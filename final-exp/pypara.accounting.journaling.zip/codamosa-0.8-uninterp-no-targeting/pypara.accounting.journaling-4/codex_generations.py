

# Generated at 2022-06-21 20:01:25.134401
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .accounts import Account, AccountType
    from finance.bookkeeping.reporting import BalanceSheet
    from finance.commons.numbers import Amount, Quantity
    from finance.commons.zeitgeist import DateRange

    period = DateRange.current_year()
    bs = BalanceSheet()
    journal = JournalEntry(datetime.datetime.now().date(), "some description", "some source")
    journal.post(datetime.datetime.now().date(), bs.accounts.get(AccountType.ASSETS), Quantity(12_00))
    journal.post(datetime.datetime.now().date(), bs.accounts.get(AccountType.REVENUES), Quantity(-10_00))

# Generated at 2022-06-21 20:01:33.800900
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Unit test for method __setattr__ of class JournalEntry
    """
    ## Assertion failure:
    # (This is just for ensuring that the `__init__` method does not fail)
    je = JournalEntry(datetime.date(2019, 1, 1), "XXX", None)
    try:
        je.postings = [Posting(je, datetime.date(2019, 1, 1), None, Direction.DEC, 1), ]
        assert False, "The above statement should have raised an AssertionError but didn't."  # pragma: no cover
    except AssertionError:
        # This is expected
        pass

# Generated at 2022-06-21 20:01:37.509292
# Unit test for constructor of class Posting
def test_Posting():
    # Constructor for Posting
    je = JournalEntry()
    assert je.date == datetime.date.today()
    assert je.description == None
    assert je.source == None
    assert je.postings == []
    assert type(je.guid) == type(Guid())

# Generated at 2022-06-21 20:01:40.609786
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting("journal", "date", "account", "direction", "amount")) == "Posting(journal=journal, date=date, account=account, direction=direction, amount=amount)"


# Generated at 2022-06-21 20:01:46.906468
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    je = JournalEntry[int](0)
    try:
        je.guid = makeguid()
    except AttributeError:
        print('Attribute guid not allowed to modify')

    try:
        je.postings = []
    except AttributeError:
        print('Attribute postings not allowed to modify')

    try:
        je.source = 1
    except AttributeError:
        print('Attribute source not allowed to modify')

# Generated at 2022-06-21 20:01:48.755485
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    with pytest.raises(AttributeError):
        JournalEntry[None].__delattr__("postings")

# Generated at 2022-06-21 20:02:00.279108
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class TestSource:
        pass
    test_source = TestSource()
    test_date = datetime.date(2019, 12, 31)
    period = DateRange(test_date, test_date)
    test_account = Account("Test Account", AccountType.ASSETS)
    test_postings = [
        Posting(None, test_date, test_account, Direction.INC, Amount(1)),
        Posting(None, test_date, test_account, Direction.DEC, Amount(1)),
    ]
    test_journal_entry = JournalEntry(test_date, "Test entry", test_source, test_postings)
    test_read_journal_entries = lambda period: [test_journal_entry]

# Generated at 2022-06-21 20:02:06.963343
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import create_account
    from ..commons.compare import equal

    _posting1 = Posting(1, 2, 3, 4)
    _posting2 = Posting(1, 2, 3, 4)
    _posting3 = Posting(2, 3, 4, 5)
    _posting4 = Posting(1, 2, "a", 4)
    _posting5 = Posting(1, 2, create_account("a"), 4)

    assert equal(_posting1, _posting2, _posting1 == _posting2)
    assert equal(_posting1, _posting3, _posting1 == _posting3)
    assert equal(_posting1, _posting4, _posting1 == _posting4)

# Generated at 2022-06-21 20:02:14.210981
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Unit test for dimensioning method ``__setattr__`` of class ``JournalEntry``.
    """
    ## Make a journal entry:
    je1 = JournalEntry(datetime.date(2020, 1, 1), "JE1", "JE-Source")
    
    ## Test:
    try:
        je1.postings.append("JE1-Posting") #will Raise Exception
    except Exception as e:
        print(e)

    # Test:
    with pytest.raises(AssertionError) as exception_info:
        je1.postings.append("JE1-Posting")

# Generated at 2022-06-21 20:02:21.621424
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from datetime import date
    from .accounts import Account as Account
    from .accounts import AccountType as AccountType
    from .accounts import AccountScheme
    from .domain import JournalEntry as JournalEntry
    from .domain import Direction as Direction
    from .domain import Posting as Posting
    from .domain import ReadJournalEntries as ReadJournalEntries
    from .commons.numbers import Quantity as Quantity
    from .commons.numbers import Amount as Amount
    journal_entry=JournalEntry()
    journal_entry.date=date(2020,1,1)
    journal_entry.description="This is just a test"
    journal_entry.source="a nice source"
    account=Account()
    account.code="123321"
    account.name="Just a test account"
    account.type=AccountType.ASSETS

# Generated at 2022-06-21 20:02:27.450731
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    pass


# Generated at 2022-06-21 20:02:38.112997
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    # given
    posting = Posting(journal=JournalEntry(date=datetime.date(year=2017, month=1, day=2), description='test', source='test'),
    date=datetime.date(year=2017, month=1, day=2), account=Account(name='test', code='123456', type=AccountType.ASSETS), direction=Direction.INC, amount=Amount(1))

    # when
    h = hash(posting)

    # then
    assert h == hash(datetime.date(year=2017, month=1, day=2)) + hash(Account(name='test', code='123456', type=AccountType.ASSETS)) + hash(Direction.INC) + hash(Amount(1))



# Generated at 2022-06-21 20:02:48.656977
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime
    
    from random import randint

    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange

    # Define a list of journal entry generators:
    journal_entry_generators = [
        lambda date: JournalEntry(date, f"Journal entry on {date}", []).post(date, "Acc1", Quantity(randint(1, 10))),
        lambda date: JournalEntry(date, f"Journal entry on {date}", []).post(date, "Acc2", Quantity(-randint(1, 10))),
    ]

    # For each day in the given period, generate a journal entry:

# Generated at 2022-06-21 20:02:54.554825
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    account = Account("A", AccountType.ASSETS)
    entry = JournalEntry(datetime.date.today(), "description", None)
    entry.post(datetime.date.today(), account, Quantity(100, "GBP"))

    print(hash(entry.postings[0]), hash(entry))

# Generated at 2022-06-21 20:02:57.609525
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    """
    Test for method __delattr__ of class JournalEntry

    """
    # Test for method __delattr__ of class JournalEntry
    pass


# Generated at 2022-06-21 20:03:08.990918
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity
    from .accounts import Account
    
    entries = []
    assert entries == []
    
    entries.append(JournalEntry[int](datetime.date.today(), "Test Journal Entry 1", 1).post(datetime.date.today(), Account('Cash'), Quantity(1000)).validate())
    assert entries[0].postings[0].amount == Quantity(1000)
    assert entries[0].postings[0].direction == Direction.INC
    assert entries[0].postings[0].is_debit == True
    assert entries[0].postings[0].is_credit == False
    assert entries[0].increments[0].amount == Quantity(1000)
    assert entries[0].debits[0].amount == Quantity(1000)
    

# Generated at 2022-06-21 20:03:14.172161
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Arrange
    journal_entry = JournalEntry(date=datetime.date.today(), description='Some description', source=None)

    # Assert
    try:
        journal_entry.postings = []
    except AttributeError as e:
        print(e)

# Generated at 2022-06-21 20:03:19.454153
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    # arrangement
    journal = JournalEntry(datetime.date.today(), 'Transaction', 'Source')
    posting = Posting(journal, datetime.date.today(), Account('Name', AccountType.ASSETS), Direction.INC, Amount(10))

    # act
    h = posting.__hash__()

    # assert
    assert h is not None

# Generated at 2022-06-21 20:03:22.978904
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Test for double-entry accounting
    with open("test_ledger.txt") as file:
        lines = file.readlines()
        print(lines)
        journal = JournalEntry.validate(lines)
        assert journal

# Generated at 2022-06-21 20:03:34.416212
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Arrange
    class TestJournalEntry(JournalEntry[str]):
        pass
    def get_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        yield TestJournalEntry(datetime.date.today(), 'test description', 'test source', [])
    case = ReadJournalEntries.__args__
    read = ReadJournalEntries.__call__
    period = DateRange.to(datetime.date.today())
    # Act
    entries = list(read(get_entries, period))
    # Assert
    assert len(entries) == 1
    assert isinstance(entries[0], case)
    assert entries[0].description == 'test description'

# Generated at 2022-06-21 20:03:51.688986
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    date = datetime.date(2020, 1, 1)
    description = "Journal Entry"
    source = 1

    je = JournalEntry(date, description, source)
    je.post(date, Account("Account1"), Quantity(1_000))
    je.post(date, Account("Account2"), Quantity(-1_000))
    je.validate()

    # Check if all the fields are printed
    print(je)

# Generated at 2022-06-21 20:04:03.501673
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import InitVar, Field

    try:
        class A:
            a0: InitVar[int]
            a0_val: Field[int]
            a1: int
            a2: int

            def __init__(self, a0):
                self.a0_val = a0
                self.a1 = a0
                self.a2 = a0

    except TypeError as e:
        print('catch TypeError: ' + str(e))
        assert str(e) == "__init__() is missing 4 required positional arguments: 'self', 'a1', 'a2', and 'unit'"

    class B:
        b0: InitVar[int]
        b0_val: Field[int]
        b1: int
        b2: int


# Generated at 2022-06-21 20:04:06.023561
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def f(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    ReadJournalEntries.__call__(f, DateRange())
    pass

# Generated at 2022-06-21 20:04:14.958956
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from datetime import date

    entry_date: date = date(2020,1,1)
    description: str = 'First journal entry of the year'
    source: str = 'Authority'
    postings: List[str] = ['cred asst', 'deb exp']

    journalEntry: JournalEntry = JournalEntry(entry_date, description, source, postings)
    assert journalEntry.date == entry_date
    assert journalEntry.description == description
    assert journalEntry.source == source
    assert journalEntry.postings == postings

# Unit tests for class Posting

# Generated at 2022-06-21 20:04:27.248803
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from .events import JournalEntry as EventJournalEntry
    from .events import Posting as EventPosting
    from .events import Event
    from .accounts import Command, Action
    from .accounts import JournalEntry as AccountJournalEntry
    from .accounts import Posting as AccountPosting
    entry = JournalEntry[Event](date=datetime.date.today(), description="Test Description")
    entry.post(date=datetime.date.today(), account=Account("foo", AccountType.ASSETS),
               quantity=Quantity(Amount(10), "USD"))
    entry.post(date=datetime.date.today(), account=Account("bar", AccountType.EQUITIES),
               quantity=Quantity(Amount(10), "USD"))
    event = Event(Command(Action.CREATE, Account("foo", AccountType.ASSETS)))
    event_journal_

# Generated at 2022-06-21 20:04:30.357914
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    with pytest.raises(TypeError):
        Posting(_T, DateTime, Account, Direction, Amount).__setattr__("", "")


# Generated at 2022-06-21 20:04:34.086710
# Unit test for constructor of class Posting
def test_Posting():
    test = Posting(JournalEntry[str], datetime.date.today(), Account("1", "ACCT"), Direction.INC, Amount(1))
    print(test)
    # assert test.journal.description == "TEST"


# Generated at 2022-06-21 20:04:35.199337
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    assert hash('foo') == hash(Posting())

# Generated at 2022-06-21 20:04:39.957448
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journalEntry = JournalEntry[str]('2020-12-11', "test", 'source')
    #print(repr(journalEntry))
    assert repr(journalEntry) == "JournalEntry(date=datetime.date(2020, 12, 11), description='test', source='source', postings=[])"



# Generated at 2022-06-21 20:04:45.331094
# Unit test for constructor of class Posting
def test_Posting():
    """
    Function to test constructor of class Posting
    """
    account = Account("KAPITAL")
    direction = Direction("INC")
    posting = Posting("journal1", "date1", account, direction, "amount1")
    assert posting.journal == "journal1"
    assert posting.date == "date1"
    assert posting.account == account
    assert posting.direction == direction
    assert posting.amount == "amount1"

# Generated at 2022-06-21 20:05:16.152792
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account, Group, AccountType
    from .books import Book
    from .transactions import Transaction, TransactionSplit

    # Test account
    account = Account(Group.ASSETS, AccountType.LIABILITIES, "account")
    # Test journal entry
    journal = JournalEntry(datetime.date(2019, 12, 31), "description", Book())

    # Test posting 1 with positive amount

# Generated at 2022-06-21 20:05:19.480918
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    a = JournalEntry(datetime.date.today(), '', '')
    setattr(a, 'date', datetime.date(2020, 4, 20))
    assert a.date == datetime.date(2020, 4, 20)

# Generated at 2022-06-21 20:05:25.767830
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting(JournalEntry[None](datetime.date.today(), "Test Description", None), datetime.date.today(), Account("Expenses", AccountType.EXPENSES), Direction.DEC, Amount(42))) == "Posting(journal=JournalEntry(date=datetime.date(2019, 3, 3), description='Test Description', source=None, guid=guid('575b77ac-d0ff-4e54-94b4-f0de4e4a0b54')), date=datetime.date(2019, 3, 3), account=Account(type=EXPENSES, name='Expenses'), direction=DEC, amount=42)"


# Generated at 2022-06-21 20:05:32.937083
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    import datetime as _dt
    from dataclasses import dataclass, field

    @dataclass(frozen=True)
    class MyBusinessObject:
        pass

    @dataclass(frozen=True)
    class MyJournalEntry(JournalEntry[MyBusinessObject]):
        date: _dt.date = _dt.date(2020, 1, 1)
        description: str = "My Description"

        def __post_init__(self):
            if not hasattr(self, "source"):
                self.source = MyBusinessObject()
            if not hasattr(self, "postings"):
                self.postings = []

    je = MyJournalEntry()
    assert je.source is not None
    assert je.postings is not None
    assert je.postings == []

# Generated at 2022-06-21 20:05:43.704373
# Unit test for constructor of class Posting
def test_Posting():
    from ..finance.currencies import Currency
    from ..finance.prices import Price
    from ..finance.transactions import Transaction, TransactionMode
    import datetime

    currency = Currency("USD")
    transaction_type = TransactionMode.EXPENSE
    transaction_date = datetime.date.today()
    transaction_description = "my expense"
    account = Account("my expense account")
    quantity = -1
    price = Price(amount=1, currency=currency)
    transaction = Transaction(transaction_type, transaction_date, transaction_description, [], price)
    posting = Posting(transaction, transaction_date, account, Direction.DEC, Amount(abs(quantity)))
    assert posting.journal == transaction
    assert posting.date == transaction_date
    assert posting.account == account
    assert posting.direction == Direction.DEC


# Generated at 2022-06-21 20:05:53.043484
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    class JournalEntryStub():
        def __init__(self):
            pass

    a = JournalEntryStub()
    b = JournalEntryStub()

    p1 = Posting(a, datetime.date(2019, 8, 1), Account.asset("cash"), Direction.INC, Amount(100))
    p2 = Posting(b, datetime.date(2019, 8, 1), Account.asset("cash"), Direction.INC, Amount(100))
    p3 = Posting(a, datetime.date(2019, 8, 2), Account.asset("cash"), Direction.INC, Amount(100))
    p4 = Posting(a, datetime.date(2019, 8, 1), Account.asset("cash"), Direction.INC, Amount(50))
    assert p1 == p2
    assert p1 != p3
   

# Generated at 2022-06-21 20:05:58.718064
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Arrange
    from .accounts import AccountFactory

    # Assets
    account_cash = AccountFactory.get_cash()
    account_bank = AccountFactory.get_bank()
    account_inventory = AccountFactory.get_inventory()

    # Liability
    account_loan = AccountFactory.get_loan()

    # Owner's Equity
    account_capital_funds = AccountFactory.get_capital_funds()

    # Income
    account_sales_revenue = AccountFactory.get_sales_revenue()
    account_services_revenue = AccountFactory.get_services_revenue()
    account_interest_revenue = AccountFactory.get_interest_revenue()

    # Expenses
    account_sales_costs = AccountFactory.get_sales_costs()

# Generated at 2022-06-21 20:06:04.458933
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry[int](date=datetime.date(2020, 1, 2),
                             description='This is a journal entry',
                             source=42) == JournalEntry[int](date=datetime.date(2020, 1, 2),
                                                             description='This is a journal entry',
                                                             source=42)

# Generated at 2022-06-21 20:06:05.516281
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries(): 
    # Normal case
    pass

# Generated at 2022-06-21 20:06:14.254794
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # Arrange
    je1 = JournalEntry(datetime.date(2011, 1, 1), 'Some description', 'This is the source #1')
    je1.post(datetime.date(2011, 1, 1), Account('Assets', 'Cash'), Amount(100, 'CAD'))
    je1.post(datetime.date(2011, 1, 1), Account('Expenses', 'Expenses'), Amount(100, 'CAD'))
    je2 = JournalEntry(datetime.date(2011, 1, 1), 'Some description', 'This is the source #2')
    je2.post(datetime.date(2011, 1, 1), Account('Assets', 'Cash'), Amount(100, 'CAD'))

# Generated at 2022-06-21 20:06:33.925564
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    """
        Tests if the method __hash__ of the class Posting work as expected
    """
    pass

# Pytest unit tests for the class Posting

# Generated at 2022-06-21 20:06:43.914852
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    import datetime
    from ..commons.numbers import ZERO
    from ..commons.zeitgeist import DateRange
    from ..entities.accounts import AccountsManager
    from ..entities.accounts.accounts import _Account, Account
    from ..entities.accounts.accounts_manager import AccountsManager
    from ..rdo import ReadRDO

    # Define an account:
    def get_accounts():
        yield Account("Personal", "Assets", "", "", "Business", "Cash")
        yield Account("Dividends", "Assets", "", "", "Business", "Dividends")
        yield Account("Business", "Expenses", "", "", "Business", "Meals and Entertainment")

    # Define an RDO:

# Generated at 2022-06-21 20:06:48.584339
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    p = Posting(None, None, None, Direction.INC, 1)
    try:
        p.journal = None
    except AttributeError as e:
        assert str(e) == "can't set attribute"


# Generated at 2022-06-21 20:06:59.047837
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    data_JournalEntry = datetime.date(year=2019, month=3, day=1)
    data_JournalEntry_Description = 'Description 1'
    data_JournalEntry_GUID = '7e00078e-ea2c-454f-b212-4048ec0f9db9'
    data_JournalEntry_Source = 'Source 1'
    data_JournalEntry_Postings_Date = datetime.date(year=2019, month=3, day=2)
    data_JournalEntry_Postings_Account_Name = 'Name 1'
    data_JournalEntry_Postings_Account_Code = 'Code 1'
    data_JournalEntry_Postings_Account_Type_Name = 'Type 1'
    data_JournalEntry_Postings_Account_Type_Code = 'TypeCode 1'
    data_JournalEntry_Post

# Generated at 2022-06-21 20:07:00.108221
# Unit test for constructor of class Posting
def test_Posting():
    pass


# Generated at 2022-06-21 20:07:11.752357
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # Test case 1
    entry1 = JournalEntry[int](
        date=datetime.date(2020, 1, 1),
        description="test_JournalEntry___eq___1",
        source=1)
    entry1.post(
        date=entry1.date,
        account=Account("101", "Cash", AccountType.ASSETS),
        quantity=10)
    entry1.post(
        date=entry1.date,
        account=Account("102", "Accounts Receivable", AccountType.ASSETS),
        quantity=20)
    entry1.post(
        date=entry1.date,
        account=Account("201", "Accounts Payable", AccountType.EQUITIES),
        quantity=-30)


# Generated at 2022-06-21 20:07:15.698718
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    entry1 = JournalEntry[str]('2020-09-22', 'Compras mes de Setembro', 'pc')
    entry2 = JournalEntry[str]('2020-09-23', 'Compras mes de Setembro', 'pc')
    assert entry1.postings.__eq__(entry2) == False

# Generated at 2022-06-21 20:07:19.984089
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journal1 = JournalEntry(datetime.date(2019, 1, 1), "description", "source")
    assert journal1 == journal1
    journal2 = JournalEntry(datetime.date(2019, 1, 2), "description", "source")
    assert journal1 != journal2


# Generated at 2022-06-21 20:07:30.627672
# Unit test for method __repr__ of class Posting

# Generated at 2022-06-21 20:07:39.549859
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    j = JournalEntry(date=datetime.date(2020, 8, 17), description='testing', source='test')
    j.post(date=datetime.date(2020, 8, 18), account='cash', quantity=1000.00)
    j.post(date=datetime.date(2020, 8, 18), account='expenses:salaries', quantity=-1000.00)
    j.validate()
    hash_x = hash(j.postings[0])
    hash_y = hash(j.postings[1])
    assert hash_x != hash_y

# Generated at 2022-06-21 20:08:22.025382
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[object]("2020/01/01", "test", None)
    je.post(datetime.date(2020, 1, 1), Account("Assets", AccountType.ASSETS), 10000)
    je.post(datetime.date(2020, 1, 1), Account("Expenses", AccountType.EXPENSES), -10000)
    je.validate()

# Generated at 2022-06-21 20:08:24.027388
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def _(period: DateRange) -> Iterable[JournalEntry[_T]]:
        assert isinstance(period, DateRange)
        return []

    ReadJournalEntries.__call__(_, DateRange())

# Generated at 2022-06-21 20:08:25.895233
# Unit test for constructor of class Posting
def test_Posting():
    posting = Posting("", datetime, "", str, Amount)
    assert posting != None



# Generated at 2022-06-21 20:08:33.041743
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    class journal:
        source = 'source'
    p1 = Posting(journal, datetime.date(2020, 1, 1), Account('A'), Direction.INC, Amount(10))
    p2 = Posting(journal, datetime.date(2020, 1, 1), Account('A'), Direction.INC, Amount(10))
    assert p1 == p2


# Generated at 2022-06-21 20:08:41.278454
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    base_date = datetime.date(2020, 1, 1)
    class TestJournalEntry(JournalEntry): pass
    test_je = TestJournalEntry(
        date=base_date, source=None, description="testing", postings=[
            Posting(journal=test_je, date=base_date, account=Account("test"), direction=Direction.INC, amount=Amount(1)),
            Posting(journal=test_je, date=base_date, account=Account("test"), direction=Direction.DEC, amount=Amount(1)),
        ]
    )
    try:
        test_je.validate()
    except:
        raise Exception('Expected: total_debit == total_credit, Actual: total_debit != total_credit')
    else:
        print('test_JournalEntry_validate passed')

# Unit

# Generated at 2022-06-21 20:08:46.137526
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date
    from .accounts import Account
    journal = JournalEntry[int](date.today(), "JournalEntry", 1)
    journal.post(date.today(), Account("Expense Account"), -1000)
    print(journal.postings)
    assert 2==2

# Generated at 2022-06-21 20:08:54.589347
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    @dataclass(frozen=True)
    class Entity(Generic[_T]):
        """
        Entity value object.
        """

        #: Globally unique, ephemeral identifier.
        guid: Guid

    je = JournalEntry[Entity[str]](datetime.date(2020,5,5), "Test JournalEntry", Entity(Guid("0")))
    je = je.post(datetime.date(2020,5,5), Account("Test Account"), 5)

# Generated at 2022-06-21 20:09:04.519766
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from datetime import datetime
    from decimal import Decimal
    from .accounts import AccountType, Account

    from datetime import date
    from decimal import Decimal
    from .accounts import AccountType, Account
    from .commons.numbers import Amount, Quantity
    from .commons.others import Guid, makeguid, DateRange
    from .services import ReadJournalEntries, read_journal_entries, read_journal_entries_from_csv

    # Journal entry class:
    class JournalEntry:
        @property
        def date(self) -> datetime.date:
            return date(2019, 4, 15)

        @property
        def description(self) -> str:
            return "description of budgeted expense"

        @property
        def source(self) -> str:
            return "budget"


# Generated at 2022-06-21 20:09:12.775869
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType

    class readJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return [JournalEntry(date(2020, 5, 1), "A Pay Cheque", "abc", [Posting(None, date(2020, 5, 1), Account(AccountType.EQUITIES, "Equities", "Owner's Equities", "Owner's Contributions", "Owner's Capital"), Direction.INC, Amount(1000000))])]
    journal_entries_list = readJournalEntries()(DateRange(date(2020, 4, 30), date(2020, 6, 1)))
    assert journal_entries_list is not None

# Generated at 2022-06-21 20:09:23.028014
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, DebitCreditRule
    from .accounts import Account
    from .accounts.rulebased import RuleBasedAccount

    account = RuleBasedAccount(
        "TEST", AccountType.ASSETS, DebitCreditRule.DEBIT_INCREASES_BALANCE, None)

    entry = JournalEntry.from_rule_based(datetime.date(2018, 12, 1), "Journal Entry TEST", account, 0)
    entry.post(datetime.date(2018, 12, 1), account, 100)

    assert entry.postings[0].account == account
    assert entry.postings[0].direction == Direction.INC
    assert entry.postings[0].amount == Amount(100)
    assert entry.postings[0].is_debit

# Generated at 2022-06-21 20:10:53.854717
# Unit test for constructor of class Posting
def test_Posting():
    journal = JournalEntry

# Generated at 2022-06-21 20:10:55.170556
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    pass

# Generated at 2022-06-21 20:10:59.529083
# Unit test for constructor of class Posting
def test_Posting():
    account = Account(AccountType.EXPENSES)
    date = datetime.date.today()
    direction = Direction.DEC
    amount = Amount(12)
    journal = JournalEntry(date, "", "")
    posting = Posting(journal, date, account, direction, amount)
    assert posting.journal == journal and posting.date == date and posting.account == account and posting.direction == direction and posting.amount == amount


# Generated at 2022-06-21 20:11:09.529118
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    j = JournalEntry("")
    p1 = Posting(j, datetime.date("2020", "01", "01"), "A", Direction.INC, 100)
    p2 = Posting(j, datetime.date("2020", "01", "01"), "A", Direction.INC, 100)
    p3 = Posting(j, datetime.date("2020", "01", "01"), "B", Direction.INC, 100)
    p4 = Posting(j, datetime.date("2020", "01", "01"), "A", Direction.DEC, 100)
    p5 = Posting(j, datetime.date("2020", "01", "01"), "A", Direction.INC, 500)
    p6 = Posting(j, datetime.date("2020", "01", "02"), "A", Direction.INC, 100)