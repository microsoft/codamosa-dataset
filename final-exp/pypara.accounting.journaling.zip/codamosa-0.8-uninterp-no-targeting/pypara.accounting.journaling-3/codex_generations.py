

# Generated at 2022-06-21 20:01:15.523417
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(JournalEntry(), None, None, None, None) == Posting(JournalEntry(), None, None, None, None)


# Generated at 2022-06-21 20:01:22.148367
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    import datetime
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account

    testObj = JournalEntry(datetime.date(2019, 12, 31), "test journal entry", "test source object")
    testObj.post(datetime.date(2019, 12, 31), Account(1, "test account", "test account", AccountType.ASSETS), Quantity(100))
    assert repr(testObj) == "<JournalEntry> 'test journal entry' [2019-12-31]"

# Generated at 2022-06-21 20:01:30.490639
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Setup
    # Execute
    result = JournalEntry(date=datetime.date.fromisoformat("2020-05-20"), description="Payment for subscription service.", source=None).__repr__()
    # Verify
    assert result == "JournalEntry(date=datetime.date(2020, 5, 20), description='Payment for subscription service.', source=None)"


# Generated at 2022-06-21 20:01:35.246106
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    j = JournalEntry[int](datetime.date.today(), "Description", 1)
    assert isinstance(j.postings, list)
    assert isinstance(j.guid, Guid)
    assert j.source == 1
    assert j.date == datetime.date.today()
    assert j.description == "Description"


# Generated at 2022-06-21 20:01:39.991619
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    new_test_JournalEntry = JournalEntry(date = '2018-01-01', description = 'New entry', source = 21)
    assert new_test_JournalEntry.date == '2018-01-01'
    assert new_test_JournalEntry.description == 'New entry'
    assert new_test_JournalEntry.source == 21


# Generated at 2022-06-21 20:01:41.079676
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    pass


# Generated at 2022-06-21 20:01:50.628803
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    import unittest

    # Declare a journal entry
    journal_entry1 = JournalEntry(date=datetime.date(2019,1,1), description='Test for Journal entry hash', source="")

    # Declare another journal entry
    journal_entry2 = JournalEntry(date=datetime.date(2019,1,1), description='Test for Journal entry hash', source="")

    # Test for hashtability
    assert hash(journal_entry1) == hash(journal_entry2)

    # Test for unhashability
    with unittest.TestCase():
        with unittest.TestCase.assertRaises(TypeError):
            hash(JournalEntry)

# Generated at 2022-06-21 20:02:01.504566
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    import datetime
    from typing import List
    from dataclasses import dataclass
    from ..commons.others import makeguid
    from .accounts import Account, AccountType, AccountStatus
    from .entries import JournalEntry, Posting, Direction
    from ..commons.numbers import Amount, Quantity

    @dataclass(frozen=True)
    class SomeBusinessClass:
        """A class for testing POSTING"""
        pass

    @dataclass(frozen=True)
    class SomeOtherBusinessClass:
        """A class for testing POSTING"""
        pass

    journal1 = JournalEntry[SomeBusinessClass](datetime.date.today(), "Test Journal Entry", SomeBusinessClass())

# Generated at 2022-06-21 20:02:13.556364
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():

    from dataclasses import MISSING
    from dataclasses import _HAS_DEFAULT_FACTORY, _FIELDS, _FIELD_TYPE, _FIELD_DEFAULT_FACTORY
    from dataclasses import _MISSING_TYPE
    from dataclasses import _is_dataclass_instance
    from dataclasses import _process_class
    from dataclasses import _copy_instance
    from dataclasses import _process_field
    from dataclasses import _DeepCopyTypes
    import inspect
    import builtins

    # inspect.Parameter.empty
    # inspect.Parameter.default
    # inspect.Parameter.kind
    # inspect.Parameter.empty

    __setattr__ = builtins.setattr
    __delattr__ = builtins.delattr

    def __setattr__(self, name, value):

        __

# Generated at 2022-06-21 20:02:24.151552
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Declare JournalEntry values
    source_1 = "value2"
    source_2 = "value3"
    source_3 = "value4"
    # source_1 and source_2 are two different source
    # source_3 is a copy of source_1
    source_3 = source_1
    # Declare JournalEntry objects
    journal_entry_1 = JournalEntry(datetime.date(2020, 1, 1), "description", source_1)
    journal_entry_2 = JournalEntry(datetime.date(2020, 1, 1), "description", source_2)
    journal_entry_3 = JournalEntry(datetime.date(2020, 1, 1), "description", source_1)
    # Declare hash sets
    hash_set = set()
    hash_set.add(journal_entry_1)
   

# Generated at 2022-06-21 20:02:33.780521
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # this test only passes if the method __delattr__ works
    # otherwise a TypeError is raised
    j = JournalEntry(datetime.date(2020,1,1), 'test', '') # create a journal entry
    del j.postings # delete the attribute
    j.validate() # call the method __delattr__

# Generated at 2022-06-21 20:02:42.701553
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Create a sample JournalEntry
    journal_entry = JournalEntry(DateRange(date(2020, 9, 1), date(2020, 9, 2)))
    print(journal_entry)
    # Assert that the representation is correct
    assert (str(journal_entry)) == ("JournalEntry[date=" + str(journal_entry.date) + ", description=" + str(
        journal_entry.description) + ", source=" + str(journal_entry.source) + ", postings=" + str(
        [posting.__repr__() for posting in journal_entry.postings]) + ", guid=" + str(journal_entry.guid) + "]")



# Generated at 2022-06-21 20:02:50.308612
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    from .accounts import Account
    from .balances import Balance

    posting = Posting(journal=None, date=date(2020, 1, 1), account=Account(name='Account1'), direction=Direction.DEC, amount=Amount(12345))

    # This is known to be a private method. But still, it is called.
    posting.__setattr__('direction',Direction.INC)

    # Check the correctness of the result.
    assert posting.direction == Direction.INC, f'Expected: Direction.INC, Actual: {posting.direction}'
    assert posting.amount == 12345, f'Expected: 12345, Actual: {posting.amount}'

    # This is known to be a private method. But still, it is called.

# Generated at 2022-06-21 20:03:02.558846
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from ddd_ledger.ledger import JournalEntry
    # Arrange
    guid1 = "01234567-0123-0123-0123-0123456789AB"
    guid2 = "01234567-0123-0123-0123-0123456789AC"

    source1 = "test1"
    source2 = "test2"

    journal_entry1 = JournalEntry(source=source1, guid=guid1, date=datetime.date.today(), description="test")
    journal_entry2 = JournalEntry(source=source1, guid=guid1, date=datetime.date.today(), description="test")
    journal_entry3 = JournalEntry(source=source1, guid=guid2, date=datetime.date.today(), description="test")

# Generated at 2022-06-21 20:03:12.180424
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import Date

    @dataclass(frozen=True)
    class BusinessObject:
        ...

    # Arrange:
    j1 = JournalEntry[BusinessObject](
        date=Date("2018-08-01"),
        description="Desc 1",
        source=BusinessObject(),
    ).post(Date("2018-08-01"), Account("A"), Quantity(100))
    j2 = JournalEntry[BusinessObject](
        date=Date("2018-09-01"),
        description="Desc 1",
        source=BusinessObject(),
    ).post(Date("2018-09-01"), Account("B"), Quantity(100))

# Generated at 2022-06-21 20:03:24.390612
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from ..gl.chart import ChartOfAccounts
    from ..gl.services import load_chart

    chart = load_chart(ChartOfAccounts())

    entry = JournalEntry(datetime.date(2019, 1, 25), "Payment", None)
    debit_account = chart.account("cash")
    credit_account = chart.account("revenue")

    entry.post(entry.date, debit_account, 10_000).post(entry.date, credit_account, 10_000)

    assert entry.guid != ""
    assert len(entry.postings) == 2
    assert entry.source is None

    delattr(entry, "guid")
    assert entry.guid == ""
    del entry.postings
    assert entry.postings == []
    del entry.source
    assert entry.source is None

# Generated at 2022-06-21 20:03:34.642551
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    @dataclass(frozen=True)
    class A:
        pass

    a = A()

    @dataclass(frozen=True)
    class E:
        description: str
        source: A

    e = E(description='test', source=a)

    with pytest.raises(AttributeError) as excinfo:
        e.description = 'test2'

    assert(str(excinfo.value) == "can't set attribute")

    with pytest.raises(AttributeError) as excinfo:
        e.source = A()

    assert(str(excinfo.value) == "can't set attribute")

# Generated at 2022-06-21 20:03:41.671420
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # True
    assert JournalEntry(datetime.date(2019, 1, 1), "Description1", "A") == JournalEntry(datetime.date(2019, 1, 1), "Description1", "A")
    # False
    assert JournalEntry(datetime.date(2018, 1, 1), "Description1", "A") != JournalEntry(datetime.date(2019, 1, 1), "Description1", "A")
    assert JournalEntry(datetime.date(2019, 11, 1), "Description1", "A") != JournalEntry(datetime.date(2019, 1, 1), "Description1", "A")
    assert JournalEntry(datetime.date(2019, 1, 12), "Description1", "A") != JournalEntry(datetime.date(2019, 1, 1), "Description1", "A")

# Generated at 2022-06-21 20:03:51.803343
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Tests if we can set the `description` field of JournalEntry instance
    """
    # Given a journal entry
    j = JournalEntry[str](
        date = datetime.date(2020, 5, 6),
        description = "Foo",
        source = "Bar"
    )
    # When we change the `description` field of the journal entry
    j.description = "Baz"
    # Then we get the updated description of the journal entry
    assert j.description == "Baz"
    # Then we get the same date as before
    assert j.date == datetime.date(2020, 5, 6)
    # Then we get the same source as before
    assert j.source == "Bar"

# Generated at 2022-06-21 20:04:01.339930
# Unit test for constructor of class Posting
def test_Posting():
    source = 'debit'
    date = datetime.date(2018,12,13)
    account = Account("Banking",AccountType.ASSETS)
    direction = Direction.INC
    amount = Amount(35)
    posting_object = Posting(source,date,account,direction,amount)
    assert isinstance(posting_object.journal,str)
    assert posting_object.date == datetime.date(2018,12,13)
    assert posting_object.account == Account("Banking",AccountType.ASSETS)
    assert posting_object.direction == Direction.INC
    assert posting_object.amount == Amount(35)

# Generated at 2022-06-21 20:04:29.119322
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from itertools import islice
    from random import randint
    from collections import defaultdict

    # Generate a bunch of unique entries
    entries = []
    for i in range(0, 100):
        entries.append(
            Posting(
                journal=(),
                date=datetime.date(2020, randint(1, 12), randint(1, 28)),
                account=Account("Account{}".format(i), "Account{}".format(i), AccountType.ASSETS),
                direction=Direction.INC,
                amount=i,
            )
        )

    # Count instances per hash
    hash_count = defaultdict(int)
    for e in entries:
        hash_count[hash(e)] += 1

    # Check number of instances per hash

# Generated at 2022-06-21 20:04:40.503006
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    posting1 = Posting(JournalEntry(date=datetime.date.today(), description="foo", source="bar"),
                       date=datetime.date.today(), account=Account("Assets", AccountType.ASSETS), direction=Direction.INC, amount=Amount(100))
    posting2 = Posting(JournalEntry(date=datetime.date.today(), description="foo", source="bar"),
                       date=datetime.date.today(), account=Account("Assets", AccountType.ASSETS), direction=Direction.INC, amount=Amount(100))
    posting3 = Posting(JournalEntry(date=datetime.date.today(), description="foo", source="bar"),
                       date=datetime.date.today(), account=Account("Assets", AccountType.ASSETS), direction=Direction.DEC, amount=Amount(100))

# Generated at 2022-06-21 20:04:45.637897
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # This either doesn't complain about "async" as a varible name or does so with an error message
    # that I can't find a way to match in the test.
    FakeJournalEntry = JournalEntry["FakeSource"]

# Generated at 2022-06-21 20:04:47.256425
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    pass


# Generated at 2022-06-21 20:04:48.261882
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert callable(ReadJournalEntries)

# Generated at 2022-06-21 20:04:53.091600
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from datetime import date
    from .accounts import Account
    from .transactions import Transaction

    journal_entry = JournalEntry[Transaction](date(2020, 1, 1), "Test", Transaction())
    journal_entry.post(date(2020, 1, 1), Account("TestAccount"), 100)
    repr(journal_entry)

# Generated at 2022-06-21 20:05:04.997492
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .financial_periods import FinancialYear
    from .products import AccountType, Product, ProductType

    year = FinancialYear(2015)

    Product.list_or_create(
        ProductType.ASSET,
        AccountType.ASSETS,
        AccountType.EQUITIES,
        AccountType.LIABILITIES,
        AccountType.REVENUES,
        AccountType.EXPENSES,
    )
    assert len(Product.objects) == 6

    product_cash = Product.objects[0]
    product_revenue = Product.objects[1]
    product_expenses = Product.objects[2]

    # create general journal entry
    general_je_1 = JournalEntry(year.start, "General Journal entry - 1", None)

# Generated at 2022-06-21 20:05:07.392678
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p = Posting(None, None, None, None, None)
    a = hash(p)

# Generated at 2022-06-21 20:05:18.014717
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Tests if the method validate of class JournalEntry is working as expected.
    """
    ## Define the variables to be used on the test:
    date = datetime.date(2020, 1, 1)
    source = Account.new_asset_account('Dummy Account')

    ## Create the journal entry:
    journal_entry = JournalEntry[Account](date, 'Test', source)

    ## Make a journal entry with no postings:
    journal_entry.validate()

    ## Make a journal entry with two postings:
    journal_entry.post(date, Account.new_income_account('Dummy Income Account'), 10)
    journal_entry.post(date, Account.new_expenses_account('Dummy Expenses Account'), -10)

    ## Validate the new journal entry
    journal_entry.validate()

# Generated at 2022-06-21 20:05:19.479543
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert False, "Not implemented. Need to add tests before implementing this method."

# Generated at 2022-06-21 20:05:39.078291
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import Account

    posting = Posting('', '2020-01-01', Account('Equity', AccountType.EQUITIES), Direction.INC, Amount(123.45))

    assert repr(posting) == "Posting(journal='', date=datetime.date(2020, 1, 1), account=Account(name='Equity', type=<AccountType.EQUITIES: 4>), direction=<Direction.INC: 1>, amount=Amount(123.45))"

# Generated at 2022-06-21 20:05:45.032606
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    p = Posting(None, datetime.date.today(), Account(0, "", "", AccountType.ASSETS), Direction.INC, Amount(0))
    try:
        p.date = datetime.date(2000, 1, 1)
        assert False, "Expected an AssertionError."
    except AssertionError:
        pass


# Generated at 2022-06-21 20:05:53.203881
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry(datetime.date(2020,6,15), "Test Journal", JournalEntry, List[Posting])
    assert repr(Posting(journal, datetime.date(2020,6,15), Account("Test Account","Test Account Type"), Direction.INC, Amount(100))) == "Posting(journal=JournalEntry(date=datetime.date(2020, 6, 15), description='Test Journal', source=List[Posting], guid=f64a06e95a064939b0a49a1679d69fc9), date=datetime.date(2020, 6, 15), account=Account(name='Test Account', type='Test Account Type'), direction=<Direction.INC: 1>, amount=100)"


# Generated at 2022-06-21 20:05:54.173871
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-21 20:06:06.103451
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # construct
    je = JournalEntry(date=datetime.date(2020, 8, 16))
    je.description = "description"
    je.source = "source"
    assert not je.postings

    # should not raise
    je.guid = "not_a_guid"

    # should raise since guid is auto-generated
    from pytest import raises
    with raises(TypeError) as excinfo:
        je.guid = "not_a_guid"
    assert "Cannot set 'guid' on frozen instance" in str(excinfo.value)

    # should raise since deleted attribute and not permitted to set
    from pytest import raises
    with raises(AttributeError) as excinfo:
        je.postings = "not_a_postings"

# Generated at 2022-06-21 20:06:16.220436
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import AccountType, Account
    from .tags import Tag
    from .taxes import Tax
    from .business import Invoice

    # Create journal entries
    j1 = JournalEntry(date=datetime.date(2019, 4, 1), description="This is journal entry 1").post(
        date=datetime.date(2019, 4, 1), account=Account.of(AccountType.ASSETS, "Cash", Tag.of("Asset"),
                                                           Tag.of("Cash"), Tax.of("VAT")), quantity=10000
    ).post(
        date=datetime.date(2019, 4, 1), account=Account.of(AccountType.REVENUES, "Retained Earnings",
                                                           Tag.of("Retained Earning"), Tag.of("Equity")), quantity=-10000
    )

# Generated at 2022-06-21 20:06:21.414931
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    """
    Constructor of ReadJournalEntries
    """
    valid_Posting = Posting(datetime.date.today(), 'test_account', Direction.INC,  Amount(12))
    instance = JournalEntry(datetime.date.today(), 'test_description', 'test_source', [valid_Posting])
    assert isinstance(instance.postings, list)

    instance.post(datetime.date.today(), 'test_account', Amount(12))
    assert isinstance(instance.postings, list)
    instance.post(datetime.date.today(), 'test_account', Amount(12))
    assert isinstance(instance.postings, list)
    instance.post(datetime.date.today(), 'test_account', Amount(14))
    assert isinstance(instance.postings, list)


# Generated at 2022-06-21 20:06:29.083428
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from datetime import date
    from .accounts import Account, AccountType

    # An account
    x = Account("x", "x", AccountType.ASSETS)

    # A journal entry
    je = JournalEntry(date.today(),"Description",None).post(date.today(),x,100)

    # Test __delattr__
    assert je in vars(je).values()
    delattr(je, "postings")
    assert je not in vars(je).values()

test_JournalEntry___delattr__()


# Generated at 2022-06-21 20:06:40.336397
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    journal = JournalEntry(datetime.date(2020, 1, 1), "This is a test")

    posting1 = Posting(journal, datetime.date(2020, 1, 1), "EXPENSES", Direction.INC, 1)
    posting2 = Posting(journal, datetime.date(2020, 1, 1), "EQUITIES", Direction.DEC, 1)

    assert posting1.is_debit
    assert posting2.is_debit

    journal.post(datetime.date(2020, 1, 1), "EXPENSES", +1)
    journal.post(datetime.date(2020, 1, 1), "EQUITIES", -1)
    journal.validate()

test_Posting___delattr__()

# Generated at 2022-06-21 20:06:52.673027
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from decimal import Decimal

    class DummyClass:
        def __init__(self, name):
            self.name = name

    dummy_1 = DummyClass('dummy_1')
    dummy_2 = DummyClass('dummy_2')

    dummy_1_account_1 = Account(
        name='dummy_1_account_1',
        type=AccountType.ASSETS
    )

    dummy_1_account_2 = Account(
        name='dummy_1_account_2',
        type=AccountType.EQUITIES
    )

    dummy_2_account_1 = Account(
        name='dummy_2_account_1',
        type=AccountType.EXPENSES
    )


# Generated at 2022-06-21 20:07:27.983813
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account1 = Account("A1", AccountType.ASSETS)
    account2 = Account("A2", AccountType.ASSETS)
    account3 = Account("A3", AccountType.EXPENSES)
    account4 = Account("A4", AccountType.REVENUES)

    # make a journal entry instance
    journal = JournalEntry("2019-03-31", "A test journal entry", None)
    # add amounts to accounts
    journal.post(datetime.date(2019, 3, 31), account1, 100)
    journal.post(datetime.date(2019, 3, 31), account2, -50)
    journal.post(datetime.date(2019, 3, 31), account3, -10)
    journal.post(datetime.date(2019, 3, 31), account4, 10)
    # test the account amounts are

# Generated at 2022-06-21 20:07:33.233209
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting("a", "b", "c", Direction("d"), Amount("e"))
    p2 = Posting("a", "b", "c", Direction("d"), Amount("e"))

    assert p1.__eq__(p2) == True

# Generated at 2022-06-21 20:07:33.909125
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-21 20:07:42.261737
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from collections import UserList
    from datetime import date
    from decimal import Decimal

    from ..commons.numbers import Amount

    from .accounts import Account, AccountType
    from .ledgers import Ledger

    l: Ledger = Ledger("Test Ledger", "Test description")
    l.open_accounts(
        (
            Account(AccountType.ASSETS, "Cash", "Cash in hand"),
            Account(AccountType.ASSETS, "Debtors", "Customers"),
            Account(AccountType.REVENUES, "Sales", "Sales of goods"),
            Account(AccountType.EXPENSES, "COGS", "Cost of Goods Sold"),
        )
    )


# Generated at 2022-06-21 20:07:50.887501
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    journal = JournalEntry['source']
    date = datetime.date(2020, 10, 1)
    account = Account(Guid('5373cf9d-b0a6-4514-a32b-e3e6a2b6d0c6'), 'a1')
    direction = Direction.INC
    amount = Amount(1000)

    p = Posting(journal, date, account, direction, amount)

    del p.journal
    del p.date
    del p.account
    del p.direction
    del p.amount


# Generated at 2022-06-21 20:07:56.280288
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    p = Posting(None, datetime.date.today(), Account(1, "An account", AccountType.ASSETS), Direction.INC, Amount(1))
    assert repr(p) == "Posting(Guid('9b907e5d-4191-4236-84a4-2e26f3d3f97c'), datetime.date(2020, 4, 29), " \
                       "Account('An account'), Direction.INC, Amount(1))"


# Generated at 2022-06-21 20:08:00.250206
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    source = ()
    date = datetime.date.today()
    account = Account("Account")
    direction = Direction.DEC
    amount = Amount(2)
    journal = JournalEntry(date, "Description", source)
    posting1 = Posting(journal, date, account, direction, amount)
    posting2 = Posting(journal, date, account, direction, amount)
    assert posting1 == posting2

# Generated at 2022-06-21 20:08:06.026254
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert hasattr(ReadJournalEntries, '__call__')
    assert hasattr(ReadJournalEntries.__call__, '__annotations__')
    assert 'period' in ReadJournalEntries.__call__.__annotations__
    assert 'return' in ReadJournalEntries.__call__.__annotations__

# Generated at 2022-06-21 20:08:16.104157
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__(): 
    obj = JournalEntry(None, None, None)
    try:
        obj.journal = "new value"
        assert False, "Expected AttributeError"
    except AttributeError:
        pass 
    try:
        obj.date = "new value"
        assert False, "Expected AttributeError"
    except AttributeError:
        pass 
    try:
        obj.description = "new value"
        assert False, "Expected AttributeError"
    except AttributeError:
        pass 
    try:
        obj.source = "new value"
        assert False, "Expected AttributeError"
    except AttributeError:
        pass 
    try:
        obj.postings = "new value"
        assert False, "Expected AttributeError"
    except AttributeError:
        pass 

# Generated at 2022-06-21 20:08:27.289841
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .accounts import IncomeAccount, ExpensesAccount, AssetsAccount
    from datetime import date
    from .interfaces import Post_Entry
    a = AssetsAccount("A")
    e = ExpensesAccount("E")
    i = IncomeAccount("I")
    @dataclass(frozen=True)
    class Entity:
        """
        A business entity which can create a journal entry.
        """
        #: Identifier of the entity.
        identifier: str

        #: Posting event of the entity.
        post_entry: Post_Entry

        #: Event handler to create a journal entry and post it to the source.
        def post(self) -> None:
            self.post_entry(JournalEntry[Entity](date.today(), "", self))

    entity = Entity("Entity", Post_Entry(a, i, e, a))

# Generated at 2022-06-21 20:09:42.788843
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    pass


# Generated at 2022-06-21 20:09:52.485181
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import Account
    from .accounts import AccountType

    # Data
    journal_date = datetime.date(2020, 7, 1)
    journal_description = "first journal"
    journal_source = "first source"
    journal_postings_one = [(datetime.date(2020,7,1), Account("1", AccountType.ASSETS, "cash"), 100)]
    journal_postings_two = [(datetime.date(2020,7,1), Account("2", AccountType.ASSETS, "cash"), 200)]

    # Assert that creating journal entries with different construction methods produces identical results
    journal_entry_one = JournalEntry[str](journal_date, journal_description, journal_source, journal_postings_one)

# Generated at 2022-06-21 20:10:04.275215
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .amounts import Currency

    journal1 = JournalEntry(datetime.date(2018, 10, 10), 'test description', '')
    journal2 = JournalEntry(datetime.date(2018, 10, 10), 'test description', '')

    account1 = Account("Test Account 1")
    account2 = Account("Test Account 2")

    posting1 = Posting(journal1, datetime.date(2018, 10, 10), account1, Direction.INC, Amount(1, Currency.USD))
    posting2 = Posting(journal2, datetime.date(2018, 10, 10), account2, Direction.INC, Amount(1, Currency.USD))

    assert posting1 == posting1
    assert posting1 != posting2


# Generated at 2022-06-21 20:10:15.073261
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from typing import NamedTuple
    from .accounts import Account, AccountType
    from .commons import Period

    class Mock(NamedTuple):
        amount: int

    journal1 = JournalEntry(date=datetime.date(2020, 1, 1), description='Test', source=Mock(100))
    journal2 = JournalEntry(date=datetime.date(2020, 1, 1), description='Test', source=Mock(100))
    journal3 = JournalEntry(date=datetime.date(2020, 1, 1), description='Test', source=Mock(100))
    journal1.post(datetime.date(2020, 1, 1), Account('Assets', AccountType.ASSETS), Quantity(100))

# Generated at 2022-06-21 20:10:21.298743
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting

    journal = JournalEntry("A journal entry")
    posting_a = Posting(journal, datetime.datetime.now(), Account("An account", AccountType.ASSETS), Direction.INC, Amount(100))
    posting_b = Posting(journal, datetime.datetime.now(), Account("An account", AccountType.ASSETS), Direction.INC, Amount(100))
    posting_c = Posting(journal, datetime.datetime.now(), Account("An account", AccountType.ASSETS), Direction.DEC, Amount(100))
    posting_d = Posting(journal, datetime.datetime.now(), Account("Another account", AccountType.ASSETS), Direction.INC, Amount(100))

# Generated at 2022-06-21 20:10:30.764284
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Ledger, AccountCode
    from .events import PaymentReceived, PaymentMade
    from ..commons.numbers import Amount, Quantity
    
    # Set up an account
    led = Ledger()
    acc = led.add_account(AccountCode("1111"), "test", AccountType.ASSETS)
    # Create a new JournalEntry
    je = JournalEntry(datetime.date.today(), "Unit test", acc)
    # Post to the journalEntry
    je.post(datetime.date.today(), acc, Quantity(100))
    # Assert that the posting has been posted to the journalEntry
    assert je.postings[0].amount.value == 100
    # Assert that the account is the same one as the one we post to
    assert je.postings[0].account == acc
    # Assert that the

# Generated at 2022-06-21 20:10:42.417957
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .accounts import create_accounts
    accounts = create_accounts()
    accounts["101"] = Account(AccountType.ASSETS, "101")
    accounts["102"] = Account(AccountType.EQUITIES, "102")
    accounts["103"] = Account(AccountType.LIABILITIES, "103")
    accounts["104"] = Account(AccountType.REVENUES, "104")
    accounts["105"] = Account(AccountType.EXPENSES, "105")
    accounts["106"] = Account(AccountType.REVENUES, "106")
    accounts["107"] = Account(AccountType.EXPENSES, "107")
    accounts["108"] = Account(AccountType.ASSETS, "108")
    accounts["109"] = Account(AccountType.EQUITIES, "109")

# Generated at 2022-06-21 20:10:44.713761
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def run(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    assert issubclass(type(run), ReadJournalEntries)



# Generated at 2022-06-21 20:10:50.010957
# Unit test for constructor of class Posting
def test_Posting():
    amount1 = Amount(100)
    j1 = JournalEntry(datetime.date(2020,9,9),'description',1)
    date1 = datetime.date(2019,9,9)
    account1 = Account('debit',AccountType.ASSETS)
    direction1 = Direction.DEC
    p1 = Posting(j1,date1,account1,direction1,amount1)
    assert p1.journal == j1
    assert p1.date == date1
    assert p1.account == account1
    assert p1.direction == direction1
    assert p1.amount == amount1
    assert p1.is_debit == False
    assert p1.is_credit == True


# Generated at 2022-06-21 20:10:50.734687
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True