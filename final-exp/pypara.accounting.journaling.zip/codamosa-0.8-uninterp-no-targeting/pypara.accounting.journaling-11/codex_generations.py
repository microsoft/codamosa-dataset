

# Generated at 2022-06-21 20:01:21.095897
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    j = JournalEntry(datetime.date.today(), "Deposit", None)
    assert j.date != None
    assert j.description != None
    assert j.source != None
    assert j.postings != None
    assert j.postings == []
    assert j.guid != None

# Generated at 2022-06-21 20:01:31.120177
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import dataclass, field
    from typing import List
    
    @dataclass(frozen=True)
    class Posting:
        """
        Provides a posting value object model.
        """

        #: Journal entry the posting belongs to.
        journal: "JournalEntry"

        #: Date of posting.
        date: datetime.date

        #: Account of the posting.
        account: str

        #: Direction of the posting.
        direction: Direction

        #: Posted amount (in absolute value).
        amount: Amount

    @dataclass(frozen=True)
    class JournalEntry:
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business

# Generated at 2022-06-21 20:01:39.705525
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry[int](date = datetime.date.today(), description="test description", source=1)
    je.post(date = datetime.date.today(), account=Account(1, "test account", AccountType.ASSETS), quantity=100)

    assert je.date == datetime.date.today()
    assert je.description == "test description"
    assert je.source == 1
    assert je.postings == [Posting[int](journal=je, date=datetime.date.today(), account=Account(1, "test account", AccountType.ASSETS), direction=Direction.INC, amount=Amount(100))]


# Generated at 2022-06-21 20:01:40.741891
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True


# Generated at 2022-06-21 20:01:52.380854
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import foobar  # @UnusedImport

    def create_journal_entry(id: int, period: DateRange) -> JournalEntry[str]:
        date = period.from_date + datetime.timedelta(days=id)
        return JournalEntry(
            date,
            f"description_{id}",
            f"business_object_{id}",
            [
                Posting(None, date, Account(foobar, "debtor_1"), Direction.INC, Amount(id * 10)),
                Posting(None, date, Account(foobar, "debtor_2"), Direction.INC, Amount(id * 10)),
                Posting(None, date, Account(foobar, "creditor"), Direction.DEC, Amount(id * 20)),
            ],
        )


# Generated at 2022-06-21 20:01:53.383320
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    pass


# Generated at 2022-06-21 20:01:59.404554
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Accounts
    from .businessobjects.person import Person

    accounts = Accounts()
    peter = Person("Peter")
    peter.post(20190202, accounts.assets.bank_account, 100)
    peter.post(20190202, accounts.equities.capital, -100)

    peter.journal_entries[0].validate()

# Generated at 2022-06-21 20:02:12.519428
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # Test: with attr present, then with attr not present.
    # Test: with attr present, then with attr deleted.
    from datetime import date
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AssetAccount
    from .accounts import ExpenseAccount
    from .accounts import LiabilityAccount
    from .accounts import RevenuesAccount

    from .accounts import ASSET_ACCOUNT
    from .accounts import EXPENSE_ACCOUNT
    from .accounts import LIABILITY_ACCOUNT
    from .accounts import REVENUES_ACCOUNT

    from .currencies import Currency
    from .currencies import Money
    from .currencies import SBP_SYMBOL

    # Default val is type Guid
    class Trade:
        pass
    
    transaction = Guid()



# Generated at 2022-06-21 20:02:23.313350
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    @dataclass(frozen=True)
    class B():
        pass
    assert eval(repr(Posting(JournalEntry(date=datetime.date(2019, 5, 9), description="Food", source=B(), postings=[]),
                             date=datetime.date(2019, 5, 9), account=Account(name="Expenses:Food"), direction=Direction.INC,
                             amount=Amount(1)))) == Posting(JournalEntry(date=datetime.date(2019, 5, 9),
                                                                        description="Food", source=B(), postings=[]),
                                                            date=datetime.date(2019, 5, 9),
                                                            account=Account(name="Expenses:Food"),
                                                            direction=Direction.INC, amount=Amount(1))


# Generated at 2022-06-21 20:02:34.344707
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .commons.numbers import Amount, Quantity

    a = JournalEntry(date=datetime.date(2018, 5, 4), description='Testing validations for Journal Entry', source='This is a test')
    a.post(date=datetime.date(2018, 5, 4), account=Account(name='Petty Cash', type=AccountType.ASSETS), quantity=Quantity(100))
    a.post(date=datetime.date(2018, 5, 4), account=Account(name='Cash on Hand', type=AccountType.ASSETS), quantity=Quantity(100))

    a.validate()

    b = JournalEntry(date=datetime.date(2018, 5, 4), description='Testing validations for Journal Entry', source='This is a test')

# Generated at 2022-06-21 20:02:48.192969
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from pytest import raises

    ## Create journal entry
    journaEntry = JournalEntry[object](date=datetime.date.today(), description="test", source=object())
    
    ## Test expected behavior
    journaEntry.postings.append(Posting(journaEntry, datetime.date.today(), Account("1111", AccountType.ASSETS, "Cash", False), Direction.DEC, Amount(100.00)))
    assert len(journaEntry.postings) == 1

    ## Test that calling __setattr__ raises an error
    with raises(AttributeError) as excinfo:
        journaEntry.postings.append(Posting(journaEntry, datetime.date.today(), Account("1111", AccountType.ASSETS, "Cash", False), Direction.DEC, Amount(100.00)))


# Generated at 2022-06-21 20:02:49.854909
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    j1 = JournalEntry("")
    j2 = JournalEntry("")

    assert j1 != j2
    assert hash(j1) != hash(j2)


# Generated at 2022-06-21 20:03:02.225232
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from datetime import date
    from .accounts import Account, AccountType
    from .exceptions import InvalidOperationError

    class JournalEntry:

        def __init__(self, a: Account, b: Account, amount: float, d: date):
            if amount <= 0:
                raise InvalidOperationError('Amount cannot be zero or less than zero')
            self.a = a
            self.b = b
            self.amount = amount
            self.date = d

        def __repr__(self):
            return self.a.__repr__() + " " + self.b.__repr__() + " " + str(self.amount) + " " + str(self.date)


# Generated at 2022-06-21 20:03:06.153763
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert str(JournalEntry(date=datetime.date(2018, 7, 1), description="Test entry")) == "<JournalEntry date=2018-07-01 desc='Test entry'>"

# Generated at 2022-06-21 20:03:19.347468
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from dataclasses import dataclass
    from typing import List
    from .accounts import Account
    from .journal import Posting, JournalEntry
    @dataclass(frozen=True)
    class T:
        pass
    obj_p1 = Posting(JournalEntry(date=None,description='Pizza',source=T(),postings=[]),date=None,account=Account(1,'name1',2),direction=1,amount=3)
    obj_p2 = Posting(JournalEntry(date=None,description='Pizza',source=T(),postings=[]),date=None,account=Account(1,'name1',2),direction=1,amount=3)

# Generated at 2022-06-21 20:03:32.579080
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # ------------ Setup ------------
    from ..commons.zeitgeist import today
    from .business import Party
    from .accounts import AccountType, Account

    pac = Party(name="Accounting")
    j = JournalEntry[Party]
    d = datetime.date.today()
    a1 = Account( "A" , AccountType.ASSETS )
    a2 = Account( "B" , AccountType.ASSETS )
    a3 = Account( "C" , AccountType.ASSETS )
    a4 = Account( "D" , AccountType.ASSETS )
    a5 = Account( "E" , AccountType.ASSETS )
    a6 = Account( "F" , AccountType.ASSETS )
    a7 = Account( "G" , AccountType.ASSETS )


# Generated at 2022-06-21 20:03:41.037625
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    def create_journal_entry(date: datetime.date, description: str, source: str) -> JournalEntry[str]:
        return JournalEntry[str](date, description, source)

    def create_posting(journal: JournalEntry[str], date: datetime.date, account: str, direction: Direction,
                       amount: int) -> Posting[str]:
        return Posting[str](journal, date, Account(account), direction, Amount(amount))

    date = datetime.date(2019, 12, 31)
    description = "Description of journal entry"
    source = "Some source"

    journal_entry_1 = create_journal_entry(date, description, source) \
        .post(date, "Account 1", +1000) \
        .post(date, "Account 2", -1000)
    postings_1 = journal_entry

# Generated at 2022-06-21 20:03:45.948805
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[object]]:
        pass

    assert read_journal_entries.__annotations__ == {
        "period": DateRange,
        "return": Iterable[JournalEntry[object]],
    }

# Generated at 2022-06-21 20:03:50.922764
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from datetime import date
    entry = JournalEntry(date.today(), "Description", None)
    post1 = Posting(entry, date.today(), None, None, None)
    assert hasattr(post1, 'journal')
    delattr(post1, "journal")
    assert not hasattr(post1, 'journal')


# Generated at 2022-06-21 20:03:54.391430
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    a = Posting(None, None, None, None, None)
    b = Posting(None, None, None, None, None)
    assert a == b



# Generated at 2022-06-21 20:04:06.203693
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

# Generated at 2022-06-21 20:04:14.431633
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journalEntry = JournalEntry[int](date=datetime.date.today(), description='description', source=1)
    print(repr(journalEntry))
    assert repr(journalEntry) == "JournalEntry(_date=datetime.date(2019, 12, 20), _description='description', _source=1, _postings=[], _guid='febc2bf4-d0dd-4ce4-894a-1decab1e9fad')"



# Generated at 2022-06-21 20:04:21.228777
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # Given
    p = Posting(journal="JournalEntry1", date=datetime.date.today(), account="Account", direction=Direction.INC,
                amount=100)

    # Then
    assert(repr(p) == "Posting(journal='JournalEntry1', date=datetime.datetime.today().date(), account='Account', direction=Direction.INC, amount=100)")



# Generated at 2022-06-21 20:04:32.769769
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    import pytest
    from dataclasses import fields

    je = JournalEntry[int]()
    # Test that creation from `__init__` works
    assert (je.guid == makeguid())

    # Test that setting `date, description, source` works
    je.date = datetime.date(2019, 10, 1)
    je.description = "description"
    je.source = 1
    assert (je.date == datetime.date(2019, 10, 1))
    assert (je.description == "description")
    assert (je.source == 1)

    # Test that setting `postings` raises an error
    with pytest.raises(AttributeError):
        je.postings = []
    # Test that setting `guid` raises an error
    with pytest.raises(AttributeError):
        je.guid

# Generated at 2022-06-21 20:04:39.339488
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    journal1 = JournalEntry('2019-01-02', 'Description', object)
    acct = Account('TestAccount')
    direction1 = Direction.INC
    amt = Amount(1)
    journal1.postings = [Posting(journal1, '2019-01-01', acct, direction1, amt)]
    del journal1.postings[0]._journal
    assert journal1.postings[0]._journal == None


# Generated at 2022-06-21 20:04:48.163461
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from datetime import date
    from finance.accounting.accounts import Account, AccountType

    assert JournalEntry(date(2001, 1, 1), "Sample Journal Entry", None, guid="1") == JournalEntry(date(2001, 1, 1), "Sample Journal Entry", None, guid="1")
    journal_entry = JournalEntry(date(2001, 1, 1), "Sample Journal Entry", None, guid="1")

    assert journal_entry.increments() == []
    assert journal_entry.decrements() == []
    assert journal_entry.debits() == []
    assert journal_entry.credits() == []

    journal_entry.post(date(2001, 1, 1), Account("Assets:Cash", AccountType.ASSETS), 100)

# Generated at 2022-06-21 20:04:58.152693
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from .accounts import AccountType, JournalEntry, Posting
    from .commons.numbers import Amount, Quantity

    je = JournalEntry("2020-01-01", "JournalEntry")
    assert len(je.postings) == 0

    je.post(date="2020-01-01", account="Cash", quantity=Quantity(100))

    assert len(je.postings) == 1

    p = Posting(je, date="2020-01-01", account=Account("Cash", AccountType.ASSETS), direction=Direction.INC, amount=Amount(100))
    assert je.postings[0] == p


# Generated at 2022-06-21 20:05:00.753413
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    entry = JournalEntry(datetime.date.fromisoformat("2020-01-01"), "test", None)
    expected = "JournalEntry(date=datetime.date(2020, 1, 1), description='test', source=None, guid=None)"
    actual = entry.__repr__()
    assert (expected == actual), f"Expected: {expected}, but got: {actual}"


# Generated at 2022-06-21 20:05:03.947882
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    journal1 = JournalEntry(date=datetime.date.today(), description= "", source = None)
    journal2 = JournalEntry(date=datetime.date.today(), description= "", source = None)
    assert journal1 != journal2

# Generated at 2022-06-21 20:05:15.098291
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # GIVEN
    test_account = Account(1, "Test Account", AccountType.ASSETS)
    test_journal = JournalEntry(datetime.date(2019, 1, 1), "Test Journal", Guid(1))

    # WHEN
    test_journal.post(datetime.date(2019, 1, 1), test_account, Quantity(100))

    # THEN
    assert len(test_journal.postings) == 1
    assert test_journal.postings[0].account == test_account
    assert test_journal.postings[0].direction == Direction.INC
    assert test_journal.postings[0].amount == Amount(100)
    assert test_journal.postings[0].is_debit == True
    assert test_journal.postings[0].is_credit == False


# Generated at 2022-06-21 20:05:34.647597
# Unit test for constructor of class Posting
def test_Posting():
    from ..books.accounts import Account
    from ..books.ledgers import Ledger
    from ..books.books import Book
    from ..books.subledgers import get_subledger

    ledger = Ledger("Test Ledger")
    book = Book("Test Book", ledger)
    sa = Account("SA", AccountType.ASSETS)
    la = Account("LA", AccountType.LIABILITIES)
    ra = Account("RA", AccountType.REVENUES)
    ea = Account("EA", AccountType.EXPENSES)
    ledger.set_book(book)
    ledger.add_accounts([sa, la, ra, ea])
    subledger = get_subledger("TEST", book)

    journal_entry = JournalEntry[str]("2020-01-01", "Test journal entry", "TEST")


# Generated at 2022-06-21 20:05:40.304791
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry(datetime.date(2020,8,1), "hello", "world")
    je.post(datetime.date(2020,8,1),Account('a1',AccountType.ASSETS),-1)
    je.post(datetime.date(2020,8,1),Account('a2',AccountType.ASSETS),1)
    je.validate()

# Generated at 2022-06-21 20:05:47.662035
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    journalEntry = JournalEntry(0,"Initial Journal Entry",0)
    journalEntry.post(0, 0, 0)
    assert journalEntry.postings == []
    journalEntry.post(0, 0, 100)
    assert journalEntry.postings[0].journal == journalEntry
    assert journalEntry.postings[0].date == 0
    assert journalEntry.postings[0].account == 0
    assert journalEntry.postings[0].direction == Direction.INC
    assert journalEntry.postings[0].amount == 100

# Generated at 2022-06-21 20:05:58.255928
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # Arrange
    from .accounts import AccountFactory
    from .entry_models import EntrySource
    source = EntrySource("test source")
    account = AccountFactory.create_asset("cash", "Cash")
    date = datetime.date(2020, 9, 30)
    amount = Amount(100)
    direction = Direction.INC

    # Act
    posting = Posting(source, date, account, direction, amount)
    res = posting.__repr__()
    print(res)

    # Assert
    assert res == "Posting(date=2020-09-30, account=Account(code=cash, name=Cash), direction=INC, amount=100)"

# Generated at 2022-06-21 20:06:01.095016
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    _test_JournalEntry___repr__()
    _test_Posting___repr__()


# Generated at 2022-06-21 20:06:04.673586
# Unit test for method __repr__ of class Posting

# Generated at 2022-06-21 20:06:13.457142
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons import new_period_1
    from ..commons.accounts import AccountType, Account
    from .accounts import AccountNumber

    account1 = Account(AccountNumber("1110"), AccountType.ASSETS, "Cash")
    account2 = Account(AccountNumber("6210"), AccountType.REVENUES, "Sales Revenue")

    period = new_period_1()
    unit = JournalEntry[str]("UnitTest", "Test", "Test", [])
    unit.post(period.start, account1, 1000)
    unit.post(period.start, account2, 1000)
    unit.validate()

# Generated at 2022-06-21 20:06:16.825822
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    je = JournalEntry("2018-01-01", "Test", "Test")
    p = Posting(je, "2018-01-01", "Test", Direction.INC, 1)
    try:
        p.amount = 2
        assert False
    except AttributeError:
        assert True
    except:
        assert False

# Generated at 2022-06-21 20:06:28.223741
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountGroup, AccountType, Account

    with AccountGroup.asset() as asset:
        account = Account(asset, "Account")
    journal = JournalEntry[int](date=datetime.date.today(), description="This is a test", source=23)
    journal.post(datetime.date.today(), account, Quantity(10))
    assert journal.postings[0].amount == Amount(10)
    assert journal.postings[0].is_debit

    journal.post(datetime.date.today(), account, Quantity(20))
    assert journal.postings[1].amount == Amount(20)
    assert journal.postings[1].is_debit

    with AccountGroup.expense() as expense:
        account = Account(expense, "Account")

# Generated at 2022-06-21 20:06:32.866424
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    a=JournalEntry[object]('2019-04-20', 'sell', 'client', list(1,2,3,4), '1-2-3-4-5-6')
    a.__delattr__('date')
    assert (a.date == 'None')

# Generated at 2022-06-21 20:07:13.145646
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .accounts import Account
    from .journal import Posting, JournalEntry
    from datetime import date

    try:
        p = Posting(JournalEntry(date(2018, 1, 1), "Description", "Source"), date(2018, 1, 1), Account(
            "Account", AccountType.ASSETS), 1, 10)
        p.journal = JournalEntry(date(2018, 2, 1), "Description", "Source")
    except AttributeError:
        pass
    else:
        assert False, "AttributeError expected"

# Generated at 2022-06-21 20:07:17.073127
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p = Posting(journal='Journal1', date='2019/01/01', account='Account1', direction='Account1', amount='100.00')
    p1 = Posting(journal='Journal1', date='2019/01/01', account='Account1', direction='Account1', amount='100.00')
    assert p == p1


# Generated at 2022-06-21 20:07:27.636809
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import Account, AccountType
    from .events import Payment
    journal = JournalEntry[Payment].create()
    account = Account.create("TestAccount", AccountType.ASSETS, "TestAccount")
    posting = Posting(journal, "2020-01-01", account, Direction.DEC, 100000)

# Generated at 2022-06-21 20:07:29.494456
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass



# Generated at 2022-06-21 20:07:35.978737
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry(datetime.date(2020,9,3), "Hello", "Hello")) == "JournalEntry(date=datetime.date(2020, 9, 3), description='Hello', source='Hello', postings=[], guid=4f4e8c4c1bfa4d0a9f4e8fc424e9cd47)"


# Generated at 2022-06-21 20:07:50.438224
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from datetime import date
    from math import nan
    from decimal import Decimal, InvalidOperation
    from .accounts import AccountType, Account

    # create a journal entry instance
    journal_entry_1 = JournalEntry[str](date(2019, 8, 17), "Test JournalEntry.__delattr__()", nan)

    # test the case when the param name is date
    try:
        del journal_entry_1.date
        raise Exception("UnknownException")
    except AttributeError:
        pass

    # test the case when the param name is description
    try:
        del journal_entry_1.description
        raise Exception("UnknownException")
    except AttributeError:
        pass

    # test the case when the param name is source

# Generated at 2022-06-21 20:07:58.993897
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType
    from .business import Employee, EmployeeId
    from .events import Event, EventType, NoOp

    # Define a source of events with two journal entries.
    source = [
        Event(EventType.CASH_TRANSACTION, date=datetime.date(2020, 9, 2), amount=Amount(12_000)),
        Event(EventType.CASH_TRANSACTION, date=datetime.date(2020, 9, 6), amount=Amount(4_000)),
    ]

    # Define an employee for journal entries.
    employee = Employee(EmployeeId("BBB"), "bbb")

    # Define a method to create journal entries.
    def create_journal(event):
        je = JournalEntry(event.date, event.type.name, event.source)


# Generated at 2022-06-21 20:08:04.273310
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    import pytest

    j1 = JournalEntry(date=datetime.date(2008, 1, 1), description="Debit $100 to accounts receivable", source="")
    j1.post(datetime.date(2008, 1, 1), Account(name="Accounts receivable", type=AccountType.ASSETS), Quantity.from_decimal(100.00))
    j1.post(datetime.date(2008, 1, 1), Account(name="Sales", type=AccountType.REVENUES), Quantity.from_decimal(100.00))

    j2 = JournalEntry(date=datetime.date(2008, 1, 1), description="Credit $50 from cash", source="")

# Generated at 2022-06-21 20:08:09.979069
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    class X:
        def __init__(self, desc):
            self.desc = desc

    journal = JournalEntry(
        date=datetime.date(2020, 4, 5), description="Test Journal Entry", source=X("Source"),
    )

    assert hash(journal) == hash(journal)
    assert hash(journal) == hash(journal.__dict__)

# Generated at 2022-06-21 20:08:13.968077
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    t1 = JournalEntry[str]("2020-01-01", "description", "source", [])
    t2 = JournalEntry[str]("2020-01-01", "description", "source", [])
    assert hash(t1) == hash(t2), "Hash is not equal"


# Generated at 2022-06-21 20:09:34.927263
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def fn(period: DateRange) -> Iterable[JournalEntry[str]]:
        assert period == DateRange.to_beginning_of_year(datetime.date.today())
        return [JournalEntry(datetime.date.today(), "Dummy", "Dummy", [])]

    assert list(fn(DateRange.to_beginning_of_year(datetime.date.today()))) == list(ReadJournalEntries.__call__(fn))

# Generated at 2022-06-21 20:09:42.917163
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # try to create a JournalEntry object with zero value
    j = JournalEntry('2010-11-10', 'test journal', 'test')

    assert j.date == datetime(2010, 11, 10)
    assert j.description == 'test journal'
    assert j.source == 'test'
    assert not j.postings
    assert isinstance(j.guid, Guid)


# Generated at 2022-06-21 20:09:43.936124
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert issubclass(ReadJournalEntries, Protocol)

# Generated at 2022-06-21 20:09:53.213976
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    journal1 = JournalEntry('12/12/2018', 'description1', 'source1')
    journal2 = JournalEntry('12/12/2018', 'description1', 'source1')
    account1 = Account('Account', '50000', 'Assets', 'Debit')
    account2 = Account('Account', '50000', 'Assets', 'Debit')
    direction1 = Direction.INC
    direction2 = Direction.INC
    amount1 = Amount(10)
    amount2 = Amount(10)
    posting1 = Posting(journal1, '12/12/2018', account1, direction1, amount1)
    posting2 = Posting(journal2, '12/12/2018', account2, direction2, amount2)
    assert posting1 == posting2

# Generated at 2022-06-21 20:09:58.056115
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup
    journal = JournalEntry("dummy")
    # Exercise
    journal.post(datetime.date(2019,1,1), Account("An Account"), 1)
    # Verify
    assert journal.postings[0].journal == journal


# Generated at 2022-06-21 20:10:08.784003
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry(datetime.date(2019, 1, 1), 'description', 'source',
                        [Posting(JournalEntry(datetime.date(2019, 1, 1), 'description', 'source'),
                                 datetime.date(2019, 1, 1), 'account', Direction.INC, Amount(1))]) == \
           JournalEntry(datetime.date(2019, 1, 1), 'description', 'source',
                        [Posting(JournalEntry(datetime.date(2019, 1, 1), 'description', 'source'),
                                 datetime.date(2019, 1, 1), 'account', Direction.INC, Amount(1))])


# Generated at 2022-06-21 20:10:14.070970
# Unit test for constructor of class Posting
def test_Posting():
    a = Posting(1,1,1,1,1)
    s = a.__dict__
    assert(s.keys().__len__() == 5)
    assert(s['journal'] == 1)
    assert(s['date'] == 1)
    assert(s['account'] == 1)
    assert(s['direction'] == 1)
    assert(s['amount'] == 1)


# Generated at 2022-06-21 20:10:19.039561
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    p = Posting(None, datetime.date(2020,1,1), Account("Liabilities:Accounts Payable"),Direction.DEC, Amount(1))
    assert p.__repr__() == "Posting(journal=None, date=datetime.date(2020, 1, 1), account=Account(type=<AccountType.LIABILITIES: 2>, name='Liabilities:Accounts Payable'), direction=<Direction.DEC: -1>, amount=Amount(1))"


# Generated at 2022-06-21 20:10:28.663694
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Test method validate of class JournalEntry
    
    Actual: validation should happen as expected
    """
    journal_entry = JournalEntry(
        date = datetime.date(2020,1,1),
        description = "Testing JournalEntry.validate()",
        source = "System Testing",
        guid = Guid()
    )
    journal_entry.post(datetime.date(2020,1,1), Account("Lia", AccountType.LIABILITIES), 100)
    journal_entry.post(datetime.date(2020,1,1), Account("Rev", AccountType.REVENUES), -100)
    assert journal_entry.validate() == None, "Validation of JournalEntry failed!"


# Generated at 2022-06-21 20:10:37.248720
# Unit test for constructor of class Posting
def test_Posting():
    @dataclass
    class JournalEntryMock:
        guid : Guid = ''
        
    journal_entry : JournalEntryMock = JournalEntryMock()

    posting : Posting[JournalEntryMock] = Posting(journal=journal_entry, 
                                                  date=datetime.datetime.today(), 
                                                  account='A', 
                                                  direction=Direction.INC, 
                                                  amount=Amount())

    assert posting.journal == journal_entry
    assert posting.guid == posting.journal.guid

