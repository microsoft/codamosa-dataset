

# Generated at 2022-06-21 20:01:15.432404
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Arrange
    JournalEntry.validate()

# Generated at 2022-06-21 20:01:16.345988
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert False, "Not implemented"



# Generated at 2022-06-21 20:01:17.955258
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert ReadJournalEntries()


# Generated at 2022-06-21 20:01:20.325121
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    test_A = Posting("source", datetime.date(2020, 1, 1), "account", Direction.INC, 10)
    test_B = Posting("source", datetime.date(2020, 1, 1), "account", Direction.INC, 10)
    assert test_A == test_B and test_A is not test_B


# Generated at 2022-06-21 20:01:22.666473
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    posting = Posting[None]("journal", "date", "account", "direction", "amount")
    assert repr(posting) == "Posting(journal, date, account, direction, amount)"

# Generated at 2022-06-21 20:01:35.933162
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from datetime import date
    from typing import Dict, List, Mapping, Sequence, Set, Tuple, Union
    from dataclasses import field, dataclass
    from enum import Enum
    import datetime
    class Direction(Enum):
        value: int
        INC = +1
        DEC = -1
        @classmethod
        def of(cls, quantity: Quantity) -> "Direction":
            assert not quantity.is_zero(), "Encountered a `0` quantity. This implies a programming error."
            return Direction.INC if quantity > 0 else Direction.DEC

# Generated at 2022-06-21 20:01:37.197922
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert False, "Not implemented!"

# Generated at 2022-06-21 20:01:48.344479
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    print("Executing: test_JournalEntry___setattr__")
    import datetime
    test_journal_entry = JournalEntry(date=datetime.date(2020, 1, 1), description="Bike purchase", source="BikeHike", postings=[])
    assert test_journal_entry.date == datetime.date(2020, 1, 1)
    assert test_journal_entry.description == "Bike purchase"
    assert test_journal_entry.source == "BikeHike"
    assert test_journal_entry.guid != None
    assert test_journal_entry.postings == []
    # Test if __setattr__ throws AssertionError on invalid attribute name
    try:
        test_journal_entry.invalid_attribute_name = "invalid_attribute"
    except AssertionError:
        assert True

# Generated at 2022-06-21 20:01:59.980674
# Unit test for method post of class JournalEntry

# Generated at 2022-06-21 20:02:06.827878
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    from ..contrib.accounts import accounts
    from ..open_books.account_ledger import AccountRegistry

    ## Prepare:
    account_registry = AccountRegistry()
    account_registry.set_accounts([
        accounts.Cash,
        accounts.Supplies,
        accounts.Utilities,
    ])

    ## When:
    posting = Posting(None, date.today(), account_registry.get_by_fullname("Cash"), Direction.INC, 100)

    ## Then:
    assert posting.amount == 100
    # and when:
    posting.amount = None
    # then:
    assert posting.amount == 100
    # and when:
    posting.amount = 200
    # then:
    assert posting.amount == 200


# Generated at 2022-06-21 20:02:22.917120
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .assets import Asset
    from .gl import DefaultGL
    from .ledgers import Ledger, LedgerTransaction
    from .equities import Equity
    from .revenues import Revenue
    from .expenses import Expense
    from .liabilities import Liability
    import datetime


# Generated at 2022-06-21 20:02:31.720519
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    import datetime
    from ..commons.numbers import Amount, Quantity

    journal = JournalEntry(datetime.date(2019, 7, 1), "Test entry", "Test source")
    journal.postings.append(Posting(journal, datetime.date(2019, 7, 1), "Account1", Direction.INC, Amount(Quantity(10))))
    journal.postings.append(Posting(journal, datetime.date(2019, 7, 1), "Account2", Direction.DEC, Amount(Quantity(10))))

    assert journal == journal
    assert journal == journal.with_postings(journal.postings)


# Generated at 2022-06-21 20:02:35.908802
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Tests `__call__` of `ReadJournalEntries`.
    """

    class _ReadJournalEntries(_ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass


# Generated at 2022-06-21 20:02:42.323056
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    with pytest.raises(dataclasses.FrozenInstanceError):
        le = JournalEntry[None](date=datetime.date(2019, 9, 1), description="Journal Entry 1", source=None)
        le.postings.append(Posting(le, datetime.date(2019, 9, 1), Account(AccountType.ASSETS, "Cash"),
                                   Direction.DEC, Amount(100)))
        le.postings = "Accounts Payable"


# Generated at 2022-06-21 20:02:43.200196
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass
    # assert ReadJournalEntries()

# Generated at 2022-06-21 20:02:45.930794
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(None, None, Account('test', AccountType.LIABILITIES), Direction.INC, Amount(0)) == Posting(None, None, Account('test', AccountType.LIABILITIES), Direction.INC, Amount(0))


# Generated at 2022-06-21 20:02:51.018717
# Unit test for constructor of class Posting
def test_Posting():
    journal = JournalEntry[str]("2020-04-08", "test")
    post = Posting[str](journal, "2020-04-08", Account(AccountType.REVENUES, "test"), Direction.INC, 1000)
    print(post)


# Generated at 2022-06-21 20:02:54.783478
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    je1 = JournalEntry(datetime.date(2020, 1, 1), "", "EQUITY", [])
    assert (je1 == je1)


# Generated at 2022-06-21 20:02:59.124443
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    je = JournalEntry(datetime.date.today(), "test", "source", postings=[])
    assert repr(je) == f"JournalEntry(date={je.date}, description={je.description}, guid={je.guid}, postings=[], source={je.source})"

# Generated at 2022-06-21 20:03:06.515004
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting(None, datetime.date(2020, 1, 1), Account("Equity", AccountType.EQUITIES), Direction.INC, Amount(100))) == "Posting(journal=None, date=datetime.date(2020, 1, 1), account=Account(name='Equity', type=<AccountType.EQUITIES: 0>), direction=<Direction.INC: 1>, amount=Amount(100))"


# Generated at 2022-06-21 20:03:25.398239
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    j1 = JournalEntry(1, "")
    assert j1.__repr__() == 'JournalEntry(1, "") [0 postings]'
    j2 = JournalEntry(2, "")
    j2.post(2, 3, 4)
    assert j2.__repr__() == 'JournalEntry(2, "") [4 postings]'


# Generated at 2022-06-21 20:03:29.398230
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p = Posting(1, datetime.date, 1, 1, 1)
    p2 = Posting(1, datetime.date, 1, 1, 1)
    assert p == p2


# Generated at 2022-06-21 20:03:33.876543
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    exec("del JournalEntry.postings")
    exec("del JournalEntry.date")
    exec("del JournalEntry.description")
    exec("del JournalEntry.source")
    exec("del JournalEntry.guid")


# Generated at 2022-06-21 20:03:39.384569
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    """
    test __repr__ of class JournalEntry by calling function __repr__ on an instance.
    """
    # Arrange:
    journal = JournalEntry(datetime.date(2020, 1, 1), 'entry0', 'source', [])

    # Act:
    string = repr(journal)

    # Assert:
    assert string == f"JournalEntry(date=datetime.date(2020, 1, 1), description='entry0', source='source', guid='{journal.guid}', postings=[])"

# Generated at 2022-06-21 20:03:45.460659
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Test that the journal entry does not allow its source to be modified once it is set
    class MockJournalEntry(JournalEntry[None]):
        pass

    mockJournalEntry = MockJournalEntry(datetime.date.today(), "", None)

    with pytest.raises(TypeError):
        mockJournalEntry.source = None


# Generated at 2022-06-21 20:03:46.664738
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True


# Generated at 2022-06-21 20:03:52.834834
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    date = datetime.date(year=2020, month=3, day=3)
    description = "Description"
    source = 'Source'
    journal_entry = JournalEntry(date, description, source, postings=[])
    assert journal_entry.date == date
    assert journal_entry.description == description
    assert journal_entry.source == source
    assert journal_entry.postings == []
    assert journal_entry.guid is not None

# Generated at 2022-06-21 20:04:04.698334
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account, AccountType
    from .billing import Bill, BillLine
    from .ledger import Ledger
    from .symbols import USD
    from .timebook import Timebook
    from .utilization import Utilization

    ledger = Ledger(Timebook(), Utilization())
    ledger.account(AccountType.EXPENSES, USD, "Dressmaking", Account)
    ledger.account(AccountType.EQUITIES, USD, "Wages Payable", Account)

    journal = JournalEntry()
    journal.date = datetime.date(2020, 7, 2)
    journal.description = "Salary"

    bill = Bill()
    bill.number = "BILL-0001"
    bill.date = journal.date
    bill.description = journal.description
    bill.timebook = ledger.timebook
   

# Generated at 2022-06-21 20:04:05.716448
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert 'ReadJournalEntries'

# Generated at 2022-06-21 20:04:17.064630
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.protocols import BusinessObject
    from ..books.events import Event
    from ..books.accounts import AccountType
    from ..commons.numbers import Amount, Quantity
    from .protocols import PublishJournalEntry
    from ..ledger.book import LedgerBook
    from ..ledger.events import EventStream
    from ..ledger.protocols import RegisterBook
    from ..books.common import User
    from ..books.protocols import ReadCurrentUser

    @RegisterBook(path = "../test/test_ledger.db")
    @RegisterBook(path = "../test/test_ledger.db")
    @dataclass(frozen = True)
    class T1(BusinessObject):
        ## Business Object
        guid: Guid
        creation_date: datetime.datetime
        last_mod

# Generated at 2022-06-21 20:04:32.232890
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass 

# Generated at 2022-06-21 20:04:43.317638
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    guid1 = Guid("d5b619a0-49a9-9f46-b28f-0a1cc299c746")
    guid2 = Guid("e5b619a0-49a9-9f46-b28f-0a1cc299c746")
    guid3 = Guid("f5b619a0-49a9-9f46-b28f-0a1cc299c746")

    # Positive test
    p1 = Posting(JournalEntry("d", "s", guid1), datetime.date(2019, 1, 1), Account("a"), Direction.INC, 100)
    p2 = Posting(JournalEntry("d", "s", guid1), datetime.date(2019, 1, 2), Account("a"), Direction.INC, 100)
    p3 = Posting

# Generated at 2022-06-21 20:04:51.043586
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    entries = JournalEntry[int](date = datetime.date(2020, 5, 21), description = "Income from sale",
                                source = 'Source1')
    entries.post(datetime.date(2020, 5, 21), Account(AccountType.REVENUES, 'Revenue'), Quantity(1500))
    entries.post(datetime.date(2020, 5, 21), Account(AccountType.ASSETS, 'Cash'), Quantity(1500))
    entries.validate()

# Generated at 2022-06-21 20:04:57.409228
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """
    Tests method __setattr__ of Posting raises an AttributeError
    """
    posting = Posting(None,
                datetime.date(1970, 1, 1),
                Account('a', ''),
                Direction.INC,
                Amount(0))
    try:
        posting.journal = None
    except AttributeError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 20:05:07.629980
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    from datetime import date
    from bookledger.domain.accounts import AccountType

    # Arrange
    journal = JournalEntry(date.today(),"Paycheck",1)

    # Act
    journal.post(date.today(), Account("Checking", AccountType.ASSETS), 300)
    journal.post(date.today(), Account("Taxes", AccountType.EXPENSES), -100)

    # Assert
    assert len(journal.postings) == 2
    assert journal.postings[0].amount == Amount(300)
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].account.name == "Checking"

    assert journal.postings[1].amount == Amount(100)
    assert journal.postings[1].direction == Direction.DEC

# Generated at 2022-06-21 20:05:11.697156
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    journal = JournalEntry(datetime.date.today(), "Test Journal", None)
    post = Posting(journal, datetime.date.today(), Account(AccountType.ASSETS, 'test'), Direction.INC, Amount(1))
    post.__delattr__('')


# Generated at 2022-06-21 20:05:18.319509
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from .accounts import Account, AccountType

    #: Journal entry the posting belongs to.
    journal: "JournalEntry[_T]"
    #: Date of posting.
    date: datetime.date
    #: Account of the posting.
    account: Account
    #: Direction of the posting.
    direction: Direction

    #: Posted amount (in absolute value).
    amount: Amount
    assert hash(Posting(journal=journal, date=date, account=account, direction=direction, amount=amount)) is not None

# Generated at 2022-06-21 20:05:19.164686
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    assert True

# Generated at 2022-06-21 20:05:30.985244
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p1 = Posting(None, date=datetime.date.today(), account=Account(id="id", name="name", type=AccountType.REVENUES), direction=Direction.DEC, amount=Amount.from_str("50.00"))
    p2 = Posting(None, date=datetime.date.today(), account=Account(id="id", name="name", type=AccountType.REVENUES), direction=Direction.DEC, amount=Amount.from_str("50.00"))
    assert hash(p1) == hash(p2)
    p3 = Posting(None, date=datetime.date.today(), account=Account(id="id", name="name", type=AccountType.REVENUES), direction=Direction.INC, amount=Amount.from_str("50.00"))

# Generated at 2022-06-21 20:05:42.448660
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    entry1 = JournalEntry(datetime.date.today(), "Description", None)
    entry2 = JournalEntry(datetime.date.today(), "Description", None)

    assert entry1.guid == entry2.guid

    posting1 = Posting(entry1, datetime.date.today(), Account.of_type_account("40"), Direction.INC, Amount(10))
    posting2 = Posting(entry2, datetime.date.today(), Account.of_type_account("40"), Direction.INC, Amount(10))
    posting3 = Posting(entry1, datetime.datetime.now(), Account.of_type_account("40"), Direction.INC, Amount(10))

    posting1 == posting2
    posting2 == posting3
    posting1 == posting3
    posting1 == posting1

    assert posting1 == posting2


# Generated at 2022-06-21 20:06:21.289929
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    journal = JournalEntry.post()
    date = datetime.date.today()
    account = Account.create("ABC")
    direction = Direction.INC
    amount = Amount(100.0)

    assert (Posting(journal, date, account, direction, amount) == \
            Posting(journal, date, account, direction, amount))


# Generated at 2022-06-21 20:06:31.147004
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():

    from .bienses import ProvideBienes
    from .cuentas import ProvideCuentas
    from .empresa import ProvideEmpresa

    # Add mock bien
    bien = ProvideBienes()
    bien.add(datetime.datetime(2018, 1, 1), 'Compra de computadoras', 'Compra de un puesto de computo', 100000)

    # Add mock cuenta
    cuenta = ProvideCuentas()
    cuenta.add(datetime.datetime(2018, 1, 1), 'Cuenta de ingresos', 'Cuenta para ingresos', AccountType.LIABILITIES)

    # Add mock empresa
    empresa = ProvideEmpresa()

# Generated at 2022-06-21 20:06:42.538564
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[object]]:
        return (
            JournalEntry(datetime.date(2020, 4, 8), "Journal Entry 1", object()),
            JournalEntry(datetime.date(2020, 4, 9), "Journal Entry 2", object()),
            JournalEntry(datetime.date(2020, 4, 10), "Journal Entry 3", object()),
        )
    assert hasattr(read_journal_entries, "__call__")
    rje = ReadJournalEntries[object]
    assert isinstance(read_journal_entries, rje)
    result = list(read_journal_entries(DateRange(datetime.date(2020, 4, 8), datetime.date(2020, 4, 10))))
    assert len(result) == 3

# Generated at 2022-06-21 20:06:48.583272
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    j = JournalEntry(datetime.date.today(), 'Buy a new car', 'Purchase')
    assert j.date == datetime.date.today()
    assert j.description == 'Buy a new car'
    assert j.source == 'Purchase'
    assert j.postings == []


# Generated at 2022-06-21 20:06:54.208829
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    a = Posting(None, datetime.date(2019, 3, 1), Account(AccountType.ASSETS, "Cash", 1), Direction.INC, Amount(100))
    b = Posting(None, datetime.date(2019, 3, 1), Account(AccountType.ASSETS, "Cash", 1), Direction.INC, Amount(100))

    assert a == b

# Generated at 2022-06-21 20:07:02.179679
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from .accounts import Account
    from .ledgers import Ledger
    from .sources import Source
    ledger=Ledger("bank")
    ledger.post("Dec",2018,"PostingTest",Source("PostingTest"),[
    ("bank","cash"),("bank","codes"),("bank","inventory")],100)
    #assert hash("bank")==hash("bank")
    assert hash(ledger.journal.entries[-1].postings[0].account)==hash(Account("bank"))
    assert hash(ledger.journal.entries[-1].postings[0])==hash(Posting(ledger.journal.entries[-1],datetime.date(2018, 12, 1) ,Account("bank"),Direction.INC,Amount(100.0)))

# Generated at 2022-06-21 20:07:11.500218
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    @dataclass(frozen=True)
    class BusinessObj:
        date: datetime.date
        description: str

    ## Setup:
    journal = JournalEntry[BusinessObj](date=datetime.date(2020, 1, 1),
                                     description="",
                                     source=BusinessObj(date=datetime.date(2020, 1, 1), description="xyz"))

    ## Test:
    journal.date = datetime.date(2021, 1, 1)
        
    ## Assert:
    assert journal.date == datetime.date(2020, 1, 1)

# Generated at 2022-06-21 20:07:15.528394
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry(datetime.datetime.today().date())
    je.post(datetime.datetime.today().date(),Account("",AccountType.ASSETS),1000)
    assert len(je.postings) == 1


# Generated at 2022-06-21 20:07:21.463221
# Unit test for constructor of class Posting
def test_Posting():
    journal = JournalEntry(datetime.date(2019, 1, 8), "Account", "")
    posting = Posting(journal, datetime.date.today(), Account("Name", AccountType.ASSETS), Direction.INC, Amount(100))
    assert posting.account == Account("Name", AccountType.ASSETS)
    assert posting.amount == Amount(100)
    assert posting.is_debit


# Generated at 2022-06-21 20:07:30.532780
# Unit test for constructor of class Posting
def test_Posting():
    MyType = TypeVar('MyType')
    j = JournalEntry[MyType](datetime.date(2019, 4, 1), 'Test', MyType())
    j.post(datetime.date(2019, 4, 1), Account('A1', AccountType.ASSETS), 1000)
    j.post(datetime.date(2019, 4, 1), Account('E1', AccountType.EQUITIES), -1000)

    for p in j.postings:
        if (p.account.name == 'A1'):
            assert p.is_debit
        elif (p.account.name == 'E1'):
            assert p.is_credit



# Generated at 2022-06-21 20:08:42.767706
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from test_posting import test_posting
    assert test_posting() == 0

# Generated at 2022-06-21 20:08:44.471001
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    pass


# Generated at 2022-06-21 20:08:45.105889
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass

# Generated at 2022-06-21 20:08:47.924123
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    a = Posting(JournalEntry('', '', ''), datetime.date.today(), None, None, 1)
    test = {}
    test[a] = 1

# Generated at 2022-06-21 20:08:52.750373
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(None, None, None, None, None) != Posting(None, None, None, None, None)


# Generated at 2022-06-21 20:08:58.145495
# Unit test for constructor of class Posting
def test_Posting():
    j = JournalEntry("date", "description", "source")
    p = Posting(j, "date", "account", "INC", "amt")
    assert p.journal==j
    assert p.date=="date"
    assert p.account=="account"
    assert p.direction=="INC"
    assert p.amount=="amt"


# Generated at 2022-06-21 20:09:06.054436
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import FrozenInstanceError

    from ..commons.zeitgeist import DateRange
    from .currencies import Currency
    from .accounts import AccountType as Type
    from .accounts import BankAccount, CashAccount

    bank_account = BankAccount("Bank Account", "BK0001", Currency.USD)
    cash_account = CashAccount("Cash Account", "CK0001", Currency.USD)

    def load_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        yield JournalEntry(
            date=datetime.date(2020, 1, 1), source=None, description="This is pay-day"
        ).post(bank_account, +10000)

    # noinspection PyArgumentList
    lje = ReadJournalEntries.__call__  # type: ignore[attr-defined]


# Generated at 2022-06-21 20:09:11.024300
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    def make_postings(n):
        return [Posting(Guid.create(), datetime.date(2019, 5, n), Account.create(), Direction.INC, Amount(1000))]

    postings_1 = make_postings(1)
    postings_2 = make_postings(1)
    postings_3 = make_postings(2)

    assert postings_1 == postings_2
    assert postings_1 != postings_3

# Generated at 2022-06-21 20:09:22.062975
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType

    sales_account = Account(AccountType.REVENUES, "SALES")
    costs_account = Account(AccountType.EXPENSES, "COSTS")
    cash_account = Account(AccountType.ASSETS, "CASH")

    transaction = JournalEntry.of(datetime.date(2020, 1, 31), "Invoicing ABC Company")
    transaction \
        .post(date=transaction.date, account=sales_account, quantity=1000) \
        .post(date=transaction.date, account=costs_account, quantity=-500) \
        .post(date=transaction.date, account=cash_account, quantity=-500) \
        .validate()

    assert transaction.date == datetime.date(2020, 1, 31)

# Generated at 2022-06-21 20:09:31.083311
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    pass
    #from datetime import date
    #from dataclasses import dataclass, field
    #from enum import Enum
    #from typing import List
    #from pytest import raises
    #from .accounts import Account, AccountType
    #
    #@dataclass(frozen=True)
    #class Posting(Generic[_T]):
    #    #: Journal entry the posting belongs to.
    #    journal: "JournalEntry[_T]"
    #    #: Date of posting.
    #    date: date
    #    #: Account of the posting.
    #    account: Account
    #    #: Direction of the posting.
    #    direction: Direction
    #    #: Posted amount (in absolute value).
    #    amount: Amount
    #    #: Globally unique, ephemeral identifier.