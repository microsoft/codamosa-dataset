

# Generated at 2022-06-21 20:01:25.985827
# Unit test for constructor of class Posting
def test_Posting():
    account1 = Account("Assets", AccountType.ASSETS)
    account2 = Account("Expenses", AccountType.EXPENSES)
    journal = JournalEntry("01-01-2020", "Salary", "ABC")
    posting1 = Posting(journal, "01-01-2020", account1, Direction.INC, Amount("100.00"))
    posting2 = Posting(journal, "01-01-2020", account2, Direction.DEC, Amount("100.00"))
    assert posting1.journal == journal
    assert posting1.date == datetime.date(2020, 1, 1)
    assert posting1.account == account1
    assert posting1.direction == Direction.INC
    assert posting1.amount == Amount("100.00")

# Generated at 2022-06-21 20:01:29.375822
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal_entry = JournalEntry[None](datetime.date(2020,3,18), "test",None, [])
    print(str(journal_entry))

test_JournalEntry___repr__()

# Generated at 2022-06-21 20:01:37.214140
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    p = Posting(journal=None, date=None, direction=None, amount=None, account=None)
    assert (p.journal == None) and (p.date == None) and (p.direction == None) and (p.amount == None) and (p.account == None)
    del p.journal, p.date, p.direction, p.amount, p.account
    assert (p.journal == None) and (p.date == None) and (p.direction == None) and (p.amount == None) and (p.account == None)


# Generated at 2022-06-21 20:01:38.277363
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert 1 == 1



# Generated at 2022-06-21 20:01:43.728278
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.zeitgeist import today, DateRange
    from ..domain.accounting import Accounts, Account, AccountType
    a1 = Account("A-01", AccountType.ASSETS, Accounts())
    a2 = Account("A-02", AccountType.EQUITIES, Accounts())
    a3 = Account("A-03", AccountType.LIABILITIES, Accounts())
    a4 = Account("A-04", AccountType.REVENUES, Accounts())
    a5 = Account("A-05", AccountType.EXPENSES, Accounts())
    je1 = JournalEntry(today(), "Test", None)
    je2 = je1.post(today(), a1, 100).post(today(), a2, -100)
    je3 = je1.post(today(), a3, -100).post(today(), a4, 100)
   

# Generated at 2022-06-21 20:01:50.460886
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # Arrange:
    @dataclass
    class Point(object):
        x: int
        y: int

    p = Point(1, 2)

    assert p.x == 1
    assert p.y == 2

    # Act:
    p.x = 10
    p.y = 20

    # Assert:
    assert p.x == 10
    assert p.y == 20

# Generated at 2022-06-21 20:02:01.383451
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def sample_journal_entry_reader(period: DateRange) -> Iterable[JournalEntry[JournalEntry]]:
        yield JournalEntry(datetime.date(2020, 1, 1), "Test journal entry #1", None)
        yield JournalEntry(datetime.date(2020, 1, 2), "Test journal entry #2", None)

    from . import datasources

    datasources.read_journal_entries = ReadJournalEntries(sample_journal_entry_reader)
    entries = list(datasources.read_journal_entries(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2))))
    assert len(entries) == 2
    assert entries[0].date == datetime.date(2020, 1, 1)
    assert entries[0].description == "Test journal entry #1"


# Generated at 2022-06-21 20:02:13.556518
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    """
    Test for method __eq__ of class JournalEntry
    """
    print("Start test for JournalEntry.__eq__")
    # Create two journal entries of type int with the same attributes
    entry1 = JournalEntry(datetime.date(2020, 6, 18), "Test 1", 1)
    entry2 = JournalEntry(datetime.date(2020, 6, 18), "Test 1", 1)
    # These two journal entries should be equal
    assert entry1 == entry2, "JournalEntry.__eq__() is not working properly"

    # Create two journal entries of type int with different attributes
    entry3 = JournalEntry(datetime.date(2020, 6, 11), "Test 2", 2)
    entry4 = JournalEntry(datetime.date(2020, 6, 11), "Test 1", 2)
    # These two journal entries should not

# Generated at 2022-06-21 20:02:21.093077
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p1 = Posting("JournalEntry()", "10/10/2017", "Account()", Direction.DEC, 100)
    p2 = Posting("JournalEntry()", "10/10/2017", "Account()", Direction.DEC, 100)
    assert hash(p1) == hash(p2)
    p3 = Posting("JournalEntry()", "10/10/2017", "Account()", Direction.DEC, 100)
    assert hash(p1) == hash(p3)
    p4 = Posting("JournalEntry()", "10/10/2017", "Account()", Direction.INC, 100)
    assert hash(p1) != hash(p4)
    p5 = Posting("JournalEntry()", "10/10/2018", "Account()", Direction.DEC, 100)

# Generated at 2022-06-21 20:02:25.108464
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Instantiating Journal entry class
    journal_entry1 = JournalEntry[int]
    journal_entry2 = JournalEntry[str]
    
    # Calling functions
    journal_entry1.is_credit
    journal_entry1.is_debit
    journal_entry1.decrements
    journal_entry1.increme

# Generated at 2022-06-21 20:02:38.364118
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Given
    import datetime
    from ..accounts.domain import Chart, Account

    # When
    chart = Chart()
    cash_account = chart.get_or_create(Account("Cash", AccountType.ASSETS))
    journal_entry = JournalEntry(datetime.date(2020, 7, 1), "Sale", None)
    journal_entry.post(datetime.date(2020, 7, 1), cash_account, 1000)
    journal_entry.post(datetime.date(2020, 7, 1), chart.get_or_create(Account("Sales", AccountType.REVENUES)), -1000)

    # Then
    assert journal_entry.validate() == None

# Generated at 2022-06-21 20:02:48.058292
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, CREDIT_CARD_ACCOUNT, CASH_ACCOUNT
    from .transaction import Transaction, TransactionDetail

    journal = JournalEntry[Transaction]()
    journal.post(datetime.date(2019, 5, 9), CASH_ACCOUNT, -900)
    journal.post(datetime.date(2019, 5, 9), CREDIT_CARD_ACCOUNT, +900)
    journal.validate()

    journal = JournalEntry[TransactionDetail]()
    journal.post(datetime.date(2019, 5, 9), CASH_ACCOUNT, -900)
    journal.post(datetime.date(2019, 5, 9), CREDIT_CARD_ACCOUNT, +900)
    journal.validate()

# Generated at 2022-06-21 20:02:50.395569
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert JournalEntry(date=None, description='', source=None).postings==[]

# Generated at 2022-06-21 20:03:02.664713
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .accounts import AccountType
    from .currency import Currency
    from .currency import CurrencyOfUnitedStatesOfAmerica as USD

    journal = JournalEntry[object]('2019-12-31', 'shares issued to founders', object(), [])
    posting = Posting[object](journal, '2019-12-31',
                              Account('EQUITY', 'SHAREHOLDERS EQUITY', AccountType.EQUITIES, '001', 'INVESTMENT',
                                      Currency('US', 'USA', 'United States Dollar'), USD, 'Y', None, None),
                              Direction.INC, Amount(-60000))
    print(posting)

# Generated at 2022-06-21 20:03:09.822998
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journal = JournalEntry(date = datetime.date(2019, 12, 31), description = "foo", source = None)
    posting = Posting(journal = journal, date = datetime.date(2019, 12, 31), account = None, direction = Direction.INC, amount = 0)
    assert posting.journal == journal
    assert posting.date == datetime.date(2019, 12, 31)
    assert posting.account is None
    assert posting.direction == Direction.INC
    assert posting.amount == 0


# Generated at 2022-06-21 20:03:21.880007
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    j = JournalEntry(date=datetime.date(2019, 1, 1), source=None, description=None)
    assert j.validate() is None
    
    j1 = j.post(date=datetime.date(2019, 1, 1), account=Account(name="Cash", type=AccountType.ASSETS, parent=None), quantity=100)
    assert j1.validate() is None
    assert j1 == j1

    j2 = j.post(date=datetime.date(2019, 1, 1), account=Account(name="Cash", type=AccountType.ASSETS, parent=None), quantity=101)
    assert j2.validate() is None
    assert j2 != j1, "j2 is not equal to j1"
    

# Generated at 2022-06-21 20:03:34.504921
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    je = JournalEntry[int](
        date=datetime.date(2019, 1, 1),
        description="Test Journal Entry",
        source=123
        )
    
    # Act
    je.post(datetime.date(2019, 1, 1), Account("Test Account", AccountType.ASSETS), 1000).post(datetime.date(2019, 1, 1), Account("Test Account", AccountType.ASSETS), 1000).post(datetime.date(2019, 1, 1), Account("Test Account", AccountType.EQUITIES), -2000)

    # Assert
    assert len(je.postings) == 3, f"Postings attribute should have 3 elements. Currently has {len(je.postings)}."

# Generated at 2022-06-21 20:03:35.730560
# Unit test for constructor of class Posting
def test_Posting():
    pass


# Generated at 2022-06-21 20:03:38.312400
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert list(ReadJournalEntries.__call__(Period(Date(2020, 5, 1), Date(2020, 5, 1))), JournalEntry[Dummy])


# Generated at 2022-06-21 20:03:46.458888
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    class A: pass
    a = A()
    entry = JournalEntry[A](date=datetime.date(2020, 1, 8), description='d', source=a)
    assert(hash(entry) == hash(JournalEntry[A](date=datetime.date(2020, 1, 8), description='d', source=a)))
    assert(entry.__hash__() == JournalEntry[A](date=datetime.date(2020, 1, 8), description='d', source=a).__hash__())

# Generated at 2022-06-21 20:04:04.345019
# Unit test for method __hash__ of class Posting

# Generated at 2022-06-21 20:04:15.856271
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    my_postings = dict()

    posting = Posting(None, None, Account(), Direction.DEC, None)
    assert posting.__hash__() not in my_postings
    my_postings[posting.__hash__()] = posting

    posting = Posting(None, None, Account(), Direction.INC, None)
    assert posting.__hash__() not in my_postings
    my_postings[posting.__hash__()] = posting

    posting = Posting(None, None, Account(AccountType.ASSETS), Direction.DEC, None)
    assert posting.__hash__() not in my_postings
    my_postings[posting.__hash__()] = posting

    posting = Posting(None, None, Account(AccountType.ASSETS), Direction.INC, None)
    assert posting.__hash

# Generated at 2022-06-21 20:04:22.540075
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    #given
    direction = 2
    account = Account("a", AccountType.ASSETS)
    amount = Amount(100)
    guid = makeguid()
    p = Posting("journal", "date", account, direction, amount)
    p.guid = guid

    #when
    del p.guid

    #then
    assert not hasattr(p, "guid")


# Generated at 2022-06-21 20:04:26.971966
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass(frozen=True)
    class _T:
        description: str

    @dataclass(frozen=True)
    class _JournalEntries:
        def __iter__(self) -> Iterable[JournalEntry[_T]]:
            for i in range(10):
                yield JournalEntry(date=datetime.date.today(), description=f"Desc_{i}", source=_T(f"{i}"))

    class _ReadJournalEntries(_ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return (i for i in self._journal_entries if i.date in period)

    _read = _ReadJournalEntries()
    entries = list(_read(DateRange(datetime.date.today())))

# Generated at 2022-06-21 20:04:28.082355
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    entries = JournalEntry.__delattr__()
    assert entries == True


# Generated at 2022-06-21 20:04:36.900788
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from datetime import date
    from .accounts import Account, AccountType
    data = date(2019,12,31)

# Generated at 2022-06-21 20:04:46.636881
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from ..commons.types import Number
    from .accounts import AccountType
    from dateutil.parser import parse

    class Ledger:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    def factory(
        date: datetime.date,
        description: str,
        source: Ledger,
        **kwargs,
    ) -> JournalEntry[Ledger]:
        je = JournalEntry(date, description, source)


# Generated at 2022-06-21 20:04:47.658037
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert True


# Generated at 2022-06-21 20:04:59.649949
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry(date=datetime.date(2019,12,1),description='journalentry',postings=[]) == JournalEntry(date=datetime.date(2019,12,1),description='journalentry',postings=[])
    assert JournalEntry(date=datetime.date(2019,12,1),description='journalentry',postings=[]) != JournalEntry(date=datetime.date(2019,12,1),description='journal',postings=[])

# Generated at 2022-06-21 20:05:04.529161
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    j = JournalEntry(datetime.date.today(), 'Test', 123)
    assert repr(j) == 'JournalEntry(date=2020-06-24, description=Test, postings=[], guid=a2b2e1eb-0faa-45b5-a849-6b0e5c8077cb)'

# Generated at 2022-06-21 20:05:25.123256
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    Description = 'Paying off credit card'
    Description1 = 'Rent'
    Description2 = 'Operating Expense'
    Description3 = 'Credit Card'
    Description4 = 'Cash'
    direction = Direction.INC
    amount = Amount(100)
    account = Account(Description3,AccountType.LIABILITIES)
    account1 = Account(Description4,AccountType.ASSETS)
    date = datetime.date(2003, 1, 10)
    date1 = datetime.date(2003, 1, 20)
    date2 = datetime.date(2003, 1, 30)
    source = 'test'
    journal_posting1 = Posting(source,date,account,direction,amount)
    journal_posting2 = Posting(source,date1,account1,direction,amount)
    journal_posting3

# Generated at 2022-06-21 20:05:32.603988
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from common.others import Guid
    from common.numbers import Amount

    from ledger.accounts import Account
    from ledger.journal import JournalEntry, Posting
    from ledger.commons.zeitgeist import DateRange

    je = JournalEntry[object]()
    je.date = datetime.date(2019, 1, 1)
    je.description = "Testing Posting"
    je.source = object()

    je.post(datetime.date(2019, 1, 1), Account(Guid(1), "Assets", "Cash", AccountType.ASSETS), Amount(100))
    je.post(datetime.date(2019, 1, 1), Account(Guid(2), "Expenses", "Food", AccountType.EXPENSES), Amount(50))

    je.validate()

    assert je.postings[0].journal

# Generated at 2022-06-21 20:05:43.348246
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    """
    Test the method `__hash__` of class `Posting`
    """
    je = JournalEntry(date = datetime.date(2020, 1, 1), description = "", source = None)
    a1 = Account(name = "a1", type = AccountType.ASSETS)
    a2 = Account(name = "a2", type = AccountType.ASSETS)
    p1 = Posting(journal = je, date = datetime.date(2020, 1, 1), account = a1, direction = Direction.INC, amount = Amount(1))
    p2 = Posting(journal = je, date = datetime.date(2020, 1, 1), account = a1, direction = Direction.INC, amount = Amount(1))

# Generated at 2022-06-21 20:05:48.435847
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import Account, AccountType

    journal_entry1 = JournalEntry(
        date=datetime.date(2019, 12, 1), description="test_description", source=1,
        postings=[Posting(journal=journal_entry1, date=datetime.date(2019, 12, 1), account=Account(
            "test_code", "test_name", AccountType.ASSETS, decimals=2, parent=None), direction=Direction.INC, amount=100
        )]
    )


# Generated at 2022-06-21 20:05:48.991862
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    pass

# Generated at 2022-06-21 20:05:56.427638
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date.today()
    from .accounts import Account
    asset_lik_account = Account(name="Abc", type=AccountType.ASSETS)
    inc_amount = 1  # Should be in positive value
    dec_amount = -2  # decrease is negative value

    journal_entry = JournalEntry(date, "Description", source={})
    journal_entry.post(date, asset_lik_account, inc_amount)
    journal_entry.post(date, asset_lik_account, inc_amount)
    journal_entry.post(date, asset_lik_account, dec_amount)
    positive_increment_count = 2
 
    assert len(list(journal_entry.increments)) == positive_increment_count

# Generated at 2022-06-21 20:05:56.912128
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert True

# Generated at 2022-06-21 20:05:58.062748
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # TODO
    pass

# Generated at 2022-06-21 20:06:01.300327
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry(0, "", 0)) == "JournalEntry(date=0, description='', source=0)"


# Generated at 2022-06-21 20:06:10.078962
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journalEntry = JournalEntry(datetime.date(2013, 1, 1), 1, {1: 1}, [])
    journalEntry2 = JournalEntry(datetime.date(2013, 1, 1), 1, {1: 1}, [])
    journalEntry3 = JournalEntry(datetime.date(2013, 1, 1), 1, {2: 2}, [])
    journalEntry4 = JournalEntry(datetime.date(2013, 1, 1), 2, {1: 1}, [])
    journalEntry5 = JournalEntry(datetime.date(2013, 1, 2), 1, {1: 1}, [])
    assert hash(journalEntry) == hash(journalEntry2)
    assert hash(journalEntry) != hash(journalEntry3)
    assert hash(journalEntry) != hash(journalEntry4)

# Generated at 2022-06-21 20:06:50.352003
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    dt = datetime.date(2020,10,29)
    description = "description"
    source = "source"
    postings = []
    je = JournalEntry(dt,description,source, postings)
    assert repr(je) == 'JournalEntry(date=datetime.date(2020, 10, 29), description=\'description\', source=\'source\', postings=[])'
    return

# Generated at 2022-06-21 20:06:56.282253
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    journalEntry = JournalEntry(date='2020-01-01', description='this is description', source='')
    account = Account(name="Test Account")
    posting = Posting(journal=journalEntry, date='2020-01-01', account=account, direction=Direction.INC, amount=3)
    try:
        del posting.journal
    except AttributeError as e:
        pass


# Generated at 2022-06-21 20:07:01.752283
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    #Given
    a_date = datetime.date(2000,1,1)
    an_account = Account(type=AccountType.ASSETS)
    a_quantity = Quantity(1)
    journal_entry = JournalEntry(date=a_date,description='',source='')

    #When
    journal_entry.post(date=a_date,account=an_account,quantity=a_quantity)

    #Then
    assert journal_entry.postings[0].amount.value==1

# Generated at 2022-06-21 20:07:06.976814
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p1 = Posting(None, None, None, None, None)
    p2 = Posting(None, None, None, None, None)
    assert p1 != p2
    assert hash(p1) != hash(p2)

# Generated at 2022-06-21 20:07:10.099448
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Setup
    je = JournalEntry(datetime.date(2020, 5, 15), 'Debit test')
    assert je.postings == []
    # Exercise
    # Assert
    # Cleanup - None

# Generated at 2022-06-21 20:07:18.657572
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from ..commons.accounts import ledgers
    from ..commons.numbers import parse_amount
    from ..commons.types import DatePeriod
    from ..commons.zeitgeist import DateRange

    from datetime import date
    from moneyed import Money

    ledgers.check_is_ready()

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        return [
            JournalEntry(date(2019, 10, 10), "Test Posting", None,
                [
                    Posting(None, date(2019, 10, 10), ledgers.get_ledger_account(ledgers.SimplifiedLedger.INCOME_TAX), Direction.INC, parse_amount("1000.00")),
                ]
            ),
        ]

    ## Execution:
    journal_ent

# Generated at 2022-06-21 20:07:29.391653
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Test method __call__ of class ReadJournalEntries.
    """

    import datetime
    from dataclasses import dataclass
    from typing import List

    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType

    @dataclass(frozen=True)
    class Foo:
        """
        Some business object.
        """
    @dataclass(frozen=True)
    class Bar:
        """
        Some other business object.
        """

    foos: List[Foo] = []
    bars: List[Bar] = []


# Generated at 2022-06-21 20:07:30.774505
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    @dataclass()
    class T(object):
        pass



# Generated at 2022-06-21 20:07:39.314683
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date
    from ..commons.zeitgeist import DateRange

    # The list of postings should be initialized in the constructor
    # when the class is frozen
    j = JournalEntry(date(2017, 12, 1), "Test", None)
    assert j.postings == []

    # Create a new mutable instance
    j = JournalEntry(date(2017, 12, 1), "Test", None)
    j.postings = [1, 2, 3]
    assert j.postings == [1, 2, 3]



# Generated at 2022-06-21 20:07:52.140842
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from ..commons.accounts import Account, AccountType
    from ..commons.numbers import Amount, Money
    from ..commons.others import make
    from ..costfactors.costfactors import CostFactor, CostFactorValue
    from ..projects.projects import Project
    from ..salaries.salaries import Salary
    from ..timesheets.timesheets import Assignment, Timesheet, TimesheetRow

    project = make(Project, code="P1", name="Project 1")
    

# Generated at 2022-06-21 20:09:14.841110
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from dataclasses import dataclass
    from ..commons.zeitgeist import DateRange
    import pytest
    from .accounts import Account, AccountType
    from .journal import JournalEntry, Posting,ReadJournalEntries, _debit_mapping, Direction
    from ..commons.others import Guid, makeguid
    from ..commons.numbers import Amount, Quantity, isum
    @dataclass(frozen=True)
    class item(Generic[_T]):
        date: datetime.date
        description: str
        source: _T
        postings: List[Posting[_T]] = field(default_factory=list, init=False)
        guid: Guid = field(default_factory=makeguid, init=False)

# Generated at 2022-06-21 20:09:22.755800
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    p = Posting(None, None, None, None, None)
    #: Setting any attribute to an arbitrary value should throw an exception.
    for attr_name in p.__dict__.keys():
        # assert_raises(AttributeError, setattr, p, attr_name, "any value")
        try:
            setattr(p, attr_name, "any value")
            raise AssertionError(f'{p}::__setattr__ did not throw an exception for setting attribute {attr_name}')
        except AttributeError:
            # expected behaviour.
            pass

# Generated at 2022-06-21 20:09:32.059501
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    source = {}
    a = JournalEntry(date=datetime.date.today(), description='description', source=source)

    ## Case: Journal entries are equal (1):
    b = JournalEntry(date=datetime.date.today(), description='description', source=source)
    assert a == b

    ## Case: Journal entries are equal (2):
    b = JournalEntry(date=datetime.date.today(), description='description', source=source)
    b.post(date=datetime.date.today(), account=None, quantity=0)
    assert a == b

    ## Case: Journal entries are equal (3):
    b = JournalEntry(date=datetime.date.today(), description='description', source=source)
    b.post(date=datetime.date.today(), account=None, quantity=1)
    a.post

# Generated at 2022-06-21 20:09:33.388512
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    j = JournalEntry(None, None, None)
    j.postings = None
    assert j.postings is not None
    j.postings = [None]
    assert j.postings is not None

# Generated at 2022-06-21 20:09:41.370112
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class TestSource:
        @staticmethod
        def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[TestSource]]:
            pass

    TestSource.read_journal_entries.__call__ = lambda _period: []
    assert isinstance(TestSource.read_journal_entries, ReadJournalEntries) is True

# Generated at 2022-06-21 20:09:50.693617
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    """
    Tests equality between two Postings entries
    """
    from .accounts import Account

    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountCategory
    from .accounts import AccountGroup
    from .accounts import Posting
    from .accounts import JournalEntry

    p1 = Posting(journal=JournalEntry(date=datetime.date(2019, 11, 5), description='JournalEntry1', source='Source1'), date=datetime.date(2019, 11, 5), account=Account(id=1, type=AccountType.REVENUES, category=AccountCategory.INCOME, group=AccountGroup.EARNINGS_OR_PROFITS), direction=Direction.DEC, amount=Amount(value=10))


# Generated at 2022-06-21 20:09:53.710033
# Unit test for constructor of class Posting
def test_Posting():
    journal = JournalEntry(0,0,0)
    assert journal.date == 0
    assert journal.description == 0
    assert journal.source == 0
    assert journal.postings == []
    assert journal.guid == Guid("00000000-0000-0000-0000-000000000000")


# Generated at 2022-06-21 20:10:06.861368
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # Assert not to be able to delete immutable attributes
    je = JournalEntry(
        date = datetime.date(2019, 1, 1),
        description = "Unit test for JournalEntry.__delattr__",
        source = None
    )
    delattr(je, 'date')
    delattr(je, 'description')
    delattr(je, 'source')
    delattr(je, 'postings')
    delattr(je, 'guid')
    # Assert to be able to delete mutable attributes, for example postings
    je.post(datetime.date(2019, 1, 1), None, 100)
    delattr(je, 'postings')
    # Assert to be able to delete all attributes
    delattr(je, 'date')
    delattr(je, 'description')

# Generated at 2022-06-21 20:10:14.476176
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # arrange
    date = datetime.date.today()
    description = "desc"
    source = 0
    postings = []
    sut = JournalEntry[int](date, description, source, postings)

    # act, assert
    sut.guid  # => no effect; check the behavior on __setattr__
    sut.post(date, Account(1, "a", AccountType.ASSETS), 1)
    assert all(p.journal is sut for p in postings)
    assert all(p.direction == Direction.INC for p in postings)

# Generated at 2022-06-21 20:10:19.400731
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert str(Posting(None, None, None, None, None)) == "Posting(journal=None, date=None, account=None, direction=None, amount=None)"