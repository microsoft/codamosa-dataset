

# Generated at 2022-06-21 20:01:17.632673
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    with pytest.raises(AttributeError):
        JournalEntry('', '', '', '', 0, Guid())

# Generated at 2022-06-21 20:01:26.343261
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from ..commons.test_accounts import test_accounts
    test_journal = JournalEntry[str]("2020-05-01", "Testing Journal", "Testing", [])
    def assert_object(posting, date, account, direction, amount):
        assert posting.journal == test_journal
        assert posting.date == date
        assert posting.account == account
        assert posting.direction == direction
        assert posting.amount == amount

    test_date = datetime.date(2020, 5, 1)
    test_account = test_accounts["Cash"]
    test_amount = 50
    test_direction = Direction.DEC

    # Case #1: All parameters
    posting1 = Posting(test_journal, test_date, test_account, test_direction, test_amount)

# Generated at 2022-06-21 20:01:37.267421
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(None, None, None, None, None) != None
    assert Posting(None, None, None, None, None) == Posting(None, None, None, None, None)

    assert Posting(1, None, None, None, None) != Posting(None, None, None, None, None)
    assert Posting(None, 1, None, None, None) != Posting(None, None, None, None, None)
    assert Posting(None, None, 1, None, None) != Posting(None, None, None, None, None)
    assert Posting(None, None, None, 1, None) != Posting(None, None, None, None, None)
    assert Posting(None, None, None, None, 1) != Posting(None, None, None, None, None)



# Generated at 2022-06-21 20:01:48.442217
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    credit_account = Account('credit_account', AccountType.LIABILITIES)
    debit_account = Account('debit_account', AccountType.EQUITIES)
    journal_entry_date = datetime.date(2020, 3, 3)
    journal_entry_description = 'test_journal_entry'
    journal_entry_source = 'test_source'
    journal_entry_credit_amount = 10
    journal_entry_debit_amount = 10
    journal_entry = JournalEntry[str](journal_entry_date, journal_entry_description, journal_entry_source)
    journal_entry.post(journal_entry_date, credit_account, journal_entry_credit_amount)
    journal_entry.post(journal_entry_date, debit_account, journal_entry_debit_amount)

# Generated at 2022-06-21 20:01:55.026174
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from typing import Callable

    def test_func(period: DateRange) -> Iterable[JournalEntry[int]]:
        pass
    test_func1: ReadJournalEntries[int] = test_func
    test_func2: Callable[[DateRange], Iterable[JournalEntry[int]]] = test_func
    assert test_func1 == test_func2

# vim: et:ts=4:sw=4:tw=79

# Generated at 2022-06-21 20:01:56.771894
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert ReadJournalEntries() != None


# Generated at 2022-06-21 20:02:05.128636
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import pytest
    from ..commons.others import try_parse_date
    from ..commons.zeitgeist import daterange

    R_J_E = ReadJournalEntries

    def _read_journal_entries(start: datetime.date, end: datetime.date) -> Iterable[JournalEntry[str]]:
        return [
            JournalEntry(
                try_parse_date("2020-01-01"), "Description 1", "Source 1", [],
            ),
            JournalEntry(
                try_parse_date("2020-01-03"), "Description 3", "Source 3", [],
            ),
        ]

    with pytest.raises(TypeError):
        R_J_E.__abstractmethods__.add("__call__")


# Generated at 2022-06-21 20:02:17.174739
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .business import Product
    from .currencies import Currency
    from .prices import Price
    from .units import Unit
    assert JournalEntry(
        datetime.date(2020, 1, 1),
        "No posting",
        None,
    ).postings == []
    assert JournalEntry(
        datetime.date(2020, 1, 1),
        "One zero posting",
        None,
    ).post(datetime.date(2020, 1, 1), Account.of("Sales"), 0).postings == []

# Generated at 2022-06-21 20:02:21.123157
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    account = Account("Account")
    date = datetime.date.today()
    journal = JournalEntry(date, "Description", "Source")
    direction = Direction.INC
    amount = Amount("5")
    posting1 = Posting(journal, date, account, direction, amount)
    posting2 = Posting(journal, date, account, direction, amount)

    assert posting1 == posting2


# Generated at 2022-06-21 20:02:22.506932
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    j = JournalEntry("date")
    assert j.date == "date"

# Generated at 2022-06-21 20:02:28.365643
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    ## Verify:
    try:
        JournalEntry[int](date=datetime.date.today(), description="Test Journal Entry", source=1)
    except Exception as ex:
        assert False, f"Expected success but got {ex}"
    else:
        assert True, f"Expected success but got {ex}"


# Generated at 2022-06-21 20:02:31.111679
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    rje = ReadJournalEntries()
    entries = rje(None)
    print(entries)
    assert entries is not None
    assert entries is not object
    assert entries is not type

# Generated at 2022-06-21 20:02:42.080546
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    # Setup
    p1 = Posting(1, 2, 3, 4, 5)
    p2 = Posting(1, 2, 3, 4, 5)
    assert p1.journal == 1
    assert p1.date == 2
    assert p1.account == 3
    assert p1.direction == 4
    assert p1.amount == 5

    # Exercise
    del p1.journal
    del p1.date
    del p1.account
    del p1.direction
    del p1.amount

    # Verify
    assert p1.journal == 1
    assert p1.date == 2
    assert p1.account == 3
    assert p1.direction == 4
    assert p1.amount == 5
    assert not hasattr(p1, 'journal')
    assert not hasattr(p1, 'date')


# Generated at 2022-06-21 20:02:49.911400
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Create the source
    source = 1
    # Create the value of the account
    acc = Account("a", "A")
    # Create the value of the amount
    amount = Amount(100)
    # Create the value of the direction
    direction = Direction.INC
    # Create the value of the date
    date = datetime.date(1999, 12, 31)
    # Create the date_range for the unit test
    date_range = DateRange(begin=date, end=date)
    # Create the journal
    journal = JournalEntry[int]
    # Test the value of the journal
    assert journal.source == None
    # Test the value of the postings
    assert journal.postings == []
    # Test the value of the guid
    assert journal.guid == None
    # Create the unit test of the function post

# Generated at 2022-06-21 20:02:55.965316
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    jo = JournalEntry(date = datetime.date(2020, 1, 1), description = "A", source = "B", postings =[])
    assert jo.date == datetime.date(2020, 1, 1)
    assert jo.description == 'A'
    assert jo.postings == []
    assert jo.source == 'B'


# Generated at 2022-06-21 20:03:01.459880
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal = JournalEntry(date=datetime.date(2019, 10, 1), description="Test journal entry", source="Test source")
    journal.post(date=datetime.date(2019, 10, 1), account='A', quantity=100)
    journal.post(date=datetime.date(2019, 10, 1), account='B', quantity=-100)
    journal.validate()

# Generated at 2022-06-21 20:03:11.685631
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import pytest
    @dataclass(frozen=True)
    class _Person:
        name: str

    @dataclass(frozen=True)
    class _Account:
        name: str

    entries: List[JournalEntry[_Person]] = []
    def _source(target: ReadJournalEntries[_Person]) -> None:
        entries.extend(target(DateRange(datetime.date(2020, 1, 1), datetime.date(2021, 12, 31))))


# Generated at 2022-06-21 20:03:17.699921
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from datetime import date
    from .accounts import Account
    entry = JournalEntry[int](date(2020,1,1), 'Description', 123)
    assert repr(entry) == repr({'type': 'journal_entry.JournalEntry', 'date': date(2020,1,1), 'description': 'Description', 'source': '123', 'postings': []})

# Generated at 2022-06-21 20:03:24.495426
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from ..commons.numbers import ZERO_CURRENCY
    from .accounts import get_account

    journal = JournalEntry[None].post(datetime.date(2020,1,1), "Test journal entry")
    journal.post(datetime.date(2020,1,1), get_account("CASH"), ZERO_CURRENCY)
    journal.validate()
    journal.__delattr__("postings")
    journal.validate()

# Generated at 2022-06-21 20:03:36.804225
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    #Dict[DateRange, Amount]
    from ..ledger import Ledger
    from dataclasses import dataclass, field
    from typing import Dict, Iterable, List, TypeVar
    from functools import partial
    from datetime import date
    from operator import attrgetter
    import itertools
    import sys
    import pytest
    @dataclass(frozen=True)
    class JournalEntry():
        date: date
        description: str
        credit: Amount = field(default=Amount(0))
        debit: Amount = field(default=Amount(0))

    T = TypeVar("T")
    @dataclass(frozen=True)
    class Journal():
        postings: Dict[DateRange, JournalEntry] = field(default_factory=dict)

# Generated at 2022-06-21 20:03:53.577747
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from . import accounts
    from .postings import journal_entry

    # Setup objects
    # Setup accounts
    account_cash = accounts.Account("Cash", AccountType.ASSETS)
    account_telephone_expense = accounts.Account("Telephone Expense", AccountType.EXPENSES)
    account_telephone_revenue = accounts.Account("Telephone Revenue", AccountType.REVENUES)

    # Perform test
    # Check journal entry

# Generated at 2022-06-21 20:04:00.050217
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journal = JournalEntry(datetime.date(2019, 1, 1), "This is the journal", None)
    p1 = Posting(journal, datetime.date(2019, 1, 1), Account.of("A101", AccountType.ASSETS), Direction.INC, Amount(100))
    p1.account = Account.of("A102", AccountType.ASSETS)


# Generated at 2022-06-21 20:04:01.973147
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():

    from datetime import date
    from ..commons.others import Quantity
    from .accounts import Account

    posting = Posting(date(2019, 1, 1), Account("A"), "Inc", Quantity(100))

    with pytest.raises(AttributeError):
        posting.journal = "Test"

# Generated at 2022-06-21 20:04:13.817524
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # GIVEN
    journal_date = datetime.date(2020, 1, 1)
    journal = JournalEntry(journal_date, '')
    journal_post_date = datetime.date(2019, 12, 1)
    journal_post_account = Account('Cash')
    journal_post_quantity_1 = Amount(1.)
    journal_post_quantity_10 = Amount(10.)
    journal_post_quantity_10_1 = Amount(1.)
    journal_post_quantity_10_2 = Amount(9.)
    journal_post_quantity_10_3 = Amount(10.)
    journal_post_quantity_10_4 = Amount(11.)
    journal_post_quantity_0 = Amount(0.)

    # WHEN:
    # 1. journal.post(journal_post_date,

# Generated at 2022-06-21 20:04:17.184623
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    abc_journal_entry = JournalEntry(date=datetime.date.today(), description='abc_a', source=True)
    assert repr(abc_journal_entry) == "JournalEntry(date=datetime.date(2020, 4, 2), description='abc_a', source=True)"

# Generated at 2022-06-21 20:04:21.613858
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    entry = JournalEntry(date=datetime.date.today(), description="No description", source='test')
    entry.post(date=datetime.date.today(), account=Account('Bank'), quantity=100)
    entry.post(date=datetime.date.today(), account=Account('Cash'), quantity=-100)
    print(entry)
    print(entry.postings)
    assert entry.__repr__() == repr(entry), '__repr__ function of class Posting is wrong'

# Generated at 2022-06-21 20:04:25.627724
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journal = JournalEntry(datetime.date(2019, 1, 1), "Test", None)
    journal.post(datetime.date(2019, 1, 1), Account.create_asset("US", "Cash", "USD", Guid()), 100)
    journal.post(datetime.date(2019, 1, 1), Account.create_expense("US", "Expense", "USD", Guid()), -100)

    assert hasattr(journal, "__hash__")

# Generated at 2022-06-21 20:04:31.469984
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    date = datetime.date(2020, 7, 15)
    description = "Some description"
    source = "Some source"
    journal_entry = JournalEntry(date, description, source)
    assert journal_entry.date == date
    assert journal_entry.description == description
    assert journal_entry.source == source
    assert journal_entry.postings == []


# Generated at 2022-06-21 20:04:39.753972
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():

    je1 = JournalEntry(datetime.date(2020, 8, 1), "Test", "GLD")
    je1.postings.append(Posting(je1, datetime.date(2020, 8, 1), Account("GLD-001", "ASSETS", "Cash"), Direction.INC, Amount(100.0)))
    je1.postings.append(Posting(je1, datetime.date(2020, 8, 1), Account("GLD-002", "ASSETS", "Cash"), Direction.DEC, Amount(100.0)))
    assert hash(je1) == hash(je1)

# Generated at 2022-06-21 20:04:41.289313
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # Assume
    JournalEntry.__delattr__(object, 'attribute')

# Generated at 2022-06-21 20:04:59.213270
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from ..functools import identity


# Generated at 2022-06-21 20:05:08.567363
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from datetime import date
    from decimal import Decimal
    from switcheo.models.enums import Currency
    from switcheo.models.accounts import Account
    p = Posting(JournalEntry(date.today(), 'TEST', 'TEEEST', list()), date.today(), Account('ETH', Currency.ETH), Direction.INC, Decimal(1))
    del p.direction
    assert str(p) == "Posting(journal=JournalEntry(date=datetime.date(2020, 10, 11), description='TEST', source='TEEEST', postings=[]), date=datetime.date(2020, 10, 11), account=Account(currency=ETH, wallet=None), direction=INC, amount=Decimal('1'))"
    del p.journal

# Generated at 2022-06-21 20:05:19.144375
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    source = Account('1', AccountType.ASSETS, 'Cash', 'USD', 'USD')
    journal : JournalEntry[Account] = JournalEntry(datetime.date(2020, 1, 1), '', '')
    posting = Posting(journal, datetime.date(2020, 1, 1), source, Direction.INC, 1000)

    # test if setting posting.journal is allowed.
    try:
        posting.journal = JournalEntry(datetime.date(2020, 1, 1), '', '')
        assert False
    except:
        assert True

    # test if setting posting.date is allowed.
    try:
        posting.date = datetime.date(2020, 1, 1)
        assert False
    except:
        assert True

    # test if setting posting.account is allowed.

# Generated at 2022-06-21 20:05:25.738342
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # ARRANGE
    jjournal = JournalEntry["T"]("1970-01-01", "description", "source ")
    assert isinstance(jjournal.date, datetime.date)
    assert isinstance(jjournal.description, str)
    assert isinstance(jjournal.source, str)
    assert isinstance(jjournal.postings, list)
    assert isinstance(jjournal.increments, Iterable)
    assert isinstance(jjournal.decrements, Iterable)
    assert isinstance(jjournal.debits, Iterable)
    assert isinstance(jjournal.credits, Iterable)
    assert isinstance(jjournal.guid, Guid)



# Generated at 2022-06-21 20:05:32.253396
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..book.accounts import AccountResolver
    from ..book.book import Book
    from ..book.transactions import Transactions

    book = Book(AccountResolver(activities=[]), Transactions([]))
    journal1 = JournalEntry(datetime.date(2020, 1, 1), "Using the python module", "")
    journal1 = journal1.post(datetime.date(2020, 1, 1), book.revenues.sale, 100)
    journal1 = journal1.post(datetime.date(2020, 1, 1), book.expenses.rent, 100)
    
    assert len(journal1.postings) == 2, "postings not updated"

# Generated at 2022-06-21 20:05:38.281424
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    testObj = JournalEntry('a', DateRange(9, 10), 'b', 'c')
    guids = set()
    for i in range(100):
        print(testObj.guid)
        guids.add(testObj.guid)
    assert(len(guids) == 1)

# Generated at 2022-06-21 20:05:46.075914
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .accounts import Account
    from .account_types import AccountTypes
    journal = JournalEntry('2017-12-25', 'Test entry', 'Test source')
    post = Posting(journal, '2017-12-25', 'assets', Direction.INC, Amount(1000))
    try:
        post.postings.append(1)
    except AttributeError:
        assert True
    else:
        assert False, 'test_Posting___setattr__ failed'


# Generated at 2022-06-21 20:05:52.109759
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journalEntry = JournalEntry(datetime.date(2010, 1, 1), "deposit", None)
    posting = Posting(journalEntry, datetime.date(2010, 1, 2), Account("Assets/Cash", AccountType.ASSETS), Direction.INC, 0)
    # posting.__setattr__("date",datetime.date(2010,2,2))
    # assert posting.date == datetime.date(2010,2,2), "posting.date is not datetime.date(2010,2,2)"

# Generated at 2022-06-21 20:05:57.160519
# Unit test for constructor of class Posting
def test_Posting():
    posting = Posting(3, 4, 5, 6)
    assert (posting.journal == 3)
    assert (posting.date == 4)
    assert (posting.account == 5)
    assert (posting.direction == 6)


# Generated at 2022-06-21 20:06:07.775734
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Test for method __setattr__ of class JournalEntry
    """
    from dataclasses import fields
    from ledger.types.journal import JournalEntry as _JournalEntry
    j = JournalEntry("01-jan-2020", "test", None)
    for f in fields(j):
        name, t = f.name, type(f.type)

        # setup
        class Test: pass
        t.__getitem__ = lambda s, obj: Test

        # act and assert
        if name == 'postings':
            try:
                j.__setattr__(name, "test")
                assert False, f"should have raised TypeError due to wrong type that is assigned to item {name} of {type(j)} "
            except TypeError:
                assert True

# Generated at 2022-06-21 20:06:42.784072
# Unit test for constructor of class Posting
def test_Posting():
    a = Posting()
    assert (a.journal == None)
    assert (a.date == None)
    assert (a.account == None)
    assert (a.direction == None)
    assert (a.amount == None)
    assert (not a.is_debit)
    assert (a.is_credit)
# Unit Test for is_debit property of class Posting
    b = Posting()
    assert (b.journal == None)
    assert (b.date == None)
    assert (b.account == Account(1, AccountType.ASSETS, "Account 1"))
    assert (b.direction == Direction.INC)
    assert (b.amount == Amount(10000))
    assert (b.is_debit)
    assert (not b.is_credit)
# Unit Test for is_debit and is_

# Generated at 2022-06-21 20:06:50.092793
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # Set up test data
    sut = JournalEntry(datetime.date(2020, 1, 1), "Description", "Source", [Posting("journal", datetime.date(2020, 1, 1), "Account", "Direction", Amount("amount"))])
    # Exercise SUT
    with pytest.raises(AttributeError):
        delattr(sut, "Unknown Attribute")

# Generated at 2022-06-21 20:06:51.399572
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert True

# Generated at 2022-06-21 20:07:01.199600
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    j = JournalEntry(
        datetime.date(2012, 5, 11),
        "first journal",
        None,
        [
            Posting(None, datetime.date(2012, 5, 11), Account(AccountType.EXPENSES, "1"), Direction.DEC, Amount(10)),
            Posting(None, datetime.date(2012, 5, 11), Account(AccountType.REVENUES, "2"), Direction.INC, Amount(10)),
        ],
    )

# Generated at 2022-06-21 20:07:10.772038
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from ..commons.transactions import Transaction
    from .accounts import AccountType, Account
    from . import accounts

    entry: JournalEntry[Transaction] = JournalEntry(datetime.date.today(), "", Transaction())

    posting_1 = Posting(entry, datetime.date.today(), Account(AccountType.ASSETS, "A"), Direction.DEC, Amount(1))
    assert posting_1.journal == entry

    posting_2 = Posting(entry, datetime.date.today(), accounts.Cash, Direction.DEC, Amount(1))
    assert posting_2.journal == entry



# Generated at 2022-06-21 20:07:14.510490
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    s: Set[JournalEntry] = {JournalEntry(datetime.date(20, 1, 1), "A", None)}
    s.add(JournalEntry(datetime.date(20, 1, 1), "A", None))
    assert len(s) == 1

# Generated at 2022-06-21 20:07:15.158412
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-21 20:07:25.873110
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from datetime import date
    from .accounts import Accounts

    accounts = Accounts()
    sources = []
    je1 = JournalEntry[str](date(2019, 1, 1), "description", "source")
    je1.post(date(2019, 1, 1), accounts.get('Equity:Opening Balances'), 500)
    je1.post(date(2019, 1, 1), accounts.get('Expenses:Training'), -100)
    je1.validate()

    sources.append(je1)

    je2 = JournalEntry[str](date(2019, 1, 1), "description", "source")
    je2.post(date(2019, 1, 1), accounts.get('Equity:Opening Balances'), 500)

# Generated at 2022-06-21 20:07:30.203808
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .accounts import AccountType

    je = JournalEntry('2019-02-01', 'one posting', '', [])
    p = Posting(je, '2019-02-01', 'AAA', AccountType.ASSETS, Direction.INC, 100)
    try:
        p.journal = ''
        p.date = ''
        p.account = ''
        p.direction = ''
        p.amount = ''
    except AttributeError:
        return True
    
    return False


# Generated at 2022-06-21 20:07:39.203133
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    class Source: pass
    journal_entry=JournalEntry[Source](
        datetime.date(2020,3,4),
        "test_JournalEntry_validate",
        Source()
        )
    
    journal_entry.post(datetime.date(2020,3,4),Account("test_JournalEntry_validate_1",AccountType.ASSETS),Quantity(2))
    journal_entry.post(datetime.date(2020,3,4),Account("test_JournalEntry_validate_2",AccountType.ASSETS),Quantity(-2))
    journal_entry.validate()

# Generated at 2022-06-21 20:08:51.010460
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from datetime import date
    posting1 = Posting(1, date(2020, 1, 1), Account("Cash"), Direction.INC, Amount(10))
    posting2 = Posting(1, date(2020, 1, 1), Account("Cash"), Direction.INC, Amount(20))
    postings = [posting1, posting2]
    journal = JournalEntry(date(2020, 1, 1), "Repay debt", "Sale of stocks", postings)
    assert repr(journal) == "JournalEntry(2020-01-01, 'Repay debt', 'Sale of stocks', [Posting(1, 2020-01-01, Cash, INC, 10), Posting(1, 2020-01-01, Cash, INC, 20)])"

# Generated at 2022-06-21 20:09:01.278826
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    test_date = datetime.date(2020, 1, 13)
    test_desc = "test desc"
    test_source = "test source"
    test_postings = [(Account.of("A"), 1), (Account.of("B"), -1)]
    test_journal_entry = JournalEntry(test_date, test_desc, test_source)
    for acc, qty in test_postings:
        test_journal_entry.post(test_date, acc, qty)
    for acc, qty in test_postings:
        assert len(list(filter(lambda x: x.account == acc and x.amount.value == qty, test_journal_entry.postings))) == 1

# Generated at 2022-06-21 20:09:10.828407
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    # Invalid journal entry (debits and credits don't match)
    j1 = JournalEntry(
        date = datetime.date.today(),
        description = 'test_JournalEntry_validate',
        source = None,
    )
    j1.post(datetime.date.today(), Account(AccountType.ASSETS, 'assets', 'cash'), 10)
    j1.post(datetime.date.today(), Account(AccountType.EXPENSES, 'expenses', 'groceries'), -20)
    try:
        j1.validate()
        assert False, 'Should raise error'
    except AssertionError:
        pass

    # Valid journal entry (debits and credits match)

# Generated at 2022-06-21 20:09:21.914232
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    from django.test import TestCase

    from ..sink.models import AccountModel

    class PostingTestCase(TestCase):
        @classmethod
        def setUpTestData(cls):
            cls.posting = Posting(JournalEntry('date', 'description', 'source'), date(2019, 1, 1),
                                  AccountModel(code='code', name='name', type=AccountType.ASSETS), Direction.INC, 1)
            cls.base_exception_msg = 'Cannot set attribute'
            cls.exception_journal_msg = f'{cls.base_exception_msg} journal'
            cls.exception_date_msg = f'{cls.base_exception_msg} date'

# Generated at 2022-06-21 20:09:30.927194
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import Account
    from datetime import date
    from ledger.commons.numbers import Amount
    from ledger.commons.others import makeguid
    from ledger.journal.core import JournalEntry, Posting
    je1 = JournalEntry()
    je1.date = date(2019,7,1)
    je1.description = "first journal entry"
    je1.source = "this is the source"
    je1.guid = makeguid()
    je1.postings = [Posting(je1, date(2019,7,1), Account("Acc1",Account.Type.ASSETS), Direction.INC, Amount(100))]
    je2 = JournalEntry()
    je2.date = date(2019,7,1)
    je2.description = "first journal entry"
    je2.source

# Generated at 2022-06-21 20:09:37.813402
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import Accounts

    accounts: Accounts = Accounts()
    j_entry = JournalEntry(date = datetime.date(2020, 11, 30), description="Expenses: Inpurchase", source="", postings=[Posting(journal = j_entry, account = accounts.get("Expenses: Inpurchase"), date = datetime.date(2020, 11, 30), direction = Direction.INC, amount = Amount(100))])
    assert j_entry.date == datetime.date(2020, 11, 30)
    assert j_entry.description == "Expenses: Inpurchase"
    assert j_entry.postings[0] == Posting(journal = j_entry, account = accounts.get("Expenses: Inpurchase"), date = datetime.date(2020, 11, 30), direction = Direction.INC, amount = Amount(100))

# Generated at 2022-06-21 20:09:39.571536
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass



# Generated at 2022-06-21 20:09:47.989792
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    j1 = JournalEntry[str](
        datetime.date(2020, 1, 1), "Test", "source",
        [Posting(None, datetime.date(2020, 1, 1), Account("A/ct"), Direction.INC, Amount(100))],
    )
    j2 = JournalEntry[str](
        datetime.date(2020, 1, 1), "Test", "source",
        [Posting(None, datetime.date(2020, 1, 1), Account("A/ct"), Direction.INC, Amount(100))],
    )
    assert hash(j1) == hash(j2)


# Generated at 2022-06-21 20:09:50.002219
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    Posting.__delattr__('journal')
    Posting.__delattr__('is_debit')


# Generated at 2022-06-21 20:09:54.952292
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting(JournalEntry(datetime.date.today(), "Description", None), datetime.date.today(), Account(0, "Account", AccountType.ASSETS), Direction.INC, Amount(10))) == f"Posting(journal=JournalEntry(date={datetime.date.today()}, description='Description', source=None, guid={makeguid()}), date={datetime.date.today()}, account=Account(id=0, name='Account', type=<AccountType.ASSETS: 1>), direction=<Direction.INC: 1>, amount=Amount(10))"