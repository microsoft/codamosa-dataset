

# Generated at 2022-06-21 20:01:19.295007
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je = JournalEntry(Date(2018, 1, 1), "Test", None)
    assert hash(je) == hash((je.date, je.description, je.source, je.guid))

# Generated at 2022-06-21 20:01:27.987443
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from dataclasses import asdict
    from operator import attrgetter

    @dataclass
    class MyAccount:
        id: Guid
        name: str
        type: AccountType

    @dataclass
    class MyJournalEntry:
        id: Guid
        date: datetime.date
        description: str

    @dataclass
    class MyPosting:
        id: Guid
        journal: MyJournalEntry
        date: datetime.date
        account: MyAccount
        direction: Direction
        amount: Amount


# Generated at 2022-06-21 20:01:38.222119
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..inventory.sales import SalesInvoice
    from ..inventory.purchases import PurchaseInvoice
    from ..money import Currency as C, Money as M

    # Given: Two business types
    sales_invoice = SalesInvoice()
    purchase_invoice = PurchaseInvoice()

    # Given: A journal entry for a sale
    entry = JournalEntry(datetime.date.today(), "Sale invoice", sales_invoice)

    # When: Postings are made
    entry.post(datetime.date.today(), Account(AccountType.ASSETS, "Accounts Receivable", C.GHS), M(500, C.GHS))
    entry.post(datetime.date.today(), Account(AccountType.REVENUES, "Sales", C.GHS), M(500, C.GHS))

    # Given: A journal entry

# Generated at 2022-06-21 20:01:49.366173
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import AccountType, Account, SystemAccountType


# Generated at 2022-06-21 20:02:00.772502
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from pybook.book.accounts import Account
    from pybook.book.journal import JournalEntry
    from pybook.commons.others import makeguid

    class TestSource:
        def __init__(self, guid):
            self.guid = guid
    test_source = TestSource(makeguid())
    test_account_revenue = Account(makeguid(), "Revenue", makeguid())
    test_account_expenses = Account(makeguid(), "Expenses", makeguid())
    test_account_capital = Account(makeguid(), "Capital", makeguid())
    test_journal_entry = JournalEntry(date(2020, 1, 1), "Test Journal Entry", test_source)

# Generated at 2022-06-21 20:02:01.492540
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-21 20:02:13.603509
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    test_account = Account(id=str(1), name="test")
    test_journal = JournalEntry(date=datetime.date.today(), description="test", source=str(1))
    test_posting = Posting(journal=test_journal, date=datetime.date.today(), account=test_account, direction=Direction.INC, amount=Amount(1))
    del test_posting.journal
    del test_posting.date
    del test_posting.account
    del test_posting.direction
    del test_posting.amount
    assert 'journal' not in test_posting.__dict__
    assert 'date' not in test_posting.__dict__
    assert 'account' not in test_posting.__dict__
    assert 'direction' not in test_posting.__dict__


# Generated at 2022-06-21 20:02:22.142031
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import ASSET_CASH, LIABILITY_DEBT, EXPENSE_MISC, REVENUE_SALES

    date = datetime.date.today()
    journal_entry = JournalEntry[None](
        date, "Test entry", None
    ).post(date, ASSET_CASH, +5.5) \
    .post(date, LIABILITY_DEBT, -5.5) \
    .post(date, EXPENSE_MISC, -20) \
    .post(date, REVENUE_SALES, +20)

    assert journal_entry.validate() is None

# Generated at 2022-06-21 20:02:34.134972
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    account1 = Account('Acc1', None, None) 
    account2 = Account('Acc2', None, None)
    account3 = Account('Acc3', None, None)
    account4 = Account('Acc4', None, None)
    account5 = Account('Acc5', None, None)
    account6 = Account('Acc6', None, None)
    account7 = Account('Acc7', None, None)
    account8 = Account('Acc8', None, None)
    account9 = Account('Acc9', None, None)
    account10 = Account('Acc10', None, None)
    account11 = Account('Acc11', None, None)
    account12 = Account('Acc12', None, None)
    account13 = Account('Acc13', None, None)
    account14 = Account('Acc14', None, None)
    account

# Generated at 2022-06-21 20:02:44.684760
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p1 = Posting(JournalEntry(datetime.date(2012,2,1), "description", object()), datetime.date(2012,2,1), Account(), Direction.INC, Amount(1))
    p2 = Posting(JournalEntry(datetime.date(2012,2,1), "description", object()), datetime.date(2012,2,1), Account(), Direction.INC, Amount(1))
    p3 = Posting(JournalEntry(datetime.date(2012,2,1), "description", object()), datetime.date(2012,2,1), Account(), Direction.INC, Amount(1))
    print(p1.__hash__() == p2.__hash__())
    print(p3.__hash__() == p2.__hash__())

# Generated at 2022-06-21 20:02:56.725413
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # Test a string representation of a Posting object
    p = Posting(1,"aa",Direction.INC,Amount(2.0))
    assert repr(p) == "journal: 1, date: aa, direction: Direction.INC"


# Generated at 2022-06-21 20:03:07.388833
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from .transactions import Transaction
    from .transactions import TransactionError
    from . import accounts
    from . import commodities

    # test for when everything is fine
    try:
        journal = JournalEntry(datetime.date.today(), 'test journal', None)
    except TransactionError as e:
        assert False, f"Error: {e}"

    account = accounts.CurrentAccount(commodities.EUR, "test account", None)
    amount = Amount(1)
    direction = Direction.INC
    post = Posting(journal, datetime.date.today(), account, direction, amount)
    assert post.__hash__() is not None, "Can not compute hash value for posting"



# Generated at 2022-06-21 20:03:18.638032
# Unit test for constructor of class Posting
def test_Posting():
    _journal = JournalEntry[int](date=datetime.date.today(), description="dummy", source=None)
    _date = datetime.date.today()
    _account = Account(type=AccountType.ASSETS, code="00")
    _direction = Direction.INC
    _amount = Amount(5)
    posting1 = Posting(_journal, _date, _account, _direction, _amount)
    assert posting1.journal == _journal
    assert posting1.date == _date
    assert posting1.account == _account
    assert posting1.direction == _direction
    assert posting1.amount == _amount
    assert posting1.is_debit == True


# Generated at 2022-06-21 20:03:24.549186
# Unit test for constructor of class Posting
def test_Posting():
    p1 = Posting(JournalEntry(date=datetime.date(2020, 1, 1), description="hey", source=5),
                "date",
                Account(number=100, name='Cash', type=AccountType.ASSETS),
                Direction.INC,
                100)
    assert isinstance(p1, Posting)
    print(p1)



# Generated at 2022-06-21 20:03:36.804914
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import Account
    from .accounts import AccountType
    exp = Account(
        "Expense",
        "Expenses",
        AccountType.EXPENSES
    )
    rev = Account(
        "Revenue",
        "Revenues",
        AccountType.REVENUES
    )
    j = JournalEntry(
        date = datetime.datetime(2020, 5, 10),
        description = "Journal Entry",
        source = None,
    )
    j.post(
        datetime.datetime.now(),
        exp,
        10
    )
    j.post(
        datetime.datetime.now(),
        rev,
        10
    )
    a = repr(j)

# Generated at 2022-06-21 20:03:40.075148
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry(datetime.date(1980,1,1), "Test Entry", 'Test Source')) == "JournalEntry(date=1980-01-01, description='Test Entry')"

# Generated at 2022-06-21 20:03:52.355051
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from dataclasses import asdict
    from datetime import date
    from decimal import Decimal
    from decimal import Decimal
    from decimal import Decimal
    from ..commons.numbers import Amount, isum
    from .accounts import Account, AccountType
    @dataclass
    class TestJournalEntry(JournalEntry):
        def TestJournalEntry(self):
            pass
    from .accounts import Account, AccountType
    from datetime import date
    ## Arrange ##
    journal = TestJournalEntry(
        date = date(2019, 9, 10),
        description = 'Test Description',
        source = None
        )
    journal.post(date(2019, 9, 10), Account(AccountType.ASSETS, 'Cash'), Decimal(100))

# Generated at 2022-06-21 20:03:53.180802
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert ReadJournalEntries() is not None

# Generated at 2022-06-21 20:04:01.082231
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Unit test for method post of class JournalEntry
    """
    je1 = JournalEntry(datetime.date(2020,7,10),
    "test description",
    2, [])

    je1.post(datetime.date(2020,7,10), "Test.Account", -5)

    assert je1.postings == [Posting(je1, datetime.date(2020,7,10), "Test.Account", Direction.DEC, 5)]



# Generated at 2022-06-21 20:04:01.639939
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass

# Generated at 2022-06-21 20:04:08.406893
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert False, "Not yet implemented"


# Generated at 2022-06-21 20:04:15.770761
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    posting1 = Posting(1,2,3,4,5)
    posting2 = Posting(1,2,3,4,5)
    posting3 = Posting(1,2,3,4,6)
    hash1 = hash(posting1)
    hash2 = hash(posting2)
    hash3 = hash(posting3)
    assert hash1 == hash2, "Hash code of two identical postings are not equal"
    assert hash1 != hash3, "Hash code of two different postings are equal"

# Generated at 2022-06-21 20:04:21.178336
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    
    # print("read journal entries")
    def read_journal_entries_factory(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    read_journal_entries = read_journal_entries_factory
    assert read_journal_entries is not None

# Generated at 2022-06-21 20:04:27.796426
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .tags import Tag, TagCategory, TagMap

    a = Account(AccountType.ASSETS,"test")
    b = Account(AccountType.LIABILITIES,"test")
    c = Account(AccountType.EQUITIES,"test")
    t = Tag("test",TagCategory.EXPENSE)
    tm = TagMap([t])
    je = JournalEntry(datetime.date(2019, 1, 1), "Entry", "Source")
    je.post(datetime.date(2019, 1, 2), a, 100)
    je.post(datetime.date(2019, 1, 3), b, 100)
    je.post(datetime.date(2019, 1, 4), c, 100)
    je.post(datetime.date(2019, 1, 5), a, 100)

# Generated at 2022-06-21 20:04:33.634674
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry(datetime.date(2020, 5, 8), "", "")
    je.post(datetime.date(2020, 5, 8), Account("Cash", AccountType.ASSETS), Quantity(10))
    je.post(datetime.date(2020, 5, 8), Account("Sales", AccountType.REVENUES), Quantity(-10))
    je.validate()

# Generated at 2022-06-21 20:04:41.451001
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # normalize digits
    assert JournalEntry.validate(
        JournalEntry(datetime.date(2020, 7, 12), "Test Journal Entry", "Test Journal Entry Source", [
            Posting(None, datetime.date(2020, 7, 12), Account("ASSETS.CASH", AccountType.ASSETS), Direction.INC, 0),
            Posting(None, datetime.date(2020, 7, 12), Account("INCOME.SALES", AccountType.REVENUES), Direction.DEC, 0)
        ])
    )


# Generated at 2022-06-21 20:04:45.785515
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry(date=datetime.date(2014, 5, 2), description="Test", source={'doc': 'journal-entry'})
    assert je.description == "Test"
    assert je.postings == []
    assert je.date == datetime.date(2014, 5, 2)
    assert je.source == {'doc': 'journal-entry'}


# Generated at 2022-06-21 20:04:50.393664
# Unit test for constructor of class Posting
def test_Posting():
    post = Posting(None, datetime.date(2019,1,1), Account("Cash"), 1, 100)
    assert post.amount == 100
    assert post.direction == Direction.INC
    assert post.account.type == AccountType.ASSETS



# Generated at 2022-06-21 20:05:03.029689
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    try:
        JournalEntry[int](date=datetime.date(2012, 1, 1), description="description", source=1).postings = [
            Posting[int](JournalEntry[int](date=datetime.date(2012, 1, 1), description="description", source=1),
                        datetime.date(2012, 1, 1), Account("assets", AccountType.ASSETS),
                        Direction.INC, Amount(0)),
            Posting[int](JournalEntry[int](date=datetime.date(2012, 1, 1), description="description", source=1),
                        datetime.date(2012, 1, 1), Account("expenses", AccountType.EXPENSES),
                        Direction.DEC, Amount(0))
        ]
        assert False
    except AttributeError:
        pass

# Generated at 2022-06-21 20:05:08.009774
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account = Account(makeguid(), "A", AccountType.EQUITIES)
    journal = JournalEntry(datetime.date.today(), "Test Journal Entry", "Test")
    journal.post(datetime.date.today(), account, Amount(100))
    journal.validate()


# Generated at 2022-06-21 20:05:26.569419
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..entity.accounts import Account, AccountType
    from ..entity.journal_entry import Direction, JournalEntry, Posting

    print('\n------------------------- test_JournalEntry_post -------------------------\n')

    def check_posting_properties(j: JournalEntry, p, expected_direction, expected_account, expected_amount):
        assert p.journal == j
        assert p.account == expected_account
        assert p.direction == expected_direction
        assert p.amount == expected_amount

    j = JournalEntry(date(2018, 1, 1), 'description', 'source')

    j.post(date(2018, 1, 1), Account(AccountType.ASSETS, 'Cash', '', 0), Quantity(100))


# Generated at 2022-06-21 20:05:32.716791
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account1 = Account(Guid('b8bc8bd6-6786-434c-9d3a-c9e1dafbab0c'), 'Assets')
    account2 = Account(Guid('b8bc8bd6-6786-434c-9d3a-c9e1dafbab0c'), 'Equities')
    journal_entry = JournalEntry('2019-01-01', 'test_journal_entry', None)
    journal_entry.post('2019-01-01', account1, 100)
    journal_entry.post('2019-01-01', account2, -100)
    journal_entry.validate()

# Generated at 2022-06-21 20:05:43.586319
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from ..commons.numbers import Quantity
    from .accounts import Account, AccountType

    REVENUE = Account("REVENUE", AccountType.REVENUES)
    CASH = Account("CASH", AccountType.ASSETS)
    date = datetime.date(year=2020, month=1, day=1)

    # Create a new journal entry
    journal = JournalEntry("Testing Journal Entry")

    # Post revenuse and cash
    journal.post(date, REVENUE, Quantity(15))
    journal.post(date, CASH, Quantity(15))
    journal.validate()

    # Create a new journal entry
    journal = JournalEntry("Testing Journal Entry")

    # Post revenuse and cash
    journal.post(date, REVENUE, Quantity(15))

# Generated at 2022-06-21 20:05:52.964313
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    """
    Tests method __hash__ of class JournalEntry.
    """
    from datetime import date
    from sharpe.accounts import register_asset

    def test_set():
        """
        Tests that two journal entries with different guids but same description are still considered equal in a set.
        """

        asset_account = register_asset(0, "cash", "cash")

        journal_entry_1 = JournalEntry(date(2020, 6, 1), "a", None).post(date(2020, 6, 1), asset_account, 1)
        journal_entry_2 = JournalEntry(date(2020, 6, 1), "a", None).post(date(2020, 6, 1), asset_account, 1)

        journal_set = {journal_entry_1, journal_entry_2}
        assert len(journal_set)

# Generated at 2022-06-21 20:05:53.692336
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Pass
    pass

# Generated at 2022-06-21 20:05:57.856558
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    je = JournalEntry[int](datetime.date(2020, 1, 1), "Test Entry", 1)
    assert repr(je) == "JournalEntry<int>[2020-01-01](Test Entry) <1>"


# Generated at 2022-06-21 20:06:08.127080
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    try:
        Posting(None, None, None, None, None).journal = 0
        assert False, "Unable to set non-field attribute `journal`"
    except AttributeError as e:
        pass

    try:
        Posting(None, None, None, None, None).date = 0
        assert False, "Unable to set non-field attribute `date`"
    except AttributeError as e:
        pass

    try:
        Posting(None, None, None, None, None).account = 0
        assert False, "Unable to set non-field attribute `account`"
    except AttributeError as e:
        pass


# Generated at 2022-06-21 20:06:17.074700
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ledger.accounts import Account as a
    from ledger.accounts import AccountType as at
    from ledger.accounts import Assets, Expenses, Revenues

    #: Just some random date
    date = datetime.date(2018, 11, 5)

    # Create an entry with a debit posting of 800 and a credit posting of 800 (to make the journal entry balanced)
    j = JournalEntry(date, "Sample desc", "source")
    print(j)
    j.post(date, a(Assets.CASH, at.ASSETS), 800)
    print(j)
    j.post(date, a(Expenses.SALARIES, at.EXPENSES), -800)
    print(j)
    assert j.postings[0].amount == 800
    assert j.postings[1].amount == 800

   

# Generated at 2022-06-21 20:06:28.428362
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry[str](datetime.date(2019, 10, 1), "x", "a")
    assert j.postings == []
    assert j.post(datetime.date(2019, 10, 1), Account.of("Current Assets", AccountType.ASSETS), Quantity(100)) == j
    assert j.postings == [Posting(j, datetime.date(2019, 10, 1), Account.of("Current Assets", AccountType.ASSETS), Direction.INC, Amount(100))]
    assert j.post(datetime.date(2019, 10, 1), Account.of("Expense", AccountType.EXPENSES), Quantity(-50)) == j

# Generated at 2022-06-21 20:06:35.193088
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from ..commons.times import Date

    source = object()
    je = JournalEntry[object](date=Date(2017, 8, 1), description="Dummy journal entry", source=source)
    assert je.description == "Dummy journal entry"
    try:
        je.description = "Foo"
    except AttributeError as e:
        assert str(e) == "'JournalEntry' object has no attribute 'description'"

# Generated at 2022-06-21 20:07:03.780335
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    date = datetime.date.today()
    description = "desc"
    source = "source"
    guid = makeguid()

    first_posting = Posting(JournalEntry(date, description, source, guid), datetime.date.today(), Account("acc", AccountType.ASSETS), Direction.INC, Amount(1))
    second_posting = Posting(JournalEntry(date, description, source, guid), datetime.date.today(), Account("acc", AccountType.ASSETS), Direction.INC, Amount(1))
    assert hash(first_posting) == hash(second_posting)
    assert first_posting == second_posting

# Generated at 2022-06-21 20:07:07.554938
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    jes = [JournalEntry('2019/01/01', 'description', 'source', [])]
    def f(period):
        return jes
    assert list(f('2019/01/01')) == jes

# Generated at 2022-06-21 20:07:17.110204
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from ..accounts.accounts import create_account
    from .journal_entries import test_JournalEntry___repr__
    import datetime
    from dataclasses import dataclass
    from typing import Dict, List, Set, TypeVar
    #: Defines a type variable.
    _T = TypeVar("_T")
    #: Provides the posting value object model.
    @dataclass(frozen=True)    
    class Posting(Generic[_T]):
        #: Journal entry the posting belongs to.
        journal: "JournalEntry[_T]"
        #: Date of posting.
        date: datetime.date
        #: Account of the posting.
        account: Account
        #: Direction of the posting.
        direction: Direction
        #: Posted amount (in absolute value).
        amount: Amount
        #:

# Generated at 2022-06-21 20:07:21.665381
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    date = datetime.date.today()
    description = "TestDescription"
    source = "TestSource"

    j = JournalEntry(date, description, source)

    assert j.date == date
    assert j.description == description
    assert j.source == source


# Generated at 2022-06-21 20:07:27.869895
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    d=date(2020,1,1)
    from .accounts import Account,AccountType
    account = Account(id=1,name='account1',type=AccountType.ASSETS,parent=None)
    from .journal import JournalEntry,Direction
    j = JournalEntry(date=d,description='my journal entry',source=1)
    post2 = Posting(j,d,account,'INC',3)
    post2.amount = 4
    assert post2.amount == 4

# Generated at 2022-06-21 20:07:29.396029
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass

# Generated at 2022-06-21 20:07:40.503396
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    j = JournalEntry(datetime.date.today(), "test", "test")
    p = Posting(j, datetime.date.today(), Account("", "", AccountType.EQUITIES), Direction.INC, Amount(1))
    try:
        p.amount = Amount(10)
        raise Exception("__setattr__ is not working!")
    except AttributeError:
        pass
    try:
        p.date = datetime.date.today()
        raise Exception("__setattr__ is not working!")
    except AttributeError:
        pass
    try:
        p.journal = j
        raise Exception("__setattr__ is not working!")
    except AttributeError:
        pass

# Generated at 2022-06-21 20:07:53.112826
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from ..commons.business import BusinessObject
    from .accounts import AccountManager

    manager = AccountManager()
    sales_account = manager.get_or_create(name="sales", type=AccountType.REVENUES)
    taxes_account = manager.get_or_create(name="tax", type=AccountType.EXPENSES)

    class Sale(BusinessObject):
        ...

    sale = Sale()


# Generated at 2022-06-21 20:08:01.464686
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journalEntry = JournalEntry[int](datetime.date(2020,1,1), 'description', 34)
    journalEntry = journalEntry.post(datetime.date(2020, 1, 1), Account('Assets'), Quantity(1))
    journalEntry = journalEntry.post(datetime.date(2020, 1, 1), Account('Revenues'), Quantity(-1))

    assert journalEntry.guid ==  Guid('2a')
    assert journalEntry.description == 'description'
    assert journalEntry.date == datetime.date(2020,1,1)
    assert journalEntry.source == 34

    assert journalEntry.postings[0].direction == Direction.INC
    assert journalEntry.postings[0].account.name == 'Assets'
    assert journalEntry.postings[0].amount == Amount(1)

    assert journalEntry.post

# Generated at 2022-06-21 20:08:02.032855
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-21 20:09:02.073237
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    class E:
        pass

    je = JournalEntry[E](datetime.date.today(), "description", E())
    je.post(je.date, Account("Assets", AccountType.ASSETS), 1000.50)
    je.post(je.date, Account("Expenses", AccountType.EXPENSES), -1000.50)

    je.validate()

    je = JournalEntry[E](datetime.date.today(), "description", E())
    je.post(je.date, Account("Assets", AccountType.ASSETS), 1000.50)
    je.post(je.date, Account("Expenses", AccountType.EXPENSES), -1000.49)

    try:
        je.validate()
    except:
        return True
    else:
        return False
    

# Generated at 2022-06-21 20:09:07.198149
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    journalEntry = JournalEntry("test")
    assert journalEntry.date == "test"
    assert journalEntry.description == ""
    assert journalEntry.source == None
    assert journalEntry.postings == []
    assert journalEntry.guid != None
    try:
        journalEntry.test = "test"
        assert False
    except AttributeError:
        assert True


# Generated at 2022-06-21 20:09:11.913799
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journal_entry = JournalEntry(date=datetime.date(1904, 5, 17), description="test")
    hash_1 = hash(journal_entry)
    journal_entry.postings.append(Posting(journal_entry, datetime.date(1904, 5, 17), Account("test", "test"), Direction.INC, Amount(1)))
    hash_2 = hash(journal_entry)
    assert hash_1 == hash_2


# Generated at 2022-06-21 20:09:19.205050
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal = JournalEntry(datetime.date(2017, 1, 1), "Test", None)
    posting = Posting(journal, datetime.date(2017, 1, 1), Account("Test", AccountType.EXPENSES), Direction.DEC, Amount(42))
    assert hash(posting) != hash(Posting(journal, datetime.date(2017, 1, 1), Account("Test", AccountType.EXPENSES), Direction.DEC, Amount(42)))

# Generated at 2022-06-21 20:09:24.137000
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    @dataclass
    class Source:
        id: str


    source = Source(id="source")
    entry = JournalEntry(datetime.date(2020, 1, 1), "description", source)

    # Check attributes are defined as expected
    assert entry.date == datetime.date(2020, 1, 1)
    assert entry.description == "description"
    assert entry.source == source
    assert entry.postings == []
    assert entry.guid.is_uuid()



# Generated at 2022-06-21 20:09:31.614498
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from datetime import date
    from ..accounts import Account as A
    from ..accounts.types import AccountType as AT
    from ..journal.model import JournalEntry as JE
    from ..journal.model import Posting as P
    SAMPLE_JE = JE(date(2019, 4, 1), "Sample journal entry", "Sample source", [])
    SAMPLE_JE.post(date(2019, 4, 1), A("cash", AT.ASSETS), 10)
    SAMPLE_JE.post(date(2019, 4, 1), A("cash", AT.ASSETS), -10)
    SAMPLE_JE.validate()

# Generated at 2022-06-21 20:09:35.805254
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    import datetime
    journal = JournalEntry(datetime.date.today(), "Coffee from Starbucks", "Test Journal", [])
    journal.post(datetime.date.today(), Account(AccountType.ASSETS, 1), 1000)
    journal.post(datetime.date.today(), Account(AccountType.REVENUES, 1), -1000)
    journal.validate()

# Generated at 2022-06-21 20:09:48.125853
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    # Setup
    posting_1 = Posting(
        date = datetime.date.today(),
        account = Account("Account"),
        direction = Direction.INC,
        amount = Amount(100),
        journal = JournalEntry(
            date = datetime.date.today(),
            description = "Journal Entry",
            source = "Journal Entry Source"
        )
    )
    posting_2 = Posting(
        date = datetime.date.today(),
        account = Account("Account"),
        direction = Direction.INC,
        amount = Amount(100),
        journal = JournalEntry(
            date = datetime.date.today(),
            description = "Journal Entry",
            source = "Journal Entry Source"
        )
    )

    # Execute
    posting_1_hash = posting_1.__hash__()
    posting_2

# Generated at 2022-06-21 20:09:59.293196
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    """Test for method __delattr__ of class JournalEntry"""
    from .accounts import AccountId
    from .business import Business
    from .busobjs import DebitMemo
    from .currencies import CurrencyId
    from .sets import Sets
    from .skus import SKUId
    from .units import UnitId
    from .warehouses import WarehouseId
    from ..commons.numbers import Qty
    from ..commons.strings import DocId
    from ..commons.zeitgeist import DateRange
    from ..configurations import get_config
    from ..txn import Txn
    from ..utils import MetaSingleton
    class Dependencies:
        config: get_config.Configurations
        txn: Txn
        sets: Sets
    deps = Dependencies()
    deps.config = get_config.Config

# Generated at 2022-06-21 20:10:07.167116
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class ReadJournalEntries():
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass
    
    assert(ReadJournalEntries.__doc__ == 'Type of functions which read journal entries from a source.')
    assert(ReadJournalEntries.__call__.__doc__ == 'Type of functions which read journal entries from a source.')

if __name__ == "__main__":
    test_ReadJournalEntries()