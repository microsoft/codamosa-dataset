

# Generated at 2022-06-21 20:01:19.517014
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    journal = JournalEntry[str]("0000-00-00","description","source")

    assert journal.postings == []

    journal.post("0000-00-00",Account("name","type"),1)

    assert journal.postings == [Posting(journal,datetime.date(1,1,1),Account("name","type"),Direction.INC,Amount(1))]

    # del journal.postings

    # assert journal.postings == []

# Generated at 2022-06-21 20:01:28.102310
# Unit test for constructor of class Posting
def test_Posting():
    print("test_Posting...")
    journal_entry_test = JournalEntry()
    account_test = Account(Guid(), "Account_Test", AccountType.ASSETS)
    debit_posting = Posting(journal_entry_test, "2020-01-01", account_test, Direction.INC, 1)
    assert debit_posting.is_debit, "First Posting is a debit"
    assert not debit_posting.is_credit, "First Posting is not a credit"
    credit_posting = Posting(journal_entry_test, "2020-01-01", account_test, Direction.DEC, 1)
    assert not credit_posting.is_debit, "Second Posting is not a debit"
    assert credit_posting.is_credit, "Second Posting is a credit"



# Generated at 2022-06-21 20:01:39.947330
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    j: JournalEntry[str] = JournalEntry("date", "description", "source")
    p: Posting[str] = Posting(j, "date", "account", "direction", "amount")
    # Posting is frozen, no mutation is allowed at the runtime.
    with pytest.raises(AttributeError):
        p.date = "today"
    with pytest.raises(AttributeError):
        p.account = "account"
    with pytest.raises(AttributeError):
        p.direction = "direction"
    with pytest.raises(AttributeError):
        p.amount = "amount"
    # Posting is generic, no type check is done at the runtime.
    p = Posting(j, "date", "account", "direction", "amount")
    # (TODO) Implement unit test for method Journal

# Generated at 2022-06-21 20:01:41.335388
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert "Posting" in repr(Posting(None, None, None, None, None))

# Generated at 2022-06-21 20:01:45.643778
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    a = JournalEntry(datetime.date(2020, 1, 1), "description_1", "source_1")
    b = JournalEntry(datetime.date(2020, 1, 1), "description_1", "source_1")
    assert a == b

# Generated at 2022-06-21 20:01:57.488941
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    DateRange = pytest.importorskip("dataclasses_jsonschema.typing.DateRange")
    from dataclasses_jsonschema.typing import DateTime

    @dataclass(frozen=True)
    class Person:
        name: str

    @dataclass(frozen=True)
    class JournalEntry:
        date: DateTime
        description: str
        source: Person
        postings: List[Posting] = field(default_factory=list, init=False)

    @dataclass(frozen=True)
    class Posting:
        date: DateTime
        account: str
        direction: str
        amount: int

    @dataclass(frozen=True)
    class Model:
        person: str
        journal_entry: JournalEntry


# Generated at 2022-06-21 20:02:05.524792
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Create objects for test
    test_journal_1 = JournalEntry(datetime.date(2010, 1, 2), 'test description 1', 'test source 1')
    test_journal_1.post(datetime.date(2010, 1, 1), Account('test account 1', 'expense'), 1)
    test_journal_2 = JournalEntry(datetime.date(2010, 1, 2), 'test description 1', 'test source 1')
    test_journal_2.post(datetime.date(2010, 1, 1), Account('test account 1', 'expense'), 1)
    test_journal_3 = JournalEntry(datetime.date(2010, 1, 2), 'test description 1', 'test source 2')

# Generated at 2022-06-21 20:02:10.433408
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # Given
    testobj = JournalEntry(None, None, None)
    # When
    actual = Posting(testobj, None, None, None, None).__repr__()
    # Then
    assert actual == "Posting(journal=None, date=None, account=None, direction=None, amount=None)"

# Generated at 2022-06-21 20:02:21.565933
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journal = JournalEntry("1", "2", "3")
    assert journal is not None, "journal is None"
    journal.post(datetime.date.today(), Account("1", "2", "3"), Quantity(1))
    journal.post(datetime.date.today(), Account("4", "5", "6"), Quantity(2))
    journal2 = JournalEntry("1", "2", "3")
    assert journal2 is not None, "journal2 is None"
    journal2.post(datetime.date.today(), Account("1", "2", "3"), Quantity(1))
    journal2.post(datetime.date.today(), Account("4", "5", "6"), Quantity(2))
    assert journal == journal2, f"journal == journal2: {journal} != {journal2}"

# Generated at 2022-06-21 20:02:32.973073
# Unit test for method __eq__ of class JournalEntry

# Generated at 2022-06-21 20:02:43.519485
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def f(period: DateRange) -> Iterable[JournalEntry[None]]:
        yield JournalEntry(datetime.date.today(), "Test", None)
    f.__name__ = 'ReadJournalEntries'
    assert list(f(DateRange()))
    assert len(list(f(DateRange()))) == 1
    return

# Generated at 2022-06-21 20:02:50.657702
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(journal=JournalEntry(date=datetime.date(year=2019, month=1, day=1), description="", source=None),
                   date=datetime.date(year=2019, month=1, day=1), account=Account(account_type=AccountType.ASSETS,
                                                                                  account_code="1000"),
                   direction=Direction.INC, amount=Amount(100)) == Posting(
        journal=JournalEntry(date=datetime.date(year=2019, month=1, day=1), description="", source=None),
        date=datetime.date(year=2019, month=1, day=1), account=Account(account_type=AccountType.ASSETS,
                                                                       account_code="1000"),
        direction=Direction.INC, amount=Amount(100))


#

# Generated at 2022-06-21 20:02:50.994164
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    pass

# Generated at 2022-06-21 20:03:00.022721
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from ..commons.datetimes import DATE_2019_07_01, DATE_2019_07_02, DATE_2019_07_10

    # Set up data
    journal_entry: JournalEntry[str] = JournalEntry(DATE_2019_07_01, "Description", "Some Object")
    posting: Posting[str] = Posting(journal_entry, DATE_2019_07_02, Account("Account", AccountType.ASSETS), Direction.DEC,
                                    Amount(100))

    # Act
    posting.date = DATE_2019_07_10

# Generated at 2022-06-21 20:03:08.990512
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    _test = Posting(JournalEntry(datetime.date(2013, 1, 26), "journal_1", None), datetime.date(2013, 1, 26), Account(
        "account_1", AccountType.ASSETS), Direction.DEC, Amount(-1)
        )
    _test_1 = Posting(JournalEntry(datetime.date(2013, 1, 26), "journal_1", None), datetime.date(2013, 1, 26), Account(
        "account_1", AccountType.ASSETS), Direction.DEC, Amount(-1)
        )
    assert _test == _test_1



# Generated at 2022-06-21 20:03:16.530040
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal = JournalEntry(datetime.date(2019, 1, 2), "First Entry", "Test", [])
    journal.post(datetime.date(2019, 1, 2), Account("Assets", "Cash", AccountType.ASSETS), Quantity(100))
    journal.post(datetime.date(2019, 1, 2), Account("Expenses", "Travel", AccountType.EXPENSES), Quantity(-100))

    journal.validate()
    assert True

# Generated at 2022-06-21 20:03:28.936014
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journalentry1 = JournalEntry(date="2020-01-10",description="description1",source="source1")
    journalentry2 = JournalEntry(date="2020-01-10",description="description1",source="source1")
    journalentry3 = JournalEntry(date="2020-01-11",description="description1",source="source1")
    journalentry4 = JournalEntry(date="2020-01-10",description="description2",source="source1")
    journalentry5 = JournalEntry(date="2020-01-10",description="description1",source="source2")
    journalentry6 = JournalEntry(date="2020-01-10",description="description1",source="source1")
    assert journalentry1 == journalentry2
    assert journalentry1 != journalentry3
    assert journalentry1 != journalentry4
    assert journalentry1 != journal

# Generated at 2022-06-21 20:03:39.234971
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import asdict
    from datetime import date
    from faker import Faker
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import Guid
    from ..ledgers.accounts import Account, AccountType

    from .journal import JournalEntry, Posting, ReadJournalEntries
    from .payments import get_payment_type_model_factory, Payment

    fake = Faker()
    fake.seed(0)

    payment_type_model_factory = get_payment_type_model_factory(payment_type_name="PaymentTypeA")

    @dataclass(frozen=True)
    class EntityA:
        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid, init=False)

        #

# Generated at 2022-06-21 20:03:42.348512
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    print("=== test_Posting___delattr__() ===")
    # TODO
    pass



# Generated at 2022-06-21 20:03:52.570319
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account, AccountType
    from .costs import Cost
    CostType = Cost
    year2020 = datetime.datetime(2020, 1, 1)
    year2021 = datetime.datetime(2021, 1, 1)
    entry = JournalEntry[CostType](year2020, "Test Posting", CostType.rent)
    account = Account[AccountType]('account', AccountType.ASSETS)
    posting = Posting[CostType](entry, year2020, account, Direction.INC, Amount(10))
    assert posting.journal == entry
    assert posting.date == year2020
    assert posting.account == account
    assert posting.direction == Direction.INC
    assert posting.amount == Amount(10)


# Generated at 2022-06-21 20:03:59.530920
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    
    ## Create a journal entry:
    je = JournalEntry[str]("2019-01-01", "Test Journal Entry", "Test Source Object")
    assert not hasattr(je, "description")
    assert not hasattr(je, "date")
    assert not hasattr(je, "source")


# Generated at 2022-06-21 20:04:04.165544
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from dataclasses import dataclass
    from unittest.case import TestCase
    test_case: TestCase = TestCase()

    @dataclass(frozen=True)
    class BizObj:
        val: int

    with test_case.assertRaises(AttributeError):
        JournalEntry(bizobj = BizObj(10))

# Generated at 2022-06-21 20:04:15.687544
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from .accounts import Account
    from .currencies import Currency

    assert hash(Posting({}, datetime.date(2019, 1, 1), Account("A", "A", AccountType.ASSETS), Direction.INC, 100))

    a = Account("A", "A", AccountType.ASSETS)
    a2 = Account("A", "A", AccountType.ASSETS)
    assert hash(Posting({}, datetime.date(2019, 1, 1), a, Direction.INC, 100)) == hash(
        Posting({}, datetime.date(2019, 1, 1), a2, Direction.INC, 100))

    # Test with currency objects
    assert hash(Posting({}, datetime.date(2019, 1, 1), Account("A", "A", AccountType.ASSETS), Direction.INC, 100, Currency()))


# Generated at 2022-06-21 20:04:27.716758
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    now = datetime.date.today()
    journal = JournalEntry(now, 'test', 'Source')
    posting = Posting(journal, now, Account('Assets', AccountType.ASSETS), Direction.INC, Amount(1))

# Generated at 2022-06-21 20:04:35.321065
# Unit test for constructor of class Posting
def test_Posting():
    account = Account("1", "Account One", AccountType.ASSETS)
    entry = JournalEntry(datetime.date.today(), "Entry #1", 10)
    debit = Posting(entry, datetime.date.today(), account, Direction.INC, Amount(12))
    assert debit.journal == entry
    assert debit.account == account
    assert debit.direction == Direction.INC
    assert debit.amount == Amount(12)
    assert debit.is_debit
    assert not debit.is_credit


# Generated at 2022-06-21 20:04:42.628934
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p1 = Posting(None, datetime.date.today(), None, None, Amount(0))
    p2 = Posting(None, datetime.date.today(), None, None, Amount(0))
    p3 = Posting(None, datetime.date.today(), None, Direction.INC, Amount(0))
    p4 = Posting(None, datetime.date.today(), None, Direction.DEC, Amount(0))
    assert len({p1, p2, p3, p4}) == 3

# Generated at 2022-06-21 20:04:50.031837
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    je = JournalEntry(
        date = datetime.date(2020, 8, 31),
        description = "Provision",
        source = None,
        )
    je.post(
        date = datetime.date(2020, 8, 31),
        account = Account(type = AccountType.REVENUES, code = "9124", name = "Salary Services"),
        quantity = -1*1000,
        )
    je.post(
        date = datetime.date(2020, 8, 31),
        account = Account(type = AccountType.EXPENSES, code = "6261", name = "Salaries and Wages"),
        quantity = +1000,
        )

# Generated at 2022-06-21 20:04:56.931214
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # Construct a JournalEntry instance
    JournalEntry = JournalEntry()
    assert JournalEntry.date == None, "Assertion failed."
    assert JournalEntry.description == None, "Assertion failed."
    assert JournalEntry.source == None, "Assertion failed."
    assert JournalEntry.postings == [], "Assertion failed."
    assert JournalEntry.guid != None, "Assertion failed."
    pass


# Generated at 2022-06-21 20:05:01.468987
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    try:
        j = JournalEntry[str]('2018-02-25', 'test journal entry', 'test journal entry', [])
        j.date = '2018-02-25'
    except Exception as e:
        print(e)

# Generated at 2022-06-21 20:05:02.790915
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    a = 1
    b = 2
    assert a == b

# Generated at 2022-06-21 20:05:17.448701
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    @dataclass
    class MockSource:
        pass
    mock_source = MockSource()
    journal_entry = JournalEntry(mock_source, "Entry 1", datetime.date(2020, 1, 1))
    assert hash(journal_entry) == hash(("Entry 1", datetime.date(2020, 1, 1), mock_source))


# Generated at 2022-06-21 20:05:25.678922
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .accounting import Ledger
    from .transactions import Transaction

    startdate = datetime.date(2020, 1, 1)
    enddate   = datetime.date(2020, 1, 31)

    ledger = Ledger().load("data/ledger-test.json")

    #: an initial sales invoice
    tr1 = Transaction("Sale", "Sale of goods").post("2020-01-02",
                                                   ledger.Account("Assets:Trade Debtors", AccountType.ASSETS),
                                                   "100.00")
    #: a purchase invoice

# Generated at 2022-06-21 20:05:28.140322
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    dummy_journal_entry = JournalEntry("dummy", "dummy", ["dummy"],["dummy"])
    dummy_post = dummy_journal_entry.post("dummy", "dummy", "dummy")
    assert dummy_post

# Generated at 2022-06-21 20:05:33.457739
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from ..entities.accounts.accounts import AccountType
    # Create journal entry, assuming date as date_1, description as description_1, source as source_1 and guid as guid_1
    journal_entry = JournalEntry(date = datetime.date.today(), description = "description_1", source = "source_1")

    # Test if method __repr__ returns the description of journal entry
    assert journal_entry.__repr__() == journal_entry.description

# Generated at 2022-06-21 20:05:42.945765
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Cash
    date = datetime.date.today()
    journal = JournalEntry(date, 'test', 'test')
    assert len(journal.postings) == 0
    journal.post(date, Cash.ASSETS, 100)
    assert len(journal.postings) == 1
    assert journal.postings[0].account.name == 'Cash'
    journal.post(date, Cash.ASSETS, -50)
    assert len(journal.postings) == 2
    assert journal.postings[1].account.name == 'Cash'
    journal.post(date, Cash.ASSETS, 0)
    assert len(journal.postings) == 2
    journal.validate()

# Generated at 2022-06-21 20:05:48.270786
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from ..commons.others import equals
    from .accounts import Account, AccountType

    @equals
    def post(account: AccountType, amount: float) -> JournalEntry[str]:
        return JournalEntry(
            date=datetime.date(2020, 1, 1),
            description="Sample",
            source="Sample"
        ).post(datetime.date(2020, 1, 1), Account("", account), amount)

    assert delattr(post(AccountType.ASSETS, 1), "postings")
    assert delattr(post(AccountType.ASSETS, 1), "postings")
    assert delattr(post(AccountType.EQUITIES, 1), "postings")
    assert delattr(post(AccountType.EQUITIES, 1), "postings")

# Generated at 2022-06-21 20:05:49.602471
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():  # pylint: disable=invalid-name
    pass


# Generated at 2022-06-21 20:06:01.729083
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Tests the __call__ method of the ReadJournalEntries protocol class.
    """
    from datetime import datetime, timedelta

    class Foo:
        pass

    entry = JournalEntry[Foo]()
    entry.date = datetime(2019, 1, 1)
    entry.source = Foo()

    def read_entries(start_date: datetime, end_date: datetime) -> Iterable[JournalEntry[Foo]]:
        if start_date <= entry.date <= end_date:
            return [entry]
        return []

    result = ReadJournalEntries.__call__(read_entries, DateRange(datetime.now(), datetime.now() + timedelta(days=1)))
    assert len(result) == 1

# Generated at 2022-06-21 20:06:11.693442
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    ev1 = JournalEntry(object())
    ev2 = JournalEntry(object())
    assert ev1 != ev2
    ev1.post(1, Account("ASSETS:BANK:CASH"), Amount(100))
    ev2.post(1, Account("ASSETS:BANK:CASH"), Amount(100))
    assert ev1 != ev2
    ev3 = JournalEntry(object())
    ev3.post(1, Account("ASSETS:BANK:CASH"), Amount(100))
    assert ev1 == ev3

if __name__ == '__main__':
    test_JournalEntry___eq__()

# Generated at 2022-06-21 20:06:16.003573
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry("1")
    je.post("1", "a", 1)
    assert len(je.postings) == 1
    assert abs(je.postings[0].amount.value) == 1
    assert je.postings[0].direction == Direction.INC
    assert je.postings[0].account == "a"
    assert je.postings[0].date == "1"

# Generated at 2022-06-21 20:06:44.645038
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():

    from ..commons.accounts import Account, AccountType

    journal=JournalEntry[int](date=datetime.date(2020,3,1),description="Entry for testing",source=42)
    assert journal.date==datetime.date(2020,3,1)
    assert journal.description=="Entry for testing"
    assert journal.source==42
    assert journal.postings==[]

    journal.post(date=datetime.date(2020,2,27),account=Account(name="Bank",description="Current bank account",type=AccountType.ASSETS),quantity=10)
    assert len(journal.postings)==1
    assert journal.postings[0].journal==journal
    assert journal.postings[0].date==datetime.date(2020,2,27)
    assert journal.postings[0].account==Account

# Generated at 2022-06-21 20:06:49.351516
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class SomeJournalReads:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    rje: ReadJournalEntries[_T] = SomeJournalReads()

    assert rje is not None

# Generated at 2022-06-21 20:06:56.086036
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    entry1 = JournalEntry(datetime.date(2020, 1, 1), "", None)
    entry1.post(datetime.date(2020, 1, 1), Account("101", AccountType.ASSETS), Quantity(100))
    entry1.post(datetime.date(2020, 1, 1), Account("201", AccountType.REVENUES), Quantity(-100))
    assert len(entry1.postings) == 2

    entry1.validate()
    print("Passed")

# Generated at 2022-06-21 20:07:00.716105
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    j1 = JournalEntry(
        date=datetime.date(2017, 1, 1),
        description='Description',
        source=None,
        postings=[]
    )
    j2 = JournalEntry(
        date=datetime.date(2017, 1, 1),
        description='Description',
        source=None,
        postings=[]
    )
    assert hash(j1) == hash(j2)

# Generated at 2022-06-21 20:07:10.528900
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .objects import AccountObject

    journal = JournalEntry[AccountObject](datetime.date(2020, 12, 31), "Journal Entry", AccountObject(Account(
        4, AccountType.EXPENSES, "Expenses"
    )))
    journal.post(datetime.date(2020, 12, 31), Account(1, AccountType.ASSETS, "Assets"), -10)
    journal.post(datetime.date(2020, 12, 31), Account(20, AccountType.EQUITIES, "Equities"), 10)


# Generated at 2022-06-21 20:07:16.329955
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    test_JournalEntry = JournalEntry(datetime.date(2019,11,20))
    test_JournalEntry.post(datetime.date(2019,11,20), "Current Assets:Cash", -100)
    assert(test_JournalEntry.postings[0].account == "Current Assets:Cash")
    assert(test_JournalEntry.postings[0].amount == 100)
    assert(test_JournalEntry.postings[0].direction == Direction.DEC)


# Generated at 2022-06-21 20:07:16.883347
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert True

# Generated at 2022-06-21 20:07:27.434147
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    class Test:
        def __init__(self, guid: Guid):
            self.guid = guid

    p1 = Posting(Test(Guid('1')), datetime.date(2019, 2, 1), Account.of('Assets', 'Cash'), Direction.INC, Amount(10))
    p2 = Posting(Test(Guid('1')), datetime.date(2019, 2, 1), Account.of('Assets', 'Cash'), Direction.INC, Amount(10))
    p3 = Posting(Test(Guid('2')), datetime.date(2019, 2, 1), Account.of('Assets', 'Cash'), Direction.INC, Amount(10))
    assert p1 is not p2
    assert p1 == p2
    assert p1 != p3
    assert p2 != p3

# Generated at 2022-06-21 20:07:32.223461
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    @dataclass(repr=False)
    class Test:
        x: int

    je = JournalEntry[Test]
    je.postings = []
    assert len(je.postings) == 0



# Generated at 2022-06-21 20:07:41.598352
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Imports
    from dataclasses import dataclass, field
    from datetime import date
    from datetime import datetime
    from datetime import timezone
    from datetime import timedelta
    from typing import List
    from typing import Set

    # Imports for methods under test
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType, Classification
    from .values import Direction, JournalEntry, Posting

    # Helper to create a journal entry:
    def create_journal_entry():
        # Create the journal activity (for the `source` field):
        @dataclass
        class DummyJournalActivity(Generic[_T]):
            #: The journal activity ID.
            id: str = field(repr=False, hash=False, compare=False)

        # Create the journal entry:

# Generated at 2022-06-21 20:08:28.931667
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    p = Posting(JournalEntry(datetime.date(2020, 1, 1), "", None), datetime.date(2020, 1, 1), Account("A1"), Direction.INC, Amount(10))
    
    assert repr(p) == "Posting(journal=JournalEntry(date=datetime.date(2020, 1, 1), description='', source=None), date=datetime.date(2020, 1, 1), account=Account(code='A1', name='', type=<AccountType.ASSETS: 1>), direction=<Direction.INC: 1>, amount=Amount(10))"


# Generated at 2022-06-21 20:08:35.755679
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from types import MethodType
    import datetime

    class SomeDummyClass(object):
        pass

    def some_func(period:DateRange):
        yield JournalEntry[SomeDummyClass](datetime.date(2019, 1, 1), "some description", SomeDummyClass(), [])
    
    bound_method = MethodType(some_func, None)
    assert ReadJournalEntries.__instancecheck__(bound_method)



# Generated at 2022-06-21 20:08:36.365684
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-21 20:08:42.523047
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    date = datetime.date(2020, 1, 1)
    description = "test"
    source = "test"
    journal = JournalEntry(date, description, source)
    # journal.postings
    # journal.guid
    assert journal.date == date, journal.date
    assert journal.description == description, journal.description
    assert journal.source == source, journal.source

    # journal.postings doesn't raise AttributeError
    try:
        journal.postings
    except AttributeError:
        assert False, "AttributeError is raised"

    # journal.guid doesn't raise AttributeError
    try:
        journal.guid
    except AttributeError:
        assert False, "AttributeError is raised"


# Generated at 2022-06-21 20:08:48.744138
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    # Test a posting
    Test_JournalEntry = JournalEntry()
    Test_Posting = Posting(Test_JournalEntry, 1, 2, 3, 4)
    Test_Posting_Hash = Test_Posting.__hash__()
    # Check the value
    assert Test_Posting_Hash == Test_JournalEntry.__hash__() + 1 + 2 + 3 + 4, "Hash of posting is incorrect"


# Generated at 2022-06-21 20:08:51.382699
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert 1 == 1

# Generated at 2022-06-21 20:09:02.620595
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from ledger.commons.amount import Amount
    from ledger.commons.dateutils import Date
    from ledger.accounts import Account, AccountType
    from ledger.journal.posting import Direction, Posting
    from ledger.journal.journal_entry import JournalEntry

    a1 = Account("a1", AccountType.ASSETS)
    b1 = Account("b1", AccountType.EXPENSES)
    c1 = Account("c1", AccountType.EQUITIES)
    d1 = Account("d1", AccountType.REVENUES)
    e1 = Account("e1", AccountType.LIABILITIES)
    f1 = Account("f1", AccountType.OTHER)

    p1 = Posting("journal", Date(2019, 1, 1), a1, Direction.INC, Amount(1))

# Generated at 2022-06-21 20:09:09.517105
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    account_liabilities_ledger = Account(code="LIABILITIES:LEDGER", name="Liabilities:Ledger")
    account_liabilities_ledger.assign_type(AccountType.LIABILITIES)
    j = JournalEntry(datetime.date.today(), "Test", None)
    # Act
    j.post(datetime.date.today(), account_liabilities_ledger, Quantity(100))
    result = j.postings[0].is_debit
    # Assert
    assert result == True

# Generated at 2022-06-21 20:09:16.878018
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
        value = 4
        Posting(
            journal=JournalEntry(
                date=value,
                description=value,
                source=value,
            ),
            date=value,
            account=Account(
                guid=value,
                name=value,
                parent=value,
                category=value,
                type=value,
            ),
            direction=value,
            amount=value,
        )

# Generated at 2022-06-21 20:09:21.531782
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry[int](datetime.date.today(), "test_journal", 0)
    journalentry = Posting[int](journal, datetime.date.today(), Account(1, "test_account", AccountType.ASSETS), Direction.INC, Amount(1))
    assert str(journalentry) == 'Posting[1, test_account, 1.00]'

# Generated at 2022-06-21 20:10:49.259557
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    import datetime
    date = datetime.date(2020, 2, 29)
    account = Account(AccountType.ASSETS, "Cash")
    description = "Payment for services."
    direction = Direction.INC
    amount = Amount(100)
    source = 'JournalEntry'
    posting = Posting(source, date, account, direction, amount)

    # Test
    assert repr(posting) == "Posting(source={}, date={}, account={}, direction={}, amount={})".format(source, date, account, direction, amount)


# Generated at 2022-06-21 20:10:59.506649
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import Account
    from .chart import Chart
    from .currency import Currency

    chart = Chart(Currency("USD", "United States Dollar"))
    chart.open("Cash", AccountType.ASSETS)
    chart.open("Equity", AccountType.EQUITIES)

    journal_entry = JournalEntry[None](datetime.date(2020, 8, 8), "Hello", None)
    journal_entry \
        .post(datetime.date(2020, 8, 1), chart["Cash"], Quantity(10.00)) \
        .post(datetime.date(2020, 8, 1), chart["Equity"], Quantity(-10.00))

# Generated at 2022-06-21 20:11:09.528470
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    j1 = JournalEntry[int](date=datetime.date(2017, 8, 1), description="T1", source=123)
    j1.post(datetime.date(2017, 8, 1), "A", +100)
    j1.post(datetime.date(2017, 8, 1), "B", -100)

    j2 = JournalEntry[int](date=datetime.date(2017, 8, 1), description="T1", source=123)
    j2.post(datetime.date(2017, 8, 1), "A", +100)
    j2.post(datetime.date(2017, 8, 1), "B", -100)

    j3 = JournalEntry[int](date=datetime.date(2017, 8, 1), description="T1", source=123)