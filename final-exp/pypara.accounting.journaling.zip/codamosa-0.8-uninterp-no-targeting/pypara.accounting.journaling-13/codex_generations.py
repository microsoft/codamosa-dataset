

# Generated at 2022-06-21 20:01:20.960449
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    account : Account = Account('0001', AccountType.EQUITIES ,'Equity')
    j : JournalEntry = JournalEntry(date=datetime.date.today(), source=None, description='Test')
    posting = Posting(journal=j, date=datetime.date.today(), account=account, direction=Direction.INC, amount=Amount(10))
    p = hash(posting)
    assert p == -1563436017, f"Incorrect hash value."


# Generated at 2022-06-21 20:01:27.876563
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry(datetime.date(2020, 1, 1), "dummy entry", "dummy object", [])

    # Posting an amount to an account
    je.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, 201, "Cash"), Amount(10))

    # Entries should contain 1 posting
    assert len(je.postings) == 1

    # Posting a 0 amount should do nothing
    je.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, 201, "Cash"), 0)

    # Entries should contain 1 posting
    assert len(je.postings) == 1

# Generated at 2022-06-21 20:01:31.515370
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class Target(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return []
    pass  # TODO: Implement unit test.



# Generated at 2022-06-21 20:01:33.126734
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    pass


# Generated at 2022-06-21 20:01:33.750391
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-21 20:01:39.051025
# Unit test for constructor of class Posting
def test_Posting():
    assert Posting[int](1, datetime.date(1, 1, 1))
    assert Posting[int](1, datetime.date(1, 1, 1), 3)
    assert Posting[int](1, datetime.date(1, 1, 1), 3, 2)
    assert Posting[int](1, datetime.date(1, 1, 1), 3, 2, 5)


# Generated at 2022-06-21 20:01:45.642450
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    JE1 = JournalEntry(
        date=datetime.date(2018, 2, 24),
        description="new",
        source="NULL"
        )
    print(JE1)
    print(JE1.postings)
    print(JE1.date)
    print(JE1.description)
    print(JE1.source)
    print(JE1.guid)
#Unit test for input of class JournalEntry

# Generated at 2022-06-21 20:01:55.531258
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class JournalEntryDateMock:
        def __init__(self, date):
            self.date = date
    
    class JournalEntryMock(_T):
        def __init__(self, date):
            self.date = date
            self.description = "test"
    
    def read_journal_entry(period) -> Iterable[JournalEntry[_T]]:
        journal_entry = JournalEntryMock(JournalEntryDateMock(period.start))
        assert journal_entry.description == "test"
        assert journal_entry.date.date == period.start
        return [journal_entry]

    test_ReadJournalEntries.read_journal_entry = read_journal_entry


# Generated at 2022-06-21 20:02:00.277626
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    class Source:
        pass

    j1 = JournalEntry(datetime.date(2019, 8, 19), "D1", Source())
    j2 = JournalEntry(datetime.date(2019, 8, 19), "D1", Source())
    assert hash(j1) == hash(j2)

# Generated at 2022-06-21 20:02:04.538133
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from .currencies import Currency, CurrencyUnit

    date = datetime.date.today()
    source = "Earned commission."
    postings = list(Posting(date, Account.of("Revenues:Commissions"), Direction.INC, Amount(1, Currency(CurrencyUnit.EUR))),
                   Posting(date, Account.of("Expenses:Commissions"), Direction.DEC, Amount(1, Currency(CurrencyUnit.EUR))))
    journal = JournalEntry(date, source, postings)
    journal.validate()
    delattr(journal, "postings")
    journal.validate()

# Generated at 2022-06-21 20:02:23.267071
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from datetime import date
    from ..accounting.library.currencies import Currencies
    from ..accounting.library.accounts import Accounts
    accounts = Accounts()
    currency = Currencies.USD
    journalEntry = JournalEntry[int](
        date(2020, 1, 5),
        "Test description",
        1,
    )
    journalEntry.post(date(2020, 1, 5), accounts.asset["Cash"][currency], 100)
    journalEntry.post(date(2020, 1, 5), accounts.revenue["Service Revenue"][currency], -100)
    journalEntry.validate()

    journalEntry = JournalEntry[int](
        date(2020, 1, 5),
        "Test description",
        1,
    )

# Generated at 2022-06-21 20:02:33.291957
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    earlier = datetime.date(2019, 1, 1)
    later = datetime.date(2019, 1, 2)

    source = Account(AccountType.ASSETS, "Bank")
    destination = Account(AccountType.ASSETS, "Cash")

    entry = JournalEntry(date=later, description="From Bank to Cash", source=source)
    entry.post(later, source, -10000)
    entry.post(later, destination, 10000)

    total_debit = isum(i.amount for i in entry.debits)
    total_credit = isum(i.amount for i in entry.credits)

    print(f"Amount: {total_debit}, {total_credit}\n")
    assert total_debit == total_credit

# Generated at 2022-06-21 20:02:36.276839
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def read_journals(period: DateRange) -> Iterable[JournalEntry[str]]:
        pass

    read_journal_entries: ReadJournalEntries[str] = read_journals

# Generated at 2022-06-21 20:02:42.193641
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    entry = JournalEntry(datetime.date(2021, 1, 1), "dummy description", 'dummy source')
    posting = Posting(entry, datetime.date(2021, 1, 1), "dummy account", Direction.INC, Amount.ONE)

    assert repr(posting) == 'Posting(date=2021-01-01, account=dummy account, direction=INC, amount=1)'


# Generated at 2022-06-21 20:02:48.583544
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from datetime import date
    from .accounts import Account, AccountType

    with open("account/accounts.json","r") as account:
        with open("account/journal.json","r") as journal:
            with open("account/transactions.json","r") as transaction:

                accounts_input=account.read()
                journals_input=journal.read()
                transactions_input=transaction.read()

                account=Account(accounts_input)
                journal=JournalEntry(journals_input)
                transaction=Transaction(transactions_input)

    journal.validate()
    return "Passed"

# Generated at 2022-06-21 20:03:01.018216
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType
    from .businessobjects import Person, Party, Transaction

    max = Person(name="Max")
    kreditanstalt = Party(name="Oesterreichische Kreditanstalt")
    payment = Transaction(description="Dividend payment of previous year")
    je = JournalEntry(date=datetime.date(2000, 1, 1), description="Dividend payment of previous year")
    je.post(date=datetime.date(2000, 1, 1), account=Account(type=AccountType.REVENUES, name="Dividends revenue"), quantity=+1)
    je.post(date=datetime.date(2000, 1, 1), account=Account(type=AccountType.ASSETS, name="Cash"), quantity=-1)
    print(je)


# Generated at 2022-06-21 20:03:11.437810
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    journal = JournalEntry(datetime.date(2019, 12, 31), "Test", None)
    posting1 = Posting(journal, datetime.date(2019, 12, 31), Account(AccountType.REVENUES, "Sales"), Direction.INC, 10)
    posting2 = Posting(journal, datetime.date(2019, 12, 31), Account(AccountType.REVENUES, "Sales"), Direction.INC, 10)
    posting3 = Posting(journal, datetime.date(2019, 12, 31), Account(AccountType.REVENUES, "Sales"), Direction.DEC, 10)
    posting4 = Posting(journal, datetime.date(2019, 12, 31), Account(AccountType.EXPENSES, "Sales"), Direction.INC, 10)

    assert posting1 == posting2
    assert posting1 != posting3
    assert posting1

# Generated at 2022-06-21 20:03:12.516644
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert False

# Generated at 2022-06-21 20:03:18.527680
# Unit test for constructor of class Posting
def test_Posting():
    account = Account("Dummy", 1001, AccountType.ASSETS, "A dummy account")
    posting = Posting(journal=None, date=datetime.date(2018, 9, 1), account=account, direction=Direction.INC, amount=Amount(100))
    assert posting.account == account
    assert posting.amount == Amount(100)


# Generated at 2022-06-21 20:03:31.059978
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .journaling import JournalEntry
    from .commons.numbers import Quantity

    # TEST 1: Tests for debit-credit mismatch.
    j1 = JournalEntry(date=datetime.date(2020, 1, 1), description="Testing Journal Entry")
    j1.post(datetime.date(2020, 1, 1), Account(123, AccountType.ASSETS, "Assets", "Cash", "Cash"), Quantity(100))
    j1.post(datetime.date(2020, 1, 1), Account(124, AccountType.EXPENSES, "Expenses", "Fuel", "Fuel Expenses"), Quantity(-100))


# Generated at 2022-06-21 20:03:44.440495
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    pass


# Generated at 2022-06-21 20:03:54.911140
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account, AccountType
    from .books import LedgerBook
    from .exceptions import InvalidBusinessObjectError
    from .journal import post_gl_transaction
    from .transactions import Transaction

    class TestSource(Transaction):
        """
        Test source: dummy business object
        """

        def __init__(self):
            pass

    class TestTarget(Transaction):
        """
        Test target: dummy business object
        """

        def __init__(self):
            pass

    abc = TestSource()
    defg = TestTarget()

    a = Account("Assets", AccountType.ASSETS, balance_type=Account.BalanceType.DEBIT)
    r = Account("Revenues", AccountType.REVENUES, balance_type=Account.BalanceType.CREDIT)

    #: Create a journal entry from

# Generated at 2022-06-21 20:03:56.098745
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass


# Generated at 2022-06-21 20:04:00.799750
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # given
    journal = JournalEntry(datetime.date.today(), "test", None)

    # when
    with journal.post(datetime.date.today(), Account.ASSETS, Quantity(10)):
        pass

    # then
    assert len(journal.postings) == 1

# Generated at 2022-06-21 20:04:05.006283
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    source = "test source"
    date = datetime.date(2020, 1, 1)
    description = "test description"
    journal_entry = JournalEntry(source, date, description)
    assert journal_entry.source == source
    assert journal_entry.date == date
    assert journal_entry.description == description

# Generated at 2022-06-21 20:04:10.167888
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    p1 = Posting(1, 2, 3, 4, 5)
    assert p1.journal == 1
    assert p1.date == 2
    assert p1.account == 3
    assert p1.direction == 4
    assert p1.amount == 5


# Generated at 2022-06-21 20:04:19.545714
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    import unittest
    from expense_manager.accounting.models import Account, AccountType
    from expense_manager.accounting.models import JournalEntry
    from expense_manager.accounting.models import Posting
    from expense_manager.commons.numbers import Amount, Quantity

    @dataclass(frozen=True)
    class _Source:
        a: str

    class _Tests(unittest.TestCase):
        def test_post(self) -> None:
            asset_cash = Account("Cash", AccountType.ASSETS, "Cash in hand")
            equity_owner = Account("Owner", AccountType.EQUITIES, "Equity owned by owner")
            expense_rent = Account("Rent", AccountType.EXPENSES, "Rent paid")

# Generated at 2022-06-21 20:04:27.349960
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    version = '1.0.0'
    #guid = Guid(str(Guid.__name__)+str(version))
    assert Posting(JournalEntry(datetime.date(2019, 9, 23), '', 'source'), datetime.date(2019, 9, 23), Account('', '', ''), Direction.INC, Amount(1)) \
        == Posting(JournalEntry(datetime.date(2019, 9, 23), '', 'source'), datetime.date(2019, 9, 23), Account('', '', ''), Direction.INC, Amount(1))

# Generated at 2022-06-21 20:04:39.017875
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from datetime import date
    from .accounts import AccountType
    from .ledger import Ledger
    ledger = Ledger('sample_files/ledger.csv')
    entries = ledger.read_journal_entries(DateRange(None, date.today()))
    assert len(entries) > 0
    assert list(entries)[0].date == date(2020, 7, 14)
    assert list(entries)[0].description == 'Fees'
    assert list(entries)[0].source == 'A'
    assert len(list(entries)[0].postings) == 2
    assert list(entries)[0].postings[1].account.type == AccountType.REVENUES
    assert list(entries)[0].postings[0].account.name == 'CASH'

# Generated at 2022-06-21 20:04:45.253564
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry(date = datetime.date(2020, 11, 19), 
                      description = "Test JE", 
                      source = "TEST",
                      guid = makeguid()) # Use default field for guid

    assert je.date == datetime.date(2020, 11, 19)
    assert je.description == "Test JE"
    assert je.source == "TEST"
    assert isinstance(je.guid, Guid)
    assert isinstance(je.postings, list)


# Generated at 2022-06-21 20:05:04.927610
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account_asset = Account("Cash")
    account_liability = Account("Credit Card")
    account_equity = Account("Owner's Equity")
    account_revenue = Account("Sales")
    account_expense = Account("Wages")

    # Build a valid journal entry:
    j = JournalEntry("Valid") \
        .post(datetime.date(2019, 10, 18), account_equity, +100) \
        .post(datetime.date(2019, 10, 18), account_asset, +100) \
        .post(datetime.date(2019, 10, 18), account_asset, +50) \
        .post(datetime.date(2019, 10, 18), account_liability, +150)

    # Validate:
    j.validate()

    # Build an invalid journal entry:


# Generated at 2022-06-21 20:05:16.195766
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from .accounts import Account
    from .business import Business
    from .ledgers import JournalEntries
    from .ledgers import Ledger
    from .ledgers import TrialBalance
    from .ledgers import BalanceSheet
    from .ledgers import IncomeStatement
    from .ledgers import RetainedEarnings
    from .ledgers import CashFlowStatement
    from .txn import _AccountingTransaction
    from .txn import DebitCreditInvoice
    from .txn import CommonEntries
    from .constants import BusinessTypes
    from .constants import BusinessClasses
    
    # creating business
    b=Business(BusinessTypes.SOLE_PROPRIETORSHIP, BusinessClasses.SOLE_PROPRIETORSHIP, 'ig', 'ig', 'ig', 'ig', 'ig')
    # creating accounts

# Generated at 2022-06-21 20:05:24.810551
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import Asset, Equity, Liability
    from .vendors import Vendor, Vendors
    from datetime import date
    vendor = Vendors().post(name="Vendor", type=Vendor)
    account = Asset.deposit.withdraw.post(
        date=date.today(), description="Deposit from Vendor", source=vendor
    )
    journal_entry = account.journal_entries[0]

# Generated at 2022-06-21 20:05:27.170298
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    ReadJournalEntries._is_protocol

# vim: et:ts=4:sw=4:tw=79:fsr=1

# Generated at 2022-06-21 20:05:32.717434
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account, AccountType
    from .journal import Direction
    journal = JournalEntry[Posting]
    obj = Posting(journal,datetime.date(2019,8,3),Account('Salary',AccountType.REVENUES),Direction.INC,Amount(2000))
    assert obj.journal==journal
    assert obj.date==datetime.date(2019,8,3)
    assert obj.account==Account('Salary',AccountType.REVENUES)
    assert obj.direction==Direction.INC
    assert obj.amount==Amount(2000)
    

# Generated at 2022-06-21 20:05:43.347389
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    """
    Unit tesing for method __hash__ of class JournalEntry.
    """
    from dataclasses import asdict
    from datetime import date
    from ..commons.numbers import Quantity, Amount

    # 2 JournalEntries for testing
    journal_1 = JournalEntry(date(2019, 12, 28), 'Test post 1', source='source_1')
    journal_1.post(date(2019, 12, 28), Account(code='Test account 1', type=AccountType.ASSETS), Quantity(1500))
    journal_2 = JournalEntry(date(2019, 12, 28), 'Test post 2', source='source_2')
    journal_2.post(date(2019, 12, 28), Account(code='Test account 2', type=AccountType.ASSETS), Amount(1500))

# Generated at 2022-06-21 20:05:48.436014
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    t1_p1 = Posting(None, datetime.date(2020, 1, 1), Account("A1"), Direction.INC, Amount(1))
    t1_p3 = Posting(None, datetime.date(2020, 1, 1), Account("A3"), Direction.INC, Amount(3))
    t2_p1 = Posting(None, datetime.date(2020, 1, 1), Account("A1"), Direction.INC, Amount(1))
    t2_p3 = Posting(None, datetime.date(2020, 1, 1), Account("A3"), Direction.INC, Amount(3))
    assert hash(t1_p1) == hash(t2_p1)
    assert hash(t1_p3) == hash(t2_p3)

# Generated at 2022-06-21 20:05:56.531587
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from datetime import date

    from ..commons.numbers import Amount, Quantity
    from .accounts import Account

    je = JournalEntry[object]()
    je.date = date(2019, 12, 27)
    je.description = "Test journal entry"
    je.source = "Coffee beans @ $1.50"
    je.post(date(2019, 12, 27), Account(AccountType.ASSET, "Cash"), Quantity(-1.5))
    je.post(date(2019, 12, 27), Account(AccountType.EXPENSE, "Raw materials"), Quantity(1.5))


# Generated at 2022-06-21 20:06:05.883287
# Unit test for constructor of class JournalEntry
def test_JournalEntry():

    from .accounts import Account, AccountType
    from .business import BusinessEntity
    from ..commons.numbers import USD
    from ..commons.zeitgeist import DateRange

    biz = BusinessEntity.create("DAVID", "ACME Corp.", USD)

    acct: Account = biz.get_or_create_account("Sales", AccountType.REVENUES)
    dr = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))

    entry1 = JournalEntry[BusinessEntity](datetime.date(2020, 1, 1), "testing", biz)
    entry1.post(datetime.date(2020, 1, 1), acct, 5000)

    assert entry1.date == datetime.date(2020, 1, 1)
    assert entry1.description == "testing"

# Generated at 2022-06-21 20:06:07.873572
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Tests method __call__ of class ReadJournalEntries
    """
    pass # TODO


# Generated at 2022-06-21 20:06:53.176008
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.zeitgeist import DateRange
    from datetime import date
    from .accounts import Account
    from .books import Book
    from .chart import Chart
    from .journals import from_book

    ## Create Chart of Accounts:
    chart = Chart()
    revenue = chart.add_account(Account("Revenue", AccountType.REVENUES))
    salary = chart.add_account(Account("Salary", AccountType.EXPENSES))
    profit = chart.add_account(Account("Profit & Loss", AccountType.EQUITIES))
    income = chart.add_account(Account("Income", AccountType.EQUITIES))

    ## Create a Journal:
    journal = from_book(Book("Sample Book"), chart)

    ## Post some entries:

# Generated at 2022-06-21 20:06:58.015067
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    JournalEntry.postings = []
    p1 = Posting(JournalEntry, datetime.date(2019, 10, 5), "Brick factory", Direction.INC, Amount(200))
    p2 = Posting(JournalEntry, datetime.date(2019, 10, 5), "Brick factory", Direction.INC, Amount(200))
    assert p1 == p2


# Generated at 2022-06-21 20:07:09.651117
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from .accounts import Account, AccountType
    from .gl import GL
    from .ledger import ledger, Ledger
    from .transactions import Transfer

    assert issubclass(JournalEntry, Generic)

    gl: GL = GL()
    ledger: Ledger = ledger()

    src: Account = gl.create_account(
        "CASH", "Cash", AccountType.ASSETS,
        description="Cash in hand."
    )

    dst: Account = gl.create_account(
        "BANK", "Bank", AccountType.ASSETS,
        description="Savings Account at the Bank."
    )


# Generated at 2022-06-21 20:07:18.424552
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from .accounts import AccountType, get_or_inc_account
    from .events import BusinessObjectEvent
    from .general import AssetAccount, EquityAccount, ExpenseAccount
    from .ledger import Ledger
    import datetime
    AED = get_or_inc_account("AED", description="Liability account for UAE Dirhams", type=AccountType.LIABILITIES)
    CHQ = get_or_inc_account("CHQ", description="Asset account for cheque", type=AccountType.ASSETS)
    CASH = get_or_inc_account("CASH", description="Asset account for cash", type=AccountType.ASSETS)
    WAGES = get_or_inc_account("WAGES", description="Expense account for wages", type=AccountType.EXPENSES)

# Generated at 2022-06-21 20:07:29.135902
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Unit test for method validate of class JournalEntry
    """
    # Case 1: Valid Case
    # Create journal entry
    date = datetime.date(2020, 5, 1)
    description = "Test Journal Entry"
    source = "Test SME"
    journal_entry = JournalEntry[str](date, description, source)
    # Create 2 postings for journal entry
    account_1 = Account(type = AccountType.ASSETS, name = "Account 1", description = "Account 1 Description")
    account_2 = Account(type = AccountType.LIABILITIES, name = "Account 2", description = "Account 2 Description")
    amount_1 = Amount(10)
    amount_2 = Amount(10)
    p1 = Posting(journal_entry, date, account_1, Direction.INC, amount_1)

# Generated at 2022-06-21 20:07:36.736687
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .accounts import Account, Ledger

    ledger = Ledger.default()

    posting = Posting(None, None, None, None, None)
    posting.amount = 10
    posting.journal = None
    posting.date = datetime.datetime.now().date()
    posting.account = Account("1", "Test")
    posting.direction = Direction.INC

    try:
        posting.guid = "1"
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-21 20:07:50.680341
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    test_account = Account("test_account", AccountType.ASSETS)
    test_business_object = "test_business_object"
    test_description = "test_description"
    test_direction = Direction.INC
    test_date = datetime.date(year=2020, month=1, day=1)
    test_amount = Amount(100)
    test_journal = JournalEntry(test_date, test_description, test_business_object)
    test_posting = Posting(test_journal, test_date, test_account, test_direction, test_amount)
    test_journal.postings = [test_posting]
    del test_journal.date
    del test_journal.description
    del test_journal.source
    del test_journal.postings
    del test_journal.guid
    del test

# Generated at 2022-06-21 20:07:57.717013
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .tags import Tag, TagValue

    journal=JournalEntry(date=None, description=None,source=None)
    
    date=None
    account=Account(
        code="",
        name="",
        type=AccountType.EXPENSES,
        description="",
        tags=[Tag(name="", description="")],
        values=[TagValue(date=None, value=Amount(0))],
        guid=None
    )
    quantity=-1000

    journal.post(date,account,quantity)
    assert journal.postings[0].direction==Direction.DEC


# Generated at 2022-06-21 20:08:03.211223
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # AssertionError if tried to assign a value to a field not in __slots__
    try:
        journal_entry = JournalEntry(datetime.date.today(), "journal entry desc", "source")
        journal_entry.s = "test"
    except AttributeError as exception:
        assert True
    else:
        assert False
    # should not raise AttributeError
    journal_entry = JournalEntry(datetime.date.today(), "journal entry desc", "source")
    journal_entry.postings = [Posting(journal=journal_entry, date=datetime.date.today(),
                                       account=Account("Account 1", AccountType.ASSETS),
                                       direction=Direction.DEC, amount=1)]

# Generated at 2022-06-21 20:08:07.500107
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Arrange
    je = JournalEntry('2020-01-01T00:00:00Z', 'test', 'test',[])
    # Act/Assert
    je.postings.append('123')


# Generated at 2022-06-21 20:09:34.145041
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert str(Posting(None,datetime.date,Account,Direction,Amount)) == 'Posting(journal=None, date=datetime.date, account=Account, direction=Direction, amount=Amount)'

# Generated at 2022-06-21 20:09:41.547740
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journalEntry = JournalEntry(datetime.date(2019, 1, 31), "Test description", None)
    assert repr(journalEntry) == "JournalEntry(date=datetime.date(2019, 1, 31), description='Test description', source=None, guid=NwyBtdC2QhOZM0tZi0p_bw)"



# Generated at 2022-06-21 20:09:50.797975
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    # Setup
    account_a = Account.make("A", account_type=AccountType.ASSETS)
    account_b = Account.make("B", account_type=AccountType.EQUITIES)
    account_c = Account.make("C", account_type=AccountType.REVENUES)
    account_d = Account.make("D", account_type=AccountType.EXPENSES)
    account_e = Account.make("E", account_type=AccountType.ASSETS)
    account_f = Account.make("F", account_type=AccountType.LIABILITIES)
    account_g = Account.make("G", account_type=AccountType.EQUITIES)
    account_h = Account.make("H", account_type=AccountType.REVENUES)

# Generated at 2022-06-21 20:10:02.486463
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from .accounts import Account
    from .commodities import USD

    E = JournalEntry[None]

    AN_ACCOUNT = Account("Assets:Checking:BofA", USD)

    j = E(date=datetime.date.today(), description="An entry", source=None).post(datetime.date.today(), AN_ACCOUNT, 100)
    assert len(j.postings) == 1
    j.__delattr__("postings")
    assert len(j.postings) == 0
    try:
        j.postings.append(None)
    except AttributeError:
        pass
    else:
        assert False, "Impossible: Postings should have been frozen."


# Generated at 2022-06-21 20:10:11.364003
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    # Create a JournalEntry object
    journal_entry = JournalEntry(datetime.date.today(), "description")
    # Create a Posting object
    posting_object = Posting(journal_entry, datetime.date.today(), "account", Direction.INC, Amount(1))

    # Check for delattr()
    with pytest.raises(AttributeError) as exception:
        delattr(posting_object, "journal")

    # Verify the exception message
    assert str(exception.value) == "'Posting' object has no attribute 'journal'"


# Generated at 2022-06-21 20:10:16.227364
# Unit test for constructor of class Posting
def test_Posting():
    journal = datetime.date.today()
    date = datetime.date.today()
    account = Account
    direction = Direction.INC
    amount = 1
    post = Posting(journal, date, account, direction, amount)

    assert post.journal == journal
    assert post.date == date
    assert post.account == account
    assert post.direction == direction
    assert post.amount == amount


# Generated at 2022-06-21 20:10:25.231235
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    import datetime

    @dataclass(frozen=True)
    class TestSource:
        pass

    je = JournalEntry[TestSource](datetime.date(2020, 5, 18), "Description", TestSource())
    assert len(je.postings) == 0
    je.postings = [Posting(je, datetime.date(2020, 5, 18), Account("Test", AccountType.ASSETS), Direction.INC, 123)]
    assert len(je.postings) == 1

# Generated at 2022-06-21 20:10:30.177807
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Test setup
    account1 = Account("Assets:Current:AccountsReceivable")
    account2 = Account("Revenues:Sales")

    # Test cases
    journal_entry = JournalEntry(datetime.date.today(), "Receivable Payment", None)
    journal_entry.post(datetime.date.today(), account1, +1000)
    journal_entry.post(datetime.date.today(), account2, -1000)
    journal_entry.validate()

# Generated at 2022-06-21 20:10:41.778019
# Unit test for constructor of class Posting
def test_Posting():
    # Set up
    # We need to build a JournalEntry object in order to pass it to the Posting constructor
    # We need to build an Account object in order to pass it to the JournalEntry constructor
    # We need to build a DateRange object in order to pass it to the Account constructor
    # We need to build a Date object in order to pass it to the DateRange constructor
    # We need to build a list of integers in order to pass it to the Date constructor
    # We need to build objects from the datetime module in order to pass it to the integer constructor
    today = datetime.date.today()
    year = today.year
    month = today.month
    day = today.day
    date = datetime.date(year,month,day)
    date_list = [year, month, day]

# Generated at 2022-06-21 20:10:49.050104
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from ..commons.others import makeguid
    from .accounts import Account
    from .ledger import Ledger
    from .chartofaccounts import ChartOfAccounts
    from .accounttypedefinition import AccountTypeDefinition
    chart = ChartOfAccounts()
    chart.define_accounts({AccountTypeDefinition(AccountType.ASSETS, 'Asset', 'Assets'),
                           AccountTypeDefinition(AccountType.EQUITIES, 'Equity', 'Equities')})
    ledger = Ledger(chart)
    a1 = ledger.add_account('Assets', 'Fixed Assets')
    a2 = ledger.add_account('Assets', 'Current Assets')
    e1 = ledger.add_account('Equities', 'Fixed Deposits')
    e2 = ledger.add_account('Equities', 'Retained Earnings')
