

# Generated at 2022-06-21 20:01:24.115905
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Arrange
    from datetime import date
    from matchzoo.core.env import ENV
    from ..models.deprecated.journal import JournalEntry

    today = date.today()
    account_A = ENV.accounts["A"]
    account_B = ENV.accounts["B"]
    account_C = ENV.accounts["C"]
    journal_1 = JournalEntry(today, "test1", None)
    journal_2 = JournalEntry(today, "test2", None)
    journal_3 = JournalEntry(today, "test3", None)
    journal_4 = JournalEntry(today, "test4", None)

    # Act
    journal_1.post(today, account_A, 100)
    journal_2.post(today, account_A, 100)

# Generated at 2022-06-21 20:01:28.129537
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry(datetime.date(2020, 1, 1), 'A Journal Entry', {})) == "JournalEntry(2020-01-01, 'A Journal Entry', {})"


# Generated at 2022-06-21 20:01:30.294242
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # FIXME: Needs to be implemented
    pass

# Generated at 2022-06-21 20:01:35.933161
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    datetime.date.today()
    account = Account("Code", "Abbr", "Name", AccountType.ASSETS)
    direction = Direction.INC
    amount = Amount.from_decimal(1.0)
    posting = Posting(journal=None, date="2020-01-01", account=account, direction=direction, amount=amount)


# Generated at 2022-06-21 20:01:47.268174
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    @dataclass
    class Source:
        pass

    source = Source()
    account = Account("Cash", "Cash")

    posting = Posting(journal=None, date=datetime.date.today(), account=account, direction=Direction.INC, amount=1)
    posting.date
    posting.account
    posting.direction
    posting.amount

    with pytest.raises(AttributeError):
        posting.journal = None

    with pytest.raises(AttributeError):
        posting.source = source

    with pytest.raises(AttributeError):
        posting.guid = Guid("afb2bf52-9152-4bc3-a3f3-f37b8e451ccc")

    @dataclass(frozen=True)
    class JournalEntrySub(JournalEntry):
        pass

    journal

# Generated at 2022-06-21 20:01:59.045559
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    print("test_ReadJournalEntries")

    @dataclass(frozen=True)
    class SourceObject:
        description: str
        account: Account
        quantity: Quantity

    @dataclass(frozen=True)
    class JournalEntry:
        description: str
        source: SourceObject
        postings: List[Posting] = field(default_factory=list, init=False)

    @dataclass(frozen=True)
    class Posting:
        date: datetime.date
        account: Account
        direction: Direction
        amount: Amount

    @dataclass(frozen=True)
    class JournalEntries:
        entries : Iterable[JournalEntry]


# Generated at 2022-06-21 20:02:06.370349
# Unit test for method __repr__ of class JournalEntry

# Generated at 2022-06-21 20:02:13.137453
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    entry = JournalEntry(datetime.date(2020, 3, 8), 'my entry', 'my source')
    assert entry.date == datetime.date(2020, 3, 8)
    assert entry.description == 'my entry'
    assert entry.source == 'my source'
    assert len(entry.postings) == 0
    assert entry.guid is not None
    assert entry.increments == []
    assert entry.decrements == []
    assert entry.debits == []
    assert entry.credits == []


# Generated at 2022-06-21 20:02:20.573934
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    class MockJournal():
        pass
    journal = MockJournal()

    posting = Posting(journal, datetime.date(2020, 8, 16), Account("Test", AccountType.EXPENSES), Direction.INC, Amount(1000))
    assert posting.__repr__() == "Posting(journal, date=datetime.date(2020, 8, 16), account=Account(name='Test', type=<AccountType.EXPENSES: 'EXPENSES'>), direction=<Direction.INC: 1>, amount=1000)"

# Generated at 2022-06-21 20:02:28.627076
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    import datetime
    from .commons.zeitgeist import DateRange
    from .accounts import Account, AccountType, MUTUAL_FUND, CASH
    from .accounting import journal_entries, Posting, ReadJournalEntries
    from .portfolios import Buy

    # Define a journal entry reading function

# Generated at 2022-06-21 20:02:44.717620
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    """
    Tests method __hash__ of class JournalEntry.
    """
    journal_entry_1 = JournalEntry(datetime.date(2020,1,1), "Test 1", "Source 1")
    journal_entry_2 = JournalEntry(datetime.date(2020,1,1), "Test 1", "Source 1")
    journal_entry_3 = JournalEntry(datetime.date(2020,1,2), "Test 1", "Source 1")
    journal_entry_4 = JournalEntry(datetime.date(2020,1,1), "Test 2", "Source 1")
    journal_entry_5 = JournalEntry(datetime.date(2020,1,1), "Test 1", "Source 2")

    assert hash(journal_entry_1) == hash(journal_entry_2), "JournalEntry __hash__ error"
    assert hash

# Generated at 2022-06-21 20:02:47.400907
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    x = Posting(12, "hi", True, 45)
    assert  x.date == 12
    assert  x.description == "hi"
    assert  x.source == True
    assert  x.amount == 45


# Generated at 2022-06-21 20:02:54.157624
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Asset, AccountType, Account
    asset = Account("asset", AccountType.ASSETS, Asset("asset"))
    le = JournalEntry(datetime.date(2018,1,1), "TestEntry", asset)
    le.post(datetime.date(2018,1,1), asset, 10)
    le.validate()
    pass

# Generated at 2022-06-21 20:02:54.840612
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    pass

# Generated at 2022-06-21 20:03:07.151492
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    @dataclass(frozen=True)
    class JE(JournalEntry):
        pass
    j1 = JE(datetime.date(2019,1,1), "desc1", "source1")
    j2 = JE(datetime.date(2019,1,1), "desc1", "source2")
    j3 = JE(datetime.date(2019,1,1), "desc2", "source1")
    j4 = JE(datetime.date(2019,1,2), "desc1", "source1")
    j5 = JE(datetime.date(2019,1,1), "desc1", "source1")
    assert hash(j1) == hash(j1)
    assert hash(j1) != hash(j2)

# Generated at 2022-06-21 20:03:15.882530
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from collections.abc import Hashable

    # Given

    @dataclass(frozen=True)
    class Person:
        name: str
        age: int


    # When
    x = Posting(1, datetime.date.today(), Account("Assets", AccountType.ASSETS), Direction.INC, Amount(10.0))


    # Then
    assert x.amount.value == 10.0
    assert x.is_debit



# Generated at 2022-06-21 20:03:28.335679
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from nose.tools import assert_true, assert_false

    t=datetime.date.today()
    je1=JournalEntry(date=t,description="This is a JournalEntry",source="a string")
    je2=JournalEntry(date=t,description="This is a JournalEntry",source="a string")
    je3=JournalEntry(date=t,description="This is a Journal Entry",source="a string")
    je4=JournalEntry(date=t,description="This is a JournalEntry",source="another string")
    je5=JournalEntry(date=t,description="This is a JournalEntry",source="a string")
    je5.post(date=t,account='assets:salary',quantity=100)

    assert_true(je1==je2)
    assert_true(je1!=je3)
   

# Generated at 2022-06-21 20:03:32.475441
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journal = JournalEntry[Account]("journal")
    journal.post("date", "account", "direction", "amount")
    posting = journal.postings[0]
    assert posting.journal == journal

# Generated at 2022-06-21 20:03:40.562325
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():                                                                                                                                                                                           
    from datetime import datetime, date
    from decimal import Decimal                                                                                                                                                                                               
    je = JournalEntry[str]('JE123', 'Test Journal Entry', datetime.today(), '')                                                                                                                                               
    assert len(je.__dict__) == 4                                                                                                                                                                                                
    je.post(date.today(), Account('ACC123', 'Tes Account', AccountType.EQUITIES, datetime.today()), Decimal(100))                                                                                                            
    assert len(je.__dict__) == 4                                                                                                                                                                                                

# Generated at 2022-06-21 20:03:45.309483
# Unit test for constructor of class Posting
def test_Posting():
    p1 = Posting(1,2,3,4,5)
    
    assert p1.journal == 1
    assert p1.date == 2
    assert p1.account == 3
    assert p1.direction == 4
    assert p1.amount == 5



# Generated at 2022-06-21 20:04:05.656928
# Unit test for constructor of class Posting
def test_Posting():
    assert 1 == 1

# Generated at 2022-06-21 20:04:17.024272
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    print("Test JournalEntry.validate")
    je1 = JournalEntry(datetime.date.today(), "Test JournalEntry", None)
    je1.post(datetime.date.today(), Account(1, "A1", AccountType.ASSETS), 100)
    je1.post(datetime.date.today(), Account(4, "A4", AccountType.EXPENSES), -100)
    je1.validate()

    je2 = JournalEntry(datetime.date.today(), "Test JournalEntry", None)
    je2.post(datetime.date.today(), Account(2, "A2", AccountType.EQUITIES), 500)
    je2.post(datetime.date.today(), Account(3, "A3", AccountType.LIABILITIES), -500)
    je2.validate()

    je3

# Generated at 2022-06-21 20:04:28.765068
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .accounts import Account, AccountType
    from ..commons.numbers import Amount, Quantity
    from .journal import Direction, JournalEntry, Posting

    j1: JournalEntry[str] = JournalEntry("2020-12-31", "Journal Entry #1", "Journal")
    j2: JournalEntry[str] = JournalEntry("2020-12-31", "Journal Entry #2", "Journal")

    acc1: Account = Account("Assets", "1000", AccountType.ASSETS)
    acc2: Account = Account("Equities", "0100", AccountType.EQUITIES)
    acc3: Account = Account("Liabilities", "0010", AccountType.LIABILITIES)
    acc4: Account = Account("Revenues", "0001", AccountType.REVENUES)

# Generated at 2022-06-21 20:04:29.370409
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass

# Generated at 2022-06-21 20:04:30.085108
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    return ReadJournalEntries[str].__call__

# Generated at 2022-06-21 20:04:39.706299
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    # Commenting out due to mypy failure
    # p = Posting(journal = JournalEntry(self, date = datetime.date(datetime.datetime(2020, 3, 12, 0, 0)), description = 'Deposit', source = BankAccount(name = 'A/c Name'), postings = list), date = datetime.date(datetime.datetime(2020, 3, 12, 0, 0)), account = Account(name = 'Account', type = ASSET), direction = INC, amount = Amount(100))
    # del p.source
    # del p.direction
    # del p.amount
    # del p.account
    # del p.date
    # del p.journal
    pass

# Generated at 2022-06-21 20:04:51.037753
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..controllers.journal import JournalEntryController
    from ..controllers.accounts import AccountController
    from .accounts import Account, AccountType
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from datetime import date
    journalEntry = JournalEntryController()
    account = AccountController()
    account.create("Cash", AccountType.ASSETS, DateRange(date(2019, 5, 31), None), True)
    account1 = AccountController()
    account1.create("Owner Equity", AccountType.EQUITIES, DateRange(date(2019, 5, 31), None), True)
    account2 = AccountController()
    account2.create("Sales", AccountType.REVENUES, DateRange(date(2019, 5, 31), None), True)
    account3 = AccountController()

# Generated at 2022-06-21 20:04:52.110522
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    pass


# Generated at 2022-06-21 20:05:04.290533
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from dataclasses import dataclass
    from typing import List
    from unittest import TestCase, main
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange
    from .journal_entries import JournalEntry, ReadJournalEntries, Direction

    @dataclass(frozen=True)
    class Source:
        pass

    @dataclass(frozen=True)
    class JournalEntryReader(ReadJournalEntries[Source]):
        data: List[JournalEntry[Source]] = field(default_factory=list, init=False)

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[Source]]:
            yield from (i for i in self.data if i.date in period)


# Generated at 2022-06-21 20:05:07.916881
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry(datetime.date.today(), "abc", None)) == "JournalEntry(date=2020-02-03, description='abc', source=<None>)"


# Generated at 2022-06-21 20:05:45.379803
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    now = datetime.date.today()
    _a = JournalEntry[_T](now, "Description", _T)
    _a.post(now, "ACCOUNT", 0)
    assert 'date' in dir(_a)
    assert 'description' in dir(_a)
    assert 'source' in dir(_a)
    assert 'postings' in dir(_a)
    assert 'guid' in dir(_a)
    assert 'increments' in dir(_a)
    assert 'decrements' in dir(_a)
    assert 'debits' in dir(_a)
    assert 'credits' in dir(_a)
    assert _a.date == now
    assert _a.description == "Description"
    assert _a.source == _T
    assert len(_a.postings) == 1

# Generated at 2022-06-21 20:05:52.192092
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    date = datetime.date(2020,1,1)
    description = 'a'
    source = 'b'
    postings = [Posting(journal='c', date=date, account='d', direction='e', amount='f')]
    guid ='g'
    journalEntry = JournalEntry(date, description, source, postings, guid)
    assert repr(journalEntry) == "JournalEntry(date=2020-01-01, description='a', source='b', postings=['c',2020-01-01,'d','e',f',True], guid='g')"

# Generated at 2022-06-21 20:06:04.885711
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import AccountType
    from .ledgers import LoadLedger
    from .readers import ReadLedger

    import datetime
    from typing import List
    from dataclasses import asdict
    from uuid import UUID

    @dataclass(frozen=True)
    class Invoice:
        """
        Invoice model class.
        """

        #: Invoice number.
        number: str

        #: Date of the invoice.
        date: datetime.date

        #: Unique, immutable identifier.
        guid: UUID = field(default_factory=makeguid)

        @classmethod
        def read_all(cls) -> Iterable["Invoice"]:
            """
            Returns all invoices.
            """

# Generated at 2022-06-21 20:06:11.201166
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():

    def test(posting):
        attr = posting.account
        assert attr == "bank"        # default value
        posting.account = "2"
        attr = posting.account
        assert attr == "bank"

    posting = Posting("", "", "bank", "", "")
    test(posting)

test_Posting___setattr__()

# Generated at 2022-06-21 20:06:19.150143
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from src.accounting.accounts import Account, AccountType
    from src.accounting.journals import JournalEntry

    # Create a sample JournalEntry
    je_sample = JournalEntry(
      date=datetime.date(2020,1,1),
      description="Payee"
    )

    # Journal entry with total debit != total credit
    je1 = je_sample.post(datetime.date(2020,1,1), Account(type=AccountType.ASSETS, name="Cash"), Quantity(50))
    je1.post(datetime.date(2020,1,1), Account(type=AccountType.REVENUES, name="Sales"), Quantity(-50))
    try:
        je1.validate()
    except AssertionError:
        print("Thrown AssertionError: Total Debits and Credits are not equal")
    

# Generated at 2022-06-21 20:06:29.975290
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import CASH
    from .test_journal_entries import test_transaction_for_source_type_A

    date = datetime.date(2020, 3, 16)
    amount = Amount(100)
    journal = test_transaction_for_source_type_A()
    source_posting = Posting(journal, date, CASH, Direction.INC, amount)

    posting_1 = Posting(journal, date, CASH, Direction.INC, amount)
    posting_2 = Posting(journal, date, CASH, Direction.DEC, amount)
    posting_3 = Posting(journal, date, CASH, Direction.INC, amount + 1)
    posting_4 = Posting(journal, date - datetime.timedelta(days=1), CASH, Direction.INC, amount)
    posting_

# Generated at 2022-06-21 20:06:41.846334
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # Set first posting
    first_posting_journal = JournalEntry([], '', '')
    first_posting_date = datetime.date.today()
    first_posting_account = Account('account', '', '')
    first_posting_direction = Direction.DEC
    first_posting_amount = Amount(100)
    
    first_posting = Posting(first_posting_journal, first_posting_date, first_posting_account, first_posting_direction, first_posting_amount)

    # Set second posting
    second_posting_journal = JournalEntry([], '', '')
    second_posting_date = datetime.date.today()
    second_posting_account = Account('account', '', '')
    second_posting_direction = Direction.DEC
    second_

# Generated at 2022-06-21 20:06:54.259422
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    @dataclass(frozen=True)
    class Account2(Account):
        pass
    guid = Guid("D3537984E4D44CBB9CED0A4B9BDBCB14")  # TODO: Is 'Guid("D3537984E4D44CBB9CED0A4B9BDBCB14")' correct?
    date = datetime.date(2020, 1, 1)
    description = "Test"
    source = "source"  # TODO: Is 'source' correct?
    account = Account2("Test Account")
    direction = Direction.INC
    amount = Amount(10)
    journal_entry = JournalEntry(guid=guid, date=date, description=description, source=source)
    assert journal_entry.postings == []
    journal_entry.post

# Generated at 2022-06-21 20:06:59.280971
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
	Direction1 = Direction
	Posting1 = Posting
	post1 = Posting1(JournalEntry, datetime.date, Account, Direction1)
	post2 = Posting1(JournalEntry, datetime.date, Account, Direction1)
	assert post2 == post2
	assert post1 == post2
	assert not(post2 != post2)
	assert not(post1 != post2)

# Generated at 2022-06-21 20:07:10.825567
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest.mock import Mock
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .placements import TargetCashflow
    from .readers.journal_entry_readers import PLACEMENT_BASED_READER

    # Construct a ledger:
    ledger = Ledger()

    # Construct readers:
    placement_reader = PLACEMENT_BASED_READER(ledger)
    mock_reader = Mock()

    # Construct a placement:

# Generated at 2022-06-21 20:07:50.933152
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p1 = Posting(journal=None, date=datetime.date(2019, 1, 1), account=None, direction=Direction.INC, amount=Amount("1"))
    p2 = Posting(journal=None, date=datetime.date(2019, 1, 1), account=None, direction=Direction.INC, amount=Amount("1"))
    assert hash(p1)==hash(p2)


# Generated at 2022-06-21 20:07:59.304307
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from . import accounts
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Category
    from .accounts import CategoryType
    from .accounts import Ledger
    __source_0 = Ledger(accounts=[], categories=[])
    __attr_classes = {'_Ledger__accounts': list, '_Ledger__categories': list, '_Ledger__books': dict, '_Ledger__lock': NoneType}
    __instance_0 = Ledger(accounts=[], categories=[])
    __attr_types = {'_Ledger__accounts': list, '_Ledger__categories': list, '_Ledger__books': dict, '_Ledger__lock': NoneType}

# Generated at 2022-06-21 20:08:06.948258
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    a = Posting(None,datetime.datetime.now(),Account("1") , Direction.INC, Amount(1))
    b = Posting(None,datetime.datetime.now(),Account("2") , Direction.DEC, Amount(1))
    journal_entry = JournalEntry(datetime.datetime.now(),"description","source")
    journal_entry.postings = [a,b]
    journal_entry.validate()


# Generated at 2022-06-21 20:08:16.409262
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    journal = JournalEntry[int](datetime.date(2020,1,1), "test", 1)
    posting1 = Posting(journal, datetime.date(2020,1,1), Account(1, "test1", AccountType.ASSETS), Direction.INC, Amount(100))
    posting2 = Posting(journal, datetime.date(2020,1,1), Account(1, "test1", AccountType.ASSETS), Direction.INC, Amount(100))
    posting3 = Posting(journal, datetime.date(2020,1,1), Account(1, "test1", AccountType.ASSETS), Direction.INC, Amount(200))
    assert posting1.__eq__(posting2)
    assert not posting1.__eq__(posting3)


# Generated at 2022-06-21 20:08:22.677179
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # noinspection PyUnresolvedReferences
    """
    This function tests the method `__setattr__` of class `JournalEntry`
    """
    
    try:
        # Trying to set an attribute
        j = JournalEntry[int](datetime.date(2019, 11, 17), 'Test', 0)
        j.description = 'Changed'
        assert True
    except:
        assert False


# Generated at 2022-06-21 20:08:30.884683
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Q1, Q2
    from .accounts import AccountType

    date1 = datetime.date.today()
    date2 = date1 + datetime.timedelta(days=1)
    date3 = date1 + datetime.timedelta(days=2)

    journal = JournalEntry("A")

    journal.post(date1, Account("assets", AccountType.ASSETS), Q2).post(
        date2, Account("expenses", AccountType.EXPENSES), Q1
    )

    assert journal.postings[0].date == date1
    assert journal.postings[0].account.name == "assets"
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].amount == Q2

    assert journal.postings[1].date

# Generated at 2022-06-21 20:08:40.732778
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    def _create_posting(journal_entry_date: datetime.date, account_id: str, amount: Amount) -> Posting[str]:
        return Posting(JournalEntry(journal_entry_date, "one", "A"), journal_entry_date, Account(account_id), Direction.INC, amount)

    positive = _create_posting(datetime.date(2018, 6, 1), "1111", Amount(23))
    positive2 = _create_posting(datetime.date(2018, 6, 1), "1111", Amount(23))
    positive3 = _create_posting(datetime.date(2018, 6, 1), "1111", Amount(23))

    assert positive == positive2
    assert positive == positive3


# Generated at 2022-06-21 20:08:44.664738
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    a = Posting(1,1,1,1,1)
    assert hash(a) == hash((a.journal, a.date, a.account, a.direction, a.amount))


# Generated at 2022-06-21 20:08:53.736218
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():

    from .accounts import Account, AccountType
    from .journal_entries import Posting, Direction

    account = Account("SBI", AccountType.ASSETS)
    posting1 = Posting("JournalEntry", datetime.datetime(day=17, month=9, year=2020), account, Direction.INC, Amount(1000))
    posting2 = Posting("JournalEntry", datetime.datetime(day=17, month=9, year=2020), account, Direction.INC, Amount(1000))
    posting3 = Posting("JournalEntry", datetime.datetime(day=13, month=9, year=2020), account, Direction.INC, Amount(1000))

    assert posting1 == posting2
    assert posting2 != posting3


# Generated at 2022-06-21 20:09:03.977522
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from .accounts import AccountType, chart_of_accounts
    from .ledgers import ReadLedgers
    from .transactions import Transaction, TransactionType

    def ledger_of_t(t: Transaction[_T]) -> Account:
        return chart_of_accounts[f"{t.type.name}.{t.source.name}", t.date, t.source]

    def journal_entries(period: DateRange) -> Iterable[JournalEntry[TransactionType]]:
        ledger_reader: ReadJournalEntries[TransactionType] = ReadLedgers(transaction_type=TransactionType.TRADE)
        transactions: Iterable[Transaction[TransactionType]] = ledger_reader(period)

# Generated at 2022-06-21 20:10:22.502628
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    posting = Posting(journal=None, date=datetime.date.today(), account=None, direction=Direction.INC, amount=Amount(1))
    assert posting.amount == Amount(1)
    del posting.amount
    assert posting.amount == Amount(1)


# Generated at 2022-06-21 20:10:24.205900
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    pass


# Generated at 2022-06-21 20:10:31.560740
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # :JournalEntry[object] is not an instance of journal2.journaling.JournalEntry[object] (src/journal2/journaling/models.py)
    journal = JournalEntry(date= datetime.date(2019,12,15),description="test",source= "test")
    # journal is not an instance of journal2.journaling.JournalEntry[object] (src/journal2/journaling/models.py)
    posting = Posting(journal= journal,date= datetime.date(2019,12,15),account= "test",direction="test",amount=100)
    # guid is a read only attribute
    posting.guid = 1
    # journal is a read only attribute
    posting.journal = 1
    # direction is a read only attribute
    posting.direction = 1
    # date is a read only attribute
    posting.date

# Generated at 2022-06-21 20:10:38.086068
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.accounts import Account
    from ..books.journals import JournalEntry
    from ..books.clock import clock
    from ..commons.numbers import Amount, Quantity

    entry = JournalEntry(date=clock.now(), description="test journal entry")
    entry.post(date=clock.now(), account=Account.build(code="1", description="Cash"), quantity=Quantity(100))

# Generated at 2022-06-21 20:10:41.407766
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class _ReadJournalEntries(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return []
    assert _ReadJournalEntries() is not None


# Generated at 2022-06-21 20:10:44.373696
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    p1 = Posting("j1",
                 datetime.date(2020, 7, 6),
                 "a1",
                 Direction.INC,
                 Amount(100))
    print(repr(p1))


# Generated at 2022-06-21 20:10:46.609803
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    account = Account.asset("cash")
    j = JournalEntry[str]("", "", "")
    j.post(datetime.date.today(), account, 500)
    j.validate()



# Generated at 2022-06-21 20:10:47.184708
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass

# Generated at 2022-06-21 20:10:50.326479
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries.__invariant__(ReadJournalEntries)

# Generated at 2022-06-21 20:10:59.677655
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import AccountName
    from .businesses import Business
    from .currencies import Currency
    from ..commons.numbers import Quantity

    business_name = 'Alpha'
    currency = Currency('USD')
    sales = AccountName('Sales', AccountType.REVENUES)
    accounts_receivable = AccountName('Accounts Receivable', AccountType.ASSETS)
    cash = AccountName('Cash', AccountType.ASSETS)
    accounts_payable = AccountName('Accounts Payable', AccountType.LIABILITIES)
    inventory = AccountName('Inventory', AccountType.ASSETS)

    def lookup_account(name: AccountName) -> Account:
        return Account(name.name, name.account_type, currency)

    # define a business