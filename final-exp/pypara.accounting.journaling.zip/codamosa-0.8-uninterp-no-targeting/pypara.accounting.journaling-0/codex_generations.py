

# Generated at 2022-06-21 20:01:21.866835
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    class TestJournalEntry(JournalEntry):
        pass

    account1 = Account("test account", AccountType.EQUITIES)
    account2 = Account("test account", AccountType.REVENUES)

    test_journal_entry = TestJournalEntry(datetime.date(2018, 1, 1), "Test", 1)
    test_journal_entry.post(datetime.date(2018, 1, 1), account1, 1)
    test_journal_entry.post(datetime.date(2018, 1, 1), account2, -1)
    test_journal_entry.validate()

# Generated at 2022-06-21 20:01:32.505471
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..ledger import AccountList, AccountType
    from ..ledger.accounts import Account, get_account
    assets = AccountList(Account(AccountType.ASSETS, 'cash', 'USD', 0, 0),
                         Account(AccountType.ASSETS, 'cash', 'INR', 0, 0),
                         Account(AccountType.ASSETS, 'gold', 'INR', 0, 0),
                         Account(AccountType.ASSETS, 'gold', 'USD', 0, 0))
    je = JournalEntry(datetime.date(2019, 1, 1), "test-je", assets)
    je.post(datetime.date(2019, 1, 1), assets['cash']['USD'], Quantity('1.0 USD'))

# Generated at 2022-06-21 20:01:34.578618
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    obj = JournalEntry[int](5, "Test object", "")
    del obj.postings
    assert obj.postings is None


# Generated at 2022-06-21 20:01:36.871681
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal = JournalEntry('date','description','source',['blah','blah'])
    journal.__repr__

# Generated at 2022-06-21 20:01:44.217360
# Unit test for constructor of class Posting
def test_Posting():
    account = Account("Assets", AccountType.ASSETS)
    posting = Posting(None, datetime.date.today(), account, Direction.INC, Amount(1))
    assert isinstance(posting, Posting)
    assert posting.journal is None
    assert posting.date == datetime.date.today()
    assert posting.account.identifier == account.identifier
    assert posting.account.description == account.description
    assert posting.account.type == account.type
    assert posting.direction == Direction.INC
    assert posting.amount == Amount(1)


# Generated at 2022-06-21 20:01:48.241997
# Unit test for constructor of class Posting
def test_Posting():
    journal = JournalEntry
    date = datetime.date
    account = Account
    direction = Direction
    amount = Amount
    Posting(journal, date, account, direction, amount)


# Generated at 2022-06-21 20:01:55.278101
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry(datetime.date.today(), "Description", 1)
    assert je.date == datetime.date.today()
    assert je.description == "Description"
    assert je.source == 1
    assert je.postings == []
    assert isinstance(je.guid, str)
    assert je.increments == []
    assert je.decrements == []
    assert je.debits == []
    assert je.credits == []


# Generated at 2022-06-21 20:02:04.630703
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Test if the contructor works
    from .accounts import AccountName
    from .ledgers import Ledger
    from .books import GeneralLedgerBook
    ledger = Ledger().load_default_chart()
    general_ledger_book = GeneralLedgerBook(ledger)
    journal_entry = JournalEntry[str]()
    journal_entry.date = datetime.date(2021, 1, 1)
    journal_entry.description = "Test Journal Entry"
    journal_entry.source = "No source"
    journal_entry.post(datetime.date(2021, 1, 1), ledger[AccountName.CASH_IN_HAND], 100)
    journal_entry.post(datetime.date(2021, 1, 1), ledger[AccountName.SALES_ALLOWANCE], -100)
    general_

# Generated at 2022-06-21 20:02:16.024953
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    JE = JournalEntry
    account1 = Account("account1", "category1", "Account 1", AccountType.ASSETS)
    account2 = Account("account2", "category2", "Account 2", AccountType.EQUITIES)
    try:
        je = JE(datetime.date.today(), "Description of the journal entry.", "") \
            .post(datetime.date.today(), account1, 100) \
            .post(datetime.date.today(), account2, -100)
        je.validate()
    except AssertionError:
        assert False, "Basic JournalEntry validation failed."

# Generated at 2022-06-21 20:02:20.197593
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # pytest.skip("Not yet implemented!")
    import unittest
    try:
        _ = ReadJournalEntries()
    except TypeError:
        pass
    else:
        unittest.fail("Expecting a TypeError to be raised!")

# Generated at 2022-06-21 20:02:38.512627
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    j = JournalEntry(date=datetime.date(2020, 4, 1), description='Hello World', source='Source')
    assert j.date == datetime.date(2020, 4, 1)
    assert j.description == 'Hello World'
    assert j.source == 'Source'
    assert j.guid == Guid('0bc20b89-d2d7-404c-8e50-6a3aeb78b7f9')
    assert j.postings == []

# Generated at 2022-06-21 20:02:47.792594
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from pprint import pprint

    # Create a journal entry instance
    je1 = JournalEntry(datetime.date(2020, 2, 8),
                       "Test Journal Entry",
                       "Test Source")

    # Create another journal entry instance
    je2 = JournalEntry(datetime.date(2020, 2, 8),
                       "Test Journal Entry",
                       "Test Source")

    # Post to the journal entry
    je1.post(datetime.date(2020, 2, 8), Account("Test Account"), 100)

    # Assert GUIDs are different
    assert je1.guid != je2.guid

    # Change date of second journal entry
    je2.date = datetime.date(2020, 2, 9)

# Generated at 2022-06-21 20:02:48.922099
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-21 20:02:51.771969
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journal = JournalEntry[Guid]('', '', '')
    journal.post(datetime.date.today(), '', 0)

# Generated at 2022-06-21 20:02:59.887204
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    print("test_ReadJournalEntries()")
    from .accounts import Account, AccountType
    from .taxes import TaxType
    from .books import Book, Books
    from .transactions import Transaction, TransactionKind, TransactionType

    def test_read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []  # Not Implemented
    assert(ReadJournalEntries.__isinstancecheck__(test_read_journal_entries))
    print("Done")


# Generated at 2022-06-21 20:03:03.609066
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from ..storage import ReadJournalEntries as ReadJournalEntriesImpl
    ReadJournalEntriesImpl(memory=True)(DateRange.from_now(days=1))

# Generated at 2022-06-21 20:03:07.528712
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from ..commons.test.test_dataclasses import assert_equal, assert_not_equal, assert_same_data_struct
    from .accounts import AccountType, RootAccount, Account
    from .datetimes import datetime, date
    from .others import UUID

    #-- POSTING --#
    # One posting
    p1 = Posting(source, date(2015, 1, 1), Account(AccountType.ASSETS, Account(AccountType.LIABILITIES)), Direction.INC, Amount(100))
    assert_equal(p1, p1)

    # Two postings with same data
    p2 = Posting(source, date(2015, 1, 1), Account(AccountType.ASSETS, Account(AccountType.LIABILITIES)), Direction.INC, Amount(100))
    assert_equal(p1, p2)

    #

# Generated at 2022-06-21 20:03:12.511255
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    try:
        del Posting.__dict__['journal']
    except TypeError as e:
        print(e)
        # The error message should be:
        # "'Posting' object does not support item deletion"


# Generated at 2022-06-21 20:03:13.866588
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert True

# Generated at 2022-06-21 20:03:16.448856
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    ## Call the constructor
    def f(period: DateRange) -> Iterable[JournalEntry[int]]:
        pass
    ReadJournalEntries

# Generated at 2022-06-21 20:03:35.644531
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # Create two postings
    posting1 = Posting[int](JournalEntry[int](date=datetime.date(year=2020, month=1, day=15),
                                              description="Test Journal Entry",
                                              source=1),
                            date=datetime.date(year=2020, month=1, day=15),
                            account=Account(code="Assets:Cash", name="Cash", type=AccountType.ASSETS),
                            direction=Direction.INC,
                            amount=Amount(5.12))


# Generated at 2022-06-21 20:03:42.007426
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # Test 1:
    account_value_1 = Account("Assets")
    account_value_2 = Account("Assets")
    journal_entry_value_1 = JournalEntry(datetime.date(2019,1,1), "Description", "Source")
    journal_entry_value_2 = JournalEntry(datetime.date(2019,1,1), "Description", "Source")
    posting_value_1 = Posting(journal_entry_value_1, datetime.date(2019,1,1), account_value_1, Direction.INC, Amount(1000))
    posting_value_2 = Posting(journal_entry_value_1, datetime.date(2019,1,1), account_value_2, Direction.INC, Amount(1000))
    assert posting_value_1 == posting_value_2
    # Test 2:

# Generated at 2022-06-21 20:03:44.246404
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je= JournalEntry(datetime.date.today(),'Test',None)
    assert 'Test' == je.description
    return

# Generated at 2022-06-21 20:03:54.800336
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Arrange
    import datetime

    # Act
    result = example_read_journal_entries(DateRange(datetime.date(2020,1,1), datetime.date(2020,1,31)))
    
    # Assert
    assert isinstance(result, Iterable)
    assert result is not None
    assert len(result) == 2
    assert next(result).date == datetime.date(2020,1,15)
    assert next(result).date == datetime.date(2020,1,29)

example_read_journal_entries = ReadJournalEntries[None]
example_read_journal_entries.__doc__ = "Example for method __call__ of class ReadJournalEntries"
example_read_journal_entries.__annotations__ = {'return': Iterable[JournalEntry[None]]}

# Generated at 2022-06-21 20:04:02.592444
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from datetime import date
    from ..commons.numbers import Amount, Quantity

    assert JournalEntry(date(2020, 6, 17), "", 0).post(date(2020, 6, 17), Account("1234", AccountType.EQUITIES), Quantity(50)).postings == [Posting(JournalEntry(date(2020, 6, 17), "", 0), date(2020, 6, 17), Account("1234", AccountType.EQUITIES), Direction.INC, Amount(50))]

# Generated at 2022-06-21 20:04:12.976691
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal = JournalEntry[str]('1970-01-01', 'Empty', 'Empty')
    posting = Posting(journal, '1970-01-01', Account(1, 'An Account', AccountType.ASSETS), Direction.INC, Amount(13))
    posting2 = Posting(journal, '1970-01-01', Account(1, 'An Account', AccountType.ASSETS), Direction.INC, Amount(13))
    posting3 = Posting(journal, '1970-01-01', Account(1, 'An Account', AccountType.ASSETS), Direction.INC, Amount(14))
    assert hash(posting) == hash(posting2)
    assert hash(posting) != hash(posting3)

# Generated at 2022-06-21 20:04:19.924074
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    Date = datetime.date
    guid = "15815c89-a7ee-4b49-8f27-eae6dc45b904"
    p = Posting(None, Date(2020, 1, 1), 0, Direction.INC, 100000)

    # This should fail
    def should_fail():
        p.date = Date(2019, 1, 1)
    from dataclasses import FrozenInstanceError
    # noinspection PyTypeChecker
    from pytest import raises
    with raises(FrozenInstanceError):
        should_fail()

    # This should pass
    p.guid = guid
    assert p.guid == guid

# Generated at 2022-06-21 20:04:23.381668
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass
    #p = Posting(journal=None, date=datetime.datetime(1,1,1), account=Account(name='', type=AccountType.INCOME), direction=Direction.INC, amount=Amount(0.0))
    #assert isinstance(p, Posting)

# Generated at 2022-06-21 20:04:32.769535
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert Posting(None, None, None, None, None).__delattr__("guid") == None
    assert Posting(None, None, None, None, None).__delattr__("journal") == None
    assert Posting(None, None, None, None, None).__delattr__("date") == None
    assert Posting(None, None, None, None, None).__delattr__("account") == None
    assert Posting(None, None, None, None, None).__delattr__("direction") == None
    assert Posting(None, None, None, None, None).__delattr__("amount") == None


# Generated at 2022-06-21 20:04:37.403112
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Get the instance of class JournalEntry
    journal_entry = JournalEntry[1]
    assert journal_entry.date == None
    assert journal_entry.description == None
    assert journal_entry.source == None
    assert journal_entry.postings == []
    assert journal_entry.guid != None


# Generated at 2022-06-21 20:05:04.534857
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from recordclass.tests.test_dataclasses import test_dataclass_field
    from datetime import date
    from .accounts import Account, AccountType
    from .commons.numbers import Quantity

    amount = Amount(Quantity(10))
    journal = JournalEntry(date.today(), "test", None)
    account = Account(AccountType.ASSETS, "123", "test", None)
    direction = Direction.INC
    posting = Posting(journal, date.today(), account, direction, amount)

    assert(posting.is_debit == 1)
    delattr(posting, 'is_debit')
    assert(posting.is_debit == 0)

    assert(posting.is_credit == 0)
    delattr(posting, 'is_credit')

# Generated at 2022-06-21 20:05:07.248115
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    print("Testing Posting.__delattr__()")
    assert False , "Test not implemented"
    print("Test successful")


# Generated at 2022-06-21 20:05:17.870983
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry[int](date=datetime.date(2018, 1, 1), description="JE-001", source=1) \
        == JournalEntry[int](date=datetime.date(2018, 1, 1), description="JE-001", source=2)
    assert JournalEntry[int](date=datetime.date(2018, 1, 1), description="JE-001", source=1) \
        != JournalEntry[int](date=datetime.date(2018, 1, 1), description="JE-002", source=1)
    assert JournalEntry[int](date=datetime.date(2018, 1, 1), description="JE-001", source=1) \
        != JournalEntry[str](date=datetime.date(2018, 1, 1), description="JE-001", source="1")

# vim:

# Generated at 2022-06-21 20:05:29.606927
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    journal_entry = JournalEntry(datetime.date(2020, 3, 1), "A journal entry", None)
    p1 = Posting(journal_entry, datetime.date(2020, 3, 1), Account("A101", "Current Assets"), Direction.INC, Amount(100))
    p2 = Posting(journal_entry, datetime.date(2020, 3, 1), Account("A101", "Current Assets"), Direction.INC, Amount(100))
    p3 = Posting(journal_entry, datetime.date(2020, 3, 2), Account("A101", "Current Assets"), Direction.INC, Amount(100))
    p4 = Posting(journal_entry, datetime.date(2020, 3, 1), Account("A101", "Current Assets"), Direction.DEC, Amount(100))

# Generated at 2022-06-21 20:05:30.553539
# Unit test for constructor of class Posting
def test_Posting():
    assert Posting("journal","date","account","direction","amount")


# Generated at 2022-06-21 20:05:40.832702
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je1 = JournalEntry(datetime.datetime.today(), 'Description1', 123, [Posting(je1, datetime.datetim.today(), Account('Account', AccountType.ASSETS, 'ParentAccount'), Direction.INC, Amount(1))])
    je2 = JournalEntry(datetime.datetime.today(), 'Description2', 123, [Posting(je1, datetime.datetim.today(), Account('Account', AccountType.ASSETS, 'ParentAccount'), Direction.INC, Amount(1))])
    jeHash1 = hash(je1)
    jeHash2 = hash(je2)
    assert(jeHash1 != jeHash2) == True

# Generated at 2022-06-21 20:05:42.298513
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert JournalEntry.__init__ is not object.__init__

# Generated at 2022-06-21 20:05:50.487106
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
  def test_case(args):
    journal_entry = args["journal_entry"]
    try:
      journal_entry.validate()
      assert True
    except AssertionError:
      assert False

  journal_entry = JournalEntry("date", "description", "source")
  test_case({"journal_entry": journal_entry})
  journal_entry = journal_entry.post("date", "account", 1)
  test_case({"journal_entry": journal_entry})
  journal_entry.postings[0].amount *= -1
  test_case({"journal_entry": journal_entry})

# Generated at 2022-06-21 20:05:54.754533
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    # Arrange
    example_posting = Posting(JournalEntry, datetime.date, Account, Direction, Amount)

    # Act
    result = hash(example_posting)

    # Assert
    assert result is not None


# Generated at 2022-06-21 20:06:06.564867
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    journal_1 = JournalEntry(date=datetime.date(2017, 6, 1), description='First journal entry')
    journal_2 = JournalEntry(date=datetime.date(2017, 6, 2), description='Second journal entry')
    entry_1 = Posting(journal=journal_1, date=datetime.date(2017, 6, 1), account=Account(name='AccountsReceivable',
                                                                                        type=AccountType.ASSETS),
                      direction=Direction.INC, amount=100)
    entry_2 = Posting(journal=journal_2, date=datetime.date(2017, 6, 2), account=Account(name='AccountsReceivable',
                                                                                        type=AccountType.ASSETS),
                      direction=Direction.INC, amount=100)