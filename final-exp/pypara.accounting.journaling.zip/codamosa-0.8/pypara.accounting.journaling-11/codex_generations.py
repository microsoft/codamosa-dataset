

# Generated at 2022-06-12 05:48:44.119944
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j1 = JournalEntry(date=datetime.date(2020, 1, 1), description="test_validate_journal_entry")
    j1.post(date=datetime.date(2020, 1, 1), account=Account(code="0000", name="cash", type=AccountType.ASSETS), quantity=13)
    j1.post(date=datetime.date(2020, 1, 1), account=Account(code="0003", name="income", type=AccountType.REVENUES), quantity=+13)
    j1.validate()

    j2 = JournalEntry(date=datetime.date(2020, 1, 1), description="test_validate_journal_entry")

# Generated at 2022-06-12 05:48:45.772263
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # need to implement
    pass

# Generated at 2022-06-12 05:48:55.030535
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    '''This function should be used as unit test for method __call__ of class ReadJournalEntries'''
    from datetime import date
    from dateutil.relativedelta import relativedelta

# Generated at 2022-06-12 05:48:56.461141
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries.__call__(None, None)


# Generated at 2022-06-12 05:49:07.654098
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal = JournalEntry[int]()
    journal.post(date=datetime.date(2020, 1, 2), account=Account(1001, 'Expenses', AccountType.EXPENSES), quantity=10)
    journal.post(date=datetime.date(2020, 1, 2), account=Account(1002, 'Revenues', AccountType.REVENUES), quantity=-10)
    journal.validate()
    journal.post(date=datetime.date(2020, 1, 2), account=Account(1002, 'Revenues', AccountType.REVENUES), quantity=10)
    try:
        journal.validate()
        assert False, 'Exception expected'
    except AssertionError:
        pass


# Generated at 2022-06-12 05:49:18.527460
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import ChartOfAccounts, Category, Account
    from .postings import JournalEntry, Increment, Decrement
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Quantity, Amount

    journalEntry = JournalEntry()
    journalEntry.date = "2020-09-01"
    journalEntry.description = "test"
    journalEntry.post("2020-09-01", Account(1, "cash", "", "", ""), Quantity(100))
    journalEntry.post("2020-09-01", Account(2, "revenue", "", "", ""), Quantity(-100))
    journalEntry.post("2020-09-01", Account(3, "equity", "", "", ""), Quantity(-100))

# Generated at 2022-06-12 05:49:29.173626
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    @dataclass(frozen=True)
    class TestBizObject:
        pass

    @dataclass(frozen=True)
    class TestPosting(Generic[TestBizObject]):
        journal: JournalEntry[TestBizObject]
        date: datetime.date
        account: Account
        direction: Direction
        amount: Amount

    @dataclass(frozen=True)
    class TestJournalEntry(Generic[TestBizObject]):
        date: datetime.date
        description: str
        source: TestBizObject
        postings: List[Posting[TestBizObject]] = field(default_factory=list, init=False)
        guid: Guid = field(default_factory=makeguid, init=False)


# Generated at 2022-06-12 05:49:36.240708
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountName
    from .currencies import Inr, Currencies
    from .database import Database
    from .exchange import ExchangeRate
    
    db = Database(":memory:")
    Inr(db)
    Currencies.setdefault(db)
    ExchangeRate(db).post(Inr, Inr.now, 1.0)
    

# Generated at 2022-06-12 05:49:46.069737
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    a1 = Account("X")
    a2 = Account("Y")
    a1_1 = Account("A", AccountType.ASSETS)
    a1_2 = Account("B", AccountType.ASSETS)
    a1_3 = Account("C", AccountType.ASSETS)
    a2_1 = Account("D", AccountType.LIABILITIES)
    a2_2 = Account("E", AccountType.LIABILITIES)
    a2_3 = Account("F", AccountType.LIABILITIES)
    r1 = Account("G", AccountType.REVENUES)
    r2 = Account("H", AccountType.REVENUES)
    e1 = Account("I", AccountType.EXPENSES)
    e2 = Account("J", AccountType.EXPENSES)

# Generated at 2022-06-12 05:49:56.906055
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import datetime
    from xledger.domain.accounts import Account
    from xledger.domain.accounts import AccountType

    def make_account() -> Account:
        return Account(
            type=AccountType.ASSETS, description="A description", name="A name", currency="DKK", account_number=1234
        )

    journal_entry = JournalEntry[str](date=datetime.date(2019, 3, 24), description="A description", source="Some source")
    account = make_account()
    journal_entry.post(date=datetime.date(2019, 3, 24), account=account, quantity=10)
    journal_entry.post(date=datetime.date(2019, 3, 24), account=account, quantity=-10)
    journal_entry.validate()
    assert True

# Generated at 2022-06-12 05:50:11.664311
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    print("In test_JournalEntry_post")
    je = JournalEntry("test_journal", "test_JournalEntry_post", "test_source")
    je.post(datetime.date.today(), Account("test", AccountType.ASSETS), Quantity(1000))
    je.validate()


# Generated at 2022-06-12 05:50:19.705603
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType
    from .businessobjects import Entity, Event

    event1 = Event(name="Eve1")
    event2 = Event(name="Eve2")

    entity1 = Entity(name="Foo", category="Bar")
    entity2 = Entity(name="NFL", category="Times")

    asset1 = Account("ASSET1", AccountType.ASSETS)
    expense1 = Account("EXPENSE1", AccountType.EXPENSES)
    expense2 = Account("EXPENSE2", AccountType.EXPENSES)
    liability = Account("LIABILITY", AccountType.LIABILITIES)
    revenue = Account("REVENUE", AccountType.REVENUES)


# Generated at 2022-06-12 05:50:31.661053
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account
    from .accounts import AccountType
    from .types import SimpleJournalEntryObject

    # Create journal entries:
    j1 = JournalEntry(date=datetime.date(2020, 10, 2), description="J1", source=SimpleJournalEntryObject())
    j1.post(date=datetime.date(2020, 10, 2), account=Account("A1", AccountType.ASSETS), quantity=+100)
    j1.post(date=datetime.date(2020, 10, 2), account=Account("A2", AccountType.EXPENSES), quantity=-100)

    j2 = JournalEntry(date=datetime.date(2020, 10, 3), description="J2", source=SimpleJournalEntryObject())

# Generated at 2022-06-12 05:50:35.672846
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def rje_func(period: DateRange) -> Iterable[JournalEntry[str]]:
        return []

    assert ReadJournalEntries.__call__(rje_func, DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))) == []

# Generated at 2022-06-12 05:50:43.111265
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime
    from dataclasses import dataclass
    from typing import Iterable
    from unittest.mock import Mock
    
    @dataclass(frozen=True)
    class SamplePeriod:
        """
        Specifies a period.
        """

        start_date: datetime.date
        end_date: datetime.date

    #: Data for the test.
    def test_data():
        journal_entry1 = Mock()
        journal_entry2 = Mock()
        journal_entry3 = Mock()
        journal_entry4 = Mock()
        journal_entry5 = Mock()

        journal_entry1.date = datetime.date(2020, 1, 1)
        journal_entry2.date = datetime.date(2020, 1, 2)

# Generated at 2022-06-12 05:50:51.672712
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .currencies import Currency

    journal_entry = JournalEntry('date', 'description', 'source')
    date = datetime.date.today()
    account = Account('Name', AccountType.ASSETS, Currency.USD)

    # Test post with quantity = 0
    quantity = 0
    journal_entry.post(date, account, quantity)
    assert journal_entry.postings == []
    
    # Test post with quantity > 0
    quantity = 2
    journal_entry.post(date, account, quantity)
    assert journal_entry.postings == [Posting(journal_entry, date, account, Direction.INC, Amount(2))]
    
    # Test post with quantity < 0
    quantity = -2
    journal_entry.post(date, account, quantity)

# Generated at 2022-06-12 05:51:00.141612
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import Date
    from ..commons.numbers import ZERO, ONE, TEN

    @dataclass(frozen=True)
    class Foo:
        """
        Just a test class.
        """

        pass

    je = JournalEntry[Foo](date = Date(2018, 7, 1), description = "Some description", source = Foo())
    je.post(Date(2018, 7, 1), Account(AccountType.EQUITIES, "First"), ZERO)
    je.post(Date(2018, 7, 1), Account(AccountType.EQUITIES, "Second"), ONE)
    je.post(Date(2018, 7, 1), Account(AccountType.EQUITIES, "Third"), TEN)


# Generated at 2022-06-12 05:51:08.211429
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry1 = JournalEntry(datetime.date(2020, 10, 3), "Test", 1)
    journal_entry1.post(datetime.date(2020, 10, 3), Account(1, "Debit", AccountType.EQUITIES), Amount(500))
    journal_entry1.post(datetime.date(2020, 10, 3), Account(2, "Credit", AccountType.EXPENSES), Amount(500))
    journal_entry1.validate()

    journal_entry2 = JournalEntry(datetime.date(2020, 10, 3), "Test", 1)
    journal_entry2.post(datetime.date(2020, 10, 3), Account(1, "Debit", AccountType.EQUITIES), Amount(500))

# Generated at 2022-06-12 05:51:11.915591
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Define ReadJournalEntries instance.
    def readJournalEntries(period: DateRange) -> Iterable[JournalEntry[Account]]:
        return ()

    # Test method __call__.
    readJournalEntries(DateRange())

# Generated at 2022-06-12 05:51:21.552310
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    a = JournalEntry(datetime.date(2018, 1, 1), "ABC", datetime.date(2018, 1, 1))
    a = a.post(datetime.date(2018, 1, 1), Account("ABC", AccountType.EQUITIES), -100)
    a = a.post(datetime.date(2018, 1, 1), Account("ABC", AccountType.ASSETS), 100)
    a = a.post(datetime.date(2018, 1, 1), Account("ABC", AccountType.ASSETS), 9)
    a = a.post(datetime.date(2018, 1, 1), Account("ABC", AccountType.ASSETS), -9)
    assert len(a.postings) == 2
    assert a.postings[0].account.name == "ABC"

# Generated at 2022-06-12 05:51:36.389957
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account
    from .ledgers import AccountBook, Ledger, ReadLedger, ReadLedgers

    class ReadLedgersImpl(ReadLedgers):
        def __call__(self, book: AccountBook) -> Iterable[Ledger]:
            ...

    class ReadLedgerImpl(ReadLedger):
        def __call__(self, name: str) -> Ledger:
            ...

    class ReadJournalEntriesImpl(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            ...

    def foo(book: AccountBook, period: DateRange) -> None:
        #: Fetches all the ledgers in the book:
        read_ledgers = ReadLedgersImpl()

# Generated at 2022-06-12 05:51:40.739433
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .ledgers import Ledger, LedgerAccount

    #: Define custom `AssertionError` for possible assertion errors in validating journal entries.
    class InvalidJournalEntry(AssertionError):
        """
        A catch-all exception for assertion errors in validating journal entries.
        """

# Generated at 2022-06-12 05:51:45.037208
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal=JournalEntry[int]("2020-02-29", "test-description", 1)
    journal.post(datetime.date.today(), Account("acc1", AccountType.ASSETS), 10)
    journal.post(datetime.date.today(), Account("acc2", AccountType.REVENUES), -10)
    try:
        journal.validate()
    except AssertionError as e:
        assert f"Total Debits and Credits are not equal: 10 != 10" == str(e)
        return
    assert False

# Generated at 2022-06-12 05:51:53.934344
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .business import Purchase
    from .business import OpenPurchase, ClosePurchase, Payment
    from datetime import date
    t1_purchasing = Account("PURCHASING")
    t2_Purchasing_Expenses = Account("Purchasing Expenses")
    t3_PURCHASING_EXPENSES_CASH = Account("PURCHASING EXPENSES CASH", AccountType.EQUITIES)
    t4_PURCHASING_EXPENSES_ACCRUED = Account("PURCHASING EXPENSES ACCRUED", AccountType.EQUITIES)
    t5_PURCHASING_EXPENSES_CASH_OUT = Account("PURCHASING EXPENSES CASH OUT", AccountType.EQUITIES)
    t6_PUR

# Generated at 2022-06-12 05:52:04.529734
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    @dataclass(frozen=True)
    class T:
        pass

    test_journal = JournalEntry(date=datetime.date.today(), description="test", source=T())
    account_name = "test_account"
    test_account = Account(account_name)
    test_amount = 250
    test_quantity = Quantity(test_amount)

    test_journal.post(datetime.date.today(), test_account, test_quantity)
    assert len(test_journal.postings) == 1
    assert test_journal.postings[0].account.code == account_name
    assert test_journal.postings[0].amount.value == test_amount



# Generated at 2022-06-12 05:52:11.175684
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import create_account
    from .business import create_journal, create_ledger
    from .common_ledger import CommonLedger
    from .reader import read_ledger

    ## Create a journal entry:
    journal = create_journal(
        date=datetime.date(2020, 1, 1),
        description="Revenue",
        source=create_ledger(period=DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2))),
    )
    journal.post(
        date=datetime.date(2020, 1, 1),
        account=create_account(
            name="Cash On Hand",
            type=AccountType.ASSETS,
            ledger=read_ledger(CommonLedger),
        ),
        quantity=+Amount(100),
    )


# Generated at 2022-06-12 05:52:19.151803
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class BusinessObject:
        pass

    my_account = Account(
        account_id=makeguid(),
        description="My Account",
        type=AccountType.ASSETS
    )
    journal_entry = JournalEntry[BusinessObject](
        date=datetime.date.today(),
        description="This is my journal entry",
        source=BusinessObject(),
        postings=[]
    )
    journal_entry.post(
        date=datetime.date.today(),
        account=my_account,
        quantity=1
    )
    assert journal_entry.postings[0].account == my_account
    assert journal_entry.postings[0].amount == 1

# Generated at 2022-06-12 05:52:24.230758
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange

    from .accounts import Account

    p = ReadJournalEntries[str](lambda arg: ())
    assert isinstance(p(DateRange(datetime.date(1, 1, 1), datetime.date(1, 1, 2))), Iterable[JournalEntry[str]])

# Generated at 2022-06-12 05:52:33.583557
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType, AccountsRepository
    accounts: AccountsRepository = AccountsRepository([
        Account(AccountType.ASSETS, "Cash", "Cash balance"),
        Account(AccountType.EQUITIES, "Rohan", "Rohan's equity"),
        Account(AccountType.LIABILITIES, "Debts", "Outstanding debt"),
        Account(AccountType.REVENUES, "Revenues", "Total revenue"),
        Account(AccountType.EXPENSES, "Expenses", "Total expenses"),
    ])
    journal_entry: JournalEntry = JournalEntry(datetime.date.today(), "Transfer from Rohan to pay off debts", accounts["Rohan"])
    journal_entry.post(datetime.date.today(), accounts["Cash"], Quantity(10))

# Generated at 2022-06-12 05:52:43.766897
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import AccountType

    class PostsHolder:
        def __init__(self):
            self.posts = []

        def post(self, date: date, account: Account, quantity: int) -> 'ReadJournalEntries':
            self.posts.append((date, account, quantity))
            return self

        def read_journal_entries(self, period: DateRange) -> Iterable[JournalEntry]:
            j = JournalEntry(self.posts[0][0], "", self)
            for p in self.posts:
                j.post(p[0], p[1], p[2])
            return [j]

    # Arrange
    ASSETS = Account.create("Assets", AccountType.ASSETS)

# Generated at 2022-06-12 05:53:01.101050
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass, asdict

    # Define a model for testing:
    @dataclass(frozen=True)
    class Foo:
        _name: str

    # Define a journal entry reader for testing:

# Generated at 2022-06-12 05:53:12.748978
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import timedelta

    from .accounts import AccountType

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        yield JournalEntry(
            date=period.end_date - timedelta(days=1),
            description="",
            source="",
        ).post(
            date=period.start_date,
            account=Account(AccountType.ASSETS, ""),
            quantity=1000,
        ).post(
            date=period.start_date,
            account=Account(AccountType.EXPENSES, ""),
            quantity=-1000,
        )

    period = DateRange.of(
        start_date=datetime.date(2019, 1, 1),
        end_date=datetime.date(2019, 1, 3),
    )

    assert read_

# Generated at 2022-06-12 05:53:24.681666
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..ledger.accounts import AccountType, Account, AccountOwner
    from ..ledger.books import Book
    from ..ledger.ledgers import Ledger, LedgerEntry
    from ..ledger.customers import Customer, CustomerSource
    from ..ledger.invoices import Invoice, InvoiceType, InvoiceStatus, InvoiceLine
    from ..ledger.products import Product, ProductCategory
    from ..ledger.receivables import Receivable, ReceivableSource
    from ..ledger.payables import Payable, PayableSource
    from ..ledger.payments import Payment, PaymentSource
    from ..ledger.billings import Billing, BillingLine, BillingSource
    from ..ledger.transactions import Transaction, TransactionLine, TransactionType
    from ..ledger.transfers import Transfer, TransferSource

    # Create test

# Generated at 2022-06-12 05:53:36.948970
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from .accounts import AccountType

    from ..commons.numbers import Amount, Quantity

    class Sample:
        pass
    sample = Sample()

    entry = JournalEntry(date(2020, 8, 6), 'asdfghjkl', sample)
    assert entry.postings == []

    account_asset = Account('Assets', 'Cash', AccountType.ASSETS)
    account_expense = Account('Expenses', 'Travel', AccountType.EXPENSES)

    entry.post(date(2020, 8, 6), account_asset, Quantity(10000))
    assert entry.postings == [
        Posting(entry, date(2020, 8, 6), account_asset, Direction.INC, Amount(10000)),
    ]


# Generated at 2022-06-12 05:53:43.676180
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je: JournalEntry[int] = JournalEntry(date=datetime.date(2020, 10, 11), description="Test journal entry", source=0)
    je.post(date=datetime.date(2020, 10, 11), account=Account(type=AccountType.ASSETS, alias="Cash"), quantity=-10000000)
    je.post(date=datetime.date(2020, 10, 11), account=Account(type=AccountType.REVENUES, alias="Fees Received"), quantity=1500000)
    je.validate()

    assert True

# Generated at 2022-06-12 05:53:55.088864
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    t1 = datetime.date(2019, 12, 31)
    t2 = datetime.date(2019, 12, 1)
    a1 = Account("EXPENSES:COMMISSIONS", AccountType.EXPENSES)
    a2 = Account("ASSETS:CASH", AccountType.ASSETS)
    q1 = Quantity(100)
    q2 = Quantity(-200)
    j1 = JournalEntry(date=t1, description = "Commissons paid for sales done in the month", source = "SALES")
    je1 = j1.post(date=t2, account=a1, quantity=q1)
    je2 = j1.post(date=t2, account=a2, quantity=q2)
    assert(je1.postings[0].account == a1)

# Generated at 2022-06-12 05:54:03.790513
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Sign
    from ..commons.others import SafeSet
    from .accounts import AccountType
    import datetime

    j1 = JournalEntry[str](date=datetime.date(2018, 1, 1), description='purchase', source="sp1")
    j1 = j1.post(datetime.date(2018, 1, 1), Account('bob', AccountType.ASSETS, Sign.DEBIT, SafeSet()),  10)
    j1 = j1.post(datetime.date(2018, 1, 1), Account('expenses', AccountType.EXPENSES, Sign.DEBIT, SafeSet()),  10)
    assert j1.credit == 20
    assert j1.debit == 20

# Generated at 2022-06-12 05:54:04.944487
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    get_journal_entries = ReadJournalEntries.__call__


# Generated at 2022-06-12 05:54:11.876939
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountNumber, AccountType, BusinessAccount, Chart

    chart = Chart([
        BusinessAccount(AccountNumber('101'), 'Bank Account', AccountType.ASSETS),
        BusinessAccount(AccountNumber('102'), 'Cash Account', AccountType.ASSETS),
        BusinessAccount(AccountNumber('201'), 'Sales', AccountType.REVENUES),
        BusinessAccount(AccountNumber('202'), 'Retained Earnings', AccountType.EQUITIES),
        BusinessAccount(AccountNumber('301'), 'Payroll Expense', AccountType.EXPENSES),
        BusinessAccount(AccountNumber('401'), 'Accounts Receivable', AccountType.ASSETS),
    ])


# Generated at 2022-06-12 05:54:14.602964
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    dr = JournalEntry.post(self, date, account, quantity)
    assert dr == JournalEntry.post
    assert dr == JournalEntry.post


# Generated at 2022-06-12 05:54:37.729505
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    business_obj = "business_obj"
    je = JournalEntry[str](datetime.date.today(), "description", business_obj)
    acc = Account("account", AccountType.ASSETS)
    je.post(datetime.date.today(), acc, 100)
    assert je.postings[0].amount == Amount(100)
    assert je.postings[0].is_debit == True
    assert je.postings[0].is_credit == False

# Generated at 2022-06-12 05:54:44.488274
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
        je = JournalEntry(datetime.date(day=1, month=1, year=2020), "t1", "t2")
        je.post(datetime.date(day=1, month=1, year=2020), Account(None, None), Quantity(3))
        je.post(datetime.date(day=1, month=1, year=2020), Account(None, None), Quantity(-3))

# Generated at 2022-06-12 05:54:55.454660
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    accounts: Dict[str, Account] = {
        "John": Account("John", AccountType.ASSETS, "Liabilities"),
        "Utility": Account("Utility", AccountType.EXPENSES, "Expenses"),
    }

    # Create journal entry:
    journal: JournalEntry[str] = JournalEntry(date=datetime.date(2020, 1, 1), description="Test", source="receipt")
    journal.post(date=datetime.date(2020, 1, 1), account=accounts["John"], quantity=-5)
    journal.post(date=datetime.date(2020, 1, 1), account=accounts["Utility"], quantity=5)

    # Validate:
    journal.validate()

# Generated at 2022-06-12 05:55:06.945830
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .common import DateRange, NoSource, init_basic_accounts, load_sample_journal_entries
    
    def assertJournalEntry(date, description, account, amount):
        assert journal.date == date
        assert journal.description == description
        assert journal.source == NoSource
        assert journal.postings[0].date == date
        assert journal.postings[0].account == account
        assert journal.postings[0].amount == amount
        assert journal.postings[0].direction == Direction.INC


    #set Up
    init_basic_accounts()
    journal = JournalEntry(NoSource)
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))
    sample_journal_entries = load_sample_journal_

# Generated at 2022-06-12 05:55:16.468457
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from random import choice
    from datetime import date

    class MockEntry(JournalEntry[object]):

        def __init__(self, date: date) -> None:
            super().__init__(date, "Description", object, [])

        def validate(self) -> None:
            pass

    def read(start: date, end: date) -> Iterable[JournalEntry[object]]:
        for year in range(start.year, end.year + 1):
            for month in range(1, 13):
                if start.month <= month <= end.month:
                    yield MockEntry(date(year, month, choice(range(1, 28))))

    # noinspection DuplicatedCode

# Generated at 2022-06-12 05:55:17.378133
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-12 05:55:23.439470
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    entry = JournalEntry(datetime.date(2020, 2, 1), "Test Entry", None)
    entry.post(datetime.date(2020, 2, 1), Account("Test Acc", None, AccountType.ASSETS), -1000)
    entry.post(datetime.date(2020, 2, 1), Account("Test Acc", None, AccountType.LIABILITIES), 1000)
    assert len(entry.postings) == 2



# Generated at 2022-06-12 05:55:29.784098
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from unittest.mock import MagicMock
    from .accounts import Account, AccountType
    read_journal_entries = ReadJournalEntries()
    journal_entries = read_journal_entries(MagicMock())
    assert issubclass(journal_entries.__class__, Iterable)

# Generated at 2022-06-12 05:55:37.047297
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .global_posting_rules import PostingRules
    from .globals import Globals
    globals = Globals()
    rules = PostingRules.get(globals)
    account1 = Account(
        code="000001",
        name="Cash",
        type=AccountType.ASSETS,
        rules=rules
    )
    account2 = Account(
        code="000002",
        name="Salaries and Wages",
        type=AccountType.EXPENSES,
        rules=rules
    )
    journal = JournalEntry(
        date=datetime.date.today(),
        description="Test Journal Entry",
        source=None
    )
    journal.post(datetime.date.today(), account1, Quantity(2000.00))

# Generated at 2022-06-12 05:55:45.297167
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False


if __name__ == "__main__":
    # NOTE:
    # Use the following command to run unit tests on this module.
    # (If invoked from an IDE, don't forget to configure build command as "-m unittest" for the project first!)
    #
    #     python -m unittest -v test_journals
    #
    import unittest

    from testcommons import get_any_account, get_any_amount, get_any_business_object, get_any_date, \
        get_any_journal_entry

    class TestJournals(unittest.TestCase):
        def test_Direction_of(self):
            assert Direction.of(3) is Direction.INC
            assert Direction.of(-5) is Direction.DEC


# Generated at 2022-06-12 05:56:30.531260
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, build_chart_of_accounts
    from ..milestones.models import Milestone
    from ..narratives.models import Narrative
    from ..transactions.models import Party, QuantityType

    ## Make test data:
    chart = build_chart_of_accounts()
    narrative1 = Narrative(name="Narrative1")
    narrative2 = Narrative(name="Narrative2")

    # Transaction:
    # Journal entry 1: Loan from A to B.
    # Journal entry 2: Carriage charges (non-taxable) by A.
    # Journal entry 3: Sales to B.
    partyA = Party(name="Party A")
    partyB = Party(name="Party B", address="Address")

# Generated at 2022-06-12 05:56:41.186815
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Current scope
    scope = locals()
    # Define a ReadJournalEntries instance
    ReadJournalEntriesInstance = ReadJournalEntries.__subclass__()
    # Define a mock_date_range
    mock_date_range = DateRange('date1', 'date2')
    # Define a mock_journal_entry
    mock_journal_entry = JournalEntry[int]()
    # Define a mock_iterable
    mock_iterable = [mock_journal_entry]
    # Record the return value of ReadJournalEntries.__call__
    scope['return_value'] = [mock_journal_entry]
    # ReadJournalEntries.__call__(period) returns an iterable of JournalEntry for a given period
    assert (ReadJournalEntriesInstance(mock_date_range) == mock_iterable)

# Generated at 2022-06-12 05:56:51.296044
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass
    class Person:
        date: datetime.date
        first_name: str
        last_name: str
    def read_persons(period: DateRange) -> Iterable[JournalEntry[Person]]:
        yield JournalEntry(date = datetime.date(2018, 9, 4),
                           description = "New Person: John Doe",
                           source = Person(datetime.date(2018, 9, 4), "John", "Doe"))
        yield JournalEntry(date = datetime.date(2018, 9, 4),
                           description = "New Person: Jane Doe",
                           source = Person(datetime.date(2018, 9, 4), "Jane", "Doe"))

# Generated at 2022-06-12 05:56:59.784657
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .commons import currency
    from .journal import JournalEntry

    acc = Account('1', 'Cash', AccountType.ASSETS, currency)

    cr = JournalEntry(date='2020-11-01', description='CR')
    # Posting 1
    cr.post(date='2020-11-01', account=acc, quantity=100)
    # Posting 2
    cr.post(date='2020-11-01', account=acc, quantity=-50)
    print(cr)


# Generated at 2022-06-12 05:57:08.642661
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .tags import Tag
    from .targets import Target
    from .transactions import DebitCredit
    from .ledgers import Ledger, Posting

    def post_income(ledger: Ledger, date: datetime.date, amount: Amount, source: Target) -> JournalEntry:
        """
        Posts income.
        """
        journal = JournalEntry(date, "Income", source)
        journal.post(date, ledger.income, amount)
        journal.post(date, ledger.balance, amount)
        return journal

    target = Target(name="Target", tags=[Tag("Tag")])
    ledger = Ledger(name="Ledger", amount_type=Amount, target_type=target)

# Generated at 2022-06-12 05:57:18.425577
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import cast
    from ..commons.zeitgeist import datetoday

    @dataclass
    class _Source:
        guid: Guid
    
    source1 = _Source(makeguid())
    source2 = _Source(makeguid())
    source3 = _Source(makeguid())
    source4 = _Source(makeguid())
    source5 = _Source(makeguid())
    source6 = _Source(makeguid())
    source7 = _Source(makeguid())
    source8 = _Source(makeguid())
    source9 = _Source(makeguid())
    source10 = _Source(makeguid())
    

# Generated at 2022-06-12 05:57:28.513643
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..ledger.accounts import AccountRepository
    from ..ledger.accounts import AccountType
    from ..ledger.accounts import ACCOUNT_TYPE_NAMES

    account_repo = AccountRepository(len(ACCOUNT_TYPE_NAMES), ACCOUNT_TYPE_NAMES)

    test_date = datetime.date(2020, 2, 29)  # The only leap day this century.

    # Create the test account:
    acc: Account = account_repo.get("EQUITY", "Retained Earnings").specify("USD")

    # Create and post a journal entry:
    je = JournalEntry("This is a Journal Entry")
    je.post(test_date, acc, 100)

    # Test:
    assert len(je.postings) == 1
    assert je.postings[0].amount == Amount

# Generated at 2022-06-12 05:57:39.192025
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from dataclasses import dataclass
    from enum import Enum
    from typing import List
    from datetime import date
    from .accounts import Account

    #: Defines a type variable.
    _T = TypeVar("_T")

    #: Defines a type variable.
    _An = TypeVar("_An")

    #: Provides a journal entry model.
    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.

# Generated at 2022-06-12 05:57:45.495501
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import account
    from .budgets import Budget
    from .cost_centers import CostCenter
    from .projects import Project

    journal = JournalEntry(datetime.date(2020, 1, 1), "Test transaction", None)
    journal.post(datetime.date(2020, 1, 1), account(CostCenter(Budget(), Project()), "12100"), 50)
    journal.validate()
    assert journal.postings[0].amount == Amount(50)


# Generated at 2022-06-12 05:57:57.129796
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    print("Method post for class JournalEntry")
    revenue_acct = Account("Revenue")
    asset_acct = Account("Asset")
    expense_acct = Account("Expense")
    liability_acct = Account("Liability")
    customers=["customer1","customer2","customer3"]
    je = JournalEntry("",customers[0] )
    je.post("2018-12-31", revenue_acct,100)
    je.post("2018-12-31", asset_acct,100)
    je.post("2018-12-31", expense_acct,100)
    je.post("2018-12-31", liability_acct,100)
    assert len(je.postings) == 4
    #print(je.postings)
    #assert je