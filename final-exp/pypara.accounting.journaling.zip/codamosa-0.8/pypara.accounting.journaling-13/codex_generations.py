

# Generated at 2022-06-12 05:48:37.969127
# Unit test for method __call__ of class ReadJournalEntries

# Generated at 2022-06-12 05:48:43.021071
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    def _read(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    assert issubclass(ReadJournalEntries[_T], Iterable[JournalEntry[_T]])
    assert _read is ReadJournalEntries[_T]

    assert isinstance(_read, ReadJournalEntries[_T])

# vim: et:sw=4:syntax=python:ts=4:

# Generated at 2022-06-12 05:48:53.565774
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    i = JournalEntry[str]('2018-08-01', 'For testing', '', [])
    i.post(datetime.datetime(2018, 8, 1), Account("ASSETS", AccountType.ASSETS, ""), 100)
    i.post(datetime.datetime(2018, 8, 1), Account("EXPENSES", AccountType.EXPENSES, ""), -100)
    i.validate()
    # Test for error scenario in validate
    i.post(datetime.datetime(2018, 8, 1), Account("EXPENSES", AccountType.EXPENSES, ""), -100)
    try:
        i.validate()
    except AssertionError:
        print("Error Scenario Validated: Debits and Credits are not equal!")

# Generated at 2022-06-12 05:49:05.939538
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup
    bj_id1 = 'b1'
    bj_entry1 = JournalEntry(datetime.date(2021, 1, 1), 'bj1', bj_id1)
    bj_entry2 = JournalEntry(datetime.date(2021, 1, 1), 'bj2', bj_id1)

    # Invoke
    bj_entry1.post(datetime.date(2021, 1, 1), Account.assets('cash'), Quantity(100))
    bj_entry2.post(datetime.date(2021, 1, 1), Account.revenues('revenues'), Quantity(100))

    # Assert
    assert len(list(bj_entry1.debits)) == 1
    assert len(list(bj_entry1.credits)) == 0

# Generated at 2022-06-12 05:49:12.358423
# Unit test for method post of class JournalEntry

# Generated at 2022-06-12 05:49:24.330946
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import mock

    from ..commons.zeitgeist import DateRange
    from .accounts import AccountType

    journal_entry1 = JournalEntry[DateRange](
        date=date(2020, 4, 1),
        description="This is journal entry 1",
        source=date(2020, 4, 1),
        postings=[
            Posting(journal_entry1, date(2020, 4, 1), Account("Cash", AccountType.ASSETS), Direction.INC, Amount(321.45)),
            Posting(journal_entry1, date(2020, 4, 1), Account("Exchange Expense", AccountType.EXPENSES), Direction.DEC, Amount(321.45)),
        ],
    )

# Generated at 2022-06-12 05:49:30.859702
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from unittest import mock
    from ..commons.zeitgeist import DateRange

    # Given: A mocked journal entry reader which does nothing
    reader = mock.Mock(spec=ReadJournalEntries[int])
    reader.return_value = None

    # When: I call the reader
    reader(DateRange.over(2020, 1, 1))

    # Then:
    # ... I should get a call to __call__
    reader.assert_called_once_with(DateRange.over(2020, 1, 1))

# Generated at 2022-06-12 05:49:34.996239
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import Date

    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[object]]:
        return [JournalEntry(datetime.date(2020, 1, 1), "", object())]
    assert list(_read_journal_entries(Date(2020, 1, 1)))
    assert not list(ReadJournalEntries.__call__(ReadJournalEntries, Date(2020, 1, 1)))

# Generated at 2022-06-12 05:49:43.539704
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .business import Sale

    sale = Sale(quantity=1, price=10)

    journal_entry = JournalEntry[Sale](date=datetime.date.today(), description="test", source=sale)

    journal_entry = journal_entry.post(date=datetime.date.today(), account=Account.ASSETS.CASH, quantity=10)
    journal_entry = journal_entry.post(date=datetime.date.today(), account=Account.REVENUES.SALES, quantity=-10)

    assert len(journal_entry.postings) == 2
    assert len(journal_entry.increments) == 1
    assert len(journal_entry.decrements) == 1

# Generated at 2022-06-12 05:49:53.897127
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import datetime
    from dataclasses import dataclass
    from mymoney.ledger.domain import Direction
    from mymoney.ledger.domain.accounts import Account

    @dataclass  # type: ignore
    class Foo:
        pass

    # Test 1:
    journal = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test",
        source=Foo(),
    ).post(date=datetime.date(2020, 1, 1), account=Account("A", AccountType.ASSETS), quantity=1)

    journal.validate()

    # Test 2:

# Generated at 2022-06-12 05:50:07.577387
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime as dt
    from ..commons.numbers import Quantity as Q
    from .accounts import Account, AccountType
    from .accounts.read import ReadAccounts

    @dataclass
    class Income(Generic[_T]):
        """
        Provides an income business object model.
        """

        #: Description to take note of the income.
        description: str

        #: Value of the income.
        amount: Amount

        #: Account to record the income.
        account: Account

        #: Date of the income.
        date: datetime.date

    #: Function to read accounts.

# Generated at 2022-06-12 05:50:14.773454
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
   je1 = JournalEntry[str](date=datetime.date.today(), description="Unit testing", source='string data')
   je1.post(date= datetime.date.today(), account=Account("1010", "", "", "", "", "", ""), quantity=1000)
   je1.post(date= datetime.date.today(), account=Account("2020", "", "", "", "", "", ""), quantity=-1000)
   je1.validate()

# Generated at 2022-06-12 05:50:20.922648
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry = JournalEntry(
        date=datetime.date(2018, 4, 21),
        description="A Test Journal Entry",
        source=None,
    )
    journal_entry.post(datetime.date(2018, 4, 21), Account("checking"), Quantity(5))
    journal_entry.post(datetime.date(2018, 4, 21), Account("saving"), Quantity(-5))
    journal_entry.validate()

# Generated at 2022-06-12 05:50:33.117600
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from dataclasses import asdict
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType, makeaccount

    ck = makeaccount(AccountType.ASSETS, "Cash")
    mm = makeaccount(AccountType.ASSETS, "Marketable Securities")
    r = makeaccount(AccountType.REVENUES, "Revenues")
    e = makeaccount(AccountType.EXPENSES, "Expenses")

    je = JournalEntry(date=datetime.date(2018, 12, 31), description="Test")

    je.post(je.date, ck, +100).post(je.date, mm, -50).post(je.date, r, +150).post(je.date, e, -150)

    je.validate()

    asdict(je)


# Generated at 2022-06-12 05:50:41.943376
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account
    from .journal import Journal
    from .accounts_repository import AccountsRepository
    from .currency import Currency
    from .commons.collections import new_list
    from .commons.zeitgeist import Date
    from .journal_repository import JournalRepository
    # endregion

    # region Setup:
    accounts_repository = AccountsRepository()

    journal_repository = JournalRepository()
    journal_repository.accounts_repository = accounts_repository

    journal_repository.register(Journal.get_account_creating_posting)
    journal_repository.register(Journal.get_amount_adjusting_posting)
    journal_repository.register(Journal.get_amount_transferring_posting)
    # endregion

# Generated at 2022-06-12 05:50:51.200689
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_account1 = Account('Assets', 'Accounts receivable', AccountType.ASSETS)
    test_account2 = Account('Revenues', 'Interests', AccountType.REVENUES)
    test_posting1 = Posting(journal='journal1', #no idea what it is for
                            date=datetime.date(2000,1,1),
                            account=test_account1,
                            direction='INC',
                            amount=Amount(9500))
    test_posting2 = Posting(journal='journal2',#no idea what it is for
                            date=datetime.date(2000,1,1),
                            account=test_account2,
                            direction='DEC',
                            amount=Amount(9500))

# Generated at 2022-06-12 05:50:59.924910
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountBook
    from .accounts import AccountType
    from .commons.zeitgeist import DateRange
    from .journal_entries import JournalEntry
    from .journal_entries import Posting
    from .journal_entries import ReadJournalEntries
    from datetime import date
    from unittest import TestCase

    account_book = AccountBook()
    account_book.register(Account("1", AccountType.ASSETS, "Bank"))
    account_book.register(Account("2", AccountType.EQUITIES, "Owner"))
    journal_entry = JournalEntry("1", "test_JournalEntry_post", "test")
    journal_entry.date = date.today()
    journal_entry.post(journal_entry.date, account_book.get("1"), 100)

# Generated at 2022-06-12 05:51:05.056642
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Mock:
    class ReadJournalEntriesImpl(Generic[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    # Invoke:
    x = ReadJournalEntriesImpl()(None)
    assert isinstance(x, Iterable[JournalEntry[_T]])
    assert not any(x)

# Generated at 2022-06-12 05:51:16.246118
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from pytest import raises
    from dnabc.commons.zeitgeist.time import today
    from dnabc.domain.accounts import AccountType, makeaccount
    from dnabc.domain.journal import JournalEntry, Direction

    #
    # Creating a journal entry:
    #

    # Creating the journal entry:
    journ = JournalEntry[None](today(), "Description", None)

    # Posting to it:
    journ.post(today(), makeaccount('A1', AccountType.ASSETS, 'Cash'), +50)

    # Validation
    journ.validate()

    # List of journal entries:
    jlst = [journ]

    #
    # Creating the function:
    #

# Generated at 2022-06-12 05:51:24.099211
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import Callable, List


    from .accounts import Account, is_subaccount

    # Create parameters:
    def journal1():
        je = JournalEntry[str]("", "", "")
        je.post(datetime.date(2019, 1, 1), Account("A", "", AccountType.ASSETS), 100)
        je.post(datetime.date(2019, 1, 1), Account("B", "", AccountType.EQUITIES), -100)
        return je

    def journal2():
        je = JournalEntry[str]("", "", "")
        je.post(datetime.date(2019, 1, 3), Account("A", "", AccountType.ASSETS), 100)

# Generated at 2022-06-12 05:51:34.923596
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Tests the method :meth:`JournalEntry.post`.
    """

    # We first create a journal entry:
    je = JournalEntry[str]("20200101", "This is a test", "This is the source")

    # We then add some postings:
    je.post(datetime.date(2020, 1, 1), Account("Investment Account", AccountType.ASSETS), +1000)
    je.post(datetime.date(2020, 1, 1), Account("Sales Account", AccountType.REVENUES), -1000)

    # We finally check that the postings are valid:
    je.validate()

# Generated at 2022-06-12 05:51:40.909577
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Given a journal entry
    jrnl = JournalEntry(datetime.date.today(), "Unit test", "pybk", [])

    # When posting
    jrnl.post(datetime.date.today(), Account("ABC","xxx"), 1).post(datetime.date.today(), Account("ABC","xxx"), -1)

    # Then it should validate
    jrnl.validate()
    # And not throw an error

# Generated at 2022-06-12 05:51:52.098250
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType

    def make_account(atype: AccountType) -> Account:
        guid = makeguid()
        return Account(guid, "name", atype)

    # accounts
    assets = make_account(AccountType.ASSETS)
    equities = make_account(AccountType.EQUITIES)
    rev = make_account(AccountType.REVENUES)
    exp = make_account(AccountType.EXPENSES)
    dty = make_account(AccountType.LIABILITIES)

    # Test case #0:
    # Amounts equal.
    je = JournalEntry("2020-01-01", "Test Case #0", None)
    je.post("2020-01-01", assets, 100)
    je.post("2020-01-01", equities, -100)


# Generated at 2022-06-12 05:52:03.597590
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import BookAccount

    journal = JournalEntry(datetime.date(2020, 10, 1), "Test journal", None)

    a01 = BookAccount("A-01", "Revenues", AccountType.REVENUES)
    a02 = BookAccount("A-02", "Expenses", AccountType.EXPENSES)

    journal.post(datetime.date(2020, 1, 1), a01, 100)
    journal.post(datetime.date(2020, 1, 1), a02, -100)

    assert journal.debits[0].account.number == "A-01"
    assert journal.credits[0].account.number == "A-02"
    assert journal.postings[0].is_debit
    assert journal.postings[1].is_credit

# Generated at 2022-06-12 05:52:06.293221
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    a = JournalEntry()
    a.post(account=100, quantity=100)
    a.post(account=100, quantity=-100)
    a.validate()

# Generated at 2022-06-12 05:52:17.197532
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ADummyJournalEntry(JournalEntry[object]):
        pass

    class AReadJournalEntriesImpl(ReadJournalEntries[object]):
        def __init__(self):
            self.called = False
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[object]]:
            self.called = True
            return []

    impl = AReadJournalEntriesImpl()
    assert not impl.called, 'Precondition failed: impl.called'
    result = impl(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 6, 30)))
    assert impl.called, 'Called should be true'
    assert len(result) == 0, 'Expected empty list'

# Generated at 2022-06-12 05:52:28.643157
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.types import Register
    from ..commons.numbers import Amount
    from .accounts import Account, RootAccount, AccountType

    # Create journal entry
    testJournalEntry = JournalEntry[Register]
    testJournalEntry.date = "2020-09-02"
    testJournalEntry.description = "Test Journal Entry"
    testJournalEntry.source = Register()

    # Create test accounts
    AccountType.ASSETS.create("Assets1", "Assets1")
    AccountType.ASSETS.create("Assets2", "Assets2")

    # Test accounts
    assert Account.find("Assets1") is not None, "Assets1 account not created"
    assert Account.find("Assets2") is not None, "Assets2 account not created"

    # Create posting to Assets1 (Debit)
    test

# Generated at 2022-06-12 05:52:31.355261
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .common_test_helpers import test_ReadJournalEntries___call__
    test_ReadJournalEntries___call__()

# Generated at 2022-06-12 05:52:39.721164
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_postings: List[Posting[str]] = [
        Posting(JournalEntry(datetime.date.today(), "", ""), datetime.date.today(), Account("Assets", AccountType.ASSETS),
                Direction.INC, Amount("100")),
        Posting(JournalEntry(datetime.date.today(), "", ""), datetime.date.today(), Account("Revenues", AccountType.REVENUES),
                Direction.DEC, Amount("100"))]

    je = JournalEntry(datetime.date.today(), "", "")
    test_postings[0].journal = je
    test_postings[1].journal = je
    je.postings = test_postings

    je.validate()



# Generated at 2022-06-12 05:52:41.407569
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    a = ReadJournalEntries()
    a(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1)))

# Generated at 2022-06-12 05:52:54.837123
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal1 = JournalEntry(datetime.date(2019, 5, 1), "JournalEntry 1", "Source 1")
    journal1.post(datetime.date(2019, 5, 1), "Assets:Cash", 10)
    journal1.post(datetime.date(2019, 5, 1), "Expenses:Gambling", -10)
    journal1.validate()
    assert str(journal1) == "[2019-05-01] JournalEntry 1 /* Source 1 */"

    journal2 = JournalEntry(datetime.date(2019, 5, 1), "JournalEntry 2", "Source 2")
    journal2.post(datetime.date(2019, 5, 1), "Expenses:Gambling", -10)
    journal2.post(datetime.date(2019, 5, 1), "Assets:Cash", 10)
    journal2

# Generated at 2022-06-12 05:52:55.927306
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass



# Generated at 2022-06-12 05:52:57.456131
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journalEntry = JournalEntry(datetime.date.today(), "Description", None)
    journalEntry.validate()

# Generated at 2022-06-12 05:52:57.925048
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:53:08.361282
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.accounts import Account, AccountType
    account = Account("MyAccount", AccountType.ASSETS)
    je = JournalEntry(datetime.date.today(),"Test JournalEntry",None)
    je.post(datetime.date.today(), account, 2)
    assert len(je.postings) == 1
    je.post(datetime.date.today(), account, 0)
    assert len(je.postings) == 1
    je.post(datetime.date.today(), account, -2)
    assert len(je.postings) == 2

if __name__ == "__main__":
    test_JournalEntry_post()

# Generated at 2022-06-12 05:53:10.076561
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert hasattr(ReadJournalEntries, "__call__")

# Generated at 2022-06-12 05:53:12.784252
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ReadJournalEntriesImpl(ReadJournalEntries[object]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[object]]:
            return tuple()

    assert callable(ReadJournalEntriesImpl())

# Generated at 2022-06-12 05:53:13.382009
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True == True

# Generated at 2022-06-12 05:53:24.913662
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from ..commons.numbers import Quantity

    date = datetime.date.today()
    account = Account(
        idealog_id="acc001",
        code="0001",
        name="Account",
        type=AccountType.ASSETS,
    )
    amount = Quantity(100)

    journal = JournalEntry[None](
        date,
        "Description",
        None,
        [],
    )

    assert len(journal.postings) == 0
    journal.post(date, account, amount)
    assert len(journal.postings) == 1
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].account == account
    assert journal.postings[0].amount == amount



# Generated at 2022-06-12 05:53:37.117560
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from contextlib import ExitStack
    from typing import Generator, Protocol
    from unittest import mock, TestCase
    from uuid import uuid4
    from ..books.entries.entries import Entry
    from ..books.entries.records import Record
    from ..books.common import Price
    from ..books.pl import Portfolio, Leg, Position

    class DummySource(Protocol):
        def get_records(self, period: DateRange) -> Generator[Record, None, None]:
            pass

    class DummyPortfolio(Portfolio):
        def __init__(self, *args, **kwargs):
            super(DummyPortfolio, self).__init__(*args, **kwargs)

# Generated at 2022-06-12 05:54:01.613539
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from decimal import Decimal
    from datetime import date
    from taxonomy import Account, Direction

    journal = JournalEntry[None](date.today(), "Test Journal Entry")

    journal.post(date.today(), Account("Test"), Decimal(0))
    journal.post(date.today(), Account("Test"), Decimal(10))
    journal.post(date.today(), Account("Test"), Decimal(10))

    assert journal.postings[0].date == date.today()
    assert journal.postings[0].account == Account("Test")
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].amount == Decimal(0)

    assert journal.postings[1].date == date.today()
    assert journal.postings[1].account == Account("Test")
    assert journal.post

# Generated at 2022-06-12 05:54:09.215771
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journal.accounts import Assets, Expenses

    ledger = [
        {
            "date": datetime.date(2019, 1, 7),
            "description": "Wages paid to John",
            "postings": {
                Assets.Bank: -1_000,
                Expenses.Wages: +1_000,
            },
        },
    ]

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        for entry in ledger:
            if entry["date"] in period:
                je = JournalEntry(entry["date"], entry["description"], None)
                for account, amount in entry["postings"].items():
                    je.post(entry["date"], account, amount)
               

# Generated at 2022-06-12 05:54:15.137940
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    t=JournalEntry(date=datetime.date.today(),description="Test",source="A")
    t.post(date=datetime.date.today(), account=Account(type=AccountType.REVENUES, name="Revenue"), quantity=10)
    assert t.postings[0].account.name == "Revenue"
    assert t.postings[0].amount == 10
    assert t.postings[0].direction == 1

# Generated at 2022-06-12 05:54:19.656780
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry(datetime.date.today(), "description", 1)
    je.post(datetime.date.today(), Account(AccountType.ASSETS, 'bank'), Amount(1))
    assert je.postings[0].amount == Amount(1)


# Generated at 2022-06-12 05:54:21.757816
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert CheckReadJournalEntries.check_ReadJournalEntries___call__(
        lambda period: [JournalEntry]
    )


# Generated at 2022-06-12 05:54:30.630139
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.date import DateRange

    je = JournalEntry(
        DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 2, 1)).date,
        "Test",
        "Test"
    )
    je.post(
        datetime.date(2019, 1, 1),
        Account(AccountType.REVENUES, 'Revenue'),
        100
    ).post(
        datetime.date(2019, 2, 1),
        Account(AccountType.EXPENSES, 'Expense'),
        100
    )
    je.validate()

# Generated at 2022-06-12 05:54:35.302699
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
   def f(p: DateRange) -> List[JournalEntry[_T]]: pass
   assert f.__annotations__['return'] == List[JournalEntry[_T]]
   assert f.__annotations__['p'] == DateRange
   assert isinstance(f, ReadJournalEntries)


# Unit test

# Generated at 2022-06-12 05:54:40.836186
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from .accounts import Account
    entry = JournalEntry(date.today(), 'Test Entry')
    entry.post(date.today(),Account('Test Account'),Amount(10))
    assert len(entry.postings) == 1
    assert entry.postings[0].amount.is_equal(Amount(10))
    assert entry.postings[0].account == Account('Test Account')

# Generated at 2022-06-12 05:54:48.667325
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType
    from .events import Event
    from .ledgers import Ledger, LedgerBook


# Generated at 2022-06-12 05:54:57.742057
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from datetime import date
    from .accounts import AccountType
    from .accounts import CategoryAccount, DepositAccount

    t1 = date(2019, 7, 1)

    # Case 1: First checking account debit and first checking account credit
    debit_account = DepositAccount(
        guid="guid0",
        name="First Checking Account",
        account_type=AccountType.ASSETS,
        is_active=True,
        created_date=t1,
        created_by="author"
    )
    credit_account = DepositAccount(
        guid="guid1",
        name="First Checking Account",
        account_type=AccountType.ASSETS,
        is_active=True,
        created_date=t1,
        created_by="author"
    )

# Generated at 2022-06-12 05:55:41.615963
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal = JournalEntry(datetime.date(2019, 12, 1), "Test", None)
    journal.post(datetime.date(2019, 1, 1), Account(AccountType.ASSETS, "Cash", None), Quantity(100))
    journal.post(datetime.date(2019, 1, 1), Account(AccountType.REVENUES, "Sales", None), Quantity(-100))

    def journal_reader(period: DateRange) -> Iterable[JournalEntry[object]]:
        assert period.from_date is None
        assert period.until_date is None
        return [journal]

    journal_reader(DateRange())

# Generated at 2022-06-12 05:55:47.853054
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Setup
    je = JournalEntry('date', 'description', 'source')
    je.post(date = 'date', account = 'account', quantity = Quantity(1000))
    je.post(date = 'date', account = 'account', quantity = Quantity(-1000))
    # Exercise
    je.validate()


# Generated at 2022-06-12 05:55:52.935685
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(datetime.date.today(), "Test", None)
    j.post(datetime.date.today(), Account("Cash", AccountType.ASSETS), 1)
    j.post(datetime.date.today(), Account("Sales", AccountType.REVENUES), -1)

# Generated at 2022-06-12 05:56:04.646622
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ddd_ledger.packages.ledger.models.accounts import AccountType
    je = JournalEntry('2020-01-31', 'Create customer account')
    je2 = je.post(datetime.date(2020, 1, 31), Account('2021', AccountType.ASSETS), Quantity(100))
    je3 = je.post(datetime.date(2020, 1, 31), Account('1001', AccountType.EQUITIES), Quantity(100))

# Generated at 2022-06-12 05:56:14.018698
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    assert False

    # 
    # 
    # import datetime
    # from unittest.mock import Mock
    # from financeager import JournalEntry
    # from financeager.domain.accounts import Account
    # from financeager.domain.values.numbers import Quantity
    #
    # # Arrange
    # account_x = Account(
    #     "X",
    #     "TEST",
    #     AccountType.ASSETS,
    #     "TEST",
    #     "TEST"
    # )
    # account_y = Account(
    #     "Y",
    #     "TEST",
    #     AccountType.EQUITIES,
    #     "TEST",
    #     "TEST"
    # )
    # account_z = Account(
    #     "Z

# Generated at 2022-06-12 05:56:26.524751
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from pprint import pprint

    def make_account(account_type: AccountType, description: str = "") -> Account:
        return Account(account_type, description)

    type_ = type
    j_entry = JournalEntry[type_]()

    # create accounts

# Generated at 2022-06-12 05:56:34.216592
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .transactions import Transaction, TransactionStatus

    t1 = Transaction(TransactionStatus.OPENED, "test-transaction", True, None)
    je1 = JournalEntry(datetime.date.today(), "test-journal-entry-1", t1)
    je1.post(datetime.date.today(), Account.get_or_create("A1"), 50)
    je1.post(datetime.date.today(), Account.get_or_create("A2"), -50)
    je1.validate()

# Generated at 2022-06-12 05:56:40.968918
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Given
    journal=JournalEntry()
    account=Account()
    date=datetime.date(2020,5,26)
    quantity=5
    expected_output=JournalEntry(date,account,quantity)
    # Exercise
    actual_output=journal.post(date, account, quantity)
    # Assert
    assert actual_output.date == expected_output.date
    assert actual_output.account == expected_output.account
    assert actual_output.quantity == expected_output.quantity



# Generated at 2022-06-12 05:56:41.700840
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:56:51.512953
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Given a set of accounts
    accountA = Account("accountA", AccountType.ASSETS)
    accountB = Account("accountB", AccountType.ASSETS)
    accountC = Account("accountC", AccountType.EXPENSES)

    # Given a journal entry for these accounts
    journal = JournalEntry("test", accountA, accountB, accountC)

    # When we post positive and negative postings
    journal.post("2020-01-01", accountA, 1000)
    journal.post("2020-01-01", accountB, -500)
    journal.post("2020-01-01", accountC, -500)

    # Then the journal entry should have correct postings
    assert len(journal.postings) == 3
    assert journal.postings[0].account == accountA
    assert journal.postings[1].account == accountB


# Generated at 2022-06-12 05:58:13.418352
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from hamcrest import assert_that, matches_sequence
    
    def sample_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        return (
            JournalEntry(date(2020, 4, 7), "description 1", "source 1"),
            JournalEntry(date(2020, 4, 6), "description 2", "source 2"),
            JournalEntry(date(2020, 4, 5), "description 3", "source 3"),
            JournalEntry(date(2020, 4, 4), "description 4", "source 4"),
            JournalEntry(date(2020, 4, 3), "description 5", "source 5"),
        )
                                             
    ## Try calling the function with a date range of 4th to 7th of April, year 2020.

# Generated at 2022-06-12 05:58:23.203010
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Testing JournalEntry.post
    """
    # Testing: When Posting a journal entry, there should be two postings (one debit and one credit)
    journal = JournalEntry(date=datetime.date(2018, 12, 1), description="Description", source="Some_Source")
    account_one = Account(type=AccountType.ASSETS, code="01", name="Cash")
    account_two = Account(type=AccountType.REVENUES, code="02", name="Sales")
    journal.post(datetime.date(2018, 12, 1), account_one, 300)
    journal.post(datetime.date(2018, 12, 1), account_two, -300)
    # Checking the debit amount value
    assert journal.debits[0].amount == 300
    # Checking the credit amount value

# Generated at 2022-06-12 05:58:35.669737
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange

    # Setup fixture
    date1 = datetime.date(2019, 1, 1)
    date2 = datetime.date(2019, 1, 2)
    date3 = datetime.date(2019, 1, 3)
    account1 = Account(name="Account 1", type=AccountType.ASSETS)
    account2 = Account(name="Account 2", type=AccountType.EQUITIES)

    je = JournalEntry(date=date1, description="Test", source=None)

    # Exercise
    je.post(date3, account1, Amount(5))
    je.post(date2, account2, Amount(-5))

    # Verify