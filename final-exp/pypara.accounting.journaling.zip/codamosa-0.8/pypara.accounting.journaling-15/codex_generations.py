

# Generated at 2022-06-12 05:48:33.126529
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je: JournalEntry = JournalEntry(None, None, None)
    je.post(None, None, None)
    assert len(je.postings)

# Generated at 2022-06-12 05:48:44.120154
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Test for method validate of class JournalEntry
    """
    from ..accounting.accounts import Account, Accounts
    accounts = Accounts()

# Generated at 2022-06-12 05:48:51.323162
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # noinspection PyMissingOrEmptyDocstring
    class Source:
        pass

    # noinspection PyMissingOrEmptyDocstring
    class JournalEntry:
        pass

    # noinspection PyMissingOrEmptyDocstring
    class _MockReadJournalEntries(ReadJournalEntries[Source]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            pass

    _MockReadJournalEntries()

# Generated at 2022-06-12 05:48:59.919412
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..workers.ledger import Ledger
    from .accounts import read_accounts, AccountType, DebitPolicy
    from .events import read_events
    from .rules import Rule

    ## Given:
    workers = [
        read_events(),
        read_accounts(),
        Ledger.as_worker(Rule(DrCrPolicy.TEMPLATE, DebitPolicy.TEMPLATE))
    ]

    ## When:
    ledger = Ledger(workers)

    ## Then:
    assert isinstance(ledger.read_journal_entries, ReadJournalEntries)

# Generated at 2022-06-12 05:49:00.540034
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-12 05:49:08.396245
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class JournalEntrySource:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return [ JournalEntry(datetime.date(2000, 1, 1), "", "") ]

    journal_entry_source: ReadJournalEntries = JournalEntrySource()
    entries = journal_entry_source(DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 12, 1)))
    assert next(entries) == JournalEntry(datetime.date(2000, 1, 1), "", "")

# Generated at 2022-06-12 05:49:11.281858
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Tests the post method of JournalEntry class
    """
    pass

# Generated at 2022-06-12 05:49:15.705682
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[None](datetime.date.today(), "Test", None)
    with pytest.raises(AssertionError) as excinfo:
        je.validate()
    assert "Total Debits and Credits are not equal: 0 != 0" in str(excinfo.value)



# Generated at 2022-06-12 05:49:20.376798
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[int](date=datetime.date.today(), description="Unit Test", source=1)
    je.post(je.date, Account("Cash", AccountType.ASSETS), +1_000)
    je.post(je.date, Account("Purchases", AccountType.EXPENSES), -1_000)
    je.validate()

# Generated at 2022-06-12 05:49:26.893100
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # create object of Class JournalEntry
    journalentry = JournalEntry[int](datetime.date(2020, 5, 31), 'description', 100)
    # Test the post method in class JournalEntry to get a new journalEntry with postings.
    journalentry1 = journalentry.post(datetime.date(2020, 5, 31), Account(1, 'account1', AccountType.LIABILITIES), Quantity(10))
    assert len(journalentry1.postings) == 1

# Generated at 2022-06-12 05:49:39.207170
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType
    from .accounts import Account, AccountId
    from .ledgers import LedgerBook
    from .ledgers import post_journal_entry
    from .accounts import AccountType

    class Payment:
        pass

    account = Account(AccountId("1"), "Name", AccountType.ASSETS)
    ledger = LedgerBook()
    journal = JournalEntry(datetime.date(2020, 5, 10), "Payment", Payment()) \
        .post(datetime.date(2020, 5, 10), account, Quantity(2)) \
        .post(datetime.date(2020, 5, 10), account, Quantity(-2))

    # Post journal entry in the ledger book
    post_journal_entry(ledger, journal)


# PEP386 version of the module.

# Generated at 2022-06-12 05:49:40.528541
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    entries = ReadJournalEntries()(DateRange())


# Generated at 2022-06-12 05:49:50.692445
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book

    book = Book.of(
        "Cash Flow",
        "This is a cash record",
        Account(AccountType.ASSETS, "Cash"),
        Account(AccountType.EQUITIES, "Capital"),
        Account(AccountType.REVENUES, "Sales"),
        Account(AccountType.EXPENSES, "Purchases"),
    )
    journal_entry = JournalEntry[JournalEntry].of(date=datetime.date(year=2019, month=9, day=9),
                                                  description="This is a journal_entry")
    journal_entry.post(date=datetime.date(year=2019, month=9, day=9), account=book.cash, quantity=100)

# Generated at 2022-06-12 05:49:54.816623
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    result: Iterable[JournalEntry[_T]] = ReadJournalEntries()(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 1, 2)))
    assert result is not None
    assert len(result) == 0
    # TODO: Add more test cases to this method

# Generated at 2022-06-12 05:50:02.890119
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    class Entry:
        pass

    #: Test journal entry:
    entry = JournalEntry(date=datetime.date.today(), description="Foo", source=Entry())
    entry.post(date=datetime.date.today(), account=Account("Assets:Cash"), quantity=1)
    entry.post(date=datetime.date.today(), account=Account("Revenues:Sales"), quantity=-1)

    ## Validate (should not raise an exception):
    entry.validate()

# Generated at 2022-06-12 05:50:03.897674
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


# Generated at 2022-06-12 05:50:04.947012
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

# Generated at 2022-06-12 05:50:11.487838
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import datetime
    from collections import namedtuple

    from ..commons.numbers import Amount, Quantity

    from .accounts import Account, AccountType

    class TestJournalEntry(Generic[_T]):
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid, init=False)


# Generated at 2022-06-12 05:50:19.001736
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, ReadAccounts
    from .business import Business

    ## Create business:
    business = Business("ABC Corp.", ReadAccounts(dict(cash=Account("Cash"))))

    ## Create a journal entry reader:
    def read_journal_entries(period: DateRange):
        yield JournalEntry(
            datetime.date(2019, 10, 1),
            "Test journal entry.",
            business,
        )

    ## Run the test:
    assert next(read_journal_entries(DateRange.from_ymd(2019, 10, 1))) == JournalEntry(
        datetime.date(2019, 10, 1),
        "Test journal entry.",
        business,
    )

# Generated at 2022-06-12 05:50:31.260818
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .money import Money
    from .accounts import AccountType, AssetAccount, EquityAccount

    asset_account = AssetAccount(name="Assets")
    equity_account = EquityAccount(name="Equity")

    journal = JournalEntry(datetime.date(2020,3,3), "TEST", Money(100, "USD"))
    assert journal.postings == []
    assert journal.increments == []
    assert journal.decrements == []
    assert journal.debits == []
    assert journal.credits == []

    journal.post(datetime.date(2020,3,3), asset_account, +100)

    assert journal.postings[0].journal == journal
    assert journal.postings[0].date == datetime.date(2020,3,3)
    assert journal.postings[0].account == asset_account

# Generated at 2022-06-12 05:50:38.605585
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    assert False

# Generated at 2022-06-12 05:50:44.802704
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry(datetime.date.today(), "Test Entry", None)
    je.post(datetime.date.today(), Account(),  1)
    je.post(datetime.date.today(), Account(), -1)
    je.post(datetime.date.today(), Account(),  0)
    je.validate()

# Generated at 2022-06-12 05:50:48.035175
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup a journal entry
    je = JournalEntry[int](datetime.date(2020, 4, 4), 'Testing', 0, [])
    # Post single posting with direction, quantity and account
    je.post(datetime.date(2020, 4, 4), Account(AccountType.ASSETS, 'DEBTORS'), +1400)
    # Assert output
    assert isinstance(je, JournalEntry)
    assert isinstance(je.postings[0], Posting)
    assert je.postings[0].journal == je



# Generated at 2022-06-12 05:50:50.029551
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # TODO: Write unit test for method __call__ of class ReadJournalEntries
    raise NotImplementedError

# Generated at 2022-06-12 05:50:59.086402
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType

    @dataclass
    class Data:
        pass

    account1 = Account.create("123", AccountType.ASSETS, "Cash")
    account2 = Account.create("456", AccountType.EXPENSES, "Salaries Expense")
    account3 = Account.create("789", AccountType.REVENUES, "Interest Revenue")
    entry = JournalEntry.create(
        date=datetime.date(2018, 12, 31), description="Cash Reconciliation for 2018 YE.", source=Data()
    )
    entry.post(date=datetime.date(2017, 12, 31), account=account1, quantity=1 * 10 ** 6)
    entry.post(date=datetime.date(2018, 12, 31), account=account2, quantity=-2 * 10 ** 6)
    entry

# Generated at 2022-06-12 05:51:03.561985
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def foo(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []

    def bar(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return iter([])

    assert isinstance(foo, ReadJournalEntries)
    assert isinstance(bar, ReadJournalEntries)

# Generated at 2022-06-12 05:51:07.395304
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Setup:
    def read(dr: DateRange):
        assert dr == period
        return entries

    period = DateRange(datetime.date.today(), datetime.date.today())
    entries = [JournalEntry(datetime.date.today(), "", None)]
    reader: ReadJournalEntries = read

    # Exercise:
    result = reader(period)

    # Verify:
    assert entries == list(result)

# Generated at 2022-06-12 05:51:16.575589
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class Sources:
        pay = object()

    def test_post():
        rent = Account.of_type(AccountType.EXPENSES, "Rent")
        j = JournalEntry(datetime.date.today(), "Pay rent", Sources.pay)
        j.post(datetime.date.today(), Account.of_type(AccountType.ASSETS, "Cash"), -1000)
        j.post(datetime.date.today(), rent, +1000)
        assert j.postings[0].account == Account.of_type(AccountType.ASSETS, "Cash"), "Cash account"
        assert j.postings[1].account == rent, "Rent account"

    test_post()

# Generated at 2022-06-12 05:51:24.285716
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    from ..domain.accounts import Account

    acc1 = Account('123')
    acc2 = Account('234')
    acc3 = Account('345')
    acc4 = Account('456')
    acc5 = Account('567')

    j1 = JournalEntry(
        date=datetime.date(2020, 1, 3),
        description='test journal 1',
        source='test source'
    )
    j1.post(date=datetime.date(2020, 1, 3), account=acc1, quantity=+200)
    j1.post(date=datetime.date(2020, 1, 6), account=acc2, quantity=-100)
    j1.post(date=datetime.date(2020, 1, 6), account=acc3, quantity=-100)


# Generated at 2022-06-12 05:51:26.171184
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-12 05:51:46.765484
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType, SystemAccount

    _j = JournalEntry[str](date=datetime.date.today(), description="", source="")
    _j.post(date=datetime.date.today(), account=Account("A", AccountType.ASSETS), quantity=1)
    _j.post(date=datetime.date.today(), account=Account("L", AccountType.LIABILITIES), quantity=-1)
    _j.post(date=datetime.date.today(), account=SystemAccount.RETAINED_EARNINGS, quantity=-1)
    _j.validate()
    print("Unit Test for method validate of class JournalEntry: PASSED")



# Generated at 2022-06-12 05:51:54.544159
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountTree, AssetAccount

    # Setup:
    root: AccountTree = AccountTree()
    asset: AssetAccount = root.add_account(AccountType.ASSETS, "Asset")


# Generated at 2022-06-12 05:52:06.103113
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.quantities import Quantity
    from ..commons.numbers import Amount
    from .accounts import Account, AccountType
    j1 = JournalEntry(date.today(), "Test Journal 1", None)
    j1.post(date.today(), Account("A1", AccountType.ASSETS), Quantity(+2000))
    j1.post(date.today(), Account("A2", AccountType.EQUITIES), Quantity(+1000))
    from .books import Book
    book = Book("Test Book")
    book.insert(j1)
    read_journal_entries = ReadJournalEntries.__getitem__(book)
    period = DateRange.make("2018-01-01", "2018-12-31")
    journal_entries = list(read_journal_entries(period))

# Generated at 2022-06-12 05:52:11.980050
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class Foo:
        #: Date of the event.
        date: datetime.date

    @dataclass(frozen=True)
    class Bar:
        #: Date of the event.
        date: datetime.date

    jes: List[JournalEntry[Foo]] = [
        JournalEntry(datetime.date.today(), "Foo1", Foo(datetime.date.today()), []).post(
            datetime.date.today(), "R1", +1
        ),
        JournalEntry(datetime.date.today(), "Foo2", Foo(datetime.date.today()), []).post(
            datetime.date.today(), "R2", +2
        ),
    ]


# Generated at 2022-06-12 05:52:19.844997
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # To test verify() you need some actual postings, but that just means creating a JournalEntry:
    je = JournalEntry(
        date=datetime.date(2020, 3, 12),
        description="Test transaction",
        source=None,
        guid="00000000-0000-0000-0000-000000000000",
    )
    je.post(date=datetime.date(2020, 3, 12), account=Account(type=AccountType.ASSETS, num=1000, name="Cash"), quantity=50)
    je.post(date=datetime.date(2020, 3, 12), account=Account(type=AccountType.EXPENSES, num=4000, name="Rent"), quantity=-50)
    je.validate()



# Generated at 2022-06-12 05:52:26.118741
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .test_data import GENERAL_LEDGER_ENTRIES

    # Define a ReadJournalEntries instance:
    entries = ReadJournalEntries()

    # Call __call__ method and check output:
    assert list(entries(DateRange(datetime.date(2020, 5, 1), datetime.date(2020, 5, 30)))) == GENERAL_LEDGER_ENTRIES

# Generated at 2022-06-12 05:52:28.564477
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def my_func(period: DateRange) -> Iterable[JournalEntry[float]]:
        pass
    assert ReadJournalEntries.__subclasshook__(my_func) is True

# Generated at 2022-06-12 05:52:37.641593
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    ## Act:
    journal = JournalEntry(date=datetime.date.today(), description='test', source='test_source')
    journal.post(date=datetime.date.today(), account=Account('Assets:Cash'), quantity=10)
    journal.post(date=datetime.date.today(), account=Account('Expenses:Wages'), quantity=-10)
    ## Assert:
    assert 2 == len(journal.postings)
    ## Act:
    journal.post(date=datetime.date.today(), account=Account('Assets:Cash'), quantity=0)
    ## Assert:
    assert 2 == len(journal.postings)


# Generated at 2022-06-12 05:52:45.660617
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from .accounts import account
    
    # Test case
    def post_1():
        entry = JournalEntry(date(2019, 8, 20), "Payee", "Source")
        entry.post(date(2019, 8, 20), account("Assets:Bank:Current"), -11)
        entry.post(date(2019, 8, 20), account("Expenses:Food"), 11)
        return entry
    
    entry = post_1()

    # Test result
    def post_2():
        expected = JournalEntry(date(2019, 8, 20), "Payee", "Source")
        expected.postings.append(Posting(expected, date(2019, 8, 20), account("Assets:Bank:Current"), Direction.DEC, Amount(11)))

# Generated at 2022-06-12 05:52:54.313846
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    source = 'tv:60'
    date = datetime.date(2019, 1, 1)
    # Create posting for debit account
    account = Account('Receivables', AccountType.ASSETS)
    amount = Amount(5000)
    direction = Direction.INC
    posting = Posting(JournalEntry, date, account, direction, amount)
    # Create journal entry and post
    journal_entry = JournalEntry(date, 'Sold a television to John', source)
    journal_entry.postings.append(posting)
    journal_entry.post(date, account, amount)
    # Assert post
    assert len(journal_entry.postings) == 2
    assert journal_entry.postings[1] == posting
    # Create posting for credit account
    account = Account('Sales', AccountType.REVENUES)
    amount = Amount

# Generated at 2022-06-12 05:53:27.473381
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry[None](datetime.date(2020, 9, 27))
    assert je.postings == []
    
    je.post(datetime.date(2020, 9, 27), Account("cash"), 3000)
    assert je.postings[0].account.code == "cash"
    assert je.postings[0].amount.number == 3000
    assert je.postings[0].direction == Direction.INC
     
    # Test direction which is dependent on the sign of the quantity
    je.post(datetime.date(2020, 9, 27), Account("cash"), -3000)
    assert je.postings[1].account.code == "cash"
    assert je.postings[1].amount.number == 3000
    assert je.postings[1].direction == Direction.DEC
    
    # Test is_debit
   

# Generated at 2022-06-12 05:53:30.068593
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def test_impl(period):
        pass
    assert callable(test_impl)
    test_impl(period=None)

# Generated at 2022-06-12 05:53:36.062866
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Given:
    je = JournalEntry(date=datetime.date.today(), description="test")
    # When:
    je.post(date=datetime.date.today(), account=Account(name="a1"), quantity=20)
    je.post(date=datetime.date.today(), account=Account(name="a2"), quantity=-20)
    # Then:
    je.validate()

# Generated at 2022-06-12 05:53:42.015083
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    source = "source of journal entry"
    date = datetime.date(2019,7,24)
    description = "excercise or rest"
    account = Account("Account", AccountType.ASSETS)
    quantity = 100

    je = JournalEntry[str](date, description, source)
    je = je.post(date, account, quantity)

    assert je.postings[0].direction == Direction.INC
    assert je.postings[0].account.type != Direction.INC

# Generated at 2022-06-12 05:53:42.627036
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:53:43.235252
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:53:54.624867
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType

    je = JournalEntry[int]  # type: ignore
    je.date = datetime.date(2020, 1, 1)
    je.description = "Test Description"
    je.source = 1

    je2 = je.post(datetime.date(2020, 2, 1), Account("Account Name", AccountType.ASSETS), Quantity(1000))
    assert len(je2.postings) == 1
    assert je2.postings[0].amount == Amount(1000)
    assert je2.postings[0].account == Account("Account Name", AccountType.ASSETS)
    assert je2.postings[0].direction == Direction.INC
    assert je2.postings[0].date == datetime.date(2020, 2, 1)


# Generated at 2022-06-12 05:54:04.105998
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    '''Test method post of class JournalEntry.
    '''

    from ..commons.numbers import Currency, Amount

    from .accounts import Account, AccountType
    from .accounts import test_make_current_assets
    from .accounts import test_make_expenses
    from .accounts import test_make_revenues
    from .accounts import test_make_fixed_assets
    from .accounts import test_make_equities

    # A class representing a business object.
    class BusinessObject:
        '''Business Object
        '''
        def __init__(self):
            '''Constructor
            '''

    # Create some accounts.
    current_assets = test_make_current_assets()
    expenses = test_make_expenses()
    revenues = test_make_revenues()
    fixed

# Generated at 2022-06-12 05:54:10.480502
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .objects import Commodity
    from datetime import date, datetime
    commodity = Commodity("Shares", "TEST", 100)
    account = Account(AccountType.ASSETS, "ASSETS", "Cash")
    commodity.post(account, date(2020, 4, 1), 100)

    test = JournalEntry(commodity, datetime.now(), "TEST")
    test2 = test.post(date(2020, 4, 1), account, 100)
    assert test2.postings[0].amount == Amount(100)
    assert test2.postings[0].account == account
    assert test2.postings[0].direction == Direction.INC
    return

# Generated at 2022-06-12 05:54:17.759162
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    assert ReadJournalEntries.__args__ == (TypeVar("_T"),)
    assert ReadJournalEntries.__origin__ == Iterable
    assert read_journal_entries.__annotations__ == {"period": DateRange}
    assert read_journal_entries.__annotations__["return"] == Iterable[JournalEntry[_T]]


# Generated at 2022-06-12 05:55:06.613761
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    f: ReadJournalEntries[int]
    assert False, "Not Implemented"


# Generated at 2022-06-12 05:55:16.076132
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import itertools
    from dataclasses import dataclass
    from typing import Iterable, List

    from .accounts import AccountType, BalanceSheetAccount, BalanceSheetAccounts

    @dataclass(frozen=True)
    class Order:
        guid: str = None
        customer: str = None
        quantity: int = None
        price: float = None

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[Order]]:
        def generate_journal_entry(sale_order: Order) -> JournalEntry[Order]:
            je = JournalEntry(sale_order.guid, sale_order.customer, sale_order, sale_order)

# Generated at 2022-06-12 05:55:25.739186
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from decimal import Decimal

    # Setup
    j = JournalEntry(datetime.date(2000, 1, 1), "Test", None)
    j.postings = []

    # Exercise
    j.post(datetime.date(2000, 1, 1), Account("Assets:Cash"), Decimal("100"))
    j.post(datetime.date(2000, 1, 1), Account("Expenses:Misc"), Decimal("-100"))

    # Verify
    assert len(j.postings) == 2
    assert j.debits[0].direction == Direction.INC
    assert j.debits[0].is_debit
    assert j.debits[0].is_credit == False
    assert j.credits[0].direction == Direction.DEC
    assert j.credits[0].is_debit == False

# Generated at 2022-06-12 05:55:35.522528
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..test.test_journal import mock_read_journal_entries
    from ..test.test_journal import mock_read_journal_entries_empty
    from .accounts import ASSETS
    from .accounts import EQUITIES
    from .accounts import REVENUES
    from .accounts import EXPENSES
    import datetime

    #: No journal entries:
    assert [] == list(mock_read_journal_entries_empty())
    assert [] == list(mock_read_journal_entries_empty(datetime.date(2017, 10, 12)))

    #: All journal entries:
    entries = list(mock_read_journal_entries())
    assert 3 == len(entries)

    #: Validate entries:
    for t in entries:
        t.validate()

    #: Journal entries

# Generated at 2022-06-12 05:55:44.430285
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def pread_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    assert issubclass(ReadJournalEntries[_T], Protocol)
    assert ReadJournalEntries[_T].__call__.__qualname__ == "__call__"
    assert ReadJournalEntries[_T].__call__.__name__ == "__call__"
    assert ReadJournalEntries[_T].__call__.__origin__ == Protocol
    try:
        ReadJournalEntries[_T].__call__.__annotations__
    except AttributeError:
        pass
    else:
        assert False
    assert read_journal_entries.__annotations__ == {"return": Iterable[JournalEntry[_T]]}

# Generated at 2022-06-12 05:55:52.190001
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je1 = JournalEntry("A", "B", "C")
    je2 = je1.post("D", "E", +1000)
    je3 = je2.post("F", "G", -1000)

    je3.validate()

    # Create an invalid journal entry:
    je4 = JournalEntry("A", "B", "C")
    je5 = je4.post("D", "E", +1000)
    je6 = je5.post("F", "G", -500)

    # Expected error at this point:
    try:
        je6.validate()
    except AssertionError as e:
        assert "equal" in str(e)
    else:
        assert False

# Generated at 2022-06-12 05:55:59.438213
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Given
    a_date = datetime.date(2019, 5, 10)
    a_journal = JournalEntry(a_date, "a description", 'a source')

    a_account = Account('account', AccountType.ASSETS)
    an_amount = Amount(100)

    # When
    a_journal.post(a_date, a_account, an_amount)

    # Then
    assert a_journal.postings[0].journal is a_journal
    assert a_journal.postings[0].date is a_date
    assert a_journal.postings[0].account is a_account
    assert a_journal.postings[0].direction is Direction.INC
    assert a_journal.postings[0].amount is an_amount
    assert len(a_journal.postings[0].journal.postings)

# Generated at 2022-06-12 05:56:04.926916
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    source = 'November rent'
    descr = 'Payment for November rent'
    payment_date = datetime.date.today()
    journal_entry = JournalEntry(payment_date, descr, source).post(payment_date, Account.cash, Amount(100)).post(payment_date, Account.rent_income, Amount(-100))
    journal_entry.validate()

# Generated at 2022-06-12 05:56:05.876833
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # TODO
    pass

# Generated at 2022-06-12 05:56:13.825389
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import datetime

    j = JournalEntry(datetime.date(2020, 10, 10), "test desc", "test source")
    j.postings = [
        Posting(j, datetime.date(2020, 10, 10), Account(AccountType.ASSETS, "Cash"), Direction.INC, Amount(1000)),
        Posting(j, datetime.date(2020, 10, 10), Account(AccountType.REVENUES, "Revenues"), Direction.DEC, Amount(1000)),
    ]

    j.validate()

# Generated at 2022-06-12 05:57:59.248644
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType

    # Define an account
    account = Account("VAT to pay", AccountType.LIABILITIES)

    # Define a journal entry
    journal = JournalEntry("Transaction 1")
    journal.post(datetime.date(2020, 1, 1), account, 100)

    # Check the postings of the journal entry
    assert len(journal.postings) == 1
    assert journal.postings[0].date == datetime.date(2020, 1, 1)
    assert journal.postings[0].account == account
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].amount == Amount(100)

# Generated at 2022-06-12 05:58:09.860138
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from datetime import date
    from decimal import Decimal

    journal = JournalEntry(date.today(), "", "")
    account_A = Account(1, "Description", AccountType.ASSETS, True)
    account_L = Account(2, "Description", AccountType.LIABILITIES, True)
    account_E = Account(3, "Description", AccountType.EQUITIES, True)
    account_R = Account(4, "Description", AccountType.REVENUES, True)
    account_X = Account(5, "Description", AccountType.EXPENSES, True)
    # def post(self, date: datetime.date, account: Account, quantity: Quantity) -> None:
    journal.post(date.today(), account_A, +Decimal(5))

# Generated at 2022-06-12 05:58:20.388990
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType

    # Arrange
    obj1 = JournalEntry(date=datetime.date(2019, 10, 12), description="Journal Entry 1")
    obj2 = JournalEntry(date=datetime.date(2019, 10, 12), description="Journal Entry 2")

    # Act
    obj1 = obj1.post(date=datetime.date(2019, 10, 12), account=Account(code="111", type=AccountType.ASSETS), quantity=100)
    obj1 = obj1.post(date=datetime.date(2019, 10, 12), account=Account(code="222", type=AccountType.EQUITIES), quantity=10)

# Generated at 2022-06-12 05:58:23.493265
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date.today()
    account = Account("Test Account")
    quantity = 1
    journal = JournalEntry(date, "Test description", "Test source")
    journal.post(date, account, quantity)
    assert journal.postings[0].amount == Amount(quantity)