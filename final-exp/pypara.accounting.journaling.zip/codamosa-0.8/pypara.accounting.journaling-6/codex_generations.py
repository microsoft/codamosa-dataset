

# Generated at 2022-06-12 05:48:44.499145
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .books import Book
    from .ledgers import Ledger
    from .accounts import Account, AccountType

    book = Book()
    ledger = Ledger(book)
    acc_cash = ledger.get_or_create_account(Account(AccountType.ASSETS, "Cash"))
    acc_sales = ledger.get_or_create_account(Account(AccountType.REVENUES, "Sales"))
    acc_cost = ledger.get_or_create_account(Account(AccountType.EXPENSES, "Cost of sales"))

    j = JournalEntry(date="2019-10-01", description="First entry")
    jpost = j.post(date="2019-10-01", account=acc_cash, quantity=+5000)
    assert len(jpost.postings) == 1

# Generated at 2022-06-12 05:48:45.402477
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-12 05:48:54.847684
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account1 = Account("EXPENSES", "EXPENSES", AccountType.EXPENSES);
    account2 = Account("ASSETS", "ASSETS", AccountType.ASSETS);
    account3 = Account("REVENUES", "REVENUES", AccountType.REVENUES);
    account4 = Account("EQUITIES", "EQUITIES", AccountType.EQUITIES);
    account5 = Account("LIABILITIES", "LIABILITIES", AccountType.LIABILITIES);
    account6 = Account("TOTAL", "TOTAL", AccountType.TOTAL);
    je = JournalEntry(
        datetime.date(2020, 1, 1),
        "A journal entry",
        "A business object",
    )

# Generated at 2022-06-12 05:48:58.032052
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    x = JournalEntry[str]('2019-02-02', 'test', 'TEST', [])
    x.post('2019-02-02',Account('123','Test','Assets'),0)

# Generated at 2022-06-12 05:49:03.628848
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from unittest import TestCase
    from datetime import date
    je = JournalEntry(date(2020, 9, 20), "Debits and Credits are equal", None)
    je.post(date(2020, 9, 20), "Assets:Cash", +100)
    je.post(date(2020, 9, 20), "Assets:Cash", -100)
    je.validate()

# Generated at 2022-06-12 05:49:14.556546
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .accounts import Accounts
    from .accounts import Branch
    from .accounts import Company
    from .accounts import Name

    accounts = Accounts(Company("T1", "Tirana Bank", Name("Gjergji", "Kambo"), Branch("B1", "Headquarters")))

    # Create account
    account = accounts.create(AccountType.EQUITIES, "Capital", Name("Gjergji", "Kambo"), "E1")

    # Create journal entry
    journal = JournalEntry(datetime.date(2020, 1, 1), "Entry", None)
    journal.post(datetime.date(2020, 1, 1), account, 1000)
    journal.post(datetime.date(2020, 1, 1), account, -1000)
    journal.validate()

# Generated at 2022-06-12 05:49:23.679060
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(datetime.date.today(), "JE", "Transaction1")
    journal.post(datetime.date(2018, 9, 1), Account("Assets", AccountType.ASSETS), 1000)
    journal.post(datetime.date(2018, 9, 1), Account("Expenses", AccountType.EXPENSES), -1000)

    assert len(journal.postings) == 2
    assert journal.postings[0].amount == 1000
    assert journal.postings[1].amount == 1000


if __name__ == "__main__":
    # Execute only if run as a script
    test_JournalEntry_post()

# Generated at 2022-06-12 05:49:29.901674
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    q = Quantity(1)
    a = Amount(1)
    account = Account("A", "Assets")
    source = int(1)
    date = datetime.date(2020, 8, 1)

    #3 different ways of validations need to be tested
    #test 1. total_debit = total_credit
    #test 2. total_debit < total_credit
    #test 3. total_debit > total_credit

    #test 1. total_debit = total_credit
    journal_entry = JournalEntry(date, "Test", source)
    journal_entry.post(date, account, q)
    journal_entry.post(date, account, q)
    journal_entry.validate()

    #test 2. total_debit < total_credit

# Generated at 2022-06-12 05:49:39.253081
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountRepository, Accounts

    # Setup fixture:
    accounts = Accounts()
    account_repository = AccountRepository(accounts)
    read_journal_entries = ReadJournalEntries(
        account_repository,
        [
            Posting(datetime.date(2018, 1, 1), "XPS", "Debit", 100, "Dr", "Cr"),
            Posting(datetime.date(2017, 1, 1), "XPS", "Credit", 200, "Dr", "Cr"),
        ],
    )

    # Exercise system:
    actual_result = list(read_journal_entries(DateRange.from_dates(datetime.date(2017, 1, 1), datetime.date(2019, 1, 1))))

    # Verify outcome:

# Generated at 2022-06-12 05:49:49.323476
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType, Account, AccountCode
    from .current import Current

    @dataclass(frozen=True)
    class TestSource:
        pass

    j1: JournalEntry[TestSource] = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Test Description",
        source=TestSource(),
    ).post(datetime.date(2020, 1, 1), Account(AccountType.CASH, AccountCode("CASH")), +100)
    j2: JournalEntry[TestSource] = JournalEntry(
        date=datetime.date(2020, 2, 1),
        description="Test Description",
        source=TestSource(),
    ).post(datetime.date(2020, 2, 1), Account(AccountType.CASH, AccountCode("CASH")), +200)
   

# Generated at 2022-06-12 05:49:54.766544
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:50:06.733671
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import SimpleAccount
    from .commons import DefaultValueResolvers
    from .journal import QueryHelper

    # Create dummy function:

# Generated at 2022-06-12 05:50:17.401229
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    class DummyClass:
        pass

    je1 = JournalEntry[DummyClass](
        date=datetime.date(2020, 1, 1),
        description='Test journal entry',
        source=DummyClass()
    )
    je2 = je1.post(date=datetime.date(2020, 1, 2), account=Account(name='Test account', type=AccountType.EQUITIES), quantity=Quantity(1234))
    je3 = je2.post(date=datetime.date(2020, 1, 3), account=Account(name='Test account', type=AccountType.EQUITIES), quantity=-1234)
    je3.validate()


# Generated at 2022-06-12 05:50:21.517438
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # pylint: disable=E0602,E0601
    class _ReadJournalEntries:

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    #: Assertion doesn't throw error
    assert isinstance(_ReadJournalEntries(), ReadJournalEntries)

# Generated at 2022-06-12 05:50:33.258792
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Asset, Equity, Expense, Revenue, Liability
    from ..commons.zeitgeist import date

    date_test=date(2020,1,1)
    account_test=Liability("test")
    quantity_test=1
    journal_test=JournalEntry(date_test,"test",2)
    journal_test.post(date_test,account_test,quantity_test)
    journal_test.validate()
    assert str(journal_test.postings)==f"Posting(journal=JournalEntry(date=datetime.date(2020, 1, 1), description='test', source=2), date=datetime.date(2020, 1, 1), account=Liability('test'), direction=<Direction.INC: 1>, amount=Amount(1))"



# Generated at 2022-06-12 05:50:42.029771
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    print('Start test_JournalEntry_post')
    journal_entry = JournalEntry[None](datetime.date(2019, 11, 8), 'test description', None)

    # Post $100 into Balance Sheet.Asset.Bank.Checking account
    journal_entry.post(datetime.date(2019, 11, 8), Account('Assets', 'Bank', 'Checking'), 100)
    assert journal_entry.postings[0].account is Account('Assets', 'Bank', 'Checking')
    assert journal_entry.postings[0].direction is Direction.INC
    assert journal_entry.postings[0].amount is Amount(100)

    # Post cash $200 - debit Asssets:Cash account
    journal_entry.post(datetime.date(2019, 11, 8), Account('Assets', 'Cash'), 200)
    assert journal_entry

# Generated at 2022-06-12 05:50:43.130707
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Given...
    pass

# Generated at 2022-06-12 05:50:44.744921
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries.__call__.__annotations__

# Generated at 2022-06-12 05:50:51.225614
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    # Create an empty journal entry
    je = JournalEntry(date=datetime.date(day=1, month=1, year=2020), description='desc', source=None)

    # Act
    # Post 100.0
    je.post(date=datetime.date.today(), account=Account('code', 'name', AccountType.REVENUES), quantity=-100.0)

    # Assert
    # Should have a single posting
    assert len(je.postings) == 1

    # Assert
    # The posting should be a credit
    assert je.postings[0].is_credit == True


# Generated at 2022-06-12 05:50:58.546006
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account

    @dataclass(frozen=True)
    class TestClass:
        pass

    tc = TestClass()
    j = JournalEntry(date=datetime.date(2020, 5, 1), description="Test1", source=tc)
    j.post(date=datetime.date(2020, 5, 1), account=Account(type=AccountType.ASSETS, name="ABC"), quantity=100)
    j.post(date=datetime.date(2020, 5, 1), account=Account(type=AccountType.REVENUES, name="XYZ"), quantity=-100)
    j.validate()
    print('test passed')

# Generated at 2022-06-12 05:51:09.706444
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert not False


# Generated at 2022-06-12 05:51:13.784946
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Define a dummy read journal entries function:
    def read(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []

    # Check that the dummy read journal entries function satisfies the type protocol:
    assert ReadJournalEntries.__instancecheck__(read)

# Generated at 2022-06-12 05:51:17.610323
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    entry = JournalEntry(datetime.datetime.now().date(), "test", None)
    entry.post(entry.date, Account("test"), 100)
    entry.post(entry.date, Account("test"), -100)
    assert entry.validate() is None

# Generated at 2022-06-12 05:51:18.234099
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:51:25.079125
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create test accounts
    account1 = Account(name="Test 1", type=AccountType.ASSETS)
    account2 = Account(name="Test 2", type=AccountType.EQUITIES)
    account3 = Account(name="Test 3", type=AccountType.LIABILITIES)
    account4 = Account(name="Test 4", type=AccountType.REVENUES)
    account5 = Account(name="Test 5", type=AccountType.EXPENSES)
    # create test journal entry
    journal1 = JournalEntry(date=datetime.date(2020, 1, 1), description="Test 1", source=None)
    journal1.post(datetime.date(2020, 1, 1), account=account1, quantity=1000.00)

# Generated at 2022-06-12 05:51:34.387160
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..models import Account
    from ..domains import accounts, parties
    from ..commons import currencies
    # Given:

    # When:
    # payment = parties.Payment(Account(accounts.AccountType.ASSETS, 'Cash'), datetime.date.today(), currencies.Amount(100), 'test')
    # Then:
    # assert isinstance(payment, parties.Payment)

    # Testing __call__ method of ReadJournalEntries
    rje = ReadJournalEntries()
    period = DateRange(datetime.date.today(), datetime.date.today())
    je = rje.__call__(period)
    assert isinstance(je, Iterable[JournalEntry[_T]])

# Generated at 2022-06-12 05:51:35.859806
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass


# Generated at 2022-06-12 05:51:40.593892
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Arrange
    class Concrete(ReadJournalEntries[None]): pass
    sut = Concrete()

    # Act
    result = sut(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)))

    # Assert
    assert isinstance(result, Iterable)
    assert not isinstance(result, list)

# EOF

# Generated at 2022-06-12 05:51:46.379860
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import unittest.mock as mock
    mock_account = mock.Mock(Account)
    mock_source = mock.Mock()

    je = JournalEntry(mock_source, "desc")
    assert je.increments == []
    assert je.decrements == []

    je.post(datetime.date(2020, 2, 16), mock_account, Quantity(100))
    assert je.increments[0].account is mock_account
    assert je.increments[0].amount == Amount(100)
    assert je.decrements == []

    je.post(datetime.date(2020, 2, 16), mock_account, Quantity(200))
    assert je.decrements[0].account is mock_account
    assert je.decrements[0].amount == Amount(200)
    assert je.increments

# Generated at 2022-06-12 05:51:54.432199
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from ..commons.numbers import Quantity
    from .ledgers import Ledger

    # Define a journal
    @dataclass(frozen=True)
    class Journal:

        #: Ledger of the journal entry.
        ledger: Ledger

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

    # Create a ledger
    ledger = Ledger()

    # Create a journal
    journal = Journal(ledger, datetime.date(year=2020, month=1, day=1), 'Description')

    # Create an account
    account = Account(AccountType.ASSETS, 'A1', 'Test Account 1')

    # Post to account

# Generated at 2022-06-12 05:52:15.391924
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class Test:
        def __init__(self, journal_entries: Iterable[JournalEntry[_T]]):
            self._journal_entries = journal_entries
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return (je for je in self._journal_entries if je.date >= period.start and je.date <= period.end)

    assert callable(Test([]))

# Generated at 2022-06-12 05:52:16.281900
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-12 05:52:26.432943
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Returns True if method ``__call__`` of class ``ReadJournalEntries`` is working as expected.
    """

    from ..commons.zeitgeist import datetimerange

    ## Define the protocol:
    def _read(period: DateRange = datetimerange()) -> Iterable[JournalEntry[int]]:
        return iter([JournalEntry(datetime.date.today(), f"descr-{i}", i) for i in range(1, 4)])

    ## Create protocol instance:
    entry_reader = ReadJournalEntries(_read)

    ## Assert:
    return sum(_read()) == sum(entry_reader())


# Generated at 2022-06-12 05:52:36.306248
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass
    class InventoryItem:
        name: str

    @dataclass
    class JournalEntries:
        entries: List[JournalEntry[InventoryItem]] = field(default_factory=list, init=False)

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[InventoryItem]]:
            return self.entries

    class TestItem:
        pass

    item = TestItem()

    journal = JournalEntries()
    journal.entries.append(JournalEntry(datetime.date.today(), "Testing....", InventoryItem("Thing #1"), []))

    def test_read_journals(period: DateRange) -> Iterable[JournalEntry[InventoryItem]]:
        yield from item.journals(period)


# Generated at 2022-06-12 05:52:42.398731
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..books.assets import Asset
    from ..books.accounts import AccountTypes
    from ..books.equities import Equity
    from ..books.revenues import Revenue
    from ..books.expenses import Expense

    assetAccount = Account("Asset Account", AccountTypes.ASSETS, None)
    equityAccount = Account("Equity Account", AccountTypes.EQUITIES, None)
    revenueAccount = Account("Revenue Account", AccountTypes.REVENUES, None)
    expenseAccount = Account("Expense Account", AccountTypes.EXPENSES, None)

    asset = Asset("My Asset")
    equity = Equity("My Equity")
    revenue = Revenue("My Revenue")
    expense = Expense("My Expense")


# Generated at 2022-06-12 05:52:52.983849
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from core import accounts
    from core.model.accounts import Account, AccountType

    test_journal = JournalEntry[int]()

    # Test case 1:
    test_journal.post(datetime.date(2017, 1, 1), Account("bank", "bank", AccountType.ASSETS), +100)
    test_journal.validate()

    # Test case 2:
    test_journal.post(datetime.date(2017, 1, 1), Account("bank", "bank", AccountType.REVENUES), -100)
    test_journal.validate()

    # Test case 3:
    test_journal.post(datetime.date(2017, 1, 1), Account("bank", "bank", AccountType.EXPENSES), +100)
    test_journal.validate()



# Generated at 2022-06-12 05:52:56.473981
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class Dummy(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    dummy = Dummy()

# Generated at 2022-06-12 05:52:58.330248
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_entries(_: DateRange) -> Iterable[JournalEntry[int]]:
        pass

    ReadJournalEntries.register(read_entries)



# Generated at 2022-06-12 05:53:11.101748
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Validate the post method of the JournalEntry class

    """
# create a series of tests for the class JournalEntry
    from .accounts import Account, AccountType, ReadAccounts
    from .transactions import Transaction

    def read_accounts(period: DateRange) -> Iterable[Account]:
        return [
            Account(AccountType.ASSETS, 'Cash', 'BANK_A'),
            Account(AccountType.EQUITIES, 'Equity', 'Owner'),
            Account(AccountType.LIABILITIES, 'Accounts Payable', 'AP'),
            Account(AccountType.REVENUES, 'Revenue', 'Revenue'),
            Account(AccountType.EXPENSES, 'Expenses', 'Expense'),
            ]
    # create a series of accounts
    ra: ReadAccounts = read_accounts
    # create a series

# Generated at 2022-06-12 05:53:12.295630
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Ensure the method is callable:
    ReadJournalEntries.__call__

# Generated at 2022-06-12 05:53:57.683940
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account = Account(code = "A101", name = "Cash", type = AccountType.ASSETS)

    journal_entry1 = JournalEntry(date = datetime.date.today(), description = "Test Journal Entry #1", 
        source = "N/A", guid = makeguid())
    journal_entry1.post(datetime.date.today(), account, Quantity(100))
    journal_entry1.post(datetime.date.today(), account, Quantity(-100))

    journal_entry2 = JournalEntry(date = datetime.date.today(), description = "Test Journal Entry #2", 
        source = "N/A", guid = makeguid())
    journal_entry2.post(datetime.date.today(), account, Quantity(100))

# Generated at 2022-06-12 05:54:06.273608
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, makeaccounts
    from .currencies import Currency, makecurrencies
    #
    # define a currency
    currency = Currency("EUR")
    #
    # define some accounts
    accounts = makeaccounts({
        "REVENUES": AccountType.REVENUES,
        "EXPENSES": AccountType.EXPENSES,
        "CASH": AccountType.ASSETS,
    })
    #
    # define a journal entry
    entry = JournalEntry[str](datetime.date.today(), "Example Journal Entry", "Example Source")
    #
    # post amounts to accounts
    entry.post(currency.today, accounts["REVENUES"], 100)
    entry.post(currency.today, accounts["CASH"], -100)
    #
    # check postings

# Generated at 2022-06-12 05:54:18.038393
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import pandas as pd

    from .accounts import AccountType, Account, AccountTypeEntries, AccountsWithEntries
    from .products import Product, ProductCategory, ProductCategoryEntries, ProductEntries


# Generated at 2022-06-12 05:54:29.329778
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .posts import Post, PostType
    from .posts import Liability, Revenue, Expense

    # Define Account and Post instances for testing
    Account1 = Account(AccountType.EQUITIES, 'Savings Account1')
    Account2 = Account(AccountType.ASSETS, 'Current Account2')
    Account3 = Account(AccountType.LIABILITIES, 'Credit Card3')
    Account4 = Account(AccountType.REVENUES, 'Revenue Account4')
    Account5 = Account(AccountType.EXPENSES, 'Expense5')

    # Define Post instances for testing
    Posting1 = Post(PostType.RECEIPTS, 'Credit Card Receipts0', '2020-01-01')

# Generated at 2022-06-12 05:54:39.597475
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    a1 = Account("A1", AccountType.ASSETS)
    a2 = Account("A2", AccountType.EXPENSES)
    e1 = JournalEntry(datetime.date(2019, 10, 5), "E1", None)
    e1.post(e1.date, a1, -100)
    e1.post(e1.date, a1, -100)
    e1.post(e1.date, a2, +100)
    e1.post(e1.date, a2, +200)
    e1.validate()
    j = JournalEntry(datetime.date(2019, 10, 5), "E1", None)
    j.post(j.date, a1, -100)
    j.post(j.date, a1, -100)

# Generated at 2022-06-12 05:54:46.587033
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Accounts, BankAccount, IncomeAccount, ExpenseAccount

    ledger = Accounts()
    account_liability = ledger.get_or_create(BankAccount("My Bank Account"))
    account_revenue = ledger.get_or_create(IncomeAccount("Income"))
    account_expense = ledger.get_or_create(ExpenseAccount("Expense"))

    entry = JournalEntry(datetime.date.today())
    entry.post(account_liability, +100)
    entry.post(account_revenue, -100)
    entry.post(account_expense, +100)

    entry.validate()

# Generated at 2022-06-12 05:54:54.090441
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Setup:
    yesterday = datetime.date.today() - datetime.timedelta(days=1)
    today = datetime.date.today()
    tomorrow = today + datetime.timedelta(days=1)
    period = DateRange(yesterday, tomorrow)

    # Exercise:
    actual = ReadJournalEntries.__call__.__annotations__['return']

    # Verify:
    assert issubclass(actual, Iterable)

# Generated at 2022-06-12 05:55:06.277346
# Unit test for method __call__ of class ReadJournalEntries

# Generated at 2022-06-12 05:55:14.470527
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup
    je = JournalEntry[str]('2020-10-16', 'Test Posting', 'Test Posting', [])
    expected_je = JournalEntry[str]('2020-10-16', 'Test Posting', 'Test Posting', [Posting(je, '2020-10-16', 'Assets:Current Assets:Cash', Direction.INC, Amount(100))])

    # Exercise
    actual_je = je.post('2020-10-16', Account.from_fullname('Assets:Current Assets:Cash'), 100)

    # Verify
    assert actual_je == expected_je


# Generated at 2022-06-12 05:55:25.030373
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account

    assert JournalEntry(datetime.date.today(), "Test1", None).post(datetime.date.today(), Account.DEBIT, +1000).decrements == [], "JournalEntry.post works with positive numbers (increment)"
    assert JournalEntry(datetime.date.today(), "Test2", None).post(datetime.date.today(), Account.CREDIT, -1000).increments == [], "JournalEntry.post works with negative numbers (decrement)"
    assert JournalEntry(datetime.date.today(), "Test3", None).post(datetime.date.today(), Account.CREDIT, +0).decrements == [], "JournalEntry.post works with zero numbers (increment)"

# Generated at 2022-06-12 05:56:40.892845
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class Sample:
        pass

    def read(period: DateRange) -> Iterable[JournalEntry[Sample]]:
        yield from ()

    ReadJournalEntries.__instancecheck__(read)

# Generated at 2022-06-12 05:56:51.116408
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class Person:
        name: str

    @ReadJournalEntries.register
    def read_journa_entries(period: DateRange) -> Iterable[JournalEntry[Person]]:
        return [
            JournalEntry(datetime.date(2018, 1, 1), "test", Person("ss"), postings=[Posting(None, datetime.date(2018, 1, 1), None, None, Amount(0))])
        ]

    res = list(read_journa_entries(DateRange(datetime.date(2018, 1, 1), datetime.date(2019, 1, 1))))
    assert len(res) == 1
    assert res[0].date == datetime.date(2018, 1, 1)
    assert res[0].postings[0].date == datetime

# Generated at 2022-06-12 05:57:02.617512
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Tests the call method.
    """
    from ..commons.zeitgeist import DateRange, today
    from .accounts import Account, create_account
    from .coinage import Coinage

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[Coinage]]:
        return (
            JournalEntry(today(), "Description1", Coinage.of(100), [])
            .post(today(), create_account(Account.CODE_CASH, AccountType.ASSETS), 100)
            .post(today(), create_account(Account.CODE_SALES_REVENUE, AccountType.REVENUES), -100),
        )

    expected = 1
    actual = 0
    for _ in read_journal_entries(DateRange(today(), today())):
        actual += 1
   

# Generated at 2022-06-12 05:57:03.256117
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass # do nothing

# Generated at 2022-06-12 05:57:04.283484
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False


# Generated at 2022-06-12 05:57:10.234992
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .accounts import AccountRepository, InMemoryAccountRepository
    
    account_repo = InMemoryAccountRepository()
    for name, atype in (("Assets", AccountType.ASSETS), ("Expenses", AccountType.EXPENSES), ("Income", AccountType.REVENUES), ("Equities", AccountType.EQUITIES)):
        account_repo.save(Account(name, atype))
    

# Generated at 2022-06-12 05:57:19.151884
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class Source(object):
        def __init__(self, abc):
            self.abc = abc

        def __str__(self):
            return '%s(%r)' % (self.__class__.__name__, self.abc)

    test1 = JournalEntry(date=datetime.date(2019, 1, 1), description='test1', source=Source('source1'))
    test1.post(date=datetime.date(2018, 12, 31), account=Account(name='Account1'), quantity=123)
    test1.post(date=datetime.date(2018, 12, 31), account=Account(name='Account2'), quantity=-123)
    test2 = JournalEntry(date=datetime.date(2019, 1, 1), description='test2', source=Source('source2'))
    test2

# Generated at 2022-06-12 05:57:24.721033
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date

    @dataclass(frozen=True)
    class Foo:
        pass

    @dataclass(frozen=True)
    class JournalEntrySource:
        date: date
        description: str
        source: Foo

    assert ReadJournalEntries.__call__.__annotations__ == {
        'self': ReadJournalEntries[_T],
        'period': DateRange,
        'return': List[JournalEntry[_T]]
    }

# Generated at 2022-06-12 05:57:25.934164
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass


# Generated at 2022-06-12 05:57:37.089925
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange

    from .objekte import Objekt, _Objekt
    from .datastore import TransientDataStore
    from . import journals

    # Setup:
    datastore: TransientDataStore = TransientDataStore()
    period: DateRange = DateRange(datetime.date(2019, 7, 1), datetime.date(2019, 7, 31))
    objekt1: Objekt = _Objekt(datastore, name="Objekt #1")
    objekt2: Objekt = _Objekt(datastore, name="Objekt #2")
