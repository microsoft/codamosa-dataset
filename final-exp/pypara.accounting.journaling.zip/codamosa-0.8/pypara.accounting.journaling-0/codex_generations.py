

# Generated at 2022-06-12 05:48:35.275987
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # @todo:
    pass

# Generated at 2022-06-12 05:48:45.145126
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import Today
    from .accounts import Account, AccountType
    from .journal import JournalEntry


# Generated at 2022-06-12 05:48:53.321794
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry[str](datetime.date.today(), "test", "0")
    j.post(datetime.date.today(), Account(AccountType.ASSETS), Quantity(1))
    j.post(datetime.date.today(), Account(AccountType.ASSETS), Quantity(-1))
    assert len(j.postings)==2
    assert j.postings[0].is_debit==True
    assert j.postings[1].is_credit==True
    assert j.postings[1].direction==Direction.DEC
    assert j.postings[1].amount==Amount(1)

# Generated at 2022-06-12 05:49:05.721143
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from unittest import TestCase
    from datetime import date

    from .accounts import AccountType
    from .businesses import Accountant
    from .currencies import Currency, CurrencyPair, ForeignExchangeRate, Money
    from .events import ExchangeRateChanged

    class _Tester(TestCase):
        def setUp(self) -> None:
            self.dollar = Currency("USD", "Dollar", "US$")
            self.euro = Currency("EUR", "Euro", "€")
            self.pair = CurrencyPair(self.dollar, self.euro, True)
            self.accountant = Accountant()

        def test_validate(self):
            acc = self.accountant.create_account(self.euro, "Equity:Opening Balances")


# Generated at 2022-06-12 05:49:10.753078
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal = JournalEntry(date = datetime.date(2020, 1, 1),
                           description = "Test of JournalEntry.validate()",
                           source = None)
    journal.post(date = datetime.date(2020, 1, 1), account = Account.of_type(AccountType.ASSETS), quantity = 100)
    journal.post(date = datetime.date(2020, 1, 1), account = Account.of_type(AccountType.EXPENSES), quantity = -100)
    journal.validate()


# Generated at 2022-06-12 05:49:11.392975
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:49:19.796098
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.test_commons import data_to_create
    from .events.events import Event
    import pandas as pd
    import pandas.util.testing as tm
    pd.set_option('display.max_columns', 8)

    event_id = data_to_create.get('event_id')
    event_amount = data_to_create.get('event_amount')
    event_date = data_to_create.get('event_date')
    event_description = data_to_create.get('event_description')
    event_source = data_to_create.get('event_source')
    account_id = data_to_create.get('account_id')

# Generated at 2022-06-12 05:49:29.943755
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup variable
    test_amount = Quantity(10)
    test_date = datetime.date(year=2019, month=2, day=25)
    test_account = Account(name="Expenses:Food")
    test_posting = Posting(journal=None, date=datetime.date(2019, 2, 25), account=test_account, direction=Direction.DEC, amount=Amount(10))
    # Create JournalEntry class using test data
    test_entry = JournalEntry[None](date=test_date, description="Test", source=None)
    # Check if the test_posting is equal to the posting created by calling the post function
    assert test_entry.post(date=test_date, account=test_account, quantity=test_amount) == test_entry


# Generated at 2022-06-12 05:49:39.300167
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ledgersim.engine.types import Account as _Account
    from ledgersim.engine.types import AccountType as _AccountType

    assert (
        JournalEntry[object]()
            .post(datetime.date(2020, 1, 1), _Account("USBANK", _AccountType.ASSETS), +20)
            .post(datetime.date(2020, 1, 1), _Account("RENT", _AccountType.REVENUES), -20)
            .validate()
    )


# Generated at 2022-06-12 05:49:49.375743
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Given
    account1 = Account(Guid('7b332f35-d8e3-4c3f-97d2-d2b874ef9aab'), 'Account 1', AccountType.ASSETS)
    account2 = Account(Guid('d2055b2f-47a2-4652-9b48-1b14d821affe'), 'Account 2', AccountType.LIABILITIES)
    account3 = Account(Guid('6cce38b8-8b2e-4da5-8b5a-26789029e1c3'), 'Account 3', AccountType.REVENUES)

# Generated at 2022-06-12 05:50:07.876756
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    acct = Account("Assets", AccountType.ASSETS)
    
    je = JournalEntry(datetime.date.today(), "Test", "Trial")
    assert not [p for p in je.postings]

    je.post(datetime.date.today(), acct, Quantity(100))
    assert len([p for p in je.postings]) == 1

    je.post(datetime.date.today(), acct, Quantity(-100))
    assert len([p for p in je.postings]) == 2

    je.post(datetime.date.today(), acct, Quantity(0))
    assert len([p for p in je.postings]) == 2



# Generated at 2022-06-12 05:50:15.362695
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    #Arrange
    je = JournalEntry(datetime.date(2020, 1, 1), "test description", "test source")
    #Act
    je.post(datetime.date(2020, 1, 1), "test account", Quantity(100))
    je.post(datetime.date(2020, 1, 1), "test account", Quantity(-100))
    je.post(datetime.date(2020, 1, 1), "test account", Quantity(0))
    #Assert
    assert len(je.postings) == 2

# Generated at 2022-06-12 05:50:23.881284
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledger import Ledger, LedgerType
    from .events import Event, EventType, EventTypeMap
    test_eventtype = EventType('testevent', 'testevent', ledger_type=LedgerType.EVENT)
    test_event_type_map = EventTypeMap('testeventtypemap', event_types=[test_eventtype, ])
    test_ledger = Ledger(name='testledger', event_type_map=test_event_type_map, account_types={
        AccountType.REVENUES, AccountType.EXPENSES, AccountType.ASSETS
    })
    test_account = Account(name='testaccount', ledger=test_ledger, type=AccountType.REVENUES)

# Generated at 2022-06-12 05:50:35.189126
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from dataclasses import dataclass,field
    from .accounts import Account
    from .journal_entries import JournalEntry, Posting
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    @dataclass(frozen=True)
    class T:
        pass
    t = T()
    t1 = T()
    t2 = T()
    t3 = T()
    j1 = JournalEntry(date=datetime.date(2019, 10, 1), description="Test", source=t)
    assert j1.post(date=datetime.date(2019, 10, 1), account=Account("Cash"), quantity=Quantity("1")) == j1

# Generated at 2022-06-12 05:50:42.844783
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class _Foo:
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

    @dataclass(frozen=True)
    class _Context:
        #: Source of journal entries.
        source: List[_Foo]

    @dataclass(frozen=True)
    class _Subject(ReadJournalEntries[_Foo]):
        ctx: _Context
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            assert self.ctx.source, "Source must not be empty if called."
           

# Generated at 2022-06-12 05:50:49.530282
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # create a journal entry
    je = JournalEntry[str]('2020-04-27', '2020-04-27', Account('Assets Account', AccountType.ASSETS), [Posting(JournalEntry[str]('2020-04-27', '2020-04-27', Account('Assets Account', AccountType.ASSETS), []), datetime.date(2020, 4, 27), Account('Assets Account', AccountType.ASSETS), Direction.INC, 1800)])
    # check the validity of the journal entry
    je.validate()

# Generated at 2022-06-12 05:50:58.141751
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from datetime import date
    from ..accounting.accounts import Account
    from ..commons.numbers import Quantity

    asset_acc = Account(
        name="Cash",
        type=AccountType.ASSETS,
    )
    exp_acc = Account(
        name="Salary",
        type=AccountType.EXPENSES,
    )

    journal_entry = JournalEntry(
        date=date(2020, 9, 2),
        description="Journal Entry for Salary",
        source=1,
    )
    journal_entry.post(date(2020, 9, 2), asset_acc, Quantity(100))
    journal_entry.post(date(2020, 9, 2), exp_acc, Quantity(-100))

    journal_entry.validate()

# Generated at 2022-06-12 05:51:02.623541
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account

    # Create a journal entry
    je = JournalEntry(date=datetime.date(2020, 7, 10), description="test1", source=None)
    je.post(date=datetime.date(2020, 7, 10), account=Account("Share Capital", AccountType.EQUITIES), quantity=200)

    # Assert that the amounts match
    assert je.postings[0].amount == Amount(200)
    assert je.postings[0].account == Account("Share Capital", AccountType.EQUITIES)
    assert je.postings[0].direction == Direction.INC



# Generated at 2022-06-12 05:51:05.746549
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    joe = Account("joe")
    journal = JournalEntry[int](datetime.date.today(), "", 0)
    journal.post(datetime.date.today(), joe, Quantity(-1))
    journal.validate()

# Generated at 2022-06-12 05:51:15.173032
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from unittest.mock import Mock
    from .journalentry import JournalEntry
    from ..commons.zeitgeist import DateRange
    class A:
        read_journal_entries = Mock(spec=ReadJournalEntries)
    class B:
        def read_journal_entries(self, period: DateRange) -> Iterable[JournalEntry]:
            pass
    a = A()
    a.read_journal_entries(period=DateRange())
    a.read_journal_entries.assert_called_once()
    b = B()
    b.read_journal_entries(period=DateRange())
    b.read_journal_entries(period=DateRange())

# Generated at 2022-06-12 05:51:33.887189
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class Payment():
        def __init__(self, date):
            self.date = date
    
    cash_account = Account('Cash')
    expenses_account = Account('Expenses', AccountType.EXPENSES)
    entries = []
    test_journal_entry = JournalEntry(datetime.date(2019,6,5), 'Test Journal Entry', Payment(datetime.date(2019,6,5)))
    test_journal_entry.post(test_journal_entry.date, cash_account, -1000)
    test_journal_entry.post(test_journal_entry.date, expenses_account, 1000)
    entries.append(test_journal_entry)
    print(test_journal_entry)
    for i in entries:
        i.validate()

#Unit test for method validate of class JournalEntry

# Generated at 2022-06-12 05:51:43.202861
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType
    from .commons import Period, DateRange
    from .ledgers import Ledger
    from .transaction import Transaction
    from .reports import TrialBalance


    def tran_journal(ledger: Ledger[_T], tran: Transaction[_T]) -> JournalEntry[_T]:
        return JournalEntry(tran.date, tran.description, tran.source).post(tran.date, tran.payable, tran.amount)


    ledger: Ledger[Transaction] = Ledger()

# Generated at 2022-06-12 05:51:52.370310
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    entry = JournalEntry(date=date(2020, 1, 1), description="TEST", source=None)
    entry.post(date=date(2020, 1, 1), account=Account(name="A"), quantity=1)

    def read_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        yield entry

    # Verify we can provide class method as implementation, and also
    # verify method resolution order of call.
    assert read_entries((date(2020, 1, 1), date(2020, 1, 1))) == [entry]
    assert ReadJournalEntries.__call__(read_entries, (date(2020, 1, 1), date(2020, 1, 1))) == [entry]

# Generated at 2022-06-12 05:52:04.223758
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(date=datetime.date(2020, 1, 1), description="test_JournalEntry_post")
    # Test case 1: positive quantity is posted as an increment of an Asset
    journal.post(date=datetime.date(2020, 1, 1), account=Account.of("Assets:Cash"), quantity=Quantity(+100))
    assert journal.postings[0].date == datetime.date(2020, 1, 1)
    assert journal.postings[0].account.name == "Assets:Cash"
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].amount == Amount(+100)
    assert journal.postings[0].is_debit == True
    assert journal.postings[0].is_credit == False

    # Test case 2: negative quantity is posted

# Generated at 2022-06-12 05:52:15.627988
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    J = JournalEntry._T  # used in _post
    Post = Posting._T

    journal1 = JournalEntry(date=datetime.date.today(), description='', source=J)
    journal2 = JournalEntry(date=datetime.date.today(), description='', source=J)

    account1 = Account(name='', type=AccountType.EXPENSES)
    account2 = Account(name='', type=AccountType.EXPENSES)

    quantity1 = Quantity(1)
    quantity2 = Quantity(2)

    journal1._post(date=datetime.date.today(), account=account1, quantity=quantity1)
    journal2._post(date=datetime.date.today(), account=account2, quantity=quantity2)

    assert journal1.postings[0].account == account1
    assert journal1

# Generated at 2022-06-12 05:52:19.729207
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from unittest.mock import Mock

    def test_function(period: DateRange):
        yield Mock()

    protocol = ReadJournalEntries[_T]
    assert callable(protocol)
    assert isinstance(test_function, protocol)

# Generated at 2022-06-12 05:52:24.802586
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType, Account
    from .posting.journals import Journal

    @dataclass(frozen=True)
    class Source:
        pass

    ## Initialize the journal and posting some entries:
    j = Journal()
    acc_cash = Account("Cash", AccountType.ASSETS)
    acc_unearned = Account("Unearned", AccountType.LIABILITIES)
    acc_sales = Account("Sales", AccountType.REVENUES)
    source = Source()
    j.post(source, datetime.date(2020, 1, 1), "Cash received", entries=lambda e, d, a: e.post(d, a, 10000) + e.post(d, a, -10000))

# Generated at 2022-06-12 05:52:33.915513
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .policies import Policy
    from .ledgers import Ledger
    from .dataclasses import Date


# Generated at 2022-06-12 05:52:35.632853
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    with Assert.raises(TypeError):
        ReadJournalEntries.__call__()


# Generated at 2022-06-12 05:52:42.640694
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry('2019-11-05', 'description', None)
    j.post('2019-11-05', Account(AccountType.EXPENSES, 'expenses1', 'expenses1'), Quantity(1))
    j.post('2019-11-05', Account(AccountType.EXPENSES, 'expenses2', 'expenses2'), Quantity(1))
    j.post('2019-11-05', Account(AccountType.EXPENSES, 'expenses3', 'expenses3'), Quantity(1))
    j.validate()

# Generated at 2022-06-12 05:53:11.381777
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from collections import namedtuple
    from .accounts import EquityAccount
    from .products import ProductUse, Reservation, StockEntry
    from .transactions import Transaction

    def read_journal_entries(*args, **kwargs) -> Iterable[JournalEntry[Transaction]]:
        yield JournalEntry(date = datetime.date(2015, 1, 1), description = "FOO", source = Transaction())

    assert list(filter(lambda i: isinstance(i, JournalEntry), ReadJournalEntries.__bases__)) == [JournalEntry]
    assert list(ReadJournalEntries.__mro__) == [ReadJournalEntries, Protocol, object]
    assert isinstance(read_journal_entries, ReadJournalEntries)
    assert list(ReadJournalEntries.__parameters__) == [TypeVar("_T")]
    assert isinstance

# Generated at 2022-06-12 05:53:21.721377
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    source = Marker()

    def journal_reader(period: DateRange):
        return [
            JournalEntry(date=datetime.date(2020, 1, 1), description="Debit & Credit", source=source),
            JournalEntry(date=datetime.date(2020, 1, 2), description="Only Debits", source=source),
            JournalEntry(date=datetime.date(2020, 1, 3), description="Only Credits", source=source),
            JournalEntry(date=datetime.date(2020, 1, 4), description="No Postings", source=source),
        ]

    journal_reader(DateRange.from_string("2020-01-01:2020-01-05"))

# Generated at 2022-06-12 05:53:28.908571
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    feb_28_2019:datetime.datetime
    feb_28_2019 = datetime.datetime(2019, 2, 28)
    a1:Account
    amount_50:Amount
    amount_50 = Amount(50)
    a1 = Account(1, "A1", AccountType.EXPENSES, None)

    e1:JournalEntry[_T]
    e1 = JournalEntry(feb_28_2019, "E1", None)

    e1_post:JournalEntry[_T]
    e1_post = e1.post(feb_28_2019, a1, -50)

    assert e1_post == e1
    assert e1_post.decrements[0].amount == amount_50


# Generated at 2022-06-12 05:53:36.563562
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Tests __call__ function
    """
    import unittest

    class TestReadJournalEntries(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    test_ReadJournalEntries = TestReadJournalEntries()
    assert test_ReadJournalEntries.__call__(None) is not None
    assert isinstance(test_ReadJournalEntries.__call__(None), Iterable[JournalEntry[_T]])


# Generated at 2022-06-12 05:53:37.494118
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False, "TODO: Implement"

# Generated at 2022-06-12 05:53:38.084834
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-12 05:53:48.320260
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(datetime.date(2020, 10, 12), "", None)
    j.post(datetime.date(2020, 10, 12), Account("A1", AccountType.ASSETS), Quantity(10))
    j.post(datetime.date(2020, 10, 12), Account("E1", AccountType.EQUITIES), Quantity(20))
    j.post(datetime.date(2020, 10, 12), Account("L1", AccountType.LIABILITIES), Quantity(30))
    j.post(datetime.date(2020, 10, 12), Account("R1", AccountType.REVENUES), Quantity(40))
    j.post(datetime.date(2020, 10, 12), Account("E2", AccountType.EXPENSES), Quantity(50))


# Generated at 2022-06-12 05:53:57.765312
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    journal = JournalEntry(datetime.date(2018, 3, 31), "test description", "test")
    # Act
    journal.post(datetime.date(2018, 4, 1), Account("test-account"), Quantity(10))
    # Assert
    assert len(journal.postings) == 1
    assert journal.postings[0].date == datetime.date(2018, 4, 1)
    assert journal.postings[0].account.name == "test-account"
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].amount == 10

# Generated at 2022-06-12 05:53:58.345942
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:54:04.027774
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry(
        datetime.date(2020, 1, 2),
        "description",
        "source",
        [
            Posting(None, datetime.date(2020, 1, 2), Account("ASSET", AccountType.ASSETS, ""), Direction.DEC, Amount(100)),
            Posting(None, datetime.date(2020, 1, 2), Account("EXPENSE", AccountType.EXPENSES, ""), Direction.INC, Amount(100)),
        ],
    )
    j.validate()

# Generated at 2022-06-12 05:54:43.242783
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry = JournalEntry[None](datetime.date(2019, 1, 1), "description", None)
    journal_entry.post(datetime.date(2019, 1, 1), Account(), 100)
    journal_entry.post(datetime.date(2019, 1, 1), Account(), -100)

    journal_entry.validate()

# Generated at 2022-06-12 05:54:51.611052
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_entry = JournalEntry(guid=Guid('201e1af0-c7db-11e9-9c00-79efc722229d'), date=datetime.date(2019, 8, 25), description='Test JournalEntry')
    assert journal_entry.date == datetime.date(2019, 8, 25)
    assert journal_entry.guid == Guid('201e1af0-c7db-11e9-9c00-79efc722229d')
    assert journal_entry.description == 'Test JournalEntry'

# Generated at 2022-06-12 05:54:59.182629
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .globals import Globals

    g = Globals.using({})
    a = Account.using(g, code="1001", name="Cash", type=AccountType.ASSETS)
    b = Account.using(g, code="2001", name="Vehicle", type=AccountType.ASSETS)
    c = Account.using(g, code="3001", name="Sales", type=AccountType.REVENUES)
    d = Account.using(g, code="4001", name="Salary", type=AccountType.EXPENSES)


# Generated at 2022-06-12 05:55:09.256281
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .currencies import Currency, CurrencyCollection
    from .ledgers import Ledger

    # Create some accounts
    accounts = Account.from_specifications(
        {
            "ASSET:AccountsReceivable": None,
            "ASSET:Cash": "USD",
            "EXPENSE:Electricity": "USD",
            "EXPENSE:Rent": "USD",
            "EQUITY:RetainedEarning": "USD",
            "LIABILITY:AccountsPayable": "USD",
            "REVENUE:ServiceFees": "USD",
        }
    )

    # Create the ledger
    ledger = Ledger()
    ledger = ledger.add_accounts(accounts)

    # Create some currencies
    currencies = CurrencyCollection()
    ledger = ledger.add_currencies(currencies)

# Generated at 2022-06-12 05:55:13.888848
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[int](datetime.date.today(), "Test Entry", 0)
    je.post(datetime.date.today(), Account("Test Account", AccountType.ASSETS), Quantity(1))
    je.post(datetime.date.today(), Account("Test Account", AccountType.EXPENSES), Quantity(-1))
    je.validate()

# Generated at 2022-06-12 05:55:24.676469
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import callable, cast
    from ..commons.zeitgeist import DateRange
    ReadJournalEntries = ReadJournalEntries
    e = ReadJournalEntries
    t = DateRange(
        begin_date=datetime.date(2020, 1, 3),
        end_date=datetime.date(2020, 1, 5),
    )
    def f1(t: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    f2: callable[[DateRange], Iterable[JournalEntry[_T]]] = lambda t: iter([])
    assert isinstance(f1, ReadJournalEntries)
    assert isinstance(f2, ReadJournalEntries)
    assert issubclass(ReadJournalEntries, callable)
    assert callable(f1)
    assert callable(f2)
    #

# Generated at 2022-06-12 05:55:32.573506
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .portfolios import Position
    from ..commons.numbers import USD

    j = JournalEntry[Position]()

    j.post(date=datetime.date(2020, 1, 1), account=Account.of(type=AccountType.EXPENSES, name="xyz"), quantity=100 * USD)
    j.post(date=datetime.date(2020, 1, 2), account=Account.of(type=AccountType.ASSETS, name="ABC"), quantity=100 * USD)
    
    print(j)

# Generated at 2022-06-12 05:55:39.936642
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from . import accounts
    from datetime import date
    journal_entry = JournalEntry[str]('date', 'desc', 'source')
    amt = journal_entry.post(date.today(), accounts.Account('1', '2', '3', '4', '5'), 1)
    assert amt.date == date.today()
    assert amt.description == 'desc'
    assert amt.source == 'source'

# Generated at 2022-06-12 05:55:45.768699
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Create an account to post to
    account = Account(name="Checking", type=AccountType.ASSETS)

    # Create a journal entry
    journal = JournalEntry(
        date = datetime.date(2019,12,31),
        description = "Debit on 2019-12-31",
        source = "Debit",
    )
    journal.post(date = datetime.date(2019,12,31), account = account, quantity = Amount(10))
    journal.post(date = datetime.date(2019,12,31), account = account, quantity = Amount(10))

    # Validate the journal entry
    journal.validate()

# Generated at 2022-06-12 05:55:53.196578
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType
    from datetime import date


# Generated at 2022-06-12 05:57:06.390966
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from bookkeeper.commons.zeitgeist import DateRange
    assert True

# Generated at 2022-06-12 05:57:15.701885
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # data
    acct = Account("account")
    j1 = JournalEntry("date", "description", "source")
    j1.post("date", acct, 500)

    # Test case 1:
    acct2 = Account("account2")
    j2 = JournalEntry("date", "description", "source")
    j2.post("date", acct, -500)
    j2.post("date", acct2, 500)

    # Test case 2:
    j3 = JournalEntry("date", "description", "source")
    j3.post("date", acct, -500)
    j3.post("date", acct2, 499)

    # Test case 3:
    j4 = JournalEntry("date", "description", "source")
    j4.post("date", acct, -500)
   

# Generated at 2022-06-12 05:57:18.880586
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je1=JournalEntry
    je1.date=1
    je1.description="test"
    je1.source
    je1.post(1, 1, 1)
    je1.validate()
    print("Test journal entry validate pass")

# Generated at 2022-06-12 05:57:29.042233
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from unittest import TestCase, mock
    from datetime import date
    from ..commons.zeitgeist import DateRange

    class StubJournal(JournalEntry[int]):
        pass

    period = DateRange(date(2000, 1, 1), date(2000, 2, 1))

    read_journal_entries = ReadJournalEntries[int]
    @read_journal_entries
    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[int]]:
        yield StubJournal(date(2000, 1, 1), "A Journal", None, [])

    result = _read_journal_entries(period)
    assert isinstance(result, Iterable[JournalEntry[int]])


# Generated at 2022-06-12 05:57:30.411072
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert issubclass(ReadJournalEntries, Protocol)

# Generated at 2022-06-12 05:57:40.886152
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    It should raise AssertionError when total debits and total credits do not match.
    """
    from .accounts import Accounts

    # Set up:
    accounts = Accounts()
    account_a = accounts.create("A", AccountType.ASSETS)  # Debit account
    account_b = accounts.create("B", AccountType.EXPENSES)  # Credit account
    account_c = accounts.create("C", AccountType.LIABILITIES)  # Debit account
    account_d = accounts.create("D", AccountType.REVENUES)  # Credit account

    # Test: Only Debits
    je = JournalEntry(None, None, None)
    je.post(None, account_a, 1)
    je.post(None, account_a, 2)

# Generated at 2022-06-12 05:57:48.229328
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class StoreItem:
        ...

    @dataclass(frozen=True)
    class StorePurchase:
        ...

    @dataclass(frozen=True)
    class StoreSale:
        ...

    def read_store_journal_entries(period: DateRange) -> Iterable[JournalEntry[StoreItem]]:
        ...


# Generated at 2022-06-12 05:57:53.715708
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Given
    journal = JournalEntry(datetime.date(2020, 3, 21), "", None)
    journal.post(datetime.date(2020, 3, 21), Account("101", "" ), 100)
    journal.post(datetime.date(2020, 3, 21), Account("102", "" ), -100)

    # When
    journal.validate()

    # Then

# Generated at 2022-06-12 05:58:03.368101
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import get_all_accounts
    from .libraries import get_library_by_name

    ## Get all accounts:
    all_accounts = get_all_accounts()

    ## Get library (for source/business-objects):
    library = get_library_by_name("library_with_books")

    ## Build a journal entry:
    j = JournalEntry[library.Book]()
    j.description = "Sales"
    j.date = datetime.date.today()
    j.source = library.get_book("XYZ")
    j.post(j.date, all_accounts["Revenues"], +1)
    j.post(j.date, all_accounts["Assets"], -1)
    j.validate()

# Generated at 2022-06-12 05:58:14.032496
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import Tuple
    from .accounts import Account, AccountType
    from .currencies import USD, EUR
    from .exchange import CurrencyExchangeRates
    from .portfolios import Portfolio
    from .pricequotes import PriceQuotes, PriceQuoteCurve, PriceQuote
    from .transactions import Transaction
    from .transactiontables import TransactionTable

    ## Create test objects.