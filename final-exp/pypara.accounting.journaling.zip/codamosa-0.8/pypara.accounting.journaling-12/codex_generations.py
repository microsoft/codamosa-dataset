

# Generated at 2022-06-12 05:48:40.605561
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    def _(self, date: datetime.date, account: Account, quantity: Quantity) -> "JournalEntry[_T]":
        if not quantity.is_zero():
            self.postings.append(Posting(self, date, account, Direction.of(quantity), Amount(abs(quantity))))
        return self
    def validate(self) -> None:
        total_debit = isum(i.amount for i in self.debits)
        total_credit = isum(i.amount for i in self.credits)
        assert total_debit == total_credit, f"Total Debits and Credits are not equal: {total_debit} != {total_credit}"
    journal_entry = JournalEntry[None]
    journal_entry.post = _
    journal_entry.validate = validate

# Generated at 2022-06-12 05:48:41.631314
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-12 05:48:53.104498
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Tests the validations done in the validate method of the JournalEntry class.

    :raises AssertionError: If the validation fails.
    """
    account1 = Account("Acc 1", AccountType.ASSETS)
    account2 = Account("Acc 2", AccountType.REVENUES)
    account3 = Account("Acc 3", AccountType.EXPENSES)

    journal1 = JournalEntry[object](datetime.date.today(), "Test Journal", object())
    journal1.post(datetime.date.today(), account1, 100)
    journal1.post(datetime.date.today(), account2, -100)

    journal2 = JournalEntry[object](datetime.date.today(), "Test Journal", object())
    journal2.post(datetime.date.today(), account2, -100)

# Generated at 2022-06-12 05:49:05.495618
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Unit test for method post of class JournalEntry
    """
    from .accounts import Account

    #create some account for testing
    account_cash = Account(
        guid=makeguid(),
        name='Cash',
        short_name='CASH',
        type=AccountType.ASSETS,
        parent=None
    )

    account_revenue = Account(
        guid=makeguid(),
        name='Revenue',
        short_name='REVENUE',
        type=AccountType.REVENUES,
        parent=None
    )

    #create random source
    source = str(makeguid())

    #create journal entry
    je = JournalEntry(
        makeguid(),
        'Test Journal Entry',
        source
    )

    #post the journal entry

# Generated at 2022-06-12 05:49:06.418361
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass


# Generated at 2022-06-12 05:49:09.046692
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    t = datetime.date(2020, 1, 1)
    je = JournalEntry[None](t, "", None)
    with pytest.raises(AssertionError):
        je.validate()

# Generated at 2022-06-12 05:49:18.173596
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # create a journal entry
    myJournal = JournalEntry[str]('2020-11-30','this is a test', 'business object')
    # add 2 postings to the journal entry
    myJournal.postings.append( Posting(myJournal, '2020-11-30', Account('Assets', 'Cash', 'USD'), Direction.INC, Amount(10000)) )
    myJournal.postings.append( Posting(myJournal, '2020-11-30', Account('Expenses', 'Payroll', 'USD'), Direction.DEC, Amount(10000)) )
    # validate the journal entry
    myJournal.validate()
    # all good
    print('Sucess: Journal Entry is valid')

# Generated at 2022-06-12 05:49:28.895042
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .products import Product, ProductPrice

    # Creating the Categories
    my_account_type1 = AccountType("VTS", "Visual Thinking Strategies")
    my_account_type2 = AccountType("ATC", "At the Center")
    my_account_type3 = AccountType("PCC", "Private Consultations and Coaching")
    my_account_type4 = AccountType("TFS", "Teaching for Success")
    my_account_type5 = AccountType("FNH", "Funding and Support")
    my_account_type6 = AccountType("COST", "Costs of Goods Sold")
    my_account_type7 = AccountType("EXP", "Expenses")
    my_account_type8 = AccountType("REV", "Revenue")

# Generated at 2022-06-12 05:49:33.634485
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class BusinessObject:
        guid: Guid

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        guid: Guid
        source: _T

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        import random
        import string
        return []

    read_journal_entries(DateRange.of(datetime.date.today()))

# Generated at 2022-06-12 05:49:42.810542
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # test if post a debit entry works
    @dataclass(frozen=True)
    class Source:
        pass

    source = Source()

    journal = JournalEntry[Source](date = datetime.date.today(), description= "test post debit entry", source = source)
    assert journal.post(date = datetime.date.today(), account = Account("some debit account", AccountType.ASSETS), quantity = Quantity(12.345)).postings[0].is_debit
    # test if post a credit entry works
    journal = JournalEntry[Source](date = datetime.date.today(), description= "test post credit entry", source = source)
    assert journal.post(date = datetime.date.today(), account = Account("some credit account", AccountType.REVENUES), quantity = Quantity(12.345)).postings[0].is_credit

# Generated at 2022-06-12 05:49:52.360796
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    with JournalEntry(datetime.date(2020, 1, 1), 'Test', 'TestSource') as je:
        je.post(je.date, Account("Test", AccountType.ASSETS), 100)
        je.post(je.date, Account("Test", AccountType.EXPENSES), -100)
    je.validate()

# Generated at 2022-06-12 05:49:53.351512
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je: JournalEntry[_T] = None

# Generated at 2022-06-12 05:50:05.423555
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    # Test with same total debit and total credit amounts
    journal_entry_debit = JournalEntry(datetime.date(2018, 1, 31), "desc1", Guid())
    journal_entry_debit.post(datetime.date(2018, 1, 31), Account("acc1", AccountType.ASSETS, Guid()), 1000)
    journal_entry_debit.post(datetime.date(2018, 1, 31), Account("acc2", AccountType.REVENUES, Guid()), -1000)
    journal_entry_debit.validate()

    journal_entry_credit = JournalEntry(datetime.date(2018, 1, 31), "desc2", Guid())
    journal_entry_credit.post(datetime.date(2018, 1, 31), Account("acc3", AccountType.ASSETS, Guid()), -1000)
    journal

# Generated at 2022-06-12 05:50:09.380595
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    with pytest.raises(AssertionError) as e: #raises an error when the assert is false
        JournalEntry(date=(datetime.date.today()), description="Accounting Journal Entry #1", source="Source 1").validate()
    assert e.type == AssertionError #test to see if the error is of type AssertionError


# Generated at 2022-06-12 05:50:14.817693
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(
        "2018-11-03",
        "Description",
        "Source"
    )

    j.post(
        date="2018-11-03",
        account=Account("Account", "Code", AccountType.ASSETS),
        quantity=100
    )

    assert j.postings[0].amount == 100

# Generated at 2022-06-12 05:50:20.625546
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry(datetime.date(2020,2,2), 'test',None)
    j.post(datetime.date(2020,2,2),Account(AccountType.ASSETS,"ASSETS","ASSETS"),100)
    j.post(datetime.date(2020,2,2),Account(AccountType.ASSETS,"ASSETS","ASSETS"),-100)

    j.validate()

# Generated at 2022-06-12 05:50:32.786818
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # TEST1 COMPLETE
    # Making test journal entries
    test_entry1 = JournalEntry(datetime.date(2019, 3, 4), "test1", 1)
    test_entry2 = JournalEntry(datetime.date(2019, 3, 4), "test2", 1)
    test_entry3 = JournalEntry(datetime.date(2019, 3, 4), "test3", 1)
    test_entry4 = JournalEntry(datetime.date(2019, 3, 4), "test4", 1)
    test_entry5 = JournalEntry(datetime.date(2019, 3, 4), "test5", 1)
    test_entry6 = JournalEntry(datetime.date(2019, 3, 4), "test6", 1)

    # TEST2 EXCEPTION
    # Making test journal entries which will raise exception
    test_entry

# Generated at 2022-06-12 05:50:40.676189
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class FakeJournalEntry(JournalEntry[int]):
        pass

    #: Takes a date range and returns a list of journal entries.
    def read_journals(period: DateRange) -> Iterable[FakeJournalEntry]:
        return [
            FakeJournalEntry(datetime.date(2019, 1, 1), "Test Journal", 123, [])
        ]

    def _test(period: DateRange):
        assert list(ReadJournalEntries.__call__(read_journals, period)) == read_journals(period)

    _test(DateRange(datetime.date(2018, 12, 31), datetime.date(2019, 1, 1)))

# Generated at 2022-06-12 05:50:41.324880
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True

# Generated at 2022-06-12 05:50:50.869090
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import RealAccount
    from .transactions import FakeTransaction_book_sales_invoice, FakeTransaction_book_purchase_invoice

    sales_invoice = FakeTransaction_book_sales_invoice.create()
    purchase_invoice = FakeTransaction_book_purchase_invoice.create()

    journal_entry = JournalEntry[None]\
        .post(sales_invoice.date, RealAccount.SALES, sales_invoice.sales - purchase_invoice.sales_tax)\
        .post(sales_invoice.date, RealAccount.TAX_PAID, purchase_invoice.sales_tax)\
        .post(sales_invoice.date, RealAccount.ACCOUNTS_RECEIVABLE, sales_invoice.total)

    return journal_entry

# Generated at 2022-06-12 05:51:08.383463
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .companies import Company
    from .finances import Money
    from .trading import Inventory
    from .reporting import AccumulateByDate

    def test_setup():
        # Defines a simple test as follows
        #  * +100u on Stock Asset
        #  * +100u on Inventory Asset
        #  * +100u on Capital Equity
        #  * +100u on Sales Revenue
        #  * -100u on Inventory Expense
        #  * -100u on Capital Equity

        # Defines a money with units `u`
        money = Money("u")

        # Defines a company
        company = Company()

        # Define a journal entry
        j = JournalEntry(datetime.date(2000, 1, 1), "Test", company)

        # Define accounts

# Generated at 2022-06-12 05:51:09.048808
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:51:19.559947
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.testing import assert_journal_entries_equal
    from ..commons.times import january, april, june
    from .accounts import AccountType
    from . import accounts

    ASSETS = Account("Assets", AccountType.ASSETS, "Assets of the organization.")
    REVENUE = Account("Revenue", AccountType.REVENUES, "Revenue of the organization.")
    EXPENSES = Account("Expenses", AccountType.EXPENSES, "Expenses of the organization.")

    ## Perform posting and validate:

# Generated at 2022-06-12 05:51:26.072530
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime as dt

    def read_journals(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []

    read_journal = ReadJournalEntries(List[JournalEntry[_T]])
    assert read_journal(DateRange(dt.date(2020, 1, 1), dt.date(2020, 2, 1))) is None


# Generated at 2022-06-12 05:51:36.968508
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    # create journal entry
    journal = JournalEntry("2019-01-01", "Buy a book", "")
    journal.post("2019-01-01", Account("Cash", "Assets"), Quantity(100))
    journal.post("2019-01-01", Account("Book", "Assets"), Quantity(-100))
    # journal will be 
    # JournalEntry(
    #     date=datetime.date(2019, 1, 1),
    #     description='Buy a book',
    #     source='',
    #     postings=[
    #         Posting(
    #             journal=<__main__.JournalEntry object at 0x0000029ECC5F27B8>,
    #             date=datetime.date(2019, 1, 1),


# Generated at 2022-06-12 05:51:44.623994
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType
    from .events import EventType
    from .events.accounts import AccountEvent
    from .events.transactions import TransactionEvent, TransactionType

    #: Sample journal entries.

# Generated at 2022-06-12 05:51:50.415615
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry[Base]("2020-01-01", "journaalpost", "source")
    j.post(datetime.datetime.now(), Account.ASSETS_CASH, 10)
    assert len(j.postings) == 1
    assert j.postings[0].amount == Amount(10)

test_JournalEntry_post()


# Generated at 2022-06-12 05:52:03.261970
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from sys import float_info

    from .accounts import Account, AccountType

    ##

# Generated at 2022-06-12 05:52:08.174384
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.transactions import Transaction
    from ..books.accounts import ExpenseAccount
    from .accounts import AssetsAccount
    assert not Transaction().postings
    assert Transaction().post(date=datetime.date.today(),
                              account=AssetsAccount(name="Cash"),
                              quantity=100).post(date=datetime.date.today(),
                                                 account=ExpenseAccount(name="Salaries"),
                                                 quantity=-100).postings

# Generated at 2022-06-12 05:52:08.856630
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True

# Generated at 2022-06-12 05:52:33.153905
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry[int](
        datetime.date(2020, 7, 11), "Description", source=1, postings=[Posting(j, date=datetime.date(2020, 7, 11), account=Account.ASSETS, direction=Direction.INC, amount=Amount(10))],
    )
    j.validate()
    print(j)

# Generated at 2022-06-12 05:52:41.182394
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # given
    from .accounts import AccountFactory
    from .currencies import CurrencyFactory
    from .istream import MemoryAccountBook
    from .streams import AccountBookStream
    from .valuation import Valuation

    currency_eur = CurrencyFactory("EUR")
    factory = AccountFactory("TST")
    account1 = factory(currency_eur)
    account2 = factory(currency_eur)
    journal = JournalEntry("2019-01-01", "Test Journal Entry")
    account_book = MemoryAccountBook(AccountBookStream("TEST", "2019-01-01", Valuation.TWD, [account1, account2]))

    # when
    journal.post(account_book, "2019-01-01", account1, 1)
    journal.post(account_book, "2019-01-02", account1, 2)


# Generated at 2022-06-12 05:52:47.067845
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .transactions import Transaction
    j = JournalEntry(datetime.date(2018,1,1), "New Year", Transaction(3))
    j.post(j.date, Account("Assets", AccountType.ASSETS), +10)
    j.post(j.date, Account("Equity", AccountType.EQUITIES), +10)
    j.validate()

# Generated at 2022-06-12 05:52:54.876562
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from unittest import TestCase, main

    from ..finance.cost_centers import CostCenter
    from ..finance.ledgers import Ledger
    from ..finance.transactions import Transaction
    from ..parties.creditors import Creditor
    from ..parties.debtors import Debtor
    from ..parties.entities import Person, PersonName

    class Test(TestCase):
        def test_entries_read_ok(self):
            # Arrange.
            debtor_name = PersonName("Mrs", "M", "Smith")
            debtor = Debtor(Person(debtor_name, "smith@mail.com", "555", "web"), "123")
            creditor_name = PersonName("Mr", "N", "Jones")

# Generated at 2022-06-12 05:52:59.768377
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[None](
        date=datetime.date.today(), description="Test JournalEntry", source=None
    )
    je.post(date=datetime.date.today(), account=Account(name="Debit-Account"), quantity=1)
    je.post(date=datetime.date.today(), account=Account(name="Credit-Account"), quantity=-1)
    je.validate()

# Generated at 2022-06-12 05:53:12.545364
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
        # Create a journal entry
        j1 = JournalEntry(datetime.date(2000,1,1),"test",None)
        j1.post(datetime.date(2000,1,1), Account("Assets", AccountType.ASSETS), +1000)
        j1.post(datetime.date(2000,1,1), Account("Expenses", AccountType.EXPENSES), -1000)
        # check whether validate() works in the case of a correct journal entry
        j1.validate()

        # Create a journal entry
        j1 = JournalEntry(datetime.date(2000,1,1),"test",None)
        j1.post(datetime.date(2000,1,1), Account("Assets", AccountType.ASSETS), -1000)

# Generated at 2022-06-12 05:53:13.147397
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:53:16.086773
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    jentry: JournalEntry[_T] = JournalEntry(_debit_mapping, Direction.INC, datetime.date.today(), "teste", Guid)
    jentry.validate()

# Generated at 2022-06-12 05:53:19.780707
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert JournalEntry(date=datetime.date(2020,1,1),description="description",source="Test Journal Entry").validate()

# Generated at 2022-06-12 05:53:23.212030
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    a = Account("Asset:Bank:Savings")
    b = Account("Expense:Food")
    je = JournalEntry(datetime.date.today(), "", None).post("Expense", 100).post("Asset", -100)
    je.validate()

# Generated at 2022-06-12 05:54:40.805631
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType
    from .ledgers import Ledger
    from .books import Book
    from .transactions import Transaction
    from .events import Event

    book = Book()
    ledger = Ledger()

    # Similar to bringing on capital from the owner
    event = Event("Start of Accounting", datetime.date(2020, 1, 1), 1_000.00)
    transaction = book.create_transaction("Open Ledger")
    transaction.add(event)
    event.post(transaction, ledger)
    transaction.commit()

    journal_entry = ledger.journal_entries.get(event.journal_entry_guid)
    print("Guid:", journal_entry.guid)
    print("Date:", journal_entry.date)
    print("Description:", journal_entry.description)

# Generated at 2022-06-12 05:54:48.637819
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Used to test default factory field
    # Check postings is an empty list
    # The test_cases:
    # 1. Input quantity that is zero
    # 2. Input a positive quantity
    # 3. Input a negative quantity
    test_cases = [
        # Date of posting
        # Account to post the amount to
        # Signed-value to post to the account
        # Expected result (none)
        (datetime.date(2018, 5, 1), "Cash", 0),
        (datetime.date(2018, 5, 1), "Cash", 10),
        (datetime.date(2018, 5, 1), "Cash", -10)
    ]

    for date, account, quantity in test_cases:
        j = JournalEntry(date, "description", None)
        j.post(date, account, quantity)
        assert j

# Generated at 2022-06-12 05:54:54.782094
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from .accounts import Account, AccountType

    today = date.today()
    journal = JournalEntry(today, 'test', 'test')
    journal.post(today, Account('Renta', AccountType.EXPENSES), -200)
    journal.post(today, Account('Salario', AccountType.REVENUES), 200)
    assert len(journal.postings) == 2

# Generated at 2022-06-12 05:54:55.534813
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    assert False

# Generated at 2022-06-12 05:55:07.035894
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from random import choice
    from .accounts import Account, Asset, Expense, Liability
    from .trade import Buy, Sell
    
    def random_account_generator():
        yield from (Asset(1, "Cash"), Asset(2, "Receivables"),
                    Expense(3, "Sales Commissions"), Expense(4, "Operating Expenses"),
                    Liability(5, "Borrowings"))
    
    def random_guid():
        return choice(range(100))
    
    def random_posting(journal_entry):
        yield from (Posting(journal_entry, choice(range(1, 10)), choice(random_account_generator()), choice((Direction.INC, Direction.DEC)), 100)
                    for _ in range(1, 3))
    

# Generated at 2022-06-12 05:55:16.523087
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Test the method post of class JournalEntry
    """
    # pylint:disable=unused-argument
    def _is_valid_journal_entry(date: datetime.date, description: str, source) -> bool:
        """
        Returns true if the journal entry is valid.
        :param date: Date of journal entry
        :param description: Description of journal entry
        :param source: Source of journal entry
        :return: Returns true if journal entry is valid
        """
        return True

    # Initialize
    journal_entry = JournalEntry(_is_valid_journal_entry, "Test", "Source")
    date = datetime.date(2020, 1, 1)
    account = Account("Assets", AccountType.ASSETS)
    quantity1 = Quantity(100.0)
    quantity2 = Quantity(-100.0)

# Generated at 2022-06-12 05:55:21.729581
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    assert(JournalEntry(datetime.date(2020,2,2), "JournalEntry_post", "JournalEntry_post").post(datetime.date(2020,2,2), Account(AccountType.EQUITIES, "JournalEntry_post") , 5000).postings[0].amount.value == 5000)


# Generated at 2022-06-12 05:55:27.014138
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    j = JournalEntry(date=datetime.date(2017, 7, 1), description="Test")
    j.post(account=Account("101", "Assets", AccountType.ASSETS), quantity=1000)
    j.post(account=Account("202", "Equities", AccountType.EQUITIES), quantity=-1000)
    j.validate()

# Generated at 2022-06-12 05:55:36.091532
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import create_accounts
    from .ledgers import Ledger, LedgerEntry

    # Test 1:
    def Test_Case_1(entry: LedgerEntry):
        j = JournalEntry(entry.date, entry.description, entry.source)
        j.post(
            entry.date,
            create_accounts([(AccountType.ASSETS, "Cash")])[0],
            -entry.quantity
        )
        j.post(
            entry.date,
            entry.account,
            entry.quantity
        )
        return j

    # Execute test 1:
    j1 = Test_Case_1(Ledger.create_entry(datetime.date(year=2020, month=1, day=1), "Buy stuff", "XYZ", "Cash", 100))

# Generated at 2022-06-12 05:55:44.672008
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountData
    from .accounts import AccountType
    from .accounts import Ledger
    ledger = Ledger()
    ledger.add(AccountData(name="Cash", type=AccountType.ASSETS))
    ledger.add(AccountData(name="Revenues", type=AccountType.REVENUES))
    j_ent = JournalEntry(date=datetime.date(2020, 1, 1), description="New Year's Day", source=ledger.balances)
    j_ent.post(date=datetime.date(2020, 1, 1), account=ledger.lookup("Cash"), quantity=1000)
    j_ent.post(date=datetime.date(2020, 1, 1), account=ledger.lookup("Revenues"), quantity=-1000)
    j_ent.validate()

# Generated at 2022-06-12 05:57:07.818177
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..accounts._accounts import _Account
    from ..accounts.accounts import Account, AccountType, BalanceSheetAccount, IncomeStatementAccount

    from .postings import _post_journal_entry, _post_to_accounts

    # 1. Account
    avco_income = Account(
        AccountType.REVENUES,
        BalanceSheetAccount.sales,
        IncomeStatementAccount.sales,
        "AVCO Income",
        False,
    )
    coffee_beans = Account(
        AccountType.ASSETS,
        BalanceSheetAccount.inventory,
        None,
        "Coffee Beans",
        False,
    )

# Generated at 2022-06-12 05:57:14.888901
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Scenario 1: Valid data -> returns JournalEntry
    # Given a JournalEntry
    je = JournalEntry[Posting]()
    # When I post a value to an account
    result = je.post(datetime.date(2019, 4, 12), Account("Assets", AccountType.ASSETS), Quantity(+123.45))
    # Then the result should be of type JournalEntry
    assert isinstance(result, JournalEntry.__class__)
    # And the amount should be 123.45
    assert result.postings[0].amount == Amount(123.45)



# Generated at 2022-06-12 05:57:20.469320
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from dataclasses import field, dataclass
    @dataclass(frozen=True)
    class Bus:
        a: int
    def read_journal_entries(period: DateRange):
        return [ JournalEntry[Bus](date(2020,1,1), "", Bus(1)) ]
    ReadJournalEntries[Bus]().__call__(DateRange(date(2020,1,1), date(2020,1,2)))

# Generated at 2022-06-12 05:57:26.350099
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal = JournalEntry(
        datetime.date(2020, 1, 1),
        "Pay Self",
        None,
        [
            Posting(None, datetime.date(2020, 1, 1), Account("Assets", "Income"), Direction.INC, Amount(100)),
            Posting(None, datetime.date(2020, 1, 1), Account("Expenses", "Pay"), Direction.DEC, Amount(100)),
        ],
    )
    assert journal.validate() is None

# Generated at 2022-06-12 05:57:28.037313
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False, "Implement me."



# Generated at 2022-06-12 05:57:31.709748
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    def f(period):
        if period == DateRange(datetime.date(2020, 5, 1), datetime.date(2020, 5, 31)):
            return []
        else:
            return None

    assert isinstance(f, ReadJournalEntries)

# Generated at 2022-06-12 05:57:38.877489
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class DummySource:
        pass

    def read() -> Iterable[JournalEntry[DummySource]]:
        yield JournalEntry(datetime.date(2019, 1, 1), "", DummySource())

    protocol = ReadJournalEntries.__protocol__
    assert protocol.__getitem__(ReadJournalEntries[DummySource]) == ReadJournalEntries

    read: ReadJournalEntries[DummySource] = read
    assert list(read(DateRange.unbounded)) == read()

# Generated at 2022-06-12 05:57:47.449923
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .prices import Price, PriceValue, PricePart
    from dataclasses import dataclass, field
    from datetime import date
    from typing import List, Optional

    @dataclass
    class Model:
        data: str

    def make_journal_entry(date: date, description: str, src: Model, postings: List[Price]) -> JournalEntry[Model]:
        """
        Helper function to make a journal entry.
        """
        journal = JournalEntry(date, description, src)
        for posting in postings:
            journal.post(date, posting.currency.account, posting.quantity)
        return journal

    # Test data
    date = date(2020, 1, 1)
    description = "Journal Entry 1"
    src = Model

# Generated at 2022-06-12 05:57:58.884446
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import get_accounts
    from .accounts import AccountType as at
    import datetime
    
    def test_JournalEntry_validate():
        accounts = get_accounts()
        accounts.add('Expenses', account_type=at.EXPENSES)
        accounts.add('Income', account_type=at.REVENUES)
        accounts.add('Sales', account_type=at.REVENUES)
        accounts.add('Cash', account_type=at.ASSETS)
        accounts.add('Assets', account_type=at.ASSETS)
        accounts.add('Liabilities', account_type=at.LIABILITIES)
        asset_accounts = accounts.filter_by(account_type=at.ASSETS)

# Generated at 2022-06-12 05:58:09.210854
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass
    class Source(Generic[_U]):
        value: _U

    # noinspection PyMissingOrEmptyDocstring
    def _call(self, period: DateRange) -> Iterable[JournalEntry[_U]]:
        return [JournalEntry(datetime.date.today(), "", self.value, [])]

    # noinspection PyMissingOrEmptyDocstring
    @dataclass
    class _ReadJournalEntries(ReadJournalEntries[_U]):
        @property
        def sample(self) -> _U:
            return random.choice([True, False])

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_U]]:
            return _call(self, period)

    # noinspection PyMissingOrEmptyDocstring