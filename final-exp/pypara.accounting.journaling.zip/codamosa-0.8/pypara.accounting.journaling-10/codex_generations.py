

# Generated at 2022-06-12 05:48:43.333062
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account

    from .accounts import AccountType

    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import AccountType

    # Test with 1 post

    j = JournalEntry[Account]()
    j.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, 'EUR'), 1000)
    j.validate()

# Generated at 2022-06-12 05:48:52.663366
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Unit test for method post of class JournalEntry
    """
    from datetime import date

    cash = Account(0, 'Cash', AccountType.ASSETS)
    bill = Account(1, 'Bill', AccountType.EQUITIES)
    date = date(year=2019, month=1, day=1)
    journal_entry = JournalEntry(date, 'test', None)

    journal_entry.post(date, cash, 100)
    journal_entry.post(date, bill, -100)
    print(journal_entry)


if __name__ == "__main__":
    test_JournalEntry_post()

# Generated at 2022-06-12 05:49:03.973415
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.amounts import Amount, Amounts
    from ..commons.numbers import Quantity, Quantities
    #from ..commons.zeitgeist import DateRange
    from ..modules.journals import (Direction, JournalEntry,
    Posting)
    from ..modules.accounts import Account, AccountType, Accounts

    jp = JournalEntry["test"](
        date = datetime.date.today(),
        description="test",
        source="test"
    )

    jp.post(date=datetime.date.today(),account=Accounts.EQUITIES.OPENING,
            quantity=Quantity(100))
    jp.post(date=datetime.date.today(),account=Accounts.EXPENSES.TAXES,
            quantity=Quantity(100))

    print(jp)

# Generated at 2022-06-12 05:49:10.578217
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import Callable
    @dataclass(frozen=True)
    class SomeType: pass

    source: SomeType = SomeType()
    je: JournalEntry[SomeType] = JournalEntry(datetime.date(2020, 1, 1), "Test", source)
    def _read_journa_entries(period: DateRange) -> Iterable[JournalEntry[SomeType]]:
        yield je
    _: ReadJournalEntries[SomeType] = _read_journa_entries

# Generated at 2022-06-12 05:49:13.138908
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    # 
    # Act
    pass
    
    # Assert
    pass
    

# Generated at 2022-06-12 05:49:24.458133
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .books import Book
    from .periods import Period
    from .transactions import Transaction

    ## Setup:
    journal_entry = JournalEntry.build(datetime.date(2020, 9, 1), "Unit Test")

    ## Assert:
    assert len(journal_entry.postings) == 0

    ## Post a debit posting:
    journal_entry.post(datetime.date(2020, 9, 1), Account.build("CASH", AccountType.ASSETS), +100)
    assert len(journal_entry.postings) == 1
    assert journal_entry.postings[0].direction == Direction.INC
    assert journal_entry.postings[0].account.name == "CASH"
    assert journal_entry.postings[0].amount == 100

    ## Post a credit

# Generated at 2022-06-12 05:49:33.641897
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    class TestAccount(Account):
        def __init__(self, number, name, balance, account_type):
            super().__init__(number, name, account_type)
            self.balance = balance
        def get_balance(self, period):
            return self.balance
    class TestAssetAccount(TestAccount):
        account_type = AccountType.ASSETS
    class TestLiabilityAccount(TestAccount):
        account_type = AccountType.LIABILITIES
    class TestEqAccount(TestAccount):
        account_type = AccountType.EQUITIES
    class TestEIaccount(TestAccount):
        account_type = AccountType.EXPENSES
    class TestRvAccount(TestAccount):
        account_type = AccountType.REVENUES


# Generated at 2022-06-12 05:49:38.873455
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(datetime.date(2020, 1, 1), "test", "test")
    journal.post(datetime.date(2020, 1, 1), Account("Test"), Quantity(120))
    assert journal.postings[0].date == datetime.date(2020, 1, 1)
    assert journal.postings[0].account.name == "Test"
    assert journal.postings[0].amount == Quantity(120)

# Generated at 2022-06-12 05:49:46.022865
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.ledgers import LedgerAccount
    journal = JournalEntry[None]
    date = datetime.date(2019, 10, 21)
    account = LedgerAccount(code='100100', title='Cash', type=AccountType.ASSETS)
    quantity = 100000
    journal.post(date, account, quantity)
    assert journal.postings[0].date == date
    assert journal.postings[0].account == account
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].amount == 100000


# Generated at 2022-06-12 05:49:53.029893
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Unit test for method __call__ of class ReadJournalEntries
    """

    a_period = DateRange(datetime.date(2019, 11, 21), datetime.date(2019, 11, 21))

    class Impl(ReadJournalEntries[_T]):
        """ Implementaion of ReadJournalEntries[_T] """
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return []

    result = Impl()(a_period)
    assert result == []

# Generated at 2022-06-12 05:50:07.766104
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account, account_type, account
    from .tags import Tag, tags
    from .tags_types import TagType, tags_type

    """
    Provided given the TagType "CODE", a code Tag is created.

    :return:
    """
    new_TagType = tags_type.new("CODE", "")

    """
    Provided given the TagType "CODE", a code Tag is created.

    :return:
    """
    new_Tag = tags.new("Python Code", new_TagType)

    """
    Provided given the name "ASSET", a type Account is created.

    :return:
    """
    new_AccountType = account_type.new("ASSET", "")


# Generated at 2022-06-12 05:50:16.203713
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType

    journal = JournalEntry[str](
        date = datetime.date(2019, 3, 30),
        description = "Purchased some inventory items.",
        source = "Inventory purchase receipt #INV-2019-12345",
        )
    journal.post(journal.date,
        Account(AccountType.ASSETS, 'Inventory'),
        Quantity(100)
        )
    journal.post(journal.date,
        Account(AccountType.EXPENSES, 'Purchases'),
        Quantity(100)
        )
    journal.validate()
    print('Validated')

# Generated at 2022-06-12 05:50:20.722440
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange

    rje = ReadJournalEntries[str]

    # coerce type
    assert isinstance(rje.__call__, Callable[[DateRange], Iterable[JournalEntry[str]]])

    #Unit test for method __call__ of class ReadJournalEntries ends

# Generated at 2022-06-12 05:50:22.228790
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:50:33.429847
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.accounts import AccountType
    from ..books.accounts import Account
    from ..books.ledgers import Ledger
    from ..books.ledgers import LedgerCodes
    from ..books.ledgers import LedgerFactory
    from ..books.ledgers import LedgerManager
    from ..books.ledgers import LedgerMock
    from ..books.ledgers import LedgerRepository
    from ..books.ledgers import LedgerType
    from ..commons.others import Guid
    import datetime
    from dataclasses import dataclass, field
    from enum import Enum
    from typing import Dict, Iterable, List, Set, TypeVar
    from dataclasses import dataclass
    from typing import Generic, TypeVar
    from ..commons.numbers import Amount, Quantity


# Generated at 2022-06-12 05:50:41.369653
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account = Account("Dummy")
    journal_entry = JournalEntry(
        date = datetime.date.today(),
        description = "Journal Entry Test",
        source = "Journal Entry Test",
    )
    journal_entry.post(date = datetime.date.today(), account = account, quantity = 10)
    assert journal_entry.postings[0].amount == 10
    journal_entry.post(date = datetime.date.today(), account = account, quantity = -5)
    assert journal_entry.postings[1].amount == 5
    journal_entry.post(date = datetime.date.today(), account = account, quantity = 0)
    assert len(journal_entry.postings) == 2

# Generated at 2022-06-12 05:50:45.216055
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Variable declaration
    je = JournalEntry(None, None, None)
    date = None
    account = None
    quantity = Quantity(0)
    je.post(date, account, quantity)

# Generated at 2022-06-12 05:50:52.214725
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account1 = Account("Dummy", AccountType.REVENUES)
    account2 = Account("Dummy", AccountType.EXPENSES)
    account3 = Account("Dummy", AccountType.REVENUES)
    account4 = Account("Dummy", AccountType.ASSETS)
    account5 = Account("Dummy", AccountType.REVENUES)
    account6 = Account("Dummy", AccountType.LIABILITIES)

    source = "Dummy"

# Generated at 2022-06-12 05:51:00.328593
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .simple_accounting_order import Order
    journal = JournalEntry(date=datetime.date.today(), description="Test Journal Entry")

    order = Order(
        date=datetime.date.today(), description="Test Order", customer="Alice", product="Shampoo", quantity=10
    )

    sales_account = Account(description="Sales", type=AccountType.REVENUES)
    inventory_account = Account(description="Inventory", type=AccountType.ASSETS)

    journal.post(date=datetime.date.today(), account=sales_account, quantity=200)
    journal.post(date=datetime.date.today(), account=inventory_account, quantity=-20)

    assert journal.postings[0].is_credit == True
    assert journal.postings[1].is_deb

# Generated at 2022-06-12 05:51:02.583779
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journals(*args, **kwargs): pass
    ReadJournalEntries.__instancecheck__(read_journals)

# Generated at 2022-06-12 05:51:11.267917
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    
    pass


# Generated at 2022-06-12 05:51:14.530522
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # # [Test 1]
    # ## Establish context:
    #
    # ## Execute:
    #
    # ## Verify:
    #
    # ## Cleanup:
    #
    pass



# Generated at 2022-06-12 05:51:15.179506
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:51:17.320722
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    print(f"test_JournalEntry_validate running...")
    assert True
    print(f"test_JournalEntry_validate complete")

# Generated at 2022-06-12 05:51:23.136989
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date = datetime.date(2020, 2, 29)
    description = 'Payment from customer'
    source = 'Customer'
    account = Account('Cash', AccountType.ASSETS)
    amount = 200
    journal_entry = JournalEntry(date, description, source, [])
    journal_entry.post(date, account, amount)
    journal_entry.post(date, account, -amount)
    journal_entry.validate()
    print('validate() OK')

if __name__ == '__main__':
    test_JournalEntry_validate()

# Generated at 2022-06-12 05:51:30.113464
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry[str](
        datetime.date.today(),
        "Posting test",
        "foo"
    )

    je.post(datetime.date.today(), Account("Revenue", AccountType.REVENUES), Quantity(11))
    je.post(datetime.date.today(), Account("Expense", AccountType.EXPENSES), -Quantity(11))

    assert len(je.postings) == 2
    je.validate()



# Generated at 2022-06-12 05:51:39.436227
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Arrange:
    class MyReadJournalEntries(_T):
        def __call__(self, period):
            return [JournalEntry(date=datetime.date(2020, 1, 1), description='Description', source=self, postings=[])]
    read_journal_entries = MyReadJournalEntries()

    # Act:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2020, 1, 1))
    actual = read_journal_entries(period)

    # Assert:
    expected = [JournalEntry(date=datetime.date(2020, 1, 1), description='Description', source=read_journal_entries, postings=[])]
    assert actual == expected

# Generated at 2022-06-12 05:51:50.645157
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    _date = datetime.date(2019,1,1)
    _date_2 = datetime.date(2019,1,2)
    _account = Account()
    _account_2 = Account()
    _quantity = Quantity(100)
    _quantity_2 = Quantity(50)
    _description = "description"
    _description_2 = "description_2"
    _source = object()
    _source_2 = object()

    _journal = JournalEntry(_date, _description, _source)
    _journal_2 = JournalEntry(_date_2, _description_2, _source_2)

    _journal.post(_date, _account, _quantity)
    _journal.post(_date_2, _account_2, _quantity_2)


# Generated at 2022-06-12 05:51:52.417244
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:52:04.272370
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .products import SKU
    from .transactions import JournalEntry, Posting, ReadJournalEntries
    def my_journal_entries(period: DateRange) -> Iterable[JournalEntry[SKU]]:
        """
        Provides the journal entries during the given period.
        """

# Generated at 2022-06-12 05:52:30.172317
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from src.accounting.accounts.accounts import Account, AccountType
    from src.accounting.journal.journal import JournalEntry
    from src.commons.numbers import Amount, Quantity

    journal: JournalEntry[str] = JournalEntry(datetime.date(2020, 1, 1), "Test1", "TEST")
    account: Account = Account("Test", AccountType.ASSETS)
    journal.post(datetime.date(2020, 1, 1), account, Quantity(1000))

    assert journal.postings[0].account == account
    assert journal.postings[0].amount == Amount(Amount(1000).value)

if __name__ == "__main__":
    test_JournalEntry_post()

# Generated at 2022-06-12 05:52:39.585892
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Quantity
    
    @dataclass(frozen=True)
    class MyAccount(Account):
        pass

    @dataclass(frozen=True)
    class MyJournalEntry(JournalEntry[int]):
        pass

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[int]]:
        return [MyJournalEntry.from_postings([
            Posting(None, datetime.date(2016, 1, 1), MyAccount("Revenues"), Direction.INC, Amount(Quantity(122))),
            Posting(None, datetime.date(2016, 1, 1), MyAccount("Sales"), Direction.DEC, Amount(Quantity(122))),
        ])]



# Generated at 2022-06-12 05:52:47.339488
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class Mock:
        """
        Mock object type.
        """

        #: Journal entries mock.
        entries: Iterable[JournalEntry[_T]]

    mock = Mock(entries=[])
    assert list(ReadJournalEntries.__call__(mock, DateRange(datetime.date.today(), datetime.date.today()))) == []
    assert list(ReadJournalEntries.__call__(mock, DateRange(datetime.date.today()-datetime.timedelta(days=10), datetime.date.today()))) == []

# Generated at 2022-06-12 05:52:54.648683
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Accounts
    from .commons.zeitgeist import now

    accounts = Accounts()
    accounts.put(Account("Cash", AccountType.ASSETS))
    accounts.put(Account("Income", AccountType.REVENUES))

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[int]]:
        # type: int -> JournalEntry[int]
        yield JournalEntry(now(), "Foo", source=1).post(now(), accounts["Cash"], 100).post(now(), accounts["Income"], -100)

    journal_entries = read_journal_entries(DateRange.now())
    assert journal_entries is not None
    assert len(list(journal_entries)) == 1

# Generated at 2022-06-12 05:53:01.720017
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass
    class Dummy(ReadJournalEntries[None]):
        entries: List[JournalEntry[None]]

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[None]]:
            return (entry for entry in self.entries if entry.date in period)

    j = JournalEntry(datetime.date(2020, 4, 4), "HEY", None)
    j.post(j.date, Account("A", AccountType.ASSETS), +100)
    j.post(j.date, Account("A", AccountType.EXPENSES), -100)
    dummy = Dummy([j])
    assert list(dummy(DateRange.closed(j.date, j.date))) == [j]

# Generated at 2022-06-12 05:53:11.886012
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journalentry = JournalEntry(
        date=datetime.date(2020,10,3),
        description="This is a Journal Entry",
        source=Account(name='account', type=AccountType.ASSETS, description="an account")
    )
    journalentry.post(date=datetime.date(2020,9,3), account=Account(name='account', type=AccountType.ASSETS, description="an account"), quantity=Quantity(5.0))
    journalentry.post(date=datetime.date(2020,9,3), account=Account(name='account2', type=AccountType.ASSETS, description="an account"), quantity=Quantity(-5.0))
    journalentry.validate()

# Generated at 2022-06-12 05:53:23.928529
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .commodities import Commodity
    from .commons.numbers import Amount
    from .commons.zeitgeist import DatetimeUtils
    import datetime
    import pytest

    # Define a journal entry
    entry = JournalEntry(
        date=DatetimeUtils.today(),
        description="entry",
        source="ID",
        postings=[],
        guid=None)

    # Add required postings
    entry.post(entry.date, Account(account_id="ID", type=AccountType.ASSETS, description="account"), Amount(quantity=10))
    entry.post(entry.date, Account(account_id="ID", type=AccountType.REVENUES, description="account"), Amount(quantity=-10))

    # Test positive scenario
    entry.validate()

   

# Generated at 2022-06-12 05:53:35.831772
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .currencies import USD, EUR
    from .types import AssetAccount, EquityAccount, ExpenseAccount, RevenueAccount
    from .dates import TODAY
    #: Description of the entry
    description = "Unit tests for method post of class JournalEntry"

    #: Business object as the source of the journal entry
    source = "Evolpe"

    #: Date of the entry
    date = TODAY()

    #: Journal entry
    journal_entry = JournalEntry(date, description, source)

    #: Account to post the amount to
    asset_account = AssetAccount("Asset Account", USD)

    #: Amount to post to the account
    amount = 1000

    assert asset_account in journal_entry.increments()

    #: Account to post the amount to

# Generated at 2022-06-12 05:53:45.383635
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime
    from dataclasses import dataclass, field
    from typing import Iterable, Union

    from ..commons.numbers import Amount, Currency, Quantity
    from ..commons.others import DateError
    from .accounts import Account

    from .journal import JournalEntry, ReadJournalEntries

    ## Define certain constants for test:
    _INR = Currency('INR')

    ## Define some accounts:

# Generated at 2022-06-12 05:53:57.368340
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .currencies import Currency, USD
    from .customers import Customer
    from .taxes import Tax
    from .transactions import Transaction, TransactionComponent

    with Currency.get_context(USD):
        customer = Customer(
            "Chameleon, Inc.",
            account=Account(
                "Customer Receivables",
                AccountType.ASSETS,
                "Current Assets",
                "Customer Receivables"
            )
        )
        tax = Tax(
            "Federal Sales Tax",
            account=Account(
                "Sales Tax Payable",
                AccountType.LIABILITIES,
                "Current Liabilities",
                "Sales Tax Payable"
            )
        )
        journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test journal entry", 0)
       

# Generated at 2022-06-12 05:54:38.025833
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account = Account("a", AccountType.EXPENSES, "1")
    a = JournalEntry(date= datetime.date(2020, 2,6), description="", source="")
    a.post(date= datetime.date(2020, 2,6), account=account, quantity=6)
    assert isinstance(a, JournalEntry)
    assert isinstance(a.postings[0], Posting)
    #Test debit
    assert a.is_debit == True

# Generated at 2022-06-12 05:54:46.832726
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class JournalEntryTest:
        def __init__(self, date, description, source, postings, guid) -> None:
            self.date = datetime.date(date[0], date[1], date[2])
            self.description = description
            self.source = source
            self.postings = postings
            self.guid = guid
    date = (2020, 1, 1)
    description = "description"
    source = "source"
    postings = []
    guid = 1
    je = JournalEntryTest(date, description, source, postings, guid)
    je.post(datetime.date(2020, 1, 2), Account('2', '2'), 1)
    assert je.date == datetime.date(2020, 1, 1)
    assert je.description == "description"
    assert je.source == "source"


# Generated at 2022-06-12 05:54:52.422451
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Quantity as Q
    from .accounts import AccountType, Account

    account_asset = Account("account_asset", AccountType.ASSETS)
    account_equities = Account("account_equities", AccountType.EQUITIES)
    account_liabilities = Account("account_liables", AccountType.LIABILITIES)
    account_expenses = Account("account_expenses", AccountType.EXPENSES)
    account_revenues = Account("account_revenues", AccountType.REVENUES)

    test_journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test Journal", "Test Journal Entry Source")
    test_journal_entry.post(datetime.date(2020, 1, 1), account_asset, Q(1))

# Generated at 2022-06-12 05:54:59.219748
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..accounting.accounts import AccountType
    from ..accounting.business_objects import Relationship
    from ..accounting.events import CustomerPaysByInvoice
    from ..accounting.settings import Settings

    #
    # Given:
    # the following journal entry
    #
    j1 = JournalEntry(datetime.date.today(), "Testing", None)

    #
    # When:
    # Posting an amount to a given account, with a given amount
    #
    j1.post(datetime.date(2018, 12, 31), Account("A1"), 1)

    #
    # Then:
    # expect that the account is added (as a posting) to the journal entry
    #
    assert len(j1.postings) == 1
    assert j1.postings[0].account.name == "A1"

# Generated at 2022-06-12 05:55:03.992563
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Create a ReadJournalEntries protocol to be implemented with a lambda
    read: ReadJournalEntries[_T] = lambda period: iter([])

    # Perform the dummy call to enforce type check.
    read(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 1)))

# Generated at 2022-06-12 05:55:12.460238
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    class S(Generic[_T]):
        pass

    s = S()

    def callable(period: DateRange) -> Iterable[JournalEntry[S]]:
        pass

    assert issubclass(ReadJournalEntries, Generic[_T])
    
    try:
        callable(DateRange.from_dates(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1)))
    except TypeError as e:
        assert "has no attribute '_name_'" in str(e)


# Generated at 2022-06-12 05:55:24.292794
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from . import accounts
    from .books import Book

    # test data
    a = accounts.Asset(Guid.from_str("{5D5B7B66-E977-41F6-9192-741325D2F2CA}"), "Cash")
    b = accounts.Asset(Guid.from_str("{63D0335A-0D3C-42E3-B342-6C88500C1D45}"), "Bank")
    c = accounts.Equity(Guid.from_str("{3D8AFB61-6BFF-4DA7-9143-51CEB93C325D}"), "Capital")

# Generated at 2022-06-12 05:55:35.130766
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account
    from .accounts import AccountCode, AccountDescription, GeneralLedger
    from .business import Ledger

    # DEFINITION
    ledger: Ledger = Ledger().create_account(
        AccountCode("1111"), AccountDescription("Cash"), AccountType.ASSETS
    )
    ledger.create_account(
        AccountCode("4111"), AccountDescription("Accounts Receivable"), AccountType.ASSETS
    )
    ledger.create_account(
        AccountCode("1200"), AccountDescription("Sales"), AccountType.REVENUES
    )
    ledger.create_account(
        AccountCode("1210"), AccountDescription("Sales Discounts"), AccountType.EXPENSES
    )

# Generated at 2022-06-12 05:55:42.643281
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry[None](datetime.date(2020,5,5), "Five dollor transaction", None)
    # Post a debit event to account 10000
    je.post(datetime.date(2020,5,5), Account("10000"), Amount(5))
    # Post a credit event to account 20000
    je.post(datetime.date(2020,5,5), Account("20000"), Amount(-5))
    # Validate the journal entry
    je.validate()
    # Check if the debit and credit postings are equal
    assert len(je.debits) == len(je.credits)

# Generated at 2022-06-12 05:55:43.477388
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-12 05:57:06.075492
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    accounts: List[Account] = [
        Account(name='Cash', type=AccountType.ASSETS),
        Account(name='Stock', type=AccountType.ASSETS),
        Account(name='MyBank Acct', type=AccountType.ASSETS),
        Account(name='MyCreditCard', type=AccountType.LIABILITIES),
        Account(name='Revenue', type=AccountType.REVENUES),
    ]

# Generated at 2022-06-12 05:57:14.637772
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    ## Arrange:
    j = JournalEntry[str]("2020-01-01", "Test", "Some Source", [])

    ## Act:
    j.post(datetime.date(2020, 1, 1), Account("ASSET", "TEST", AccountType.ASSETS), Quantity(100))
    j.post(datetime.date(2020, 1, 1), Account("LIAB", "TEST", AccountType.LIABILITIES), -100)

    ## Assert:
    assert len(j.postings) == 2
    assert len(list(j.increments)) == 1
    assert len(list(j.debits)) == 1
    assert len(list(j.credits)) == 1
    j.validate()


# Generated at 2022-06-12 05:57:21.835256
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry(date=datetime.date(2019, 1, 15),
                     description="plop",
                     source=None)
    j.post(date=datetime.date(2019, 1, 15),
           account=Account(type=AccountType.EQUITIES, code=1, label="café de la crèche"),
           quantity=1000)
    j.post(date=datetime.date(2019, 1, 15),
           account=Account(type=AccountType.LIABILITIES, code=1, label="bancontact"),
           quantity=-1000)

    j.validate()

    assert True

# Generated at 2022-06-12 05:57:31.620079
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Data
    account = Account("60003",	"Accounts Payable",	AccountType.LIABILITIES)
    date = datetime.date.today()
    journal = JournalEntry[None](date, "Test Journal Entry", None)
    credit_amount = Amount(1000)
    debit_amount = Amount(-2000)
    # Tests
    journal.post(date, account, credit_amount)
    journal.post(date, account, debit_amount)
    assert len(journal.postings) == 2
    assert journal.postings[0].amount == credit_amount
    assert journal.postings[1].amount == debit_amount
    assert journal.postings[0].is_credit
    assert journal.postings[1].is_debit


# Generated at 2022-06-12 05:57:42.465538
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je1 = JournalEntry(datetime.date(2019,1,1), "First Entry" , 1)
    je1.post(datetime.date(2019,1,1), Account("Assets", "Bank", AccountType.ASSETS), 10)
    je1.post(datetime.date(2019,1,1), Account("Expenses", "Rent", AccountType.EXPENSES), -10)
    try:
        je1.validate()
    except:
        assert 0
    je2 = JournalEntry(datetime.date(2019,1,2), "Second Entry" , 1)
    je2.post(datetime.date(2019,1,2), Account("Assets", "Bank", AccountType.ASSETS), 1)

# Generated at 2022-06-12 05:57:44.049223
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Tests the method __call__ of ReadJournalEntries.
    """


# Generated at 2022-06-12 05:57:55.602179
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from hamcrest import assert_that, calling, contains, raises
    from .accounts import NormalAccount
    from .periods import Period, Periods

    def get_journal_entries():
        pass

    def get_journal_entries_with_wrong_return_type():
        return "foo"

    #: Unit test function:
    def run_test(periods: Periods, expect_entries: List[JournalEntry[Period]],
                 get_journal_entries_: ReadJournalEntries[Period]) -> None:
        entries = get_journal_entries_(periods)
        assert_that(entries, contains(*expect_entries))

    # Setup:

# Generated at 2022-06-12 05:57:57.071737
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False, "TBD"

# Generated at 2022-06-12 05:58:07.047315
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date, timedelta
    from dataclasses import dataclass, field
    from typing import Generic, TypeVar

    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class _T1(Generic[_T]):
        a: _T

    @dataclass(frozen=True)
    class _T2(Generic[_T]):
        b: _T

    @dataclass(frozen=True)
    class _T3(Generic[_T]):
        a: _T1[int]
        b: _T2[int]


# Generated at 2022-06-12 05:58:11.517024
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry = JournalEntry[str]('date', 'description', 'source')
    journal_entry.post(
        date='date',
        account=Account('Account'),
        quantity='quantity'
    )
    assert journal_entry.postings[0].journal == journal_entry