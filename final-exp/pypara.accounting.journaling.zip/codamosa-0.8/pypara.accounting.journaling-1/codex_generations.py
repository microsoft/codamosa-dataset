

# Generated at 2022-06-12 05:48:40.607090
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountScheme
    from .business import Business
    from .division import Division
    from .transactions import Transaction

    # Event handlers:
    def on_receipt_journal_entry(entry: JournalEntry[Transaction]):
        print(entry)

    def on_payment_journal_entry(entry: JournalEntry[Transaction]):
        print(entry)

    # Configure app:
    accounts = AccountScheme(name="Core Accounts")
    accounts.assets.register(name="Cash")
    accounts.expenses.register(name="Food")
    accounts.expenses.register(name="Beverages")

    # Create some transactions:
    # Business object -> Journal entry

# Generated at 2022-06-12 05:48:48.231289
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    print("Unit test for method post of class JournalEntry:")

    class Customer:
        def __init__(self, name):
            self.name = name

    joe = Customer("Joe")
    journal = JournalEntry(datetime.date(2017, 1, 1), "Purcahse", joe)
    journal.post(datetime.date(2017, 1, 1), Account.stock(), Quantity(13))
    journal.post(datetime.date(2017, 1, 1), Account.vat(), Quantity(2))
    journal.post(datetime.date(2017, 1, 1), Account.bank(), Quantity(-15))

    assert len(journal.postings) == 3
    assert journal.date == datetime.date(2017, 1, 1)
    assert journal.description == "Purcahse"

# Generated at 2022-06-12 05:48:53.430349
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    J = JournalEntry
    journal = J
    def post(date,account, amount):
        journal.post(date,account,amount)
    post(datetime.date(2000,2,2),1,100)
    post(datetime.date(2000,2,2),2,-100)
    journal.validate()

# test_JournalEntry_validate()

# Generated at 2022-06-12 05:49:02.336317
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from ..commons.currencies import USD
    from ..commons.numbers import USD
    from .accounts import Account, AccountType
    from .transactions import Transaction

    JournalEntry.__init__(self, date(2020, 1, 1), "Dummy", Transaction(date(2020, 1, 1), "Dummy"))
    a = Account("Assets")
    assert isinstance(a, Account)
    a.type(AccountType.ASSETS)
    self.post(date(2020, 1, 1), a, USD(10))
    self.validate(self)



# Generated at 2022-06-12 05:49:09.478138
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    a = JournalEntry(datetime.date(2019,1,1),'Sale of 1 for $1',1)
    a.post(datetime.date(2019,1,1),Account('Cash',"Assets"),1)
    a.post(datetime.date(2019,1,1),Account('Sales',"Income"),1)
    assert a.postings[0].account.name =='Cash'
    assert a.postings[1].account.name =='Sales'

# Generated at 2022-06-12 05:49:16.713429
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from .ledgers import Ledger

    book = Ledger()

    journal_entry = JournalEntry(datetime.date(2019, 1, 1), "Some Description", None)
    journal_entry.post(datetime.date(2019, 1, 1), book.accounts.ASSETS, 10)
    journal_entry.post(datetime.date(2019, 1, 1), book.accounts.RS_EQUITY.CAPITAL, -10)

    journal_entry.validate()


# Generated at 2022-06-12 05:49:17.402788
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:49:28.352914
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .business_objects import Company
    from .ledger import Ledger
    c1 = Company("c1", "Company 1")
    c2 = Company("c2", "Company 2")

    c1_ledger = Ledger(c1)
    c1_ledger.accounts.asset("A1", "A1 Description")
    c1_ledger.accounts.equity("E1", "E1 Description")
    c1_ledger.accounts.revenue("R1", "R1 Description")
    c1_ledger.accounts.expense("X1", "X1 Description")

    c2_ledger = Ledger(c2)
    c2_ledger.accounts.asset("A2", "A2 Description")

# Generated at 2022-06-12 05:49:35.730204
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    description = 'test description'
    date = datetime.date(2019, 3, 1)
    source = ""
    journal_entry = JournalEntry(date, description, source)
    journal_entry.post(date, Account(AccountType.ASSETS, "1", "", True), 10)
    journal_entry.post(date, Account(AccountType.REVENUES, "1", "", True), -10)
    journal_entry.validate()

    journal_entry = JournalEntry(date, description, source)
    journal_entry.post(date, Account(AccountType.ASSETS, "1", "", True), 10)
    journal_entry.post(date, Account(AccountType.REVENUES, "1", "", True), -9)

# Generated at 2022-06-12 05:49:42.981072
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(datetime.date.today(), "", None)
    j.post(datetime.datetime(2020,1,1).date(), Account("test"), Quantity(100))
    j.post(datetime.datetime(2020,1,1).date(), Account("test"), Quantity(-100))
    assert not j.postings
    j.post(datetime.datetime(2020,1,1).date(), Account("test"), Quantity(-100))
    assert len(j.postings) == 1
    assert j.postings[0].amount == Amount(100)
    j.validate()

# Generated at 2022-06-12 05:49:49.914152
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class gj:pass
    assert isinstance(ReadJournalEntries.__call__(gj,period=DateRange('1','2')),Iterable)


# Generated at 2022-06-12 05:50:01.093691
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import datetime
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    # Create JournalEntry
    je = JournalEntry[str](datetime.date(2020, 5, 1), "Test journal entry", "Source object")
    # Create postings
    assets = Account("Assets", "", AccountType.ASSETS)
    revenues = Account("Revenues", "", AccountType.REVENUES)
    je.post(datetime.date(2020, 5, 1), assets, Quantity(100))
    je.post(datetime.date(2020, 5, 1), revenues, Quantity(-100))
    # Validate correct journal entry
    je.validate()
    # Invalidate journal entry by posting wrong amount
    je.post(datetime.date(2020, 5, 1), revenues, Quantity(-50))

# Generated at 2022-06-12 05:50:10.152188
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    
    journal = JournalEntry(datetime.date(2020, 1, 1), "source", "business_object")
    journal.post(datetime.date(2020, 1, 1), Account(name="account", type=AccountType.ASSETS), Quantity(100))
    journal.post(datetime.date(2020, 1, 1), Account(name="account", type=AccountType.ASSETS), Quantity(200))
    journal.post(datetime.date(2020, 1, 1), Account(name="account", type=AccountType.ASSETS), Quantity(-100))
    journal.post(datetime.date(2020, 1, 1), Account(name="account", type=AccountType.ASSETS), Quantity(-200))

    assert len(journal.postings) == 2

# Generated at 2022-06-12 05:50:19.166621
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .sources import Source1
    my_source = Source1(1, 2)
    myje = JournalEntry(datetime.date.today(), "Test Journal Entry", my_source)
    myje_with_postings = myje.post(datetime.date.today(), Account('asset', 'my account', 'my description'), 100)
    assert(myje_with_postings.postings[0].direction == Direction.INC)
    myje_with_postings = myje.post(datetime.date.today(), Account('asset', 'my account', 'my description'), -100)
    assert(myje_with_postings.postings[0].direction == Direction.DEC)

# Generated at 2022-06-12 05:50:31.354340
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Tests `JournalEntry.validate()` method.
    """
    journal = JournalEntry(date=datetime.date(2020, 3, 1), description="Test")
    journal.post(date=datetime.date(2020, 3, 1), account=Account(AccountType.ASSETS, "Bank A/C"), quantity=100)
    journal.post(date=datetime.date(2020, 3, 1), account=Account(AccountType.REVENUES, "Sale"), quantity=-100)
    journal.validate()

    # Corrupt the journal and try validating
    journal.post(date=datetime.date(2020, 3, 1), account=Account(AccountType.ASSETS, "Bank A/C"), quantity=10)

# Generated at 2022-06-12 05:50:39.338206
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(datetime.date(2020, 10, 2), "Some Test Journal")
    journal.post(datetime.date(2020, 10, 2), Account("Test Account"), +100)
    journal.post(datetime.date(2020, 10, 2), Account("Test Account"), +400)
    journal.post(datetime.date(2020, 10, 2), Account("Test Account"), -500)
    journal.post(datetime.date(2020, 10, 2), Account("Test Account"), -100)
    print(journal.postings)
    journal.validate()
    print(journal.postings)


# Generated at 2022-06-12 05:50:42.547842
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        """
        A dummy function.
        """
        pass

# Generated at 2022-06-12 05:50:51.455620
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    print(datetime.date.today())
    from .accounts import Account, AccountType
    from .journal import Direction, JournalEntry, Posting
    from .ledgers import EquityLedger, RevenueLedger
    from .numbers import Amount
    j = JournalEntry[int]()
    j.date = datetime.date.today()
    j.description = "Test journal entry"
    j.source = 17
    j.post(datetime.date.today(), Account(type=AccountType.ASSETS, name="Test Asset"), 100)
    j.post(datetime.date.today(), EquityLedger.RETAINED_EARNINGS, -100)
    j.post(datetime.date.today(), RevenueLedger.REVENUES, 50)

# Generated at 2022-06-12 05:51:00.037604
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .commons.testing import Date

    journal = JournalEntry(Date(2019, 11, 2), "JournalEntry Test", "Test")
    account1 = Account("Account1", AccountType.EQUITIES)
    account2 = Account("Account2", AccountType.LIABILITIES)

    journal.post(Date(2019, 11, 2), account1, 1)
    journal.post(Date(2019, 11, 2), account2, -1)

    assert journal.description == "JournalEntry Test"
    assert journal.guid != ''
    assert journal.postings != []
    assert len(journal.postings) == 2
    assert journal.postings[0].account.name == "Account1"
    assert journal.postings[1].account.name == "Account2"
    assert len(list(journal.increments)) == 1
   

# Generated at 2022-06-12 05:51:04.405977
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create an empty journal:
    journalEntry = JournalEntry([])
    # Test
    journalEntry.post(datetime.date(2019,1,1), Account("CREDIT"), 100)
    assert journalEntry.postings[0].amount == 100
    assert journalEntry.postings[0].direction == Direction.INC

# Generated at 2022-06-12 05:51:20.627850
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    # Create journal entries with 
    journal1 = JournalEntry(date=datetime.date(2020,7,9), description='opening balance', source=None)
    account1 = Account(type=AccountType.LIABILITIES, name='payroll expenses', description='amounts in payroll')
    journal1.post(date=datetime.date(2020,7,9), account=account1, quantity=1000)
    print(journal1.validate())
    journal1.validate()
    return
test_JournalEntry_validate()

# Generated at 2022-06-12 05:51:29.297512
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    print("*** function test_JournalEntry_post()")
    j = JournalEntry(datetime.date(2019, 1, 1), "test_JournalEntry_post", str)
    j.post(datetime.date(2019, 1, 1), Account("test_JournalEntry_post_account", AccountType.EXPENSES), -1)
    j.post(datetime.date(2019, 1, 1), Account("test_JournalEntry_post_account", AccountType.ASSETS), +1)
    assert "test_JournalEntry_post_account" in [p.account.name for p in j.postings]



# Generated at 2022-06-12 05:51:39.799576
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    from ..books.accounts import Accounts
    from ..books.journals import JournalEntries

    a = Accounts()
    j = JournalEntries()

    a.add_account(Account(
        name = "Test",
        type = AccountType.ASSETS,
        description = "Test account"
    ))
    a.add_account(Account(
        name = "Test2",
        type = AccountType.EXPENSES,
        description = "Test account 2"
    ))


# Generated at 2022-06-12 05:51:40.632089
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    pass



# Generated at 2022-06-12 05:51:41.706181
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    test_ReadJournalEntries___call__.__doc__
    pass

# Generated at 2022-06-12 05:51:52.762228
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import create_account, get_account
    from .accountants import Accountant
    from .books import Book
    from .transactions import Invoice, InvoiceLine, InvoicingTransaction

    class Test:
        """
        Test fixture to test ``ReadJournalEntries`` protocol.
        """

        def __init__(self, invoicing: InvoicingTransaction[_T]):
            accountant = Accountant()
            book = Book()
            book.add(invoicing)
            accountant.add(book)
            self.read_journal_entries = accountant.read_journal_entries


# Generated at 2022-06-12 05:52:04.576882
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class _MockData:
        date: datetime.date
        description: str

    @dataclass(frozen=True)
    class _MockPosting:
        date: datetime.date
        account: Account
        direction: Direction
        amount: Amount

    @dataclass(frozen=True)
    class _MockJournalEntry:
        date: datetime.date
        description: str
        source: _MockData
        postings: List[_MockPosting]


# Generated at 2022-06-12 05:52:11.200425
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..model.accounts import Account, AccountType
    from ..model.journal import JournalEntry, Posting, Direction

    fnl = Account(AccountType.ASSETS, 'FNL')
    j = JournalEntry('2020-02-01', 'initialization', fnl, [])
    assert j.postings == []

    j.post('2020-02-01', fnl, 1000)
    assert j.postings == [Posting(j, '2020-02-01', fnl, Direction.INC, 1000)]

    j.post('2020-02-01', fnl, -1000)
    assert j.postings == [Posting(j, '2020-02-01', fnl, Direction.INC, 1000), Posting(j, '2020-02-01', fnl, Direction.DEC, 1000)]




# Generated at 2022-06-12 05:52:20.138875
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.zeitgeist import today, this_year
    from ..services import AccountingService
    accounting_service: AccountingService = AccountingService()
    source = accounting_service.create_invoice(
        "Invoice-1", "Client-1", today(), [("Product-1", 5, 200), ("Product-2", 10, 100)]
    )
    journal = accounting_service.post_to_journals(source)
    assert len(journal.debits) == 3
    assert len(journal.credits) == 1
    assert journal.date == today()
    assert journal.description == "Invoice-1"
    assert journal.source == source
    assert sum(i.amount for i in journal.increments) == 1800
    assert sum(i.amount for i in journal.decrements) == 1800



# Generated at 2022-06-12 05:52:30.137971
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from ..commons.numbers import Quantity
    from .accounts import Account

    je=JournalEntry(date(2020,1,1),"abc",None)
    acc=Account('abc','def',1)
    je.post(date(2020,1,2),acc,Quantity(100))
    assert len(je.postings)==1
    assert je.postings[0].direction==Direction.INC

    je1=JournalEntry(date(2020,1,1),"abc",None)
    je1.post(date(2020,1,2),acc,Quantity(-100))
    assert len(je1.postings)==1
    assert je1.postings[0].direction==Direction.DEC

# Generated at 2022-06-12 05:52:53.100449
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date(2020, 1, 1)
    source = None

    je1 = JournalEntry[None](date, "Test 1", source)
    je1.post(date, Account(AccountType.ASSETS, "", ""), +100)
    je1.post(date, Account(AccountType.ASSETS, "", ""), -100)

    je2 = JournalEntry[None](date, "Test 2", source)
    je2.post(date, Account(AccountType.EXPENSES, "", ""), +100)
    je2.post(date, Account(AccountType.EXPENSES, "", ""), -100)

    je3 = JournalEntry[None](date, "Test 3", source)
    je3.post(date, Account(AccountType.LIABILITIES, "", ""), +100)
    je

# Generated at 2022-06-12 05:52:58.022906
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    '''
    Tests method post of class JournalEntry
    '''
    je = JournalEntry(datetime.date.today(), 'This is a Journal Entry', 0)
    je.post(datetime.date.today(), Account('Asset Account', AccountType.ASSETS), 100)
    assert je.postings[0].direction == Direction.INC

# Generated at 2022-06-12 05:52:58.499894
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-12 05:53:11.302312
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from . import Account, Direction, JournalEntry
    from ..commons.money import Money
    from ..commons.numbers import Quantity

    j = JournalEntry(datetime.date(2018,1,1), "tester")
    j.post(datetime.date.today(), Account(AccountType.ASSETS, "cash", 0), Money(Quantity(100)))
    j.post(datetime.date.today(), Account(AccountType.LIABILITIES, "loan", 0), Money(Quantity(-200)))
    print(j)
    print(j.increments)
    print(j.decrements)
    print(j.debits)
    print(j.credits)

    inc = j.increments
    dec = j.decrements
    inc_amount = 0
    dec_amount = 0
    inc_amount_

# Generated at 2022-06-12 05:53:13.932884
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ReadJournalEntriesImpl:
        def __call__(self, period: DateRange):
            return []
    assert isinstance(ReadJournalEntriesImpl(), ReadJournalEntries)

# Generated at 2022-06-12 05:53:25.606922
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup phase: Creating accounts
    result = 0 # Temporary variable
    cash = Account(name="Cash", type=AccountType.ASSETS) # Creating cash account
    disbursement = Account(name="Disbursement", type=AccountType.EXPENSES) # Creating disbursement account

    # Test case 1: Postings of different dates.
    jnl1 = JournalEntry(date=datetime.date(2020, 5, 10),
                               description="A payment",
                               source="A Payment")
    jnl1.post(date=datetime.date(2020, 5, 10), account=cash, quantity=100)
    jnl1.post(date=datetime.date(2020, 5, 10), account=disbursement, quantity=-100)
    result = jnl1.postings[0].amount.value and jnl1.post

# Generated at 2022-06-12 05:53:37.621530
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .ledgers import Ledger
    from .books import Book

    class CashBook(Book):

        def __init__(self):
            super().__init__()
            self.total = 0

        def post(self, entry: JournalEntry):
            self.total += entry.postings[0].amount.value
            super().post(entry)

    cash_book = CashBook()

    class LedgerReadJournalEntries(ReadJournalEntries):
        def __init__(self, ledger: Ledger):
            self.ledger = ledger

        def __call__(self, period: DateRange):
            return self.ledger.entries(period)

    cash_ledger = Ledger()
    read_ledger_entries = LedgerReadJournalEntries(cash_ledger)
    cash_book.read_journal_ent

# Generated at 2022-06-12 05:53:43.585868
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    entry = JournalEntry(datetime.date.today(), "Entry1", None)
    entry.post(datetime.date.today(), Account("A1", AccountType.ASSETS), Amount(100))
    entry.post(datetime.date.today(), Account("A1", AccountType.REVENUES), Amount(-100))

    entries = list(ReadJournalEntries.__call__(lambda x: [entry], DateRange.today()))
    assert entries == [entry], "Should be [entry]."

# Generated at 2022-06-12 05:53:55.024964
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import today, DateRange
    from .accounts import AccountType, Account

    ### Test-1: Happy case, simple

# Generated at 2022-06-12 05:54:04.405115
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import List
    from datetime import date
    from .accounts import Account, AccountType
    from .others import JournalEntry as JE

    @dataclass(frozen=True)
    class Source:
        pass

    def read(period: DateRange) -> List[JE[Source]]:
        return [JE(date(2020, 4, 24), "Test", Source(), [])]

    assert list(read(DateRange(date(2020, 3, 1), date(2020, 3, 31)))) == []
    assert list(read(DateRange(date(2020, 1, 1), date(2020, 6, 30)))) == [JE(date(2020, 4, 24), "Test", Source(), [])]

# Generated at 2022-06-12 05:54:35.772292
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_logs(period: DateRange) -> Iterable[JournalEntry[str]]:
        pass

    rj = ReadJournalEntries
    assert isinstance(read_logs, rj)

# Generated at 2022-06-12 05:54:45.311969
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    global AB
    test_ReadJournalEntries___call__.total_log_entries = 0
    journal_entries = []
    def fn(*args):
        nonlocal test_ReadJournalEntries___call__, journal_entries
        journal_entries = [JournalEntry(datetime.date(2017, 1, 4), 'Test', 'Test', [])]
        test_ReadJournalEntries___call__.total_log_entries += 1
        return journal_entries
    AB = ReadJournalEntries()
    AB.__call__ = fn
    assert AB(DateRange(datetime.date(2017, 1, 4), datetime.date(2017, 1, 4))), "Journal entry not added."

test_ReadJournalEntries___call__()

# Generated at 2022-06-12 05:54:56.315504
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class TestEntry(JournalEntry):
        pass

    a = Account('a')
    b = Account('b')

    entry = TestEntry(date=datetime.date(2020, 1, 1), description="test", source=None)
    assert entry.postings == []
    assert entry.post(datetime.date(2020, 1, 1), a, Quantity(100)) is entry
    assert entry.post(datetime.date(2020, 1, 1), a, -Quantity(100)) is entry
    assert entry.postings == []
    assert entry.post(datetime.date(2020, 1, 1), a, Quantity(100)) is entry
    assert entry.post(datetime.date(2020, 1, 1), b, -Quantity(100)) is entry

# Generated at 2022-06-12 05:55:07.800372
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    ## Using Assets account as the test data
    # Assets Account details
    Account.assets_account_code = '100'
    Account.assets_account_name = 'Assets'
    Account.assets_account = Account('100', 'Assets')

    ## Creating JournalEntry
    j = JournalEntry(datetime.date(2020, 2, 6), 'Trial Balance')

    ## Creating transactions
    j.post(datetime.date(2020, 2, 6), Account.assets_account, 1000)
    j.post(datetime.date(2020, 2, 6), Account.assets_account, -1000)
    j.validate()

    ## Creating negative transactions
    j.post(datetime.date(2020, 2, 6), Account.assets_account, 1000)

# Generated at 2022-06-12 05:55:15.097284
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    debitAccount = Account("Asset", AccountType.ASSETS)
    creditAccount = Account("Liability", AccountType.LIABILITIES)
    debitAmount = Amount(100)
    creditAmount = Amount(100)
    date = datetime.date.today()
    description = "Test journal entry"
    journalEntry = JournalEntry("Test object") \
        .post(date=date, account=debitAccount, quantity=debitAmount) \
        .post(date=date, account=creditAccount, quantity=-creditAmount)
    journalEntry.validate()

# Generated at 2022-06-12 05:55:15.791268
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:55:25.171933
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class TestSource:
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

    read: ReadJournalEntries[TestSource] = lambda period: [JournalEntry(datetime.date(2017, 3, 31), "Test", TestSource(datetime.date(2017, 6, 30), "Description"))]

    assert iter(read(DateRange(datetime.date(2017, 3, 31), datetime.date(2017, 6, 30))))

    assert iter(read(DateRange(datetime.date(2017, 3, 31), datetime.date(2017, 6, 30)))).__next__().__class__ == JournalEntry
# EOF

# Generated at 2022-06-12 05:55:35.259863
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date

    from .accounts import AccountFactory

    from .journal import ReadJournalEntries

    test_data = [
        JournalEntry[None](date(2020, 1, 31), "Test 1", None, []),
        JournalEntry[None](date(2020, 2, 29), "Test 2", None, []),
        JournalEntry[None](date(2020, 3, 31), "Test 3", None, []),
        JournalEntry[None](date(2020, 4, 30), "Test 4", None, []),
    ]

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        return filter(lambda je: period.in_between(je.date), test_data)

    read_journal_entries = ReadJournalEntries(read_journal_entries)

    assert list

# Generated at 2022-06-12 05:55:41.273485
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..registry import SourceRegistry

    SourceRegistry.define('Event',[
        ('date', datetime.date), ('description', str), ('amount', Amount), ('source', 'Event')
    ])

    journal = JournalEntry[str](datetime.date.today(), "testing", "test source")
    account = Account("testing")
    journal.post(datetime.date.today(), account, +100)
    journal.validate()

# Generated at 2022-06-12 05:55:43.665140
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert bool(ReadJournalEntries()) is False


# Generated at 2022-06-12 05:57:05.813693
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..ledger.ledgers import build_ledger, Ledger
    from ..ledger.rules import TransactionRule
    journal = JournalEntry(datetime.date.today(), "entry", "TRANSACTION_A")
    ledger = build_ledger(
        TransactionRule(
            journal.date, "TRANSACTION_A", [
                ("EQUITY_ACCOUNT_A", -100),
                ("ASSETS_ACCOUNT_B", 100),
            ],
            "description"),[])
    journal.post(journal.date, ledger["ASSETS_ACCOUNT_B"], 100)
    journal.validate()
    # print(journal.postings)
    assert journal.postings[0].amount == 100
    assert journal.postings[0].account.name == "ASSETS_ACCOUNT_B"

# Generated at 2022-06-12 05:57:15.155803
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Test case for method ``__call__`` of class ``ReadJournalEntries``.
    """
    ## Test:
    from ..commons.zeitgeist import today, yesterday, tomorrow
    from .accounts import Account, AccountType

    def dummy_read_function(period):
        def posting(journal, date, account, direction, amount):
            return Posting(journal, date, Account.of(account), direction, amount)

        def journal(date, description, source, postings):
            return (
                JournalEntry(today, "Dummy journal entry", "Dummy source", [posting(None, today, "Dummy account", Direction.INC, 1)])
                if date == today
                else None
            )

        return (journal(date, None, None, []) for date in range(period.start, period.end))



# Generated at 2022-06-12 05:57:24.251809
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from .accounts import (Account, TransactionAccount, AccountType)
    from .transactions import Transaction

    t1 = Transaction.debit(Account(AccountType.ASSETS, 'Cash'), date(2019, 1, 1), 100)
    t2 = Transaction.debit(Account(AccountType.ASSETS, 'Bank'), date(2019, 1, 1), 200)
    t3 = Transaction.credit(Account(AccountType.REVENUES, 'Sales'), date(2019, 1, 1), 100)
    t4 = Transaction.credit(Account(AccountType.REVENUES, 'Sales'), date(2019, 1, 1), 200)
    je1 = JournalEntry(date(2019, 1, 1), 'je1', t1)

# Generated at 2022-06-12 05:57:34.950149
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def op(period: DateRange=DateRange(datetime.date.today(), datetime.date.today())) -> Iterable[JournalEntry[None]]:
        yield JournalEntry(datetime.date.today(), "", None)

    ReadJournalEntries.__call__(op, DateRange())
    ReadJournalEntries.__call__(op)

    class I(ReadJournalEntries):
        def __init__(self, a: int=0) -> None:
            pass

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[None]]:
            yield JournalEntry(datetime.date.today(), "", None)

    I.__call__(I(), DateRange())
    I.__call__(I())

# Generated at 2022-06-12 05:57:42.232143
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(datetime.date(2019, 8, 1), "Test post", None)
    journal.post(datetime.date(2019, 8, 1), Account("TEST", AccountType.ASSETS), 100)
    journal.post(datetime.date(2019, 8, 1), Account("TEST", AccountType.REVENUES), -100)

    # The below line should raise an AssertionError
    #journal.post(datetime.date(2019, 8, 1), Account("TEST", AccountType.ASSETS), 100)

# Generated at 2022-06-12 05:57:48.657286
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountList, AccountType

    # set up a trial balance on 1st January
    accounts = AccountList()
    accounts.add("cash", AccountType.ASSETS)
    accounts.add("sales", AccountType.REVENUES)
    accounts.add("wages", AccountType.EXPENSES)
    accounts.add("consultancy", AccountType.EXPENSES)

    journal = JournalEntry("my description", None)
    journal.post(datetime.date(2020, 1, 1), accounts.account("cash"), +1000)
    journal.post(datetime.date(2020, 1, 1), accounts.account("sales"), +3000)
    journal.post(datetime.date(2020, 1, 1), accounts.account("wages"), -2000)

# Generated at 2022-06-12 05:57:51.281680
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Programmer: Rachita Mishra
    Date: 11/15/2019
    Modified By:
    Date:
    """
    pass

# Generated at 2022-06-12 05:58:01.211787
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Accounts, Account

    # set up
    date = datetime.date(2020, 1, 1)
    account_assets = Account(Accounts.ASSETS)
    account_equities = Account(Accounts.EQUITIES)
    account_expenses = Account(Accounts.EXPENSES)
    account_revenues = Account(Accounts.REVENUES)
    journal = JournalEntry(date, "Test Journal", None)

    # call
    journal.post(date, account_assets, +100)
    journal.post(date, account_equities, -100)
    journal.post(date, account_expenses, -100)
    journal.post(date, account_revenues, +100)
    journal.post(date, account_assets, +100)

    # assert

# Generated at 2022-06-12 05:58:02.141551
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-12 05:58:12.814088
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from idom.core.models.accounts import Account, AccountType
    import pytest
    # Test constants
    IN_DATE = date(2020, 6, 1)
    OUT_DATE = date(2020, 6, 30)
    ACCOUNT_ID = '99'
    ACCOUNT_NAME = 'BK 012'
    ACCOUNT_TYPE = AccountType.ASSETS
    # Setup
    expected_posting = Posting(JournalEntry[None](date(2020, 5, 31), 'Sample Description', None), OUT_DATE, Account(ACCOUNT_ID, ACCOUNT_NAME, ACCOUNT_TYPE), Direction.DEC, Amount(100))
    # Test
    j = JournalEntry[None](date(2020, 5, 31), 'Sample Description', None)