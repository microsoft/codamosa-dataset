

# Generated at 2022-06-12 05:48:43.608910
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    import inspect
    import typing
    from ..ledger.accounts import Account, AccountType
    from ..ledger.entries import JournalEntry, Posting, ReadJournalEntries

    ## Setup
    account1 = Account(
        guid="account-1",
        type=AccountType.ASSETS,
        name="Cash",
        code="cash",
        description="Cash",
        parent=None,
        category_guid="category-1",
        category_name="Assets",
        category_code="assets",
    )

# Generated at 2022-06-12 05:48:53.499697
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[None](datetime.date.today(), "", None)
    je.post(datetime.date.today(), Account("A1", "Account 1", AccountType.ASSETS), 1)
    je.post(datetime.date.today(), Account("E1", "Account 2", AccountType.EQUITIES), -1)
    je.validate()
    je.post(datetime.date.today(), Account("E1", "Account 2", AccountType.EQUITIES), -1)
    try:
        je.validate()
        assert False, "Journal Entry Validation Working fine. Please check it again."
    except AssertionError:
        assert True


# Generated at 2022-06-12 05:49:05.909594
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import ReadAccounts
    from .subsidiaries import ReadSubsidiaries

    def read_journal_entries(read_accounts: ReadAccounts, read_subsidiaries: ReadSubsidiaries) -> ReadJournalEntries:
        from .accounts import Account, read_account_amount

        mappings: Dict[str, str] = {
            "cash": "cash",
            "inventory": "inventory",
            "salaries": "salaries",
            "wages": "wages",
        }

        def get_account(reference: str) -> Account:
            name = read_account_amount[reference]
            return read_accounts[name]

        def get_subsidiary(reference: str) -> str:
            return read_subsidiaries[reference]


# Generated at 2022-06-12 05:49:12.340905
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Case 1: Postings should be correctly posted
    account_1 = Account(1,1,"TESTING_ACCOUNT_TYPE", "TESTING_DESCRIPTION")
    account_2 = Account(2,2,"TESTING_ACCOUNT_TYPE", "TESTING_DESCRIPTION")
    journal_1 = JournalEntry(datetime.date.today(),"TESTING_DESCRIPTION",None)
    journal_1.post(datetime.date.today(), account_1, 100)
    assert len(journal_1.postings) == 1
    assert journal_1.postings[0].is_debit == True
    assert journal_1.postings[0].journal == journal_1
    assert journal_1.postings[0].account == account_1

# Generated at 2022-06-12 05:49:20.854575
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journalEntry = JournalEntry(date = datetime.date.today(), description = "", source = "")
    journalEntry.guid = "00000000-0000-0000-0000-000000000000"
    journalEntry.post(datetime.date.today(), Account(name = "", parent = None, type = AccountType.ASSETS), Quantity(1))
    journalEntry.post(datetime.date.today(), Account(name = "", parent = None, type = AccountType.REVENUES), Quantity(-1))
    print(journalEntry.postings)


# Generated at 2022-06-12 05:49:31.122898
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import unittest
    import typing
    from dataclasses import dataclass
    from datetime import date

    @dataclass
    class TestJournalEntry(JournalEntry):
        pass

    @dataclass
    class TestSource:
        pass

    def _create_journal_entry(
            date: str,
            account_type: AccountType,
            amount: int,
            description: str,
            source: TestSource,
            expected_postings: typing.Dict[str, typing.Union[bool, int]]) -> TestJournalEntry:
        return TestJournalEntry(
            date=date,
            description=description,
            source=source).\
            post(date=date, account=Account(account_type, "Test", "Test", "Test"), quantity=amount).\
            validate()


# Generated at 2022-06-12 05:49:37.332040
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import unittest
    import unittest.mock
    from ..samples.invoices import Invoice

    class Test(unittest.TestCase):

        def test_is_called__with_period(self):
            journal_entries: Iterable[JournalEntry[Invoice]] = []
            read_journal_entries: ReadJournalEntries[Invoice] = unittest.mock.MagicMock()
            period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

            read_journal_entries(period)

            read_journal_entries.assert_called_once_with(period)

        def test_returns_journal_entries(self):
            journal_entries: Iterable[JournalEntry[Invoice]] = []
            read_journal_

# Generated at 2022-06-12 05:49:38.309556
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass


# Generated at 2022-06-12 05:49:48.341724
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from pytest import raises, mark
    
    class ReadJournalEntriesMock(ReadJournalEntries[int]):
        def __call__(self, period: DateRange) -> List[JournalEntry[int]]:
            return [JournalEntry(datetime.date(2020, 1, 2), "", 101)]
    
    def test_with_mock():
        assert len(ReadJournalEntriesMock()(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2)))) == 1

    with raises(TypeError):
        ReadJournalEntries.__call__(None, None)
    
    with raises(TypeError):
        ReadJournalEntries.__call__(ReadJournalEntries, None)
    

# Generated at 2022-06-12 05:49:59.450979
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    
    from uuid import UUID
    from datetime import datetime

    from ..accounts.models import Account
    from .accounts import AccountType

    from .models import (
        JournalEntry,
        Posting,
    )

    _today = datetime.today()
    _random: UUID = UUID("404f476d-5b5e-40e2-8c6e-b81d65592160")
    _date: datetime.date = _today.date()
    _account: Account = Account(None, None, AccountType.ASSETS, "account", None)
    
    _journal1 = JournalEntry('date', 'description', 'source')
    _journal1.post('date', _account, -5)

    _journal2 = JournalEntry('date', 'description', 'source')
    _journal2

# Generated at 2022-06-12 05:50:15.326144
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons import Quantity

    # Given: A journal entry factory which creates a simple journal entry.
    def journal_entry_factory(
        date: datetime.date = datetime.date(2019, 1, 2),
        description: str = "Sample Journal Entry"
    ) -> JournalEntry[None]:
        return JournalEntry(date, description, None).post(date, Account("Assets:Cash"), Quantity(100))

    # Given: A collection of journal entries.
    je1 = journal_entry_factory()
    je2 = journal_entry_factory(date(2019, 1, 6), "Another Journal Entry")
    je3 = journal_entry_factory(date(2019, 2, 4), "Yet Another Journal Entry")

# Generated at 2022-06-12 05:50:23.858362
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..accounts.models import Accounts
    from ..books.models import AccountBook, create_book
    from ..books.testing import BookTests
    from ..commons.testing import import_module, new_guid
    from ..ledgers.models import Ledger
    from ..ledgers.testing import LedgerTests

    # TODO: How to test "is_debit" and "is_credit" properties of class Posting?
    # TODO: How to test "increments" and "decrements" properties of class JournalEntry?

    module = import_module(__file__)

    # Accounts:
    accounts = Accounts()
    book = create_book(new_guid(), "Test Book", accounts)


# Generated at 2022-06-12 05:50:35.194214
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.zeitgeist import DateRange

    #act
    entry = JournalEntry(datetime.date(2019, 2, 27), 'Aperçu du Trésorerie + Comptes bancaires'
                        , '20190227-Banque')
    posting = entry.post(datetime.date(2019, 2, 27), 'Cash', 500)
    posting2 = entry.post(datetime.date(2019, 2, 27), 'Bank Account', 500)
    posting3 = entry.post(datetime.date(2019, 2, 27), 'Cash', -500)
    posting4 = posting3.post(datetime.date(2019, 2, 27), 'Bank Account', -500)


    # assert
    assert entry.postings == [posting, posting2, posting3, posting4]

# Generated at 2022-06-12 05:50:42.051712
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date as dtdate

    je = JournalEntry[str]("","")

    je.post(dtdate.today(),"", 100)
    assert len(je.postings) == 1
    assert je.postings[0].amount == 100
    assert je.postings[0].account == ""
    assert je.postings[0].direction == Direction.INC

    je.post(dtdate.today(), "", -100)
    assert len(je.postings) == 2
    assert je.postings[1].amount == 100
    assert je.postings[1].account == ""
    assert je.postings[1].direction == Direction.DEC

# Generated at 2022-06-12 05:50:51.250620
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .business_objects import _businessobject
    import datetime
    from .commons.zeitgeist import DateRange
    from .double_entry_book import Book

    def readjournalsentries() -> Iterable[JournalEntry[_businessobject]]:
        # Returns a generator so that the iteration starts only when we ask it to and not when the function is called.
        #
        # We will get asked to start the iteration when we call the `build` method on the book.
        #
        # (This is only a stub as the real implementation will be provided by the user of this library.)
        #
        for entry in book.filter(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 1, 1))):
            yield entry


# Generated at 2022-06-12 05:50:59.952963
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Setup:
    from datetime import date
    from typing import Callable

    # Execute:
    ReadJournalEntries.__call__(
        Callable[
            [DateRange],
            Iterable[JournalEntry[str]],
        ](
            lambda _: [
                JournalEntry[str](
                    date(2020, 1, 1),
                    "ABC",
                    "JE1",
                    [
                        Posting[str](
                            None,
                            date(2020, 1, 1),
                            Account("100", AccountType.ASSETS),
                            Direction.INC,
                            Amount(100),
                        ),
                    ],
                ),
            ],
        ),
        DateRange(
            date(2020, 1, 1),
            date(2020, 1, 2),
        ),
    )

# Generated at 2022-06-12 05:51:07.604720
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .commons import make_account_book
    from .core import make_journal_entry

    ACCOUNTS = make_account_book([
        Account("Assets", AccountType.ASSETS),
        Account("Equities", AccountType.EQUITIES),
        Account("Liabilities", AccountType.LIABILITIES),
        Account("Revenues", AccountType.REVENUES),
        Account("Expenses", AccountType.EXPENSES),
    ])

    @dataclass
    class MySource:
        pass

    A = ACCOUNTS["Assets"]
    E = ACCOUNTS["Equities"]
    L = ACCOUNTS["Liabilities"]
    R = ACCOUNTS["Revenues"]
    X = ACCOUNTS["Expenses"]
    S = MySource()
    J = make_

# Generated at 2022-06-12 05:51:13.097211
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    entry = JournalEntry(datetime.date.today(), "Some description", "")
    for i in range(10):
        entry.post(datetime.date.today(), Account.of(AccountType.ASSETS, "My asset"), i)
    assert len(list(entry.debits)) == 10
    assert len(list(entry.postings)) == 10



# Generated at 2022-06-12 05:51:22.313747
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class TransactionSource(object):
        def __init__(self):
            self._guid=1

    jes:List[JournalEntry[TransactionSource]] = list()

    je = JournalEntry[TransactionSource](date=datetime.date(2020,1,1), description="test1", source=TransactionSource())
    je.post(datetime.date(2020,1,1), Account("A1"), 100)
    je.post(datetime.date(2020,1,1), Account("A2"), -100)
    jes.append(je)

    je = JournalEntry[TransactionSource](date=datetime.date(2020,2,2), description="test2", source=TransactionSource())
    je.post(datetime.date(2020,2,2), Account("A1"), -200)

# Generated at 2022-06-12 05:51:25.802734
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    jour = JournalEntry('date', 'desc', 'source', [])
    jour.post(datetime(2020, 1, 1), 'Account', 5)
    assert len(jour.postings) == 1


# Generated at 2022-06-12 05:51:37.111755
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class Reporter:
        pass

    reporter = Reporter()

    period: DateRange = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))
    journal_entries: Iterable[JournalEntry[Reporter]] = ReadJournalEntries()(period=period)

    assert False

# Generated at 2022-06-12 05:51:37.732662
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:51:40.236144
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert ReadJournalEntries.__call__(lambda period: None, DateRange.from_dates(datetime.date.today(), datetime.date.today()))


# Generated at 2022-06-12 05:51:46.207552
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import List, NamedTuple
    from ..commons.zeitgeist import DateRange

    class Person(NamedTuple):
        """
        Represents a person.
        """

        name: str
        dob: datetime.date

    class Cash(NamedTuple):
        """
        Represents cash.
        """

        name: str

    def cash_transfer(
        *,
        src: Cash,
        dest: Cash,
        amount: Amount,
        period: DateRange,
        read_journal_entries: ReadJournalEntries[Cash],
    ) -> Iterable[JournalEntry[Cash]]:
        """
        This is a user-defined function which gets all the journal entries
        of a given transfer between cash accounts.
        """
        return read_journal_entries(period)


# Generated at 2022-06-12 05:51:48.418019
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    callable = ReadJournalEntries([])
    assert callable is not None



# Generated at 2022-06-12 05:51:54.985180
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountManager
    from .accounts.types import AccountTypes

    j = JournalEntry[None](date=datetime.date(2020, 4, 1), description="test")
    j.post(date=datetime.date(2020, 4, 1), account=AccountManager.get_booking_account(AccountTypes.ASSETS_CASH), quantity=100)
    j.post(date=datetime.date(2020, 4, 1), account=AccountManager.get_booking_account(AccountTypes.REVENUES_SALES), quantity=-100)
    #j.post(date=datetime.date(2020, 4, 1), account=AccountManager.get_booking_account(AccountTypes.ASSETS_CASH), quantity=50)
    #j.post(date=datetime.date(2020, 4, 1

# Generated at 2022-06-12 05:52:02.064676
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # create journal of transaction
    journal = JournalEntry(date=datetime.date.today(), description="par", source="xxx")

    acc1 = Account("acc1")
    acc2 = Account("acc2")
    journal.post(date=datetime.date.today(), account=acc1, quantity=100)
    journal.post(date=datetime.date.today(), account=acc2, quantity=-100)
    journal.validate()

# Generated at 2022-06-12 05:52:06.864921
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..accounts.models import AccountType
    from ..accounts.datasets import AssetAccount
    from ..accounts.datasets import RevenueAccount
    je = JournalEntry[str]("2019-01-01","foo","bar")
    je.post(datetime.date(2019,1,1),AssetAccount("Assets:Current Assets:Cash"),1000.0) #Debit
    je.post(datetime.date(2019,1,1),RevenueAccount("Revenues:Interest"),1000.0) #Credit
    je.validate()

# Generated at 2022-06-12 05:52:18.459542
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .businesses import Business, read_businesses
    from .currencies import Currency
    from .markets import Market, read_markets
    from .natures import Nature, read_natures
    from .ownerships import BusinessOwner, read_ownerships

    #: Business Owner
    owner: BusinessOwner = BusinessOwner("Homer", "Simpson")

    #: Business
    business: Business = Business("Mountain Moes", owner)

    #: Market
    market: Market = Market("Springfield")

    #: Nature
    nature: Nature = Nature("Health and Wellness")

    #: Currency
    currency: Currency = Currency("USD")

    #: Account
    account: Account = Account("Cash", account_type=AccountType.ASSETS)

    # Assign values
    business.market = market

# Generated at 2022-06-12 05:52:23.640652
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry('date', 'description', 'source')
    j.post(datetime.date(2019, 10, 10), 'account', 1)
    assert j.postings.direction == 'Direction.INC'
    assert j.postings.account == 'account'
    assert j.postings.amount == 1


# Generated at 2022-06-12 05:52:41.363718
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    A = Account("A", AccountType.REVENUES)
    B = Account("B", AccountType.EXPENSES)
    C = Account("C", AccountType.REVENUES)
    je = JournalEntry[None](datetime.date.today(), "Test", None)
    je.post(datetime.date.today(), A, 100)
    je.post(datetime.date.today(), B, -100)
    je.post(datetime.date.today(), C, 100)
    assert (1, 2) == (len(je.increments), len(je.decrements))
    for p in je.increments:
        assert p.account in {A, C}
    for p in je.decrements:
        assert p.account == B
    assert je.validate()

# Generated at 2022-06-12 05:52:52.118693
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def post(date: datetime.date, account: str, quantity: int) -> Posting[str]:
        return Posting("", date, Account(account), Direction.of(Quantity(quantity)), Amount(abs(quantity)))

    # Given: Source of a journal entry.
    source = "a journal entry"

    # And: Journal entries
    journal1 = JournalEntry(datetime.date(2020, 1, 1), "journal 1", source, [
        post(datetime.date(2020, 1, 1), "credit", 77),
        post(datetime.date(2020, 1, 1), "debit", -88),
    ])

# Generated at 2022-06-12 05:52:59.706803
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    asset = Account("Cash", "Cash", AccountType.ASSETS)
    equity = Account("Equity", "Equity", AccountType.EQUITIES)

    entry = JournalEntry(date=datetime.date(2020, 1, 1), description="Test", source=None)
    entry.post(date=datetime.date(2020, 1, 1), account=asset, quantity=10)
    entry.post(date=datetime.date(2020, 1, 1), account=equity, quantity=-10)

    entry.validate()

# Generated at 2022-06-12 05:53:01.537204
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:53:05.894839
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Test data
    class Mock:
        pass
    # Test code
    result = ReadJournalEntries.__call__(None, DateRange.Always())
    assert Iterable.__instancecheck__(result)

# Generated at 2022-06-12 05:53:06.618837
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:53:14.944900
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date

    test_journal_entry = JournalEntry(date(2020, 1, 1), "Testing Journal Entry method post", "test_journal_entry")

    # testing with positive amount
    test_journal_entry.post(date(2020, 1, 1), "testing account", 10)

    assert len(test_journal_entry.postings) == 1
    assert test_journal_entry.postings[0].journal == test_journal_entry
    assert test_journal_entry.postings[0].date == date(2020, 1, 1)
    assert test_journal_entry.postings[0].account == "testing account"
    assert test_journal_entry.postings[0].direction == Direction.INC
    assert test_journal_entry.postings[0].amount == 10

    # testing with 0 amount
    test_journal

# Generated at 2022-06-12 05:53:26.453265
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Money, Quantity
    #: Date of the entry.
    date = datetime.datetime.today().date()
    #: Description of the entry.
    description = 'Posting entry test'
    #: Business object as the source of the journal entry.
    source = 'Unit test'
    #: Postings of the journal entry.
    postings = []
    #: Globally unique, ephemeral identifier.
    guid = '131'

    JE = JournalEntry(date, description, source)
    JENew = JE.post(date, 'Saving', Money(0))
    assert JE.postings == JENew.postings
    assert JE.date == JENew.date
    assert JE.description == JENew.description
    assert JE.source == JENew

# Generated at 2022-06-12 05:53:34.061816
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    rje: ReadJournalEntries = lambda period: [JournalEntry(datetime.date(2020, 2, 1), "T1", None)]

    assert len(list(rje(DateRange(from_date=datetime.date(2020, 1, 1), to_date=datetime.date(2020, 3, 1))))) == 1

    assert len(list(rje(DateRange(from_date=datetime.date(2020, 3, 1), to_date=datetime.date(2020, 5, 1))))) == 0

# Generated at 2022-06-12 05:53:44.245943
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..rules.accounts import ManageAccounts
    accounts = ManageAccounts()
    accounts.setup()

    from ..rules.ledgers import ManageLedgers
    ledgers = ManageLedgers(accounts)

    action = ledgers.create_journal_entry()

    @ReadJournalEntries
    def read(period: DateRange) -> Iterable[JournalEntry[action.domain]]:
        f = action.posting(date=datetime.date(2019, 12, 31), account=accounts.account("CA"), quantity=100)
        t = action.posting(date=datetime.date(2019, 12, 31), account=accounts.account("EA"), quantity=-100)
        return [action.apply(f, t)]


# Generated at 2022-06-12 05:54:18.526138
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # setup
    account_a = Account(guid="account#a", number=1, type=AccountType.ASSETS)
    account_b = Account(guid="account#b", number=2, type=AccountType.EXPENSES)
    amount = Amount(100)

    entry = JournalEntry[int](date=datetime.date.today(),
                              description="test",
                              source=1)
    entry.post(date=datetime.date.today(),
               account=account_a,
               quantity=+amount)
    entry.post(date=datetime.date.today(),
               account=account_b,
               quantity=-amount)

    # execute
    actual_increments = list(entry.increments)
    actual_decrements = list(entry.decrements)
    actual_debits = list

# Generated at 2022-06-12 05:54:20.974222
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account_type = AccountType.EXPENSES
    account = Account("Food", account_type)
    journal_entry = JournalEntry
    journal_entry.validate

# Generated at 2022-06-12 05:54:21.604553
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-12 05:54:23.086586
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ...


# Generated at 2022-06-12 05:54:24.293474
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
  assert 1 == 1

# Generated at 2022-06-12 05:54:34.050499
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import BalanceCheck
    from .accounts import BalanceSheet
    from .accounts import BalanceUpdater
    from .accounts import chart_of_accounts

    from .context import TestCoAController
    from .context import TestLedgerData
    from .context import TestLedgerEngine

    if __debug__:
        import doctest

        doctest.testmod()

        ## Create test objects:
        controller = TestCoAController(chart_of_accounts)
        ledger = TestLedgerEngine(TestLedgerData(controller))
        updater = BalanceUpdater(controller)

        ## Test CASH account:

# Generated at 2022-06-12 05:54:43.804651
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class Account1(Account):
        pass

    class Account2(Account):
        pass

    account1 = Account1('ID1', 'Test', AccountType.ASSETS)
    account2 = Account2('ID2', 'Test', AccountType.LIABILITIES)

    class Source:
        pass

    source = Source()

    journal1 = JournalEntry(datetime.date.today(), 'Test', source)
    journal2 = journal1.post(datetime.date.today(), account1, 10)

    journal = journal2.post(datetime.date.today(), account1, 15)
    journal = journal.post(datetime.date.today(), account2, 20)

    assert journal.postings[0].amount.value == 10
    assert journal.postings[1].amount.value == 20

# Generated at 2022-06-12 05:54:44.394377
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-12 05:54:50.633507
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    entry = JournalEntry.create() \
        .post("2020-01-01", "CHEQ:Current", -25.99) \
        .post("2020-01-01", "EXP:Groceries", 25.99)
    entry.validate()
    print("Finished tests")

test_JournalEntry_validate()

# Generated at 2022-06-12 05:54:58.787220
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..accounting.accounts import AccountRepository

    account_repo = AccountRepository(None)


# Generated at 2022-06-12 05:56:15.202077
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(date=datetime.date(2020, 8, 2), description='PostTest', source='N/A')
    journal.post(date=datetime.date(2020, 8, 2), account=Account('WP', AccountType.EQUITIES), quantity=Quantity(10))
    journal.post(date=datetime.date(2020, 8, 2), account=Account('WP', AccountType.REVENUES), quantity=Quantity(10))
    journal.validate()


# Generated at 2022-06-12 05:56:22.719222
# Unit test for method __call__ of class ReadJournalEntries

# Generated at 2022-06-12 05:56:30.625316
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    def test_case(date, account, quantity, expected_result):
        journal = JournalEntry(date=date, description="", source=None)
        journal.post(date, account, quantity)
        actual_result = journal.postings
        assert actual_result == expected_result, f"Excepted {expected_result}, Actual {actual_result}"
        print("Expected {expected_result}, Actual {actual_result}")

    test_case(datetime.date(2020, 1, 1), Account("Test", AccountType.ASSETS), Quantity(10), [Posting(journal=journal,
             date=datetime.date(2020, 1, 1), account=Account("Test", AccountType.ASSETS), direction=Direction.INC,
             amount=Amount(10))])
test_JournalEntry_post()

# Generated at 2022-06-12 05:56:41.256828
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    # Normal case
    value = JournalEntry[int]
    id = value(1, "First Entry", 1, [])
    assert id.post(datetime.date(2020, 5, 30), Account("100", AccountType.ASSETS), Quantity(100)) == JournalEntry[int]
    assert id.post(datetime.date(2020, 5, 30), Account("110", AccountType.EQUITIES), Quantity(110)) == JournalEntry[int]
    assert id.post(datetime.date(2020, 5, 30), Account("200", AccountType.LIABILITIES), Quantity(200)) == JournalEntry[int]
    assert id.post(datetime.date(2020, 5, 30), Account("300", AccountType.REVENUES), Quantity(-300)) == JournalEntry[int]

# Generated at 2022-06-12 05:56:51.332714
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class Income():
        ...
    class Expense():
        ...

    class Journal(ReadJournalEntries[Income]):
        """
        Simulates a journal.
        """

# Generated at 2022-06-12 05:57:02.750603
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_account_1 = Account.root_account(1, 'asset', AccountType.ASSETS)
    test_account_2 = Account.root_account(2, 'expense', AccountType.EXPENSES)
    test_account_3 = Account.root_account(3, 'account receivable', AccountType.ASSETS)
    test_account_4 = Account.root_account(4, 'account payable', AccountType.LIABILITIES)
    data = JournalEntry[str]('2020-03-23', 'test', 'test source')
    data.post('2020-03-23', test_account_1, 10)
    data.post('2020-03-23', test_account_1, 20)
    data.post('2020-03-23', test_account_2, -30)

# Generated at 2022-06-12 05:57:09.703974
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..reports.sampleaccounts import account_root
    from ..commons.units import USD
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import Date, DateRange
    from .accounts import Account, AccountType

    account1 = Account("Assets:Cash in Hand", AccountType.ASSETS)
    account2 = Account("Assets:Bank", AccountType.ASSETS)
    account3 = Account("Expenses:Interest Expense", AccountType.EXPENSES)

    transaction = JournalEntry("Transfer of money", "Transfer of money")
    transaction.post("2020-01-01", account1, Quantity(5, USD))
    transaction.post("2020-01-01", account2, -Quantity(5, USD))

    transaction.post("2020-01-01", account2, Quantity(5, USD))


# Generated at 2022-06-12 05:57:18.880790
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from buchschloss.ledger import journal, ledger
    from datetime import date

    def to_journal_entry(posting: ledger.Posting) -> JournalEntry[journal.JournalEntry]:
        journal_entry = JournalEntry[journal.JournalEntry](posting.date, posting.comment, posting.journal_entry)
        journal_entry.postings = [Posting(journal_entry, p.date, p.account, p.direction, p.amount) for p in posting.postings]
        return journal_entry


# Generated at 2022-06-12 05:57:19.433307
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass # TODO

# Generated at 2022-06-12 05:57:27.234440
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    @dataclass
    class _T:
        pass
    source = _T()
    je = JournalEntry[source](datetime.date(2020, 9, 5), "test", source)
    print(je)
    je2 = je.post(datetime.date(2020, 9, 7), Account.of("Assets", "Cash"), 10)
    je3 = je2.post(datetime.date(2020, 9, 7), Account.of("Assets", "Cash"), -5)
    for p in je3.postings:
        print(p)
    print(je3)
