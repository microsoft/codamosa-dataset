

# Generated at 2022-06-12 05:48:31.171385
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ReadJournalEntries_Mock_Impl(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange):
            pass

    ReadJournalEntries_Mock_Impl()

# Generated at 2022-06-12 05:48:34.482212
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert ReadJournalEntries.__call__.__annotations__["return"] == Iterable[JournalEntry[None]]
    assert ReadJournalEntries.__call__.__annotations__["period"] == DateRange

# Generated at 2022-06-12 05:48:38.638413
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import testledger
    tl = testledger.ledger()
    je = JournalEntry(tl.date('2012-01-01'), "Transaction", None)
    je.post(tl.date('2012-01-01'), tl.account('Assets:CAD:Chequing'), 10)
    je.post(tl.date('2012-01-01'), tl.account('Expenses:Food'), -10)
    je.validate()

# Generated at 2022-06-12 05:48:39.235266
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
  assert True

# Generated at 2022-06-12 05:48:44.722875
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .commons.others import now
    from . import exchanges
    from . import products
    from . import quantities

    # Define a journal entry:
    ie = JournalEntry(now(), "My Journal Entry", None)
    ie.post(now(), Account("USD", AccountType.ASSETS), +100)
    ie.post(now(), Account("USD", AccountType.LIABILITIES), -100)

    # Perform validation:
    ie.validate()

# Generated at 2022-06-12 05:48:54.544731
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime
    from dataclasses import dataclass
    from enum import Enum
    from typing import List

    @dataclass
    class Transaction:
        pass

    @dataclass
    class Account(Transaction):
        pass

    @dataclass(frozen=True)
    class Posting:
        pass

    @dataclass(frozen=True)
    class JournalEntry:
        pass

    class ReadJournalEntries(Protocol):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            pass

    @dataclass
    class Guid:
        numbers: List[int]

    @dataclass(frozen=True)
    class DateRange:
        start_date: datetime.date
        end_date: datetime.date


# Generated at 2022-06-12 05:49:07.034477
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    test_ACCOUNT = Account("Test", AccountType.ASSETS)
    test_DATE = datetime.date.today()
    test_JOURNAL_ENTRY = JournalEntry[list]()
    test_QTY = Quantity(1)

    test_JOURNAL_ENTRY.post(test_DATE, test_ACCOUNT, test_QTY)

    assert len(test_JOURNAL_ENTRY.postings) == 1
    assert test_JOURNAL_ENTRY.postings[0].account == test_ACCOUNT
    assert test_JOURNAL_ENTRY.postings[0].date == test_DATE
    assert test_JOURNAL_ENTRY.postings[0].amount == Amount(test_QTY)

# Generated at 2022-06-12 05:49:13.190478
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Arrange
    def source(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    unit: ReadJournalEntries[_T] = source
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    # Act
    actual = unit(period)
    # Assert

# Generated at 2022-06-12 05:49:18.758650
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal = JournalEntry[int](datetime.date.today(), 'Test', 1)
    journal.post(datetime.date.today(), Account('Test Account', AccountType.LIABILITIES), 1)
    journal.post(datetime.date.today(), Account('Test Account', AccountType.EXPENSES), -1)
    journal.validate()

# Generated at 2022-06-12 05:49:28.394288
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..ledger.ledger import Ledger
    from .lib.read_journal_entries_ledger import read_journal_entries_ledger

    rje: ReadJournalEntries = read_journal_entries_ledger()

    # Test:
    ledger = Ledger()
    ledger.add_date_range(DateRange(20180601, 20180731))
    entries = list(rje(ledger.date_range))
    assert len(entries) == 10
    assert sum(1 for e in entries if e.date.year == 2018 and e.date.month == 6) == 5
    assert sum(1 for e in entries if e.date.year == 2018 and e.date.month == 7) == 5

# Generated at 2022-06-12 05:49:36.250724
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class MockReadJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return []

    assert len(list(MockReadJournalEntries()(DateRange()))) == 0



# Generated at 2022-06-12 05:49:38.355407
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry(datetime.date.today(), "Testing", "Test", [])
    assert je.validate() == None

# Generated at 2022-06-12 05:49:43.738161
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    This test case is to test the posting of journal entry
    """
    from .accounts import Account, AccountType

    journal = JournalEntry[int] (1, 'test journal entry', 1)
    journal.post(22, Account (1, 'Account1', AccountType.REVENUES), 50)
    journal.post(22, Account (2, 'Account2', AccountType.LIABILITIES), 50)
    journal.validate()

# Generated at 2022-06-12 05:49:54.091071
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j1 = JournalEntry(datetime.date(2020,1,1),"test", "test")
    j1.post(datetime.date(2020,1,1), Account(AccountType.REVENUES, "test", "test"), Quantity(1))
    j1.post(datetime.date(2020,1,1), Account(AccountType.REVENUES, "test2", "test2"), Quantity(2))
    j1.post(datetime.date(2020,1,1), Account(AccountType.EXPENSES, "test3", "test3"), Quantity(3))
    j1.post(datetime.date(2020,1,1), Account(AccountType.EXPENSES, "test4", "test4"), Quantity(4))
    assert len(j1.postings) == 4

# Generated at 2022-06-12 05:50:00.203990
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account

    je=JournalEntry(date=datetime.date(2020,5,5),description="Sample",source=Account("SAMPLE ACCOUNT",0.0,AccountType.ASSETS))
    je.post(date=datetime.date(2020,5,5),account=Account("SAMPLE ACCOUNT",0.0,AccountType.ASSETS),quantity=1000)

# Generated at 2022-06-12 05:50:09.749032
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.accounts import DummyAccounts
    accounts = DummyAccounts()

    from datetime import date
    today = date.today()
    from ..books.partners import Partner, DummyPartner
    partner = Partner(DummyPartner(), "Unknown")

    from ..books.accounts import Account, AccountType
    account_bank_assets = Account(AccountType.ASSETS, "BANK", "Bank", "", "Cash held in bank.")
    account_taxing_expenses = Account(AccountType.EXPENSES, "TAXING", "Taxing", "", "Expenses of taxing.")

    # create a journal entry
    je = JournalEntry(today, "", partner)
    je.description = "Test"
    je.post(today, account_bank_assets, -1000)

# Generated at 2022-06-12 05:50:15.453762
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import account_types

    journal1 = JournalEntry(datetime.date.today(), 'test journal entry', None)
    journal1.post(datetime.date.today(), account_types['ASSETS']['Cash'], 5).post(datetime.date.today(), account_types['LIABILITIES']['Credit'], 5)
    journal1.validate()



# Generated at 2022-06-12 05:50:23.925904
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountBook
    from .periods import PeriodBook

    # First we create an account book.
    ab = AccountBook()

    # Then we add a couple of accounts.
    assets = ab.add(AccountType.ASSETS, "Assets")
    debor = ab.add(AccountType.EQUITIES, "Debor")
    credor = ab.add(AccountType.EQUITIES, "Credor")
    bank = ab.add(AccountType.ASSETS, "Bank")

    # We also create a period book.
    pb = PeriodBook()

    # Then we create a journal entry and post a debt of `5000` to `debor` and `1000` to `bank`.
    je = JournalEntry(pb.wsdate, "Overpaid debt", Guid())

# Generated at 2022-06-12 05:50:31.445275
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account = Account(1, "test", AccountType.EXPENSES)
    source = "test"
    je = JournalEntry(date = datetime.date.today(), description = "", source = source)
    je.post(date = datetime.date.today(), account = account, quantity = 100)
    expected = [JournalEntry.postings[0].amount]
    actual = [100]
    assert expected == actual

if __name__ == '__main__':
    test_JournalEntry_post()

# Generated at 2022-06-12 05:50:39.410784
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # If a JournalEntry is incorrect it will raise an AssertionError
    # If a JournalEntry is correct, it won't raise an AssertionError
    try:
        jn = JournalEntry(datetime.date(2020, 7, 1), "This test", "Test", list())
        jn.post(datetime.date(2020, 7, 1), Account("Assets", AccountType.ASSETS), Quantity(10))
        jn.post(datetime.date(2020, 7, 1), Account("Revenues", AccountType.REVENUES), Quantity(10))
        jn.validate()
        assert True
    except:
        assert False

# Generated at 2022-06-12 05:50:54.656383
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry(
        date=datetime.date(2020, 7, 10),
        description="Test",
        source="Test"
    )

    j.post(datetime.date(2020, 7, 10), Account("1110", AccountType.EXPENSES), -100)
    j.post(datetime.date(2020, 7, 10), Account("1120", AccountType.ASSETS), 100)

    j.validate()

# Generated at 2022-06-12 05:51:06.508221
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # ----------------------------------------------------------------
    # Setup:
    from unittest import mock
    from datetime import date

    # Create a mock asset account and expense account:
    id_asset: str = "id_asset"
    type_asset: AccountType = AccountType.ASSETS
    asset: Account = mock.Mock(name="asset", id=id_asset, type=type_asset)
    id_expense: str = "id_expense"
    type_expense: AccountType = AccountType.EXPENSES
    expense: Account = mock.Mock(name="expense", id=id_expense, type=type_expense)

    # Create a mock journal entry and source:
    source: str = "mock_source"
    description: str = "mock_description"

# Generated at 2022-06-12 05:51:17.273693
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class _TestObject:
        pass

    def _test_call(period: DateRange):
        assert period.is_valid()
        yield JournalEntry[int](datetime.date(2000, 1, 1), "Test1", 0)
        yield JournalEntry[int](datetime.date(2000, 1, 2), "Test2", 1)
        yield JournalEntry[int](datetime.date(2000, 1, 3), "Test3", 2)
        yield JournalEntry[int](datetime.date(2000, 1, 4), "Test4", 3)


# Generated at 2022-06-12 05:51:24.649368
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts.read import ReadAccountsFromFile
    from .accounts.collection import AccountCollection
    from .core import BaseCSVFeed
    from .core.file import CSVFile
    from .core.read import CSVFeedReader

    accounts = AccountCollection(Account(id='1', name='TEST', type=AccountType.ASSETS),
                                 Account(id='2', name='TEST', type=AccountType.LIABILITIES))


# Generated at 2022-06-12 05:51:32.507966
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class A:
        pass

    @dataclass(frozen=True)
    class B:
        pass

    def spec():
        def mock(period: DateRange) -> Iterable[JournalEntry[A]]:
            yield JournalEntry(datetime.date.today(), "", A())

    assert ReadJournalEntries.__subclasscheck__(spec)
    assert not ReadJournalEntries.__subclasscheck__(
        (lambda period: [JournalEntry(datetime.date.today(), "", B())])
    )

# Generated at 2022-06-12 05:51:42.449933
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from datetime import date

    from ..models.accounts import Account
    from ..models.journal import JournalEntry, Direction

    je = JournalEntry(date.today(), "Testing", None).post(date.today(), Account(name="Dr", type=AccountType.ASSETS), 100).post(date.today(), Account(name="Cr", type=AccountType.EXPENSES), -100)
    je.validate()
    je = JournalEntry(date.today(), "Testing", None).post(date.today(), Account(name="Dr", type=AccountType.ASSETS), 100).post(date.today(), Account(name="Cr", type=AccountType.REVENUES), -100)
    je.validate()

# Generated at 2022-06-12 05:51:52.846119
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    entry = JournalEntry(
        date=datetime.date.fromisoformat("2020-01-01"),
        description="Testing JournalEntry.post()",
        source="TBD",
    )
    entry.post(datetime.date.fromisoformat("2019-12-31"), Account("Test1", AccountType.LIABILITIES), Quantity(-100))
    entry.post(datetime.date.fromisoformat("2019-12-31"), Account("Test2", AccountType.ASSETS), Quantity(100))

    try:
        entry.validate()
    except Exception as error:
        print(error)
        assert False, "JournalEntry.validate() raised Exception unexpectedly!"

    entry.post(datetime.date.fromisoformat("2019-12-31"), Account("Test3", AccountType.EXPENSES), Quantity(-10))
    entry

# Generated at 2022-06-12 05:52:04.715770
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType, RootAccount
    from .ledgers import Ledger, LedgerEntry
    from .tags import Tag

    revenues_account = Account("Revenues", AccountType.REVENUES, RootAccount())
    expenses_account = Account("Expenses", AccountType.EXPENSES, RootAccount())

    insurance_expenses_account = Account("Insurance", AccountType.EXPENSES, expenses_account)
    insurance_ledger = Ledger(insurance_expenses_account)
    insurance_ledger.post(datetime.date(2020, 1, 1), insurance_expenses_account, 500)

    taxes_expenses_account = Account("Taxes", AccountType.EXPENSES, expenses_account)
    taxes_ledger = Ledger(taxes_expenses_account)
    taxes_ledger.post

# Generated at 2022-06-12 05:52:05.176138
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-12 05:52:06.062656
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # todo
    assert True == True

# Generated at 2022-06-12 05:52:32.748271
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    class T:
        pass

    t1 = T()
    t2 = T()

    j1 = JournalEntry[T](datetime.date(2020, 1, 1), "", t1)
    j2 = JournalEntry[T](datetime.date(2020, 1, 1), "", t2)

    j1.post(datetime.date(2020, 1, 1), Account("A"), 10)
    j1.post(datetime.date(2020, 1, 1), Account("B"), -10)

    j2.post(datetime.date(2020, 1, 1), Account("A"), 10)
    j2.post(datetime.date(2020, 1, 1), Account("B"), -10)

    j1.validate()
    j2.validate()

# Generated at 2022-06-12 05:52:40.171215
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..accounting import accounts
    import pytest

    a1 = accounts.CurrentAssets.Cash.Bank.Checking
    a2 = accounts.Revenues.CreditCardRevenue

    je = JournalEntry(datetime.date(2019, 10, 1), "Test", None)
    je.post(datetime.date(2019, 10, 1), a1, -300)
    je.post(datetime.date(2019, 10, 1), a2, 300)
    je.validate()

    with pytest.raises(AssertionError):
        je.post(datetime.date(2019, 10, 1), a2, 300)
        je.validate()

# Generated at 2022-06-12 05:52:46.588346
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from random import randrange
    from unittest.mock import Mock, call
    journal_entry = JournalEntry[int](datetime.date.today(), "Test", 1)
    def side_effect(*args): return randrange(10)
    journal_entry.postings = [Posting(journal_entry, datetime.date.today(), Account("test", AccountType.ASSETS), Direction.INC, Amount(1)) for _ in range(10)]
    journal_entry.validate()

# Generated at 2022-06-12 05:52:52.046372
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    steven_account = Account('steven_account', AccountType.ASSETS)
    steven_posting = Posting(None, datetime.date.today(), steven_account, Direction.INC, Amount(1000))
    steven_journal_entry = JournalEntry(datetime.date.today(), 'testing', None, [steven_posting])
    
    steven_journal_entry.validate()

# Generated at 2022-06-12 05:53:01.225094
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account

    j1 = JournalEntry(datetime.date(2019,1,1), "Test", "This is a test")
    a1 = Account('a1', "Assets", AccountType.ASSETS)
    a2 = Account('a2', "Liabilities", AccountType.LIABILITIES)

    j1.post(datetime.date(2019,1,1), a1, Quantity(-5))
    j1.post(datetime.date(2019,1,1), a2, Quantity(5))

    assert(j1.debits == [Posting(j1, datetime.date(2019,1,1), a1, Direction.DEC, Amount(5))])

# Generated at 2022-06-12 05:53:03.844188
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test = ReadJournalEntries()
    test1 = JournalEntry[test]()
    assert test1

# Generated at 2022-06-12 05:53:13.860343
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    def test_data():
        return (
            (JOURNAL_1, True),
            (JOURNAL_2, False)
        )
    for journal, is_valid in test_data():
        if is_valid:
            journal.validate()
        else:
            try:
                journal.validate()
            except AssertionError:
                pass
            else:
                assert False, f"Journal {journal} should have failed validation."

JOURNAL_1 = JournalEntry(date=datetime.date(2019, 12, 31), description="Journal Entry 1", source=None)
JOURNAL_1.post(datetime.date(2019, 12, 31), Account("Cash", AccountType.ASSETS), Quantity(100))

# Generated at 2022-06-12 05:53:21.359278
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je1 = JournalEntry[None](datetime.date(2020,3,15),
                'Transfer of Funds',
                None)
    je1.post(datetime.date(2020,3,15),
            Account('Cash', AccountType.ASSETS),
            10000)
    je1.post(datetime.date(2020,3,15),
            Account('Bank', AccountType.ASSETS),
            -10000)
    je1.validate()

# Generated at 2022-06-12 05:53:25.864042
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    entry = JournalEntry(datetime.date(2020, 1, 1), "Testing", None)
    entry.post(datetime.date(2020, 1, 1), Account.ASSETS, +10)
    entry.post(datetime.date(2020, 1, 1), Account.REVENUES, -10)
    entry.validate()

# Generated at 2022-06-12 05:53:34.994216
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    journal_entry = JournalEntry(None, None, None)
    date = datetime.date(2020, 3, 31)
    account = Account("cash", AccountType.ASSETS)

    # Act
    journal_entry.post(date, account, Quantity(100))

    # Assert
    assert len(journal_entry.postings) == 1
    posting = journal_entry.postings[0]
    assert posting.date == date
    assert posting.account == account
    assert posting.direction == Direction.INC
    assert posting.amount == Amount(100)


# Generated at 2022-06-12 05:54:20.379281
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(datetime.date.today(), "Sample journal entry", None)
    journal = journal.post(datetime.date.today(), Account("Assets"), 4)
    assert len(journal.postings) == 1
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].account.name == "Assets"
    assert journal.postings[0].amount == Amount(4)

    journal = journal.post(datetime.date.today(), Account("Revenue"), -2)
    assert len(journal.postings) == 2
    assert journal.postings[1].direction == Direction.DEC
    assert journal.postings[1].account.name == "Revenue"
    assert journal.postings[1].amount == Amount(2)


# Generated at 2022-06-12 05:54:27.293290
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Setup
    account_a = Account(type=AccountType.ASSETS, name="A")
    account_b = Account(type=AccountType.ASSETS, name="B")
    je = JournalEntry(date=None, description=None, source=None)
    je.post(None, account_a, +1)
    je.post(None, account_b, -1)

    # Exercise
    je.validate()

    # Verify
    assert True

# Generated at 2022-06-12 05:54:36.395111
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    
    from .accounts import Account, AccountType
    from .currencies import Currency, getcurrency
    from .events import OfferEvent, OfferEventType
        
    date = datetime.date.fromisoformat("2020-01-01")
    
    #Creation of JournalEntry
    journal = JournalEntry(date, "FEE", OfferEvent(OfferEventType.FEE, "USD", 0.01))
    
    account = Account("USD", AccountType.ASSETS, "Cash")
    journal.post(date, account, 0.01)
    
    account = Account("USD", AccountType.EXPENSES, "Fee")
    journal.post(date, account, 0.01)
    
    journal.validate()
    assert True

# Generated at 2022-06-12 05:54:36.914953
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

# Generated at 2022-06-12 05:54:44.636060
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    _JournalEntry = JournalEntry
    _Posting = Posting
    _Direction = Direction
    
    _journal = _JournalEntry(datetime.date(2020, 1, 1), '', '')
    _journal.post(datetime.date(2020, 1, 1), '', 1)
    _journal.post(datetime.date(2020, 1, 1), '', -1)

    assert _journal.postings[0].direction == _Direction.INC
    assert _journal.postings[1].direction == _Direction.DEC

# Generated at 2022-06-12 05:54:51.506135
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry[str]('01-01-2020', 'Test', 'Source')
    j.post(datetime.datetime.now(),
           Account('1000', 'Cash', AccountType.ASSETS),
           1000)
    j.post(datetime.datetime.now(),
           Account('1000', 'Cash', AccountType.ASSETS),
           -1000)
    j.validate()

# Generated at 2022-06-12 05:54:53.012052
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

# Generated at 2022-06-12 05:54:56.254251
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class MockReadJournalEntries(_T):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            assert period.start <= period.end
            return []
    MockReadJournalEntries()(DateRange(datetime.date.today(), datetime.date.today()))

# Generated at 2022-06-12 05:54:56.842016
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-12 05:55:08.125869
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType
    from .business import AccountRegister, Business, BusinessLine
    from .transactions import Transaction

    ## Setup:
    business_line = BusinessLine(name='test', cfs_type=AccountType.EQUITIES)
    business = Business(name='test', lines=[business_line])
    business_line.business = business

    register = AccountRegister(business=business)
    register.environment.accounting_period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    assert len(register.journal) == 0

    ## Transaction with 1 posting (INC):

# Generated at 2022-06-12 05:56:15.937049
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    from .accounts import AccountFactory
    from .books import Book
    from .events import on_journal_entry_created

    Book().install()
    account1 = AccountFactory.create("ASSETS", "Assets").install()
    account2 = AccountFactory.create("EXPENSES", "Expenses").install()

    j = JournalEntry(date = datetime.date(2020, 4, 1), description="Test", source=None)
    on_journal_entry_created(j)

    # Act
    j.post(datetime.date(2020, 4, 1), account1, 10)
    j.post(datetime.date(2020, 4, 1), account2, -10)

    # Assert
    assert j.postings[0].is_debit
    assert j.postings[1].is_credit

# Generated at 2022-06-12 05:56:16.559908
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:56:20.333378
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Unit test for method __call__ of class ReadJournalEntries.
    """
    from ..unittests.auxiliary import _run_test
    _run_test("test_ReadJournalEntries___call__", globals())

# Generated at 2022-06-12 05:56:25.732426
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    ## Prepare
    JournalEntry.postings = [Posting(1, datetime.date(2020,2,2), Account(1, AccountType.ASSETS, "a"), Direction.INC, Amount(100))]
    ## Execute
    try:
        ## Test
        JournalEntry.validate()
    except:
        return False
    return True

# Generated at 2022-06-12 05:56:26.514768
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False, "TODO: Implement"

# Generated at 2022-06-12 05:56:28.230181
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    print("test_ReadJournalEntries___call__()")    
    assert False, "Not implemented."



# Generated at 2022-06-12 05:56:39.438367
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date, timedelta
    from ledger import JournalEntry, ReadJournalEntries

    jes = [
        JournalEntry[None](date(2020, 1, 1), "Test1", None),
        JournalEntry[None](date(2020, 1, 1), "Test2", None),
        JournalEntry[None](date(2020, 2, 1), "Test3", None),
    ]

    def read_je(period: DateRange) -> Iterable[JournalEntry[None]]:
        return (je for je in jes if period.contains(je.date))

    assert list(read_je(DateRange(date(2020, 1, 1), date(2020, 1, 31)))) == jes[:2]
    ReadJournalEntries[None]


# Generated at 2022-06-12 05:56:50.276780
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # pylint: disable=unused-argument,missing-docstring,too-many-locals,too-many-statements
    from dataclasses import _MISSING_TYPE  # pylint: disable=protected-access

    #: Function (lambda) which reads all journal entries.
    read_all: ReadJournalEntries[_T] = lambda period: []

    #: Function (lambda) with no type annotation.
    read_no_type: ReadJournalEntries = lambda period: []

    #: Function (lambda) with type annotation for ``_T``.
    read_with_type: ReadJournalEntries[str] = lambda period: []

    #: Function (lambda) which returns a list of journal entries.

# Generated at 2022-06-12 05:57:02.549158
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import typing
    from typing import Callable, Iterable, TypeVar
    from ..commons.zeitgeist import DateRange

    T = TypeVar('T')

    def wrapper(f: Callable) -> Callable[[Iterable[T]], ReadJournalEntries[T]]:
        def inner(*args, **kwargs):
            return f(*args, **kwargs)
        return typing.cast(ReadJournalEntries[T], inner)
    wrapper_v = wrapper(lambda period: journal_entries)  # type: ReadJournalEntries[T]
    journal_entries = [JournalEntry(datetime.date(2010, 1, 1), '', None)]  # type: Iterable[JournalEntry[T]]
    period = DateRange(datetime.date(2010, 1, 1), datetime.date(2010, 1, 1)) 

# Generated at 2022-06-12 05:57:09.627849
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date = datetime.date(2019, 4, 13)
    description = 'A simple test for JournalEntry_validate()'
    source = 'JournalEntry_validate'

    account_id_1 = 1
    balance_1 = 100
    account_1 = Account(account_id_1, 'A1', balance_1, AccountType.ASSETS)

    account_id_2 = 2
    balance_2 = 0
    account_2 = Account(account_id_2, 'A2', balance_2, AccountType.LIABILITIES)
    
    account_id_3 = 3
    balance_3 = 0
    account_3 = Account(account_id_3, 'A3', balance_3, AccountType.REVENUES)
    
    amount_1 = 20
    amount_2 = -20
    amount_3

# Generated at 2022-06-12 05:58:24.902655
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from .accounts import Account, AccountType
    from .funds import Fund
    from .money import Currencies, LocalCurrency
    from .transactions import Transaction, Transfer

    # Setup:
    usd = Currencies.get("USD")
    eur = Currencies.get("EUR")
    local = LocalCurrency(usd)

    # Test PayIn
    transaction = Transaction(date(2019, 3, 1), "PayIn", Fund(usd, Amount(1000)))
    je = transaction.journal()
    je.post(date(2019, 3, 1), Account.of(AccountType.ASSETS, local), Amount(1000))
    assert len(je.postings) == 1
    assert je.postings[0].date == date(2019, 3, 1)