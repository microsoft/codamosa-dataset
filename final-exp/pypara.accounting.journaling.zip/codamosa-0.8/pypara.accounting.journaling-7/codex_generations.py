

# Generated at 2022-06-12 05:48:43.252055
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    start = datetime.date(year=2020, month=1, day=1)
    end = datetime.date(year=2020, month=1, day=31)
    from ..events.accounts import AccountEvent
    from ..events.orders import OrderEvent, OrderType

# Generated at 2022-06-12 05:48:54.194696
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    Account1 = Account("account1", AccountType.ASSETS)
    Account2 = Account("account2", AccountType.LIABILITIES)
    date = datetime.date(2029, 1, 1)
    journal = JournalEntry(date, "description", "source")
    journal.post(date, Account1, +1000)
    journal.post(date, Account2, -1000)
    assert len(journal.postings) == 2
    assert journal.postings[0].date == journal.postings[1].date == date
    assert journal.postings[0].account == Account1
    assert journal.postings[1].account == Account2
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[1].direction == Direction.DEC
    assert journal.postings[0].amount == journal.postings

# Generated at 2022-06-12 05:49:06.500376
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount
    from ..accounting import accounts

    #: Model for accounting journal entries.
    @dataclass(frozen=True)
    class Journal(_T):
        pass

    #: Models the method which will read journal entries

# Generated at 2022-06-12 05:49:17.482444
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class _Test:

        def __init__(self):
            self.count = 0
            self.count2 = 0

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[int]]:
            self.count += 1
            self.count2 += 1
            return [
                JournalEntry(datetime.date(2019, 12, 31), "test1", 1),
                JournalEntry(datetime.date(2019, 12, 31), "test2", 2)
            ]

    test: _Test = _Test()
    fn: ReadJournalEntries[int] = test
    assert fn(DateRange.of(dt(2019, 12, 31))) == test(DateRange.of(dt(2019, 12, 31)))
    assert test.count == 1
    assert test.count2 == 2



# Generated at 2022-06-12 05:49:28.354366
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Test the method validate of class JournalEntry.
    """
    joe = Account(code="FOO", name="JOE", type=AccountType.EXPENSES)
    jim = Account(code="BAR", name="JIM", type=AccountType.ASSETS)

    je = JournalEntry(date=datetime.date.today(), description="Entry 1")

    ## Test for equal debits and credits:
    assert je.post(date=datetime.date.today(), account=joe, quantity=100).post(date=datetime.date.today(), account=jim, quantity=-100).validate()

    ## Test for unequal debits and credits:

# Generated at 2022-06-12 05:49:32.350552
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    class obj:
        pass
    
    je = JournalEntry(datetime.date.today(), "test", obj())
    je.post(datetime.date.today(), Account(AccountType.ASSETS, ""), Quantity(1))
    je.post(datetime.date.today(), Account(AccountType.EQUITIES, ""), Quantity(-1))
    je.validate()

# Generated at 2022-06-12 05:49:37.979837
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    ## Should validate:
    JournalEntry(datetime.date.today(), "", "", [Posting(0, datetime.date.today(), Account(0, "", "", AccountType.ASSETS), Direction.INC, Amount(100)),
                                                   Posting(0, datetime.date.today(), Account(0, "", "", AccountType.EQUITIES), Direction.INC, Amount(100))]).validate()
    JournalEntry(datetime.date.today(), "", "", [Posting(0, datetime.date.today(), Account(0, "", "", AccountType.REVENUES), Direction.DEC, Amount(100)),
                                                   Posting(0, datetime.date.today(), Account(0, "", "", AccountType.EXPENSES), Direction.DEC, Amount(100))]).validate()

# Generated at 2022-06-12 05:49:46.679610
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    from datetime import date

    journal = JournalEntry[int](
        date=date(2019, 7, 31), 
        description="Test", 
        source=1
    )

    journal.post(
        date=date(2019, 7, 31),
        account=Account(
            identifier=1,
            name="Assets",
            type=AccountType.ASSETS
        ),
        quantity=+100
    )
    journal.post(
        date=date(2019, 7, 31),
        account=Account(
            identifier=2,
            name="Liabilities",
            type=AccountType.LIABILITIES
        ),
        quantity=-100
    )

    journal.validate()



# Generated at 2022-06-12 05:49:52.167771
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create a new journal entry
    test_value = JournalEntry(datetime.date(2020, 1, 1), "Test Posting", "Source")

    # Post increment event
    test_value.post(datetime.date(2020, 1, 1), Account("Test Account", "", "", AccountType.REVENUES), 100)

    # Validate
    test_value.validate()



# Generated at 2022-06-12 05:49:53.123704
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries.__call__.__annotations__

# Generated at 2022-06-12 05:50:00.204356
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries.__call__(JournalEntry)

# Generated at 2022-06-12 05:50:05.541565
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    entries = [JournalEntry(datetime.date(2020, 1, 2), "test", None, [])]
    date_range = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2))

    assert list(ReadJournalEntries.__call__(lambda x: entries, date_range)) == entries

# Generated at 2022-06-12 05:50:11.793788
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account1 = Account("IDR", "Assets", "Cash", "Cash in US Dollars")
    account2 = Account("IDR", "Expenses", "Transportation", "Transportation Cost in IDR")

    the_entry = JournalEntry(datetime.date(2016, 1, 1), "Taxi trip", ())
    the_entry.post(datetime.date(2016, 1, 1), account1, Amount(200000))
    the_entry.post(datetime.date(2016, 1, 1), account2, Amount(200000))

    assert the_entry.postings[0].amount == Amount(200000)
    assert the_entry.postings[0].direction == Direction.INC
    assert the_entry.postings[0].account == account1
    assert the_entry.postings[0].journal == the_entry

    assert the

# Generated at 2022-06-12 05:50:16.207075
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books import journals
    from ..books.accounts import Account, AccountType
    from ..books.companies import Company
    from ..books.markets import Currency, EquitySecurity
    from ..books.ledgers import Ledger
    from ..books.markets import StockMarket
    from ..books.trades import Trade

    # Create a company, its ledger, and a stock market:
    company = Company()
    ledger = Ledger(company)
    stock_market = StockMarket()

    # Create an equity security at the stock market:
    security = EquitySecurity(stock_market, "Coke", Currency.USD)

    # Create a trade:

# Generated at 2022-06-12 05:50:24.179229
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account

    journal_entry: JournalEntry = JournalEntry(datetime.date(2020, 2, 1), "Description", "source")
    journal_entry.post(datetime.date(2020, 2, 1), Account.create("Account 1", "Asset"), 10)
    journal_entry.post(datetime.date(2020, 2, 1), Account.create("Account 2", "Liability"), -10)
    assert journal_entry.postings[0].account.name == "Account 1"
    assert journal_entry.postings[0].amount == 10
    assert journal_entry.postings[0].direction == Direction.INC
    assert journal_entry.postings[1].account.name == "Account 2"
    assert journal_entry.postings[1].amount == 10

# Generated at 2022-06-12 05:50:35.476757
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account

    DEBIT_ACCOUNT = Account("DEBIT_ACCOUNT", AccountType.EXPENSES)
    CREDIT_ACCOUNT = Account("CREDIT_ACCOUNT", AccountType.REVENUES)

    entry = JournalEntry(datetime.date(2020, 9, 20), "entry description", None)
    entry.post(datetime.date(2020, 9, 20), DEBIT_ACCOUNT, -10)
    entry.post(datetime.date(2020, 9, 20), CREDIT_ACCOUNT, 10)

    # debit event postings
    assert len(list(entry.debits)) == 1
    assert [p.account for p in entry.debits] == [DEBIT_ACCOUNT]
    assert [p.amount for p in entry.debits] == [Amount(10)]

    # credit event postings


# Generated at 2022-06-12 05:50:43.018691
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..booking.source import GeneralLedger
    from ..booking.source.atoms import PostingLine
    journal = JournalEntry[GeneralLedger](datetime.date(2020, 1, 1), 'test', GeneralLedger.of('test'))

    journal.post(datetime.date(2020,1,1), Account(1), 100)

    assert journal.postings[0].account == Account(1)
    assert journal.postings[0].is_debit
    assert journal.postings[0].amount == 100

    journal.post(datetime.date(2020, 1, 1), Account(2), -100)

    assert journal.postings[1].account == Account(2)
    assert not journal.postings[1].is_debit
    assert journal.postings[1].amount == 100

# Generated at 2022-06-12 05:50:48.766864
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.zeitgeist import today

    class A:
        pass

    j = JournalEntry[A](
        today(),
        "A/P to A/R repayment",
        A(),
    )

    j.post(today(), "A/R", Amount(-100))
    j.post(today(), "A/P", Amount(100))

    j.validate()

    assert True

# Generated at 2022-06-12 05:50:50.079402
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert isinstance(ReadJournalEntries.__call__, property)

# Generated at 2022-06-12 05:50:59.163065
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class A(object):
        def __init__(self, account, quantity):
            self.account = account
            self.quantity = quantity

    class B(object):
        def __init__(self, account, quantity):
            self.account = account
            self.quantity = quantity
    a = A(account = 'cash', quantity = 12)
    b = B(account = 'salary', quantity = 3)
    x = [a, b]
    y = []
    z = []
    o = []
    journal_entry = JournalEntry[str]()
    for i in x:
        k = journal_entry.post(i.account, i.quantity)
        y.append(k)
    for j in y:
        l = j.postings
        z.append(l)

# Generated at 2022-06-12 05:51:07.502834
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ...

# Generated at 2022-06-12 05:51:18.180669
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.models import Transaction
    from .accounts import AccountType, Account
    from .ledgers import Ledger
    from datetime import date
    from decimal import Decimal
    # create a journal
    je = JournalEntry[Transaction].of(date(2020, 5, 10), 'test journal')
    # post an increment event to account receivable
    je.post(date(2020, 5, 10), Account(AccountType.LIABILITIES, 'A/R'), Decimal('10.00'))
    # post a decrement event to account receivable
    je.post(date(2020, 5, 10), Account(AccountType.LIABILITIES, 'A/R'), Decimal('-5.00'))
    # post an increment event to account receivable

# Generated at 2022-06-12 05:51:25.059970
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from datetime import datetime
    from datetime import timedelta
    from typing import Dict
    from typing import List
    from typing import Tuple

    from ..accounts.accounts import Account
    from ..accounts.accounts import AccountT

    from .accounts import AccountType

    from dataclasses import asdict
    from dataclasses import dataclass
    from dataclasses import field
    from dataclasses import replace
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass(frozen=True)
    class Person(DataClassJsonMixin):
        first_name: str
        last_name: str


# Generated at 2022-06-12 05:51:33.084755
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class A:
        def __init__(self, arg):
            self.arg = arg

    class B(Protocol[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    def C(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
        return ()

    instance = A('text')
    assert not isinstance(instance, B)
    assert isinstance(instance, ReadJournalEntries)

    instance = C
    assert not isinstance(instance, B)
    assert isinstance(instance, ReadJournalEntries)

# Generated at 2022-06-12 05:51:33.739829
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:51:39.099613
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(datetime.datetime.today().date(), "Test", "Test")
    j.post(datetime.datetime.today().date(), Account("Test", AccountType.EQUITIES), Quantity(100))
    j.post(datetime.datetime.today().date(), Account("Test", AccountType.REVENUES), Quantity(100))
    j.validate()

# Generated at 2022-06-12 05:51:40.556423
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False, "Not implemented"
    # Setup
    # Assume
    # Action
    # Assert

# Generated at 2022-06-12 05:51:44.133980
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry=JournalEntry[int](datetime.date(2020,10,1),"entered by Sushila")
    journal_entry.post(datetime.date(2020,10,1),Account(1,"Cheque Account"),1000)
    journal_entry.post(datetime.date(2020,10,1),Account(2,"Cash Account"),-1000)
    journal_entry.validate()

# Generated at 2022-06-12 05:51:53.518565
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..books.book import Book
    from ..books.depreciation import DepreciationBook
    from ..books.inventory import InventoryBook
    from ..books.payables import PayablesBook
    from ..books.receivables import ReceivablesBook
    from ..books.sales import SalesBook
    from ..books.tax import TaxBook

    def make_book(book_cls: Book) -> Book:
        book = book_cls()
        book.create(date=datetime.date.today(), description="Test Data")
        return book

    books = [
        make_book(book_cls)
        for book_cls in [
            DepreciationBook,
            InventoryBook,
            PayablesBook,
            ReceivablesBook,
            SalesBook,
            TaxBook,
        ]
    ]


# Generated at 2022-06-12 05:51:54.172379
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ...

# Generated at 2022-06-12 05:52:17.799672
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[int](datetime.date.today(), "", 1)
    try:
        je.validate()
    except AssertionError:
        assert True
    else:
        assert False

    je.post(datetime.date.today(), Account("Assets:Checking"), 20)
    je.post(datetime.date.today(), Account("Expenses:Food"), -10)
    je.post(datetime.date.today(), Account("Expenses:Food"), -10)
    try:
        je.validate()
    except AssertionError:
        assert False
    else:
        assert True

# Generated at 2022-06-12 05:52:18.383838
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:52:22.394772
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je1 = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="test journal entry test_JournalEntry_validate",
        source=None,
        postings=None)
    assert je1.validate() is None

# Generated at 2022-06-12 05:52:32.438714
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    je = JournalEntry[object](date=datetime.date(2020, 4, 1), description="Dummy entry for unit test")
    a1 = Account(code="200001", name="Cash", type=AccountType.ASSETS)
    a2 = Account(code="300001", name="Sales", type=AccountType.REVENUES)
    je = je.post(date=datetime.date(2020, 4, 1), account=a1, quantity=10000)
    je = je.post(date=datetime.date(2020, 4, 1), account=a2, quantity=10000)
    je.validate()

    # Check the posting
    assert je.postings[0].account == a1
    assert je.postings[1].account == a2

    assert je.postings

# Generated at 2022-06-12 05:52:40.858371
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass
    class _Dummy:
        pass

    @dataclass
    class _Source:
        def __call__(self):
            yield JournalEntry(date=datetime.date(2005, 5, 7), description="1st Entry", source=_Dummy(),
                               postings=[
                                   Posting(None, datetime.date(2005, 5, 7), Account(1, "Assets:Cash"), Direction.INC,
                                           Amount(15000)),
                                   Posting(None, datetime.date(2005, 5, 7), Account(2, "Equity:Opening Balances"),
                                           Direction.DEC, Amount(15000))
                               ])


# Generated at 2022-06-12 05:52:51.583113
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from ..commons.localization import Currency
    from .accounts import AccountType as AT, AccountCategory
    from .accounts import Accounts, AccountDef


# Generated at 2022-06-12 05:53:00.949115
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from .accounts import AccountType

    a1 = Account("A1", AccountType.EXPENSES)
    a2 = Account("A2", AccountType.EXPENSES)
    a3 = Account("A3", AccountType.REVENUES)
    a4 = Account("A4", AccountType.REVENUES)
    a5 = Account("A5", AccountType.EXPENSES)

    # Single posting:
    je = JournalEntry[None]("Description", date.today(), None).post(date.today(), a1, 1000)
    je.validate()

    # Multiple postings:
    je = JournalEntry[None]("Description", date.today(), None).post(date.today(), a1, 1000).post(date.today(), a2, -1000)
    je.validate()

    #

# Generated at 2022-06-12 05:53:12.717342
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Test for case where debits and credits are equal
    from ..accounts.accounts import AccountFactory
    from ..commons.zeitgeist import DatePeriod
    from .journal_entries import JournalEntry
    from datetime import date
    AccountFactory.set_user_defined_account_types(
        {AccountType.EXPENSES, AccountType.ASSETS, AccountType.REVENUES})
    x = JournalEntry(date.today(), "Test")
    x.post(date.today(), AccountFactory.get("X", AccountType.ASSETS), -5)
    x.post(date.today(), AccountFactory.get("Y", AccountType.REVENUES), 0)
    x.post(date.today(), AccountFactory.get("Z", AccountType.EXPENSES), 5)

# Generated at 2022-06-12 05:53:13.333517
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:53:25.243364
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from core.model import Account
    
    # test function post in class JournalEntry to find the error
    def post(self, date: datetime.date, account: Account, quantity: Quantity) -> "JournalEntry[_T]":
        """
        Posts an increment/decrement event (depending on the sign of ``quantity``) to the given account.

        If the quantity is ``0``, nothing is posted.

        :param date: Date of posting.
        :param account: Account to post the amount to.
        :param quantity: Signed-value to post to the account.
        :return: This journal entry (to be chained conveniently).
        """
        if not quantity.is_zero():
            self.postings.append(Posting(self, date, account, Direction.of(quantity), Amount(abs(quantity))))
        return self

   

# Generated at 2022-06-12 05:53:56.626661
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date

    assert issubclass(ReadJournalEntries, Protocol)



# Generated at 2022-06-12 05:53:59.019995
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j1 = JournalEntry[str]("date", "description", "source")
    j1.post("date", "account", 1)
    assert j1.postings[0].amount == 1

# Generated at 2022-06-12 05:54:07.303122
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    ## Prepare
    from datetime import date
    from gobt import Account
    from gobt.ledgers.accounts import AccountType
    
    F_Account = Account('F', AccountType.ASSETS)
    T_Account = Account('T', AccountType.ASSETS)
    assert F_Account.type == AccountType.ASSETS 
    assert T_Account.type == AccountType.ASSETS 
    
    ## Posting
    from gobt.ledgers.journal_entry import JournalEntry
    journal = JournalEntry(date(2020, 1, 1), 'journal description', 'business obj')
    ## Posting to F_Account
    F_posting_journal = journal.post(date(2020, 1, 1), F_Account, 20)
    assert F_posting_journal.postings[0].amount == 20
    assert F_

# Generated at 2022-06-12 05:54:07.927585
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    assert True

# Generated at 2022-06-12 05:54:19.540006
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..interfaces.accounts import AccountRepository
    from .accounts import AccountType
    from .taxonomy import Taxonomy
    from .taxonomy import TaxonomyRepository
    from .taxonomy import test_TaxonomyRepository_create_account

    tr = TaxonomyRepository()
    tr.create("my_taxonomy", Taxonomy("My Taxonomy"))
    t_id = tr.get_id("my_taxonomy")

    journal_entry = JournalEntry[Taxonomy](datetime.date(2020, 1, 1), "test", Taxonomy(""))

    repository: AccountRepository[Taxonomy] = AccountRepository[Taxonomy]()
    # test__JournalEntry_post_assets

# Generated at 2022-06-12 05:54:31.027774
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    je = JournalEntry[None]()
    je.post('2019-07-17', 'AccountA', Quantity(100))
    je.post('2019-07-17', 'AccountB', Quantity(100))
    assert je.postings[0].date == '2019-07-17'
    assert je.postings[0].account == 'AccountA'
    assert je.postings[0].direction == 'INC'
    assert je.postings[0].amount == Amount(100)
    assert je.postings[1].date == '2019-07-17'
    assert je.postings[1].account == 'AccountB'
    assert je.postings[1].direction == 'INC'

# Generated at 2022-06-12 05:54:41.339156
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from bookkeeper.accounts import Account, AccountType
    from bookkeeper.journal.ledgers import Ledger

    # Ledger
    ledger = Ledger()

    # Accounts
    expenses = ledger.accounts.add("Expenses", AccountType.EXPENSES, Guid("b0c7fe4a-4c8d-4b9f-b5c5-5f5c5a5d5e5e"))
    revenues = ledger.accounts.add("Revenues", AccountType.REVENUES, Guid("c0b7fe4a-4c8d-4b9f-b5c5-5f5c5a5d5e5e"))

# Generated at 2022-06-12 05:54:48.727443
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    a = Account(AccountType.ASSETS, 'Cash')
    b = Account(AccountType.LIABILITIES, 'Loan')
    c = Account(AccountType.EXPENSES, 'Fees')
    je = JournalEntry(datetime.date(2020, 7, 1), 'Test', None)
    print(je.post(datetime.date(2020, 7, 1), a, Quantity(100)))
    print(je.post(datetime.date(2020, 7, 1), b, Quantity(60)))
    print(je.post(datetime.date(2020, 7, 1), c, Quantity(40)))
    print(je.post(datetime.date(2020, 7, 1), c, Quantity(60)))
    for i in je.postings:
        print(i)



# Generated at 2022-06-12 05:54:50.996462
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class Src:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

# Generated at 2022-06-12 05:54:52.950084
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass


# Generated at 2022-06-12 05:56:05.521555
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    # Setup:
    count = 0
    _read_journal_entries = ReadJournalEntries[str]
    _read_journal_entries(DateRange(datetime.date.min, datetime.date.max)) # type: ignore

    # Cleanup 1 (of 2):
    del count

# Generated at 2022-06-12 05:56:10.838311
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    # Arrange:
    class MySource:
        pass

    @dataclass(frozen=True)
    class MyJournalEntry(JournalEntry[MySource]):
        pass

    def my_read_journal_entries(period: DateRange) -> Iterable[MyJournalEntry]:
        return [MyJournalEntry(datetime.datetime.now().date(), "Description", MySource(), [])]

    # Act:
    read_journal_entries: ReadJournalEntries[MySource] = my_read_journal_entries

    # Assert:
    journal_entries = read_journal_entries(DateRange.latest_month())
    assert len(list(journal_entries)) == 1

# Generated at 2022-06-12 05:56:11.561825
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-12 05:56:18.448697
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    period = DateRange("2016-01-01", "2016-01-10")
    account = Account("Sales")
    rje: ReadJournalEntries[_T] = lambda period: filter(lambda journal: journal.postings[0].account == account, [])
    result = rje(period)
    assert iter(result) is result
# End of test_ReadJournalEntries___call__()

# Generated at 2022-06-12 05:56:19.110887
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-12 05:56:29.329039
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import BalanceSheet, Ledger

    from .taxables import TaxableAccount
    from .taxes import TaxAccount, TaxCredit, TaxRegistry

    date = datetime.date.today()

    ledger = Ledger()
    ledger.add(TaxableAccount(name="Expense"))
    ledger.add(TaxableAccount(name="Tax"))

    taxes = TaxRegistry()
    taxes.add(TaxAccount(name="Tax", account=ledger["Tax"]), TaxCredit(ledger["Expense"]))

    with BalanceSheet.from_ledger(ledger, taxes=taxes) as balance_sheet:
        entry = JournalEntry(date, "Income")
        entry.post(date, ledger["Income"], Quantity(1))
        entry.post(date, ledger["Expense"], Quantity(1))

        balance

# Generated at 2022-06-12 05:56:40.855069
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import unittest
    from dataclasses import asdict
    from datetime import date
    from unittest.mock import Mock

    from . import accounts
    from .accounts import AccountType


# Generated at 2022-06-12 05:56:49.259814
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import NewAccount
    @dataclass
    class Test:
        pass
    test_entry = JournalEntry[Test](date = datetime.date(2020,5,15), description = "test post method")
    test_entry_with_posting = test_entry.post(date = datetime.date(2020,5,15), account = NewAccount(name = "test_account", account_type = AccountType.ASSETS, order = 2), quantity = Amount(500))
    assert test_entry_with_posting.postings[0].amount == Amount(500)


# Generated at 2022-06-12 05:56:58.471301
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry(datetime.date.today(),"TestEntry","Test")
    je.post(datetime.date.today() + datetime.timedelta(days=10), Account("Assets"), 10)
    je.post(datetime.date.today() + datetime.timedelta(days=10), Account("Expenses"), -10)
    je.post(datetime.date.today() + datetime.timedelta(days=10), Account("Revenues"), 0)
    assert len(je.postings) == 2

# Generated at 2022-06-12 05:57:07.468880
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    This function tests the functionality of the method post of the class JournalEntry.
    """
    je = JournalEntry(date=datetime.date(2020,1,1), description="Initialization", source=None)
    je.post(date=datetime.date(2020,1,1), account=Account(name="Cash",type=AccountType.ASSETS), quantity=100)
    je.post(date=datetime.date(2020,1,1), account=Account(name="Capital",type=AccountType.EQUITIES), quantity=-100)
    print(je.postings[0].is_debit)
    print(je.postings[1].is_credit)

if __name__ == "__main__":
    test_JournalEntry_post()