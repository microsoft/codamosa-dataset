

# Generated at 2022-06-12 05:48:43.959661
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType

    a1 = Account.make(AccountType.ASSETS,"a1name" )
    a1.type
    a1.code
    a1.name
    a1.description
    a1.is_balance_sheet_account
    a1.is_temporary_account
    a1.is_unrealized_account
    a1.is_legal_account
    a1.is_transfer_account
    a1.is_revaluation_account
    a1.is_reconciliation_account


    j = JournalEntry.make()
    j.date
    j.description
    j.source
    j.postings
    j.post(date=datetime.date(2019,1,1), account=a1, quantity=-1)

# Generated at 2022-06-12 05:48:52.700666
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def str_iter(i: int) -> Iterable[str]:
        for j in range(i):
            yield str(j)

    @dataclass(frozen=True)
    class Foo:
        s: str

    def read_foos(period: DateRange = None) -> Iterable[Foo]:
        for s in str_iter(4):
            yield Foo(s)

    assert list(read_foos()) == [Foo(s) for s in str_iter(4)]
    assert list(read_foos()) == list(read_foos(DateRange()))

# Generated at 2022-06-12 05:48:53.692678
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True # TODO: Implement test


# Generated at 2022-06-12 05:49:06.022259
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account, Accounts
    from .ledgers import Ledger
    from datetime import date
    import pytest

    accounts = Accounts(
        Account("Bank Account", AccountType.REVENUES),
        Account("Cash", AccountType.EXPENSES),
        Account("Goods Sold", AccountType.REVENUES),
        Account("Office Expense", AccountType.EXPENSES),
        Account("Sales Tax", AccountType.EXPENSES),
        Account("Total Revenue", AccountType.EQUITIES),
    )
    revenue_accounts = [accounts["Goods Sold"], accounts["Total Revenue"]]
    expense_accounts = [accounts["Cash"], accounts["Office Expense"], accounts["Sales Tax"]]
    ledger = Ledger(accounts)


# Generated at 2022-06-12 05:49:16.949361
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountRef
    from .currencies import CurrencyRef
    from .ledgers import LedgerRef
    from .parties import PartyRef

    ledger = LedgerRef.make("Test", "Test")
    currency = CurrencyRef.make("INR", "INR")
    party = PartyRef.make("Test", "Test")

    expense = AccountRef.make("Expense", "Expense", AccountType.EXPENSES).as_account(ledger, currency)
    equity = AccountRef.make("Equity", "Equity", AccountType.EQUITIES).as_account(ledger, currency)

    journal_entry = JournalEntry(datetime.date(2019, 7, 1), "Test", party)

    journal_entry.post(datetime.date(2019, 7, 1), expense, -100)
    journal_entry

# Generated at 2022-06-12 05:49:27.919331
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from . import exampleobjects
    from .accounts import Accounts, AccountType
    from .currencies import Currency

    accounts = Accounts()
    usd = Currency("USD")

    ## Create the source:
    source = exampleobjects.Customer("ODL", "+431234567")

    ## Create the journal entry:
    journalentry = JournalEntry(datetime.date(2019, 12, 14), "Sales Invoice", source)

    ## Post the sales invoice:

# Generated at 2022-06-12 05:49:34.996076
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    journal = JournalEntry(datetime.date.today(), "Test", None)
    # Act
    journal.post(datetime.date.today(), Account(1, "Test Account 1", AccountType.ASSETS), Quantity(100))
    journal.post(datetime.date.today(), Account(2, "Test Account 2", AccountType.REVENUES), Quantity(-100))
    # Assert
    assert journal.postings[0].account.name == "Test Account 1"
    assert journal.postings[0].amount == Amount(100)
    assert journal.postings[1].account.name == "Test Account 2"
    assert journal.postings[1].amount == Amount(100)
    assert journal.postings[1].direction == Direction.INC

# Generated at 2022-06-12 05:49:44.640776
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass, field
    from typing import Any
    from unittest import mock
    from unittest.mock import Mock, sentinel
    from ..commons.zeitgeist import DateRange
    
    @dataclass(frozen=True)
    class FakeJournalEntry:
        pass

    @dataclass(frozen=True)
    class FakeReadJournalEntries(ReadJournalEntries[Any]):
        def __call__(self, period: DateRange) -> Iterable[FakeJournalEntry]:
            pass
        
    @dataclass(frozen=True)
    class FakeJournalEntries(ReadJournalEntries[Any]):
        pass
    
    
    
    read_journal_entries = FakeReadJournalEntries()

# Generated at 2022-06-12 05:49:50.737073
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # arrange
    journal = JournalEntry(datetime.date(2020, 11, 11), "My Description", object())

    # act
    journal.post(datetime.date(2020,11,11), Account(AccountType.ASSETS, "My Account"), 100)
    journal.post(datetime.date(2020,11,11), Account(AccountType.ASSETS, "My Account"), -100)

    # assert
    assert len(journal.postings) == 2

# Generated at 2022-06-12 05:50:01.142024
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create a test class.
    @dataclass
    class TestClass:
        a: int

    # Test the method.
    test_class = TestClass(1)
    je = JournalEntry(datetime.date.today(), "test0", test_class)
    assert je.postings == []
    assert je.post(je.date, Account("Assets", AccountType.ASSETS), 1).postings[0].amount == 1
    assert je.post(je.date, Account("Expenses", AccountType.EXPENSES), -1).postings[1].amount == 1
    assert je.post(je.date, Account("Assets", AccountType.ASSETS), 0).postings[2] == je.postings[2]

# Generated at 2022-06-12 05:50:05.843346
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False, "Not implemented."

# Generated at 2022-06-12 05:50:11.927880
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime
    from dataclasses import dataclass, field
    from typing import List
    from ..commons import zeitgeist
    from ..commons.zeitgeist import DateRange

    from .accounts import Account

    @dataclass
    class JournalEntry:
        guid: str
        date: datetime.date
        description: str

        debits: List["Posting"] = field(default_factory=list)
        credits: List["Posting"] = field(default_factory=list)

    @dataclass
    class Posting:
        account: Account
        amount: int


# Generated at 2022-06-12 05:50:22.640488
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    # when
    je = JournalEntry[int](date=datetime.date.today(), description="", source=0)
    je.post(date=je.date, account=Account("123", AccountType.EXPENSES), quantity=10)
    je.post(date=je.date, account=Account("123", AccountType.EXPENSES), quantity=-10)
    je.post(date=je.date, account=Account("123", AccountType.EXPENSES), quantity=0)
    
    # then
    assert len(je.postings) == 2
    assert je.postings[0].amount == 10
    assert je.postings[0].direction == Direction.INC
    assert je.postings[1].amount == 10
    assert je.postings[1].direction == Direction.DEC

# Generated at 2022-06-12 05:50:34.115034
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType

    from .read import mock

    # Define a tuple of some postings:

# Generated at 2022-06-12 05:50:41.115570
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import Date, DateRange
    assert issubclass(ReadJournalEntries, Protocol)
    rje = ReadJournalEntries[int]
    assert isinstance(rje.__call__, FunctionType)
    assert rje.__call__.__name__ == "__call__"
    assert rje.__call__.__qualname__ == "ReadJournalEntries.__call__"
    def test_rje(self, period: DateRange) -> Iterable[JournalEntry[int]]:
        return self(period)

    assert issubclass(test_rje, ReadJournalEntries) is True

# Generated at 2022-06-12 05:50:44.946122
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class MyJournalEntries(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return []

    assert callable(MyJournalEntries())

# Generated at 2022-06-12 05:50:50.422958
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry[int](datetime.date.today(), 'Desc', 1)
    je = je.post(datetime.date.today(), Account.dummy(), 100)
    assert je.postings[0].account.code == Account.dummy().code
    assert je.postings[0].amount == Amount(100)
    assert je.postings[0].direction == Direction.INC
    assert je.postings[0].is_debit
    assert not je.postings[0].is_credit

# Generated at 2022-06-12 05:50:59.086548
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date

    class MyJournalEntry:
        def __init__(self, date, amount):
            self.date = date
            self.amount = amount

    MyJournalEntries = ReadJournalEntries[MyJournalEntry]

    def read(period: DateRange) -> List[MyJournalEntry]:
        return [MyJournalEntry(date(2017, 1, 1), Amount(100)),
                MyJournalEntry(date(2017, 1, 2), Amount(200)),
                MyJournalEntry(date(2017, 1, 3), Amount(300))]

    read_journal_entries: MyJournalEntries = read
    assert len(list(read_journal_entries(DateRange.from_start_end(date(2017, 1, 1), date(2017, 1, 3))))) == 3

# Generated at 2022-06-12 05:51:06.099880
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class Account:
        def __init__(self, name, type):
            self.name = name
            self.type = type

    from datetime import date
    from typing import Tuple
    from dataclasses import dataclass
    from ..commons.numbers import Amount

    @dataclass(frozen=True)
    class Source:
        date: date
        description: str
        amount: Amount


    def make_journal_entry(date, description, amount, account):
        source = Source(date, description, amount)
        entry = JournalEntry[Source](date, description, source)
        entry.post(date, account, amount)
        return entry

    creditor_account = Account("Creditor Account", AccountType.LIABILITIES)
    debtor_account = Account("Debtor Account", AccountType.ASSETS)

   

# Generated at 2022-06-12 05:51:16.991676
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(date=datetime.date(2013, 12, 31), description="test", source=None)

    j.post(date=datetime.date(2013, 12, 31), account=Account(name="test1", type=AccountType.ASSETS), quantity=Amount(-100))
    j.post(date=datetime.date(2013, 12, 31), account=Account(name="test2", type=AccountType.EXPENSES), quantity=Amount(-50))
    j.post(date=datetime.date(2013, 12, 31), account=Account(name="test3", type=AccountType.EQUITIES), quantity=Amount(100))


# Generated at 2022-06-12 05:51:34.734251
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Creating test account
    account = Account(code='Test', name='Test Account', type=AccountType.EQUITIES, is_balance_sheet_account=True)
    # Creating test journal entry
    test_journal_entry = JournalEntry(
        date=datetime.date.today(),
        description='test transaction',
        source='test'
    )
    # Posting three times
    test_journal_entry.post(datetime.date.today(), account, Quantity(100))
    test_journal_entry.post(datetime.date.today(), account, Quantity(200))
    test_journal_entry.post(datetime.date.today(), account, Quantity(300))
    # Checks the postings list length is still 3
    assert len(test_journal_entry.postings) == 3
    # Checks the sum of the posted values is 600

# Generated at 2022-06-12 05:51:43.674089
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from mock import Mock
    from src.domain.entities.accounts import Account
    from src.domain.entities.numbers import Amount, Quantity
    from tests.src.domain.entities.accounts import mock_account

    je: JournalEntry = JournalEntry(datetime.date(2018, 1, 1), "test", Mock())

    acc1: Account = mock_account("ASSETS", "BANK", "B1", "USD")
    acc2: Account = mock_account("EXPENSES", "SALARIES", "S1", "USD")
    acc3: Account = mock_account("LIABILITIES", "LOAN", "L1", "USD")

    q1: Quantity = Quantity(100)
    q2: Quantity = Amount(-100)


# Generated at 2022-06-12 05:51:44.315588
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

# Generated at 2022-06-12 05:51:53.596211
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Valid journal:
    JournalEntry[int](datetime.datetime.now().date(), "Description", 1, [Posting(2,  datetime.datetime.now().date(), Account("Assets/Bank"), Direction.INC, Amount(100.0)), Posting(2,  datetime.datetime.now().date(), Account("Expenses/Books"), Direction.DEC, Amount(100.0))]).validate()

    # Invalid journal:

# Generated at 2022-06-12 05:52:04.623352
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class MockedJournalEntry(JournalEntry[str]):
        def __init__(self, date: datetime.date, description: str, source: str):
            super().__init__(date, description, source)

    def mock_read(period: DateRange) -> Iterable[JournalEntry[str]]:
        return [MockedJournalEntry(datetime.date(2020, 1, 1), "Desc", "Source")]

    assert isinstance(mock_read, ReadJournalEntries)
    assert isinstance(mock_read(DateRange()), Iterable)
    assert isinstance(next(mock_read(DateRange())), JournalEntry)
    assert isinstance(next(mock_read(DateRange())), MockedJournalEntry)


# Generated at 2022-06-12 05:52:16.502637
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import json

    from .accounts import AccountService
    from .accounts.read import ReadAccounts
    from .accounts.read import ReadAccountsFrom

    from .book import Book, BookService
    from .book.read import ReadBooks
    from .book.read import ReadBooksFrom

    from .ledgers import LedgerService
    from .ledgers.read import ReadLedgers
    from .ledgers.read import ReadLedgersFrom

    from .entries.read import ReadJournalEntries
    from .entries.read import ReadJournalEntriesFrom

    # Services:
    ## Account Service:
    accounts_file = "./tests/sample/accounts.json"
    with open(accounts_file, "r") as fp:
        accounts = json.load(fp)

# Generated at 2022-06-12 05:52:28.003292
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from accounting.accounts import Account
    from accounting.commons.zeitgeist import DateRange
    from accounting.journal.readjournalentries import read_journal_entries

    from .cash import Cash  # type: ignore
    from .equipment import Equipment  # type: ignore
    from .expense import Expense  # type: ignore
    from .income import Income  # type: ignore
    from .payment import Payment  # type: ignore
    from .receipt import Receipt  # type: ignore
    from .utilities import Comparable
    from .__init__ import main_books, main_cash, main_equipment


# Generated at 2022-06-12 05:52:38.118648
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from .accounts import Account, AccountType
    from .journals import JournalEntry as JE, Direction
    from .commons.others import Guid
    from .commons.numbers import Amount,Quantity
    from .commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    #Income = Account("Income", "Income", AccountType.REVENUES)
    Expense = Account("Expense", "Expense", AccountType.EXPENSES)
    Test = Account("Test", "Test", AccountType.EQUITIES)
    date = datetime.date(2020, 3, 27)
    date1 = datetime.date(2020, 3, 27)
    journal = JE(date, "description", "source")

# Generated at 2022-06-12 05:52:45.680953
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import Account, AccountType, EquityAccount, RevenueAccount, ExpenseAccount, AssetAccount
    from .commons.numbers import Amount
    from .commons.zeitgeist import DateRange

    def def_ReadJournalEntries_E(period):
        yield JournalEntry[None](date(2018, 1, 13),
            "Accounts Receivable Card",
            None,
            []) \
            .post(date(2018, 1, 13),
                Account(AccountType.ASSETS, "Accounts Receivable Card"),
                Amount(11)) \
            .post(date(2018, 1, 13),
                Account(AccountType.REVENUES, "Sales"),
                Amount(11))

# Generated at 2022-06-12 05:52:54.337426
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from bookkeeper.resources import AccountType
    from bookkeeper.resources import Account
    from bookkeeper.resources import Posting
    from copy import copy

    # Test data
    # create a source 
    source = "source"
    # create two accounts
    account_1 = Account("name_1", AccountType.ASSETS)
    account_2 = Account("name_2", AccountType.REVENUES)
    # create a journal entry
    journal_entry = JournalEntry(date.today(), "description", source)
    # create a posting with account 1
    posting_a_1 = Posting(journal_entry, date.today(), account_1, Direction.INC, Amount(10))
    # add the posting to the journal entry
    journal_entry.postings.append(posting_a_1)

    #

# Generated at 2022-06-12 05:53:15.676218
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """tests adding a Posting to a Journal Entry"""
    date = datetime.date.today()
    account = Account(name="testaccount", type=AccountType.ASSETS)
    quantity = Quantity(10)
    entry = JournalEntry(date, "Test Description", "Test")
    entry.post(date, account, quantity)
    assert entry.postings[0].date == date
    assert entry.postings[0].account == account
    assert entry.postings[0].direction == Direction.INC
    assert entry.postings[0].amount == Quantity(10)
    assert entry.postings[0].is_debit
    assert not entry.postings[0].is_credit

# Generated at 2022-06-12 05:53:26.851162
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .factories import make_journal_entry
    from .ledgers import Ledger
    from datetime import date

    # Arrange.
    ledger = Ledger.empty
    date_range = DateRange(date(2020, 5, 1), date(2020, 5, 31))

    journal_entry = make_journal_entry(
        date=date(2020, 5, 20),
        description="Foo",
        source=None,
        postings=(
            (ledger.root, 1),
            (ledger.root, -1),
        ),
    )

    ledger.add_journal_entry(journal_entry)

    # System under test.
    read_journal_entries = ledger.read_journal_entries

    # Act
    journal_entries = read_journal_entries(period=date_range)

    #

# Generated at 2022-06-12 05:53:38.222834
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(datetime.date.today(), "", "")
    journal.post(journal.date, Account("100301", AccountType.ASSETS), +100)
    journal.post(journal.date, Account("100401", AccountType.EQUITIES), +100)
    journal.post(journal.date, Account("100501", AccountType.LIABILITIES), -200)
    journal.post(journal.date, Account("300101", AccountType.REVENUES), -200)
    journal.post(journal.date, Account("400101", AccountType.EXPENSES), +200)
    assert len(journal.postings) == 4
    assert len(journal.increments) == 3
    assert len(journal.debits) == 3
    assert len(journal.decrements) == 1

# Generated at 2022-06-12 05:53:48.502484
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .articles import Article
    from .globals import GLOBAL
    from .ledgers import Ledger, LedgerType
    from .services import make_account_service, make_journal_entry_service, make_ledger_service

    journal = JournalEntry(date=datetime.date(2020, 5, 1), description="SELL 10 ABC @ $10")
    journal.post(date=journal.date, account=GLOBAL.accounts.get_account(name="Current Assets", type=AccountType.ASSETS), quantity=2)
    journal.post(date=journal.date, account=GLOBAL.accounts.get_account(name="Cash", type=AccountType.ASSETS), quantity=-2)

# Generated at 2022-06-12 05:53:54.524882
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class TestClass:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[int]]:
            pass

    tc = TestClass()
    ReadJournalEntries.__getitem__(TestClass, JournalEntry[int])(tc, DateRange(datetime.date(1, 1, 1), datetime.date(1, 1, 1)))

# Generated at 2022-06-12 05:54:04.028444
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .generics import create_some_account
    from .converters import to_amount
    from .commons.numbers import Quantity
    account1 = create_some_account(Account(AccountType.ASSETS, "Assets"))
    account2 = create_some_account(Account(AccountType.EXPENSES, "Expenses"))
    data = [(datetime.datetime(year=2020, month=10, day=1), account1, Quantity(1)), (datetime.datetime(year=2020, month=10, day=1), account2, Quantity(-1))]
    journal = JournalEntry(source=datetime.datetime(year=2020, month=10, day=1), description="description")

# Generated at 2022-06-12 05:54:11.204597
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import datetime
    from decimal import Decimal as D
    from ..books.accounts import Account, AccountType

    # Setup
    accounts = {
        "Assets:Bank:Checking": Account("Assets:Bank:Checking", AccountType.ASSETS),
        "Expenses:Food:Restaurant": Account("Expenses:Food:Restaurant", AccountType.EXPENSES),
        "Liabilities:Credit Card": Account("Liabilities:Credit Card", AccountType.LIABILITIES)
    }
    entry = JournalEntry[object](
        datetime.date(2020, 1, 1), "Lunch meal", None,
    )
    entry.post(datetime.date(2020, 1, 1), accounts['Assets:Bank:Checking'], -D('1000'))

# Generated at 2022-06-12 05:54:19.458895
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class TestSource:
        pass

    def test_case() -> None:
        journal = JournalEntry[TestSource](datetime.date(2020, 12, 30), "Test journal entry", TestSource())
        journal.post(journal.date, Account("Assets", "Cash", AccountType.ASSETS), +500)
        journal.post(journal.date, Account("Revenues", "Sales", AccountType.REVENUES), -500)
        print(journal)

    test_case()

# Generated at 2022-06-12 05:54:30.953059
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from django.db.models import Count

    e = se.JournalEntry(date=datetime.date(2020, 1, 29))
    e.post(
        date=datetime.date(2020, 1, 29),
        account=Account(
            id=32, type=AccountType.ASSETS, code="1121", title="Cash in hand", parent_id=None
        ),
        quantity=980000,
    )
    e.post(
        date=datetime.date(2020, 1, 29),
        account=Account(
            id=20, type=AccountType.LIABILITIES, code="2000", title="Accounts payable", parent_id=None
        ),
        quantity=-970000,
    )

# Generated at 2022-06-12 05:54:41.299967
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry("test", "corona")
    journal.post("date", "revenue", 10)
    journal.post("date", "revenue2", -25)
    journal.post("date", "expense", 23)
    journal.post("date", "revenue", -10)
    
    assert len(journal.debits) == 3
    assert next(iter(journal.debits)).amount == 10
    assert next(iter(journal.debits)).amount == 25
    assert next(iter(journal.debits)).amount == 23
    
    assert len(journal.credits) == 2
    assert next(iter(journal.credits)).amount == 10
    assert next(iter(journal.credits)).amount == 23

    assert len(journal.increments) == 3
    assert next(iter(journal.increments)).amount

# Generated at 2022-06-12 05:55:15.510385
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

# Generated at 2022-06-12 05:55:25.436297
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .values import Value

    # Arrange:
    ledger = Ledger("Demo Ledger 1")
    c_phone = ledger.add(Account("Telephone Expense", AccountType.EXPENSES))
    c_salary = ledger.add(Account("Salary Expense", AccountType.EXPENSES))
    c_equity = ledger.add(Account("Equity", AccountType.EQUITIES))
    c_assets = ledger.add(Account("Assets", AccountType.ASSETS))
    c_liab = ledger.add(Account("Liabilities", AccountType.LIABILITIES))

    # Act:
    read_journal_entries = ledger.journal

    # Arrange:

# Generated at 2022-06-12 05:55:26.945520
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def f():
        pass

    assert isinstance(f, ReadJournalEntries)

# Generated at 2022-06-12 05:55:29.996287
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class T:
        pass

    t = T()
    je = JournalEntry[T]()
    je.post(date, account, quantity)

# Generated at 2022-06-12 05:55:37.121498
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    #prepare
    acc_1 = Account("1", "acc_1", AccountType.ASSETS, "Assets")
    acc_2 = Account("2", "acc_2", AccountType.EQUITIES, "Equities")
    acc_3 = Account("3", "acc_3", AccountType.EXPENSES, "Expenses")
    acc_4 = Account("4", "acc_4", AccountType.REVENUES, "Revenues")

    entry = JournalEntry(date=datetime.date.today(), description="Test entry", source=None)
    entry.post(date=datetime.date.today(), account=acc_1, quantity=100)
    entry.post(date=datetime.date.today(), account=acc_2, quantity=-100)

    #act
    entry.validate()

# Generated at 2022-06-12 05:55:39.785691
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    T = TypeVar("T")
    class Foo:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[T]]:
            pass
    Foo()

# Generated at 2022-06-12 05:55:46.607062
# Unit test for method __call__ of class ReadJournalEntries

# Generated at 2022-06-12 05:55:47.215454
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:55:57.280825
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType as T, AccountGroup as G
    from datetime import date
    from fractions import Fraction as Q

    Asset = T.ASSETS
    Revenue = T.REVENUES
    Expense = T.EXPENSES

    Cash = G.CASH
    Inventory = G.INVENTORY
    Sales = G.SALES
    CostOfSales = G.COST_OF_SALES

    Cash_Account = Account(Cash, Asset, "Cash")
    Inventory_Account = Account(Inventory, Asset, "Inventory")
    Sales_Account = Account(Sales, Revenue, "Sales")
    CostOfSales_Account = Account(CostOfSales, Expense, "CostOfSales")

    journal = JournalEntry(date(2019,1,1),"1st Jan 2019")

# Generated at 2022-06-12 05:56:07.900684
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry("test")
    je.post("account1", "2020-10-10", 500)
    je.post("account1", "2020-10-10", -250)
    je.post("account2", "2020-10-10", 50)
    je.post("account2", "2020-10-10", -50)
    je.post("account3", "2020-10-10", -250)
    je.post("account3", "2020-10-10", 500)
    assert(len(je.postings) == 6)
    assert(je.postings[0] == Posting(je, "2020-10-10", "account1", +1, 500))
    assert(je.postings[1] == Posting(je, "2020-10-10", "account1", -1, 250))

# Generated at 2022-06-12 05:57:26.297998
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class JournalEntriesSource:
        def fetch(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            entries = (
                JournalEntry[JournalEntriesSource](date=datetime.date(2020, 2, 10), description='Sales', source=self),
                JournalEntry[JournalEntriesSource](date=datetime.date(2020, 2, 11), description='Purchase', source=self),
            )
            for entry in entries:
                entry.post(account=Account('Cash'), quantity=100)
            return entries

    source = JournalEntriesSource()
    read = ReadJournalEntries.__getitem__(JournalEntriesSource)
    date_range = DateRange(start=datetime.date(2020, 2, 1), end=datetime.date(2020, 2, 29))

# Generated at 2022-06-12 05:57:37.515247
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Tests method validate of class JournalEntry
    """
    from ..commons.numbers import isum
    from .accounts import Expense, Liability
    from .accounts import Income, Asset

    account1 = Asset("Account1")
    account2 = Liability("Account2")
    account3 = Income("Account3")
    account4 = Expense("Account4")

    date = datetime.date(2020, 1, 1)

    journal = JournalEntry(date, "Test", None)

    journal.post(date, account1, 100)
    journal.post(date, account2, -100)

    journal.post(date, account3, -100)
    journal.post(date, account4, 100)

    journal.validate()

    assert isinstance(journal.date, datetime.date)

# Generated at 2022-06-12 05:57:44.287929
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    def _assert(source: int, expected: str):
        je = JournalEntry[int](datetime.date.today(), "Test journal entry", source)
        je.post(datetime.date.today(), Account("Assets", AccountType.ASSETS), Amount(source))
        assert repr(je) == expected

    _assert(100, f"100 @ {Account('Assets', AccountType.ASSETS)}")
    _assert(-100, f"-100 @ {Account('Assets', AccountType.ASSETS)}")

# Generated at 2022-06-12 05:57:50.269114
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class JournalEntriesReader(ReadJournalEntries[_T]):
        def __init__(self):
            pass

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    #
    # Test:
    #
    j = JournalEntriesReader()
    assert isinstance(j, ReadJournalEntries[_T])

# Generated at 2022-06-12 05:57:58.683555
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    journal_entry = JournalEntry(
        date = datetime.date(2020, 9, 8),
        description = "Expense of 1000 INR on software development.",
        source = "Software Development",
        postings = [
            Posting(journal_entry, datetime.date(2020, 9, 8), Account.of(AccountType.EXPENSES, "COGS"), Direction.INC, Amount(1000)),
            Posting(journal_entry, datetime.date(2020, 9, 8), Account.of(AccountType.EQUITIES, "Retained Earnings"), Direction.DEC, Amount(1000))
        ]
    )

    journal_entry.validate()

# Generated at 2022-06-12 05:58:08.903085
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from unittest import TestCase, mock
    from .accounts import AccountType
    from .ledgers import GLAccounts
    from .ledgers import GLJournalEntries

    # build test case
    class _T(TestCase):
        def test_GLAccounts___call__(self):
            # setup mock
            gl_accounts = mock.Mock(GLAccounts)
            gl_accounts.__iter__.return_value = [
                mock.MagicMock(Account, account='account', type=AccountType.ASSETS),
                mock.MagicMock(Account, account='account', type=AccountType.REVENUES),
            ]

            # test
            self.assertIsInstance(gl_accounts(), Iterable)
            self.assertIsInstance(gl_accounts()[0], Account)
            self.assertIsInstance

# Generated at 2022-06-12 05:58:10.976263
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Function which can be used as a test for unit testing
    """
    assert True


# Generated at 2022-06-12 05:58:13.949019
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import now

    read_journal_entries: ReadJournalEntries[str] = lambda _: []
    assert list(read_journal_entries(DateRange(now(), now()))) == []

# Generated at 2022-06-12 05:58:20.037880
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    sourceObject = 1
    sourceType = 'TestSource'
    account = Account(sourceType, sourceObject, 'Test Account')
    je = JournalEntry[1](datetime.date(2020, 1, 1), 'Test Journal Entry', 1)
    je.post(datetime.date(2020, 1, 1), account, 1)
    assert len(je.postings) == 1
    assert je.postings[0].direction == Direction.INC


# Generated at 2022-06-12 05:58:23.609490
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import AccountType

    ## Create an instance of read journal entries function:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        return [
            JournalEntry(date(2020, 1, 1), "Journal Entry 1", None, []).post(date(2020, 1, 1), Account("A1", AccountType.ASSETS, "Account 1"), -5),
            JournalEntry(date(2020, 1, 1), "Journal Entry 2", None, []).post(date(2020, 1, 1), Account("A1", AccountType.ASSETS, "Account 1"), +7).post(date(2020, 1, 1), Account("A2", AccountType.ASSETS, "Account 2"), -7),
        ]
