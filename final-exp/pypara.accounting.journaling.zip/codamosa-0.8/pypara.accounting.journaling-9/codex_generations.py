

# Generated at 2022-06-12 05:48:33.846533
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Setup:
    journa1 = JournalEntry('2019-01-01', 'testing', 'test')
    journa1.post(datetime.date(2019, 1, 1), Account('asset'), Amount(100))
    journa1.post(datetime.date(2019, 1, 1), Account('equity'), Amount(100))
    # Exercise & Verify:
    assert True == journa1.validate()

# Generated at 2022-06-12 05:48:41.194118
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account = Account()
    account.name = "foobar"
    source = "foobar"
    journal = JournalEntry[str](datetime.date.today(), "foobar", source)
    journal.post(datetime.date.today(), account, 6)
    journal.post(datetime.date.today(), account, 9)
    assert (journal.postings[0].amount == Amount(6))
    assert (journal.postings[1].amount == Amount(9))


# Generated at 2022-06-12 05:48:49.475857
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    class CreateJournalEntries(ReadJournalEntries[None]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[None]]:
            assert period == DateRange.between(
                datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    CreateJournalEntries()(DateRange.between(
        datetime.date(2018, 1, 1), datetime.date(2018, 12, 31)))

# Generated at 2022-06-12 05:48:50.136605
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:48:56.550800
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange:
    #          Balance Sheet           |        Income Statement
    #            Assets    Liabilities |       Revenues    Expenses
    #    ---------------------------  |   ----------------------------
    #     Bank (Dr)        1000        |     Income (Cr)        1000
    #     Cash (Dr)        1000        |     Expense (Dr)         200
    #     Retained Earning (Cr)        |     Shareholder's Equity (Cr)
    #                                  |                             800
    account_bank = Account(1, AccountType.ASSETS, "Bank")
    account_cash = Account(2, AccountType.ASSETS, "Cash")
    account_re = Account(3, AccountType.EQUITIES, "Retained Earning")
    account_income = Account(4, AccountType.REVENUES, "Income")
    account_

# Generated at 2022-06-12 05:49:08.354677
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Tests method validate of class JournalEntry.
    """
    ## Create journal entries:
    journal1 = JournalEntry(datetime.date(2020, 5, 1), "Description1", "Source1")
    journal1.post(datetime.date(2020, 5, 1), Account("Account1", AccountType.ASSETS), 100.0)
    journal1.post(datetime.date(2020, 5, 1), Account("Account2", AccountType.REVENUES), 100.0)

    journal2 = JournalEntry(datetime.date(2020, 5, 1), "Description2", "Source2")
    journal2.post(datetime.date(2020, 5, 1), Account("Account1", AccountType.ASSETS), 100.0)

# Generated at 2022-06-12 05:49:18.978240
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert (
        issubclass(
            ReadJournalEntries,
            type,
        )
    ), "Cannot use `issubclass` with `ReadJournalEntries` because it is not a type."
    assert (
        (
            ReadJournalEntries.__call__ is type.__call__
        ) is False
    ), "Cannot use `ReadJournalEntries.__call__ is type.__call__` because `ReadJournalEntries.__call__ is not a method."
    assert (
        (type(
            ReadJournalEntries.__call__
        ) is type) is True
    ), "Cannot use `type(ReadJournalEntries.__call__) is type` because `ReadJournalEntries.__call__ is not a method."

# Generated at 2022-06-12 05:49:29.546180
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class Foo:
        pass

    @dataclass(frozen=True)
    class Bar:
        pass

    bar1 = Bar()
    bar2 = Bar()

    foo = Foo()

    assert isinstance(Foo, ReadJournalEntries)  # type: ignore
    assert isinstance(foo, ReadJournalEntries)  # type: ignore
    assert not isinstance(Bar, ReadJournalEntries)  # type: ignore
    assert not isinstance(bar1, ReadJournalEntries)  # type: ignore
    assert not isinstance(bar2, ReadJournalEntries)  # type: ignore
    assert callable(Foo)
    assert callable(foo)
    assert not callable(Bar)
    assert not callable(bar1)

# Generated at 2022-06-12 05:49:36.456826
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import TimeFence
    @dataclass(frozen=True)
    class MyTestType:
        start: datetime.date
        end: datetime.date
        value: str
    @dataclass(frozen=True)
    class MyTestJournalEntry(JournalEntry[MyTestType]):
        def validate(self) -> None:
            pass

# Generated at 2022-06-12 05:49:46.260666
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.numbers import EUR
    from .accounts import Fund

    j1 = JournalEntry[Fund].from_postings(
        datetime.date(2018, 8, 25),
        "From Budget To Fund",
        Fund("Test Fund"),
        [
            Posting(None, datetime.date(2018, 8, 25), Account("Fund", AccountType.ASSETS), Direction.INC, EUR(100)),
            Posting(None, datetime.date(2018, 8, 25), Account("Budget", AccountType.EQUITIES), Direction.DEC, EUR(100)),
        ],
    )

    j1.validate()


# Generated at 2022-06-12 05:49:52.315600
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass



# Generated at 2022-06-12 05:50:04.509352
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from io import StringIO
    from datetime import date
    from unittest import TestCase
    from unittest.mock import MagicMock
    from ..commons.zeitgeist import DateRange

    class MockJournalEntry(JournalEntry):
        def validate(self):
            pass

    class MockAccount:
        type = AccountType.ASSETS

    readjournalentries = MagicMock(spec=ReadJournalEntries)
    ReadJournalEntries.__call__(readjournalentries, DateRange(date(2012, 1, 1), date(2020, 1, 1)))
    readjournalentries.assert_called_once_with(DateRange(date(2012, 1, 1), date(2020, 1, 1)))

    # check that iterator has sufficient typing information to check the type of its elements
    readjournalentries.reset_mock()

# Generated at 2022-06-12 05:50:15.943410
# Unit test for method __call__ of class ReadJournalEntries

# Generated at 2022-06-12 05:50:21.681632
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    date=datetime.date(2020, 2, 17)
    account1=Account(1,'assets','Assets','Current Assets','Cash','Cash')
    account2=Account(2,'revenue','Revenue','Sales Revenue','Sales Revenue','Sales Revenue')
    je=JournalEntry[None](date,'Cash Sale for stock',None)
    je.post(date,account1,100)
    je.post(date,account2,100)
    je.validate()

# Generated at 2022-06-12 05:50:32.105168
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        for date in range(period.start.value, period.end.value + 1):
            yield JournalEntry(datetime.date.fromordinal(date), "", None)

    december_2019 = DateRange(
        datetime.date(2019, 12, 1), datetime.date(2019, 12, 31)
    )
    entries = list(read_journal_entries(december_2019))
    assert len(entries) == 31
    assert entries[0].date == datetime.date(2019, 12, 1)
    assert entries[-1].date == datetime.date(2019, 12, 31)

# Generated at 2022-06-12 05:50:37.724294
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account_1 = Account("account_1", AccountType.ASSETS)
    account_2 = Account("account_2", AccountType.EQUITIES)
    journal_entry = JournalEntry("date", "description", "source")
    journal_entry.post("date", account_1, 100)
    journal_entry.post("date", account_2, -100)
    journal_entry.validate()

# Generated at 2022-06-12 05:50:47.456870
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def mock_reader(period: DateRange) -> Iterable[JournalEntry[None]]:
        return (
            JournalEntry(datetime.date(2000, 1, 1), "jv1", None),
            JournalEntry(datetime.date(2000, 1, 2), "jv2", None),
            JournalEntry(datetime.date(2000, 1, 3), "jv3", None),
        )

    def read(read_function: ReadJournalEntries[_T]) -> Iterable[JournalEntry[_T]]:
        return read_function(DateRange(None, None))

    assert read(mock_reader)

# Generated at 2022-06-12 05:50:57.467409
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account
    from .books import Book
    from .records import Record

    @dataclass(frozen=True)
    class B(Book):
        read: ReadJournalEntries[_T]

    @dataclass(frozen=True)
    class R(Record):
        book = B()

        def checking_balance(self) -> Amount:
            return self.book.checking_balance()

    @dataclass(frozen=True)
    class Saving(Account):
        def check(self, amount: Amount) -> None:
            assert self.type == AccountType.ASSETS, "This account cannot be used to receive debits."
            self.balance += amount


# Generated at 2022-06-12 05:50:59.620672
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Arrange

    # Action and Assert
    pass


# Generated at 2022-06-12 05:51:07.950742
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .articles import Article
    from .accounts import Account

    # Create the source article
    source = Article(code="test", name="test_article")
    # Create the accounts
    s_account = Account(code="test", name="test_account", type=AccountType.ASSETS)
    p_account = Account(code="test", name="test_account", type=AccountType.REVENUES)

    # Create the journal entry
    journal_entry = JournalEntry(date=datetime.date.today(), description="test_description")
    journal_entry.post(date=datetime.date.today(), account=s_account, quantity=100)
    journal_entry.post(date=datetime.date.today(), account=p_account, quantity=-100)

    # Validate the journal entry
    journal_entry.validate()

# Generated at 2022-06-12 05:51:24.362641
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.accounts import Account, AccountType
    from ..books.journal import JournalEntry, Posting

    #: Create a journal entry
    je = JournalEntry(datetime.date(2020, 2, 15), "Test", "Test", Posting)
    #: Add some random postings with the API method post()
    je.post(datetime.date(2020, 2, 15), Account("Test", AccountType.ASSETS), 100).post(
        datetime.date(2020, 2, 15), Account("Test", AccountType.EXPENSES), -100)
    je.post(datetime.date(2020, 2, 15), Account("Test", AccountType.LIABILITIES), -50).post(
        datetime.date(2020, 2, 15), Account("Test", AccountType.REVENUES), 50)
    #: Validate the journal

# Generated at 2022-06-12 05:51:35.659471
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Unit test for method post of class JournalEntry
    """
    from .accounts import Account, AccountType
    from .ledgers import Ledger, PostingReads
    from .books import Book, BookReads
    account1 = Account("1", AccountType.ASSETS)
    account2 = Account("2", AccountType.REVENUES)
    journal1 = JournalEntry(datetime.datetime.now().date(), "Journal Entry 1", object())
    journal1.post(datetime.datetime.now().date(), account1, 50)
    journal1.post(datetime.datetime.now().date(), account1, -10)
    journal1.post(datetime.datetime.now().date(), account2, 40)

# Generated at 2022-06-12 05:51:37.554200
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    fd = ReadJournalEntries()
    fd.__call__(DateRange())


# Generated at 2022-06-12 05:51:42.533146
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType

    # Define accounts:
    assets = Account(AccountType.ASSETS, "Assets")
    expenses = Account(AccountType.EXPENSES, "Expenses")

    # Create journal entry:
    journal = JournalEntry("Checking Account", assets.balance(1).post(1))
    journal.post(expenses, -1)

    # Validate the journal entry:
    journal.validate()

# Generated at 2022-06-12 05:51:43.962174
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False, "TODO: Implement!"

# Generated at 2022-06-12 05:51:44.615620
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True == True

# Generated at 2022-06-12 05:51:53.771207
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..accounts import Account, AccountName, AccountType

    # Setup:
    asset = Account(AccountType.ASSETS, AccountName.CASH_AT_BANK)
    revenue = Account(AccountType.REVENUES, AccountName.FEES_EARNED)
    expense = Account(AccountType.EXPENSES, AccountName.TRADE_PAYABLES)

    # Exercise:

# Generated at 2022-06-12 05:52:05.512817
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import field
    from datetime import date
    from typing import Dict, Iterable, Optional, TypeVar
    from .accounts import Account, AccountType
    from .books import Money, Book
    from .ledgers import Ledger
    from .unitsofmeasurement import UnitOfMeasurement
    from .valuation import Valuation

    class Item:
        """
        Dummy item model class.
        """

        def __init__(self, name: str, book: Book) -> None:
            """
            Initializes an instance of ``Item``.
            """
            self.name = name
            self.book = book

    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class _JournalEntry:
        """
        Dummy journal entry model class.
        """

       

# Generated at 2022-06-12 05:52:10.704322
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    JE = JournalEntry
    JE._validate
    def test_JournalEntry_post():
        journal_entries = [JE(0,0,0)]
        expectations = [2, 3]
        for journal_entry in journal_entries:
            journal_entry.post(0,0,2)
        for i in range(len(journal_entries)):
            assert journal_entries[i].postings[0] == expectations[i]
        #assert journal_entries[0].postings[0].amount == 2
        #assert journal_entries[1].postings[0].amount == 3

test_JournalEntry_post()

# Generated at 2022-06-12 05:52:12.234488
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def f():
        pass
    assert isinstance(f, ReadJournalEntries)

# Generated at 2022-06-12 05:52:41.039037
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.accounts import Account, AccountType
    from ..commons.numbers import Amount, Quantity
    from .instruments import Instrument

    import datetime
    import random

    # Create accounts
    account_liability = Account(AccountType.LIABILITIES, "Liability")
    account_revenue = Account(AccountType.REVENUES, "Revenue")
    account_expense = Account(AccountType.EXPENSES, "Expense")
    account_equity = Account(AccountType.EQUITIES, "Equity")

    # Create instruments (creates instruments.json file)
    instrument_cash = Instrument("Cash")
    instrument_vix = Instrument("VIX")
    instrument_spy = Instrument("SPY")

    ORDER_VALUE = 12345

    # Create entry1

# Generated at 2022-06-12 05:52:50.679246
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j=JournalEntry(date=datetime.date(2000,1,1),description="test")
    j.post(date=datetime.date(2000,1,1),account=Account("te","asset"),quantity=1)
    j.post(date=datetime.date(2000,1,1),account=Account("te","asset"),quantity=-1)
    try:
        j.validate()
    except:
        assert False
    j.post(date=datetime.date(2000,1,1),account=Account("te","asset"),quantity=-1)
    try:
        j.validate()
        assert False
    except:
        assert True

# Generated at 2022-06-12 05:53:00.499897
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Accounts

    from .instruments import Instrument

    from .markets import Marketer, Market, MarketRole, Trader, TraderRole
    from .markets import TraderEvent, TraderEventType

    marker = Marketer("Marketer")
    product = Instrument("Product")
    market = Market("Market")
    trader = Trader("Trader")
    participant = Trader("Participant")

    trader_join = TraderEvent(TraderEventType.JOIN, market.id, trader.id, trader.name, TraderRole.BUYER)
    participant_join = TraderEvent(TraderEventType.JOIN, market.id, participant.id, participant.name, TraderRole.BUYER)
    marker.add_trader(trader_join)
    marker.add_trader(participant_join)

    market.register_

# Generated at 2022-06-12 05:53:09.612615
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    x = JournalEntry("Asset", "Account", "2019-01-15", "Equity")
    x.post("2019-01-15", "Account", 10)
    assert x.postings == [("2019-01-15", "Account", 10)]

    y = JournalEntry("Revenue", "Account", "2019-01-15", "Equity")
    y.post("2019-01-15", "Account", -20)
    assert y.postings == [("2019-01-15", "Account", -20)]

# Generated at 2022-06-12 05:53:11.327105
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False, "Not implemented"

# Generated at 2022-06-12 05:53:21.596613
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Test method post of class JournalEntry.
    """
    from .accounts import Account, AccountType
    from .accounts import Accounts
    account = Account("Assets", AccountType.ASSETS)
    accounts = {account.name: account}
    accounts = Accounts(accounts)
    journal = JournalEntry(datetime.date(2020, 12, 18), "Test Post", accounts)
    journal.post(datetime.date(2020, 12, 18), account, -100)
    assert journal.postings[0].account.name == "Assets"
    assert journal.postings[0].direction == Direction.DEC
    assert journal.postings[0].amount == 100


# Generated at 2022-06-12 05:53:29.238004
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    credit_account = Account(0, 'credit', AccountType.EQUITIES)
    debit_account = Account(0, 'debit', AccountType.ASSETS)
    credit_posting = Posting(JournalEntry(datetime.date(2018, 1, 1), 'credit', 'credit'), datetime.date(2018, 1, 1),
        credit_account, Direction.INC, Amount(10))
    debit_posting = Posting(JournalEntry(datetime.date(2018, 1, 1), 'debit', 'debit'), datetime.date(2018, 1, 1),
        debit_account, Direction.INC, Amount(10))

    journal_entry = JournalEntry(datetime.date(2018, 1, 1), 'test_journal', 'test_journal')

# Generated at 2022-06-12 05:53:34.119905
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry[str]("2019-02-12", "desc", "src")
    assert j.postings == []
    j.post("2019-02-12", Account("assets", AccountType.ASSETS), -1)
    assert j.postings[0].direction == Direction.DEC
    assert j.postings[0].amount.value == 1

# Generated at 2022-06-12 05:53:38.077725
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry(datetime.date(2019, 1, 1), "Test journal", "Test source", [])
    j.post(datetime.date(2019, 1, 1), Account(1), 10)
    j.post(datetime.date(2019, 1, 1), Account(2), -10)
    j.validate()

# Generated at 2022-06-12 05:53:39.820451
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import inspect
    assert "__call__" in inspect.signature(ReadJournalEntries).parameters

# Generated at 2022-06-12 05:54:21.649781
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from typing import List
    je: JournalEntry = JournalEntry(date=datetime.date(2020,1,1),
                                    description="Test Journal",
                                    source="TestSource")
    je.post(date=datetime.date(2020,1,1),
            account=Account(type=AccountType.ASSETS, name="TestAccount"),
            quantity=100)
    je.validate()
    assert len(je.postings) == 1
    assert isinstance(je.postings, List)
    assert not je.postings[0].account.name == "TestAccount"
    assert not je.postings[0].amount == 100
    assert not je.postings[0].date == datetime.date(2020,1,1)
    assert not je.postings[0].direction == Direction.INC

# Generated at 2022-06-12 05:54:22.421856
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:54:23.961634
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j1 = JournalEntry[int]

# Generated at 2022-06-12 05:54:24.965962
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert False, "not implemented"

# Generated at 2022-06-12 05:54:34.438399
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    
    #-- Arrange
    j = JournalEntry(
        date=datetime.date(2020, 1, 30),
        description="Allocate Balance",
        source=None,
    )

    #-- Act
    j.post(
        date=datetime.date(2020, 1, 30),
        account=Account("Liabilities", AccountType.LIABILITIES),
        quantity=-8.00
    )
    
    #-- Assert
    assert len(j.postings) == 1
    assert j.postings[0].journal == j
    assert j.postings[0].date == datetime.date(2020, 1, 30)
    assert j.postings[0].account.name == "Liabilities"
    assert j.postings[0].account.type == AccountType

# Generated at 2022-06-12 05:54:34.957472
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:54:45.057760
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from accounting.commons.numbers import Amount, Quantity
    from accounting.domain.accounts import AccountType, Account
    from accounting.domain.journal import Direction, JournalEntry, Posting
    from datetime import date
    from typing import Dict, List, TypeVar
    from unittest import TestCase
    from unittest.mock import patch

    _T = TypeVar("_T")
    my_dict = Dict[str, float]

    class Dummy:
        def __init__(self, guid: str, balance: Amount, date: date) -> None:
            self.guid = guid
            self.balance = balance
            self.date = date


# Generated at 2022-06-12 05:54:49.920422
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class Dummy:
        pass

    # noinspection PyTypeChecker
    ReadJournalEntries.__call__(Dummy(), None)


#: Type of function which reads journal entries from a source.
ReadJournalEntriesType = ReadJournalEntries[_T]

# Generated at 2022-06-12 05:54:50.939473
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def _():
        return 1
    _()

# Generated at 2022-06-12 05:54:58.898991
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from ..commons.numbers import EUR, USD, Amount

    from .accounts import AccountsModule, Account, AccountType, GLAccount, AccountStatus, GLAccountStatus
    from .readers import GLAccountReader, GLAccountStatsReader

    accounts = AccountsModule()

    accounts.add_account("ASSETS", AccountType.ASSETS)
    accounts.add_account("LIABILITIES", AccountType.LIABILITIES)
    accounts.add_account("REVENUES", AccountType.REVENUES)
    accounts.add_account("EXPENSES", AccountType.EXPENSES)
    accounts.add_account("EQUITIES", AccountType.EQUITIES)

    accounts.add_account("CASH", AccountType.ASSETS)
    accounts.add_account("EUR-CASH", AccountType.ASSETS)
   

# Generated at 2022-06-12 05:56:10.302807
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange
    from .books import Book
    from ..models.persistence.contracts import IReadJournalEntries

    datacluster = IReadJournalEntries(Book.TEST)

    print("Contract:")
    print(datacluster.__class__)
    print("")

    print("JournalEntries:")
    try:
        entries = datacluster(DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 12, 31)))
        for e in entries:
            print(e)
    except:
        pass
    print("")

# Generated at 2022-06-12 05:56:17.561557
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import unittest
    import uuid
    from datetime import date

    class JournalEntry(Generic[_T]):
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid, init=False)
    
    class DateRange():
        def __init__(self, start_date: date, end_date: date):
            self._start=start_date
            self._end=end_date
        


# Generated at 2022-06-12 05:56:28.354459
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .books import Book
    from .businessobjects import WithJournalEntry
    from .journal import Journal
    from .ledger import Ledger
    from .segments import Segment

    class AccountTest(Account, WithJournalEntry):
        ...

    class TestUnit(WithJournalEntry):
        ...

    ## Set up:
    books = Book.create(f"Test Books", "foreman", "test_journal_entry")
    revenues = Segment.create(books, "Revenues", "RVN", 1)
    expenses = Segment.create(books, "Expenses", "EXP", 0)
    asset_type = books.add_account_type(name="Asset", weight=1)
    liability_type = books.add_account_type(name="Liability", weight=0)
    receivable

# Generated at 2022-06-12 05:56:28.860326
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ...

# Generated at 2022-06-12 05:56:40.430767
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from operator import attrgetter
    from .accounts import AccountFactory
    from .events import DoubleEntryEvent
    from .ledger import Ledger, LedgerBuilder
    from .meta import Meta

    ## Dummy definition for meta:
    class _Meta(Meta):
        pass

    ## Events:
    ev0 = DoubleEntryEvent.cheque_transaction(
        date=datetime.date(2020, 1, 1),
        cheque_no=1,
        source="",
        amount=Amount(100),
    )
    ev1 = DoubleEntryEvent.cheque_transaction(
        date=datetime.date(2020, 1, 2),
        cheque_no=2,
        source="",
        amount=Amount(200),
    )

# Generated at 2022-06-12 05:56:45.449883
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(datetime.date.today(), "Dummy journal entry", "")
    j.post(j.date, Account("An account", AccountType.ASSETS), Amount(10))
    assert (j.postings[0].amount == Amount(10)) and (j.postings[0].direction == Direction.INC)


# Generated at 2022-06-12 05:56:49.660253
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class PeriodStub(DateRange):
        def __init__(self, start, end):
            self.start = start
            self.end = end

        def __iter__(self):
            return iter((self.start,self.end))

    ReadJournalEntries(PeriodStub(datetime.date(2020,1,1),datetime.date(2020,2,2)))

# Generated at 2022-06-12 05:57:02.014752
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .journals import JournalEntry, Posting, Direction
    journalEntry = JournalEntry(datetime.date(2045, 1, 1), "Test", "", [])
    journalEntry.post(datetime.date(2045, 1, 1), Account("A"), Quantity(15))
    journalEntry.post(datetime.date(2045, 1, 1), Account("A"), Quantity(20))
    journalEntry.post(datetime.date(2045, 1, 1), Account("A"), Quantity(-30))
    assert len(journalEntry.postings) == 1
    assert journalEntry.postings[0].amount == Quantity(5)
    assert journalEntry.postings[0].direction == Direction.INC
    assert journalEntry.postings[0].account == Account("A")
    assert journalEntry.post

# Generated at 2022-06-12 05:57:08.589865
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    #: Type of business objects which generate journal entries.
    BusinessObject = TypeVar("BusinessObject")
    def create_journal_entry(date: datetime.date, description: str, source: BusinessObject) -> JournalEntry[BusinessObject]:
        je = JournalEntry(date, description, source)
        return je

    je = create_journal_entry(datetime.date(2020, 1, 1), "sale", "sale")
    je.post(datetime.date(2020, 1, 1), Account("sales"), 2000)
    je.post(datetime.date(2020, 1, 1), Account("credit_sales"), 2000)
    je.validate()

# Generated at 2022-06-12 05:57:10.703685
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from doctest import testmod
    testmod(name="ReadJournalEntries")