

# Generated at 2022-06-12 05:48:40.844707
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Arrange
    je: JournalEntry[int] = JournalEntry(datetime.datetime(2020, 1, 31), "Description", 1)
    je.post(datetime.datetime(2020, 1, 31), Account(AccountType.ASSETS, "Cash Account", "Cash Account"), 1234)
    je.post(datetime.datetime(2020, 1, 31), Account(AccountType.REVENUES, "Sales", "Sales"), -1234)
    # Act
    # Assert
    je.validate()

# Generated at 2022-06-12 05:48:42.077856
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries.__call__.__annotations__

# Generated at 2022-06-12 05:48:53.464726
# Unit test for method __call__ of class ReadJournalEntries

# Generated at 2022-06-12 05:49:05.859215
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account = Account("123", "Cash", AccountType.ASSETS, "Bank", is_bank=True)
    account1 = Account("111", "Sales", AccountType.REVENUES, "Sales")
    account2 = Account("222", "Sales", AccountType.EXPENSES, "Sales")
    journal = JournalEntry("2019-12-31", "Testing", "")
    journal.post(datetime.date(2019, 12, 31), account, 100)
    journal.post(datetime.date(2019, 12, 31), account, -100)
    journal.validate()
    journal.post(datetime.date(2019, 12, 31), account1, 100)
    journal.post(datetime.date(2019, 12, 31), account2, -100)
    journal.validate()

# Generated at 2022-06-12 05:49:12.320547
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountRepository
    from .accounts import AccountType

    # Arrange
    accounts = AccountRepository()
    accounts.add(Account("ASSETS:CASH", AccountType.ASSETS))
    accounts.add(Account("REVENUES:CASH", AccountType.REVENUES))

    date = datetime.date.today().replace(year=2020, month=1, day=1)
    journal_entry = JournalEntry[str]("test entry", date, "test_source")
    journal_entry.postings = [
        Posting(journal_entry, date, accounts["ASSETS:CASH"], Direction.INC, Amount(100_00)),
        Posting(journal_entry, date, accounts["REVENUES:CASH"], Direction.DEC, Amount(100_00)),
    ]

    # Act
    journal

# Generated at 2022-06-12 05:49:20.055537
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    class TestPost(Generic[_T]):
        pass

    @dataclass(frozen=True)
    class TestJournal(Generic[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            now = datetime.datetime.now().date()
            assert period.start <= now
            assert now <= period.end
            return []

    test = TestPost()
    assert test
    assert callable(test)


# Generated at 2022-06-12 05:49:27.423489
# Unit test for method post of class JournalEntry

# Generated at 2022-06-12 05:49:35.176502
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from dataclasses import dataclass
    from datetime import date
    from ..commons.numbers import Amount
    from ..commons.others import AutoRepr

    @dataclass(frozen=True)
    class Positions(AutoRepr):

        position_id: str

        @property
        def guid(self) -> Guid:  # hack
            return makeguid()

    account_A = Account("A", AccountType.ASSETS)
    account_B = Account("B", AccountType.EXPENSES)

    position = Positions("POSITION-1")

    journal = JournalEntry(date(2015, 4, 1), "SOME DESCRIPTION", position)
    journal.post(date(2015, 4, 1), account_A, +800)

# Generated at 2022-06-12 05:49:39.770258
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    try:
        j = JournalEntry[int](None, None, None)
        j.post(1, Account(None, AccountType.ASSETS, None), 100)
        j.post(1, Account(None, AccountType.REVENUES, None), 100)
        j.validate()
        assert True
    except Exception as e:
        assert False

# Generated at 2022-06-12 05:49:49.864847
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account

    # A mock journal entry reader:
    class JournalEntriesReader(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            yield JournalEntry(period.start_date, "Txn1", "Source1", [])
            yield JournalEntry(period.start_date, "Txn2", "Source2", [])
    
    # Read journal entries:
    reader: ReadJournalEntries[str] = JournalEntriesReader()
    journal_entries: List[JournalEntry[str]] = list(reader(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))))

    # Check:
    assert len(journal_entries) == 2

# Generated at 2022-06-12 05:50:07.500943
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..ledgers.ledgers import Ledger
    from ..ledgers.books import AccountBook
    from ..ledgers.journals import Accountant
    from ..ledgers.journals import posting
    from ..ledgers.journals import verification
    from ..ledgers.journals import journal
    
    #: Declares a validator that checks that the journal entries are consistent on both sides.
    validate = verification.make_cross_side_verifier()
    
    #: Declares a validator that checks that the journal entries are consistent on both sides.
    validate = verification.make_cross_side_verifier()
    
    #: Example ledger.
    ledger = Ledger()
    
    #: Example account book.
    book = AccountBook(ledger)
    
    #: Example accountant.
    accountant = Accountant(book)
    

# Generated at 2022-06-12 05:50:11.793523
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Define dummy implementation:
    def spy__call__() -> None:
        pass

    # Assert if the protocol can be satisfied by the function
    assert issubclass(type(spy__call__), ReadJournalEntries)

# Generated at 2022-06-12 05:50:13.035330
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass



# Generated at 2022-06-12 05:50:20.237340
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AssetAccount
    from .business import Company

    company = Company("Sample Company", "IN", None)
    account = AssetAccount("Account Description", company)
    entry = JournalEntry[Company]("Entry Description", company)
    entry\
        .post(datetime.date(2020, 1, 1), account, 1500)\
        .post(datetime.date(2020, 1, 1), account, -1000)\

    assert entry.postings[0].amount == 1500
    assert entry.postings[0].date == datetime.date(2020, 1, 1)
    assert entry.postings[0].direction == Direction.INC
    assert entry.postings[0].journal == entry
    assert entry.postings[0].account == account

    assert entry.postings[1].amount == 1000

# Generated at 2022-06-12 05:50:32.309524
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account, AccountKind

    assets= Account(AccountType.ASSETS,AccountKind.BANK,"Test Bank", "Test Bank");
    je= JournalEntry.date(datetime.date(2020,10,14),"Test JournalEntry")
    je.post(datetime.date(2020,10,14),assets,100);
    je.post(datetime.date(2020,10,14),assets,-50);
    je.post(datetime.date(2020,10,14),assets,50);
    je.validate();
    assert(je.postings[0].amount==Amount(100));
    assert(je.postings[0].direction==Direction.INC);
    assert(je.postings[1].amount==Amount(50));

# Generated at 2022-06-12 05:50:40.337062
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    # Given a Journal entry
    j1: JournalEntry[int] = JournalEntry(datetime.date(2019, 1, 1), "entry_1", 1)
    ac1 = Account(1, "asset_1", AccountType.ASSETS)
    ac2 = Account(2, "revenue_1", AccountType.REVENUES)
    Quantity(100)
    j1.post(datetime.date(2019, 1, 1), ac1, Quantity(100))
    j1.post(datetime.date(2019, 1, 1), ac2, Quantity(-100))

    # When a validation is performed on the journal entry
    j1.validate()

    # Then it should pass without error

# Generated at 2022-06-12 05:50:50.324185
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    a1 = Account("a1", AccountType.ASSETS)
    r1 = Account("r1", AccountType.REVENUES)
    e1 = Account("e1", AccountType.EXPENSES)
    feb_1 = datetime.date(2020, 2, 1)

    # Create a journal entry
    j = JournalEntry[int](feb_1, "invoice 1", 1)
    # debit assets for 1000
    j.post(feb_1, a1, 1000)
    # credit revenues for 1000
    j.post(feb_1, r1, -1000)

    # validate
    j.validate()

    # create another entry, which is not balanced
    j2 = JournalEntry[int](feb_1, "invoice 1", 1)
    # debit assets for 1000
    j2.post

# Generated at 2022-06-12 05:50:53.512432
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def readjournalentries(period: DateRange) -> Iterable[JournalEntry[int]]:
        return []
    assert isinstance(readjournalentries, ReadJournalEntries)

# Generated at 2022-06-12 05:51:05.308673
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountTypes
    from datetime import date
    from decimal import Decimal
    from unittest import TestCase, main

    class TestJournalEntry(TestCase):
        def test_post(self):
            journalentry = JournalEntry[int](date(year=2019, month=3, day=1), "Dummy entry", source=1)
            journalentry.post(date(year=2019, month=3, day=1), AccountTypes.ASSETS.general.cash, Quantity(Decimal(1)))
            journalentry.post(date(year=2019, month=3, day=1), AccountTypes.ASSETS.general.cash, Quantity(Decimal(1)))
            journalentry.post(date(year=2019, month=3, day=1), AccountTypes.ASSETS.general.cash, Quantity(Decimal(1)))

# Generated at 2022-06-12 05:51:10.437363
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry("ok")
    j.post("2018-10-01", "Assets:Cash", Amount(1000))
    j.post("2018-10-02", "Expenses:Grocery", Amount(200))
    j.post("2018-10-03", "Revenues:Salary", Amount(2000))
    print(j)

# Generated at 2022-06-12 05:51:24.386748
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # We assume the journal entry is consistent, which implies a programming error.
    je = JournalEntry(date=datetime.date.today(),
                      description="Test Journal Entry",
                      source="Test",
                      postings=[Posting(journal=je, date=datetime.date.today(), account=Account.names.ASSETS, direction=Direction.INC, amount=1),
                                Posting(journal=je, date=datetime.date.today(), account=Account.names.EQUITIES, direction=Direction.DEC, amount=1)])

    # We assume the journal entry is inconsistent, which is correct.

# Generated at 2022-06-12 05:51:34.923675
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    accounta = Account('accounta',0)
    accountb = Account('accountb',0)
    accountc = Account('accountc',0)
    entry = JournalEntry(datetime.date(2020,2,2),"Test Journal Entry",None)
    entry.post(datetime.date(2020,2,2),accounta,10)
    entry.post(datetime.date(2020,2,2),accountb,-10)
    try:
        entry.post(datetime.date(2020,2,2),accountc,10)
        assert False
    except AssertionError:
        assert True
    try:
        entry.post(datetime.date(2020,2,2),accountc,-5)
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-12 05:51:39.098986
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry[int](datetime.date.today(), "", 0)
    assert j.postings == []
    j.post(datetime.date.today(), Account("","",AccountType.ASSETS), Quantity(100))
    assert j.postings != []

# Generated at 2022-06-12 05:51:45.699786
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Accounts
    from .ledgers import Ledgers
    from .units import Balance
    from .units import JournalEntries
    from .units import Postings
    from .units import BalanceWorkers
    Ledgers.load()
    Accounts.load()
    journal_entries = JournalEntries()
    journal_entries.load()
    postings = Postings()
    postings.load()
    balance = Balance()
    balance.load()
    journal_entries_to_validate = journal_entries.journal_entries_to_validate()
    postings_to_validate = postings.postings_to_validate()
    balance_to_validate = balance.balance_to_validate()

# Generated at 2022-06-12 05:51:54.210184
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    @dataclass(frozen=True)
    class TestJournalEntry(JournalEntry): pass

    @dataclass(frozen=True)
    class MockSource:
        """
        Mocks a source, to be used in tests.
        """

        #: Unique identifier of the source.
        guid: Guid

    journal = TestJournalEntry(datetime.date(2020, 1, 1), "Some description", MockSource(makeguid()))

    assert journal.postings == []

    journal.post(journal.date, Account("Assets/Cash", AccountType.ASSETS), +1000)
    journal.post(journal.date, Account("Revenues/Sale", AccountType.REVENUES), -1000)

    journal.validate()


# Generated at 2022-06-12 05:52:05.853955
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    debits = []
    credits = []
    def _post(date: datetime.date, account: Account, quantity: Quantity):
        if not quantity.is_zero():
            if account.type in _debit_mapping[Direction.of(quantity)]:
                debits.append(Posting(S, date, account, Direction.of(quantity), Amount(abs(quantity))))
            else:
                credits.append(Posting(S, date, account, Direction.of(quantity), Amount(abs(quantity))))

    S = JournalEntry(None, None, None, list())
    S.post(None, Account(1, AccountType.EXPENSES), -100)
    S.post(None, Account(2, AccountType.EQUITIES), -200)

# Generated at 2022-06-12 05:52:17.688349
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .units import Unit
    from dataclasses import dataclass, field
    from datetime import date

    @dataclass
    class TestObject:
        id: str = field(default_factory=lambda: makeguid())

    source = TestObject()

    unit = Unit(10, 'kg', 'kilogram')

    je1 = JournalEntry[TestObject](date.today(),"test", source).post(date.today(),"a",-100)
    je2 = JournalEntry[TestObject](date.today(),"test", source).post(date.today(),"a",-100)
    je3 = JournalEntry[TestObject](date.today(),"test", source).post(date.today(),"b",100)

# Generated at 2022-06-12 05:52:26.069638
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    JournalEntry(date = datetime.date(2020,1,1),description = "Test",source = "").post(datetime.date(2020,1,1),Account("Test","Test"), Quantity(1)).validate()
    JournalEntry(date = datetime.date(2020,1,1),description = "Test",source = "").post(datetime.date(2020,1,1),Account("Test","Test"), Quantity(1)).post(datetime.date(2020,1,1),Account("Test","Test"), Quantity(1)).validate()


# Generated at 2022-06-12 05:52:27.822024
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    exp_je = JournalEntry('ABC', '1', 2)
    exp_je.validate()


# Generated at 2022-06-12 05:52:36.545100
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup:
    je = JournalEntry[int]()
    a1 = Account(id_=1, code_="1", name_="a1", type_=AccountType.ASSETS)
    a2 = Account(id_=2, code_="2", name_="a2", type_=AccountType.REVENUES)

    # Exercise:
    je.post(datetime.date(2020, 1, 1), a1, 1)
    je.post(datetime.date(2020, 1, 1), a2, -1)

    # Verify:
    assert je.validate() is None
    assert len(je.postings) == 2


# Generated at 2022-06-12 05:52:49.677310
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        print(period)
        return []

    f: ReadJournalEntries[_T] = read_journal_entries
    f(DateRange.of(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31)))



# Generated at 2022-06-12 05:52:58.443238
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass
    @dataclass
    class TestObj:
        pass
    x: Iterable[JournalEntry[TestObj]] = [JournalEntry(datetime.date(2020, 1, 1), "", TestObj())]
    f: ReadJournalEntries[TestObj] = lambda period: x
    assert f(DateRange.today()) == x
    assert f(DateRange.today()).__next__() == x.__next__()
    assert f(DateRange.today()).__iter__() == x.__iter__()
    assert f(DateRange.today()).__getitem__(0) == x.__getitem__(0)

# Generated at 2022-06-12 05:53:09.330399
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import datetime
    from app.domain.model.accounts import Account
    a1 = Account.of("A1", "Assets", "USD")
    a2 = Account.of("A2", "Equities", "USD")
    journal = JournalEntry(datetime.date(2020, 6, 1), "Test Journal", None)
    journal.postings.append(Posting(journal, datetime.date(2020, 6, 1), a1, Direction.DEC, Amount(20)))
    journal.postings.append(Posting(journal, datetime.date(2020, 6, 1), a2, Direction.INC, Amount(20)))
    journal.validate()

# Generated at 2022-06-12 05:53:15.898641
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .readjournalentries import read_journal_entries
    from .testutils.coreutils import to_datetime
    from .testutils.journal import build_journal_entry
    from .testutils.journal import build_posting
    from .testutils.journal import calc_posting
    from .testutils.journal import with_account
    from .testutils.journal import with_posting

    #: Date of journal entry.
    j_date = datetime.date(2020, 11, 27)

    #: Description of journal entry.
    j_desc = "Received first month's subscription fee"

    #: Date of posting.
    p_date = datetime.date(2020, 11, 27)

    #: Three accounts.

# Generated at 2022-06-12 05:53:21.204175
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import USD, Amount, Quantity
    from .accounts import Account, AccountType
    entry = JournalEntry(a, b, c)
    entry.post(d, Account(AccountType.ASSETS, "Cash in Hand"), Amount(USD, 100))

# Generated at 2022-06-12 05:53:21.820191
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True == True

# Generated at 2022-06-12 05:53:29.310025
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():  # noqa: D103
    from unittest import TestCase, mock

    tc: TestCase = mock.MagicMock()
    tc.assertCountEqual = tc.assertCountEqual

    entries = [
        JournalEntry(datetime.date(2000, 1, 1), "For test.", "Test 1."),
        JournalEntry(datetime.date(2000, 1, 2), "For test.", "Test 2."),
        JournalEntry(datetime.date(2000, 1, 3), "For test.", "Test 3."),
        JournalEntry(datetime.date(2000, 1, 4), "For test.", "Test 4."),
        JournalEntry(datetime.date(2000, 1, 5), "For test.", "Test 5.")
    ]

    def read(rng: DateRange) -> Iterable[JournalEntry]:
        return

# Generated at 2022-06-12 05:53:35.877642
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    entry1 = JournalEntry(datetime.date(2000, 1, 4), "Testing the validation of JournalEntry", "Test")
    entry1.post(datetime.date(2000, 1, 4), Account.of("Testing the validation of JournalEntry"), 10000)
    entry1.validate()
    print("Unit test passed, method validate of class JournalEntry")


if __name__ == "__main__":
    test_JournalEntry_validate()

# Generated at 2022-06-12 05:53:36.892627
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    #Given:
    #When:
    #Then:
    return

# Generated at 2022-06-12 05:53:46.403605
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    p1 = Posting(JournalEntry(datetime.date(2018,1,1),"Test",1),datetime.date(2018,1,1),Account("A",AccountType.ASSETS),Direction.INC,Amount(10))
    p2 = Posting(JournalEntry(datetime.date(2018,1,1),"Test",1),datetime.date(2018,1,1),Account("A",AccountType.REVENUES),Direction.DEC,Amount(10))
    list = [p1,p2]
    je1 = JournalEntry(datetime.date(2018,1,1),"Test",1)
    je2 = JournalEntry(datetime.date(2018,1,1),"Test",1)
    je2.postings = list

# Generated at 2022-06-12 05:54:07.934827
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import unittest
    import datetime
    from ..commons.zeitgeist import today, tomorrow, yesterday

    class TestReadJournalEntries(ReadJournalEntries[int]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[int]]:
            return list()

    class TestCases(unittest.TestCase):
        def test_positive(self):
            # Arrange + Act
            result = TestReadJournalEntries()(DateRange(yesterday, today))

            # Assert
            self.assertIsInstance(result, list)
            self.assertEqual(len(result), 0)

    unittest.main()

# Generated at 2022-06-12 05:54:13.897463
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Initialization
    journal = JournalEntry("2019-09-01", "Posting Test", "")

    # Excercise
    journal.post("2019-09-01", "Revenue:Restaurant",+1)

    # Assertion
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].is_credit
    assert journal.postings[0].journal == journal

# Generated at 2022-06-12 05:54:21.359377
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import datetime

    def read_journa_entries(date_range: DateRange) -> Iterable[JournalEntry[_T]]:
        entries = [
            JournalEntry(date=datetime.now(), description='', source='', postings=[]),
            JournalEntry(date=datetime.now(), description='', source='', postings=[])
        ]
        return entries

    read_journal_entries: ReadJournalEntries[_T] = read_journa_entries
    read_journal_entries('test')
    assert 'test' == 'test'

# Generated at 2022-06-12 05:54:32.622212
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime
    from typing import List
    from unittest import TestCase, mock

    from ..commons.zeitgeist import DatePeriod
    from ...accounts import Account
    from ...accounts.tools import AccountsRead
    from ...articles import ArticlesRead
    from ...articles.tools import Article

    #: Mocked accounts read dependency.
    _accounts_read: AccountsRead = mock.Mock()

    #: Mocked articles read dependency.
    _articles_read: ArticlesRead = mock.Mock()

    #: Mocked article.
    _article: Article = mock.Mock(Article)

    #: Mocked account.
    _account: Account = mock.Mock(Account)

    #: Mocked journal entry.
    _journal_entry: JournalEntry = mock.Mock(JournalEntry)

    #: This is

# Generated at 2022-06-12 05:54:43.288152
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pa=Account(code="p", name="Assets", type=AccountType.ASSETS)
    pb=Account(code="p", name="Assets", type=AccountType.ASSETS)
    pc=Account(code="p", name="Liability", type=AccountType.LIABILITIES)
    pd=Account(code="p", name="Equity", type=AccountType.EQUITIES)
    pe=Account(code="p", name="Revenue", type=AccountType.REVENUES)
    pf=Account(code="p", name="Expense", type=AccountType.EXPENSES)
    je=JournalEntry(datetime.date(2020, 1, 8), "test", "test", [])
    je.post(datetime.date(2020, 1, 8), pa, 1000)

# Generated at 2022-06-12 05:54:47.965005
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account

    je = JournalEntry[None]
    je.post(datetime.date.today(), Account.of(AccountType.ASSETS, "Cash"), Amount(100))

    assert len(je.postings) == 1

# Generated at 2022-06-12 05:54:52.785233
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Given
    j = JournalEntry[int](date=datetime.date(2020, 5, 21), description='test', source=0)
    # When
    j = j.post(date=datetime.date(2020, 5, 21), account=Account('Assets', AccountType.ASSETS, 'Assets'), quantity=1.00)
    j = j.post(date=datetime.date(2020, 5, 21), account=Account('Assets', AccountType.ASSETS, 'Assets'), quantity=0.00)
    # Then
    assert len(j.postings) == 1
    assert j.postings[0].direction == Direction.INC
    assert j.postings[0].account.type == AccountType.ASSETS

# Generated at 2022-06-12 05:54:54.171719
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert list(ReadJournalEntries()(DateRange())) == []

# Generated at 2022-06-12 05:55:05.428102
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create a test account
    account = Account("account", False, None, AccountType.ASSETS)
    # Create a test journal entry
    je = JournalEntry("2020-01-01", "description", "source")
    # Post 100 to the test account
    je.post(je.date, account, 100)
    # Check correct posting
    assert je.postings[0].date == je.date
    assert je.postings[0].account == account
    assert je.postings[0].amount == Amount(100)
    assert je.postings[0].direction == Direction.INC
    # Check there is no posting for 0
    je.post(je.date, account, 0)
    assert len(je.postings) == 1

# Generated at 2022-06-12 05:55:07.225631
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def func(period: DateRange) -> Iterable[JournalEntry[str]]:
        pass



# Generated at 2022-06-12 05:55:45.912103
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .businessobjects import PurchaseOfGoodsAndServices
    from .accounts import Accounts

    ## Act:
    je = JournalEntry[PurchaseOfGoodsAndServices]()
    je.source = PurchaseOfGoodsAndServices(id="PO-1234-ABCD", date=datetime.date(2020, 5, 1), amount=Amount(100.00), gst=Amount(10.00))
    je.date = datetime.date(2020, 5, 1)
    je.description = "Purchase of goods and services"
    je.post(datetime.date(2020, 5, 1), Accounts.GET.by_name("Accounts Payable"), Amount(100.00))
    je.post(datetime.date(2020, 5, 1), Accounts.GET.by_name("GST Payable"), Amount(10.00))

# Generated at 2022-06-12 05:55:53.259845
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounttypes import AccountType as AT
    import datetime as dt
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from ..commons.strings import truncate
    from ..commons.zeitgeist import DateRange
    from .journals import Posting, JournalEntry, Direction
    # Providing a common DateRange
    period = DateRange(start=dt.date(year=2000, month=1, day=1), end=dt.date(year=2020, month=1, day=1))

    # cash = Account(name='cash', type=AT.asset)
    # expense = Account(name='expense', type=AT.expense)
    # revenue = Account(name='revenue', type

# Generated at 2022-06-12 05:55:54.156069
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    raise NotImplementedError


# Generated at 2022-06-12 05:56:06.011259
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from unittest import TestCase, mock

    from .accounts import ACCOUNTS

    class TestReadJournalEntries(TestCase):

        def test_returns_journal_entries_for_given_range(self):

            def dbReadJournalEntries(dateRange: DateRange) -> List[JournalEntry[str]]:
                return [
                    JournalEntry(datetime.date(2018, 1, 1), "Intro", "B", [Posting(None, datetime.date(2018, 1, 1), ACCOUNTS["A"], Direction.DEC, Amount(100))]),
                ]

            reader = ReadJournalEntries.__getitem__(None, str)
            reader = reader(dbReadJournalEntries)


# Generated at 2022-06-12 05:56:15.905080
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import make_account_number
    from .accounts import make_account
    from .journal import JournalEntry
    from .journal import Direction
    from .journal import Posting
    from datetime import date

    A1 = make_account("A1", "Account 1", AccountType.ASSETS)
    A2 = make_account("A2", "Account 2", AccountType.ASSETS)
    E1 = make_account("E1", "Account 3", AccountType.EQUITIES)
    L1 = make_account("L1", "Account 4", AccountType.LIABILITIES)
    R1 = make_account("R1", "Account 5", AccountType.REVENUES)

# Generated at 2022-06-12 05:56:27.034752
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.accounts import Account, Accounts
    from ..books.payees import Payee, Payees
    from ..books.products import Product, Products
    from ..books.persons import Person, Persons
    from ..books.companies import Company, Companies
    from ..books.customers import Customer, Customers
    from ..books.vendors import Vendor, Vendors
    from ..books.warehouses import Warehouse, Warehouses
    
    # Create book of accounts:
    payees = Payees({"Customer 1": Customer(Person(name="Customer 1")), "Vendor 1": Vendor(Person(name="Vendor 1"))})
    products = Products({"Product 1": Product(name="Product 1")})
    persons = Persons({"Person 1": Person(name="Person 1")})

# Generated at 2022-06-12 05:56:38.400964
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class Test:
        def __init__(self, date=None, desc=None, source=None):
            self.date = date
            self.description = desc
            self.source = source
            self.postings = list()

        def post(self, date, account, quantity):
            self.postings.append((Posting(self, date, account, Direction.of(quantity), Amount(abs(quantity)))))

        def validate(self, total_debit, total_credit):
            assert total_debit == total_credit, f"Total Debits and Credits are not equal: {total_debit} != {total_credit}"

    je = Test()
    je.post(datetime.date.today(), Account('Cash_in_hand', AccountType.REVENUES), Quantity(100))

# Generated at 2022-06-12 05:56:49.141616
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    #: Date of the entry.
    date = datetime.date(2020, 1, 1)
    #: Description of the entry.
    description = "test journal entry"
    #: Business object as the source of the journal entry.
    source = None
    #: Postings of the journal entry.
    postings = list()

    #: Globally unique, ephemeral identifier.
    guid = Guid("48a9b1d9-e6e8-42d1-af17-2a5049c4b4c9")

    je = JournalEntry(date, description, source, postings, guid)
    je.post(date, Account("TestAsset", AccountType.ASSETS), Amount(100))
    je.post(date, Account("TestRevenue", AccountType.REVENUES), Amount(-100))


# Generated at 2022-06-12 05:56:59.432948
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    ## Arrange ##
    ## Act ##
    entry = JournalEntry(datetime.date(2020, 6, 1), "Test", None).post(
        datetime.date(2020, 6, 1), accounts.CommonStock, 10000
    ).post(datetime.date(2020, 6, 1), accounts.Revenues, -10000)

    ## Assert ##
    assert entry.postings == [
        Posting(entry, datetime.date(2020, 6, 1), accounts.CommonStock, Direction.INC, 10000),
        Posting(entry, datetime.date(2020, 6, 1), accounts.Revenues, Direction.DEC, 10000),
    ]

# Generated at 2022-06-12 05:57:08.460987
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class B(Generic[_T]):
        def __init__(self,name,amount):
            self.amount=amount
            self.name=name

    A=JournalEntry[B]
    a=A(date=datetime.date(2019, 2, 28), description="test", source=B("test",100))
    b=a.post(date=datetime.date(2019, 2, 28), account=Account(number=171,name="Cash", type=AccountType.ASSETS),quantity=-100)
    c=b.post(date=datetime.date(2019, 2, 28), account=Account(number=374, name="Accounts Receivable", type=AccountType.ASSETS), quantity=-100)

# Generated at 2022-06-12 05:58:22.372872
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j1 = JournalEntry(date=datetime.date(2020, 1, 1),
                      description="1",
                      source="",
                      postings=[Posting(journal=None, date=datetime.date(2020, 1, 1),
                                        account=Account(
                                            code="Assets:Cash",
                                            name="Cash",
                                            type=AccountType.ASSETS),
                                        direction=Direction.INC,
                                        amount=100.0),
                               Posting(journal=None, date=datetime.date(2020, 1, 1),
                                       account=Account(
                                           code="Income:Sales",
                                           name="Sales",
                                           type=AccountType.REVENUES),
                                       direction=Direction.DEC,
                                       amount=100.0)])

# Generated at 2022-06-12 05:58:24.825439
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry[object](date=datetime.date.today(),description="Test",source=object())
    j.post(date=datetime.date.today(),account=Account("test"),quantity=1)
    j.validate()

