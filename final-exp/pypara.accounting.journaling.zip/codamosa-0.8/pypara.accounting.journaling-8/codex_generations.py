

# Generated at 2022-06-12 05:48:44.526630
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ...accounts import Account, AccountType, ChartOfAccounts
    from ...models import Entity
    from ...storage.memory import MemoryStorage
    from ...storage.astracake import AstroCakeStorage
    from bank_of_nobert.bank_of_nobert.accounts import AccountType

    # Create a chart of accounts:
    chart: ChartOfAccounts = ChartOfAccounts()
    chart.add(Account("1001", "Cash", AccountType.ASSETS))
    chart.add(Account("2001", "Inventory", AccountType.ASSETS))
    chart.add(Account("3001", "Sales", AccountType.REVENUES))
    chart.add(Account("3002", "COGS", AccountType.EXPENSES))

# Generated at 2022-06-12 05:48:50.352392
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[object](date=datetime.date.today(), description="", source=None)
    je.post(date=je.date, account=Account("A", AccountType.ASSETS), quantity=1000)
    je.post(date=je.date, account=Account("B", AccountType.EQUITIES), quantity=-1000)
    je.validate()
    assert True

# Generated at 2022-06-12 05:48:56.103108
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Given
    from .accounts import Account
    from datetime import date
    e = JournalEntry[str](date(2018, 4, 1), "Test", "TestSource")
    e.post(date(2018, 4, 1), Account("Cash", AccountType.ASSETS), 1000)
    e.post(date(2018, 4, 1), Account("Sales", AccountType.REVENUES), -1000)

    # When
    e.validate()

    # Then
    # No exception is thrown

# Generated at 2022-06-12 05:49:08.010933
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import JournalAccount
    from datetime import date
    from hamcrest.core.assert_that import assert_that
    from datetime import date
    from decimal import Decimal
    from hamcrest.core.matcher_assert import Is
    from hamcrest.core.description import Description
    from hamcrest.core.string_description import StringDescription
    from hamcrest.core.equal_to import EqualTo
    from hamcrest.core.any_of import AnyOf
    from hamcrest.core.is_ import Is
    Entry = JournalEntry[str]
    def with_postings(expected_postings):
        def matcher(entry: Entry):
            actual_postings = entry.postings
            expected_postings_count = len(expected_postings)
            actual_postings_count = len

# Generated at 2022-06-12 05:49:18.763624
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..persistence.dummy import make_dummy_journal_entries
    from ..persistence.journal import JournalStore

    store = JournalStore()
    j = JournalEntry(date=datetime.date(2019, 1, 1), description="", source=())

    j.post(date=datetime.date(2019, 1, 1), account=store.accounts["Cash"], quantity=1000).post(
        date=datetime.date(2019, 1, 1), account=store.accounts["Inventory"], quantity=-1000
    )

    try:
        j.validate()
    except AssertionError:
        raise AssertionError("Validation failed")

    j.post(date=datetime.date(2019, 1, 2), account=store.accounts["Income"], quantity=-1000)


# Generated at 2022-06-12 05:49:27.673892
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # GIVEN: A journal entry of a business object
    class TestSource:
        pass
    journalEntry = JournalEntry[TestSource](datetime.date(2020, 1, 1), "Test JournalEntry", TestSource())

    # WHEN: This journal entry is posted with a quantity of 10
    journalEntry.post(datetime.date(2020, 1, 1), Account("Assets:Test"), 10)

    # THEN: The journal entry has a posting for this event
    assert journalEntry.postings[0] == Posting(journalEntry, datetime.date(2020, 1, 1), Account("Assets:Test"), Direction.INC, Amount(10))

# Generated at 2022-06-12 05:49:35.321283
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    entries = [JournalEntry(
                    date = datetime.date(2020, 9, 6),
                    description = "test journal entry",
                    source = "sales"
                ).post(
                    date = datetime.date(2020, 9, 7),
                    account = Account.instance(
                        account_id=5864,
                        name="Cash",
                        type=AccountType.ASSETS,
                        parent=None
                    ),
                    quantity = Quantity(1000)
                )
                .post(
                    date = datetime.date(2020, 9, 7),
                    account = Account.instance(
                        account_id=2312,
                        name="Sales",
                        type=AccountType.REVENUES,
                        parent=None
                    ),
                    quantity = Quantity(-1000)
                )]
    entry = entries[0]
    entry.validate()

# Generated at 2022-06-12 05:49:39.539270
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry = JournalEntry(datetime.date(2020, 8, 8), 'Test', 2)
    journal_entry.post(datetime.date(2020, 8, 8), Account("Test", AccountType.ASSETS), Quantity(10))
    assert len(journal_entry.postings) == 1

# Generated at 2022-06-12 05:49:40.148434
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert 1 == 1

# Generated at 2022-06-12 05:49:44.737960
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_accounts = Account(AccountType.ASSETS, 'test_asset')
    test_postings = [Posting(10, test_accounts, Direction.INC, Amount(100))]
    test_JournalEntry = JournalEntry(datetime.date.today(), 'test_description', {}, test_postings, makeguid())
    test_JournalEntry.validate()

# Generated at 2022-06-12 05:49:57.102818
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    ## Arrange
    j = JournalEntry(date=datetime.date.today(), description="", source=None)

    j.post(j.date, Account("A1", AccountType.ASSETS), Quantity(100))
    j.post(j.date, Account("A2", AccountType.ASSETS), Quantity(200))
    j.post(j.date, Account("E1", AccountType.EQUITIES), Quantity(-300))

    ## Act
    j.validate()

    ## Assert
    assert True

# Generated at 2022-06-12 05:50:00.359255
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass
    class Dummy:
      pass
      
    def f(period: DateRange) -> Iterable[JournalEntry[Dummy]]:
      return []

    assert callable(ReadJournalEntries.__call__)
    assert isinstance(f, ReadJournalEntries)

# Generated at 2022-06-12 05:50:03.327527
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class Minimal:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass
    Minimal()

# Generated at 2022-06-12 05:50:15.402522
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .books import Book
    from .books import TestBook
    from .postings import TestPostings
    from .source import TestSource

    ## Data Setup:
    book = Book(TestBook)
    bk_acc = book.accounts[Account(AccountType.ASSETS, 'Bank')]
    ca_acc = book.accounts[Account(AccountType.EQUITIES, 'Capital')]

    ## Test Setup:
    je = JournalEntry(TestSource, datetime.date(2020, 1, 1), "test")

    ## Postings:
    je.post(datetime.date(2020, 1, 1), bk_acc, 100)
    je.post(datetime.date(2020, 1, 1), ca_acc, -100)

    ## Test:
    je.validate()

# Generated at 2022-06-12 05:50:21.383375
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Test JournalEntry", object())
    journal_entry.post(datetime.date(2020, 1, 1), Account.of("Assets", AccountType.ASSETS), Quantity(2))
    journal_entry.post(datetime.date(2020, 1, 1), Account.of("Revenues", AccountType.REVENUES), Quantity(-2))
    journal_entry.validate()

# Generated at 2022-06-12 05:50:27.542837
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    class Foo:
        pass
    je = JournalEntry(
        datetime.date(2020, 1, 1),
        "Foo",
        Foo(),
    )
    je.post(datetime.date(2020, 1, 1), Account(), 1000.0)
    je.post(datetime.date(2020, 1, 1), Account(), -1000.0)
    je.validate()

# Generated at 2022-06-12 05:50:38.337278
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .accounts import AccountType
    journal_entry1=JournalEntry(date=datetime.date(2020,3,3),description='casa')
    journal_entry1.post(date=datetime.date(2020,3,3),account=Account(name='casa',type=AccountType.ASSETS),quantity=100)
    journal_entry1.validate()
    journal_entry2=JournalEntry(date=datetime.date(2020,3,3),description='casa')
    journal_entry2.post(date=datetime.date(2020,3,3),account=Account(name='casa',type=AccountType.ASSETS),quantity=0)
    journal_entry2.validate()

# Generated at 2022-06-12 05:50:49.531694
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity

    # Create an account and a journal entry
    a = Account("A1", AccountType.ASSETS)
    je = JournalEntry(datetime.datetime.now().date(), "Description", "A1")

    # Post something
    je.post(datetime.datetime.now().date(), a, Quantity(5))
    assert len(je.debits) == 1
    assert len(je.credits) == 0

    # Post something else
    je.post(datetime.datetime.now().date(), a, Quantity(-5))
    assert len(je.debits) == 0
    assert len(je.credits) == 1

    # Make an invalid entry

# Generated at 2022-06-12 05:50:50.924469
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Accounts

    entries = ReadJournalEntries()



# Generated at 2022-06-12 05:50:59.705288
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Tests the method ``validate`` of class ``JournalEntry``.
    """

    from .accounts import AccountType
    from .business_objects import BusinessObject

    obj = BusinessObject()

    # One journal entry with a single debit and credit posting:
    je1 = JournalEntry(datetime.date(2019, 12, 30), "This is a test", obj)
    je1.post(je1.date, Account(AccountType.INCOME, "Income"), +10)
    je1.post(je1.date, Account(AccountType.REVENUES, "Sales"), -10)

    # <Test 1>: Validate journal entry.
    je1.validate()

    # One journal entry with two debits and one credit posting:

# Generated at 2022-06-12 05:51:10.921024
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def call(period):
        print(f'ReadJournalEntries is called with period = {period}')
        return [1, 2, 3]
    c = ReadJournalEntries.__call__
    c.__qualname__ = 'call'
    ret = c(None, None)
    assert ret == [1, 2, 3]

# Generated at 2022-06-12 05:51:19.321565
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry(
        date=datetime.date(2020, 2, 14),
        description="Cash Sale of pens",
        source='Business Event'
    ).post(
        date=datetime.date(2020, 2, 14),
        account=Account(
            code='10100',
            name='Cash Account'
        ),
        quantity=120
    ).post(
        date=datetime.date(2020, 2, 14),
        account=Account(
            code='40100',
            name='Stationary Sales Account'
        ),
        quantity=-120
    )
    je.validate()
    print(je)

# Generated at 2022-06-12 05:51:31.264600
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import create_account, add_posting_to_account, calculate_account_balance
    from .numbers import Quantity
    from .journal import JournalEntry
    import datetime

    # creating an expense account
    expenses_account = create_account("Expenses Account", AccountType.EXPENSES)

    # creating a cash account
    cash_account = create_account("Cash Account", AccountType.ASSETS)

    # posting an expense to expenses account
    expense_posting = add_posting_to_account(expenses_account, datetime.datetime.now(), Quantity(3000, "USD"))

    # posting an expense to cash account

# Generated at 2022-06-12 05:51:41.560608
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import uuid
    from .accounts import Account

    class TestClass:
        pass

    test_obj = TestClass()
    je = JournalEntry(datetime.date(2020, 1, 1), "TEST", test_obj)
    je.post(datetime.date(2020, 1, 1), Account(uuid.uuid4(), "TEST_ASSETS", AccountType.ASSETS), Amount(100))
    je.post(datetime.date(2020, 1, 1), Account(uuid.uuid4(), "TEST_EQUITIES", AccountType.EQUITIES), Amount(100))
    je.post(datetime.date(2020, 1, 1), Account(uuid.uuid4(), "TEST_LIABILITIES", AccountType.LIABILITIES), Amount(100))

# Generated at 2022-06-12 05:51:44.756656
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def f(period: DateRange) -> Iterable[JournalEntry[int]]:
        ...
    assert isinstance(f, ReadJournalEntries)

# Generated at 2022-06-12 05:51:51.392128
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    from .accounts import AccountType

    je = JournalEntry[object](datetime.datetime.now().date(), 'Test journal entry', None)
    je.post(datetime.datetime.now().date(), Account(AccountType.ASSETS, 'Test account 1', None), Amount(100))
    je.post(datetime.datetime.now().date(), Account(AccountType.EQUITIES, 'Test account 2', None), Amount(100))
    je.validate()

# Generated at 2022-06-12 05:51:56.492733
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def _read_journal_entries_function(period: DateRange) -> Iterable[JournalEntry[object]]:
        pass
    assert hasattr(_read_journal_entries_function, '__call__')
    assert issubclass(type(_read_journal_entries_function), ReadJournalEntries)

# Generated at 2022-06-12 05:52:07.227521
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType, Account
    from .businessobjects import Business
    from .codes import Code
    from .events import Event
    from .tags import Tag
    from .types import Type
    from .units import Unit
    from .users import User

    acc_op_exp = Account(1, AccountType.EXPENSES, "Operational Expenses", Code("420", Type(1, "Expense")))
    acc_op_rev = Account(2, AccountType.REVENUES, "Operational Revenues", Code("310", Type(1, "Revenue")))

    biz_a = Business(1, "A")
    biz_b = Business(2, "B")

    user = User(id=1, username="user", name="User")


# Generated at 2022-06-12 05:52:12.933654
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(datetime.date.today(), "description", "source")
    j.post(datetime.date.today(), Account("liabilities", "liability", "liability"), -2)
    assert len(j.postings) == 1
    assert j.postings[0].direction == Direction.DEC

# Generated at 2022-06-12 05:52:20.969828
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import random
    import names
    import datetime
    from ..core.accounts.account_mapper import map_to_account

    expense_account = map_to_account(10)
    revenue_account = map_to_account(20)
    asset_account = map_to_account(30)
    equity_account = map_to_account(40)
    liability_account = map_to_account(50)

    for i in range(0, 10000):
        value = random.randint(-100,100)
        a = JournalEntry[int]()
        a.date =  datetime.date( random.randint(1985,2020), random.randint(1,12), random.randint(1,28))
        a.description = names.get_full_name()

# Generated at 2022-06-12 05:52:40.723415
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    jo1 = JournalEntry(datetime.date(2020, 2, 9), "Description", 'Source')
    jo1.post(datetime.date(2020, 2, 9), Account("Cash"), Quantity(1000))
    jo1.post(datetime.date(2020, 2, 9), Account("Expenses"), Quantity(300))
    jo1.post(datetime.date(2020, 2, 9), Account("Equities"), Quantity(200))
    jo1.post(datetime.date(2020, 2, 9), Account("Cash"), Quantity(1000))
    print(jo1.postings[0].amount)
    print(jo1.postings[1].amount)
    print(jo1.postings[2].amount)
    print(jo1.postings[3].amount)


# Generated at 2022-06-12 05:52:50.285149
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    # Arrange:
    JE = JournalEntry[None]
    je = JE(
        date = datetime.date(2019, 12, 31),
        description = 'test_ReadJournalEntries___call__',
        source = None
    )

    class SubReadJournalEntries(ReadJournalEntries[None]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[None]]:
            return [je]

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    # Act:
    test_result = SubReadJournalEntries()(period)

    # Assert:
    assert test_result == [je]

# Generated at 2022-06-12 05:52:50.749814
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-12 05:52:51.513406
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:52:52.008711
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-12 05:52:55.276331
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.model import Book
    book=Book()
    journal_entry=JournalEntry()
    journal_entry.post(date,account,quantity)

# Generated at 2022-06-12 05:52:59.749926
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account = Account("Account", AccountType.ASSETS)
    qty = Quantity(5)
    date = datetime.date(2020, 3, 1)

    journal = JournalEntry[int](date, "Description", 0)
    journal.post(date, "name", Quantity(0))
    journal.post(date, account, qty)
    journal.validate()

# Generated at 2022-06-12 05:53:06.673406
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    actual = ReadJournalEntries.__call__
    
    assert actual.__name__ == '__call__', "Expected name to be __call__"
    assert actual.__qualname__ == 'ReadJournalEntries.__call__', "Expected qualname to be ReadJournalEntries.__call__"

# Generated at 2022-06-12 05:53:14.968504
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..books.ledger import LedgerBook
    import random
    import datetime
    from .accounts import AccountType
    from .balancesheet import BalanceSheetAccount
    from .incomesheet import IncomeSheetAccount
    from ..factories import book_factory

    
#Testing if it rises an error if there are not the same amounts
    print("Testing if error is raised when there are not the same amounts:")
    book = book_factory(BalanceSheetAccount, IncomeSheetAccount)
    journal = book.journal()
    date = datetime.date(2020, 8, 8)
    description = "First description"
    JournalEntry(date, description, None)
    print("Testing if error is raised when there are not the same amounts:")

# Generated at 2022-06-12 05:53:24.828145
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal_entry: JournalEntry[int] = JournalEntry(
        date=datetime.date(2019,5,5),
        description="Auto Test: JournalEntry validate function",
        source=int(1)
    )
    journal_entry.post(datetime.date(2019,5,5), account=Account(name="x", parent_name=None, currency=None), quantity=1)
    journal_entry.post(datetime.date(2019,5,5), account=Account(name="y", parent_name=None, currency=None), quantity=-1)
    journal_entry.validate() # Return None if correct


# Generated at 2022-06-12 05:53:59.232079
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .commons.numbers import Quantity, Amount

    account1 = Account("Assets:Bank:RBC", AccountType.ASSETS)
    account2 = Account("Expense:Restaurant:Groceries", AccountType.EXPENSES)

    je = JournalEntry(datetime.date.today(),"Description","Source")
    je.post(datetime.date.today(), account1, Quantity(10000))
    je.post(datetime.date.today(), account2, Quantity(2500))
    je.post(datetime.date.today(), account1, Quantity(-5000))
    je.post(datetime.date.today(), account2, Quantity(-5000))


# Generated at 2022-06-12 05:54:07.450050
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account

    j = JournalEntry(datetime.date(2020,6,20), "Test Journal Entry", "Test Object")
    j.post(datetime.date(2020,6,20), Account("Test Account A"), 100.05)
    j.post(datetime.date(2020,6,20), Account("Test Account B"), -100.05)

    assert j.journal == "Test Journal Entry"
    assert j.date == datetime.date(2020,6,20)
    assert j.description == "Test Journal Entry"
    assert j.source == "Test Object"
    assert j.postings[0].journal == "Test Journal Entry"
    assert j.postings[0].date == datetime.date(2020,6,20)

# Generated at 2022-06-12 05:54:19.125796
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # When
    journalEntry = JournalEntry[None]
    journalEntry.date = datetime.date.today()
    journalEntry.description = 'test'
    journalEntry.source = None
    journalEntry.post(journalEntry.date, Account(AccountType.ASSETS, '1'), Quantity(200))
    journalEntry.post(journalEntry.date, Account(AccountType.EQUITIES, '2'), Quantity(300))
    journalEntry.post(journalEntry.date, Account(AccountType.LIABILITIES, '3'), Quantity(400))

    # Then
    assert journalEntry.postings[0].date == journalEntry.date
    assert journalEntry.postings[0].account.name == '1'
    assert journalEntry.postings[0].direction == Direction.INC

# Generated at 2022-06-12 05:54:29.477056
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(datetime.date.today(), 'Test JournalEntry', 'None')
    j.post(datetime.date.today(), Account('Asset', AccountType.ASSETS), 100)
    j.post(datetime.date.today(), Account('Asset', AccountType.ASSETS), 100)
    j.post(datetime.date.today(), Account('Liability', AccountType.LIABILITIES), 100)
    assert len(j.postings[0].account.name) > 0
    assert j.postings[1].account.type == AccountType.ASSETS
    assert j.postings[2].direction == Direction.INC
    assert j.postings[3].amount == 100


# Generated at 2022-06-12 05:54:29.990924
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ...

# Generated at 2022-06-12 05:54:34.480012
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period):
        pass

    assert callable(read_journal_entries)

    from .commons.zeitgeist import DateRange

    read_journal_entries(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31)))

# Generated at 2022-06-12 05:54:44.562471
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime
    from dataclasses import dataclass, field
    from typing import Optional
    from typing_extensions import Protocol
    from .accounts import Account, AccountType
    from .testdata import accounts, account_by_code
    from ..commons.numbers import Amount, Quantity, ZERO
    from ..commons.zeitgeist import DateRange

    # Test data.

# Generated at 2022-06-12 05:54:56.225009
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        yield JournalEntry(date=datetime.date(2020, 1, 1), description="1", source=None)
        yield JournalEntry(date=datetime.date(2020, 1, 2), description="2", source=None)
        yield JournalEntry(date=datetime.date(2020, 1, 3), description="3", source=None)

    assert len(list(read_journal_entries(DateRange(None, None)))) == 3
    assert len(list(read_journal_entries(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2))))) == 2

# Generated at 2022-06-12 05:55:07.713665
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    from .accounts import Account
    from .books import CostCenter
    from .inventory import Product

    p1 = Product("Computer", CostCenter.objects.get(description="IT"))
    p2 = Product("Chair", CostCenter.objects.get(description="Office"))
    a1 = Account.objects.get(name="Inventory")
    a2 = Account.objects.get(name="Cost of Goods Sold")
    a3 = Account.objects.get(name="Cash")
    a4 = Account.objects.get(name="Sales Return")
    d1 = datetime.date(2019, 1, 1)
    d2 = datetime.date(2019, 1, 2)

    je1 = JournalEntry(d1, "Sale of Products", None)
    je1.post(d1, a1, -7)

# Generated at 2022-06-12 05:55:16.696903
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Testing the post method of class JournalEntry.
    """

    event = JournalEntry[object](
        date=datetime.date.today(),
        description="dummy",
        source=None
    )

    assert len(event.postings) == 0

    event.post(datetime.date.today(), Account("1"), 1)
    assert len(event.postings) == 1
    assert event.postings[0].direction == Direction.INC

    event.post(datetime.date.today(), Account("2"), -1)
    assert len(event.postings) == 2
    assert event.postings[1].direction == Direction.DEC

    event.post(datetime.date.today(), Account("3"), 0)
    assert len(event.postings) == 2

# Generated at 2022-06-12 05:56:05.793094
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    assert True
    
    

# Generated at 2022-06-12 05:56:11.495907
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je1 = JournalEntry(datetime.date(2020, 1, 1), "Description", None)
    je1.post(datetime.date(2020, 1, 1), "Account", Quantity(100))
    assert len(je1.postings) == 1
    assert je1.postings[0].account == "Account"
    assert je1.postings[0].amount == Amount(100)

    je1.post(datetime.date(2020, 1, 5), "Account", Quantity(100))
    assert len(je1.postings) == 2
    assert je1.postings[1].account == "Account"
    assert je1.postings[1].amount == Amount(100)

    je1.post(datetime.date(2020, 1, 7), "Account", Quantity(0))

# Generated at 2022-06-12 05:56:22.397531
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date1 = datetime.date(2020, 1, 1)
    date2 = datetime.date(2020, 2, 1)
    date3 = datetime.date(2020, 3, 1)
    account1 = Account("A1", AccountType.EQUITIES)
    account2 = Account("A2", AccountType.EQUITIES)
    journalentry = JournalEntry(date1, "Test journal", "2")
    journalentry.post(date1, account1, 10)
    journalentry.post(date2, account2, -10)
    assert (journalentry.postings[0].direction == Direction.INC)
    assert (journalentry.postings[0].amount == 10)
    assert (journalentry.postings[1].direction == Direction.DEC)
    assert (journalentry.postings[1].amount == 10)


# Generated at 2022-06-12 05:56:28.625814
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():

    def apply(arg: DateRange) -> Iterable[JournalEntry[object]]:
        ...

    ReadJournalEntries[object](apply)

    from datetime import date, timedelta

    d1 = date.today() - timedelta(days=1)
    d2 = date.today()

    assert ReadJournalEntries[object](apply).__call__(DateRange(d1, d2)) == apply(DateRange(d1, d2))

# Generated at 2022-06-12 05:56:29.108530
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-12 05:56:34.912950
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ReadJournalEntriesImpl(ReadJournalEntries[int]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[int]]:
            yield JournalEntry(datetime.date.today(), "", 12, [])
    entries = ReadJournalEntriesImpl()
    list(entries(DateRange.TODAY))

# Generated at 2022-06-12 05:56:43.591332
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from . import Account
    from .accounts import AccountType
    from .journal_entries import JournalEntry
    from .read_accounts import read_accounts
    from .read_journal_entries import read_journal_entries
    import datetime
    accounts = read_accounts("sample_accounts.csv")
    je_source = JournalEntry[Account](datetime.date(2019, 1, 1), "Test", accounts[0])
    je_source.post(datetime.date(2019, 1, 1), accounts[0], 10)
    je_source.post(datetime.date(2019, 1, 1), accounts[1], -5)
    je_source.post(datetime.date(2019, 1, 1), accounts[2], -5)
    je_source.validate()
    assert je_source.post

# Generated at 2022-06-12 05:56:50.423073
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from timeit import Timer
    from itertools import chain
    from .corporate import Transaction, TransactionType
    from .financial import Cash, Bank
    from .shared import Income, Sales, Taxes

    ## Define target to be tested:
    target = ReadJournalEntries()

    ## Check for expected behavior:
    assert target.__call__(DateRange()) == ()

    ## Verify performance:
    assert Timer(target.__call__, [DateRange()]).timeit(number=10000) < 10


# Generated at 2022-06-12 05:57:02.549237
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import datetime, timedelta
    from unittest.mock import Mock

    D = datetime.date
    R = DateRange
    J = JournalEntry
    

    def apply (period: DateRange, je1: JournalEntry[str], je2: JournalEntry[str]) -> None:
        # Arrange
        mock = Mock()
        mock.__call__().return_value = [je1, je2]
        result: Iterable[JournalEntry[str]] = mock.__call__(period)

        # Act
        for element in result:
            # Assert
            mock.__call__(element)
            assert element == je1 or element == je2


# Generated at 2022-06-12 05:57:09.464357
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date

    # Setup:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        yield Account.make_account(AccountType.ASSETS, 'Cash')

    _ReadJournalEntries = ReadJournalEntries
    assert isinstance(read_journal_entries, _ReadJournalEntries)

    period: DateRange = DateRange(date(2018, 1, 1), date(2018, 1, 10))

    # Exercise:
    result = read_journal_entries(period)

    # Verify:
    from typing import Iterable

    expected: Iterable[JournalEntry[_T]] = [Account.make_account(AccountType.ASSETS, 'Cash')]
    assert list(result) == list(expected)