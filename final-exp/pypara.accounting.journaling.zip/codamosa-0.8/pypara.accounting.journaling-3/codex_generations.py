

# Generated at 2022-06-12 05:48:38.495195
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class ReadJournalEntriesImpl:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            yield JournalEntry(datetime.date.min, "", "")

    try:
        ReadJournalEntriesImpl()
    except TypeError:
        assert False, "Should NOT raise TypeError"

    try:
        ReadJournalEntries()
    except TypeError:
        assert False, "Should NOT raise TypeError"

# Generated at 2022-06-12 05:48:47.257035
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts.repository import read_accounts_by_number
    from ..commons.datetime import MONTHS_PER_YEAR, QUARTERS_PER_YEAR, TODAY
    assert read_accounts_by_number()
    # Number of entries and postings per entry:
    num_entries = 100
    num_postings = 5

    # Period to test with:
    period_start = TODAY - datetime.timedelta(days=num_entries*num_postings)
    period_end = TODAY

    # Posting accounts (expenses and revenues):
    acc_expenses = read_accounts_by_number()(AccountType.EXPENSES)
    acc_revenues = read_accounts_by_number()(AccountType.REVENUES)


# Generated at 2022-06-12 05:48:55.673495
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account
    from datetime import date
    from .commons.numbers import Amount, Quantity

    # Build test data
    date = date(2018, 12, 28)
    account = Account(1, "Cash", AccountType.ASSETS)
    journal = JournalEntry(date.today(), "Purchase from WalMart", "business_object")
    quantity = Quantity(10)

    # Test to check result before adding a posting
    assert len(journal.postings) == 0
    assert journal.post(date, account, quantity) == journal

    # Test to check result after adding a posting
    assert len(journal.postings) == 1
    posting = journal.postings[0]
    assert posting.date == date
    assert posting.account == account
    assert posting.direction == Direction.INC
    assert posting.amount

# Generated at 2022-06-12 05:49:00.632848
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class Revenue(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return iter([])
    assert Revenue()(DateRange((datetime.date(2000, 1, 1), datetime.date(2000, 1, 31)))).__next__() is None

# Generated at 2022-06-12 05:49:10.389975
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountFactory
    from .module import commands, Module
    from .others import GLAccount
    from .repositories import Repository
    from .types import Event
    from ..commons.times import now
    from ..commons.unitofwork import UnitOfWork
    from ..commons.zeitgeist import DateRange, today

    ## Set up:
    module = Module()
    unitofwork = UnitOfWork(Repository(module))
    unitofwork.begin()

    ## Test:
    with raises(AssertionError) as err:
        # Add the journal entries:
        journal = JournalEntry(today, "Test", None)
        journal.post(today, AccountFactory.create(GLAccount.CASH), Amount(1))

# Generated at 2022-06-12 05:49:19.334313
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    def testpost(acctype: AccountType, quantity, expectedDirection: Direction):
        account = Account("ACCT", acctype)
        posting = JournalEntry("DESC", "SRC")
        posting.post(date.today(), account, quantity)
        assert posting.postings[0].direction == expectedDirection

    testpost(AccountType.ASSETS, -7, Direction.DEC)
    testpost(AccountType.ASSETS, 7, Direction.INC)
    testpost(AccountType.EXPENSES, -7, Direction.INC)
    testpost(AccountType.EXPENSES, 7, Direction.DEC)

    testpost(AccountType.EQUITIES, -7, Direction.DEC)
    testpost(AccountType.EQUITIES, 7, Direction.INC)
    test

# Generated at 2022-06-12 05:49:24.158180
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import today, this_year

    class Reader(ReadJournalEntries[_T]):

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return []

    assert list(Reader()(this_year)) == []
    assert list(Reader()(today)) == []

# Generated at 2022-06-12 05:49:31.910009
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    # Arrange
    journal = JournalEntry(date=datetime.date.today(), description="salary")
    # Act
    journal.post(datetime.date.today(), Account('debit_account', AccountType.EXPENSES), 10000)
    journal.post(datetime.date.today(), Account('credit_account', AccountType.EQUITIES), 10000)
    # Assert
    assert journal.postings[0].is_debit == True
    assert journal.postings[0].is_credit == False
    assert journal.postings[1].is_debit == False
    assert journal.postings[1].is_credit == True


# Generated at 2022-06-12 05:49:40.830975
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass
    from datetime import date
    from typing import List, Optional
    from .accounts import Account, AccountType, _Account

    from .journal import _JournalEntry, JournalEntry, Posting, ReadJournalEntries

    @dataclass(frozen=True)
    class JournalEntrySource:
        pass

    @dataclass(frozen=True)
    class JournalEntry(JournalEntry):
        """
        Provides a journal entry model.
        """

        #: Business object as the source of the journal entry.
        source: JournalEntrySource = field(init=False)

        @property
        def source(self) -> JournalEntrySource:
            """
            Business object as the source of the journal entry.
            """
            return self.source


# Generated at 2022-06-12 05:49:51.026674
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account

    # GIVEN an entry with a empty list of postings
    entry = JournalEntry(datetime.date(2020, 1, 1), "", None)

    # WHEN I post a debit (+100) and then a credit (-100)
    entry.post(datetime.date(2020, 1, 1), Account.ASSET_CASH, +100)
    entry.post(datetime.date(2020, 1, 1), Account.REVENUE, -100)

    # THEN the entry has two postings with credit and debit equal
    assert len(entry.postings) == 2
    total_debit = isum(i.amount for i in entry.postings if i.is_debit)
    total_credit = isum(i.amount for i in entry.postings if i.is_credit)
    assert total

# Generated at 2022-06-12 05:50:07.878891
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class Fuel(object):
        def __init__(self, description: str, fuel_type: str, quantity: Quantity, total_amount: Amount):
            self.description = description
            self.fuel_type = fuel_type
            self.quantity = quantity
            self.total_amount = total_amount

    from .accounts import Account

    ACCOUNTS = {
        "Fuel Expenses": Account("Fuel Expenses", AccountType.EXPENSES),
        "Fuel Sales": Account("Fuel Sales", AccountType.REVENUES),
        "Cash": Account("Cash", AccountType.ASSETS),
    }

    def test_validate_journal_entry(journal_entry: JournalEntry[Fuel], accounts: Dict[str, Account]) -> None:
        journal_entry.validate()


# Generated at 2022-06-12 05:50:18.034090
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    '''
    All validations are tested: description is not-none, necessary fields are present,
    fields are of expected types and proper amount of postings result from
    posting function.
    '''
    from datetime import date
    from ..books.accounts import Account, AccountType

    # First check a valid description
    description = "This is a description"
    journal = JournalEntry(date(2020,1,1), description, 1)
    assert journal.description == description

    # Check for the empty strings in description
    description = " "
    journal = JournalEntry(date(2020,1,1), description, 1)
    assert journal.description == description

    # Check if account is of Account type
    journal = JournalEntry(datetime.date(2020,1,1), "This is a description", 1)

# Generated at 2022-06-12 05:50:23.476011
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import zeitgeist as zg

    @dataclass(frozen=True)
    class DummySource:
        pass

    def read_journal(period: DateRange) -> Iterable[JournalEntry[DummySource]]:
        return (
            JournalEntry(
                date=zg.now().date,
                description=f"Journal entry {i}",
                source=DummySource(),
            )
            for i in range(2)
        )

    ReadJournalEntries.__call__(read_journal, zg.DateRange.fromToday())

# Generated at 2022-06-12 05:50:27.264669
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    journal_read: ReadJournalEntries[object] = read_journal_entries
    journal_read(DateRange.from_now(10))

# Generated at 2022-06-12 05:50:28.361961
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert issubclass(ReadJournalEntries, Protocol)

# Generated at 2022-06-12 05:50:38.923417
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry(date=datetime.date.today(), description="This is a test", source="A")

    # The source field is only used for tracking purposes and is not part of the actual posted entry.
    # It is therefore not included in the test.
    je.post(date=datetime.date.today(), account=Account(name='Equities:Capital'), quantity=Quantity(100))
    je.post(date=datetime.date.today(), account=Account(name='Assets:Cash'), quantity=Quantity(-100))

    assert [i.amount for i in je.increments] == [Quantity(100)]
    assert [i.amount for i in je.decrements] == [Quantity(100)]
    assert [i.amount for i in je.debits] == [Quantity(100)]

# Generated at 2022-06-12 05:50:46.475270
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType
    from .books import Journal

    # Given: A journal
    journal = Journal(...)

    # When: A function to read journal entries
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[None]]:
        return journal.read(period)

    # Then: It is a valid instance of ReadJournalEntries
    ReadJournalEntries(read_journal_entries)

# Generated at 2022-06-12 05:50:57.402989
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import itertools
    @dataclass(frozen=True)
    class T:
        pass

    @dataclass(frozen=True)
    class J:
        pass

    t = T()
    j = J()

# Generated at 2022-06-12 05:51:07.200625
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    class Src(Generic[_T]):
        pass
    obj1 = JournalEntry(datetime.date(2020, 1, 1),"desc",Src())
    obj1.post(datetime.date(2020, 1, 1),Account(AccountType.ASSETS, "a1"), Quantity(10))
    obj1.post(datetime.date(2020, 1, 1),Account(AccountType.EQUITIES, "e1"), Quantity(10))
    try:
        obj1.validate()
    except:
        raise AssertionError("JournalEntry Validate Failed")
    obj2 = JournalEntry(datetime.date(2020, 1, 1),"desc",Src())
    obj2.post(datetime.date(2020, 1, 1),Account(AccountType.ASSETS, "a1"), Quantity(9))

# Generated at 2022-06-12 05:51:17.945284
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date, timedelta
    from unittest import TestCase, TestSuite, TextTestRunner, mock
    from .accounts import open_account

    def test_run():
        from ..commons.zeitgeist import date_range
        td1, td2, td3 = timedelta(days=1), timedelta(days=2), timedelta(days=3)
        d1, d2, d3 = date.today() - td3, date.today() - td2, date.today() - td1
        a1, a2 = open_account("A1", "Account 1", AccountType.ASSETS), open_account("A2", "Account 2", AccountType.ASSETS)
        pe = mock.patch("autochartist.domain.ledger.journal.JournalEntry.post")

# Generated at 2022-06-12 05:51:26.880332
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date

    result = ReadJournalEntries()(None)  # type: ignore[invocation]
    assert isinstance(result, Iterable)
    assert result == iter([])



# Generated at 2022-06-12 05:51:37.728971
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .books import Book
    from .accounts import AccountType
    from .datasources import DummyDataSource

    ds = DummyDataSource()
    ds.init_books()

    book = Book(journal=ds.journal_entries)
    _ = book.create_account(AccountType.EXPENSES, "Foo", description="Bar")
    _ = book.create_account(AccountType.ASSETS, "FOO", description="BAR")
    _ = book.create_account(AccountType.EXPENSES, "FOO", description="BAR")
    _ = book.create_account(AccountType.EQUITIES, "FOO", description="BAR")
    _ = book.create_account(AccountType.LIABILITIES, "FOO", description="BAR")

    journal_entry: JournalEntry = Journal

# Generated at 2022-06-12 05:51:48.077650
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import datetime
    from forexconnect import ForexConnect
    from .accounts import AccountRepository

    account_repository = AccountRepository()

    _ = account_repository.find('Assets/Cash')
    _ = account_repository.find('Assets/Market/Forex/USD')
    _ = account_repository.find('LIABILITIES/Market/Forex/USD')

    # Create a function that reads journal entries from ForexConnect.
    read_journal_entries = ReadJournalEntries.__getitem__(
        ForexConnect,
        ReadJournalEntries,
        (account_repository.find,))

    # Read all journal entries

# Generated at 2022-06-12 05:51:51.905401
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je = JournalEntry[str](datetime.date.today(), 'desc', 'source')
    je.post(datetime.date.today(), Account("Assets:Cash"), Quantity(Amount("10.00")))
    assert len(je.postings) == 1
    assert je.postings[0].direction == Direction.INC

# Generated at 2022-06-12 05:51:58.879083
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
	je = JournalEntry(datetime.date.today(), "test", None)
	je.post(datetime.date.today(), Account("1", "test"), Quantity(1))
	assert len(je.postings) == 1
	je.post(datetime.date.today(), Account("1", "test"), Quantity(-1))
	je.post(datetime.date.today(), Account("2", "test"), Quantity(-1))
	assert len(je.postings) == 2

# Generated at 2022-06-12 05:52:08.457503
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Create a journal entry
    j1 = JournalEntry[int](datetime.date(2019, 4, 1), "Description", 1)
    
    # create a date
    date = datetime.date(2019, 4, 1)
    # create an account
    a1 = Account("Asset", AccountType.ASSETS)
    
    # Post a positive quantity
    j1.post(date, a1, Quantity(10))
    
    # check if a positive quantity was posted
    assert len(j1.postings) == 1
    # check if the quantity was posted to the correct account
    assert isinstance(j1.postings[0].account, Account)
    assert j1.postings[0].account.name == "Asset"
    assert j1.postings[0].amount == Amount(10)
    
    # Post a

# Generated at 2022-06-12 05:52:10.412514
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ReadJournalEntries.__call__.__annotations__

# Generated at 2022-06-12 05:52:19.701468
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .ledgers import LedgerAccount
    from .subledgers import SubledgerAccount
    je = JournalEntry(
        date=datetime.date.today(),
        description="This is a test journal entry",
        source={'name': 'John Doe'}
    )
    je.post(
        date=datetime.date.today(),
        account=LedgerAccount(
            name='Assets',
            type=AccountType.ASSETS
        ),
        quantity=100000000
    )
    assert je.postings[0].direction == Direction.INC
    assert je.postings[0].is_debit == True
    assert je.postings[0].is_credit == False

# Generated at 2022-06-12 05:52:29.845044
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import accounts
    from .exchange import Exchanger, ExchangeRate
    from .functions import open_journal_entry
    from .ledgers import Ledger
    from .transactions import PaymentTxn

    ## Setup:
    ledger = Ledger()
    entry = open_journal_entry(date(2020, 1, 1), "First entry.")
    entry.post(date(2020, 1, 1), accounts.cash, 100)
    entry.post(date(2020, 1, 1), accounts.revenues, -100)
    entry.validate()
    ledger.append(entry)

    ## Test:
    entries = ledger(DateRange.from_year(2020))
    assert list(entries) == [entry]

# Generated at 2022-06-12 05:52:32.189730
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry[object](datetime.date(2020, 1, 1), "This is a stub journal entry with no postings")
    j.validate()

# Generated at 2022-06-12 05:52:52.791155
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account, AccountTree
    from .general import GeneralLedger
    from .opening import OpeningBalance
    from .conversion import to_ledger_owl

    journal_entry = JournalEntry[str](date='2020-01-01', description='Test journal entry', source='Source')
    journal_entry.post('2020-01-01', Account('Assets', 'Cash', 'Cash on hand'), 1)
    journal_entry.post('2020-01-01', Account('Revenues', 'Revenue', 'Sales'), -1)
    journal_entry.validate()

# Generated at 2022-06-12 05:52:57.928734
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Unit test method __call__ of class ReadJournalEntries
    """
    class ReadJournalEntriesImpl(_T):
        """
        Implmentation of class ReadJournalEntries
        """
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass
    assert(ReadJournalEntriesImpl())

# Generated at 2022-06-12 05:52:58.710438
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    #TODO
    pass

# Generated at 2022-06-12 05:53:11.499950
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import Callable, Dict
    from ..commons.numbers import ZERO
    from ..commons.others import makeguid
    from .accounts import Account
    from .ledger import Ledger
    from .transactions import Transaction

    def make_account(name: str) -> Account:
        return Account(
            name=name,
            number=name,
            short_name=name,
            type=AccountType.ASSETS,
            description=f"Account {name}",
            balance=ZERO,
            balance_previous_year=ZERO,
            open_periods=[],
        )


# Generated at 2022-06-12 05:53:17.602755
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    timestamp = datetime.datetime.now()
    posting = Posting(journal = JournalEntry(date = timestamp, description = "Testing post method", source = None, postings = []),
                                date = timestamp, account = Account("TEST", AccountType.REVENUES), direction = Direction.INC, amount = Amount(1.00))
    assert posting.is_debit == False


# Generated at 2022-06-12 05:53:24.447052
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    jn_entry = JournalEntry(datetime.date.today(), 'Bye Bye', [], [])
    jn_entry.post(datetime.date.today(), Account('101', AccountType.ASSETS, '101', 'cash', 'Cash'), 10000)
    jn_entry.post(datetime.date.today(), Account('201', AccountType.EXPENSES, '201', 'sales', 'Sales'), -10000)
    jn_entry.validate()

# Generated at 2022-06-12 05:53:28.422672
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # fn = ...
    # entries = fn(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)))
    # assert ...
    return

# Generated at 2022-06-12 05:53:32.337406
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(datetime.datetime(2020, 10, 10), "", [""])
    j.post(datetime.datetime(2020, 10, 10), "assets", 10)

    assert len(j.increments) == 1


# Generated at 2022-06-12 05:53:42.758676
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ddddd.commons.zeitgeist import DateRange

    class Src:
        pass

    journal = JournalEntry(
        datetime.date.today(),
        "test",
        Src(),
    ).post(
        datetime.date.today(),
        Account(AccountType.ASSETS, "test"),
        1000,
    ).post(
        datetime.date.today(),
        Account(AccountType.EXPENSES, "test"),
        1000,
    )

    def read(period: DateRange) -> Iterable[JournalEntry[_T]]:
        yield journal

    read_journal_entries: ReadJournalEntries[_T] = read

    assert list(read_journal_entries(DateRange(datetime.date.today(), datetime.date.today()))) == [journal]

# Generated at 2022-06-12 05:53:54.093445
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Create two accounts
    accounts = []
    account_id = 0

    def new_account():
        nonlocal account_id
        account_id += 1
        return Account(account_id, "Test account")

    # Create JournalEntry
    def new_journal_entry(description: str, debit: Quantity, credit: Quantity) -> JournalEntry:
        j = JournalEntry(datetime.date(2020, 1, 1), description, None)
        j.post(datetime.date(2020, 1, 1), new_account(), debit)
        j.post(datetime.date(2020, 1, 1), new_account(), credit)
        return j

    j = new_journal_entry("Test journal entry", 1234, 1234)
    assert j.validate() is None


# Generated at 2022-06-12 05:54:43.460415
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    try:
        je = JournalEntry("Date", "Bollo", "Money", Guid)
        je.post("Date", "Account", 1)
        je.post("Date", "Account", 1)
        je.validate()
    except AssertionError:
        pass
    else:
        assert False, "AssertionError should be raised"

# Generated at 2022-06-12 05:54:55.524428
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    my_acct = Account("My Acct", AccountType.LIABILITIES)
    je1 = JournalEntry(datetime.date(2020, 8, 1), "Buy orange", 1)
    je2 = JournalEntry(datetime.date(2020, 8, 1), "Buy orange", 1)

    je1.post(datetime.date(2020, 8, 1), my_acct, 10010)
    je1.post(datetime.date(2020, 8, 1), my_acct, -10010)

    je2.post(datetime.date(2020, 8, 1), my_acct, 10010)
    je2.post(datetime.date(2020, 8, 1), my_acct, -10010)

    assert je1.postings == je2.postings



# Generated at 2022-06-12 05:54:59.333109
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @ReadJournalEntries
    def read_journal_entries(period: DateRange):
        pass
    read_journal_entries(DateRange())
    print("passed")


# Generated at 2022-06-12 05:55:09.331676
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Test cases
    testcases = [
        {"date": datetime.date(2020, 1, 2), "description": "Test journal entry", 
        "source": None, "postings": [], "account": None, "guid": None,
        "date_posting": datetime.date(2020, 1, 2), "account_posting": None, "quantity_posting": None,
        "direction": Direction.INC, "amount": None, "is_debit": True, "is_credit": False, "increments": [], 
        "decrements": [], "debits": [], "credits": []},
    ]

    # Run test cases
    for test in testcases:
        journal_entry = JournalEntry(test["date"], test["description"], test["source"])

# Generated at 2022-06-12 05:55:16.726613
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je1 = JournalEntry[str](datetime.date(2020, 9, 24), "hello", "world")
    je1.post(datetime.date(2020, 9, 24), Account(AccountType.ASSETS, "a", "Cash"), Quantity(-100))
    je1.post(datetime.date(2020, 9, 24), Account(AccountType.REVENUES, "r", "Revenue"), Quantity(-100))
    assert je1.postings[0].direction == Direction.DEC
    assert je1.postings[0].amount == -100
    assert je1.postings[0].is_debit
    assert je1.postings[1].is_credit
    je1.validate()

# Generated at 2022-06-12 05:55:25.784499
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(
        date=datetime.date(2019, 7, 1),
        description="Journal Entry",
        source="Business Source",
    )
    journal.post(
        date=datetime.date(2019, 7, 1),
        account=Account(name=1, type=AccountType.ASSETS),
        quantity=100,
    )
    # call post method
    journal.post(
        date=datetime.date(2019, 8, 1),
        account=Account(name=2, type=AccountType.ASSETS),
        quantity=-50,
    )
    # increment and decrement events
    journal.post(
        date=datetime.date(2019, 8, 1),
        account=Account(name=3, type=AccountType.REVENUES),
        quantity=25,
    )
   

# Generated at 2022-06-12 05:55:35.550999
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    @dataclass(frozen=True)
    class Ledger:
        pass

    le = Ledger()

    je = JournalEntry[Ledger]
    je = je(date=datetime.date(2020, 1, 1), description="test journal entry", source=le)
    assert not je.postings
    je = je.post(date=datetime.date(2020, 1, 1), account=Account(name="ACC", type=AccountType.ASSETS), quantity=100)
    assert len(je.postings) == 1
    assert je.postings[0].date == datetime.date(2020, 1, 1)
    assert je.postings[0].account == Account(name="ACC", type=AccountType.ASSETS)
    assert je.postings[0].amount == Amount(100)
    assert je.postings

# Generated at 2022-06-12 05:55:44.460791
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from . import employee

    TestReadJournalEntries = ReadJournalEntries

    #: Test data.

# Generated at 2022-06-12 05:55:52.865191
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Check that the following journal entry is valid
    je = JournalEntry(
        date = datetime.date.today(),
        description = "This is a valid journal entry",
        source = "JournalEntry.validate",
        postings = [Posting(
                journal = je,
                date = datetime.date.today(),
                account = "liabilities:bank:current",
                direction = Direction.INC,
                amount = Amount(40.0)
            )])
    je.validate()
    # Check that the following journal entry is invalid

# Generated at 2022-06-12 05:56:04.551539
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Tests the __call__ method of ReadJournalEntries.
    """
    # Setup
    @dataclass(frozen=True)
    class Source:
        pass

    @dataclass(frozen=True)
    class PostingSource(Source):
        pass

    @dataclass(frozen=True)
    class ProposalSource(Source):
        pass

    @dataclass(frozen=True)
    class ProposalEntry(JournalEntry[ProposalSource]):
        pass

    @dataclass(frozen=True)
    class ProposalPosting(Posting[PostingSource]):
        pass

    @dataclass(frozen=True)
    class MyJournalEntries:
        entries: Iterable[JournalEntry[Source]] = field(default_factory=list)

    my_journal

# Generated at 2022-06-12 05:57:02.198530
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Setup:
    def _read(dr: DateRange) -> Iterable[JournalEntry]:
        return [JournalEntry(datetime.date(2020, 1, 1), "A", "")]

    # Exercise & Verify:
    assert tuple(_read(DateRange.from_string("20200101 to 20200102"))) == \
           (JournalEntry(datetime.date(2020, 1, 1), "A", ""),)

# Generated at 2022-06-12 05:57:06.140940
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Unit test for method __call__ of class ReadJournalEntries
    """
    def test_function(period: DateRange) -> Iterable[JournalEntry[int]]:
        pass

    from ..commons.zeitgeist import DateRange

    assert isinstance(test_function, ReadJournalEntries)

# Generated at 2022-06-12 05:57:15.446236
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    try:
        journal = JournalEntry(datetime.date.fromisoformat("2020-01-01"), "Test", None)
        journal.post(datetime.date.fromisoformat("2020-01-01"), Account.fromstring("Assets:Cash"), 100)
        journal.post(datetime.date.fromisoformat("2020-01-01"), Account.fromstring("Expenses:Repairs:Equipment"), -100)
        journal.validate()
    except Exception as e:
        print(e)
        print("Failed to validate simple journal")

# Generated at 2022-06-12 05:57:24.638161
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
  # Create entries
  je = JournalEntry[int](date = datetime.date.today(), description = "Sample Entry", source = 3)
  debit_account = Account(
      guid = makeguid(),
      type = AccountType.REVENUES,
      name = "Debit Account",
      path = "Debit Path",
      root_path = "Debit Root Path")
  credit_account = Account(
      guid = makeguid(),
      type = AccountType.EXPENSES,
      name = "Credit Account",
      path = "Credit Path",
      root_path = "Credit Root Path")
  je.post(date = datetime.date.today(), account = debit_account, quantity = Quantity(10))
  je.post(date = datetime.date.today(), account = credit_account, quantity = Quantity(10))
 

# Generated at 2022-06-12 05:57:36.005223
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    First test for journal entry
    """
    from .accounts import Account, AccountType
    from .periods import Period
    try:
        from datetime import date
    except ImportError:
        from backports.datetime_fromisoformat import MonkeyPatch
        MonkeyPatch.patch_fromisoformat()
        from datetime import date
    
    # Method to be tested
    def validate(self):
        total_debit = 0
        total_credit = 0
        total_debit = sum(i.amount for i in self.debits)
        total_credit = sum(i.amount for i in self.credits)
        assert total_debit == total_credit, f"Total Debits and Credits are not equal: {total_debit} != {total_credit}"
        
    # Creates asset account

# Generated at 2022-06-12 05:57:45.775915
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import makeaccount
    from datetime import date

    acc1000 = makeaccount("1000", "Assets")
    acc1100 = makeaccount("1100", "Accounts Receivable")
    acc3200 = makeaccount("3200", "Services")
    acc7000 = makeaccount("7000", "Credit Card Payable")
    acc8001 = makeaccount("8001", "Capital")
    acc8003 = makeaccount("8003", "Revenues")
    acc8030 = makeaccount("8030", "Sales")


    payment_journal = JournalEntry(date(2020, 5, 31), "Monthly payment to credit card", None)
    payment_journal.post(date(2020, 5, 31), acc1000, -Amount(1750)) 

# Generated at 2022-06-12 05:57:57.410229
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.others import now
    from ..commons.zeitgeist import today
    from ..model.accounts import Account, AccountType
    from ..model.journals import ReadJournalEntries, JournalEntry

    def read_entries(period: DateRange) -> Iterable[JournalEntry[int]]:
        aa = Account(AccountType.ASSETS, "Cash")
        ra = Account(AccountType.REVENUES, "Sales")

# Generated at 2022-06-12 05:58:02.014421
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    print(">>> test_ReadJournalEntries___call__ called.")
    class Test(ReadJournalEntries[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass
    Test()
    print(">>> test_ReadJournalEntries___call__ ran.")

test_ReadJournalEntries___call__()

# Generated at 2022-06-12 05:58:12.650570
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class _MockType:
        pass

    mock_source: _MockType = _MockType()
    mock_postings: List[Posting[object]] = []
    mock_journal: JournalEntry[object] = JournalEntry(
        datetime.date(2020, 10, 18),
        "Test Journal Entry",
        mock_source,
        mock_postings,
    )
    mock_postings.append(
        Posting(
            mock_journal,
            datetime.date(2020, 10, 18),
            Account(AccountType.EQUITIES, "Test", "Test Account"),
            Direction.INC,
            Amount(1234),
        )
    )

# Generated at 2022-06-12 05:58:22.667321
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import AccountType

    def get_read_journal_entries() -> ReadJournalEntries[int]:
        def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[int]]:
            yield JournalEntry(date(2018, 1, 1), "Description", 1, [
                Posting(None, date(2018, 1, 1), Account(AccountType.ASSETS, "Assets", "Operating"), Direction.INC, Amount(100)),
                Posting(None, date(2018, 1, 1), Account(AccountType.REVENUES, "Revenues", "Operating"), Direction.DEC, Amount(100)),
            ])