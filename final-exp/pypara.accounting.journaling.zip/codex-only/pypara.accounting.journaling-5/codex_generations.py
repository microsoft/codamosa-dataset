

# Generated at 2022-06-24 00:57:44.926727
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(JournalEntry(datetime.date(2018, 1, 1), "Desc", "Source"),
                 datetime.date(2018, 1, 1),
                 Account("Account", AccountType.ASSETS),
                 Direction.INC,
                 Amount(1))
    p2 = Posting(JournalEntry(datetime.date(2018, 1, 1), "Desc", "Source"),
                 datetime.date(2018, 1, 1),
                 Account("Account", AccountType.ASSETS),
                 Direction.INC,
                 Amount(1))

    assert p1 == p2


# Generated at 2022-06-24 00:57:45.549692
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    pass

# Generated at 2022-06-24 00:57:55.962800
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import Account
    #
    a=Account("Account 1", AccountType.EXPENSES)
    a2=Account("Account 2", AccountType.EXPENSES)
    je1=JournalEntry("0001", "Journal Evet 1", "Source 1")
    je2=JournalEntry("0002", "Journal Evet 2", "Source 2")
    p1=Posting(je1, datetime.date(2019, 1, 2), a, Direction.INC, Amount.from_quantity(1000))
    p2=Posting(je1, datetime.date(2019, 1, 2), a, Direction.INC, Amount.from_quantity(1000))
    p3=Posting(je1, datetime.date(2019, 1, 2), a2, Direction.INC, Amount.from_quantity(1000))
    p4

# Generated at 2022-06-24 00:58:06.021648
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # verify dataclass fields
    assert hasattr(ReadJournalEntries, '__annotations__') == True
    assert hasattr(ReadJournalEntries.__call__, '__annotations__') == True
    assert hasattr(ReadJournalEntries.__call__.__annotations__, '__annotations__') == True
    assert hasattr(ReadJournalEntries.__call__.__annotations__.__annotations__, '__getitem__') == True
    assert hasattr(ReadJournalEntries.__call__.__annotations__.__annotations__.__getitem__, '__call__') == True
    assert hasattr(ReadJournalEntries.__call__.__annotations__.__annotations__.__getitem__.__call__, '__annotations__') == True

# Generated at 2022-06-24 00:58:07.375785
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    je = JournalEntry("source")
    je.source = "source"

# Generated at 2022-06-24 00:58:18.190995
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class Income:
        def __init__(self, description: str = "", account: Account = Account(""), amount: Amount = Amount(0)):
            self.description = description
            self.account = account
            self.amount = amount

        def __str__(self):
            return f"{self.__class__.__name__}{{description={self.description}, account={self.account}, amount={self.amount}}}"

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 10))
    income1 = Income("Income1", Account("A1"), Amount(100))
    income2 = Income("Income1", Account("A1"), Amount(100))
    income3 = Income("Income3", Account("A2"), Amount(100))

# Generated at 2022-06-24 00:58:28.282826
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .ledgers import Ledger, LedgerEntryType
    from .books.general import GeneralLedgerBook, GeneralLedgerBookEntry

    journal_entry = JournalEntry[None]()
    for i in range(7):
        journal_entry.post(datetime.date.today(), Account("a" + str(i)), Amount(i))
    for i, p in enumerate(journal_entry.postings):
        assert p.journal == journal_entry, f"JournalEntry::post: [{i}] p.journal"
        assert p.date == datetime.date.today(), f"JournalEntry::post: [{i}] p.date"
        assert p.account == Account("a" + str(i)), f"JournalEntry::post: [{i}] p.account"

# Generated at 2022-06-24 00:58:29.845812
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    with raises(TypeError):
        del JournalEntry.description

# Generated at 2022-06-24 00:58:33.932869
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    def _hash_test(x,y):
        assert hash(x) == hash(y)

    _hash_test(JournalEntry(datetime.date(2020, 1, 1), "Description", None, []),
               JournalEntry(datetime.date(2020, 1, 1), "Description", None, []))

# Generated at 2022-06-24 00:58:38.532545
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal = JournalEntry[None]("2019-11-01", "Desc...", None)
    posting = Posting(journal, "2019-11-01", "Assets:A:B:C", Direction.INC, 100)
    hash({posting})
    a = {posting}
    b = {posting}
    assert (hash(posting) == hash(posting))
    assert(a == b)



# Generated at 2022-06-24 00:58:45.743049
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    journal = JournalEntry(date=datetime.date.today(), description="description", source="source")
    date = datetime.date.today()
    account = Account(name="name", code="code", type=AccountType.ASSETS)
    direction = Direction.INC
    amount = Amount(10)

    posting1 = Posting(journal=journal, date=date, account=account, direction=direction, amount=amount)
    posting2 = Posting(journal=journal, date=date, account=account, direction=direction, amount=amount)

    assert posting1 == posting2



# Generated at 2022-06-24 00:58:52.484815
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from typing import cast

    from .accounts import Account, AccountType

    from .testing.accounts import create_ledger

    from .testing.journal import DummySourceOfJournalEntries

    # Create a ledger:
    ledger = create_ledger()

    # Create the journal entries reader:
    dummy_source = DummySourceOfJournalEntries()
    read_journal_entries = ReadJournalEntries.__getitem__(
        None, {cast(Account, ledger["Sales"]), cast(Account, ledger["Opening"])}
    )
    read_journal_entries = ReadJournalEntries.__call__(
        None, dummy_source, datetime.date(2020, 6, 1), datetime.date(2020, 7, 31)
    )


# Generated at 2022-06-24 00:58:53.507433
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    f = Posting.__hash__
    pass


# Generated at 2022-06-24 00:59:01.202063
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Setup:
    @dataclass(frozen=True)
    class AccountDetails:
        date: datetime.date
        account: Account
        quantity: Quantity

    @dataclass(frozen=True)
    class BusinessObject:
        description: str
        postings: List[AccountDetails]


# Generated at 2022-06-24 00:59:08.641373
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Case 1: 2 journal entries with different dates, descriptions and guid
    j1 = JournalEntry[str](datetime.Date(1, 1, 1), "foo", "bar")
    j2 = JournalEntry[str](datetime.Date(1, 1, 2), "foo1", "bar1")
    hash(j1) == hash(j2)

    # Case 2: 2 journal entries with the same dates, descriptions and guid

    j3 = JournalEntry[str](datetime.Date(1, 1, 1), "foo", "bar")
    j4 = JournalEntry[str](datetime.Date(1, 1, 1), "foo", "bar")
    hash(j3) == hash(j4)

    # Case 3: 2 journal entries with different dates, same descriptions and same guid

# Generated at 2022-06-24 00:59:15.081385
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    test = 0
    test_journal_info = JournalEntry(None,None,None,None)
    expected = '<JournalEntry(date=None, description=None, source=None, postings=None, guid=None)>'
    result = test_journal_info.__repr__()
    assert result == expected

# Generated at 2022-06-24 00:59:18.105528
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    je = JournalEntry
    assert not hasattr(je, "_journal")
    je._journal = "journal"
    assert hasattr(je, "_journal")
    delattr(je, "_journal")
    assert not hasattr(je, "_journal")


# Generated at 2022-06-24 00:59:28.077025
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    with pytest.raises(AttributeError):
        Posting(None, None, None, None, None).__delattr__('journal')
        Posting(None, None, None, None, None).__delattr__('date')
        Posting(None, None, None, None, None).__delattr__('account')
        Posting(None, None, None, None, None).__delattr__('direction')
        Posting(None, None, None, None, None).__delattr__('amount')
    with pytest.raises(AttributeError):
        Posting(None, None, None, None, None).__delattr__(None)

# Generated at 2022-06-24 00:59:37.821547
# Unit test for constructor of class Posting
def test_Posting():
    J = JournalEntry[str]("2020-05-01", "My Description", "My Source")
    J1 = J.post("2020-05-01", Account("My Account", AccountType.ASSETS), Quantity(1000.00))
    J2 = J.post("2020-05-01", Account("My Account", AccountType.EQUITIES), Quantity(-500.00))
    if J1 is None or J2 is None:
        pass
    else:
        assert J1.date == "2020-05-01", "Date assignment failed for 1st entry"
        assert J2.date == "2020-05-01", "Date assignment failed for 2nd entry"
        assert J1.description == "My Description", "Description assignment failed for 1st entry"
        assert J2.description == "My Description", "Description assignment failed for 2nd entry"


# Generated at 2022-06-24 00:59:45.398947
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    """
    Tests the constructor of `JournalEntry` class.
    """
    from datetime import date
    from ..commons.numbers import Amount
    from .accounts import Account

    # Initialize a journal entry
    je = JournalEntry[int](date(2018, 5, 20), "Test Posting", 0)
    assert je.date == date(2018, 5, 20)
    assert je.description == "Test Posting"
    assert je.source == 0
    assert je.is_debit


# Generated at 2022-06-24 00:59:51.696340
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account
    from .accounts import AccountType as at
    from .commons.numbers import Amount
    from .commons.zeitgeist import Date
    from .journal_entries import JournalEntry
    from .journal_entries import Posting
    from .journal_entries import Direction as d

    je = JournalEntry(Date(1,1,1), "test 1" , "test source")
    je.postings = [
        Posting(je, Date(1,1,1), Account("code 1", at.EQUITIES), d.INC, Amount(100)), 
        Posting(je, Date(1,1,1), Account("code 2", at.REVENUES), d.DEC, Amount(100)), 
    ]

    je.validate()

    # Todo: Run when https://github.

# Generated at 2022-06-24 00:59:59.638533
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Setup:

    # Execute:
    j1 = JournalEntry[None](datetime.date.today(), "desc1")
    j1.post(datetime.date.today(), Account(AccountType.ASSETS, "A1"), Quantity(100))
    j1.post(datetime.date.today(), Account(AccountType.ASSETS, "A2"), Quantity(100))
    j1.post(datetime.date.today(), Account(AccountType.LIABILITIES, "L1"), Quantity(-200))

    # Expect:
    assert j1.postings[0].amount == Amount(100)
    assert j1.postings[1].amount == Amount(100)
    assert j1.postings[2].amount == Amount(200)



# Generated at 2022-06-24 01:00:03.611427
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass
    # Create an instance of Journal Entry
    # Write a test to check the postings of the instance
    # assert that the direction of both the postings is INC and DEC respectively
    # assert that the amount of both the postings is the same (14)
    # assert that the account type of the INC posting is EQUITY and the account name is "Opening balances"
    # assert that the account type of the DEC posting is INCOME and the account name is "Dividends"

# Generated at 2022-06-24 01:00:08.957842
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from datetime import date
    from .accounts import Account
    from .currencies import Currency, USD
    from .units import Units
    from .numbers import Amount
    account = Account("Assets:Current:Cash", "Cash")
    posting = Posting(0, date.today(), account, Direction.INC, Amount(1, USD))
    assert hash(posting) == hash((posting.journal, posting.date, posting.account, posting.direction, posting.amount))


# Generated at 2022-06-24 01:00:16.020996
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Unit test for method __setattr__ of class JournalEntry
    """
    import datetime
    # Import the class to be tested
    from ..ledger.journal import JournalEntry, Posting
    # Define a mock function that returns None, by default
    def mock_makeguid():
        return None
    # Define a mock function that returns True, by default
    def mock_Account_type_eq_AccountType_ASSETS(self, other):
        return True
    # Import mock
    import unittest.mock as mock
    # Mock the function makeguid
    mock_makeguid_ = mock.Mock(side_effect=mock_makeguid)

# Generated at 2022-06-24 01:00:21.311948
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    je = JournalEntry(date=datetime.date(2020, 1, 1), description="Test entry", source='source')
    assert dir(je).count("_JournalEntry__guid")
    delattr(je, "guid")
    assert dir(je).count("_JournalEntry__guid") == 0

# Generated at 2022-06-24 01:00:26.614013
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    j1 = JournalEntry(date=datetime.date(2018, 7, 20), description="First journal", source=None, postings=[])
    j2 = JournalEntry(date=datetime.date(2018, 7, 20), description="First journal", source=None, postings=[])
    assert j1 == j2, "First JournalEntry test failed"
    j3 = JournalEntry(date=datetime.date(2018, 7, 20), description="First journal", source="First", postings=[])
    assert j1 != j3, "Second JournalEntry test failed"
    j4 = JournalEntry(date=datetime.date(2018, 7, 20), description="First journal", source="First", postings=[])
    assert j3 == j4, "Third JournalEntry test failed"

# Generated at 2022-06-24 01:00:32.964435
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import random
    import string
    import uuid
    from ..commons.zeitgeist import now
    from .accounts import Account, load_accounts

    accounts = load_accounts()
    assert len(accounts) > 2, "At least have: Cash, Bank, Equity."

    rvalues = random.choices(string.ascii_letters, k=random.randint(2, 10))

    def create_journal_entry() -> JournalEntry[str]:
        sample_range = DateRange.of(now() - datetime.timedelta(days=1), now())
        sample_date = sample_range.random_in_range

# Generated at 2022-06-24 01:00:43.456375
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account1 = Account("account1", AccountType.ASSETS)
    account2 = Account("account2", AccountType.REVENUES)

    journal_entry1 = JournalEntry(datetime.date(2020, 8, 2), "Test journal entry.", "source")
    journal_entry1.post(datetime.date(2020, 8, 2), account1, 100)
    journal_entry1.post(datetime.date(2020, 8, 2), account2, -100)

    journal_entry1.validate()

    ## A journal entry with no postings should result in 0.
    journal_entry2 = JournalEntry(datetime.date(2020, 8, 2), "Test journal entry.", "source")
    journal_entry2.validate()

    ## Adding a debit and credit of same amount to journal entry should result in 0.
    journal_entry

# Generated at 2022-06-24 01:00:54.817280
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from datetime import date
    from book_ledger.ledgers.enums import Direction
    from book_ledger.ledgers.accounts import Account, AccountType
    from book_ledger.ledgers.amounts import Amount, Quantity
    from book_ledger.ledgers.journal import JournalEntry, Posting
    a1 = Account("A1", AccountType.ASSETS)
    a2 = Account("A2", AccountType.EQUITIES)
    p1 = Posting(journal=JournalEntry(date=date(year=2019, month=10, day=15), description="D1", source="S1"), date=date(year=2019, month=10, day=15), account=a1, direction=Direction.INC, amount=Amount(Quantity(100)))

# Generated at 2022-06-24 01:01:05.741846
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .accounts import NewAccount, NewAccountType
    from .accounts import AccountCategory, DefaultAccountCategory
    from datetime import date
    from dataclasses import dataclass

    # Declare a dummy source
    @dataclass
    class DummySource:
        pass

    # Create sample journal entry
    dummy_source = DummySource()
    journal_entry = JournalEntry(date(2019,1,1), "This is a test journal entry", dummy_source)

    # Declare sample accounts
    cash = NewAccount(name="Cash", type=AccountType.ASSETS, category=AccountCategory.CASH)
    workinprogress = NewAccount(name="Work in progress", type=AccountType.ASSETS, category=AccountCategory.INVENTORY)

# Generated at 2022-06-24 01:01:09.803206
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    a = Posting(None, datetime.date.today(), None, None, None)
    b = Posting(None, datetime.date.today(), None, None, None)
    assert(hash(a) == hash(b))


# Generated at 2022-06-24 01:01:14.763302
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    j=JournalEntry()
    def _():
        del j.postings
        print(j.postings)
    try:
        _()
    except Exception as e:
        assert type(e)==AttributeError


# Generated at 2022-06-24 01:01:17.702154
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    d = datetime.datetime.now()
    e = JournalEntry[object](date=d, source=None, postings=[])
    assert e.date == d

# Generated at 2022-06-24 01:01:29.103284
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Unit test for method post of class JournalEntry.
    """

#    ledgers = Ledger()
#    journ = JournalEntry(datetime.date(2020, 5, 19))
#    journ.post(datetime.date(2020, 5, 19), Income, 10.0)
#    journ.post(datetime.date(2020, 5, 19), Revenue, -10.0)
#    journ.validate()
#    print(journ.increments)
#    print(journ.postings)
#    print(journ.guid)
#    print(len(journ.postings))
#    print(journ.credits)
#    print(journ.debits)
#    print(journ.decrements)
#    print(journ.date)
#

# Generated at 2022-06-24 01:01:29.989711
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    pass


# Generated at 2022-06-24 01:01:30.473471
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass

# Generated at 2022-06-24 01:01:36.287064
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    e = JournalEntry
    e1 = e(date = datetime.date(2020,1,1), description = "new year", source = "test", postings = [])
    assert e1.date == datetime.date(2020,1,1)
    assert e1.description == "new year"
    assert e1.source == "test"
    assert e1.postings == []
    assert e1.guid != None
    assert e1.increments == ()
    assert e1.decrements == ()
    assert e1.debits == ()
    assert e1.credits == ()



# Generated at 2022-06-24 01:01:39.816337
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting("journal", datetime.date(2019,10,1), "Account", -1, 100)) == \
           "Posting(journal, datetime.date(2019, 10, 1), 'Account', <Direction.DEC: -1>, 100)"


# Generated at 2022-06-24 01:01:49.849776
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from .accounts import Account
    from .books import Book
    from .parties import Party
    from .periods import Period
    from .transaction import Transaction

    b = Book(
        name="Test Book",
        fiscal_year=2019,
        periods=[Period(2019, 1, "Jan"), Period(2019, 2, "Feb")],
        parties=[Party("Ali")],
        accounts=[
            Account(AccountType.ASSETS, "cash", "Cash"),
            Account(AccountType.ASSETS, "bank", "Bank"),
            Account(AccountType.REVENUES, "fee", "Fee"),
            Account(AccountType.EXPENSES, "rent", "Rent"),
        ],
    )

    ## 01

# Generated at 2022-06-24 01:01:51.469915
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    pass



# Generated at 2022-06-24 01:01:55.978853
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    p = Posting(JournalEntry[None], datetime.date.today(), Account(AccountType.ASSETS, "Cash"), Direction.INC, Amount(200))
    assert p.__repr__() == 'Posting(journal=JournalEntry(date=2020-12-31, description=\'\', source=None, postings=[]), date=2020-12-31, account=Account(type=<AccountType.ASSETS: "ASSETS">, account=\'Cash\'), direction=<Direction.INC: 1>, amount=Amount(200))'

# Generated at 2022-06-24 01:02:00.183263
# Unit test for constructor of class Posting
def test_Posting():
    p = Posting(1, datetime.date.today(), 1, 1, 1)
    assert type(p.journal) == int
    assert type(p.date) == datetime.date
    assert type(p.account) == int
    assert type(p.direction) == int
    assert type(p.amount) == int

# Generated at 2022-06-24 01:02:09.410218
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Prepare data for this test
    date = datetime.date.fromisoformat("2020-05-08")
    description = "test"
    
    ACCOUNT_TYPE_ASSETS = AccountType.ASSETS.value
    ACCOUNT_TYPE_EQUITIES = AccountType.EQUITIES.value
    ACCOUNT_TYPE_LIABILITIES = AccountType.LIABILITIES.value
    ACCOUNT_TYPE_REVENUES = AccountType.REVENUES.value
    ACCOUNT_TYPE_EXPENSES = AccountType.EXPENSES.value


# Generated at 2022-06-24 01:02:20.959934
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    posting = Posting(3, datetime.date(2019, 12, 18), Account('1001', AccountType.ASSETS), Direction.INC, Amount(100))
    # journal = JournalEntry('JE1', datetime.date(2019, 12, 18), 'Payment for purchase of statuary', {'invoice': Invoice(['1001', '1002'], [100, 100])})
    journal = JournalEntry(datetime.date(2019, 12, 18), 'Payment for purchase of statuary', 0)
    journal.postings.append(posting)
    assert journal.date == datetime.date(2019, 12, 18)
    assert journal.description == 'Payment for purchase of statuary'
    assert journal.source == 0
    assert journal.postings[0].journal == 3

# Generated at 2022-06-24 01:02:26.297233
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal = JournalEntry[object](date=datetime.date.today(), description="Sample Journal Entry",
                                   source=object())
    account = Account(number="1234", name="Sample Account", type=AccountType.EXPENSES, 
                      is_active=True, description=None, parent=None)
    posting = Posting(journal=journal, date=datetime.date.today(), account=account, 
                      direction=Direction.DEC, amount=Amount(100))

    assert isinstance(posting.__hash__(), int)

# Generated at 2022-06-24 01:02:34.283343
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Given
    class TestSource:
        pass

    e = JournalEntry[TestSource](
        date=datetime.date(2020, 1, 1),
        description="Test Journal Entry for Unit Test",
        source=TestSource(),
    )
    e.post(datetime.date(2020, 1, 1), Account("ASSETS"), +10)
    e.post(datetime.date(2020, 1, 1), Account("REVENUES"), -10)

    # When
    e.validate()

    # Then
    pass

# Generated at 2022-06-24 01:02:38.099795
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Arrange
    date = datetime.date.today()
    description = "Rent paid for May, 2020"
    source = "Rent Expense"
    postings = []

    # Act
    journalEntry = JournalEntry(date, description, source, postings)

    # Assert
    assert journalEntry.date == date
    assert journalEntry.description == description
    assert journalEntry.source == source
    assert journalEntry.postings == postings

# Generated at 2022-06-24 01:02:47.785426
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from datetest import datetime, date
    from dataclasses import make_dataclass

    journal_origin = make_dataclass("Journal_origin", [("field1", str),("field2", str)])
    account_origin = make_dataclass("account_origin", [("field1", str),("field2", str)])

    # Variables
    journal_1 = journal_origin("A", "B")
    journal_2 = journal_origin("A", "B")
    account_1 = account_origin("A", "B")
    account_2 = account_origin("A", "B")
    date_1 = date(2019, 1, 1)
    date_2 = date(2019, 1, 2)
    date_1_fail = date(2019, 1, 2)

# Generated at 2022-06-24 01:02:52.423670
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from ..commons.others import makeguid
    test = JournalEntry[None]
    assert test.guid == makeguid()
    test.date = datetime.date.today()
    assert test.guid != makeguid()

# Generated at 2022-06-24 01:02:59.813935
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from datetime import datetime
    from datetime import date
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AssetAccount
    from .accounts import LiabilityAccount
    from .accounts import RevenueAccount
    from .accounts import ExpenseAccount
    from .accounts import EquityAccount
    journalentry = JournalEntry[str]()
    journalentry._date = date(2019, 4, 2)
    journalentry._description = "Bank deposit"
    journalentry._source = "Payment invoice"

# Generated at 2022-06-24 01:03:05.269140
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    '''
    Generate repr in case of Posting
    '''
    defined_object = Posting(Source(0,"Name",False,"on"), datetime.date(1,1,1), Account("Name"), Direction.DEC, Amount(3))
    assert defined_object == eval(repr(defined_object))


# Generated at 2022-06-24 01:03:06.386786
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert False == True


# Generated at 2022-06-24 01:03:10.626564
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    p = Posting(JournalEntry("2011/01/01", "Test"), "2011/02/01", Account("Cash", AccountType.ASSETS), Direction.INC)
    p.journal = 11
    assert p.journal == JournalEntry("2011/01/01", "Test")

# Generated at 2022-06-24 01:03:20.977859
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from ..commons.test.test_others import assert_hashable
    from .categories import Category
    from .accounts import Account, AccountType

    assert_hashable(JournalEntry[Category])

    #: @TODO: Should this be allowed? Or should the whole class be mutable?
    journal = JournalEntry(date=datetime.date(2019, 3, 31), description="Test", source=Category.of("expense"))
    journal.post(datetime.date(2019, 3, 31), Account.of(AccountType.EXPENSES, "expense_1"), +100)
    journal.post(datetime.date(2019, 3, 31), Account.of(AccountType.ASSETS, "asset_1"), -100)
    assert_hashable(journal)

# Generated at 2022-06-24 01:03:23.223376
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    _ = JournalEntry  # force `dataclasses`'s hook to execute.

# Generated at 2022-06-24 01:03:32.246687
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from datetime import date
    from .accounts import AccountType, account
    from .journal import (
        DateRange,
        JournalEntry,
        Posting,
        Direction,
        Amount,
        ReadJournalEntries,
    )


# Generated at 2022-06-24 01:03:37.731272
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    a = Posting(JournalEntry(), datetime.date.today(), Account("1"), Direction.INC, Amount(1))
    b = Posting(a.journal, a.date, a.account, a.direction, a.amount)
    assert a == b
    assert hash(a) == hash(b)

# Generated at 2022-06-24 01:03:38.618506
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 01:03:46.252411
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    """
    Tests implementation of method __eq__ of class Posting.
    """
    journal1 = JournalEntry[int]("2020-02-29", "Test Journal")
    journal2 = JournalEntry[int]("2020-02-29", "Test Journal")
    assert journal1.postings == journal2.postings
    assert journal1.post("2020-02-29", Account("Payroll Account"), Amount("100.0"))
    assert journal1.post("2020-02-29", Account("Cash"), Amount("100.0"))
    assert journal1.post("2020-02-29", Account("Cash"), Amount("200.0"))
    assert journal1.post("2020-02-29", Account("Cash"), Amount("200.0"))
    assert journal2.post("2020-02-29", Account("Payroll Account"), Amount("100.0"))

# Generated at 2022-06-24 01:03:47.004156
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    pass


# Generated at 2022-06-24 01:03:47.461353
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass

# Generated at 2022-06-24 01:03:47.906202
# Unit test for constructor of class Posting
def test_Posting():
    assert None == 1

# Generated at 2022-06-24 01:03:53.231313
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class Cls():
        def __init__(self, value):
            self.value = value

    a: ReadJournalEntries[Cls] = lambda x: []

# Generated at 2022-06-24 01:03:56.395043
# Unit test for constructor of class Posting
def test_Posting():
    je = JournalEntry('2019-04-01', 'This is for test', 'This is for source')
    je.post('2019-04-01', 'This is for test1', 123)
    je.validate()

# Generated at 2022-06-24 01:04:03.344831
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    je = JournalEntry[int](
        datetime.date(2019, 3, 1),
        "Sample Journal Entry",
        1,
    )

    p1 = Posting[int](
        je,
        datetime.date(2019, 3, 1),
        Account.for_type(AccountType.ASSETS, "Cash"),
        Direction.INC,
        Amount.of(1),
    )

    p2 = Posting[int](
        je,
        datetime.date(2019, 3, 1),
        Account.for_type(AccountType.REVENUES, "Sales"),
        Direction.DEC,
        Amount.of(1),
    )

    assert p1 == p1
    assert p1 != p2
    assert hash(p1) == hash(p1)

# Generated at 2022-06-24 01:04:05.246631
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    """
    Testing the constructor of class ReadJournalEntries
    :return:
    """
    pass

# Generated at 2022-06-24 01:04:12.933212
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import Account
    from .ledger import Ledger
    from .sources import create_expense_claim
    from dataclasses import asdict
    from datetime import date
    from hashlib import sha256
    from unittest import TestCase

    ## Define.
    class Test(TestCase):

        def test(self):
            ledger = Ledger()
            journal_entry = JournalEntry[None](date=date(2019, 8, 2), description="This is a test")

# Generated at 2022-06-24 01:04:17.014976
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    posting = Posting(None, datetime.date(2020, 1, 1), Account("Assets:Cash:JPY"), Direction.INC, Amount(10))
    assert hash(posting) == hash((posting.date, posting.account, posting.direction, posting.amount))


# Generated at 2022-06-24 01:04:18.425954
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    pass


# Generated at 2022-06-24 01:04:24.773450
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import Account
    from .journal import Direction
    from .journal import JournalEntry
    from .journal import Posting
    from datetime import date

    date = date(2020, 9, 20)
    account = Account("1000", "Cash")
    direction = Direction.INC
    amount = Amount(10000)
    posting = Posting(JournalEntry(date, "Description", object), date, account, direction, amount)

    expected = f"Posting({posting.date}, {posting.account}, {posting.direction}, {posting.amount})"

    assert posting.__repr__() == expected

# Generated at 2022-06-24 01:04:31.559869
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    _hash_ = hash("posting")
    _source = JournalEntry("2019-01-01", "description", "source")
    posting = Posting(_source, "2019-01-01", "account", Direction.INC, "amount")
    assert hash(posting) == _hash_ + hash(_source) + hash(posting.date) + hash(posting.account) + hash(posting.direction) + hash(posting.amount)

# Generated at 2022-06-24 01:04:41.381800
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType, Account

    class Foo:
        pass

    class Bar:
        pass

    foo = Foo()
    bar = Bar()

    def read_journal_entries_target(period: DateRange) -> Iterable[JournalEntry[object]]:
        yield JournalEntry(datetime.date(2010, 1, 1), "desc1", foo, [Posting(None, datetime.date(2010, 1, 1), Account("a2", AccountType.EQUITIES), Direction.INC, 10)])
        yield JournalEntry(datetime.date(2010, 1, 1), "desc2", bar, [Posting(None, datetime.date(2010, 1, 1), Account("a1", AccountType.EXPENSES), Direction.DEC, 10)])


# Generated at 2022-06-24 01:04:45.674818
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    obj1 = Posting(JournalEntry(), datetime.date(2020, 1, 1), Account("Account"), Direction.INC, Amount(10*10**18))
    obj2 = Posting(JournalEntry(), datetime.date(2020, 1, 1), Account("Account"), Direction.INC, Amount(10*10**18))

    assert hash(obj1) == hash(obj2)

# Generated at 2022-06-24 01:04:50.669899
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    post1 = Posting(None, None, None, None, None)
    post2 = Posting(None, None, None, None, None)
    assert post1 == post2


# Generated at 2022-06-24 01:04:53.323624
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    a = JournalEntry()
    del a.guid
    try:
        assert a.guid is None
    except AttributeError:
        pass


# Generated at 2022-06-24 01:05:05.605285
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from .accounts import Account
    from .books import Ledger, ProcessPayment

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[ProcessPayment]]:
        for journal in ledger.journal_entries:
            yield journal

    ledger = Ledger()
    assert ReadJournalEntries.__origin__ == Iterable
    assert ReadJournalEntries.__args__ == (JournalEntry[ProcessPayment],)
    assert ReadJournalEntries(ledger, period=DateRange.from_date(datetime.date(2019, 10, 1))) == ledger.journal_entries

    RJE = read_journal_entries
    assert RJE(ledger, period=DateRange.from_date(datetime.date(2019, 10, 1))) == ledger.journal_entries

    lst = list()
   

# Generated at 2022-06-24 01:05:09.225895
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # pylint: disable=too-few-public-methods,unused-variable
    class Foo:
        pass

    class Bar(ReadJournalEntries[Foo]):
        pass

    bar: ReadJournalEntries[Foo] = Bar()

# Generated at 2022-06-24 01:05:10.689411
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    journal = JournalEntry("date", "description", "source")
    assert journal.postings == []
    
    with pytest.raises(AttributeError):
        del journal.postings



# Generated at 2022-06-24 01:05:16.324536
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # arrange
    je=JournalEntry('journal','date','description','source','posting','guid')
    
    # act
    delattr(je,'postings')
    
    # assert
    assert not hasattr(je,"postings")

# Generated at 2022-06-24 01:05:19.511593
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert True


# Generated at 2022-06-24 01:05:29.088657
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(JournalEntry, datetime.date.today(), Account(""), Direction.INC, Amount(10)) == \
           Posting(JournalEntry, datetime.date.today(), Account(""), Direction.INC, Amount(10))
    assert Posting(JournalEntry, datetime.date.today(), Account(""), Direction.INC, Amount(10)) != \
           Posting(JournalEntry, datetime.date.today(), Account(""), Direction.INC, Amount(20))
    assert Posting(JournalEntry, datetime.date.today(), Account(""), Direction.INC, Amount(10)) != \
           Posting(JournalEntry, datetime.date.today(), Account(""), Direction.DEC, Amount(10))

# Generated at 2022-06-24 01:05:34.699082
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """
    Unit tests to validate the method `__setattr__` of class `Posting`.
    """
    # Arrange
    # Act
    # Assert
    # TODO: Implement unit test `test_Posting___setattr__`

# Generated at 2022-06-24 01:05:45.065709
# Unit test for constructor of class Posting
def test_Posting():
    @dataclass
    class _JournalEntry:
        guid: Guid
    def _journal():
        return _JournalEntry(guid=makeguid())
    j = _journal()
    p = Posting(journal=j, date=datetime.date.today(), account=Account.of("0000", "", AccountType.ASSETS), direction=Direction.INC, amount=Amount(10))
    assert p.journal.guid == j.guid
    assert p.date == datetime.date.today()
    assert p.account.code == "0000"
    assert p.account.name == ""
    assert p.account.type == AccountType.ASSETS
    assert p.direction == Direction.INC
    assert p.amount == Amount(10)
    assert p.is_debit
    assert not p.is_credit
    print

# Generated at 2022-06-24 01:05:54.223863
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass
    class Journal:
        pass

    calendar = DateRange(datetime.date(2019, 1, 4), datetime.date(2019, 1, 5))
    j1: JournalEntry[Journal] = JournalEntry(datetime.date(2019, 1, 4), "Description", Journal())
    j2: JournalEntry[Journal] = JournalEntry(datetime.date(2019, 1, 5), "Description", Journal())

    def read_journal_entries(journal_range: DateRange) -> Iterable[JournalEntry[Journal]]:
        return [j1]

    assert read_journal_entries(calendar) == [j1]

# Generated at 2022-06-24 01:06:05.189250
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account
    from .ledgers import Ledger, LedgerEntry
    from .accountants import Accountant
    from .business import Business
    from ..commons.numbers import Amount, Quantity

    business = Business()
    accountant = Accountant(business)
    a = Accountant(business)

    ledger1 = Ledger(
        'salary account'
        ,a
    )

    ledger2 = Ledger(
        'petty cash'
        ,a
    )

    ledger3 = Ledger(
        'expense'
        ,a
    )

    accountant.journal.post(
        '01-01-2020',
        description='salary paid',
        debit=ledger1,
        credit=ledger2,
        amount=Amount(10000),
    )


# Generated at 2022-06-24 01:06:16.288604
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from datetime import date
    from .accounts import Account
    from .types import CashFlow, Expense, Income
    from .transactions import Transaction
    from .journal import JournalEntry, Posting

    # Make dummy objects
    account = Account(name="Test Account", type=AccountType.EXPENSES)
    ledger = CashFlow(direction=Direction.INC, date=date(2019, 8, 28), amount=50)
    expense = Expense(date=date(2019, 8, 28), description="Test expense", ledger=ledger)
    transaction = Transaction(date=date(2019, 8, 28), description="Test transaction", ledger=ledger, expense=expense)
    journal_entry = JournalEntry(date=date(2019, 8, 28), description="Test journal entry", source=transaction)

# Generated at 2022-06-24 01:06:21.039857
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # Given
    source = object()
    account = Account.CONTRIBUTED_CAPITAL
    direction = Direction.INC
    amount = Amount(100)
    posting1 = Posting(source, datetime.date(2019, 10, 1), account, direction, amount)
    posting2 = Posting(source, datetime.date(2019, 10, 1), account, direction, amount)

    # Then
    assert posting1 == posting2

# Generated at 2022-06-24 01:06:25.470263
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    def _test_JournalEntry___hash__(je):
        a = hash(je)
        je.postings.append(Posting(je, datetime.date.today(), Account(AccountType.ASSETS, ""), Direction.INC, 1))
        b = hash(je)
        assert a == b
    for t in [datetime.date, str, int]:
        _test_JournalEntry___hash__(JournalEntry(datetime.date.today(), "", t(1)))


# Generated at 2022-06-24 01:06:33.369875
# Unit test for constructor of class Posting
def test_Posting():
    # Test __init__ to create an entry and assert properties
    journal = JournalEntry("", "")
    account = Account("")
    date = datetime.date(1,1,1)
    amount = Amount(2)
    test_posting = Posting(journal, date, account, Direction.INC,amount)
    assert test_posting.journal == journal and test_posting.date == date and \
        test_posting.account == account and test_posting.direction == Direction.INC and \
            test_posting.amount == amount


# Generated at 2022-06-24 01:06:35.157285
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert ReadJournalEntries

test_ReadJournalEntries()

# Generated at 2022-06-24 01:06:38.251235
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    journal = JournalEntry(datetime.date(2020,12,15), "dummy description", None, [])
    del journal.postings

# Generated at 2022-06-24 01:06:41.334542
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    je = JournalEntry(datetime.date(2020, 1, 1), "Test", None)
    je.post(datetime.date(2020, 1, 1), Account(1201, "AccTest", AccountType.ASSETS), Quantity(100))
    assert len(je.postings) == 1
    with pytest.raises(AttributeError):
        je.postings = "test"

# Generated at 2022-06-24 01:06:42.836675
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    Posting(None, None, None, None, None)


# Generated at 2022-06-24 01:06:51.114025
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import Account
    from .commons import Currency
    from .entry_types import Transaction
    from .ledgers import LedgerBook
    from .postings import Posting
    from .settings import LoadSettings
    from .system import AccountingSystem

    system = AccountingSystem(LoadSettings("../tests/tests.settings"))

    book = system.new_book("Test-Book", "Test-Book", Currency("SGD"), datetime.date(2017, 1, 1))
    transaction_id = book.new_id("Transaction")
    journal1 = book.journal("Journal-1")
    journal2 = book.journal("Journal-2")

    book.debit("Assets:Cash", Quantity(100)).credit("Equity:Paid-Up", Quantity(100)).post(journal1)

# Generated at 2022-06-24 01:07:00.906182
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    payload = (1, "a", 2, "b", 3, "c")

    @dataclass(frozen=True)
    class T:
        x: int
        y: str

    p1 = Posting(1, payload[0], payload[1], payload[2], payload[3], payload[4], payload[5])
    assert p1.__repr__() == f"<Posting(Journal={repr(payload[0])}, Date={repr(payload[1])}, Account={repr(payload[2])}, Direction={repr(payload[3])}, Amount={repr(payload[4])})>"

    p2 = Posting(None, payload[0], payload[1], payload[2], payload[3], payload[4], payload[5])
    assert p2.__repr__()

# Generated at 2022-06-24 01:07:08.226871
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(
        journal=JournalEntry(
            date=datetime.date(2019, 11, 25),
            description="Add some description",
            source="Account: A"),
        date=datetime.date(2019, 11, 25),
        account="Account: A",
        direction=Direction.INC,
        amount=Amount(100)
    ) == Posting(
            journal=JournalEntry(
                date=datetime.date(2019, 11, 25),
                description="Add some description",
                source="Account: A"),
            date=datetime.date(2019, 11, 25),
            account="Account: A",
            direction=Direction.INC,
            amount=Amount(100)
        )


# Generated at 2022-06-24 01:07:10.460998
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    journal_entry=JournalEntry([])
    setattr(journal_entry, "test_attribute", 1)
    assert journal_entry.test_attribute == 1


# Generated at 2022-06-24 01:07:22.340568
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Test: 'journal is properly validated'
    def test_1():
        # given
        journal_entry = JournalEntry(date=None, description=None, source=None)
        journal_entry.post(date=None, account=None, quantity=Amount(1))

        # when
        journal_entry.validate()

        # then
        # no exception

    test_1()

    # Test: 'journal with balance of zero is properly validated'
    def test_2():
        # given
        journal_entry = JournalEntry(date=None, description=None, source=None)
        journal_entry.post(date=None, account=None, quantity=Amount(1))
        journal_entry.post(date=None, account=None, quantity=Amount(-1))

        # when
        journal_entry.validate()

        #

# Generated at 2022-06-24 01:07:30.667445
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():

    @dataclass(frozen=True)
    class Source:
        pass

    source=Source()

    @dataclass(frozen=True)
    class MyJournalEntry(JournalEntry[Source]):
        pass

    je=MyJournalEntry(datetime.datetime.now().date(), 'my description', source, [])
    je.post(je.date, Account('my account'), 1)

    assert len(je.postings)==1
    assert je.postings[0].journal is je
    assert je.postings[0].direction is Direction.INC
    assert je.postings[0].amount.value == 1

# Generated at 2022-06-24 01:07:40.984395
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    import uuid as uuid_module
    @dataclass(frozen=True)
    class User:
        user_id: uuid_module.UUID

    @dataclass(frozen=True)
    class Account:
        account_number: str

    import datetime as datetime_module
    obj = JournalEntry[User](
        datetime_module.date(2016, 1, 1),
        "Test Journal Entry",
        User(uuid_module.UUID(int = 0)),
        [
            Posting(
                None,
                datetime_module.date(2016, 1, 1),
                Account("12345"),
                Direction.INC,
                Amount(100)
            )
        ]
    )
    obj.source.__hash__()
    obj.__hash__()

    import pytest
