

# Generated at 2022-06-24 00:57:46.494388
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Arrange
    j = JournalEntry(datetime.date.today(), "Test Journal Entry", None)
    j.postings.append(Posting(j, datetime.date.today(), Account(AccountType.ASSETS, "DebitAccount"), Direction.INC, Amount(10)))
    j.postings.append(Posting(j, datetime.date.today(), Account(AccountType.REVENUES, "CreditAccount"), Direction.DEC, Amount(10)))
    
    # Act
    j.validate()
    
    # Assert
    # Nothing to do

# Generated at 2022-06-24 00:57:50.273016
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    #: Arrange
    date = datetime.date(2020, 1, 1)
    description = "description"
    source = 1
    postings: List[Posting[int]] = []
    journal = JournalEntry[int](date, description, source, postings)
    expected = "<JournalEntry date=2020-01-01, description='description', source=1, postings=[]>"

    # Act
    result = repr(journal)

    # Assert
    assert result == expected, "The repr method of JournalEntry does not work!"


# Generated at 2022-06-24 00:57:57.503353
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    p = Posting(journal=JournalEntry(date=datetime.date(2019, 1, 1), description='test', source=''),
                date=datetime.date(2019, 1, 1), account=Account('account', AccountType.ASSETS),
                direction=Direction.INC, amount=Amount(1))
    assert str(p) == "Posting(journal=JournalEntry(date=datetime.date(2019, 1, 1), description='test', source=''), date=datetime.date(2019, 1, 1), account=Account(name='account', type='ASSETS', description='Unknown'), direction='INC', amount=Amount(1))"

# Generated at 2022-06-24 00:58:01.107323
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    je=JournalEntry('28-10-2019','abc','abc')
    je.post(datetime.date.today(),Account(1,'assets','xyz',True),10)
    je.post(datetime.date.today(),Account(1,'assets','xyz',True),-10)
    assert len(je.postings)==1
    assert je.postings[0].amount==10

# Generated at 2022-06-24 00:58:07.375600
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """Unit test for method __setattr__ of class Posting

    This unit test fails because dataclass __setattr__ calls are disabled.
    """
    p = Posting(None, None, None, None ,None)
    assert p.journal is None



# Generated at 2022-06-24 00:58:18.200968
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    def test_property(given_journalEntry: JournalEntry[_T], expected_repr):
        actual_repr = given_journalEntry.__repr__()
        assert actual_repr == expected_repr, f"{actual_repr} != {expected_repr}"


# Generated at 2022-06-24 00:58:28.282134
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from ..commons.zeitgeist import DateRange
    from .ledger import Ledger
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[Ledger]]:
        ledger = Ledger(datetime.date(2019, 1, 1))
        ledger.add_account(Account(1, 'Assets'))
        ledger.add_account(Account(2, 'Liabilities'))
        ledger.add_account(Account(3, 'Equities'))
        ledger.add_account(Account(4, 'Revenues'))
        ledger.add_account(Account(5, 'Expenses'))

# Generated at 2022-06-24 00:58:37.961774
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal_entry = JournalEntry(datetime.date.today(), "Description", "Source")
    journal_entry.post(datetime.date.today(), Account(1, "Account", AccountType.ASSETS), Quantity(100))
    posting = journal_entry.postings[0]

    assert (hash(posting) == hash(posting))
    # Check for hash equality for different postings with same value
    assert (hash(Posting(journal_entry, datetime.date.today(), Account(1, "Account", AccountType.ASSETS), Direction.INC, Amount(100))) == hash(Posting(journal_entry, datetime.date.today(), Account(1, "Account", AccountType.ASSETS), Direction.INC, Amount(100))))
    # Check for hash equality for different postings with different values

# Generated at 2022-06-24 00:58:43.866857
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import AccountType, Account
    from .business import OTParty
    from .businesss import OTCompany
    from .currencies import Currency
    a = Account("Cash", AccountType.ASSETS, Currency)
    b = Account("Salary Expense", AccountType.EXPENSES, Currency)
    c = Account("Salary Payable", AccountType.LIABILITIES, Currency)
    party = OTParty("John", Currency)
    company = OTCompany("My company", Currency)
    j = JournalEntry("Date", "Description", party)

    p1 = Posting(j, "Date", a, Direction.INC, Amount("100"))
    p2 = Posting(j, "Date", b, Direction.DEC, Amount("100"))

# Generated at 2022-06-24 00:58:51.104062
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    class TestJournalEntry(JournalEntry[None]):
        def __init__(self, postings: List[Posting[None]]):
            self.postings = postings

    posting1 = Posting(TestJournalEntry([]), None, None, None, None)
    with pytest.raises(AttributeError):
        posting1.postings = []  # type: ignore
    with pytest.raises(AttributeError):
        posting1.something = []  # type: ignore

    posting2 = Posting(TestJournalEntry([]), None, None, None, None)
    with pytest.raises(AttributeError):
        posting2.postings = []  # type: ignore
    posting2.something = []  # type: ignore

# Generated at 2022-06-24 00:58:55.423182
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    test_ID = 'test_JournalEntry'

    journal_entry = JournalEntry(date = datetime.date(2020, 5, 21))
    journal_entry.post(datetime.date(2020, 5, 21), 'assets', 10)
    journal_entry.post(datetime.date(2020, 5, 21), 'revenues', 5)

    journal_entry.validate()

# Generated at 2022-06-24 00:59:02.267875
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    date = datetime.date.today()
    description = "Test"
    source = "Test"
    journal = JournalEntry[str](date=date, description=description, source=source)
    journal = journal.post(date=datetime.date.today(), account=Account("Assets:Current:Cash"), quantity=100.0)

# Generated at 2022-06-24 00:59:07.266133
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class ReadJournalEntries_:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    ReadJournalEntries_()

# Generated at 2022-06-24 00:59:08.842666
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    pass

# Generated at 2022-06-24 00:59:15.100792
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from datetime import date

    from .accounts import AccountType
    from .accounts import EXPENSES, REVENUES

    e = JournalEntry(date(2020, 1, 1), "Purchase")
    e.post(date(2020, 1, 1), EXPENSES, 10)
    e.post(date(2020, 1, 1), REVENUES, 10)

    assert hash(e) == hash(e)
    assert hash(e) != hash(JournalEntry(date(2020, 1, 1), "Purchase"))
    assert hash(e) != hash(JournalEntry(date(2030, 1, 1), "Purchase"))


# Generated at 2022-06-24 00:59:26.077460
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    journal = JournalEntry[int](date=datetime.date(1, 1, 1), description="desc", source=1)
    posting = Posting(journal=journal, date=datetime.date(1, 1, 1), account=Account("account", AccountType.ASSETS),
                      direction=Direction.INC, amount=Amount(1))
    posting2 = Posting(journal=journal, date=datetime.date(1, 1, 1), account=Account("account", AccountType.ASSETS),
                       direction=Direction.INC, amount=Amount(1))
    posting3 = Posting(journal=journal, date=datetime.date(1, 1, 2), account=Account("account", AccountType.ASSETS),
                       direction=Direction.INC, amount=Amount(1))

# Generated at 2022-06-24 00:59:31.428810
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Ledger
    from .transaction import Transaction
    from .balancesheet import BalanceSheet
    from .balancesheet import ApplyBalanceSheet

    # Create an instance of Ledger
    ledger = Ledger()
    # Create an instance of BalanceSheet
    balanceSheet = BalanceSheet(ledger)
    # Create an instance of Transaction
    t = Transaction(ledger)
    # Create an instance of ApplyBalanceSheet
    b = ApplyBalanceSheet()

    # Create all the accounts
    a1 = ledger.account("Cash")
    a2 = ledger.account("Share Capital")
    a3 = ledger.account("Retained Earnings")
    a4 = ledger.account("Property, Plant and Equipment")
    a5 = ledger.account("Sales")
    a6 = ledger.account("Operating Expenses")

# Generated at 2022-06-24 00:59:32.892946
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass



# Generated at 2022-06-24 00:59:41.100014
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.others import makeguid
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    date = datetime.date(2020, 1, 1)
    description = "description"
    source = "journalentry"
    count = 3
    journalentry = JournalEntry(date, description, source)
    for i in range(1, count):
        journalentry.post(date, Account("account" + str(i)), Quantity(i))
    
    debits = list(journalentry.debits)
    assert len(debits) == 2
    assert debits[0].amount == Quantity(2)
    assert debits[0].account.name == "account2"
    assert debits[0].direction == Direction.INC

# Generated at 2022-06-24 00:59:43.838358
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert JournalEntry(date=datetime.date(2019, 10, 25), description="opening bank account ABCD with $100") == JournalEntry(date=datetime.date(2019, 10, 25), description="opening bank account ABCD with $100")



# Generated at 2022-06-24 00:59:52.819871
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    # -- Setup --
    from .accounts import AccountFactory
    from .ledgers import Ledger
    from .books import Book
    from .txns import TransactionFactory

    # -- Arrange --
    ledger = Ledger(makeguid())
    book = Book(
        name="Test",
        description="Test",
        currency="USD",
        ledger=ledger,
    )

    account_factory = AccountFactory(book)
    asset = account_factory(name="Cash", type=AccountType.ASSETS, balance=100)
    TransactionFactory(book).create(
        date=datetime.date(2012,1,1),
        description="Test",
        debit=asset,
        credit=asset,
        amount=10
    )

    # -- Act --

# Generated at 2022-06-24 00:59:53.780684
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass



# Generated at 2022-06-24 01:00:02.216060
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountId
    from .customers import CustomerId
    from .invoices import SalesInvoiceId, SalesInvoiceLineId

    def _test(date: datetime.date, description: str, debits: Amount, credits: Amount, expected_result: bool) -> None:
        """
        Performs unit tests for a journal entry.

        :param date: Date of the journal entry.
        :param description: Description of the journal entry.
        :param debits: Debit amount (a positive value).
        :param credits: Credit amount (a positive value).
        :param expected_result: Expected result of the test.
        """
        ## Define source:

# Generated at 2022-06-24 01:00:10.091325
# Unit test for constructor of class Posting
def test_Posting():
    JE = JournalEntry(date = datetime.date(2020,2,10), description="Test", source=None)
    P = Posting(journal=JE, date=datetime.date(2020,2,10), account=Account(name = "A", type=AccountType.ASSETS), direction=Direction.INC, amount = Amount(10))
    assert P.amount == 10
    assert P.account == Account(name = "A", type=AccountType.ASSETS)
    assert P.direction == Direction.INC
    assert P.journal == JE
    assert P.date == datetime.date(2020,2,10)


# Generated at 2022-06-24 01:00:10.827154
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass


# Generated at 2022-06-24 01:00:11.307390
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert True

# Generated at 2022-06-24 01:00:18.164585
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from core.utilities.random_generators import generate_random_posting
    from dataclasses import asdict
    import datetime, random

    for _ in range(10):
        posting1 = generate_random_posting()
        posting2 = Posting(posting1.journal, posting1.date, posting1.account, posting1.direction, posting1.amount)

        assert posting1 == posting2
        assert posting1.__dict__ == posting2.__dict__
    # End of tests



# Generated at 2022-06-24 01:00:27.670576
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():

    from .accounts import Accounts, get_account
    from .commodities import Commodities
    from .journal import Journal

    journal = Journal(Commodities(), Accounts())

    debit_entries = \
        journal.new_entry(datetime.date.today()) \
            .post(datetime.date.today(), get_account("Cash"), +10) \
            .post(datetime.date.today(), get_account("Equity"), -10)

    credit_entries = \
        journal.new_entry(datetime.date.today()) \
            .post(datetime.date.today(), get_account("Cash"), -10) \
            .post(datetime.date.today(), get_account("Equity"), +10)


# Generated at 2022-06-24 01:00:30.654421
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    a = Posting(None, None, None, None, None)
    b = Posting(None, None, None, None, None)

    assert a == b


# Generated at 2022-06-24 01:00:35.575716
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from .accounts import Account
    from .prices import Price, PriceService
    from .recipes import Recipe
    from .stock import Stock, StockService

    account = Account("stock")
    stock = Stock("stock", account)
    transaction = StockService.buy_stock("", datetime.date(2020, 1, 1), stock, Price("1 USD"))
    j = JournalEntry(date=datetime.date(2020, 1, 1), description="", source=transaction)

    assert j.date == datetime.date(2020, 1, 1)
    assert j.description == ""
    assert j.source == transaction
    assert j.postings == []
    assert len(j.increments) == 0
    assert len(j.decrements) == 0
    assert len(j.debits) == 0

# Generated at 2022-06-24 01:00:39.409320
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def _fetch(p: DateRange) -> Iterable[JournalEntry[None]]:
        pass
    
    rje = ReadJournalEntries.__getitem__(ReadJournalEntries, (None,))
    assert issubclass(rje, ReadJournalEntries)
    assert rje(_fetch) == _fetch

# Generated at 2022-06-24 01:00:45.479427
# Unit test for constructor of class Posting
def test_Posting():
    from datetime import date
    from .accounts import Account, AccountType

    journal = None

    date = date(2099, 11, 29)

    account = Account(AccountType.ASSETS, "p_1", "PostingAccount", "")

    direction = Direction.DEC

    amount = Amount(100)

    posting = Posting(journal, date, account, direction, amount)

    assert posting.account.number == "p_1"
    assert posting.amount == 100
    assert posting.direction == Direction.DEC
    assert posting.journal == None
    assert posting.date == date(2099, 11, 29)


# Generated at 2022-06-24 01:00:53.482966
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import fields

    class AnInstance:
        def __init__(self):
            self.date = datetime.date.today()
            self.description = 'Sales'
            self.source = 'SalesOrder'
            self.postings = [Posting(self, datetime.date.today(),
                                     Account(AccountType.ASSETS, 'Cash'),
                                     Direction.DEC, Amount(100))]
            self.guid = str(id(self))

    obj = JournalEntry(AnInstance())

    for attr in fields(JournalEntry):
        assert hasattr(obj, attr.name)
    return True

# Generated at 2022-06-24 01:01:01.972382
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal=JournalEntry(date=datetime.date(2000, 1, 1), description="journal", source="source", postings=["postings"])
    assert repr(journal)=='JournalEntry(date=datetime.date(2000, 1, 1), description=\'journal\', source=\'source\', guid=\'f97c9b24-d490-43a1-b0b6-30b943905104\')'
    assert journal.postings==["postings"]


# Generated at 2022-06-24 01:01:06.173358
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    je1 = JournalEntry[str](date=datetime.date(2018, 2, 3), description="Test entry")
    je2 = JournalEntry[str](date=datetime.date(2018, 2, 3), description="Test entry")
    assert je1 == je2


# Generated at 2022-06-24 01:01:17.707499
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal_entry = JournalEntry(
        date=datetime.date(2019, 7, 1),
        description='debit',
        source='buy 10 shares of ABC at $100 per share',
        postings=[Posting(
            journal=JournalEntry(
                date=datetime.date(2019, 7, 1),
                description='debit',
                source='buy 10 shares of ABC at $100 per share'
            ),
            date=datetime.date(2019, 7, 1),
            account='ABC',
            direction='debit',
            amount=1000
        )]
    )

# Generated at 2022-06-24 01:01:27.966204
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    t1 = makeguid()
    a1 = Account("I")
    a2 = Account("E")
    je1 = JournalEntry(datetime.date(2019, 11, 29), "T1", t1)
    je2 = JournalEntry(datetime.date(2019, 11, 29), "T1", t1)
    je3 = JournalEntry(datetime.date(2019, 11, 28), "T1", t1)
    je4 = JournalEntry(datetime.date(2019, 11, 29), "T2", t1)
    je5 = JournalEntry(datetime.date(2019, 11, 29), "T1", makeguid())
    assert je1 == je2
    assert je1 != je3
    assert je1 != je4
    assert je1 != je5

# Generated at 2022-06-24 01:01:36.807276
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import Account
    from .transactions import Transaction
    from .currencies import Currency
    from .commons.numbers import isum
    from .commons.test_data import account_1000, account_2000, account_3000, usd

    transaction = Transaction(
        isum(account_1000, account_2000, plus=+usd(100)),
        isum(account_3000, plus=-usd(100)))
    entry = JournalEntry[Transaction]()
    entry.date = datetime.date(2020, 2, 1)
    entry.description = "Does something"
    entry.source = transaction
    entry.post(datetime.date(2020, 2, 1), Account.of("1000"), +usd(100))

# Generated at 2022-06-24 01:01:43.255345
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from ..commons.types import Product
    from .accounts import AccountType, Accounts
    p = Product("P1")
    p.journal.post(datetime.date(2020,1,1), Accounts.ASSET_BANK, 100)
    assert p.journal.date == datetime.date(2020, 1, 1)
    assert p.journal.description == "P1"
    assert p.journal.source is p
    assert len(p.journal.postings) == 1
    assert p.journal.postings[0].journal is p.journal
    assert p.journal.postings[0].date == datetime.date(2020, 1, 1)
    assert p.journal.postings[0].account == Accounts.ASSET_BANK
    assert p.journal.postings[0].account.type is AccountType.ASSETS

# Generated at 2022-06-24 01:01:50.176181
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    #Given
    p1 = Posting(1, "a", 100)
    p2 = Posting(1, "b", 100)
    p3 = Posting(1, "a", 101)
    p4 = Posting(2, "a", 101)
    p5 = Posting(2, "a", 100)
    #Then
    assert p1 == p1
    assert p1 == p5
    assert p1 != p2
    assert p1 != p3
    assert p1 != p4

# Generated at 2022-06-24 01:02:01.124148
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    try:
        a = Posting(journal = None, date = datetime.datetime(2019, 1, 1), account = Account(type = AccountType.ASSETS, name = "Cash"), direction = Direction.INC, amount = Amount(1))
        a.journal = "abc"
        assert False, "no error"
    except:
        assert True, "error"
    try:
        a = Posting(journal = None, date = datetime.datetime(2019, 1, 1), account = Account(type = AccountType.ASSETS, name = "Cash"), direction = Direction.INC, amount = Amount(1))
        a.date = "abc"
        assert False, "no error"
    except:
        assert True, "error"

# Generated at 2022-06-24 01:02:10.975249
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from operator import attrgetter
    from dataclass_factory import Factory

    from finance.books import Account
    from finance.books.journal import JournalEntry

    class Order:
        company: str
        customer: str
        value: float

    order = Order("Company1", "Customer1", 500)
    entry: JournalEntry[Order] = JournalEntry(
        datetime.date(year=2019, month=1, day=1),
        "Test",
        order,
    ).post(datetime.date(year=2019, month=1, day=1), Account("Sales"), 500)

    factory = Factory()
    factory.update(JournalEntry, (attrgetter("postings"),))
    processed_entry: JournalEntry[Order] = factory.build(JournalEntry, data=entry)


# Generated at 2022-06-24 01:02:22.147506
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # Handle a normal Posting
    actual = repr(Posting(journal=JournalEntry(date=datetime.date(2019, 3, 1), description="sale of 100 gold",source=None),
                          date=datetime.date(2019, 3, 1),
                          account=Account(name="revenue", type=AccountType.REVENUES),
                          direction=Direction.INC,
                          amount=Amount(500)))

# Generated at 2022-06-24 01:02:25.695612
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(None, None, None, Direction.INC, Amount(100))
    p2 = Posting(None, None, None, Direction.INC, Amount(100))
    assert p1 == p2

    p3 = Posting(None, None, None, Direction.DEC, Amount(100))
    assert p1 != p3


# Generated at 2022-06-24 01:02:31.263784
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    """
    Unit test for method __delattr__ of class JournalEntry
    """
    # test case 1
    journal = JournalEntry(
        date = 'date',
        description = 'description',
        source = 'source',
    )
    journal.__delattr__('description')
    del journal.description
    assert journal.description == 'description'


# Generated at 2022-06-24 01:02:42.392973
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p = Posting(None, datetime.date(2015, 1, 1), None, Direction.INC, Amount(1))
    assert p == Posting(None, datetime.date(2015, 1, 1), None, Direction.INC, Amount(1))
    assert p != Posting(None, datetime.date(2015, 1, 1), None, Direction.DEC, Amount(1))
    assert p != Posting(None, datetime.date(2015, 1, 2), None, Direction.INC, Amount(1))
    assert p != Posting(None, datetime.date(2015, 1, 1), None, Direction.INC, Amount(2))
    assert p != Posting(None, datetime.date(2015, 1, 1), None, Direction.INC, Amount(1))

# Generated at 2022-06-24 01:02:47.061925
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
  Posting()
  if 1 == 1:
    pass
  else:
    1 / 0


# Generated at 2022-06-24 01:02:47.856433
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 01:02:52.136576
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import RootAccount

    j = JournalEntry[RootAccount](
        datetime.date(2020, 5, 7),
        "Test journalEntry",
        RootAccount()
    )
    j.post(datetime.date(2020, 5, 7), Account(Guid()), 2)
    j.post(datetime.date(2020, 5, 7), Account(Guid()), -2)
    assert len(j.postings) == 2



# Generated at 2022-06-24 01:02:57.070323
# Unit test for constructor of class Posting
def test_Posting():
    # Test method from dataclasses.
    # d = datetime.date.today()
    # p = Posting(d, "SA-001", "Credit", 1000)
    # print(Posting.__init__)
    # assert p.date == d
    pass


# Generated at 2022-06-24 01:03:03.776880
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import Account
    from .exchanges import Currency
    from .journals import JournalEntry

    p = Posting(JournalEntry(datetime.date(2020, 1, 31), "Test", None), datetime.date(2020, 1, 31), Account("A", Currency("USD"), AccountType.ASSETS, None, None), Direction.DEC, Amount(10))

    assert str(p) == "<Posting: '31-01-2020', A, -10 USD>"



# Generated at 2022-06-24 01:03:14.650776
# Unit test for constructor of class Posting
def test_Posting():
    import unittest

    #from dataclasses import dataclass, field
    #from typing import List, TypeVar
    #from .accounts import Account, AccountType
    #from .commons.primitives import Quantity
    #from .journal import Direction, JournalEntry, Posting


    @dataclass(frozen=True)
    class Source:
        pass


    def build_journal_entry() -> JournalEntry[Source]:
        journal = JournalEntry(datetime.date(2020, 1, 1), "Some description", Source())
        journal.post(datetime.date(2020, 1, 1), Account("debit account", AccountType.ASSETS), Quantity(100))
        journal.post(datetime.date(2020, 1, 1), Account("credit account", AccountType.EQUITIES), Quantity(-100))
        journal.validate

# Generated at 2022-06-24 01:03:25.436553
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from .accounts import AccountType

    class Ledger:
        def __init__(self):
            self.postings = []

        def post(self, date: datetime.date, account: Account, amount: Amount) -> "Ledger":
            self.postings.append(Posting(self, date, account, Direction.INC, amount))
            return self

    def validate_postings(journal_entry: JournalEntry[Ledger]):
        ## Get total debit and credit amounts:
        total_debit = isum(i.amount for i in journal_entry.debits)
        total_credit = isum(i.amount for i in journal_entry.credits)

        ## Check:

# Generated at 2022-06-24 01:03:28.581887
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    @dataclass(frozen=True)
    class Test:
        p: Posting
    test=Test(Posting(JournalEntry(datetime.date.today(),'sample',1),datetime.date.today(),Account(1,'cash'),Direction.INC,Amount(1000)))
    with pytest.raises(AttributeError):
        test.p.amount=Amount(10000)

# Generated at 2022-06-24 01:03:35.151151
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Define date for the journal entry
    date1 = datetime.date(2020, 1, 1)
    # Initialize a JournalEntry
    test_JournalEntry = JournalEntry(date1,'test description',1)
    # Check the date
    assert test_JournalEntry.date == date1
    # Check the description
    assert test_JournalEntry.description == 'test description'
    # Check the source
    assert test_JournalEntry.source == 1


# Generated at 2022-06-24 01:03:36.010063
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    pass


# Generated at 2022-06-24 01:03:37.485017
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    entry = JournalEntry(None)
    hash(entry)

# Generated at 2022-06-24 01:03:45.066744
# Unit test for constructor of class JournalEntry
def test_JournalEntry():

    entry = JournalEntry(datetime.date(2019, 9, 29), 'Initial', 'BTC', [
                                                                            Posting(journal=JournalEntry,
                                                                                        date=datetime.date(2019, 9, 29),
                                                                                        account=Account,
                                                                                        direction=Direction,
                                                                                        amount=Amount(50000)),
                                                                            Posting(journal=JournalEntry,
                                                                                        date=datetime.date(2019, 9, 29),
                                                                                        account=Account,
                                                                                        direction=Direction,
                                                                                        amount=Amount(500))
                                                                            ])
    print('journal_entry.py Test Journal Entry')
    print(entry)

test_JournalEntry()

# Generated at 2022-06-24 01:03:49.478961
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Setup
    from datetime import date
    from .accounts import AccountType
    asset = Account('My asset account', AccountType.ASSETS, 'Asset account')
    source = "My source"
    date = date(2020, 1, 1)
    description = "My description"
    j = JournalEntry(date, description, source)
    j.post(date, asset, Quantity(1))

    # Check
    # No exception thrown

# Generated at 2022-06-24 01:03:57.134443
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    je1 = JournalEntry[Posting](date = datetime.date(2007,4,1), description = "Test")
    je2 = JournalEntry[Posting](date = datetime.date(2007,4,1), description = "Test")
    je3 = JournalEntry[Posting](date = datetime.date(2007,5,1), description = "Test")

    # Same date, same description.
    assert je1 == je2

    # Same date, different description.
    assert not (je1 == je3)

# Generated at 2022-06-24 01:04:01.993467
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry(date = datetime.date(2020,1,1), description = "test",source = "test", postings=[])
    assert je.date == datetime.date(2020, 1, 1)
    assert je.description == "test"
    assert je.source == "test"
    assert je.postings == []


# Generated at 2022-06-24 01:04:11.630005
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import datamodel, field, fields
    from pytest import raises

    @datamodel
    class TestValue:
        a: int = field(default=1, metadata={"min": 0, "max": 10})
        b: str = field(default="x", metadata={"min": 0, "max": 10})
        c: int = field(default=0)

    def do_setattr(input_list):
        # type: (list) -> None
        obj = TestValue()
        for item in input_list:
            with raises(ValueError):
                setattr(obj, item[0], item[1])


# Generated at 2022-06-24 01:04:22.182073
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import Account, AccountType
    from .ledgers import Ledger, Posting, JournalEntry
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity
    import datetime
    dt = datetime.date.today()
    #print(amount)
    #qty1 = Quantity(12342.00)
    #print(qty1)
    #print(type(qty1))
    #print(dt)
    #print(type(dt))
    ledger1 = Ledger()
    ledger1.open("2016-01-01")
    c = Account("Cash")
    ledger1.add_account(c)
    jen1 = JournalEntry(dt, "test01", ledger1)

# Generated at 2022-06-24 01:04:23.075187
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class Test:
        def __call__(self):
            pass
    Test()

# Generated at 2022-06-24 01:04:27.750767
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import dataclasses
    import typing
    @dataclasses.dataclass
    class Foo:
        pass
    class Bar(typing.Generic[Foo]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[Foo]]:
            pass
    assert True

# Generated at 2022-06-24 01:04:32.982876
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # pylint: disable=missing-function-docstring
    @dataclass
    class TestEntity:
        pass
    def method_rje(obj: DateRange) -> Iterable[JournalEntry[TestEntity]]:
        # pylint: disable=unused-argument
        return []
    method_rje
    pass

# Generated at 2022-06-24 01:04:42.463261
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType

    journal = JournalEntry[int](datetime.date.today(), "", "")
    journal \
        .post(datetime.date.today(), Account(AccountType.ASSETS, "", "", ""), 1000) \
        .post(datetime.date.today(), Account(AccountType.EXPENSES, "", "", ""), -2400) \
        .post(datetime.date.today(), Account(AccountType.REVENUES, "", "", ""), 2000) \
        .post(datetime.date.today(), Account(AccountType.REVENUES, "", "", ""), -400)
    assert len(list(journal.postings)) == 4
    assert len(list(journal.increments)) == 2
    assert len(list(journal.decrements)) == 2

# Generated at 2022-06-24 01:04:47.288557
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal = JournalEntry('1')
    date = datetime.date.today()
    
    account = Account(AccountType.EQUITIES, '2')
    direction = Direction.INC
    amount = Amount(10)
    
    posting1 = Posting(journal, date, account, direction, amount)
    posting2 = Posting(journal, date, account, direction, amount)
    
    assert posting1 == posting2
    assert hash(posting1) == hash(posting2)

# Generated at 2022-06-24 01:04:53.945867
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .companies import Company
    from .currencies import Currency, CurrencyPair

    cp = CurrencyPair(Currency.EUR, Currency.USD, rate=1.1)
    c = Company(None, "Company 1", Currency.USD)
    a1 = Account(c, "Account 1", AccountType.ASSETS)
    a2 = Account(c, "Account 2", AccountType.LIABILITIES)
    a3 = Account(c, "Account 3", AccountType.REVENUES)
    je = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", c)
    je.post(datetime.date(2020, 1, 1), a1, 100)
    je.post(datetime.date(2020, 1, 1), a2, -100)
    je

# Generated at 2022-06-24 01:04:54.623551
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    pass

# Generated at 2022-06-24 01:05:06.933751
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .test_domain_objects import Company, Transaction
    from .accounts import Currency, Equity, IncomeAccount, IncomeAccountType, LiabilityAccount

    # Arrange:
    cash = Equity("Cash", Currency.USD)
    revenue = IncomeAccount("Revenue", IncomeAccountType.REVENUE, Currency.USD)
    tax_liabilities = LiabilityAccount("Tax Liabilities", Currency.USD)

    txn = Transaction(
        date=datetime.date(2019, 2, 1),
        description="Sale",
        source=Company("Foo Inc."),
        postings=[
            (cash, +1000),
            (revenue, -1000),
        ],
    )

    # Act:
    po = Posting(txn, datetime.date(2019, 2, 1), tax_liabilities, Direction.INC, Amount(100))



# Generated at 2022-06-24 01:05:13.983639
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from ..test_utils import DummyUow
    from ..test_utils.test_data import TestData
    from .accounts import Accounts, ChartOfAccounts

    # Setup:
    uow = DummyUow()
    coa = ChartOfAccounts(uow)
    accounts: Accounts = coa.current()

    # Exercise:
    journal = JournalEntry(date=datetime.date.today(), description="Test Journal Entry").post(
        date=datetime.date.today(), account=accounts.cash, quantity=100
    )

    # Validate:
    assert journal.postings[0].journal is journal
    assert journal.postings[0].date == datetime.date.today()
    assert journal.postings[0].account is accounts.cash
    assert journal.postings[0].direction == Direction.INC


# Generated at 2022-06-24 01:05:20.261513
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    
    assert Posting.__repr__ is not object.__repr__
    # Create a Posting instance with default values
    posting = Posting(journal=None, date=datetime.date(year=1900, month=1, day=1), account=Account(name='', type=AccountType.EQUITIES), direction=Direction.INC, amount=0.00)

    # Check that Posting.__repr__ returns a string
    assert isinstance(posting.__repr__(), str)

    

# Generated at 2022-06-24 01:05:29.593624
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType, Account
    from .businesses import Business
    from .events import NewBusiness
    from .events import NewAccount
    from dataclasses import dataclass
    from datetime import date
    from typing import Any
    from typing import Optional
    @dataclass(frozen=True)
    class _Business(Business):
        @classmethod
        def new(cls):
            business, journal_entry = super().new()
            journal_entry.post(business.date, Account((AccountType.EQUITIES, "EQUITIES", "EQUITIES")), 1)
            return business, journal_entry
    @dataclass(frozen=True)
    class _AccountJournalEntry:
        date: date
        description: str
        account: Any
        quantity: Optional[int]

# Generated at 2022-06-24 01:05:36.660299
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from datetime import date
    from .accounts import Cash
    from .equities import Equity
    from .sources.trades import Trade

    #* Set up
        # - Create JournalEntry
        # - Create JournalEntry with same fields
        # - Create JournalEntry with different fields

    date1 = date(2020, 6, 11)
    date2 = date(2020, 6, 12)

    description1 = "Buy X shares"
    description2 = "Sell X shares"

    guid1 = "0b67e2c0-8d07-4060-87e0-77d7acd8b844"
    guid2 = "0b67e2c0-8d07-4060-87e0-77d7acd8b845"


# Generated at 2022-06-24 01:05:45.621111
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    a1 = Account("ASSETS-BANK", AccountType.ASSETS)
    a2 = Account("BANK-ASSETS", AccountType.ASSETS)
    a3 = Account("INCOME", AccountType.REVENUES)

    p1 = Posting(None, datetime.date(1980, 1, 1), a1, Direction.INC, Amount(1.0))
    p2 = Posting(None, datetime.date(1980, 1, 1), a2, Direction.INC, Amount(1.0))
    p3 = Posting(None, datetime.date(1980, 1, 1), a3, Direction.INC, Amount(1.0))

    p1p1 = Posting(None, datetime.date(1980, 1, 1), a1, Direction.INC, Amount(1.0))
    p1p2

# Generated at 2022-06-24 01:05:46.594926
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    pass


# Generated at 2022-06-24 01:05:56.611103
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    JE = JournalEntry("test")
    JE.post("2020-01-01", "Assets:Cash", 1)

# Generated at 2022-06-24 01:06:04.593582
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    je = JournalEntry(datetime.date(2018, 1, 1), "test", "")
    p = je.post(datetime.date(2018, 1, 1), Account("1", "", "", ""), 1)
    assert str(p) == "Posting(journal=JournalEntry(date=2018-01-01, description='test', source=''), date=2018-01-01, account=Account(code='1', name='', type=ASSETS, parent=None), direction=INC, amount=1)"



# Generated at 2022-06-24 01:06:16.247882
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date
    from ..commons.numbers import Amount
    from ..commons.datatypes import Money
    from .accounts import Account, AccountType
    from .accounts import AssetAccount, ExpenseAccount
    from .accounts import CashAccount, UtilitiesAccount
    from .accounts import RevenueAccount, CapitalAccount
    from .accounts import SalesAccount, OwnersAccount

    class BusinessObject1: pass
    class BusinessObject2: pass

    je1 = JournalEntry(BusinessObject1(), "Journal Test", date(2020, 12, 31), "1st Journal Test")
    je2 = JournalEntry(BusinessObject2(), "Journal Test", date(2020, 12, 31), "2nd Journal Test")
    account_cash_usd = CashAccount(Currency('USD'), "Cash")
    account_utilities = UtilitiesAccount("Utilities")


# Generated at 2022-06-24 01:06:22.550322
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    class BusinessObject:
        def __init__(self, x: int):
            self.x = x

    a = JournalEntry[BusinessObject](datetime.date(2016, 1, 1), "Description", BusinessObject(1234))
    b = JournalEntry[BusinessObject](datetime.date(2016, 1, 1), "Description", BusinessObject(4321))
    assert a != b

    a.post(datetime.date(2016, 1, 1), Account("Expense"), 5)
    b.post(datetime.date(2016, 1, 1), Account("Expense"), 5)
    assert a == b

# Generated at 2022-06-24 01:06:30.327765
# Unit test for constructor of class Posting
def test_Posting():
    # Create object of class JournalEntry
    journalEntry = JournalEntry("a", "b", "c", "d", "e")
    # Create object of class Posting with the journalEntry object.
    posting = Posting(journalEntry, "b", "c", "d", "e")
    # Get the increment and decrement events.
    incrEvents = posting.increments
    decrEvents = posting.decrements
    # Get the debit and credit postings.
    debitPostings = posting.debits
    creditPostings = posting.credits
    # Validate the journal entry
    posting.validate()

# Generated at 2022-06-24 01:06:34.463195
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    P = Posting
    assert P(None, None, None, None, None) == P(None, None, None, None, None)

# Generated at 2022-06-24 01:06:35.611987
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 01:06:37.348219
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert False

# Generated at 2022-06-24 01:06:43.172020
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    """
    Tests the method __repr__ of class JournalEntry.
    """
    # Tests if the __repr__ function of a JournalEntry returns the same object when converting it to a string,
    # running eval on it, and then converting it back to a JournalEntry.
    # Also tests if a JournalEntry is not equal to another JournalEntry with the same values in its fields.
    entry1 = JournalEntry(datetime.date(2020,8,3), "Test Description 1", "Test Source 1")
    assert eval(entry1.__repr__()) == entry1
    entry2 = JournalEntry(datetime.date(2020,8,3), "Test Description 1", "Test Source 1")
    assert eval(entry2.__repr__()) == entry2
    assert entry1 != entry2

# Generated at 2022-06-24 01:06:47.484840
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting("journal", "date", "account", "direction", "amount")
    p2 = Posting("journal", "date", "account", "direction", "amount")
    p3 = Posting("another_journal", "date", "account", "direction", "amount")
    assert p1 == p2
    assert p1 != p3

# Generated at 2022-06-24 01:06:58.543089
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    @dataclass(frozen=True)
    class TestJournal:
        date: datetime.date = datetime.date(2020, 1, 1)
        description: str = ""
        source: str = ""
        postings: List[Posting] = field(default_factory=list)

    entry = TestJournal()
    entry.postings.append(
        Posting(
            journal=entry,
            date=entry.date,
            account=Account(name="Cash"),
            direction=Direction.INC,
            amount=Amount(100),
        )
    )
    entry.postings.append(
        Posting(
            journal=None,
            date=entry.date,
            account=Account(name="Cash"),
            direction=Direction.INC,
            amount=Amount(100),
        )
    )

# Generated at 2022-06-24 01:06:59.070169
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    pass

# Generated at 2022-06-24 01:07:01.644221
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    source = 5
    date = datetime.date.today()
    description = "Test Journal Entry"
    j = JournalEntry(date, description, source)
    assert j.date == date
    assert j.description == description
    assert j.source == source

# Generated at 2022-06-24 01:07:09.059371
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from ..accounts import Account, AccountType
    from ..commons.numbers import Quantity
    j1 = JournalEntry[int]()
    j1.post(date(2019, 1, 1), Account("Cash", AccountType.ASSETS), Quantity(100))
    j1.post(date(2019, 1, 1), Account("Revenue", AccountType.REVENUES), Quantity(-100))
    assert j1.postings[0].amount == j1.postings[1].amount
    assert j1.postings[0].is_debit
    assert not j1.postings[1].is_debit
    assert j1.postings[0].direction.value == 1
    assert j1.postings[1].direction.value == -1
    assert j1.postings[1].account.type

# Generated at 2022-06-24 01:07:15.901483
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    obj1 = JournalEntry(date=datetime.date, description="test journal entry", source=None)
    obj2 = JournalEntry(date=datetime.date, description="test journal entry", source=None)
    assert obj1 == obj2, "Failure to assert __eq__ of two objects with same value"


# Generated at 2022-06-24 01:07:21.327313
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    j1 = JournalEntry(date=datetime.date(2020, 1, 1), description="Journal Entry 1", source="Batch")
    p1 = Posting(j1, date=datetime.date(2020, 1, 1), account=Account("Assets", AccountType.ASSETS), direction=Direction.INC, amount=Amount(1))
    j2 = JournalEntry(date=datetime.date(2020, 1, 1), description="Journal Entry 1", source="Batch")
    p2 = Posting(j1, date=datetime.date(2020, 1, 1), account=Account("Assets", AccountType.ASSETS), direction=Direction.DEC, amount=Amount(1))

    assert(p1 == p1)
    assert(p2 == p2)
    assert(p1 != p2)

# Generated at 2022-06-24 01:07:28.901195
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    jl = JournalEntry(datetime.date.today(), "", None)
    u = Posting(jl, datetime.date.today(), Account(None, '', AccountType.EXPENSES), Direction.INC, Amount(0))
    assert hasattr(u, 'journal')
    assert hasattr(u, 'account')
    assert hasattr(u, 'direction')
    assert hasattr(u, 'amount')
    assert not hasattr(u, 'id')
    u.id = u.id + 1
    assert not hasattr(u, 'id')

# Generated at 2022-06-24 01:07:36.623777
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    journal = JournalEntry(datetime.date(2020, 8, 28), "Monthly Salary", None)
    journal.post(datetime.date(2020, 8, 28), Account(AccountType.ASSETS, "Cash", "Cash"), 100)
    journal.post(datetime.date(2020, 8, 28), Account(AccountType.REVENUES, "Salary", "Monthly Salary"), -100)
    assert journal.postings[0].date == datetime.date(2020, 8, 28)
    assert journal.postings[0].account == Account(AccountType.ASSETS, "Cash", "Cash")
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].amount == 100
    assert journal.postings[1].date == datetime.date(2020, 8, 28)
    assert journal

# Generated at 2022-06-24 01:07:43.699402
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # source of business object
    journal_source = Account.create("Account 1", "This is account 1.", AccountType.ASSETS)
    # business object 1
    journal_source_b = Account.create("Account 1", "This is account 1.", AccountType.ASSETS)
    # another business object
    journal_source_c = Account.create("Account 2", "This is account 2.", AccountType.EXPENSES)
    # journal entry 1
    journal_a = JournalEntry(date=datetime.date(2019, 12, 1), description="This is a journal entry", source=journal_source)
    journal_a.post(datetime.date(2019, 12, 1), Account.create("Account 1", "This is account 1.", AccountType.ASSETS), Quantity(100))
    #journal entry 2