

# Generated at 2022-06-24 00:57:44.955057
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    """Unit test for method __hash__ of class JournalEntry"""
    def test():
        # Setup
        journal_entry = JournalEntry(
            date=datetime.date(2016, 1, 1),
            description="Dummy journal entry",
            source=None,
        )
    
        # Exercise
        result = journal_entry.__hash__()
    
        # Verify
        assert result == hash(journal_entry.__getstate__())
    
        # Cleanup - none necessary
    
    # Perform test
    test()



# Generated at 2022-06-24 00:57:50.844526
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry[None](datetime.date(2020, 8, 11), "description", None, [])
    assert je.date.strftime("%Y%m%d") == "20200811"
    assert je.description == "description"
    assert je.source == None
    assert len(je.postings) == 0
    assert len(je.guid) == 36

# Generated at 2022-06-24 00:57:57.876365
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    source = 'test'
    journalEntry = JournalEntry('2020-01-01', 'testEntry1', source)
    
    posting1 = Posting(journalEntry, datetime.date(2020, 1, 1), 'income', Direction.INC, 50)
    posting2 = Posting(journalEntry, datetime.date(2020, 1, 1), 'income', Direction.INC, 50)
    posting3 = Posting(journalEntry, datetime.date(2020, 1, 2), 'income', Direction.INC, 50)

    assert (posting1 == posting2) == True
    assert (posting1 == posting3) == False


# Generated at 2022-06-24 00:57:59.746700
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    try:
        journal_entry = JournalEntry(date = datetime.date(2000, 1, 1), description = '', source = '')
        journal_entry.guid = 'test'
    except:
        pass
    assert True

# Generated at 2022-06-24 00:58:10.349619
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    s = '''
    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """
        date: datetime.date = datetime.date(2020, 1, 1)
        description: str = "Test"
        source: _T = field(repr=False)
        postings: List[Posting[_T]] = field(default_factory=list, init=False)
        guid: Guid = field(default_factory=makeguid, init=False)
        '''
    exec(s) 

    journal = JournalEntry(None)      # type: ignore
    posting = Posting(journal, datetime.date(2020, 1, 1), Account("Test"), Direction.INC, Amount(1))

# Generated at 2022-06-24 00:58:13.721813
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Only types are used in the methods of this class.
    assert ReadJournalEntries.__call__(None, DateRange(datetime.date.today(), datetime.date.today())) == None  # type: ignore[attr-defined]

# Generated at 2022-06-24 00:58:22.286946
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Arrange
    journal_entry_1: JournalEntry = JournalEntry(date=datetime.date.today(), description="Accounts for moving goods", source=0)
    account_1: Account = Account("inventory","asset")
    account_2: Account = Account("revenue","revenue")
    date: datetime.date = datetime.date.today()
    amount: Amount = Amount(100)

    # Act
    journal_entry_1.post(date, account_1, amount)
    journal_entry_1.post(date, account_2, -amount)

    # Assert
    assert journal_entry_1.increments is not None
    assert journal_entry_1.decrements is not None
    assert journal_entry_1.debits is not None
    assert journal_entry_1.credits is not None

# Generated at 2022-06-24 00:58:30.723399
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Test to validate the implementation of method __setattr__ of class JournalEntry
    """
    # Arrange
    journal = JournalEntry(date = datetime.date(2016, 1, 1), description = "journal", source = None, postings = [])
    
    # Act
    # Assert that postings isn't replaced by []
    journal.postings.append(Posting(journal, datetime.date(2016, 1, 1), "a", Direction.INC, 1))
    assert 3 == 1 + 2


# Generated at 2022-06-24 00:58:39.058658
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from borg.domain.accounting.accounts import Account, AccountType
    from borg.domain.accounting.journal import JournalEntry, Posting
    from borg.domain.commons.numbers import Amount, Quantity
    from borg.domain.commons.zeitgeist import DateRange

    transaction: JournalEntry[None] = JournalEntry(
        date=datetime.date.fromisoformat("2020-01-01"),
        description="Test Transaction",
        source=None,
    )

    account1: Account = Account(
        code="ASSETS:CASH",
        name="Cash",
        type=AccountType.ASSETS,
    )
    transaction.post(datetime.date.fromisoformat("2020-01-01"), account1, Quantity(+10))


# Generated at 2022-06-24 00:58:45.734105
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    account = Account('Assets', AccountType.ASSETS)
    direction = Direction.INC
    amount = Amount(12.00)
    journal = JournalEntry[Posting](datetime.date(2020,1,1), "Description", Posting)
    p = Posting(journal, datetime.date(2020,1,2), account, direction, amount)
    delattr(p, 'guid')


# Generated at 2022-06-24 00:58:49.260081
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry[str](date=datetime.date(2020, 12, 31), description="Can't get no satisfaction",
                             source="The Rolling Stones") == JournalEntry[str](
        date=datetime.date(2020, 12, 31), description="Can't get no satisfaction",
        source="The Rolling Stones")
# True

# Generated at 2022-06-24 00:58:51.352504
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(None, None, None, None, None) == Posting(None, None, None, None, None)


# Generated at 2022-06-24 00:58:52.671564
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    Posting(None, None, None, None, None).__repr__()


# Generated at 2022-06-24 00:59:00.459218
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    date = datetime.date(2020, 1, 14)
    account1 = Account(code="A", type=AccountType.ASSETS)
    account2 = Account(code="L", type=AccountType.LIABILITIES)
    journal_entry1 = JournalEntry(date, "Description", object()).post(date, account1, Quantity(1000))
    journal_entry2 = JournalEntry(date, "Description", object()).post(date, account1, Quantity(1000))
    journal_entry3 = JournalEntry(date, "Description", object()).post(date, account2, Quantity(1000))

    assert journal_entry1.__hash__() == journal_entry2.__hash__()
    assert journal_entry1.__hash__() != journal_entry3.__hash__()

# Generated at 2022-06-24 00:59:08.842880
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from pyledgertools.commons.others import datetime_to_date
    from pyledgertools.journaling.accounts import AccountType, root_account, sub_account
    from pyledgertools.journaling.journal_entries import JournalEntry

    journal_entry = JournalEntry(datetime_to_date(datetime.datetime.now), "description", Guid())
    journal_entry.post(datetime.date.today(), root_account(AccountType.ASSETS, "cash"), 100)
    assert journal_entry.postings[0].journal == journal_entry

# Generated at 2022-06-24 00:59:18.641758
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from c2cwsgiutils.util import dict_to_object
    import datetime
    from ddd_ledger.config import local_accounts, local_currencies
    from ddd_ledger.vault import AccountsVault, CurrenciesVault

    currencies = CurrenciesVault(local_currencies)
    accounts = AccountsVault(local_accounts, currencies)

    account_object = accounts.get("CASH")
    date = datetime.date.today()
    description = "Today"
    source = dict_to_object({"yes": True, "no": False})

# Generated at 2022-06-24 00:59:28.614448
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    date = datetime.date(2020, 1, 1)
    description = "Test Entry"
    source = JournalEntry
    postings = []
    guid = makeguid()
    journal_entry = JournalEntry(date, description, source)

    assert journal_entry.date == date, "Date is incorrect"
    assert journal_entry.description == description, "Description is incorrect"
    assert journal_entry.source == source, "Source is incorrect"
    assert journal_entry.postings == postings, "Postings is incorrect"
    assert journal_entry.guid == guid, "Guid is incorrect"


# JournalEntry.post() test 1, decrements

# Generated at 2022-06-24 00:59:29.636663
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 00:59:39.055884
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    e1 = JournalEntry(date=datetime.date.today(), description="Test JournalEntry", source=None)
    e2 = JournalEntry(date=datetime.date.today(), description="Test JournalEntry", source=None)
    e3 = JournalEntry(date=datetime.date.today(), description="Test JournalEntry", source=None)
    p1 = Posting(journal=e1, date=datetime.date.today(), account=Account(code="=1", name="Asset 1"), direction=Direction.INC, amount=Amount(100))
    p2 = Posting(journal=e2, date=datetime.date.today(), account=Account(code="=1", name="Asset 1"), direction=Direction.DEC, amount=Amount(100))

# Generated at 2022-06-24 00:59:39.827376
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True


# Generated at 2022-06-24 00:59:41.279119
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    entry = JournalEntry(None, "", None)
    assert entry.__hash__() == object.__hash__(entry)

# Generated at 2022-06-24 00:59:44.548501
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    with pytest.raises(AttributeError):
        posting = Posting(None, None, None, None, None)
        posting.journal = "journal"
        posting.date = None
        posting.account = None
        posting.direction = None
        posting.amount = None
# Test End


# Generated at 2022-06-24 00:59:49.168653
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journal_entry = JournalEntry[Account](datetime.date(2020, 3, 12), "test", Account(AccountType.ASSETS, "Acc1"), [])
    journal_entry.post(datetime.date(2020, 3, 12), Account(AccountType.REVENUES, "Acc2"), Quantity(6432.0))
    journal_entry.post(datetime.date(2020, 3, 12), Account(AccountType.ASSETS, "Acc1"), Quantity(6432.0))
    assert hash(journal_entry) == -1806026867

# Generated at 2022-06-24 00:59:58.557581
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    _T = "test"
    _quantity = Quantity(100)
    _date = datetime.date(1,1,1)
    _account = Account()
    _description = "description"

    _postings = []

    def _append(p):
        _postings.append(p)

    journalEntry = JournalEntry(_T, _date, _description, _append)
    journalEntry.post(_date, _account, _quantity)
    journalEntry.post(_date, _account, Quantity(-50))

    assert journalEntry.postings[0].amount == Amount(100)
    assert journalEntry.postings[0].direction == Direction.INC
    assert journalEntry.postings[0].is_debit
    assert not journalEntry.postings[0].is_credit

    assert journalEntry.postings[1].amount

# Generated at 2022-06-24 01:00:02.327609
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p1 = Posting(datetime.datetime.utcnow(), 'debit', 1, Account.of('account', 'type'), Direction.INC, Amount(10))
    p2 = Posting(datetime.datetime.utcnow(), 'credit', 2, Account.of('account', 'CREDIT'), Direction.DEC, Amount(20))
    assert hash(p1) == hash(p2)


# Generated at 2022-06-24 01:00:05.613687
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert eval(repr(_x.postings[0])).__dict__ == _x.postings[0].__dict__


# Generated at 2022-06-24 01:00:11.702404
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class MockJournalEntries(ReadJournalEntries[None]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[None]]:
            return [JournalEntry(datetime.date(2020, 4, 4), "test", None)]

    entries = MockJournalEntries()
    assert list(entries(DateRange(datetime.date(2020, 4, 4), datetime.date(2020, 4, 4))))

# Generated at 2022-06-24 01:00:16.548777
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry[float](datetime.date(2020, 1, 1), "Tansaction description.", 1.0)) == "JournalEntry(date=datetime.date(2020, 1, 1), description='Tansaction description.', source=1.0, guid='00000000-0000-0000-0000-000000000000')"


# Generated at 2022-06-24 01:00:26.666443
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from .accounts import AccountType

    from datetime import date

    p1 = Posting(1, date(2013,2,2), Account("TestAccount", AccountType.ASSETS, "Test Currency", 1000), Direction.INC, Amount(10))
    p2 = Posting(1, date(2013, 2, 2), Account("TestAccount", AccountType.ASSETS, "Test Currency", 1000), Direction.INC, Amount(10))
    p3 = Posting(2, date(2013, 2, 2), Account("TestAccount", AccountType.ASSETS, "Test Currency", 1000), Direction.INC, Amount(10))
    p4 = Posting(1, date(2013, 1, 2), Account("TestAccount", AccountType.ASSETS, "Test Currency", 1000), Direction.INC, Amount(10))

# Generated at 2022-06-24 01:00:32.677934
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(1, datetime.date(2019, 1, 1), "", "", "") == Posting(1, datetime.date(2019, 1, 1), "", "", "")
    assert Posting(1, datetime.date(2019, 1, 1), "", "", "") != Posting(2, datetime.date(2019, 1, 1), "", "", "")

# Generated at 2022-06-24 01:00:43.299675
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    r=Posting("eq1","eq1",Account(1,1),0,0)
    s=Posting("eq1","eq1",Account(1,1),0,0)
    t=Posting("eq1","eq1",Account(1,1),1,1)
    u=Posting("eq1","eq1",Account(2,2),2,2)
    v=Posting("eq1","eq1",Account(1,2),2,2)
    w=Posting("eq1","eq1",Account(1,1),2,2)
    x=Posting("eq1","eq1",Account(1,1),0,2)
    assert(r==s)
    assert (not (r==t))
    assert (not (r==u))
    assert (not (r==v))


# Generated at 2022-06-24 01:00:54.429911
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    source = "my source"
    date = datetime.date(year=2020, month=2, day=2)
    description = "my description"
    posting = Posting(JournalEntry(date, description, source), datetime.date(year=2020, month=1, day=1), Account("cash", AccountType.ASSETS), Direction.DEC, Amount(1))
    journal1 = JournalEntry(date, description, source)
    journal1.postings.append(posting)
    journal2 = JournalEntry(date, description, source)
    journal2.postings.append(posting)
    journal3 = JournalEntry(date, description, source)

# Generated at 2022-06-24 01:00:59.114159
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    print("test_JournalEntry___delattr__()")
    ## Arrange ##
    ## Act ##
    ## Assert ##


# Generated at 2022-06-24 01:01:06.296423
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j = JournalEntry(datetime.date.today(), "Trial Entry", 0)
    j.post(datetime.date.today(), Account(1), Quantity(10))
    j.post(datetime.date.today(), Account(2), Quantity(10))
    print(j)

#Unit Test for property increment of class JournalEntry

# Generated at 2022-06-24 01:01:06.915891
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    pass

# Generated at 2022-06-24 01:01:10.355844
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from dataclasses import dataclass, field
    from datetime import date

    @dataclass
    class _D:
        x: int = field(init=False)

    p = Posting(_D(), date(2020, 1, 1), Account('FOO', AccountType.ASSETS), Direction.INC, Amount(1000))
    p.x = 5
    assert p.x == 5
    p._x = 5
    try:
        p._x = 5
        raise Exception('Posting.__setattr__ did not freeze the dataclass')
    except Exception as e:
        assert str(e) == 'Cannot set read-only attribute'


# Generated at 2022-06-24 01:01:13.372000
# Unit test for constructor of class Posting
def test_Posting():
    Posting(JournalEntry(datetime.date.today(),'expenses',''), datetime.date.today(), Account(1,'3-230','expenses'), Direction.INC, Amount(2))

# Generated at 2022-06-24 01:01:15.839792
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    a=JournalEntry(date=datetime.date.today(),description="trial",source="source")
    assert isinstance(a,JournalEntry)

# Generated at 2022-06-24 01:01:23.944774
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import ChartOfAccounts

    class Nutroid(ReadJournalEntries[str]):
        def __init__(self, coa: ChartOfAccounts) -> None:
            self.coa = coa


# Generated at 2022-06-24 01:01:32.522381
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass(frozen=True)
    class _MockReadJournalEntries(Generic[_T]):
        """
        Test fixture for class ReadJournalEntries.
        """

        #: Unit test for ReadJournalEntries class
        # Return a list of different accounts

# Generated at 2022-06-24 01:01:33.030983
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    pass

# Generated at 2022-06-24 01:01:43.223335
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    a = JournalEntry(datetime.date(2020,1,1), 'desc', None)
    a.post(datetime.date(2020,1,1), Account(AccountType.ASSETS, 'asset'), 100)
    a.post(datetime.date(2020,1,1), Account(AccountType.EXPENSES, 'expense'), -100)

    # ValueError: cannot delete attribute 'date' of type 'datetime.date'
    # a.__delattr__('date')
    # AttributeError: 'JournalEntry' object has no attribute 'date'
    # print(a.date)
    # ValueError: cannot delete attribute 'description' of type 'str'
    # a.__delattr__('description')
    # AttributeError: 'JournalEntry' object has no attribute 'description'
    # print(a.

# Generated at 2022-06-24 01:01:53.315555
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from .accounts import AccountType
    from .currencies import Currency
    from .transaction import Transaction

    @dataclass(frozen=True)
    class DummyThing:
        pass

    def read_journal_entries(range: DateRange) -> Iterable[JournalEntry[Transaction]]:
        return []

    read_journal_entries_var: ReadJournalEntries[Transaction] = read_journal_entries
    assert read_journal_entries_var(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))) == []

    a1 = Account("A1", Currency("INR"), AccountType.ASSETS)
    a2 = Account("A2", Currency("INR"), AccountType.REVENUES)

# Generated at 2022-06-24 01:01:56.183713
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert Posting.__repr__

# Generated at 2022-06-24 01:02:02.029342
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account1: Account = Account(id="A1", type=AccountType.ASSETS)
    account2: Account = Account(id="A2", type=AccountType.LIABILITIES)
    entry: JournalEntry[None] = JournalEntry(datetime.date(2020, 1, 1), "Test", None)
    entry.post(datetime.date(2020, 1, 1), account1, Amount(10))
    entry.post(datetime.date(2020, 1, 1), account2, Amount(10))
    entry.validate()

# Generated at 2022-06-24 01:02:03.133881
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    with pytest.raises(TypeError):
        hash(JournalEntry)

# Generated at 2022-06-24 01:02:05.442176
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    with pytest.raises(AttributeError):
        JournalEntry.__delattr__('account')


# Generated at 2022-06-24 01:02:15.883689
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from pytest import raises
    from .accounts import Account, AccountType

    account = Account(AccountType.ASSETS, "Account 1")
    direction = Direction.INC

    # Try to compare two postings with the same JournalEntry, date, account and direction
    j = JournalEntry(date=datetime.date(2020, 6, 20), description="JournalEntry 1", source=None)
    p1 = Posting(journal=j, date=datetime.date(2020, 6, 20), account=account, direction=direction, amount=Amount(20))
    p2 = Posting(journal=j, date=datetime.date(2020, 6, 20), account=account, direction=direction, amount=Amount(50))

    assert not p1 == p2

    # Try to compare two postings with the same JournalEntry, date, account, direction and amount
   

# Generated at 2022-06-24 01:02:25.552332
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    date = datetime.date(2020, 9, 11)
    guid1 = makeguid()
    guid2 = makeguid()
    guid3 = makeguid()
    p1 = Posting(JournalEntry(date,"f1",1), date, Account("guid1","a1",""), Direction.INC, Amount(1))
    p2 = Posting(JournalEntry(date,"f1",1), date, Account("guid1","a1",""), Direction.INC, Amount(1))
    p3 = Posting(JournalEntry(date,"f2",2), date, Account("guid3","a3",""), Direction.INC, Amount(1))
    p4 = Posting(JournalEntry(date,"f2",2), date, Account("guid1","a1",""), Direction.INC, Amount(2))

# Generated at 2022-06-24 01:02:33.456710
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Setup the Journal
    je = JournalEntry(datetime.date(2020, 2, 2), "Journal of 2020", datetime.date(2020, 2, 2))
    je.post(datetime.date(2020, 2, 2), Account(AccountType.EXPENSES, "EXP", "Rent"), 100)
    je.post(datetime.date(2020, 2, 2), Account(AccountType.EXPENSES, "EXP", "Rent"), 100)

    # Go on with the test
    assert(je.postings)

# Generated at 2022-06-24 01:02:37.566586
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journal = JournalEntry[None](date=datetime.date.today(), description="")
    posting = Posting[None](journal, datetime.date.today(), Account(), Direction.INC, Amount(100))

    try:
        posting.amount = Amount(200)  # type: ignore

    except AttributeError:
        print("Type error: cannot assign attribute")
    

# Generated at 2022-06-24 01:02:43.350888
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journals = JournalEntry[str]
    journals.post(date = datetime.date(2020, 3, 15), account=accounts.access("Cash Account"), quantity=10000)
    journals.post(date = datetime.date(2020, 3, 15), account=accounts.access("Sales Account"), quantity=10000)
    journals.validate()
    assert journals

# Generated at 2022-06-24 01:02:52.840780
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account
    from .gl import GL
    from .glbook import GLBook
    from .gljournal import GLJournal
    from .ledger import Ledger
    from .glposting import GLPosting
    from .glaccount import GLAccount
    from .glaccountmap import GLAccountMap
    from .glpostingmap import GLPostingMap
    from .parties import Party
    import datetime
    import decimal

    ledger = Ledger("GAAP", "Cash")

    glaccount = GLAccount("ASSET_BANK_ACCOUNT", "Assets", "Bank Account", Account("ASSET_BANK_ACCOUNT", "Assets", "Bank Account"))  
    glaccountmap = GLAccountMap(glaccount, "MANUAL")

    gl = GL("A1", "Cash Deposit", "Cash Deposit.")

# Generated at 2022-06-24 01:03:00.058374
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    """
    Unit test for the __eq__ method of the JournalEntry class
    """
    source1 = "chequing"
    source2 = "savings"

    posting_date1 = datetime.date(2020, 3, 25)
    posting_date2 = datetime.date(2020, 3, 26)

    guid1 = "journal entry guid 1"
    guid2 = "journal entry guid 2"

    description1 = "description 1"
    description2 = "description 2"

    account1 = Account("Assets", "Chequing", AccountType.ASSETS)
    account2 = Account("Assets", "Savings", AccountType.ASSETS)

    direction1 = Direction.INC
    direction2 = Direction.DEC

    amount1 = Quantity(100.0)
    amount2 = Quantity(200.0)


# Generated at 2022-06-24 01:03:03.769992
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import now

    class X:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    X()

# Generated at 2022-06-24 01:03:14.651950
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from datetime import date
    from .accounts import AccountType, AccountTypeGroup, AccountTypeCode
    from .accounts import Account, Chart

    chart = Chart()
    chart.add(Account("Revenue", AccountType("Revenue", AccountTypeGroup.REVENUE, AccountTypeCode("REVENUE"))))
    chart.add(Account("Cost of Goods Sold", AccountType("Cost of Goods Sold", AccountTypeGroup.EXPENSE, AccountTypeCode("COGS"))))


# Generated at 2022-06-24 01:03:17.947230
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    ## Fixture:
    journal_entries = [JournalEntry(datetime.datetime.today(), "Testing", None)]
    ## Result:
    assert journal_entries[0] == journal_entries[0]

# Generated at 2022-06-24 01:03:26.453721
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass
    class Foo:
        bar: str

    class Baz:
        def __init__(self, bar: str) -> None:
            self.bar = bar

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[Foo]]:
        return []

    ReadJournalEntries()(DateRange.past())
    ReadJournalEntries()(DateRange.past()).__next__()
    ReadJournalEntries()(DateRange.past()).__iter__()
    ReadJournalEntries()(DateRange.past()).__sizeof__()
    ReadJournalEntries()(DateRange.past()).__reversed__()



# Generated at 2022-06-24 01:03:33.420598
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AssetAccount
    from .accounts import EquityAccount
    from .accounts import LiabilityAccount
    from .accounts import ExpenseAccount
    from .accounts import RevenueAccount

    asset_acc = AssetAccount("asset")
    equity_acc = EquityAccount("equity")
    liability_acc = LiabilityAccount("liability")
    expense_acc = ExpenseAccount("expense")
    revenue_acc = RevenueAccount("revenue")

    assert asset_acc.is_debit
    assert not asset_acc.is_credit

    assert equity_acc.is_debit
    assert not equity_acc.is_credit

    assert liability_acc.is_debit
    assert not liability_acc.is_credit


# Generated at 2022-06-24 01:03:43.217780
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journalEntry = Posting(JournalEntry(datetime.date.today(), 'test', 'test'), datetime.date.today(), 
    Account('test', 'test', AccountType.ASSETS), Direction.INC, Amount("3"))
    
    assert journalEntry.__repr__() == "Posting(journal=JournalEntry(date=2022-07-24, description='test', source='test', guid='a2d69c4f-6b76-4b03-b9d4-60a9a7aecf1c'), date=2022-07-24, account=Account(number='test', description='test', type=<AccountType.ASSETS: ('AS', 'Assets')>), direction=<Direction.INC: 1>, amount=Amount('3'))"


# Generated at 2022-06-24 01:03:49.013393
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    class PO:
        def __repr__(self):
            return 'TestPO'
    t = JournalEntry(PO(), 'Hello', 'World')
    print(t)
    assert t.__repr__() == "JournalEntry(date=datetime.date(datetime.datetime.now().year, 1, 1), " \
                           "description='Hello', source='World', guid='3b3e1b3f-e0ce-4d8e-a0c6-300b66d7c1a8', " \
                           "postings=None)"

# Generated at 2022-06-24 01:03:54.294246
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class _T:
        pass
    _T_instance = _T()  # type: ignore
    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T_instance]]:
        pass
    _read_journal_entries() # type: ignore

# Generated at 2022-06-24 01:03:55.308724
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    assert True

# Generated at 2022-06-24 01:04:04.395751
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    journal_entry = JournalEntry(date = datetime.date.today(), description = "Sample Description", source = object())
    posting = Posting(journal = journal_entry, date = datetime.date.today(), account = Account("Sample Account"), direction = Direction.INC, amount = Amount(1))
    try:
        del posting.direction
    except AttributeError as e:
        assert type(e) is AttributeError
        assert e.args[0] == "'Posting' object attribute 'direction' is read-only"
        assert e.__context__ is None
    else:
        raise AssertionError("No exception thrown")

# Generated at 2022-06-24 01:04:05.071757
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-24 01:04:09.856546
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    posting = Posting(JournalEntry(datetime.date(2019, 10, 1), "Description", None), datetime.date(2019, 10, 1), Account("Test Account"), Direction.DEC, Amount(1))
    assert hash(posting) == hash((posting.date, posting.account, posting.is_debit, posting.amount))


# Generated at 2022-06-24 01:04:21.233413
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Test case data
    postings = [Posting(None, datetime.date(2020, 1, 1), Account(), Direction.INC, Amount(123))]
    test_data = [
        {'description': 'description', 'date': datetime.date(2020, 1, 1), 'postings': postings},
        {'description': 'description', 'date': datetime.date(2020, 1, 1), 'postings': postings, 'guid': Guid("dummy")}
    ]

# Generated at 2022-06-24 01:04:27.271960
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import Account, AccountType
    from .books import BookLedger
    from ..commons import Money
    from ..commons.numbering import TestNumbering

    # Setup.
    TestNumbering()
    # Test.
    bl = BookLedger()
    acc = Account(AccountType.ASSETS, "Assets", "A100")
    # Test.
    assert bl.create_journal_entry("2018-01-01", "description", Money(10, 'USD'))\
        .post(acc, Money(10, 'USD'))\
        .post(acc, Money(10, 'USD')) == \
        bl.create_journal_entry("2018-01-01", "description", Money(10, 'USD'))\
        .post(acc, Money(10, 'USD'))\
        .post

# Generated at 2022-06-24 01:04:28.824667
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from .accounts import Account

    pass

# Generated at 2022-06-24 01:04:29.843359
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert ReadJournalEntries


# Generated at 2022-06-24 01:04:38.831434
# Unit test for constructor of class Posting
def test_Posting():
    #account_name = "Dummy Account"
    #account_type = "Dummy Account Type"

    #account = Account(account_name, account_type)
    account = Account("Dummy Account", "Dummy Account Type")

    direction = "Dummy Direction"

    date = "Dummy Date"

    amount = "Dummy Amount"

    journal = "Dummy Journal"

    posting = Posting(journal, date, account, direction, amount)

    assert posting.journal == journal
    assert posting.date == date
    assert posting.account == account
    assert posting.direction == direction
    assert posting.amount == amount 
    print("Test Posting - Constructor Test Passed")


# Generated at 2022-06-24 01:04:47.114499
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .accounts import Account
    import datetime
    from .journal_entries import JournalEntry, Posting
    from .commons.numbers import Amount, Quantity

    journal_entry = JournalEntry(datetime.date(year=2019, month=12, day=31), "test", None)

    with pytest.raises(PermissionError):
        Posting(journal_entry, None, None, None, None).__setattr__("journal_entry", None)

    with pytest.raises(PermissionError):
        Posting(journal_entry, None, None, None, None).__setattr__("date", None)

    with pytest.raises(PermissionError):
        Posting(journal_entry, None, None, None, None).__setattr__("account", None)


# Generated at 2022-06-24 01:04:54.157398
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_ = JournalEntry[object](datetime.date.today(), "Test Posting", None)
    journal_.post(datetime.date.today(), Account.create("1", "Cash"), 10)
    journal_.post(datetime.date.today(), Account.create("2", "Sales"), -5)
    journal_.post(datetime.date.today(), Account.create("3", "Sales", AccountType.REVENUES), 5)
    journal_.validate()

# Generated at 2022-06-24 01:04:58.594774
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class SomeClass:
        def __init__(self):
            pass

    def read_journal_entries(period: DateRange):
        pass

    # Returns true if the type is same
    assert read_journal_entries.__class__ == ReadJournalEntries.__class__

# Generated at 2022-06-24 01:05:02.829391
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    """Unit test for method __eq__ of class JournalEntry."""
    # Given
    from .accounts import ASSETS, EQUITIES, EXPENSES, LIABILITIES, REVENUES

    # When
    journal_entry_1 = JournalEntry[str](datetime.date(2017, 1, 1), "Description", "Source") \
        .post(datetime.date(2017, 1, 1), REVENUES, Amount(100)) \
        .post(datetime.date(2017, 1, 1), ASSETS, Amount(100))

# Generated at 2022-06-24 01:05:13.217572
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from ..commons.test_utils import assert_test_case
    Posting(JournalEntry[int](datetime.date.today(), "description", 10), datetime.date.today(), Account("name",
    AccountType.ASSETS), Direction.INC, Amount(10)).__dict__
    assert_test_case(Posting(JournalEntry[int](datetime.date.today(), "description", 10), datetime.date.today(),
    Account("name", AccountType.ASSETS), Direction.INC, Amount(10)), {"journal": JournalEntry[int](datetime.date.today(),
    "description", 10), "date": datetime.date.today(), "account": Account("name", AccountType.ASSETS), "direction":
    Direction.INC, "amount": Amount(10)}, True)

# Generated at 2022-06-24 01:05:23.436844
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    @dataclass(frozen=True)
    class Source(Generic[_T]):
        guid: Guid

    entry1 = JournalEntry[Source](date=datetime.date(2020, 1, 1), description="Void Journal Entry")
    entry1.validate()

    entry2 = JournalEntry[Source](date=datetime.date(2020, 1, 1), description="Revenue Journal Entry", source=Source(makeguid()))
    entry2.post(date=datetime.date(2020, 1, 1), account=Account(makeguid(), name="Revenue Account", type=AccountType.REVENUES), quantity=100)
    entry2.post(date=datetime.date(2020, 1, 1), account=Account(makeguid(), name="Assets Account", type=AccountType.ASSETS), quantity=-100)
    entry

# Generated at 2022-06-24 01:05:24.475236
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # Test passed (no exception)
    assert True
    

# Generated at 2022-06-24 01:05:34.909021
# Unit test for method __setattr__ of class JournalEntry

# Generated at 2022-06-24 01:05:40.649241
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    anAccount = Account(AccountType.ASSETS, Guid(), 'test account')
    anEntry = JournalEntry(datetime.date(2019, 2, 14), 'test journal entry', "test")
    anEntry.post(date = datetime.date(2019, 2, 14), account = anAccount, quantity = 100)
    assert anEntry.postings[0].journal is anEntry
    delattr(anEntry, 'date')
    assert not hasattr(anEntry, 'date')
    assert anEntry.postings[0].journal is anEntry

# Generated at 2022-06-24 01:05:42.931594
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    je1 = JournalEntry(date = datetime.date(2019, 1, 1), description = 'something', source = object())
    je2 = JournalEntry(date = datetime.date(2019, 1, 1), description = 'something', source = object())
    assert je1 == je2

# Generated at 2022-06-24 01:05:51.151379
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    print("testing JournalEntry post")
    je = JournalEntry(datetime.date.today(), "testing", None)
    je.post(datetime.date.today(), Account("Assets:Cash"), 10000)
    je.post(datetime.date.today(), Account("Equities:Opening-Balances"), -10000)
    for p in je.postings:
        print(p)

    assert je.validate() == None

# Generated at 2022-06-24 01:05:54.741761
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    j = JournalEntry(datetime.now(),"Tested",2)
    assert j.date == datetime.now()
    assert j.description == "Tested"
    assert j.source == 2
    assert j.postings == []
    assert len(j.guid) == 32


# Generated at 2022-06-24 01:06:00.035227
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Given
    from .accounts import Account
    account = Account('123456789', 'Income', AccountType.REVENUES)
    journal_entry = JournalEntry('2019-5-5', 'description', "source")
    journal_entry.post(1,account,+20000)
    # When
    print(journal_entry)
    # Then
    # __repr__ pass

# Generated at 2022-06-24 01:06:02.896540
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass
    class _T: pass
    assert issubclass(ReadJournalEntries[_T], Protocol)

# Generated at 2022-06-24 01:06:11.391562
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    account_chart = {
        Account.equity: Account(Account.equity, AccountType.EQUITIES),
        Account.cash: Account(Account.cash, AccountType.ASSETS),
    }
    source = None

    def post_increment(j: JournalEntry, a: str, q: int) -> None:
        j.post(j.date, account_chart[a], q)

    je1 = JournalEntry(datetime.date(2018, 1, 1), "Test 1", source)
    je2 = JournalEntry(datetime.date(2018, 1, 1), "Test 1", source)
    assert je1 != je2

    je2 = JournalEntry(datetime.date(2018, 1, 1), "Test 2", source)
    assert je1 != je2
    

# Generated at 2022-06-24 01:06:13.637824
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    def _f():
        Posting("j", "d", "a", "d", "a")
    _f()


# Generated at 2022-06-24 01:06:14.214823
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass

# Generated at 2022-06-24 01:06:22.442414
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    import inspect
    import ast
    from .accounts import Account, AccountType, OpenAccounts

    open_accounts: OpenAccounts = dict(
        a1=Account(makeguid(), "a1", AccountType.ASSETS),
        a2=Account(makeguid(), "a2", AccountType.EXPENSES),
        a3=Account(makeguid(), "a3", AccountType.EXPENSES),
        a4=Account(makeguid(), "a4", AccountType.REVENUES),
        a5=Account(makeguid(), "a5", AccountType.REVENUES),
    )


# Generated at 2022-06-24 01:06:25.287285
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    j = JournalEntry[int](date=datetime.date(2019, 5, 23), description="dummy", source=123)
    assert j.__hash__() is not None



# Generated at 2022-06-24 01:06:26.809141
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert JournalEntry(datetime.datetime.today().date(), 'Test', 'Test')

# Generated at 2022-06-24 01:06:33.810669
# Unit test for constructor of class Posting
def test_Posting():
    account = Account("abcd", "abcd", AccountType.EQUITIES)
    p = Posting("j1", datetime.date.today(), account, Direction.INC, Amount(10))
    assert p.journal == "j1"
    assert p.date == datetime.date.today()
    assert p.account == account
    assert p.direction == Direction.INC
    assert p.amount == Amount(10)
    assert p.is_debit
    assert not p.is_credit


# Generated at 2022-06-24 01:06:45.261176
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j1 = JournalEntry("2019-04-02", "", "")
    j1.post("2019-04-03", "a1", +123)
    j1.post("2019-04-04", "b2", -456)

    assert j1.postings[0].date == "2019-04-03"
    assert j1.postings[0].account == "a1"
    assert j1.postings[0].direction == Direction.INC
    assert j1.postings[1].date == "2019-04-04"
    assert j1.postings[1].account == "b2"
    assert j1.postings[1].direction == Direction.DEC

    j2 = JournalEntry("2019-04-02", "", "")

# Generated at 2022-06-24 01:06:53.119239
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # set up
    je = JournalEntry(datetime.date(2019,11,13), 'test', 't')
    # test
    try:
        je.postings = [Posting(je, datetime.date(2019,11,13), Account('A', AccountType.ASSETS), Direction.INC, Amount(0))]
    except Exception as e:
        assert isinstance(e, AttributeError)
        assert e.args == ("can't set attribute",)
    else:
        assert False, 'expected exception'


# Generated at 2022-06-24 01:06:54.288309
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert True


# Generated at 2022-06-24 01:06:58.420625
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    journal = JournalEntry[str]("", "", "")
    delattr(journal, 'date')
    delattr(journal, 'postings')
    delattr(journal, 'guid')
    delattr(journal, 'source')
    delattr(journal, 'description')

    print('finished')


# Generated at 2022-06-24 01:07:04.823540
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    test_data = [
            Posting(None, datetime.date(2020, 1, 1), Account(Guid.make(), 'Test Account'), Direction.INC, Amount(1)),
            Posting(None, datetime.date(2020, 1, 1), Account(Guid.make(), 'Test Account'), Direction.INC, Amount(1)),
    ]

    # Test the equality of two posting instances that should be equal
    assert test_data[0] == test_data[1]


# Generated at 2022-06-24 01:07:11.857280
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    entry = JournalEntry(date=datetime.date(2019, 12, 31), description='test_JournalEntry', source=None)
    entry.post(datetime.date(2019, 12, 31), Account('test_JournalEntry'), Quantity(1))

    guid_e = entry.guid
    guid_p = entry.postings[0].journal.guid

    assert guid_e == guid_p


# Generated at 2022-06-24 01:07:14.649023
# Unit test for constructor of class Posting
def test_Posting():
    post = Posting(1, 2, 3, 4)
    assert post.journal == 1
    assert post.date == 2
    assert post.account == 3
    assert post.direction == 4

# Generated at 2022-06-24 01:07:21.349710
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    posting1 = Posting(
        "001",
        datetime.date.today(),
        Account("002", "test2", AccountType.EQUITIES, None),
        Direction.INC,
        Amount(20)
    )

    posting2 = Posting(
        "001",
        datetime.date.today(),
        Account("002", "test2", AccountType.EQUITIES, None),
        Direction.INC,
        Amount(20)
    )

    assert posting1 == posting2


# Generated at 2022-06-24 01:07:26.677907
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from ..commons.zeitgeist import now
    from .accounts import account
    
    src = object()
    je = JournalEntry(now(), "An entry", src)
    je.post(now(), account("CASH"), +151)
    je.post(now(), account("REVENUE"), -151)

    je.validate()

# Generated at 2022-06-24 01:07:33.602172
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    d = datetime.date.today()
    des = "Description"
    source = 123
    direction = Direction.INC
    amount = 300
    entry = JournalEntry(d,des,source)
    entry.postings.append(Posting(entry,d,Account("123",AccountType.ASSETS),direction,amount))

    s = '<JournalEntry value=<date=2020-08-05, description=\'Description\', source=123, guid=\'2edc5cc3-4b4d-4d4b-99e4-ec4d8c5b5f5e\'>'
    assert str(entry) == s

# Generated at 2022-06-24 01:07:40.587763
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from .accounts import AccountType, Account
    from .currency import Currency
    from .context import Context
    from .builders import make_journal
    j = make_journal(Currency.USD, Account(AccountType.ASSETS))
    with Context():
        j.post(datetime.date.today(), Account(AccountType.EXPENSES), 10)
        j.post(datetime.date.today(), Account(AccountType.EXPENSES), -10)
        del j.postings
        del j.date
        del j.description
        del j.source
        del j.guid