

# Generated at 2022-06-24 00:57:46.976457
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import Account, AccountType
    from .businesss import Transaction
    # Arrange
    source = Transaction(100)
    journal = JournalEntry(datetime.date(2020, 1, 1), "Test", source)
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.REVENUES, "Sales", None, None), 100)
    journal.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash", None, None), -100)
    # Act
    repr(journal)
    # Assert
    assert True

# Generated at 2022-06-24 00:57:47.634268
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    assert False

# Generated at 2022-06-24 00:57:55.352369
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    import datetime
    from dataclasses import dataclass
    from typing import List
    @dataclass(frozen=True)
    class JournalEntry:
        a=1
        b=2
        c=3
        def __repr__(self):
            return "{self.a} {self.b} {self.c}".format(self=self)
    assert Posting(journal=JournalEntry(),date=datetime.date(2020,1,1),account=Account("", ""),direction=Direction.INC,amount=Quantity(1)).__repr__() == "1 2 3"

# Generated at 2022-06-24 00:57:59.273585
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry(datetime.date(2019, 3, 4), "test desc", "test source")
    assert je.date == datetime.date(2019, 3, 4)
    assert je.description == "test desc"
    assert je.source == "test source"
    assert je.postings == []
    assert not je.increments
    assert not je.decrements
    assert not je.debits
    assert not je.credits


# Generated at 2022-06-24 00:58:09.528674
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    ## Postings in which debits and credits do not match.
    p1 = Posting(
        JournalEntry(datetime.date.today(), "Test Journal Entry", "source"),
        datetime.date.today(),
        Account("Assets/Cash"),
        Direction.INC,
        Amount(1000),
    )
    p2 = Posting(
        JournalEntry(datetime.date.today(), "Test Journal Entry", "source"),
        datetime.date.today(),
        Account("Expenses/Rent"),
        Direction.DEC,
        Amount(600),
    )

    try:
        JournalEntry(
            datetime.date.today(),
            "Test Journal Entry",
            "source",
            [p1, p2],
        ).validate()
    except AssertionError:
        pass

    ## Postings in

# Generated at 2022-06-24 00:58:16.198892
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journal = JournalEntry(datetime.date(2019, 8, 3), "Payment", None)
    assert journal == JournalEntry(datetime.date(2019, 8, 3), "Payment", None)

    journal.post(datetime.date(2019, 8, 3), Account("A/R", AccountType.ASSETS, None), +1000)
    journal.post(datetime.date(2019, 8, 3), Account("Cash", AccountType.ASSETS, None), -1000)
    assert journal == JournalEntry(datetime.date(2019, 8, 3), "Payment", None).post(datetime.date(2019, 8, 3), Account("A/R", AccountType.ASSETS, None), +1000).post(datetime.date(2019, 8, 3), Account("Cash", AccountType.ASSETS, None), -1000)
    

# Generated at 2022-06-24 00:58:20.783346
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    j1 = JournalEntry(datetime.date.today(), "test", None)
    j2 = JournalEntry(datetime.date.today(), "test", None)
    j3 = JournalEntry(datetime.date.today(), "test2", None)
    assert j1 == j2 # Check if two instances with the same hash are equal
    assert j1 != j3
    assert hash(j1) == hash(j2)
    assert hash(j1) != hash(j3)

# Generated at 2022-06-24 00:58:30.271833
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    account = Account('Assets', 'Cash', AccountType.ASSETS)
    je1 = JournalEntry(datetime.date.today(), 'deposit', None, [Posting(None, datetime.date.today(), account, Direction.INC, Amount('23.32'))])
    je2 = JournalEntry(datetime.date.today(), 'deposit', None, [Posting(None, datetime.date.today(), account, Direction.INC, Amount('23.32'))])
    assert je1 == je2
    je3 = JournalEntry(datetime.date.today(), 'deposit', None, [Posting(None, datetime.date.today(), account, Direction.INC, Amount('23.32')), Posting(None, datetime.date.today(), account, Direction.INC, Amount('23.32'))])
    assert je1

# Generated at 2022-06-24 00:58:32.626638
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert 'posting.Direction.INC' in repr(Posting)
    assert 'posting.Posting' in repr(Posting)


# Generated at 2022-06-24 00:58:38.863865
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .assets import instruments
    import inspect

    journal_entries_reader: ReadJournalEntries[inspect._empty] = lambda period: [1, 2, 3]
    assert list( journal_entries_reader( DateRange() ) ) == [1, 2, 3]

# Generated at 2022-06-24 00:58:39.415121
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    assert 1==1

# Generated at 2022-06-24 00:58:48.723030
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry[int](date = datetime.date.today(), description = "", source = 1)
    je = je.post(date = datetime.date.today(), account = Account(AccountType.EXPENSES, Guid(), ""), quantity = 1)
    je = je.post(date = datetime.date.today(), account = Account(AccountType.REVENUES, Guid(), ""), quantity = 1)
    assert je.date == datetime.date.today()
    assert je.description == ""
    assert je.source == 1
    assert je.guid == je.postings[0].journal.guid
    assert je.guid != je.postings[1].journal.guid
    je.validate()

# Generated at 2022-06-24 00:58:51.360119
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    try:
        test = Posting(1,1,1,1,1)
        del test.date
    except:
        print("Posting - __delattr__ - ERROR")


# Generated at 2022-06-24 00:58:54.990750
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    ## Test journal entry:
    je = JournalEntry[object](datetime.date(2016, 9, 8), "Test journal entry", None)

    ## Test consistent hash values:
    assert je.__hash__() == je.__hash__()

    ## Test hash value is not zero:
    assert bool(je.__hash__())

# Generated at 2022-06-24 00:59:01.498308
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # Create and return a journal entry
    def create_je():
        je = JournalEntry[None](date=None, description=None, source=None)
        return je
    # Create a journal entry
    je = create_je()
    # Create a posting
    posting = Posting(je, None, None, None, None)
    # Posting is frozen, so it should throw an exception
    try:
        posting.a = 1
        assert False, "Code should raise exception."
    except AttributeError:
        # Expects to fail with Attribute Error
        assert True, "Code should raise exception."
    except Exception:
        # Expects to fail with Attribute Error
        assert False, "Code should raise Attribute Error."

# Generated at 2022-06-24 00:59:02.526522
# Unit test for constructor of class Posting
def test_Posting():
    pass



# Generated at 2022-06-24 00:59:11.274883
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    d = datetime.date(2020,1,1)
    d2 = datetime.date(2020,1,2)
    s = 10
    s2 = 20
    s3 = -10
    j1 = JournalEntry(d, "test journal entry", None, None)
    j1.post(d, "test account", s)
    j1.post(d2, "test account", s2)
    j1.post(d, "test account2", s3)
    assert j1.increments[0].amount == s
    assert j1.increments[1].amount == s2
    assert j1.decrements[0].amount == s3
    assert j1.debits[0].amount == s
    assert j1.debits[1].amount == s2

# Generated at 2022-06-24 00:59:19.193495
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class Temp:
        pass

    try:
        x = ReadJournalEntries()
    except TypeError:
        pass
    else:
        raise Exception('Incorrect type check for ReadJournalEntries')

    try:
        x = ReadJournalEntries.__call__
    except TypeError:
        pass
    else:
        raise Exception('Incorrect type check for ReadJournalEntries')

    try:
        x = ReadJournalEntries.__doc__
    except TypeError:
        pass
    else:
        raise Exception('Incorrect type check for ReadJournalEntries')

    try:
        x = ReadJournalEntries.__init__
    except TypeError:
        pass
    else:
        raise Exception('Incorrect type check for ReadJournalEntries')


# Generated at 2022-06-24 00:59:23.012043
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    je = JournalEntry[str]("2019-01-01", "Test", "", None)
    assert repr(je) == "JournalEntry(date=datetime.date(2019, 1, 1), description='Test', source='', guid='<unknown>')"

# Generated at 2022-06-24 00:59:34.749265
# Unit test for method __call__ of class ReadJournalEntries

# Generated at 2022-06-24 00:59:42.206221
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from ..trade.deal import Deal
    from ..time.timeperiods import DateRange

    #: Start date of the test deal.
    purchase_date = datetime.date.today()

    #: Date range of the test deal.
    date_range = DateRange(purchase_date, datetime.date(2050, 12, 31))

    #: Test deal.
    test_deal = Deal(deal_id=Guid.make(),
                     description="Test Deal",
                     counter_party="XYZ Limited",
                     maturity_date=date_range.end,
                     purchase_date=purchase_date,
                     face_amount=1000000)

    #: Test posting.
    test_posting = Posting(object(), datetime.date.today(), Account(), Direction.INC, Amount())

    # This should pass
    test_post

# Generated at 2022-06-24 00:59:49.737347
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass
    class JournalEntryReader():
        def __call__(self, period: DateRange):
            pass
    reader = JournalEntryReader()
    assert ReadJournalEntries.__conform__(reader) == reader
    assert ReadJournalEntries.__instancecheck__(reader)
    assert not ReadJournalEntries.__instancecheck__(1)
test_ReadJournalEntries()

# Generated at 2022-06-24 00:59:52.639185
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    source = ...
    journal = JournalEntry[type(source)](datetime.date(2020, 4, 29), "test", source)
    journal.post(datetime.date(2020, 4, 29), Account("checking"), Quantity(100))
    journal.post(datetime.date(2020, 4, 29), Account("credit"), Quantity(-50))
    journal.validate()

# Generated at 2022-06-24 01:00:00.792742
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    import pytest
    from datetime import date
    from .accounts import Account
    from .business import Order

    Order = Order.__args__
    Order.__origin__ = Order
    Order.__name__ = "Order"

    def test_call():

        journal = JournalEntry(date(2018, 10, 11), "test", Order(1, date(2018, 10, 11)))
        journal.post(date(2018, 10, 11), Account.assets_cash, +100)
        journal.post(date(2018, 10, 11), Account.expenses_merchandise, -100)
        journal.validate()
        entries.append(journal)

    def test_journal_date():
        journal = JournalEntry(date(2018, 10, 12), "test", Order(1, date(2018, 10, 11)))

# Generated at 2022-06-24 01:00:11.089621
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    #: Date of the entry.
    date1 = datetime.date(2020, 1, 1)
    #: Description of the entry.
    description1 = "This is description 1"
    #: Business object as the source of the journal entry.
    source1 = "This is source 1"

    journalEntry1 = JournalEntry[str](
                date=date1,
                description=description1,
                source=source1,
                postings=list()
            )


    #: Date of the entry.
    date2 = datetime.date(2020, 1, 1)
    #: Description of the entry.
    description2 = "This is description 1"
    #: Business object as the source of the journal entry.
    source2 = "This is source 1"


# Generated at 2022-06-24 01:00:14.001590
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p = Posting(None, None, None, None, None)
    assert hash(p) == hash((p.date, p.account, p.direction, p.amount))

# Generated at 2022-06-24 01:00:24.804852
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # GIVEN:
    Account_obj = Account(name="Account1", type=AccountType.ASSETS)
    Entry_obj = JournalEntry(date=datetime.date(2019, 1, 20), description="Entry1", source="Test1")
    Entry_obj.post(date=datetime.date(2019, 1, 20), account=Account_obj, quantity=10)
    Entry_obj.post(date=datetime.date(2019, 1, 20), account=Account_obj, quantity=-10)

    # WHEN:
    Entry_obj.validate()
    entries = list(Entry_obj.decrements)

    # THEN:
    assert entries
    assert len(entries) == 1
    assert entries[0].journal == Entry_obj
    assert entries[0].date == Entry_obj.date

# Generated at 2022-06-24 01:00:31.084437
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from . import accounts, entities
    from ..commons.numbers import D

    # Create a source:
    source = entities.Trade(accounts.StockAccount(), accounts.CashAccount(), "XYZ", D("100"), D("100"), D("50"))

    # Create a journal entry:
    journal = JournalEntry[entities.Trade]()

    # Post to one account:
    journal = journal.post(datetime.date.today(), accounts.StockAccount(), D("50"))
    # Post to another account:
    journal = journal.post(datetime.date.today(), accounts.CashAccount(), D("-150"))

    # Check:
    print(journal.postings)
    # Get the first posting:
    posting1 = journal.postings[0]
    # Delete the 'accounts' attribute of the first posting:
    del posting

# Generated at 2022-06-24 01:00:40.312299
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from unittest.mock import MagicMock
    from ..commons.zeitgeist import SundayMorning, Yesterday

    # Do nothing
    def f():
        pass

    # Get a callable
    callback = ReadJournalEntries(MagicMock())

    # Consume period parameter and return Dummy value
    callback(SundayMorning)

    # Consume period parameter and return Dummy value
    callback(Yesterday)

    # Do nothing
    callback = ReadJournalEntries(f)

    # Consume period parameter and return Dummy value
    callback(SundayMorning)

    # Consume period parameter and return Dummy value
    callback(Yesterday)

# Generated at 2022-06-24 01:00:42.906228
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry(datetime.date(2001,1,1), "", "")
    assert j.validate() is None

# Generated at 2022-06-24 01:00:53.890852
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType, Account, BalanceSheet
    from .transactions import Transaction, TransactionType
    from .ledger import Ledger
    from .mutations import Mutation

    # Set up ledger:
    ledger = Ledger()

    # Set up accounts:
    ledger.create_account(Account("Expected Cash", AccountType.ASSETS))
    ledger.create_account(Account("Received Cash", AccountType.ASSETS))
    ledger.create_account(Account("Sales Revenue", AccountType.REVENUES))
    ledger.create_account(Account("Office Supplies", AccountType.EXPENSES))

    # Set up transaction types:
    ledger.create_transaction_type(TransactionType("Buy", BalanceSheet, Mutation("+Expected Cash"), Mutation("-Office Supplies")))
    ledger.create_transaction_

# Generated at 2022-06-24 01:01:05.333494
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry(
                date = datetime.date(2017, 9, 4),
                description = "Transaction 1",
                source = None,
                guid = Guid("4b4e8161-f75a-4e06-be50-43eb2a48d3a3")) == \
           JournalEntry(
                date = datetime.date(2017, 9, 4),
                description = "Transaction 1",
                source = None,
                guid = Guid("4b4e8161-f75a-4e06-be50-43eb2a48d3a3"))

# Generated at 2022-06-24 01:01:10.040025
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
	assert(repr(Posting(JournalEntry, datetime.date, Account, Direction.INC, 10)) == "Posting(journal=JournalEntry,date=datetime.date,account=Account,direction=<Direction.INC: 1>,amount=10)")

# Generated at 2022-06-24 01:01:18.507767
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    # Arrange
    date = datetime.date(2019, 4, 27)
    account = Account.new("Inventory", AccountType.ASSETS)
    direction = Direction.INC
    amount = Amount(1234)
    journal = JournalEntry(date, "desc", object())

    # Act
    posting_1 = Posting(journal, date, account, direction, amount)
    posting_2 = Posting(journal, date, account, direction, amount)

    # Assert
    assert hash(posting_1) == hash(posting_2)


# Generated at 2022-06-24 01:01:22.144132
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def empty_reader() -> Iterable[JournalEntry[None]]:
        return []

    assert empty_reader() == ReadJournalEntries.__call__(empty_reader, DateRange())

# Generated at 2022-06-24 01:01:31.890648
# Unit test for method __repr__ of class JournalEntry

# Generated at 2022-06-24 01:01:35.267063
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal_entry = JournalEntry(datetime.date(2020,5,5),'this is journal entry','journal entry')
    assert journal_entry.date == datetime.date(2020,5,5)
    assert journal_entry.description == 'this is journal entry'
    assert journal_entry.source == 'journal entry'


# Generated at 2022-06-24 01:01:44.441247
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from datetime import date
    from unittest.mock import Mock
    journalEntry = JournalEntry(date(2020, 5, 1), "1/5/2020", "Test")
    Posting(journalEntry, date(2020, 5, 1), Account(1,"TestAccount","ASSET"), Direction.INC, Amount(10))

# Generated at 2022-06-24 01:01:49.632498
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    _source = object()
    _account = Account("1", AccountType.EQUITIES)
    _direction = Direction.INC
    _amount = Amount(1)

    _journal = JournalEntry(datetime.date(2020, 10, 1), "Description", _source)
    _posting = Posting(_journal, datetime.date(2020, 10, 1), _account, _direction, _amount)

    assert _posting is not None
    assert hasattr(_posting, "date")
    assert _posting.__delattr__("date")
    assert not hasattr(_posting, "date")



# Generated at 2022-06-24 01:01:54.018378
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    jour = JournalEntry("mock")
    p = Posting(jour, "mockdate", "mockaccount", "mockdirection", "mockamount")
    assert p.__repr__() == "Posting(journal='JournalEntry(mock)', date='mockdate', account='mockaccount', direction='mockdirection', amount='mockamount')"



# Generated at 2022-06-24 01:01:56.704927
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal = JournalEntry(date=datetime.date.fromisoformat("2020-11-01"), description="Financial accounting")
    assert repr(journal) == "JournalEntry(date=2020-11-01, description='Financial accounting', guid=ae56dd7f)"


# Generated at 2022-06-24 01:02:01.396596
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from datetime import date
    from .accounts import Accounts

    p1: Posting = Posting(None, date(2020, 1, 1), Accounts['Assets:Cash'], Direction.DEC, Amount(100))
    p2: Posting = Posting(None, date(2020, 1, 1), Accounts['Assets:Cash'], Direction.DEC, Amount(100))
    p3: Posting = Posting(None, date(2020, 1, 2), Accounts['Assets:Cash'], Direction.DEC, Amount(100))

    assert p1 == p2
    assert p1 != p3


# Generated at 2022-06-24 01:02:05.899742
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    assert hash(Posting('journal',datetime.datetime(2000, 1, 1), Account('account', AccountType.REVENUES), Direction.DEC, Amount(10))) == hash(('journal',datetime.datetime(2000, 1, 1), Account('account', AccountType.REVENUES), Direction.DEC, Amount(10)))


# Generated at 2022-06-24 01:02:07.169766
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    Posting(None, None, None, None, None)


# Generated at 2022-06-24 01:02:07.512853
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass

# Generated at 2022-06-24 01:02:09.595575
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    source = "str"
    je = JournalEntry(datetime.date.today(), "Test", source)
    assert hash(je) == hash(source)

# Generated at 2022-06-24 01:02:21.130440
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    account1 = Account(name="Account1")
    account2 = Account(name="Account2")
    account3 = Account(name="Account3")
    account4 = Account(name="Account4")
    journal_entry1 = JournalEntry[int](datetime.date(2018, 10, 1), "Description", 1)
    journal_entry2 = JournalEntry[int](datetime.date(2018, 10, 2), "Description", 2)
    posting1 = Posting(journal_entry1, datetime.date(2018, 10, 1), account1, Direction.INC, Amount(10))
    posting2 = Posting(journal_entry1, datetime.date(2018, 10, 1), account2, Direction.INC, Amount(10))

# Generated at 2022-06-24 01:02:24.354129
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    j1 = JournalEntry(datetime.date(2019, 9, 1), "JournalEntry", "Source")
    j1.date = datetime.date(2019, 9, 2)
    j1.description = "modified"
    j1.source = "Modified Source"

# Generated at 2022-06-24 01:02:26.533639
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j=JournalEntry[str]("a","a",[])
    assert j.postings==[]
    j1=j.post("a","a",1)
    assert j1.postings[0].amount.value==1



# Generated at 2022-06-24 01:02:37.978290
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import itertools
    import pytest
    from .accounts import AccountType
    from .ledger import TRADING, LEDGER

    c1 = LEDGER.find_account(AccountType.CASH, TRADING)
    c2 = LEDGER.find_account(AccountType.CASH, TRADING)
    i1 = LEDGER.find_account(AccountType.CREDITOR, TRADING)
    i2 = LEDGER.find_account(AccountType.CREDITOR, TRADING)
    j1 = JournalEntry((1, 1), "Journal Entry", TRADING)
    j2 = JournalEntry((1, 1), "Journal Entry", TRADING)
    j3 = JournalEntry((1, 1), "Journal Entry", TRADING)


# Generated at 2022-06-24 01:02:42.226250
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # Setup:
    journal_entry = JournalEntry[int](date=datetime.date.today(), description="Dummy Journal Entry.")

    # Exercise:
    del journal_entry.postings

    # Verify:
    assert not hasattr(journal_entry, 'postings')

# Generated at 2022-06-24 01:02:44.121712
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass


# Generated at 2022-06-24 01:02:47.144706
# Unit test for constructor of class Posting
def test_Posting():
    posting = Posting()
    assert isinstance(posting, Posting)
    assert posting.journal == None
    assert posting.date == None
    assert posting.account == None
    assert posting.direction == None
    assert posting.amount == None


# Generated at 2022-06-24 01:02:56.615157
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    import pytest
    # If the journal entry is the same, the __eq__ of JournalEntry should return True

    # Create a journal entry
    account = Account("Account A", AccountType.ASSETS)
    journal_one = JournalEntry(datetime.date(2020,10,10), "test journal_one", 1)
    journal_one.post(datetime.date(2020,10,10), account, 100)

    journal_two = JournalEntry(datetime.date(2020,10,10), "test journal_one", 1)
    journal_two.post(datetime.date(2020,10,10), account, 100)

    # Expected result is True
    result = journal_one == journal_two
    assert result is True



# Generated at 2022-06-24 01:02:59.203538
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    obj = Posting(None, None, None, None, None)
    assert obj.__repr__() == "Posting(None, None, None, None, None)"



# Generated at 2022-06-24 01:03:11.036737
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    date = datetime.date.today()
    description = 'Test'
    source = 'TestSource'
    account1 = Account('TestAccount1', AccountType.EQUITIES)
    amount1 = Amount(1000)
    account2 = Account('TestAccount2', AccountType.ASSETS)
    amount2 = Amount(1000)
    direction1 = Direction.INC
    direction2 = Direction.DEC

    post1 = Posting(JournalEntry(date, description, source), date, account1, direction1, amount1)
    post2 = Posting(JournalEntry(date, description, source), date, account2, direction2, amount2)

    j1 = JournalEntry(date, description, source)
    j1.postings.append(post1)
    j1.postings.append(post2)


# Generated at 2022-06-24 01:03:16.154028
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert eval(repr(
        Posting("journal", datetime.date.today(), Account("Code", "Description", AccountType.ASSETS), Direction.INC,
                Amount(1)))) == \
           Posting("journal", datetime.date.today(), Account("Code", "Description", AccountType.ASSETS),
                   Direction.INC, Amount(1))



# Generated at 2022-06-24 01:03:26.454575
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """
    Tests that the only way to create a _Posting instance is through its constructor.
    """

    @dataclass(frozen=True)
    class Test(Generic[_T]):
        pass

    p = Posting[Test](journal=None, date=None, account=None, direction=None, amount=None)
    try:
        p.journal = None
    except AttributeError:
        pass
    else:
        assert False, "Expected AttributeError"
    try:
        p.date = None
    except AttributeError:
        pass
    else:
        assert False, "Expected AttributeError"
    try:
        p.account = None
    except AttributeError:
        pass
    else:
        assert False, "Expected AttributeError"

# Generated at 2022-06-24 01:03:37.781892
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..accounting.ledger import ReadLedgerAccounts, ReadLedgerTransactions
    from ..accounting.ledger.models import LedgerAccount, LedgerTransaction
    from ..accounting.ledger.types import ReadLedgerJournalEntries

    def read_ledger_accounts(period: DateRange) -> Iterable[LedgerAccount]:
        pass

    def read_ledger_transactions(period: DateRange) -> Iterable[LedgerTransaction]:
        pass

    def read_ledger_journal_entries(period: DateRange) -> Iterable[JournalEntry[LedgerTransaction]]:
        pass

    ReadLedgerJournalEntries(read_ledger_accounts, read_ledger_transactions)(datetime.date(2019, 12, 31))


# Generated at 2022-06-24 01:03:45.498402
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from datetime import date
    from .accounts import Account, AccountType
    from .ledger import Ledger
    from .transactions import Payment

    # Arrangement
    ledger: Ledger = Ledger("")
    cash_account: Account = ledger.create_account(AccountType.ASSETS, "Cash")
    expense_account: Account = ledger.create_account(AccountType.EXPENSES, "Expense")
    revenue_account: Account = ledger.create_account(AccountType.REVENUES, "Revenue")

    payment1: Payment = ledger.book_payment("Test Payment 1", date(2020, 1, 2), cash_account, expense_account, 12, 34)
    payment2: Payment = ledger.book_payment("Test Payment 2", date(2020, 1, 3), cash_account, expense_account, 56, 78)


# Generated at 2022-06-24 01:03:52.162661
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import Callable, List
    from unittest import TestCase
    from dataclasses import dataclass, field

    @dataclass
    class Foo:
        description: str

        def __init__(self, description: str) -> None:
            self.description = description

        def __eq__(self, other: 'Foo') -> bool:
            return isinstance(other, Foo) and other.description == self.description

    @dataclass
    class JournalEntryFoo(JournalEntry[Foo]):
        date: datetime.date = field(default=datetime.date.today())
        description: str = field(default="")
        source: Foo = field(default=Foo(""))
        postings: List[Posting[Foo]] = field(default_factory=list)
        guid: Guid = field

# Generated at 2022-06-24 01:03:57.086061
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    # arrange
    p = Posting(JournalEntry(datetime.date.today(), "description", "source", []), datetime.date.today(), "account", Direction.INC, 600)
    # act
    del p.journal
    # assert
    assert not hasattr(p, "journal")


# Generated at 2022-06-24 01:04:07.774820
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def ReadJournalEntries(journal_type):
        from ddd_ledger.domain.accounts import Account
        from ddd_ledger.domain.transactions import Transaction
        from ddd_ledger.domain.journal import JournalEntry
        from datetime import datetime, timedelta
        from ddd_ledger.domain.parties import Party
        from typing import Iterable
        def __call__(period: DateRange) -> Iterable[JournalEntry[journal_type]]:
            #: Date of the entry.
            date = datetime.now()
            #: Description of the entry.
            description = "description"
            #: Business object as the source of the journal entry.
            source = Transaction(description=description, date=date, debit=Account(
                name="Cash", type=AccountType.ASSETS))
            #: Postings

# Generated at 2022-06-24 01:04:18.114529
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    # Create a sample Posting
    @dataclass(frozen=True)
    class Posting:
        """
        Provides a posting value object model.
        """

        #: Date of posting.
        date: datetime.date

        #: Account of the posting.
        account: Account

        #: Direction of the posting.
        direction: Direction

        #: Posted amount (in absolute value).
        amount: Amount

        def __hash__(self):
            return hash(
                (self.date, self.account, self.direction, self.amount))

    # Create set of 2 sample Postings
    posting1 = Posting(datetime.date(2020, 4, 1), Account(AccountType.ASSETS, "Posting 1"), Direction.INC, Amount(1))

# Generated at 2022-06-24 01:04:25.388407
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..accounts.test_accounts import make_accounts_for_test
    from ..commons.test_commons import get_random_date
    from ..commons.test_commons import get_random_decimal_amount

    accounts = make_accounts_for_test()

    def post_random_amount(je: JournalEntry, account: Account):
        print("Hello")
        je.post(get_random_date(), account, get_random_decimal_amount())

    # je = JournalEntry.create("Test1", "Testing", {
    #     accounts["Revenue"]: 1000,
    #     accounts["Expense"]: 200,
    # })
    #
    # print(je)
    # print(je.postings)

# Generated at 2022-06-24 01:04:35.987149
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from dataclasses import Field
    from dataclasses import is_dataclass
    from dataclasses import make_dataclass
    from dataclasses import replace
    from inspect import isclass
    from pytest import raises

    cls = JournalEntry[_T]
    assert is_dataclass(cls)
    orig_fields = cls.__dataclass_fields__.copy()

    # Test class dataclasses
    for name, field in orig_fields.items():
        class_ = getattr(cls, name)
        is_a_class = isclass(class_)
        if is_a_class:
            assert name in field.metadata
            dic = field.metadata.copy()
            dic.pop(name)

# Generated at 2022-06-24 01:04:37.233170
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert False == True



# Generated at 2022-06-24 01:04:41.339317
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal = JournalEntry("date", "description", "source")
    journal.post(datetime.date(2020, 1, 1), "account", 20)
    journal.post(datetime.date(2020, 1, 1), "account", -20)
    journal.validate()
    #assert journal.validate() == True

# Generated at 2022-06-24 01:04:48.870441
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal_entry = JournalEntry(datetime.date(2019, 11, 4), "Service Revenue", "Wages")
    journal_entry.post(datetime.date(2019, 11, 4), Account(AccountType.LIABILITIES, "Wages Payable"), 1000)
    journal_entry.post(datetime.date(2019, 11, 4), Account(AccountType.REVENUES, "Service Revenue"), 1000)

# Generated at 2022-06-24 01:04:57.755177
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert "Posting(journal=JournalEntry(date=datetime.date(2020, 1, 1), description='', source=), date=datetime.date(2020, 1, 1), account=Account(name='', type=AccountType.ASSETS, options=), direction=Direction.INC, amount=Amount(amount=100))" == str(
        Posting(JournalEntry(date=datetime.date(2020, 1, 1), description='', source=None), datetime.date(2020, 1, 1), Account(name='', type=AccountType.ASSETS, options=None), Direction.INC, Amount(100)))

# Generated at 2022-06-24 01:05:02.251383
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import pytest

    # A function which read journal entries from a source:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return ()
    ReadJournalEntriesType = ReadJournalEntries[None]
    def is_ReadJournalEntriesType(val: any) -> val is ReadJournalEntriesType:
        return isinstance(val, ReadJournalEntriesType)
    assert is_ReadJournalEntriesType(read_journal_entries)

# Generated at 2022-06-24 01:05:12.746692
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from decimal import Decimal
    from datetime import date
    from pytest import raises
    from .accounts import Account, AccountType
    from . import journal_entries
    from .journal_entries import Posting, Direction
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid

    # Example
    journal_entry = journal_entries.JournalEntry(date(2020, 2, 1), "Foo", makeguid())
    posting_1 = Posting(journal_entry, date(2020, 2, 1), Account(AccountType.REVENUES, "10110"), Direction.INC, Amount(Decimal(100.00)))

# Generated at 2022-06-24 01:05:23.402974
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():

    date = datetime.date(2020, 7, 15)
    #: Description of the entry.
    desc = "TEST"
    #: Business object as the source of the journal entry.
    source = JournalEntry
    #: Globally unique, ephemeral identifier.
    guid1 = Guid(1)
    guid2 = Guid(2)
    guid3 = Guid(1)
    
    #: Postings of the journal entry.
    postings = List[Posting] = field(default_factory=list, init=False)

    posting1 = Posting(journal, date, account, direction, amount)
    posting2 = Posting(journal, date, account, direction, amount)
    posting3 = Posting(journal, date, account, direction, amount)
    posting4 = Posting(journal, date, account, direction, amount)

# Generated at 2022-06-24 01:05:28.304375
# Unit test for constructor of class Posting
def test_Posting():
    AccountType.ASSETS == AccountType.of(1)
    Account.expenses == Account.of(AccountType.EXPENSES, id=1)


# Generated at 2022-06-24 01:05:39.607073
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    @dataclass(frozen=True)
    class RealEstate:
        """
        Provides a real estate value object model.
        """

        #: Street address of the real estate.
        address: str

        #: City the real estate is located in.
        city: str

    real_estate = RealEstate(address="701 N Broadway", city="St Louis")
    journal = JournalEntry[RealEstate](date=(2017, 11, 6), description="Real Estate Purchase", source=real_estate)
    journal.post(date=(2017, 11, 6), account=Account(code="1000", name="Cash"), quantity=50000)
    journal.post(date=(2017, 11, 6), account=Account(code="2000", name="Real Estate"), quantity=-50000)
    journal.validate()

# Generated at 2022-06-24 01:05:42.982703
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # Initial test for constructor of class ReadJournalEntries
    assert True

# Generated at 2022-06-24 01:05:46.227516
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journalEntry = JournalEntry(date=1, description=2, source=3)
    assert journalEntry.postings == []

# Generated at 2022-06-24 01:05:48.763254
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    pass


# Generated at 2022-06-24 01:05:56.951698
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import FrozenInstanceError
    from datetime import date
    from .accounts import AccountType
    from .accounts import Company, Account

    # Create a Company
    company = Company(
        code="XYZ",
        name="ABC Ltd.",
        email=None,
        address=None,
        phone=None
    )

    # Create Journal Entries
    je1 = JournalEntry(
        date=date(2018, 12, 12),
        description="Inventory purchase",
        source=company
    )
    je1.post(date=date(2018, 12, 12), account=Account(type=AccountType.ASSETS, code="1000", name="Cash in hand"), quantity=10_000.00)

# Generated at 2022-06-24 01:06:03.938397
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():

    # Given
    je = JournalEntry(datetime.date(2020, 1, 1), 'Test', 'This is the source', [])

    # Expect
    expected = 'JournalEntry(\n  description=Test,\n  source=This is the source,\n  postings=[],\n  guid=' + je.guid + '\n)'

    # When
    actual = repr(je)

    # Then
    assert expected == actual


# Generated at 2022-06-24 01:06:08.611169
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def test_func(period : DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    test_ReadJournalEntries = ReadJournalEntries(test_func)
    test_ReadJournalEntries(DateRange(datetime.datetime(2020,1,1),datetime.datetime(2020,2,2)))

# Generated at 2022-06-24 01:06:15.999592
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    a = JournalEntry(
        date=datetime.date.today(),
        description="this is the test",
        source="test source"
    )
    a.post(date=datetime.date.today(), account=Account(AccountType.ASSETS, name="Assets:Statutory Cash"), quantity=100)
    a.post(date=datetime.date.today(), account=Account(AccountType.REVENUES, name="Revenues:Income"), quantity=-100)
    a.validate()
    # raise AssertionError if one of the asserts fails
    assert True

# Generated at 2022-06-24 01:06:24.003704
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    #: Date of the entry.
    date = datetime.date(day=1, month=1, year=2010)
    #: Description of the entry.
    description = "first entry"

    #: Globally unique, ephemeral identifier.
    guid1 = makeguid()
    guid2 = makeguid()

    journal1 = JournalEntry(date=date, description=description, source="sample source")
    journal2 = JournalEntry(date=date, description=description, source="sample source")

    journal1.postings.append(Posting(journal1, date, Account("Tenants", AccountType.LIABILITIES), Direction.INC, Amount(10000)))
    journal1.postings.append(Posting(journal1, date, Account("Security Deposit", AccountType.ASSETS), Direction.DEC, Amount(10000)))
    
    journal

# Generated at 2022-06-24 01:06:34.056443
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    source = "Hello"
    postings = [Posting(JournalEntry[str](datetime.date(2018, 12, 31), "Hello World", "Hello"), datetime.date(2018, 12, 31), Account("A-101", "Account A", AccountType.ASSETS), Direction.INC, Amount(100)),
                Posting(JournalEntry[str](datetime.date(2018, 12, 31), "Hello World", "Hello"), datetime.date(2018, 12, 31), Account("A-102", "Account B", AccountType.ASSETS), Direction.DEC, Amount(100))]
    _ = JournalEntry[str](datetime.date(2018, 12, 31), "Hello World", "Hello", postings)

# Generated at 2022-06-24 01:06:45.309046
# Unit test for constructor of class Posting
def test_Posting():
    class Test_Posting():
        def __init__(self, journal, date, account, direction, amount):
            self.journal = journal
            self.date = date
            self.account = account
            self.direction = direction
            self.amount = amount

        def is_debit(self):
            if self.account.type in _debit_mapping[self.direction]:
                return True
            return False

    j = Test_Posting("test", "01/02/2020", "test", "test", 100)
    p = Posting("test", "01/02/2020", "test", "test", 100)
    assert p.journal == j.journal
    assert p.date == j.date
    assert p.account == j.account
    assert p.direction == j.direction
    assert p.amount == j.amount

# Generated at 2022-06-24 01:06:56.447680
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import AccountType, Account

    p1:Posting = Posting(Guid(),datetime.date.today(),Account('1', '1', AccountType.ASSETS),Direction.INC,Amount(123))
    p2:Posting = Posting(Guid(),datetime.date.today(),Account('1', '1', AccountType.ASSETS),Direction.INC,Amount(123))
    assert p1 == p2

    p1:Posting = Posting(Guid(),datetime.date.today(),Account('1', '1', AccountType.ASSETS),Direction.INC,Amount(12))
    p2:Posting = Posting(Guid(),datetime.date.today(),Account('1', '1', AccountType.ASSETS),Direction.INC,Amount(123))
    assert p1 != p2



# Generated at 2022-06-24 01:07:03.192530
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from pytest import raises
    assert eval(repr(
        JournalEntry(
            date=datetime.date(2020, 1, 2),
            description="Test Journal Entry",
            source="Test",
            postings=[
                Posting(
                    journal=None,
                    date=datetime.date(2020, 1, 2),
                    account=Account(
                        code="123",
                        type=AccountType.EXPENSES,
                        name="Test Account"
                    ),
                    direction=Direction.INC,
                    amount=Amount(0.10)
                )
            ],
            guid=None
        )
    )).date == datetime.date(2020, 1, 2)



# Generated at 2022-06-24 01:07:10.050338
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # import
    from ..accounts import Account, AccountType, AccountManager
    from ..commons import Currency, Quantity
    from ..settings import Settings
    from .journal_entry_factory import JournalEntryFactory
    from .postings import post

    # set Settings
    Settings.accounts = AccountManager([])

    # create JournalEntryFactory
    journal_entry_factory = JournalEntryFactory(None, start_date=None, account_type=AccountType.ASSETS)

    # create Account
    account_type = AccountType.ASSETS
    currency = Currency.get_default()
    account1 = Account(account_type, currency)
    account2 = Account(account_type, currency)

    # create Posting
    posting1 = post(date=None, account=account1, quantity=Quantity(0))

# Generated at 2022-06-24 01:07:21.681771
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    j_oDate = datetime.date(2020,1,1)
    j_oAccount = Account('cash')
    j_oDirection = Direction.INC
    j_oAmount = Amount(100)
    
    posting_1 = Posting(JournalEntry(date = j_oDate, description = "",source = None),date = j_oDate, account = j_oAccount, direction = j_oDirection, amount = j_oAmount)
    posting_2 = Posting(JournalEntry(date = j_oDate, description = "",source = None),date = j_oDate, account = j_oAccount, direction = j_oDirection, amount = j_oAmount)
    
    assert posting_1 == posting_2
    


# Generated at 2022-06-24 01:07:26.245070
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    with pytest.raises(AttributeError):
        posting = Posting
        posting.journal   = JournalEntry
        posting.date      = datetime.date
        posting.account   = Account
        posting.direction = Direction.INC
        posting.amount    = Amount(1000)


# Generated at 2022-06-24 01:07:35.192822
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # Test Members
    j1 = JournalEntry(date=datetime.date(2017, 1, 1), description="test journal entry 1", source=None, postings=[])
    j2 = JournalEntry(date=datetime.date(2017, 1, 1), description="test journal entry 1", source=None, postings=[])
    j3 = JournalEntry(date=datetime.date(2017, 1, 1), description="test journal entry 2", source=None, postings=[])
    j4 = JournalEntry(date=datetime.date(2017, 1, 2), description="test journal entry 1", source=None, postings=[])

# Generated at 2022-06-24 01:07:45.461965
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(JournalEntry(datetime.date.today(), '', None), datetime.date.today(), Account('A', AccountType.ASSETS), Direction.INC, Amount(10))
    p2 = Posting(JournalEntry(datetime.date.today(), '', None), datetime.date.today(), Account('A', AccountType.ASSETS), Direction.INC, Amount(10))
    p3 = Posting(JournalEntry(datetime.date.today(), '', None), datetime.date.today(), Account('A', AccountType.EXPENSES), Direction.INC, Amount(10))
    p4 = Posting(JournalEntry(datetime.date.today(), '', None), datetime.date.today(), Account('A', AccountType.ASSETS), Direction.DEC, Amount(10))