

# Generated at 2022-06-24 00:57:48.036720
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    import datetime
    from .accounts import Accounts
    a = Accounts()
    a.new('Assets', 'Cash', 'Cash in the bank')
    a.new('Assets', 'Accounts Receivable', 'Amounts receivable from customers')
    a.new('Revenues', 'Sales', 'Sales of goods')
    a.new('Expenses', 'Taxes', 'Taxes paid to government')
    a.new('Expenses', 'Interest', 'Interest expense')
    date = datetime.date(2019, 1, 31)
    j = JournalEntry(date, 'Test', 'Source')
    j.post(date, a.get('Assets', 'Cash'), 0)
    j.post(date, a.get('Assets', 'Accounts Receivable'), +5000)

# Generated at 2022-06-24 00:57:57.411338
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .digest import TransactionDigest
    from .storage import Storage
    import random
    import datetime
    storage = Storage.for_file("tests.jnl.json")
    digest = TransactionDigest.create()
    je = JournalEntry(datetime.date(2020, 4, 16), "Description of Journal Entries")
    je.post(datetime.date(2020, 4, 16), storage.Accounts.Cash, +random.randint(1, 100))
    je.post(datetime.date(2020, 4, 16), storage.Accounts.Cash, -random.randint(1, 100))
    je.post(datetime.date(2020, 4, 16), storage.Accounts.Cash, random.randint(-100, 100))

# Generated at 2022-06-24 00:57:58.755745
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    pass

# Generated at 2022-06-24 00:58:04.470708
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from dataclasses import asdict

    # Arrange
    je1 = JournalEntry[None]('2020-06-01', 'test', None)
    je2 = JournalEntry[None]('2020-06-01', 'test', None)
    je3 = JournalEntry[None]('2020-06-02', 'test', None)

    # Act
    je1.postings = [Posting[None](je1, '2020-06-01', Account('test'), Direction.INC, 1)]
    je2.postings = [Posting[None](je2, '2020-06-01', Account('test'), Direction.INC, 1)]
    je3.postings = [Posting[None](je3, '2020-06-02', Account('test'), Direction.INC, 1)]

    # Assert
    assert je1!=je2

# Generated at 2022-06-24 00:58:15.515369
# Unit test for method __repr__ of class Posting

# Generated at 2022-06-24 00:58:19.541323
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    date = datetime.date(2019, 3, 31)
    description = "Paycheck from Company Xyz"
    source = None
    journalEntry = JournalEntry(date, description, source)
    journalEntry.post(date, account="Liabilities:Income-Tax", quantity=1)
    journalEntry.post(date, account="Liabilities:HRA", quantity=0)
    journalEntry.post(date, account="Assets:Employee Provident Fund", quantity=1)
    journalEntry.post(date, account="Equities:Opening Balances", quantity=0)
    assert journalEntry == journalEntry

# Generated at 2022-06-24 00:58:28.412963
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from dataclasses import asdict, replace
    from datetime import datetime, timedelta
    from decimal import Decimal
    from uuid import UUID

    from ..commons import Amount, Quantity
    from ..entities import Account, Unit, Ledger

    def create_postings(journal, date, unit, ledger, *args):
        if len(args) % 2 != 0:
            raise ValueError("Positional arguments should be pairs of account and quantity")

        for i in range(0, len(args), 2):
            quantity = args[i + 1]
            if quantity != 0:
                journal.post(date, Account(args[i], ledger), Quantity(quantity, unit))

    def build_journal():
        unit = Unit(code="ABC", description="A simple unit")
        ledger = Ledger(unit)
        journal = Journal

# Generated at 2022-06-24 00:58:38.042112
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal = JournalEntry[object]("2019-01-01", "Test", object())
    posting1 = Posting(journal, datetime.date(2019, 1, 1), Account("Assets", "Cash"), Direction.INC, Amount(100))
    posting2 = Posting(journal, datetime.date(2019, 1, 1), Account("Assets", "Cash"), Direction.INC, Amount(100))
    posting3 = Posting(journal, datetime.date(2019, 1, 1), Account("Assets", "Cash"), Direction.INC, Amount(101))
    posting4 = Posting(journal, datetime.date(2019, 1, 2), Account("Assets", "Cash"), Direction.INC, Amount(100))

# Generated at 2022-06-24 00:58:39.686472
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    try:
        Posting.__delattr__("_debit_mapping")
    except AttributeError as ae:
        print(f"AttributeError exception: {ae}")


# Generated at 2022-06-24 00:58:48.722688
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    #: Test date range.
    date_range = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 2))

    #: Test journal entry.
    journal_entry = JournalEntry[str]("2019-01-01", "Test journal entry", "This is a test journal entry")

    #: Test journal entry reader.
    journal_entry_reader = lambda _: (journal_entry,)

    #: Test read journal entries protocol.
    read_journal_entries = ReadJournalEntries()

    # Execute the test.
    assert read_journal_entries(journal_entry_reader, date_range) == (journal_entry,)

# Generated at 2022-06-24 00:58:53.807170
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Setup
    journal_entry = JournalEntry[None](
        date=datetime.date(year=2020, month=6, day=12),
        description="Journal entry description",
        source=None)

    # Exercise
    repr_string = journal_entry.__repr__()

    # Verify
    assert repr_string == f"JournalEntry(date=datetime.date(2020, 6, 12), description='Journal entry description', source=None, guid={journal_entry.guid})"



# Generated at 2022-06-24 00:59:01.403128
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    # Test 1
    # Input parameter: journal: JournalEntry[_T]
    # Input parameter: date: datetime.date
    # Input parameter: account: Account
    # Input parameter: direction: Direction
    # Input parameter: amount: Amount
    # Expected output: Posting
    journal_ = JournalEntry()

    date_ = datetime.date(2016, 10, 8)

    account_ = Account()

    direction_ = Direction.INC

    amount_ = Amount(5)

    posting_ = Posting(journal_, date_, account_, direction_, amount_)

    posting1_ = posting_

    # Test 2
    # Input parameter: journal: JournalEntry[_T]
    # Input parameter: date: datetime.date
    # Input parameter: account: Account
    # Input parameter: direction: Direction
    # Input parameter: amount

# Generated at 2022-06-24 00:59:04.325328
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting(None, None, Account(AccountType.ASSETS), None, None)) == "Posting(account=Account(type=<AccountType.ASSETS: 1>), amount=None, direction=None, date=None, journal=None)"


# Generated at 2022-06-24 00:59:14.617525
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    @dataclass(frozen=True)
    class Mock:
        pass
    journal_entry1 = JournalEntry[Mock](date=datetime.date(2018, 7, 23), description="Buy shares of IBM", 
        source=Mock(), postings=[Posting(journal_entry1, datetime.date(2018, 7, 23), "Assets:Brokerage", Direction.INC, Amount(10000))])
    journal_entry2 = JournalEntry[Mock](date=datetime.date(2018, 7, 23), description="Buy shares of IBM", 
        source=Mock(), postings=[Posting(journal_entry2, datetime.date(2018, 7, 23), "Assets:Brokerage", Direction.INC, Amount(10000))])
    assert hash(journal_entry1) == hash(journal_entry2)

# Unit

# Generated at 2022-06-24 00:59:16.670514
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    assert hash(JournalEntry(datetime.date(), "", None)) == hash(JournalEntry(datetime.date(), "", None))

# Generated at 2022-06-24 00:59:19.081030
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class MockReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return None

    return MockReadJournalEntries
ReadJournalEntries.__call__.__annotations__["return"] = Iterable[JournalEntry[_T]]

# Generated at 2022-06-24 00:59:30.234899
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    result = JournalEntry(datetime.date.today(), "Description", "Source") \
        .post(datetime.date.today(), Account("Name", AccountType.ASSETS, "Parent"), 100) \
        .post(datetime.date.today(), Account("Name", AccountType.REVENUES, "Parent"), -100)
    actual = result.guid

    assert result is not None, f"Expected: a result ; Actual: {result}"
    assert isinstance(result, JournalEntry), f"Expected: a JournalEntry ; Actual: {result}"
    assert actual is not None, f"Expected: a result ; Actual: {actual}"
    assert isinstance(actual, Guid), f"Expected: a Guid ; Actual: {actual}"

# Generated at 2022-06-24 00:59:31.188963
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    with pytest.raises(TypeError):
        ReadJournalEntries()

# Generated at 2022-06-24 00:59:39.713060
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal_entry = JournalEntry(datetime.date.today(), "description")
    journal_entry.post(datetime.date.today(), Account("revenue"), 1)
    assert journal_entry.__repr__() == "JournalEntry(date=2019-05-13, description='description', postings=[Posting(journal=JournalEntry(date=2019-05-13, description='description', postings=[]), date=2019-05-13, account=Account(name='revenue', type=<AccountType.REVENUES: 2>), direction=<Direction.DEC: -1>, amount=<Amount.one: 1>)], guid='2d756567-e7c1-4cf9-9496-22a39762f061')"




# Generated at 2022-06-24 00:59:45.076897
# Unit test for constructor of class Posting
def test_Posting():
    #test with negative amount
    testPosting = Posting("journal object", datetime.date(2018, 1, 1), Account("Assets", AccountType.ASSETS), Direction.DEC, Amount(-100))
    assert testPosting.amount == Amount(-100)
    assert testPosting.direction == Direction.DEC
    assert testPosting.date == datetime.date(2018, 1, 1)
    assert testPosting. account == Account("Assets", AccountType.ASSETS)
    assert testPosting.is_debit == False
    assert testPosting.journal == "journal object"
    #test with positive amount
    testPosting = Posting("journal object", datetime.date(2018, 1, 1), Account("Assets", AccountType.ASSETS), Direction.INC, Amount(100))

# Generated at 2022-06-24 00:59:51.385760
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from .accounts import Account, Asset, Cash
    from .accounts import AccountType, BusinessUnit
    from .accounts import BusinessUnitChart, Chart
    from .accounts import Expense
    from .accounts import Liability, Bank

    # AttributeError: cannot delete attribute 'journal' of Posting
    from .journal import JournalEntry
    from .journal import Posting
    from .journal import Direction
    from datetime import date
    from numbers import Number
    from typing import Dict

    # Define business unit, chart of accounts and accounts.
    unit: BusinessUnit = BusinessUnit(name="R & D")
    chart: Chart = BusinessUnitChart(business_unit=unit)
    cash: Cash = chart.create_account(
        name="Cash",
        type=AccountType.ASSET,
    )

# Generated at 2022-06-24 00:59:59.489289
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journal = JournalEntry(date=datetime.date(2018, 12, 31), description="dummy")
    journal.postings = [Posting(journal, datetime.date(2018, 12, 31), Account(1), Direction.INC, 1)]
    journal2 = JournalEntry(date=datetime.date(2018, 12, 31), description="dummy")
    journal2.postings = [Posting(journal2, datetime.date(2018, 12, 31), Account(1), Direction.INC, 1)]
    assert journal == journal2

test_JournalEntry___eq__()

# Generated at 2022-06-24 01:00:03.290804
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    a = Posting(None, datetime.date.today(), Account('aaa'), Direction.INC, Amount(10))
    b = Posting(None, datetime.date.today(), Account('aaa'), Direction.INC, Amount(10))
    assert a == b, "Posting __eq__ method should return True"
    assert a is not b, "Posting __eq__ method should return True"


# Generated at 2022-06-24 01:00:08.563991
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Setup
    t1 = JournalEntry[str]("2020-01-01", "d", "s", "p")
    t2 = JournalEntry[str]("2020-01-01", "d", "s", "p")
    t3 = JournalEntry[str]("2020-01-01", "d", "s", "p")
    t4 = JournalEntry[str]("2020-01-02", "d", "s", "p")
    t5 = JournalEntry[str]("2020-01-01", "d1", "s", "p")
    t6 = JournalEntry[str]("2020-01-01", "d", "s1", "p")
    t7 = JournalEntry[str]("2020-01-01", "d", "s", "p1")

    # Exercise and Verify

# Generated at 2022-06-24 01:00:11.236612
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    journal = JournalEntry
    date = datetime.date
    account = Account
    direction = Direction
    amount = Amount
    assert Posting.__delattr__(journal, date, account, direction, amount) == None


# Generated at 2022-06-24 01:00:17.346506
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    l1 = JournalEntry("2018-01-01", "Test", "")
    l1.post("2018-01-01", "A1", 100)
    l1.post("2018-01-01", "A2", -100)
    l1.validate()
    assert len(l1.postings) == 2
    assert l1.postings[0].is_debit
    assert l1.postings[1].is_credit

# Generated at 2022-06-24 01:00:23.512273
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Variables
    date = datetime.date.today()
    description = "Description"
    source = "Source"
    journal_entry1 = JournalEntry[str](date, description, source)
    
    # Test
    journal_entry1_hash = journal_entry1.__hash__()

    # Assertions
    assert isinstance(journal_entry1_hash, int)


# Generated at 2022-06-24 01:00:34.817644
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .business import Sale
    from .ledger import Ledger
    from .accounts import Account, AccountType

    from datetime import date
    from decimal import Decimal

    ledger = Ledger()

    ledger.new_account(
        Account("11100000", "Assets", "Cash"),
        Account("11200000", "Assets", "Receivables"),
        Account("12100000", "Liabilities", "Payables"),
        Account("13100000", "Equity", "Retained Earnings"),
        Account("41101000", "Revenues", "Sales"),
        Account("51000000", "Expenses", "Cost of Sales"),
    )


# Generated at 2022-06-24 01:00:44.904871
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..ledger.postings import JournalEntry, Posting, Direction
    from ..ledger.accounts import Account, AccountType

    Allowance = Account.of("Allowance", AccountType.EXPENSES)
    Distribution = Account.of("Distribution", AccountType.EQUITIES)
    Wages = Account.of("Wages", AccountType.REVENUES)

    allowances: JournalEntry = JournalEntry(
        datetime.date.today(), "Allowances", "Employee",
    ).post(datetime.date.today(), Allowance, +20000)
    dist: JournalEntry = JournalEntry(
        datetime.date.today(), "Distribution", "Employee",
    ).post(datetime.date.today(), Distribution, +20000)

# Generated at 2022-06-24 01:00:54.223935
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # case1
    journal = 1
    date = datetime.date(2020, 1,1)
    account = Account(AccountType.ASSETS, "")
    direction = Direction.INC
    amount = 1
    posting = Posting(journal, date, account, direction, amount)
    output = posting.__repr__()
    expected_output = "<journal=1, date=2020-01-01, account=<AccountType.ASSETS: 1>, direction=Direction.INC: 1, amount=1>"
    assert output == expected_output, "Failed  case1"
    # case2
    journal = 1
    date = datetime.date(2020, 1,1)
    account = Account(AccountType.ASSETS, "")
    direction = Direction.DEC
    amount = 1

# Generated at 2022-06-24 01:01:05.623480
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    date = datetime.date(2020, 2, 1)
    description = 'Dummy Journal Entry'
    source = 'Dummy Source'
    entry = JournalEntry[str](date, description, source)

    entry.post(datetime.date(2020, 2, 1), Account('ASSETS_A'), +1000)
    entry.post(datetime.date(2020, 2, 1), Account('REVENUES_A'), -1000)

    # Verify that the postings are well initialized.
    assert entry.postings[0].date == entry.postings[1].date
    assert entry.postings[0].amount == -entry.postings[1].amount

    # Verify that the hash of two equivalent entries are the same.
    entry_copy = JournalEntry[str](date, description, source)
    entry_copy.postings = entry.post

# Generated at 2022-06-24 01:01:08.516653
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(None, None, None, None, None) == Posting(None, None, None, None, None)



# Generated at 2022-06-24 01:01:09.478054
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    raise NotImplementedError()



# Generated at 2022-06-24 01:01:21.352536
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    empty_string = ''
    description = empty_string
    source = True
    postings = []

    @dataclass(frozen=True)
    class JournalEntryTest(Generic[_T]):
        #: Date of the entry.
        date: datetime.date
        #: Description of the entry.
        description: str
        #: Business object as the source of the journal entry.
        source: _T
        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)
        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid, init=False)

    journalEntry = JournalEntryTest(date = datetime.date.today(), description = description, source = source, postings = postings)


# Generated at 2022-06-24 01:01:31.277769
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    import copy
    import datetime

    from dataclasses import field
    from enum import Enum
    from typing import Any, List, TypeVar
    import moz_sql_parser
    T = TypeVar("T")
    @dataclass(frozen=True)
    class _Dummy:
        dummy: int
    @dataclass(frozen=True)
    class _Foo(Generic[T]):
        foo: int = field(init=False)
        def __post_init__(self):
            self.foo: int = 1
        def __eq__(self, other: "JournalEntry") -> bool:
            return self.foo ==other.foo
        def __setattr__(self, name: str, value: Any) -> None:
            super().__setattr__(name,value)

# Generated at 2022-06-24 01:01:39.614471
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    t1 = JournalEntry(date=datetime.date.today(), description="test", source="test")
    p1 = Posting(journal=t1, date=datetime.date.today(), account="test", direction=Direction.INC, amount=123)
    p2 = Posting(journal=t1, date=datetime.date.today(), account="test", direction=Direction.INC, amount=123)
    return p1.__hash__() == p2.__hash__()

# Generated at 2022-06-24 01:01:49.650903
# Unit test for constructor of class Posting
def test_Posting():
    # Arrange
    # Act
    posting = Posting(JournalEntry(datetime.datetime.strptime("2020-01-01", "%Y-%m-%d").date(), "Entry 1", None), datetime.datetime.strptime("2020-01-01", "%Y-%m-%d").date(), Account("Assets:Cash", AccountType.ASSETS), Direction.INC, Amount(900))

    # Assert
    assert posting.journal.date == datetime.datetime.strptime("2020-01-01", "%Y-%m-%d").date()
    assert posting.journal.description == "Entry 1"
    assert posting.journal.source == None
    assert posting.date == datetime.datetime.strptime("2020-01-01", "%Y-%m-%d").date()
   

# Generated at 2022-06-24 01:01:55.041235
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    _journal: JournalEntry[Any] = JournalEntry(date=datetime.date(2020, 1, 3), description="Testing", source=None)
    _posting = Posting(journal=_journal, date=datetime.date(2020, 1, 3), account=Account(name="some name", type=AccountType.ASSETS), direction=Direction.INC, amount=Amount(1000.0))
    _result = _posting.__delattr__('journal')
    assert _result == None


# Generated at 2022-06-24 01:01:59.094629
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from ..commons.datetime import today

    j = JournalEntry[int](today(), "My description", 1)
    try:
        j.guid = makeguid()
        assert True # This should not be reached.
    except AttributeError:
        assert True # Expected.

# Generated at 2022-06-24 01:02:08.690054
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # GIVEN
    acct1 = Account(name= 'asset1', type=AccountType.ASSETS)
    acct2 = Account(name= 'equity', type=AccountType.EQUITIES)
    post1 = Posting(date=datetime.date(2020, 1, 1), account=acct1, direction=Direction.INC, amount=Amount(100))
    post2 = Posting(date=datetime.date(2020, 1, 1), account=acct1, direction=Direction.INC, amount=Amount(100))
    post3 = Posting(date=datetime.date(2020, 1, 1), account=acct2, direction=Direction.INC, amount=Amount(100))
    
    # WHEN & THEN
    assert post1 == post2
    assert post1 != post3
    
test

# Generated at 2022-06-24 01:02:11.923365
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    my_journal_entry = JournalEntry(datetime.date(2020,3,3),"my_description","my_source")
    assert my_journal_entry.guid is not None

# Generated at 2022-06-24 01:02:18.703981
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # Source: https://stackoverflow.com/questions/48697772/how-does-one-unit-test-a-python-protocol
    class SubClass(ReadJournalEntries):
        pass
    try:
        SubClass()  # No errors means the unittest passes
    except Exception:
        assert False, 'Should not have raised an exception'

# Generated at 2022-06-24 01:02:25.259354
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je1 = JournalEntry[object](
        datetime.date(2000, 1, 1), 'description', object(), [
            Posting(JournalEntry, datetime.date.today(), Account('Assets', AccountType.ASSETS), Direction.INC, Amount(1000))])
    je2 = JournalEntry[object](
        datetime.date(2000, 1, 1), 'description', object(), [
            Posting(JournalEntry, datetime.date.today(), Account('Assets', AccountType.ASSETS), Direction.INC, Amount(1000))])
    assert hash(je1) == hash(je2)

# Generated at 2022-06-24 01:02:32.541340
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Test class JournalEntry constructor with all parameters
    j_entry_1 = JournalEntry(date=datetime.date(2020, 1, 1), description="Add item", source=1, postings=[])
    assert j_entry_1.date == datetime.date(2020, 1, 1)
    assert j_entry_1.description == "Add item"
    assert j_entry_1.source == 1
    assert j_entry_1.postings == []
    assert type(j_entry_1.guid) == str

    # Test class JournalEntry constructor with minimum required parameters
    j_entry_2 = JournalEntry(date=datetime.date(2020, 1, 2), description="Remove item", source=2)
    assert j_entry_2.date == datetime.date(2020, 1, 2)
    assert j_entry_2

# Generated at 2022-06-24 01:02:42.764051
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from datetime import date
    from pytest import importorskip

    from ledgersim.ledger import Account, JournalEntry, Posting, Direction
    from ledgersim.commons.numbers import Quantity, Amount

    from tests.utils import TemporaryLedger

    # skip if ledger package is not installed
    importorskip("ledger")

    le = JournalEntry("1")
    le.date = date(2020, 1, 1)
    le.description = "Test2"
    le.post(date(2020, 1, 1), Account("Cash"), Quantity("10000"))
    le.post(date(2020, 1, 1), Account("Equity:Opening Balances"), Quantity("-10000"))

    # Posting should be a part of this entry which is being used as key in hashmap
    tl = TemporaryLedger()

# Generated at 2022-06-24 01:02:51.685020
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    def _do_test(js: JournalEntry):
        with pytest.raises(AttributeError):
            del js.guid
    def _do_test_with_child(child: str):
        te = JournalEntry(date, description, source)
        te.post(date, account, quantity)
        _do_test(te)
        _do_test(te.postings[0])
    date = datetime.date.today()
    description = "description"
    source = object()
    account = object()
    quantity = object()
    _do_test(JournalEntry(date, description, source))



# Generated at 2022-06-24 01:03:00.630321
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    # Arrange
    journal = JournalEntry(datetime.date(2020, 1, 1), "test journal entry", None)
    d1 = datetime.date(2020, 1, 1)
    d2 = datetime.date(2020, 1, 2)
    a1 = Account("1", "test account 1")
    a2 = Account("2", "test account 2")
    d = Direction.INC
    amt = Amount(100)
    p1 = Posting(journal, d1, a1, d, amt)
    p2 = Posting(journal, d1, a1, d, amt)
    p3 = Posting(journal, d1, a1, d, amt)
    p4 = Posting(journal, d1, a2, d, amt)

# Generated at 2022-06-24 01:03:11.791501
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass
    class JournalEntryDTO:
        """
        Serialized version of journal entries.
        """

        #: Date of journal entry.
        Date: datetime.date

        #: Description of journal entry.
        Description: str

        #: Postings of journal entry.
        Postings: List[Dict]

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[JournalEntryDTO]]:
        """
        Loads journal entries from storage.
        """
        return []

    # Ensure that the type signature is respected:
    # Type signature checked: 100%
    A: ReadJournalEntries = read_journal_entries
    A(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31)))

# Generated at 2022-06-24 01:03:20.925751
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import AccountType

    class _Account:
        def __init__(self, name, type_):
            self.name = name
            self.type_ = type_

    class _JournalEntry:
        def __init__(self, description):
            self.description = description

    account = _Account('Assets', AccountType.ASSETS)
    journal = _JournalEntry('Description')
    posting = Posting(journal, datetime.date(2020, 1, 1), account, Direction.DEC, Amount(1))

    assert posting.__repr__() == "Posting[date=2020-01-01, account=Assets, direction=DEC, amount=1.00]"

# Generated at 2022-06-24 01:03:25.248735
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    with pytest.raises(AttributeError):
        Posting(journal=None, date=datetime.date(2020, 1, 1), account=None, direction=None, amount=None)
        Posting.journal = None  # type: ignore[attr-defined, assignment]  # noqa: F821


# Generated at 2022-06-24 01:03:29.950383
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry.make()
    assert repr(journal.postings[0]) == 'Posting(journal=JournalEntry(date=datetime.date(2020, 1, 1), description="", postings=[Posting(journal=<ref>, date=datetime.date(2020, 1, 1), account=Account(name="Capital", type=<AccountType.EQUITIES: 6>), direction=<Direction.INC: 1>, amount=Amount(100))], guid="<guid>"), date=datetime.date(2020, 1, 1), account=Account(name="Capital", type=<AccountType.EQUITIES: 6>), direction=<Direction.INC: 1>, amount=Amount(100))'

# Generated at 2022-06-24 01:03:32.317947
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert True

# Generated at 2022-06-24 01:03:39.254863
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    je1: JournalEntry[str] = JournalEntry(date=datetime.date.today(), description="Test description", source="Test source")
    je1.post(date=datetime.date.today(), account=Account("Test account"), quantity=+1234)
    je1.post(date=datetime.date.today(), account=Account("Test account"), quantity=-1234)
    assert len(je1.postings) == 2

# Generated at 2022-06-24 01:03:45.331784
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal_entry = JournalEntry('2019-12-12', 'Line1\nLine2', 'source')
    assert journal_entry.date == datetime.date(2019, 12, 12)
    assert journal_entry.description == 'Line1\nLine2'
    assert journal_entry.source == 'source'
    assert journal_entry.postings == []
    assert journal_entry.guid != ''
    assert journal_entry.increments == []
    assert journal_entry.decrements == []
    assert journal_entry.debits == []
    assert journal_entry.credits == []
    return journal_entry



# Generated at 2022-06-24 01:03:47.977759
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # This test verifies that an instance of this class can be constructed.
    # If this call does not raise any errors, then it is a success.
    # This test is needed because of this class is a Protocol.
    ReadJournalEntries("")

# Generated at 2022-06-24 01:03:51.611624
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry(datetime.date.today(), 'test description', 'test source')
    assert je is not None

test_JournalEntry()

# Generated at 2022-06-24 01:04:02.777411
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account

    #Case 1:
    #Journal Entry with Revenues and Expenses accounts
    account1 = Account.get_or_create(name="Cash", type=AccountType.ASSETS)
    account2 = Account.get_or_create(name="Sales", type=AccountType.REVENUES)
    account3 = Account.get_or_create(name="Inventory", type=AccountType.ASSETS)
    account4 = Account.get_or_create(name="Purchases", type=AccountType.EXPENSES)

    journal_entry1 = JournalEntry[str]("2017-01-01")
    journal_entry1.source = "Entry-1"
    journal_entry1.post(date="2017-01-01", account= account1, quantity=100)

# Generated at 2022-06-24 01:04:05.873520
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    je1 = JournalEntry[object](datetime.date.today(), "Description", object())
    je2 = JournalEntry[object](datetime.date.today(), "Description", object())

    assert je1 != je2

# Generated at 2022-06-24 01:04:10.394720
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .transactions import Transaction

    t1 = Transaction("Payment from Customer") \
        .post("2020-01-01", "Assets:Cash", 1000) \
        .post("2020-01-01", "Revenues:Sales", -1000)
    assert t1.journal.guid

    print(t1)

# Generated at 2022-06-24 01:04:21.641351
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    @dataclass(frozen=True)
    class FakeSource:
        pass

    fake_source = FakeSource()
    posting = Posting(journal=None, date=datetime.date(2020, 10, 21), account=Account(name="Assets", type="ASSETS"), direction=Direction.INC, amount=Amount(2))
    posting_other = Posting(journal=None, date=datetime.date(2020, 10, 21), account=Account(name="Assets", type="ASSETS"), direction=Direction.DEC, amount=Amount(2))
    journal_entry = JournalEntry(date=datetime.date(2020, 10, 21), description="description1", source=fake_source)
    journal_entry.postings.append(posting)

# Generated at 2022-06-24 01:04:25.816202
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    account = Account("000", "ASSETS", AccountType.ASSETS)
    date = datetime.date(2020, 1, 1)
    journal_entry = JournalEntry[None](date, "some random entry")
    journal_entry.post(date, account, Quantity(10))
    journal_entry.post(date, account, Quantity(-5))
    assert (
        journal_entry.postings == [
            Posting(journal_entry, date, account, Direction.INC, Amount(10)),
            Posting(journal_entry, date, account, Direction.DEC, Amount(5)),
        ]
    )

# Generated at 2022-06-24 01:04:26.979019
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 01:04:34.014283
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(JournalEntry(datetime.date(2020, 1, 1), "description", "source"), datetime.date(2020, 1, 1), Account(
        "a", AccountType.ASSETS), Direction.INC, Amount(10)) == Posting(JournalEntry(
        datetime.date(2020, 1, 1), "description", "source"), datetime.date(2020, 1, 1), Account(
        "a", AccountType.ASSETS), Direction.INC, Amount(10)) is True


# Generated at 2022-06-24 01:04:36.410611
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    pass



# Generated at 2022-06-24 01:04:45.637631
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Unit test for method __setattr__ of class JournalEntry
    """
    from ..customers.customer import Customer
    from .accounts import AccountType
    from .currencies import Currency
    from .unitsofmeasure import Unit

    currency = Currency("USD", "US Dollar", "US$")
    unit = Unit("USD__Piece", "US Dollar per piece", currency)

    # Assign a value to guid
    def test_JournalEntry___setattr__1():
        c = Customer("CUST01", "ABC Corporation")
        je = JournalEntry(datetime.date.today(), "test", c)
        je.guid = "test_guid"
        return je

    # Update a value of guid

# Generated at 2022-06-24 01:04:53.024457
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Arrange
    account1=Account(name='Cash', type=AccountType.ASSETS)
    account2=Account(name='Insurance', type=AccountType.LIABILITIES)
    account3=Account(name='Sales', type=AccountType.REVENUES)
    account4=Account(name='Taxes', type=AccountType.EXPENSES)
    account5=Account(name='Fees', type=AccountType.EXPENSES)
    account6=Account(name='Checking Account', type=AccountType.ASSETS)
    account7=Account(name='Savings Account', type=AccountType.ASSETS)
    account8=Account(name='VISA', type=AccountType.ASSETS)
    account9=Account(name='MasterCard', type=AccountType.ASSETS)

# Generated at 2022-06-24 01:05:05.326874
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    """ Unit test for method __delattr__ of class JournalEntry"""
    # Constructor test:
    j = JournalEntry(datetime.date(2020, 7, 19), "This is a test journal entry source", None)
    assert j.date.isoformat() == '2020-07-19'
    assert j.description == 'This is a test journal entry source'
    assert j.source == None
    assert j.postings == []
    assert not hasattr(j, 'datetime')
    j.datetime = datetime.datetime(2020, 7, 19, 17, 43, 40)
    assert j.datetime.isoformat() == '2020-07-19T17:43:40'
    del j.datetime
    assert not hasattr(j, 'datetime')
    # Test for custom exception:

# Generated at 2022-06-24 01:05:06.572578
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p=Posting(JournalEntry)

# Generated at 2022-06-24 01:05:15.615392
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    import datetime
    from ..core.accounts import Account, AccountType
    from ..core.journal.entries import Direction, Posting, JournalEntry
    posting=Posting(JournalEntry(date=datetime.date(2016, 2, 18), description="descr", source=25), date=datetime.date(2016, 2, 18), account=Account("account", AccountType.ASSETS, guid="guid"), direction=Direction.INC, amount=2221)
    assert posting.journal == JournalEntry(date=datetime.date(2016, 2, 18), description="descr", source=25)
    assert posting.date == datetime.date(2016, 2, 18)
    assert posting.account == Account("account", AccountType.ASSETS, guid="guid")
    assert posting.direction == Direction.INC
    assert posting.amount == 2

# Generated at 2022-06-24 01:05:24.444882
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """
    Test for method Posting.__setattr__
    """
    import datetime
    from.accounts import AccountId, AccountName, AccountType

    @dataclass(frozen=True)
    class Transaction:
        transaction_id : str

    transaction = Transaction("id-1")

    posting = Posting(
        JournalEntry(
            date=datetime.date(2020, 1, 1),
            description="Test",
            source=transaction,
            postings=[]
        ),
        datetime.date(2020, 1, 1),
        Account(AccountType.ASSETS, AccountId("a-1"), AccountName("Test Account 1")),
        Direction.INC,
        Amount(100000)
    )


# Generated at 2022-06-24 01:05:29.535606
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[int](datetime.date(2020, 1, 1), "First", 1)
    je.post(datetime.date(2020, 1, 1), Account("Cash", AccountType.ASSETS), +100)
    je.post(datetime.date(2020, 1, 1), Account("Account Receivable", AccountType.ASSETS), +100)
    je.post(datetime.date(2020, 1, 1), Account("Sales", AccountType.REVENUES), -200)
    je.validate()

# Generated at 2022-06-24 01:05:32.082081
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class Foo:
        pass

    f = Foo()
    f.__call__ = lambda period: None

    assert ReadJournalEntries.__conform__(f) is f


# Generated at 2022-06-24 01:05:39.207203
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    print('Testing JournalEntry.__eq__()')
    entry1 = JournalEntry(
                date=datetime.date.today(),
                description='Testing',
                source=None
                )
    entry1.post(date=datetime.date.today(), account=Account('A', AccountType.ASSETS, '1300'), quantity=100)

    entry2 = JournalEntry(
                date=datetime.date.today(),
                description='Testing',
                source=None
                )
    entry2.post(date=datetime.date.today(), account=Account('A', AccountType.ASSETS, '1300'), quantity=100)

    entry3 = JournalEntry(
                date=datetime.date.today(),
                description='Testing',
                source=None
                )

# Generated at 2022-06-24 01:05:49.554972
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Valid journal entry:
    JournalEntry(
        datetime.date(2018, 12, 31), "Description", source="Source", postings=[
            Posting(None, datetime.date(2018, 12, 31), Account(1, "Assets", "A", AccountType.ASSETS), Direction.INC, 100),
            Posting(None, datetime.date(2018, 12, 31), Account(2, "Expense", "E", AccountType.EXPENSES), Direction.DEC, 100)
        ]
    ).validate()
    # Invalid journal entry:

# Generated at 2022-06-24 01:05:56.095216
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Given: A function which returns iterable of journal entries of a given date range.
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry['_T']]:
        return [JournalEntry[str](date=datetime.date(2020, 1, 1), description='', source='')]

    # When: The function is called with a given date range.
    entries = read_journal_entries(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1)))

    # Then: It returns expected journal entries.
    assert entries is not None

# Generated at 2022-06-24 01:06:06.533635
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from unittest.mock import Mock
    from zeep import xsd
    from .accounts import AccountType
    from .articles import Article
    from .businessobjects import BusinessObject

    journalEntry=JournalEntry[BusinessObject]
    def func1(period: DateRange):
        return [JournalEntry(period.start, "descr", Article(Guid("123"), "Foo", "Bar", Account(Guid("234"), AccountType.ASSETS)))]

    f = ReadJournalEntries(func1)
    f = ReadJournalEntries(lambda period: [JournalEntry(period.start, "descr", Article(Guid("123"), "Foo", "Bar", Account(Guid("234"), AccountType.ASSETS)))])

# Generated at 2022-06-24 01:06:12.492454
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal_date = datetime.date(2020, 4, 7)
    journal_description = 'Test for JournalEntry class'
    journal_source = 'Test'
    journal = JournalEntry(journal_date, journal_description, journal_source)
    assert journal.date == journal_date
    assert journal.description == journal_description
    assert journal.source == journal_source
    assert journal.postings == []


# Generated at 2022-06-24 01:06:16.082799
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():

    try:
        del Posting(JournalEntry, datetime.date, Account, Direction, Amount).is_debit
    except Exception as e:
        assert 'is_debit' in str(e)
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:06:22.146175
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(JournalEntry(datetime.date(2020, 1, 1), "test1", "test1"), datetime.date(2020, 1, 1),
                 Account(AccountType.ASSETS, "test1"), Direction.INC, Amount(1))
    p2 = Posting(JournalEntry(datetime.date(2020, 1, 1), "test1", "test1"), datetime.date(2020, 1, 1),
                 Account(AccountType.ASSETS, "test1"), Direction.INC, Amount(1))
    assert p1 == p2


# Generated at 2022-06-24 01:06:32.447874
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    @dataclass(frozen=True)
    class Dummy:
        pass

    dummy1 = Dummy()
    dummy2 = Dummy()

    source = Dummy()

    account1 = Account('a')
    account2 = Account('b')
    account3 = Account('c')

    j1 = JournalEntry(date=datetime.date.today(), description='j1', source=dummy1)
    j1.post(datetime.date.today(), account1, Quantity(1))
    j1.post(datetime.date.today(), account2, Quantity(2))

    j2 = JournalEntry(date=datetime.date.today(), description='j1', source=dummy1)
    j2.post(datetime.date.today(), account1, Quantity(1))

# Generated at 2022-06-24 01:06:35.599708
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    j = JournalEntry(date=datetime.date(2020, 4, 9), description='description', source='source')
    j.post(date = datetime.date(2020, 4, 9), account = "1110 Cash on Hand", quantity = 100)
    j.post(date = datetime.date(2020, 4, 9), account = "5250 Discounts on Sales", quantity = -10)

# Generated at 2022-06-24 01:06:46.425815
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import AccountType
    from .sources import ObjectSource
    from .subjects import Subject

    period = DateRange(start=datetime.date(year=2020, month=1, day=1), end=datetime.date(year=2020, month=12, day=31))
    source = ObjectSource[Subject]("test_test__test_test")
    account_type = AccountType("Assets", "A")
    account = Account("A-100", "Cash on hand", account_type, source)

# Generated at 2022-06-24 01:06:57.827574
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import AccountTypes, Account, AccountType
    import datetime
    from types import SimpleNamespace

    # Enters a journal entry for the accounts
    journal_entry_1 = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", "Test business object")

    journal_entry_1.post(datetime.date(2020, 1, 1), Account(AccountTypes.Expenses, "test-expenses", AccountType.EXPENSES), -100)
    journal_entry_1.post(datetime.date(2020, 1, 1), Account(AccountTypes.Cash, "test-cash", AccountType.ASSETS), 100)

    # Enters a second journal entry for the accounts
    journal_entry_2 = JournalEntry(datetime.date(2020, 1, 1), "Test Journal Entry", "Test business object")

# Generated at 2022-06-24 01:07:07.029618
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal_entry = JournalEntry(date = datetime.date(2020, 1, 1),
                                 description = "My journal entry",
                                 source = "My source")
    posting1 = Posting(journal = journal_entry,
                       date = datetime.date(2020, 1, 1),
                       account = Account("My account", AccountType.ASSETS),
                       direction = Direction.INC,
                       amount = Amount(100))
    posting2 = Posting(journal = journal_entry,
                       date = datetime.date(2020, 1, 1),
                       account = Account("My account", AccountType.ASSETS),
                       direction = Direction.INC,
                       amount = Amount(100))
    assert hash(posting1) == hash(posting2)

# Generated at 2022-06-24 01:07:09.059476
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    e = JournalEntry
    e(date=None, description=None, source=None)
    e(date=None, description=None, source=None)
    print('Success: test_JournalEntry')


# Generated at 2022-06-24 01:07:17.210078
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert str(JournalEntry(
        source=None,
        description='',
        date=datetime.date.today(),
        postings=[]
    )
) == "JournalEntry(date=datetime.date(2020, 1, 3), description='', postings=[], source=None, guid=e0e1bbc6-66e6-4bad-b4a4-4c3b3a6ba948)"

# Generated at 2022-06-24 01:07:20.652660
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal_entry = JournalEntry(datetime.date(2019,1,1), "Description", None)
    assert journal_entry.date == datetime.date(2019,1,1),  "Date is wrong"



# Generated at 2022-06-24 01:07:21.636155
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert False, "Missing unit test"


# Generated at 2022-06-24 01:07:29.224381
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from datetime import datetime
    from .accounts import Account, AccountType
    from .postings import ReadJournalEntries, JournalEntry, Posting
    from ..ledger.ledger import ReadJournalEntries
    def make_journal_entries(period) -> Iterable[JournalEntry[_T]]:
        journal = JournalEntry(datetime.now(), "", "")
        journal = journal.posting(datetime.now(),
                                  Account("cash", AccountType.ASSETS),
                                  100)
    ReadJournalEntries(make_journal_entries)

# Generated at 2022-06-24 01:07:39.579585
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal1 = JournalEntry(datetime.date.today(), "this is a journal entry", None)
    lst = [
        Posting(journal1, datetime.date(2020,2,2), Account("A"), Direction.DEC, Amount(5.5)),
        Posting(journal1, datetime.date(2020,2,2), Account("A"), Direction.DEC, Amount(5.5)),
        Posting(journal1, datetime.date(2020,2,3), Account("B"), Direction.DEC, Amount(5.5)),
        Posting(journal1, datetime.date(2020,2,2), Account("C"), Direction.DEC, Amount(5.5)),
        Posting(journal1, datetime.date(2020,2,2), Account("A"), Direction.INC, Amount(5.5)),
    ]
   