

# Generated at 2022-06-24 00:57:50.709863
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from dataclasses import fields
    from datetime import date
    post = JournalEntry(date(2020, 1, 2))
    assert [i.name for i in fields(JournalEntry)] == ['date', 'description', 'source', 'postings', 'guid']
    assert post.date == date(2020, 1, 2)
    del post.date
    assert [i.name for i in fields(JournalEntry)] == ['date', 'description', 'source', 'postings', 'guid']
    assert [i.init for i in fields(JournalEntry)] == [True, True, True, False, False]
    journal = JournalEntry(date(2020, 1, 2), "info", 'source')
    del journal.description

# Generated at 2022-06-24 00:57:53.295071
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    """
    Unit test for method __delattr__ of class Posting
    """
    Posting.__delattr__(Posting)

# Generated at 2022-06-24 00:57:57.929990
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry(datetime.date(2020, 1, 1), "Description", "Source")
    p = Posting(journal, datetime.date(2020, 1, 1), Account("Account", AccountType.ASSETS), Direction.INC, Amount(1))
    assert repr(p) == "Posting(date=2020-01-01, account=Account(name='Account', type=AccountType.ASSETS), direction=Direction.INC, amount=Amount(1))"


# Generated at 2022-06-24 00:58:03.122427
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # Given a journal_entry_1
    journal_entry_1 = JournalEntry(
        date=datetime.date(2017, 10, 1),
        description='Journal entry 1',
        source='A1'
    )

    # And a journal_entry_2 with the same data as journal_entry_1
    journal_entry_2 = JournalEntry(
        date=datetime.date(2017, 10, 1),
        description='Journal entry 1',
        source='A1'
    )

    # When I compare journal_entry_1 and journal_entry_2
    result = journal_entry_1 == journal_entry_2

    # Then the result should be True
    assert result



# Generated at 2022-06-24 00:58:14.157787
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date
    from ..core.base import Base
    from ..core.objects import (Object, ObjectFactory)
    from ..core.services import Service
    from ..domain.accounts import Ledger, Postable
    from ..domain.transactions import Transaction
    from ..domain.ports import JournalReader

    #: Sample business object.
    @dataclass(frozen=True)
    class Test(Base):

        #: Name of the test object.
        name: str

        #: Override to get a string representation.
        def __str__(self) -> str:
            return self.name

    #: Sample test object factory.
    class TestFactory(ObjectFactory):

        #: Name prefix for the test objects.
        name_prefix: str = "Test"

        #: Gets the next name.

# Generated at 2022-06-24 00:58:17.049522
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """
    Test case to check acceptance of attribute guid in Posting class object.
    """
    ctx = Posting(JournalEntry, datetime.date.today(), Account('account'), Direction.DEC, Amount(1))
    # Set the attributes for a instance created using dataclass
    ctx.guid = 1
    assert ctx.guid == 1

# Generated at 2022-06-24 00:58:28.247011
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    j0 = JournalEntry(date=datetime.date.fromisoformat('2020-12-01'), description='desc', source=None)
    j0.post(date=datetime.date.fromisoformat('2020-12-01'), account=Account('acc1', AccountType.ASSETS), quantity=100)
    j0.post(date=datetime.date.fromisoformat('2020-12-01'), account=Account('acc2', AccountType.EXPENSES), quantity=-100)

    repr_of_j0 = repr(j0)

# Generated at 2022-06-24 00:58:29.802400
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # TODO: add a test here
    pass

# Generated at 2022-06-24 00:58:34.146545
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(JournalEntry(datetime.date(2020, 1, 1), "Description", "Source"), datetime.date(2020, 1, 1), Account(
        "Account", AccountType.ASSETS), Direction.INC, Amount(100))
    p2 = Posting(JournalEntry(datetime.date(2020, 1, 1), "Description", "Source"), datetime.date(2020, 1, 1), Account(
        "Account", AccountType.ASSETS), Direction.INC, Amount(100))
    assert p1 == p2



# Generated at 2022-06-24 00:58:39.041690
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    @dataclass(frozen=True)
    class Foo:
        pass

    journal = JournalEntry(date=datetime.date(2020, 1, 5), description="", source=Foo())
    journal.date = datetime.date(2020, 1, 10)

# Generated at 2022-06-24 00:58:48.223544
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from .accounts import AccountType
    from .accounting_period import AccountingPeriod

    from .accounts import AccountRegister

    from .journal_entries import Posting, JournalEntry
    from .journal_entries import _debit_mapping

    from .books import GeneralLedger

    from .accounts import Account

    from .accounting_period import AccountingPeriod

    from .books import GeneralLedger

    l_startDate = datetime.date(2017, 12, 1)
    l_endDate = datetime.date(2017, 12, 31)
    l_period = AccountingPeriod(l_startDate, l_endDate)
    l_accountRegister = AccountRegister()
    l_accountRegister.add_account("Cash", AccountType.ASSETS)

# Generated at 2022-06-24 00:58:48.998482
# Unit test for constructor of class Posting
def test_Posting():
    pass


# Generated at 2022-06-24 00:58:55.904396
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..tms.trades import Trade
    from ..tms.accounts import AccountType, Account
    from ..tms.entities import Broker
    from ..positions import Position

    # Define a trade
    trade = Trade(
        date=datetime.date(2020, 5, 9),
        asset='AGRO',
        quantity=+100,
        price=Amount(23.5),
        broker=Broker.get('xp'),
    )

    # Define an account
    equities = Account.get(AccountType.EQUITIES, 'xp')

    # Define a posting

# Generated at 2022-06-24 00:59:05.788505
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Arrange
    @dataclass(frozen=True)
    class _JournalEntry(JournalEntry[str]):
        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: str

        #: Postings of the journal entry.
        postings: List[Posting[str]] = field(default_factory=list, init=False)

        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid, init=False)

    # Act
    _JournalEntry(date=datetime.date.today(), description="testJEntry", source="testJEntry")

# Generated at 2022-06-24 00:59:07.027044
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass

# Generated at 2022-06-24 00:59:17.331009
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class Test:
        pass
    # Test setup
    t = Test()
    t.date = datetime.date(2009, 1, 1)
    t.description = "Test JournalEntry"
    t.postings = []
    t.guid = '4da0d526-9a06-11ea-bb37-0242ac130002'
    t.post = JournalEntry.post
    t.debits = JournalEntry.debits
    t.credits = JournalEntry.credits
    t.increments = JournalEntry.increments
    t.decrements = JournalEntry.decrements
    # Test executions
    t.post(datetime.date(2009, 1, 1), Account('Account1', AccountType.ASSETS, 'Account1'), Quantity(10))

# Generated at 2022-06-24 00:59:19.352166
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    import inspect
    assert inspect.signature(ReadJournalEntries.__call__).return_annotation == Iterable[JournalEntry[_T]]

# Generated at 2022-06-24 00:59:31.252137
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account

    # Empty postings:
    assert [] == [
        Posting(JournalEntry(datetime.date(2020, 5, 4), "Description", None), datetime.date(2020, 5, 4), Account("01200", "Assets", AccountType.ASSETS), Direction.DEC, Amount(10))
        for _ in range(0)
    ]

    # One posting:

# Generated at 2022-06-24 00:59:37.305028
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Arrange
    journalEntry = JournalEntry(Object, "Hola", "Motorola")
    journalEntry.postings.append(Posting(journalEntry, datetime.date.today(), Account.from_name("Motorola"), Direction.DEC, Amount(100)))
    journalEntry.postings.append(Posting(journalEntry, datetime.date.today(), Account.from_name("Motorola"), Direction.INC, Amount(100)))

    # Act
    journalEntry.validate()

# Generated at 2022-06-24 00:59:43.085487
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(None, datetime.date(2020,8, 2), Account("cash"), Direction.DEC, Amount(100)) == Posting(None, datetime.date(2020,8, 2), Account("cash"), Direction.DEC, Amount(100))

# Generated at 2022-06-24 00:59:46.456358
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass


# Generated at 2022-06-24 00:59:57.116584
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Tests for the method JournalEntry.__repr__.
    from datetime import date
    from .accounts import Account
    from .ast import AssetAccount, ExpenseAccount, RevenueAccount, Cash, WagesExpense, SalesRevenue

    # Case-1: JournalEntry has no postings
    journalEntry = JournalEntry(date.today(), "Rent", Cash, [])
    assert journalEntry.__repr__() == "JournalEntry(date=%s, description=%s, source=%s, postings=%s)" % (date.today(), "Rent", Cash, [])
    
    # Case-2: JournalEntry has a postings
    posting1 = Posting(journalEntry, date.today(), AssetAccount('Cash'), Direction.INC , 100)

# Generated at 2022-06-24 01:00:00.978283
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import AccountType

    posting = Posting(None, datetime.date.today(), Account(AccountType.ASSETS, 'Cash'), Direction.INC, Amount(100))
    print(posting)

    assert True


# Generated at 2022-06-24 01:00:06.683136
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    import datetime
    from dataclasses import dataclass, field
    from typing import List, TypeVar
    from .accounts import Account

    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class JournalEntry(_T):
        date: datetime.date
        description: str
        source: _T

        postings: List[Posting[_T]] = field(default_factory=list, init=False)
        guid: Guid = field(default_factory=makeguid, init=False)

    @dataclass(frozen=True)
    class Posting(_T):
        journal: JournalEntry[_T]
        date: datetime.date
        account: Account
        direction: Direction
        amount: Amount


# Generated at 2022-06-24 01:00:16.600615
# Unit test for constructor of class Posting
def test_Posting():
    def validator(posting):
        if not isinstance(posting, Posting):
            print('Object is not of type Posting')
            return False
        return True

    journal = JournalEntry[0](date = datetime.date(2020,1,1),
                              description = 'test',
                              source = 0)
    account = Account(code = '123',
                      name = 'test',
                      type = AccountType.ASSETS)
    postings = [Posting(journal = journal,
                        date = datetime.date(2020,1,1),
                        account = account,
                        direction = Direction.INC,
                        amount = Amount(2))]

# Generated at 2022-06-24 01:00:21.870776
# Unit test for constructor of class Posting
def test_Posting():
    j=JournalEntry[str]('2020-06-06','Purchases', 'Purchases',[])
    p=Posting(j,'2020-06-06','Equity(Purchases)', Direction.DEC, 5000)
    p.is_debit
    assert p.journal == j


# Generated at 2022-06-24 01:00:30.006605
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from .accounts import Account
    from .commons.zeitgeist import DateRange


    class _JournalEntry(JournalEntry):
        pass


    abc = _JournalEntry(date=datetime.date(2019, 6, 1), description="Paid some cash")
    assert abc.date == datetime.date(2019, 6, 1)
    assert abc.description == "Paid some cash"
    # assert abc.postings == list()
    # assert abc.guid == Guid("dcb8ddcd-f3b3-49b3-827b-d1c0dfa7cae9")
    # abc = abc.post(datetime.date(2019, 6, 1), Account("Assets:Liabilities", AccountType.ASSETS), Amount(1000))
    # assert abc.post

# Generated at 2022-06-24 01:00:36.228293
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import Account, AccountType

    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid

    from .journal import JournalEntry, Posting

    ## Arrange:
    account1 = Account(
        'account',
        'account description',
        AccountType.ASSETS,
        'entity',
        'entity description',
        )
    account2 = Account(
        'account_other',
        'account description',
        AccountType.ASSETS,
        'entity',
        'entity description',
        )
    je = JournalEntry(
        date=datetime.date(2019, 1, 1),
        description='entry description',
        source=None,
        )

# Generated at 2022-06-24 01:00:44.954834
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    """
    Unit test for method __hash__ of class JournalEntry.
    """
    class T:
        pass
    t = T()

    # Equivalent journal entries must have same hash values.
    journal1 = JournalEntry(datetime.date.today(), "description 1", t)
    journal2 = JournalEntry(datetime.date.today(), "description 1", t)
    assert hash(journal1) == hash(journal2)

    # Different journal entries must have different hash values.
    journal3 = JournalEntry(datetime.date.today(), "description 2", t)
    assert hash(journal1) != hash(journal3)

    # Equivalent journal entries must have same hash values.
    journal1.post(datetime.date.today(), Account("debit1", AccountType.EQUITIES), 10)

# Generated at 2022-06-24 01:00:53.834235
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import zeitgeist

    assert issubclass(ReadJournalEntries, Protocol)
    assert list(ReadJournalEntries.__call__.__args__) == [
        TypeVar("_T"),
        "ReadJournalEntries[~_T]",
    ]
    assert list(ReadJournalEntries.__call__.__return_annotation__.__args__) == [
        TypeVar("_T"),
        "_T",
    ]

    def read(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []

    assert isinstance(read, ReadJournalEntries)
    assert list(read(zeitgeist.in_year(2019))) == []


# Generated at 2022-06-24 01:01:05.298069
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    # Raises:
    #  File "c:\Users\yuhu\Documents\GitHub\lib-python\lib\lib\venoene\modeling\journal.py", line 88, in __delattr__
    #    raise AttributeError("can't delete attribute")
    # AttributeError: can't delete attribute
    from ..commons.types import (
        Country,
        Currency,
        CurrencyPair,
        DateRange,
        ExchangeRate,
        Mic,
        Offer,
        Price,
        Rate,
        Side,
        Ticker,
        Trade,
        Transaction,
        User,
    )
    from ..market import Ensemble

    # TODO: Don't like this setup. It should be easier.
    CurrencyPair(Currency.USD, Currency.GBP)

# Generated at 2022-06-24 01:01:17.250362
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    import dataclasses

    #: Provides a business object.
    @dataclasses.dataclass(frozen=True)
    class Test(Generic[_T]):
        value: _T

    #: Date of the entry.
    date: datetime.date = datetime.date.today()
    #: Description of the entry.
    description: str = "Test Journal Entry"
    #: Business object as the source of the journal entry.
    source: Test[Account] = Test(Account("Test"))
    #: Postings of the journal entry.
    postings: List[Posting[Test[Account]]] = list()
    #: Globally unique, ephemeral identifier.
    guid: Guid = makeguid()

    journalEntry = JournalEntry[Test[Account]](date, description, source, postings, guid)

    assert isinstance

# Generated at 2022-06-24 01:01:17.925628
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
  assert True

# Generated at 2022-06-24 01:01:18.823580
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert True

# Generated at 2022-06-24 01:01:20.883029
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert isinstance(ReadJournalEntries, type)
    assert issubclass(ReadJournalEntries, Protocol)

# Generated at 2022-06-24 01:01:23.485856
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting(None, None, None, None, None)) == "Posting(None, None, None, None, None)"



# Generated at 2022-06-24 01:01:33.822449
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # Arrange
    guid_a = makeguid()
    guid_b = makeguid()
    guid_c = makeguid()

    class T: pass
    a = JournalEntry[T](datetime.date.today(), 'abc', T(), [], guid_a)
    b = JournalEntry[T](datetime.date.today(), 'def', T(), [], guid_b)

    c1 = Posting(a, datetime.date.today(), Account.get('ASSETS.CASH'), Direction.INC, Amount(100), guid_c)
    c2 = Posting(a, datetime.date.today(), Account.get('ASSETS.CASH'), Direction.INC, Amount(100), guid_c)

# Generated at 2022-06-24 01:01:35.633342
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    t = JournalEntry(datetime.date(2019, 1, 2), "kiran", "acc1")
    del t.date
    assert t.date is None

# Generated at 2022-06-24 01:01:38.567476
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def unit(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []

    # noinspection PyTypeChecker
    ReadJournalEntries()(DateRange.from_now(days=-31),)

# Generated at 2022-06-24 01:01:48.536341
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    Period = DateRange("2019-01-01", "2019-01-06")
    journal = JournalEntry("a", "b", "c")
    assert journal.date == "a"
    assert journal.description == "b"
    assert journal.source == "c"
    assert journal.postings == []
    assert hasattr(journal, "guid")

    journal.__delattr__("date")
    assert not hasattr(journal, "date")
    assert journal.description == "b"
    assert journal.source == "c"
    assert journal.postings == []
    assert hasattr(journal, "guid")

    journal.__delattr__("description")
    assert not hasattr(journal, "date")
    assert not hasattr(journal, "description")
    assert journal.source == "c"

# Generated at 2022-06-24 01:01:54.680466
# Unit test for constructor of class Posting
def test_Posting():
    date = datetime.date.today()
    description = "create account"
    account_category = "Software"
    account_name = "Cost of Goods Sold"
    account = Account(account_category, account_name)
    direction = Direction.DEC
    amount = 100
    p = Posting()
    assert p.date, date
    assert p.description, description
    assert p.account.category, account_category
    assert p.account.name, account_name
    assert p.direction, direction
    assert p.amount, amount


# Generated at 2022-06-24 01:01:56.318540
# Unit test for constructor of class ReadJournalEntries

# Generated at 2022-06-24 01:02:01.578574
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal = JournalEntry(date=datetime.date(2017, 9, 14), description="test_Posting___hash__")
    journal.post(datetime.date(2017, 9, 14), Account("Test", AccountType.ASSETS), 100)
    journal.validate()
    posting = journal.postings[0]
    assert hash(posting) == hash((posting.journal, posting.date, posting.account, posting.direction, posting.amount))


# Generated at 2022-06-24 01:02:11.974031
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # test when the dates are same
    journal_entry1 = JournalEntry(datetime.date(2020, 1, 1), "Description", "source")
    journal_entry2 = JournalEntry(datetime.date(2020, 1, 1), "Description", "source")
    assert journal_entry1 == journal_entry2
    # test when description is same
    journal_entry1 = JournalEntry(datetime.date(2020, 1, 1), "Description", "source")
    journal_entry2 = JournalEntry(datetime.date(2020, 1, 2), "Description", "source")
    assert journal_entry1 != journal_entry2
    # test when source is same
    journal_entry1 = JournalEntry(datetime.date(2020, 1, 1), "Description", "source")

# Generated at 2022-06-24 01:02:21.202166
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..books.accounts import Accounts, AccountType, SubAccountType

    def get_accounts(*, name: str) -> Accounts:
        return Accounts(name, AccountType.ASSETS, SubAccountType.EQUITY)

    from . import Instrument

    equity = Instrument.Equity(
        guid=makeguid(),
        name="Equity",
        symbol="EQ",
        price=Amount(100),
        interest_rate=Amount(0.1),
        accounts=get_accounts(name="Equity"),
    )

    bond = Instrument.Bond(
        guid=makeguid(),
        name="Bond",
        symbol="BO",
        price=Amount(100),
        interest_rate=Amount(0.1),
        accounts=get_accounts(name="Bond"),
    )


# Generated at 2022-06-24 01:02:24.428666
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    #Setup
    date = datetime.date(2020, 1, 1)
    description = "Description String"

    #Exercise
    journal = JournalEntry(date, description)

    #Verify
    assert repr(journal).startswith('JournalEntry') == True


# Generated at 2022-06-24 01:02:37.250216
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    class A:
        pass

    je = JournalEntry[A](datetime.date(2020, 1, 1), "Test", A(), [
        Posting(je, datetime.date(2020, 1, 1), Account("Assets:Cash", AccountType.ASSETS), Direction.INC, Amount(10)),
        Posting(je, datetime.date(2020, 1, 1), Account("Expenses:Rent", AccountType.EXPENSES), Direction.DEC, Amount(10)),
    ])
    assert repr(je) == "JournalEntry(date=datetime.date(2020, 1, 1), description='Test', source=<__main__.A object at 0x7fb57e6d3860>, guid=31a5f566-c2e5-4cc5-8ddf-5a5a5d090a68)"

# Generated at 2022-06-24 01:02:39.228031
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    amount = 10
    account = Account("Account", "Assets", "Bank")
    date = datetime.date.today()
    description = "Test description"

    journal = JournalEntry(date, description)

# Generated at 2022-06-24 01:02:39.762466
# Unit test for constructor of class Posting
def test_Posting():
    pass

# Generated at 2022-06-24 01:02:48.882574
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    source = Account(number='2201', name='Bank', type=AccountType.ASSETS)
    je = JournalEntry(date=datetime.date(2020, 9, 1), description='Interest', source=source)
    je.postings = [Posting(journal=je, date=datetime.date(2020, 9, 1), account=source, direction=Direction.INC, amount=10)]

# Generated at 2022-06-24 01:02:54.579311
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    
    # Defining Posting
    journal_entry = JournalEntry[int](datetime.datetime.now().date(), "Description", 1)
    posting1 = Posting(journal_entry, datetime.datetime.now().date(), Account("account_name", AccountType.ASSETS), Direction.INC, Amount(1))
    

    # Assert equal when equal except GUID
    posting2 = Posting(journal_entry, datetime.datetime.now().date(), Account("account_name", AccountType.ASSETS), Direction.INC, Amount(1))
    assert posting1 == posting2, "__eq__ failed"

    # Assert not equal when journal different

# Generated at 2022-06-24 01:03:00.923858
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from datetime import date
    from .accounts import Account
    from .ledgers import Ledger
    from .books import Book
    from .books import post_amount
    from .books import render_journal_entry
    from .books import ReadJournalEntries

    ledger = Ledger()

    # Test Accounts
    bank = Account(ledger, "Bank", AccountType.ASSETS, 0)
    cash = Account(ledger, "Cash", AccountType.ASSETS, 0)
    revenue = Account(ledger, "Revenue", AccountType.REVENUES, 0)
    expense = Account(ledger, "Expense", AccountType.EXPENSES, 0)
    equity = Account(ledger, "Equity", AccountType.EQUITIES, 0)

    # Posting with increment/decrement

# Generated at 2022-06-24 01:03:12.453390
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from . import account_set
    instance1 = Posting(None, datetime.date(2020, 3, 10), account_set.CASH, Direction.INC, Amount(100.00))
    instance2 = Posting(None, datetime.date(2020, 3, 10), account_set.CASH, Direction.INC, Amount(100.00))
    instance3 = Posting(None, datetime.date(2020, 3, 10), account_set.CASH, Direction.INC, Amount(100.01))
    instance4 = Posting(None, datetime.date(2020, 3, 10), account_set.CASH, Direction.DEC, Amount(100.00))
    instance5 = Posting(None, datetime.date(2020, 3, 10), account_set.EQUIPMENT, Direction.INC, Amount(100.00))

# Generated at 2022-06-24 01:03:16.449106
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    posting = Posting(None, datetime.date.today(), None, None, None)
    assert posting.journal is None
    assert posting.date is None 
    assert posting.account is None 
    assert posting.direction is None 
    assert posting.amount is None 


# Generated at 2022-06-24 01:03:20.681243
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # if (!Entity instanceof Object) { // [CLS]
    #     return false;
    # } // [CLS]
    # return Object.prototype.toString.call(Entity) === "[object Entity]"; // [CLS]
    pass


# Generated at 2022-06-24 01:03:24.390372
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je = JournalEntry(datetime.date(2018, 1, 2), "", None, [])

    assert hash(je) is not None

# Generated at 2022-06-24 01:03:36.189513
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from .accounts import Account
    from .transactions import Transaction, TransactionCurrency
    from .transactions import TransactionItem, PostingAccount

    je = JournalEntry[Transaction]()
    assert(je.postings == [])
    je.postings.append(Posting(je, datetime.date.today(), Account(1, "first account"), Direction.INC, Amount(1)))
    assert(je.postings == [Posting(je, datetime.date.today(), Account(1, "first account"), Direction.INC, Amount(1))])

    ti = TransactionItem(Transaction(0, "description", date=datetime.date.today(), currency=TransactionCurrency.USD),
                                 1, Amount(1), PostingAccount(Account(1, "first account")))
    je = JournalEntry[TransactionItem]()

# Generated at 2022-06-24 01:03:41.014078
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    class JournalEntryTest:
        def __init__(self, id: Guid):
            self.__id = id

        def __setattr__(self, name: str, value: object) -> None:
            if name == "_JournalEntry__id":
                raise AttributeError(f"Cannot change attribute '{name}'.")
            super().__setattr__(name, value)

    with JournalEntryTest(None) as test:
        test.__id = "new id"  # type: ignore
        assert test.__id is None  # type: ignore

# Generated at 2022-06-24 01:03:47.607035
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import Account
    from .operations import Operation
    from .currencies import Currency

    account = Account(1, AccountType.ASSETS, "Cash", Currency.USD)
    operation = Operation(1, 'Cash Flow')
    posting = Posting(operation, datetime.date(2019, 1, 5), account, Direction.INC, Amount(10))
    assert isinstance(posting, Posting)
    assert posting.__repr__(), 'Posting(date=datetime.date(2019, 1, 5), account=Account[id=1,type=ASSETS,name=Cash,currency=USD], direction=INC, amount=10)'



# Generated at 2022-06-24 01:03:55.850771
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journal = JournalEntry[int](datetime.date.today(), "Test", 1)
    posting = Posting(journal, datetime.date.today(), Account(AccountType.ASSETS, "Test"), Direction.INC, Amount(1))
    with pytest.raises(AttributeError, match="Cannot set attribute 'amount' on object of type 'Posting': for an immutable object, please use the copy or replace method."):
        posting.amount = Amount(2)
    assert posting.amount == Amount(1)


# Generated at 2022-06-24 01:04:07.103331
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    @dataclass(frozen=True)
    class Foo:
        pass
    jounal = JournalEntry(date=datetime.date(year=2019, month=1, day=1),
                          description="Test",
                          source=Foo())
    income = Account(type=AccountType.REVENUES, code="1000", name="Income")
    expense = Account(type=AccountType.EXPENSES, code="2000", name="Expense")
    (jounal.post(datetime.date(year=2019, month=1, day=1), income, 100)
     .post(datetime.date(year=2019, month=1, day=1), expense, Quantity(100)))
    print(jounal)
    print(jounal.postings)
    print(jounal.increments)


# Generated at 2022-06-24 01:04:07.969725
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    pass


# Generated at 2022-06-24 01:04:11.066413
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from datetime import date
    je1 = JournalEntry(date(2019, 4, 3), "foo bar", None)
    je2 = JournalEntry(date(2019, 4, 3), "foo bar", None)
    assert je1 == je2

# Generated at 2022-06-24 01:04:20.794982
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def office_expenses(period: DateRange) -> Iterable[JournalEntry[str]]:
        ## Accounts:
        office_rent = Account("Office Rent", AccountType.EXPENSES)
        electricity = Account("Electricity", AccountType.EXPENSES)
        telephone = Account("Telephone", AccountType.EXPENSES)

        ## Transaction #1:
        rent = JournalEntry(datetime.date(2018, 4, 1), "Monthly office rent", "monthly rent") \
            .post(datetime.date(2018, 4, 1), office_rent, Quantity(20000)) \
            .post(datetime.date(2018, 4, 1), telephone, Quantity(3000))
        yield rent

        ## Transaction #2:

# Generated at 2022-06-24 01:04:21.521675
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 01:04:26.679044
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from ..books.accounts import AccountType
    to_account = Account(name='Account A', type=AccountType.ASSETS)
    amount = 100
    _source = "0001"
    _date = datetime.date(2020,1,1)
    source = JournalEntry[_source](date=_date, description='Description', source=_source)

    source_post = source.post(date=_date, account=to_account, quantity=amount)
    account_amount = [amount for p in source_post.postings if p.account == to_account][0].amount
    assert account_amount == amount


# Generated at 2022-06-24 01:04:37.071530
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import Account, AccountType
    from .numbers import Amount
    from .journal_entries import Posting
    account_1 = Account('12345', 'a_name', AccountType.ASSETS)
    account_2 = Account('54321', 'another_name', AccountType.LIABILITIES)
    amount_1 = Amount(100, '$')
    amount_2 = Amount(100, '$')
    posting_1 = Posting(account_1, 'a_direction', amount_1)
    posting_2 = Posting(account_2, 'another_direction', amount_2)
    assert posting_1.__repr__() == f'Posting(account={account_1}, direction=a_direction, amount=Amount($100.00))'

# Generated at 2022-06-24 01:04:46.177093
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    """
    Tests method __repr__ of class JournalEntry.
    """
    date = datetime.date(2019, 10, 4)
    description = 'Payment for the car'
    source = 'Payment slip for car'
    postings = [Posting('abc', datetime.date(2019, 10, 4), 'liabilities', 'DEC', Amount(2000.00)), Posting('abc', datetime.date(2019, 10, 4), 'cash', 'INC', Amount(2000.00))]
    journal = JournalEntry(date, description, source, postings)

# Generated at 2022-06-24 01:04:53.024165
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    """
    Test case to check if the method `__delattr__` of the class JournalEntry works as expected.
    """
    a = JournalEntry(
        1,
        "Description",
        2  # Source
    )
    a.post(3, 4, 5)
    # Test for attribute guid
    assert a.guid == 1
    delattr(a, "guid")
    assert not a.guid
    # Test for attribute postings
    assert a.postings == 2
    delattr(a, "postings")
    assert not a.postings
    # Test for invalid attribute
    try:
        delattr(a, "wrong attr")
    except AttributeError as exc:
        assert exc

# Generated at 2022-06-24 01:05:05.324651
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    """
    Tests for method post of class JournalEntry
    """
    from .accounts import AccountType, Accounts

    # Create the account and journal entry object
    account = Account("Revenue", AccountType.REVENUES)
    journal = JournalEntry(datetime.datetime.today(), "Groceries", "")

    # Test for method post
    journal.post(datetime.datetime.today(), account, Quantity(100))
    journal.validate()

    # Test for method post with same account
    journal.post(datetime.datetime.today(), account, Quantity(-10))
    journal.validate()

    # Test for method post with other account
    other_account = Account("Expense", AccountType.EXPENSES)
    journal.post(datetime.datetime.today(), other_account, Quantity(10))

# Generated at 2022-06-24 01:05:09.907173
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry(datetime.date(2019, 4, 1), "Testing Validation", None)
    je.post(datetime.date(2019, 4, 1), Account(account_type=AccountType.ASSETS, name="Cash in hand"), 1000)
    je.post(datetime.date(2019, 4, 1), Account(account_type=AccountType.REVENUES, name="Revenue"), -1000)
    je.validate()

# Generated at 2022-06-24 01:05:15.202268
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from accounting.businessobjects.billing import Billing
    billing = Billing(1, 2)
    entry = JournalEntry[Billing](datetime.date.today(), "Test Description", billing)
    entry.guid = 3
    entry.post(datetime.date.today(), Account(1, "Test Account"), 1)
    entry.__delattr__("date")
    assert entry.date == datetime.date.today()
    entry.__delattr__("description")
    assert entry.description == "Test Description"
    entry.__delattr__("source")
    assert entry.source == billing
    entry.__delattr__("postings")
    assert entry.postings == [Posting[Billing](entry, datetime.date.today(), Account(1, "Test Account"), Direction.INC, 1)]
    entry.__del

# Generated at 2022-06-24 01:05:24.188897
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from .accounts import AccountType, Account
    from .bookvalues import BookValue
    from .bookperiods import BookPeriod, BookMonth
    from .books import Book
    from .parties import Party
    from .storages import Storage
    from .warehouses import Warehouse
    book: Book[BookPeriod] = Book(
        name="Test",
        book_value_type=BookValue,
        parties=[Party(name="Test Party")],
        warehouses=[Warehouse(name="Test Warehouse")],
        storage_type=Storage,
        periods=[BookMonth(datetime.datetime.now())],
    )
    a1 = book.accounts.create(Account(
        type=AccountType.ASSETS, name="Test A1", description="Test A1"))

# Generated at 2022-06-24 01:05:31.192085
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal_entry = JournalEntry(
        "2020-05-22",
        "Description of journal entry",
        "Source of journal entry",
        [
            Posting(journal_entry, "2020-05-22", "account 1", "INC", 100),
            Posting(journal_entry, "2020-05-22", "account 2", "INC", 200),
        ]
    )

# Generated at 2022-06-24 01:05:35.685387
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    date = datetime.date(2010, 1, 1)
    account = Account(1, "Test Account", AccountType.ASSETS, [])
    entry = JournalEntry(date, "Test", account)

    ledger = [entry]

    assert ledger[0].postings[0].date.year == 2010

# Generated at 2022-06-24 01:05:43.144996
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from dacite import from_dict
    from .accounts import Ledger, AccountType, Account


# Generated at 2022-06-24 01:05:50.664043
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert isinstance(ReadJournalEntries.__call__, property)
    assert ReadJournalEntries.__call__.fget is None
    with pytest.raises(AttributeError):
        ReadJournalEntries.__call__.fset
    with pytest.raises(AttributeError):
        ReadJournalEntries.__call__.fdel

# Generated at 2022-06-24 01:05:55.789321
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from .accounts import AccountType, Account

    j = JournalEntry(datetime.date.today(), "test", None)

    j.postings = []

    assert j.postings == []

    j.post(datetime.date.today(), Account(AccountType.ASSETS, "Cash"), 100)

    assert j.postings[0].account.code == "Cash"
    assert j.postings[0].direction == Direction.INC
    assert j.postings[0].amount == 100

# Generated at 2022-06-24 01:06:06.388635
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    original = JournalEntry(datetime.date(2000, 1, 1), "Sample Description", source=None)
    original.post(datetime.date(2000, 1, 1), Account("Bank Cash"), 1)
    original.post(datetime.date(2000, 1, 1), Account("Sales"), -1)

# Generated at 2022-06-24 01:06:14.067694
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    obj1 = JournalEntry[None]( date=datetime.date.today(), description='abc', guid='abc', postings=None, source=None)
    obj2 = JournalEntry[None]( date=datetime.date.today(), description='def', guid='def', postings=None, source=None)
    obj3 = JournalEntry[None]( date=datetime.date.today(), description='abc', guid='abc', postings=None, source=None)
    # assert hash(obj1) == hash(obj3)
    # assert hash(obj2) != hash(obj3)

# Generated at 2022-06-24 01:06:22.385811
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import AccountMap
    from .sources import JournalSource

# Generated at 2022-06-24 01:06:29.083041
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    import datetime
    # Define object for test
    test_journal_entry = JournalEntry[int](date=datetime.date(2019, 1, 1), description="Journal entry 1", source=1)
    test_posting = Posting[int](journal=test_journal_entry, date=datetime.date(2019, 1, 1), account=Account('Assets-Current-Cash'), direction=Direction.INC, amount=Amount(500))
    assert hash(test_posting) is not None


# Generated at 2022-06-24 01:06:33.473572
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je = JournalEntry(date=datetime.date(2019, 2, 1), description="", source=None)
    d = {je: "a"}
    je2 = JournalEntry(date=datetime.date(2019, 2, 1), description="", source=None)
    assert je in d and je2 in d

# Generated at 2022-06-24 01:06:42.115907
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    from journal.domain.accounts import DebitAccount, CreditAccount
    from journal.domain.models import Posting

    posting = Posting("", date(2019, 1, 21), DebitAccount("", ""), Direction.INC, Amount(3))
    # print(posting.is_debit)
    posting.account = CreditAccount("", "")
    # print(posting.is_debit)
    assert posting.is_debit == False
    assert posting.is_credit == True
    print("test_Posting___setattr__ passed.")


# Generated at 2022-06-24 01:06:42.738365
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    pass

# Generated at 2022-06-24 01:06:48.489757
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert issubclass(ReadJournalEntries, Protocol)
    assert issubclass(ReadJournalEntries.__init__, Protocol)
    assert callable(ReadJournalEntries.__call__)
    assert not hasattr(ReadJournalEntries, '__dict__')
    try:
        class X(ReadJournalEntries):
            pass
    except TypeError:
        pass
    else:
        assert False, "Should raise TypeError"

# Generated at 2022-06-24 01:06:54.387368
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    try:
        JournalEntry.__setattr__("date", "date")
        JournalEntry.__setattr__("description", "description")
        JournalEntry.__setattr__("source", "source")
        JournalEntry.__setattr__("postings", "postings")
        JournalEntry.__setattr__("guid", "guid")
    except:
        assert False
    assert True

# Generated at 2022-06-24 01:06:57.334818
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry(datetime.date(2020, 1, 1), "Entry 1", "Source")) == "JournalEntry(datetime.date(2020, 1, 1), 'Entry 1', 'Source')"


# Generated at 2022-06-24 01:07:00.260709
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass


# Generated at 2022-06-24 01:07:04.597883
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def journal_reader(period: DateRange) -> Iterable[JournalEntry[_T]]:
        raise NotImplementedError()

    # Validate the prototype of the method call:
    assert callable(journal_reader), "Expected the function to be callable."
    assert list(journal_reader(None)) == [], "Expected no journal entries in the returned iterable."

# Generated at 2022-06-24 01:07:15.230455
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    t = "Transactions"
    de = JournalEntry(datetime.date(2019, 1, 1), "description", t)
    with pytest.raises(AttributeError):
        de.guid = None
    with pytest.raises(AttributeError):
        de.postings = None
    with pytest.raises(AttributeError):
        de.amount = None
    with pytest.raises(AttributeError):
        de.inc = None
    with pytest.raises(AttributeError):
        de.dec = None
    with pytest.raises(AttributeError):
        de.debits = None
    with pytest.raises(AttributeError):
        de.credits = None
    with pytest.raises(AttributeError):
        de.is_debit = None

# Generated at 2022-06-24 01:07:20.814657
# Unit test for constructor of class Posting
def test_Posting():
    #journal: "JournalEntry[_T]",
    #date: datetime.date,
    #account: Account,
    #direction: Direction,
    #amount: Amount
    description = datetime.datetime.now()
    date = datetime.datetime.now()
    account = Account("ACC")
    direction = Direction.INC
    amount = Amount(12)
    journal = JournalEntry(description,"xxx",date)
    post = Posting(journal, date, account, direction, amount)
    assert type(post) == Posting
    assert post.journal == JournalEntry(description,"xxx",date)
    assert post.date == datetime.datetime.now()
    assert post.account == Account("ACC")
    assert post.direction == Direction.INC
    assert post.amount == Amount(12)
    assert post.is_deb

# Generated at 2022-06-24 01:07:31.198950
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # Setup
    journal_entry_date = datetime.date(2019, 8, 1)
    journal_entry_description = "Test"
    journal_entry_source = ""
    journal_entry = JournalEntry(journal_entry_date, journal_entry_description, journal_entry_source)

    posting_date = datetime.date(2019, 8, 1)
    posting_account = Account("1001", "Assets", AccountType.ASSETS)
    posting_direction = Direction.INC
    posting_amount = Amount(10)

    posting = Posting(journal_entry, posting_date, posting_account, posting_direction, posting_amount)

    # Exercise
    posting_repr = posting.__repr__()

    # Verify

# Generated at 2022-06-24 01:07:35.751832
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    def check(source):
        je = JournalEntry[str](datetime.date(2019, 12, 25), "Test Journal Entry", source)
        assert je.source == source

    check("Source1")
    check(100)

# Generated at 2022-06-24 01:07:42.649256
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    try:
        a = JournalEntry('', '', '')
        a.postings = [1,2,3]
        assert False, 'Should raise AssertionError when trying to set postings'
    except AssertionError as e:
        assert str(e) == 'Cannot override postings attribute of JournalEntry', 'Should have correct error message'