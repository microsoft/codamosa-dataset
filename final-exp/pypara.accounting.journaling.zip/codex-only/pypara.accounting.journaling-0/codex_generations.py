

# Generated at 2022-06-24 00:57:45.252567
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    p = Posting(JournalEntry(datetime.date.today(), "", None), datetime.date.today(), Account(AccountType.ASSETS, "Cash"), Direction.DEC, Amount(1000))
    p.amount = Amount(2000)

    assert(p.amount == Amount(2000))


# Generated at 2022-06-24 00:57:49.765110
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    entry1 = JournalEntry(date=datetime.date.today(), description="test", source=None)
    entry2 = JournalEntry(date=datetime.date.today(), description="test", source=None)
    assert hash(entry1) == hash(entry2)

# Generated at 2022-06-24 00:57:55.694793
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account = Account(type=AccountType.ASSETS, number=1, name="cash", description="the money")
    je = JournalEntry(date=datetime.date(2019, 1, 1), description="", source=None) \
        .post(date=datetime.date(2019, 1, 1), account=account, quantity=100) \
        .post(date=datetime.date(2019, 1, 1), account=account, quantity=-100)
    je.validate()

# Generated at 2022-06-24 00:58:00.856329
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(date=datetime.date(2019, 1, 1), account=Account("1001", AccountType.ASSETS), direction=Direction.DEC,
                 amount=Amount("150.00"))
    p2 = Posting(date=datetime.date(2019, 1, 1), account=Account("1001", AccountType.ASSETS), direction=Direction.DEC,
                 amount=Amount("150.00"))
    p3 = Posting(date=datetime.date(2019, 1, 1), account=Account("1001", AccountType.ASSETS), direction=Direction.DEC,
                 amount=Amount("100.00"))
    assert p1 == p2
    assert p1 != p3


# Generated at 2022-06-24 00:58:05.802258
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    je = JournalEntry(date=datetime.date(2000, 1, 1), description="Test", source=None)
    je.postings = []
    assert je.postings == []

# Generated at 2022-06-24 00:58:17.306866
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    entry = JournalEntry(date=datetime.date.today(), description='Bought a pen', source=None)
    entry.post(date=datetime.date.today(), account=Account(guid=Guid('b7d0e12a-b2fb-4f9d-9a6a-a6b7e67c0e0c'), name='Cash'), quantity=1000)
    entry.post(date=datetime.date.today(), account=Account(guid=Guid('d1b5fa5b-bc5b-4a7f-8e2a-7c643e87a6a7'), name='Stationary'), quantity=-100)
    print(entry.__repr__())
    print(entry.debits)
    print(entry.credits)



# Generated at 2022-06-24 00:58:28.246907
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    je1=JournalEntry(date=datetime.date(2020,9,11), description="Wage", source="Wage")
    je2=JournalEntry(date=datetime.date(2020,9,11), description="Wage", source="Wage")
    je1.post(datetime.date(2020,9,11), Account(name="Cash"), Quantity(10.0))
    je1.post(datetime.date(2020,9,11), Account(name="Wage"), Quantity(-10.0))
    je2.post(datetime.date(2020,9,11), Account(name="Wage"), Quantity(-10.0))
    je2.post(datetime.date(2020,9,11), Account(name="Cash"), Quantity(10.0))
    assert repr(je1) == repr(je2)

# Generated at 2022-06-24 00:58:33.166918
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup
    date1 = datetime.date(2018, 1, 1)
    guid1 = "5A6AED7B"
    test_JournalEntry = JournalEntry(date1, "bla bla", None, None)

    # nothing is posted if quantity is zero
    test_JournalEntry.post(date1, None, 0)
    assert len(test_JournalEntry.postings) == 0

    # Execute
    test_JournalEntry.post(date1, None, 3)

# Generated at 2022-06-24 00:58:38.905481
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from types import FunctionType
    assert issubclass(FunctionType, ReadJournalEntries)
    assert issubclass(ReadJournalEntries, FunctionType)
    assert not issubclass(FunctionType, ReadJournalEntries)
    assert not issubclass(ReadJournalEntries, FunctionType)

# Generated at 2022-06-24 00:58:40.823217
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    a = JournalEntry[int](datetime.date(2000, 1, 1), "desc", 1, [Posting("a", datetime.date(2000, 1, 1), "b", -1, 100)])
    a.validate()


# Generated at 2022-06-24 00:58:49.691627
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import read_account
    journalentry = JournalEntry[int](date=datetime.date.today(), description="LOL", source=1)
    posting = Posting[int](journal=journalentry, date=datetime.date.today(),account=read_account(path_account_file="accounts/",account_id=3),direction=Direction.INC,amount=Amount(quantity=1) )
    assert posting.journal == JournalEntry[int](date=datetime.date.today(), description="LOL", source=1)
    assert posting.date == datetime.date.today()
    assert posting.account == Account(id=3, name="Test", type= AccountType.LIABILITIES)
    assert posting.direction == Direction.INC

# Generated at 2022-06-24 00:58:50.597877
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-24 00:58:55.181448
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journal_e_1 = JournalEntry[None](datetime.date(2019,6,21),"Test1",None,postings=[])
    journal_e_2 = JournalEntry[None](datetime.date(2019,6,21),"Test1",None,postings=[])
    journal_e_3 = JournalEntry[None](datetime.date(2019,5,21),"Test2",None,postings=[])
    assert (journal_e_1==journal_e_2 )
    assert (journal_e_1!=journal_e_3 )

# Generated at 2022-06-24 00:59:05.506903
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    class Object:
        pass

    Object.journal = JournalEntry[Object]()
    on_init = vars(Object.journal)
    Object.journal.postings.append(Posting(Object.journal, datetime.date.today(), Account('Test'),
                                   Direction.INC, Amount(100)))
    on_append = vars(Object.journal)

    assert Object.journal.postings == [Posting(Object.journal, datetime.date.today(), Account('Test'),
                                               Direction.INC, Amount(100))]
    assert on_init == {'date': None, 'description': None, 'source': None, 'postings': [], 'guid': None}
    assert on_append == on_init

# Generated at 2022-06-24 00:59:11.859559
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry(datetime.date(2012, 12, 12), "test journal entry", "")
    je.post(datetime.date(2012, 12, 12), Account(AccountType.EQUITIES, Guid(), "Test Account"), 100)
    je.post(datetime.date(2012, 12, 12), Account(AccountType.LIABILITIES, Guid(), "Test Liability Account"), -100)
    je.validate()

# Generated at 2022-06-24 00:59:19.237311
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    obj = Posting(JournalEntry(datetime.date(2020, 5, 1), 'Andi Dev', 'Dev', []), datetime.date(2020, 5, 1), 'Cash', Direction.INC, 1000)
    assert obj.journal == JournalEntry(datetime.date(2020, 5, 1), 'Andi Dev', 'Dev', [])
    assert obj.date == datetime.date(2020, 5, 1)
    assert obj.account == 'Cash'
    assert obj.direction == Direction.INC
    assert obj.amount == 1000
    # assert obj.is_debit == True
    # assert obj.is_credit == False

    obj.journal = JournalEntry(datetime.date(2020, 5, 1), 'Andi Dev', 'Dev', [])

# Generated at 2022-06-24 00:59:23.906272
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting(None, datetime.date(2018,10,10), Account(name="Test"), Direction.INC, Amount(10))) == "Posting(journal=None, date=2018-10-10, account=Account(name='Test'), direction=Direction.INC, amount=Amount(10))"


# Generated at 2022-06-24 00:59:35.543028
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    LedgerJournalEntry=JournalEntry[int]
    j1=LedgerJournalEntry(date=datetime.date.today(),description="j1",source=1001)
    j1.post(date=datetime.date.today(),account=Account("account1",AccountType.ASSETS),quantity=1000)
    j1.post(date=datetime.date.today(),account=Account("account2",AccountType.ASSETS),quantity=-1000)
    j2=LedgerJournalEntry(date=datetime.date.today(),description="j1",source=1001)
    j2.post(date=datetime.date.today(),account=Account("account1",AccountType.ASSETS),quantity=1000)

# Generated at 2022-06-24 00:59:42.679013
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import Account, AccountType

    posting1 = Posting(journal={}, date={}, account=Account(name='ACCOUNT-1', type=AccountType.EXPENSES, path='/EXPENSES/ACCOUNT-1'), direction=Direction.DEC, amount=Amount(10))
    posting2 = Posting(journal={}, date={}, account=Account(name='ACCOUNT-1', type=AccountType.EXPENSES, path='/EXPENSES/ACCOUNT-1'), direction=Direction.DEC, amount=Amount(10))
    posting3 = Posting(journal={}, date={}, account=Account(name='ACCOUNT-2', type=AccountType.EXPENSES, path='/EXPENSES/ACCOUNT-2'), direction=Direction.DEC, amount=Amount(10))

# Generated at 2022-06-24 00:59:52.713530
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    je1 = JournalEntry(
        date=datetime.date.today(), description="Posting 1", source=1, guid="8ebbca68-be30-4cda-ad66-8b1e89b2c4d1"
    )
    je2 = JournalEntry(
        date=datetime.date.today(), description="Posting 2", source=2, guid="7ebbca68-be30-4cda-ad66-8b1e89b2c4d1"
    )
    je3 = JournalEntry(
        date=datetime.date.today(), description="Posting 3", source=3, guid="6ebbca68-be30-4cda-ad66-8b1e89b2c4d1"
    )

# Generated at 2022-06-24 00:59:58.719262
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    try:
        JournalEntry(date = datetime.date(2020, 11, 2), description = 'test description', source = 'test source').postings = 'not-a-list'
    except TypeError:
        pass
    else:
        assert False, "JournalEntry should not allow to modify postings"


# Generated at 2022-06-24 01:00:02.962823
# Unit test for constructor of class Posting
def test_Posting():
    """
    This function creates a Posting value object and validate it by calling its properties and assert the results
    """
    p = Posting("JournalEntry", datetime.datetime(2009, 8, 27, 22, 41, 56), Account("Account"), 2, 3)

    # Test is_debit
    assert p.is_debit == False

    # Test is_credit
    assert p.is_credit == True


# Unit Test for constructor of class JournalEntry

# Generated at 2022-06-24 01:00:04.093909
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-24 01:00:10.498266
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry(datetime.date(2020, 8, 13), 'Test', 'Source')
    posting = Posting(journal, datetime.date(2020, 8, 13), Account('Test'), Direction.DEC, Amount(12))
    assert repr(posting) == "Posting(journal=JournalEntry(date=datetime.date(2020, 8, 13), description='Test', source='Source', postings=[<Posting entry>]), date=datetime.date(2020, 8, 13), account=Account(name='Test', number=0, type=AccountType.EXPENSES), direction=<Direction.DEC: -1>, amount=12)"


# Generated at 2022-06-24 01:00:21.717308
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je = JournalEntry[int] (date = datetime.date(2020, 8, 28), description = "Payment by Customer #2", source = 2)
    je = je.post(date = datetime.date(2020, 8, 28), account = Account("Accounts Receivables"), quantity = Quantity(1400))
    je = je.post(date = datetime.date(2020, 8, 28), account = Account("Cash"), quantity = Quantity(-1400))

    je2 = JournalEntry[int] (date = datetime.date(2020, 8, 28), description = "Payment by Customer #2", source = 2)
    je2 = je2.post(date = datetime.date(2020, 8, 28), account = Account("Accounts Receivables"), quantity = Quantity(1400))

# Generated at 2022-06-24 01:00:29.167922
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Given a journal entry made of dataclasses
    le1 = JournalEntry[None](datetime.date(2017,7,12), 'description', None)
    le2 = JournalEntry[None](datetime.date(2017,7,12), 'description', None)
    le3 = JournalEntry[None](datetime.date(2017,7,13), 'description', None)
    le4 = JournalEntry[None](datetime.date(2017,7,12), 'description', None)
    le4.post(datetime.date(2017,7,12), Account('Test', AccountType.ASSETS), Quantity('100.00'))
    le5 = JournalEntry[None](datetime.date(2017,7,12), 'description', None)

# Generated at 2022-06-24 01:00:40.003297
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import account, equity
    from datetime import date

    p1 = Posting(None, date(2020,1,1), equity("A"), Direction.INC, Amount(100))
    assert p1.journal == None
    assert p1.date == date(2020, 1, 1)
    assert p1.account == equity("A")
    assert p1.direction == Direction.INC
    assert p1.amount == Amount(100)
    assert p1.is_debit is False
    assert p1.is_credit is True
    p2 = Posting(None, date(2020,1,1), account("A", AccountType.EXPENSES), Direction.DEC, Amount(100))
    assert p2.journal == None
    assert p2.date == date(2020, 1, 1)

# Generated at 2022-06-24 01:00:49.898144
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    """
    Test for JournalEntry.__eq__
    """
    # Construct two JournalEntry objects and test for equality
    journal_entry1 = JournalEntry[object](
            date = datetime.datetime(2020, 1, 1),
            description = '',
            source = object())
    journal_entry2 = JournalEntry[object](
            date = datetime.datetime(2020, 1, 1),
            description = '',
            source = object())

    journal_entry1.post(
            date = datetime.datetime(2020, 1, 1),
            account = Account(account_type = AccountType.ASSETS, name='Account 1'),
            quantity = Quantity(amount = 100))

# Generated at 2022-06-24 01:00:56.857212
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    ### Test Invalid Date
    try:
        test_account = Account("assets", AccountType.ASSETS)
        test_journal = JournalEntry(datetime.date(2030, 8, 5), "test", "test")
        test_journal.post(datetime.date(2029, 8, 5), test_account, 5)
    except AssertionError as _err:
        assert type(_err) == AssertionError
    else:
        raise AssertionError("AssertionError was not raised.")
    ### Test Invalid Amount

# Generated at 2022-06-24 01:00:59.384811
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert Posting[int] in globals()
    del Posting.__dict__['__dict__']['__delattr__']


# Generated at 2022-06-24 01:01:09.648465
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j=JournalEntry()
    j.post(date=datetime.datetime.now(), account=Account(code="1111", name="Account 1"), quantity=10)
    j.post(date=datetime.datetime.now(), account=Account(code="1112", name="Account 2"), quantity=-10)
    assert len(j.postings) == 2
    assert j.postings[0].account == Account(code="1111", name="Account 1")
    assert j.postings[0].amount == Amount(10)
    assert j.postings[1].account == Account(code="1112", name="Account 2")
    assert j.postings[1].amount == Amount(10)

# Generated at 2022-06-24 01:01:21.514243
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date
    from pytrade.domain.accounts import AccountType
    from pytrade.domain.lib import Account

    # https://stackoverflow.com/questions/610883/how-to-know-if-an-object-has-an-attribute-in-python
    # This is equivalent to hasattr() but more readable.
    hasattr(JournalEntry._definition, '_counter')

    # =============================================================================================
    # object.__setattr__(self, name, value)
    # How: 
    #   - __setattr__ is a function, which can be assigned on a class.
    #
    # Reference:
    #   - https://docs.python.org/3/reference/datamodel.html#object.__setattr__
    #
    # Test:
    #   - Test that an

# Generated at 2022-06-24 01:01:24.678990
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Declare a journal entry
    journal = JournalEntry("My journal entry")
    assert hash(journal) == 0
    assert hash("My journal entry") == -3944050873396926022



# Generated at 2022-06-24 01:01:30.320591
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Given
    date, description, source, postings = (datetime.date.today(), "", "", [])
    journal_entry = JournalEntry(date, description, source, postings)
    # Then
    assert repr(journal_entry) == "JournalEntry(date = {}, description = {}, source = {}, postings = {})".format(
        repr(date), repr(description), repr(source), repr(postings)
    )



# Generated at 2022-06-24 01:01:38.108173
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # Arrange
    posting = Posting(
        journal=JournalEntry(
            date=datetime.date(2020, 1, 1),
            description='Description',
            source=None
        ),
        date=datetime.date(2020, 2, 1),
        account=Account(
            code='public/current_assets/cash',
            name='Cash',
            type=AccountType.ASSETS
        ),
        direction=Direction.INC,
        amount=Amount(123.45),
    )
    
    # Act
    repr_ = repr(posting)

    # Assert

# Generated at 2022-06-24 01:01:40.000838
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():

    pass

# Generated at 2022-06-24 01:01:47.371609
# Unit test for constructor of class Posting
def test_Posting():
    # Just test whether the constructor is working or not
    posting=Posting(JournalEntry(datetime.date(year=2019,month=4,day=4)),datetime.date(year=2019,month=4,day=4),Account('Test'),Direction.INC,Amount(abs(1000)))
    assert posting.amount==Amount(abs(1000))
    assert posting.date==datetime.date(year=2019,month=4,day=4)
    assert posting.direction==Direction.INC
    assert posting.account==Account('Test')


# Generated at 2022-06-24 01:01:51.402305
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry(date=datetime.date(2020, 1, 1), description="Foo", source="Bar", postings=[])) == \
           "JournalEntry(date=datetime.date(2020, 1, 1), description='Foo', source='Bar', postings=[])"



# Generated at 2022-06-24 01:02:00.432853
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import Account
    from .currency import Currency
    from .commons import CurrencyRange

    journal = JournalEntry("Description of Journal Entry", "Source of Journal Entry", None)
    account_1 = Account("Account 1")
    account_2 = Account("Account 2")
    currency = Currency("INR", CurrencyRange("0.02", "3.1", 0.2), 3, 2)

    date = datetime.date(2020, 1, 1)
    journal.post(date, account_1, 100)
    journal.post(date, account_2, -200)


# Generated at 2022-06-24 01:02:09.740661
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # Test setup
    class JournalEntry():
        def __init__(self):
            self.guid = makeguid()
            self.postings = list()

        def post(self, date, account, quantity):
            self.postings.append(Posting(self, date, account, Direction.of(quantity), abs(quantity)))
            return self

    # Test scenario
    p = Posting(JournalEntry(), datetime.date.today(), Account("Assets:Cash"), Direction.INC, 100)

    # Test assertions
    try:
        p.journal = None
        raise AssertionError("Should raise error when setting attribute that doesn't exist")
    except AttributeError:
        pass


# Generated at 2022-06-24 01:02:14.906895
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    a = Account('a')
    j = JournalEntry(1, 'a', 'a')
    j.post(1, a, 5)
    j.validate()

    try:
        delj.postings[0]
    except Exception as e:
        print(e)
        return 0
    return 1


# Generated at 2022-06-24 01:02:22.189740
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # Define a test class.
    @dataclass
    class TestClass:
        # Define a field.
        field1: str
        # Define a journal entry.
        journal=JournalEntry[TestClass]
        # Create an instance of the test class.
        TestClassInstance=TestClass("some string", journal)
    # Test the method.
    TestClassInstance.__delattr__("field1")
    # Check the result.
    assert (not hasattr(TestClassInstance, "field1"))

# Generated at 2022-06-24 01:02:30.891363
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..bookkeeping.accounts import Account
    from ..bookkeeping.commodities import Commodity

    from .journal_entries import JournalEntries

    currency = Commodity("USD")
    cash = Account("Assets:Cash", AccountType.ASSETS, currency)
    income = Account("Revenues:Income", AccountType.REVENUES, currency)
    expenses = Account("Expenses:Food", AccountType.EXPENSES, currency)
    payable = Account("Liabilities:Payable", AccountType.LIABILITIES, currency)

    entries = JournalEntries()
    entries.new("Payment", guid="BLAH").post("2014-01-01", cash, +100).post("2014-01-01", income, +100).validate()

# Generated at 2022-06-24 01:02:32.938617
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert isinstance(ReadJournalEntries, object)



# Generated at 2022-06-24 01:02:39.854859
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # Create a journal entry
    post_entry = JournalEntry(datetime.date(2020, 1, 4), "Test journal entry", "Test source")
    # Create a couple of postings
    post1 = Posting(post_entry, datetime.date(2020, 1, 4), Account('Test account', 'Equities'), Direction.INC, Amount(2000))
    post2 = Posting(post_entry, datetime.date(2020, 1, 4), Account('Test account', 'Equities'), Direction.INC, Amount(2000))
    assert post1 == post2


# Generated at 2022-06-24 01:02:49.034885
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from typing import Dict, Iterable, List

    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AgeGroup, AccountType, AccountSubType
    from .categories import Category, CategoryType, CategorySubType

    ## Define categories:
    income = Category(
        CategoryType.REVENUES, CategorySubType.REVENUE_SALES, "Sales Revenue", guid="f49b2725-22ec-4b0e-b8b4-c4e4a9b9f7c9"
    )

# Generated at 2022-06-24 01:02:54.661905
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journal_entry_1 = JournalEntry(datetime.date(2020, 1, 1), "first journal entry", "")
    journal_entry_1.post(datetime.date(2020, 1, 1), Account("Assets", "Cash"), 100)
    journal_entry_1.post(datetime.date(2020, 1, 1), Account("Expenses", "Food"), -100)
    assert journal_entry_1.date == datetime.date(2020, 1, 1)
    assert journal_entry_1.description == "first journal entry"
    assert journal_entry_1.source == ""
    assert journal_entry_1.postings[0].journal == journal_entry_1
    assert journal_entry_1.postings[0].date == datetime.date(2020, 1, 1)
    assert journal_entry_1.post

# Generated at 2022-06-24 01:03:01.169344
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date, timedelta
    from .accounts import Account
    from .journal import JournalEntry
    # setup dummy accounts
    sample_account = Account(
        guid='9a9fcfe9-6dbe-4c72-a0a2-eeaba508beb9',
        name='sample account',
        type=AccountType.EQUITIES,
        parent_guid='',
    )
    # setup a sample journal entry
    sample_journal_entry = JournalEntry(
        date = date.today() + timedelta(days=1),
        description = 'sample journal entry',
        source = None,
    )
    # test the method
    sample_journal_entry.post(date.today(), sample_account, 1)
    assert sample_journal_entry.postings[0].amount.value == 1
   

# Generated at 2022-06-24 01:03:11.177961
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    je1 = JournalEntry(datetime.date.today(), 'description', 'source')
    je2 = JournalEntry(datetime.date.today(), 'description', 'source')
    p1 = Posting(je1, datetime.date.today(), Account('Account', '123456789'), Direction.INC, Amount(1000))
    p2 = Posting(je1, datetime.date.today(), Account('Account', '123456789'), Direction.INC, Amount(1000))
    p3 = Posting(je2, datetime.date.today(), Account('Account', '123456789'), Direction.INC, Amount(1000))

    assert p1 == p2
    assert p1 != p3

# Generated at 2022-06-24 01:03:13.127898
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert JournalEntry("2020-05-07", "Description", "test_source", postings=None)

# Generated at 2022-06-24 01:03:23.735365
# Unit test for constructor of class Posting
def test_Posting():
    j = JournalEntry[int](datetime.date(2020,7,5),'description',2)
    j.post(datetime.date(2020,7,5), Account(AccountType.ASSETS,0), 5)
    assert j.postings[0].date == datetime.date(2020,7,5)
    assert j.postings[0].account.type == AccountType.ASSETS
    assert j.postings[0].account.guid == 0
    assert j.postings[0].direction == Direction.INC
    assert j.postings[0].amount == 5
    assert j.postings[0].is_debit == True
    assert j.postings[0].is_credit == False
    assert j.increments[0].date == datetime.date(2020,7,5)
    assert j.incre

# Generated at 2022-06-24 01:03:28.917920
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    account = Account("Assets Account.Cash.Business Checking", AccountType.ASSETS)
    posting = Posting("AcBook.JournalEntry[id-1]", datetime.date(2020, 1, 1), account, Direction.INC, amount=10)
    assert (
        repr(posting) == "Posting(journal='AcBook.JournalEntry[id-1]', date=datetime.date(2020, 1, 1), account=Account('Assets Account.Cash.Business Checking', AccountType.ASSETS), direction=Direction.INC, amount=Amount(10))"
    )



# Generated at 2022-06-24 01:03:37.195850
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    from core.domain.accounts import Account, AccountType

    j = JournalEntry(date=date(2020, 3, 14), description='DebitPostingTest')
    p1 = Posting(j, date=date(2020, 3, 14), account=Account(AccountType.ASSETS, 'testaccount'), direction=Direction.INC, amount=1)
    assert j.postings == [p1], '__setattr__ is not working properly'
    assert j.postings == [p1], '__setattr__ is not working properly'


# Generated at 2022-06-24 01:03:37.736720
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass

# Generated at 2022-06-24 01:03:45.110187
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Arrange
    from .accounts import Account

    account1 = Account("111010", "Cash")
    account2 = Account("111010", "Cash")
    journal = JournalEntry[str]("2019-01-01", "description", "source")
    posting1 = Posting(journal, "2019-01-01", account1, Direction.INC, Amount(100))
    posting2 = Posting(journal, "2019-01-01", account2, Direction.INC, Amount(100))
    journal.postings.append(posting1)
    journal.postings.append(posting2)

# Generated at 2022-06-24 01:03:51.951697
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .. import accounts
    from .. import event_sources
    from .. import event_stores
    from .. import events

    from . import event_handlers

    event_store = event_stores.InMemoryEventStore()
    journal_entry_store = event_handlers.JournalEntryStore(
        accounts.inmemory.get_account_manager(event_store),
        ReadJournalEntries.from_event_source(event_sources.SingleEventSource(event_store)),
    )

    asset_account = event_handlers.accounts.AssetAccount(
        "ASSET_1", "Dummy asset account.",
    )
    revenue_account = event_handlers.accounts.RevenueAccount(
        "REVENUE_1", "Dummy revenue account.",
    )

# Generated at 2022-06-24 01:03:53.130927
# Unit test for constructor of class Posting
def test_Posting():
    assert Posting.__new__(Posting)

# Generated at 2022-06-24 01:03:53.889204
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-24 01:04:05.380664
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Test case:
    # Example of Journal entry can be read with __repr__.
    journal = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description='Vendu 100 actions AAA pour 3000€',
        source=object(),
        postings=[
            Posting(journal=None,
                    date=datetime.date(2020, 1, 1),
                    account=Account(2000, 'Portefeuille', AccountType.ASSETS),
                    direction=Direction.INC,
                    amount=Amount(3000)),
            Posting(journal=None,
                    date=datetime.date(2020, 1, 1),
                    account=Account(1000, 'Compte courant', AccountType.ASSETS),
                    direction=Direction.DEC,
                    amount=Amount(3000))
        ]
    )

    expected

# Generated at 2022-06-24 01:04:08.591123
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Account, AccountType

    class MyReadJournalEntries(ReadJournalEntries[_T]):
        pass

    assert issubclass(MyReadJournalEntries, ReadJournalEntries)
    assert issubclass(ReadJournalEntries, Protocol)



# Generated at 2022-06-24 01:04:18.597882
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    # given
    guid: Guid = makeguid()
    posting = Posting(guid, datetime.date(2019, 1, 1), Account("0000", "", AccountType.ASSETS), Direction.INC, Amount(10))
    posting_same = Posting(guid, datetime.date(2019, 1, 1), Account("0000", "", AccountType.ASSETS), Direction.INC, Amount(10))
    posting_different = Posting(makeguid(), datetime.date(2019, 1, 1), Account("0000", "", AccountType.ASSETS), Direction.INC, Amount(10))

    # when
    hash_posting = hash(posting)
    hash_posting_same = hash(posting_same)
    hash_posting_different = hash(posting_different)

    # then
    assert hash_post

# Generated at 2022-06-24 01:04:24.484991
# Unit test for constructor of class Posting
def test_Posting():
    test_Account = Account(code="010101", name="test_Account", type=AccountType.ASSETS, parent="0101")
    test_Direction = Direction.of(2)
    test_Amount = Amount(2)
    test_Guid = makeguid()

    test_JournalEntry = JournalEntry(date="2019/10/01", description="test_JournalEntry", source="test_BusinessObject")
    test_Posting = Posting(journal=test_JournalEntry, date="2019/10/01", account=test_Account, direction=test_Direction, amount=test_Amount)
    assert test_Posting.journal.date == datetime.date(2019, 10, 1)
    assert test_Posting.journal.description == 'test_JournalEntry'

# Generated at 2022-06-24 01:04:31.810954
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import Account, AccountType

    test_account = Account("test_account", AccountType.ASSETS, None)
    test_posting = Posting(JournalEntry(datetime.date(2020, 1, 1), "Description", None),
                           datetime.date(2020, 1, 1), test_account, Direction.INC, Amount(1000))
    assert repr(test_posting) == "<Posting source: test_account  amount: $1,000.00 direction: INC>"

# Generated at 2022-06-24 01:04:41.596876
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType

    Account.register("pettycash", AccountType.ASSETS, "My Assets")
    Account.register("patrons", AccountType.ASSETS, "My Assets")
    Account.register("revenues", AccountType.REVENUES, "My Revenues")
    Account.register("expenses", AccountType.EXPENSES, "My Expenses")

    # this should get validated

# Generated at 2022-06-24 01:04:52.478226
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from datetime import date
    from .accounts import Account
    from .accounts import AccountMap
    from .accounts import AccountType
    from .accounts import AccountVector
    from .accounts import is_account_id
    from .accounts import is_account_type
    from .bussiness_objects import Party
    from .bussiness_objects import PartyMap
    from .bussiness_objects import is_party
    # fixture is the setup required to run a test method
    # set up some accounts and parties
    asset_accounts = AccountVector(is_account_id, is_account_type)
    asset_accounts.add(AccountType.ASSETS, 'Checking account', 'Account for everyday expenses')
    asset_accounts.add(AccountType.ASSETS, 'Credit Card account', 'Account for credit card expenses')


# Generated at 2022-06-24 01:04:58.083242
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    print('testing')
    jo = JournalEntry(datetime.date(2020, 1, 10), 'description string', 'source') 
    print(jo)
    expected_result = f'JournalEntry(date=2020-01-10, description=description string, source=source, postings=[], guid={jo.guid})'
    assert str(jo) == expected_result

# Generated at 2022-06-24 01:05:08.317812
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..books import accounts
    from . import transactions
    ## Setup:
    ## Create a journal entry:
    je = JournalEntry(
        datetime.date(2019, 7, 1),
        "Test journal entry",
        FauxInvoice("I-001", "Faux invoice", datetime.date(2019, 7, 1), datetime.date(2019, 7, 30), 300),
    )
    ## Post a posting with a positive quantity to an 'ASSETS' account:
    je.post(datetime.date(2019, 7, 1), accounts.Cash, +Amount(300))

    ## Validate:
    ## Journal entry should be consistent
    assert je.validate() == None


# Generated at 2022-06-24 01:05:11.651013
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    try:
        JournalEntry().__setattr__('date', "2020-01-02")
    except Exception as e:
        print(e)
        assert type(e) == TypeError
    else:
        assert False


# Generated at 2022-06-24 01:05:14.408614
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert hasattr(JournalEntry.post,'__delattr__')
    assert hasattr(JournalEntry.validate,'__delattr__')
    assert hasattr(JournalEntry,'__delattr__')


# Generated at 2022-06-24 01:05:15.050958
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass

# Generated at 2022-06-24 01:05:18.417363
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert not ReadJournalEntries.__abstractmethods__
    assert not ReadJournalEntries.__init__
    assert ReadJournalEntries.__module__ == __name__


###
# Testcases for the module.
###


# Generated at 2022-06-24 01:05:21.276212
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    def _hash(journal_entry):
        return hash(journal_entry)

    entry1 = JournalEntry[str]('2020-01-01', 'Test Description', 'Test Source', [])
    entry2 = JournalEntry[str]('2020-01-01', 'Test Description', 'Test Source', [])

    assert entry1.__hash__() == entry2.__hash__()
    assert entry1.__hash__() == _hash(entry2)

# Generated at 2022-06-24 01:05:25.728270
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # Given
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        pass
    # When
    read_journal_entries(DateRange.create(datetime.date.today(), datetime.date.today()))
    # Then
    assert True

# Generated at 2022-06-24 01:05:29.776557
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    try:
        journalentry = JournalEntry[object](None,None,None)
        raise AssertionError
    except TypeError:
        pass


# Generated at 2022-06-24 01:05:33.137405
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass # TODO


# Generated at 2022-06-24 01:05:35.457588
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p1 = Posting(None, None, None, None, None)
    p2 = Posting(None, None, None, None, None)

    assert p1.__hash__() == p2.__hash__()

# Generated at 2022-06-24 01:05:42.897478
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    """
    Test the method __delattr__ of the class JournalEntry.
    """
    from ..accounting.accounts import Account
    from ..accounting.ledgers import GLAPosting
    from ..accounting.ledgers import GLA
    from ..accounting.receivables import ReceivablesPosting
    from ..accounting.receivables import Receivables
    from ..organizations.merchants import Merchant

    period = DateRange(datetime.date(2020, 1, 1))


# Generated at 2022-06-24 01:05:52.191983
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    entry: JournalEntry[Entity] = JournalEntry(
        date=datetime.date(2019, 10, 1), description="Test Entry", source=Entity()
    )
    entry.post(date=datetime.date(2019, 10, 1), account=Account("A", AccountType.ASSETS, ""), quantity=100)
    entry.post(date=datetime.date(2019, 10, 1), account=Account("L", AccountType.LIABILITIES, ""), quantity=-100)
    entry.validate()

# Generated at 2022-06-24 01:06:03.779107
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import io

    from unittest import TestCase, TestResult, TextTestRunner
    from unittest.mock import Mock

    from .accounts import Account

    class JournalEntryTest(TestCase):
        "Unit test for method validate of class JournalEntry"
        def test_invalid(self):
            "`validate` with invalid journal entry raises `AssertionError`"
            j = JournalEntry(account=Account(1, "Cash"), date=datetime.date.today(),
                             description="Cash in bank", source=None)
            j.post(date=datetime.date.today(), account=Account(1, "Cash"), quantity=Amount(1000))
            j.post(date=datetime.date.today(), account=Account(2, "Loan", AccountType.LIABILITIES),
                   quantity=Amount(1000))


# Generated at 2022-06-24 01:06:10.494523
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry(datetime.date(2012, 3, 3), "This is a dummy journal entry", None)
    je2 = JournalEntry(datetime.date(2012, 4, 4), 'This is another dummy journal entry', "This is a dummy string")
    assert je.date == datetime.date(2012, 3, 3)
    assert je.description == "This is a dummy journal entry"
    assert je.source is None
    assert je2.description == 'This is another dummy journal entry'
    assert je2.source == "This is a dummy string"


# Generated at 2022-06-24 01:06:14.347310
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # create journal entry object
    journalentry = JournalEntry("2019-10-10", "Entry", "Source")

    # test if constructor works
    assert journalentry.date == "2019-10-10"
    assert journalentry.description == "Entry"
    assert journalentry.source == "Source"

# Generated at 2022-06-24 01:06:22.514552
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from datetime import date
    from typing import Iterable, List
    from .accounts import Account, AccountType

    @dataclass(frozen=True)
    class TestAccount(Account):
        name: str
        type: AccountType
        balance_sheet_category:str = field(default="")

    @dataclass(frozen=True)
    class TestJournalEntry:
        name: str

    def get_journal_entries(period: DateRange) -> Iterable[JournalEntry[TestJournalEntry]]:
        account = TestAccount(name="Pencil", type=AccountType.ASSETS)
        return[JournalEntry(date(2021, 1, 1), "test", TestJournalEntry("test"), [Posting(account, date(2021, 1, 1), account, Direction.INC, 1)])]

    call = ReadJournal

# Generated at 2022-06-24 01:06:33.069929
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from datetime import date
    from ..commons.numbers import Amount

    journal_entry_1 = JournalEntry(date(2020,1,1), "description", 'source')
    journal_entry_2 = JournalEntry(date(2020,1,1), "description", 'source')
    journal_entry_3 = JournalEntry(date(2020,1,1), "description", 'sources')

    journal_entry_1.post(date(2020,1,1), Account('account'), Amount('1.05'))
    journal_entry_2.post(date(2020,1,1), Account('account'), Amount('1.05'))
    journal_entry_3.post(date(2020,1,1), Account('accounts'), Amount('1.05'))


# Generated at 2022-06-24 01:06:44.607496
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    '''
    Test Post method of JournalEntry class
    '''
    # Create a journal entry
    journal_entry = JournalEntry(datetime.date.today(), "", 0)
    journal_entry.guid = makeguid()
    # Post a amount to the account
    journal_entry.post(datetime.date.today(), Account(AccountType.REVENUES, ""), Amount(10))
    assert len(journal_entry.postings) == 1, "Number of postings should be 1"
    # Post a negative value
    journal_entry.post(datetime.date.today(), Account(AccountType.REVENUES, ""), Amount(-10))
    assert len(journal_entry.postings) == 1, "Number of postings should be 1"
    # Post 0 value

# Generated at 2022-06-24 01:06:48.596904
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # ARRANGE #
    class SUT:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass
    sut = SUT()

    # ACT #
    # ASSERT #
    assert issubclass(SUT, ReadJournalEntries)

# Generated at 2022-06-24 01:06:54.094092
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from .accounts import Account

    p1 = Posting(None, datetime.date.today(), Account(), Direction.INC, 100)
    p2 = Posting(None, datetime.date.today(), Account(), Direction.INC, 100)

    assert p1 == p2
    assert hash(p1) == hash(p2)

# Generated at 2022-06-24 01:07:00.563391
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    a1 = Account("Assets:Cash", AccountType.ASSETS)
    j1 = JournalEntry(datetime.date(2020, 1, 1), "Payment", "", [])
    p1 = Posting(j1, datetime.date(2020, 1, 1), a1, Direction.DEC, Amount(1))
    p2 = Posting(j1, datetime.date(2020, 1, 1), a1, Direction.DEC, Amount(1))
    p3 = Posting(j1, datetime.date(2020, 1, 1), Account("Equities:Drawings", AccountType.EQUITIES), Direction.DEC, Amount(1))

    assert p1 == p2
    assert hash(p1) == hash(p2)

    assert p1 != p3
    assert hash(p1) != hash(p3)

# Generated at 2022-06-24 01:07:05.772082
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    ## Arrange ##
    def f(period: DateRange) -> Iterable[JournalEntry]:
        class DummyJournalEntry(JournalEntry):
            date: datetime.date

            def __init__(self, date: datetime.date):
                self.date = date

        return [DummyJournalEntry(p) for p in period]

    ## Act ##

    ## Assert ##
    ReadJournalEntries.__call__.__annotations__ == {"return": Iterable[JournalEntry]}

# Generated at 2022-06-24 01:07:08.185321
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert True


# Generated at 2022-06-24 01:07:15.929308
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..ledger.models import Source

    # Arrange
    source=Source(code='X',name='X',type='payment')
    source.save()
    a=JournalEntry(source=source,date='2020-01-01',description='Test')

    # Act
    a.post(date='2020-01-01',account=Account.objects.get(code='11000'),quantity=1)

    # Assert
    assert a.postings[0].amount == 1, "The amount is not equal"
    assert a.postings[0].is_debit == True, "The journal is not debited"
    assert a.postings[0].is_credit == False, "The journal is not credited"
    assert a.postings[0].direction == Direction.INC, "The journal is not increment"

# Generated at 2022-06-24 01:07:19.379266
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    d = datetime.date.today()
    j = JournalEntry[int](d, '', 0)
    assert j.date == d
    assert j.description == ''
    assert j.source == 0
    assert j.postings == []

# Generated at 2022-06-24 01:07:27.799895
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .accounts import accounts
    from .currencies import currencies

    # Create a new journal entry
    journal_entry = JournalEntry[int](date=datetime.date(2020, 1, 1), description="Test", source=1)
    journal_entry.post(date=datetime.date(2020, 1, 1), account=accounts.Cash[currencies.CAD], quantity=100)

    # Cannot set attribute "journal" to None
    try:
        journal_entry.postings[0].journal = None
    except AssertionError:
        pass
    else:
        assert False, "Expected AssertionError"

# Generated at 2022-06-24 01:07:29.666346
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journal = JournalEntry(datetime.now(), 'Test Journal', 0, [])
    assert isinstance(journal.__hash__(), int)



# Generated at 2022-06-24 01:07:39.994311
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # Define JournalEntries with the same values
    journalentry1: JournalEntry = JournalEntry(datetime.datetime(2019, 4, 4), "Test", None)
    journalentry2: JournalEntry = JournalEntry(datetime.datetime(2019, 4, 4), "Test", None)
    journalentry3: JournalEntry = JournalEntry(datetime.datetime(2019, 4, 4), "Test", None)

    # Define JournalEntry with different values
    journalentry4: JournalEntry = JournalEntry(datetime.datetime(2019, 4, 4), "Test1", None)
    journalentry5: JournalEntry = JournalEntry(datetime.datetime(2019, 4, 3), "Test1", None)
    journalentry6: JournalEntry = JournalEntry(datetime.datetime(2019, 4, 3), "Test", None)

   

# Generated at 2022-06-24 01:07:42.418116
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from accounting import Posting
    posting = Posting()
    try:
        posting.x = 10
        assert False, "Shouldn't be allowed to set attributes after object creation"
    except AttributeError:
        print("AttributeError expected here.")
