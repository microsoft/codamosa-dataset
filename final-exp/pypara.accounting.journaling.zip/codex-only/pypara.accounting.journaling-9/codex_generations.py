

# Generated at 2022-06-24 00:57:42.655563
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry(date=datetime.date(2020, 1, 1), description="test", source=None) == \
        JournalEntry(date=datetime.date(2020, 1, 1), description="test", source=None)

# Generated at 2022-06-24 00:57:44.581669
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class AClass:
        pass
    assert issubclass(AClass, ReadJournalEntries)

# Generated at 2022-06-24 00:57:47.170359
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    je1 = JournalEntry(None, None, None)
    je1.postings = [0,0]

# Generated at 2022-06-24 00:57:51.299744
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    source = None
    date = None
    description = None
    postings = None
    guid = None

    entry = JournalEntry[None](date, description, source, postings)
    entry.postings = postings
    entry.date = date
    entry.description = description
    entry.guid = guid
    entry.source = source

# Generated at 2022-06-24 00:57:55.159858
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class Account:
        pass

    @dataclass
    class Transaction:
        pass

    @dataclass
    class TransactionJournal(ReadJournalEntries[Transaction]):
        pass

if __name__ == '__main__':
    test_ReadJournalEntries()

# Generated at 2022-06-24 00:58:05.797002
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # Purpose - to test that __eq__ method of the class Posting works successfully
    # Input - two objects of type Posting, each with the same data
    # Expected result - True
    journal1 = JournalEntry(date=datetime.date.fromisoformat("2020-01-01"), description="test journal entry 1",
                            source="test source 1", postings=[], guid="12345678")
    journal2 = JournalEntry(date=datetime.date.fromisoformat("2020-01-01"), description="test journal entry 1",
                            source="test source 1", postings=[], guid="12345678")


# Generated at 2022-06-24 00:58:13.759456
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    """
    Creates a JournalEntry object with a parametrised constructor
    """
    _T = 0
    je = JournalEntry(_T)
    assert je.date == None
    assert je.description == None
    assert je.source == 0
    assert je.postings == []

    # using constructor with parameters
    je_source = JournalEntry(dt.date(2019,1,1), "Sample Journal Entry", 10, [])

    assert je_source.date == dt.date(2019,1,1)
    assert je_source.description == "Sample Journal Entry"
    assert je_source.source == 10
    assert je_source.postings == []

    # test for method post

# Generated at 2022-06-24 00:58:14.393103
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass


# Generated at 2022-06-24 00:58:18.890366
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    try:
        posting = Posting(None, datetime.date.today(), None, None, None)
        del posting.journal
        del posting.date
        del posting.account
        del posting.direction
        del posting.amount
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-24 00:58:28.360901
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    joe = Account("Joe")
    joe_debtor = Account("Joe - Debtor", AccountType.LIABILITIES)
    joe_creditor = Account("Joe - Creditor", AccountType.EQUITIES)
    cash = Account("Cash", AccountType.ASSETS)
    total = Account("Total", AccountType.EQUITIES)
    sundry_debtors = Account("Sundry Debtors", AccountType.LIABILITIES)

# Generated at 2022-06-24 00:58:32.089116
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[type]]:
        return []

    rj = read_journal_entries
    rj(DateRange())

    assert isinstance(read_journal_entries, ReadJournalEntries)

test_ReadJournalEntries___call__()

# Generated at 2022-06-24 00:58:39.796416
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal = JournalEntry(datetime.date(2020, 10, 11), "Foo", "Bar", [])
    account = Account("Assets", "Cash", AccountType.ASSETS)
    posting = Posting(journal, datetime.date(2020, 10, 11), account, Direction.INC, Amount(100))

    assert hash(posting) == posting.hash


# Generated at 2022-06-24 00:58:50.075451
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import Account, AccountType

    #: An example journal entry instance.
    entry = JournalEntry(datetime.date(2019, 9, 20), "Foo Bar", None)

    #: An example account instance.
    account = Account(AccountType.ASSETS, "Cash")

    #: An example posting instance.
    posting = Posting(entry, datetime.date(2019, 9, 20), account, Direction.INC, Amount(42))

    assert entry.date == datetime.date(2019, 9, 20)
    assert entry.description == "Foo Bar"
    assert entry.source is None
    assert posting.date == datetime.date(2019, 9, 20)
    assert posting.account == account
    assert posting.journal == entry
    assert posting.direction == Direction.INC

# Generated at 2022-06-24 00:58:53.517873
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import Account, AccountType

    account = Account("a", AccountType.ASSETS)
    je = JournalEntry("d", "d", "s")
    je.post(datetime.datetime.today(), account, 100)
    je.post(datetime.datetime.today(), account, -100)
    hash(je)
    assert True

# Generated at 2022-06-24 00:58:53.967981
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-24 00:58:57.333203
# Unit test for constructor of class JournalEntry
def test_JournalEntry():

    # Create a journal entry
    j = JournalEntry("January 1, 2014", "First entry", "Source 1")

    # Postings
    j.post("January 1, 2014", Asset("Current Asset"), 1000)
    j.post("January 1, 2014", Liability("Current Liability"), -1000)

    assert j.date == "January 1, 2014"
    assert j.description == "First entry"
    assert j.source == "Source 1"
    assert j.postings == 1000
    assert j.postings == -1000
    

# Generated at 2022-06-24 00:59:02.311605
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Code

    @dataclass
    class Test:
        pass

    # Test credit

# Generated at 2022-06-24 00:59:07.550085
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry('2020-03-05','Test',{},[])) == "JournalEntry(date=datetime.date(2020, 3, 5), description='Test', source={}, postings=[])"

# Generated at 2022-06-24 00:59:12.405195
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    try:
        delattr (Posting, "date")
    except AttributeError:
        print("AttributeError")
    else:
        print("No AttributeError")

test_Posting___delattr__()


# Generated at 2022-06-24 00:59:19.264766
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import Account, AccountType, Equity
    from .instruments import Instrument

    # Account definition
    equity = Equity(Equity.SYSTEM, "Equity")

    # Instrument definition
    instrument = Instrument("Share")

    # Journal definition
    journal = JournalEntry
    journal.date = datetime.date(2019, 8, 19)
    journal.description = "This is a Journal"
    journal.source = equity
    journal.postings = [("Equity", 100)]
    journal.validate()

    # Assertion
    assert journal.date == datetime.date(2019, 8, 19)
    assert journal.description == "This is a Journal"
    assert journal.source == equity
    assert journal.postings == [("Equity", 100)]
    assert isinstance(journal, JournalEntry)

    # Account definition

# Generated at 2022-06-24 00:59:26.822248
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # Test for Posting.__eq__ function
    # arrange
    journal = object()
    date = datetime.date(2020, 2, 5)
    account = object()
    direction = object()
    amount = object()
    test_object = Posting(journal, date, account, direction, amount)
    # act
    result = test_object.__eq__(test_object)
    # assert
    assert result is True

# Generated at 2022-06-24 00:59:36.951715
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    class BusinessObject:
        pass

    obj = BusinessObject()
    journal = JournalEntry(datetime.date(2019, 10, 1), "Description 1", obj)
    journal.post(datetime.date(2019, 10, 1), Account("Expenses:Current:Bills"), -100)
    journal.post(datetime.date(2019, 10, 1), Account("Assets:Current:Bank"), +100)
    journal.validate()
    journal = JournalEntry(datetime.date(2019, 10, 1), "Description 2", obj)
    journal.post(datetime.date(2019, 10, 1), Account("Expenses:Current:Bills"), -100)
    try:
        journal.validate()
    except AssertionError:
        pass  # test passed

# Generated at 2022-06-24 00:59:46.054292
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j=JournalEntry(
        date=datetime.datetime(2019, 11, 11),
        description="desc",
        source=0
    )
    j.post(datetime.datetime(2019, 11, 11), Account(1, "a", AccountType.ASSETS), 500)
    j.post(datetime.datetime(2019, 11, 11), Account(2, "a", AccountType.ASSETS), -500)

    j.validate()

    ## validate() should fail.
    j.post(datetime.datetime(2019, 11, 11), Account(3, "a", AccountType.ASSETS), -500)
    assert True

# Generated at 2022-06-24 00:59:48.029443
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass(frozen=True)
    class ReadJournalEntriesSubClass:
        def __call__(self, period):
            pass

    ReadJournalEntriesSubClass()

# Generated at 2022-06-24 00:59:58.455971
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from collections import namedtuple

    Source = namedtuple("Source", ["a", "b", "c", "d"])

    read_journal_entries1: ReadJournalEntries[Source] = lambda period: [
        JournalEntry(date=datetime.date(2020, 1, 1), source=Source("1", None, None, None))
    ]
    assert read_journal_entries1(DateRange.from_dates(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1))) == [
        JournalEntry(date=datetime.date(2020, 1, 1), source=Source("1", None, None, None))
    ]


# Generated at 2022-06-24 01:00:00.856069
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal = JournalEntry()
    journal.post(datetime.date(2001, 1, 1),Account('testing',AccountType.ASSETS),Quantity(1))
    journal.post(datetime.date(2001, 1, 1),Account('testing',AccountType.ASSETS),Quantity(-1))

# Generated at 2022-06-24 01:00:11.090396
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    date = datetime.date(2020, 5, 9)
    description = 'test description'
    source = 1


# Generated at 2022-06-24 01:00:22.501981
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    for i in range(10000):
        assert hash(JournalEntry[str](datetime.date.today(), "Description", "Biz-Obj", [Posting(None, None, None, None, Amount(0))])) == hash(JournalEntry[str](datetime.date.today(), "Description", "Biz-Obj", [Posting(None, None, None, None, Amount(0))]))
    assert hash(JournalEntry[str](datetime.date.today(), "Description", "Biz-Obj", [Posting(None, None, None, None, Amount(1))])) != hash(JournalEntry[str](datetime.date.today(), "Description", "Biz-Obj", [Posting(None, None, None, None, Amount(2))]))

# Generated at 2022-06-24 01:00:28.575261
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date
    from bigcaptial.books.accounting.accounts import ChartOfAccounts
    coa = ChartOfAccounts()
    cash = coa.get(101)
    interest_expense = coa.get(199)
    journal_entry = JournalEntry(date(2020, 5, 9), 'deposit $100 deposit', "")
    journal_entry.post(date(2020, 5, 9), cash, 100)
    journal_entry.post(date(2020, 5, 9), interest_expense, 10)
    journal_entry.validate()

# Generated at 2022-06-24 01:00:32.609699
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # Type cannot be declared since it's a Protocol type
    #
    # Type:
    #   Type of business object.
    #
    def _(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    result = _
    assert isinstance(result, ReadJournalEntries)

# Generated at 2022-06-24 01:00:43.217367
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup:
    from .accounts import Account, AccountType
    from .business import Stock
    from .accounts import StockAccount
    from .commons.numbers import Amount, Quantity

    journal_entry = JournalEntry[Stock]()
    stock_1 = Stock("Stock-1", "Stock-1")
    stock_account_1 = StockAccount("Account-1", "Account-1", stock_1)
    date = datetime.date.today()

    # Exercise:
    journal_entry = journal_entry.post(date, stock_account_1, Quantity(100))
    journal_entry = journal_entry.post(date, stock_account_1, Quantity(100))

    # Test:

# Generated at 2022-06-24 01:00:51.593141
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    a = Posting(None, datetime.date(2019, 1, 1), Account(1, "A"), Direction.INC, Amount(1))
    b = Posting(None, datetime.date(2019, 1, 1), Account(1, "A"), Direction.INC, Amount(1))
    c = Posting(None, datetime.date(2019, 1, 1), Account(1, "A"), Direction.INC, Amount(1))
    assert (a == b) and (b == a)
    assert (a == c) and (c == a)
    assert (b == c) and (c == b)


# Generated at 2022-06-24 01:00:58.917954
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from ..commons.others import makeamount
    from .accounts import Account, AccountType

    def makejournalentry(description: str, source: str) -> JournalEntry[str]:
        return JournalEntry(date=datetime.date.today(), description=description, source=source)

    def makeposting(journal: JournalEntry[str], date: datetime.date, account: Account, direction: Direction, amount: Amount) -> Posting[str]:
        return Posting(journal, date, account, direction, amount)

    #
    # Setup
    #

    bank_account = Account(name="BANK", type=AccountType.ASSETS)
    cash_account = Account(name="CASH", type=AccountType.ASSETS)

# Generated at 2022-06-24 01:01:09.014308
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    a1 = Account(type=AccountType.ASSETS, name='Cash')
    a2 = Account(type=AccountType.REVENUES, name='Revenues')
    je1 = JournalEntry(date=datetime.date(2020,12,30), description="Earned consulting income.", source="Consulting")
    je1.post(date=datetime.date(2020,12,30), account=a1, quantity=Quantity(100))
    je1.post(date=datetime.date(2020,12,30), account=a2, quantity=Quantity(-100))
    je1.validate()

# Generated at 2022-06-24 01:01:15.049312
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():

    from .accounts import Account, AccountType
    from .journal import Posting

    assert Posting(1, 'As of', Account('Assets', AccountType.ASSETS), -1, 1).__repr__() == "Posting(journal=1, date=1, account=Account(name='Assets', type=<AccountType.ASSETS: 2>), direction=-1, amount=1)"



# Generated at 2022-06-24 01:01:23.686643
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from datetime import date
    from .accounts import Account
    from .accounttypes import AccountType

    je = JournalEntry(date.today(), "Description", 'source')
    je.post(date.today(), Account('account', 'accountname', AccountType.ASSETS), 5000)
    je.post(date.today(), Account('account2', 'accountname2', AccountType.EQUITIES), -5000)
    print(je.date)
    print(je.description)
    print(je.source)
    print(je.postings)
    print(je.guid)

# Generated at 2022-06-24 01:01:27.966698
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    """
    Test that user can delete existing attribute of journal entry object
    """
    je = JournalEntry()
    delattr(je, 'date')
    assert 'date' not in vars(je)


# Generated at 2022-06-24 01:01:35.009497
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import DateRange

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        yield JournalEntry(_T, datetime.date.today(), "Entry1", _T)
        yield JournalEntry(_T, datetime.date.today(), "Entry2", _T)
        yield JournalEntry(_T, datetime.date.today(), "Entry3", _T)

    assert len(list(ReadJournalEntries.__call__(read_journal_entries, DateRange(datetime.date.today())))) == 3

# Generated at 2022-06-24 01:01:44.208668
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    debit1 = Posting(None, datetime.date(2020, 5, 6), Account("Non-Operating Income", AccountType.EQUITIES),
                     Direction.DEC, Amount(100.0))
    debit2 = Posting(None, datetime.date(2020, 5, 6), Account("Non-Operating Income", AccountType.EQUITIES),
                     Direction.DEC, Amount(100.0))
    debit3 = Posting(None, datetime.date(2020, 5, 6), Account("Non-Operating Income", AccountType.EQUITIES),
                     Direction.INC, Amount(100.0))
    debit4 = Posting(None, datetime.date(2020, 5, 7), Account("Non-Operating Income", AccountType.EQUITIES),
                     Direction.DEC, Amount(100.0))

# Generated at 2022-06-24 01:01:54.130835
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import Account
    from .documents import Invoice
    from .services import Service
    from .products import Product
    from .parties import Party

    #: Customer (party)
    customer = Party("John Smith")

    #: Supplier (party)
    supplier = Party("Acme")

    #: Product (inventory)
    product = Product("ACME-001", "Laptop S1", "{}/delivery".format(supplier.name), 40)

    #: Service (service)
    service = Service("ACME-001", "Maintenance of Laptop S1", "{}/support".format(supplier.name), 10)

    #: Inventory account of customer.
    inventory = Account("Inventory", AccountType.ASSETS)

    #: Purchase account of customer.

# Generated at 2022-06-24 01:02:00.669709
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class T:
        pass

    class Unit:
        def test_empty(self):
            rje = ReadJournalEntries()
            assert list(rje(DateRange(date(2019,1,1), date(2019,1,1)))) == []

        def test_single_journal_entry(self):
            j1 = JournalEntry(date(2019,1,1), "J1", T())
            rje = lambda period: [j1]
            assert list(rje(DateRange(date(2019,1,1), date(2019,1,1)))) == [j1]

        def test_two_journal_entries(self):
            j1 = JournalEntry(date(2019,1,1), "J1", T())

# Generated at 2022-06-24 01:02:03.862301
# Unit test for constructor of class Posting
def test_Posting():
    d = datetime.date(2020, 1, 1)
    p = Posting(None, d, Account('', AccountType.ASSETS), Direction.DEC, Amount(10))
    assert p.date == d
    assert p.is_debit == False
    assert p.is_credit == True


# Generated at 2022-06-24 01:02:05.485894
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass


# Generated at 2022-06-24 01:02:11.178920
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Tests that attempting to set an attribute to a JournalEntry instance
    raises an AttributeError
    """
    # Setup
    x = JournalEntry[None](datetime.date.today(), "", None)
    d = datetime.date(1,1,1)
    
    # Exercise
    try:
        x.date = d
    except AttributeError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:02:14.555317
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass

# Generated at 2022-06-24 01:02:24.766021
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from datetime import date
    from .accounts import Account, AccountType
    from .books import SimpleBook
    from .commons.numbers import Amount, Quantity

    # Create a new simple book:
    book: SimpleBook = SimpleBook()

    # Create two accounts:
    account_general = book.account(AccountType.EQUITIES, "General")
    account_cash = book.account(AccountType.ASSETS, "Cash")
    account_bank = book.account(AccountType.ASSETS, "Bank")

    # Create a new journal entry:
    journal = JournalEntry[SimpleBook](date.today(), "Income")

    # Post some values to the accounts:
    result = journal.post(date.today(), account_general, Quantity(10))
    result = result.post(date.today(), account_cash, Quantity(20))

# Generated at 2022-06-24 01:02:37.291420
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from ...books import Book
    from ...books.accounts import AccountType
    from ...books.pl import PL
    from ...books.sales_book import SalesBook
    from ...commons.context import Context

    with Context(dt=datetime.date(2019, 1, 1)):
        pl, sales_book = PL(Book), SalesBook(Book)
        invoice = sales_book.issue_invoice(amount=500, customer="Customer")
        journal_entry = SalesBook.journal_entry()
        journal_entry.post(date=invoice.date, account=pl.accounts.get(name="Account Receivable"), quantity=invoice.amount)

# Generated at 2022-06-24 01:02:38.213895
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    a=JournalEntry
    delattr(a,'trash')


# Generated at 2022-06-24 01:02:45.958904
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    entry = JournalEntry[int](date=datetime.date(2020, 1, 1), description='description', source=10)
    entry = entry.post(date=datetime.date(2020, 1, 1), account=Account(code='1', type=AccountType.ASSETS), quantity=1)
    entry = entry.post(date=datetime.date(2020, 1, 1), account=Account(code='2', type=AccountType.REVENUES), quantity=-1)
    entries = set()
    entries.add(entry)
    entries.add(entry)
    assert len(entries) == 1

# Generated at 2022-06-24 01:02:55.334011
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    j = JournalEntry(date = datetime.date.today(), description="posting", source = "whatever")
    p1 = Posting(journal = j, date = j.date, account = Account(code = 101, name = "Assets", type = AccountType.ASSETS), direction = Direction.INC, amount = Amount(decimal = 1000))
    p2 = Posting(journal = j, date = j.date, account = Account(code = 101, name = "Assets", type = AccountType.ASSETS), direction = Direction.INC, amount = Amount(decimal = 1000))
    p3 = Posting(journal = j, date = j.date, account = Account(code = 101, name = "Assets", type = AccountType.ASSETS), direction = Direction.INC, amount = Amount(decimal = 500))

# Generated at 2022-06-24 01:02:57.999610
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    @dataclass(frozen=True)
    class Foo:
        pass

    foo = Foo()

    journal = JournalEntry[Foo](source=foo)

    with pytest.raises(AttributeError):
        journal.source = 'bar'

# Generated at 2022-06-24 01:03:09.343148
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from ..commons.numbers import Amount, Quantity

    from .accounts import Account, AssetType, LiabilityType, EquityType, RevenuesType, ExpensesType, AccountType

    from .ledgers import Ledger

    from .accounts import Account, AssetType, LiabilityType, EquityType, RevenuesType, ExpensesType, AccountType



    journal = JournalEntry()
    journal.date = datetime.date(2008, 3, 15)
    journal.description = ""

    journal.post(datetime.date(2008, 3, 15), Account("assets:cash", "Cash", AssetType), Quantity(1000))
    journal.post(datetime.date(2008, 3, 15), Account("equities:equity", "Equity", EquityType), Quantity(1000))
    journal.validate()

    entry_date = datetime.date

# Generated at 2022-06-24 01:03:16.593824
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    import datetime, typing
    from decimal import Decimal
    from ..accounts import Account, Balance, AccountType

    # Set up
    date: datetime.date = datetime.date.today()
    total_amount: Decimal = Decimal('30')
    total_quantity: Decimal = Decimal('30')
    cash: Account = Account.new('Cash', AccountType.ASSETS)
    balance: Balance = Balance.of(date, cash, Decimal('0'), Decimal('0'), Decimal('0'), Decimal('0'))
    postings: typing.List[JournalEntry] = []
    postings.append(JournalEntry(date, 'Test description', balance, postings))
    postings[0].post(date, cash, total_quantity)

# Generated at 2022-06-24 01:03:21.926077
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    je1 = JournalEntry(date=datetime.date(2000, 1, 1), description="desc1", source=None)
    p1 = Posting(journal=je1, date=datetime.date(2000, 1, 1), account=Account(id=1), direction=Direction.INC, amount=Amount(currency="CAD", value=1))
    p2 = Posting(journal=je1, date=datetime.date(2000, 1, 1), account=Account(id=1), direction=Direction.INC, amount=Amount(currency="CAD", value=1))
    assert p1 == p2, "__eq__ is not implemented correctly. It should return True for two equal Posting instances."


# Generated at 2022-06-24 01:03:22.770284
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert(True)

# Generated at 2022-06-24 01:03:31.919727
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import accounts
    from .periods import Year

    def tax_journal_entry(date: datetime.date, tax_rate: float):
        return JournalEntry(date, f"Tax of {int(tax_rate * 100)}%", Year(date.year)) \
            .post(date, accounts.payables.tax, 1) \
            .post(date, accounts.revenues.tax, tax_rate) \
            .post(date, accounts.expenses.tax, tax_rate)

    # test_validate_debits_credits_equal
    # Scenario: Validate a journal entry when total debits and credits are equal.
    tax_journal_entry(datetime.date.today(), 0.5).validate()

    # test_validate_debits_credits_not_equal
    #

# Generated at 2022-06-24 01:03:41.736494
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from .accounts import Account, AccountType
    from .businesses import Business
    from .currencies import Currency

    # Test Setup:
    b = Business(name="Hiraeth Inc.", currency=Currency.USD)
    a = Account(name="Account A", type=AccountType.REVENUES)
    j = JournalEntry.create(datetime.date.today(), "Journal of Hiraeth Inc.", b)

    # Execute:
    # AssertionError: Cannot modify an immutable instance.
    try:
        j.postings.append(Posting(j, datetime.date.today(), a, +1, Amount(20)))
    except AssertionError:
        pass
    else:
        raise


# Generated at 2022-06-24 01:03:46.533734
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry
    fecha = datetime.date(2019, 1, 5)
    account = Account
    direction = Direction
    amount = Amount
    posting = Posting[journal](journal, fecha, account, direction, amount)
    assert posting.__repr__() == "Posting(journal=<class '__main__.JournalEntry'>, date=datetime.date(2019, 1, 5), account=<class '__main__.Account'>, direction=<Direction.INC: 1>, amount=0)"


# Generated at 2022-06-24 01:03:50.490380
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Setup
    journal_entry = JournalEntry(date=datetime.date(2019, 1, 1), description='',source='')
    # Exercise
    repr(journal_entry)
    repr(journal_entry.postings)

# Generated at 2022-06-24 01:04:01.625442
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """
    Checks the ``__setattr__`` method of the `Posting` class.

    This method is used to prevent mutation of fields in `Posting` instances.
    """
    account = Account("A", AccountType.ASSETS)
    journal = JournalEntry(datetime.date(2019, 1, 1), "J")
    posting = Posting(journal, datetime.date(2019, 1, 1), account, Direction.INC, Amount(100))

    # Attempting to change the attribute `journal` using the dictionary interface of an instance.
    with pytest.raises(AttributeError):
        posting.__dict__["journal"] = journal

    # Attempting to change the attribute `journal` using the set attr method of an instance.
    with pytest.raises(AttributeError):
        posting.__setattr__("journal", journal)



# Generated at 2022-06-24 01:04:11.407601
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import Account
    from .commons.others import today

    #eq
    account1 = "Account1"
    account2 = "Account2"
    account3 = "Account3"
    account4 = "Account4"

    account_type1 = AccountType.ASSETS
    journal_entry1 = JournalEntry(date=today(), description="Journal Entry 1 ")
    journal_entry2 = JournalEntry(date=today(), description="Journal Entry 2 ")
    amount1 = 12
    amount2 = 3
    direction1 = Direction.INC
    direction2 = Direction.DEC

    p1 = Posting(journal=journal_entry1, date=today(), account=Account(name=account1, type=account_type1),
                 direction=direction1, amount=amount1)

# Generated at 2022-06-24 01:04:18.635445
# Unit test for constructor of class Posting
def test_Posting():
    # Given
    journal = JournalEntry()
    journal.post(datetime.date(2019, 3, 14), Account('ASSETS', 'BANK'), Quantity(42))
    posting = Posting(journal, datetime.date(2019, 3, 14), Account('ASSETS', 'BANK'), Direction.INC, Amount(42))
    # Then
    assert posting.journal == journal
    assert posting.date == datetime.date(2019, 3, 14)
    assert posting.account == Account('ASSETS', 'BANK')
    assert posting.direction == Direction.INC
    assert posting.amount == Amount(42)



# Generated at 2022-06-24 01:04:22.383025
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry(datetime.date(2020, 3, 24), "Test", None)
    je.postings.append(Posting(je, datetime.date(2020, 3, 24), Account("Cash", AccountType.ASSETS), Direction.INC, Amount(100)))
    je.postings.append(Posting(je, datetime.date(2020, 3, 24), Account("Bank", AccountType.ASSETS), Direction.INC, Amount(100)))
    je.validate()

# Generated at 2022-06-24 01:04:26.987591
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    class TestSource:
        pass

    journal = JournalEntry[TestSource](
        date = datetime.date(2020, 1, 1),
        description = 'Test journal entry',
        source = TestSource()
    )

    class TestAccount(Account):
        pass

    journal.post(
        datetime.date(2020, 1, 1),
        account = TestAccount(
            name = 'Test Account',
            type = AccountType.ASSETS
        ),
        quantity = -500
    )

    assert journal.postings[0].amount == Amount(500)
    assert journal.postings[0].is_debit
    assert not journal.postings[0].is_credit

# Generated at 2022-06-24 01:04:31.362505
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry(datetime.date(2020, 4, 15), "Test", None)
    account1 = Account("20", "Income", AccountType.EXPENSES)
    account2 = Account("20", "Income", AccountType.EXPENSES)
    posting1 = Posting(journal, datetime.date(2020, 4, 15), account1, Direction.DEC, Amount(0))
    posting2 = Posting(journal, datetime.date(2020, 4, 15), account2, Direction.DEC, Amount(0))
    object_id = id(posting1)
    object_id2 = id(posting2)
    journal_id = id(journal)
    account_id = id(account1)

# Generated at 2022-06-24 01:04:36.990488
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import dataclass, field

    @dataclass(frozen=True)
    class A:
        a: int = 0

        def __setattr__(self, name, value):
            if name == 'a':
                self.__dict__[name] = value + 1
            else:
                self.__dict__[name] = value

    a = A(1)
    assert a.a == 2

# Generated at 2022-06-24 01:04:44.586892
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    try:
        je = JournalEntry(date=datetime.datetime.now(), description="hello")
        je.postings.append(Posting(journal=je, date=datetime.datetime.now(), account=None, direction=None, amount=None))
        je.date = None
        je.description = "world"
        je.postings.append(Posting(journal=je, date=datetime.datetime.now(), account=None, direction=None, amount=None))
        je.postings[0].guid = None # guard
    except Exception as e:
        assert False, f"JournalEntry.__setattr__ threw {e}"

# Generated at 2022-06-24 01:04:52.715424
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from ..db.postgres.models import Order
    from ..ledgers.controllers import journal_entry_factory

    # setup
    o: Order = Order.factory(id=1, amount=10.00, product='test')

    # Arrange
    j1: JournalEntry[Order] = journal_entry_factory(o)
    j1.post(o.date, Account(code='1000', name='Cash'), o.amount).post(o.date, Account(code='2000', name='Sales'), o.amount)
    j1.validate()

    # Assert
    assert 'journal' in j1.postings[0].__dict__, 'The Posting object should contain the journal'
    assert 'journal' in j1.postings[1].__dict__, 'The Posting object should contain the journal'

   

# Generated at 2022-06-24 01:04:58.144813
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from ..clock import TestDate
    from .accounts import Asset, Expense, Equity, Liability, Revenue
    from .companies import Company

    # Setup test:
    company = Company("Sample Textile Company")
    ae = company.accounting

    with TestDate(datetime.date(2019, 9, 19)):
        # Create journal entry:
        je1 = ae.journal().entry("Entry 1", EntrySource())
        je1.post(ae.accounts.BANK_CHEQUING, +10)
        je1.post(ae.accounts.BANK_SAVINGS, +20)
        je1.post(ae.accounts.CASH, +30)
        je1.post(ae.accounts.EQUITY_COMMON_STOCK, -40)

# Generated at 2022-06-24 01:04:59.525950
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting(None, datetime.date(2020, 1, 1), None, None, Amount(0))) == "Posting(date=datetime.date(2020, 1, 1), account=None, direction=INC, amount=0)"

# Generated at 2022-06-24 01:05:03.567538
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    #  function which read journal entries from a source.
    def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    pass


# Generated at 2022-06-24 01:05:13.670586
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    unit test for the method validate of class JournalEntry
    """
    ## create a journal entry
    journal = JournalEntry(datetime.date.today(), 'test', 'test')
    ## create a valid journal entry
    journal.post(datetime.date.today(), Account.create('test', 'test', AccountType.ASSETS), 100)
    journal.post(datetime.date.today(), Account.create('test', 'test', AccountType.REVENUES), -100)
    journal.validate()
    ## try with an invalid journal entry should raise an error
    journal.post(datetime.date.today(), Account.create('test', 'test', AccountType.ASSETS), 100)
    journal.post(datetime.date.today(), Account.create('test', 'test', AccountType.REVENUES), -101)
    failed

# Generated at 2022-06-24 01:05:23.514169
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from .accounts import Accounts
    from .account_types import AccountTypes
    from .currencies import EUR

    from .business_objects import BusinessObject, BusinessObjectTypes, BusinessObjects
    from .business_object_types import BusinessObjectTypes
    from .business_objects import BusinessObjects
    from .currency_exchanges import CurrencyExchanges, DateBasedRateSource, Rate

    from .categories import Categories, CategoryTypes
    from .category_types import CategoryTypes


# Generated at 2022-06-24 01:05:30.866217
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    a = Posting((JournalEntry('2019', 'test1', None, None), datetime.date(2019, 3, 31), Account(1, 1, 'Account1', AccountType.ASSETS), Direction.DEC, Amount(10)))
    b = Posting((JournalEntry('2019', 'test1', None, None), datetime.date(2019, 3, 31), Account(1, 1, 'Account1', AccountType.ASSETS), Direction.DEC, Amount(10)))
    c = Posting((JournalEntry('2019', 'test1', None, None), datetime.date(2019, 3, 31), Account(1, 1, 'Account2', AccountType.ASSETS), Direction.DEC, Amount(10)))

# Generated at 2022-06-24 01:05:33.215135
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass



# Generated at 2022-06-24 01:05:38.307050
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .amounts import Amount

    test_journal = JournalEntry[str]("2020-04-01", "This is a test journal entry", "")
    test_journal.post(test_journal.date, Account("Cash", AccountType.ASSETS), Amount(100))
    test_journal.post(test_journal.date, Account("Test Expense", AccountType.EXPENSES), Amount(100))
    test_journal.validate()

# Generated at 2022-06-24 01:05:43.686647
# Unit test for constructor of class Posting
def test_Posting():
    #Dummy entries for testing
    debitEntry = Posting(JournalEntry, "12-11-2019", Account("Expenses","expenses", AccountType.EXPENSES), Direction.DEC, Amount("100"))
    creditEntry = Posting(JournalEntry, "12-11-2019", Account("Revenue","revenue", AccountType.REVENUES), Direction.INC, Amount("100"))
    assert debitEntry.is_debit == True
    assert debitEntry.is_credit == False
    assert creditEntry.is_debit == False
    assert creditEntry.is_credit == True


# Generated at 2022-06-24 01:05:55.576760
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    #Arrange
    import datetime
    from .accounts import Account, AccountType
    from .currencies import Currency, CurrencyType
    #Act
    journal_entry = JournalEntry(datetime.date(2020,5,5), "This is just a test entry", 1)
    account = Account("Assets:Cash", AccountType.ASSETS, Currency(CurrencyType.USD, 1, "United States Dollar"))
    journal_entry.post(datetime.date(2020, 5, 5), account, 100)
    #Assert
    assert journal_entry.date == datetime.date(2020, 5, 5)
    assert journal_entry.description == "This is just a test entry"
    assert journal_entry.postings[0].account.name == "Assets:Cash"
    assert journal_entry.postings[0].amount.value

# Generated at 2022-06-24 01:06:02.177438
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    @dataclass
    class _A():
        pass

    try:
        p = Posting(_A(), datetime.date.today(), Account("Assets:Cash"), Direction.INC, Amount(10))
        p.postings.append(p)
    except AttributeError:
        print("Attribute Error caught")
    else:
        assert False, "Posting attribute is not immutable"

# Generated at 2022-06-24 01:06:04.205023
# Unit test for constructor of class Posting
def test_Posting():
    p = Posting('journal', 'date', 'account', 'direction', 'amount')
    assert p == p, "equal"

# Generated at 2022-06-24 01:06:07.881689
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    a = []
    x = Posting(a, datetime.date.today(), Account(AccountType.ASSETS, 'Cash'), Direction.INC, Amount(10))
    del x.journal


# Generated at 2022-06-24 01:06:11.846646
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class A(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return []

    assert A()(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 2))) == []

# Generated at 2022-06-24 01:06:14.850036
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def _ReadingJournalEntries(period: DateRange) -> Iterable[JournalEntry[_T]]: yield

    _ReadingJournalEntries(period=DateRange(datetime.date.today(), datetime.date.today()))

# Generated at 2022-06-24 01:06:18.611487
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journal_entry = JournalEntry("2019-10-27", "My Journal Entry", None)
    posting = Posting("2019-10-27", journal_entry, "Assets:Cash", "INC", 100)
    try:
        posting.journal = "Another journal entry"
    except Exception:
        pass
    finally:
        assert posting.journal == journal_entry


# Generated at 2022-06-24 01:06:27.233048
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    posting1 = Posting(journal=None, date=None, account=None, direction=None, amount=None)
    posting1_copy = Posting(journal=None, date=None, account=None, direction=None, amount=None)
    posting2 = Posting(journal=None, date=datetime.datetime(2010, 1, 1).date(), account=None, direction=None,
                       amount=Amount(1.0))
    posting3 = Posting(journal=None, date=None, account=Account("", "", AccountType.REVENUES), direction=None,
                       amount=None)
    posting4 = Posting(journal=None, date=None, account=None, direction=Direction.INC, amount=None)

# Generated at 2022-06-24 01:06:32.089651
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    """
    Test whether method 'Posting.__delattr__' can be called.
    """
    posting = Posting(object, datetime.date.today(), Account("Testing"),Direction.INC, Amount(123))
    try:
        posting.__delattr__("journal")
    except:
        pass


# Generated at 2022-06-24 01:06:40.447718
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # Given
    p: Posting = Posting(
        JournalEntry(
            datetime.date(year=2018, month=1, day=1),
            "Test",
            None,
            [],
        ),
        datetime.date(year=2018, month=1, day=1),
        Account(Guid("Account"), "Testing", AccountType.EXPENSES, None),
        Direction.DEC,
        Amount(10),
    )
    # When
    r = repr(p)
    # Then

# Generated at 2022-06-24 01:06:42.944500
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert JournalEntry.__init__.__annotations__.keys() == {'self', 'date', 'description', 'source'}

# Generated at 2022-06-24 01:06:47.180484
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    date = datetime.date.today()
    description = 'Travel Expense'
    source = 'Travel Expense'
    postings = []
    journal = JournalEntry[str](date, description, source, postings)
    assert isinstance(journal, JournalEntry)
    assert isinstance(journal.__dict__, dict)
    assert journal.date == date

# Generated at 2022-06-24 01:06:53.117455
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    je = JournalEntry[None](datetime.date.fromisoformat('2014-05-01'), 'A journal entry', 0)
    assert repr(je) == "JournalEntry(date=datetime.date(2014, 5, 1), description='A journal entry', source=0, " \
                       "postings=[], guid=00000000-0000-0000-0000-000000000000)"

# Generated at 2022-06-24 01:07:00.531698
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..books.coa import make_chart_of_accounts
    from ..books.ledger import make_ledger
    from ..books.book import Book

    coa = make_chart_of_accounts("Global Corporation")
    ledger = make_ledger("Global Corporation")
    book = Book(coa, ledger)

    def _get(account_name: str):
        return coa.of(account_name)

    jentry = JournalEntry[object]("2019-01-01", "Initializing book")

    jentry.post("2019-01-01", _get("Assets:Sweets Counter"), 1000)
    jentry.post("2019-01-01", _get("Equities:Capital"), -1000)
    jentry.validate()


# Generated at 2022-06-24 01:07:08.453572
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..test_commons.builders import account, journal
    from .accounts import AccountType

    account_a = Account(AccountType.REVENUES, "abc", "bcd")
    account_b = Account(AccountType.EXPENSES, "abc", "bcd")
    entry = journal.JournalEntry(datetime.date(year=2020, month=1, day=1), "description", "source")

    entry.post(datetime.date(year=2020, month=1, day=1), account_a, 100)
    assert len(entry.postings) == 1
    assert entry.postings[0].is_debit == False

    entry.post(datetime.date(year=2020, month=1, day=1), account_b, 100)
    assert len(entry.postings) == 2

# Generated at 2022-06-24 01:07:13.195994
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date

    source = "random source"
    date_ = date(2020,1,1)
    account = Account("Account", AccountType.EQUITIES)
    amount = 1
    direction = Direction.INC

    posting = Posting(source, date_, account, direction, amount)

    with pytest.raises(dataclasses.FrozenInstanceError):
        posting.account = account


# Generated at 2022-06-24 01:07:19.430457
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry[int](None, '', 0)
    p = Posting(journal, datetime.date(2020, 1, 1), Account(0, '', 0, ''), Direction.INC, Amount(10))
    assert repr(p) == 'Posting(journal=JournalEntry(None, , 0), date=datetime.date(2020, 1, 1), account=Account(0, , 0, ), direction=Direction.INC, amount=Amount(10))'


# Generated at 2022-06-24 01:07:23.820836
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal = JournalEntry("name1", "description1", "source1", "postings1", "guid1")
    assert repr(journal) == "JournalEntry(date='name1', description='description1', source='source1', postings='postings1', guid='guid1', )"

# Generated at 2022-06-24 01:07:28.581022
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    account = Account(Guid('001'), '2', 'Cash', None, AccountType.ASSETS)
    account_2 = Account(Guid('002'), '3', 'Cash', None, AccountType.ASSETS)
    entry_1 = JournalEntry(datetime.date(2020, 1, 1), '', '')
    entry_2 = JournalEntry(datetime.date(2020, 1, 1), '', '')
    assert entry_1 == entry_2
    entry_2.post(datetime.date(2020, 1, 1), account, Quantity(1))
    assert entry_1 != entry_2
    entry_1.post(datetime.date(2020, 1, 1), account, Quantity(1))
    assert entry_1 == entry_2

# Generated at 2022-06-24 01:07:30.580100
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def read_journal_entries(period):
        print(period)
    assert hasattr(read_journal_entries, '__call__')

# Generated at 2022-06-24 01:07:37.383714
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    date = datetime.date(2019, 1, 1)
    description = "DUMMY"
    postings = [
        Posting(None, date, Account.NP, Direction.INC, Amount(100)),
        Posting(None, date, Account.A, Direction.INC, Amount(100)),
    ]
    source = "DUMMY"
    guid = makeguid()
    journal = JournalEntry(date, description, source)
    assert journal.date == date
    assert journal.description == description
    assert journal.postings == []
    assert journal.source == source
    assert journal.guid != guid
    journal.date = date
    journal.description = description
    journal.postings = postings
    journal.source = source
    journal.guid = guid
    assert journal.date == date
    assert journal.description == description


# Generated at 2022-06-24 01:07:41.371988
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert Posting(JournalEntry, 'date', 'account', 'direction', 'amount')
