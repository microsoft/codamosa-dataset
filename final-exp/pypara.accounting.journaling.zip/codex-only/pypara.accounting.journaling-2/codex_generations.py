

# Generated at 2022-06-24 00:57:50.041649
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from collections import OrderedDict

# Generated at 2022-06-24 00:57:50.623328
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    pass

# Generated at 2022-06-24 00:57:56.111929
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Setup
    journalEntry = JournalEntry(1, 'a', 1)
    expected = "JournalEntry(date=1, description='a', source=1, postings=[], guid=6d5d631d-611c-47f5-b037-bfd78b7e5e65)"

    # Exercise
    actual = repr(journalEntry)

    # Verify
    assert expected == actual

    # Cleanup - none

# Generated at 2022-06-24 00:57:59.180750
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # arrange
    post1 = Posting(None, datetime.date(2018, 1, 1), Account('test'), Direction.INC, Amount(1))
    post2 = Posting(None, datetime.date(2019, 1, 1), Account('test'), Direction.INC, Amount(1))

    # assert
    assert hash(post1) != hash(post2)

# Generated at 2022-06-24 00:57:59.574338
# Unit test for constructor of class Posting
def test_Posting():
    assert 1==1

# Generated at 2022-06-24 00:58:09.988730
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journal_entry_A = JournalEntry(
                                 date=datetime.date(2020, 5, 2),
                                 description="a",
                                 source=None,
                                 postings=[
                                     Posting(None, datetime.date(2020, 1, 5), Account("Assets", AccountType.ASSETS), Direction.INC, 1000),
                                     Posting(None, datetime.date(2020, 1, 5), Account("Liabilities", AccountType.LIABILITIES), Direction.DEC, 1000)
                                 ],
                                 guid=makeguid()
                             )

# Generated at 2022-06-24 00:58:18.581182
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..banks.banks import BankAccount
    from ..banks.banks import TransactionRequest
    from ..banks.banks import TransactionRequestType
    from ..budgets.budgets import Budget
    from ..budgets.budgets import BudgetLine
    from ..budgets.budgets import BudgetLineStatus
    from ..budgets.budgets import BudgetLineType
    from ..budgets.budgets import BudgetStatus
    from ..budgets.budgets import BudgetType
    from ..events.events import Event
    from ..events.events import Invoice
    from ..events.events import InvoiceStatus
    from ..events.events import InvoiceType
    from ..events.events import Payment
    from ..events.events import PaymentStatus
    from ..events.events import PaymentType
    from ..events.events import Receipt

# Generated at 2022-06-24 00:58:28.316900
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    p = Posting(None, date(1,1,1), None, None, None)
    try:
        p.date = date(1,1,1)
        raise AssertionError("Assignments to Posting.date did not raise an AttributeError")
    except AttributeError:
        pass
    try:
        p.account = None
        raise AssertionError("Assignments to Posting.account did not raise an AttributeError")
    except AttributeError:
        pass
    try:
        p.direction = None
        raise AssertionError("Assignments to Posting.direction did not raise an AttributeError")
    except AttributeError:
        pass

# Generated at 2022-06-24 00:58:34.456957
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    a = Posting(None, datetime.date.today(), None, None, None)
    b = Posting(None, datetime.date.today(), None, None, None)
    c = Posting(None, datetime.date.today() + datetime.timedelta(days=1), None, None, None)
    assert a == b, "__eq__ failed"
    assert a != c, "__eq__ failed"


# Generated at 2022-06-24 00:58:45.388770
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from .accounts import Account
    from .books import Book
    from .ledgers import Ledger
    from .transactions import Transaction
    from datetime import date
    from dolang.syntax import parse_expr
    from dolang.syntax import SyntaxError
    from dolang.validator import validate_expr
    from dolang.transpiler import Parameter, Expr, Transpiler

    # These files should fail
    fail_files = [
        "test/test_dolang_files/fail_tests/fail_invalid_account.dol",
        "test/test_dolang_files/fail_tests/fail_invalid_period.dol",
        "test/test_dolang_files/fail_tests/fail_invalid_transaction.dol",
    ]

    #

# Generated at 2022-06-24 00:58:48.762461
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from datetime import date
    j1 = JournalEntry[int](date.today(), '', 1)
    j2 = JournalEntry[int](date.today(), '', 1)
    assert j1 == j2
    assert hash(j1) == hash(j2)


__all__ = sorted(__all__)

# Generated at 2022-06-24 00:58:57.447484
# Unit test for constructor of class Posting
def test_Posting():
    from ..commons.zeitgeist import now
    from .accounts import Account, AccountType
    from .types import JournalEntry, Posting, ReadJournalEntries
    from .ledgers.source import ReadLedgerSource
    from .ledgers.mem import MemoryLedgerSource
    from .entries.source import ReadJournalEntrySource
    from .entries.mem import MemoryJournalEntrySource
    from .books.source import ReadAccountingBookSource
    from .books.mem import MemoryAccountingBookSource
    from .books import AccountingBook, Book

    def load_default_books(book_source: ReadAccountingBookSource) -> None:
        book_source.save(AccountingBook(Book("Income", "An income statement")))


    memory_journal_entry_source = MemoryJournalEntrySource()
    memory_ledger_source = MemoryLedger

# Generated at 2022-06-24 00:58:59.431737
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    j = JournalEntry[int](datetime.date(2019, 12, 31), "description", 1)
    assert j.date == datetime.date(2019, 12, 31)
    assert j.description == "description"
    assert j.source == 1
    assert j.postings == []
    assert j.guid is not None


# Generated at 2022-06-24 00:59:01.173927
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    pass



# Generated at 2022-06-24 00:59:05.974211
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Test 1: Illegal assignment
    journal_entry = JournalEntry(datetime.date.today(), "", None, [])
    try:
        journal_entry.postings = [Posting(journal_entry, datetime.date.today(), Account("", AccountType.REVENUES),
                                          Direction.INC, Amount(0)),
                                  Posting(journal_entry, datetime.date.today(), Account("", AccountType.EXPENSES),
                                          Direction.DEC, Amount(0))]
    except AttributeError:
        pass

# Generated at 2022-06-24 00:59:11.594078
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    from .accounts import Account, AccountType
    from .commons.numbers import Amount, Quantity, isum
    # create a posting
    p = Posting(date(2020, 1, 1), Account('Assets:Bank'), Direction.INC, Amount(123))

    # add an attribute
    p.xyz = "asdf"  # Throws exception

# Generated at 2022-06-24 00:59:16.218760
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def read(period: DateRange) -> Iterable[JournalEntry[None]]:
        pass
    assert issubclass(ReadJournalEntries[None], Generic)
    assert callable(ReadJournalEntries[None].__call__)
    assert issubclass(ReadJournalEntries[None].__call__.type, Iterable)
    assert issubclass(ReadJournalEntries[None].__call__.type[0], JournalEntry)

    _: ReadJournalEntries[None] = read

# Generated at 2022-06-24 00:59:18.904588
# Unit test for constructor of class Posting
def test_Posting():
    account = Account('Assets', AccountType.ASSETS)
    journal = JournalEntry('1/1/2018', 'rent', 'rent payment')
    date = datetime.date.today()
    direction = Direction.INC
    amount = 500
    posting = Posting(journal, date, account, direction, amount)
    print(posting)


# Generated at 2022-06-24 00:59:30.418567
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # GIVEN
    post1 = Posting(
        "journal",
        datetime.date(2019, 9, 5),
        Account("account", AccountType.ASSETS),
        Direction.INC,
        Amount(100),
    )
    post2 = Posting(
        "journal",
        datetime.date(2019, 9, 5),
        Account("account", AccountType.ASSETS),
        Direction.INC,
        Amount(100),
    )
    post3 = Posting(
        "journal",
        datetime.date(2019, 9, 5),
        Account("account", AccountType.EXPENSES),
        Direction.INC,
        Amount(100),
    )

    # THEN
    assert post1 == post2
    assert post1 != post3

# Generated at 2022-06-24 00:59:39.674176
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from ..commons.others import makeguid
    from .accounts import *
    _journal = JournalEntry[str](date=datetime.date(2020,7,24), description='--test-journal--', source='--test-source--')
    assert _journal.guid != makeguid()
    _guid = _journal.guid
    _journal = JournalEntry[str](date=datetime.date(2020,7,24), description='--test-journal--', source='--test-source--')
    assert _journal.guid == _guid
    _journal.post(datetime.date(2020,7,24), Account(AccountType.ASSETS, 'Cash'), Quantity(1000))
    assert (_journal.postings[0].journal.guid == _journal.guid)

# Generated at 2022-06-24 00:59:44.564883
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    @dataclass
    class Posting:

        journal: int

        date: int

        account: int

        direction: int

        amount: int

    posting = Posting(1,2,3,4,5)
    assert posting.journal == 1
    assert posting.date == 2
    assert posting.account == 3
    assert posting.direction == 4
    assert posting.amount == 5

    posting.journal = 10
    assert posting.journal == 10
    posting.date = 20
    assert posting.date == 20
    posting.account = 30
    assert posting.account == 30
    posting.direction = 40
    assert posting.direction == 40
    posting.amount = 50
    assert posting.amount == 50


# Generated at 2022-06-24 00:59:48.284159
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry(datetime.date(2020, 5, 4), "Description", None)
    account = Account(10, "Account", AccountType.ASSETS)
    posting = Posting(journal, datetime.date(2020, 5, 4), account, Direction.INC, Amount(25.45))
    expected = "Posting(JournalEntry(date=datetime.date(2020, 5, 4), description='Description', source=None), date=datetime.date(2020, 5, 4), account=Account(number=10, name='Account', type=AccountType.ASSETS), direction=Direction.INC, amount=Amount(25.45))"
    assert repr(posting) == expected

# Generated at 2022-06-24 00:59:58.490467
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import Account, AccountType
    from .books import Book
    from .books import Journal
    from .books import Ledger
    from .books import PostingRule


# Generated at 2022-06-24 01:00:03.942442
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    journal_entry_1 = JournalEntry(None, None, None)
    journal_entry_2 = JournalEntry(None, None, None)
    posting_1 = Posting(journal_entry_1, datetime.date(2020, 1, 1), None, Direction.INC, Amount(1))
    posting_2 = Posting(journal_entry_2, datetime.date(2020, 1, 1), None, Direction.INC, Amount(1))
    posting_3 = Posting(journal_entry_1, datetime.date(2020, 1, 1), None, Direction.INC, Amount(2))
    posting_4 = Posting(journal_entry_1, datetime.date(2020, 2, 1), None, Direction.INC, Amount(1))

# Generated at 2022-06-24 01:00:10.440946
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    account = Account('Account 1')
    journal = JournalEntry(date=datetime.date.today(), description='JournalEntry', source='Source')
    posting = Posting(journal=journal, date=datetime.date.today(), account=account, direction='INC', amount=1.1)
    assert repr(posting) == "Posting(date=datetime.date(2020, 1, 2), account='Account 1', direction=INC, amount=Amount(1.1, currency=None), guid=Guid('7b82473a-4585-4cd3-a3b4-24c51f4d8957'))"


# Generated at 2022-06-24 01:00:21.631149
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    source = "entry-source"
    description = "entry-description"

    journalEntry = JournalEntry(
        date=datetime.datetime.now() - datetime.timedelta(days=1),
        description=description,
        source={source}
    )
    posting = Posting(
        journal=journalEntry,
        date=datetime.datetime.now() - datetime.timedelta(days=1),
        account=Account(account_id=1,
                        account_type=AccountType.EQUITIES,
                        account_name="Equity",
                        currency="USD"
                       ),
        direction=Direction.INC,
        amount=Amount(10)
    )

# Generated at 2022-06-24 01:00:24.368832
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Arrange
    from tests.testdata import testdata_dec
    journal = JournalEntry(datetime.date.today(), "description", "source")

    # Act
    hash(journal)

    # Assert

# Generated at 2022-06-24 01:00:27.372609
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    class A:pass
    a1 = JournalEntry[A]("2019-01-01","test",A(),"postings")
    a2 = JournalEntry[A]("2019-01-01","test",A(),"postings")
    assert a1 == a2


# Generated at 2022-06-24 01:00:30.069299
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """
    This should fail to compile, since we are trying to set an attribute that is not in the class definition.
    """
    # p = Posting()
    # p.guid = 3   # This should result in a compile-time error.
    # assert False

# Generated at 2022-06-24 01:00:41.378546
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    j = JournalEntry(datetime.date(2019, 7, 1), "Description", None)
    assert '''JournalEntry(date=datetime.date(2019, 7, 1), description='Description', source=None)''' == repr(j)
    j.post(datetime.date(2019, 7, 1), Account(1, "Assets", "Cash", AccountType.ASSETS, None, None), Quantity(1000))
    j.post(datetime.date(2019, 7, 1), Account(2, "Revenues", "Sales", AccountType.REVENUES, None, None), Quantity(-500))
    j.post(datetime.date(2019, 7, 1), Account(3, "Revenues", "Sales Tax", AccountType.REVENUES, None, None), Quantity(-500))

# Generated at 2022-06-24 01:00:46.881954
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert Posting('some_journal', datetime.date.today(), Account('some_account'), Direction.of(100), Amount(100)).__repr__() == "Posting(journal='some_journal', date=datetime.date(2020, 1, 15), account=Account('some_account'), direction=<Direction.INC: 1>, amount=100)"
    assert Posting('some_journal', datetime.date.today(), Account('some_account'), Direction.of(-100), Amount(100)).__repr__() == "Posting(journal='some_journal', date=datetime.date(2020, 1, 15), account=Account('some_account'), direction=<Direction.DEC: -1>, amount=100)"

# Generated at 2022-06-24 01:00:57.386007
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..biz.vendors import Vendor
    from ..biz.purchases import Purchase
    from datetime import date
    from .accounts import Account

    je = JournalEntry(date(2020, 5, 1), "to test journal method", Vendor())

    account_payable = Account(AccountType.LIABILITIES, "account payable")
    je.post(date(2020, 5, 1), account_payable, 1000)

    assert len(je.postings) == 1
    assert je.postings[0].journal == je
    assert je.postings[0].date == date(2020, 5, 1)
    assert je.postings[0].account == Account(AccountType.LIABILITIES, "account payable")
    assert je.postings[0].direction == Direction.INC
    assert je.postings[0].amount == 1000


# Generated at 2022-06-24 01:01:04.056370
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .books import Book

    book = Book()

    asset = Account(AccountType.ASSETS, "Assets", "Child Assets", "GrandChild Assets")
    liability = Account(AccountType.LIABILITIES, "Liabilities", "Child Liabilities", "GrandChild Liabilities")

    JournalEntry(datetime.date(2017, 10, 2), "Test Journal Entry", book)\
        .post(datetime.date(2017, 10, 2), asset, 10)\
        .post(datetime.date(2017, 10, 2), liability, -10)

# Generated at 2022-06-24 01:01:09.710392
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(None, datetime.date(2019, 10, 2), None, None, 0)
    p2 = Posting(None, datetime.date(2019, 10, 2), None, None, 0)
    assert p1 == p2


# Generated at 2022-06-24 01:01:11.706662
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # @todo: Test class JournalEntry.__eq__()
    pass


# Generated at 2022-06-24 01:01:12.816151
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert False, "Unimplemented"

# Generated at 2022-06-24 01:01:15.783284
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    JournalEntry._create_journal_entry(date=datetime.date(2019, 1, 1), description='monthly salary', source=journal_entry_id, postings=[Posting_entry])

# Generated at 2022-06-24 01:01:16.469015
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

# Generated at 2022-06-24 01:01:18.650641
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p = Posting(None, None, None, None, None)
    assert hash(p) == 0


# Generated at 2022-06-24 01:01:28.974829
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    j1 = JournalEntry("2019-08-01", "foo", "source", [])
    j2 = JournalEntry("2019-08-01", "foo", "source", [])
    h1 = hash(j1)
    h2 = hash(j2)
    assert h1 == h2, f'j1: {j1}: hash: {h1}, j2: {j2}: hash: {h2}'
    # assert j1 == j1, f"j1: {j1}: hash: {h1}, j2: {j2}: hash: {h2}"
    # assert j1 == j2, f"j1: {j1}: hash: {h1}, j2: {j2}: hash: {h2}"


# Generated at 2022-06-24 01:01:32.801728
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import Account
    from .journal_entries import JournalEntry, Posting
    posting = Posting(JournalEntry(datetime.date.today(), "desc", object()), datetime.date.today(), Account(),
                      Amount(1))
    assert repr(posting) == "JournalEntry[object]: desc"

# Generated at 2022-06-24 01:01:41.741946
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Tests if the __repr__ method has one specific format
    assert repr(JournalEntry[int](datetime.date.today(), "Description", 1, [Posting(1, datetime.date.today(), Account("Account"), Direction.INC, Amount(1))])) == "JournalEntry(date=datetime.date(2019, 1, 1), description='Description', source=1, postings=[Posting(journal=JournalEntry(datetime.date(2019, 1, 1), 'Description', 1), date=datetime.date(2019, 1, 1), account=Account('Account'), direction=<Direction.INC: 1>, amount=1.0)], guid='guid')"


# Generated at 2022-06-24 01:01:42.389156
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 01:01:45.634101
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(None, None, None, None, None)
    p2 = Posting(None, None, None, None, None)
    assert p1 != p2, "The two postings should not be equal"
    assert p1 is not p2, "The two postings should not be the same object"


# Generated at 2022-06-24 01:01:51.360924
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # given
    account = Account("test", "test", AccountType.ASSETS)
    # when
    journal_entry_1 = JournalEntry[int](datetime.date(2020,5,5), "test", 1)
    journal_entry_2 = JournalEntry[str](datetime.date(2020,5,5), "test", 1)
    # then
    assert journal_entry_1 == journal_entry_2


# Generated at 2022-06-24 01:01:51.931156
# Unit test for constructor of class Posting
def test_Posting():
    pass

# Generated at 2022-06-24 01:01:52.818893
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass


# Generated at 2022-06-24 01:02:03.224093
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class ReadJournalEntriesImpl1(ReadJournalEntries[None]):
        def __init__(self, period: DateRange):
            self._period = period

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[None]]:
            return [JournalEntry(datetime.date.today(), "test journal entry", None)]

    # This is a correct implementation.
    #: Check: Read journal entries.
    import pytest

    with pytest.raises(TypeError) as excinfo:
        ReadJournalEntriesImpl1(DateRange(datetime.date.today()))
    assert "is not callable" in str(excinfo.value)

    class ReadJournalEntriesImpl2(ReadJournalEntries[None]):
        def __init__(self, period: DateRange):
            self._period = period

# Generated at 2022-06-24 01:02:14.166597
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import Accounts, Account
    from .books import Books

    # Create instance of Accounts
    accounts = Accounts()

    # Create instance of Books
    books = Books(accounts)

    # Create instances of Posting
    p1 = books.posting(
        date=datetime.date(year=2019, month=1, day=1),
        account=accounts.assets.bank_and_cash.cash_at_bank,
        increment=Amount(10),
    )

    p2 = books.posting(
        date=datetime.date(year=2019, month=1, day=1),
        account=accounts.assets.bank_and_cash.cash_at_bank,
        increment=Amount(10),
    )

    # Call method __eq__ of instances of class Posting

# Generated at 2022-06-24 01:02:24.466188
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import AssetAccount, RevenuesAccount, ExpensesAccount
    from .main import Transaction, Journal
    from .journal_entries import JournalEntry, Posting
    j = Journal()
    t = Transaction(date=datetime.date(2019,1,1), description="test transaction", journal=j)
    je = JournalEntry(date=datetime.date(2018,1,1), description="test journal", source=t)
    je.post(date=datetime.date(2018,1,1), account=AssetAccount("Cash"), quantity=10)
    je.post(date=datetime.date(2018,1,1), account=RevenuesAccount("Sales"), quantity=10)
    je.post(date=datetime.date(2018,1,1), account=AssetAccount("Cash"), quantity=-5)

# Generated at 2022-06-24 01:02:30.860139
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from ..portfolios.markers import Marker
    from ..portfolios.positions import Position

    journal = JournalEntry[Position](date=datetime.date(2018, 10, 30),
                                     description="Entry journal for test case",
                                     source=Position.create_long(Marker.create_cash(), 100))
    journal.post(journal.date, Account.create_cash(), -100)
    journal.post(journal.date, Account.create_income(), 100)

    assert str(journal) == "[2018-10-30: Entry journal for test case]: [100.0 $CASH] -> (100.0 $INCOME)"

# Generated at 2022-06-24 01:02:34.026658
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    try:
        je = JournalEntry(None, None, None)
        assert False, "JournalEntry should not allow to set attributes"
    except AttributeError as e:
        pass

# Generated at 2022-06-24 01:02:38.731767
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    '''
    This method tests __eq__ method of class Posting
    '''
    #given
    p1 = Posting(journal=None,date=datetime(2020, 5, 30),account=Account(type=AccountType.EQUITIES, name='POLE EMPLOI'),direction=Direction.INC,amount=Amount(5))
    p2 = Posting(journal=None,date=datetime(2020, 5, 30),account=Account(type=AccountType.EQUITIES, name='POLE EMPLOI'),direction=Direction.INC,amount=Amount(6))
    p3 = Posting(journal=None,date=datetime(2020, 5, 30),account=Account(type=AccountType.EQUITIES, name='POLE EMPLOI'),direction=Direction.INC,amount=Amount(5))


# Generated at 2022-06-24 01:02:39.564561
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # TODO:
    pass



# Generated at 2022-06-24 01:02:48.716108
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # create the journal entry
    je = JournalEntry[str]('2020-01-01', 'Test Journal Entry', 'Source1', [])
    # post 2000 to ACCOUNT_A_1
    je.post('2020-01-01', ACCOUNT_A_1, 2000)
    # post -2000 to ACCOUNT_C_1
    je.post('2020-01-01', ACCOUNT_C_1, -2000)
    # check the result of validate
    je.validate()
    # post -2000 to ACCOUNT_E_1
    je.post('2020-01-01', ACCOUNT_E_1, -2000)
    # check the result of validate
    je.validate()
    # post 1000 to ACCOUNT_A_2
    je.post('2020-01-01', ACCOUNT_A_2, 1000)

# Generated at 2022-06-24 01:02:58.041485
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class Source:
        pass
    #
    journal_entry = JournalEntry[Source](
        date=datetime.date(2019, 1, 1),
        description="test",
        source=Source(),
    )
    journal_entry.post(datetime.date(2019, 1, 1), Account("Assets:Bank:Chequing"), +100)
    journal_entry.post(datetime.date(2019, 1, 1), Account("Expenses:Groceries"), -100)
    #
    read_function = lambda period: [journal_entry]
    read_journal_entries: ReadJournalEntries = read_function
    #

# Generated at 2022-06-24 01:03:09.414070
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Setup
    from ..ledgers.cachedledger import CachedLedger
    from ..ledgers.inmemoryledger import InMemoryLedger
    from ..ledgers.ledger import Ledger
    from ..ledgers.memoryreader import MemoryReader
    from ..ledgers.readjournalentries import ReadJournalEntries
    from ..ledgers.readledger import ReadLedger

    # Arrange
    ledger: Ledger = InMemoryLedger(
        MemoryReader(ReadJournalEntries(CachedLedger(ReadLedger(InMemoryLedger()))),),
    )

    # Act
    # TODO: Add more test cases
    result: Iterable[JournalEntry[Posting]] = ledger.read_journal_entries(DateRange(datetime.date(2017, 1, 1)))

    # Assert

# Generated at 2022-06-24 01:03:13.923405
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType

    income_account = Account(AccountType.REVENUES, "Sales")
    expense_account = Account(AccountType.EXPENSES, "Cost of Goods Sold")

    journal = JournalEntry(datetime.date.today(), "Invoice ABC", "")
    journal.post(journal.date, income_account, 100)
    journal.post(journal.date, expense_account, 50)

    journal.validate()

# Generated at 2022-06-24 01:03:24.821612
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import Amount, Quantity
    from ..commons.others import makeguid
    from ..common.accounts import Asset, Equity, Expense, Revenue
    from ..simulation.entities.accounts import AccountOwner
    from ..simulation.entities.transaction import Transaction
    from ..simulation.entities.accounts import AccountOwner
    from ..simulation.entities.transaction import Transaction
    from .accounts import Account, AccountType
    from .journal_entries import JournalEntry, Posting

    def create_account_owners():
        from datetime import date
        from ..commons.zeitgeist import DateRange

        to = date(2020, 1, 1)
        from ..simulation.entities.accounts import AccountOwner

# Generated at 2022-06-24 01:03:35.208689
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from accounting.crud import PreparedTransaction
    import datetime
    from accounting.entities.accounts import AccountType, Account, AccountRepository
    from accounting.entities.journals import JournalEntry

    transaction = PreparedTransaction().with_entities(AccountRepository)

    date = datetime.date(2020, 1, 1)
    description = "Test"
    source = "Source"

    je = JournalEntry[str](date, description, source)
    account = Account("Assets:Accounts Receivable (A/R)", AccountType.ASSETS)
    quantity = 100
    je.post(date, account, quantity)
    je.validate()
    assert True


# Generated at 2022-06-24 01:03:36.981254
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # Check: Check the class definition.
    assert ReadJournalEntries

# Generated at 2022-06-24 01:03:44.949931
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal_entry:JournalEntry = JournalEntry('01/01/01', "Test JournalEntry", 'Test Source')
    posting = Posting(journal_entry, '01/01/01', Account(AccountType.ASSETS, "Test Account"), Direction.INC, 1.0)
    posting1 = Posting(journal_entry, '01/01/01', Account(AccountType.ASSETS, "Test Account"), Direction.INC, 1.0)
    posting2 = Posting(journal_entry, '01/01/02', Account(AccountType.ASSETS, "Test Account"), Direction.INC, 1.0)
    posting3 = Posting(journal_entry, '01/01/01', Account(AccountType.EQUITIES, "Test Account"), Direction.INC, 1.0)

# Generated at 2022-06-24 01:03:49.338632
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    a = Posting(None, None, None, None, None)
    b = Posting(None, None, None, None, None)
    c = Posting(None, None, None, None, None)
    assert a.__hash__() == b.__hash__(), "The hash of a and b is not equal"
    assert b.__hash__() == c.__hash__(), "The hash of b and c is not equal"


# Generated at 2022-06-24 01:03:55.158631
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..commons.others import now

    # Given
    cash = Account("cash")
    equity = Account("equity")
    entry = JournalEntry(now(), "", "", [])

    # When
    entry.post(now(), cash, +5)
    entry.post(now(), equity, -5)

    # Then
    entry.validate()

# Generated at 2022-06-24 01:04:06.535860
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .ledgers import Ledger
    from .books import Book
    from .charts import Chart

    chart = Chart()  # Create a chart
    assets: Account = chart.new_account("Assets", AccountType.ASSETS)
    liabilities: Account = chart.new_account("Liabilities", AccountType.LIABILITIES)
    today = date(2020, 2, 16)  # Create today's date
    one_month_from_today = today.replace(month=today.month + 1).date()  # Create a date one month from today
    salary = assets.child("Salary", AccountType.REVENUES)  # Create an account "Salary" under "Assets"

# Generated at 2022-06-24 01:04:13.447235
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    r = Posting(journal=JournalEntry, date = datetime.date.today(), account=Account('asset_account', AccountType.ASSETS), direction=Direction.INC, amount = 100)
    p = Posting(journal=JournalEntry, date = datetime.date.today(), account=Account('asset_account', AccountType.EXPENSES), direction=Direction.DEC, amount = 100)
    journal = JournalEntry(description='description', source='source', postings=[r,p])
    journal.validate()
    assert True

# Generated at 2022-06-24 01:04:14.647719
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():  # noqa
    # Tests that this abstract method is indeed abstract and explicitly present in the class definition.
    pass



# Generated at 2022-06-24 01:04:21.449443
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Arrange:
    entry = JournalEntry(datetime.datetime(2020, 1, 10), "Asset Purchase", None)

    # Act and Assert:
    # ... validate that we can't set the "guid" field:
    try:
        setattr(entry, "guid", makeguid())
        assert False, "This should have caused an exception."
    except TypeError as ex:
        assert "can't set attribute" in str(ex), "Unexpected exception"

    # ... validate that we can't set the "postings" field:
    try:
        setattr(entry, "postings", list())
        assert False, "This should have caused an exception."
    except TypeError as ex:
        assert "can't set attribute" in str(ex), "Unexpected exception"

    # ... validate that we can't set the

# Generated at 2022-06-24 01:04:24.491438
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    je = JournalEntry(datetime.date.today(), "Test journal entry", None)
    p = Posting(je, datetime.date.today(), None, None, Amount(1))
    try:
        p.journal = None
        assert False
    except AttributeError as e:
        assert True



# Generated at 2022-06-24 01:04:29.163286
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    @dataclass(frozen=True)
    class _JournalEntries:
        period: DateRange
        entries: List[JournalEntry[_T]]
    _JournalEntries([1,2,3])
    return True
test_ReadJournalEntries()

# Generated at 2022-06-24 01:04:39.236122
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from ..commons.businessobjects import BusinessObject
    test = Posting(1, datetime.date.today(), Account(1, "TestAccount", AccountType.ASSETS), Direction.INC, 100)
    assert test.journal == 1
    assert test.date == datetime.date.today()
    assert test.account == Account(1, "TestAccount", AccountType.ASSETS)
    assert test.direction == Direction.INC
    assert test.amount == 100
    test.journal = 2
    assert test.journal == 1, "Journal property should not be reassignable"
    test.date = datetime.date.today() - datetime.timedelta(days=1)
    assert test.date == datetime.date.today(), "Date property should not be reassignable"

# Generated at 2022-06-24 01:04:44.666386
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    class S(Generic[_T]):
        def __init__(self):
            self.journal = JournalEntry()
            self.date = datetime.date(2000,1,1)
            self.account = Account()
            self.account.type = AccountType.ASSETS
            self.direction = Direction.INC
            self.amount = Amount([0])

    s = S()
    assert (hash(s))

test_Posting___hash__()


# Generated at 2022-06-24 01:04:49.119731
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from ..commons.json import dataclass_json

    journal = JournalEntry(date=datetime.date(2019, 3, 31), description='Test', source=None, guid='journal-1')
    account = Account(name='Test Account', type=AccountType.ASSETS)
    posting = Posting(journal, datetime.date(2019, 3, 30), account, Direction.INC, Amount(100))
    assert dataclass_json(posting) == '{"journal": {"date": "2019-03-31", "description": "Test", "source": null, "guid": "journal-1"}, "date": "2019-03-30", "account": {"name": "Test Account", "type": "ASSETS"}, "direction": "INC", "amount": 100}'

# Generated at 2022-06-24 01:04:57.414225
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    with pytest.raises(AttributeError, match=r"can't set attribute"):
        Posting(
            journal = JournalEntry(date=datetime.date.today(), description = "Description", source = ()),
            date = datetime.date.today(),
            account = Account(type = AccountType.ASSETS, code = "CODE", name = "NAME"),
            direction = Direction.INC,
            amount = Amount()
        ).journal = JournalEntry(
            date = datetime.date.today(),
            description = "Description",
            source = ()
        )


# Generated at 2022-06-24 01:05:03.303204
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from .accounts import AccountType

    # Define a dummy function type:
    def dummy_func_type(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass
    ReadJournalEntries_object = ReadJournalEntries()
    ReadJournalEntries_object.__class__ = dummy_func_type

    assert ReadJournalEntries_object

# Generated at 2022-06-24 01:05:08.670827
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    t = [1,2,3]
    assert JournalEntry(date=datetime.date(2020, 9, 1), description="desc", source=t, guid="sdfsdfsdfs") == \
           JournalEntry(date=datetime.date(2020, 9, 1), description="desc", source=t, guid="sdfsdfsdfs")


# Generated at 2022-06-24 01:05:14.897952
# Unit test for constructor of class Posting
def test_Posting():
    from ..books.accounts import Account
    from .accounts import AssetAccount, EquityAccount
    p  = Posting('journal','December','account','direction','amount')
    assert p.journal == 'journal'
    assert p.date == 'December'
    assert p.account == 'account'
    assert p.direction == 'direction'
    assert p.amount == 'amount'
    assert p.is_debit() == 'is_debit'
    assert p.is_credit() == 'is_credit'


# Generated at 2022-06-24 01:05:19.842341
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .books import Book
    from .business import Business
    from .business import BusinessUnit
    business = Business("example", "Sample Business")
    book = Book("example", "Sample Book", business)

    order = Order("order", "Sample Order", book, date)
    OrderEntry("entry", "Sample Order Entry", order)

    # TODO: complete the test

# vim:et:sw=4:ts=4

# Generated at 2022-06-24 01:05:29.328636
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import unittest.mock as mock
    from ..commons.zeitgeist import DateTimeRange
    from .accounts import AccountType
    from .journal.values import JournalEntry, ReadJournalEntries

    # Create mock objects:
    m_accounts = mock.Mock()

    # Setup accounts:
    def make_account(type: AccountType) -> mock.Mock:
        m_account = mock.Mock(spec=Account)
        m_account.type = type
        return m_account

    m_accounts.make_account.side_effect = make_account

    # Define subject:

# Generated at 2022-06-24 01:05:35.535562
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal_entry = JournalEntry('2019-04-25', 'description', _T)
    assert journal_entry.date=='2019-04-25'
    assert journal_entry.description=='description'
    assert journal_entry.source==_T
    assert len(journal_entry.postings) == 0


# Generated at 2022-06-24 01:05:43.443935
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from pyberry.accounting.accounts import Asset, Equity, Liability, Revenue, Expense
    from pyberry.accounting.journal import JournalEntry, Direction

    # create a journal entry and post an entry to a Revenue account
    j = JournalEntry(datetime.date(2020, 1, 1), "Test Journal", None)
    j.post(datetime.date(2020, 1, 5), Revenue("Test Revenue"), 10)

    # try to set 'postings' attibute
    try:
        j.postings.append(Direction.INC)
    except AttributeError as exc:
        assert "can't set attribute" in str(exc)



# Generated at 2022-06-24 01:05:54.030300
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from datetime import date
    from ppb_controller import Account

    a = JournalEntry(date.today(), "a", None)
    a.post(date.today(), Account(""), 1)
    assert repr(a) == "JournalEntry(date=datetime.date(2020, 7, 1), description='a', source=None, postings=[Posting(journal=<JournalEntry object at 0x7feccb6f5490>, date=datetime.date(2020, 7, 1), account=Account(name='', type=<AccountType.ASSETS: 'ASSETS'>), direction=<Direction.INC: 1>, amount=1)])"

# Generated at 2022-06-24 01:06:05.152798
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date
    from unittest.mock import Mock
    from finance.repositories.ledger import DatabaseSession

    dal = Mock(DatabaseSession)

# Generated at 2022-06-24 01:06:13.432586
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    one = Account.of(AccountType.EXPENSES, 'Office Expense')
    two = Account.of(AccountType.REVENUES, 'Sales')
    three = Account.of(AccountType.ASSETS, 'Cash On Hand')
    test = JournalEntry(datetime.date(2019,10,22),'some description', one)
    test.post(datetime.date(2019,10,22), two, 1)
    test.post(datetime.date(2019,10,22),three, -1)
    test.validate()

# Generated at 2022-06-24 01:06:21.880862
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    p1 = Posting(journal=None, date=datetime.date.today(), account=Account("a", account_type=AccountType.ASSETS), direction=Direction.INC, amount=Amount("1.00"))
    p2 = Posting(journal=None, date=datetime.date.today(), account=Account("b", account_type=AccountType.ASSETS), direction=Direction.INC, amount=Amount("1.00"))
    j1 = JournalEntry(date=datetime.date.today(), description="test journal 1", source=None, postings=[p1])
    j2 = JournalEntry(date=datetime.date.today(), description="test journal 2", source=None, postings=[p2])
    j3 = JournalEntry(date=datetime.date.today(), description="test journal 1", source=None, postings=[p1])

# Generated at 2022-06-24 01:06:25.553106
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..books.accounts import expenses
    from ..books.ledgers import manual_journal_entries
    a = JournalEntry[None]
    m = JournalEntry[None]
    a.post(datetime.date.today(), expenses.office, 100)
    assert a == m



# Generated at 2022-06-24 01:06:35.190466
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import Ledger
    from .transactions import Transaction, TransactionDetail

    tr_1 = Transaction()
    tr_1.date = date(2019, 1, 1)
    tr_1.description = "First transaction"
    tr_1.post(amount=12, account=Ledger.CASH)
    tr_1.post(amount=12, account=Ledger.EQUITY)
    tr_1.validate()

    tr_2 = Transaction()
    tr_2.date = date(2019, 1, 2)
    tr_2.description = "Second transaction"
    tr_2.post(amount=12, account=Ledger.CASH)
    tr_2.post(amount=12, account=Ledger.EQUITY)
    tr_2.validate()

# Generated at 2022-06-24 01:06:46.232804
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je1 = JournalEntry[int](datetime.date(2019, 10, 17), "description", 1)
    je1.post(datetime.date(2019, 10, 17), Account("A123", AccountType.ASSETS), Amount(1))
    je1.post(datetime.date(2019, 10, 17), Account("L321", AccountType.LIABILITIES), Amount(1))
    
    je2 = JournalEntry[int](datetime.date(2019, 10, 17), "description", 1)
    je2.post(datetime.date(2019, 10, 17), Account("A123", AccountType.ASSETS), Amount(1))
    je2.post(datetime.date(2019, 10, 17), Account("L321", AccountType.LIABILITIES), Amount(1))

    assert je1 == je2
    assert hash

# Generated at 2022-06-24 01:06:47.561243
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    pass


# Generated at 2022-06-24 01:06:53.947282
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    """Test for JournalEntry.__delattr__()"""
    j = JournalEntry(None, "Description", None)
    j.date = datetime.date.today()
    assert j.date is not None
    delattr(j, "date")
    with pytest.raises(AttributeError) as error:
        j.date
    assert "has no attribute 'date'" in str(error)


# Generated at 2022-06-24 01:07:02.582133
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..books.accounts import Account, AccountDao
    from ..books.books import Book
    from ..books.books import BookDao
    from ..books.storages import InMemoryStorage
    from ..books.units import Unit
    storage = InMemoryStorage()
    book = Book.create(name="My Book", storage=storage)
    book2 = Book.create(name="My Book", storage=storage)
    bookDao = BookDao(storage=storage)
    accountDao = AccountDao(storage=storage)
    accountDao.create_root_account(book=book, name="Root Account", account_type=AccountType.ASSETS)
    accountDao.create_root_account(book=book, name="Root Account", account_type=AccountType.EQUITIES)
    accountDao.create_root_

# Generated at 2022-06-24 01:07:06.714472
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # Define journal entry
    journal1 = JournalEntry(datetime.date.today(), "Description", "Source", [])
    journal2 = JournalEntry(datetime.date.today(), "Description", "Source", [])
    journal3 = JournalEntry(datetime.date.today(), "Description1", "Source", [])
    
    assert(journal1 != journal2)
    assert(journal1 == journal3)

# Generated at 2022-06-24 01:07:12.577615
# Unit test for method __repr__ of class JournalEntry

# Generated at 2022-06-24 01:07:17.645771
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journal = JournalEntry(datetime.date(2020, 11, 16), 'Test Entry')
    posting = Posting(journal, datetime.date(2020, 11, 16), Account(AccountType.ASSETS, 'Cash'), Direction.INC, Amount(1000))
    try:
        posting.journal = journal
    except AttributeError:
        pass
    else:
        assert False


# Generated at 2022-06-24 01:07:18.181097
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert True

# Generated at 2022-06-24 01:07:25.836558
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    ja = _T
    jb = _T
    ja.source = 'a'
    jb.source = 'b'
    ja.postings = [Posting(ja, datetime.date.today(), Account('A1', AccountType.ASSETS, "Current Assets"), Direction.INC, Amount(100))]
    jb.postings = [Posting(ja, datetime.date.today(), Account('A1', AccountType.ASSETS, "Current Assets"), Direction.INC, Amount(100))]
    print(jb == ja)



# Generated at 2022-06-24 01:07:34.958747
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
	from freezegun import freeze_time
	import datetime
	from dataclasses import dataclass, field
	from typing import Dict, Set, TypeVar
	from datetime import date
	from numbers import Amount, Quantity, isum
	from otherutils import makeguid, guid
	from zeitgeist import DateRange
	from accounts import Account
	from journal import Direction
	from datetime import timedelta
	from datetime import tzinfo
	from datetime import datetime
	from datetime import date
	import datetime
	from journal import Posting
	from journal import JournalEntry
	from journal import ReadJournalEntries
	
	import datetime
	from datetime import date
	from datetime import datetime
	from datetime import tzinfo
	from datetime import timedelta
	from zeitgeist import DateRange
	

# Generated at 2022-06-24 01:07:41.346391
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    target_date = datetime.date(2020, 1, 1)
    target_account = Account("Cash")
    target_amount = 42
    target_journal_entry = JournalEntry(target_date, "Bought stuffs with cash", None)
    target = Posting(target_journal_entry, target_date, target_account, Direction.INC, Amount(target_amount))
    target.journal.postings.append(target)

    # Test function
    try:
        delattr(target, "guid")
    except:
        assert False
    else:
        assert True
