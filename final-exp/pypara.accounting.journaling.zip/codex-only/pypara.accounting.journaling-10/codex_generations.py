

# Generated at 2022-06-24 00:57:43.901766
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    with pytest.raises(AttributeError) as e:
        journalEntry = JournalEntry(datetime.date(2020, 1, 1), "Test journal entry", None)
        journalEntry.guid = Guid.parse('b4f4ca2a-d8f8-4f4a-a51d-3f889801e84b')
        del journalEntry.guid
    assert e.value.args[0] == "can't delete attribute"

# Generated at 2022-06-24 00:57:49.633826
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    with pytest.raises(AttributeError) as excinfo:
        journal = JournalEntry(datetime.date.today(), "JournalEntry test", "")
        posting = Posting(journal, datetime.date.today(), Account("test_account"), Direction.INC, Amount(1))
        posting.date = datetime.date.today()
    assert "Cannot reassign immutable object" in str(excinfo.value)


# Generated at 2022-06-24 00:57:51.909726
# Unit test for constructor of class Posting
def test_Posting():
    p = Posting(None, None, None, None, None)
    assert p.journal is None
    assert p.date is None
    assert p.account is None
    assert p.direction is None
    assert p.amount is None


# Generated at 2022-06-24 00:58:02.879102
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    @dataclass
    class MockJournal:
        guid: Guid = makeguid()

    posting = Posting(MockJournal(), datetime.date(2019, 2, 2), Account("A/C A"), Direction.INC, Amount(10))
    posting_ = Posting(MockJournal(), datetime.date(2019, 2, 2), Account("A/C A"), Direction.INC, Amount(10))
    posting_du_account = Posting(MockJournal(), datetime.date(2019, 2, 2), Account("A/C B"), Direction.INC, Amount(10))
    posting_du_amount = Posting(MockJournal(), datetime.date(2019, 2, 2), Account("A/C A"), Direction.INC, Amount(11))

# Generated at 2022-06-24 00:58:08.314654
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert eval(repr(Posting(None, None, Account(None, AccountType.ASSETS, ''), Direction.INC, Amount(100)))) == Posting(None, None, Account(None, AccountType.ASSETS, ''), Direction.INC, Amount(100))


# Generated at 2022-06-24 00:58:10.733857
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class ReadJournalEntries_class(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass
        pass
    pass

# Generated at 2022-06-24 00:58:11.239428
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    pass

# Generated at 2022-06-24 00:58:22.211532
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from typing import Callable
    from unittest.mock import MagicMock
    from ..commons.zeitgeist import DateRange, Dated

    @dataclass(frozen=True)
    class Foo(Dated):
        pass

    def verify(fn: Callable[[DateRange], Iterable[JournalEntry[Foo]]]):
        mock = MagicMock(side_effect=fn)
        assert fn is not mock
        assert list(ReadJournalEntries.__invoke__(ReadJournalEntries, mock, DateRange.now())) == list(mock())

    verify(lambda _: [])
    verify(lambda _: [JournalEntry(datetime.date(2020, 1, 1), "Lorem", Foo(datetime.date(2020, 1, 1)), [])])

# Generated at 2022-06-24 00:58:31.153565
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from ..commons.accounts import Account, AccountType
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DatetimeProvider, datetime_test
    from .accounts import AccountRepository
    from .entries import JournalEntry, Posting
    ## Setup:
    the_account = Account('test_account', AccountType.ASSETS)
    the_posting = Posting(123, datetime_test(2020, 5, 9), the_account, Direction.INC, Amount(Quantity('123.45')))
    ## Exercise:

# Generated at 2022-06-24 00:58:39.273597
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from dataclasses import dataclass

    @dataclass(frozen=True)
    class JournalEntryImpl:
        date: datetime.date
        description: str
        source: str
        guid: str


# Generated at 2022-06-24 00:58:49.596032
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    '''
    Unit test for method __call__ of class ReadJournalEntries
    '''
    from ..ledger import Ledger
    
    # define a class to be returned by ReadJournalEntries.__call__
    class Item():
        def __init__(self, i, p, q):
            self.raw = {'id': i, 'period': p, 'quantity': q}
        def __repr__(self):
            return repr(self.raw)
    
    # define a function to be used via Ledger.generate()

# Generated at 2022-06-24 00:58:51.352288
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class C(ReadJournalEntries[_T]):
        pass

    print(C)
    assert C is not None

# Generated at 2022-06-24 00:58:52.173119
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True


# Generated at 2022-06-24 00:58:58.703321
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Arrange
    source = Account('Assets')
    j = JournalEntry[Account](datetime.date.today(), 'description', source)

    # Act
    result = j.__repr__()

    # Assert
    expected_repr = "JournalEntry(date=datetime.date(2020, 8, 24), description='description', source=Account(name='Assets', type=AccountType.ASSETS), postings=[], guid=Guid('816c39fa-6b16-6cfe-6fb8-3c0cd9b3641e'))"
    assert result == expected_repr

# Generated at 2022-06-24 00:59:07.964058
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account
    from . import books
    from . import journals
    direc = Direction.INC
    j = journals.SalesJournal(books.GeneralJournal)
    post = Posting(j, datetime.date(2019,11,13),Account('15900', 'cash'), direc, Amount(10))
    assert post.journal == j
    assert post.date == datetime.date(2019,11,13)
    assert post.account.acc_id == '15900'
    assert post.account.acc_title == 'cash'
    assert post.direction == Direction.INC
    assert post.amount == Amount(10)
    assert post.is_debit == True
    assert post.is_credit == False
    direc = Direction.DEC
    j = journals.PurchaseJournal(books.GeneralJournal)

# Generated at 2022-06-24 00:59:13.013493
# Unit test for constructor of class Posting
def test_Posting():
    p = Posting(None, datetime.date.today(), Account(str(1), AccountType.ASSETS), Direction.INC, Amount(Quantity(1)))
    print(p)


# Generated at 2022-06-24 00:59:14.706608
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    import pytest
    with pytest.raises(AttributeError):
        del JournalEntry.postings


# Generated at 2022-06-24 00:59:25.229404
# Unit test for method __eq__ of class JournalEntry

# Generated at 2022-06-24 00:59:30.009669
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    class C:
        def __delattr__(self, name):
            print(f"deleting attribute {name}")

    c = C()
    c.a = 1
    del c.a
    c = C()
    c.a = 1
    del c.__dict__['a']

# Generated at 2022-06-24 00:59:30.947219
# Unit test for constructor of class Posting
def test_Posting():
    pass


# Generated at 2022-06-24 00:59:38.930835
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from ..accounts.models import Account

    je = JournalEntry("test journal entry")
    p = Posting(je, "test date", Account("test account"), Direction.DEC, Amount("test amount"))
    assert p.__repr__() == "Posting(journal=JournalEntry(description='test journal entry', guid='t2b0-7e07-4d4e-64b2-10e3-3d3a-f41d-9c9b'), date='test date', account=Account(name='test account', type=<AccountType.ASSETS: 'ASSETS'>), direction=Direction.DEC, amount=Amount('test amount'))"



# Generated at 2022-06-24 00:59:44.531394
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    posting = Posting(journal=0, date=0, account=0, direction=1, amount=2)
    if (posting.journal != 0 or posting.date != 0 or posting.account != 0 or posting.direction != 1 or posting.amount != 2 or posting.is_debit != False or posting.is_credit != True):
        raise Exception("Test not implemented.")

# Generated at 2022-06-24 00:59:50.895171
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .books import AccountBook
    from .reader import LedgerReader
    from .types import Journal

    book = AccountBook.create()
    journal: Journal = book.create_journal("TEST")
    reader = LedgerReader(journal, singleton_source=True)
    target_date = datetime.date.today()

    entry = reader.create_entry(
        "TEST",
        target_date,
        lambda journal: journal.post(target_date, "ASSETS:Cash", 100),
        lambda journal: journal.post(target_date, "EQUITIES:Equity", -100),
    )

    entry.validate()


# Generated at 2022-06-24 00:59:53.698495
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    je1 = JournalEntry(datetime.date(2020, 1, 10), 'description', 'source')
    je2 = JournalEntry(datetime.date(2020, 1, 10), 'description', 'source')
    assert je1 == je2

# Generated at 2022-06-24 01:00:02.216208
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from ..commons.others import setwith

    # given
    journal0 = JournalEntry(
        date=datetime.date(2019, 1, 1),
        description="debit",
        source=None
    )
    journal1 = JournalEntry(
        date=datetime.date(2019, 1, 2),
        description="credit",
        source=None
    )

    journal0.post(datetime.date(2019, 1, 2), Account("Assets/Cash"), Quantity(100))
    journal1.post(datetime.date(2019, 1, 2), Account("Equities/Opening"), Quantity(-100))

    # when
    journals = setwith([journal0, journal1])

    # then
    assert len(journals) == 2
    assert journal0 in journals
    assert journal1 in journals

# Generated at 2022-06-24 01:00:06.684247
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    print(JournalEntry(datetime.date(2020, 1, 1), "desc1", source="source1").post(datetime.date(2020, 1, 1), Account(1, "A1", AccountType.ASSETS), Quantity(10)))


# Generated at 2022-06-24 01:00:09.402679
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    journal=JournalEntry[str]("date","description","source","postings")
    del journal.guid
    assert not hasattr(journal,"guid")

# Generated at 2022-06-24 01:00:15.673882
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    """
    Tests the function ``Posting.__hash__`` to see if it returns a value that
    can be used in a hashtable.
    """

    # Setup
    journal = JournalEntry[int]()
    p1, p2, p3, p4 = [Posting(journal, datetime.date(2020, 1, 1), Account("Account"), Direction.INC, Amount(1)) for i in range(4)]

    # Exercise
    d = {p1: 1, p2: 2, p3: 3, p4: 4}
    # Verify
    assert d[p1] == 1
    assert d[p2] == 2
    assert d[p3] == 3
    assert d[p4] == 4

# Generated at 2022-06-24 01:00:25.427615
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    o = Posting(journal=JournalEntry(date=datetime.date(2020, 1, 1), description="a", source=None),
                date=datetime.date(2020, 1, 1),
                account=Account(id="id", name="name", account_type=AccountType.ASSETS),
                direction=Direction.INC,
                amount=Amount(10))
    assert repr(o) == "Posting(journal=JournalEntry(date=datetime.date(2020, 1, 1), description='a', source=None), date=datetime.date(2020, 1, 1), account=Account(id='id', name='name', account_type=AccountType.ASSETS), direction=Direction.INC, amount=Amount(10))"


# Generated at 2022-06-24 01:00:32.236330
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert (
        Posting(None, datetime.date(2019, 9, 29), Account("act1", "ACCOUNTS RECEIVABLE - UNDEFINED", AccountType.ASSETS), Direction.INC, Amount(102.0)) ==
        Posting(None, datetime.date(2019, 9, 29), Account("act1", "ACCOUNTS RECEIVABLE - UNDEFINED", AccountType.ASSETS), Direction.INC, Amount(102.0))
    )

# Generated at 2022-06-24 01:00:41.979344
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    a1 = Account("a1", AccountType.ASSETS)
    a2 = Account("a2", AccountType.ASSETS)
    a3 = Account("a3", AccountType.LIABILITIES)

    p1 = Posting(None, datetime.date.today(), a1, Direction.INC, Amount(10))
    assert a1 != a2, "before posts"
    assert p1 != Posting(None, datetime.date.today(), a2, Direction.INC, Amount(10)), "objects refer to different accounts"
    assert p1 != Posting(None, datetime.date.today(), a1, Direction.DEC, Amount(10)), "objects refer to different directions"
    assert p1 != Posting(None, datetime.date.today(), a1, Direction.INC, Amount(20)), "objects refer to different amounts"
   

# Generated at 2022-06-24 01:00:44.675050
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry(datetime.date.today(), 'desc', 'source')
    assert isinstance(je, JournalEntry), f'Test failed for class JournalEntry'

# Generated at 2022-06-24 01:00:54.072262
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    firstPosting = Posting(journal =None, date =datetime.datetime.today(),account =Account(id ="acct1"), direction=Direction.DEC, amount =Amount(1))
    secondPosting = Posting(journal=None, date=datetime.datetime.today(),account=Account(id="acct1"), direction=Direction.DEC, amount=Amount(1))
    thirdPosting = Posting(journal=None, date=datetime.datetime.today(),account=Account(id="acct2"), direction=Direction.DEC, amount=Amount(1))
    firstEntry = JournalEntry(date=datetime.datetime.today(),description="eqTest", source=None, guid=makeguid())

# Generated at 2022-06-24 01:01:04.095113
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(JournalEntry(date=datetime.date(2020, 1, 1), description="description1", source="source1"), date=datetime.date(2020, 1, 1), account=Account("name1", AccountType.ASSETS), direction=Direction.DEC, amount=Amount(1000))
    p2 = Posting(JournalEntry(date=datetime.date(2020, 1, 1), description="description1", source="source1"), date=datetime.date(2020, 1, 1), account=Account("name1", AccountType.ASSETS), direction=Direction.DEC, amount=Amount(1000))
    assert p1 == p2


# Generated at 2022-06-24 01:01:14.294474
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account, AccountGroup
    from .accounts import AccountGroupType, AccountTree, AccountTreeFactory
    from .accounts import AccountTreeUnitOfWork
    from ..commons.times import DateTimePeriod, TimeSpan
    from ..commons.zeitgeist import now

    def journal_entry_generator(period: DateRange = DateTimePeriod.in_last(TimeSpan.from_days(365)), **kwargs):
        """
        Generates a few test journal entries.

        :param period: Date range to generate transactions in and as per.
        :return: Sequence of test journal entries.
        """
        def make_posting_dict(postings, account_group_types):
            """
            Makes a posting dictionary.
            """
            current_account_group_type = account_group_types

# Generated at 2022-06-24 01:01:23.840807
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from .accounts import Account

    t = JournalEntry("")
    t.post("", Account(""), 0)
    t.post("", Account(""), 0)
    t.post("", Account(""), 0)
    t.post("", Account(""), 0)
    t.post("", Account(""), 0)
    t.post("", Account(""), 0)
    t.post("", Account(""), 0)
    t.post("", Account(""), 0)
    t.post("", Account(""), 0)
    t.post("", Account(""), 0)
    t.post("", Account(""), 0)


# Generated at 2022-06-24 01:01:30.883225
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    je1 = JournalEntry('2020-01-01', 'test', 'debit', 'credit', 'description', 'date', 'source', 'postings', 'guid', 'increments', 'decrements', 'debits', 'credits')
    je2 = JournalEntry('2020-01-01', 'test', 'debit', 'credit', 'description', 'date', 'source', 'postings', 'guid', 'increments', 'decrements', 'debits', 'credits')
    assert (je1 == je2)

# Generated at 2022-06-24 01:01:42.797574
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    """
    Unit test for method __repr__ of class Posting
    """
    # create a JournalEntry object
    journalEntry = JournalEntry(datetime.date(2020, 3, 1), "Test Description", "Test Source")
    # create a Posting object
    posting = Posting(journalEntry, datetime.date(2020, 3, 1), "Test Account", 1, 100)
    # check if the __repr__ method works correctly

# Generated at 2022-06-24 01:01:43.503571
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-24 01:01:44.440960
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert issubclass(JournalEntry, Generic)

# Generated at 2022-06-24 01:01:54.240837
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    dt = datetime.date(2020, 1, 1)
    desc = "Transferred $10 from savings to checking."
    j1 = JournalEntry(date=dt, description=desc, source=None)
    j2 = JournalEntry(date=dt, description=desc, source=None)
    j3 = JournalEntry(date=dt, description=desc, source=None)
    j1.post(date=dt, account="Assets:Checking", quantity=10)
    j1.post(date=dt, account="Assets:Savings", quantity=-10)
    j2.post(date=dt, account="Assets:Checking", quantity=10)
    j2.post(date=dt, account="Assets:Savings", quantity=-10)

# Generated at 2022-06-24 01:02:03.327110
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from datetime import date
    from ..commons.numbers import Zero

    from .accounts import Account, Book, AccountType
    from .journal import JournalEntry, Posting

    # setup:
    book: Book = Book(name="Test Book 1")
    account_1: Account = book.add(name="Account 1", type=AccountType.EQUITIES)
    account_2: Account = book.add(name="Account 1", type=AccountType.REVENUES)
    entry = JournalEntry(date=date(2019, 9, 1), description="Monthly Salary")
    posting_1: Posting = entry.post(date=date(2019, 9, 1), account=account_1, quantity=1000)

# Generated at 2022-06-24 01:02:05.169634
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert JournalEntry.postings.default_factory() == []

# Generated at 2022-06-24 01:02:15.500647
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    @dataclass(frozen=True)
    class DummyJournalEntry(JournalEntry[str]):
        pass

    @dataclass(frozen=True)
    class DummyJournalEntries:
        stub: Set[JournalEntry[str]]

    mock_journal_entries: ReadJournalEntries[str] = DummyJournalEntries({
        DummyJournalEntry(
            date=datetime.date(2018, 1, 1),
            description="Description",
            source="SOURCE",
            postings=[
            ]
        )
    })

    result = list(mock_journal_entries(DateRange(
        start_date=datetime.date(2017, 1, 1),
        end_date=datetime.date(2018, 1, 1)
    )))

    assert len(result) == 1

# Generated at 2022-06-24 01:02:23.417587
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Setup
    def setup_JournalEntry_post():
        debit = Account(Guid(), 'Account-1', AccountType.EXPENSES)
        credit = Account(Guid(), 'Account-2', AccountType.REVENUES)

        return debit, credit

    debit, credit = setup_JournalEntry_post()

    # Execute
    jentry = JournalEntry('journal', 'description', 'source')
    result = jentry.post(datetime.date.today(), debit, 0).post(datetime.date.today(), credit, 0)
    assert result.postings == []

# Generated at 2022-06-24 01:02:28.734136
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    #arrange
    #these variables is declared using dataclass
    journal = JournalEntry[1]
    date = datetime.date(2020, 1, 8)
    account = Account(AccountType.ASSETS, "1000", "Cash")
    direction = Direction.INC
    amount = Amount(100)

    #expected = posting1==posting2
    EXPECTED = True
    posting1 = Posting(journal, date, account, direction, amount)
    posting2 = Posting(journal, date, account, direction, amount)

    #act
    RESULT = posting1 == posting2

    #assert
    assert RESULT == EXPECTED


# Generated at 2022-06-24 01:02:31.171089
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    pass

# Generated at 2022-06-24 01:02:34.616920
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    assert hash(JournalEntry(datetime.date(2020,1,1), "test description", "test source")) == hash(
        JournalEntry(datetime.date(2020,1,1), "test description", "test source"))

# Generated at 2022-06-24 01:02:37.151498
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Create test data
    jo = JournalEntry[int](datetime.date(2019, 8, 1), "Test", 0, [])
    assert "2019-08-01" in str(jo)
    assert "Test" in str(jo)
    assert "source" in str(jo)

# Generated at 2022-06-24 01:02:39.841366
# Unit test for constructor of class Posting
def test_Posting():
    p = Posting(1, datetime.date(2020, 1, 1), 1, 1, Amount(1))

# Generated at 2022-06-24 01:02:48.998696
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    """
    Tests the method __delattr__ of class JournalEntry
    """
    from datetime import date
    from core_domain.transaction import Transaction
    from .__init__ import HighLevelAccounts, LowLevelAccounts
    from .accounts import Account, AccountType

    credit_card_account: Account = HighLevelAccounts.CREDIT_CARD_ACCOUNT
    fees_and_interest_expense_account: Account = LowLevelAccounts.FEES_AND_INTEREST_EXPENSE_ACCOUNT
    interest_income_account: Account = LowLevelAccounts.INTEREST_INCOME_ACCOUNT
    cash_balance_account: Account = HighLevelAccounts.CASH_BALANCE_ACCOUNT
    assert credit_card_account.type == AccountType.LIABILITIES

# Generated at 2022-06-24 01:02:51.125687
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    print("JournalEntry.ReadJournalEntries.Test")

    rje: ReadJournalEntries = lambda x: "rje"
    assert rje(DateRange.EMPTY) == "rje"

# Generated at 2022-06-24 01:02:58.785809
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate(): #pylint: disable=C0103
    """
    Unit test for method validate of class JournalEntry
    """
    journal = JournalEntry(datetime.date(2020, 8, 6), "An entry", "A source")
    journal.post(datetime.date(2020, 8, 6), Account("Assets", AccountType.ASSETS), Quantity(10.0))
    journal.post(datetime.date(2020, 8, 6), Account("Revenue", AccountType.REVENUES), Quantity(-10.0))
    journal.validate()

# Generated at 2022-06-24 01:03:10.494312
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je1 = JournalEntry(datetime.date(2016, 1, 1), "test", None, [
        Posting(None, datetime.date(2016, 1, 1), Account(AccountType.ASSETS, "A1"), Direction.INC, Amount(1.1)),
        Posting(None, datetime.date(2016, 1, 1), Account(AccountType.EQUITIES, "E1"), Direction.DEC, Amount(1.1))
    ])

# Generated at 2022-06-24 01:03:13.265658
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry[str]("2020-06-20", "A test journal entry", "A test journal source")) == "<JournalEntry at 0x7feedc350610>"

# Generated at 2022-06-24 01:03:24.253450
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from unittest import TestCase

    class _T(TestCase):
        def test_read_journal_entries(self):
            from ddddd.commons.zeitgeist import DateRange
            from datetime import date

            from .accounts import Account, AccountType
            from .currency import Currency
            from .journal import JournalEntry, Posting, ReadJournalEntries, Direction

            _Currency = Currency('PLN')
            _Account = Account('Cash', AccountType.ASSETS)


# Generated at 2022-06-24 01:03:27.182573
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass



# Generated at 2022-06-24 01:03:38.364464
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(
        Posting(
            JournalEntry(datetime.date.today(), "", None),
            datetime.date.today(),
            Account("bank", AccountType.ASSETS),
            Direction.INC,
            Amount(100),
        )
    ) == "Posting(journal=JournalEntry(date=datetime.date(2020, 1, 22), description='', source=None, guid='0dd6-a8a2-f2b3-0481-90f1-8f36-3dbc-cdc1'), date=datetime.date(2020, 1, 22), account=Account(code='bank', type=<AccountType.ASSETS: 'Assets'>), direction=<Direction.INC: 1>, amount=100)"


# Generated at 2022-06-24 01:03:45.887001
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # Case 1:
    account = Account("Account")
    journal = JournalEntry[account](
            datetime.date(2020, 8, 1),
            "Journal entry",
            account
        )
    posting = Posting[account](
        journal,
        datetime.date(2020, 8, 1),
        account,
        Direction.INC,
        Amount(1)
    )

# Generated at 2022-06-24 01:03:47.176991
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    j = JournalEntry()
    s = {j, j}
    assert len(s) == 1

# Generated at 2022-06-24 01:03:52.433276
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .business import ConcreteBusiness
    from .accounts import Accounts

    ### Create a business:
    a_business = ConcreteBusiness.create(Guid(), "My business")
    aditya = a_business.list_participants()[0]

    ### Create accounting:
    accounts = Accounts(a_business)

    ### Create a journal entry:
    je = JournalEntry(datetime.date.today(), "A journal entry")
    je.post(je.date, accounts.cash_account, 1000)
    je.post(je.date, accounts.equity_account, 1000)

    ### Validate the journal entry:
    assert je.debits
    assert je.credits
    je.validate()
    je2 = JournalEntry(datetime.date.today(), "A journal entry")

# Generated at 2022-06-24 01:04:04.159775
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Given
    date = datetime.date.today()
    description = "Test Journal Entry"
    source = "Test Source"
    account_1 = Account("Test Account 1", AccountType.ASSETS, "Test Account 1 Description")
    account_2 = Account("Test Account 2", AccountType.EQUITIES, "Test Account 2 Description")
    account_3 = Account("Test Account 3", AccountType.LIABILITIES, "Test Account 3 Description")
    account_4 = Account("Test Account 4", AccountType.REVENUES, "Test Account 4 Description")
    account_5 = Account("Test Account 5", AccountType.EXPENSES, "Test Account 5 Description")
    amount = Amount(1000.00)

    # When
    journal = JournalEntry(date, description, source)

# Generated at 2022-06-24 01:04:10.071240
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    # Test case:
    assert 100 + 0 == 100
    # Test case:
    assert 100 == 100
    # Test case:
    assert 100 + 1 == 101
    # Test case:
    assert 1 - 100 == -99
    # Test case:
    assert 100 + -100 == 0
    # Test case:
    assert 1 == -1 + 2
    # Test case:
    assert 100 + -100 == 100 - 100

# Generated at 2022-06-24 01:04:10.656175
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert True

# Generated at 2022-06-24 01:04:21.834349
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account
    from .events import create_events
    account_a = Account("Assets", AccountType.ASSETS)
    account_b = Account("Debts", AccountType.LIABILITIES)
    amount = 10
    last_date = datetime.date(2020, 1, 1)
    je = create_events(last_date).create_journal_entry(description="Dividends")
    je.post(date=last_date, account=account_a, quantity=amount)
    je.post(date=last_date, account=account_b, quantity=0 - amount)
    posting = Posting(journal=je, date=last_date, account=account_a, direction=Direction.INC, amount=Amount(amount))
    assert posting.is_debit == True

# Generated at 2022-06-24 01:04:25.937411
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Setup:
    date = datetime.date(2020, 1, 1)
    description = "Testing"
    source = (1,)
    guid = Guid()

    # Exercise:
    journal = JournalEntry[tuple](date, description, source, guid = guid)

    # Verify:
    assert journal.date == date
    assert journal.description == description
    assert journal.source == source
    assert journal.guid == guid
    assert journal.postings == []


# Generated at 2022-06-24 01:04:29.571830
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    journalEntry = JournalEntry[str](datetime.date(2020,1,1), "1", "1")
    journalEntry.postings = ["1"]

    assert journalEntry.postings == ["1"]

# Generated at 2022-06-24 01:04:32.407270
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    # Arrange
    assert hasattr(Posting, "journal")
    # Act
    del Posting.journal
    # Assert
    assert not hasattr(Posting, "journal")


# Generated at 2022-06-24 01:04:34.420044
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    source = dataclass(frozen=True)(a=1,b=2)
    JE = JournalEntry(1, 'description',source,[])
    assert JE.date == 1
    assert JE.description == 'description'
    assert JE.source == source
    assert JE.postings == []
    assert len(str(JE.guid)) == 36

# Generated at 2022-06-24 01:04:40.832255
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    test_source_object=object()
    date = datetime.date.today()
    test_account = Account("test", "test", AccountType.ASSETS)
    test_direction = Direction.DEC
    test_amount = 20
    test_posting = Posting(test_source_object, date, test_account, test_direction, test_amount)
    assert(hash(test_posting) == hash((test_source_object, date, test_account, test_direction, test_amount)))


# Generated at 2022-06-24 01:04:42.784904
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    assert hash(JournalEntry("2019-01-01","desc",2,3)) == hash("2019-01-01 desc 2 3")

# Generated at 2022-06-24 01:04:44.428421
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    je = JournalEntry(datetime.date.today(), "test", None)
    try:
        delattr(je, "date")
    except AttributeError:
        pass
    else:
        raise AssertionError("Expected AttributeError")



# Generated at 2022-06-24 01:04:46.468351
# Unit test for constructor of class Posting
def test_Posting():
    obj = Posting("journal", "date", "account", "direction", "amount")
    assert obj.journal == "journal"
    assert obj.date == "date"
    assert obj.account == "account"
    assert obj.direction == "direction"
    assert obj.amount == "amount"


# Generated at 2022-06-24 01:04:53.603079
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from ...book.book import Book
    from ...book.ledger import Ledger

    # Arrange:
    book: Book = Book()
    ledger: Ledger = book.create_ledger("Test")

    account1 = ledger.create_account("bank1", AccountType.ASSETS, "XYZ Bank 1")
    account2 = ledger.create_account("bank2", AccountType.ASSETS, "XYZ Bank 2")

    account3 = ledger.create_account("revenue1", AccountType.REVENUES, "Revenue 1")
    account4 = ledger.create_account("revenue2", AccountType.REVENUES, "Revenue 2")

    # Act (1):
    j1: JournalEntry = JournalEntry("2019-01-02", "First entry", None)

# Generated at 2022-06-24 01:05:05.936861
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    import datetime
    from dataclasses import _field_repr, _is_dataclass
    from abc import ABC

    # Set up JournalEntry class
    class A(ABC):
        pass

    B = type("B", (A,), {})

    @dataclass
    class JournalEntry(B):
        date: datetime.date
        description: str
        source: Guid
        postings: List["Posting"] = field(default_factory=list, init=False)

    # Set up Posting class
    @dataclass
    class Posting:
        journal: "JournalEntry"
        date: datetime.date
        account: "Account"
        direction: "Direction"
        amount: Amount

    # Set up Account class
    @dataclass
    class Account:
        name: str
        type

# Generated at 2022-06-24 01:05:13.137437
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting[str](None, datetime.date(2020, 1, 20), Account("A"), Direction.INC, Amount(1)) == \
           Posting[str](None, datetime.date(2020, 1, 20), Account("A"), Direction.INC, Amount(1))

    assert tuple(Posting[str](None, datetime.date(2020, 1, 20), Account("A"), Direction.INC, Amount(1))
                 .__eq__(Posting[str](None, datetime.date(2020, 1, 20), Account("A"), Direction.INC, Amount(1))))



# Generated at 2022-06-24 01:05:21.183271
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    """
    Test for constructor of JournalEntry class.
    """
    # Arrange
    date = datetime.date(2020, 1, 1)
    description = "Test Entry for Journal Entry"
    source = f"Test Journal Entry Source"
    journal_entry = JournalEntry(date, description, source)

    # Act
    # Nothing.

    # Assert
    assert journal_entry.date == date
    assert journal_entry.description == description
    assert journal_entry.source == source
    assert journal_entry.postings == []


# Generated at 2022-06-24 01:05:29.924948
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert post.journal == JournalEntry(datetime.date.today(), "I journal test", "I am source")
    assert post.date == datetime.date.today()
    assert post.account == Account(AccountType.REVENUES,"其它收入")
    assert post.direction == Direction.INC
    assert post.amount == Amount(10)
    assert post.is_debit == False
    assert post.is_credit == True
    assert post2.is_debit == True
    assert post2.is_credit == False
    assert post3.direction == Direction.DEC
    assert j.date == datetime.date.today()
    assert j.postings == [post,post2,post3]
    assert j.postings[1].journal == j

# Generated at 2022-06-24 01:05:35.874199
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import get_accounts

    voucher = JournalEntry()
    voucher.post(datetime.date(2020, 1, 1), get_accounts().get("Receivables"), 100).post(
        datetime.date(2020, 2, 1), get_accounts().get("Cash"), -100
    ).validate()

# Generated at 2022-06-24 01:05:43.363515
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    class Source:
        def __init__(self, x):
            self.x = x

    d = datetime.date(2016, 1, 1)
    j1 = JournalEntry[Source](d, "Journal 1", Source(1))
    j2 = JournalEntry[Source](d, "Journal 2", Source(2))
    j3 = JournalEntry[Source](d, "Journal 3", Source(3))

    p1 = Posting(j1, d, Account.of("assets"), Direction.INC, Amount(10))
    p2 = Posting(j1, d, Account.of("assets"), Direction.INC, Amount(10))
    p3 = Posting(j2, d, Account.of("assets"), Direction.INC, Amount(10))

# Generated at 2022-06-24 01:05:54.926237
# Unit test for constructor of class Posting
def test_Posting():
    account = Account("TestAccount","ACT")
    source = "TestObject"
    journalEntry = JournalEntry(datetime.date.today(), "TestDescription", source)
    posting = Posting(journalEntry, datetime.date.today(), account, Direction.INC, Amount(0))
    assert posting.journal == journalEntry
    assert posting.date == datetime.date.today()
    assert posting.account == account
    assert posting.direction == Direction.INC
    assert posting.amount == Amount(0)
    assert posting.is_debit == (account.type in _debit_mapping[Direction.INC])
    assert posting.is_credit == (account.type not in _debit_mapping[Direction.INC])


# Generated at 2022-06-24 01:05:57.908080
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry[object]("NA", "NA", "NA")
    je.post("NA", "NA", 15)
    je.post("NA", "NA", -15)
    je.validate()

# Generated at 2022-06-24 01:06:03.497728
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry(datetime.date.today(), "description", "source")) == (
        f"JournalEntry(date={datetime.date.today()}, description='description', source='source', postings=[], "
        "guid="
        f"'{makeguid()}')"
    )


# Generated at 2022-06-24 01:06:10.953480
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    a = JournalEntry("2019-11-18", "journal1", "source1")
    b = JournalEntry("2019-11-18", "journal2", "source2")
    c = JournalEntry("2019-11-18", "journal1", "source2")
    d = JournalEntry("2019-11-19", "journal1", "source1")
    
    value = {"a":a,"b":b,"c":c,"d":d}
    print(value["a"])
    print(value["b"])
    print(value["c"])
    print(value["d"])

if __name__ == "__main__":
    test_JournalEntry___hash__()

# Generated at 2022-06-24 01:06:12.395324
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    pass


# Test case for method post of class JournalEntry

# Generated at 2022-06-24 01:06:20.290551
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import Account, AccountType
    from .journal.core import ReadJournalEntries
    from .journal.core import JournalEntry, Posting

    # Helper function to create a journal entry
    def make_journal_entry() -> JournalEntry:
        def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
            pass

        # create account and journal entry
        account = Account("account", AccountType.UNKNOWN)
        journal = JournalEntry(date=datetime.date(2020, 9, 1), description='Booking a flight',
                               source=read_journal_entries)
        # create a posting and append to journal entry
        posting = Posting(journal, datetime.date(2020, 9, 1), account, Direction.INC, Amount(100.00))

# Generated at 2022-06-24 01:06:22.291911
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    je1 = JournalEntry("1", "2", "3")
    je2 = JournalEntry("1", "2", "3")
    assert je1 == je2
    return

# Generated at 2022-06-24 01:06:27.234762
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    """
    Test to ensure that JournalEntry doesn't allow deletion of its attributes.
    """
    je = JournalEntry[None](datetime.date(2020, 1, 1), "Test", None)
    try:
        delattr(je, "date")
    except TypeError:
        pass
    else:
        raise AssertionError("Failed to prevent deletion of a JournalEntry attribute!")

# Generated at 2022-06-24 01:06:33.107396
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import Account, AccountType
    post1 = Posting("journal", datetime.date(2020, 2, 1), Account("name","type"), Direction.INC, Amount(1234))
    post2 = Posting("journal", datetime.date(2020, 2, 1), Account("name","type"), Direction.INC, Amount(1234))
    assert post1 == post2


# Generated at 2022-06-24 01:06:44.607347
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account
    from .currencies import Currency
    from .exchange import ExchangeRate
    from .exchange import ExchangeRates
    from decimal import Decimal

    exchange = ExchangeRates()
    exchange.add(ExchangeRate(Currency.USD, Currency.INR, Decimal(70.4)))
    exchange.add(ExchangeRate(Currency.INR, Currency.USD, Decimal(.014)))

    from .general import General

    income_account = Account(name="Income", type=AccountType.REVENUES, currency=Currency.USD)
    expense_account = Account(name="Expense", type=AccountType.EXPENSES, currency=Currency.INR)

    def setup():
        general = General(exchange)
        general.create_account(income_account)
       

# Generated at 2022-06-24 01:06:52.305753
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # set a read-only attribute
    try:
        Posting(None, datetime.date.today(), None, None, Amount(0)).journal = None
        assert False, "Should fail on attempting to set a read-only attribute for a Posting."
    except Exception:
        pass

    # set a regular attribute
    try:
        Posting(None, datetime.date.today(), None, None, Amount(0)).something = None
        assert False, "Should fail on attempting to set an attribute which doesn't exist on a Posting."
    except Exception:
        pass



# Generated at 2022-06-24 01:07:00.608829
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    obj = JournalEntry(
        date=datetime.date(year=2018, month=1, day=1),
        description='d',
        source=None,
        postings=[Posting(
            journal=None,
            date=datetime.date(year=2018, month=1, day=1),
            account=Account(
                guid='123',
                name='n',
                description='d',
                type=AccountType.ASSETS),
            direction=Direction.INC,
            amount=Amount(1)
        )]
    )
    assert repr(obj) == "JournalEntry(date=2018-01-01, description='d')"


# Generated at 2022-06-24 01:07:05.859522
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    j = JournalEntry(date="2012-03-03", description="test", source="source")
    p = Posting(j, date="2012-03-03", account=12, direction=1, amount=12)
    # delete journal
    del p.journal
    assert not hasattr(p, 'journal')
    # delete date
    with pytest.raises(AttributeError):
        del p.date
    # delete account
    with pytest.raises(AttributeError):
        del p.account
    # delete direction
    with pytest.raises(AttributeError):
        del p.direction
    # delete amount
    with pytest.raises(AttributeError):
        del p.amount


# Generated at 2022-06-24 01:07:11.283378
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(None, datetime.date(2020, 8, 2), Account("A", AccountType.ASSETS), Direction.INC, Amount(100.50)) == Posting(None, datetime.date(2020, 8, 2), Account("A", AccountType.ASSETS), Direction.INC, Amount(100.50))
    assert not (Posting(None, datetime.date(2020, 8, 2), Account("A", AccountType.ASSETS), Direction.INC, Amount(100.50)) == Posting(None, datetime.date(2020, 8, 2), Account("A", AccountType.ASSETS), Direction.INC, Amount(101.50)))

# Generated at 2022-06-24 01:07:17.082759
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    je = JournalEntry[str]('2020-01-01', 'test', 'test')
    init_postings = len(je.postings)
    je.post(datetime.date(2020, 1, 1), Account('test', '0', 'test', AccountType.ASSETS), Quantity(1))
    assert init_postings + 1 == len(je.postings)

# Generated at 2022-06-24 01:07:27.846764
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from .accounts import Account
    from datetime import date
    acct1 = Account('Assets:Cash','Assets','Asset')
    acct2 = Account('Expenses:Phone','Expenses','Expense')
    je = JournalEntry(date(2018, 4, 26), "Water bill", "Water bill payment",
                                 [Posting(je, date(2018, 4, 26), acct1, Direction.DEC, Amount(100)),
                                  Posting(je, date(2018, 4, 26), acct2, Direction.INC, Amount(100))])

# Generated at 2022-06-24 01:07:35.029431
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    """ Unit test for constructor of JournalEntry"""
    from .accounts import Assets, Expenses
    jeg = JournalEntry(
        date=datetime.date(2018, 1, 1),
        description="Cash withdrawal for meeting",
        source=Assets(
            guid="38a71aae-b2a1-11e8-96f8-529269fb1459"
        ),
    )\
    .post(datetime.date(2018, 1, 1), Expenses(guid="38a71aae-b2a1-11e8-96f8-529269fb1460"), 1000.0)
    print(jeg)

# Generated at 2022-06-24 01:07:39.368980
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from .accounts import Account
    from .products import Product
    from .taxes import Tax
    from .transactions import Transaction, TransactionType
    from .commons.zeitgeist import date

    product = Product(name="Product A", guid="aa")
    tax = Tax(name="Tax A", rate=0.1, guid="bb")
    income = Account(name="Sales Income", type=AccountType.REVENUES, guid="cc")
    taxes = Account(name="Sales Taxes", type=AccountType.EXPENSES, guid="dd")
    assets = Account(name="Assets", type=AccountType.ASSETS, guid="ee")


# Generated at 2022-06-24 01:07:43.223300
# Unit test for constructor of class Posting
def test_Posting():
    journal = JournalEntry("Test")
    date = datetime.date(2020, 1, 1)
    account = AccountType.ASSETS
    direction = Direction.INC
    amount = Amount(100)

    posting = Posting(journal, date, account, direction, amount)

    assert posting.journal == journal
    assert posting.date == date
    assert posting.account == account
    assert posting.direction == direction
    assert posting.amount == amount
