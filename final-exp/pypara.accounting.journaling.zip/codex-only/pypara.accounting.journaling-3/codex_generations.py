

# Generated at 2022-06-24 00:57:46.244245
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journal_entry_1 = JournalEntry(datetime.date.today(), "Test", "0")
    journal_entry_2 = JournalEntry(datetime.date.today(), "Test", "0")
    journal_entry_3 = JournalEntry(datetime.date.today(), "Test", "1")
    assert journal_entry_1 == journal_entry_2, "__eq__ is not implemented correctly"
    assert journal_entry_3 != journal_entry_2, "__eq__ is not implemented correctly"



# Generated at 2022-06-24 00:57:49.872891
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    d = datetime.date.today()
    je1 = JournalEntry[str]("hello", d, "abc")
    je2 = JournalEntry[str]("hello", d, "abc")
    assert hash(je1) == hash(je2)


# Generated at 2022-06-24 00:57:57.978422
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    import datetime
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType

    #: Date of the entry.
    date: datetime.date
    #: Description of the entry.
    description: str
    #: Business object as the source of the journal entry.
    source: 1
    #: Postings of the journal entry.
    postings: List[Posting[1]]
    #: Globally unique, ephemeral identifier.
    guid: Guid
    date = datetime.date(1,1,1)
    description = 'a'
    guid = makeguid()

    # The total amout of all postings must be zero
    # 4 posting should be created
    # As the quantity is 10000, the absolute value of it is 10000

# Generated at 2022-06-24 00:58:03.931348
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def read_journal_entries(period):
        return [JournalEntry(date=datetime.date(2020,11,26), description='test description 1', source=1),
                JournalEntry(date=datetime.date(2020,11,26), description='test description 2', source=2)]

    read_journal_entries = ReadJournalEntries.__getitem__(dict, ReadJournalEntries[JournalEntry])
    assert isinstance(read_journal_entries, ReadJournalEntries[JournalEntry])
    assert '__module__' in dir(read_journal_entries)
    assert '__annotations__' in dir(read_journal_entries)
    assert read_journal_entries.__module__ == 'ledger.repositories.journal.__init__'
    assert read_journal_entries.__annotations__

# Generated at 2022-06-24 00:58:11.780776
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange

    # Given a journal entry
    journal_entry = JournalEntry[None]('2020-01-01', 'Transaction 1')

    # When we post an amount to an account
    journal_entry.post('2020-01-02', Account('1050', 'Cash', AccountType.ASSETS), 100)

    # Then postings has two entries
    assert len(journal_entry.postings) == 1

# Generated at 2022-06-24 00:58:20.495854
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Setup
    je = JournalEntry(
        datetime.date(2020, 1, 1),
        "Some description",
        object(),
    )

    # Exercise and Verify
    je.validate()
    je.post(datetime.date(2020, 1, 1), Account(AccountType.CASH, 'CASH'), Quantity(10))
    je.validate()
    je.post(datetime.date(2020, 1, 1), Account(AccountType.EXPENSES, 'EXPENSES'), Quantity(-10))
    je.validate()

# Generated at 2022-06-24 00:58:23.844809
# Unit test for constructor of class Posting
def test_Posting():
    a = Posting(None, None, None, None, None)
    assert a.journal == None
    assert a.date == None
    assert a.account == None
    assert a.direction == None
    assert a.amount == None


# Generated at 2022-06-24 00:58:26.409083
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    post1 = Posting(None, None, None, None, None)
    post2 = Posting(None, None, None, None, None)
    assert hash(post1) == hash(post2)

# Generated at 2022-06-24 00:58:37.475545
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    assert hash(JournalEntry[None](datetime.date.today(), "desc", None)) == hash(
        JournalEntry[None](datetime.date.today(), "desc", None))

# Generated at 2022-06-24 00:58:38.768315
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    pass

# Generated at 2022-06-24 00:58:48.013145
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import AssetAccount, ExpenseAccount
    from .accounts import AccountType
    from .accounts import AccountRepository
    from .currencies import USD, CurrencyRepository
    from .entities import BusinessEntity
    from .entities import BusinessEntityRepository

    a1 = AssetAccount(AccountType.ASSETS, "1", "Account1", USD)
    a2 = ExpenseAccount(AccountType.EXPENSES, "2", "Account2", USD)

    account_repo = AccountRepository(currency_repo=CurrencyRepository())
    account_repo.add(a1)
    account_repo.add(a2)

    b1 = BusinessEntity(uuid="1", name="Business Entity")
    b2 = BusinessEntity(uuid="2", name="Business Entity 2")
    b_repo

# Generated at 2022-06-24 00:58:55.286366
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(datetime.date(2020, 1, 1), 
                            'Journal Entry for Account 3 and Account4', 
                            Guid('2b74a9f9-7587-4b19-a386-e600981f5721'))
    journal.post(datetime.date(2020, 1, 1), Account(Guid('0dda1678-7b6d-49c2-9549-9b9467c8b811'), 'Account 3'), Amount(5))
    journal.post(datetime.date(2020, 1, 1), Account(Guid('acb5be7f-17ee-4ba7-a4f4-4c49ad9cc0e9'), 'Account 4'), Amount(5))
    print(journal.increments)
    #validate the journal entry


# Generated at 2022-06-24 00:59:06.202612
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    j1 = JournalEntry(date=datetime.date(year=2019, month=5, day=13),
                      description="j1",
                      source="j1")
    p1 = Posting(j1,
                 date=datetime.date(year=2019, month=5, day=13),
                 account=Account.from_string("Equity:Opening Balances"),
                 direction=Direction.INC,
                 amount=Amount(quantity=100))
    p2 = Posting(j1,
                 date=datetime.date(year=2019, month=5, day=13),
                 account=Account.from_string("Equity:Opening Balances"),
                 direction=Direction.INC,
                 amount=Amount(quantity=100))

# Generated at 2022-06-24 00:59:15.573357
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    guid="e2e6a981-d0fb-4b2f-8835-ac51b7d9a9a4"
    guid1="e2e6a981-d0fb-4b2f-8835-ac51b7d9a9a4"
    guid2="e2e6a981-d0fb-4b2f-8835-ac51b7d9a9a5"
    guid3="e2e6a981-d0fb-4b2f-8835-ac51b7d9a9a4"
    journal="journal"
    journal1="journal1"
    journal2="journal2"
    date=datetime.datetime(2018,1,1)
    date1=datetime.datetime(2018,1,1)
   

# Generated at 2022-06-24 00:59:23.756833
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    j1 = JournalEntry(datetime.date(2020, 1, 1), "journal1", "source1")
    j1.post(datetime.date(2020, 1, 1), Account("Account1", AccountType.EXPENSES), -100)

    assert (j1.postings[0].date == datetime.date(2020, 1, 1))
    assert (j1.postings[0].account.name == "Account1")
    assert (j1.postings[0].account.type == AccountType.EXPENSES)
    assert (j1.postings[0].direction == Direction.DEC)
    assert (j1.postings[0].amount == 100)



# Generated at 2022-06-24 00:59:35.403089
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    """
    Unit test for method '__eq__' of class JournalEntry.
    """
    account1 = Account("1", "name1", AccountType.ASSETS)
    account2 = Account("2", "name2", AccountType.LIABILITIES)

    journal1 = JournalEntry("source1")
    journal2 = JournalEntry("source2")

    journal1Posting1 = Posting(journal1, datetime.date(2020, 1, 1), account1, Direction.INC, 1)
    journal1Posting2 = Posting(journal1, datetime.date(2020, 1, 1), account2, Direction.DEC, 1)
    journal1.postings.append(journal1Posting1)
    journal1.postings.append(journal1Posting2)


# Generated at 2022-06-24 00:59:40.324617
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # Because class ReadJournalEntries is a Protocol.
    assert issubclass(ReadJournalEntries, Protocol)

    # Because class ReadJournalEntries has a special method __call__
    assert isinstance(ReadJournalEntries.__call__, type)

    # Because the __call__ method of class ReadJournalEntries is a type annotation.
    assert Callable[[DateRange], Iterable[JournalEntry[_T]]] == \
           ReadJournalEntries.__call__.__annotations__['return']

# Generated at 2022-06-24 00:59:46.168427
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(JournalEntry('test', 'test', 'test', 'test', 'test'), 1, 1, 1, 1) == Posting(JournalEntry('test', 'test', 'test', 'test', 'test'), 1, 1, 1, 1)


# Generated at 2022-06-24 00:59:46.641425
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    pass

# Generated at 2022-06-24 00:59:49.072083
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    r: ReadJournalEntries[str] = lambda p: []
    assert r.__call__(None) is not None
    # TODO: Need to implement this test

# Generated at 2022-06-24 00:59:58.557038
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account, AccountType
    from .books import Book, BookFactory
    from .commons.zeitgeist import Date
    from .currencies import Currencies
    from .tags import Tag
    book = BookFactory(Book("My Book"))
    book.open(Currencies.get("INR"), Date(2018, 1, 1))
    book.master_journal.post(Date(2018, 1, 1), "a", """
        Assets:Bank:Current-Account   +10000
        Equity:Opening-Balances      -10000
    """)
    book.master_journal.post(Date(2018, 1, 1), "a", """
        Expenses:Business:Salary     -10000
        Liabilities:Loans:Borrowings +10000
    """)

# Generated at 2022-06-24 01:00:02.327401
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    """
    Checks the method __hash__ from class JournalEntry
    """
    journal = JournalEntry(datetime.date.today(), "This is a description", str(makeguid()))
    journal.post(datetime.date.today(), Account(AccountType.ASSETS, "Account assets", None), 100)
    hash_value = journal.__hash__()
    assert isinstance(hash_value, int)

# Generated at 2022-06-24 01:00:08.327380
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    ledger = JournalEntry[object]
    ledgers = [ledger(date=datetime.date(2018, 12, 18),
                 description="Entry 1",
                 source=None)]

    ledger2 = JournalEntry[object]
    ledgers.append(ledger2(date=datetime.date(2018, 12, 18),
                 description="Entry 1",
                 source=None))

    assert ledger.__hash__() == ledger2.__hash__()

# Generated at 2022-06-24 01:00:15.586976
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    import datetime

    from .accounts import AccountType
    from .accounts import Account

    # 1. ARRANGE
    from .currency import Currency
    from ultron8.api import settings
    settings.CURRENCY = "EUR"
    settings.HOME_CURRENCY = "EUR"
    settings.CURRENCIES["EUR"] = Currency(code="EUR", symbol="€", numeric="978", precision=2)

    # CREATE ACCOUNTS
    assets = Account(name="Assets", type=AccountType.ASSETS)
    liabilities = Account(name="Liabilities", type=AccountType.LIABILITIES)
    revenues = Account(name="Revenues", type=AccountType.REVENUES)
    expenses = Account(name="Expenses", type=AccountType.EXPENSES)

# Generated at 2022-06-24 01:00:25.957350
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from collections import namedtuple
    TestClass = namedtuple('TestClass', 'journal date account direction amount')
    TestClass.__repr__ = lambda self: 'TestClass(journal=%r, date=%r, account=%r, direction=%r, amount=%r)' % self

    test_obj = TestClass('journal', 'date', 'account', 'direction', 'amount')
    assert 'TestClass(journal=%r, date=%r, account=%r, direction=%r, amount=%r)' % test_obj == test_obj.__repr__()

    test_obj = TestClass(None, 'date', 'account', 'direction', 'amount')

# Generated at 2022-06-24 01:00:31.801023
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from datetime import date, timedelta
    from .accounts import Account, AccountType, CreateAccounts

    #: Data for testing:
    data = [
        (date(2020, 3, 1), "Opening Balance", Account("X"), Amount(10_000)),
        (date(2020, 3, 2), "Purchase", Account("R"), Amount(1_000)),
        (date(2020, 3, 3), "Sales", Account("X"), Amount(2_000)),
        (date(2020, 3, 4), "Closing Balance", Account("X"), Amount(7_000)),
    ]


    #: Define a type alias:
    Entry = JournalEntry[_T]


    #: Define a function to generate journal entries:

# Generated at 2022-06-24 01:00:42.186748
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journal_entry1=JournalEntry(date=1,description='journal_entry1' ,source=1)
    journal_entry2=JournalEntry(date=1,description='journal_entry1' ,source=1)
    assert journal_entry1==journal_entry2
    journal_entry3=JournalEntry(date=1,description='journal_entry2' ,source=1)
    assert journal_entry1!=journal_entry3
    journal_entry4=JournalEntry(date=1,description='journal_entry1' ,source=2)
    assert journal_entry1!=journal_entry4
    journal_entry5=JournalEntry(date=2,description='journal_entry1' ,source=1)
    assert journal_entry1!=journal_entry5
#-----------------------------------------------------------------------------

# Generated at 2022-06-24 01:00:53.834906
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():

    journalInput = JournalEntry(
        date=datetime.date(2020, 5, 10),
        description="Debit/Credit does not match",
        source=datetime.datetime(2020, 5, 10)
    )
    journalInput.post(
        date=datetime.date(2020, 5, 10),
        account=Account(number=1, name="Test", type=AccountType.ASSETS),
        quantity=Amount(100)
    )

    journalInput.post(
        date=datetime.date(2020, 5, 10),
        account=Account(number=2, name="Test", type=AccountType.LIABILITIES),
        quantity=Amount(100)
    )

# Generated at 2022-06-24 01:01:05.298415
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Case: all postings balance.
    entry = JournalEntry[None](
        datetime.date(2020, 1, 1), "A", None
    ).post(
        datetime.date(2020, 1, 1), Account("A", AccountType.ASSETS), 1000.00
    ).post(
        datetime.date(2020, 1, 1), Account("B", AccountType.EXPENSES), 1000.00
    )
    entry.validate()

    # Case: postings do not balance.

# Generated at 2022-06-24 01:01:10.879351
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    j1 = JournalEntry(datetime.date.today(), 'entry1', None)
    j2 = JournalEntry(datetime.date.today(), 'entry1', None)
    j3 = JournalEntry(datetime.date.today(), 'entry2', None)

    assert j1 == j2
    assert j1 != j3


# Generated at 2022-06-24 01:01:14.312129
# Unit test for constructor of class ReadJournalEntries

# Generated at 2022-06-24 01:01:21.750406
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    #Arrange
    journal_entry = JournalEntry[Posting(1)]
    #Act
    posting = Posting(journal_entry, datetime.date(2020, 2, 3), "Posting2", 3)
    posting2 = Posting(journal_entry, datetime.date(2020, 2, 3), "Posting2", 3)
    posting3 = Posting(journal_entry, datetime.date(2020, 2, 3), "Posting2", 3)
    posting4 = Posting(journal_entry, datetime.date(2020, 2, 3), "Posting", 3)
    posting5 = Posting(journal_entry, datetime.date(2020, 2, 3), "Posting2", 4)

# Generated at 2022-06-24 01:01:25.725403
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    h1 = {1, 2, 3}
    h2 = {3, 4, 5}
    h3 = h1.union(h2)
    h1.add(6)
    print(h1)
    print(h2)
    print(h3)

# Generated at 2022-06-24 01:01:30.360329
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    je1 = JournalEntry(datetime.date.today(), "test", 1)
    je2 = JournalEntry(datetime.date.today(), "test", 1)
    p1 = je1.post(datetime.date.today(), Account("1234"), 1)
    p2 = je2.post(datetime.date.today(), Account("1234"), 1)

    assert p1 == p2

# Generated at 2022-06-24 01:01:38.140811
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    test_obj = object()

    @dataclass(frozen=True)
    class MockData:
        period: DateRange
        result: List[JournalEntry[object]]

    data = [
        MockData(DateRange(datetime.date(2020, 9, 1), datetime.date(2020, 11, 30)), []),
        MockData(DateRange(datetime.date(2020, 9, 1), datetime.date(2020, 12, 31)), [JournalEntry(datetime.date(2020, 12, 31), "Test", test_obj)]),
    ]

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[object]]:
        for item in data:
            if period == item.period:
                return item.result


# Generated at 2022-06-24 01:01:43.894387
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journalEntry = JournalEntry(datetime.date.today(), "Test", "Source")
    posting = Posting(journalEntry, datetime.date.today(), Account('Assets', AccountType.ASSETS,1), Direction.INC, Amount(1000))
    assert posting.__hash__() == -1765189745

# Generated at 2022-06-24 01:01:47.725799
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journal1 = JournalEntry("Test", "Test", JournalEntry("Test", "Test", "Test"))
    journal2 = JournalEntry("Test", "Test", JournalEntry("Test", "Test", "Test"))
    assert hash(journal1) == hash(journal2)

# Generated at 2022-06-24 01:01:56.871465
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import AccountType
    assert Posting(JournalEntry, datetime.date.fromisoformat('2020-01-01'), Account('ASSET01', AccountType.ASSETS), Direction.INC, Amount(11)) == Posting(JournalEntry, datetime.date.fromisoformat('2020-01-01'), Account('ASSET01', AccountType.ASSETS), Direction.INC, Amount(11))
    assert Posting(JournalEntry, datetime.date.fromisoformat('2020-01-01'), Account('ASSET01', AccountType.ASSETS), Direction.INC, Amount(11)) != Posting(JournalEntry, datetime.date.fromisoformat('2020-01-02'), Account('ASSET01', AccountType.ASSETS), Direction.INC, Amount(11))

# Generated at 2022-06-24 01:02:01.686415
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    assert isinstance(read_journal_entries, ReadJournalEntries[_T])

# Generated at 2022-06-24 01:02:07.163321
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Without direction sign
    je = JournalEntry[int](datetime.date.today(), "Testing #01", 1)
    je = je.post(je.date, Account.ASSETS, +10)
    je = je.post(je.date, Account.EQUITIES, +1)
    je = je.post(je.date, Account.LIABILITIES, -1)
    je = je.post(je.date, Account.REVENUES, -10)
    je = je.post(je.date, Account.EXPENSES, -1)
    assert je.postings[0].direction == Direction.INC
    assert je.postings[1].direction == Direction.INC
    assert je.postings[2].direction == Direction.DEC
    assert je.postings[3].direction == Direction.DEC
    assert je.postings

# Generated at 2022-06-24 01:02:11.077742
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    print()
    #: Date of the entry.
    date = datetime.date
    #: Description of the entry.
    description = "description A"
    a = JournalEntry(date, description)
    print(a.postings)
    print(a.__repr__())

# Generated at 2022-06-24 01:02:18.274248
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    @dataclass
    class Revenue:
        pass

    # Create a JournalEntry instance
    journalEntry = JournalEntry(datetime.date.today(),
                                "A basic JournalEntry",
                                Revenue())

    # Check if the instance is created properly
    assert journalEntry.date
    assert journalEntry.description
    assert journalEntry.source
    assert isinstance(journalEntry.postings, list)
    assert isinstance(journalEntry.guid, Guid.__class__)



# Generated at 2022-06-24 01:02:22.407052
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    p = Posting(makeguid(), datetime.date.today(), "", "", Direction.INC, 0)
    p.guid = makeguid()
    p.date = datetime.date.today()
    p.account = ""
    p.direction = Direction.INC
    p.amount = 0

# Generated at 2022-06-24 01:02:31.016462
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account_assets = Account("Assets")
    account_revenues = Account("Revenues")
    j = JournalEntry("EMPTY", datetime.date(1970, 1, 1), source=None)
    j.post(datetime.date(2018, 1, 1), account_assets, Quantity(1000))
    j.post(datetime.date(2018, 1, 1), account_revenues, Quantity(-1000))
    j.validate()

    account_assets = Account("Assets")
    account_revenues = Account("Revenues")
    j = JournalEntry("EMPTY", datetime.date(1970, 1, 1), source=None)
    j.post(datetime.date(2018, 1, 1), account_assets, Quantity(500))

# Generated at 2022-06-24 01:02:37.953736
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account1 = Account("A", AccountType.ASSETS)
    account2 = Account("B", AccountType.LIABILITIES)
    journal = JournalEntry("2020-01-01", "Test", None, postings=[
        Posting(journal, "2020-01-01", account1, Direction.DEC, Amount(2)),
        Posting(journal, "2020-01-01", account2, Direction.INC, Amount(2)),
    ])
    journal.validate()
    assert True

# Generated at 2022-06-24 01:02:45.279542
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from dataclasses import _MISSING_TYPE

    from .accounts import AssetAccount

    j1 = JournalEntry(datetime.date(2019, 4, 1), "Description", "Source", [
        Posting(None, datetime.date(2019, 4, 1), AssetAccount(name="Cash"), Direction.INC, Amount(100)),
        Posting(None, datetime.date(2019, 4, 1), AssetAccount(name="Stock"), Direction.DEC, Amount(100)),
    ])

# Generated at 2022-06-24 01:02:54.705604
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    je1 = JournalEntry(datetime.date(2020, 1, 1), "Sample", None)
    je1.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), Quantity(10))
    je1.post(datetime.date(2020, 1, 1), Account(AccountType.EQUITIES, "Equity"), Quantity(-10))
    je2 = JournalEntry(datetime.date(2020, 1, 1), "Sample", None)
    je2.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Cash"), Quantity(10))
    je2.post(datetime.date(2020, 1, 1), Account(AccountType.EQUITIES, "Equity"), Quantity(-10))
    assert je1 == je2


# Generated at 2022-06-24 01:03:00.401038
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journal=JournalEntry(date=datetime.date(2016,4,4), description="Journal entry 1", source="object1", guid="-gyKb58cQ9e35wpdG4t4")
    journal.post(date=datetime.date(2016,4,4), account="Account1", quantity=10)
    journal.validate()
    journal_dict={journal:"Journal Entry"}
    assert hash(journal) in journal_dict, "Hash method is not working"
    assert journal_dict[journal]=="Journal Entry", "Hash method is not working"
    assert hash(journal)==-3422940164404060883, "Hash method is not working"


# Generated at 2022-06-24 01:03:09.988102
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .transactions import Transaction, TransactionKind
    import datetime
    a=Account('Food',AccountType.EXPENSES)
    b=Transaction(datetime.date(2020,1,1),'lunch',TransactionKind.DEBIT,a,10)
    c=JournalEntry(datetime.date(2020,1,1),'lunch',None)
    c.post(datetime.date(2020,1,1),a,-10)
    # assert c.increments.amount==10
    # assert c.decrements.amount==10

# Generated at 2022-06-24 01:03:11.079436
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert issubclass(ReadJournalEntries, Protocol)

# Generated at 2022-06-24 01:03:11.699110
# Unit test for constructor of class Posting
def test_Posting():
    pass

# Generated at 2022-06-24 01:03:12.320799
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True

# Generated at 2022-06-24 01:03:23.234240
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    import datetime
    from dataclasses import dataclass
    from typing import List

    from .accounts import Account, AccountType
    from .journal import Direction, JournalEntry, Posting

    class Assets(Account):
        def __init__(self):
            super().__init__("Assets", AccountType.ASSETS)

    @dataclass(frozen=True)
    class BizObject:
        pass

    journal = JournalEntry(datetime.date.today(), "Description", BizObject())
    journal.post(datetime.date.today(), Assets(), 1)

    assert journal.postings[0].amount == 1
    assert journal.postings[0].account.name == "Assets"
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].journal is journal

# Generated at 2022-06-24 01:03:31.580484
# Unit test for constructor of class Posting
def test_Posting():
    account = Account.of("foo", AccountType.ASSETS, Guid("b0e9d3a1-c865-43c0-b04d-03fc1e7e15a0"))
    journal_entry = JournalEntry.of(datetime.date(2019, 1, 1), "foo")
    posting = Posting(journal_entry, datetime.date(2019, 1, 1), account, Direction.INC, Amount(10))
    assert posting.journal == journal_entry
    assert posting.date == datetime.date(2019, 1, 1)
    assert posting.account == account
    assert posting.direction == Direction.INC
    assert posting.amount == Amount(10)


# Generated at 2022-06-24 01:03:41.820057
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal_entry_1 = JournalEntry(DateRange(start_date=date(2020, 1, 16), end_date=date(2020, 1, 16)), "test", None)
    journal_entry_2 = JournalEntry(DateRange(start_date=date(2020, 1, 16), end_date=date(2020, 1, 16)), "test", None)
    assert journal_entry_1.date == journal_entry_2.date
    assert journal_entry_1.description == journal_entry_2.description    
    assert journal_entry_1.source == journal_entry_2.source    
    assert journal_entry_1.postings == journal_entry_2.postings
    assert journal_entry_1.increments == journal_entry_2.increments 
    assert journal_entry_1.decrements == journal_entry_

# Generated at 2022-06-24 01:03:49.648814
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # get a JournalEntry
    journal_entry = JournalEntry(date = datetime.date(20, 9, 16), description = "description", source = "source")
    # try to delete the attribute "name"
    try:
        del journal_entry.name
    except:
        # record the exception as a dict so that it can be tested
        err = {"message": f"{journal_entry.__class__.__name__} has no attribute 'name'"}
    # test the exception is the expected one
    assert err == {"message": "JournalEntry has no attribute 'name'"}
    # try to delete the attribute "post"

# Generated at 2022-06-24 01:04:00.844796
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():

    # Setup:
    guid = makeguid()
    description = "Purchase of computers"
    account_guid = makeguid()
    debit = 1000.0
    credit = 0.0
    posting = Posting(
        JournalEntry(
            date = datetime.date(2018, 1, 31),
            description = "Supplier invoice payment",
            source = "supplier_invoice",
            guid = guid,
        ),
        datetime.date(2018, 1, 31),
        Account(
            name = "Bank Account",
            type = AccountType.ASSETS,
            guid = account_guid,
        ),
        Direction.DEC,
        Amount(debit - credit),
    )

    # Exercise:
    result = posting.__repr__()

    # Verify:

# Generated at 2022-06-24 01:04:07.890557
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from datetime import date

    journal_entry_date = date(2020, 6, 2)
    account = Account('Employee A/C', AccountType.EXPENSES)
    direction = Direction.INC
    amount = Amount(200)
    posting = Posting(journal_entry_date, account, direction, amount)
    assert repr(posting) == 'Posting(journal_entry_date=2020-06-02, account=Employee A/C, direction=INC, amount=200)'


# Generated at 2022-06-24 01:04:08.705921
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    pass



# Generated at 2022-06-24 01:04:13.842996
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry("date", "description", 1)
    journal.post(datetime.date, "Account 1", 100)
    assert len(journal.postings) == 1
    assert journal.postings[0].account == "Account 1"
    assert journal.postings[0].amount == 100
    assert journal.postings[0].direction == Direction.INC


# Generated at 2022-06-24 01:04:23.432224
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    date = datetime.date(2019, 1, 1)
    account = Account("test_account", AccountType.ASSETS)
    direction = Direction.INC
    amount = Amount(10)

    je = JournalEntry(date, "test_journal_entry", "test_source")
    je.post(date, account, amount)
    
    try:
        posting = je.postings[0]
        posting.journal = "test_journal"
        posting.date = "test"
        posting.account = "test"
        posting.direction = "test"
        posting.amount = "test"
        # posting.is_debit = "test"
        # posting.is_credit = "test"
    except AttributeError:
        pass

# Generated at 2022-06-24 01:04:32.230201
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    expected_journal_entry = JournalEntry(date = datetime.date(2018, 2, 25), description = "test", source = None, options = {}, guid = "b52320e5-766a-4532-b7ce-fedf9d91f239")
    actual_journal_entry = JournalEntry(date = datetime.date(2018, 2, 25), description = "test", source = None, options = {}, guid = "b52320e5-766a-4532-b7ce-fedf9d91f239")
    assert expected_journal_entry == actual_journal_entry


# Generated at 2022-06-24 01:04:41.982166
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import account_with
    import datetime

    account = account_with(id='id', name='name')
    direction = Direction.DEC
    date = datetime.date.today()
    amount = Amount(10)
    journal = JournalEntry[str](date, 'description', 'source', [])
    # call test
    posting = Posting(journal, date, account, direction, amount)

# Generated at 2022-06-24 01:04:51.026699
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    """
    Unit tests for method __eq__ of class Posting.
    """

    p1 = Posting(JournalEntry(date=datetime.date.today(), description="TEST", source="TEST"), datetime.date.today(), Account("A","A",AccountType.ASSETS), Direction.INC, Amount(100))
    p2 = Posting(JournalEntry(date=datetime.date.today(), description="TEST", source="TEST"), datetime.date.today(), Account("A","A",AccountType.ASSETS), Direction.INC, Amount(100))

    assert p1 == p2


# Generated at 2022-06-24 01:04:51.795092
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert ReadJournalEntries()

# Generated at 2022-06-24 01:04:55.467631
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    assert hash(Posting(DateRange(None, None), AccountType.EQUITIES, Direction.DEC, Amount(1)))==hash((DateRange.closed(None, None), AccountType.EQUITIES, Direction.DEC, Amount(1)))


# Generated at 2022-06-24 01:04:57.527595
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert False, "TODO: Write unit tests for JournalEntry.__delattr__"


# Generated at 2022-06-24 01:04:59.084494
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass


__all__ = list(set(__all__))

# Generated at 2022-06-24 01:05:05.880594
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry(datetime.date(2019, 1, 1), "Test", None)
    je.post(datetime.date(2019, 1, 1), Account(AccountType.ASSETS, "Bank", "Cash in Bank"), +1000)
    je.post(datetime.date(2019, 1, 1), Account(AccountType.EQUITIES, "Capital", "Capital"), -1000)
    je.validate()

# Generated at 2022-06-24 01:05:08.620740
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    j = JournalEntry[None](datetime.date(2020,1,1),'desc',None,[])
    assert hash(j) == hash(('2020-01-01', 'desc'))

# Generated at 2022-06-24 01:05:15.095865
# Unit test for constructor of class Posting
def test_Posting():
    import datetime
    a = Account("A")
    dir = Direction.INC
    amt = Amount(1)
    date = datetime.date.today()
    p = Posting("journal","date","account","direction","amount")
    assert p.journal == "journal"
    assert p.date == "date"
    assert p.account == "account"
    assert p.direction == "direction"
    assert p.amount == "amount"
    assert p.is_debit == False
    assert p.is_credit == True


# Generated at 2022-06-24 01:05:24.087398
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    dummy_journal = JournalEntry(datetime.datetime(2018, 1, 1), "Dummy Description", "Dummy Source", [])
    dummy_posting = Posting(dummy_journal, datetime.datetime(2018, 1, 1), Account("Asset:Cash"), Direction.INC, 1)

# Generated at 2022-06-24 01:05:25.020464
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert issubclass(ReadJournalEntries, Protocol)

# Generated at 2022-06-24 01:05:31.849781
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    assert hash(JournalEntry(datetime.datetime.now().date(), "test", None)) == hash(JournalEntry(datetime.datetime.now().date(), "test", None))
    assert not JournalEntry(datetime.datetime.now().date(), "test_1", None) == JournalEntry(datetime.datetime.now().date(), "test_2", None)

# Generated at 2022-06-24 01:05:36.511426
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je = JournalEntry("Test")
    je.post(je.date, Account("L1"), Amount(1))
    je.post(je.date, Account("L2"), Amount(2))
    je.post(je.date, Account("A1"), Amount(3))
    je.guid = "abc"
    assert hash(je) == 1


# Generated at 2022-06-24 01:05:39.241234
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert JournalEntry(
        date=datetime.date(2013,1,1),
        description="This is a test description", 
        source="This is a test source"
    ) is not None

# Generated at 2022-06-24 01:05:45.286768
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date

    je = JournalEntry[str](date(2019, 4, 20), "Testing", "Testing", [])
    with pytest.raises(TypeError) as excinfo:
        je.description = "New Description"
    assert "can't set attribute" in str(excinfo)

# Generated at 2022-06-24 01:05:53.709853
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    """ test __hash__ fonctionnality of class Posting """
    posting_1 = Posting(None, datetime.date.today(), Account("account", AccountType.ASSETS), Direction.INC, Amount(1))
    posting_2 = Posting(None, datetime.date.today(), Account("account", AccountType.ASSETS), Direction.INC, Amount(1))
    assert hash(posting_1) == hash(posting_2)
    assert posting_1 == posting_2
    assert posting_1.__hash__() == posting_2.__hash__()


# Generated at 2022-06-24 01:05:58.995920
# Unit test for constructor of class Posting
def test_Posting():
    journal = JournalEntry[str]("2020-01-01", "test description", "test source")
    account = Account("test account", "test type", "test description", Guid.from_string("test id"))
    direction = Direction.INC
    amount = Amount(10)
    posting1 = Posting(journal, datetime.date.today(), account, direction, amount)


# Generated at 2022-06-24 01:06:01.578938
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    result = JournalEntry.__repr__
    assert result is not None


# Generated at 2022-06-24 01:06:10.162981
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    class Test:
        def __init__(self, id, name):
            self.id = id
            self.name = name

    source = Test('00001', 'name')
    journal_entry = JournalEntry[Test](date=datetime.date.today(), description='test_Posting___setattr__', source=source)
    posting = Posting[Test](journal_entry, date=datetime.date.today(), account=Account("00001", "name"), direction=Direction.INC, amount=100)
    try:
        posting.date = datetime.date.today()
    except AttributeError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:06:17.757234
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    assert hash(Posting(JournalEntry(datetime.date(1, 2, 3), 'test_Posting___hash__', 'test'), datetime.date(1, 2, 3), Account('test_Posting___hash__', 'test', AccountType.REVENUES), Direction.INC, Amount(0))) == hash(Posting(JournalEntry(datetime.date(1, 2, 3), 'test_Posting___hash__', 'test'), datetime.date(1, 2, 3), Account('test_Posting___hash__', 'test', AccountType.REVENUES), Direction.INC, Amount(0)))


# Generated at 2022-06-24 01:06:25.305283
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    #: Convenience function for creating a posting.
    def posting(journal: "JournalEntry[_T]", date: datetime.date, account: Account, direction: Direction, amount: Amount) -> Posting[_T]:
        return Posting(journal, date, account, direction, amount)

    #Assign date, direction and amount of a Posting
    j = JournalEntry(_T, datetime.date.today(), 'Test Journal', _T, [])
    p = posting(j, datetime.date.today(), Account(AccountType.ASSETS, 'Test Account', '', ''), Direction.INC, Amount(100))
    assert p.date == datetime.date.today()
    assert p.direction == Direction.INC
    assert p.amount == Amount(100)

    # Assigning journal, account of a Posting

# Generated at 2022-06-24 01:06:30.133694
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    """
    Tests the method __repr__ of class Posting.
    """
    # __repr__ shouldn't throw any exception (we assume that the code is correct)
    _ = repr(Posting(None, datetime.date(2020,1,1), Account("test", AccountType.ASSETS), Direction.DEC, Amount(1)))

# Generated at 2022-06-24 01:06:37.145909
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType
    from .books import Books
    from .ledgers import Ledger
    from .transactions import Transactions
    from ..commons.zeitgeist import DateRange

    e = {
        "description": "XYZ",
        "transactions": [
            {"date": "2018-01-15", "description": "TRX1", "from": "CASH", "to": "REVENUE", "qty": 100},
        ]
    }

    # Generate journal entries on-the-fly:
    def gen(period: DateRange) -> Iterable[JournalEntry[str]]:
        for entry in e['transactions']:
            yield JournalEntry(datetime.datetime.fromisoformat(entry['date']), entry['description'], entry)

    # Test:
    ledger = Ledger.from_

# Generated at 2022-06-24 01:06:37.596945
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-24 01:06:38.170729
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True

# Generated at 2022-06-24 01:06:46.568977
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    new_JE = JournalEntry(date = datetime.date(2020, 4, 1), description = 'debit', source = 0)
    assert new_JE.date == datetime.date(2020, 4, 1)
    assert new_JE.description == 'debit'
    assert new_JE.source == 0
    assert new_JE.postings == []
    assert type(new_JE.guid) == type(str())
    assert new_JE.increments == []
    assert new_JE.decrements == []
    assert new_JE.debits == []
    assert new_JE.credits == []


# Generated at 2022-06-24 01:06:47.150125
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass

# Generated at 2022-06-24 01:06:58.421051
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from dataclasses import dataclass
    from datetime import date

    from ..commons.numbers import Amount, Quantity

    @dataclass(frozen=True)
    class SomeSource:
        pass

    source = SomeSource()
    entry = JournalEntry[SomeSource](date(2019, 10, 31), "Description", source)

    # Test entry.post() method
    entry.post(date(2019, 10, 31), Account("A/C 1"), Quantity(100))

    assert (2019, 10, 31) == (entry.postings[0].date.year, entry.postings[0].date.month, entry.postings[0].date.day)
    assert str(Account("A/C 1")) == str(entry.postings[0].account)
    assert Amount(100) == entry.postings[0].amount

# Generated at 2022-06-24 01:07:01.604475
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    assert hash(Posting(JournalEntry, datetime.date, Account, Direction, Amount)), "test_Posting___hash__ failed"


# Generated at 2022-06-24 01:07:08.328841
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    from .transactions import Transaction
    from .ledgers import LedgerBook
    lb = LedgerBook()
    t = Transaction(lb)
    account_revenues = Account("Revenues", AccountType.REVENUES)
    account_expenses = Account("Expenses", AccountType.EXPENSES)
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Derivative", t)

    journal_entry.post(datetime.date(2020, 1, 1), account_revenues, 100)
    journal_entry.post(datetime.date(2020, 1, 1), account_expenses, -30)
    journal_entry.validate()

# Generated at 2022-06-24 01:07:14.371775
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    class Transaction:
        """
        This is a sample transaction class used for testing
        """

        def __init__(self):
            self.journal = JournalEntry[Transaction]()

    T = Transaction()
    T1 = JournalEntry(T,"T1")
    T1.post(T,"T1",10)
    assert T1.postings[0].amount == 10
    assert T1.postings[0].direction == Direction.INC
    assert T1.postings[0].is_debit == True
    assert T1.postings[0].is_credit == False

# Generated at 2022-06-24 01:07:25.328861
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    entry = JournalEntry(date = datetime.date(2020, 8, 1), description = "Test journal entry", source = "Testing")
    entry.postings = [Posting(journal = entry, date = datetime.date(2020, 8, 1), account = Account(code = "00", type = AccountType.ASSETS), direction = Direction.INC, amount = Amount(1)),
                      Posting(journal = entry, date = datetime.date(2020, 8, 1), account = Account(code = "01", type = AccountType.REVENUES), direction = Direction.DEC, amount = Amount(1))]
    entry.guid = makeguid()

    assert entry.date == datetime.date(2020, 8, 1)
    assert entry.description == "Test journal entry"
    assert entry.source == "Testing"
    assert entry.postings

# Generated at 2022-06-24 01:07:27.148187
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    name = 'akanksha'
    assert name.__delattr__() == None


# Generated at 2022-06-24 01:07:35.746649
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from src.domain.accounts import AccountType
    from src.domain.accounts.account import Account

    # Mock
    import datetime
    from towncrier.testing import make_journalEntry
    from unittest.mock import Mock
    transaction_mock = Mock()
    transaction_mock.date = datetime.date(2019,7,3)
    transaction_mock.description = "Transaction description"

    # Expectation
    expected = 2912774071340741033

    # Test
    je = JournalEntry(datetime.date(2019,7,3), "Transaction description", 
        transaction_mock)
    je.post(datetime.date(2019,7,3), Account("Code1","Account1",AccountType.EQUITIES), 2)

# Generated at 2022-06-24 01:07:36.999379
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    a = JournalEntry.__delattr__


# Generated at 2022-06-24 01:07:42.487569
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import Assets, Expenses, Liabilities, Revenues

    entries = []

    @dataclass(frozen=True)
    class JournalSource:
        name: str

    source = JournalSource("Test")
