

# Generated at 2022-06-24 00:57:42.341875
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    '''
    def  __delattr__ self,name:
        '''
    # Test function not implemented.
    raise Exception("Test function not implemented.")


# Generated at 2022-06-24 00:57:50.084878
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from ..commons.zeitgeist import now

    from .accounts import AccountIndex
    from .ledger import Ledger

    ledger = Ledger()
    index = AccountIndex(ledger)
    assets = index.lookup("Assets")
    expenses = index.lookup("Expenses")
    revenues = index.lookup("Revenues")

    entry = JournalEntry[Ledger](now().date(), "Testing")
    entry.post(assets, -1).post(revenues, +1)
    entry.validate()

    del entry.postings[0].date



# Generated at 2022-06-24 00:57:51.028766
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass


# Generated at 2022-06-24 00:57:56.149242
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    assert hash(Posting(JournalEntry(datetime.date.today(), "", None), datetime.date.today(), Account("", AccountType.ASSETS), Direction.INC, Amount(0))) == hash(
        Posting(JournalEntry(datetime.date.today(), "", None), datetime.date.today(), Account("", AccountType.ASSETS), Direction.INC, Amount(0)))


# Generated at 2022-06-24 00:58:04.873867
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # Create JournalEntry objects
    @dataclass(frozen=True)
    class Source(object):
        name: str
        age: int

    source1 = Source("Bob", 30)
    source2 = Source("Bob", 30)

    entry1 = JournalEntry[Source](date=datetime.date(2020, 1, 1), description="rent", source=source1)
    entry2 = JournalEntry[Source](date=datetime.date(2020, 1, 1), description="rent", source=source1)

    # Compare two identical JournalEntry objects
    assert entry1 == entry2



# Generated at 2022-06-24 00:58:15.988439
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    posting1 = Posting(None, date = datetime.date(2020,10,15), account = "Account1", direction = Direction.INC, amount = Amount(10))
    posting2 = Posting(None, date = datetime.date(2020,10,15), account = "Account1", direction = Direction.INC, amount = Amount(10))
    posting3 = Posting(None, date = datetime.date(2020,10,15), account = "Account1", direction = Direction.INC, amount = Amount(11))
    posting4 = Posting(None, date = datetime.date(2020,10,16), account = "Account1", direction = Direction.INC, amount = Amount(10))

# Generated at 2022-06-24 00:58:25.288024
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from hypothesis import given, settings, Verbosity
    from hypothesis.strategies import dates

    # Input values
    date = dates().example()
    account = Account(name="Test Account #1", type=AccountType.ASSETS)
    direction = Direction(1)
    amount = Amount(500)
    journal = JournalEntry(date = date, description = "Test description #1", source = None)
    
    posting = Posting(journal = journal, date = date, account = account, direction = direction, amount = amount)

    # Expected results
    
    # Actual results
    try:
        posting.__delattr__("journal")
        assert False
    except AttributeError:
        assert True
    try:
        posting.__delattr__("date")
        assert False
    except AttributeError:
        assert True

# Generated at 2022-06-24 00:58:37.435213
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    source = 1
    description = 'description'
    account = Account('account', 'description')
    account2 = Account('account2', 'description')
    date = datetime.datetime(2020, 1, 1).date()
    date2 = datetime.datetime(2020, 1, 2).date()
    amount = Amount(10)

    posting1 = Posting(JournalEntry(date, description, source), date, account, Direction.INC, amount)
    posting2 = Posting(JournalEntry(date, description, source), date, account, Direction.DEC, amount)
    posting3 = Posting(JournalEntry(date, description, source), date2, account, Direction.INC, amount)
    posting4 = Posting(JournalEntry(date, description, source), date, account2, Direction.INC, amount)

# Generated at 2022-06-24 00:58:47.413113
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from datetime import date

    @dataclass
    class MySource:
        """
        A source type.
        """

    source = MySource()

    j = JournalEntry[MySource](date(2018, 9, 6), "Test Entry", source)
    j.post(date(2018, 9, 6), Account("111", AccountType.ASSETS), -10)
    j.post(date(2018, 9, 6), Account("211", AccountType.EXPENSES), +10)
    j.validate()

    assert len(j.postings) == 2

    for p in j.postings:
        assert p.journal is j

    assert j.increments
    assert j.decrements

    assert j.debits
    assert j.credits


# Generated at 2022-06-24 00:58:54.894737
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account, Accounts, create_accounts
    from .accounts import Assets, Liabilities, Equity, Revenues, Expenses, create_accounts_hierarchy

    accounts = Accounts(create_accounts_hierarchy())

    j1 = JournalEntry(date=datetime.date(2020, 1, 1), description="x", source=None) \
        .post(datetime.date(2020, 1, 1), accounts.assets.hkd_cash, -100) \
        .post(datetime.date(2020, 1, 1), accounts.expenses.sundries, 100)


# Generated at 2022-06-24 00:58:55.469683
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    ...  # TODO

# Generated at 2022-06-24 00:59:03.679179
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import get_accounts

    accounts = get_accounts()
    from .transactions import ReadTransactions, get_transactions

    transactions = get_transactions(accounts)

    for transaction in transactions.filter(DateRange.from_date(datetime.date(2019, 1, 1))):
        print(transaction)
        for posting in transaction.postings:
            print(posting)

test_Posting()

# Generated at 2022-06-24 00:59:07.656455
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():

    @dataclass
    class _T:
        name: str

    entry = JournalEntry(_T('test'))
    entry.post(None, None, 100)
    assert entry.guid

# Generated at 2022-06-24 00:59:17.637857
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je1 = JournalEntry[None](
        date=datetime.date(2019, 7, 1), description="Test Description", source=None
    )
    je2 = JournalEntry[None](
        date=datetime.date(2019, 7, 1), description="Test Description", source=None
    )
    je3 = JournalEntry[None](
        date=datetime.date(2019, 7, 2), description="Test Description", source=None
    )
    je4 = JournalEntry[None](
        date=datetime.date(2019, 7, 1), description="Other Description", source=None
    )

    hash_set = set()

    for je in [je1, je2, je3, je4]:
        hash_set.add(je)


# Generated at 2022-06-24 00:59:28.215473
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    ## Setup:
    journal_entry = JournalEntry[int](datetime.date(1,1,1), 'Purchase', 1)

    ## Test:
    journal_entry.post(datetime.date(1,2,1), Account('Cash', AccountType.ASSETS), Amount(100))
    journal_entry.post(datetime.date(1,2,1), Account('Stock', AccountType.ASSETS), Amount(100))
    journal_entry.post(datetime.date(1,2,1), Account('Purchases', AccountType.EXPENSES), Amount(200))

    print(journal_entry.postings)

    ## Verify:
    journal_entry.validate()

    return journal_entry

# Generated at 2022-06-24 00:59:34.382496
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    description = "test description"
    date = datetime.date(2019, 3, 2)
    date2 = datetime.date(2019, 3, 3)
    description2 = "test description2"
    testSource = TestObject("testSource")
    testSource2 = TestObject("testSource2")
    testSource3 = TestObject("testSource3")
    testSource4 = TestObject("testSource4")
    posting0 = Posting(description, date, testSource, Direction.INC, Amount(0))
    posting1 = Posting(description, date, testSource, Direction.INC, Amount(1))
    posting2 = Posting(description, date, testSource, Direction.DEC, Amount(1))
    journalEntry = JournalEntry[TestObject](description, date, testSource, [posting0, posting1, posting2])


# Generated at 2022-06-24 00:59:37.664747
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # Creating JournalEntry object
    journal_entry = JournalEntry('date', 'description', 'source', 'postings', 'guid')

    # Creating attribute name
    attribute_name = 'source'

    # Deleting the attribute
    delattr(journal_entry, attribute_name)

# Generated at 2022-06-24 00:59:48.000432
# Unit test for constructor of class Posting
def test_Posting():
    from ..domain import entities
    from . import accounts

    acc = accounts.Account.of("Assets", "Cash", AccountType.ASSETS)

    inv = entities.Invoice(date=datetime.date(2020, 7, 18), description="From A to B for 10")

    j = JournalEntry(date=datetime.date(2020, 5, 4), description="Invoice", source=inv)
    p = Posting(journal=j, date=datetime.date(2020, 5, 4), account=acc, direction=Direction.INC, amount=100)

    assert p.journal == j
    assert p.date == datetime.date(2020, 5, 4)
    assert p.account == acc
    assert p.direction == Direction.INC
    assert p.amount == 100

    assert p.is_debit
    assert not p

# Generated at 2022-06-24 00:59:58.455360
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    from dataclasses import dataclass, field

    @dataclass
    class T:
        guid_: Guid = field(default_factory=makeguid, init=True)
        pass

    t = T()

    je1 = JournalEntry(date(2020, 2, 20), "Test", t)
    p1 = Posting(je1, date(2020, 2, 20), "", Direction.INC, 0)
    assert p1.journal == je1
    assert p1.journal.guid != t.guid_, "T does not have guid, which is created by JournalEntry"

    t2 = T()
    je2 = JournalEntry(date(2020, 2, 20), "Test", t2)

# Generated at 2022-06-24 01:00:00.882927
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p1 = Posting(None, None, None, None, None)
    assert hash(p1) == hash(p1.guid)
    p2 = Posting(None, None, None, None, None)
    assert hash(p1) == hash(p2)

# Generated at 2022-06-24 01:00:11.090884
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal = JournalEntry(date=datetime.date(2020, 1, 1), description="Test journal entry", source=None, postings=[])
    account1 = Account(code = '000001', name = 'Account1', type = AccountType.ASSETS)
    account2 = Account(code = '000002', name = 'Account2', type = AccountType.EXPENSES)
    
    journal.post(date = datetime.date(2020, 1, 1), account = account1, quantity = 10)
    journal.post(date = datetime.date(2020, 1, 1), account = account2, quantity = -10)
    
    assert len(journal.postings) == 2
    assert journal.postings[0].account == account1
    assert journal.postings[0].amount == 10

# Generated at 2022-06-24 01:00:14.001846
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting(None, None, None, None, None)) == "Posting(journal=None, date=None, account=None, direction=None, amount=None)"

# Generated at 2022-06-24 01:00:16.646541
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    dele = JournalEntry[None]
    try:
        del dele.postings
    except AttributeError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:00:17.757314
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass # TODO


# Generated at 2022-06-24 01:00:22.733371
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journal_entry_1 = JournalEntry(datetime.date(2020, 1, 2), '', 0)
    journal_entry_2 = JournalEntry(datetime.date(2020, 1, 2), '', 0)
    assert journal_entry_1 == journal_entry_2

# Generated at 2022-06-24 01:00:23.326926
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    pass

# Generated at 2022-06-24 01:00:25.681635
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    entry = JournalEntry[None]("date", "description", None)
    entry.post(datetime.date.today(), None)
    entry.validate()
    del entry.postings

# Generated at 2022-06-24 01:00:26.480721
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert False, "Test not implemented"

# Generated at 2022-06-24 01:00:32.704916
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date, timedelta
    from types import FunctionType
    from unittest import TestCase
    
    def read_journal(period: DateRange) -> Iterable[JournalEntry[str]]:
        return (JournalEntry(date, 'Description', 'Source {}'.format(i)) for date in period.days())
    
    ReadJournalEntries.register(FunctionType)(read_journal)
    
    class Tests(TestCase):
        def test__call__(self):
            days = [date(2018, 4, 1) + timedelta(days=i) for i in range(31)]
            period = DateRange(days[0], days[-1])

            result = read_journal(period)
            self.assertEqual(len(list(result)), 31)

# Generated at 2022-06-24 01:00:34.683302
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

if __name__ == "__main__":
    test_JournalEntry_post()

# Generated at 2022-06-24 01:00:44.793731
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import Account
    from .accounts import Accounts
    from .accounts import AccountType
    from .accounts import AccountTypes
    from dataclasses import dataclass

    @dataclass
    class _T:
        id: int

    account1 = Account(1, "Account 1", AccountType.ASSETS)
    account2 = Account(2, "Account 2", AccountType.ASSETS)

    entry1 = JournalEntry[str](datetime.date(2020, 1, 1), "Entry")

    entry2 = JournalEntry[str](datetime.date(2020, 1, 1), "Entry")

    entry3 = JournalEntry[str](datetime.date(2020, 1, 2), "Entry")


# Generated at 2022-06-24 01:00:52.341604
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(
        JournalEntry(datetime.date.today(), "test", None),
        datetime.date.today(),
        Account("account1"),
        Direction.INC,
        Amount(10)
    )

    p2 = Posting(
        JournalEntry(datetime.date.today(), "test", None),
        datetime.date.today(),
        Account("account1"),
        Direction.INC,
        Amount(10)
    )

    assert p1 == p2, "Posting __eq__ method does not work correctly."


# Generated at 2022-06-24 01:00:54.289232
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    class S():
        pass
    s = S()
    he = JournalEntry(datetime.date(2020,1,1), 'sum', s)
    print(he)
test_JournalEntry()

# Generated at 2022-06-24 01:01:01.972348
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    date = datetime.date.today()
    description = "Test journal entry"
    source = "Test source"
    postings = (Posting("Test journal entry", date, "Assets:Cash", Direction.INC, Amount(13)),)
    journal = JournalEntry(date, description, source, postings)
    assert isinstance(journal.__repr__(), str), "repr output is not a string"

# Generated at 2022-06-24 01:01:02.860154
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert True


# Generated at 2022-06-24 01:01:10.950004
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from dataclasses import dataclass, field
    from typing import Iterable
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .journal import JournalEntry, ReadJournalEntries

    @dataclass(frozen=True)
    class _BalanceSheetEntry:
        ...

    @dataclass(frozen=True)
    class _BalanceSheetEntries:
        """
        Reads journal entries from a JSON file.
        """

        #: File path to read.
        file_path: str

        #: Cache of loaded journal entries.
        entries: List[JournalEntry[_BalanceSheetEntry]] = field(default_factory=list)


# Generated at 2022-06-24 01:01:22.847750
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    
    from .accounts import Account
    from .journals import JournalEntry
    from .products import Check
    from .products import Deposit
    
    
    # get two journal entry objects
    je1 = JournalEntry[Check](date=datetime.date.today(),
                           description='test',
                           source=Check)
    je2 = JournalEntry[Deposit](date=datetime.date.today(),
                             description='test',
                             source=Deposit)
    
    # post to them
    je1.post(date=datetime.date.today(),
            account=Account,
            quantity=10)
    je2.post(date=datetime.date.today(),
             account=Account,
             quantity=10)
    
    # get their hash values
    h1 = hash(je1)
    h2

# Generated at 2022-06-24 01:01:28.345848
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import Account
    account = Account(1, "Test Account")
    je = JournalEntry(datetime.date(2020, 5, 23), 'Test Journal Entry', 1)
    je.post(datetime.date(2020, 5, 23), account, 1)
    print(hash(je))


# Generated at 2022-06-24 01:01:36.837346
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():

    from datetime import date

    from .accounts import Account

    from .posting import Posting, JournalEntry

    from .source import BusinessObject

    date_of_posting = date.today()
    date_of_entry1 = date_of_posting
    date_of_entry2 = date(date_of_posting.year + 1, date_of_posting.month, date_of_posting.day)
    journal_entry_description = "Journal entry description"
    business_object1 = BusinessObject()
    business_object2 = BusinessObject()
    posted_amount1 = Amount(1)
    posted_amount2 = Amount(2)
    account1 = Account()
    account2 = Account()
    source1 = BusinessObject()
    source2 = BusinessObject()


# Generated at 2022-06-24 01:01:44.163425
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    a = Posting(JournalEntry(datetime.date.today(), "abc", "abc"), datetime.date.today(), "abc", Direction.INC, 100)
    b = Posting(JournalEntry(datetime.date.today(), "abc", "abc"), datetime.date.today(), "abc", Direction.INC, 100)
    assert a == b


# Generated at 2022-06-24 01:01:52.097280
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from unittest.mock import MagicMock
    joe = MagicMock()
    je = JournalEntry(date=datetime.date.today(),
                      description="",
                      source=joe)
    je.post(date=datetime.date.today(),
            account="",
            quantity=1)
    assert je.postings[0].journal == je
    assert je.postings[0].date == datetime.date.today()
    assert je.postings[0].account == ""
    assert je.postings[0].direction == Direction.INC
    assert je.postings[0].amount == 1

# Generated at 2022-06-24 01:02:03.197125
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from .accounts import Account
    from .currencies import USD, EUR
    from .utils import source_file
    from .events import Order, OrderSide
    from .events import Order, OrderSide, EventSourced
    from .events import Order, OrderSide, EventSourced

    ## The journal entries for the order:

# Generated at 2022-06-24 01:02:04.126028
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 01:02:07.218175
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Create a journal entry
    je = JournalEntry(2019, "test")
    assert je.date == 2019
    assert je.description == "test"


# Generated at 2022-06-24 01:02:18.504955
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    """
    Test method validate of class JournalEntry
    """
    # assets = Account("912000", "Assets")
    # expenses = Account("61", "Expenses", AccountType.EXPENSES)
    # cash = Account("1100", "Cash")
    # re1 = Account("610", "Rent Expense")
    # re2 = Account("616", "Utilities Expense")
    # re3 = Account("619", "Other Expense")

    # je1=JournalEntry(date=datetime.date.today(),description="Rent")
    # je1.post(date=datetime.date.today(),account=assets,quantity=3000).post(date=datetime.date.today(),account=expenses,quantity=-3000)
    # assert len(je1.postings)==2
    # assert (je

# Generated at 2022-06-24 01:02:21.214590
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry(1, 2, 3, 4, 5)) == "JournalEntry(date=1, description=2, source=3, postings=[4, 5])"


# Generated at 2022-06-24 01:02:22.561616
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-24 01:02:28.392475
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je1 = JournalEntry(datetime.date(2012, 1, 1), "desc1", None)
    assert hash(je1) == hash((je1.date, je1.description, je1.guid))

    je2 = JournalEntry(datetime.date(2012, 1, 1), "desc2", None)
    assert hash(je2) == hash((je2.date, je2.description, je2.guid))

    assert hash(je1) != hash(je2)



# Generated at 2022-06-24 01:02:38.520176
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    """
    Unit test for method __repr__ of class JournalEntry.

    :raises AssertionError: If the test fails.
    """
    # Test setup
    a1 = Account("a1", AccountType.ASSETS)
    a2 = Account("a2", AccountType.LIABILITIES)
    journal = JournalEntry(
        datetime.date(2020, 1, 1),
        "this is a test",
        None
    )

    journal.post(
        datetime.date(2020, 1, 1),
        a1,
        Quantity(+10)
    )

    journal.post(
        datetime.date(2020, 1, 2),
        a2,
        Quantity(-10)
    )

    # Test method
    result = repr(journal)

    # Test assertions

# Generated at 2022-06-24 01:02:39.680529
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .samples.journal import JournalEntries
    assert JournalEntries == ReadJournalEntries

# Generated at 2022-06-24 01:02:45.249346
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journalEntry = JournalEntry('2020-01-08', 'journal_entry_1', '', [])
    assert journalEntry.__repr__() == "JournalEntry(date=datetime.date(2020, 1, 8), description='journal_entry_1', source='', postings=[], guid='9c902d23-6c96-4f43-a6eb-58cf2e889781')"

# Generated at 2022-06-24 01:02:54.710700
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    #: Date of the entry.
    date = datetime.date.today()

    #: Description of the entry.
    description = "desc"

    #: Business object as the source of the journal entry.
    source = "Source"

    #: Postings of the journal entry.
    postings = []

    #: Globally unique, ephemeral identifier.
    guid = Guid("")

    je = JournalEntry[str](date, description, source, postings, guid)
    je.post("2018-03-23", "Equity:Capital", 100)
    assert len(je.postings) == 1
    assert je.postings[0].direction == Direction.INC
    assert je.postings[0].amount == Amount("100.0")
    assert je.postings[0].is_debit == False
    assert je.postings

# Generated at 2022-06-24 01:02:55.264135
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    pass

# Generated at 2022-06-24 01:02:57.214287
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    with pytest.raises(AssertionError):
        @dataclass
        class ReadJournalEntries2(ReadJournalEntries):
            pass

# Generated at 2022-06-24 01:03:04.806376
# Unit test for constructor of class Posting
def test_Posting():
    p1 = Posting(None, datetime.date(2019,6,2), Account("R001", "Assets", "Cash Account"), Direction.INC, Amount(1000))
    p2 = Posting(None, datetime.date(2019,6,2), Account("L002", "Liabilities", "Credit Card"), Direction.DEC, Amount(1000))
    print(p1.account.name)
    print(p1.date)
    print(p1.is_debit)
    print(p2.is_credit)


# Generated at 2022-06-24 01:03:13.670061
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class _ReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return JournalEntry(date = datetime.date(2019, 12, 31), description = 'test description', source = 1)

    entries = _ReadJournalEntries().__call__(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)))
    assert isinstance(entries, JournalEntry)
    assert entries.date.year == 2019
    assert entries.date.month == 12
    assert entries.description == 'test description'
    assert entries.source == 1

# Generated at 2022-06-24 01:03:24.623108
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from .accounts import Account
    from .numbers import Amount

    journal = JournalEntry
    date = datetime.date.today()
    account = Account
    direction = Direction.INC
    amount = Amount
    posting = Posting(journal, date, account, direction, amount)
    try:
        posting.journal = journal
    except Exception:
        posting.journal = journal
    try:
        posting.date = date
    except Exception:
        posting.date = date
    try:
        posting.account = account
    except Exception:
        posting.account = account
    try:
        posting.direction = direction
    except Exception:
        posting.direction = direction
    try:
        posting.amount = amount
    except Exception:
        posting.amount = amount

# Generated at 2022-06-24 01:03:36.139700
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from datetime import datetime
    from ..repositories.memrepos import AccountRepository
    from .accounts import AccountType

    a_rep = AccountRepository()
    a1 = a_rep.get_or_make(AccountType.ASSETS, Guid("1a3a32de-c637-11e8-a355-529269fb1459"), "Cash")
    a2 = a_rep.get_or_make(AccountType.EQUITIES, Guid("2a3a32de-c637-11e8-a355-529269fb1459"), "Equity")
    je = JournalEntry(datetime.now().date(), "Some description", None)

    je.post(datetime.now().date(), a1, 10)

# Generated at 2022-06-24 01:03:37.614628
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass


# Generated at 2022-06-24 01:03:45.389293
# Unit test for method post of class JournalEntry
def test_JournalEntry_post(): 
    from ..accounts import AccountType
    from ..commons.numbers import Amount, Quantity, isum
    from ..commons.zeitgeist import DateRange
    from .accounts import Account

    # preparation of data
    #: Account to post the amount to.
    account = Account(code='10000', name='Cash on Hand', type=AccountType.ASSETS)
    #: Signed-value to post to the account.
    quantity = Quantity(100)
    #: Date of posting.
    date = datetime.date(2020,3,2)
    #: Date of the entry.
    date_entry = datetime.date(2020,3,2)
    #: Description of the entry.
    description = 'Portfolio Subscription'
    #: Business object as the source of the journal entry.
    source = 'Cash on Hand'

# Generated at 2022-06-24 01:03:52.118256
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from datetime import date
    from unittest.mock import Mock

    entry_obj = Mock()
    entry_obj.date = date(2019, 6, 30)
    entry_obj.description = "description_str"
    entry_obj.source = object()
    entry_obj.postings = [Posting(object(), date(2019, 6, 30), object(), Direction.INC, Amount(10))]

    assert repr(JournalEntry(entry_obj.date, entry_obj.description, entry_obj.source)) == (
        f"JournalEntry("
        f"date={entry_obj.date}, "
        f"description={entry_obj.description}, "
        f"source={entry_obj.source}, "
        f"postings=[{entry_obj.postings[0]}]"
        f")"
    )


# Generated at 2022-06-24 01:03:53.833903
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    obj = ReadJournalEntries()
    assert hasattr(obj, "__call__")

# Generated at 2022-06-24 01:04:00.892403
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    """
    Unit test for method __eq__ of class JournalEntry.
    """
    this_date = datetime.date(2020, 8, 26)
    this_description = "This is my first journal entry."
    this_source = "Business object 1"
    journal_entry_1 = JournalEntry(this_date, this_description, this_source)
    journal_entry_2 = JournalEntry(this_date, this_description, this_source)
    assert journal_entry_1 == journal_entry_2


# Generated at 2022-06-24 01:04:11.097115
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journal1 = JournalEntry[int](date=datetime.date(2020, 5, 3), description="Journal 1", source=1)
    journal2 = JournalEntry[int](date=datetime.date(2020, 5, 3), description="Journal 1", source=1)
    assert hash(journal1) == hash(journal2)
    journal3 = JournalEntry[int](date=datetime.date(2020, 5, 3), description="Journal 2", source=1)
    journal4 = JournalEntry[int](date=datetime.date(2020, 5, 3), description="Journal 2", source=2)
    journal5 = JournalEntry[int](date=datetime.date(2020, 5, 4), description="Journal 2", source=1)
    assert hash(journal3) != hash(journal4) != hash(journal5)

# Generated at 2022-06-24 01:04:18.506007
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    test_Posting = Posting(0,None,None,None)
    try:
        test_Posting.__delattr__("journal")
        test_Posting.__delattr__("date")
        test_Posting.__delattr__("account")
        test_Posting.__delattr__("direction")
        test_Posting.__delattr__("amount")
    except Exception as e:
        print("test_Posting___delattr__ throwed an exception: ",e)


# Generated at 2022-06-24 01:04:26.163949
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert datetime.date(2019, 12, 5).__repr__() == "datetime.date(2019, 12, 5)"
    assert str(datetime.date(2019, 12, 5)) == "2019-12-05"
    assert str(datetime.date(2019, 12, 5)) == "2019-12-05"
    assert JournalEntry(date = datetime.date(2019, 12, 5), description = "sample", source = "sample").__repr__() == \
           "JournalEntry(date=datetime.date(2019, 12, 5), description='sample', source='sample', " \
           "postings=[], guid=None)"
    assert isinstance(JournalEntry(date = datetime.date(2019, 12, 5), description = "sample", source = "sample"), JournalEntry)

# Generated at 2022-06-24 01:04:29.843384
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    with raises(AssertionError):
        journalEntry = JournalEntry[str]("2020-2-1", "journalEntry", "test")
        journalEntry.postings.pop(0)

# Generated at 2022-06-24 01:04:33.338711
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    obj = Posting(1, "2", 3, 4, 5)
    try:
        obj.a = 1
        assert False, "Assigning a new attribute must raise exception"
    except AttributeError:
        assert True

# Generated at 2022-06-24 01:04:38.623411
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # If we manage to call this function, then the protocol check passes
    ReadJournalEntries.__call__
    # This code is unreachable
    assert True==False # pragma: no cover

# Generated at 2022-06-24 01:04:46.964742
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    testPosting  = Posting
    testAccount1 = Account()
    testDirection1 = Direction
    testAmount1 = Amount
    testPostingObj = testPosting(3,3,testAccount1,testDirection1,testAmount1)
    testPostingObj.journal = 1
    testPostingObj.date = 2
    testPostingObj.account = 3
    testPostingObj.direction = 4
    testPostingObj.amount = 5
    # here we test case 1: when the attribute is in the object
    assert testPostingObj.journal == 1
    del testPostingObj.journal
    assert testPostingObj.journal == 1
    # here we test case 2: when the attribute is not in the object
    testPostingObj.journal = 1
    assert testPostingObj.journal == 1
    testPosting

# Generated at 2022-06-24 01:04:50.434768
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-24 01:05:00.724602
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    a = Account('A')
    b = Account('B')
    je = JournalEntry(datetime.date.today(), 'Testing', None)
    je.post(datetime.date.today(), a, 100)
    je.post(datetime.date.today(), b, -100)
    je.validate()
    je = JournalEntry(datetime.date.today(), 'Testing', None)
    je.post(datetime.date.today(), a, 100)
    je.post(datetime.date.today(), b, -150)
    try:
        je.validate()
    except AssertionError:
        return
    raise AssertionError("Error in test case: test_JournalEntry_validate")

# Generated at 2022-06-24 01:05:10.977148
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from .accounts import AccountType, Account, AssetAccount, ExpenseAccount
    from .currencies import Currency
    from .environments import Environment, create_default_environment

    env = Environment('Test Env')
    acc = AssetAccount('Test Account', 'Test Account', env.currency_system.default, env)
    acc1 = AssetAccount('Test Account 1', 'Test Account 11', env.currency_system.default, env)
    acc2 = AssetAccount('Test Account 2', 'Test Account 12', env.currency_system.default, env)
    acc3 = AssetAccount('Test Account 3', 'Test Account 13', env.currency_system.default, env)
    acc4 = AssetAccount('Test Account 4', 'Test Account 14', env.currency_system.default, env)

# Generated at 2022-06-24 01:05:18.076566
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import AssetAccount
    from .contact import Contact
    from .events import PaymentOfSalesInvoice

    acc = AssetAccount("Cash")
    acc1 = AssetAccount("other Cash account")
    contact1 = Contact(name="contact1", account_payable=acc)
    contact2 = Contact(name="contact2", account_payable=acc1)
    date = datetime.date(day=10, month=9, year=2019)

    payment = PaymentOfSalesInvoice(contact1, acc, date=date)

    post1 = Posting(payment, date, acc, Direction.INC, Amount(10))
    post2 = Posting(payment, date, acc1, Direction.INC, Amount(10))
    post3 = Posting(payment, date, acc, Direction.INC, Amount(10))
    post4 = Post

# Generated at 2022-06-24 01:05:22.656734
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    test_Posting = Posting(date = '1/1/2', account = Account(type = AccountType.ASSETS, guid = 'a'), direction = Direction.INC, amount = Amount(1))
    assert (test_Posting.__delattr__() == None)


# Generated at 2022-06-24 01:05:26.831018
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():

    @dataclass(frozen=True)
    class Foo(object):
        """
        Data class for testing.
        """
        foo: int

    je = JournalEntry[Foo](datetime.date.today(), 'Foo', Foo(1))
    del je.foo
    assert False

# Generated at 2022-06-24 01:05:35.158757
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # Test
    a = Account("A")
    j = JournalEntry(datetime.date.today(), "J")
    p = Posting(j, datetime.date.today(), a, Direction.INC, Amount(100))
    # Check
    assert p.journal == j
    assert p.date == datetime.date.today()
    assert p.account == a
    assert p.direction == Direction.INC
    assert p.amount == Amount(100)
    try:
        p.journa = j
        assert False, "could set attribute `journa`"
    except AttributeError as e:
        assert "journa" in str(e)

# Generated at 2022-06-24 01:05:36.423792
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    r=JournalEntry.__repr__()
    assert("return ") in r

# Generated at 2022-06-24 01:05:45.219467
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import Account
    from .events import Event
    from ..commons.zeitgeist import Today, Tomorrow

    class T:
        pass
    t = T()

    date = Today()
    description = "foo"
    source = t
    account = Account(name="bar")
    amount = Amount(1)
    direction = Direction.INC
    postings = [Posting(date=date, account=account, direction=direction, amount=amount)]

    journal1 = JournalEntry(date=date, description=description, source=source)
    journal2 = JournalEntry(date=Tomorrow(), description=description, source=source)
    journal3 = JournalEntry(date=date, description="bar", source=source)
    journal4 = JournalEntry(date=date, description=description, source=Event(name="bar"))
    journal5 = Journal

# Generated at 2022-06-24 01:05:55.749518
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from hamper import datamodel, time
    from hamper import gl, repos

    mock_datetime = time.MockDatetime(datetime.datetime(year=2020, month=8, day=1))
    mock_gl = gl.MockGeneralLedger(datamodel.GeneralLedger(master_data=[
        datamodel.Account(code="10100", name="Cash"),
        datamodel.Account(code="11000", name="Sales"),
        datamodel.Account(code="21000", name="Overhead"),
    ]))

    def test_journal_entry_validation(journal_entry):
        try:
            journal_entry.validate()
        except:
            journal_entry.validate()


# Generated at 2022-06-24 01:05:59.159515
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    je1 = JournalEntry('2019-10-09', 'TEST', 'TEST')
    je2 = JournalEntry('2019-10-09', 'TEST', 'TEST')
    assert je1 == je2

# Generated at 2022-06-24 01:06:06.236467
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Create a journal entry:
    je = JournalEntry(date=datetime.date(year=2019, month=1, day=1), description="Test")

    ## Postings:
    je.post(datetime.date(year=2019, month=1, day=1), Account("Test", AccountType.ASSETS), +100)
    je.post(datetime.date(year=2019, month=1, day=1), Account("Test", AccountType.REVENUES), -100)

    ## Validate:
    je.validate()

# Generated at 2022-06-24 01:06:07.067924
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert True



# Generated at 2022-06-24 01:06:11.035354
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Given
    journal = JournalEntry(datetime.date.today(), "Test", None)

    # When
    val = hash(journal)

    # Then
    assert val is not None
    assert isinstance(val, int)

# Generated at 2022-06-24 01:06:19.708774
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal : JournalEntry[object] = JournalEntry(datetime.date(2019, 1, 1), "description", object())
    posting = Posting[object](journal, datetime.date(2019, 1, 1), Account("account", AccountType.ASSETS), Direction.INC, Amount(100))

    assert repr(posting) == "Posting(journal=JournalEntry(date=datetime.date(2019, 1, 1), description=\"description\", source=<object object at 0x10b12a0a0>, guid=None), date=datetime.date(2019, 1, 1), account=Account(code=\"account\", name=None, type=<AccountType.ASSETS: \"ASSETS\">), direction=<Direction.INC: 1>, amount=100)"


# Generated at 2022-06-24 01:06:20.252615
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    pass

# Generated at 2022-06-24 01:06:27.154846
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Setup...
    class ParseDate:
        def __init__(self, date: datetime.date) -> None:
            self.date = date

    class DummySource:
        def __init__(self) -> None:
            pass


# Generated at 2022-06-24 01:06:36.099906
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # Test set attribute
    posting = Posting(JournalEntry, datetime.date.today(), Account("assets", AccountType.ASSETS), Direction.INC, Amount(1))
    posting2 = Posting(JournalEntry, datetime.date.today(), Account("equities", AccountType.EQUITIES), Direction.DEC, Amount(1))
    assert posting.date == posting2.date
    posting.date = "Whatever"
    assert posting.date != posting2.date
    posting.journal = posting2
    assert posting.journal == posting2
    posting.account = posting2.account
    assert posting.account == posting2.account
    posting.direction = posting2.direction
    assert posting.direction == posting2.direction
    posting.amount = posting2.amount
    assert posting.amount == posting2.amount
    # Test with invalid attribute

# Generated at 2022-06-24 01:06:46.459283
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    """
    To test the method __eq__ of class Posting
    """
    from .accounts import AccountType, Account
    from .journal import JournalEntry
    from .taxes import TaxSystem, TaxType, TaxRule
    from .products import ProductMixin, ProductType

    # Creating accounts
    account_expenses = Account("Expense", AccountType.EXPENSES, "Expenses of the business")
    account_assets = Account("Asset", AccountType.ASSETS, "Assets of the business")
    account_equities = Account("Equity", AccountType.EQUITIES, "Equities of the business")
    account_liabilities = Account("Liability", AccountType.LIABILITIES, "Liaibitative of the business")

# Generated at 2022-06-24 01:06:57.828135
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    import datetime
    from dataclasses import dataclass, field
    from enum import Enum
    from typing import Dict, List, Set, TypeVar
    from .accounts import Account, AccountType
    from .books import Book
    class Direction(Enum):
        value: int
        INC = +1
        DEC = -1
    @dataclass
    class Account(Account):
        type: AccountType = AccountType.ASSETS
    @dataclass(frozen=True)
    class Posting:
        journal: "JournalEntry"
        date: datetime.date
        account: Account
        direction: Direction
        amount: int
        @property
        def is_debit(self) -> bool:
            return self.account.type in _debit_mapping[self.direction]

# Generated at 2022-06-24 01:07:06.518173
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal = JournalEntry[str](date=datetime.date(year=2018, month=12, day=7),
                                description="Booking of cash received.",
                                source="Cash received.")
    journal.post(
        date=journal.date,
        account=Account(name="Cash", type=AccountType.ASSETS),
        quantity=+100,
    )
    journal.post(
        date=journal.date,
        account=Account(name="Receivables", type=AccountType.REVENUES),
        quantity=-100,
    )

    # Actual test
    assert repr(journal) == "<JournalEntry: 2018-12-07 Booking of cash received. (Cash received.)>"

# Generated at 2022-06-24 01:07:15.367721
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import unittest
    import datetime
    from abc import ABCMeta
    from .accounts import AccountType
    from .users import User, init_users

    class TestSource(metaclass=ABCMeta):
        pass

    def make_entry(date: datetime.date) -> JournalEntry[TestSource]:
        return JournalEntry(
            date, "Test journal entry", TestSource(),
        )

    init_users()
    User.objects.all().delete()

    user = User(name="Test User", email="test_user@test.com")
    user.save()
    user.create_accounts()

    income_account = user.get_account(AccountType.REVENUES, "Income")
    expense_account = user.get_account(AccountType.EXPENSES, "Expenses")
    bank_account

# Generated at 2022-06-24 01:07:18.318425
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    first_journal_entry = JournalEntry("2020-01-01", "First Journal Entry", "test", [])
    second_journal_entry = JournalEntry("2020-01-01", "First Journal Entry", "test", [])
    
    result = first_journal_entry == second_journal_entry
    expected = True
    assert result == expected, f"Test Failed."


# Generated at 2022-06-24 01:07:19.248542
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 01:07:22.573583
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    assert hash(JournalEntry(datetime.date.today(), "", None)) == hash("JournalEntry(date=datetime.date(2020, 8, 18), description='', source=None)")


# Generated at 2022-06-24 01:07:24.432359
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # TODO write test case
    Tested = True
    assert Tested

# Generated at 2022-06-24 01:07:28.595663
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    from .accounts import Account, Accounts

    assert str(Posting(None, None, Accounts['assets'], None, None)) == "Posting(journal=None, date=None, account=Account(type=<AccountType.ASSETS: 2>, name='Assets'), direction=None, amount=None)"

# Generated at 2022-06-24 01:07:39.038116
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from ..commons.numbers import zero
    from ..commons.others import makeguid

    @dataclass(frozen=True)
    class Bus(Generic[_T]):
        guid: Guid = field(default_factory=makeguid)
    
    bus = Bus()
    journal = JournalEntry(
        date = datetime.date(2020,4,19), 
        description = "This is a unit test", 
        source = bus)
    journal.post(datetime.date(2020,4,19), 
                 Account(name="Cash", type=AccountType.ASSETS), 
                 zero())
    journal.post(datetime.date(2020,4,19), 
                 Account(name="Revenues", type=AccountType.REVENUES), 
                 zero())

# Generated at 2022-06-24 01:07:40.905798
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass
