

# Generated at 2022-06-24 00:57:48.504317
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from ..commons.zeitgeist import DatePeriod
    date_period = DatePeriod()

    def dummy_read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return "dummy_read_journal_entries"
    read_journal_entries = ReadJournalEntries(dummy_read_journal_entries)
    # Type of read_journal_entries.__call__ : <class 'function'>
    # Type of read_journal_entries(date_period) : str
    print("Type of read_journal_entries.__call__ :", type(read_journal_entries.__call__))
    print("Type of read_journal_entries(date_period) :", type(read_journal_entries(date_period)))

# Generated at 2022-06-24 00:57:57.652445
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    # Given
    class _Source:
        pass

    j1 = JournalEntry[object](datetime.date.today(), "Test 1", _Source())
    j2 = JournalEntry[object](datetime.date.today(), "Test 2", _Source())
    p1_1 = Posting[object](j1, datetime.date.today(), "Assets:Account", Direction.INC, Amount(100))
    p1_2 = Posting[object](j1, datetime.date.today(), "Equities:Account", Direction.DEC, Amount(100))
    p2_1 = Posting[object](j2, datetime.date.today(), "Assets:Account", Direction.INC, Amount(100))

# Generated at 2022-06-24 00:57:59.000080
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(None).__class__ == str

# Generated at 2022-06-24 00:58:00.714626
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    je = JournalEntry(None, None)
    try:
        delattr(je, 'non_existent_attribute')
    except AttributeError:
        pass
    else:
        assert False, "Should have raised AttributeError"

# Generated at 2022-06-24 00:58:12.003279
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from commons.datetime import Date

    @dataclass(frozen=True)
    class Revenue:
        account: str

    revenue = Revenue("Revenue")

    je = JournalEntry(date=Date.today(), description="Fee", source=revenue)
    je.post(Date.today(), Account("Sales", AccountType.REVENUES), 100)
    je.post(Date.today(), Account("Cash at Bank", AccountType.ASSETS), -100)

    assert je.postings[0].is_debit == True
    assert je.postings[1].is_credit == True

    assert je.postings[0].direction == Direction.INC
    assert je.postings[1].direction == Direction.DEC

    assert je.postings[0].is_credit == False
    assert je.postings[1].is_deb

# Generated at 2022-06-24 00:58:20.630212
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # given
    je=JournalEntry[int](date=datetime.date.today(), description="", source=1)
    je.post(date=datetime.date.today(), account=Account(name="Assets", type=AccountType.ASSETS), quantity=10)
    je.post(date=datetime.date.today(), account=Account(name="Expenses", type=AccountType.EXPENSES), quantity=-10)

    # when
    try:
        je.validate()
    except AssertionError:
        pytest.fail("Validation failed")

    # then

# Generated at 2022-06-24 00:58:27.187005
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account

    account = Account("account", AccountType.ASSETS)

    JE = JournalEntry[None](date=datetime.date.today(), description="Test JE", source=None)
    JE.post(date=datetime.date.today(), account=account, quantity=1)

    assert len(JE.postings) == 1
    assert JE.postings[0].account == account
    assert JE.postings[0].amount == 1
    assert JE.postings[0].direction == Direction.INC



# Generated at 2022-06-24 00:58:37.514076
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    DEBIT_ACCOUNT = Account("Debit-Account", "Debit-Account", AccountType.ASSETS)
    CREDIT_ACCOUNT = Account("Credit-Account", "Credit-Account", AccountType.ASSETS)

    je1 = JournalEntry[object](datetime.date(2020, 1, 1), "", object())
    je1.post(datetime.date(2020, 1, 1), DEBIT_ACCOUNT, +1000)
    je1.post(datetime.date(2020, 1, 1), CREDIT_ACCOUNT, -1000)

    je2 = JournalEntry[object](datetime.date(2020, 1, 1), "", object())
    je2.post(datetime.date(2020, 1, 1), DEBIT_ACCOUNT, +1000)

# Generated at 2022-06-24 00:58:46.024308
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import Account, AccountType
    from .journal import JournalEntry

    date = datetime.date.today()
    description = 'Description'
    source = 'Source'
    guid = 'guid'

    account  = Account('Account', 'Account', AccountType.ASSETS)
    posting = JournalEntry(date, description, source).post(date, account, 1000).postings[0]
    journal_entry = JournalEntry(date, description, source, [posting], guid)

    # Check that the hash of JournalEntry is the hash of the guid
    assert hash(journal_entry) == hash(guid)


# Generated at 2022-06-24 00:58:47.036844
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert ReadJournalEntries(period=DateRange()).__call__

# Generated at 2022-06-24 00:58:50.699883
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal_entry_hash = JournalEntry(datetime.date(2020, 1, 1), "Testing Journal Entry", 1)
    assert hash(journal_entry_hash) == hash(journal_entry_hash.guid.__str__() + journal_entry_hash.__str__())


# Generated at 2022-06-24 00:58:59.064896
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    """
    Test method __hash__ of class JournalEntry.
    """

    # Test if two equal journal entries have equal hashes.
    assert JournalEntry(datetime.date(2020, 1, 1), "desc", None, list([])) == \
        JournalEntry(datetime.date(2020, 1, 1), "desc", None, list([]))
    assert hash(JournalEntry(datetime.date(2020, 1, 1), "desc", None, list([]))) == \
        hash(JournalEntry(datetime.date(2020, 1, 1), "desc", None, list([])))

    # Test if two unequal journal entries have different hashes.

# Generated at 2022-06-24 00:59:07.753497
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal_date = datetime.date.today()
    account = Account('A')
    journal = JournalEntry[str](journal_date, 'test journal', 'test source')
    entry_date = datetime.date.today()
    direction = Direction.INC
    amount = Amount(10)
    posting = Posting(journal, entry_date, account, direction, amount)
    assert repr(posting) == "Posting(journal=JournalEntry(date=2020-06-06, description='test journal', source='test source', guid='5550a6f7-6d47-4a7d-a926-3ead3da970ce'), date=2020-06-06, account=Account(name='A', type=ASSETS), direction=INC, amount=Amount(10))"

# Generated at 2022-06-24 00:59:15.804346
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    class Dummy:
        pass
    assert hash(Posting(JournalEntry(datetime.date(2019, 1, 1), "", Dummy()),
                        datetime.date(2019, 1, 1), Account("", "", AccountType.ASSETS),
                        Direction.INC, Amount(1))) == hash((JournalEntry(datetime.date(2019, 1, 1), "", Dummy()),
                                                            datetime.date(2019, 1, 1), Account("", "", AccountType.ASSETS),
                                                            Direction.INC, Amount(1)))

# Generated at 2022-06-24 00:59:17.304683
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    obj_1 = Posting()
    obj_2 = Posting()
    assert hash(obj_1) == hash(obj_2)


# Generated at 2022-06-24 00:59:18.587798
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-24 00:59:19.529833
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    it = ReadJournalEntries()

# Generated at 2022-06-24 00:59:31.449744
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    @dataclass(frozen=True)
    class JournalEntryTest(_T):
        """
        Provides a journal entry model
        """
        @property
        def increments(self) -> Iterable[Posting[_T]]:
            return None

        @property
        def decrements(self) -> Iterable[Posting[_T]]:
            return None

        @property
        def debits(self) -> Iterable[Posting[_T]]:
            return None

        @property
        def credits(self) -> Iterable[Posting[_T]]:
            return None
        def validate(self) -> None:
            self.journal.validate(self.period)
    try:
        del JournalEntryTest.increments
    except AttributeError:
        assert True == True
    else:
        assert True == False

# Generated at 2022-06-24 00:59:35.489590
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    datetime_today = datetime.date.today()
    je = JournalEntry[int]()
    assert je.date == datetime_today
    assert je.description == ""
    assert je.source == 0
    assert je.postings == []
    assert je.guid != ""

# Generated at 2022-06-24 00:59:38.022756
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    with pytest.raises(AttributeError):
        journal_entry = JournalEntry[str](datetime.date.today(), "My description", "My source")
        journal_entry.date.today()



# Generated at 2022-06-24 00:59:46.757236
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    _period = DateRange(start=datetime.date(2020, 1, 1))

    @dataclass
    class Sample:
        index: int

    def read(period: DateRange) -> Iterable[JournalEntry[Sample]]:
        return [JournalEntry[Sample](date=datetime.date(2020, 1, index), description=f"Sample{index}", source=Sample(index))
                for index in range(1, 30 + 1)]

    rje = ReadJournalEntries[Sample]()
    assert read(_period) == rje(_period)



# Generated at 2022-06-24 00:59:47.290757
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass

# Generated at 2022-06-24 00:59:56.089616
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import Stock
    from .markets import Exchange

    assert Posting(JournalEntry(date="2017-01-01", description="a", source=Stock("MSFT", Exchange("NYSE"))), date="2017-01-01", account=Account("foo", AccountType.ASSETS), direction=Direction.INC, amount=Amount(100)) == Posting(JournalEntry(date="2017-01-01", description="a", source=Stock("MSFT", Exchange("NYSE"))), date="2017-01-01", account=Account("foo", AccountType.ASSETS), direction=Direction.INC, amount=Amount(100))

# Generated at 2022-06-24 00:59:56.587365
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-24 00:59:58.275426
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    jo = JournalEntry('2018-01-01', 'Pay 15k to somebody', None)
    del jo.postings

# Generated at 2022-06-24 01:00:01.593651
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # arrange
    je_date = datetime.date(2020, 1, 2)
    je_description = "Test 1"
    je = JournalEntry(je_date, je_description)
    # assert
    assert je.date == je_date
    assert je.description == je_description


# Generated at 2022-06-24 01:00:04.374053
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 01:00:09.413373
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    description = "description"
    source = 'source'
    # dictionary of account and quantity
    data = {'Account 1': 100, 'Account 2':-100}
    # Constructor test
    entry = JournalEntry[str](datetime.date(2019, 1, 31), description, source)
    for account, quantity in data.items():
        entry.post(datetime.date(2019, 1, 31), account, quantity)

    entry.validate() # validation test

# Generated at 2022-06-24 01:00:16.550642
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Arrange:
    class ReadJournalEntriesImpl(Generic[_T]):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            # pass
            return iter((JournalEntry[str](date=datetime.date.today(), description="", source=""),))

    # Act:
    mock = ReadJournalEntriesImpl()
    result = list(mock(None))

    # Assert:
    assert (
        result[0] ==
        JournalEntry[str](date=datetime.date.today(), description="", source="")
    )

# Generated at 2022-06-24 01:00:17.655186
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class Foo:
        pass

    foo1 = Foo()

# Generated at 2022-06-24 01:00:27.333424
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import _MISSING_TYPE
    from unittest import TestCase

    @dataclass(frozen=True)
    class BusinessObject:
        #
        # Public attributes
        #
        name: str = "BusinessObject"

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        #
        # Public attributes
        #
        date: datetime.date
        description: str
        source: _T

        #
        # Private attributes
        #
        _postings: List[Posting[_T]] = field(default_factory=list)

        #
        # Public methods
        #
        def post(self, date: datetime.date, account: Account, quantity: Quantity) -> "JournalEntry":
            #
            # Implement method
            #
            self

# Generated at 2022-06-24 01:00:30.761816
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je = JournalEntry(datetime.date(2020, 1, 1), 'abc', 1)
    je = je.post(datetime.date(2020, 1, 1), Account.of('Assets', 'Current Assets', 'Cash'), -100)
    je = je.post(datetime.date(2020, 1, 1), Account.of('Revenue', 'Sales'), 100)

# Generated at 2022-06-24 01:00:32.337493
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    pass

# Generated at 2022-06-24 01:00:35.927779
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class Foo: pass
    lx = []
    rje = lambda period: lx.append(1)
    rjef = ReadJournalEntries.__getitem__(Foo, ReadJournalEntries.__args__)
    rjef(rje, None, None)
    assert lx == [1]

# Generated at 2022-06-24 01:00:44.698848
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Accounts
    from .open_books import OpenBooks

    books = OpenBooks()
    accounts = Accounts()

    a1 = accounts.add_account(101, "101", "101", AccountType.ASSETS)
    a2 = accounts.add_account(102, "102", "102", AccountType.REVENUES)

    je = books.create_jorunal_entry(datetime.date.today())
    je.post(datetime.date.today(), a1, 100)
    je.post(datetime.date.today(), a2, -100)

    print(je)

    p1 = Posting(je, datetime.date.today(), a1, Direction.INC, 100)
    p2 = Posting(je, datetime.date.today(), a2, Direction.DEC, 100)

   

# Generated at 2022-06-24 01:00:45.543832
# Unit test for constructor of class Posting
def test_Posting():
    assert False


# Generated at 2022-06-24 01:00:50.118939
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    A = Posting(journal=None, date=datetime.date.today(), account=None, direction=None, amount=None)
    B = Posting(journal=None, date=datetime.date.today(), account=None, direction=None, amount=None)
    assert A == B

# Generated at 2022-06-24 01:00:57.021868
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from dataclasses import dataclass
    from ..commons.others import Guid
    from .accounts import Account, AccountType

    @dataclass(frozen=True)
    class JournalEntry:
        #: Date of the entry.
        date: datetime.date
        #: Description of the entry.
        description: str
        #: Business object as the source of the journal entry.
        source: _T
        #: Postings of the journal entry.
        postings: List[Posting[_T]] = field(default_factory=list, init=False)
        #: Globally unique, ephemeral identifier.
        guid: Guid = field(default_factory=makeguid, init=False)


# Generated at 2022-06-24 01:01:01.933570
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Initialise variables
    _date = datetime.datetime(2019, 1, 1)
    _description = "Test Entry"
    _source = "Test"
    _postings = None

    # Construct the object
    _journal_entry = JournalEntry(_date, _description, _source, _postings)

    # Perform the test
    assert isinstance(_journal_entry, JournalEntry)

# Generated at 2022-06-24 01:01:09.306769
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class A:
        pass

    @dataclass(frozen=True)
    class B:
        a: int
        b: str

    rje: ReadJournalEntries[A] = lambda period: [JournalEntry(datetime.date(2000, 1, 1), 'desc', A())]
    assert isinstance(rje, ReadJournalEntries)

    try:
        _: ReadJournalEntries[B] = lambda period: [JournalEntry(datetime.date(2000, 1, 1), 'desc', A())]
        assert False, 'should raise TypeError'
    except TypeError:
        pass

# Generated at 2022-06-24 01:01:21.046453
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    '''
    Test for method __repr__
    '''
    from .accounts import Account
    from .journal import JournalEntry, Posting, Direction
    from .taxes import Tax
    from .sales import Sale, SalesJournal
    import datetime
    from dataclasses import dataclass
    from typing import TypeVar
    
    _T = TypeVar("_T")
    
    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """
    
        #: Date of the entry.
        date: datetime.date
    
        #: Description of the entry.
        description: str
    
        #: Business object as the source of the journal entry.
        source: _T
    
        #: Postings of the journal entry

# Generated at 2022-06-24 01:01:25.126677
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    je = JournalEntry(datetime.date(1,2,3), 'description', 'source')
    assert hasattr(je, 'guid')
    delattr(je, 'guid')
    assert not hasattr(je, 'guid')

# Generated at 2022-06-24 01:01:34.132519
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journalEntry_test_1 = JournalEntry[str](datetime.date(2019, 9, 1), "test", "aaaa", [])
    journalEntry_test_2 = JournalEntry[str](datetime.date(2019, 9, 1), "test", "aaaa", [])
    journalEntry_test_3 = JournalEntry[str](datetime.date(2019, 9, 15), "test", "aaaa", [])
    journalEntry_test_4 = JournalEntry[str](datetime.date(2019, 9, 1), "test1", "aaaa", [])
    journalEntry_test_5 = JournalEntry[str](datetime.date(2019, 9, 1), "test", "aaaa1", [])

# Generated at 2022-06-24 01:01:34.638435
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-24 01:01:35.218420
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass

# Generated at 2022-06-24 01:01:36.059264
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 01:01:45.769932
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Asset
    from .others import Company
    from .read import ReadAccounts
    from .read import ReadCompanies
    from .read import ReadCurrencies
    from .read import ReadTransactionUnits
    from .transaction import Transaction
    import datetime
    from dataclasses import dataclass, field
    from enum import Enum
    from typing import Generic, List, TypeVar
    import sys

    #: Defines a type variable.
    _T = TypeVar("_T")

    class Direction(Enum):
        """
        Provides an enumeration for indicating increment and decrement events.
        """

        #: Declares the value type.
        value: int

        #: Indicates increment events.
        INC = +1

        #: Ind

# Generated at 2022-06-24 01:01:48.379438
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    # Given
    journal=JournalEntry("journal")

    # When
    posting=Posting("journal", 'date', 'account', 'direction', 'amount')

    # Then
    assert posting.journal == "journal"
    assert posting.date == 'date'
    assert posting.account == 'account'
    assert posting.direction == 'direction'
    assert posting.amount == 'amount'


# Generated at 2022-06-24 01:01:51.020324
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-24 01:01:59.814565
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import Account, AccountType, createAccount
    p = Posting(JournalEntry(), datetime.date(2020, 4, 1), createAccount(AccountType.ASSETS, "Cash"), Direction.INC, 100)
    assert p.journal == JournalEntry()
    assert p.date == datetime.date(2020, 4, 1)
    assert p.account == createAccount(AccountType.ASSETS, "Cash")
    assert p.direction == Direction.INC
    assert p.amount == 100
    assert p.is_debit == True
    assert p.is_credit == False


# Generated at 2022-06-24 01:02:01.149887
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    """
    Unit test for method `__delattr__` of class `Posting`
    """
    pass

# Generated at 2022-06-24 01:02:05.575860
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    def test_method(posting, value):
        posting.a = value

    try:
        posting = Posting(None, datetime.date(2020, 6, 1), None, None, Amount(0))
        test_method(posting, 42)
    except:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-24 01:02:16.166477
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from dataclasses import dataclass
    from typing import List
    from .accounts import Account
    from .booking import Book, Booking
    from .dates import Date
    from .numbers import Amount, Quantity


# Generated at 2022-06-24 01:02:25.490666
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # Arrange
    posting = Posting(JournalEntry(date=datetime.date(2018, 9, 1), description="description", source=1), datetime.date(2018, 9, 1), Account(type=AccountType.ASSETS, name="name"), Direction.INC, Amount(1.0))

    # Act
    result = posting.__repr__()

    # Assert
    assert result == "Posting(journal=JournalEntry(date=datetime.date(2018, 9, 1), description='description', source=1), date=datetime.date(2018, 9, 1), account=Account(type=<AccountType.ASSETS: 10>, name='name'), direction=<Direction.INC: 1>, amount=Amount(value=1.0))"


# Generated at 2022-06-24 01:02:32.686117
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Setup:
    j = JournalEntry[None](
        date=datetime.date(2013, 2, 27), description="Description", source=None,
    )
    j.post(date=datetime.date(2013, 2, 27), account=Account.of("bank", "RBC", AccountType.ASSETS), quantity=3000)
    j.post(date=datetime.date(2013, 2, 27), account=Account.of("train", "Skytrain", AccountType.EQUITIES), quantity=300)
    j.post(date=datetime.date(2013, 2, 27), account=Account.of("expense", "Meal", AccountType.EXPENSES), quantity=-100)

# Generated at 2022-06-24 01:02:39.868732
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry(datetime.date(2015, 1, 1), "des", "source") == JournalEntry(datetime.date(2015, 1, 1), "des", "source")
    assert JournalEntry(datetime.date(2015, 1, 1), "des", "source") != JournalEntry(datetime.date(2015, 1, 2), "des", "source")
    assert JournalEntry(datetime.date(2015, 1, 1), "des0", "source") != JournalEntry(datetime.date(2015, 1, 1), "des", "source")
    assert JournalEntry(datetime.date(2015, 1, 1), "des", "source0") != JournalEntry(datetime.date(2015, 1, 1), "des", "source")

# Generated at 2022-06-24 01:02:41.579354
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass

# Generated at 2022-06-24 01:02:47.721766
# Unit test for constructor of class Posting
def test_Posting():
    p1 = Posting(None, datetime.date(2020, 1, 1), None, Direction.INC, 10000)
    assert p1.is_debit == False
    assert p1.is_credit == True


# Generated at 2022-06-24 01:02:57.919708
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from ..accounting.accounts import Account, AccountType
    from ..accounting.taxonomy import Taxonomy
    from ..accounting.transactions import TransactionFactory, TransactionSchema

    txn_schema = TransactionSchema.build(
        "example",
        [Taxonomy.build(AccountType.REVENUES, "REV", "Revenues"),
         Taxonomy.build(AccountType.ASSETS, "ASSET", "Assets")],
        [Account.build("REV001", "Sales"),
         Account.build("ASSET001", "Accumulated Revenue")]
    )
    txn_factory = TransactionFactory.build(txn_schema)


# Generated at 2022-06-24 01:03:02.056966
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    foo = Posting(Guid("a"),datetime.date(2020,3,3), Account("a", "", "", AccountType("a"), Guid("a")),Direction.DEC, Amount("100"))
    theHash = hash(foo)
    assert (theHash != None)

# Generated at 2022-06-24 01:03:09.667605
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journaltest = JournalEntry[str](datetime.date(2020, 5, 1), "test", "book", list())
    postingtest = Posting[str](journaltest, datetime.date(2020, 5, 1), Account("compte", AccountType.ASSETS), Direction.INC, Amount(11))
    assert hash(postingtest) == hash((postingtest.journal, postingtest.date, postingtest.account, postingtest.direction, postingtest.amount))


# Generated at 2022-06-24 01:03:13.574498
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date
    from pytime import weeday

    j = JournalEntry[object](
        date(2020, 7, weeday.thursday),
        "my desc",
        my_source_obj,
    )
    j.post(date(2020, 7, 1), account1, 100.0)
    for p in j.postings:
        p.account

# Generated at 2022-06-24 01:03:19.811433
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():

    from datetime import date

    from .accounts import ROOT, Account, AccountType

    # _date = date(2019, 2, 1)

    # s = JournalEntry(_date, 'Test')
    # s.postings.append(3)

    s = JournalEntry(date(2019, 2, 1), 'Test')
    s.post(date(2019, 2, 1), Account(ROOT, AccountType.ASSETS, 'Cash'), 50)

    pass

# Generated at 2022-06-24 01:03:28.374654
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from datetime import date

    # revenues
    product_sale = Account("11", "Sales of product")
    commission = Account("12", "Sales commission")

    # expenses
    product = Account("21", "Purchased product")
    # other
    cash = Account("50", "Cash")
    bank = Account("60", "Bank")

    # Define a business object
    @dataclass
    class SaleRecord:
        date: date
        quantity: Quantity
        sale: Amount

    # Create first journal entry
    jh = JournalEntry(date(2020, 3, 1), "Sale record 1", SaleRecord(date(2020, 3, 1), +7, +100))

# Generated at 2022-06-24 01:03:36.021794
# Unit test for constructor of class Posting
def test_Posting():
    date = datetime.date.today()
    date_string = str(date)
    journal = JournalEntry[str]()
    account = Account("account")
    direction = Direction.INC
    amount = Amount(10000)
    posting = Posting(journal,date,account,direction,amount)
    assert posting.journal.description == journal.description
    assert posting.date.__str__() == date_string
    assert posting.account.name == account.name
    assert posting.direction == direction
    assert posting.amount == amount
    assert posting.is_debit
    assert not posting.is_credit

# Generated at 2022-06-24 01:03:39.254222
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    j1 = JournalEntry(datetime.date.today(), "description", None)
    j2 = JournalEntry(datetime.date.today(), "description", None)
    assert j1 == j2


# Generated at 2022-06-24 01:03:46.931113
# Unit test for method __setattr__ of class JournalEntry

# Generated at 2022-06-24 01:03:52.288540
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from ..commons.events import Event
    from ..domainmodels.accountbook import AccountBook
    from ..domainmodels.accountbook import EventRecord

    def create_journal(accountbook, eventlog):
        class Journal(EventRecord):
            def on_record(self, event: Event) -> None:
                self.scope.journal(self.record_date, "test_journal", self.scope).post(
                    self.record_date, accountbook.accounts[0], 1 * event.amount
                )

        return Journal(accountbook, eventlog, accountbook.journal_entries)

    accountbook = AccountBook()
    journal = create_journal(accountbook, accountbook.events)

    #:
    #: This demonstrates that the delete of object attributes is not allowed.
    #:


# Generated at 2022-06-24 01:03:54.294179
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    """
    Unit test for constructor of class ReadJournalEntries.
    """
    # Check:
    assert ReadJournalEntries

# Generated at 2022-06-24 01:04:05.767079
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    
    today = datetime.date.today()
    journal = JournalEntry(today, "", "")

    journal.post(today, Account('ASSETS', AccountType.ASSETS), Amount(100))
    journal.post(today, Account('EXPENSES', AccountType.EXPENSES), Amount(100))

    # test to pass
    journal.validate()
    
    journal.post(today, Account('EXPENSES', AccountType.EXPENSES), Amount(100))
    
    # test to fail
    try:
        journal.validate()
        assert False, "Failed to throw an exception when debits and credits did not match"
    except:
        assert True # Successfully threw an exception

    journal = JournalEntry(today, "", "")


# Generated at 2022-06-24 01:04:08.624951
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        return []
    assert isinstance(read_journal_entries, ReadJournalEntries)

# Generated at 2022-06-24 01:04:18.636018
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():

    # Entry 1:
    entry1 = JournalEntry[None](
        date=datetime.date(2015, 9, 3),
        description="Purchase of 10Nos. of Widget1 @ $100 each",
        source=None,
    )
    entry1.post(
        date=entry1.date,
        account=Account(code='1000', name='Cash', type=AccountType.ASSETS),
        quantity=-1 * (10 * 100),  # -$1000
    ).post(
        date=entry1.date,
        account=Account(code='2400', name='Inventory', type=AccountType.EQUITIES),
        quantity=10,  # 10 Nos. of Widget1
    )

    # Entry 2:

# Generated at 2022-06-24 01:04:23.046689
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    import datetime
    from ..books.business import Business, BusinessType

    mybusiness = Business('David', datetime.date(1998, 8, 27), BusinessType.SOLE_PROPRIETORSHIP, '123456789', None, None)
    je = JournalEntry(datetime.date(1998, 8, 27), 'Business Creation', mybusiness)

    assert je.date == datetime.date(1998, 8, 27)
    assert je.description == 'Business Creation'
    assert je.source == mybusiness
    assert je.postings == []


# Generated at 2022-06-24 01:04:26.871225
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journal_entry = JournalEntry(date = datetime.date(2020,5,5), description = 'description', source = 1)
    hash_value = hash(journal_entry)
    assert hash_value != 0
    return hash_value

# Generated at 2022-06-24 01:04:37.189645
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    v1_1 = JournalEntry(datetime.date.today(), 'Test journal entry', None, [])
    v1_2 = JournalEntry(datetime.date.today(), 'Test journal entry', None, [])
    v1_3 = JournalEntry(datetime.date.today(), 'Test journal entry', None, [])
    v1_3.post(datetime.date.today(), Account('Assets', 'Cash', AccountType.ASSETS), 100)
    v1_4 = JournalEntry(datetime.date.today(), 'Test journal entry', None, [])
    v1_4.post(datetime.date.today(), Account('Assets', 'Cash', AccountType.ASSETS), 100)

# Generated at 2022-06-24 01:04:38.632359
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass


# Generated at 2022-06-24 01:04:44.981461
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry("JournalEntry Mock")
    account = Account("Account Mock")
    amount = Amount(Quantity(100))
    date = datetime.date(2019, 4, 17)
    direction = Direction.INC
    posting = Posting(journal, date, account, direction, amount)

    s = posting.__repr__()

    assert s == "Posting(journal=JournalEntry('JournalEntry Mock'), date=datetime.date(2019, 4, 17), account=Account('Account Mock'), direction=<Direction.INC: 1>, amount=100)"


# Generated at 2022-06-24 01:04:50.567671
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    j = JournalEntry(datetime.date(2019, 1, 1), "hello", 1)
    p = Posting(j, datetime.date(2019, 1, 1), Account(1, "A", AccountType.ASSETS), Direction.INC, Amount(100))
    assert str(p) == "Posting(journal=JournalEntry(date=datetime.date(2019, 1, 1), description='hello', source=1, guid='75dca7ae-3770-45b8-8eef-c05d57b1b3e3'),\
date=datetime.date(2019, 1, 1), account=Account(id=1, name='A', type=AccountType.ASSETS), direction=Direction.INC, amount=Amount(100))"

# Generated at 2022-06-24 01:05:02.526922
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account
    from .ledgers import Ledger
    from .books import Book
    
    journalEntry = JournalEntry(datetime.date(2020,1,1), "Journal Entry", "Source")

    journalEntry.post(datetime.date(2020,1,1), Account.parse("Assets:Cash"), 10000000)
    journalEntry.post(datetime.date(2020,1,1), Account.parse("Revenues:Sales"), -10000000)

    assert len(journalEntry.postings) == 2
    
    ledger = Ledger(Book(None), None)

    ledger.post(journalEntry)
    assert ledger.get_account_balance(Account.parse("Assets:Cash")) == 10000000
    assert ledger.get_account_balance(Account.parse("Revenues:Sales")) == 0

# Generated at 2022-06-24 01:05:08.017389
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Create two journal entries with the same properties
    journal_1 = JournalEntry(datetime.date(2020, 7, 1), "test description", "test source")
    journal_2 = JournalEntry(datetime.date(2020, 7, 1), "test description", "test source")
    # Check that the objects have the same hash
    assert hash(journal_1) == hash(journal_2)

# Generated at 2022-06-24 01:05:15.118675
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Check __setattr__ of class JournalEntry
    """
    from ..commons.zeitgeist import DateTimeRange
    from .accounts import Account

    dateFrom = datetime.date(2016, 10, 14)
    dateTo = datetime.date(2016, 10, 15)
    dateTimeFrom = datetime.datetime(2016, 10, 14, 0, 0, 0)
    dateTimeTo = datetime.datetime(2016, 10, 15, 23, 59, 59)
    dateRange = DateTimeRange(dateTimeFrom, dateTimeTo)

    # pylint: disable=unused-variable
    def readJournalEntries(_dateRange: DateTimeRange) -> Iterable[JournalEntry[_T]]:
        """
        Reads journal entries
        """
        return []


# Generated at 2022-06-24 01:05:24.122124
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from .accounts import Account, AccountType
    from .journal import Journal
    from .ledgers import Ledger, ReadLedger


    journal = Journal('journal', 'ledger', 'journal group')
    ledger = Ledger('ledger', 'ledger group')
    account1 = Account('account', 'account group', AccountType.ASSETS)
    account2 = Account('account', 'account group', AccountType.LIABILITIES)

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        if period.start == datetime.date(2019, 1, 1) and period.end == datetime.date(2019, 12, 31):
            entry = JournalEntry(
                date=datetime.date(2019, 1, 1),
                description='Test',
                source=journal
            )

# Generated at 2022-06-24 01:05:31.168940
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from .accounts import Account, AccountType

    @dataclass(frozen=True)
    class _AccountSource(Generic[_T]):
        entries: Iterable[JournalEntry[_T]]

    @dataclass(frozen=True)
    class _Source(_T):
        pass


# Generated at 2022-06-24 01:05:36.420518
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    class X:
        pass
    x = X()
    p = Posting(date=datetime.date.today(), account=Account("A"), direction=Direction.INC, amount=Amount(10), journal=x)
    assert hash(p) == hash((p.date, p.account, p.direction, p.amount, p.journal))


# Generated at 2022-06-24 01:05:40.282804
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # J04
    _ = JournalEntry(datetime.date(2020, 5, 2), "AR Receipt: 8902984", 91209879089,
                     [Posting(1, datetime.date(2020, 5, 2), "Receivables: AR(8902984)", Direction.INC, Amount(321865))])

# Generated at 2022-06-24 01:05:49.613112
# Unit test for constructor of class Posting
def test_Posting():
    a = "a"
    b = "b"
    c = "c"
    test_date = datetime.date.today()
    test_account = Account("Test Account", AccountType.REVENUES)
    test_direction = Direction.INC
    test_amount = Amount(10)

    test_posting = Posting(a, test_date, test_account, test_direction, test_amount)

    assert test_posting.journal == a
    assert test_posting.date == test_date
    assert test_posting.account == test_account
    assert test_posting.direction == test_direction
    assert test_posting.amount == test_amount
    assert test_posting.is_debit is False
    assert test_posting.is_credit is True


# Generated at 2022-06-24 01:05:54.145470
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    le = JournalEntry(datetime.date(2020, 1, 1), "test", None)
    le.post(le.date, Account(AccountType.REVENUES, "Test", "TST"), -100)
    le.post(le.date, Account(AccountType.EXPENSES, "Test", "TST"), 100)
    le.validate()


# Generated at 2022-06-24 01:06:05.189133
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    import datetime
    from datetime import datetime, timedelta
    from typing import Any, List, Union
    from mydata import ReadJournalEntries
    from mydata.accounts import Account, AccountType
    from mydata.journal import Direction, JournalEntry, Posting
    from mydata.zeitgeist import DateRange

    def example_read(period: DateRange) -> List[JournalEntry[Any]]:
        journal = JournalEntry[Any](datetime(2020,3,1), "Net pay") \
            .post(datetime(2020,3,1), Account("Salaries payable",AccountType.LIABILITIES), +10000) \
            .post(datetime(2020,3,1), Account("Cash", AccountType.ASSETS), -10000)
        assert journal.validate() is None

        return [journal]

    read_journal_

# Generated at 2022-06-24 01:06:16.289283
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import Field

    #: Date of the entry
    date = datetime.date(2019,12,13)

    #: Description of the entry.
    description = 'My first journal entry'

    #: Business object as the source of the journal entry.
    source = 'My first journal entry'

    #: Postings of the journal entry.
    postings = [Posting]

    #: Globally unique, ephemeral identifier.
    guid = Guid

    # Initializing JournalEntry object
    journal_entry = JournalEntry(date, description, source)

    # Checking if the fields in the JournalEntry object are the same as the defined variables
    for field in dataclasses.fields(journal_entry):
        assert field.name in journal_entry.__dict__

# Generated at 2022-06-24 01:06:24.185087
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    import datetime
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account

    a = Account(name="a")
    b = Account(name="b")
    c = Account(name="c")
    d = Account(name="d")

    je = JournalEntry((), "Test", (), [])
    je.post(datetime.date(2020,1,1), a, Quantity(1))
    je.post(datetime.date(2020,1,2), b, Quantity(2))
    je.post(datetime.date(2020,1,3), c, Quantity(3))
    je.post(datetime.date(2020,1,4), d, Quantity(4))
    assert len(je.postings) == 4

# Generated at 2022-06-24 01:06:30.083996
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    entry1 = JournalEntry(datetime.date(2020, 10, 10), 'Test', object())
    entry2 = JournalEntry(datetime.date(2020, 10, 10), 'Test2', object())
    entry3 = JournalEntry(datetime.date(2020, 10, 10), 'Test', object())
    assert hash(entry1) == hash(entry2)
    assert hash(entry1) != hash(entry3)


# Generated at 2022-06-24 01:06:31.717905
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # Test for constructor
    assert ReadJournalEntries is not None

# Generated at 2022-06-24 01:06:34.812844
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je = JournalEntry("2019-1-1", "Description")
    je2 = JournalEntry("2019-1-1", "Description")
    assert hash(je) == hash(je2)

# Generated at 2022-06-24 01:06:45.874401
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from unittest.mock import Mock
    from accountobjects import *
    from journalobjects import *
    from journalobjects import JournalEntry
    def test_JournalEntry___delattr__(self):
        journal_entry = JournalEntry('2008-01-01', 'Test Journal Entry', Mock(), [Posting(Mock(), '2008-01-01', Account(AccountType.ASSETS, 'Cash', '', True, 'USD'), Direction.INC, Amount(Decimal('10.00'))), Posting(Mock(), '2008-01-01', Account(AccountType.EQUITIES, 'Dividends', '', True, 'USD'), Direction.DEC, Amount(Decimal('10.00')))])
        try:
            delattr(journal_entry, 'postings')
            assert False
        except AttributeError:
            assert True

# Generated at 2022-06-24 01:06:47.999838
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from dataclasses import is_dataclass
    assert is_dataclass(JournalEntry)



# Generated at 2022-06-24 01:06:49.439028
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    assert True


# Generated at 2022-06-24 01:06:53.689875
# Unit test for constructor of class Posting
def test_Posting():
    Jane = Posting('Jane','19th May','ASSETS')
    print('Jane info:')
    print(Jane.journal)
    print(Jane.date)
    print(Jane.account)
    print(Jane.direction)
    print(Jane._isDebit)

# Generated at 2022-06-24 01:06:56.624646
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class ReadJournalEntriesHelper:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    ReadJournalEntriesHelper()


# Generated at 2022-06-24 01:07:03.542184
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Set-up
    JE = JournalEntry   # alias for JournalEntry

    # Exercise 1
    je1 = JE(date=datetime.date.today(), description="Test-JE-1").post(date=datetime.date.today(), account=Account(1, name="Test-A-1"), quantity=+1)

    # Exercise 2
    je2 = JE(date=datetime.date.today(), description="Test-JE-1").post(date=datetime.date.today(), account=Account(2, name="Test-A-2"), quantity=-1)

    # Exercise 1 & Verify
    je1.validate()

    # Exercise 2 & Verify
    je2.validate()

# Generated at 2022-06-24 01:07:09.852586
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # GIVEN a JournalEntry instance
    journalEntry = JournalEntry("06/12/2020", "description", "source", "Postings")

    # WHEN the method __hash__ is called
    result = hash(journalEntry)

    # THEN the result is the hash of the journalEntry
    assert result == hash(journalEntry)

# Generated at 2022-06-24 01:07:15.616420
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(None, None, None, None, None)
    p2 = p1
    p3 = Posting(None, None, None, None, None)
    assert p1 is p2
    assert not p1 == p3


# Generated at 2022-06-24 01:07:26.537615
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal = JournalEntry(datetime.date(2020, 2, 1), "COGS", "txn_001")
    assert(journal.date == datetime.date(2020, 2, 1))
    assert(journal.description == "COGS")
    assert(journal.source == "txn_001")
    assert(journal.postings == [])
    assert(journal.guid == "1ef23003-2d7c-4fc6-963d-b4fed5b7f976")

    journal.post(datetime.date(2020, 2, 1), Account.of("Inventory"), Quantity(100))
    journal.post(datetime.date(2020, 2, 1), Account.of("CostOfGoodSold"), Quantity(-100))
    journal.validate()


# Generated at 2022-06-24 01:07:35.395409
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import Account
    from .persistence import InMemory
    from .business import Business

    store = InMemory()

    business = Business(store, "test", "Test Business", "NZD")

    business._create_account_hierarchy()

    dr_acct = business.accounts.assets.cash.deposit
    cr_acct = business.accounts.expenses.meal

    je = JournalEntry(
        description="test",
        source=None,
        date=datetime.date(2020, 1, 1)
    )

    je.post(datetime.date(2020, 1, 1), dr_acct, +100.0)
    je.post(datetime.date(2020, 1, 1), cr_acct, -100.0)

    je.validate()

    print(je)

# Generated at 2022-06-24 01:07:44.526393
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from dataclasses import dataclass
    from typing import List

    class Account:
        pass

    @dataclass
    class JournalEntry:
        account: Account
        date: DateRange

    class ReadJournalEntries(Protocol):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            pass

    def read_journal_entries(period: DateRange) -> List[JournalEntry]:
        return []

    ReadJournalEntries.register(read_journal_entries)
    assert callable(read_journal_entries)
    read_journal_entries(DateRange(1, 1)) # type: ignore