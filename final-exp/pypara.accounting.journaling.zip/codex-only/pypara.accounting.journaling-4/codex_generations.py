

# Generated at 2022-06-24 00:57:40.548257
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    j1 = JournalEntry('2017-01-01', 'First entry', None)
    j2 = JournalEntry('2017-01-01', 'First entry', None)
    assert (j1 == j2)


# Generated at 2022-06-24 00:57:41.152833
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    pass

# Generated at 2022-06-24 00:57:41.847287
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass


# Generated at 2022-06-24 00:57:51.029543
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import Account
    
    from .accounts import AccountType

    from .commons.numbers import Amount

    from .commons.others import makeguid

    from .commons.zeitgeist import DateRange

    from .journals import JournalEntry

    from assertpy import assert_that

    import datetime

    je1 = JournalEntry[str](datetime.date.today(), '', '', '')

    je2 = JournalEntry[str](datetime.date.today(), '', '', '')

    p1 = Posting[str](je1, je1.date, Account.of(AccountType.ASSETS, "", ""), Direction.INC, Amount("1.00"))


# Generated at 2022-06-24 00:57:54.603762
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    class T:
        pass

    with pytest.raises(AttributeError):
        JournalEntry[T].postings.append("Test")
    with pytest.raises(AttributeError):
        JournalEntry[T].guid = "Test"

# Generated at 2022-06-24 00:58:05.332903
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from ..commons.ammool import ammool
    from .ledger import Ledger
    from .books import Books
    from ..core.accounts.core import (
        EquityAccount,
        ExpenseAccount,
        RevenueAccount,
        AssetAccount,
        LiabilityAccount,
    )

    ## Setup:
    book = Books(Ledger)

    ## Define a function to read journal entries under a date range:
    def read_entries(rng: DateRange) -> Iterable[JournalEntry[ammool]]:
        return book.journal.read(rng)


# Generated at 2022-06-24 00:58:13.524816
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType, Account
    from .products import SimpleProduct

    from ..commons.dates import DateRange

    from datetime import date


# Generated at 2022-06-24 00:58:13.950899
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert True

# Generated at 2022-06-24 00:58:19.390607
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    """
    Tests method __hash__ of class Posting<_>
    """
    
    ## Arrange ##
    source = "source"
    description = "description"
    date = datetime.datetime.now()
    account = Account("account name", AccountType.REVENUES, "some notes")
    direction = Direction.INC
    amount = Amount(10)
    jentry = JournalEntry(date, description, source)
    posting1 = Posting(jentry, date, account, direction, amount)
    posting2 = Posting(jentry, date, account, direction, amount)
    
    ## Action ##
    posting_hash1 = hash(posting1)
    posting_hash2 = hash(posting2)
    
    ## Assert ##

# Generated at 2022-06-24 00:58:23.306083
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    entries: List[JournalEntry[bool]] = [JournalEntry(datetime.date(2020, 1, 1), "a", True, [])]

    def reader(period: DateRange) -> Iterable[JournalEntry[bool]]:
        return entries

    assert list(reader(None)) == entries

# Generated at 2022-06-24 00:58:30.691227
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    post1 = Posting(journal=JournalEntry(date=datetime.date(2018, 10, 19), description="buy bitcoin", source=1),
                    date=datetime.date(2018, 10, 19),
                    account="crypto:bitcoin",
                    direction=Direction.INC,
                    amount=Amount(1))
    post1.__delattr__("amount")
    post1.__delattr__("journal")
    post1.__delattr__("date")
    post1.__delattr__("account")
    post1.__delattr__("direction")
    assert post1.__dict__ == {}


# Generated at 2022-06-24 00:58:36.917088
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    class TestSource:
        pass
    test_source = TestSource()
    test_date = datetime.date(2020, 1, 31)
    test_description = "Test Journal Entry"
    test_journal_entry = JournalEntry(
        date = test_date,
        description = test_description,
        source = test_source,
    )
    test_journal_entry.post(test_date, Account(code="Test", name="Test Account", type=AccountType.ASSETS), Amount(100))
    test_journal_entry.validate()

# Generated at 2022-06-24 00:58:45.742624
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal = JournalEntry(datetime.date(2017, 7, 1), "Unit Test", None)
    posting1 = Posting(journal, datetime.date(2017, 7, 1), Account("Test"), Direction.INC, Amount(1))
    posting2 = Posting(journal, datetime.date(2017, 7, 1), Account("Test"), Direction.INC, Amount(1))
    posting3 = Posting(journal, datetime.date(2017, 7, 1), Account("Test"), Direction.INC, Amount(2))
    set_of_postings = frozenset([posting1, posting2, posting3])
    assert len(set_of_postings) == 2


# Generated at 2022-06-24 00:58:47.228180
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    """
    Unit test for method __call__ of class ReadJournalEntries
    """


# Generated at 2022-06-24 00:58:52.010608
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    j1 = JournalEntry(datetime.date(2019, 1, 24), "desc for j1", {1, 2, 3})
    j1.post(datetime.date(2019, 1, 23), Account(AccountType.ASSETS, "Cash"), Amount(100))
    j1.post(datetime.date(2019, 1, 23), Account(AccountType.EQUITIES, "Shareholder's Equity"), Amount(-100))
    print(j1)

# Generated at 2022-06-24 00:59:00.241445
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    date = datetime.datetime.today().date()
    guid = makeguid()
    transaction = "A simple transaction with a guid hashed"
    transaction_2 = "A simple transaction with a guid hashed v2"
    account = Account("Assets:Bank:Checking")
    type = AccountType.ASSETS
    account_2 = Account("Assets:Bank:Savings")
    type_2 = AccountType.EQUITIES
    direction = Direction.INC
    direction_2 = Direction.DEC
    amount = Amount(10)
    amount_2 = Amount(10)
    posting = Posting(date, account, direction, amount, guid)
    posting_2 = Posting(date, account, direction, amount, guid)
    posting_3 = Posting(date, account, direction, amount_2, guid)
    posting_

# Generated at 2022-06-24 00:59:09.701322
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    entry = JournalEntry[None](
        date=datetime.date(2020, 2, 16),
        description="test",
        source=None,
        postings=[
            Posting(journal=None, date=datetime.date(2020, 2, 16), account=Account(code="100", type=AccountType.REVENUES), direction=Direction.INC, amount=Amount(100)),
            Posting(journal=None, date=datetime.date(2020, 2, 16), account=Account(code="200", type=AccountType.EXPENSES), direction=Direction.DEC, amount=Amount(100))
        ]
    )
    assert repr(entry) == "JournalEntry(date=2020-02-16, description='test', source=None, guid={})"

# Generated at 2022-06-24 00:59:13.488724
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert "journal" in dir(ReadJournalEntries.__call__)
    assert "date" in dir(ReadJournalEntries.__call__)
    assert "period" in dir(ReadJournalEntries.__call__)
    assert "description" in dir(ReadJournalEntries.__call__)
    assert "source" in dir(ReadJournalEntries.__call__)

# Generated at 2022-06-24 00:59:16.340675
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    account = Account("ACCOUNT", AccountType.ASSETS)
    entry = JournalEntry(date=datetime.date(2020, 10, 22), description="Description").post(date=datetime.date(2020, 10, 22), account=account, quantity=100)
    entry.validate()

# Generated at 2022-06-24 00:59:27.726346
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType, Account
    from .ledgers import Ledger

    @dataclass(frozen=True)
    class TestSource:
        pass

    source = TestSource()

    ledger = Ledger()

    # FIXME: The type of account needs to be explicitly specified here inorder to support incremental types.
    #        This is because dataclass doesn't support forward references, i.e., JournalEntry can't be used as
    #        type of the field postings.
    #        See: https://github.com/python/mypy/issues/2122

# Generated at 2022-06-24 00:59:31.714886
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    je1 = JournalEntry[str](datetime.date(2020, 8, 2), 'Acquire a car', 'Bought a Blue-Car', [])
    try:
        je1.guid = 'sdfsdfs'
    except AttributeError:
        assert True
    

# Generated at 2022-06-24 00:59:40.684885
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from .accounts import Accounts
    from .transactions import Expense, Payment
    from .records import AccountShell
    from ..commons.context import Context
    from ..commons.money import USD

    # Create the context:
    context = Context()

    # Create the accounts:
    accounts = Accounts(context).create(shells=[
        AccountShell("Cash", AccountType.ASSETS),
        AccountShell("Taxes Payable", AccountType.LIABILITIES),
        AccountShell("Expenses", AccountType.EXPENSES),
    ])

    # Create a journal entry

# Generated at 2022-06-24 00:59:51.483891
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    import datetime
    from ..accounts.accounts import Account
    from ..accounts.accounts import AccountType
    from .journal import JournalEntry
    from .posting import Posting
    from ..commons.numbers import Amount
    from .transactions import Transaction

    #declare data
    dee = datetime.date(2017,1,1)
    acc1 = Account(AccountType.ASSETS, 'cash', 'cash and balances')
    acc2 = Account(AccountType.EXPENSES, 'compensation', 'compensation')
    acc3 = Account(AccountType.ASSETS, 'assets', 'assets')
    acc4 = Account(AccountType.EQUITIES, 'equity', 'equity')
    acc5 = Account(AccountType.LIABILITIES, 'debts', 'debts')

# Generated at 2022-06-24 00:59:59.784934
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journal1 = JournalEntry(datetime.date(2019, 3, 5), "Description for journal entry", "Source")
    journal1.postings.append(Posting(journal1, datetime.date(2019, 3, 5), Account(100001, "Account 1", AccountType.ASSETS), Direction.INC, Amount(10000)))
    journal1.postings.append(Posting(journal1, datetime.date(2019, 3, 5), Account(200002, "Account 2", AccountType.REVENUES), Direction.DEC, Amount(10000)))

    journal2 = JournalEntry(datetime.date(2019, 3, 5), "Description for journal entry", "Source")

# Generated at 2022-06-24 01:00:01.373003
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    posting = Posting(None, None, None, None, None)
    print(posting.__repr__())
    return

# Generated at 2022-06-24 01:00:08.437912
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    def test_object(period: DateRange) -> Iterable[JournalEntry[str]]:
        yield JournalEntry(date=datetime.date.today(), description="Dummy Journal Entry created by unittest.", source="", postings=[])

    assert list(ReadJournalEntries.__call__.__function__(test_object, DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 2, 1)))) == []

# Generated at 2022-06-24 01:00:15.644099
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from datetime import date
    from datetime import timedelta
    import json
    import os
    import pathlib
    from ..commons.numbers import Amount
    from ..commons.others import DateRange
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import AccountSystem
    from . import journal as journal_mod

    with open(os.path.join(pathlib.Path(__file__).parent.absolute(), '../tests/journal.json')) as f:
        entries = json.load(f)
        def create_entries(entries):
            return journal_mod.read_journal_entries(entries)
        assert isinstance(create_entries(entries), Iterable), "Should return an iterable"

# Generated at 2022-06-24 01:00:22.032091
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    je1 = JournalEntry[int](date=datetime.date(2020, 4, 17), description="Test JournalEntry", source=123)
    je1.post(date=datetime.date(2020, 4, 17), account=Account(code="1", name="Account 1", type=AccountType.ASSETS),
             quantity=5)
    assert 1 == len(je1.postings), "Expected one posting"

# Generated at 2022-06-24 01:00:22.609349
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    pass

# Generated at 2022-06-24 01:00:30.471995
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date as date

    from .accounts import AccountType
    from .commons.zeitgeist import DateRange
    from .journal.entries import JournalEntry, Posting, ReadJournalEntries, Direction

    # Given
    class ReadJEntries(ReadJournalEntries[None]):
        @staticmethod
        def __call__(period: DateRange) -> Iterable[JournalEntry[None]]:
            # 1st row
            jrn = JournalEntry(date(2020, 1, 1), "First", None)

# Generated at 2022-06-24 01:00:37.761456
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    # Given
    date = datetime.date(year=2020, month=1, day=1)
    description = "Test Journal Entry"
    source = "Test Source"

    # When
    je = JournalEntry(date, description, source)

    # Then
    assert je.date == date
    assert je.description == description
    assert je.source == source
    assert len(je.postings) == 0
    assert je.guid is not None


# Generated at 2022-06-24 01:00:45.197908
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    """
    Unit Test for the ReadJournalEntries class.
    """
    from typing import cast
    from .accounting_books import AccountingBook

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[AccountingBook]]:
        """
        Read journal entries from the accounting book.

        :param period: Date range to read from.
        :return: Journal entries from that date range.
        """
        ...

    assert type(cast(ReadJournalEntries[AccountingBook], read_journal_entries)) is ReadJournalEntries


# Generated at 2022-06-24 01:00:51.109557
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import Account, AccountType
    from ..commons.zeitgeist import DateRange

    j = JournalEntry("d", "des", "t", postings=None, guid=None)
    assert j.date == "d"
    assert j.description == "des"
    assert j.source == "t"
    assert j.postings == []
    assert not j.guid is None


# Generated at 2022-06-24 01:00:58.909448
# Unit test for constructor of class JournalEntry
def test_JournalEntry():

    # Arrange
    asset_account = Account.get(name="Cash")
    expense_account = Account.get(name="Travel Expense")
    asset_account2 = Account.get(name="Cash")
    expense_account2 = Account.get(name="Travel Expense")
    expense_account3 = Account.get(name="Travel Expense")
    start_date = datetime.date(2019, 1, 1)
    end_date = datetime.date(2019, 1, 4)
    quantity = 1500
    quantity2 = 2500
    description1 = "Farewell party expenses"
    description2 = "Farewell party expenses"
    description3 = "Farewell party expenses"
    
    # Act
    journal_entry1 = JournalEntry[str]().post(end_date, asset_account, quantity)
    journal_

# Generated at 2022-06-24 01:01:01.982444
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert ReadJournalEntries

# Generated at 2022-06-24 01:01:02.853264
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    Posting(JournalEntry(), datetime.date(2018, 1, 1), "Assets:Cash", Direction.INC, Amount(123))

# Generated at 2022-06-24 01:01:06.537230
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    print("\n*****Unit Test for method __delattr__ of class Posting*****")
    # Try to delete a non-existent attribute
    try:
        del p.non_existent
        assert False # Test should not reach this statement
    except AttributeError:
        print("AttributeError exception raised as expected")
    except:
        print("Unexpected exception raised")
        assert False # Test should not reach this statement


# Generated at 2022-06-24 01:01:18.031848
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account

    # Arrange
    journal_entry = JournalEntry[None](date = datetime.date(2020,7,23), description = 'Test')
    date = datetime.date(2020,7,23)
    account = Account('Assets', 'Cash', AccountType.ASSETS)
    quantity = Quantity(100)

    # Act
    journal_entry.post(date, account, quantity)

    # Assert
    assert journal_entry.postings[0].account == account
    assert journal_entry.postings[0].amount == Amount(quantity)
    assert journal_entry.postings[0].is_debit == True
    assert journal_entry.postings[0].is_credit == False
    assert journal_entry.postings[0].direction == Direction.INC


# Generated at 2022-06-24 01:01:28.477475
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    date = datetime.date(2019, 1, 1)
    description = "Test description"
    source = "Test Source"
    postings = ["Test Posting"]
    guid = "Test GUID"

    journal_entry = JournalEntry[str](date, description, source, postings, guid)
    assert journal_entry.date == date, "Date should be equal to the value passed in constructor"
    assert journal_entry.description == description, "Description should be equal to the value passed in constructor"
    assert journal_entry.source == source, "Source should be equal to the value passed in constructor"
    assert journal_entry.postings == postings, "Postings should be equal to the value passed in constructor"
    assert journal_entry.guid == guid, "GUID should be equal to the value passed in constructor"



# Generated at 2022-06-24 01:01:36.880447
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    """
    Unit test for method __delattr__ of class Posting.
    """
    import datetime
    from dataclasses import field, dataclass
    from typing import TypeVar

    from .accounts import Account, AccountType
    from ..commons.numbers import Amount, Quantity

    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry.
        description: str

        #: Business object as the source of the journal entry.
        source: _T

        #: Postings of the journal entry.

# Generated at 2022-06-24 01:01:38.957958
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal_entry = JournalEntry(
        date=None,
        description=None,
        source=None,
        postings=[]
    )
    print(journal_entry)

# Generated at 2022-06-24 01:01:48.826499
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    #Arrange
    date = datetime.date.fromisoformat('2019-01-01')
    description = "Test Journal Entry"
    source = "catalog:source"
    postings = []
    journal = JournalEntry[str](date, description, source, postings)

    #Assert
    assert journal.date == date
    assert journal.description == description
    assert journal.source == source
    assert journal.postings == postings

    #Act
    date2 = datetime.date.fromisoformat('2019-01-02')
    account = Account("Account")
    quantity = 10
    journal.post(date2, account, quantity)
    
    #Assert
    assert len(journal.postings) == 1
    assert journal.postings[0].date == date2
    assert journal.postings[0].account == account


# Generated at 2022-06-24 01:01:50.174600
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert ReadJournalEntries.__call__  # Synthesized



# Generated at 2022-06-24 01:01:57.912445
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from .accounts import AccountList
    from .business import Vendor

    vendor = Vendor(name="Dummy Vendor")
    journal = JournalEntry[Vendor](
        date=datetime.date(2018, 1, 1),
        description="Dummy Journal Entry",
        source=vendor,
    )
    assert journal == journal

    journal = JournalEntry[Vendor](
        date=datetime.date(2018, 1, 1),
        description="Dummy Journal Entry",
        source=vendor,
        postings=[
            Posting(journal, datetime.date(2018, 1, 1), AccountList.oc_accounts_payable, Direction.DEC, 10000),
            Posting(journal, datetime.date(2018, 1, 1), AccountList.oc_cash, Direction.INC, 10000),
        ]
    )

# Generated at 2022-06-24 01:02:02.058337
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # arrange
    j = JournalEntry[int](date=datetime.date(2020, 1, 1), description="Test")

    # act
    result = j.__repr__()

    # assert
    assert "JournalEntry" in result

# Generated at 2022-06-24 01:02:12.643522
# Unit test for constructor of class Posting
def test_Posting():
    #: Test the following functions
    #:  1. Posting.is_debit
    #:  2. Posting.is_credit
    #:
    #: Test Setup
    #:  1. Create accounts to be tested
    #:  2. Create a JournalEntry
    #:  3. Posting amount
    #:
    #: Test cases
    #:  1. Test Posting to Assets accounts with INC direction
    #:  2. Test Posting to Assets accounts with DEC direction
    #:  3. Test Posting to Revenues accounts with INC direction
    #:  4. Test Posting to Revenues accounts with DEC direction

    # Test Setup
    #: 1. Create Accounts
    asset_account = Account('Assets A/C', account_type=AccountType.ASSETS)
    revenue_account = Account

# Generated at 2022-06-24 01:02:21.242805
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from ...commons.zeitgeist import datestring
    from .accounts import AccountCreate
    from .invoices import Invoice, InvoiceCreate
    from .sales import SalesCreate

    start, end = datestring("2020/1/1"), datestring("2020/1/10")
    assert start < end

    buy = AccountCreate("Buy")
    sell = AccountCreate("Sell")

    def sales_create_journal(invoice: Invoice) -> JournalEntry[Invoice]:
        return JournalEntry(invoice.date, f"Sales Invoice {invoice.number}", invoice).post(
            invoice.date, sell.deposit, invoice.amount
        )

    sales_create = SalesCreate(buy=buy, sell=sell, journal_create=sales_create_journal)


# Generated at 2022-06-24 01:02:26.269390
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    SET_OF_JOURNAL_ENTRY = set()
    SET_OF_JOURNAL_ENTRY.add(JournalEntry(None))
    SET_OF_JOURNAL_ENTRY.add(JournalEntry(None))
    SET_OF_JOURNAL_ENTRY.add(JournalEntry(None))
    SET_OF_JOURNAL_ENTRY.add(JournalEntry(None))
    SET_OF_JOURNAL_ENTRY.add(JournalEntry(None))

# Generated at 2022-06-24 01:02:37.734374
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from .accounts import Account
    from .currencies import Currency, USD
    from .institutions import Institution
    from .markets import Stock
    from .portfolios import Portfolio
    from .taxes import Tax
    from .trades import Trade

    account = Account(
        guid="abc",
        name="abc",
        account_type=AccountType.EXPENSES,
        institution=Institution(
            name="abc",
            guid="abc",
            institution_type=AccountType.EXPENSES,
            categories=[AccountType.EXPENSES],
            owners=["abc"],
            tax_identifier="abc",
            is_custodian=True,
            currency=Currency(USD, 1),
        ),
    )


# Generated at 2022-06-24 01:02:47.747468
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from datetime import date
    from .accounts import Account, get_account
    from .books import Book000, get_book
    from .chart import Chart000, get_chart
    from .transaction import Transaction
    from .path import Path000
    pass

    ## Initialize a book:
    book = get_book(Book000)

    ## Initialize a chart:
    with get_chart(Chart000) as chart:

        ## Prepare accounts:
        with chart.scope() as scope:
            bank = scope.get(get_account("Bank"))
            cash = scope.get(get_account("Cash"))
            debt = scope.get(get_account("Debt"))
            equity = scope.get(get_account("Equity"))
            income = scope.get(get_account("Income"))

# Generated at 2022-06-24 01:02:51.191093
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    try:
        ReadJournalEntries()
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-24 01:02:54.561592
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass


# Generated at 2022-06-24 01:03:01.097887
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    j1 = JournalEntry(date=datetime.date(2020, 8, 20), description="foo", source="bar", guid="1")
    j2 = JournalEntry(date=datetime.date(2020, 8, 20), description="foo", source="bar", guid="1")
    j3 = JournalEntry(date=datetime.date(2020, 8, 20), description="foo", source="bar", guid="2")
    a1 = Account("42", "X", AccountType.EXPENSES, "EUR")
    a2 = Account("43", "X", AccountType.EXPENSES, "EUR")
    assert j1 != j2
    assert j1 != j3
    j1 = j1.post(datetime.date(2020, 8, 20), a1, -150)
    assert j1 != j2
    assert j

# Generated at 2022-06-24 01:03:12.628597
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry(None, "", None, ())
    j.validate()
    j = JournalEntry(None, "", None, ())
    j.post(None, None, 3)
    j.post(None, None, -3)
    j.validate()
    j = JournalEntry(None, "", None, ())
    j.post(None, None, 3)
    j.post(None, None, 15)
    j.post(None, None, -18)
    j.validate()
    j = JournalEntry(None, "", None, ())
    j.post(None, None, 3)
    j.post(None, None, -5)
    try:
        j.validate()
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-24 01:03:16.076037
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    my_account = Account('my account')
    my_posting = Posting(None, datetime.date(2019, 1, 1), my_account, Direction.INC, Amount(6))
    assert my_posting.account is my_account
    my_posting.account = 'test'
    assert my_posting.account == 'test'


# Generated at 2022-06-24 01:03:18.052830
# Unit test for constructor of class Posting
def test_Posting():
    my_Posting = Posting()
    assert my_Posting is not None


# Generated at 2022-06-24 01:03:20.532160
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    assert JournalEntry(date = datetime.date(2020, 12, 12), description = "Testing", source = "test", guid = "1")

# Generated at 2022-06-24 01:03:27.895919
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from datetime import date
    from ..commons.zeitgeist import DateRange

    from .accounts import Account

    from .books import JournalEntry
    from .books import Posting
    from ..commons.numbers import Amount
    from ..commons.numbers import Quantity
    from .common import ledger_entries as le

    j1 = JournalEntry(date(2020, 1, 1), "Test transaction 1", source=le)
    j1.post(date(2020, 1, 1), account=Account(type=AccountType.ASSETS, name="Cash"), quantity=Quantity(10))

    assert len(j1.postings) == 1, "Posting not created"

# Generated at 2022-06-24 01:03:29.380281
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    pass


# Generated at 2022-06-24 01:03:34.227970
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    _ReadJournalEntriesImpl = ReadJournalEntries[None]
    _read_fnc: _ReadJournalEntriesImpl = lambda period: []
    assert isinstance(_read_fnc, _ReadJournalEntriesImpl)

# Generated at 2022-06-24 01:03:43.567691
# Unit test for constructor of class Posting
def test_Posting():
    """
    Tests the constructor of class Posting
    """
    # User input
    import datetime
    from typing import Tuple
    from ..commons.others import makeguid

    entry_date = datetime.date.fromisoformat("2020-04-01")
    entry_description = "Test Description"
    entry_source = "Test Source"

    entry_postings = [
        Posting(None, datetime.date.fromisoformat("2020-04-02"),
                Account(makeguid(), "Test Account", AccountType.ASSETS, None),
                Direction.INC, 5),
        Posting(None, datetime.date.fromisoformat("2020-04-02"),
                Account(makeguid(), "Test Account", AccountType.EQUITIES, None),
                Direction.DEC, 5)
    ]

   

# Generated at 2022-06-24 01:03:49.138779
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journal_entry1 = JournalEntry[int](date = datetime.date(2019, 4, 14), description = 'Albertsons', source = 1, guid = makeguid())
    journal_entry2 = JournalEntry[int](date = datetime.date(2019, 4, 14), description = 'Safeway', source = 2, guid = makeguid())
    assert (journal_entry1 != journal_entry2) == True


# Generated at 2022-06-24 01:03:54.070214
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    je = JournalEntry(date = datetime.date(2020, 9, 5), description = "Testing Journal Entry", source = "")
    p = Posting(journal = je, date = datetime.date(2020, 9, 5), account = Account(name = "Account", type = AccountType.ASSETS), direction = Direction.INC, amount = Amount(1))
    assert(p.__repr__() == 'Posting(journal=JournalEntry(date=datetime.date(2020, 9, 5), description=\'Testing Journal Entry\', source=\'\'), date=datetime.date(2020, 9, 5), account=Account(name=\'Account\', type=<AccountType.ASSETS: \'Assets\'>), direction=<Direction.INC: 1>, amount=Amount(1))')


# Generated at 2022-06-24 01:04:05.560422
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    # Build JournalEntry1
    journal1 = JournalEntry[None](date=datetime.date(2018, 1, 1),
                                 description="journal1",
                                 source=None)
    journal1.postings.append(Posting(journal=journal1, date=datetime.date(2018, 1, 1), account=Account.get_account("Assets:Current Assets"), direction=Direction.INC, amount=Amount(100)))
    journal1.postings.append(Posting(journal=journal1, date=datetime.date(2018, 1, 1), account=Account.get_account("Expenses:Advertising"), direction=Direction.DEC, amount=Amount(100)))

    # Build JournalEntry2

# Generated at 2022-06-24 01:04:16.393812
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    frozenset_ = frozenset
    test_date = datetime.date(2020, 7, 21)
    test_postings = [Posting(1, test_date, Account(1, AccountType.ASSETS, "Test Account", "", 0), Direction.DEC, Amount(0))]
    test_source = 1
    result = JournalEntry(test_date, 'test description', test_source, test_postings)
    # Assert exceptions will be raised
    try:
        result.postings = [Posting(1, test_date, Account(1, AccountType.ASSETS, "Test Account", "", 0), Direction.DEC, Amount(0))]
    except TypeError as e:
        pass
    else:
        raise Exception("AssertionError was not thrown")

# Generated at 2022-06-24 01:04:25.360528
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import astuple

    from .accounts import Account, AccountType

    je1 = JournalEntry[str]("2020-01-01", "Test", "123", [], "GUID")
    assert astuple(je1) == ("2020-01-01", "Test", "123", je1.postings, "GUID")

    je2 = je1.post(datetime.date(2020, 1, 2), Account("A1", "A1", AccountType.EXPENSES, "A"), -1000)

# Generated at 2022-06-24 01:04:33.425866
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    @dataclass(frozen=True)
    class Tester:
        pass
    tester = Tester()
    j1 = JournalEntry[Tester](datetime.date(2019, 10, 18), "Test", tester)
    j1.post(datetime.date(2019, 10, 18), Account("Foo", AccountType.ASSETS), 1).post(datetime.date(2019, 10, 18), Account("Baa", AccountType.EQUITIES), -1)
    del j1.postings
    assert j1.postings == []

# Generated at 2022-06-24 01:04:40.737932
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    obj1 = Posting(journal=None, date=datetime.date.today(), account=Account(identifier="a123", type=AccountType.ASSETS), direction=Direction.INC, amount=Amount(10))
    obj2 = Posting(journal=None, date=datetime.date.today(), account=Account(identifier="a123", type=AccountType.ASSETS), direction=Direction.INC, amount=Amount(10))
    assert obj1 == obj2 and not (obj1 != obj2)

# Generated at 2022-06-24 01:04:48.490414
# Unit test for constructor of class Posting
def test_Posting():
    from .accounts import AccountType, Account
    from .businessobjects.commodities import Commodity, CommodityPair
    from .businessobjects.taskexecution import TaskExecution
    from .businessobjects.transactions import Transaction
    from .journalentries import JournalEntry

    #Create a commodity pair
    commodity_pair = CommodityPair.default(Commodity.USD, Commodity.INR)
    
    #Create a journal entry
    journal_entry = JournalEntry(datetime.datetime.now().date(), "Test Journal Entry", TaskExecution.default())

    #Create an account
    account = Account.default(AccountType.ASSETS)

    #Create a posting
    posting = Posting(journal_entry, datetime.datetime.now().date(), account, Direction.INC, Amount(10))



# Generated at 2022-06-24 01:05:00.305838
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    from datetime import date

    je = JournalEntry[str](date.today(), "abc", "abc")
    je.post(date(2100, 12, 1), Account("A1"), Quantity(20))
    je.post(date(2100, 12, 2), Account("A2"), Quantity(40))
    je.post(date(2100, 12, 3), Account("A3"), Quantity(60))
    je.post(date(2100, 12, 4), Account("A4"), Quantity(80))
    je.post(date(2100, 12, 5), Account("A5"), Quantity(100))
    je.post(date(2100, 12, 6), Account("A6"), Quantity(120))
    je.post(date(2100, 12, 7), Account("A7"), Quantity(140))

# Generated at 2022-06-24 01:05:11.460494
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(None, datetime.date(2020, 1, 1), None, Direction.INC, Amount(100))
    p1_ = Posting(None, datetime.date(2020, 1, 1), None, Direction.INC, Amount(100))
    p2 = Posting(None, datetime.date(2020, 2, 1), None, Direction.INC, Amount(100))
    p3 = Posting(None, datetime.date(2020, 1, 2), None, Direction.INC, Amount(100))
    p4 = Posting(None, datetime.date(2020, 1, 1), None, Direction.DEC, Amount(100))
    assert p1 == p1_
    assert p1 != p2
    assert p1 != p3
    assert p1 != p4



# Generated at 2022-06-24 01:05:15.214408
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Setup
    je = JournalEntry(datetime.date.today(), "Test", "", [])

    je.post(datetime.date.today(),"Assets", 1000)
    je.post(datetime.date.today(),"Expenses", 1000)

    # Test
    je.validate()

    # Teardown

# Generated at 2022-06-24 01:05:16.524429
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
	pass


# Generated at 2022-06-24 01:05:28.352617
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal = JournalEntry(datetime.date(2019, 2, 3), "invoice 123", "invoice 123")
    journal = journal.post(journal.date, Account("cash", AccountType.ASSETS), 100)
    p = Posting(journal, journal.date, Account("cash", AccountType.ASSETS), Direction.INC, 100)
    assert hash(p) == hash((journal, p.date, p.account, p.direction, p.amount))
    assert hash(p) != hash((journal, p.date, p.account, Direction.DEC, p.amount))
    assert hash(p) != hash((journal, p.date, Account("check", AccountType.ASSETS), p.direction, p.amount))
    assert hash(p) != hash((journal, journal.date, p.account, Direction.DEC, p.amount))


# Generated at 2022-06-24 01:05:35.496324
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    jnl = JournalEntry(datetime.date(2018, 10, 1), "Test", None)
    jnl.post(datetime.date(2018, 10, 1), Account("OTR", AccountType.ASSETS), Quantity(1))
    jnl.post(datetime.date(2018, 10, 1), Account("OTR", AccountType.ASSETS), Quantity(1))
    jnl.validate()

# Generated at 2022-06-24 01:05:37.492572
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # Setup
    actual = None

    # Exercise
    actual = Posting.__repr__()

    # Verify
    # None


# Generated at 2022-06-24 01:05:45.432622
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    import datetime as dt
    from ..commons.numbers import Amount
    from ..commons.others import makeguid
    from .accounts import Account, AccountType
    @dataclass(frozen=True)
    class Account1(Account): 
        Account1.type = AccountType.ASSETS
        Account1.name = "Account1"
    @dataclass(frozen=True)
    class Account2(Account): 
        Account2.type = AccountType.LIABILITIES
        Account2.name = "Account2"

    # arrange
    je = JournalEntry[None]()
    je.date = dt.date(2020, 5, 12)
    je.description = "desc"
    je.source = None

# Generated at 2022-06-24 01:05:50.306243
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    class MyClass:
        @ReadJournalEntries
        def mymethod(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    assert not isinstance(MyClass().mymethod, ReadJournalEntries)

# Generated at 2022-06-24 01:05:51.239466
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    Posting
    pass


# Generated at 2022-06-24 01:05:58.188495
# Unit test for method __delattr__ of class Posting

# Generated at 2022-06-24 01:06:06.446468
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry(datetime.date(2019, 1, 1), 'test_desc', 'source')
    assert type(je.date) is datetime.date  # is it true that je.date is a datetime.date?
    assert type(je.description) is str  # is it true that je.description is a string?
    assert type(je.source) is str  # is it true that je.source is a string?
    assert type(je.postings) is list # is it true that je.postings is a list?
    assert type(je.guid) is Guid # is it true that je.guid is a Guid?


# Generated at 2022-06-24 01:06:13.687614
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date

    from ..commons.numbers import Amount

    from .accounts import Account

    class BusinessObject:
        pass

    journal_entry = JournalEntry[BusinessObject](date(2020, 11, 11), "Test Journal Entry", BusinessObject())
    journal_entry.postings = []

    journal_entry.post(date(2020, 11, 11), Account(AccountType.ASSETS, "Cash Account"), Amount(0))

    assert len(journal_entry.postings) == 0



# Generated at 2022-06-24 01:06:14.427231
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass

# Generated at 2022-06-24 01:06:15.687526
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    
    ReadJournalEntries = ReadJournalEntries()

    assert ReadJournalEntries != None

# Generated at 2022-06-24 01:06:21.953877
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    je = JournalEntry(datetime.date.today(), "Test", "Test source")
    je.post(datetime.date.today(), Account("1001", "Cash"), 10)
    je.post(datetime.date.today(), Account("2001", "Sales"), -10)
    je.validate()

    je = JournalEntry(datetime.date.today(), "Test", "Test source")
    je.post(datetime.date.today(), Account("1001", "Cash"), 10)
    je.post(datetime.date.today(), Account("2001", "Sales"), 10)
    je.validate()

# Generated at 2022-06-24 01:06:25.612881
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
        
    # In:
    #JournalEntry.__repr__(self)
    # Out:
    # '<JournalEntry period=DateRange(start=datetime.date(2019, 1, 1), end=datetime.date(2019, 12, 31))>'
    pass

# Generated at 2022-06-24 01:06:34.963085
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_entries = [JournalEntry[int] for _ in range(100)]

    class Tracked:
        callbacks_called = 0

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[int]]:
        Tracked.callbacks_called += 1
        return journal_entries

    for _ in range(10):
        assert read_journal_entries(DateRange.unbounded()) == journal_entries
    assert Tracked.callbacks_called == 10

    Tracked.callbacks_called = 0
    read_journal_entries2: ReadJournalEntries[int] = read_journal_entries
    for _ in range(10):
        assert read_journal_entries2(DateRange.unbounded()) == journal_entries
    assert Tracked.callbacks_called == 10

# Generated at 2022-06-24 01:06:40.585587
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journalentry = JournalEntry(datetime.date.today(), "sample description", Guid.newobject())
    posting = Posting(journalentry, datetime.date.today(), Account(), Direction.INC, 1)
    assert posting.date == datetime.date.today()
    assert posting.account
    assert posting.direction == Direction.INC
    assert posting.amount == 1



# Generated at 2022-06-24 01:06:46.310941
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from .accounts import Account
    from .accounts import AccountType
    from .numbers import Amount
    from .numbers import Quantity
    from .journal import Direction
    from .journal import Posting
    from .journal import JournalEntry
    JournalEntry = JournalEntry  # Silence PyFlakes.
    JournalEntry = JournalEntry  # Silence PyFlakes.
    Posting = Posting  # Silence PyFlakes.
    Amount = Amount  # Silence PyFlakes.
    Quantity = Quantity  # Silence PyFlakes.
    Account = Account  # Silence PyFlakes.
    AccountType = AccountType  # Silence PyFlakes.
    Direction = Direction  # Silence PyFlakes.
    # Testing attributes of class Posting
    #### post = Posting(journal = JournalEntry, date = datetime.date, account = Account, direction = Direction, amount =

# Generated at 2022-06-24 01:06:51.398142
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    JE = JournalEntry(date=datetime.date(2020, 1, 5), description="Test", source=0, postings=[])
    assert repr(JE) == "JournalEntry(date=datetime.date(2020, 1, 5), description='Test', source=0, postings=[])"
    

# Generated at 2022-06-24 01:06:52.402190
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert 0 != 1


# Generated at 2022-06-24 01:06:53.448943
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass


# Generated at 2022-06-24 01:07:00.270005
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from datetime import datetime, timedelta
    from .accounts import Account, AssetAccount, AccountType, EQUITY

    # Set up
    journal_entry = JournalEntry[JournalEntry[Posting]](date=datetime.now(), description="Test Journal Entry", source=None)

    # Execute
    ledger_account = AssetAccount("Cash", 5000, AccountType.ASSETS)
    journal_entry.post(datetime.now() + timedelta(days=1), ledger_account, +2000)

    # Verifiy
    assert journal_entry.postings[0].account == ledger_account

# Generated at 2022-06-24 01:07:03.981562
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    a = JournalEntry(datetime.date.today(), "", "")
    print(a.date)
    print(a.description)
    print(a.source)
    print(a.postings)
    print(a.guid)
    # a.__delattr__()
    # print(a.date)

# Generated at 2022-06-24 01:07:04.524940
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    pass

# Generated at 2022-06-24 01:07:08.398519
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    # Arrange
    # Act
    # Assert
    pass

# Generated at 2022-06-24 01:07:09.717917
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    je = JournalEntry(datetime.date(2019, 12, 1), 'First day of december', 1)
    delattr(je, 'postings')
    assert je.postings == []


# Generated at 2022-06-24 01:07:20.883796
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def f(period: DateRange) -> Iterable[JournalEntry[_T]]:
        print("--called--")
        return list()

    f1 = ReadJournalEntries[str]
    print(f1.__annotations__)
    print(f1.__module__)
    print(f1.__qualname__)
    print(f1.__args__)
    print(f1.__origin__)
    print(f1.__params__)
    print(f1.__slots__)
    print(f1.__text_signature__)
    print(type(f1))
    print("--instance-call--")
    print(type(f1(f)))

# Generated at 2022-06-24 01:07:31.279409
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountSystem
    from .accounts.spec import SpecAccountSystem

    # Setup
    asys = SpecAccountSystem.create()
    bsys = AccountSystem(asys)

    # Test
    je = JournalEntry(datetime.date(2020, 12, 11), "test", None)

    # assert(je.guid != Guid.empty)
    assert(je.postings == [])

    je.post(datetime.date(2020, 12, 11), bsys.assets.cash, +12)
    assert(je.postings == [Posting(je, datetime.date(2020, 12, 11), bsys.assets.cash, Direction.INC, Amount(12))])

    je.post(datetime.date(2020, 12, 11), bsys.expenses.software, -2)

# Generated at 2022-06-24 01:07:41.158501
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    journal_entry = JournalEntry(datetime.date(2020, 1, 1), "Journal entry", "Source")
    journal_entry.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Assets"), 100)
    journal_entry.post(datetime.date(2020, 1, 1), Account(AccountType.LIABILITIES, "Liabilities"), 100)
    journal_entry.post(datetime.date(2020, 1, 1), Account(AccountType.ASSETS, "Assets"), 120)
    journal_entry.post(datetime.date(2020, 1, 1), Account(AccountType.LIABILITIES, "Liabilities"), 100)
    assert len(journal_entry.postings) == 4, "Expected 4 postings."