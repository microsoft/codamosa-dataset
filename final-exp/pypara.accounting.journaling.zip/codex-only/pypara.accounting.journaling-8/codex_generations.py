

# Generated at 2022-06-24 00:57:40.493129
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    je = JournalEntry[int](datetime.date(2020, 12, 31), "Test", 1)
    assert je.__repr__() == str(je)

# Generated at 2022-06-24 00:57:43.472347
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class ReadJournalEntriesImpl:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    ReadJournalEntriesImpl()
    ReadJournalEntries[int] # Valid
    ReadJournalEntries[str] # Valid
    ReadJournalEntries[str](lambda period: [])

# Generated at 2022-06-24 00:57:44.154023
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert False, "Not implemented"

# Generated at 2022-06-24 00:57:44.785280
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    assert issubclass(ReadJournalEntries, Protocol)

# Generated at 2022-06-24 00:57:48.908556
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    x = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description='desc',
        source='source',
    )
    del x.date
    assert x.date is None

# Generated at 2022-06-24 00:57:54.643977
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    journal1 = JournalEntry(date=datetime.date(year=2020,month=10,day=1), description="journal 1", source=10)
    account = Account(code="1", name="account 1")
    journal1.post(date=datetime.date(year=2020,month=10,day=1), account=account, quantity=10)
    assert str(journal1) == "2020-10-01 journal 1"


# Generated at 2022-06-24 00:58:04.439631
# Unit test for constructor of class Posting
def test_Posting():
    from ..ledgers.parsers import EntryParser
    from ..ledgers.readers import FileReader
    reader = FileReader(path="/home/jeff/python/midas/data/ledger/beancount", entry_parser=EntryParser())
    parser = EntryParser()
    for x in reader.entries:
        print(x)
        if x:
            entry=parser.parse(x)
            print(entry.postings)
            p=Posting(journal=entry,date=entry.date,account=entry.postings[0].account,direction=entry.postings[0].direction,amount=entry.postings[0].amount)
    assert p is not None

# Generated at 2022-06-24 00:58:12.303567
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    class Test:
        pass
    obj = Test()
    obj.__setattr__("a", datetime.date.today())
    obj.__setattr__("b", 1)
    obj.__setattr__("c", True)
    obj.__setattr__("d", "a")
    obj.__setattr__("e", Test())
    obj.__setattr__("f", JournalEntry(datetime.date.today(), "test", None, None))
    pass

# Generated at 2022-06-24 00:58:22.263372
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    account: Account = Account("")
    ledger = JournalEntry[Account](date=datetime.date.today(), description='', source=account)
    ledger.post(date=datetime.date.today(), account=account, quantity=1)
    ledger.post(date=datetime.date.today(), account=account, quantity=2)
    ledger.validate()
    print(ledger)
    ledger2: JournalEntry[Account] = JournalEntry(date=datetime.date.today(), description='', source=account)
    ledger2.post(date=datetime.date.today(), account=account, quantity=1)
    ledger2.post(date=datetime.date.today(), account=account, quantity=2)
    ledger2.validate()
    print(ledger2)

    assert ledger == ledger2

# Generated at 2022-06-24 00:58:32.691354
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    print("Testing method __eq__ of class Posting")
    # initialize
    description1 = "description1"
    description2 = "description2"
    description3 = "description3"
    description4 = "description4"
    description5 = "description5"
    description6 = "description6"
    description7 = "description7"
    description8 = "description8"
    description9 = "description9"
    description10 = "description10"
    description11 = "description11"
    description12 = "description12"
    description13 = "description13"
    description14 = "description14"
    description15 = "description15"


# Generated at 2022-06-24 00:58:40.000186
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import AccountType
    from .globals import GLOBALS
    from ..commons import money
    from datetime import date

    GLOBALS.profile.sampledate = date(year=2019, month=8, day=1)

    #: An increment/decrement event (must be non-zero).
    #: @type: Quantity
    quantity = Quantity(5)

    #: Date of posting.
    #: @type: datetime.date
    date = GLOBALS.profile.sampledate

    #: Account to post the amount to.
    #: @type: Account
    account = GLOBALS.accounts.find("320")

    #: Journal entry the posting belongs to.
    #: @type: JournalEntry[_T]
    journalEntry = JournalEntry[Posting]

    #: Post

# Generated at 2022-06-24 00:58:49.376837
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from .accounts import AccountList
    from .currencies import CurrencyList
    from .institutions import InstitutionList

    # setup
    institution = InstitutionList().by_name("TEST")
    currency = CurrencyList().by_code("TEST")
    account = AccountList().by_id(0)
    journal_entry = JournalEntry[None]("A", "B", None)
    posting = Posting[None](journal_entry, "a", account, Direction.INC, Amount(1, currency))
    expect = hash((journal_entry, "a", account, Direction.INC, Amount(1, currency)))

    # execute
    actual = hash(posting)

    # verify
    assert actual == expect

# Generated at 2022-06-24 00:58:54.905528
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal = JournalEntry(
        date=datetime.date(year=2019, month=1, day=1),
        description="test",
        source=None,
    )
    journal.post(date=journal.date, account=Account(code="10100", name="Cash at bank"), quantity=50)
    journal.post(date=journal.date, account=Account(code="10200", name="Cash in hand"), quantity=-50)
    journal.validate()

# Generated at 2022-06-24 00:58:58.245918
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    """
    Tests the __delattr__ method of the Posting class.
    """
    obj = Posting(None, datetime.date(2020, 1, 1), Account("1", AccountType.ASSETS), Direction.INC, Amount(1))

    assert obj.journal == None
    with pytest.raises(AttributeError):
        del obj.journal
    with pytest.raises(AttributeError):
        obj.journal = None


# Generated at 2022-06-24 00:59:03.970783
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    a = Account("bank", AccountType.ASSETS)
    e = Account("expense", AccountType.EXPENSES)
    j = JournalEntry(datetime.date.today(), "test", None, [])
    j.post(datetime.date.today(), a, 300)
    j.post(datetime.date.today(), e, 300)
    j.validate()

# Generated at 2022-06-24 00:59:10.763332
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journal = JournalEntry('blank')
    p = Posting(journal=journal, date=datetime.date.today(), account=Account(name='ACT', type=AccountType.ASSETS), direction=Direction.DEC, amount=0)
    p.journal = None
    p.date =None
    p.account = None
    p.direction = None
    p.amount = None

# Generated at 2022-06-24 00:59:17.037607
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    try:
        __name__, __file__
    except NameError:
        __name__, __file__ = ('', '')

    try:
        p = Posting(journal=1, date=2, account=3, direction=4, amount=5)
        p.journal = 1
        p.date = 2
        p.account = 3
        p.direction = 4
        p.amount = 5

        assert False
    except AttributeError:
        assert True


# Generated at 2022-06-24 00:59:28.801464
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class Foo():
        pass

    j1 = JournalEntry(datetime.date(2019, 1, 1), "Description1", Foo())
    j2 = JournalEntry(datetime.date(2019, 1, 2), "Description2", Foo())

    #: Defines a source of journal entries.
    def journal_entries(period: DateRange) -> Iterable[JournalEntry[Foo]]:
        for j in (j1, j2):
            if period.contains(j.date):
                yield j

    #: Instantiates a ReadJournalEntries
    r = ReadJournalEntries[Foo]

    #: Specifies a period.
    p = DateRange.from_dates(j1.date, j2.date)

    #: Validates the instantiated object.

# Generated at 2022-06-24 00:59:33.259734
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    entry1 = JournalEntry(datetime.datetime.now(), 'test journal entry', 'objectid', [])
    entry2 = JournalEntry(entry1.date, entry1.description, entry1.source, [])
    assert entry1 == entry2
    assert hash(entry1) == hash(entry2)


# Generated at 2022-06-24 00:59:41.329246
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from .accounts import AccountType
    from .utils.mock import MockReadJournalEntries
    from .utils.persist import InMemoryJournalReader
    from .utils.transaction import Trxn

    ## Perform test:
    actual = MockReadJournalEntries(InMemoryJournalReader(Trxn.sample()))(DateRange(2020, 1, 3, 2020, 1, 3))

    ## Check:
    assert isinstance(actual, Iterable)
    assert isinstance(actual, JournalEntry)
    assert isinstance(actual[0].date, datetime.date)
    assert isinstance(actual[0].description, str)
    assert isinstance(actual[0].source, Trxn)
    assert isinstance(actual[0].postings[0].journal, JournalEntry)

# Generated at 2022-06-24 00:59:52.003579
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from datetime import date
    from test.core.domain.accounts import TestAccount
    from test.core.domain.journal import TestJournalEntry, TestSource

    # Arrange:
    account = TestAccount(5)
    journal = TestJournalEntry(date=date(2018, 1, 1), description='Journal Description', source=TestSource())
    posting = Posting(journal=journal, date=date(2018, 1, 1), account=account, direction=Direction.DEC, amount=5)

    # Act:
    try:
        posting.journal = TestJournalEntry(date=date(2018, 1, 1), description='Another Journal Description',
                                           source=TestSource())
    except Exception as ex:
        actual = ex

    # Assert:
    expected = AttributeError('Cannot overwrite attribute journal of Posting')
    assert str

# Generated at 2022-06-24 01:00:00.269076
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import Account
    from .accounts.repository import AccountRepository
    from .currencies import Currency, CurrencyRepository

    repos = AccountRepository(
            CurrencyRepository(
                Currency("USD"),
                Currency("CAD"),
                Currency("GBP")
            ),
            Account("1010", "Cash", AccountType.ASSETS, Currency("USD")),
            Account("1011", "Cash", AccountType.ASSETS, Currency("CAD")),
            Account("1012", "Cash", AccountType.ASSETS, Currency("GBP")),
            Account("1020", "Payables", AccountType.LIABILITIES, Currency("USD"))
    )
    journal_entry = JournalEntry(datetime.date(2020, 2, 1), "Payment of Payables", Guid)

# Generated at 2022-06-24 01:00:04.133037
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    pass



# Generated at 2022-06-24 01:00:13.767495
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    # Create two distinct JournalEntry instances
    new_entry = JournalEntry(date=datetime.date.today(), description="description", source=None)
    new_entry_2 = JournalEntry(date=datetime.date.today(), description="description2", source=None)
    # Create a set to add the JournalEntry instances
    journal_entries_set = set()
    # Hash the two JournalEntry instances
    hash_new_entry = new_entry.__hash__()
    hash_new_entry_2 = new_entry_2.__hash__()
    # Add the journal entries to the set
    journal_entries_set.add(new_entry)
    journal_entries_set.add(new_entry_2)
    # Test the set has two values
    assert len(journal_entries_set) == 2
    #

# Generated at 2022-06-24 01:00:24.628557
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import accounts
    from .currencies import usd
    from datetime import date
    je = JournalEntry[None](date.today(), "Desc", None)
    assert hash(je) == hash(je.date)
    je.post(date.today(), accounts.checking_usd, -100)
    je.post(date.today(), accounts.cash_usd, 100)
    assert hash(je) == hash(je.date)
    assert hash(je) != hash(je.postings)
    je.guid = makeguid()
    assert hash(je) != hash(je.date)
    assert hash(je) != hash(je.guid)

# Generated at 2022-06-24 01:00:31.685611
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date
    from opentrons.commons.quantities import Amount, Quantity
    from opentrons.commons.history import History
    from opentrons.commons.cookbook import Recipe
    from opentrons.reagents import ReagentSlot
    from opentrons.dispense_plan.get_pipette_for_volume import PipetteRequest
    from opentrons.instruments import Pipette as PipetteInterface
    from opentrons.calibration_storage import (
        save_pipette_calibration,
        get_pipette_calibration,
        delete_pipette_calibration,
        load_address_calibration,
        get_last_modified_date,
    )
    from opentrons.cameras import Camera

# Generated at 2022-06-24 01:00:36.191414
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class Foo(ReadJournalEntries[_T]):
        """
        Concrete type of ReadJournalEntries.

        For the purpose of unit tests.
        """

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass


# Generated at 2022-06-24 01:00:41.561655
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    # Arrange
    period = DateRange.from_str('2020-01-01', '2020-01-01')

    # Act
    def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
        return period
    read_journal_entities = ReadJournalEntries()

    # Assert
    assert period == read_journal_entities.__call__(period)

# Generated at 2022-06-24 01:00:43.549746
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[str]]:
        return []
    assert issubclass(read_journal_entries.__class__, ReadJournalEntries)

# Generated at 2022-06-24 01:00:53.270893
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import dummy_accounts
    date = datetime.date(2020, 9, 1)
    journal = JournalEntry(date, "A journal", "Source")
    account = Account.of(dummy_accounts[0])
    direction = Direction.INC
    amount = Amount(100)
    posting1 = Posting(journal, date, account, direction, amount)
    posting2 = Posting(journal, date, account, direction, amount)
    posting3 = Posting(journal, date, account, direction, Amount(200))
    assert posting1 == posting2
    assert posting1 != posting3
    print('Success!')



# Generated at 2022-06-24 01:01:04.575284
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from ..primitives.primitives import Account
    from ..primitives.primitives import AccountType
    from ..primitives.primitives import Guid
    from ..primitives.primitives import Amount
    from ..primitives.primitives import Direction
    from ..primitives.primitives import Posting
    from ..primitives.primitives import JournalEntry
    from ..primitives.primitives import Date
    import datetime
    from dataclasses import dataclass
    from typing import Dict, Iterable, List, Set, TypeVar

    assert not hasattr(JournalEntry, '__hash__')

    @dataclass(frozen=True)
    class JournalEntry(Generic[_T]):
        """
        Provides a journal entry model.
        """

        #: Date of the entry.
        date: datetime.date

        #: Description of the entry

# Generated at 2022-06-24 01:01:10.192185
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from accounting.journal.entries import Posting
    posting = Posting(None, datetime.date(2020, 1, 1), Account("Assets", "Cash", AccountType.ASSETS, None), Direction.INC, Amount.from_float(1.1))
    posting.amount = Amount.from_float(2.2)

# Generated at 2022-06-24 01:01:15.386961
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert repr(JournalEntry(date=datetime.date(2019, 10, 29), guid=Guid.parse('7897d6da-2bf8-49c6-a9f9-7b9c31a77b7c'), source='source', description='JournalEntry(date=2019-10-29, description=\'source\')'))

# Generated at 2022-06-24 01:01:26.756429
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    '''
    Test __hash__ method of class Posting
    '''
    p = Posting(JournalEntry, datetime.date(2015, 1, 1), Account("1"), Direction.INC, Amount(1))
    p2 = Posting(JournalEntry, datetime.date(2015, 1, 1), Account("1"), Direction.INC, Amount(1))
    p3 = Posting(JournalEntry, datetime.date(2015, 1, 1), Account("1"), Direction.DEC, Amount(1))

    hash1 = p.__hash__()
    hash2 = p2.__hash__()
    hash3 = p3.__hash__()
    print(f"Hash of p: {hash1}, hash of p2: {hash2}, hash of p3: {hash3}")

# Generated at 2022-06-24 01:01:29.930282
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    pass


# Generated at 2022-06-24 01:01:34.527455
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from ..commons.zeitgeist import to_datetime

    class ExampleReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return ["Foo", "Bar"]

    assert list(ExampleReadJournalEntries()(DateRange(to_datetime("2020-01-01"), datetime.date.today()))) == ["Foo", "Bar"]


# Generated at 2022-06-24 01:01:35.058708
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass

# Generated at 2022-06-24 01:01:43.420567
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journal = JournalEntry(datetime.date(2020, 1, 1), 'Hello World', None)
    journal.post(datetime.date(2020, 1, 1), Account.ASSET_CASH, 100)
    journal.post(datetime.date(2020, 1, 1), Account.EQUITY_CAPITAL, -100)
    journal2 = JournalEntry(datetime.date(2020, 1, 1), 'Hello World', None)
    journal2.post(datetime.date(2020, 1, 1), Account.ASSET_CASH, 100)
    journal2.post(datetime.date(2020, 1, 1), Account.EQUITY_CAPITAL, -100)

    assert hash(journal) == hash(journal2)

# Generated at 2022-06-24 01:01:51.798376
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    je = JournalEntry[int](datetime.date(2019, 1, 1), "", 0)
    p = Posting[int](je, datetime.date(2019, 1, 1), Account("", AccountType.ASSETS), Direction.INC, Amount(1000))
    assert repr(p) == "Posting(journal=JournalEntry(date=datetime.date(2019, 1, 1), description='', source=0), date=datetime.date(2019, 1, 1), account=Account(name='', type=<AccountType.ASSETS: 1>), direction=<Direction.INC: 1>, amount=Amount(1000))"


# Generated at 2022-06-24 01:02:00.807318
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    je = JournalEntry(datetime.date(2019, 7, 12), "JournalEntry 1", 0)
    je1 = JournalEntry(datetime.date(2019, 7, 12), "JournalEntry 1", 0)
    je2 = JournalEntry(datetime.date(2019, 7, 13), "JournalEntry 1", 0)
    je3 = JournalEntry(datetime.date(2019, 7, 12), "JournalEntry 2", 0)
    je4 = JournalEntry(datetime.date(2019, 7, 12), "JournalEntry 1", 1)
    assert (je == je1) and (je != je2) and (je != je3) and (je != je4)

# Generated at 2022-06-24 01:02:10.387877
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal1 = JournalEntry[str](date=datetime.date(2020, 1, 1), description="test hash 1", source='test hash')
    journal1 = journal1.post(date=datetime.date(2020, 1, 1), account=Account("account1"), quantity=1)
    journal2 = JournalEntry[str](date=datetime.date(2020, 2, 1), description="test hash 2", source='test hash')
    journal2 = journal2.post(date=datetime.date(2020, 2, 1), account=Account("account2"), quantity=2)
    posting1 = Posting[str](journal1, date=datetime.date(2020, 1, 1), account=Account("account1"), direction=Direction.INC, amount=1)

# Generated at 2022-06-24 01:02:19.859106
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    transaction_ledger = [JournalEntry[object](datetime.date(2020,1,1),"This is a test", object), JournalEntry[object](datetime.date(2020,1,1),"This is a test", object)]
    transaction_ledger[0].post(datetime.date(2020,1,1), Account(AccountType.LIABILITIES, "liabilities"), -200)
    transaction_ledger[1].post(datetime.date(2020,1,1), Account(AccountType.LIABILITIES, "liabilities"), -200)
    assert transaction_ledger[0].postings[0] == transaction_ledger[1].postings[0]

# Generated at 2022-06-24 01:02:30.593983
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import AccountType
    from .accounts import Account
    from .accounts import Category
    from .accounts import Chart

    chart = Chart(
        name="My Chart",
        categories=[
            Category(
                name="Assets",
                type=AccountType.ASSETS,
                accounts=[Account(name="Current Assets", type=AccountType.ASSETS)],
            )
        ],
    )

    account = chart.account(fullname="Assets:Current Assets")
    entryA = JournalEntry(datetime.datetime.now().date(), "test", None, [])
    entryB = JournalEntry(datetime.datetime.now().date(), "test", None, [])

# Generated at 2022-06-24 01:02:42.024932
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    """
    This functions tests the __eq__ method of the JournalEntry class
    """
    date = datetime.date(1,1,1)
    account = Account("Account1", "Type1")
    account2 = Account("Account2", "Type1")
    account3 = Account("Account1", "Type2")

    journal = JournalEntry[int](date, "Test", 1)
    journal.post(date, account, 100)
    journal.post(date, account2, 100)

    journal2 = JournalEntry[int](date, "Test", 1)
    journal2.post(date, account, 100)
    assert journal == journal2

    journal3 = JournalEntry[int](date, "Test3", 1)
    journal3.post(date, account, 100)
    assert journal != journal3

    journal4 = JournalEntry

# Generated at 2022-06-24 01:02:52.361554
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from dataclasses import _MISSING_TYPE
    from .accounts import Account

    je = JournalEntry("test")
    assert je.date == "test"
    je.date = "new"
    assert je.date == "new"

    je = JournalEntry("test")
    assert je.description == "test"
    je.description = "new"
    assert je.description == "new"

    je = JournalEntry("test")
    assert je.source == "test"
    je.source = "new"
    assert je.source == "new"

    je = JournalEntry("test")
    assert je.postings == []
    je.postings = list()
    assert je.postings == []

    je = JournalEntry("test")
    assert je.guid != _MISSING_TYPE  # type: ignore


# Generated at 2022-06-24 01:02:58.098469
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from .accounts import Account
    from .journal import JournalEntry
    from dataclasses import replace
    from datetime import date

    journal = JournalEntry[str](date(2018, 11, 1), "description", "source")
    posting = Posting(journal, date(2018, 11, 1), Account('account'), Direction.DEC, Amount(100))
    posting2 = Posting(journal, date(2018, 11, 1), Account('account'), Direction.DEC, Amount(100))

    assert hash(posting) == hash(posting2)


# Generated at 2022-06-24 01:03:03.826401
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    assert JournalEntry(datetime.date(2018, 1, 1), "Debit a/c", None).post(datetime.date(2018, 1, 1), Account("a/c"), 1).__eq__(JournalEntry(datetime.date(2018, 1, 1), "Debit a/c", None).post(datetime.date(2018, 1, 1), Account("a/c"), 1))

# Generated at 2022-06-24 01:03:14.695357
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    from ..models.persons import Customer
    from ..models.portfolios import Balance
    from ..models.sales import Invoice
    customer = Customer("joe@example.com")
    balance = Balance(customer, "USD", 100.0)
    invoice = Invoice(customer, "USD", 50.0)
    posting = Posting(None, None, None, None, None)
    try:
        posting.journal = balance
        posting.date = datetime.date(2019, 5, 15)
        posting.account = Account("sa.c.1234", "USD", AccountType.EQUITIES)
        posting.direction = Direction.INC
        posting.amount = Amount(0.0)
    except Exception as ex:
        assert False, f"Exception {ex} was thrown when setting properties in class Posting."
    assert True

# Generated at 2022-06-24 01:03:24.541539
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    """
    Unit test for method __repr__ of class Posting
    """ 
    class JournalEntryStub():
        pass

    account = Account(name="account", type=AccountType.ASSETS)
    journal_entry = JournalEntryStub()

    posting = Posting(journal=journal_entry, date=datetime.date(2020, 1, 1), account=account, direction=Direction.INC, amount=Amount(10))
    assert posting.__repr__() == "Posting(journal=JournalEntryStub(), date=datetime.date(2020, 1, 1), account=Account(name=account), direction=<Direction.INC: 1>, amount=10.00)"


# Generated at 2022-06-24 01:03:31.919237
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    try:
        # Arrange
        je = JournalEntry(
            date=datetime.date(2019, 12, 31),
            description="Test Journal Entry",
            source=object(),
        )

        # Act and Assert
        je.validate()
        # Assert
        assert False, "Expected AssertionError was not raised"
    except AssertionError:
        # Expected
        pass



# Generated at 2022-06-24 01:03:39.339606
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import create_account

    account1 = create_account("Account1", AccountType.ASSETS)
    account2 = create_account("Account2", AccountType.EQUITIES)
    re = JournalEntry("Test description", "Test source", "2020-01-01")
    re.post("2020-01-02", account1, 100)
    re.post("2020-01-02", account2, -100)
    re.validate()
    assert isinstance(re, JournalEntry)



# Generated at 2022-06-24 01:03:47.043694
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import Account, AccountType
    #: Type of journal entry test object.
    @dataclass(frozen=True)
    class TestObject:
        """
        Test object.
        """
        #: Object id.
        id: int

    #: Account to use for testing
    account = Account("TEST01", AccountType.EXPENSES, "TEST01")
    #: Object to use for testing
    obj = TestObject(1)
    #: Date to use for testing
    date = datetime.date.today()
    #: Quantity to use for testing
    quantity = 1000000

    #: Instantiate the journal entry object to test
    journal = JournalEntry[TestObject](date, "TEST01", obj)

    #: Post the given quantity to the journal entry object

# Generated at 2022-06-24 01:03:47.829847
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    pass



# Generated at 2022-06-24 01:03:54.090700
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    j = JournalEntry(datetime.date.today(), "test", None)
    j.post(datetime.date.today(), Account(AccountType.ASSETS, "Cash"), Amount(-100))
    j.post(datetime.date.today(), Account(AccountType.EXPENSES, "Misc"), Amount(100))
    j.validate()

# Generated at 2022-06-24 01:04:00.129530
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    x: JournalEntry[float]= JournalEntry(datetime.date.today(), "", 100)
    x.postings.append(Posting(x, datetime.date.today(), Account(""), Direction.INC, 1))
    def __setattr__(self, name, value):
        pass
    x.__setattr__ = __setattr__
    x.date = datetime.date.today()

# Generated at 2022-06-24 01:04:05.203476
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    je = JournalEntry(datetime.date(2020, 1, 1), "Test", None)
    assert len(je.postings) == 0
    je.postings.append(1)
    try:
        je.postings = [1]
    except Exception as ex:
        assert type(ex) is AttributeError

# Generated at 2022-06-24 01:04:12.909962
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, BalanceDirective, Account

    account_expense = Account("Some Expense", AccountType.EXPENSES, BalanceDirective.DEBIT)
    account_revenue = Account("Some Revenue", AccountType.REVENUES, BalanceDirective.CREDIT)

    # Provided a datetime, an account and an amount, the 'post' method concatenates the datetime, the account and the amount
    print(JournalEntry[str](datetime.date(2020, 12, 31), "SomeDescription", "SomeSource").post(datetime.date(2020, 12, 31), account_expense, 1.23).postings)

# Generated at 2022-06-24 01:04:21.678849
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    # arrange
    JOURNAL = JournalEntry(datetime.date(2018, 11, 1), "", "")
    POSTING = Posting(JOURNAL, datetime.date(2018, 11, 1), Account("Account", AccountType.ASSETS), Direction.INC, 1000)
    # act
    result = hash(POSTING)
    # assert
    assert result == hash(JOURNAL) and result == hash(datetime.date(2018, 11, 1)) and result == hash(Account("Account", AccountType.ASSETS)) and result == hash(Direction.INC) and result == hash(1000)

# Generated at 2022-06-24 01:04:22.354418
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 01:04:22.796962
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass

# Generated at 2022-06-24 01:04:33.893714
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from .accounts import Account
    from .temp import tempguid

    journal = JournalEntry(datetime.date(2020, 1, 1), "temp", None)

    posting = Posting(journal, datetime.date(2020, 1, 1), Account("a1", AccountType.REVENUES), Direction.INC, Amount(100))

    assert posting == posting
    assert posting != Posting(journal, datetime.date(2020, 1, 1), Account("a1", AccountType.REVENUES), Direction.INC, Amount(101))
    assert posting != Posting(journal, datetime.date(2020, 1, 2), Account("a1", AccountType.REVENUES), Direction.INC, Amount(100))

# Generated at 2022-06-24 01:04:42.509943
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    j = JournalEntry("Gupta Infotech Ltd. Pvt. Ltd.").post(datetime.date(2013, 1, 1), Account("Assets:Cash"), 1000)
    j.post(datetime.date(2013, 1, 1), Account("Expenses:Rent"), -900)
    j.post(datetime.date(2013, 1, 1), Account("Equity:Opening Balances"), -100)
    assert repr(j.postings[0]) == "Posting(journal=<JournalEntry(date=2013-01-01, description='Gupta Infotech Ltd. Pvt. Ltd.', guid='guid-xxxx-xxxx-xxxx-xxxx')>, date=2013-01-01, account=Account('Assets:Cash'), direction=<Direction.INC: 1>, amount=Amount(1000))"



# Generated at 2022-06-24 01:04:43.439141
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    pass
    # TODO

# Generated at 2022-06-24 01:04:52.629940
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    from .accounts import AccountBook, AccountType
    from .records import RecordBook
    from .tools import get_book_locator
    from .units import UnitBook

    # Get book locators:
    account_loc = get_book_locator(AccountBook)
    record_loc = get_book_locator(RecordBook)
    unit_loc = get_book_locator(UnitBook)

    # Get accounts:
    assets = account_loc.get("Assets")
    equities = account_loc.get("Equities")
    cash = account_loc.get("Cash")
    sales = account_loc.get("Sales")

    # Create a journal entry:
    entry = JournalEntry(date=datetime.date(year=2019, month=8, day=11))

# Generated at 2022-06-24 01:04:58.082278
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .accounts import Account, AccountType
    from .numbers import Amount, Quantity, Unit
    from .people import Person
    from .things import Thing
    from .times import Date
    from .transactions import SaleOfGoods

    # Arrange
    date = Date.now()
    seller: Person = Person("Mike")
    buyer: Person = Person("Joe")
    item: Thing = Thing("Pen", Unit("pcs"))
    quantity: Quantity = Quantity(2)
    amount: Amount = Amount(25.0)

    # Act and Assert
    ## Assert identity properties:
    transaction: SaleOfGoods = SaleOfGoods(date=date) \
        .from_(seller) \
        .to(buyer) \
        .invoice_for(item, quantity, amount)

# Generated at 2022-06-24 01:05:01.862170
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    je = JournalEntry()
    assert je is not None
    assert je.date is not None
    assert je.description is not None
    assert je.source is not None
    assert je.postings is not None
    assert je.increments is not None
    assert je.decrements is not None
    assert je.debits is not None
    assert je.credits is not None
    assert je.guid is not None

# Generated at 2022-06-24 01:05:07.810997
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    account = Account("BANK")
    journal = JournalEntry[int](datetime.date.today(), "", 1)
    posting1 = Posting(journal, datetime.date.today(), account, Direction.INC, Amount(1))
    posting2 = Posting(journal, datetime.date.today(), account, Direction.INC, Amount(1))
    assert posting1.__hash__() == posting2.__hash__()

# Generated at 2022-06-24 01:05:12.572166
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    a : JournalEntry[int]
    a = JournalEntry(date=datetime.date(2019, 12, 31), description="test", source=1)
    del a.date
    del a.description
    del a.source
    del a.postings
    del a.guid



# Generated at 2022-06-24 01:05:14.751551
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True
    return


# Local Variables:
# compile-command: "cd ../ && pytest -v --cov=datum tests/test_journal.py"
# End:

# Generated at 2022-06-24 01:05:22.145557
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    # Source: https://docs.python.org/3/library/functions.html#delattr
    class Coordinate:
        x = 10
        y = -5
        z = 0

    point1 = Coordinate()
    print('x = ',point1.x)
    print('y = ',point1.y)
    print('z = ',point1.z)

    delattr(Coordinate, 'z')
    print('--After deleting z attribute--')
    print('x = ',point1.x)
    print('y = ',point1.y)

# Generated at 2022-06-24 01:05:24.782085
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(None, None, None, None, None) == Posting(None, None, None, None, None)


# Generated at 2022-06-24 01:05:28.505993
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    raise NotImplementedError


# Generated at 2022-06-24 01:05:39.817502
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType

    ledger = JournalEntry[None]("2020-03-31", "Test-JournalEntry-post", None)
    ledger.post("2020-03-31", "Test", AccountType.EXPENSES, 1000)
    ledger.post("2020-03-31", "Test", AccountType.EXPENSES, -1000)
    ledger.post("2020-03-31", "Test", AccountType.EXPENSES, 0) # Should not be posted
    ledger.post("2020-03-31", "Test", AccountType.EXPENSES, 0.0) # Should not be posted
    ledger.post("2020-03-31", "Test", AccountType.EXPENSES, 0.00) # Should not be posted

# Generated at 2022-06-24 01:05:49.176310
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    """Unit test for method __setattr__ of class Posting"""
    new_posting = Posting(journal=None, date=datetime.date(2019, 9, 1), account=Account("ASSETS",AccountType.ASSETS), direction=Direction.INC, amount=Amount(12))
    assert new_posting.date == datetime.date(2019, 9, 1)
    assert new_posting.account.code == "ASSETS"
    assert new_posting.account.type == AccountType.ASSETS
    assert new_posting.direction == Direction.INC
    assert new_posting.amount == 12

# Unit Testing for method INC and method DEC of class Direction    

# Generated at 2022-06-24 01:05:57.174242
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date
    from datetime import timedelta

    from .accounts import Account
    from .accounts import AccountType
    from .accounts import Ledger

    from .banks import BankTransaction
    from .banks import BankTransactionType

    from .contracts import Contract
    from .contracts import ContractStatus
    from .contracts import ContractType

    from .events import Event, EventType

    from .items import Item
    from .items import ItemType

    from .places import Place

    from .products import Product
    from .products import ProductType

    @dataclass(frozen=True)
    class Source:
        pass

    ledger = Ledger("Test Ledger")

    def entry(date: date, description: str):
        return JournalEntry[Source](date, description, Source())


# Generated at 2022-06-24 01:06:06.996342
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    journal_entry_1 = JournalEntry[object](date=datetime.date(2020, 1, 1), description="entry", source=object())
    journal_entry_1_copy = JournalEntry[object](date=datetime.date(2020, 1, 1), description="entry", source=object())
    journal_entry_2 = JournalEntry[object](date=datetime.date(2020, 1, 1), description="entry", source=object())
    journal_entry_3 = JournalEntry[object](date=datetime.date(2020, 1, 2), description="entry", source=object())
    journal_entry_4 = JournalEntry[object](date=datetime.date(2020, 1, 1), description="entry", source=object())

# Generated at 2022-06-24 01:06:17.629673
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    from datetime import date
    from ddddd.accounts import AccountType, Account
    from ddddd.commons.numbers import Amount, Quantity
    from ddddd.journal import Direction, JournalEntry, Posting

    # test data

# Generated at 2022-06-24 01:06:18.174193
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    assert True

# Generated at 2022-06-24 01:06:25.571372
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    class JournalEntry:
        def __init__(self, guid):
            self.guid = guid

    journal = JournalEntry(1)
    journal2 = JournalEntry(2)
    p1 = Posting(journal, datetime.date(2020, 1, 1), Account("CASH"), Direction.INC, Amount(1))
    p2 = Posting(journal2, datetime.date(2020, 1, 1), Account("CASH"), Direction.INC, Amount(1))
    p3 = Posting(journal, datetime.date(2021, 1, 1), Account("CASH"), Direction.INC, Amount(1))
    p4 = Posting(journal, datetime.date(2020, 1, 1), Account("EQUITIES"), Direction.INC, Amount(1))

# Generated at 2022-06-24 01:06:28.912752
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    o1=JournalEntry(date=datetime.date.today(),
                      description="Selling a bicycle",
                      source=None,
                      postings=[])
    o2=JournalEntry(date=datetime.date.today(),
                      description="Selling a bicycle",
                      source=None,
                      postings=[])
    assert hash(o1) == hash(o2)

# Generated at 2022-06-24 01:06:30.794028
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from important import Important
    assert Important.Posting.__delattr__()


# Generated at 2022-06-24 01:06:40.375410
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from .accounts import AccountType
    from .accounts import Book, BookRecord, BookType
    from .accounts import Account, AccountType
    from .parties import Party
    from .parties import BusinessAccount
    from ..commons import Amount, Currency, Quantity

    # Create a Book
    book = Book(BookRecord(
        book_type = BookType.LEDGER,
        book = 'Sample Book',
        currency = Currency('EUR', 'Euro', '€'),
        cashbook = None,
    ))

    # Create a Business Account
    business = Party(
        party = 'Sample Business',
        location = None,
        time_zone = None,
    )


# Generated at 2022-06-24 01:06:43.353158
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    p = Posting(None,datetime.date(2019,1,1),Account("Test",AccountType.ASSETS),Direction.INC,Amount(100))
    assert p.__repr__() == "Posting(None, datetime.date(2019, 1, 1), Test, INC, 100.00)"


# Generated at 2022-06-24 01:06:51.315340
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # New Test data
    date = datetime.date(2019, 12, 31)
    description = "Test description with special characters ' newline\n\n"
    source = "Test source"
    account = Account(1, "TestAccount", AccountType.ASSETS)
    direction = Direction.DEC
    quantity = 20000
    amount = Amount(quantity)
    posting = Posting(source, date, account, direction, amount)
    postings = [posting]
    journal_entry = JournalEntry(date, description, source, postings)

# Generated at 2022-06-24 01:06:57.909518
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # Setup
    source = object()
    date = datetime.date(year=2019, month=1, day=1)
    description = "Test description"

    # Execute
    journal_entry_instance = JournalEntry[object](date, description, source)

    # Verify
    assert repr(journal_entry_instance) == f"JournalEntry(date={date}, description={description}, source={source}, postings=[], guid={journal_entry_instance.guid})"


# Generated at 2022-06-24 01:07:04.604324
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal = JournalEntry[None](date = datetime.date.today(), description = "Test Posting", source = None)
    posting = Posting(journal = journal, date = datetime.date.today(), account = Account(type = AccountType.ASSETS, code = "test", name = "Test"), direction = Direction.INC, amount = 50)
    posting2 = Posting(journal = journal, date = datetime.date.today(), account = Account(type = AccountType.ASSETS, code = "test", name = "Test"), direction = Direction.INC, amount = 50)
    posting_hash = hash(posting)
    posting2_hash = hash(posting2)
    assert posting_hash == posting2_hash, "Hash of two identical postings do not match"


# Generated at 2022-06-24 01:07:09.763606
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class ReadJournalEntries2:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return []

    assert isinstance(ReadJournalEntries2(), ReadJournalEntries)

# Generated at 2022-06-24 01:07:22.236032
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    @dataclass(frozen=True)
    class _TestJournalEntry:
        pass

    @dataclass(frozen=True)
    class _TestPosting:
        journal: "JournalEntry[_T]"
        date: datetime.date
        account: Account
        direction: Direction
        amount: Amount
    _JournalEntry = JournalEntry[_T]
    _TestEntry = _TestJournalEntry

    entry = _JournalEntry(datetime.date.today(), "TestDesc", _TestEntry(), list())
    posting = _TestPosting(entry, datetime.date.today(), Account("testaccountsys"), Direction.INC, Amount(1000))
    assert posting == posting
    assert posting.journal == entry
    assert posting.journal.description == "TestDesc"
    assert posting.journal.date == datetime.date.today()

# Generated at 2022-06-24 01:07:24.483216
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(None, None, None, None, None) == Posting(None, None, None, None, None)

# Generated at 2022-06-24 01:07:28.665341
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    j1 = JournalEntry(datetime.date(2019, 12, 31), "Sample journal entry", None, [])
    assert j1.date == datetime.date(2019, 12, 31)
    assert j1.description == "Sample journal entry"
    assert j1.source == None
    assert j1.postings == []

# Generated at 2022-06-24 01:07:36.460305
# Unit test for constructor of class Posting
def test_Posting():
    journalentry = JournalEntry[int](datetime.date(2020, 1, 1), "Description", 1)
    account = Account("Assets", "Cash", AccountType.ASSETS)
    posting = Posting(journalentry, datetime.date(2020, 1, 1), account, Direction.INC, Amount(100))
    assert posting.journal == journalentry
    assert posting.date == datetime.date(2020, 1, 1)
    assert posting.account == account
    assert posting.direction == Direction.INC
    assert posting.amount == Amount(100)


# Generated at 2022-06-24 01:07:40.144163
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    a = Posting(1, datetime.date(2016, 1, 1), "test", Direction.DEC, Amount(300))
    b = Posting(1, datetime.date(2016, 1, 1), "test", Direction.DEC, Amount(300))
    assert a.__hash__() == b.__hash__()
