

# Generated at 2022-06-24 00:57:41.063324
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    assert(Posting)

# Generated at 2022-06-24 00:57:41.520299
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    pass

# Generated at 2022-06-24 00:57:46.702376
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    def _do(account, direction, quantity):
        posting = Posting(None, None, account, direction, Amount(quantity))
        return posting.is_debit

    # ASSET accounts must show DEBIT entries:
    assert _do(Account.of("A1", AccountType.ASSETS), Direction.INC, 1000) is True
    assert _do(Account.of("A2", AccountType.ASSETS), Direction.DEC, 1000) is True
    assert _do(Account.of("A3", AccountType.ASSETS), Direction.INC, -1000) is True
    assert _do(Account.of("A4", AccountType.ASSETS), Direction.DEC, -1000) is True

    # LIABILITY accounts must show CREDIT entries:

# Generated at 2022-06-24 00:57:48.121976
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    read_entries = ReadJournalEntries
    assert isinstance(read_entries, type)
    assert hasattr(read_entries, "__call__")
    assert callable(read_entries.__call__)

# Generated at 2022-06-24 00:57:51.116798
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p1 = Posting(None, None, None, None, None)
    p2 = Posting(None, None, None, None, None)
    assert hash(p1) == hash(p2)


# Generated at 2022-06-24 00:57:52.624734
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass


# Generated at 2022-06-24 00:57:55.813293
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    j = JournalEntry(datetime.date(2017, 9, 23), "some", None)
    del j.postings
    assert hasattr(j, "postings")
    assert "JournalEntry" in str(j)
    assert "postings" in str(j)

# Generated at 2022-06-24 00:58:01.544467
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    _T = datetime.date
    journal = JournalEntry[datetime.date](datetime.date.today(),"description",datetime.date.today(),[])
    result = journal.__repr__()
    print(result)
    assert result != ""


# Generated at 2022-06-24 00:58:09.015807
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    assert getattr(JournalEntry(datetime.date(2019,1,1), "TEST", None), "postings") == []
    delattr(JournalEntry(datetime.date(2019,1,1), "TEST", None), "postings")
    assert getattr(JournalEntry(datetime.date(2019,1,1), "TEST", None), "postings") == []

# Generated at 2022-06-24 00:58:18.322398
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    import datetime
    from src.secnac.finance.accounts import Account, AccountType
    from src.secnac.finance.entries import Direction, JournalEntry, Posting
    posting = Posting(
        JournalEntry(datetime.date(2019, 11, 1), "Test", "Test", []),
        datetime.date(2019, 11, 1),
        Account(AccountType.EQUITIES, "Cash"),
        Direction.INC,
        100
    )

    assert repr(posting) == "Posting(<JournalEntry: date: 2019-11-01, description:'Test', guid:'2fe9e9c205f711ea91e1f6c18e6bfdc5'>, date: 2019-11-01, account:Equities(Cash), direction:INC, amount:100)"

# Generated at 2022-06-24 00:58:22.219244
# Unit test for constructor of class Posting
def test_Posting():
    assert Posting(Posting,datetime.date(2020,4,4),Account("Cash","Equity"),Direction.INC,Amount(400))



# Generated at 2022-06-24 00:58:32.690276
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    from .accounts import AccountType, Equity
    from datetime import datetime
    from .journal import JournalEntry
    from .commons.numbers import Quantity

    # Test for unequal JournalEntries
    je1 = JournalEntry[int](datetime(2010, 1, 1).date(), "test1", 1)
    je1.post(datetime(2010, 1, 1).date(), Equity("Test1"), Quantity(10))
    je2 = JournalEntry[int](datetime(2010, 1, 1).date(), "test1", 1)
    je2.post(datetime(2010, 1, 1).date(), Equity("Test1"), Quantity(10))
    je3 = JournalEntry[int](datetime(2011, 1, 1).date(), "test1", 1)

# Generated at 2022-06-24 00:58:34.229531
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    journal = JournalEntry(datetime.date(2020, 10, 12), "Description", None)
    assert journal == journal


# Generated at 2022-06-24 00:58:45.036592
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from docstash.commons.numbers import Quantity

    # Arrange
    journal_entry = JournalEntry(datetime.date(2020,1,1), "", [])

    # Act
    posting1 = Posting(journal_entry, datetime.date(2020,1,1), Account(AccountType.ASSETS, ""), Direction.INC, Amount(Quantity(10, 1)))
    posting2 = Posting(journal_entry, datetime.date(2020,1,1), Account(AccountType.EXPENSES, ""), Direction.DEC, Amount(Quantity(10, 1)))
    
    # Assert
    assert posting1.is_debit
    assert not posting1.is_credit
    assert not posting2.is_debit
    assert posting2.is_credit

# Generated at 2022-06-24 00:58:49.103881
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # Arrange
    je = JournalEntry('2020-01-01', 'Payment for oil', 'oil')
    # Act
    delattr(je, 'description')
    # Assert
    assert je.description == 'Payment for oil'

# Generated at 2022-06-24 00:58:51.723829
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    p = Posting(None, None, None, None, None)
    with pytest.raises(AttributeError):
        p.__setattr__('test_case', None)
	

# Generated at 2022-06-24 00:59:00.002424
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    journal = JournalEntry(date=datetime.date(2020,12,4), description='test')

# Generated at 2022-06-24 00:59:08.049661
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    date = datetime.date(year=2020, month=7, day=2)
    description = "This is the description of a journal entry"
    source = "This is the source of a journal entry"
    postings = [
        Posting(None, date, Account("12345", "Cash"), Direction.INC, Amount(100)),
        Posting(None, date, Account("23456", "Sales"), Direction.DEC, Amount(100)),
    ]
    guid = "9d9afd24-ac8f-4c64-a0c0-05d2636a5a5f"
    je = JournalEntry(date, description, source, postings, guid)


# Generated at 2022-06-24 00:59:17.582852
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    x: JournalEntry[int] = JournalEntry[int](datetime.date(2020, 3, 4), "Test Journal Entry")
    assert str(x) == "JournalEntry(date=2020-03-04, description='Test Journal Entry', source=<class 'int'>, guid=<guid>)"
    assert x.date == datetime.date(2020, 3, 4)
    assert x.description == "Test Journal Entry"
    assert x.source == int
    assert x.postings == list()
    assert len(x.increments) == 0
    assert len(x.decrements) == 0
    assert len(x.debits) == 0
    assert len(x.credits) == 0
    return x


# Generated at 2022-06-24 00:59:28.562240
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    journal_entry = JournalEntry(
        date=datetime.date(2018, 1, 1),
        description="",
        source="",
        guid=datetime.datetime.now(),
    )
    assert journal_entry.postings == []
    journal_entry.post(
        date=datetime.date(2018, 1, 1),
        account=Account(
            name="Account 1",
            account_type=AccountType.LIABILITIES,
            parent_account=None
        ),
        quantity=100
    )
    assert journal_entry.postings != []
    # noinspection PyUnresolvedReferences
    delattr(journal_entry, "postings")
    assert journal_entry.postings == []

# Generated at 2022-06-24 00:59:33.394576
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    assert hash(Posting('journal', datetime.date.today(), Account('account_num', 'account_name'),
                       Direction.INC, Amount(100))) == hash(Posting('journal', datetime.date.today(),
                                                                   Account('account_num', 'account_name'), Direction.INC,
                                                                   Amount(100)))


# Generated at 2022-06-24 00:59:41.384365
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    from .ledgers import Ledger
    from .postings import Posting, PostingAccountType

    ledger: Ledger
    ledger = Ledger()

    def get_postings(journal: JournalEntry) -> List[Posting]:
        return journal.postings

    def create_posting(date: datetime.date, account: Account, description: str, debit: bool, amount: int) -> Posting:
        account_type = PostingAccountType.DEBIT if debit else PostingAccountType.CREDIT
        return Posting(journal=journal, date=date, account=account, direction=direction, amount=Amount(amount))


# Generated at 2022-06-24 00:59:46.570676
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    """
    Test the implementation of method __setattr__ of class JournalEntry
    """
    class Test:
        def __init__(self):
            self.Test = self
    Test()

# Generated at 2022-06-24 00:59:49.683751
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    assert Posting(None, datetime.date(2019, 6, 30), Account(AccountType.EXPENSES, "EXPENSES-01"), Direction.INC, Amount(100)) == \
        Posting(None, datetime.date(2019, 6, 30), Account(AccountType.EXPENSES, "EXPENSES-01"), Direction.INC, Amount(100))


# Generated at 2022-06-24 00:59:56.538691
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    journal_read = lambda period: iter([JournalEntry(date=datetime.date(2013, 1, 1), description="", source="")])

    journal_data = list(journal_read(DateRange(datetime.date(2013, 1, 1), datetime.date(2013, 1, 31))))
    assert len(journal_data) == 1, "Should have read exactly one journal entry"
    assert journal_data[0].date == datetime.date(2013, 1, 1), "Should have read exactly one journal entry"

# Generated at 2022-06-24 00:59:58.374446
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    a = Posting([], [], [], [])
    a._Posting__dict__
    delattr(a, 'journal')

# Generated at 2022-06-24 01:00:07.267289
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Accounts, AccountType
    from .common import Common
    from .countries import Countries

    class User:
        pass

    accounts = Accounts(Countries.INDIA)

# Generated at 2022-06-24 01:00:09.084545
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    try:
        del Posting.journal
    except AttributeError as e:
        assert type(e) == AttributeError

# Generated at 2022-06-24 01:00:12.597374
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    @dataclass(frozen=True)
    class FakeJournal:
        account: Account
        direction: Direction
        amount: Amount
    try:
        Posting(FakeJournal(), datetime.date.today(), Account(), Direction.INC, amount=Amount.from_int(10)).amount
        assert False
    except AttributeError:
        assert True

# Generated at 2022-06-24 01:00:23.501182
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Given:
    account1 = Account("Account1")
    account2 = Account("Account2")
    account3 = Account("Account3")
    je1 = JournalEntry(datetime.date(2020, 1, 1), "Event1", None)
    je2 = JournalEntry(datetime.date(2020, 1, 1), "Event2", None)

    # When:
    je1.post(datetime.date(2020, 1, 1), account3, +100)
    je2.post(datetime.date(2020, 1, 1), account1, -50)
    je2.post(datetime.date(2020, 1, 1), account2, +50)

    # Then:
    assert je1.postings[0].is_debit is True

# Generated at 2022-06-24 01:00:27.630384
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    a = "Asset account"
    j = "Journal Entry"
    p = Posting(j, datetime.date(2019, 1, 2), a, Direction.DEC, Amount(23456))
    assert p.__repr__() == "Posting(journal=Journal Entry, date=2019-01-02, account=Asset account, direction=DEC, amount=23456)"

# Generated at 2022-06-24 01:00:30.154439
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    assert True


# Generated at 2022-06-24 01:00:33.932398
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():  # noqa: D103
    with pytest.raises(AttributeError):
        Posting(None, None, None, None, None).postings = None


# Generated at 2022-06-24 01:00:44.121140
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    from .accounts import AccountType, Account, AccountSet
    from .organizations import Organization, OrganizationSet

    account_set = AccountSet()
    org_set = OrganizationSet()
    journal_entry = JournalEntry(datetime.date(2020,1,1), "Test", source = "source")

    for acc_name in ("A", "L", "E", "X"):
        account_set.add(Account(acc_name, f"Description of {acc_name}", AccountType[acc_name]))

    org_set.add(Organization(account_set["A"], "Test Organization"))

    journal_entry.post(datetime.date(2020,1,1), account_set["A"], Quantity(100))

# Generated at 2022-06-24 01:00:46.601587
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    assert repr(Posting(10, datetime.date(2020, 1, 15), Account("Assets:Cash"), Direction.INC, Amount(10))) == "2020-01-15 Assets:Cash INC 10"

# Generated at 2022-06-24 01:00:47.877484
# Unit test for constructor of class Posting
def test_Posting():
    pass

# Generated at 2022-06-24 01:00:55.941110
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    entry_1=JournalEntry(date=datetime.date(year=2020,month=1,day=1),description='Test',source=object())
    entry_1.postings.append(Posting(journal=entry_1,date=datetime.date(2020,1,1),account='Test account',direction=Direction.INC,amount=Amount(1)))
    entry_1.validate()

    entry_2=JournalEntry(date=datetime.date(year=2020,month=1,day=1),description='Test',source=object())
    entry_2.postings.append(Posting(journal=entry_2,date=datetime.date(2020,1,1),account='Test account',direction=Direction.INC,amount=Amount(1)))
    entry_2.validate()


# Generated at 2022-06-24 01:01:05.826974
# Unit test for constructor of class Posting
def test_Posting():
    P1 = Posting(JournalEntry(), datetime.date(2019, 9, 26), Account("FOO"), Direction.of(Quantity(10)), Amount(1))
    assert P1.account.type == AccountType.UNKNOWN
    assert P1.direction == Direction.INC
    print(P1)

# Generated at 2022-06-24 01:01:13.683901
# Unit test for constructor of class Posting
def test_Posting():
    """
    Ensure that we can construct a posting successfully.
    """
    # create journal entry object
    journal_entry = JournalEntry('journal entry', datetime.date(2017,1,1), 'description', 'source', 'postings')
    # create account object
    account = Account('account_id', 'account_title', 'account_type')
    # create posting object
    posting = Posting(journal_entry, datetime.date(2017,1,1), account, Direction.INC, 100)
    # ensure that posting is debit
    assert posting.is_debit
    # ensure that posting is not credit
    assert not posting.is_credit


# Generated at 2022-06-24 01:01:22.414320
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    # Create a Posting
    journal = JournalEntry(date=datetime.date(2020, 1, 1), description="a", source="a")
    date = datetime.date(2020, 1, 1)
    account = Account("a", AccountType.ASSETS, True)
    direction = Direction.INC
    amount = Amount(100)
    posting = Posting(journal, date, account, direction, amount)
    # Retrieve the hash of the Posting
    posting_hash = posting.__hash__()
    # Check the hash is not None
    assert posting_hash is not None

# Generated at 2022-06-24 01:01:33.126724
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from ..portfolios.models import Position, Tran
    from ..portfolios.simulation import SimulatedSession
    from .accounts import Account

    session: SimulatedSession
    session = SimulatedSession(date=datetime.date(2010, 1, 1))

    position: Position
    position = Position(session=session, account=Account.of(guid="ROOT"), quantity=1000)

    position.modify(date=datetime.date(2010, 1, 2), quantity=900)
    position.modify(date=datetime.date(2010, 1, 3), quantity=1100)

    assert position.journal.postings[0].amount == 100
    assert position.journal.postings[1].amount == 200
    assert position.journal.postings[2].amount == 200

    del position.journal.postings[1]

   

# Generated at 2022-06-24 01:01:34.490794
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    date = datetime.date
    assert date(2020, 1, 1) == date(2020, 1, 1)

# Generated at 2022-06-24 01:01:38.049233
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    posting1 = Posting(journal='', date='', account='', direction='', amount=10)
    posting2 = Posting(journal='', date='', account='', direction='', amount=10)
    assert (posting1 == posting2)


# Generated at 2022-06-24 01:01:43.887995
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from .accounts import Account
    from .accounts import AccountType
    from .journal_entries import JournalEntry
    from .journal_entries import Posting
    from .journal_entries import Direction
    from .commons.numbers import Amount
    from .commons.others import makeguid
    from datetime import date
    je1 = JournalEntry(date.today(), "Description_1", None)
    je2 = JournalEntry(date.today(), "Description_2", None)
    posting1 = Posting(je1, date.today(), Account("A1", AccountType.ASSETS), Direction.INC, Amount(99))
    posting2 = Posting(je1, date.today(), Account("A1", AccountType.ASSETS), Direction.INC, Amount(99))

# Generated at 2022-06-24 01:01:53.870696
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    je1 = JournalEntry(datetime.date.today(), "N/A", None)
    assert repr(je1) == "JournalEntry(date=datetime.date(2019, 5, 31), description='N/A', guid=a3239b30-17e0-400d-8b2f-07b37438ba9a, postings=())", "Start with empty postings"

    # Test JournalEntry with one posting
    je2 = JournalEntry(datetime.date.today(), "N/A", None)
    account1 = Account(AccountType.EQUITIES, "Shareholder equity")
    je2.post(datetime.date.today(), account1, 500)

# Generated at 2022-06-24 01:01:54.321149
# Unit test for constructor of class Posting
def test_Posting():
    assert Posting()

# Generated at 2022-06-24 01:02:03.325226
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    je = JournalEntry(
        date=datetime.date(2019, 12, 31),
        description="A test journal entry",
        source=None
    )

    # Act
    je.post(
        date=datetime.date(2019, 10, 1),
        account=Account(
            name="A Bank account",
            account_type=AccountType.ASSETS
        ),
        quantity=100
    )

    # Assert
    assert len(je.postings) == 1
    assert je.postings[0].journal == je
    assert je.postings[0].date == datetime.date(2019, 10, 1)
    assert je.postings[0].account == Account(
        name="A Bank account",
        account_type=AccountType.ASSETS
    )
    assert je.post

# Generated at 2022-06-24 01:02:08.517226
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
  """
  Test the constructor of class JournalEntry
  """
  try:
    j1 = JournalEntry(date=datetime.date(2020, 5, 9), description = "Test", source = 0)

    assert j1 is not None
  except Exception as e:
    print(e)
    raise AssertionError("JournalEntry constructor failed")


# Generated at 2022-06-24 01:02:09.972389
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    _T = TypeVar('_T')
    a = classmethod(ReadJournalEntries)

# Generated at 2022-06-24 01:02:21.343574
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    
    from ..commons.zeitgeist import DateRange, DateTimeRange

    from .accounts import Accounts, AccountType, PostingFlag

    from .transactions import Sale
    from .accounts import Account

    from .unittests import mock_accounts

    import datetime

    accounts = mock_accounts()

    #: Create a sale entry with empty attributes.
    sale = Sale()

    #: Set values on attributes.
    sale.sale_date = datetime.date(2020, 1, 1)
    sale.sale_account = Account(accounts.cash_at_hand)
    sale.sale_amount = 100
    sale.cost_account = Account(accounts.discount_given)
    sale.cost_amount = -50
    sale.tax_account = Account(accounts.gst_collected)
    sale

# Generated at 2022-06-24 01:02:28.273806
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    from datetime import date
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .accounts import AccountType
    from .accounts import get_account
    from .events import Event
    from .events import TransactionEvent
    from .events import TransactionEntry
    from .events import TransactionType

    account_cash = get_account(AccountType.ASSETS, "Cash")
    account_income = get_account(AccountType.REVENUES, "Income")
    account_expenses = get_account(AccountType.EXPENSES, "Expenses")


    # Transaction Event
    transaction_event_1 = TransactionEvent(date(2019, 1, 1),  "gift", TransactionType.INCOME,
                                           {TransactionEntry(account_cash, Quantity(10))})

    # Transaction Event
    transaction

# Generated at 2022-06-24 01:02:31.362490
# Unit test for method __call__ of class ReadJournalEntries
def test_ReadJournalEntries___call__():
    from datetime import date  # type: ignore

    assert list(ReadJournalEntries()(DateRange(date(2020, 3, 1), date(2020, 5, 31)))) == []



# Generated at 2022-06-24 01:02:38.383124
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    # Given
    desc = "Test"
    date = datetime.date(2020, 9, 1)
    journal = JournalEntry[object](date, desc)
    account1 = Account(name="Bank", type=AccountType.ASSETS)
    account2 = Account(name="Cash", type=AccountType.ASSETS)
    credit = 999
    debit = 1
    journal.post(date, account1, credit).post(date, account2, debit)

    # When/Then
    assert journal == journal


# Generated at 2022-06-24 01:02:44.734061
# Unit test for method __eq__ of class JournalEntry
def test_JournalEntry___eq__():
    j1=JournalEntry(None, 'foo', None, [])
    j2=JournalEntry(None, 'foo', None, [])
    assert j1==j2
    j3=JournalEntry(None, 'bar', None, [])
    assert j1!=j3
    j4=JournalEntry(None, 'foo', None, [Posting(j1, None, None, None, None)])
    assert j1!=j4


# Generated at 2022-06-24 01:02:52.910744
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    p1 = Posting(None, datetime.date(2019, 3, 1), Account(1, "Test1", AccountType.ASSETS, ""), Direction.INC, Amount(10))
    p2 = Posting(None, datetime.date(2019, 3, 1), Account(1, "Test1", AccountType.ASSETS, ""), Direction.INC, Amount(10))
    assert p1 == p2
    p1 = Posting(None, datetime.date(2019, 3, 1), Account(1, "Test1", AccountType.ASSETS, ""), Direction.INC, Amount(10))
    p2 = Posting(None, datetime.date(2019, 3, 1), Account(1, "Test2", AccountType.ASSETS, ""), Direction.INC, Amount(10))
    assert not p1 == p2
    p

# Generated at 2022-06-24 01:02:59.139528
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import read_accounts

    # Given
    accounts = read_accounts("accounts.csv")
    period = DateRange(date(2019, 5, 1), date(2019, 5, 31))
    accounts_f = read_accounts("accounts.csv")
    def read_journal_entries(period_):
        return []
    ReadJournalEntries_2 = ReadJournalEntries
    ReadJournalEntries_2()
    # When
    ReadJournalEntries()
    # Then
    assert 1 == 1, f"Test should be finished"

# Generated at 2022-06-24 01:03:09.765969
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    a = Posting(None, datetime.date.today(), Account("a", AccountType.ASSETS), Direction.INC, Amount(1.23))
    b = Posting(None, datetime.date.today(), Account("b", AccountType.ASSETS), Direction.INC, Amount(1.23))
    c = Posting(None, datetime.date.today(), Account("a", AccountType.ASSETS), Direction.DEC, Amount(1.23))
    d = Posting(None, datetime.date.today(), Account("a", AccountType.ASSETS), Direction.INC, Amount(2.34))
    assert a == a
    assert a != b
    assert a != c
    assert a != d


# Generated at 2022-06-24 01:03:12.522561
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    class _ReadJournalEntries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return None
    ReadJournalEntries = _ReadJournalEntries()
    assert ReadJournalEntries

# Generated at 2022-06-24 01:03:15.455878
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    date = datetime.date(2020, 10, 10)
    description = "foo bar"
    source = "yo"
    journal = JournalEntry(date, description, source)
    assert journal.date == date
    assert journal.description == description
    assert journal.source == source


# Generated at 2022-06-24 01:03:26.002788
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    from dataclasses import asdict, astuple, replace
    from ..commons.numbers import zero
    from ..commons.random import Random

    # Prepare test data
    rand = Random()
    journal = rand.journal_entry(Random.random_date(), "Scripted test")
    account = rand.account('', AccountType.ASSETS)
    direction = Direction.INC
    amount = Amount(1000)
    posting = Posting(journal, journal.date, account, direction, amount)

    # Test __eq__ method
    assert posting == posting
    assert posting != Posting(journal, journal.date, account, Direction.DEC, amount)
    assert posting != Posting(journal, journal.date, account, direction, Amount(1000.001))
    assert posting != Posting(journal, journal.date, account, direction, amount)

# Generated at 2022-06-24 01:03:33.870571
# Unit test for constructor of class Posting
def test_Posting():
    journal = JournalEntry(datetime.date(2020, 9, 4), '', 0)
    date = datetime.date(2020, 9, 4)
    account = Account(AccountType.ASSETS, '', '', '')
    direction = Direction.INC
    amount = Amount(10)
    p = Posting(journal, date, account, direction, amount)
    assert p.journal == journal
    assert p.date == date
    assert p.account == account
    assert p.direction == direction
    assert p.amount == amount
    assert p.is_debit
    assert not p.is_credit

# Generated at 2022-06-24 01:03:43.533987
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    from dataclasses import _MISSING_TYPE
    Posting.journal = None  # type: ignore
    Posting.date = None  # type: ignore
    Posting.account = None  # type: ignore
    Posting.direction = None  # type: ignore
    Posting.amount = None  # type: ignore
    Posting.is_debit = None  # type: ignore
    Posting.is_credit = None  # type: ignore


# Generated at 2022-06-24 01:03:45.406472
# Unit test for constructor of class Posting
def test_Posting():
    assert True
    return True

# Generated at 2022-06-24 01:03:48.045288
# Unit test for method __setattr__ of class Posting
def test_Posting___setattr__():
    journal = JournalEntry(datetime.date.today(), 'description', 'source')
    try:
        Posting(journal, datetime.date.today(), Account('AccountName', 'AccountType'), Direction.INC, Amount(100))
    except Exception as e:
        print(e)
        pass

# Generated at 2022-06-24 01:04:00.471165
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    # Arrange
    journal_1_date = datetime.date(2020, 1, 1)
    account_1 = Account('Assets', 'A1', AccountType.ASSETS)
    amount_1 = Amount(1)
    direction_1 = Direction.INC

    journal_2_date = datetime.date(2020, 1, 1)
    account_2 = Account('Equities', 'E1', AccountType.EQUITIES)
    amount_2 = Amount(2)
    direction_2 = Direction.INC
    
    journal_3_date = datetime.date(2020, 1, 1)
    account_3 = Account('Liabilities', 'L1', AccountType.LIABILITIES)
    amount_3 = Amount(3)
    direction_3 = Direction.INC
    
    journal_4_date = datetime.date

# Generated at 2022-06-24 01:04:10.858422
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    # Arrange
    str_A = "Account A"
    str_B = "Account B"
    acct_A = Account(name=str_A, type=AccountType.ASSETS)
    acct_B = Account(name=str_B, type=AccountType.LIABILITIES)
    qty_100 = 100
    qty_200 = 200
    qty_minus_100 = -100
    qty_minus_200 = -200
    date = datetime.date.today()
    tst_jrnl = JournalEntry(date, "", 0)

    # Assert
    assert tst_jrnl.postings == []
    assert tst_jrnl.increments == []
    assert tst_jrnl.decrements == []

# Generated at 2022-06-24 01:04:16.341899
# Unit test for constructor of class Posting
def test_Posting():
    posting1 = Posting('JournalEntry1', datetime.date(), 'Account', 'Direction', 100)
    assert posting1.journal == 'JournalEntry1' 
    assert posting1.date == datetime.date()
    assert posting1.account == 'Account'
    assert posting1.direction == 'Direction'
    assert posting1.amount == 100


# Generated at 2022-06-24 01:04:22.716673
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():
    date = datetime.date(2020,7,31)
    description = "sell"
    account = Account("expenses",AccountType.EXPENSES)
    journal = JournalEntry(date,description,None)
    quantity = 3
    journal.post(date,account,quantity)
    assert journal.postings[0].account == account
    assert journal.postings[0].direction == Direction.INC
    assert journal.postings[0].amount == Amount(quantity)

# Generated at 2022-06-24 01:04:33.769714
# Unit test for method __eq__ of class Posting
def test_Posting___eq__():
    """
    This test is going to validate equality of two instances of Posting class.
    """

    #Arrange
    struct1 = JournalEntry(date = datetime.date.today(), description = "Some description", source = "Some Source")
    struct1.post(date = datetime.date.today(),account = Account(), quantity = Amount(5))
    struct2 = JournalEntry(date = datetime.date.today(), description = "Some description", source = "Some Source")
    struct2.post(date = datetime.date.today(),account = Account(), quantity = Amount(5))
    struct3 = JournalEntry(date = datetime.date.today(), description = "Some description", source = "Some Source")
    struct3.post(date = datetime.date.today(),account = Account(), quantity = Amount(5))

    #Act
    result

# Generated at 2022-06-24 01:04:36.546341
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    pass


# Generated at 2022-06-24 01:04:45.749563
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    a=JournalEntry(datetime.date.today(), "hello", "YJ")
    a.post(datetime.date.today(), Account("hello"), 10)
    # print(a.__repr__())

# Generated at 2022-06-24 01:04:53.127017
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    class JournalEntry:    # 1
        def __init__(self, description, date):
            self.description = description
            self.date = date

    class Posting:    # 2
        def __init__(self, journal, date, account, direction, amount):
            self.journal = journal
            self.date = date
            self.account = account
            self.direction = direction
            self.amount = amount
        def __delattr__(self, attr):
            super().__delattr__(attr)
            if attr == 'amount':
                self.account.amount -= self.amount # 3

    class Account:    # 4
        def __init__(self, name, type, amount=0):
            self.name = name
            self.type = type
            self.amount = amount

# Generated at 2022-06-24 01:05:03.139193
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import Account, AccountType
    from .sources.transactions import Transaction
    # Create an account and a transaction object, then create a journal entry with these
    account1 = Account("Assets:Cash", AccountType.ASSETS)
    transaction1 = Transaction("2004-01-01", "Bank deposit", 100, "Assets:Cash")
    entry1 = JournalEntry[Transaction]("2004-01-01", "Bank deposit", transaction1)
    entry1.post("2004-01-01", account1, 100)
    # Check validate method returns None if the debits and credits are equal
    assert entry1.validate() is None


# Generated at 2022-06-24 01:05:08.571178
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    source = datetime.date.today()
    description = "This is a journal entry unit test"
    je = JournalEntry[datetime.date](date=source, description=description, source=source)
    assert je.date == source
    assert je.description == description
    assert je.source == source
    assert je.postings == []
    assert je.guid != ""



# Generated at 2022-06-24 01:05:12.961901
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    """
    Tests the method __repr__ of class JournalEntry.
    """
    je = JournalEntry("2020-01-01", "f", "s")
    assert repr(je) == "JournalEntry(date=datetime.date(2020, 1, 1), description='f', source='s', postings=[])"


# Generated at 2022-06-24 01:05:23.403127
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    from .books import Book
    from .businesses import Business

    book = Book("Book")
    business1 = Business("Business1")
    business2 = Business("Business2")

    journalEntry1 = JournalEntry[Business](datetime.date.today(), "Dummy entry1", business1)
    journalEntry2 = JournalEntry[Business](datetime.date.today(), "Dummy entry2", business1)
    journalEntry3 = JournalEntry[Business](datetime.date.today(), "Dummy entry3", business1)

    assert hash(journalEntry1) == hash(journalEntry2)
    assert hash(journalEntry1) == hash(journalEntry3)
    assert hash(journalEntry2) == hash(journalEntry3)


# Generated at 2022-06-24 01:05:24.475077
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    p = Posting
    p[int](1,1,1,"EUR",2)

# Generated at 2022-06-24 01:05:31.365724
# Unit test for method __repr__ of class JournalEntry
def test_JournalEntry___repr__():
    assert (
        JournalEntry(date=datetime.date(2020, 1, 1), description="One", source=None).__repr__()
        == "JournalEntry(date=datetime.date(2020, 1, 1), description='One', source=None, postings=[], guid=<GUID>)"
    )

# Generated at 2022-06-24 01:05:40.646463
# Unit test for constructor of class JournalEntry
def test_JournalEntry():
    journal1 = JournalEntry[str](date='2020-12-01', description='Open book for 2020', source='Book', postings=['EXPENSE: 100'])
    journal2 = JournalEntry[str](date='2020-12-01', description='Open book for 2020', source='Book', postings=['REVENUE: 100'])
    journal3 = JournalEntry[str](date='2020-12-01', description='Open book for 2020', source='Book', postings=['REVENUE: 100', 'EXPENSE: 100'])
    assert journal1.date == '2020-12-01'
    assert journal2.date == '2020-12-01'
    assert journal3.date == '2020-12-01'
    assert journal1.description == 'Open book for 2020'
    assert journal2.description == 'Open book for 2020'
    assert journal3

# Generated at 2022-06-24 01:05:47.998883
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    from .accounts import IncomeAccount, ExpenseAccount, EquityAccount
    from .commons.numbers import ZERO_AMOUNT

    # Case 1: DEBITS = CREDITS successfully
    a = JournalEntry(datetime.date.today(), "desc", "bsn", [
        Posting(None, datetime.date.today(), IncomeAccount("INCOME_ACCOUNT"), Direction.INC, Amount(100)),
        Posting(None, datetime.date.today(), ExpenseAccount("EXPENSE_ACCOUNT"), Direction.DEC, Amount(100)),
    ])
    a.validate()

    # Case 2: DEBITS < CREDITS, successfully raises an error

# Generated at 2022-06-24 01:05:56.271746
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    assert hash(JournalEntry(datetime.date(2019, 6, 7), "", ())) == hash(JournalEntry(datetime.date(2019, 6, 7), "", ()))
    assert hash(JournalEntry(datetime.date(2019, 6, 7), "", ())) != hash(JournalEntry(datetime.date(2019, 6, 8), "", ()))
    assert hash(JournalEntry(datetime.date(2019, 6, 7), "", ())) != hash(JournalEntry(datetime.date(2019, 6, 7), "A", ()))
    assert hash(JournalEntry(datetime.date(2019, 6, 7), "", ())) != hash(JournalEntry(datetime.date(2019, 6, 7), "", "A"))

# Generated at 2022-06-24 01:06:02.030789
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    journal = JournalEntry(datetime.date.today(), "test", None)
    journal.post(datetime.date.today(), Account.create("ASSETS", "cash"), 100)
    journal.post(datetime.date.today(), Account.create("REVENUES", "revenue"), -100)
    journal.validate()

# Generated at 2022-06-24 01:06:02.636326
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    pass

# Generated at 2022-06-24 01:06:07.917940
# Unit test for method validate of class JournalEntry
def test_JournalEntry_validate():
    # Get total debit and credit amounts:
    total_debit = isum(i.amount for i in self.debits)
    total_credit = isum(i.amount for i in self.credits)

    # Check:
    assert total_debit == total_credit, f"Total Debits and Credits are not equal: {total_debit} != {total_credit}"

# Generated at 2022-06-24 01:06:09.259531
# Unit test for constructor of class ReadJournalEntries
def test_ReadJournalEntries():
    read_je = ReadJournalEntries()
    assert(read_je == ReadJournalEntries)

# Generated at 2022-06-24 01:06:18.981651
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    from lch.journal import JournalEntry
    from lch.accounts import Account
    from lch.balance import Balance
    from lch.zeitgeist import now

    balance = Balance()
    date = now()

    balance.register(Account("Assets:Current Assets:Cash"))
    balance.register(Account("Assets:Current Assets:Bank"))
    balance.register(Account("Liabilities:Current Liabilities"))
    balance.register(Account("Liabilities:Current Liabilities:Credit Card"))
    balance.register(Account("Expenses:Salaries"))

    journal = JournalEntry()

    journal.post(date, balance.find("Assets:Current Assets:Cash"), Amount(100.00))
    journal.post(date, balance.find("Liabilities:Current Liabilities:Credit Card"), Amount(-100.00))

# Generated at 2022-06-24 01:06:26.064658
# Unit test for method validate of class JournalEntry

# Generated at 2022-06-24 01:06:35.220935
# Unit test for method __repr__ of class JournalEntry

# Generated at 2022-06-24 01:06:46.232754
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from datetime import date
    from decimal import Decimal

    from .accounts import Account, AccountType

    assert hasattr(JournalEntry, "__setattr__")

    journal_entry = JournalEntry(date(2020, 1, 10), "Description", None)

    with pytest.raises(AttributeError):
        journal_entry.postings = []
    assert journal_entry.postings == []

    with pytest.raises(AttributeError):
        journal_entry.guid = uuid.UUID("00000000-0000-0000-0000-000000000000")
    assert journal_entry.guid != uuid.UUID("00000000-0000-0000-0000-000000000000")

    with pytest.raises(TypeError):
        journal_entry.date = "2020-01-10"

# Generated at 2022-06-24 01:06:52.495706
# Unit test for method __repr__ of class Posting
def test_Posting___repr__():
    test_journal=JournalEntry(datetime.datetime.now(),"Description","source")
    test_account=Account(account_type=AccountType.ASSETS,code="assets1",name="assets1")
    test_posting=Posting(test_journal,datetime.datetime.now(),test_account,Direction.DEC,Amount(1))
    test_posting.__repr__()
    assert True==True

# Generated at 2022-06-24 01:07:01.880046
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    a1 = Posting(1, "A", 2, 3, 4)
    a2 = Posting(1, "B", 2, 3, 4)
    a3 = Posting(2, "A", 2, 3, 4)
    a4 = Posting(1, "A", 1, 3, 4)
    a5 = Posting(1, "A", 2, 1, 4)
    a6 = Posting(1, "A", 2, 3, 1)
    a7 = Posting(1, "A", 2, 3, 4)
    assert isinstance(a1, Posting)
    assert isinstance(a1, object)
    assert hash(a1) != hash(a2)
    assert hash(a1) != hash(a3)
    assert hash(a1) != hash(a4)
   

# Generated at 2022-06-24 01:07:03.124561
# Unit test for constructor of class Posting
def test_Posting():
	#return DateRange()
	return Posting()

# Generated at 2022-06-24 01:07:07.126937
# Unit test for method __setattr__ of class JournalEntry
def test_JournalEntry___setattr__():
    from src.journal.journal import JournalEntry
    je = JournalEntry[str](date=datetime.date(year=2000, month=1, day=1), description="desc", source="source")
    print(je.date) # 2000-01-01
    je.date=datetime.date(year=2019, month=12, day=31)
    print(je.date) # 2019-12-31

# Generated at 2022-06-24 01:07:07.611075
# Unit test for method __delattr__ of class Posting
def test_Posting___delattr__():
    pass

# Generated at 2022-06-24 01:07:13.133678
# Unit test for method __hash__ of class JournalEntry
def test_JournalEntry___hash__():
    """ Unit test for method __hash__ of class JournalEntry. """

    @dataclass(frozen=True)
    class _Tag:
        """ Tag class for the unit test. """
        pass

    @dataclass(frozen=True)
    class _Tag2:
        """ Tag2 class for the unit test. """
        pass

    _ACCOUNT1 = Account(
        type=AccountType.ASSETS,
        fullname="_ACCOUNT1",
        shortname="A1",
        description="Test account 1",
    )
    _ACCOUNT2 = Account(
        type=AccountType.ASSETS,
        fullname="_ACCOUNT2",
        shortname="A2",
        description="Test account 2",
    )

# Generated at 2022-06-24 01:07:18.313023
# Unit test for method post of class JournalEntry
def test_JournalEntry_post():

    p = Posting('', datetime.date(2018, 1, 1), '', Direction.INC, Amount(123))
    je = JournalEntry(datetime.date(2018, 1, 1), '', '', [p])
    je.post(datetime.date(2018, 1, 1), '', Quantity(100))
    assert len(je.postings) == 2

# Generated at 2022-06-24 01:07:22.579070
# Unit test for constructor of class Posting
def test_Posting():
    new_Account = Account('DEBIT', AccountType.ASSETS, 1)
    new_Entry = JournalEntry(date=datetime.date(2015,12,25),description= "Hello")
    new_Posting(new_Entry, date=datetime.date(2015,12,25),account=new_Account,direction=Direction.INC,amount=Amount(1.00))
    assert(new_Posting.journal == new_Entry)
    assert(new_Posting.date == datetime.date(2015, 12, 25))
    assert(new_Posting.account == new_Account)
    assert(new_Posting.direction == Direction.INC)
    assert(new_Posting.amount == Amount(1.00))


# Generated at 2022-06-24 01:07:27.981737
# Unit test for constructor of class Posting
def test_Posting():
    je:JournalEntry = JournalEntry()
    p = Posting(je, datetime.date.today(), Account(), Direction.INC, Amount(10))
    assert p.journal is je
    assert p.date == datetime.date.today()
    assert isinstance(p.account, Account)
    assert p.direction == Direction.INC
    assert p.amount == Amount(10)

# Generated at 2022-06-24 01:07:35.132822
# Unit test for method __hash__ of class Posting
def test_Posting___hash__():
    journal_entry_1 = JournalEntry('2019-01-01', 'Test Journal Entry 1')
    journal_entry_2 = JournalEntry('2019-01-01', 'Test Journal Entry 2')
    list_of_postings = [Posting(journal_entry_1, '2019-01-01', Account('Test Account', AccountType.ASSETS), Direction.INC, 12), Posting(journal_entry_2, '2019-01-01', Account('Test Account', AccountType.ASSETS), Direction.INC, 12)]
    s = set()
    for p in list_of_postings:
        s.add(p)
    assert len(s) == 1

# Generated at 2022-06-24 01:07:45.462719
# Unit test for method __delattr__ of class JournalEntry
def test_JournalEntry___delattr__():
    # We need to declare a concrete class for the generic journal entry class JournalEntry
    # to make sure the 'frozen' attribute is set to True. Otherwise, we cannot drop attributes from it.
    @dataclass
    class AccountableJournalEntry(JournalEntry):
        pass
    acc_je = AccountableJournalEntry(1, 2, 3, 4, 5)
    assert acc_je.__dict__ == {'date': 1, 'description': 2, 'source': 3, 'postings': 4, 'guid': 5}
    del acc_je.postings
    assert acc_je.__dict__ == {'date': 1, 'description': 2, 'source': 3, 'guid': 5}
    try:
        del acc_je.date
    except AttributeError as e:
        # should raise AttributeError
        pass
   