

# Generated at 2022-06-23 20:01:31.158667
# Unit test for constructor of class Session
def test_Session():
    # Case 1
    session_1 = Session("test_Session.json")
    dic_1 = {
        "headers": {},
        "cookies": {},
        "auth": {
            "type": None,
            "username": None,
            "password": None
        }
    }
    assert dic_1 == session_1
    # Case 2
    path_2 = "C:\\User\\Desktop\\test1.json"
    session_2 = Session(path_2)
    dic_2 = {
        "headers": {},
        "cookies": {},
        "auth": {
            "type": None,
            "username": None,
            "password": None
        }
    }
    assert dic_2 == session_2
    # Case 3

# Generated at 2022-06-23 20:01:40.376898
# Unit test for constructor of class Session
def test_Session():
    session = Session("test_path")
    assert isinstance(session['headers'], dict)
    assert isinstance(session['cookies'], dict)
    session["headers"]["key1"] = "test1"
    session["headers"]["key2"] = "test2"
    assert len(session["headers"]) == 2
    assert session["headers"]["key1"] == "test1"
    assert session["headers"]["key2"] == "test2"
    session["cookies"]["key1"] = "test1"
    session["cookies"]["key2"] = "test2"
    assert len(session["cookies"]) == 2
    assert session["cookies"]["key1"] == "test1"
    assert session["cookies"]["key2"] == "test2"



# Generated at 2022-06-23 20:01:45.269617
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.context import Environment
    env = Environment()
    env.config.dir = Path('.')
    session = get_httpie_session(env.config.dir, 'test_session', 'localhost', 'http://localhost:5000')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
    }

# Generated at 2022-06-23 20:01:47.307350
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR,"session", "http://127.0.0.1", "http://127.0.0.1") is Session


# Generated at 2022-06-23 20:01:58.458572
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json

    request_headers = {
        'Accept': 'text/json',
        'Cookie': "key1=value1; key2=value2",
        'Content-Type': 'text/json',
        'If-None-Match': '"123"',
        'If-Modified-Since': 'Tue, 08 Apr 2014 01:02:03 GMT'
    }
    request_headers['Cookie']
    headers = {
        'Accept': 'text/json',
        'Content-Type': 'text/json',
        'If-None-Match': '"123"',
        'If-Modified-Since': 'Tue, 08 Apr 2014 01:02:03 GMT'
    }

# Generated at 2022-06-23 20:02:01.802134
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session=Session('/tmp/file.json')
    session.cookies=RequestsCookieJar()
    session['cookies']['a']={"value":"12","value2":"34"}
    session.remove_cookies(['a'])
    assert not 'a' in session['cookies']

# Generated at 2022-06-23 20:02:04.779920
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    mocked_session = {'cookies': {'hello': 'world'}}
    session = Session('my_session')
    session.dict = mocked_session
    session.remove_cookies({'hello'})
    assert(len(mocked_session['cookies']) == 0)

# Generated at 2022-06-23 20:02:07.164061
# Unit test for constructor of class Session
def test_Session():
    s = Session("a/b/c/session")
    assert s.path == Path("a/b/c/session")


# Generated at 2022-06-23 20:02:12.979671
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./')
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    session.remove_cookies(['cookie1'])

    assert 'cookie1' not in session['cookies']
    assert 'value1' not in session['cookies']['cookie1']
    assert 'cookie2' in session['cookies']
    assert 'value2' in session['cookies']['cookie2']

# Generated at 2022-06-23 20:02:14.511842
# Unit test for constructor of class Session
def test_Session():
    session = Session('./test_data/test_session.json')
    assert session.path == os.path.normpath('./test_data/test_session.json')

# Generated at 2022-06-23 20:02:22.493384
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(DEFAULT_SESSIONS_DIR / 'test_Session_update_headers')
    session.load()
    req_headers = RequestHeadersDict({
        'Content-Length': 123,
        'Host': 'httpbin.org',
        'If-Unmodified-Since': '0',
        'User-Agent': 'httpie/0.9.2',
        'Cookie': 'foo=bar; spam=eggs'
    })
    session.update_headers(req_headers)
    assert session.headers == RequestHeadersDict({
        'Host': 'httpbin.org',
        'User-Agent': 'httpie/0.9.2'
    })
    assert session.cookies == {
        'foo': 'bar', 'spam': 'eggs'
    }

# Generated at 2022-06-23 20:02:26.456133
# Unit test for constructor of class Session
def test_Session():
    sess_path = Path(__file__).parent.joinpath('../../httpie/sessions/.httpie')
    sess = Session(sess_path)
    assert sess['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-23 20:02:35.836286
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/dev/null')
    session.update_headers({})
    assert (session['headers'] == {})
    assert (session['cookies'] == {})
    assert (session['auth'] == {'type': None, 'username': None,
                                'password': None})

    session.update_headers({'User-Agent': 'Mozilla/5.0'})
    assert (session['headers'] == {'User-Agent': 'Mozilla/5.0'})
    assert (session['cookies'] == {})
    assert (session['auth'] == {'type': None, 'username': None,
                                'password': None})

    session.update_headers({'Cookie': 'name=value'})
    assert (session['cookies'] == {'name': {'value': 'value'}})

# Generated at 2022-06-23 20:02:39.502855
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import os
    import tempfile
    from httpie.context import Environment
    config_dir = Path(tempfile.mkdtemp())
    env = Environment(config_dir=config_dir, is_windows=False)
    get_httpie_session(env.config_dir, 'foo', None, 'http://localhost')

# Generated at 2022-06-23 20:02:43.842407
# Unit test for constructor of class Session
def test_Session():
    session = Session(path='test')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-23 20:02:55.312561
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('')
    s.update_headers(RequestHeadersDict({'Accept': 'application/json'}))
    s.update_headers(RequestHeadersDict({'Accept': 'application/xml'}))

    assert len(s['headers']) == 1
    assert s['headers'].get('Accept') != None
    assert s['headers']['Accept'] == 'application/json'

    s.update_headers(RequestHeadersDict({'If-Match': None}))
    assert len(s['headers']) == 1
    assert s['headers']['Accept'] == 'application/json'

    s.update_headers(RequestHeadersDict({'Cookie': 'a=b; c=d'}))
    assert len(s['headers']) == 1

# Generated at 2022-06-23 20:02:58.551201
# Unit test for constructor of class Session
def test_Session():
    path = 'sessions/test.json'
    session = Session(path)
    session.load()
    return session

# Generated at 2022-06-23 20:03:02.083664
# Unit test for constructor of class Session
def test_Session():
    path = Path('/var/httpie/sessions/localhost/test.json')
    session = Session(path)
    assert session.path == Path('/var/httpie/sessions/localhost/test.json')

# Generated at 2022-06-23 20:03:05.503194
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:03:15.339317
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    '''
    test function update_headers:
    1. init Session object, a session object has two property:
        [headers, cookies];
    2. call update_headers to update headers property, which should
        ignore some header while storing others;
    3. check if headers property works as intended.
    '''
    session = Session(path=Path('./test/'))
    session.update_headers(RequestHeadersDict({
        'Content-Type': 'text/plain',
        'Cookie': 'key1=value1; key2=value2',
        'User-Agent': 'HTTPie/1.0.0',
        'Accept': 'text/html'
    }))
    print(session['headers'])
    print(session['cookies'])
    assert('Content-Type' in session['headers'])


# Generated at 2022-06-23 20:03:25.438394
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.cli.dicts import ConfigDict
    config = ConfigDict()
    config['config_dir'] = DEFAULT_CONFIG_DIR
    config['sessions.dir'] = DEFAULT_SESSIONS_DIR

    # nonexistent session
    session = get_httpie_session(config['sessions.dir'], "sessionx", "10.24.8.1", "http://10.24.8.1/api/get")
    assert session is not None

    # new session
    session = get_httpie_session(config['sessions.dir'], "session1", "10.24.8.1", "http://10.24.8.1/api/get")
    assert session is not None
    assert session['headers']
    assert session['cookies']
    assert session['auth']
    assert session

# Generated at 2022-06-23 20:03:30.037538
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(__file__).parent / 'fixtures'
    session_name = 'my_session'
    host = 'httpbin.org'
    url = 'http://httpbin.org/'
    session = get_httpie_session(config_dir, session_name, host, url)
    print(session)

test_get_httpie_sessiion()

# Generated at 2022-06-23 20:03:36.439863
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from httpie.context import Environment

    env = Environment(config_dir=Path(TemporaryDirectory().name))
    session = Session(Path())

    session.cookies.set_cookie(create_cookie('foo', 'bar'))
    session.cookies.set_cookie(create_cookie('baz', 'qux'))
    session.remove_cookies(['baz', 'qux'])

    cookies = list(session.cookies)
    assert len(cookies) == 1
    assert cookies[0].value == 'bar'

# Generated at 2022-06-23 20:03:39.831567
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_obj = Session('./test')
    session_obj['cookies'] = {'foo': 'bar', 'baz': 'qux'}
    session_obj.remove_cookies(['baz'])
    assert session_obj['cookies'] == {'foo': 'bar'}
    session_obj.remove_cookies(['foo'])
    assert session_obj['cookies'] == {}

# Generated at 2022-06-23 20:03:46.156230
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import os
    os.environ['HTTPIE_CONFIG_DIR'] = '/home/user/httpie/'
    my_session = get_httpie_session(Path(os.environ["HTTPIE_CONFIG_DIR"]), ".session", "www.yahoo.com", "www.yahoo.com")
    my_session["cookies"] = {"name1": {"value": "val1"}, "name2": {"value": "val2"}}
    my_session.remove_cookies(["name1"])
    assert my_session["cookies"] == {"name2": {"value": "val2"}}

# Generated at 2022-06-23 20:03:46.788373
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert True

# Generated at 2022-06-23 20:03:52.461324
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    #A case 1:
    new_headers = RequestHeadersDict({"Content-Type": "application/json"})
    session.update_headers(new_headers)
    assert session.headers == {}
    #A case 2:
    new_headers = RequestHeadersDict({"If-Match": "123"})
    session.update_headers(new_headers)
    assert session.headers == {}
    #A case 3:
    new_headers = RequestHeadersDict({"Accept": "application/json"})
    session.update_headers(new_headers)
    assert session.headers == {"Accept": "application/json"}
    #A case 4:
    new_headers = RequestHeadersDict({"Cookie": "abc=123"})

# Generated at 2022-06-23 20:03:58.782900
# Unit test for function get_httpie_session
def test_get_httpie_session():
    test_session_name = 'test'
    test_host = 'localhost'
    test_url = 'https://www.google.com/'
    test_session = get_httpie_session(DEFAULT_CONFIG_DIR, test_session_name, test_host, test_url)
    path = (DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / test_host / f'{test_session_name}.json')
    assert test_session.path == path

# Generated at 2022-06-23 20:04:09.617400
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.client import test_session
    from httpie.config import Config
    cfg = Config(config_dir = '../httpie/config')
    url = 'http://localhost:8080/httpie/test_session'

    def test_session_host(host, session_name):
        session = get_httpie_session(cfg.config_dir, session_name, host, url)
        # upload the same image
        image_path = Path('../httpie/img/tree.jpg')
        test_session().request(
            'POST',
            url,
            files={ 'image' : (image_path.name, image_path.open('rb'), 'image/jpeg', {}) },
            cookies=session.cookies,
            headers=session.headers
        )
        # update cookie and header
        session

# Generated at 2022-06-23 20:04:13.657795
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {'a': {'value': 1}, 'b': {'value': 2}}
    assert session.remove_cookies(['a', 'c']) == None
    assert session['cookies'] == {'b': {'value': 2}}



# Generated at 2022-06-23 20:04:19.654822
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(DEFAULT_CONFIG_DIR)
    session_name = 'test_session'
    host = 'www.google.com'
    url = 'https://www.google.com'
    path = config_dir / SESSIONS_DIR_NAME / host / f'{session_name}.json'
    session = Session(path)
    session_path = get_httpie_session(config_dir, session_name, host, url)
    assert session_path == session

# Generated at 2022-06-23 20:04:24.335911
# Unit test for constructor of class Session
def test_Session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'my_session'
    host = 'http://httpbin.org'
    url = 'http://httpbin.org/get'
    httpie_session = get_httpie_session(
        config_dir, session_name, host, url)
    print(httpie_session.get('headers'))

# Generated at 2022-06-23 20:04:28.093699
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = get_httpie_session(DEFAULT_CONFIG_DIR, SESSIONS_DIR_NAME, 'www.google.com', 'https://www.google.com')
    assert config_dir

# Generated at 2022-06-23 20:04:37.321749
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Test update_headers of the Session class works as expected
    """
    session = Session("bob.json")

    request_headers = RequestHeadersDict({'Accept-Encoding': "gzip",
                                          'If-Modified-Since': "12345",
                                          'Cookie': 'foo=bar;',
                                          'Content-Type': 'asdf',
                                          'User-Agent': 'HTTPie/1.0.2',
                                          'Not-Ignored': 'qwerz'})
    session.update_headers(request_headers)

    # Check the request_headers object has the expected headers
    assert request_headers == {'Not-Ignored': 'qwerz'}

    # Check the session headers were updated with the expected headers

# Generated at 2022-06-23 20:04:42.937599
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class Foo(Session):
        _is_empty = False
        _is_modified = False
        _is_loaded = True

    session = Foo(config_dir=DEFAULT_SESSIONS_DIR)
    foo_request_headers = RequestHeadersDict((('cookie', 'name1=value1'), ('cookie', 'name2=value2')))
    session.update_headers(foo_request_headers)
    assert(session.cookies.get_dict() == {'name1': 'value1', 'name2': 'value2'})



# Generated at 2022-06-23 20:04:45.887671
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert isinstance(get_httpie_session(
        '$HOME/.httpie', 'example', 'localhost', 'http://localhost/'),
        Session)



# Generated at 2022-06-23 20:04:53.608442
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test_session")
    session.update_headers(RequestHeadersDict({"Cookie":"Name1=Value1;Name2=Value2;Name3=Value3"}))
    session.remove_cookies({"Name1", "Name2"})
    session.cookies.get_dict()
    assert bool(session.cookies.get_dict()["Name1"]) == False
    assert bool(session.cookies.get_dict()["Name2"]) == False
    assert bool(session.cookies.get_dict()["Name3"]) == True

# Generated at 2022-06-23 20:04:59.052572
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    def start_test():
        test = Session('test')
        test['cookies']['biscuit'] = {'value': 'hola', 'path': '/'}
        yield test.remove_cookies, ['biscuit']

    for func, args in start_test():
        try:
            func(*args)
        except Exception as e:
            print(e)
            continue

    print('everything is correct')


if __name__ == '__main__':
    test_Session_remove_cookies()

# Generated at 2022-06-23 20:05:07.963065
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    '''
    unit test for method update_headers of class Session
    '''
    session = Session(path=".httpie/sessions/test_Session_update_headers.json")
    cookie_value = '''qwertyuiop1=qwertyuiop2; Path="/"'''
    header_value = '''Content-Type
application/json
User-Agent'''
    request_headers = [['cookie', cookie_value], ['user-agent', header_value]]
    session.update_headers(request_headers)
    expected_headers = [['user-agent', header_value]]
    expected_cookies = [['qwertyuiop1', 'qwertyuiop2']]

# Generated at 2022-06-23 20:05:15.835093
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins import AuthPlugin
    s = Session('test')
    # Test with empty headers.
    s.update_headers(RequestHeadersDict())
    assert s['headers'] == {}
    assert s['cookies'] == {}
    # Test with a cookie header
    s.update_headers(RequestHeadersDict({'Cookie': 'a=1; b=2'}))
    assert s['headers'] == {}
    assert s['cookies'] == {'a': {'value': '1'}, 'b': {'value': '2'}}
    # Test with a user agent header

# Generated at 2022-06-23 20:05:19.519681
# Unit test for constructor of class Session
def test_Session():
    SESSION = Session('/home/httpie/config/sessions/localhost/test.json')
    test_get_httpie_session('/home/httpie/config')
    test_update_headers(dict())
    test_headers(dict())
    test_cookies(dict())
    test_auth(dict())
    test_remove_cookies(dict())

# Generated at 2022-06-23 20:05:25.298539
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    h = {"Content-Type": "text/html", "Host": "www.example.com"}
    session = Session("")
    session.update_headers(h)
    # Content-Type只有一个字符C所以不会被放入session的headers
    assert 'Content-Type' not in session['headers']
    assert 'Host' in session['headers']

# Generated at 2022-06-23 20:05:31.803632
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Setup
    s = Session('/tmp/test.json')
    s.update({
        'cookies': {
            'a': {'value': 1},
            'b': {'value': 2},
            'c': {'value': 3},
            'd': {'value': 4},
        }
    })

    # Exercise
    s.remove_cookies(['b', 'c'])

    # Verify
    assert s['cookies'] == {
        'a': {'value': 1},
        'd': {'value': 4},
    }

# Generated at 2022-06-23 20:05:38.953804
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import pytest
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.context import Environment
    session = Session(None)
    env = Environment()
    env.update(
        config_dir=DEFAULT_CONFIG_DIR,
        headers=[('Cookie', 'a=b')],
        auth_plugin=HTTPBasicAuth,
        auth_username='abc',
        auth_password='123'
    )
    session.update_headers(env.headers)
    assert session.headers == {'Cookie': 'a=b'}
    assert session.get('auth') == {'type': 'basic', 'username': 'abc', 'password': '123'}
    assert session.get('cookies') == {'a': {'value': 'b'}}

# Generated at 2022-06-23 20:05:45.894560
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test_path')
    session['cookies'] = {}
    session['cookies']['cookie1'] = {'value': 'value1'}
    session['cookies']['cookie2'] = {'value': 'value2'}
    assert session['cookies'] == {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
# End of the unit test

# Generated at 2022-06-23 20:05:51.969794
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import ExitStatus
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.utils import get_response
    from httpie.input import SEP_CREDENTIALS
    from httpie.output.streams import get_default_stream
    from httpie.plugins import AuthPlugin, plugin_manager
    from httpie.session import Session
    from httpie.status import ExitStatus


    class MockAuthPlugin(AuthPlugin):
        name = 'Test basic auth'
        auth_type = 'mock'
        auth_parse = True

        def get_auth(self, *args, **kwargs):
            return (
                self.raw_auth.encode('utf8')
                if self.raw_auth
                else b''
            )



# Generated at 2022-06-23 20:06:01.819293
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    session = Session("0.0.0.0")
    assert len(session.headers) == 0
    session.update_headers(RequestHeadersDict({"Accept": "*/*", "Accept-Encoding": "gzip, deflate"}))
    assert len(session.headers) == 1
    assert session.headers.get("Accept") == "*/*"
    assert session.headers.get("Accept-Encoding") is None
    session.update_headers(RequestHeadersDict({"If-Match": "\"737060cd8c284d8af7ad3082f209582d\""}))
    assert len(session.headers) == 1
    assert session.headers.get("Accept") == "*/*"

# Generated at 2022-06-23 20:06:09.661988
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test.json")
    session.update_headers({
        'Content-Type': 'application/json',
        'Cookie': 'f=b; foo=bar',
        'If-Modified-Since': 'Sat, 27 Jun 2020 03:59:36 GMT'
    })
    assert(session.get("headers") == {
        'Content-Type': 'application/json',
        'Cookie': 'f=b; foo=bar',
        'If-Modified-Since': 'Sat, 27 Jun 2020 03:59:36 GMT'
    })

# Generated at 2022-06-23 20:06:14.635933
# Unit test for constructor of class Session
def test_Session():
    session_name = 'test_name'
    session = Session(session_name)
    assert session.path == Path(session_name)
    assert session.headers == RequestHeadersDict({})
    assert session.cookies == RequestsCookieJar()
    assert session.auth is None

# Generated at 2022-06-23 20:06:22.788880
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import unittest.mock as mock
    session = Session('path')
    session['cookies'] = {
        'cookie1' : {'value' : '1234'},
        'cookie2' : {'value' : '5678'}
    }
    session.remove_cookies(['cookie1'])
    assert session['cookies']['cookie1'] is None
    assert session['cookies']['cookie2'] == {'value' : '5678'}
    del session

# Generated at 2022-06-23 20:06:28.549377
# Unit test for constructor of class Session
def test_Session():
    s = Session('test.json')
    assert s.path.name == 'test.json'
    assert type(s['headers']) is dict
    assert type(s['cookies']) is dict
    assert type(s['auth']) is dict
    assert type(s['auth']['type']) is None
    assert type(s['auth']['username']) is None
    assert type(s['auth']['password']) is None

# Generated at 2022-06-23 20:06:38.992716
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """
    In this test we will test if get_httpie_session() can parse the url correctly.

    :return: None
    """
    import httpie
    if httpie.__version__ != '0.9.9':
        return
    default_session_path = os.path.join(DEFAULT_SESSIONS_DIR, 'localhost', 'default.json')
    path = get_httpie_session(
        DEFAULT_CONFIG_DIR,
        'default',
        'localhost',
        'http://localhost/',
    )
    assert(path.path == default_session_path)
    path_2 = get_httpie_session(
        DEFAULT_CONFIG_DIR,
        'default',
        'localhost',
        'http://localhost:9010/',
    )

# Generated at 2022-06-23 20:06:48.014599
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from tempfile import NamedTemporaryFile
    tmp = NamedTemporaryFile(suffix='.json', delete=False)
    dic = {'headers': [1, 2, 3],
           'cookies': [4, 5, 6],
           'auth': {'type': 'basic',
                    'username': 'user',
                    'password': 'password'}
           }
    import json
    json.dump(dic, tmp)
    tmp.close()
    Session(tmp.name)
    os.unlink(tmp.name)
    return True
    # test passed

# Generated at 2022-06-23 20:06:48.816251
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-23 20:06:50.123900
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-23 20:06:53.534349
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """test for update_headers of class Session"""
    session = Session()
    session.update_headers({"a": "b", "c": "d"})
    assert session.headers == {"a": "b", "c": "d"}



# Generated at 2022-06-23 20:06:58.373630
# Unit test for function get_httpie_session
def test_get_httpie_session():
    r = get_httpie_session(Path('/Users/root/.httpie/sessions'), 'httpbin.org_80', None, 'http://httpbin.org/get')
    assert r == {'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}

# Generated at 2022-06-23 20:07:11.267809
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import unittest

    class TestSuite(unittest.TestCase):
        def setUp(self):
            # The init function only loads the dict from the file
            self.session = Session(None)

        def test_update_headers_without_cookies(self):
            self.session.headers['User-Agent'] = 'httpie/0.9.9'
            self.session.headers['Accept-Encoding'] = 'deflate, gzip'
            self.session.update_headers({'Host': 'localhost'})

            self.assertDictEqual(
                self.session.headers,
                {'Accept-Encoding': 'deflate, gzip', 'Host': 'localhost'})


# Generated at 2022-06-23 20:07:16.437347
# Unit test for constructor of class Session
def test_Session():
    a = Session("test_Session")
    assert a.path == Path("test_Session")
    assert len(a['headers']) == 0
    assert len(a['cookies']) == 0
    assert a['auth']['type'] is None
    assert a['auth']['username'] is None
    assert a['auth']['password'] is None

# Generated at 2022-06-23 20:07:27.667435
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import httpie
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.compat import is_windows
    plugin_manager.load_internal_plugins()
    plugin_manager.load_external_plugins()

    # we create a config file in the folder managed by this instance of
    # httpie.py
    config = Config(base_dir=httpie.DEFAULT_CONFIG_DIR)
    env = Environment(config,
        stdin=None,
        stdout=None,
        stderr=None,
        argv=None,
        env=None,
        is_windows=is_windows,
    )

    session = get_httpie_session(env.config.directory, "unittest", None, None)

    request_

# Generated at 2022-06-23 20:07:35.207444
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {
        'Content-Type': 'application/json', 
        'Host': 'www.google.com', 
        'If-Match': '*', 
        'User-Agent': 'httpie/0.9.9'
    }
    headers_dict = {}
    for key in headers:
        if headers[key] is None:
            continue
        if type(headers[key]) != str:
            headers[key] = headers[key].decode('utf8')
        headers_dict[key] = headers[key]
    assert headers_dict == {'Host': 'www.google.com', 'User-Agent': 'httpie/0.9.9'}

# Generated at 2022-06-23 20:07:44.922291
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session.load()
    session.cookies.set_cookie(create_cookie('a', 'b'))
    session.cookies.set_cookie(create_cookie('c', 'd'))
    session.cookies.set_cookie(create_cookie('e', 'f'))
    assert session.cookies['a']
    assert session.cookies['c']
    assert session.cookies['e']

    session.remove_cookies(['a', 'c'])
    assert 'a' not in session.cookies
    assert 'c' not in session.cookies
    assert session.cookies['e']
    
    session.remove_cookies(['e'])
    assert 'e' not in session.cookies

# Generated at 2022-06-23 20:07:47.286584
# Unit test for constructor of class Session
def test_Session():
    try:
        Session('/home/xxx/httpie/sessions/github.com/aaaa.json')
    except FileNotFoundError as e:
        print(e)

# Generated at 2022-06-23 20:07:48.140511
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session() is None

# Generated at 2022-06-23 20:07:54.006383
# Unit test for constructor of class Session
def test_Session():
    s = Session('/foo/bar')
    assert s['path'] == Path('/foo/bar')
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}
    assert s.auth is None


# Generated at 2022-06-23 20:07:59.698482
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.utils import env
    env.config_dir = Path(DEFAULT_CONFIG_DIR)
    s = get_httpie_session(env.config_dir, 'felix', 'https://httpie.org', 'https://httpie.org')
    assert len(s) == 3
    assert s['headers'] == {}

# Generated at 2022-06-23 20:08:09.228641
# Unit test for constructor of class Session
def test_Session():
    test_dict = {'headers': {'User-Agent': 'HTTPie/1.0.2'}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}
    test_path = DEFAULT_SESSIONS_DIR / 'test_session.json'
    s = Session(test_path)
    assert s == test_dict
    assert s.path == test_path
    assert s.headers == test_dict['headers']
    assert s.cookies == test_dict['cookies']
    assert s.auth == test_dict['auth']



# Generated at 2022-06-23 20:08:13.845221
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='test',
        host=None,
        url='https://httpbin.org/post',
    )

    assert os.path.exists(session.path)

# Generated at 2022-06-23 20:08:20.588153
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_to_remove = 'test'
    sess = Session('session.json')
    sess.cookies = RequestsCookieJar()
    sess.cookies.set(cookie_to_remove, 'test')
    assert cookie_to_remove in sess.cookies
    sess.remove_cookies([cookie_to_remove])
    assert cookie_to_remove not in sess.cookies



# Generated at 2022-06-23 20:08:25.511594
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = '/home/mert/.httpie'
    session_name = '1'
    host = '127.0.0.1'
    url = 'http://127.0.0.1/3'
    assert get_httpie_session(config_dir, session_name, host, url) == Session( '/home/mert/.httpie/sessions/127.0.0.1/1.json' )


# Generated at 2022-06-23 20:08:30.479602
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/foo')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

test_Session_remove_cookies()

# Generated at 2022-06-23 20:08:33.573407
# Unit test for function get_httpie_session
def test_get_httpie_session():
	assert(get_httpie_session(config_dir=DEFAULT_CONFIG_DIR, session_name='xyz', host="", url="") is not None)

# Generated at 2022-06-23 20:08:38.642207
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    request_headers = RequestHeadersDict()
    request_headers.add_if_not_exists('Cookie', 'custome')
    session.update_headers(request_headers)
    assert (session['headers'] == {})



# Generated at 2022-06-23 20:08:42.130105
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, "sessionname", None, "http://localhost/") != None


# Generated at 2022-06-23 20:08:51.603794
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(os.path.expanduser("~/.httpie"))
    session_name = "my_session"
    default_session_path = config_dir / SESSIONS_DIR_NAME / "localhost" / "my_session.json"
    url = "http://localhost:5000"
    assert get_httpie_session(config_dir, session_name, None, url).path == default_session_path
    url = "http://localhost:5000/new/url"
    assert get_httpie_session(config_dir, session_name, None, url).path == default_session_path
    url = "http://some.other.server.de/some/url"
    assert get_httpie_session(config_dir, session_name, None, url).path == default_session_path
    session_name

# Generated at 2022-06-23 20:08:57.125009
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/home/httpie/.httpie/session')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2', 'name3': 'value3'}
    session.remove_cookies(('name1', 'name3'))

    assert session['cookies'] == {'name2': 'value2'}



# Generated at 2022-06-23 20:09:01.695881
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(Path("~/.config/httpie"), "name", None, "https://localhost/")
    assert session.path == Path("~/.config/httpie/sessions/localhost/name.json")

# Generated at 2022-06-23 20:09:12.944083
# Unit test for constructor of class Session
def test_Session():
    import json
    import pytest
    def reset_session():
        s = Session('/Users/chouc/.config/httpie/sessions/localhost/test.json')
        s.load()
        s['headers'] = {}
        s['cookies'] = {}
        s['auth'] = {
            'type': None,
            'username': None,
            'password': None
        }

    test_request_headers = RequestHeadersDict()
    test_request_headers['User-Agent'] = 'HTTPie/0.9.7'
    test_request_headers['cookie'] = 'foo=bar;baz=qux'
    test_request_headers['Cookie'] = 'Baz=qux'
    test_request_headers['Cookie2'] = '$Version="1"; quux=quuz'

# Generated at 2022-06-23 20:09:25.320777
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Makes an example of request_headers dictionary
    request_headers = RequestHeadersDict({
        'Host': 'httpbin.org',
        'User-Agent': 'HTTPie/1.0.0',
        'Accept-Encoding': 'gzip, deflate',
        'Accept': '*/*',
        'Connection': 'keep-alive',
        'cache-control': 'no-cache',
        'cookie': 'test=test',
    })
    # Makes a Session object
    session = Session('test')
    # Calls the update_headers method
    session.update_headers(request_headers)
    # print(session.headers)
    assert session['headers']['Host'] == 'httpbin.org'
    assert 'User-Agent' not in session['headers']

# Generated at 2022-06-23 20:09:35.204144
# Unit test for function get_httpie_session
def test_get_httpie_session():
    s = get_httpie_session(
        config_dir=Path('/config'),
        session_name='foo.bar',
        host='',
        url='http://localhost:8080/foo'
    )
    assert isinstance(s, Session)
    assert 'http://localhost_8080/foo.bar.json' == str(s.path)
    s = get_httpie_session(
        config_dir=Path('/config'),
        session_name='~/test',
        host='',
        url='http://localhost:8080/foo'
    )
    assert '~/test.json' == str(s.path)

# Generated at 2022-06-23 20:09:43.783124
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session = Session(path=Path('./test.json'))
    request_headers = RequestHeadersDict()
    request_headers['Host'] = 'www.pexels.com'
    request_headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:42.0)'
    request_headers['User-Agent'] += ' Gecko/20100101 Firefox/42.0'
    request_headers['User-Agent'] += ' Accept: */*'
    request_headers['Accept-Language'] = 'en-US,en;q=0.5'
    request_headers['Accept-Encoding'] = 'gzip, deflate'
    request_headers['Cache-Control'] = 'max-age=0'

# Generated at 2022-06-23 20:09:48.467168
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/')
    headers = RequestHeadersDict()
    headers['user-agent'] = 'HTTPie'
    headers['Content-Type'] = 'application/json'
    session.update_headers(headers)
    assert (headers.get('user-agent') == None)
    assert (headers.get('Content-Type') == 'application/json')

# Generated at 2022-06-23 20:09:52.860812
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/dev/null') # actually never used
    session['cookies'] = {'a': 'a', 'b': 'b'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': 'b'}


# Generated at 2022-06-23 20:09:56.852252
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
  cookies = {'name1': 'value1', 'name2': 'value2', 'name3': 'value3'}
  cookies_path = Path('./cookies.json')
  session = Session(cookies_path)
  session['cookies'] = cookies
  names2delete = ['name2']
  session.remove_cookies(names2delete)
  # test if the method remove_cookies works properly
  assert 'name2' not in session['cookies']
  # test if the method remove_cookies does not affect other keys in the Session
  assert session['cookies'] == {'name1': 'value1', 'name3': 'value3'}

# Generated at 2022-06-23 20:10:07.651230
# Unit test for constructor of class Session
def test_Session():
    path = '~/.httpie/sessions/localhost/abc.json'
    session = Session(path)
    session.load()
    assert isinstance(session, Session)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }
    session['auth']['type'] = 'basic'
    session['auth']['username'] = 'admin'
    session['auth']['password'] = '123'
    session.save()
    path = '~/.httpie/sessions/localhost/abc.json'
    session = Session(path)
    session.load()
    assert isinstance(session, Session)

# Generated at 2022-06-23 20:10:21.433934
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path('./test'))
    request_headers = RequestHeadersDict({'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 'Cookie':'foo=bar; baz=qux'})
    session.update_headers(request_headers)
    assert('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'==session['headers']['User-Agent'])

# Generated at 2022-06-23 20:10:27.536995
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'test')
    s['cookies'] = {'a': {'value': 'a'}, 'b': {'value': 'b'}, 'c': {'value': 'c'}}
    s.remove_cookies(['b', 'd'])
    assert s['cookies'] == {'a': {'value': 'a'}, 'c': {'value': 'c'}}
    assert isinstance(s['cookies'], dict)

# Generated at 2022-06-23 20:10:31.686905
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_dir= './'
    path = Path(test_dir) / 'test.json'
    session = Session(path)
    session.load()
    session.update_headers({
        'cookie': 'user=test',
        'content-type': 'application/json'
    })
    assert session.headers['content-type'] == 'application/json'
    assert session.cookies['user'].value == 'test'

# Generated at 2022-06-23 20:10:40.707451
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from typing import Optional, Union
    session = Session(Path('./'))
    session.update_headers({
        'User-Agent': 'HTTPie/1.0.3',
        'Content-Type': 'text/plain',
        'Accept': 'application/json',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Cookie': 'auth=token; session_id=HOGEHOGE'
    })
    cookie_jar = session.cookies
    assert cookie_jar._cookies['localhost.local']
    cookie_jar.set_cookie(create_cookie('session_id2', 'FOOFOOFOO'))
    session.cookies = cookie_jar

# Generated at 2022-06-23 20:10:41.625718
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert True

# Generated at 2022-06-23 20:10:50.443314
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("tmp.json")
    request_headers = RequestHeadersDict("tmp.json")
    request_headers["user-agent"] = "HTTPie/0.9.2"
    session.update_headers(request_headers)
    print(session)
    assert session["headers"] == {}
    assert os.path.exists("tmp.json")
    os.remove("tmp.json")

    session = Session("tmp.json")
    request_headers = RequestHeadersDict("tmp.json")
    request_headers["HTTPie-temp-header"] = "HTTPie/0.9.2"
    session.update_headers(request_headers)
    assert session["headers"] == {"HTTPie-temp-header" : "HTTPie/0.9.2"}

# Generated at 2022-06-23 20:10:55.513093
# Unit test for function get_httpie_session
def test_get_httpie_session():
    '''
    Tests if the function get_httpie_session works correctly when it is
    called with a session name that contains a forward slash.
    '''
    path = get_httpie_session(DEFAULT_CONFIG_DIR, 'session/default', None, None)
    assert isinstance(path, Session)

# Generated at 2022-06-23 20:11:00.858830
# Unit test for constructor of class Session
def test_Session():
    file_path='httpie_test.json'
    session=Session(file_path)
    assert(session._path==Path(file_path))
    assert(session['headers']=={})
    assert(session['cookies']=={})
    assert(session['auth']=={'type': None,
            'username': None,
            'password': None})


# Generated at 2022-06-23 20:11:03.146247
# Unit test for constructor of class Session
def test_Session():
    x = Session(path = "~/tmp")
    print(x)
    print(x.get('headers'))
    print(x.get('cookies'))
    print(x.get('auth'))

# Generated at 2022-06-23 20:11:09.773649
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.plugin import AuthPlugin
    from httpie.plugins.basic_auth import BasicAuth
    from httpie.plugins.digest_auth import DigestAuth

    config_dir = DEFAULT_SESSIONS_DIR / 'localhost'
    session_path = config_dir / 'default.json'
    config_dir.mkdir(parents=True, exist_ok=True)
    session = Session(session_path)
    session.update_headers({
        'Authorization': 'Basic YWxpY2U6YWxpY2U=',
        'Cookie': 'sessionid=123; csrftoken=xyz; other=otherval'
    })
    session.save()

    session.load()
    print(session.headers)
    print(session.cookies)

# Generated at 2022-06-23 20:11:13.937103
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    ses = Session('./test.json')
    ses.load()
    ses.update_headers('./test.json')
    ses.save()

# Generated at 2022-06-23 20:11:19.762301
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path('/path/to/session'))
    session['headers'] = {'header1': 'val1', 'header2': 'val2'}
    session['headers'].pop = lambda key: None
    session.update_headers(RequestHeadersDict({'header1': 'val1', 'header2': 'val2', 'header3': 'val3', 'header4': 'val4'}))
    


if __name__ == '__main__':
    test_Session_update_headers()

# Generated at 2022-06-23 20:11:28.845157
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import shutil
    import os
    import json
    import pytest
    from httpie.utils import get_path_to_config_dir
    import requests
    from requests.cookies import RequestsCookieJar

    def create_session(name: str, host: Optional[str], url: str):
        session = get_httpie_session(
            config_dir=get_path_to_config_dir(),
            session_name=name,
            host=host,
            url=url
        )
        session.update_headers({'header1': 'value1'})
        session_cookie = requests.cookies.create_cookie(
            name='session_cookie', value='session_value')
        cookies = RequestsCookieJar()
        cookies.set_cookie(session_cookie)
        session.cookies = cookies
       