

# Generated at 2022-06-23 20:01:25.910580
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sess = get_httpie_session(Path('./'), 'abc', 'http://hahaha.com', 'http://httpbin.org/')
    assert sess is not None
    assert type(sess) is Session

# Generated at 2022-06-23 20:01:36.952385
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'test'
    host = None
    url = 'http://www.baidu.com/'
    session = get_httpie_session(config_dir, session_name, host, url)
    cookie = create_cookie(name='test_cookie', value='test_cookie_value', path='/')
    request_cookies = RequestsCookieJar()
    request_cookies.set_cookie(cookie)

# Generated at 2022-06-23 20:01:40.949776
# Unit test for constructor of class Session
def test_Session():
    session = Session('/path/to/session.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }

# Generated at 2022-06-23 20:01:41.808098
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert type(Session) == type


# Generated at 2022-06-23 20:01:49.142512
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from pathlib import Path
    from httpie.config import DEFAULT_CONFIG_DIR
    import os
    session_name = 'test_session1'
    url = 'https://localhost'
    host = None
    session = get_httpie_session(DEFAULT_CONFIG_DIR, session_name, host, url)
    session.load()
    cookies = session.cookies
    cookie = create_cookie('test_cookie', 'test_value')
    cookies.set_cookie(cookie)
    session.cookies = cookies
    session.save()
    session = get_httpie_session(DEFAULT_CONFIG_DIR, session_name, host, url)
    session.load()
    assert 'test_cookie' in session.cookies._cookies
    session.remove_cookies(['test_cookie'])
   

# Generated at 2022-06-23 20:01:52.843045
# Unit test for constructor of class Session
def test_Session():
    testdata = {
        'headers': {
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate',
            'Host': 'httpbin.org',
            'User-Agent': 'python-requests/2.18.4'
        },
        'cookies': {
        },
        'auth': {
        }
    }
    path = './test_data/session.json'
    session = Session(path)
    assert(session == testdata)

# Generated at 2022-06-23 20:01:57.984966
# Unit test for function get_httpie_session
def test_get_httpie_session():

    session = get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='test',
        host='test.test.test',
        url='test.test.test/test.test'
    )

    print(session)

if __name__ == '__main__':
    test_get_httpie_session()

# Generated at 2022-06-23 20:02:03.583727
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_name1 = 'cookie1'
    cookie_name2 = 'cookie2'

    session = Session('path')
    session['cookies'][cookie_name1] = 'cookie_value'
    session['cookies'][cookie_name2] = 'cookie_value'

    assert len(session['cookies']) == 2

    cookies_to_remove = [cookie_name1, cookie_name2]
    session.remove_cookies(cookies_to_remove)
    assert len(session['cookies']) == 0



# Generated at 2022-06-23 20:02:12.984433
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    sess = Session(os.path.join('tmp', 'test-httpie-sess') + '.json')
    request_headers = RequestHeadersDict({
        'User-Agent': 'HTTPie/0.9.9',
        'Host': 'httpbin.org',
        'Accept': 'application/json',
        'Cookie': 'foo=bar; bar=baz',
        'Content-Type': 'application/json',
        'If-None-Match': '"foo"',
    })
    sess.update_headers(request_headers)

# Generated at 2022-06-23 20:02:18.589527
# Unit test for constructor of class Session
def test_Session():
    path = '/foo/bar'
    session = Session(path)

    # Checking the path
    assert session.path.name == 'bar'
    assert session.path.suffix == '.json'
    assert session.path.parent.name == 'bar'

    # Checking headers
    assert session['headers'] == {}
    assert len(session['headers']) == 0

    # Checking cookies
    assert session['cookies'] == {}
    assert len(session['cookies']) == 0

    # Checking auth
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    assert len(session['auth']) == 3


# Generated at 2022-06-23 20:02:22.374645
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='/dev/null')
    session.update_headers(request_headers={'Some-Header': 'value'})
    assert session.headers == {'Some-Header': 'value'}



# Generated at 2022-06-23 20:02:25.720105
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_sessions/my_session.json')
    session['cookies']['session_id'] = {'value': 'test_cookie_value'}
    session['cookies']['session_id2'] = {'value': 'test_cookie_value2'}
    session.remove_cookies(['session_id'])
    assert 'session_id' not in session.get('cookies')
    assert 'session_id2' in session.get('cookies')

# Generated at 2022-06-23 20:02:30.855513
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Assume session_name has no path separator, such as ':separator:'
    get_httpie_session(Path('./'), 'session_name', 'host', 'url')
    # Assume session_name has path separator, such as ':separator:'
    get_httpie_session(Path('./'), ':separator:', 'host', 'url')

# Generated at 2022-06-23 20:02:32.112437
# Unit test for constructor of class Session
def test_Session():
    s = Session('./tests/session_test.json')
    s.update_headers({'Client': 'HTTPie', 'Test': 'OK'})
    s.save()
    assert s.load() == s

# Generated at 2022-06-23 20:02:36.183236
# Unit test for function get_httpie_session
def test_get_httpie_session():
    #THIS TEST IS NOT WORKING
    config_dir = DEFAULT_CONFIG_DIR

    #session_name = "test1"
    #host = "google.com"
    #url = "google.com"

    session = get_httpie_session(config_dir, "test1", None, None)
    print(session)
    #assert session is not None

# Generated at 2022-06-23 20:02:41.671223
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path="mock")
    request_headers = RequestHeadersDict({'content-type': 'application/json'})
    session.update_headers(request_headers)
    assert request_headers == RequestHeadersDict({'content-type': 'application/json'})
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-23 20:02:49.119110
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.core import Context
    from httpie.core import main as httpie_core_main
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.plugins import FormatterPluginManager

    args = []

    class TestContext(Context):
        def __init__(self):
            self.args = []
            self.config_dir = DEFAULT_SESSIONS_DIR
            self.config = {}
            self.stdout = StringIO()
            self.stderr = StringIO()
            self.stdin = StringIO()
            self.stdin_isatty = False
            self.formatter = FormatterPluginManager.get(
                'json'
            )()  # type: ignore

    context = TestContext()
    context.args = []


# Generated at 2022-06-23 20:02:58.551163
# Unit test for function get_httpie_session
def test_get_httpie_session():
    class ConfigDirs:
        def __init__(self, path):
            self.config_dir = path

    class Env:
        def __init__(self, config_dirs, httpie_dir=None, httpie_cfg_dir=None):
            self.config_dirs = config_dirs
            self.httpie_dir = httpie_dir
            self.httpie_cfg_dir = httpie_cfg_dir

        @classmethod
        def load(cls, path):
            path = path or Path()
            return cls(ConfigDirs(path))

    config_dir = Path('/tmp/httpie-test/test')
    env = Env.load(config_dir)

# Generated at 2022-06-23 20:03:07.735280
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test.json")
    test_headers = {'test_header': 'test_value', 'test_header2': 'test_value2', 'test_header3': 'test_value3'}
    print("test_headers before:", test_headers)
    session.update_headers(test_headers)
    print("test_headers after:", test_headers)
    for name, value in test_headers.items():
        if name not in session['headers']: continue
        if value != session['headers'][name]:
            print("test_Session_update_headers: failed")
            return
    print("test_Session_update_headers: passed")


# Generated at 2022-06-23 20:03:11.375149
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_path = Path('/home/vasilis/Documents/httpie')
    session_path = Session(config_path)
    assert session_path == Path('/home/vasilis/Documents/httpie/sessions')

# Generated at 2022-06-23 20:03:13.578453
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {"a": "1", "b": "2"}
    assert len(session['cookies']) == 2
    session.remove_cookies(["a"])
    assert len(session['cookies']) == 1



# Generated at 2022-06-23 20:03:18.137068
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session')
    session.update_headers({'Cookie': 'foo=bar; bar=baz'})
    session.remove_cookies(['foo'])
    assert session['cookies'] == {'bar': {'value': 'baz'}}

# Generated at 2022-06-23 20:03:28.158147
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from tempfile import TemporaryDirectory
    from shutil import copyfileobj
    from httpie.plugins import builtin
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.input import KeyValueArg
    import json

    tmpdir = TemporaryDirectory()
    config_dir = Path(tmpdir.name)
    session = get_httpie_session(
        config_dir,
        session_name='Facebook',
        host='facebook.com',
        url='http://facebook.com'
    )


# Generated at 2022-06-23 20:03:36.716699
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # assert_raises(AssertionError, s.update_headers,{} )
    # assert_raises(AssertionError, s.update_headers, {'ok': 'ok', 'ok2': None })
    # assert_raises(AssertionError, s.update_headers, {'ok': 'ok', 'ok2': 'ok2'})

    from httpie.cli.dicts import RequestHeadersDict

    s = Session("test_Session_update_headers")
    # assert_raises(AssertionError, s.update_headers, {})
    # assert_raises(AssertionError, s.update_headers, {'ok': 'ok', 'ok2': None })
    # assert_raises(AssertionError, s.update_headers, {'ok': 'ok', 'ok

# Generated at 2022-06-23 20:03:42.427751
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('~/.httpie').expanduser()
    session_name = 'http://example.com'
    host = None
    url = 'http://example.com'

    session = get_httpie_session(config_dir, session_name, host, url)
    assert session
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-23 20:03:46.473409
# Unit test for constructor of class Session
def test_Session():
    conf_dict = {
        "username": "admin",
        "password": "1234"
    }
    new_session = Session(conf_dict)
    assert new_session.username == "admin"
    assert new_session.password == "1234"

    # Constructor of parents class is undefined
    # conf_dict = {}
    # new_session = Session(conf_dict)


# Generated at 2022-06-23 20:03:57.228489
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Use case-1:
    # Check if the session file is created
    # and the configuration is loaded.
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()

    # Create a session file
    session = get_httpie_session(
        session_name="test_session", host="www.test.com",
        url="https://www.test.com", config_dir=Path(temp_dir.name))
    session.save()

    # Check if the session file was created
    assert os.path.exists(session.path)
    assert len(session.header) > 0

    # Use case-2:
    # Check if the session file is not created
    # when the configuration is not loaded.
    temp_dir = tempfile.TemporaryDirectory()

    # Create a session file
    session = get

# Generated at 2022-06-23 20:04:01.062129
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('./test')
    session_name = 'test'
    host = 'test_host'
    url = 'https://www.google.com/'
    get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-23 20:04:05.146253
# Unit test for constructor of class Session
def test_Session():
    session = Session('.')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-23 20:04:15.146624
# Unit test for method update_headers of class Session

# Generated at 2022-06-23 20:04:21.459797
# Unit test for constructor of class Session
def test_Session():
    temp_dir = Path.cwd() / 'tests' / 'temp'
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir, exist_ok=True)
    path = temp_dir / 'session.json'
    session = Session(path=path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }

# Generated at 2022-06-23 20:04:23.898112
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    c_session = Session("dummy")
    c_session.cookies = {"name":"value"}
    c_session.remove_cookies("name")
    assert c_session.cookies == {}

# Generated at 2022-06-23 20:04:34.931031
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_name_1 = 'testcookie_name_1'
    cookie_name_2 = 'testcookie_name_2'
    cookie_value = 'testcookie_value'

    # Create testsession
    session = Session('test.json')
    jar = RequestsCookieJar()
    jar.set_cookie(create_cookie(cookie_name_1, cookie_value))
    jar.set_cookie(create_cookie(cookie_name_2, cookie_value))
    session.cookies = jar
    session['cookies'][cookie_name_1] = {'value': cookie_value}
    session['cookies'][cookie_name_2] = {'value': cookie_value}

    # Actual test
    session.remove_cookies([cookie_name_1])

# Generated at 2022-06-23 20:04:43.365482
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """
    Tests for the get_httpie_session() function.

    """
    # TODO: Use temp dir.
    path = Path('/tmp/test_get_httpie_session')
    if path.is_dir():
        path.rmdir()

    # Can't use `/' as separator.
    try:
        get_httpie_session(
            path.parent,
            session_name=path.name,
            host='test.org',
            url='http://test.org'
        )
    except Exception as e:
        assert isinstance(e, ValueError)
        assert 'slash' in e.args[0]

    # Path is relative to the current working directory

# Generated at 2022-06-23 20:04:51.063864
# Unit test for constructor of class Session
def test_Session():
    
    p = "/home/httpie/httpie.json"
    s = Session(path=p)
    assert s.path == Path(p)
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] ==  {
        'type': None,
        'username': None,
        'password': None
    }
    assert s.helpurl == 'https://httpie.org/doc#sessions' 
    assert s.about == 'HTTPie session file'


# Generated at 2022-06-23 20:04:56.995988
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/some/path')
    session['cookies'] = {'foo': 'bar', 'baz': 'qux'}
    session.remove_cookies(['baz'])
    assert session['cookies'] == {'foo': 'bar'}
    # The following line should not change the session cookie
    session.remove_cookies(['does-not-exist'])
    assert session['cookies'] == {'foo': 'bar'}



# Generated at 2022-06-23 20:05:06.051019
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test-session')
    test_headers = {
        'if-modified-since': 'Wed, 24 Jul 2019 19:48:06 GMT',
        'if-none-match': '"5d3825-1828d-596f56e2fd1c0"',
        'user-agent': 'HTTPie/1.0.2',
        'cookie': 'name=chocolate; expires=Fri, 31 Jan 2020 22:02:35 GMT; Max-Age=2000000; path=/; HttpOnly'
    }
    session.update_headers(test_headers)

# Generated at 2022-06-23 20:05:08.726253
# Unit test for function get_httpie_session
def test_get_httpie_session():
    s = get_httpie_session(Path("."), "mySession", "host", "http://host")
    assert s.items()



# Generated at 2022-06-23 20:05:11.569494
# Unit test for constructor of class Session
def test_Session():
    session_name = 'session_name'
    try:
        session = get_httpie_session(DEFAULT_CONFIG_DIR, session_name, None, None)
    except Exception:
        print("Failed to create session.")
        return False
    return True


# Generated at 2022-06-23 20:05:20.218373
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # We have to have a session with cookies to test method remove_cookie.
    # This is a temporary solution. A better solution is to, maybe,
    # extract the cookies dictionary from the '__dict__' key of the session
    # and use it for testing purposes.
    session = get_httpie_session(
        config_dir="/home/user/.config",
        session_name="session_name",
        host=None,
        url="https://httpbin.org/headers"
    )
    session.cookies = {"cookie1": {"name": "cookie1", "value": "cheese"}, "cookie2": {"name": "cookie2", "value": "chocolate"}}
    session.remove_cookies(["cookie1", "cookie3"])

# Generated at 2022-06-23 20:05:24.770699
# Unit test for constructor of class Session
def test_Session():
    session_name = 'sivan'
    host = 'www.sivan.com'
    url = 'https://www.sivan.com'
    config_dir = Path('/Users/sivan/.httpie')
    s = get_httpie_session(config_dir, session_name, host, url)
    # print(s.path)
    # print(s.headers)
    # print(s.cookies)
    # print(s.auth)
    pass



# Generated at 2022-06-23 20:05:33.626640
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pwd = os.path.dirname(os.path.realpath(__file__))
    os.environ['HTTPIE_CONFIG_DIR'] = pwd
    os.environ['HTTPIE_CONFIG_FILE'] = ''

    assert VALID_SESSION_NAME_PATTERN.match('a')
    assert VALID_SESSION_NAME_PATTERN.match('a.b')
    assert not VALID_SESSION_NAME_PATTERN.match('a.b/c')
    assert not VALID_SESSION_NAME_PATTERN.match('/a.b')
    assert not VALID_SESSION_NAME_PATTERN.match('a.b?')
    assert not VALID_SESSION_NAME_PATTERN.match('a.b#')
    assert get_httpie_session

# Generated at 2022-06-23 20:05:38.419353
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import DEFAULT_CONFIG_DIR

    session = get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='ceshiname',
        host='ceshihost',
        url='ceshiurl',
    )
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-23 20:05:41.907995
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = SESSIONS_DIR_NAME
    url = 'http://www.google.com'
    host = ''
    assert get_httpie_session(config_dir,session_name,host,url)

# Generated at 2022-06-23 20:05:48.680881
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        config_dir = Path('./test_data'),
        session_name = 'httpbin',
        host = '',
        url = 'https://httpbin.org/get'
    )
    assert session['cookies'] == {
        'foo': {'value': 'bar'},
        'baz': {'value': 'qux'},
    }
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    assert session['headers'] == {
        'Accept': 'application/json',
        'Connection': 'keep-alive',
    }

# Generated at 2022-06-23 20:05:59.603183
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        config_dir=Path(os.path.dirname(__file__)),
        session_name='test_filename',
        host=None,
        url="https://httpie.org",
    )
    if os.path.sep in session_name:
        path = os.path.expanduser(session_name)
    else:
        hostname = host or urlsplit(url).netloc.split('@')[-1]
        if not hostname:
            # HACK/FIXME: httpie-unixsocket's URLs have no hostname.
            hostname = 'localhost'

        # host:port => host_port
        hostname = hostname.replace(':', '_')

# Generated at 2022-06-23 20:06:08.561850
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(path=None)
    request_headers = RequestHeadersDict({
        'HOST': 'example.com',
        'COOKIE': 'a=b',
        'CONTENT-TYPE': 'application/json'
    })

    expected_output = {'Host': 'example.com'}
    s.update_headers(request_headers)
    assert s['headers'] == expected_output, 'headers not updated correctly'
    assert s['cookies'] == \
        {'a': {'value': 'b'}}, 'cookies not updated correctly'



# Generated at 2022-06-23 20:06:16.414663
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from requests.cookies import RequestsCookieJar
    path = Path('/home/usr/.config/httpie/sessions/localhost/default.json')
    session = Session(path)
    assert isinstance(session, BaseConfigDict)
    assert isinstance(session, Session)
    assert session.path == path
    assert session.headers == RequestHeadersDict(session['headers'])
    assert session.cookies == RequestsCookieJar()
    assert session.auth == None


# Generated at 2022-06-23 20:06:22.933510
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path = "test.json")
    session.update_headers(request_headers = {"Cookie": "name:123; name2:456"})
    assert "name" in session['cookies']
    assert "name2" in session['cookies']
    session.remove_cookies(names = ["name"])
    assert "name" not in session['cookies']
    assert "name2" in session['cookies']

# Generated at 2022-06-23 20:06:32.021104
# Unit test for constructor of class Session
def test_Session():
    path = 'C:\\Users\\Administrator\\AppData\\Roaming\\.httpie\\sessions\\www.baidu.com\\test_Session.json'
    Session(path)
    assert os.path.exists(path)

    # test update_headers
    # RequestHeadersDict(self['headers'])
    # dict(headers)

# Generated at 2022-06-23 20:06:41.254411
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    原先的信息存在不会替换，其他信息会加入headers
    """
    url = 'http://www.github.com/wangxuangege/httpie'
    headers_dict = {
        # 'User-Agent': 'HTTPie/2.0.0',
        'User-Agent': 'HTTPie/1.0.0',
        'cookie': 'a=b;c=d',
        'Accept': 'application/json',
        'If-Match': 'QWERTYUIOP'
    }

    session = Session('')
    session.update_headers(RequestHeadersDict(headers_dict))
    assert session.headers == {'Accept': 'application/json'}


# Generated at 2022-06-23 20:06:41.841287
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-23 20:06:46.348236
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('test_session.json'))
    request_headers = RequestHeadersDict({"hello":"world"})
    session.update_headers(request_headers)
    assert session["headers"]["hello"] == "world"

# Generated at 2022-06-23 20:06:49.779365
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.context import Environment
    env = Environment(config_dir='./')
    get_httpie_session(None, None, 'http://example.com', 'http://example.com')

# Generated at 2022-06-23 20:06:56.649417
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    sess = Session(path="/tmp/sess.json")
    sess.update_headers({"Cookie":"username=admin; password=123; path=/", \
                         'User-agent':'HTTPie/0.9.8',\
                         'If-None-Match': "W/8675309"})
    assert sess['headers'] == {'User-agent': 'HTTPie/0.9.8'}
    assert sess['cookies'] == {'username': {'value': 'admin'},\
                               'password': {'value': '123'}}

# Generated at 2022-06-23 20:07:01.425360
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = 'config_dir'
    session_name = 'session_name'
    host = 'host'
    url = 'url'
    try:
        assert \
        get_httpie_session(config_dir, session_name, host, url) ==\
        Session(config_dir + session_name + host + url)
    except:
        return 1
    else:
        return 0


# Generated at 2022-06-23 20:07:12.728411
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test_Session_update_headers")
    session.update_headers({"Host": "https://httpie.org/", "Content-type": "text/html"})
    # testing that the cookie was stored
    assert "cookie" in session["headers"].keys()
    session.update_headers({"Host": "https://www.example.com/", "Cookie": "cookie1=value1; cookie2=value2; cookie3=value3"})
    # testing that the cookie was stored
    assert "Cookie" in session["headers"].keys()
    assert "Host" not in session["headers"].keys()
    session.update_headers({"Cookie": "cookie2=value2"})
    assert "cookie2" not in session["cookies"].keys()

# Generated at 2022-06-23 20:07:21.793818
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Tests for the method update_headers of class Session
    """
    # the headers that will be stored in the session
    session_headers = {'header1': 'value1', 'header2': 'value2', 'header3': 'value3'}
    # the headers that won't be stored in the session
    ignored_headers = {'Content-Type': 'value1', 'If-Modified-Since': 'value2', 'If-Unmodified-Since': 'value3'}

    session = Session('session_file_path')
    headers = []
    headers = list(headers)
    for key, value in session_headers.items():
        headers += [(key, value)]

    for key, value in ignored_headers.items():
        headers += [(key, value)]

    request_headers = RequestHeadersDict(headers)


# Generated at 2022-06-23 20:07:31.851206
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Given:
        - A Session object with headers A=a, B=b, C=c
        - A request_headers D=d, A=D
    When:
        - update_headers is called with request_headers
    Then:
        - Session object has headers D=d, B=b, C=c
    """
    session = Session('hoge')
    session['headers'] = {'A': 'a', 'B': 'b', 'C': 'c'}
    request_headers = RequestHeadersDict({'D': 'd', 'A': 'A'})

    session.update_headers(request_headers)

    assert session['headers'] == {'D': 'd', 'B': 'b', 'C': 'c'}



# Generated at 2022-06-23 20:07:43.236202
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Stub Session.__init__(), because its arguments are private
    session = Session('path')
    # Stub self.headers, because it is a property
    session.__dict__['headers'] = {}
    # Stub self.cookies, because it is a property
    session.__dict__['cookies'] = {}

    # Test 1: request_headers is empty
    request_headers = {}
    assert session.update_headers(request_headers) == None
    assert {} == session.headers
    assert {} == session.cookies

    # Test 2: request_headers is not empty

    # request_headers contains headers that will not be saved in the session
    request_headers = {
        'If-Modified-Since': 'Sun, 06 Nov 1994 08:49:37 GMT'
    }

    # request_headers contains headers that will be saved in the

# Generated at 2022-06-23 20:07:44.368977
# Unit test for constructor of class Session
def test_Session():
    s = Session('~a/b')
    assert s.path == Path('~a/b').expanduser()

# Generated at 2022-06-23 20:07:52.266372
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir = DEFAULT_CONFIG_DIR
    test_session_name = 'test_session'
    test_url = 'https://www.baidu.com/'
    session = get_httpie_session(config_dir, test_session_name, None, test_url)

    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie('c1', 'v1'))
    session.cookies.set_cookie(create_cookie('c2', 'v2'))
    session.cookies.set_cookie(create_cookie('c3', 'v3'))
    session.cookies.set_cookie(create_cookie('c4', 'v4'))

    session.save()

    session.remove_cookies(['c1', 'c3'])

# Generated at 2022-06-23 20:07:58.443870
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('nonexistent')
    session['cookies']['a'] = {'value': 'v1'}
    session['cookies']['b'] = {'value': 'v2'}
    session['cookies']['c'] = {'value': 'v3'}
    session.remove_cookies(['b', 'd'])
    assert 'b' not in session['cookies']
    assert 'd' not in session['cookies']
    assert 'a' in session['cookies']
    assert 'c' in session['cookies']


# Generated at 2022-06-23 20:08:05.822120
# Unit test for constructor of class Session
def test_Session():
    url = "https://www.google.com"
    url_split = urlsplit(url)
    # print(url_split)
    print(url_split.netloc)
    # print(url_split.path)
    # print(url_split.query)
    # print(url_split.fragment)
    # print(url_split.username)
    # print(url_split.password)
    # print(url_split.hostname)
    # print(url_split.port)
    print(url_split.netloc.split('@')[-1])
    # print(url_split.path.split('@')[-1])
    # print(url_split.query.split('@')[-1])
    # print(url_split.fragment.split('@')

# Generated at 2022-06-23 20:08:07.504841
# Unit test for constructor of class Session
def test_Session():
    s = Session(Path(r'C:\Users\user\.httpie\sessions\localhost\test.json'))

# Generated at 2022-06-23 20:08:13.629006
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path(''))
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie('test', 'value'))
    assert 'test' in session.cookies
    session.remove_cookies(['test'])
    assert 'test' not in session.cookies

# Generated at 2022-06-23 20:08:24.517854
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """
    Test function get_httpie_session
    :return:
    """
    from httpie.cli.dicts import RequestHeadersDict
    config_dir = Path(DEFAULT_SESSIONS_DIR)
    session_name = max(config_dir.glob('*.json'))
    host = ''
    url = 'https://m.weibo.cn/api/container/getIndex?containerid=2304135768176550_-_WEIBO_SECOND_PROFILE_WEIBO&luicode=10000011&lfid=2304135768176550'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session is not None
    assert session.headers == {}

# Generated at 2022-06-23 20:08:29.354289
# Unit test for constructor of class Session
def test_Session():
    test_data = Session(path='path')
    assert test_data
    assert test_data.path == 'path'
    assert test_data['headers'] == {}
    assert test_data['cookies'] == {}
    assert test_data['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-23 20:08:38.167714
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path=Path('/some/path'))
    s.load()
    s['cookies'] = {'a': {'value': 'b'}, 'laval': {'value': 'valb'}, 'aval': {'value': 'vala'}}
    to_remove = ['aval', 'c']
    s.remove_cookies(to_remove)
    assert s['cookies'] == {'a': {'value': 'b'}, 'laval': {'value': 'valb'}}

# Generated at 2022-06-23 20:08:48.128363
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_Session_update_headers.json')
    session.update_headers({'User-Agent': 'test client'})
    assert session.headers['User-Agent'] == 'test client'
    session.update_headers({'Content-Type': 'text/json'})
    assert 'Content-Type' not in session.headers
    session.update_headers({'Cookie': 'sid=8a8'})
    assert session.cookies is not None and len(session.cookies) == 1
    session.update_headers({'If-None-Match': '"0e"'})
    assert 'If-None-Match' not in session.headers


# Generated at 2022-06-23 20:08:52.496104
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path('./httpie/sessions/session.json'))
    session.update_headers(RequestHeadersDict({
        'Cookie': 'a=1',
        'Content-Type': 'application/json'
    }))
    
    assert session['headers'] == {}
    assert session['cookies'] == {'a': {'value': '1'}}

# Generated at 2022-06-23 20:09:02.512595
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """
    Test that get_httpie_session correctly generate the session file.
    """
    # Setup
    import tempfile
    config_dir = Path(tempfile.gettempdir())
    session_name = "test"
    host = "host.com"
    url = "http://host.com"

    # Test
    session = get_httpie_session(config_dir, session_name, host, url)
    filesystem_session = Session(config_dir / SESSIONS_DIR_NAME / "host_com" / "test.json")
    filesystem_session.load()

    # Assert
    assert session == filesystem_session

# Generated at 2022-06-23 20:09:11.242394
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session.json')
    assert len(session['cookies']) == 0
    session.cookies = RequestsCookieJar()
    assert len(session['cookies']) == 0
    cookie1 = create_cookie('cookie1', 'value1', path='/')
    cookie2 = create_cookie('cookie2', 'value2', path='/')
    session.cookies.set_cookie(cookie1)
    session.cookies.set_cookie(cookie2)
    assert len(session['cookies']) == 2
    session.remove_cookies(['cookie2'])
    assert len(session['cookies']) == 1

# Generated at 2022-06-23 20:09:14.366188
# Unit test for constructor of class Session
def test_Session():
    path = '~/.httpie/sessions/test.json'
    session = Session(path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}
    assert session.path == os.path.expanduser(path)

# Generated at 2022-06-23 20:09:18.646722
# Unit test for constructor of class Session
def test_Session():
    print('\nTest: constructor of class Session')
    s = Session('/Users/wq/.config/httpie/sessions/localhost/test.json')
    print('s = ', s)

# test_Session()


# Generated at 2022-06-23 20:09:27.761370
# Unit test for function get_httpie_session
def test_get_httpie_session():
    host_dirname = '127_0_0_1'
    directory = DEFAULT_SESSIONS_DIR / 'www.example.com' / host_dirname
    os.makedirs(directory)

# Generated at 2022-06-23 20:09:34.227331
# Unit test for constructor of class Session
def test_Session():
    path = 'C:\\Users\\vlada\\AppData\\Roaming\\httpie\\sessions\\vlada_google.com\\google.json'
    session = Session(path)
    assert session is not None
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-23 20:09:36.856660
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test")
    session['cookies'] = {"test": "test"}
    session.remove_cookies(["test"])
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:09:39.829065
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("my/path")
    s['cookies'] = {'x': 'y'}
    s.remove_cookies(['x'])
    assert len(s['cookies']) == 0

# Generated at 2022-06-23 20:09:44.426947
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    s['cookies'] = {
        'a':{'value':'1'},
        'b':{'value':'2'},
        'c':{'value':'3'}
    }
    assert s.cookies
    s.remove_cookies(['a'])
    assert not s.cookies


# Generated at 2022-06-23 20:09:50.318287
# Unit test for constructor of class Session
def test_Session():
    path = Path('test_Session.json')
    s = Session(path)
    assert type(s) == Session
    assert type(s.path) == Path
    assert s.path == path
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}



# Generated at 2022-06-23 20:09:58.364867
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.plugins.builtin import UnixSocketAuthPlugin
    config_dir = DEFAULT_SESSIONS_DIR
    session_name = 'test'
    host = 'host'
    url = 'http://host:80/'
    session = get_httpie_session(config_dir, session_name, host, url)
    path = config_dir / SESSIONS_DIR_NAME / f'{host}' / f'{session_name}.json'
    assert session.path == path
    assert session.auth == {
        'type': None,
        'username': None,
        'password': None,
    }
    assert session.cookies == {}
    host = 'host'
    url = 'http://host/'

# Generated at 2022-06-23 20:10:03.631469
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_name = "session"
    config_dir = Path(".")
    url = "http://localhost:5000/"
    session = get_httpie_session(config_dir, session_name, None, url)
    session.remove_cookies(["test"])

# Generated at 2022-06-23 20:10:06.929252
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path('/test.json'))
    request_headers = {'name': 'value'}
    session.update_headers(request_headers)
    assert session.headers == request_headers


# Generated at 2022-06-23 20:10:13.624577
# Unit test for constructor of class Session
def test_Session():
    path = "/Users/yuegeng/PycharmProjects/httpie-session/httpie/config/httpie/sessions/localhost/test1.json"
    session = Session(path)
    session.update_headers({"hello":"world"})

if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-23 20:10:24.876965
# Unit test for constructor of class Session
def test_Session():
    # test session_name that means local path
    local_path = '~/test.json'
    session = Session(local_path)
    session_path = os.path.expanduser(local_path)
    assert session.path == session_path

    # test session_name that means session name
    url = 'http://demo.org/api/v1/test/test'
    host = urlsplit(url).netloc.split('@')[-1]
    session_name = 'test'
    session = Session(session_name)
    session_path = os.path.expanduser(f'~/.httpie/sessions/{host}/{session_name}.json')
    assert session.path == session_path

    # test session_name that means session name in config dir

# Generated at 2022-06-23 20:10:28.591626
# Unit test for constructor of class Session
def test_Session():
    a = Session('http://www.baidu.com')
    if not isinstance(a, BaseConfigDict):
        print('Type error!')
    print(a)

# Generated at 2022-06-23 20:10:29.725181
# Unit test for constructor of class Session
def test_Session():
    assert Session.__init__()

# Generated at 2022-06-23 20:10:31.316194
# Unit test for constructor of class Session
def test_Session():
    Session("./session")
    return True


# Generated at 2022-06-23 20:10:34.706343
# Unit test for constructor of class Session
def test_Session():
    session = Session("/home/mohaimin/.httpie/sessions/example.com.json")
    assert session['headers'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-23 20:10:40.364822
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test2')
    session.load()
    assert ('cookies' in session)
    session.remove_cookies(['foo',])
    session.save()
    assert('foo' not in session['cookies'])
    session['cookies'] = {}
    session.save()
    assert('cookies' in session)



# Generated at 2022-06-23 20:10:43.183345
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        config_dir='~',
        session_name='session_name',
        host='host',
        url='url'
    )
    session.load()
    assert isinstance(session, Session)

# Generated at 2022-06-23 20:10:48.045155
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/foo.json')
    session.update_headers(
        RequestHeadersDict([('Content-Type', 'application/json')])
    )
    assert session['headers'] is None
    assert session['cookies'] == {}
    assert session['auth']['type'] == None
    assert session['auth']['username'] == None
    assert session['auth']['password'] == None

# Generated at 2022-06-23 20:10:55.500343
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = os.path.expanduser('~/.httpie')
    session_name = 'test'
    host = 'https://www.google.com'
    url = 'https://www.google.com'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert os.path.sep in session_name
    assert path.exists(session_name)
    assert 'test' in session_name

# Generated at 2022-06-23 20:10:56.119140
# Unit test for constructor of class Session
def test_Session():
    assert Session

# Generated at 2022-06-23 20:11:06.793838
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    This function tests if the update_headers function of Session correctly updates the headers field.

    :return: None
    """
    session = Session('session1')
    assert session['headers'] == {}

    new_headers = {'a': 'b', 'c': 'd'}
    session.update_headers(new_headers)
    assert session['headers'] == new_headers

    new_headers = {'a': 'b', 'c': 'd', 'e': None}
    session.update_headers(new_headers)
    assert session['headers'] == {'a': 'b', 'c': 'd'}

    new_headers = {'a': (1, 2, 3), 'c': 'd'}
    session.update_headers(new_headers)

# Generated at 2022-06-23 20:11:11.337929
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s=Session('/blabla')
    s({'cookies': dict(x=1, y=2, z=3)})
    names=['x', 'y', 'blabla']
    s.remove_cookies(names)
    assert s['cookies']==dict(z=3)

# Generated at 2022-06-23 20:11:16.396233
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()
    plugin_manager.load_builtin_plugins()
    s = get_httpie_session(config_dir=Path('~/.httpie'), session_name="s", host=None, url="http://s.s/s.s")
    assert isinstance(s, Session)

# Generated at 2022-06-23 20:11:24.584967
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from tests.utils import TEST_SESSIONS_DIR
    app_name = 'http'
    url = 'https://www.google.com/'
    session_name = 'test_get_httpie_session'
    host = 'www.google.com'
    assert get_httpie_session(
        TEST_SESSIONS_DIR, session_name, host, url) != None
    assert get_httpie_session(
        TEST_SESSIONS_DIR, session_name, host, url) != None