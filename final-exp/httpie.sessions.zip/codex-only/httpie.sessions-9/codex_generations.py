

# Generated at 2022-06-23 20:01:36.914996
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # When a Session object is instantiated with a path, the path is
    # saved in abs_config_file attribute as a Path object.
    s = Session("config")
    # By default, 'headers' key is stored with an empty dictionary as value.
    s.headers == {}
    # By default, 'cookies' key is stored with an empty dictionary as value.
    s.cookies == {}
    # By default, 'auth' key is stored with a dictionary which has three
    # keys: 'type', 'username', 'password' and has None as value.
    s.auth == {'type': None, 'username': None, 'password': None}
    # When 'remove_cookies' is called with no argument, 'cookies' key is
    # set to empty dictionary.
    s.remove_cookies([])
    s.cook

# Generated at 2022-06-23 20:01:43.121466
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # test case: update_headers method updates session headers with request ones
    # while ignoring header prefixes
    request_headers = {"Content-Type": "application/json",
                        "Content-Length": "17",
                        "Existing-Header": "value",
                        "New-Header": "value"}
    sess = Session(path = "C:/httpie/sessions")
    sess.update_headers(request_headers)

    assert sess.headers == {"Existing-Header": "value", "New-Header": "value"}

# Generated at 2022-06-23 20:01:55.546113
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/tmp/httpie')
    session_name = 'test1'
    host = '127.0.0.1'
    url = 'http://127.0.0.1:8989/test1'
    if not os.path.exists(config_dir / SESSIONS_DIR_NAME / host):
        os.makedirs(config_dir / SESSIONS_DIR_NAME / host)
    f = open(config_dir / SESSIONS_DIR_NAME / host / f'{session_name}.json','w')
    f.write('{"x":"y"}')
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session['x'] == 'y'
    session.load()

# Generated at 2022-06-23 20:02:03.065496
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test')
    session['headers'] = {}
    session['cookies'] = {}
    session['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/1.2.0'})
    assert session.headers == {}
    session.update_headers({'Cookie': 'id=10;'})
    assert session.cookies.get_dict() == {'id': '10'}

# Generated at 2022-06-23 20:02:07.615387
# Unit test for constructor of class Session
def test_Session():
    session_name = "test_session_name"
    host = "localhost:8080"
    url = "http://localhost:8080"
    config_dir = Path("./test_dir")
    session = get_httpie_session(config_dir,session_name,host,url)
    assert session.path==config_dir/SESSIONS_DIR_NAME/host

# Generated at 2022-06-23 20:02:15.978804
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('test.json')
    headers = {'abc': 'def', 'ghi': 'jkl', 'MNO': 'pqr', 'stu': 'vw-xyz'}
    s.update_headers(headers)

    # Make sure that update_headers does not overwrite the headers explicitly
    # set by user.
    assert s['headers'] == headers

    # Check that the headers with prefix 'content-' and 'if-' are not stored in
    # session.
    headers = {'content-type': 'text', 'if-modified-since': 'today',
               'abc': 'def'}
    s.update_headers(headers)


# Generated at 2022-06-23 20:02:19.002978
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=None)
    request_headers = {'header1': 'value1','header2': 'value2','header3': 'value3','header4': 'value4','header5': 'value5',}
    session.update_headers(request_headers)
    print(session)

# Generated at 2022-06-23 20:02:26.368552
# Unit test for constructor of class Session
def test_Session():
    if not os.path.exists(DEFAULT_SESSIONS_DIR):
        os.mkdir(DEFAULT_SESSIONS_DIR)
    path = Path(DEFAULT_SESSIONS_DIR) / 'sess.json'
    with open(path, 'w') as file:
        file.write('{}')

    session = Session(path)
    assert session.headers == {}
    assert session.cookies == {}
    assert session.auth == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-23 20:02:27.568219
# Unit test for function get_httpie_session
def test_get_httpie_session():
    to_test = get_httpie_session(DEFAULT_CONFIG_DIR, "test_session", "stdin", "http://localhost")
    assert to_test.__class__ == Session


# Generated at 2022-06-23 20:02:30.112326
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session('arg', 'path', 'arg', 'url')
    assert isinstance(session, Session)

# Generated at 2022-06-23 20:02:33.457979
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('sessions/test')
    s['cookies'] = {'test': {'value': 'test'}, 'other': {'value': 'other'}}
    s.remove_cookies(['test'])
    assert len(s['cookies']) == 1

# Generated at 2022-06-23 20:02:41.927384
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session = Session("/tmp/httpie_session")
    session['headers'] = {'Host': 'www.example.com',
                          'Content-Type': 'application/json',
                          'If-Match': '"123"',
                          'Range': 'bytes=10-'}
    request_headers = RequestHeadersDict(
        {'Host': 'www.example.com',
         'Content-Type': 'application/json',
         'If-Match': '"123"',
         'Range': 'bytes=10-',
         'user-agent': 'HTTPie/1.0.3',
         'Cookie': 'key=value'
         }
    )

    session.update_headers(request_headers)


# Generated at 2022-06-23 20:02:47.141203
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(
        DEFAULT_CONFIG_DIR, 'sesh', 'localhost', 'http://localhost')

    assert get_httpie_session(
        DEFAULT_CONFIG_DIR, 'sesh/../sesh', 'localhost', 'http://localhost')

    assert get_httpie_session(
        DEFAULT_CONFIG_DIR, 'sesh', '192.168.1.1:8080', 'http://192.168.1.1:8080')


# Generated at 2022-06-23 20:02:55.048803
# Unit test for constructor of class Session
def test_Session():
    try:
        # Test session_name which is not a valid file name
        config_dir = DEFAULT_CONFIG_DIR
        session_name = 'session'
        host = 'host'
        url = 'http://localhost:8080/test'
        get_httpie_session(config_dir, session_name, host, url)
    except FileNotFoundError:
        print('Test succeeded in Session.__init__()!')
    except Exception as e:
        raise e
    else:
        print('Test failed in Session.__init__()!')



# Generated at 2022-06-23 20:02:59.621259
# Unit test for constructor of class Session
def test_Session():
    session = Session(Path("test_value"))
    assert session.path == Path("test_value")
    assert session["headers"] == {}
    assert session["cookies"] == {}
    assert session["auth"] == {"type": None, "username": None, "password": None}



# Generated at 2022-06-23 20:03:04.907793
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    from httpie.utils import get_config_dir
    config_dir = get_config_dir()
    session_name = 'test'
    host = 'www.baidu.com'
    url = 'https://www.baidu.com/'
    session = get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-23 20:03:07.132231
# Unit test for function get_httpie_session
def test_get_httpie_session():
    print(get_httpie_session('/root/.config', 'session_demo', 'www.google.com', 'www.google.com'))

# Generated at 2022-06-23 20:03:12.231205
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('abc.json')
    request_headers = RequestHeadersDict.from_raw_items([
        ('Foo', 'bar'),
        ('User-Agent', 'HTTPie/0.9.2')
    ])
    session.update_headers(request_headers)
    assert session.headers['foo'] == 'bar'
    assert 'user-agent' not in session.headers

# Generated at 2022-06-23 20:03:15.617180
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session_path = get_httpie_session('data\temp','abc','','abc').path
    assert session_path == 'data\\temp\\sessions\\abc\\abc.json'

# Generated at 2022-06-23 20:03:25.632171
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.cli.dicts import RequestHeadersDict
    
    # test of normal case
    s = Session('test_normal.json')
    s['headers']['Accept'] = 'text/html'
    r = RequestHeadersDict()
    r['Host'] = 'www.google.com'
    r['Cookie'] = 'abc=123'
    s.update_headers(r)
    assert s['headers']['Host'] == 'www.google.com'
    assert s['cookies']['abc']['value'] == '123'
    assert s['headers']['Accept'] == 'text/html'

    # test of unauthorized http_auth
    s = Session('test_auth.json')
    r = RequestHeadersDict

# Generated at 2022-06-23 20:03:34.558695
# Unit test for constructor of class Session
def test_Session():
    session_path = "httpie_test"

    session = Session(session_path)
    session.update_headers({"host":"www.baidu.com", "user-agent":"HTTPie/0.9.2", "cookie":"BAIDUID=0D00E05AD40D93EF36CDB78B8B3B3A88:FG=1; BIDUPSID=98DB4F57D87B53BEAF4C4D1FD4BAB2B7"})
    session.auth = {'type': 'basic', 'raw_auth':'admin:pass'}

    assert session.auth.username == "admin"
    assert session.auth.password == "pass"

    assert session.headers.get("user-agent") == "HTTPie/0.9.2"

# Generated at 2022-06-23 20:03:40.768675
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'https://github.com/jakubroztocil/httpie'
    config_dir = Path('./httpie') 
    session_path = Path('./httpie/sessions/github.com/default.json')
    session_name = 'default'
    host = 'github.com'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.path == session_path
    assert session_name in str(session.path)
    assert host in str(session.path)

# Generated at 2022-06-23 20:03:44.954809
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='path')
    session.cookies = {'cookieA': 'valueA', 'cookieB': 'valueB', 'cookieC': 'valueC'}
    session.remove_cookies(['cookieB'])
    assert session.cookies == {'cookieA': 'valueA', 'cookieC': 'valueC'}


# Generated at 2022-06-23 20:03:50.459866
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(DEFAULT_SESSIONS_DIR / 'test.json'))

    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}

    session.remove_cookies(['a'])

    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-23 20:03:55.481687
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, 'default', 'github.com', 'https://github.com')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-23 20:03:59.015575
# Unit test for function get_httpie_session
def test_get_httpie_session():
    path = os.path.abspath(os.path.dirname(__file__))
    session = get_httpie_session(os.path.join(path, 'httpie'), 'localhost', 'localhost', 'http://localhost')
    assert session


# Test for function is_valid_name

# Generated at 2022-06-23 20:03:59.878430
# Unit test for constructor of class Session
def test_Session():
    Session("test").__init__("test")

# Generated at 2022-06-23 20:04:10.747672
# Unit test for constructor of class Session
def test_Session():
    test_session = Session(path=DEFAULT_SESSIONS_DIR / 'www_httpie_org.json')
    test_session.update_headers(RequestHeadersDict({'Connection': 'close', 'user-agent': 'httpie/1.0.2', 'Cookie': 'sessionid=something'}))
    assert test_session['headers'] == {'Connection': 'close', 'user-agent': 'httpie/1.0.2'}
    assert test_session['cookies'] == {'sessionid': {'value': 'something'}}
    assert isinstance(test_session.cookies, RequestsCookieJar)
    assert isinstance(test_session.headers, RequestHeadersDict)
    test_session.remove_cookies(['sessionid'])
    assert test_session['cookies'] == {}

# Generated at 2022-06-23 20:04:14.667753
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path="")
    session['headers'] ={}
    session.update_headers({'content-type':'application/x-www-form-urlencoded', 'Content-Length':'14', 'If-None-Match': '*'})
    assert session.headers == {'content-type': 'application/x-www-form-urlencoded'}

# Generated at 2022-06-23 20:04:21.006877
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import pytest
    session = Session(Path('/tmp/foo.json'))
    session['cookies'] = {'a': 1, 'b': 2}
    session.remove_cookies(['b'])
    assert session['cookies'] == {'a': 1}
    with pytest.raises(AssertionError) as exc:
        assert session['cookies'] == {'a': 1, 'b': 2}
    assert str(exc.value) == "'b' not found in session['cookies']"

# Generated at 2022-06-23 20:04:26.686157
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sess_path = get_httpie_session(
        DEFAULT_CONFIG_DIR,
        'session_name',
        None,
        'http://localhost'
    )
    assert sess_path == Session(Path(DEFAULT_CONFIG_DIR) / SESSIONS_DIR_NAME / 'localhost' / 'session_name.json')



# Generated at 2022-06-23 20:04:32.919298
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('example_dir')
    session_name = 'example_session'
    host = 'example_host'
    url = 'https://example_url.com'

    session = get_httpie_session(
        config_dir,
        session_name,
        host,
        url
    )

    assert session.path == config_dir / SESSIONS_DIR_NAME / f'{host}/{session_name}.json'

# Generated at 2022-06-23 20:04:35.293513
# Unit test for constructor of class Session
def test_Session():
    assert Session('test.json').helpurl == 'https://httpie.org/doc#sessions'
    assert Session('test.json').about == 'HTTPie session file'

# Generated at 2022-06-23 20:04:39.708779
# Unit test for constructor of class Session
def test_Session():
    session = Session('test')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth']['type'] == None
    assert session['auth']['username'] == None
    assert session['auth']['password'] == None
    assert session.path.name == 'test'


# Generated at 2022-06-23 20:04:47.831566
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/home/alice/.config/httpie/sessions/localhost/test.json')
    request_headers = {}
    request_headers['Content-Type'] = 'application/json'
    request_headers['If-Match'] = '*'
    request_headers['Cookie'] = 'demo:mycart'
    session.update_headers(request_headers)
    assert session['headers'] == {}
    assert session['cookies']['demo'] == {'value': 'mycart'}

# Generated at 2022-06-23 20:04:57.228025
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # return session by file name with relative path
    session = get_httpie_session(Path(), "sessions/test/test1.json", None, None)
    assert session != None

    # return session by file name with absolute path
    session = get_httpie_session(Path(), "/test/test1.json", None, None)
    assert session != None

    # return session by file name with absolute path
    session = get_httpie_session(Path(), "/test/test1.json", "test", None)
    assert session != None

    # return session by file name with absolute path
    session = get_httpie_session(Path(), "test/test1.json", "test", None)
    assert session != None

    # return session by file name with absolute path

# Generated at 2022-06-23 20:05:02.106991
# Unit test for constructor of class Session
def test_Session():
    from httpie.downloads import DEFAULT_DOWNLOAD_DIR
    s = Session(DEFAULT_DOWNLOAD_DIR)
    assert s.path == DEFAULT_DOWNLOAD_DIR
    assert s.get('headers', '') == {}
    assert s.get('cookies', '') == {}
    assert s.get('auth', '') == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-23 20:05:08.288809
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('/tmp/sess.json')
    sess.cookies['a'] = 'a'
    sess.cookies['b'] = 'b'
    assert len(sess.cookies) == 2
    assert sess.cookies['a'] == 'a'
    assert sess.cookies['b'] == 'b'
    sess.remove_cookies(['a'])
    assert len(sess.cookies) == 1
    assert 'a' not in sess.cookies
    assert 'b' in sess.cookies

# Generated at 2022-06-23 20:05:16.139554
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import os
    import os.path
    import sys
    import tempfile
    import shutil
    import unittest

    from httpie import sessions

    class TestGetHttpieSession(unittest.TestCase):
        def setUp(self):
            self.rootdir = tempfile.mkdtemp()
            self.subdirA = os.path.join(self.rootdir, 'subdirA')
            os.makedirs(self.subdirA)
            self.subdirB = os.path.join(self.rootdir, 'subdirB')
            os.makedirs(self.subdirB)
            self.subdirC = os.path.join(self.subdirB, 'subdirC')
            os.makedirs(self.subdirC)

            self.subsubsubfile = os

# Generated at 2022-06-23 20:05:22.928213
# Unit test for constructor of class Session
def test_Session():
    session = Session('~/')
    assert ['headers', 'auth', 'cookies'] == list(session.keys())
    assert not session['headers']

    assert session['auth']['type'] is None
    assert session['auth']['username'] is None
    assert session['auth']['password'] is None

    assert not session['cookies']

# Generated at 2022-06-23 20:05:26.121462
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    a = Session('sd')
    a['cookies'] = {}
    assert a['cookies'] == {}
    a['cookies']['1'] = 1
    assert a['cookies'] == {'1': 1}


# Generated at 2022-06-23 20:05:31.355039
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_session = Session('~/.httpie/tmp/unix.json')
    test_session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}, 'name3': {'value': 'value3'}}
    test_session.remove_cookies(['name2', 'name3'])
    assert test_session['cookies'] == {'name1': {'value': 'value1'}}

# Generated at 2022-06-23 20:05:34.097439
# Unit test for constructor of class Session
def test_Session():
    session = Session(path="url")
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }

# Generated at 2022-06-23 20:05:38.266205
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=None)
    session.update_headers({
        'auth': 'user:pass',
        'HTTPie-Debug-ID': '123'
    })
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    assert session['headers'] == {
        'auth': 'user:pass',
        'HTTPie-Debug-ID': '123'
    }

# Generated at 2022-06-23 20:05:44.584576
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'name1': {'value': 'value1'}}
    session.remove_cookies([])
    assert session['cookies'] == {'name1': {'value': 'value1'}}
    session.remove_cookies(['name2'])
    assert session['cookies'] == {'name1': {'value': 'value1'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:05:46.875390
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    headers = RequestHeadersDict()
    headers['test'] = 'test'
    session.update_headers(headers)
    assert session['headers'] == headers

# Generated at 2022-06-23 20:05:52.811818
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'session_file_name'
    host = None
    url = 'https://httpbin.org/headers'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert isinstance(session, Session)
    assert session.path == Path(f'{DEFAULT_SESSIONS_DIR}/httpbin_org/session_file_name.json')

# Generated at 2022-06-23 20:06:02.459457
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """First test of Session class"""
    session = Session('test.json')
    cookie_names = ['name1','name2','name3','name4']
    session['cookies'] = {}
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import AuthBasicPlugin
    from httpie.cli.parser import get_parser
    p = get_parser()
    for name in cookie_names:
        session['cookies'][name] = {'value': 'value'}
        session['auth'] = {'type': 'basic', 'raw_auth': 'help'}
        session['headers'] = {'header': 'value'}
    session.remove_cookies(['name1'])

# Generated at 2022-06-23 20:06:08.560828
# Unit test for constructor of class Session
def test_Session():
    # Test case 1
    path = '~/httpie/sessions/github.com/login'
    actual = Session(path)
    expected = {
        'headers': {},
        'cookies': {},
        'auth': {
            'type': None,
            'username': None,
            'password': None
        }
    }
    assert actual == expected



# Generated at 2022-06-23 20:06:18.640702
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('Sessions/test1.json')
    request_headers = RequestHeadersDict({'Accept-Encoding': 'gzip'})
    session.update_headers(request_headers)
    assert session.headers.items() == {'Accept-Encoding': 'gzip'}.items()
    assert not request_headers
    session.update_headers({'User-Agent': 'HTTPie/1.0.2'})
    assert session.headers.items() == {
        'Accept-Encoding': 'gzip',
        'User-Agent': 'HTTPie/1.0.2'
    }.items()
    # ignore explicitly unset headers
    session.update_headers({'Content-Length': None})

# Generated at 2022-06-23 20:06:23.608908
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test/unit_tests/test_session')
    session.cookies = RequestsCookieJar()
    session.cookies.set('test1', 'test1')
    assert 'test1' in session.cookies
    session.remove_cookies(['test1'])
    assert 'test1' not in session.cookies



# Generated at 2022-06-23 20:06:29.379466
# Unit test for constructor of class Session
def test_Session():
    expected_dict = {
        'headers': {},
        'cookies': {},
        'auth': {
            'type': None,
            'username': None,
            'password': None
        }
    }
    path = '~/some_path'
    session = Session(path)
    assert session.path == (Path('~')/'some_path')
    assert session.data == expected_dict
    assert session.loaded == False


# Generated at 2022-06-23 20:06:34.726302
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/test.json')
    s['cookies'] = {'name1':{'value':'value1'},'name2':{'value':'value2'}}
    s.remove_cookies(['name2'])
    assert s['cookies'] == {'name1':{'value':'value1'}}

# Generated at 2022-06-23 20:06:36.916769
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("my_session")
    session['cookies'] = {"A":{"value":"a","path":"/"}}
    session.remove_cookies(["A"])
    assert len(session['cookies'].keys()) == 0

# Generated at 2022-06-23 20:06:43.425727
# Unit test for constructor of class Session
def test_Session():
    import json
    import os
    import requests
    import shutil
    import tempfile
    import urllib.parse
    import unittest
    from httpie.compat import urlquote

    class SessionTest(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.cwd = os.getcwd()
            os.chdir(self.tempdir)

        def tearDown(self):
            os.chdir(self.cwd)
            shutil.rmtree(self.tempdir)

        def test_update_headers(self):
            session = Session(path='foo')


# Generated at 2022-06-23 20:06:53.795348
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import unittest
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.config import BaseConfigDict
    # Test1 - test without cookies
    headers_dict = {'Content-Type': 'application/json', 'accept-encoding': 'gzip'}
    #The below headers should not be stored to the session
    request_headers = RequestHeadersDict({'if-none-match': None, 'user-agent': 'httpie/2.2.0'})
    session = Session('/content')
    session.update_headers(request_headers)
    # Convert session dictionary to RequestHeadersDict
    session_headers = RequestHeadersDict(session['headers'])
    assert len(session_headers) == len(headers_dict)

# Generated at 2022-06-23 20:07:00.944367
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import json
    import os
    # Create a session
    session_name = "test_header"
    host = 'localhost'
    url = "http://127.0.0.1:8080/api/v1/monitor/cpu"
    session = get_httpie_session(DEFAULT_SESSIONS_DIR ,session_name, host, url)
    # HTTP Request Headers
    # Accept:	text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
    # Accept-Encoding:	gzip, deflate, sdch
    # Accept-Language:	zh-CN,zh;q=0.8
    # Cache-Control:	no-cache
    # Connection:	keep-alive
    # Cookie:	BW_AD

# Generated at 2022-06-23 20:07:06.624873
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(''))
    session.load()
    session['cookies'] = {'foo':{'value':'bar'}}
    session.remove_cookies(['spam'])
    assert 'foo' in session['cookies']
    session.remove_cookies(['foo'])
    assert 'foo' not in session['cookies']

# Generated at 2022-06-23 20:07:16.454881
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValue

    cookies = 'foo=bar; baz=42'
    req_headers = RequestHeadersDict({
        'HTTPIE_SESSION_TEST': 'HTTPIE_SESSION_TEST',  # Will be ignored
        'X-Foo': 'bar',
        'cookie': cookies,
        'Authorization': 'bearer TOKEN',
    })

    session = Session('httpie_session_test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    session.update_headers(req_headers)
    assert session['headers'] == {'X-Foo': 'bar'}

# Generated at 2022-06-23 20:07:27.666473
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/')
    session['headers'] = {'test': 'testtest'}
    session.update_headers({'test': 'value'})

    assert not session['headers']['test'] == 'testtest'
    assert session['headers']['test'] == 'value'

    session['headers'] = {'content-type': 'value'}
    session.update_headers({'content-type': 'newvalue'})

    assert not session['headers']['content-type'] == 'value'
    assert session['headers']['content-type'] == 'newvalue'

    session = Session('/')
    session['headers'] = {'content-length': 'value'}
    session.update_headers({'content-length': 'newvalue'})


# Generated at 2022-06-23 20:07:30.162162
# Unit test for constructor of class Session
def test_Session():
    assert VALID_SESSION_NAME_PATTERN.match('a-b_c.d')
    assert VALID_SESSION_NAME_PATTERN.match('127.0.0.1')
    assert VALID_SESSION_NAME_PATTERN.match('127_0_0_1')

# Generated at 2022-06-23 20:07:41.738821
# Unit test for function get_httpie_session
def test_get_httpie_session():
    directory = Path(os.getcwd()) / '.httpie'
    config_dir = directory / 'config'
    directory.mkdir()
    config_dir.mkdir()
    sessions_dir = config_dir / SESSIONS_DIR_NAME
    sessions_dir.mkdir()

    session_name = 'tester'
    host = 'localhost'
    url = 'http://localhost:5000/'

    session = get_httpie_session(config_dir, session_name, host, url)
    path_to_session = str((config_dir / SESSIONS_DIR_NAME /
                           f'{host}/{session_name}.json'))


# Generated at 2022-06-23 20:07:51.755986
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    from httpie.config import BaseConfigDict
    from httpie.sessions import get_httpie_session, SESSIONS_DIR_NAME
    from httpie.plugins import builtin
    from httpie.plugins.manager import PluginManager
    from httpie.context import Environment
    from httpie import ExitStatus
    plugin_manager = PluginManager(load_defaults=False)
    plugin_manager.add_plugin_from_module(builtin)
    cfg_dir = Path(__file__).parent
    config_dir = cfg_dir / '.httpie'
    config_dir.mkdir(exist_ok=True)
    config_dir = Path(config_dir)
    config_dir = config_dir / SESSIONS_DIR_NAME / 'localhost'

# Generated at 2022-06-23 20:07:55.418614
# Unit test for constructor of class Session
def test_Session():
    session = Session('/a/b/c.txt')
    assert (
        session['headers'] == {} and
        session['cookies'] == {} and
        session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }
    )

# Generated at 2022-06-23 20:08:01.729904
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # test for mimimal changes
    headers = {
        b'User-agent': 'HTTPie/0.9.6',
        b'Accept': '*/*',
        b'Accept-Encoding': b'gzip, deflate',
        b'Connection': b'keep-alive',
        b'Authorization': 'Basic 00000000000000000000000000000000'
    }
    session = Session('.')
    session.update_headers(headers)
    assert set(session['headers'].keys())-set(headers.keys()) == set()

# Generated at 2022-06-23 20:08:06.373791
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://localhost:8989'
    netloc = 'localhost:8989'
    default_session_dir = DEFAULT_CONFIG_DIR / 'sessions'
    session_dir = default_session_dir / 'localhost_8989'
    session_dir.mkdir(parents=True, exist_ok=True)
    session = 'testing'
    path = session_dir / f'{session}.json'
    res = get_httpie_session(DEFAULT_CONFIG_DIR, session, host=netloc, url=url)
    assert isinstance(res, Session)
    assert res.path == path

# Generated at 2022-06-23 20:08:17.468952
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    with TemporaryDirectory() as tempdir:
        config_dir = Path(tempdir)
        session_name = 'session01'
        # host = 'www.example.com'
        # url = f'http://{host}/'
        # os.mkdir(os.path.join(tempdir, 'sessions', host))
        # session_path = os.path.join(tempdir, 'sessions', host, f'{session_name}.json')
        # with open(session_path, 'w') as f:
        #     f.write('{"a": "hello"}')

        # os.path.exists(session_path)
        # session = get_httpie_session(config_dir, session_name, host, url)
        # session['

# Generated at 2022-06-23 20:08:26.500948
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session['headers'] = {'Accept': 'application/json'}
    session['cookies'] = {'a': 'b'}

    request_headers = RequestHeadersDict({
        'Host': 'example.com',
        'Accept': '*/*',
        'Content-Type': 'application/json',
        'Cookie': 'a=c',
        'If-Match': 'abc123'
    })
    session.update_headers(request_headers)

    assert session['headers'] == {
        'Host': 'example.com',
        'Accept': '*/*',
        'Content-Type': 'application/json',
    }
    assert session['cookies'] == {'a': {'value': 'c'}}

# Generated at 2022-06-23 20:08:38.747635
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    '''
    Tests that Session.update_headers() correctly updates the
    session headers with the request ones while ignoring
    certain name prefixes.
    '''

    session = Session("")
    # Create request headers
    request_headers = RequestHeadersDict()
    request_headers["User-Agent"] = "HTTPie/1.0.2"
    request_headers["Content-Type"] = "text/html"
    request_headers["Content-Length"] = "42"
    request_headers["Accept-Encoding"] = "identity"
    request_headers["If-Modified-Since"] = "Wed, 21 Oct 2015 07:28:00 GMT"
    request_headers["Cookie"] = "session=abcdefghijklmnopqrstuvwxyz;"
    # Test ignored headers with valid and uppercase prefixes


# Generated at 2022-06-23 20:08:49.638007
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from copy import copy
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.client import JSON_ACCEPT
    from httpie.models import Environment

    json_headers = RequestHeadersDict({'Accept': JSON_ACCEPT})
    headers = copy(json_headers)
    headers.update({
        'User-Agent': 'Wget/1.17.1 (linux-gnu)',
        'Accept': '*/*',
        'Content-Type': 'application/json'
    })

    # Calling update_headers
    session = Session(DEFAULT_SESSIONS_DIR / 'test.json')
    session.update_headers(headers)

    # Verify that the Accept header has been removed
    del headers['Accept']

    # Verify that the other headers have been added to the session

# Generated at 2022-06-23 20:08:57.037714
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path = "path")
    request_headers = {
        'Accept': 'application/json',
        'Accept-Encoding': 'gzip, deflate',
        'Auth-Token': '42b6a88c0d5e344aacf43064f0eee384',
        'Content-Length': '0',
        'Content-Type': 'application/json',
        'If-Modified-Since': 'Tue, 20 Oct 2020 10:00:00 GMT',
        'If-None-Match': '"abcd"',
        'If-Unmodified-Since': 'Tue, 20 Oct 2020 10:00:00 GMT',
        'If-Match': '"abcd"'
    }
    session.update_headers(request_headers)

# Generated at 2022-06-23 20:09:03.813375
# Unit test for constructor of class Session
def test_Session():
    print("Testing session initialization")
    print("Testing 'headers' attribute")
    test_Session = Session("cookie.json")
    assert test_Session.headers == {}
    print("Testing 'cookies' attribute")
    assert test_Session.cookies == {}
    print("Testing 'aut' attribute")
    assert test_Session.auth == {
            'type': None,
            'username': None,
            'password': None
        }

# Generated at 2022-06-23 20:09:09.554442
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./test_session.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}, 'c': {'value': '3'}}
    session.remove_cookies(('a', 'c'))
    assert session['cookies'] == {'b': {'value': '2'}}, 'Expecting to delete the cookies a, c'

if __name__ == '__main__':
    test_Session_remove_cookies()

# Generated at 2022-06-23 20:09:15.267838
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/home/httpie/.config/httpie')
    session_name = 'test_session_name'
    host = 'github.com'
    url = 'http://httpie.org/doc'
    expected_path = Path('/home/httpie/.config/httpie/sessions/httpie.org/test_session_name.json')
    actual_path = get_httpie_session(config_dir, session_name, host, url).path
    assert actual_path == expected_path



# Generated at 2022-06-23 20:09:19.408424
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/path/to/sessions')
    session.update_headers({"cookie": "", "User-Agent": "some_agent"})
    assert session['headers'] == {"User-Agent": "some_agent"}


# Generated at 2022-06-23 20:09:25.635049
# Unit test for function get_httpie_session
def test_get_httpie_session():
    os.environ['HTTPIE_CONFIG_DIR'] = '/var/tmp'
    session_name = 'test'
    host = None
    url = 'https://example.com/test'
    session = get_httpie_session(
        config_dir=os.environ.get('HTTPIE_CONFIG_DIR'),
        session_name=session_name,
        host=host,
        url=url
    )

    assert(isinstance(session, Session))

# Generated at 2022-06-23 20:09:35.544701
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    S = Session('/dev/null')
    S.cookies = RequestsCookieJar()
    S.cookies.set_cookie(create_cookie('key1', 'value1'))
    S.cookies.set_cookie(create_cookie('key2', 'value2'))
    S.cookies.set_cookie(create_cookie('key3', 'value3'))
    S.remove_cookies(['key2', 'key4'])
    assert len(S.cookies) == 2
    assert S.cookies['key1'] == 'value1'
    assert S.cookies['key3'] == 'value3'

# Generated at 2022-06-23 20:09:40.642169
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./test_session.json')
    session['cookies']['testtype'] = {'value': 'testvalue'}
    session.remove_cookies(['testtype'])
    assert 'testtype' not in session['cookies']
    os.remove('./test_session.json')


# Generated at 2022-06-23 20:09:51.730358
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import requests
    from httpie.compat import Path
    from httpie.sessions import Session

    cookie = create_cookie('httpie', 'awesome')
    jar = requests.cookies.RequestsCookieJar()
    jar.set_cookie(cookie)

    request_headers = {
        'Cookie': str(cookie),
        'User-Agent': 'HTTPie/0.9.2',
        'Accept': 'application/json',
        'Accept-Encoding': 'gzip, deflate, compress',
        'Host': 'httpbin.org',
    }

    session = get_httpie_session(
        Path.home() / '.httpie',
        'httpie',
        'httpbin.org',
        'https://httpbin.org/get',
    )
    assert session.path == Path.home

# Generated at 2022-06-23 20:09:57.204641
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.cli.parser import Parser
    parser = Parser()
    config_dir = DEFAULT_CONFIG_DIR
    url = 'http://localhost:5000/test'
    # Test with cookie in request headers
    request_headers = RequestHeadersDict(
        parser.split_key_value_headers(
            parser.parse_headers(['cookie: key=value'])))
    session = get_httpie_session(config_dir, session_name='test', host=None, url=url)
    assert 'cookies' in session
    assert 'headers' in session
    session.update_headers(request_headers)
    assert 'cookie' not in session['headers']
    assert 'key' in session['cookies']

# Generated at 2022-06-23 20:10:02.099352
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('/')
    sess['cookies'] = {}
    sess['cookies']['foo'] = {'value':'bar'}
    assert 'foo' in sess['cookies']
    sess.remove_cookies(['foo'])
    assert 'foo' not in sess['cookies']


# Generated at 2022-06-23 20:10:07.255505
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session['cookies'] = {
        'cookie1': 'cookie1_value',
        'cookie2': 'cookie2_value'
    }
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {'cookie1': 'cookie1_value'}



# Generated at 2022-06-23 20:10:18.567827
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import os
    from httpie.core import main
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    plugin_manager.register(HTTPBasicAuth)
    s = Session(os.path.expanduser('~/.httpie/sessions/localhost/httpbin_org.json'))
    s.load()
    s.update_headers(main.build_headers({'color': 'blue', 'User-Agent': 'test'},
                                                              {'auth': '', 'auth-type': 'basic'}))
    print(s)



# Generated at 2022-06-23 20:10:21.804041
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # In Python 3.9, Path.relative_to() can be used to verify the path
    # is within the config directory.
    # https://docs.python.org/3/library/pathlib.html#pathlib.Path.relative_to
    get_httpie_session(DEFAULT_CONFIG_DIR, 'foo', None, 'http://a.com/')



# Generated at 2022-06-23 20:10:30.007671
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path("test", "httpie")
    session_name = 'my-session'
    host = None
    url = 'http://myurl.com/test/session'

    expected = 'test/httpie/sessions/myurl_com/my-session.json'
    expected = Path(expected)
    assert get_httpie_session(config_dir, session_name, host, url).path == expected

    expected = 'test/httpie/sessions/myurl_com/my-session.json'
    expected = Path(expected)
    assert get_httpie_session(config_dir, './my-session', host, url).path == expected

    expected = '~/my-session.json'
    expected = Path(expected)

# Generated at 2022-06-23 20:10:33.707639
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    session.update_headers(headers={'key': 'val'})
    assert(session.headers['key'] == 'val')
    session.update_headers(headers={'key2': 'val2'})
    assert(session.headers['key2'] == 'val2')
    assert(session.headers['key'] == 'val')
    session.update_headers(headers={'key': 'new_val'})
    assert(session.headers['key2'] == 'val2')
    assert(session.headers['key'] == 'new_val')

# Generated at 2022-06-23 20:10:41.397866
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = '.httpie_session'
    host = '127.0.0.1'
    url = 'http://127.0.0.1'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-23 20:10:43.411457
# Unit test for constructor of class Session
def test_Session():
    path = Path('./test.txt')
    test = Session(path)
    test.save()

# Generated at 2022-06-23 20:10:51.386183
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.config import BaseEnvironment


# Generated at 2022-06-23 20:10:56.829424
# Unit test for function get_httpie_session
def test_get_httpie_session():

    url = 'http://www.github.com'
    session_name = 'new_session'
    config_dir = os.path.join(os.getcwd(), 'sessions')

    sess = get_httpie_session(config_dir, session_name, None, url)
    print(sess)
    assert sess is not None

# Generated at 2022-06-23 20:11:02.750731
# Unit test for constructor of class Session
def test_Session():
    c = Session("./test.json")
    headers = RequestHeadersDict({"header1":"value1"})
    c.update_headers(headers)
    c['headers'] = headers
    c['cookies'] = {'cookie1':'value1'}
    c['auth'] = {
        'type': 'Basic',
        'username': 'bob',
        'password': None
    }

if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-23 20:11:11.030875
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session(None)
    assert 'cookies' in sess.keys()
    assert len(sess.keys()) == 3

    sess['cookies']['a'] = 1
    sess['cookies']['b'] = 2
    sess['cookies']['c'] = 3
    assert len(sess['cookies'].keys()) == 3

    sess.remove_cookies(['a','b'])
    assert len(sess['cookies'].keys()) == 1
    assert sess['cookies']['c'] == 3

# Generated at 2022-06-23 20:11:18.162843
# Unit test for constructor of class Session
def test_Session():

    path = 'test_file.json'
    session = Session(path)
    assert session.name == 'test_file'
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

    # Test overridden property
    session.headers = {'test': 'test'}
    assert session['headers'] == {'test': 'test'}
    assert session.headers == {'test': 'test'}


# Generated at 2022-06-23 20:11:23.730113
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('tests/fixtures/sessions/my_session.json')
    session.load()
    session.remove_cookies(['name2'])
    assert 'name2' not in session['cookies']
    assert 'name1' in session['cookies']

# Generated at 2022-06-23 20:11:30.698234
# Unit test for function get_httpie_session
def test_get_httpie_session():
    class my_session(Session):
        def __init__(self):
            self.test_config_dir = Path('/home/example/.config/httpie')
            self.test_session_name = 'my_session'
            self.test_host = 'www.example.com'
            self.test_url = 'https://www.example.com/page.html'

    session_obj = my_session()
    session_obj_assert = get_httpie_session(
        session_obj.test_config_dir,
        session_obj.test_session_name,
        session_obj.test_host,
        session_obj.test_url,
    )