

# Generated at 2022-06-23 20:01:37.928765
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config, DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth

    config_dir = DEFAULT_CONFIG_DIR / 'test'
    if os.path.exists(config_dir):
        import shutil
        shutil.rmtree(config_dir)
    os.makedirs(config_dir)

    session_name = 'sess'
    path = config_dir / SESSIONS_DIR_NAME / 'localhost' / f'{session_name}.json'

    config = Config(config_dir=config_dir, config_path=config_dir / 'config.json')
    env = Environment(config)
    auth = HTTPBasicAuth()

# Generated at 2022-06-23 20:01:42.171685
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("session_unittest")
    session['cookies'] = {'a': {'value': 1}, 'b' : {'value': 2}}
    session.remove_cookies(['b', 'c'])
    assert session['cookies'] == {'a': {'value': 1}}

# Generated at 2022-06-23 20:01:47.979979
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.compat import FileNotFoundError
    
    session = Session('test-sessions/new_session.json')
    request_headers = RequestHeadersDict([('Cookie', 'cookie_1=value_1'), ('Cookie', 'cookie_2=value_2'), ('A', '1')])
    session.update_headers(request_headers)
    assert session['headers'] == {'A': '1'}
    assert session['cookies'] == {'cookie_1': {'value': 'value_1'}, 'cookie_2': {'value': 'value_2'}}

# Generated at 2022-06-23 20:01:54.895367
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/dummy')
    s['cookies'] = {'ABC': {'value': 'foo', 'max-age': '5'}}
    s.remove_cookies(['XYZ'])
    assert s['cookies'] == {'ABC': {'value': 'foo', 'max-age': '5'}}
    s.remove_cookies(['ABC'])
    assert s['cookies'] == {}



# Generated at 2022-06-23 20:01:59.471682
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('~/httpie/test')
    session.cookies = RequestsCookieJar()
    session.cookies.set('test1', 'testvalue1')
    assert 'test1' in session.cookies.keys()
    session.remove_cookies(['test1'])
    assert 'test1' not in session.cookies.keys()


# Generated at 2022-06-23 20:02:01.255935
# Unit test for constructor of class Session
def test_Session():
    assert Session(config_dir=DEFAULT_SESSIONS_DIR, session_name='./test', host=None, url='http://test.com')

# Generated at 2022-06-23 20:02:04.668154
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('foo.json')
    session['cookies'] = {'foo': 'bar'}
    session.remove_cookies(['foo'])
    assert not session.cookies
    session.remove_cookies(['foo'])  # no effect

# Generated at 2022-06-23 20:02:14.634104
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    #
    # assert that header updates are performed correctly
    #
    session = Session(DEFAULT_SESSIONS_DIR)
    session.update_headers({'header1': 'value1'})
    assert session.headers['header1'] == 'value1'
    session.update_headers({'header2': 'value2'})
    assert session.headers['header2'] == 'value2'
    session.update_headers({'header1': 'newvalue11'})
    assert session.headers['header1'] == 'newvalue11'
    #
    # assert that headers from SESSION_IGNORED_HEADER_PREFIXES are not being
    # added to the session
    #
    session = Session(DEFAULT_SESSIONS_DIR)

# Generated at 2022-06-23 20:02:20.743129
# Unit test for constructor of class Session
def test_Session():
    # test pattern
    path_not_ok1 = "~/path/to/file"
    path_not_ok2 = '/path/to/file'
    path_not_ok3 = '../path/to/file'
    path_not_ok4 = 'test.test'
    path_ok1 = '/path/to'
    path_ok2 = '/another/path'
    path_ok3 = 'test_test'
    path_ok4 = 'test.test'
    # test case1
    session1 = Session(path_not_ok1)
    if(session1.path == '~/path/to/file'):
        assert True
    else:
        assert False
    session2 = Session(path_not_ok2)

# Generated at 2022-06-23 20:02:30.142047
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_Session_update_headers')
    session.update_headers({})
    assert session.headers == RequestHeadersDict()
    session.update_headers({'Head-er': 'value'})
    assert session.headers == {'Head-er': 'value'}
    session.update_headers({'Cookie': 'c=d; e=f; g=h'})
    assert session.headers == {'Head-er': 'value'}
    assert session.cookies == {'c': 'd', 'e': 'f', 'g': 'h'}
    session.update_headers({'If-match': 'value'})
    assert session.headers == {'Head-er': 'value'}

# Generated at 2022-06-23 20:02:33.205181
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://www.google.com'
    host = 'www.google.com'

    session = get_httpie_session(DEFAULT_SESSIONS_DIR, "mysession", host, url)
    print("session created: ", session)


if __name__ == '__main__':
    test_get_httpie_session()

# Generated at 2022-06-23 20:02:41.736453
# Unit test for constructor of class Session
def test_Session():
    test_httpie_session = Session(Path('./httpie_session.json'))
    assert test_httpie_session['headers'] == {}
    assert test_httpie_session['cookies'] == {}
    assert test_httpie_session['auth']['type'] == None
    assert test_httpie_session['auth']['username'] == None
    assert test_httpie_session['auth']['password'] == None
    
    # Test the method of update_headers
    test_httpie_session['headers'] = {'header1': 'value1', 'header2': 'value2'}
    test_httpie_session.update_headers({'header3': 'value3', 'header4': 'value4'})
    assert test_httpie_session['headers']['header3'] == 'value3'

# Generated at 2022-06-23 20:02:46.676699
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {
        'name1': 'value1',
        'name2': 'value2',
        'name3': 'value3',
    }
    names = ['name1', 'name4', 'name5']
    session.remove_cookies(names)
    assert session['cookies'] == {
        'name2': 'value2',
        'name3': 'value3',
    }

# Generated at 2022-06-23 20:02:53.938326
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("../test_session.json")
    request_headers = {
        "Accept": "application/json",
        "Accept-Encoding": "gzip, deflate",
        "Content-length": 0,
        "User-Agent": "HTTPie/0.9.8"
    }
    session.update_headers(request_headers)
    assert session.headers == {"Accept": "application/json", "Accept-Encoding": "gzip, deflate", "Content-length": 0}

# Generated at 2022-06-23 20:02:57.331817
# Unit test for constructor of class Session
def test_Session():
    s = Session('test')
    assert s
    assert s['headers']
    assert s['cookies']
    assert s['auth']
    assert s['auth']['type'] == None
    assert s['auth']['username'] == None
    assert s['auth']['password'] == None

# Generated at 2022-06-23 20:03:03.511054
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://www.google.com'
    session_name = 'test'
    session = get_httpie_session(Path('.'), session_name, None, url)
    session.load()
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }

# Generated at 2022-06-23 20:03:05.416525
# Unit test for constructor of class Session
def test_Session():
    session = Session('example_session')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-23 20:03:09.070768
# Unit test for constructor of class Session
def test_Session():
    s = Session('test_sessions')
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-23 20:03:13.737656
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path("."))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}, 'c': {'value': '3'}}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': {'value': '3'}}

# Generated at 2022-06-23 20:03:15.571772
# Unit test for constructor of class Session
def test_Session():
    with open('httpie.json') as f:
        session = Session(path='httpie.json')


# Generated at 2022-06-23 20:03:25.579032
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    request_headers = {}
    request_headers["Host"] = "www.google.com"
    request_headers["User-Agent"] = "Mozilla"
    request_headers["Content-Length"] = 2
    request_headers["Connection"] = "keep-alive"
    request_headers["Accept"] = "text/html"
    request_headers["Content-Type"] = "application/json"
    request_headers["Cookie"] = "name=value"
    headers = RequestHeadersDict(request_headers)
    session = Session('teste')
    session.update_headers(headers)
    headers = session.headers
    assert headers["Host"] == "www.google.com"
    assert headers["User-Agent"] == "Mozilla"

# Generated at 2022-06-23 20:03:27.946570
# Unit test for constructor of class Session
def test_Session():
    session_path = Path('session_path')
    session = Session(session_path)
    assert session.path == session_path

# Generated at 2022-06-23 20:03:36.550928
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from unittest.mock import patch
    from pathlib import Path
    from uuid import uuid4

    session_name = str(uuid4())
    url_name = "https://github.com/jakubroztocil/httpie"
    config_dir = Path("config_dir")
    host = "2020-05-22T14:15:29.222430"

    with patch("httpie.sessions.get_httpie_session") as get_httpie_session:
        get_httpie_session.return_value = Session("Return")
        result = get_httpie_session(config_dir, session_name, host, url_name)
        get_httpie_session.assert_called_with(config_dir, session_name, host, url_name)

        assert result.__class

# Generated at 2022-06-23 20:03:42.646310
# Unit test for constructor of class Session
def test_Session():
    path = Path('/home/user/.config/httpie/sessions/localhost/a_session.json')
    assert str(path) == '/home/user/.config/httpie/sessions/localhost/a_session.json'
    session = Session(path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-23 20:03:53.961575
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from urllib.parse import urlsplit
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.config import BaseConfigDict, DEFAULT_CONFIG_DIR
    from httpie.plugins.registry import plugin_manager
    session_name = 'sessions'
    host = 'localhost'
    url = 'http://localhost'
    session = Session(Path(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / host / f'{session_name}.json'))
    session.load()
    assert type(session['headers']) is RequestHeadersDict
    assert type(session['cookies']) is dict
    assert type(session['auth']) is dict
    assert type(session['auth']['type']) is str

# Generated at 2022-06-23 20:03:59.630758
# Unit test for constructor of class Session
def test_Session():
    config_dir = Path("./tests/")
    session_name = 'abc'
    url = 'https://github.com/jakubroztocil/httpie'
    session = get_httpie_session(config_dir, session_name, None, url)
    session.load()
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-23 20:04:05.739852
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path('./test.txt'))
    session.update_headers(RequestHeadersDict({
        'test-cookie': 'test-cookie',
        'test-cookie-2': 'test-cookie-2',
    }))
    session.remove_cookies(['test-cookie'])

    assert session.cookies == RequestsCookieJar({
        'test-cookie-2': 'test-cookie-2',
    })

# Generated at 2022-06-23 20:04:16.464005
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # create a session
    session = Session('/config_dir')
    # fill its headers dictionnary
    session['headers'] = {'old': 'header', 'key1': 'value1'}
    # check that the session header is filled
    assert session['headers'] == {'old': 'header', 'key1': 'value1'}
    # create a request header dictionnary to update the session header
    request_headers = RequestHeadersDict({'key1': 'value1', 'key2': 'value2', 'Content-Type': 'text/html'})
    # call update method
    session.update_headers(request_headers)
    # check that the request header do not contain the old header
    assert 'old' not in session['headers']
    # assert that the request header do not contain content header

# Generated at 2022-06-23 20:04:23.934375
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(Path(''))
    s['headers']['Content-type'] = 'application/json'
    s['headers']['User-agent'] = 'HTTPie/1.0.2'
    s.update_headers([('User-Agent','HTTPie/1.0.2'),('Content-Type','text/plain')])
    assert s['headers']['Content-type'] == 'text/plain'
    assert s['headers']['User-agent'] == 'HTTPie/1.0.2'
    # print(s.headers())


if __name__ == '__main__':
    test_Session_update_headers()

# Generated at 2022-06-23 20:04:34.931625
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Add four cookies in one session
    sess = Session('/haha')
    sess['cookies'] = {
        'cookie1': {'value': 'value1', 'path': '/path1'},
        'cookie2': {'value': 'value2', 'path': '/path2'},
        'cookie3': {'value': 'value3', 'path': '/path3'},
        'cookie4': {'value': 'value4', 'path': '/path4'},
    }

# Generated at 2022-06-23 20:04:35.985398
# Unit test for constructor of class Session
def test_Session():
    pass


# Generated at 2022-06-23 20:04:43.980822
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(path='')
    # Test if update_headers works correctly when no headers are given
    s.update_headers({})
    assert s == {
        "headers": {},
        "cookies": {}
    }

    # Test if update_headers works correctly when setting a header
    s = Session(path='')
    s.update_headers({"Accept-Encoding": "gzip"})
    assert s == {
        "headers": {"Accept-Encoding": "gzip"},
        "cookies": {}
    }

    # Test if update_headers works correctly when setting many headers
    s = Session(path='')
    s.update_headers({
        "Accept-Encoding": "gzip",
        "Accept-Language": "en"
    })

# Generated at 2022-06-23 20:04:53.132897
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httmock import HTTMock, response

    with HTTMock(mock_get):
        req = requests.get('http://www.example.com/')

    session = Session(path='test.json')
    session.update_headers(req.request.headers)

    print(session)
    assert session['headers'] == {'Accept': '*/*',
                                  'Accept-Encoding': 'gzip, deflate',
                                  'Connection': 'keep-alive',
                                  'User-Agent': 'python-requests/2.20.0'}
    assert session['cookies'] == {}



# Generated at 2022-06-23 20:04:56.873757
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(config_dir=None)
    s['cookies'] = {'1':{'value':'1'},'2':{'value':'2'}}
    s.remove_cookies(['2'])
    assert dict(s['cookies']) == {'1':{'value':'1'}}


# Generated at 2022-06-23 20:05:00.055639
# Unit test for constructor of class Session
def test_Session():
    path = '.'
    session = Session(path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    return



# Generated at 2022-06-23 20:05:08.792064
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from http.cookies import SimpleCookie
    from pathlib import Path
    from urllib.parse import urlsplit

    def _assert_nopath_session(expected_path, host, url):
        path = get_httpie_session(Path('.'), 'foo', host, url).path
        assert Path(expected_path) == path, path

    # existing session files have priority
    session_file_path = '.config/sessions/host.com/foo.json'
    Path(session_file_path).write_text('{}')
    _assert_nopath_session(session_file_path, None, 'http://host.com/')
    _assert_nopath_session(session_file_path, 'host.com', 'http://host.com/')

# Generated at 2022-06-23 20:05:14.746435
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {'name1': 'value1', 'name2': 'value2'}
    session = Session('test_Session_update_headers')
    session.update_headers(request_headers)
    assert session.headers == request_headers
    assert session.cookies == {}
    assert session.auth == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-23 20:05:16.313220
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, 'test', 'github.com', 'https://github.com/')

# Generated at 2022-06-23 20:05:27.331198
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.cli.dicts import ConfigDict
    from httpie.cli import parser

    config_dir = Path('/tmp')
    session_name = 'test_session'
    url = 'https://tmp.com/tmp'

    args = parser.parse_args(args=['--session', session_name, url])
    config = ConfigDict()
    config.merge(args)

    session_path = (
        config_dir / SESSIONS_DIR_NAME / 'tmp_com' / f'{session_name}.json'
    )
    session = get_httpie_session(config_dir, session_name, args.auth_host, url)
    assert session.path == session_path

# Generated at 2022-06-23 20:05:33.079298
# Unit test for constructor of class Session
def test_Session():
    import tempfile

    tmp_path = tempfile.mkdtemp()
    path = os.path.join(tmp_path, 'test_session.json')
    session = Session(path)
    assert session.path == Path(path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    os.remove(path)
    os.removedirs(tmp_path)



# Generated at 2022-06-23 20:05:35.930423
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name="sessio_name",
        host="host",
        url="http://www.example.com"
    )

# Generated at 2022-06-23 20:05:43.612976
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("/dev/null")
    dic = {
        'Content-Type': 'application/json',
        'Content-Encoding': 'utf-8',
        'Connection': 'keep-alive',
        'Accept': 'application/json',
        'User-Agent': 'httpie/1.0.0',
        'Accept-Encoding': 'gzip, deflate',
        'Pragma': None,
        'Cookie': 'hello=world',
        'World': 'hello'
    }
    session.update_headers(RequestHeadersDict(dic))

# Generated at 2022-06-23 20:05:48.532258
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # get_httpie_session(config_dir: Path, session_name: str,
    #                     host: Optional[str], url: str) -> 'Session':
    # fake a call
    from pathlib import Path
    from httpie.input import SEP_CREDENTIALS

    # Same tests as for SessionsPlugin.get_session()
    config_dir = Path(__file__).parent.parent / "httpie"
    session_name = "test_session"
    # standard URL and session name
    host = "httpbin.org"
    url = "http://httpbin.org/get"
    session_file = Path(__file__).parent.parent / "httpie" / "sessions" / "httpbin_org" / "test_session.json"

# Generated at 2022-06-23 20:05:52.383344
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path="test.json")
    s['cookies'] = {"a": 1, "b": 2}
    s.remove_cookies(["a", "c"])
    assert s['cookies'] == {"b": 2}

# Generated at 2022-06-23 20:05:56.713761
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session_name = "my_first_session"
    host = "http://example.com"
    url = "http://example.com/index.html"
    get_httpie_session(DEFAULT_SESSIONS_DIR, session_name, host, url)

# Generated at 2022-06-23 20:06:01.131959
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_headers = {"Host": "www.bigtime.com", "Cookie": None, "User-Agent": "MyApp 1.0"}
    request_headers = {"Host": "www.bigtime.com", "cookie": "csrftoken=1"}
    session = Session("")
    session.update_headers(request_headers)
    assert session.headers == session_headers

# Generated at 2022-06-23 20:06:04.782682
# Unit test for constructor of class Session
def test_Session():
    s = Session(path="abc")
    assert s["headers"] == {}
    assert s["cookies"] == {}
    assert s["auth"] == {"type": None, "username": None, "password": None}



# Generated at 2022-06-23 20:06:11.836638
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # 1. Create Session instance
    session = Session('test_session')

    # 2. Set cookies on Session instance
    session['cookies'] = {'val1': 1, 'val2': 2, 'val3': 3, 'val4': 4}

    # 3. Call method remove_cookies on Session instance - pass in list of values
    session.remove_cookies(['val2', 'val4'])

    # 4. Validate method remove_cookies has removed values from Session instance
    assert session['cookies'] == {'val1': 1, 'val3': 3}

# Generated at 2022-06-23 20:06:16.894576
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('Dummy')

    # Check if name is not in cookies[]
    session['cookies'] = {'a': 1, 'b': 2}
    session.remove_cookies(['c'])
    assert session['cookies'] == {'a': 1, 'b': 2}

    # Check if name is in cookies[]
    session.remove_cookies(['b'])
    assert session['cookies'] == {'a': 1}

# Generated at 2022-06-23 20:06:23.484063
# Unit test for constructor of class Session
def test_Session():
    name = "test"
    session = Session(name)
    assert(session.path == "test")
    assert(session.headers == {})
    assert(session.cookies == {})
    assert(session.auth == {'type': None, 'username': None, 'password': None})
    assert(session.about == 'HTTPie session file')
    assert(session.helpurl == 'https://httpie.org/doc#sessions')


# Generated at 2022-06-23 20:06:31.220954
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        config_dir=DEFAULT_SESSIONS_DIR,
        session_name='1',
        host='',
        url='http://httpbin.org/tre?e=',
    )
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None,
    }
    assert session.path.name == 'httpbin.org_tre_e_.json'
    assert session.path.parent.name == 'httpbin.org_tre_e_'
    assert not session.path.exists()

# Generated at 2022-06-23 20:06:38.450847
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert Session({}).update_headers({'content-length': 3, 'user-agent': 'test-user-agent', 'cookie': 'test-cookie'}) == {'content-length': '3', 'user-agent': 'test-user-agent'}
    assert Session({}).update_headers({'content-length': '3', 'user-agent': 'test-user-agent', 'cookie': 'test-cookie'}) == {'content-length': '3', 'user-agent': 'test-user-agent'}


# Generated at 2022-06-23 20:06:49.583234
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config = {
        "cookies": {
            "user": "vicky",
            "key": "value"
        },
        "headers": {
            "user-agent": "httpie/1.0.3",
            "accept": "*/*",
            "accept-encoding": "gzip, deflate"
        },
        "auth": {
            "type": "basic",
            "username": None,
            "password": None
        }
    }
    request_headers = {
        "User-Agent": "HTTPie/0.9.8",
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate",
        "Cookie": "user=jack"
    }
    session = Session("test")
    session.update(config)
    session.update_headers

# Generated at 2022-06-23 20:07:00.016466
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sample_session = Session(Path(__file__).parent)
    sample_session.update({
        'cookies': {
            'cookie1': {
                'value': 'value1',
            },
            'cookie2': {
                'value': 'value2',
            },
        }
    })

    assert 'cookie1' in sample_session['cookies']
    sample_session.remove_cookies(['cookie1'])
    assert 'cookie1' not in sample_session['cookies']

    assert 'cookie2' in sample_session['cookies']
    sample_session.remove_cookies(['cookie1', 'cookie2'])
    assert 'cookie2' not in sample_session['cookies']

if __name__ == '__main__':
    test_Session_remove_cookies()

# Generated at 2022-06-23 20:07:08.990167
# Unit test for constructor of class Session
def test_Session():
    path = Path('../../../httpie/sessions').resolve()
    session = Session(path)
    assert session != None
    assert session.about != None
    assert session.helpurl != None
    assert session.path != None
    assert session.headers != None
    assert session.cookies != None
    assert session.auth != None
    assert isinstance(session['headers'], dict)
    assert isinstance(session['cookies'], dict)
    assert isinstance(session['auth'], dict)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {}

# Generated at 2022-06-23 20:07:09.682114
# Unit test for constructor of class Session
def test_Session():
    pass

# Generated at 2022-06-23 20:07:12.991143
# Unit test for constructor of class Session
def test_Session():
    session = Session('cookie.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }

# Generated at 2022-06-23 20:07:15.849046
# Unit test for constructor of class Session
def test_Session():
    sessions = Session('./sessions')
    assert sessions['auth'] == {
            'type': 'basic',
            'username': username,
            'password': password
        }
    assert sessions['cookies'] == None


# Generated at 2022-06-23 20:07:17.682416
# Unit test for constructor of class Session
def test_Session():
    test = Session("test.json")
    assert test is not None

# Generated at 2022-06-23 20:07:24.929190
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session.cookies = RequestsCookieJar()
    session.cookies.set('cookie1','value1')
    session.cookies.set('cookie2','value2')
    session.cookies.set('cookie3','value3')
    session.remove_cookies(['cookie2'])
    for cookie in session.cookies:
        assert cookie.name in ['cookie1','cookie3']
        assert cookie.value in ['value1','value3']



# Generated at 2022-06-23 20:07:34.451825
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from collections import OrderedDict
    from httpie.input import ParseError
    from httpie.cli.parser import parse_items
    from httpie.compat import is_windows
    from httpie.context import Environment

    env = Environment()

# Generated at 2022-06-23 20:07:44.616634
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session_name = 'test.json'
    url = 'http://localhost/index.html'
    session = get_httpie_session(DEFAULT_CONFIG_DIR, session_name, 'localhost', url)
    assert session.path == Path(url).name
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}

    session['headers'] = {'accept-encoding': 'gzip'}
    session['cookies'] = {'key': 'value'}
    session['auth'] = {'type': 'basic', 'username': 'admin', 'password': 'secret'}

    assert session['headers'] == {'accept-encoding': 'gzip'}

# Generated at 2022-06-23 20:07:46.592915
# Unit test for constructor of class Session
def test_Session():
    session = Session('/tmp/test.json')
    assert isinstance(session, Session)
    assert session.headers is not None

# Generated at 2022-06-23 20:07:56.682936
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from requests.cookies import RequestsCookieJar
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp:
        config_dir = Path(temp)
        os.makedirs(config_dir / SESSIONS_DIR_NAME / 'example.com')
        session_path = config_dir / SESSIONS_DIR_NAME / 'example.com' / 'test.json'
        session = get_httpie_session(config_dir, 'test', 'example.com', 'http://example.com')

        with open(session_path, 'w+') as f:
            f.write('{"headers": {"h1": "v1"}}')

        session.update_headers({'H2': 'v2'})

# Generated at 2022-06-23 20:08:02.813002
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('./')
    session_name = 'test'
    host = 'httpbin.org'
    url = 'http://httpbin.org'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert(session.get("headers"))
    assert(session.get("cookies"))
    assert(session.get("auth"))
    session2 = Session('./httpbin_org/test.json')
    assert(session == session2)

# Generated at 2022-06-23 20:08:07.297588
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/path/to/session')
    dict_headers = session.update_headers(b'Auth: basic abcd\nAccept: text')
    # print(dict_headers)
    print(type(dict_headers))

# Generated at 2022-06-23 20:08:17.837368
# Unit test for constructor of class Session
def test_Session():
    S = Session

    # Test 1
    print('\nTest 1')
    s0 = S(path=Path())
    print(s0)
    print()

    # Test 2
    print('\nTest 2')
    s1 = S(path=Path(r'\home\username\path'))
    print(s1)
    print()

    # Test 3
    print('\nTest 3')
    s2 = S(path='/home/username/path')
    print(s2)
    print()

    # Test 4
    print('\nTest 4')
    print(s0.helpurl)
    print()

    # Test 5
    print('\nTest 5')
    print(s0.about)
    print()

    # Test 6
    print('\nTest 6')
    print

# Generated at 2022-06-23 20:08:22.461456
# Unit test for constructor of class Session
def test_Session():
    s = Session("session1.json")
    assert s['auth']['type'] == None
    assert s['auth']['username'] == None
    assert s['auth']['password'] == None
    assert s['cookies'] == {}
    assert s['headers'] == {}


# Generated at 2022-06-23 20:08:29.182645
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    session['headers'] = {'foo': 'bar', 'Content-Type': 'text/html'}
    session.update_headers({'Host': 'www.example.com', 'Content-Type': 'text/html'})
    assert session['headers'] == {'foo': 'bar', 'Host': 'www.example.com', 'Content-Type': 'text/html'}

# Generated at 2022-06-23 20:08:32.793266
# Unit test for constructor of class Session
def test_Session():
    import os
    import tempfile

    s = Session(path = tempfile.mkdtemp())
    s.load()
    assert s.get('headers') == {}
    assert s.get('cookies') == {}
    assert s.get('auth') == {'type': None, 'username': None, 'password': None}
    os.rmdir(tempfile.gettempdir())

# Generated at 2022-06-23 20:08:37.901124
# Unit test for constructor of class Session
def test_Session():
    session = Session('./test_Session.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-23 20:08:46.295959
# Unit test for function get_httpie_session
def test_get_httpie_session():

    # mock session file
    home_dir = os.path.expanduser("~")
    config_dir = Path(home_dir) / '.httpie'
    session_dir = config_dir / SESSIONS_DIR_NAME
    session_path = session_dir / 'test.json'

    # make dirs
    session_dir.mkdir(parents=True, exist_ok=True)

    # mock url
    url = 'http://127.0.0.1:8080/api/'
    host = '127.0.0.1'
    session_name = 'test'


# Generated at 2022-06-23 20:08:51.819333
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/path')
    session['cookies'] = {
        'name1': {'value': 'value1'},
        'name2': {'value': 'value2'},
        'name3': {'value': 'value3'},
        }
    session.remove_cookies(['name2', 'name3'])
    assert session['cookies'] == {'name1': {'value': 'value1'}}


# Generated at 2022-06-23 20:08:59.687593
# Unit test for constructor of class Session
def test_Session():
    session = Session(path='config/new_session.json')
    print(session)

    session.headers['new_header'] = 'new_value'
    session.cookies.set(create_cookie('new_cookie_1', 'new_value_1'))
    session.cookies.set(create_cookie('new_cookie_2', 'new_value_2'))
    session.auth = {
        'type': 'basic',
        'raw_auth': 'none'
    }
    session.save()

# Generated at 2022-06-23 20:09:02.018936
# Unit test for constructor of class Session
def test_Session():
    baseConfig = BaseConfigDict()
    print(baseConfig)

# Generated at 2022-06-23 20:09:10.449174
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.auth import CombinableAuthBase

    # Set up PluginManager with basic auth plugin (used to create session.auth)
    plugin_manager.auth_plugins.update({
        name: cls
        for name, cls in {
            HTTPBasicAuth.name: HTTPBasicAuth,
        }.items()
    })
    plugin_manager.auth_plugins.update({
        name: cls
        for name, cls in {
            HTTPBasicAuth.name: HTTPBasicAuth,
        }.items()
    })

    # create session name and  hostname
    session_name = "test"
    host_name = "localhost"
    url = "https://httpie.org"
    httpie

# Generated at 2022-06-23 20:09:16.496341
# Unit test for constructor of class Session
def test_Session():
    session_file = Session('/path/to/session.json')
    session_file['auth'] = {
        'type': 'OAuth2Implicit',
        'username': 'username',
        'password': 'password',
    }
    session_file['headers'] = {'user-agent': 'chrome'}
    session_file['cookies'] = {
        'name': {
            'value': 'value',
            'path': '/',
            'expires': 'None',
            'secure': True,
        }
    }
    session_file.dump()


# Generated at 2022-06-23 20:09:20.100912
# Unit test for constructor of class Session
def test_Session():
    session = Session("test")
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}



# Generated at 2022-06-23 20:09:23.363100
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import pytest
    from httpie.config import Config
    config_dir = Config().config_dir
    assert get_httpie_session(config_dir, 'test', 'httpie.org', 'httpie.org')

# Generated at 2022-06-23 20:09:30.259819
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {
        'Content-Encoding': 'gzip',
        'Content-Type': 'application/json',
        'If-None-Match': '"6c4e6f3ac638f448a9e4c16df4e0d2a7"',
        'Content-Length': 100,
        'User-Agent': 'HTTPie/0.9.9'
    }
    session = Session('test')
    session.update_headers(headers)
    print(session)
    assert session == {
        'headers': {'Content-Length': '100', 'User-Agent': 'HTTPie/0.9.9'},
        'cookies': {},
        'auth': {'type': None, 'username': None, 'password': None}
    }



# Generated at 2022-06-23 20:09:36.765815
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("blablabla.json")
    session['cookies'] = {
        'cookie1': 'value1',
        'cookie2': 'value2',
        'cookie3': 'value3',
        'cookie4': 'value4'
    }
    names = ['cookie1', 'cookie4']
    session.remove_cookies(names)
    assert 'cookie1' not in session['cookies']
    assert 'cookie4' not in session['cookies']

# Generated at 2022-06-23 20:09:42.472877
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from .helpers import make_config_dir
    config_dir = make_config_dir(DEFAULT_SESSIONS_DIR)
    test_session_name = "test_session"
    test_url = "http://example.com/api/resource"
    test_host = "example.com"
    test_session = get_httpie_session(
        config_dir, session_name=test_session_name, host=test_host, url=test_url)
    assert test_session

# Generated at 2022-06-23 20:09:47.611932
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies_dict = {'session':{'value':'123'}, 'user_id':{'value':'321'}}
    session = Session('')
    session['cookies'] = cookies_dict
    session.remove_cookies(['session'])
    assert session['cookies'] == {'user_id':{'value':'321'}}

# Generated at 2022-06-23 20:09:54.563850
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    session = Session('/home/User/config/sessions/session.json')
    assert session.get('headers') == {}
    assert session.get('cookies') == {}
    assert session.get('auth') == {'type': None, 'username': None, 'password': None}
    assert session.get('path') == Path('/home/User/config/sessions/session.json')
    assert session.helpurl == 'https://httpie.org/doc#sessions'
    assert session.about == 'HTTPie session file'


# Generated at 2022-06-23 20:09:59.702897
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    
    session = Session('./test.json')
    session.update_headers({'accept': '*/*', 'accept-encoding': 'gzip'})
    expected_headers = {'accept': '*/*', 'accept-encoding': 'gzip'}
    assert session.headers == expected_headers


# Generated at 2022-06-23 20:10:05.847317
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = "session_name"
    host = "host"
    url = "url"

    session = get_httpie_session(
        config_dir,
        session_name,
        host,
        url,
    )

    session.remove_cookies('SESSIONID')

# Generated at 2022-06-23 20:10:09.380919
# Unit test for constructor of class Session
def test_Session():
    path = "C:\\Users\\Shubham\\AppData\\Roaming\\httpie\\sessions\\github.com"
    session = Session(path)
    assert session.headers == {}
    assert session.auth == None
    assert session.cookies == RequestsCookieJar()

# Generated at 2022-06-23 20:10:10.936919
# Unit test for constructor of class Session
def test_Session():
    assert Session('a')


# Generated at 2022-06-23 20:10:19.061644
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("session_test")
    s['cookies'] = {
        'name1': {'value': 'value1'},
        'name2': {'value': 'value2'},
        'name3': {'value': 'value3'},
    }
    s.remove_cookies(['name1', 'name2'])

    assert s['cookies'] == {
        'name3': {'value': 'value3'},
    }

# Generated at 2022-06-23 20:10:27.848646
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Test for case when session_name is a path
    config_dir = DEFAULT_CONFIG_DIR 
    session_name = '/mnt/c/Users/mattr/Documents/test.json'
    host = None
    url = 'https://httpbin.org/get'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert isinstance(session, Session)
    assert session.path == session_name

    # Test for case when session_name is a name
    config_dir = DEFAULT_CONFIG_DIR 
    session_name = 'test'
    host = None
    url = 'https://httpbin.org/get'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert isinstance(session, Session)

# Generated at 2022-06-23 20:10:37.612925
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import json
    import requests

    config_dir = DEFAULT_SESSIONS_DIR
    session_name = 'dummy-session'
    host = 'http://myhost.com'
    url = 'http://myhost.com/some_url'

    auth_dict = {'type': 'basic', 'raw_auth': 'user:pass'}
    string_key = 'Ο συγγραφέας είπε'
    string_value = 'Χαίρετε Ἑλλάδα'
    check_cookies_value = 'some_value'
    check_cookies_key = 'check'



# Generated at 2022-06-23 20:10:40.111263
# Unit test for function get_httpie_session
def test_get_httpie_session():
    result = get_httpie_session(Path('.'), 'foo', '', '')
    assert result.path == Path('./sessions/localhost/foo.json')
    assert isinstance(result, Session)

# Generated at 2022-06-23 20:10:46.562544
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # 1. Initialize Session object
    session = Session("test.json")

    # 2. Test update_headers() function
    session.update_headers({'name': 'value'})

    assert(session.get('headers') == {'name': 'value'})

    # Test update_headers() function
    session.update_headers({'name': 'value2'})

    assert(session.get('headers') == {'name': 'value2'})



# Generated at 2022-06-23 20:10:55.199967
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(".")
    session.load_dict({
        'cookies': {
            'abc': {'value':'abc_val'},
            'def': {'value':'def_val'},
        }
    })
    session.remove_cookies(['abc'])
    assert session['cookies'] == {'def': {'value': 'def_val'}}
    session.remove_cookies(['def'])
    assert session['cookies'] == {}



# Generated at 2022-06-23 20:11:02.940055
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path="test")
    session.update_headers(RequestHeadersDict({'header1': 'value1', 'header2': 'value2'}))
    assert session.headers == {'header1': 'value1', 'header2': 'value2'}
    session.update_headers(RequestHeadersDict({'Cookie': 'name1=value1; name2=value2', 'If-modified': '19/07/2019'}))
    assert session.headers == {'header1': 'value1', 'header2': 'value2'}
    assert len(session.cookies) == 2

# Generated at 2022-06-23 20:11:13.578906
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # None inputs
    s = get_httpie_session(None, None, None, None)
    assert s['headers'] == {}

    # Invalid session name
    s = get_httpie_session(
        DEFAULT_SESSIONS_DIR, '../../../invalid', None, None)
    assert s['headers'] == {}
    s = get_httpie_session(
        DEFAULT_SESSIONS_DIR, 'invalid/../../../invalid', None, None)
    assert s['headers'] == {}
    s = get_httpie_session(
        '/invalid/../../../invalid',
        '../../../invalid', None, None)
    assert s['headers'] == {}

# Generated at 2022-06-23 20:11:15.970534
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.context import Environment
    print(Environment().config_dir)
    session = get_httpie_session(Environment().config_dir, 'session', '', 'www.google.com')
    session.save()

# Generated at 2022-06-23 20:11:22.430939
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict()
    session = {"headers":{"name":"zhou"}}
    request_headers.update(session)
    request_headers.update({"headers":{"name":"xiaoming"}})
    request_headers.update({'User-Agent':'HTTPie/1.0.0'})
    request_headers.update({'if-range':'HTTPie/1.0.0'})
    request_headers.update({'Range':'bytes=0-1024'})
    request_headers.update({'Cookie':'HTTPie/1.0.0'})
    session_new = Session("/root/.config/httpie/sessions/www.baidu.com/www.baidu.com.json")
    session_new.update_headers(request_headers)


# Generated at 2022-06-23 20:11:24.665526
# Unit test for constructor of class Session
def test_Session():
    session = Session(Path("dummy.json"))
    assert session.helpurl == 'https://httpie.org/doc#sessions'

# Generated at 2022-06-23 20:11:27.564104
# Unit test for constructor of class Session
def test_Session():
    session = Session('/test/test')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

