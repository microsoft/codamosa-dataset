

# Generated at 2022-06-23 20:01:31.432670
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    req_headers = {
        "Accept": "text/html",
        "Accept-Charset": "utf-8,ISO-8859-1;q=0.5",
        "Accept-Language": "eo,en",
        "Host": "host.com",
        "Cookie": "jsessionid=fee818ac-5e5e-4b58-b5a9-57cc499b31c1;\
                    ai_user=VGbp6|2019-11-28T16:32:14.047Z",
        "If-None-Match": "W/\"c881b-NZhZOjoOaYXKWbxsTdzqO3qjDwO8\""
    }
    session = Session('path')
    session.update_headers(req_headers)

# Generated at 2022-06-23 20:01:40.622240
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("testdata/sessions/example.json")
    headers0 = {
        'A': 'a',
        'B': 'b',
        'Cookie': 'c=d; e=f; g=h',
        'User-agent': 'HTTPie/0.9.9',
        'Content-type': 'application/json'
    }
    session.update_headers(headers0)
    headers1 = session.headers
    assert headers1['A'] == 'a'
    assert headers1['B'] == 'b'
    assert headers1['Content-type'] == 'application/json'
    assert not session.cookies
    assert 'User-agent' not in headers1

    # Verify that method Session.update_headers is idempotent
    session.update_headers(headers0)

# Generated at 2022-06-23 20:01:45.318476
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from httpie.cli.parser import get_parser

    parser = get_parser()
    args = parser.parse_args([])
    config_dir = Path(TemporaryDirectory().name)

    session = get_httpie_session(config_dir, 'example.com', 'http://www.example.com')

    assert session is not None, 'session'

# Generated at 2022-06-23 20:01:56.888887
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('.')
    headers = RequestHeadersDict()
    headers['host'] = 'host'
    headers['Content-Type'] = 'Content-Type'
    headers['If-Match'] = 'If-Match'
    session.update_headers(headers)
    assert session.headers == {'host': 'host','Content-Type': 'Content-Type','If-Match': 'If-Match'}

    # cookies
    headers['Cookie'] = 'Cookie'
    session.update_headers(headers)
    assert session.headers == {'host': 'host','Content-Type': 'Content-Type','If-Match': 'If-Match'}
    assert session['cookies'] == {'Cookie': {'value': 'Cookie'}}

    # user-agent

# Generated at 2022-06-23 20:02:00.315173
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Arrange
    session = Session(path=Path('/foo/bar.json'))
    session.load()
    headers = RequestHeadersDict({})
    # Act
    session.update_headers(headers)
    # Assert
    assert session.headers == RequestHeadersDict({})

# Generated at 2022-06-23 20:02:03.597347
# Unit test for function get_httpie_session
def test_get_httpie_session():
        x=get_httpie_session(DEFAULT_CONFIG_DIR,"sessions","httpbin.org","https://httpbin.org");
        assert type(x) == Session

# Generated at 2022-06-23 20:02:09.412855
# Unit test for constructor of class Session
def test_Session():
    session = Session('test.json')
    assert session.get('headers') == {}
    assert session.get('cookies') == {}
    assert session.get('auth') == {
        'type': None,
        'username': None,
        'password': None
    }


if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-23 20:02:17.666663
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    from httpie.compat import is_windows
    
    config_dir = Path(SESSIONS_DIR_NAME) / 'host1'
    host = 'host1'
    url = 'https://host1:8443'
    session_name = 'unix_localhost'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.path.as_posix() == (
            (config_dir / 'unix_localhost.json').as_posix())
    validate_path = re.compile(r'^\\{0,2}[a-zA-Z]:\\|^\\')

# Generated at 2022-06-23 20:02:28.997259
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session(path=DEFAULT_SESSIONS_DIR)
    sess.remove_cookies([])
    assert sess['cookies'] == {}
    sess['cookies']['abc'] = 'def'
    assert sess['cookies'] == {'abc': 'def'}
    sess.remove_cookies(['abc'])
    assert sess['cookies'] == {}
    sess['cookies']['abc'] = 'def'
    sess['cookies']['def'] = 'ghi'
    sess.remove_cookies(['abc', 'def'])
    assert sess['cookies'] == {}
    sess['cookies']['abc'] = 'def'
    sess['cookies']['def'] = 'ghi'
    sess.remove_

# Generated at 2022-06-23 20:02:34.695543
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='./test')
    session.from_dict({
        'headers': {
            'Content-Type': 'application/json'
        },
        'cookies': {
            'foo': {'value': 'bar'},
            'baz': {'value': 'qux'},
        },
        'auth': {
            'type': 'basic',
            'raw_auth': 'foo:bar'
        },
    })
    session.remove_cookies(['baz'])
    assert session.cookies['foo'].value == 'bar'
    assert 'baz' not in session.cookies

# Generated at 2022-06-23 20:02:40.965564
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session.cookies = RequestsCookieJar()
    session.cookies.set('cookie_name_1', 'cookie_value_1')
    session.cookies.set('cookie_name_2', 'cookie_value_2')
    session['cookies']['cookie_name_3'] = {}
    session.remove_cookies(['cookie_name_1', 'cookie_name_2'])
    assert len(session.cookies) == 1
    assert session['cookies']['cookie_name_3']

# Generated at 2022-06-23 20:02:45.314474
# Unit test for constructor of class Session
def test_Session():
    session = Session(path='./test_session.json')
    assert session.path.exists() == False
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-23 20:02:56.000319
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("./test-session.json")
    # Example copied from
    # https://developer.mozilla.org/en-US/docs/Web/HTTP/Cookies
    # Name: SID
    # Value: 31d4d96e407aad42
    # Domain: example.com
    # Path: /
    # Expires: Session cookie (expires when browser closes)
    # Secure: Yes
    # HttpOnly: Yes
    # SameSite: Lax
    cookies = "SID=31d4d96e407aad42; Domain=example.com; Path=/; Expires=; Secure; HttpOnly; SameSite=Lax"
    request_headers = {"Cookie": cookies}
    session.update_headers(request_headers)
    assert(session.headers == {})

# Generated at 2022-06-23 20:03:03.460097
# Unit test for constructor of class Session
def test_Session():
    session_name = 'test_Session_1'
    if VALID_SESSION_NAME_PATTERN.match(session_name) is None:
        raise ValueError('Invalid session name')
    host = 'www.example.com'
    url = 'https://www.example.com'
    config_dir = '~'
    assert get_httpie_session(Path(config_dir), session_name, host, url)


# Generated at 2022-06-23 20:03:09.959129
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session(path='sess')
    sess['cookies']={'name1':{'value':'value1'},'name2':{'value':'value2'}}
    assert(len(sess['cookies'])==2)
    sess.remove_cookies(['name1'])
    assert(len(sess['cookies'])==1)
    assert('name1' not in sess['cookies'])

# Generated at 2022-06-23 20:03:11.763235
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {
        'user-agent': 'HTTPie/1.1'
    }
    session = Session('path')
    session.update_headers(headers)
    assert headers == session.headers



# Generated at 2022-06-23 20:03:19.658018
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path("/tmp")
    session_name = "test_session"
    host = "example.com"
    url = "https://example.com/api/v3/search?q=test"
    session = get_httpie_session(config_dir, session_name, host, url)
    assert(type(session) == Session)
    assert(session.path == Path("/tmp/sessions/example.com/test_session.json"))


# Generated at 2022-06-23 20:03:20.833058
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session()


# Generated at 2022-06-23 20:03:24.469219
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
   session = Session(path=Path(""))
   session['cookies'] = {"cook1" : {}, "cook2": {}, "cook3": {}}
   session.remove_cookies(["cook1", "cook2"])
   assert session['cookies'] == {"cook3":{}}

# Generated at 2022-06-23 20:03:32.084256
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers({'header1': 'value'})
    assert session['headers'] == {'header1': 'value'}
    session.update_headers({'header2': 'value'})
    assert session['headers'] == {'header1': 'value', 'header2': 'value'}
    session.update_headers({'header2': 'value'})
    assert session['headers'] == {'header1': 'value', 'header2': 'value'}
    session.update_headers({'header2': 'new value'})
    assert session['headers'] == {'header1': 'value', 'header2': 'new value'}

# Generated at 2022-06-23 20:03:37.455756
# Unit test for constructor of class Session
def test_Session():
    session_path = "sessions/localhost/test.json"
    session = Session(path=session_path)
    assert session.helpurl == 'https://httpie.org/doc#sessions'
    assert session.about == 'HTTPie session file'
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }

test_Session()

# Generated at 2022-06-23 20:03:45.565822
# Unit test for constructor of class Session
def test_Session():
    try:
        os.remove(DEFAULT_SESSIONS_DIR / 'test.json')
    except FileNotFoundError:
        pass
    session = Session(DEFAULT_SESSIONS_DIR / 'test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}
    session.save()
    session_new = Session(DEFAULT_SESSIONS_DIR / 'test.json')
    session_new.load()
    assert session_new['headers'] == {}
    assert session_new['cookies'] == {}
    assert session_new['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-23 20:03:50.755634
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Testing the update_headers() method of class Session
    url="www.v2ex.com"
    request_headers={"User-Agent":"test"}

    s=Session(path="test.json")
    s.update_headers(request_headers)

    assert s['headers'] == {'user-agent':'test'}

# Generated at 2022-06-23 20:03:57.100295
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = DEFAULT_SESSIONS_DIR / 'localhost' / 'session_a.json'
    session = Session(str(session_path))
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2', 'cookie3': 'value3'}
    session.remove_cookies(['cookie1', 'cookie4'])
    assert session['cookies'] == {'cookie2': 'value2', 'cookie3': 'value3'}

# Generated at 2022-06-23 20:04:00.406454
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('te')
    s['cookies'] = {'a': '1', 'b': '2', 'c': '3'}
    s.remove_cookies({'a', 'c'})
    assert s['cookies'] == {'b': '2'}



# Generated at 2022-06-23 20:04:03.992171
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=".test.json")
    session['cookies'] = {'test1': {'value': 'test1_value'}, 'test2': {'value': 'test2_value'}}
    session.remove_cookies(['test1', 'test3'])
    assert ('test1' not in session['cookies'])
    assert ('test2' in session['cookies'])



# Generated at 2022-06-23 20:04:11.063175
# Unit test for function get_httpie_session
def test_get_httpie_session():
    _cookies_file = "cookies.txt"
    session_name = 'test'
    default_sessions_dir = DEFAULT_SESSIONS_DIR # "/Users/jingjing/work/httpie/httpie/.httpie"
    host = 'localhost'
    url = 'localhost'

    path = default_sessions_dir / SESSIONS_DIR_NAME / hostname / f'{session_name}.json'

    session = Session(path)
    session.load()
    print(session)

# Generated at 2022-06-23 20:04:18.175132
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    config = Config()
    session = get_httpie_session(config.config_dir, 'test', 'www.example.com', 'http://www.exaple.com')
    assert session['headers'] == {}, "headers is empty"
    assert session['cookies'] == {}, "cookies is empty"
    assert session['auth'] == {'type': None, 'username': None, 'password': None}
    assert session.path == config.config_dir / 'sessions/www_example_com/test.json'


# Generated at 2022-06-23 20:04:23.898105
# Unit test for constructor of class Session
def test_Session():
    session = Session(path=DEFAULT_SESSIONS_DIR / 'session.json')
    session.load()
    assert session.__dict__ == {}
    session['headers'] = {}
    session['cookies'] = {}
    session['auth'] = {
            'type': None,
            'username': None,
            'password': None
        }
    session.save()

    assert session.headers == {}
    assert session.cookies == {}
    assert session.auth is None
    

# Generated at 2022-06-23 20:04:34.606291
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print('\n\n-------------------------\n')
    print('test method update_headers')
    session = Session(path=DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME)

    print('\n\nold session:')
    print(session)

    session.update_headers(request_headers={
        'Accept-Charset': 'utf-8',  # new
        'Content-Length': None,  # ignored
        'Foo': 'Bar',  # new
        'Content-Type': 'application/json',  # ignored
        'Baz': 'Qux',  # new
        'Cache-Control': 'no-cache',  # new
    })

    print('\n\nnew session:')
    print(session)



# Generated at 2022-06-23 20:04:42.905517
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://test_httpie.com/'
    host = 'test_host.com'
    session_name = 'test_session'

    config_dir = Path(__file__).parent

    path = config_dir / SESSIONS_DIR_NAME / 'test_host_com' / (
        f'{session_name}.json'
    )

    test_session = get_httpie_session(config_dir, session_name, host, url)
    assert path == test_session.path
    assert isinstance(test_session, Session)

    # test with None values
    test_session = get_httpie_session(config_dir, session_name, '', url)
    assert path == test_session.path
    assert isinstance(test_session, Session)

# Generated at 2022-06-23 20:04:48.441950
# Unit test for constructor of class Session
def test_Session():
    path = DEFAULT_SESSIONS_DIR / "www.google.com" / "google.json"
    session = Session(path)
    assert session == {
        "headers": {},
        "cookies": {},
        "auth": {
            "type": None,
            "username": None,
            "password": None
        }
    }


# Generated at 2022-06-23 20:04:51.511145
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./session.json')
    session.load()
    session.remove_cookies(['cookie1', 'cookie2'])
    assert session['cookies'] == {}


# Generated at 2022-06-23 20:05:00.462689
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.plugins.builtin import BuiltinAuthPlugin
    session = Session('test')
    url = 'http://example.com'
    request_headers = {'x-header': 'test'}
    user_agent_header = 'User-Agent'
    simple_cookie = SimpleCookie()
    name = 'my_cookie'
    value = 'my_value'
    simple_cookie[name] = value
    for cookie_name, morsel in simple_cookie.items():
        session['cookies'][cookie_name] = {'value': morsel.value}
    request_headers['Cookie'] = simple_cookie.output(header='', sep=' ')

# Generated at 2022-06-23 20:05:04.629904
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/Users/azk/.config/httpie')
    session_name = 'test'
    host = '127.0.0.1'
    url = 'http://127.0.0.1/test'
    get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-23 20:05:08.928814
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    s.cookies = {'test' : {'value' : 'x', 'path' : '/path'}}
    s.remove_cookies({'test'})
    assert s.cookies.get('test') == None

# Generated at 2022-06-23 20:05:16.625626
# Unit test for constructor of class Session
def test_Session():
    from pytest import raises
    from httpie.plugins.builtin.auth import BasicAuth
    from httpie.plugins.builtin.auth import DigestAuth
    from pathlib import Path
    data = {"headers": {
        "Accept-Encoding": "gzip, deflate"
    },
    "cookies": {
        "UserID": {
            "value": "1234",
            "path": "/"
        },
        "Password": {
            "value": "AAAA",
            "path": "/",
            "expires": "2019-05-29"
        }
    },
    "auth": {
        "type": "Basic",
        "username": "Test",
        "password": "test"
    }
    }

# Generated at 2022-06-23 20:05:24.098624
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_name = 'c'
    s = Session('/sessions/host_port/s.json')
    s.cookies = RequestsCookieJar()
    s.cookies.set_cookie(create_cookie(cookie_name, 'c'))
    assert len(s.cookies) == 1

    s.remove_cookies((cookie_name,))
    assert len(s.cookies) == 0




# Generated at 2022-06-23 20:05:33.040075
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='path')

    # Test for setting headers
    session.update_headers(RequestHeadersDict({'X-Header': 'value'}))
    assert session.headers == RequestHeadersDict({'x-header': 'value'})

    # Test for setting cookies
    session.update_headers(RequestHeadersDict({'Cookie': 'a=b'}))
    assert session['cookies'] == {'a': {'value': 'b'}}

    # Test for ignoring some headers
    session.update_headers(RequestHeadersDict({'Content-Type': 'application/json'}))
    assert 'content-type' not in session.headers

    # Test for cookie overwriting
    session.update_headers(RequestHeadersDict({'Cookie': 'a=c'}))

# Generated at 2022-06-23 20:05:36.823907
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {
        'cookie1': {},
        'cookie2': {},
        'cookie3': {},
    }
    session = Session(path='/')
    session['cookies'] = cookies
    session.remove_cookies(['cookie2', 'cookie3'])
    assert session['cookies'] == {
        'cookie1': {},
    }

# Generated at 2022-06-23 20:05:42.499783
# Unit test for constructor of class Session
def test_Session():
    s = Session('httpie.json')
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}
    assert s.path == Path('httpie.json')
    assert s.helpurl == 'https://httpie.org/doc#sessions'
    assert s.about == 'HTTPie session file'



# Generated at 2022-06-23 20:05:45.435563
# Unit test for constructor of class Session
def test_Session():
    main_dir = Path.home()
    host = 'github.com'
    url = 'http://github.com'
    session_name = 'session'
    assert get_httpie_session(main_dir, session_name, host, url)

# Generated at 2022-06-23 20:05:51.703270
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("/user/carol/sessions.json")
    session["cookies"] = {
        "a": {
            "value": "1",
            "path": "/path/",
            "domain": ".domain.com",
            "expires": "2020-05-05T05:05:05",
            "secure": False
        },
        "b": {
            "value": "2",
            "path": "/path/",
            "domain": ".domain.com",
            "expires": "2020-05-05T05:05:05",
            "secure": False
        }
    }
    session.remove_cookies(["a"])

# Generated at 2022-06-23 20:06:01.596434
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import pytest
    from httpie import ExitStatus

    def run(args):
        headers, _, exit_status = http(*args, session='test/test')
        assert exit_status == ExitStatus.OK
        return headers

    httpbin_both = 'httpbin.org/cookies/set?k1=v1&k2=v2'
    httpbin_one = 'httpbin.org/cookies/set?k1=v1'
    httpbin_none = 'httpbin.org/headers'

    def _test_cookies_in_headers(headers):
        headers = dict(headers)
        assert headers['Cookie'] == (
            'a=b; c=d; k1=v1; k2=v2; k3=v3')


# Generated at 2022-06-23 20:06:11.757435
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import httpie.cli.argtypes as argtypes
    from httpie.cli.dicts import RequestHeadersDict

    session = Session('session')
    request_headers = RequestHeadersDict()
    session.update_headers(request_headers)

    assert len(session['headers']) == 0

    request_headers['Content-Type'] = 'application/json'
    request_headers['Accept-Encoding'] = 'gzip'
    request_headers['Set-Cookie'] = 'foo=bar; version=1; domain=localhost; port=80'
    session.update_headers(request_headers)

    assert session['headers']['Accept-Encoding'] == 'gzip'
    assert len(session['cookies']) == 1
    assert session['cookies']['foo']['value'] == 'bar'




# Generated at 2022-06-23 20:06:14.428114
# Unit test for constructor of class Session
def test_Session():
    session_path = '~/.config/httpie/sessions/localhost/sessions.json'
    session_object = Session(session_path)
    assert type(session_object['headers']) is dict
    assert type(session_object['cookies']) is dict
    assert type(session_object['auth']) is dict

# Generated at 2022-06-23 20:06:25.756579
# Unit test for function get_httpie_session
def test_get_httpie_session():
    path=('session.json')
    name='session'
    host='127.0.0.1:8080'
    url='http://127.0.0.1:8080/path'
    session=Session(path)
    session.load()
    session.update_headers(url)
    assert session.path==('session.json'),'The session path is session.json'
    assert session.name==('session'),'The session name is session'
    assert session.host==('127.0.0.1:8080'),'The session host is 127.0.0.1:8080'
    assert session.url==('http://127.0.0.1:8080/path'),'The session url is 127.0.0.1:8080'

# Generated at 2022-06-23 20:06:30.676920
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    config_dir = Path(__file__).parent / 'tests' / 'data' / 'config'
    session_name = 'session_1'
    url = 'https://example.com'
    session = get_httpie_session(config_dir, session_name, None, url)
    assert isinstance(session, Session)
    assert session['cookies'] == {'username': 'foo', 'password': 'bar'}


# Generated at 2022-06-23 20:06:32.177000
# Unit test for constructor of class Session
def test_Session():
    s = Session(Path('./'))
    print(s.dict)


# Generated at 2022-06-23 20:06:36.357422
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {
        'cookie1': {},
        'cookie2': {},
        'cookie3': {}
    }
    session.remove_cookies(['cookie1', 'cookie2'])
    assert session['cookies'] == {'cookie3': {}}

# Generated at 2022-06-23 20:06:44.124834
# Unit test for constructor of class Session
def test_Session():

    import json
    config_dir = DEFAULT_CONFIG_DIR
    session_name = "session_1.json"

    # Test that the file was created
    session = get_httpie_session(config_dir, session_name, "www.google.com", "https://httpie.org/")
    path = str(DEFAULT_SESSIONS_DIR / "www_google_com" / "session_1.json")
    assert os.path.exists(path) is True
    os.remove(path)

    # Test that the good file was loaded
    get_httpie_session(config_dir, "www.google.com/session_1", None, "https://httpie.org/")
    assert os.path.exists(path) is True
    os.remove(path)



# Generated at 2022-06-23 20:06:47.159626
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("./test_session_file.json")
    session = session.remove_cookies(names=['test1', 'test2'])


# Generated at 2022-06-23 20:06:52.195022
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    path = Path("/Users/.httpie/sessions/localhost/test.json")
    temp = Session(path)
    assert temp['headers'] == {}
    assert temp['cookies'] == {}
    assert temp['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-23 20:06:58.918861
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = 'D:\\Project\\httpie-plugin-session\\tests\\session.json'
    session_name = 'test'
    session = Session(session_path)
    session.load()
    assert len(session['cookies']) == 3
    session.remove_cookies(['PHPSESSID', 'foo'])
    assert len(session['cookies']) == 1
    assert 'PHPSESSID' not in session['cookies']
    assert 'foo' not in session['cookies']



# Generated at 2022-06-23 20:07:06.690819
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(None)
    headers = RequestHeadersDict(s['headers'])
    headers['content-type'] = 'application/json'
    request_headers = RequestHeadersDict(headers)
    request_headers['content-length'] = '0'
    request_headers['content-length'] = b'0'
    s.update_headers(request_headers)
    for i in request_headers:
        print(i)
    pass



# Generated at 2022-06-23 20:07:11.821436
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session1 = Session(path = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / "test")
    request_headers = [
        (['authorization','Basic aGk6aGk=']),
        (['test','test'])
    ]
    session1.update_headers(request_headers)
    print(session1)


# Generated at 2022-06-23 20:07:14.147201
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('temp.json')
    s['cookies'] = {1: 'a'}
    s.remove_cookies([1])
    print(s)



# Generated at 2022-06-23 20:07:21.092960
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Checking the remove_cookies method of class Session
    """
    cookies = {
        'somecookie': {
            'value': 'somevalue',
            'path': '/',
            'secure': False,
            'expires': None
        },
        'someothercookie': {
            'value': 'somevalue',
            'path': '/',
            'secure': False,
            'expires': None
        }
    }
    s = Session(path='some/path')
    s['cookies']=cookies
    assert s['cookies'] == cookies
    s.remove_cookies(['somecookie'])
    expected_cookies = {'someothercookie': {'value': 'somevalue', 'path': '/', 'secure': False, 'expires': None}}
    assert s['cookies'] == expected

# Generated at 2022-06-23 20:07:31.553016
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from requests import cookies
    from httpie.compat import str

    class loop(object):

        def __init__(self, data):
            self.data = data

        def __iter__(self):
            return self

        def __next__(self):
            try:
                return next(self.data)
            except:
                raise StopIteration

    class RequestHeadersDict(dict):
        pass


# Generated at 2022-06-23 20:07:36.442149
# Unit test for constructor of class Session
def test_Session():
    session = Session('json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] ==  {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-23 20:07:41.870881
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies')
    session['cookies'] = {'a':'b', 'c': 'd'}
    assert session['cookies'] == {'a':'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-23 20:07:45.690688
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('test')
    sess['cookies'] = {'c1': 'cookie1',
                       'c2': 'cookie2'}
    sess.remove_cookies(('c1', 'c3'))
    assert sess['cookies'] == {'c2': 'cookie2'}



# Generated at 2022-06-23 20:07:52.899086
# Unit test for constructor of class Session
def test_Session():
    from httpie.sessions import Session
    import json
    import os
    import shutil
    import tempfile
    import textwrap

    _json_data = textwrap.dedent("""
    {
      "helpurl": "https://httpie.org/doc#sessions",
      "about": "HTTPie session file",
      "auth": {
        "type": "basic",
        "raw_auth": "demo:demo"
      },
      "cookies": {
        "cookie1": {
          "value": "test1"
        },
        "cookie2": {
          "value": "test2"
        }
      },
      "headers": {
        "h1": "v1",
        "h2": "v2"
      }
    }
    """).strip()

    tmp

# Generated at 2022-06-23 20:08:01.082685
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """Test for method update_headers of class Session"""
    from httpie.config import base_dir
    from httpie.plugins.resolve.resolver import DEFAULT_RESOLVER_PLUGIN

    # Set the default resolver plugin to 'sessions'
    DEFAULT_RESOLVER_PLUGIN.name = 'sessions'
    # Create a session
    sess_dir = base_dir / SESSIONS_DIR_NAME
    sess_dir.mkdir(exist_ok=True)
    sess_path = sess_dir / 'localhost.json'
    sess = Session(sess_path)

    # Create an ordinary request
    req = RequestHeadersDict()
    req['cookie'] = 'A_Cookie=foo; Expires=Wed, 09 Jun 2021 10:18:14 GMT'
    req

# Generated at 2022-06-23 20:08:02.209783
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert "true" in "true"


# Generated at 2022-06-23 20:08:12.147387
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import configparser

    config_dir = os.path.join(os.path.dirname(__file__), 'testutils', 'config_dir')
    config_path = os.path.join(config_dir, 'config.ini')

    config = configparser.ConfigParser()
    config.read(config_path)

    url = config['get_httpie_session']['url']
    session_name = config['get_httpie_session']['session_name']
    host = config['get_httpie_session']['host']
    expected_session_path = config['get_httpie_session']['expected_session_path']

    session = get_httpie_session(config_dir, session_name, host, url)
    actual_session_path = str(session.path)

    assert expected_

# Generated at 2022-06-23 20:08:14.844259
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Configuring Session
    session = Session("test.json")
    session.update_headers({"Accept": "application/json"})
    assert session.headers == {"Accept": "application/json"}

# Generated at 2022-06-23 20:08:25.172299
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from tempfile import TemporaryDirectory
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.client import JSON_ACCEPT
    from httpie.plugins import AuthPlugin, registry

    class MyAuthPlugin(AuthPlugin):
        auth_type = 'custom-auth'
        auth_parse = False
        auth_require = False
        auth_export = True

        def get_auth(self, username, password):
            return auth

    @registry.register
    class MyAuthPlugin2(AuthPlugin):
        auth_type = 'custom-auth2'
        auth_parse = True
        auth_require = False
        auth_export = True

        def get_auth(self, username, password):
            return auth

    url = 'https://httpbin.org/get?a=1'

# Generated at 2022-06-23 20:08:33.394333
# Unit test for constructor of class Session
def test_Session():
    session_dict = {
        'headers': {
            'Content-type': 'application/json',
            'Accept': 'application/json',
        },
        'cookies': {
            'token': {'value': '123456'},
            'session': {'value': '654321'},
        },
        'auth': {
            'type': 'Basic',
            'raw_auth': 'guest:welcome'
        }
    }
    session = Session(path='./test_session')
    session.load()
    assert session == session_dict

# Generated at 2022-06-23 20:08:40.864212
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('~/.config/httpie')
    session_name = 'test_session'
    host = 'localhost'
    url = 'http://localhost:80/test'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.is_new()
    session.save()
    session = get_httpie_session(config_dir, session_name, host, url)
    assert not session.is_new()

# Generated at 2022-06-23 20:08:47.952747
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # if no session name given, return None
    assert get_httpie_session('', '', None, '') is None
    # given session name 'foo/bar' is invalid, error message as expected
    expected_error = 'invalid session name: "foo/bar"'
    assert 'foo/bar' not in VALID_SESSION_NAME_PATTERN.pattern
    try:
        get_httpie_session('', 'foo/bar', None, '')
    except ValueError as e:
        assert e.args[0] == expected_error

# Generated at 2022-06-23 20:08:56.014375
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = Path("./test_cookies.json")
    try:
        session_path.unlink()
    except FileNotFoundError:
        pass
    session = Session(session_path)
    assert session['cookies'] == {}

    session['cookies'] = {'my_key1': 'my_value1', 'my_key2': 'my_value2', 'my_key3': 'my_value3'}
    assert session['cookies'] == {'my_key1': 'my_value1', 'my_key2': 'my_value2', 'my_key3': 'my_value3'}
    session.remove_cookies(['my_key1', 'my_key3'])
    assert session['cookies'] == {'my_key2': 'my_value2'}

# Generated at 2022-06-23 20:09:01.652200
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session.update({'cookies': {'test_cookie': {'test_value': 'test'},
                                'test_cookie2': {'test_value': 'test'}}})
    assert len(session['cookies']) == 2
    session.remove_cookies(['test_cookie'])
    assert len(session['cookies']) == 1
    assert session['cookies'] == {'test_cookie2': {'test_value': 'test'}}

# Generated at 2022-06-23 20:09:09.762061
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.session import Session
    plugin_manager.load_builtin_plugins()
    config = Config({'skip_request_headers': 'User-Agent'})
    env = Environment(config=config)
    session = Session({})
    env.session = session
    session.update_headers(RequestHeadersDict({"name":"value"}))
    print(session.headers)

# Generated at 2022-06-23 20:09:15.998694
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    session.update_headers({'name': 'value'})
    assert session['headers'] == {'name': 'value'}

    session.update_headers({'name': 'value2'})
    assert session['headers'] == {'name': 'value2'}

    session.update_headers({'name': None})
    assert session['headers'] == {}

    session.update_headers({'SET-COOKIE': 'SESSION=hai'})
    assert session == {
            'headers': {},
            'cookies': {
                'SESSION': {'value': 'hai'}
            }
        }


# Generated at 2022-06-23 20:09:18.734582
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Arrange
    session = Session('/tmp/some_file.json')
    request_headers = RequestHeadersDict({"content_type": "application/json"})
    # Act
    session.update_headers(request_headers)
    # Assert
    # Check if content_type is not in session headers
    assert 'content_type' not in session['headers']

# Generated at 2022-06-23 20:09:25.859812
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    path = '/tmp/httpie-test_Session_remove_cookies.json'
    session = Session(path)
    session['cookies'] = {'a': {'path': '/'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {}
    session['cookies'] = {'a': {'path': '/'}}
    session.remove_cookies(['b'])
    assert session['cookies'] == {'a': {'path': '/'}}


# Generated at 2022-06-23 20:09:38.002316
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert 'sessions' in SESSIONS_DIR_NAME
    assert 'sessions' in str(DEFAULT_SESSIONS_DIR)
    assert VALID_SESSION_NAME_PATTERN.match('sessions')
    assert not VALID_SESSION_NAME_PATTERN.match('sessions/')
    assert len(SESSION_IGNORED_HEADER_PREFIXES) == 2
    assert 'Content-' in SESSION_IGNORED_HEADER_PREFIXES
    assert 'If-' in SESSION_IGNORED_HEADER_PREFIXES

    # get_httpie_session(config_dir: Path, session_name: str, host: Optional[str], url: str) -> Session:
    # assert 'sessions' in SESSIONS_DIR_NAME

# Generated at 2022-06-23 20:09:40.670668
# Unit test for function get_httpie_session
def test_get_httpie_session():
    path = get_httpie_session('~/.httpie', 'test_h')
    print(path)

# Generated at 2022-06-23 20:09:51.776293
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/test')

    headers = {
        'Host': 'httpbin.org',
        'Connection': 'keep-alive',
        'User-Agent': 'HTTPie/v0.9.2',
        'Content-Length': '19',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US,en;q=0.8'
    }

    session.update_headers(headers)

# Generated at 2022-06-23 20:09:52.616166
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("")
    assert not session.remove_cookies("")

# Generated at 2022-06-23 20:09:55.245754
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {'name': 'value'}
    session.remove_cookies(['name'])
    assert not session['cookies']

# Generated at 2022-06-23 20:10:01.821389
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(DEFAULT_CONFIG_DIR)
    session_name = 'session01'
    host = 'www.google.com'
    url = 'https://www.google.com'
    session_path = (config_dir / SESSIONS_DIR_NAME / host /
                    f'{session_name}.json')
    get_httpie_session(config_dir, session_name, host, url)
    assert os.path.exists(session_path)
    os.remove(session_path)



# Generated at 2022-06-23 20:10:09.512430
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config, DEFAULT_CONFIG_DIR
    from httpie.plugins.registry import plugin_manager

    plugin_manager.load()
    config = Config(dir=str(DEFAULT_CONFIG_DIR))
    session = get_httpie_session(config.dir, 's1', 'http://localhost', '')
    if session is None:
        print('session is None')
    else:
        print(session.config.path)
# Unit test end


if __name__ == '__main__':
    test_get_httpie_session()

# Generated at 2022-06-23 20:10:16.689515
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """
    Test that get_httpie_session returns a valid Session object, regardless
    of whether the session file exists or not.

    """
    import tempfile
    name = 'foo'
    config_dir = Path(tempfile.mkdtemp(prefix='httpie'))
    DEFAULT_SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    host = 'example.org'
    url = 'http://example.org/one'
    session = get_httpie_session(config_dir, name, host, url)
    assert isinstance(session, Session)
    assert session.path == (
        config_dir / SESSIONS_DIR_NAME / host / f'{name}.json'
    )
    # Same test as above with a different hostname.
    host = 'example.com'

# Generated at 2022-06-23 20:10:18.864062
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        config_dir = Path('/home/cq/config'),
        session_name = "douban",
        host = 'www.douban.com'
    )
    print(session)

# Generated at 2022-06-23 20:10:24.723717
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path="/")
    session['cookies'] = {'cookie1':{'value':'value1'}, 'cookie2':{'value':'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2':{'value':'value2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}



# Generated at 2022-06-23 20:10:30.342460
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test.json')
    s.update({'cookies': {'c1': 1, 'c2': 2}})
    s.remove_cookies(['c1', 'c3'])
    assert s.get('cookies', None) == {'c2': 2}

# Generated at 2022-06-23 20:10:39.044687
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import DEFAULT_CONFIG_DIR

    def _get_httpie_session(session_name, url, host=None):
        print(session_name, url, host)

        if session_name.startswith('.'):
            path = os.path.expanduser(session_name)
        else:
            if host is None:
                host = urlsplit(url).netloc.split('@')[-1]
                if not host:
                    host = 'localhost'
                host = 'http://%s' % host
            host = host.replace(':', '_')
            path = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / host / f'{session_name}.json'
        session = Session(path)
        session.load()
        return session

    #

# Generated at 2022-06-23 20:10:42.032845
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test_session")
    session['cookies'] = {'session_id': 1}
    session.remove_cookies(['session_id'])
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:10:47.958793
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    session = Session(Path('/home/ligen/.httpie/sessions/localhost/test.json'))
    # test_init
    assert isinstance(session['headers'], dict)
    assert isinstance(session['cookies'], dict)
    assert isinstance(session['auth'], dict)
    # test_update_headers
    request_headers = {'Send': 'Hello'}
    session.update_headers(request_headers)
    assert 'Send' in session['headers']
    # test_headers
    assert 'Send' in session.headers


# Generated at 2022-06-23 20:10:49.974151
# Unit test for constructor of class Session
def test_Session():
    s = Session(path="test_session")
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-23 20:11:01.062780
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session("a")
    s.update_headers({'Authorization': 'Basic Zm9vOmJhcg=='})
    assert s['headers'] == {'Authorization': 'Basic Zm9vOmJhcg=='}
    s.update_headers({'If-Match': 'W/"foo"'})
    assert s['headers'] == {'Authorization': 'Basic Zm9vOmJhcg==',
                            'If-Match': 'W/"foo"'}
    s.update_headers({'User-Agent': 'HTTPie/1.0.3'})
    assert s['headers'] == {'Authorization': 'Basic Zm9vOmJhcg==',
                            'If-Match': 'W/"foo"'}

# Generated at 2022-06-23 20:11:06.074013
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    request_headers = RequestHeadersDict({"Accept-Encoding":"gzip","Connection":"keep-alive","Content-Length":"11","User-Agent":"HTTPie/2.2.0"})
    session = Session('sessionfile.json')
    session.update_headers(request_headers)
    assert session.headers == RequestHeadersDict({"Accept-Encoding":"gzip","Connection":"keep-alive","User-Agent":"HTTPie/2.2.0"})

# Generated at 2022-06-23 20:11:11.680517
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    my_session = Session(path=Path(""))
    my_session["cookies"] = {}
    assert my_session["cookies"] == {}
    my_session["cookies"] = {"test": "test"}
    assert my_session["cookies"] == {"test": "test"}
    my_session.remove_cookies(["test","bad"])
    assert my_session["cookies"] == {}

# Generated at 2022-06-23 20:11:17.434618
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies_dict1 = {'cookies': {'cookie_name1': 'cookie_value1', 'cookie_name2': 'cookie_value2'}}
    session1 = Session('session_name1.json')
    session1.update(cookies_dict1)
    assert session1.cookies == {'cookies': {'cookie_name1': 'cookie_value1', 'cookie_name2': 'cookie_value2'}}
    session1.remove_cookies(['cookie_name2'])
    assert session1.cookies == {'cookies': {'cookie_name1': 'cookie_value1'}}

# Generated at 2022-06-23 20:11:26.429681
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cwd = os.getcwd()
    if cwd.endswith('unit-tests'):
        os.chdir('../../')

    session = get_httpie_session(
        config_dir = DEFAULT_CONFIG_DIR,
        session_name = 'www.wikipedia.org',
        host = 'www.wikipedia.org',
        url = 'https://www.wikipedia.org/'
    )

    # Test when no cookie is removed
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie('zero', '0'))
    session.cookies.set_cookie(create_cookie('one', '1'))
    session.cookies.set_cookie(create_cookie('two', '2'))