

# Generated at 2022-06-23 20:01:31.254368
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Initialize variables
    request_headers = {
        'Content-Type': 'application/json',
        'Content-Length': 9,
        'Request-Number': 3,
        'redirect-Count': 2,
        'Connection': 'keep-alive',
        'Host': 'httpbin.org',
    }
    request_headers['If-Modified-Since'] = '123'
    
    # Initialize object and headers
    session = Session(path=Path('session.json'))
    session.headers = {
        'Content-Type': 'application/json',
        'Content-Length': 9,
        'Request-Number': 3,
        'redirect-Count': 2,
        'Connection': 'keep-alive',
    }

    # Get response

# Generated at 2022-06-23 20:01:33.407078
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session(Path('./'), 'test', '127.0.0.1', 'http://127.0.0.1')

# Generated at 2022-06-23 20:01:34.962210
# Unit test for constructor of class Session
def test_Session():
    print("test_Session")
    s = Session("../Sessions/")
    print(s)

# Generated at 2022-06-23 20:01:41.194790
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('home/config') 
    session_name = 'my_session'

    httpie_session = get_httpie_session(config_dir, session_name, None, None)
    session_path = Path('home/config/sessions/localhost/my_session.json')
    assert httpie_session.path == session_path

    httpie_session.load()



# Generated at 2022-06-23 20:01:43.996189
# Unit test for constructor of class Session
def test_Session():
    get_httpie_session("C:/Users/Administrator/AppData/Roaming/httpie/config.json","httpproject","localhost","http://localhost:5000/")

# Generated at 2022-06-23 20:01:56.315048
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    S = Session('path')
    S.cookies = RequestsCookieJar()
    S.cookies.set_cookie(create_cookie(
                'selected', 'true',  path='/'))
    S.cookies.set_cookie(create_cookie(
                'tab', 'details',  path='/'))
    S.cookies.set_cookie(create_cookie(
                'abcd', 'efgh',  path='/'))
    S.cookies.set_cookie(create_cookie(
                'username', 'admin',  path='/'))
    for i in S['cookies']:
        if i == 'selected':
            S.cookies.clear_expired_cookies()
    test_cookie = S.cookies.as_dict()

# Generated at 2022-06-23 20:02:04.503415
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.context import Environment
    from httpie.cli.constants import DEFAULT_UA
    from httpie.plugins import plugin_manager
    from httpie.plugins.manager import builtin_plugins

    config_dir = Environment(
        colors=0,
        extensions=builtin_plugins(),
    ).config_dir

    # without cookies
    session_name = 'test_session'
    request_headers = RequestHeadersDict([
        ('Authorization', '123'),
        ('User-Agent', 'HTTPie/1.0.0'),
    ])
    session = Session(
        config_dir / SESSIONS_DIR_NAME / 'localhost' / f'{session_name}.json'
    )
    session.update_headers(request_headers)
    assert session['headers'] == {'Authorization': '123'}

# Generated at 2022-06-23 20:02:14.482738
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/dev/null'))

    session.update_headers({'Cookie': ''})
    assert session['cookies'] == {}

    session.update_headers({'Cookie': 'a=b'})
    assert session['cookies'] == {'a': {'value': 'b'}}

    session.update_headers({'Cookie': 'a=c'})
    assert session['cookies'] == {'a': {'value': 'c'}}

    session.update_headers({'Cookie': 'a=c; d=e'})
    assert session['cookies'] == {'a': {'value': 'c'}, 'd': {'value': 'e'}}

    session.update_headers({'Cookie': 'a=c; d=e; d=f'})
   

# Generated at 2022-06-23 20:02:18.198738
# Unit test for constructor of class Session
def test_Session():
    path = DEFAULT_SESSIONS_DIR / 'test_Session.json'
    session = Session(path)
    session.load()
    session['headers'] = 'test'
    session['cookies'] = 'test'
    session['auth'] = 'test'
    session.save()


if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-23 20:02:23.067053
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {'foo': 'bar', 'baz': 'qux'}
    session = Session('/tmp/test_Session_update_headers.json')
    session.update_headers(headers)
    assert session['headers'] == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-23 20:02:24.326391
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session()
    # session.update_headers({})

# Generated at 2022-06-23 20:02:30.020781
# Unit test for function get_httpie_session
def test_get_httpie_session():
    dir_ = os.path.expanduser('~/.config/httpie')
    session_name = 'session_name'
    url = 'http://domain.com'
    assert isinstance(get_httpie_session(dir_, session_name, 'domain.com', url), Session)
    assert isinstance(get_httpie_session(dir_, session_name, None, url), Session)

# Generated at 2022-06-23 20:02:33.703904
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("")
    s.cookies= {'1': {'value': '11'}, '2': {'value': '22'}}
    s.remove_cookies(['1', '3'])
    assert s.cookies == {'2': {'value': '22'}}

# Generated at 2022-06-23 20:02:42.048337
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir = Path('/root')
    session_name = 'session'
    host = 'localhost'
    url = 'localhost'

    session = get_httpie_session(
        config_dir, session_name, host, url
    )

    jar = RequestsCookieJar()
    jar.set('cookie1', 'value1')
    jar.set('cookie2', 'value2')
    jar.set('cookie3', 'value3')

    session.cookies = jar

    assert jar == session.cookies

    # Remove only cookie3
    session.remove_cookies(['cookie3'])

    jar.set_cookie(create_cookie('cookie2', 'value2', path='/'))
    jar.set_cookie(create_cookie('cookie1', 'value1', path='/'))
    assert jar

# Generated at 2022-06-23 20:02:47.101909
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=None)
    session.update_headers(request_headers={
        'User-Agent': 'HTTPie/0.9.9',
        'Host': 'httpbin.org',
        'Connection': 'keep-alive',
        'Accept-Encoding': 'gzip, deflate',
        'Accept': '*/*',
        'Accept-Language': 'zh-CN,zh;q=0.8',
        'Cookie': 'foo=bar;baz=wob;c=d;'
    })


# Generated at 2022-06-23 20:02:51.037366
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('./')
    session_name = 'my_session'
    host = 'host'
    url = 'http://example.com'

    assert get_httpie_session(config_dir,session_name,host,url)

# Generated at 2022-06-23 20:02:59.162228
# Unit test for constructor of class Session
def test_Session():
    # <https://docs.python.org/2/library/cookielib.html#cookie-objects>
    jar = RequestsCookieJar()
    jar.set_cookie(create_cookie(
        'session_id', '74630e1d-bfed-4521-a819-b9c2c6817c7d'))
    jar.set_cookie(create_cookie(
        'csrftoken', 'A9jq6C1U6AKfYMpnPb6Z2gx0NCb5R34I', path='/'))

# Generated at 2022-06-23 20:03:10.108652
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.input import ParseResult
    from httpie.models import Request
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie import ExitStatus
    from httpie.cli import parser

    session_dict = {
        'headers': {},
        'cookies': {},
        'auth': {
            'type': None,
            'username': None,
            'password': None
        }
    }

    session = Session(session_dict)


# Generated at 2022-06-23 20:03:13.938648
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/sessions/test')
    session.update_headers(RequestHeadersDict({
        'Accept': 'text/html',
        'Content-Type': 'application/json',
        'If-Match': '"a7cd05fe34da3bdee67ab2739a5a5d11"',
        'Cookie': 'foo=bar',
    }))
    assert session.headers == RequestHeadersDict({
        'Accept': 'text/html',
    })
    assert session.cookies == RequestsCookieJar([('foo', 'bar')])

# Generated at 2022-06-23 20:03:19.657876
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(DEFAULT_CONFIG_DIR)
    session_name = "TEST"
    host = "TEST_HOST"
    url = "https://www.example.com"

    session = get_httpie_session(config_dir,
                                 session_name,
                                 host,
                                 url)
    assert session != None


# Generated at 2022-06-23 20:03:25.558683
# Unit test for constructor of class Session
def test_Session():
    session = get_httpie_session(Path('./'), 'session_name', 'host', 'http://www.example.com')

    assert session.headers == {}
    assert session.cookies == {}
    assert session.auth == {
        'type': None,
        'username': None,
        'password': None,
        }
    assert session.helpurl == 'https://httpie.org/doc#sessions'
    assert session.about == 'HTTPie session file'

# Generated at 2022-06-23 20:03:34.480107
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')
    session.update_headers({'Content-Length': '123'})
    session.update_headers({'user-agent': 'HTTPie/1.0.2'})
    session.update_headers({'Host': 'httpbin.org'})
    session.update_headers({'Accept-Encoding': None})
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})
    session.update_headers({'Cookie': 'foo=spam'})
    session.update_headers({'If-Modified-Since': 'Sat, 29 Oct 1994 19:43:31 GMT'})

# Generated at 2022-06-23 20:03:37.364517
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path = '/test')
    s['cookies'] = {'test':{'value':'1'}}
    s.remove_cookies(['test'])
    assert s['cookies'] == {}


# Generated at 2022-06-23 20:03:40.043810
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("D:\Develop\Git\httpie\httpie\sessions\www.httpbin.org\default.json")
    s.update({'cookies': {'a':{'b':'c'},'d':{'e':'f'}}})
    s.remove_cookies(['a'])
    assert s.get('cookies')=={'d':{'e':'f'}}

# Generated at 2022-06-23 20:03:46.322739
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from StringIO import StringIO

    session = Session(path=None)
    session._load_from_file = lambda path: StringIO('{"headers":{}}')
    session.load()
    session.update_headers({'content-length': '0'})

    expected = {'Content-Length': '0'}
    assert session.headers == expected

    session.update_headers({'if-modified-since': '123'})
    assert session.headers == expected

    session.update_headers({'user-agent': 'HTTPie/1.0.2'})
    assert session.headers == expected

# Generated at 2022-06-23 20:03:57.143607
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', 'httpie.org', 'http://httpie.org')
    assert session is not None
    assert session.path == DEFAULT_SESSIONS_DIR / 'httpie.org' / 'test.json'
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', None, 'http://httpie.org')
    assert session is not None
    assert session.path == DEFAULT_SESSIONS_DIR / 'httpie.org' / 'test.json'
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, '/tmp/test', None, 'http://httpie.org')
    assert session is not None
    assert session.path == '/tmp/test'

# Generated at 2022-06-23 20:04:02.186113
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path="./unitTest")
    session["cookies"] = {"test": {"value": "testvalue"}, "test1": {"value": "testvalue"}}
    session.remove_cookies(["test1"])
    assert "test1" not in session["cookies"]
    assert session["cookies"]["test"]["value"] == "testvalue"
    session.clear()


# Generated at 2022-06-23 20:04:10.092464
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test_Session_remove_cookies')
    s.cookies = RequestsCookieJar()
    s.cookies.set('a', 'b')
    s.cookies.set('c', 'd')
    s.cookies.set('e', 'f')
    assert len(s['cookies']) == 3
    s.remove_cookies(['a', 'c'])
    assert len(s['cookies']) == 1

# Generated at 2022-06-23 20:04:15.365800
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    req_headers = {'clear-site-data': '*', 'host': 'localhost', 'cookie': 'MyCookie=MyValue'}
    headers = {'clear-site-data': '*', 'cookie': 'MyCookie=MyValue'}
    ses = Session('tests/sessions/session.json')
    ses.update_headers(req_headers)
    assert ses.headers == headers

# Generated at 2022-06-23 20:04:18.246632
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test_session.json")
    session["cookies"] = {'cookie1': {'value': 'value1'},
                          'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1', 'cookie2'])
    assert session['cookies'] == {}
    session.delete()

# Generated at 2022-06-23 20:04:24.488888
# Unit test for constructor of class Session
def test_Session():
    s = Session('hello_world.json')
    print(s['headers'])
    print(s['cookies'])
    print(s['auth'])
    assert type(s['headers']) is dict
    assert type(s['cookies']) is dict
    assert type(s['auth']) is dict
    assert s['auth']['type'] is None
    assert s['auth']['username'] is None
    assert s['auth']['password'] is None
    return s


if __name__ == '__main__':
    session = test_Session()

# Generated at 2022-06-23 20:04:31.276426
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/path/to/file')
    headers_dict = RequestHeadersDict()
    headers_dict['Content-Type'] = 'application/json'
    headers_dict['Cookie'] = 'name=value'
    session.update_headers(headers_dict)
    assert session.headers['Cookie'] == 'name=value'
    assert session.headers['Content-Type'] == 'application/json'


# Generated at 2022-06-23 20:04:34.769697
# Unit test for constructor of class Session
def test_Session():
    print('\n')
    s = Session(path='./httpie/config.json')
    print(s)
    print(s.headers)
    print(s.auth)
    print(s.cookies)
    # print(s.remove_cookies(names=[]))

# Generated at 2022-06-23 20:04:38.961895
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('dummy')
    session['cookies'] = {'a':{'value':'A'},'b':{'value':'B'}}
    session.remove_cookies(['a','c'])
    assert session['cookies'] == {'b':{'value':'B'}}


# Generated at 2022-06-23 20:04:47.362478
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    from httpie.config import DEFAULT_SESSIONS_DIR
    config_dir = Path.cwd()
    session_name = "test"
    host = "127.0.0.1"
    url = "http://127.0.0.1"
    session = get_httpie_session(config_dir, session_name, host, url)
    assert isinstance(session, Session)
    assert session.path == DEFAULT_SESSIONS_DIR / host / 'test.json'

# Generated at 2022-06-23 20:04:53.696727
# Unit test for function get_httpie_session
def test_get_httpie_session():
    with patch('httpie.sessions.os') as mockos:
        mockos.path.expanduser.return_value = 'mock_home'
        get_session = get_httpie_session(mock_home, 'test', 'www.httpie.org', 'www.httpie.org')
        assert get_session.path == mock_home + '/' + SESSIONS_DIR_NAME + '/' + 'www_httpie_org/test.json'


# Generated at 2022-06-23 20:04:55.486459
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert len(get_httpie_session(DEFAULT_SESSIONS_DIR, 'example', '', '')) == 4

# Generated at 2022-06-23 20:05:03.342039
# Unit test for constructor of class Session
def test_Session():
    import sys
    import pytest

    SESSIONS_DIR = Path.home() / SESSIONS_DIR_NAME

    if not os.path.exists(SESSIONS_DIR):
        os.makedirs(SESSIONS_DIR)

    session_name = "my_session.json"
    session_path = SESSIONS_DIR / session_name
    if os.path.exists(session_path):
        os.remove(session_path)

    session = Session(SESSIONS_DIR)
    session["headers"]["h1"] = "ha1"
    session.save()

    session = Session(SESSIONS_DIR)
    assert session["headers"]["h1"] == "ha1"

    session.save(SESSIONS_DIR / "my_session.json")

# Generated at 2022-06-23 20:05:10.379239
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path("/test_config_dir")
    session_name = "test_get_httpie_session"
    host_1 = "host_1.com"
    host_2 = "host_2.com:8888"
    url_1 = "https://{}".format(host_1)
    url_2 = "https://{}/test_url".format(host_2)

    session_1 = get_httpie_session(config_dir, session_name, host_1, url_1)
    assert session_1.path == config_dir / SESSIONS_DIR_NAME / host_1 / "{}.json".format(session_name)
    session_2 = get_httpie_session(config_dir, session_name, host_2, url_2)

# Generated at 2022-06-23 20:05:18.474692
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    sess = Session(path='/tmp/test.json')

# Generated at 2022-06-23 20:05:24.750437
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        Path("./config"), 'test_session', 'localhost:9001', 'http://localhost:9001/'
    )
    assert session is not None
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-23 20:05:31.394861
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = Path('./sessions/www_httpbin_org.json')
    session = Session(path)
    session.load()
    request_headers = {'Accept': 'application/json', 'Cookie': 'a=1; b=2;'}
    session.update_headers(request_headers)
    jar = session.cookies
    assert jar._cookies["www.httpbin.org"]["/"] == {'a': '1', 'b': '2'}
    assert session['headers'] == {'Accept': 'application/json'}

# Generated at 2022-06-23 20:05:35.920907
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = os.getcwd()

    session = Session(path)
    session.load()

    if not os.path.exists(path):
        os.mkdir(path)
        with open(path + "session.json", "w") as session_file:
            session_file.write(json.dumps(session))

    #Remove cookie "cookie_name"
    session.remove_cookies([cookie_name])


# Generated at 2022-06-23 20:05:39.274442
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path = 'None')
    session['cookies']['a'] = 'a'
    session['cookies']['b'] = 'b'
    session['cookies']['c'] = 'c'
    session.remove_cookies(['a', 'd'])
    assert session['cookies'].keys() == {'b', 'c'}


# Generated at 2022-06-23 20:05:44.414157
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json
    import tempfile

    session_file_path = tempfile.TemporaryDirectory().name + "/a.json"
    session_file = open(session_file_path, "w")

    session_file.write('''
    {
        "cookies": {
            "A": 11,
            "B": 22,
            "C": 33,
            "D": 44
        }
    }
    ''')
    session_file.close()

    target_session = Session(session_file_path)
    target_session.load()

    target_session.remove_cookies(["A", "D"])

    assert target_session.get("cookies") == {
                                                "B": 22,
                                                "C": 33
                                            }

# Generated at 2022-06-23 20:05:54.260930
# Unit test for constructor of class Session
def test_Session():
    config_dir = Path("~/.config/httpie")
    session_name = 'default'
    host = "www.google.com"
    url = "http://www.google.com"
    sess = get_httpie_session(config_dir, session_name, host, url)
    assert sess['cookies'] == {}
    assert sess['auth'] == {'type': None, 'username': None, 'password': None}
    assert {'type', 'username', 'password'} == sess['auth'].keys()
    assert isinstance(sess.cookies, RequestsCookieJar)
    assert sess.cookies == RequestsCookieJar()
    assert isinstance(sess.auth, type(None))
    assert isinstance(sess.headers, RequestHeadersDict)
    assert s

# Generated at 2022-06-23 20:06:02.734894
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('noneed_for_it')
    session['cookies'] = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}

    assert session['cookies']['a'] == 'a'
    assert session['cookies']['b'] == 'b'
    assert session['cookies']['c'] == 'c'
    assert session['cookies']['d'] == 'd'

    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 'c', 'd': 'd'}

    session.remove_cookies(['c', 'd'])
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:06:11.510448
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from requests.structures import CaseInsensitiveDict
    unixsocket_url = '/tmp/test.sock/1'
    host = 'localhost/tmp/test.sock'
    result_dict = {
        'headers': CaseInsensitiveDict(
            {'Host': host,
             'Connection': 'close',
             'Accept-Encoding': 'gzip, deflate',
             'Accept': '*/*',
             'User-Agent': 'python-requests/2.18.4'}),
        'cookies': {}
    }
    assert (get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', host, unixsocket_url) == result_dict)

# Generated at 2022-06-23 20:06:16.344721
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/session.json')
    session['cookies'] = {
        'google': {
            'value': 'google',
            'path': '/',
            'secure': 'no',
            'expires': '2019-11-14 18:47:17'
        },
        'redhat': {
            'value': 'redhat',
            'path': '/',
            'secure': 'no',
            'expires': '2019-11-14 18:47:17'
        }
    }
    assert len(session['cookies']) == 2
    session.remove_cookies(names=['redhat'])
    assert len(session['cookies']) == 1

# Generated at 2022-06-23 20:06:20.043068
# Unit test for function get_httpie_session
def test_get_httpie_session():
    path = get_httpie_session(Path('~/.httpie'), 'example', None, 'https://example.org')
    assert path == '~/.httpie/sessions/example.org/example.json'

# Generated at 2022-06-23 20:06:26.155055
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = "session"
    host = "test.test"
    url = "http://test.test"
    session = get_httpie_session(config_dir,session_name,host,url)
    assert session.about == "HTTPie session file"


# Generated at 2022-06-23 20:06:30.302010
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/path/to/config')
    session_name = 'test'
    host = 'github.com'
    url = 'https://github.com'
    assert '/path/to/config/sessions/github_com/test.json' == str(
        get_httpie_session(config_dir, session_name, host, url).path)

# Generated at 2022-06-23 20:06:31.225998
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert(1)

# Generated at 2022-06-23 20:06:35.442437
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('session_name')
    request_headers = RequestHeadersDict(
        {'a': '1', 'b': '2', 'Content-Type': 'application/json'})
    session.update_headers(request_headers)
    print(session['headers'])

# Generated at 2022-06-23 20:06:38.097323
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test")
    session['cookies'] = {'test': {'value': 'test'}}
    session.remove_cookies(['test', 'test1'])
    assert session['cookies'] == {}


# Generated at 2022-06-23 20:06:41.803440
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(''))
    session.update_headers(request_headers={'Cookie': 'first_cookie=1; second_cookie=2'})
    session.remove_cookies(names='first_cookie')
    assert session.get('cookies') == {'second_cookie': {'value': '2'}}

# Generated at 2022-06-23 20:06:52.667692
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Remove cookies from the session

    """
    session = Session(Path(__file__).joinpath('test_session_cookies.json'))
    session.load()
    assert len(session['cookies']) == 2
    assert 'google' in session['cookies']
    assert 'gmail' in session['cookies']
    session.remove_cookies(['google'])
    assert len(session['cookies']) == 1
    assert 'google' not in session['cookies']
    assert 'gmail' in session['cookies']
    session.remove_cookies(['gmail'])
    assert len(session['cookies']) == 0
    assert 'google' not in session['cookies']
    assert 'gmail' not in session['cookies']

# Generated at 2022-06-23 20:06:57.807328
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {'c1': 'v1', 'c2': 'v2', 'c3': 'v3'}
    session.remove_cookies(['c1', 'c4'])
    assert session['cookies'] == {'c2': 'v2', 'c3': 'v3'}

# Generated at 2022-06-23 20:07:00.122235
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_filename')
    session['cookies'] = {'cookie_name': None}
    session.remove_cookies(['cookie_name'])
    assert 'cookies' not in session

# Generated at 2022-06-23 20:07:11.594541
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path = '')

    # Valid headers
    session.update_headers({
        'User-Agent': 'HTTPie/1.0.0',
        'Content-Type': 'application/json',
        'Accept': 'text/json',
        'If-Match': '*'
    })
    assert session['headers'] == {
        'User-Agent': 'HTTPie/1.0.0',
        'Accept': 'text/json',
    }

    # Invalid headers
    session.update_headers({
        'User-Agent': 'HTTPie/1.0.0',
        'Content-Type': 'application/json',
        'Accept': 'text/json',
        'If-Match': '*',
        'Cookie': 'test=test'
    })

# Generated at 2022-06-23 20:07:18.897743
# Unit test for constructor of class Session
def test_Session():
    session_name = "test_session"
    host = "test_host"
    url = "test_url"
    config_dir = "test_dir"

    session = get_httpie_session(config_dir, session_name, host, url)
    print("initialized")

    request_headers = RequestHeadersDict()
    request_headers["key1"] = "value1"
    request_headers["key2"] = "value2"
    session.update_headers(request_headers)

    print(session.headers)

    assert session is not None

# Generated at 2022-06-23 20:07:20.887562
# Unit test for constructor of class Session
def test_Session():
    session = Session("~/httpie/sessions/localhost/session.json")


# Generated at 2022-06-23 20:07:29.909032
# Unit test for constructor of class Session
def test_Session():
    s = Session("path")
    s.update_headers({"header1": "value1"})
    assert s.headers == {"header1": "value1"}

    s.update_headers({"content-type": "value2"})
    assert s.headers == {"header1": "value1"}

    s.update_headers({"user-agent": "HTTPie/0.9.9"})
    assert s.headers == {"header1": "value1"}

    s.update_headers({"cookie": "value4"})
    assert s.headers == {"header1": "value1"}

    assert s.cookies == {'cookie': 'value4'}



# Generated at 2022-06-23 20:07:37.777670
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import httpie.environment as env
    from httpie import config
    from httpie.compat import is_windows
    from pathlib import Path
    import os
    import shutil

    cwd = config.Config().dir
    if cwd == DEFAULT_CONFIG_DIR:
        cwd = cwd / 'httpie-test'
        os.makedirs(str(cwd))
        env.ENV['CONFIG_DIR'] = str(cwd)
    config_dir = config.Config().dir


# Generated at 2022-06-23 20:07:40.122137
# Unit test for constructor of class Session
def test_Session():
    __test_check_file_name()
    __test_load_file()
    __test_save_file()


# Generated at 2022-06-23 20:07:48.140427
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.sessions import Session
    session = Session(path='/tmp/test.json')
    session['cookies'] = {
        'cookie1': {'value': 'value1'},
        'cookie2': {'value': 'value2'},
    }
    assert len(session['cookies']) == 2
    session.remove_cookies(['cookie2'])
    assert len(session['cookies']) == 1
    assert session['cookies']['cookie1']['value'] == 'value1'

# Generated at 2022-06-23 20:07:53.627203
# Unit test for constructor of class Session
def test_Session():
    session = Session('C:\\Users\\Owner\\.config\\httpie\\sessions\\github')
    print(session)
    print(session['headers'])
    print(session['cookies'])
    print(session['auth'])

if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-23 20:08:03.817746
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    jar = RequestsCookieJar()
    new_cookies = ['a','b']
    old_cookies = ['c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u']
    for cookie in new_cookies:
        jar.set_cookie(create_cookie(cookie, '0'))
    for cookie in old_cookies:
        jar.set_cookie(create_cookie(cookie, '0', expires=0))
    jar.clear_expired_cookies()
    s = Session("")
    s.cookies = jar
    assert len(s.cookies)==len(new_cookies)+len(old_cookies)
    s.remove_cookies(new_cookies)

# Generated at 2022-06-23 20:08:09.112064
# Unit test for constructor of class Session
def test_Session():
    session = Session("/home/user/.config/httpie/sessions/httpbin.com/default.json")
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }



# Generated at 2022-06-23 20:08:18.393732
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.plugins.builtin import UnixSocketAuthPlugin

    config_dir = Path('/tmp/config_dir')
    session_name = 'session'
    host = 'localhost'
    url = 'http://localhost'

    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.path == Path('/tmp/config_dir/sessions/localhost/session.json').absolute()
    session.load()
    session.headers['X-DEBUG'] = 'True'
    session.save(config_dir)

    session2 = get_httpie_session(config_dir, session_name, host, url)
    assert 'X-DEBUG' in session2.headers
    # Test private method

# Generated at 2022-06-23 20:08:27.482592
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/session.json')
    session['headers'] = {}

    headers = {'test1': 'test2'}
    session.update_headers(headers)
    assert session.headers['test1'] == 'test2'

    headers = {'content-type': 'test3', 'if-emsg': 'test4'}
    session.update_headers(headers)
    assert session.headers['content-type'] == 'test3'
    assert session.headers['if-emsg'] == 'test4'

    # Test if custom header is saved in session headers
    headers = {'x-custom-header': 'test5'}
    session.update_headers(headers)
    assert session.headers['x-custom-header'] == 'test5'

    # Test if content-type is not saved in session headers


# Generated at 2022-06-23 20:08:33.625205
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('~/.config/httpie/sessions/example_com/session1.json')
    session['cookies']['session'] = {'value': '1234'}
    session['cookies']['user_id'] = {'value': '5678'}
    session.remove_cookies(['user_id'])
    assert 'user_id' not in session['cookies']

# Generated at 2022-06-23 20:08:42.726303
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(
        config_dir=Path('~/.httpie'),
        session_name='test',
        host='localhost',
        url='http://localhost/test'
    )
    assert get_httpie_session(
        config_dir=Path('~/.httpie'),
        session_name='test',
        host='localhost:8080',
        url='http://localhost:8080/test'
    )
    assert get_httpie_session(
        config_dir=Path('~/.httpie'),
        session_name='test',
        host='localhost:8080',
        url='http://localhost/test'
    )

# Generated at 2022-06-23 20:08:47.644231
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='')
    cookies = {'b': {'value': '2'}, 'a': {'value': '1'}}
    session['cookies'] = cookies
    session.remove_cookies(names=['a', 'c'])
    assert session['cookies'] == {'b': {'value': '2'}}



# Generated at 2022-06-23 20:08:55.807271
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    Session = get_httpie_session(config_dir=None, session_name=None, host=None, url=None)
    s = Session
    # add headers
    request_headers = RequestHeadersDict()
    request_headers["Content-Type"] = "application/json"
    request_headers["Accept"] = "application/json"
    request_headers["Cookie"] = "name=John"
    s.update_headers(request_headers)
    # test first
    assert s["headers"]["Content-Type"] == "application/json"
    assert s["headers"]["Accept"] == "application/json"
    assert s["cookies"]["name"] == {"value":"John"}
    # update headers

# Generated at 2022-06-23 20:09:06.661234
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.builtin import http
    from httpie.plugins.manager import plugin_manager
    from httpie.request import PreparedRequest
    from httpie.session import Session
    plugin_manager.load_builtin_plugins()
    config = Config()
    env = Environment(config=config)
    session = Session(path=config.directory / SESSIONS_DIR_NAME / 'test.json')
    session.load()
    session.update_headers(RequestHeadersDict({'Content-Type': 'text/html',
                                               'Cookie': 'csrftoken=45q3s412e1',
                                               'User-Agent': 'HTTPie/1.0.0'}))
    session_headers = session.headers


# Generated at 2022-06-23 20:09:08.709052
# Unit test for constructor of class Session
def test_Session():
    session = Session('filename')
    assert session['headers'] == {}
    assert session['cookies'] == {}


# Generated at 2022-06-23 20:09:16.767674
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_dic = requests.structures.CaseInsensitiveDict()
    headers_dic['is_add'] = 'True'
    headers_dic['is_del'] = None
    headers_dic['Content-Type'] = 'application/json'
    headers_dic['Cookie'] = 'is_add=False; is_del = True'
    headers_dic['Host'] = 'www.woniu.com'
    session = Session("test")
    session.update_headers(headers_dic)
    current_headers = session.headers
    assert current_headers['is_add'] == 'True'
    assert current_headers['is_del'] == None
    assert current_headers['Content-Type'] == 'application/json'
    assert current_headers['Host'] == 'www.woniu.com'

# Generated at 2022-06-23 20:09:17.415581
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass




# Generated at 2022-06-23 20:09:27.224691
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from types import SimpleNamespace
    from httpie import ExitStatus
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager

    current_dir = Path(os.path.dirname(__file__))
    session = Session(current_dir / 'Sessions.py')
    request_headers = RequestHeadersDict({'key': 'value'})
    session.update_headers(request_headers)
    # property test: headers
    assert session.headers == dict({'key': 'value'})

    # property test: cookies
    cookies = RequestsCookieJar()
    cookies.set_cookie(create_cookie('name', 'value'))
    session.cookies = cookies
    cookie = session.cookies
    assert cookie.__class

# Generated at 2022-06-23 20:09:29.622242
# Unit test for constructor of class Session
def test_Session():
    s = Session("/home/yang/httpie-0.9.9/session.json")
    assert s is not None

# Generated at 2022-06-23 20:09:33.506699
# Unit test for constructor of class Session
def test_Session():
    sess = Session('test')
    assert (sess['headers'] == {})
    assert (sess['cookies'] == {})
    assert (sess['auth'] == {'type': None, 'username': None, 'password': None})

# Generated at 2022-06-23 20:09:41.345935
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Setup
    config_dir = '/configpath'
    session_name = 'sess1'
    host = 'github.com'
    url = 'http://github.com/'
    # Exercise
    result = get_httpie_session(config_dir, session_name, host, url)
    # Verify
    exp_path = '/configpath/sessions/github_com/sess1.json'
    assert repr(result) == repr(Session(exp_path))
    # Cleanup - none necessary



# Generated at 2022-06-23 20:09:46.073493
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("Some path")
    session["headers"] = {}
    session.update_headers({"X-Test-Name": "Test value", "Content-Type": "json"})
    print("session[\"headers\"] =", session["headers"])



# Generated at 2022-06-23 20:09:49.683943
# Unit test for constructor of class Session
def test_Session():
    session = Session('/home/bloodfish/.config/httpie/sessions/localhost/123.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-23 20:09:54.603763
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='unit_test',
        host='127.0.0.1',
        url='http://127.0.0.1/',
    )
    assert session.headers == {}
    assert isinstance(session.cookies, RequestsCookieJar)
    assert session.auth is None

# Generated at 2022-06-23 20:10:03.945679
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    d = Session('./d.json')
    r = {'Content-Type': 'image/png', 'Accept': '*/*', 'Cache-Control': 'no-cache'}
    d.update_headers(r)
    r = {'Content-Type': 'application/json', 'Accept': '*/*', 'Cache-Control': 'no-cache'}
    d.update_headers(r)
    r = {'Cookie': 'foo=bar', 'Accept': '*/*', 'Cache-Control': 'no-cache'}
    d.update_headers(r)
    print(d['headers'])
    assert d['headers'] == {'Accept': '*/*'}
    assert d['cookies']['foo'] == {'value': 'bar'}
    d.save()

# Generated at 2022-06-23 20:10:11.798464
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    jar = RequestsCookieJar()
    jar.set('c1', 'v1')
    jar.set('c2', 'v2')
    session = Session('~/here')
    session.cookies = jar

    session.remove_cookies(names=['c1'])
    assert session['cookies'] == {'c2': {'value': 'v2', 'path': '/'}}
    assert list(session.cookies.keys()) == ['c2']

    session.remove_cookies(names=['c2'])
    assert session['cookies'] == {}
    assert list(session.cookies.keys()) == []

# Generated at 2022-06-23 20:10:23.451846
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict([
        ("Host", "example.org"),
        ("Accept-Encoding", "gzip"),
        ("Content-Length", "124"),
        ("Cookie", "name=value1; name2=value2"),
        ("If-Match", "c04"),
        ("If-None-Match", "c04"),
        ("User-Agent", "HTTPie/0.9.2")
    ])

    session = Session(None)
    session.update_headers(headers)

    assert (set(session.headers.keys()) ==
            set(["Host", "Accept-Encoding", "Cookie", "User-Agent"]))
    assert (set(session['cookies'].keys()) == set(["name", "name2"]))



# Generated at 2022-06-23 20:10:29.825598
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json
    path = './sessions/localhost/test-cookie.json'
    s = Session(path)
    instance = {'cookies': {'foo': 'bar'}}
    s.update(instance)
    s.dump()
    with open(path, 'r') as f:
        dump_str = json.load(f)
    assert dump_str['cookies']['foo'] == 'bar'
    s.remove_cookies(['foo'])
    s.dump()
    with open(path, 'r') as f:
        dump_str = json.load(f)
    assert 'foo' not in dump_str['cookies']

# Generated at 2022-06-23 20:10:34.366113
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {'cookie1': {'value': 'val1'}, 'cookie2': {'value': 'val2'}}
    assert session['cookies'] == {'cookie1': {'value': 'val1'}, 'cookie2': {'value': 'val2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'val2'}}



# Generated at 2022-06-23 20:10:45.987093
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("TEST")
    s["cookies"] = {"camisole": {}, "salopette": {}}
    s.remove_cookies(["camisole"])
    assert "cookies" in s
    assert "camisole" not in s["cookies"]
    assert "salopette" in s["cookies"]
    s.remove_cookies(["salopette"])
    assert "cookies" in s
    assert "camisole" not in s["cookies"]
    assert "salopette" not in s["cookies"]
    s.remove_cookies(["camisole", "salopette"])
    assert "cookies" in s
    assert "camisole" not in s["cookies"]
    assert "salopette" not in s["cookies"]

#

# Generated at 2022-06-23 20:10:50.783834
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("./tests/mock_sessions/session.json")
    s.remove_cookies(['b'])
    assert s['cookies'] == {'a': {'value': '1'}}


# Generated at 2022-06-23 20:10:54.999070
# Unit test for constructor of class Session
def test_Session():
    session = Session('./config')
    print(session)
    print(session['headers'])
    print(session['cookies'])
    print(session['auth'])

if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-23 20:11:03.964018
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict({'a': 'alpha', 'b': 'beta'})
    session = Session('test.json')
    session.update_headers(request_headers)
    session.save()

    session = Session('test.json')
    session.load()
    assert session.headers == request_headers

    # Test with None values
    request_headers = RequestHeadersDict({'a': 'alpha', 'b': None})
    session = Session('test.json')
    session.update_headers(request_headers)
    session.save()

    session = Session('test.json')
    session.load()
    assert session.headers == RequestHeadersDict({'a': 'alpha'})



# Generated at 2022-06-23 20:11:11.629035
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, "test", "example.org", "https://example.org/test").path == DEFAULT_CONFIG_DIR / "sessions" / "example_org" / "test.json"
    assert get_httpie_session(DEFAULT_CONFIG_DIR, "test", "example.org", "https://subdomain.example.org/test").path == DEFAULT_CONFIG_DIR / "sessions" / "subdomain_example_org" / "test.json"

# Generated at 2022-06-23 20:11:15.665398
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    This test is to test Session.remove_cookies() method.
    The test case is to remove a cookie from session by specifying a name which is a string.
    """
    session = Session('test')
    assert session.remove_cookies(['name']) is None


# Generated at 2022-06-23 20:11:22.200251
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.utils import AuthCredentials

    print("test_Session_update_headers")

    session = Session(path='/tmp/test.json')

# Generated at 2022-06-23 20:11:26.123149
# Unit test for constructor of class Session
def test_Session():
    h = {
        'headers': {},
        'cookies': {},
        'auth': {
            'type': None,
            'username': None,
            'password': None
        }
    }
    session = Session(path=Path('./'))
    assert session == h