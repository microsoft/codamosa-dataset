

# Generated at 2022-06-23 20:01:25.413901
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    ses = Session('test')
    ses['cookies'] = {'1': '1', '2': '2'}
    ses.remove_cookies(['1', '3'])
    assert ses['cookies'] == {'2': '2'}

# Generated at 2022-06-23 20:01:29.285899
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path="")
    session['cookies'] = {'a': 1, 'b': 2}
    assert 'a' in session['cookies']
    assert 'b' in session['cookies']
    session.remove_cookies(['a', 'c'])
    assert 'a' not in session['cookies']
    assert 'b' in session['cookies']



# Generated at 2022-06-23 20:01:34.117142
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test_session.json")
    session['cookies'] = {"a":"b", "c":"d"}
    session.remove_cookies(["a", "c"])
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:01:43.611091
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # GIVEN a JSON-serialized session
    session = Session('/tmp/test_session.json')
    session['headers'] = {
        'Accept-Encoding': 'gzip,deflate,compress',
        'Cookie': 'foo=bar; other=cookie'
    }
    session['cookies'] = {
        'foo': {
            'value': 'bar'
        },
        'other': {
            'value': 'cookie'
        },
        'not-to-be-removed': {
            'value': 'never'
        }
    }
    session['auth'] = {'type': 'basic', 'username': 'alice', 'password': 'pass'}

    # WHEN removing some cookies
    session.remove_cookies(['foo', 'not-to-be-removed'])



# Generated at 2022-06-23 20:01:56.124060
# Unit test for constructor of class Session
def test_Session():
    session = Session('test.json')
    path = Path('test.json')
    assert session.path == path
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }
    assert session.helpurl == 'https://httpie.org/doc#sessions'
    assert session.about == 'HTTPie session file'
    session['headers']['key'] = 'value'
    session['cookies']['key'] = 'value'
    assert 'key' in session.headers
    assert session.headers['key'] == 'value'
    assert 'key' in session.cookies
    assert session.cookies['key'] == 'value'
    session.cookies['key1']

# Generated at 2022-06-23 20:01:58.287256
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
        s = Session("test")
        s.cookies =1
        s.remove_cookies('a')
        assert s.cookies==1

# Generated at 2022-06-23 20:02:05.662549
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class TestSession(Session):
        def __init__(self, config_path):
            super().__init__(config_path)

    session = TestSession('test_session')
    request_headers = {
        'User-Agent': 'HTTPie/0.9.9',
        'Content-Type': 'application/json',
        'If-None-Match': 'test',
        'Cookies': 'a=b; c=d',
        'Connection': None,
    }
    session.update_headers(request_headers)

    assert session['headers']['Content-Type'] == 'application/json'
    assert 'If-None-Match' not in session['headers']
    assert len(session['cookies']) == 2
    assert 'a' in session['cookies']

# Generated at 2022-06-23 20:02:14.983740
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pytest import raises
    from urllib.parse import urlparse

    config_dir = DEFAULT_SESSIONS_DIR
    session_name = 'foo'
    url = 'https://example.com:8080'

    # a.0 - path
    s = get_httpie_session(config_dir, session_name, None, url)
    assert s.path == config_dir / session_name

    # a.1 - host from url
    s = get_httpie_session(config_dir, session_name, None, url)
    host = urlparse(url).netloc
    assert s.path == config_dir / SESSIONS_DIR_NAME / host / session_name

    # a.2 - port is normalized to :
    url = 'https://example.com:8080/'
    s = get

# Generated at 2022-06-23 20:02:21.081459
# Unit test for constructor of class Session
def test_Session():
    session1 = Session(path=os.path.join(os.path.dirname(__file__),
                                        "../../../sessions/httpbin.org/test.json"))
    # Path('/Users/yaros/httpie/tests/sessions/httpbin.org/test.json')
    print(session1.path)

    session1.load()

    # {'headers': {'foo': 'bar', 'baz': '2'}, 'cookies': {'first': {'value': 'one', 'path': '', 'secure': False, 'expires': None}}, 'auth': {'type': None, 'username': None, 'password': None}}
    print(session1)
    print(session1['auth'])


# Generated at 2022-06-23 20:02:31.171592
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test_session.json")
    headers = RequestHeadersDict(session['headers'])
    # Test for empty request headers
    session.update_headers(RequestHeadersDict({}))
    assert session["headers"] == headers
    # Test for non-parsable cookie in request headers
    session.update_headers(RequestHeadersDict({"Cookie": "abc"}))
    assert session["headers"] == headers
    # Test for non-storable header in request headers
    session.update_headers(RequestHeadersDict({"Content-Type": "text/html"}))
    assert session["headers"] == headers
    # Test for plain cookie in request headers
    session.update_headers(RequestHeadersDict({"Cookie": "name=value"}))

# Generated at 2022-06-23 20:02:33.415620
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test_session")
    session.update_headers({'host':'www.test.com'})
    assert 'host' in session.headers


# Generated at 2022-06-23 20:02:40.732352
# Unit test for method update_headers of class Session
def test_Session_update_headers():  # pylint: disable=unused-variable
    import pytest
    from httpie.cli.headers import HeadersParser
    headers = HeadersParser().parse(['User-Agent:HTTPie/0.9.9', 'Cookie:X-Test=1', 'Host:www.baidu.com'])
    s = Session('www.baidu.com.json')
    s.update_headers(headers)
    assert s.headers == {'User-Agent': 'HTTPie/0.9.9', 'Host': 'www.baidu.com'}
    assert s['cookies'] == {'X-Test': {'value': '1'}}



# Generated at 2022-06-23 20:02:41.840383
# Unit test for constructor of class Session
def test_Session():
    path = Path(DEFAULT_CONFIG_DIR)
    session = Session(path)

# Generated at 2022-06-23 20:02:45.172953
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = "http://www.google.com/"
    config_dir = DEFAULT_SESSIONS_DIR
    session_name = 'toto'
    session = get_httpie_session(config_dir, session_name, None, url)

# Generated at 2022-06-23 20:02:45.923584
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-23 20:02:52.098323
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='path')
    session['cookies']['a'] = 'some value'
    session['cookies']['b'] = 'some value'
    session['cookies']['c'] = 'some value'
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 'some value'}


# Generated at 2022-06-23 20:02:52.737220
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-23 20:02:53.345923
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-23 20:02:55.785097
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://web.com'
    session_name = 'test'
    os.mkdir(DEFAULT_SESSIONS_DIR)
    s = get_httpie_session(DEFAULT_SESSIONS_DIR, session_name, None, url)
    s.save()
    os.rmdir(DEFAULT_SESSIONS_DIR)

# Generated at 2022-06-23 20:02:59.088799
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'test_key': {'value': 'test_value'}}
    name = 'test_key'
    session.remove_cookies([name])
    assert name not in session['cookies']

# Generated at 2022-06-23 20:03:10.108488
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers_in = {
        # Cookies
        'Cookie': 'foo=bar',
        # Ignored headers
        'Content-Type': 'application/json',
        'If-None-Match': 'foo',
        # Stored headers
        'Content-Length': '123',
        'User-Agent': 'httpie/1.0',
        'Accept': '*/*',
        # Incorrect header name
        'Invalid-Name': 'baz',
    }
    request_headers = RequestHeadersDict(request_headers_in)
    session = Session('test')
    session.update_headers(request_headers)
    assert {'Cookie': 'foo=bar', 'Invalid-Name': 'baz'} == request_headers_in

# Generated at 2022-06-23 20:03:14.775083
# Unit test for constructor of class Session
def test_Session():
    """
    Tetsing Session class constructor.
    This tests :
    - gets filename of config file.
    - initializes session data.
    """
    config_path = os.path.join(os.path.expanduser("~"), '.config',
                               'httpie', 'sessions')
    test_session_json_file = config_path + '/' + 'test_session.json'
    test_session_1 = Session(test_session_json_file)
    assert test_session_1['headers'] == {}
    assert test_session_1['cookies'] == {}
    assert test_session_1['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-23 20:03:25.268065
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    data = {'headers': {
        'Accept': 'application/json',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Cookie': '$Version=0; Customer="WILE_E_COYOTE"; $Path=/acme; '
                  'Part_Number="Rocket_Launcher_0001"; $Path=/acme',
        'User-Agent': 'HTTPie/0.9.8',
        'Cache-Control': 'no-cache',
        'Content-Length': '18',
        'Content-Type': 'application/json',
        'If-Match': '1234'
    }}

# Generated at 2022-06-23 20:03:26.125349
# Unit test for constructor of class Session
def test_Session():
    pass


# Generated at 2022-06-23 20:03:28.756393
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert DEFAULT_SESSIONS_DIR.parent == DEFAULT_CONFIG_DIR
    assert get_httpie_session(DEFAULT_CONFIG_DIR, 'a', 'b', 'c').headers == {}

# Generated at 2022-06-23 20:03:33.564023
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('path')
    cookies = {
        'name1': 'value1',
        'name2': 'value2',
        'name3': 'value3'
    }
    s['cookies'] = cookies
    names = ['name1', 'name2']
    s.remove_cookies(names)
    assert s['cookies'] == {'name3': 'value3'}

# Generated at 2022-06-23 20:03:37.815675
# Unit test for constructor of class Session
def test_Session():
    session = Session("/tmp/session1")
    assert session.path.is_dir() == False
    assert session.helpurl == 'https://httpie.org/doc#sessions'
    assert session.about == 'HTTPie session file'
    assert session.get("headers", None) == None
    assert session.get("cookies", None) == None
    assert session.get("auth", None) == None

# Generated at 2022-06-23 20:03:46.322552
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    request_headers = {
        'Content-Type': 'text/html; charset=UTF-8',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Cookie': 'foo=bar; baz=qux',
        'Connection': 'keep-alive',
        'Transfer-Encoding': 'chunked',
        'TE': 'trailers',
        'Accept-Encoding': 'gzip,deflate'
    }

    session.update_headers(request_headers)


# Generated at 2022-06-23 20:03:57.143909
# Unit test for constructor of class Session
def test_Session():
    # Invalid session names
    invalid_session_name_patterns = [
        'abc*',
        '~',
        '!',
        '!@#',
        '.',
        '..',
        '.hi',
        'hi.',
        '..hi',
        'hi..',
        'h..i',
        'h__i',
        '/',
        '.hidden'
    ]
    for session_name in invalid_session_name_patterns:
        try:
            session = Session(session_name)
        except ValueError:
            continue
    # Valid session names
    valid_session_name_patterns = [
        'a',
        'a.b',
        'ab',
        'a-b',
        'a_b',
        'a@b'
    ]

# Generated at 2022-06-23 20:04:01.434487
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test.json")
    session.update_headers({"Content-Type": "test", "User-Agent": "test"})
    assert("Content-Type" not in session.headers)
    assert("User-Agent" not in session.headers)
    session.update_headers({"Test1": "test", "Test2": "test"})
    assert("Test1" in session.headers)
    assert("Test2" in session.headers)

# Generated at 2022-06-23 20:04:06.261579
# Unit test for constructor of class Session
def test_Session():
    session_name = 'test'
    url = 'https://httpie.org'
    DEFAULT_SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, session_name, '', url)
    assert len(list(DEFAULT_SESSIONS_DIR.glob('*'))) >= 1
    assert len(list(DEFAULT_SESSIONS_DIR.glob('*.json'))) == 0
    assert (DEFAULT_SESSIONS_DIR / 'httpie_org' /
            f'test.json') == Path(session.path)

# Generated at 2022-06-23 20:04:09.482259
# Unit test for constructor of class Session
def test_Session():
    path = '/home/conda/.httpie/sessions/a.json'
    session = Session(path)
    assert session is not None


# Generated at 2022-06-23 20:04:14.180298
# Unit test for constructor of class Session
def test_Session():
    """
    Unit test for Session constructor and object creation
    """
    s = Session("test_Session")
    assert s.path == Path("test_Session")
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-23 20:04:16.912747
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("Session_test.json")
    session.update_headers({"Content-Type":"application/json"})
    assert "Content-Type" not in session.headers



# Generated at 2022-06-23 20:04:20.709178
# Unit test for constructor of class Session
def test_Session():
    path = Path('/path/to/session_command.json')
    session = Session(path)
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-23 20:04:32.294445
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # test for local file path
    config_dir = os.path.expanduser('~/.httpie')
    s = get_httpie_session(config_dir, '~/.httpie/sessions/reddit.com/session.json', host=None, url='https://reddit.com')
    assert s.path.absolute() == Path(config_dir).absolute() / 'sessions' / 'reddit.com' / 'session.json'

    # test for url
    config_dir = os.path.expanduser('~/.httpie')
    s = get_httpie_session(config_dir, 'session', host=None, url='https://www.google.com')
    assert s.path.absolute() == Path(config_dir).absolute() / 'sessions' / 'www_google_com' / 'session.json'

# Generated at 2022-06-23 20:04:39.407317
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    # Start testing
    session.update_headers({'name': 'value'})
    assert session['headers'] == {'name': 'value'}

    session.update_headers({'Name': 'value'})
    assert session['headers'] == {'Name': 'value'}

    session.update_headers({'name': None})
    assert session['headers'] == {'Name': 'value'}

    session.update_headers({'content-type': 'application/json'})
    assert session['headers'] == {'Name': 'value', 'content-type': 'application/json'}

    session.update_headers({'content-Type': 'application/json'})
    assert session['headers'] == {'Name': 'value', 'content-type': 'application/json'}

    session.update_

# Generated at 2022-06-23 20:04:51.715468
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    from httpie.context import Environment
    from httpie import ExitStatus
    from httpie.output.streams import TestStdout

    env = Environment(
        config=Config(),
        stdin=None,
        stdout=TestStdout(),
        stderr=TestStdout(),
        argv=[],
        stdin_isatty=True,
    )

    session = get_httpie_session(
        config_dir=env.config.config_dir,
        session_name="httpbin",
        host=None,
        url="http://httpbin.org/headers",
    )
    env.session = session
    env.session.save()
    print(env.session["headers"])
    env.session['headers']['test'] = 'test'


# Generated at 2022-06-23 20:04:56.432229
# Unit test for constructor of class Session
def test_Session():
    raw_session = {
        'headers': {},
        'cookies': {},
        'auth': {
            'type': 'basic',
            'raw_auth': 'admin:123456',
        }
    }
    session = Session('test.json')
    session.update(raw_session)
    assert session.auth
    assert session['cookies']

# Generated at 2022-06-23 20:05:02.707122
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_dict = {"name1": {"value":"testing_value1"},
                   "name2": {"value":"testing_value2"}}
    session = Session("test_session")
    session["cookies"] = cookie_dict
    session.remove_cookies(["name1"])
    assert session['cookies'] == {"name2": {"value":"testing_value2"}}


__all__ = ('Session', 'get_httpie_session', 'SESSIONS_DIR_NAME',
           'VALID_SESSION_NAME_PATTERN')

# Generated at 2022-06-23 20:05:05.371962
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {'foo': {'value': 'bar'}}
    session.remove_cookies(['foo'])
    assert session['cookies'] == dict()


# Generated at 2022-06-23 20:05:11.384305
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path='test.json')
    s['cookies'] = {'a': {'value': 'value1'}, 'b': {'value': 'value2'}}
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b': {'value': 'value2'}}

# Generated at 2022-06-23 20:05:17.169278
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {}
    headers['content-type'] = 'text/html'
    headers['if-none-match'] = '3e3e'
    headers['user-agent'] = 'Test'
    headers['cookie'] = 'test=test;'
    session = Session(path='sessions/test.json')
    session['headers'] = {}
    session['cookies'] = {}
    session.update_headers(headers)
    assert session['headers'] == {'user-agent': 'Test'}
    assert session['cookies'] == {'test': {'value': 'test'}}



# Generated at 2022-06-23 20:05:21.753646
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    name = 'cookiename'
    session = Session('session')
    session['cookies'][name] = {}
    assert name in session['cookies']
    session.remove_cookies([name])
    assert name not in session['cookies']

# Generated at 2022-06-23 20:05:29.962878
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    # Test when cookie name is present in the cookies dict
    s = Session('/tmp/example')
    s['cookies'].update({'name': {'value': ''}})
    s.remove_cookies(['name'])

    assert 'name' not in s['cookies']

    # Test when cookie name is not present in the cookies dict
    s = Session('/tmp/example')
    s['cookies'].update({'name': {'value': ''}})
    s.remove_cookies(['name1'])

    assert 'name' in s['cookies']

    # Test when there is no cookies dict in the session
    s = Session('/tmp/example')
    s.remove_cookies(['name'])

    assert 'cookies' not in s

# Generated at 2022-06-23 20:05:33.149765
# Unit test for constructor of class Session
def test_Session():
    session = Session(path = 'test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-23 20:05:37.166840
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    expected = {}
    s = Session('/')
    s.update(cookies={'c1': {'value': '2'}, 'c2': {'value': '22'}, 'c3': {'value': '222'}})
    s.remove_cookies(['c1', 'c3'])
    actual = s.cookies
    assert expected == actual


# Generated at 2022-06-23 20:05:37.916077
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    Session.update_headers()

# Generated at 2022-06-23 20:05:39.072675
# Unit test for constructor of class Session
def test_Session():
    Session('~/.httpie/sessions/a.json')


# Generated at 2022-06-23 20:05:43.401140
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = {"cookies": {"a": "1", "b": "2"}}
    session = Session(s)
    session.remove_cookies(["a"])
    assert session.cookies == {"b": "2"}
    session.remove_cookies(["c"])
    assert session.cookies == {"b": "2"}

# Generated at 2022-06-23 20:05:49.629449
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Init a session with request headers
    session = Session('test/sessions/test.json')
    session.update_headers(RequestHeadersDict({'A': '1', 'A-auth': '2', 'Cookie': '3'}))
    expected_headers = {'a': '1', 'a-auth': '2'}
    expected_cookies = {'3': {'value': '3', 'rest': {}}}
    print('headers from request:', session['headers'])
    print('cookies from request:', session['cookies'])
    assert session['headers'] == expected_headers
    assert session['cookies'] == expected_cookies


# Generated at 2022-06-23 20:06:00.349517
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    res = {'type': 'Basic', 'raw_auth': 'kim:kim', 'username': 'kim', 'password': 'kim'}
    path = '~/.httpie/sessions/localhost/kim.json'
    s = Session(path)
    s['auth'] = res
    s['cookies']['sss'] = {'value': 'kkk'}
    s['cookies']['fff'] = {'value': 'kkk'}
    s['headers']['fds'] = 'sdf'
    s['headers']['dsf'] = 'sdf'
    s['headers']['dfsdf'] = 'sdf'
    s.remove_cookies(['fff'])

# Generated at 2022-06-23 20:06:03.663919
# Unit test for constructor of class Session
def test_Session():
    test_file = DEFAULT_CONFIG_DIR / 'sessions' / 'test.json'
    test_session = Session(test_file)
    print(test_session)

# Generated at 2022-06-23 20:06:10.297205
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from unittest import mock
    from pathlib import Path
    config_dir = Path('./test_dir/config/')
    session_name = 'testSession'
    host = 'http://localhost:5000'
    url = 'http://localhost:5000/dummy'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.path == config_dir / SESSIONS_DIR_NAME / 'localhost_5000' / f'{session_name}.json'

# Generated at 2022-06-23 20:06:19.700721
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # test without url, the url don't use in this update_headers
    test_session = Session('session_path')
    test_session.update_headers(RequestHeadersDict({'Content-Type': 'application/x-www-form-urlencoded'}))
    assert test_session.headers == RequestHeadersDict({'Content-Type': 'application/x-www-form-urlencoded'})
    test_session.update_headers(RequestHeadersDict({'If-Modified-Since': 'Mon, 04 Aug 2014 07:59:34 GMT'}))
    assert test_session.headers == RequestHeadersDict({'Content-Type': 'application/x-www-form-urlencoded','If-Modified-Since': 'Mon, 04 Aug 2014 07:59:34 GMT'})
    test_session.update_

# Generated at 2022-06-23 20:06:30.365253
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import sys  # noqa
    import httpie
    httpie.__file__
    session = Session('/a/b/foo.json')
    assert 'name1' not in session['cookies']
    assert 'name2' not in session['cookies']
    assert 'name3' not in session['cookies']
    assert 'name4' not in session['cookies']
    assert 'name5' not in session['cookies']
    session['cookies']['name1'] = 'value1'
    session['cookies']['name2'] = 'value2'
    session['cookies']['name3'] = 'value3'
    session['cookies']['name4'] = 'value4'
    session['cookies']['name5'] = 'value5'

# Generated at 2022-06-23 20:06:33.595334
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        DEFAULT_CONFIG_DIR, 'my-session', 'https://httpie.org', None)
    assert isinstance(session, Session)

# Generated at 2022-06-23 20:06:39.152571
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/path/to/session.json')
    cookies = {
        'session': 'session_value',
        'username': 'username_value',
        'password': 'password_value',
    }
    session['cookies'] = dict(cookies)
    session.remove_cookies(['username','password'])
    assert session['cookies'] == {'session': 'session_value'}


# Generated at 2022-06-23 20:06:41.254398
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/xxx.json')
    session.update_headers('')


if __name__ == '__main__':
    test_Session_update_headers()

# Generated at 2022-06-23 20:06:46.538613
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test")
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}
# END of Unit test remove_cookies



# Generated at 2022-06-23 20:06:56.617358
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=None)
    assert len(session.headers) == 0 and len(session['cookies']) == 0 and session['auth'] == {'type': None, 'username': None, 'password': None}
    session.update_headers(RequestHeadersDict({'content-type': 'text/html'}))
    assert len(session.headers) == 1 and session.headers['content-type'] == 'text/html' and len(session['cookies']) == 0 and session['auth'] == {'type': None, 'username': None, 'password': None}
    session.update_headers(RequestHeadersDict({'Cookie': 'test1=ttest1; Domain=www.testdomain.com; Path=/; Expires=Sun, 06 Nov 2020 21:46:12 GMT; HttpOnly'}))
   

# Generated at 2022-06-23 20:07:03.266729
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Case 1: default sessions dir has no sessions, should return None
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'hello', 'www.google.com', 'https://www.google.com') == {}
    # Case 2: os.path.sep in session name, should return None
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'hello/hello', 'www.google.com', 'https://www.google.com') == {}
    # Case 3: session name is a invalid path
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'hello\\hello', 'www.google.com', 'https://www.google.com') == {}
    # Case 4: valid session name

# Generated at 2022-06-23 20:07:08.166616
# Unit test for constructor of class Session
def test_Session():
    path = Path('./sample_session.json')
    session = Session(path)

    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-23 20:07:11.507980
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', 'test.com', 'http://test.com/')
    assert session.about == 'HTTPie session file'

# Generated at 2022-06-23 20:07:19.674670
# Unit test for constructor of class Session
def test_Session():
    # Create a session object
    session_file_path = DEFAULT_SESSIONS_DIR/'session.json'
    session = Session(session_file_path)
    assert session.path == session_file_path

    # Assert the content of session
    expected_headers = {}
    headers = session['headers']
    assert headers == expected_headers

    expected_cookies = {}
    cookies = session['cookies']
    assert cookies == expected_cookies

    expected_auth = {
        'type': None,
        'username': None,
        'password': None
    }
    auth = session['auth']
    assert auth == expected_auth



# Generated at 2022-06-23 20:07:22.781459
# Unit test for constructor of class Session
def test_Session():
    session = Session("testSession")
    session.load()
    res = session.get("headers", None)
    assert res == {}
    res = session.get("cookies", None)
    assert res == {}
    res = session.get("auth", None)
    assert res == {'type': None, 'username': None, 'password': None}
    return session



# Generated at 2022-06-23 20:07:32.844380
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # pylint: disable=unused-import
    # noinspection PyUnresolvedReferences
    from httpie.utils import strip_ansi
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, 'session1', '', '')
    assert isinstance(session, Session)
    assert session == {'auth': {'type': None, 'username': None, 'password': None}, 'cookies': {}, 'headers': {}}
    # pylint: disable=protected-access
    assert 'session1' in session._path.stem
    from httpie.cli.parser import parser
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, 'session2', '', '')
    assert isinstance(session, Session)

# Generated at 2022-06-23 20:07:43.597417
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names = ['name1', 'name2', 'name3', 'name4']
    cookies = {name: {} for name in names}
    session = Session('path')
    session['cookies'] = {**cookies}
    
    names.pop()
    session.remove_cookies(names) # remove 3 cookies
    assert session['cookies'] == {'name4': {}} # remove 3 cookies and only session['cookies'] = {'name4': {}}
    assert session['cookies'] != cookies # if remove cookies and equal cookies, it will fail

    session['cookies'] = {**cookies}
    session.remove_cookies(names) # remove 3 cookies again
    assert session['cookies'] == {'name1': {}, 'name4': {}} # if remove cookies and equal cookies, it will fail
    
    


# Generated at 2022-06-23 20:07:47.873475
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies_dict = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    cookie_names = ['name1', 'name3']
    s = Session('')
    s['cookies'] = cookies_dict
    s.remove_cookies(cookie_names)
    assert s['cookies'] == {'name2': {'value': 'value2'}}


# Generated at 2022-06-23 20:07:55.938892
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Path of httpie config directory
    config_dir = Path(r'c:\Users\tiany\AppData\Roaming\httpie')
    # Path of session file
    session_file = r'\sessions\github.com_80\test.json'
    session_test = get_httpie_session(config_dir, 'test', 'github.com', 'http://github.com')
    # Compare the path of session file
    assert session_test.path == config_dir / SESSIONS_DIR_NAME /'github.com_80' / f'{session_file}'

# Generated at 2022-06-23 20:08:03.164880
# Unit test for constructor of class Session
def test_Session():
    import json
    import requests
    import os
    import shutil
    path = 'file'
    session = Session(path)
    cookie = requests.cookies.create_cookie(name='name', value='value')
    #session.add_cookie(cookie)
    session.save(path)

    if os.path.exists(path):
        os.remove(path)
    else:
        print('no such file path')

    if os.path.exists('file'):
        os.remove('file')
    else:
        print('no such file file')

test_Session()

# Generated at 2022-06-23 20:08:10.098802
# Unit test for function get_httpie_session
def test_get_httpie_session():
    os.environ["XDG_CONFIG_HOME"] = "./tests/fixtures"
    session = get_httpie_session(None, "dir/dir/dir", "hostname1", "url")
    assert session.path == Path("./tests/fixtures/sessions/hostname1/dir/dir/dir.json")
    session = get_httpie_session(None, "/dir/dir/dir", "hostname2", "url")
    assert session.path == Path("/dir/dir/dir")

# Generated at 2022-06-23 20:08:13.932829
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s=Session('/home/user/.httpie/sessions/github.com/_80.json')
    s.load()
    s.remove_cookies(['logged_in','dotcom_user'])
    print(s)

# Generated at 2022-06-23 20:08:18.160837
# Unit test for constructor of class Session
def test_Session():
    # Test valid session name
    session = Session('a_session.json')
    assert True

    # Test invalid session name
    try:
        Session('a:session.json')
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-23 20:08:27.329660
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import core
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.helpers import get_response
    from httpie.output.streams import get_binary_stream
    from httpie.session import Session

    # Dummy session
    session = Session(path="dummy.json")
    session['headers'] = {}
    session['cookies'] = {}
    session['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }

    # Dummy request

# Generated at 2022-06-23 20:08:39.568302
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        config_dir='~/.httpie/sessions',
        session_name='default',
        host='localhost:4123',
        url='http://localhost:4123/api/v1/form',
    )

# Generated at 2022-06-23 20:08:43.318680
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test.json")
    session.load()
    session['cookies']['abc'] = 'abc'
    session.remove_cookies(['abc'])
    assert 'abc' not in session['cookies']

# Generated at 2022-06-23 20:08:51.614336
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_dict = {
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.6,en;q=0.4',
        'Cookie': 'user=JY',
        'Host': 'example.com'
    }
    expected_cookies = {
        'user': {'value': 'JY'}
    }
    expected_headers = {
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.6,en;q=0.4',
        'Host': 'example.com'
    }
    session = Session("")

# Generated at 2022-06-23 20:08:55.116557
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    # Init
    session = Session(path = Path(''))
    session['cookies'] = {'JWT': 'abc123'}

    # Test 1: Should remove the cookie
    session.remove_cookies(names = ['JWT'])
    assert 'JWT' not in session['cookies']

    # Test 2: Should not remove the cookie
    session.remove_cookies(names = ['JWT'])
    assert 'JWT' not in session['cookies']

# Generated at 2022-06-23 20:09:02.245217
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = ''
    session_name = 'sessiontest'
    host = ''
    url = 'https://httpie.org'
    httpie_session = get_httpie_session(
        config_dir, session_name, host, url)
    assert httpie_session.path == (
        '/home/robin/.config/httpie/sessions/httpie_org/sessiontest.json')

# Generated at 2022-06-23 20:09:12.942424
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('test.json')

# Generated at 2022-06-23 20:09:17.261450
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import copy

    this_session = Session(DEFAULT_SESSIONS_DIR)

    request_headers = RequestHeadersDict()
    request_headers['Cookie']= 'ssssssss'
    request_headers['If-None-Match'] = '000000000000000000'
    this_session.update_headers(request_headers)

    assert_headers = copy.deepcopy(this_session)
    assert_headers['headers'] = {}

    assert this_session == assert_headers

# Generated at 2022-06-23 20:09:21.768679
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'test_get_httpie_session'
    host = None
    url = 'http://www.baidu.com'
    get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-23 20:09:29.342146
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('./tests/test-config')   # config_dir: ./tests/test-config
    session_name = 'default'                   # session_name: default

    url = 'https://david-yang-d.github.io'
    host = urlsplit(url).netloc.split('@')[-1]  # host: david-yang-d.github.io

    # hostname: david-yang-d.github.io
    hostname = host or urlsplit(url).netloc.split('@')[-1]

    path = (config_dir / SESSIONS_DIR_NAME / hostname / f'{session_name}.json') \
        # path: ./tests/test-config/default.json


# Generated at 2022-06-23 20:09:38.560387
# Unit test for constructor of class Session
def test_Session():
    session = Session("/home/httpie/.config/httpie/sessions/some_path.json")
    assert isinstance(session, dict)
    assert session.headers == {}
    assert session.cookies == {}
    assert session.auth == {
        'type': None,
        'username': None,
        'password': None
    }
    assert session.get('headers', None) == {}
    assert session.get('cookies', None) == {}
    assert session.get('auth', None) == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-23 20:09:50.133069
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    # init session test
    session = Session(config_dir / SESSIONS_DIR_NAME / 'test.json')
    session.load()
    # test session update
    assert session.headers == {}
    session.update_headers({'User-Agent': 'httpie-wxt/2.0.0',
                            'Cookie': 'name=value',
                            'User-Agent': 'httpie/2.0.0',
                            'content-type': 'application/json',
                            })
    assert session.headers == {'User-Agent': 'httpie/2.0.0',
                                'content-type': 'application/json',
                                }
    # test cookie update
    assert session.cookies == {}

# Generated at 2022-06-23 20:09:58.238478
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/home/.config/httpie/sessions/localhost/test_domain.json')
    session['cookies'] = {}
    cookie1_name = 'cookie1'
    cookie1_value = 'value1'
    cookie2_name = 'cookie2'
    cookie2_value = 'value2'
    session['cookies'] = {
        cookie1_name: {'value': cookie1_value},
        cookie2_name: {'value': cookie2_value}
    }
    assert session['cookies'] == {
        cookie1_name: {'value': cookie1_value},
        cookie2_name: {'value': cookie2_value}
    }
    session.remove_cookies([cookie1_name])

# Generated at 2022-06-23 20:09:59.672339
# Unit test for constructor of class Session
def test_Session():
    sess = Session("tests/sessions/test_session.json")
    assert sess

# Generated at 2022-06-23 20:10:05.041552
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """
    Test function get_httpie_session.

    """
    DEFAULT_CONFIG_DIR = '/home/xjchen/.config/httpie/'
    get_httpie_session(DEFAULT_CONFIG_DIR, 'session_name', 'aaa', 'bbb')

# Generated at 2022-06-23 20:10:08.673593
# Unit test for constructor of class Session
def test_Session():
    a = Session('/session/1')
    assert a['headers'] == {}
    assert a['cookies'] == {}
    assert a['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-23 20:10:19.218473
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.utils import get_config_dir
    session_name = 'test_get_httpie_session'
    host = None
    url = 'http://example.com/'
    config_dir = get_config_dir()
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session is not None
    assert session['cookies'] == {}
    assert session['headers'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-23 20:10:20.931061
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session(None, "name", "", "")


# Generated at 2022-06-23 20:10:25.517870
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = "test"
    host = "www.google.com"
    url = "https://www.google.com"


    session = get_httpie_session(config_dir, session_name, host, url)

    assert session is not None


# Generated at 2022-06-23 20:10:36.444340
# Unit test for constructor of class Session
def test_Session():
    path = f'httpie_project/config/httpie/sessions/localhost/session1.json'
    session = Session(path)
    session['headers'] = {}
    session['cookies'] = {}
    session['auth'] = {
        'type': 'basic',
        'username': 'admin',
        'password': '1234'
    }

    assert session['headers'] == {}
    assert session['cookies'] == {}

    session['headers'] = {
        'Accept-Language': 'en-US,en',
        'Host': 'httpbin.org'
    }
    assert session['headers'] == {
        'Accept-Language': 'en-US,en',
        'Host': 'httpbin.org'
    }


# Generated at 2022-06-23 20:10:44.277641
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.compat import str
    session = Session('sessions/test.json')
    request_headers = RequestHeadersDict({
        'Content-Type': 'application/json',
        'accept-encoding': 'gzip',
        'cookie': 'SessionID=12345'
    })
    session.update_headers(request_headers)
    assert session.headers == {'accept-encoding': 'gzip'}
    assert session.cookies.keys() == ['SessionID']

# Generated at 2022-06-23 20:10:49.514124
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/Users/billingham/.httpie/')
    session_name = 'abc'
    host = None
    # http://127.0.0.1:5000/manage/accounts/
    url = 'http://127.0.0.1:5000/manage/accounts/'
    result = get_httpie_session(config_dir, session_name, host, url)
    print(result)



# Generated at 2022-06-23 20:11:00.080175
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Ensure that the headers set in a session are not the same as the ones set
    in a request
    """
    session = Session("test.json")
    session.update_headers(RequestHeadersDict({'Accept': 'application/json', 'Accept-Encoding': 'utf-8'}))
    session.update_headers(RequestHeadersDict({'Content-Type': 'text/plain; charset=utf-8', 'Accept-Language': 'en-US'}))

    assert session.headers != RequestHeadersDict({'Accept': 'application/json', 'Accept-Encoding': 'utf-8'})
    assert session.headers == RequestHeadersDict({'Accept-Language': 'en-US', 'Accept': 'application/json'})


# Generated at 2022-06-23 20:11:09.903535
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('/tmp/file')
    sess.cookies = RequestsCookieJar()
    sess.cookies.set_cookie(create_cookie('a', '1'))
    sess.cookies.set_cookie(create_cookie('b', '1'))
    sess.cookies.set_cookie(create_cookie('c', '1'))
    sess.cookies.set_cookie(create_cookie('d', '1'))
    sess.remove_cookies(['d'])
    assert 'd' not in sess.cookies._cookies
    assert 'a' in sess.cookies._cookies

if __name__ == '__main__':
    test_Session_remove_cookies()

# Generated at 2022-06-23 20:11:13.237584
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {"key1": "", "key2": "", "key3": ""}
    session.remove_cookies(["key1", "key3"])
    assert session['cookies'] == {"key2": ""}



# Generated at 2022-06-23 20:11:16.718716
# Unit test for function get_httpie_session
def test_get_httpie_session():
    s = get_httpie_session(None, None, None, 'http://s.com')
    assert s['cookies'] == {}
    assert s['headers'] == {}
    assert s['auth']['type'] is None
    assert s['auth']['username'] is None
    assert s['auth']['password'] is None



# Generated at 2022-06-23 20:11:25.807532
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import json
    from httpie.config import Config
    from httpie.input import KeyValue, SEP_CREDENTIALS

    c = Config()
    c.update_headers = Session.update_headers