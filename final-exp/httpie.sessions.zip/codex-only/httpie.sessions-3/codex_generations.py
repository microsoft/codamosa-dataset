

# Generated at 2022-06-23 20:01:28.852223
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
	path = Path('/tmp/test')
	session = Session(path)
	session.update_headers({'cookies': 'a=1; b=2; c=3'})
	assert all(a in session.cookies for a in ['a', 'b', 'c'])
	session.remove_cookies(['b', 'c'])
	assert 'a' in session.cookies
	assert not any(a in session.cookies for a in ['b', 'c'])

# Generated at 2022-06-23 20:01:33.701738
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert type(get_httpie_session('~/.config/httpie', 'my_session', 'http://localhost:8080/', 'http://localhost:8080/')) == Session


# Generated at 2022-06-23 20:01:43.206262
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from pathlib import Path
    from json import dumps, loads, JSONDecodeError
    from httpie import ExitStatus
    from httpie.session import Session
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.core import main

    def load_httpie_session(session_json):
        try:
            return loads(session_json)
        except JSONDecodeError:
            return None

    # Arrange
    httpie_path = Path(__file__).parent.parent
    plugins_dir = httpie_path / 'plugins'
    plugin_manager = PluginManager(plugins_dir=plugins_dir)
    plugin_manager.load_installed()
    http_basic_auth = plugin_manager.get_auth_plugin("basic")()


# Generated at 2022-06-23 20:01:56.075799
# Unit test for function get_httpie_session
def test_get_httpie_session():
    dir_name = '.httpie_test/'
    path = os.path.expanduser('~')
    dir_path = path + '/' + dir_name

    if os.path.exists(dir_path):
        os.rmdir(dir_path)
    os.mkdir(dir_path)
    os.mkdir(dir_path + SESSIONS_DIR_NAME)

    # save and load session from default dir
    try:
        session = get_httpie_session(Path(dir_path), 'test', None, None)
        assert type(session) is Session
    finally:
        os.rmdir(dir_path + SESSIONS_DIR_NAME)

    # save and load session from specified dir

# Generated at 2022-06-23 20:02:03.902090
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.compat import str
    from httpie import __version__
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.requestitems import RequestItems
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import build_stream_writer
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import Session
    from httpie.sessions import get_httpie_session
    plugin_manager.load_all()

# Generated at 2022-06-23 20:02:07.066645
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(Path('/tmp'), 'foo', 'example.com', 'http://example.com:80')

# Generated at 2022-06-23 20:02:11.588391
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/home/user/.config/httpie/sessions/host/session.json')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-23 20:02:15.751704
# Unit test for constructor of class Session
def test_Session():
    from os.path import expanduser
    from pathlib import Path
    from httpie.config import DEFAULT_CONFIG_DIR
    session_name = "test_session"
    host = 'localhost'
    url = 'http://localhost/'
    config_dir = Path(expanduser(DEFAULT_CONFIG_DIR))
    session = get_httpie_session(config_dir, session_name, host, url)
    assert True

# Generated at 2022-06-23 20:02:21.245179
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """
    Tests whether get_httpie_session is functioning properly.
    """
    from httpie.config import DEFAULT_CONFIG_DIR

    # Test case for http://
    url = "http://example.com"
    expected_result = str(DEFAULT_CONFIG_DIR) + '/sessions/example.com/test_name.json'
    assert get_httpie_session(DEFAULT_CONFIG_DIR, "test_name", None, url).path == expected_result

    # Test case for https://
    url = "https://example.com"
    expected_result = str(DEFAULT_CONFIG_DIR) + '/sessions/example.com/test_name.json'
    assert get_httpie_session(DEFAULT_CONFIG_DIR, "test_name", None, url).path == expected_result



# Generated at 2022-06-23 20:02:30.523854
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from collections import OrderedDict
    from httpie.config import defaults
    from httpie.context import Environment
    from httpie.compat import OrderedDict as StdOrderedDict

    env = Environment(
        config=defaults.copy(),
        stdin=None,
        stdin_isatty=False,
        stdout=None,
        stdout_isatty=True,
        stderr=None,
        stderr_isatty=False,
        override_env=None,
        config_dir=None,
        config_file=None,
        session_name=None,
        should_load_config=True,
    )
    request_headers = env.default_headers
    request_headers.unset('User-Agent')

# Generated at 2022-06-23 20:02:34.640054
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'test_sessions'
    host = None
    url = 'https://httpie.org/doc#sessions'

    session = get_httpie_session(config_dir, session_name, host, url)
    session.dump()

    new_session = get_httpie_session(config_dir, session_name, host, url)
    assert session == new_session



# Generated at 2022-06-23 20:02:40.926694
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    c1 = {'c1': 'val1'}
    c2 = {'c2': 'val2'}
    s.cookies = RequestsCookieJar()
    s.cookies.set_cookie(create_cookie('c1', 'val1'))
    s.cookies.set_cookie(create_cookie('c2', 'val2'))

    s.remove_cookies(['c1', 'c2'])

    assert s.cookies == {'c1': c1, 'c2': c2}

# Generated at 2022-06-23 20:02:46.115454
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('sessions/test.json')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    assert len(session['cookies']) == 2
    session.remove_cookies(['name1', 'name3'])
    assert len(session['cookies']) == 1
    assert session['cookies']['name2'] == 'value2'

# Generated at 2022-06-23 20:02:47.076604
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass


# Generated at 2022-06-23 20:02:50.994807
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'hello' : 'world'}
    names = ['hello']
    session.remove_cookies(names)
    assert session['cookies'] == {}




# Generated at 2022-06-23 20:02:58.281549
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import CaseInsensitiveDict
    request_headers = CaseInsensitiveDict()
    request_headers['Content-Type'] = 'application/json'
    request_headers.add('content-type', 'application/json')
    request_headers['Cookie'] = 'jstests_sid=123456'
    s = Session('test.json')
    s.update_headers(request_headers)
    assert s.headers['content-type'] == 'application/json'
    assert s['headers']['content-type'] == 'application/json'
    assert s['cookies']['jstests_sid']['value'] == '123456'

# Generated at 2022-06-23 20:03:09.264435
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    obj = Session({
        u'headers': [
            (u'Accept', u'application/json'),
            (u'Content-Type', u'application/json'),
        ],
        u'cookies': {
            u'foo': {u'path': u'/', u'value': u'bar'},
            u'baz': {u'path': u'/', u'value': u'qux'}
        }
    })
    # update_headers method of class Session response after execute

# Generated at 2022-06-23 20:03:09.861200
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert False

# Generated at 2022-06-23 20:03:16.234102
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # check valid session name
    config_dir = Path("~/.config")
    url = "https://httpbin.org/get"
    session_name = "test_session"
    host = "httpbin.org"
    assert get_httpie_session(config_dir, session_name, host, url).path == "~/.config/sessions/httpbin_org/test_session.json"

    # check invalid session name
    session_name = "invalid;session"
    assert not get_httpie_session(config_dir, session_name, host, url)
    session_name = ""
    assert not get_httpie_session(config_dir, session_name, host, url)
    session_name = "test_session;test_session"

# Generated at 2022-06-23 20:03:20.348779
# Unit test for function get_httpie_session
def test_get_httpie_session():

    session_name = 'test'
    host = 'http://localhost:8080'
    url = host + '/'

    config_dir = '.'
    session = get_httpie_session(config_dir, session_name, host, url)

    print(session)

# Generated at 2022-06-23 20:03:27.687753
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['headers'] = {
        'abc': 'abc',
        'A': 'B'
    }
    session['cookies'] = {
        'abc': 'abc',
        'A': 'B'
    }
    session['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }
    session.update_headers({
        'abc': 'abc',
        'A': 'B'
    })
    session.remove_cookies({
        'abc': 'abc',
        'A': 'B'
    })

# Generated at 2022-06-23 20:03:34.380274
# Unit test for function get_httpie_session
def test_get_httpie_session():
    try:
        session = get_httpie_session(
            config_dir=Path('/'),
            session_name='localhost_8888_sess.json',
            host='localhost:8888',
            url='http://localhost:8888'
        )
        print(session)
    except FileNotFoundError:
        print('file not found')


if __name__ == "__main__":
    test_get_httpie_session()

# Generated at 2022-06-23 20:03:37.755523
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("")
    session['headers'] = {'Accept': 'text/html', 'Cookie': 'a=b; c=d'}
    session.update_headers({'Accept': 'text/json'})
    assert session['headers'] == {'Accept': 'text/json', 'Cookie': 'a=b; c=d'}

# Generated at 2022-06-23 20:03:42.384528
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    header_list = ['name=value', 'key=value1', 'key=value2']
    s = Session('tests/session_test')
    s.update_headers(RequestHeadersDict(header_list))
    d = {'name': 'value', 'key': 'value1, value2'}
    assert s['headers'] == d



# Generated at 2022-06-23 20:03:49.744358
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test_session")
    session['cookies'] = {'cookie1': {'value': 'val1'}, 'cookie2': {'value': 'val2'}}
    assert session['cookies'] == {'cookie1': {'value': 'val1'}, 'cookie2': {'value': 'val2'}}
    session.remove_cookies(['cookie1', 'cookie3'])
    assert session['cookies'] == {'cookie2': {'value': 'val2'}}

# Generated at 2022-06-23 20:03:52.033260
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("")
    names = ["o", "c", "p", "q" ]
    session.remove_cookies(names)

# Generated at 2022-06-23 20:03:58.426708
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('./session.json'))
    request_headers = RequestHeadersDict(
        {
            'Content-Type': 'application/json',
            'Host': 'httpbin.org',
            'If-None-Match': 'w/"686897696a7c876b7e"'
        }
    )

    session.update_headers(request_headers)

    assert session.get('headers') == {
        'Host': 'httpbin.org'
    }

# Generated at 2022-06-23 20:04:05.108050
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.core import main
    import os

    os.chdir('/tmp/')
    config_dir = Path('.httpie')
    if not os.path.exists(config_dir):
        os.makedirs(config_dir)

    #session_name = 'db_session_1'
    session_name = 'db_session_1'
    url = 'https://postman-echo.com/basic-auth'
    username = 'postman'
    password = 'password'


# Generated at 2022-06-23 20:04:08.282804
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session_headers = {'Accept': 'application/json'}
    session.update_headers(session_headers)
    assert session_headers == session['headers']

# Generated at 2022-06-23 20:04:11.543349
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/home/user/.httpie')
    session_name = 'test_session'
    host = None
    url = 'http://testserver:8000/hi'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session._path == '/home/user/.httpie/sessions/testserver/test_session.json'

# Generated at 2022-06-23 20:04:13.749616
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'session', None, 'http://www.google.com') is not None

# Generated at 2022-06-23 20:04:20.839479
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('my_awesome_session')
    session['headers'] = {}
    session['cookies'] = {'abc': {'value': 'abc_value'},
                          'def': {'value': 'def_value'},
                          'ghi': {'value': 'ghi_value'}}

    names = ['def', 'xyz']

    session.remove_cookies(names)

    assert session['cookies'] == {'abc': {'value': 'abc_value'},
                                  'ghi': {'value': 'ghi_value'}}

# Generated at 2022-06-23 20:04:28.719279
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'test_host_test_port' / '.test.json')
    session.update_headers(RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9', 'Content-Type': 'application/json', 'Cookie': 'test_cookie=test_cookie_value'}))
    assert session.headers == {'User-Agent': 'HTTPie/0.9.9', 'Content-Type': 'application/json'}


# Generated at 2022-06-23 20:04:37.725536
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.output.streams import ColorizingStream
    from httpie.plugins.manager import CLIColors
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import debug

    from httpie import __version__

    config_dir = Path(__file__).parent / 'data'

# Generated at 2022-06-23 20:04:45.295584
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """ Test function get_httpie_session"""
    url = 'http://www.httpie.org'
    session_name = 'test'
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, session_name, None, url)
    print(f'test_get_httpie_session: {session}')
    assert session.path == DEFAULT_SESSIONS_DIR / 'www_httpie_org' / 'test.json'

# Generated at 2022-06-23 20:04:55.428655
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(DEFAULT_SESSIONS_DIR / 'test.json')
    session.load()
    request_headers = {
        "Content-Type": "application/json",
        "Content-Length": "",
        "If-Match": "",
        "User-Agent": "HTTPie/1.0.2",
        "Cookie": "name=value; name2=value2",
    }
    session.update_headers(request_headers)
    assert session.headers == {
        "Content-Type": "application/json",
        "Content-Length": "",
        "If-Match": "",
        "User-Agent": "HTTPie/1.0.2",
    }

# Generated at 2022-06-23 20:05:01.898845
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session('', "session_name", 'host', '').path.name == 'host/session_name.json'
    assert get_httpie_session('', "session_name", None, 'https://host').path.name == 'host/session_name.json'
    assert get_httpie_session('', "session_name", 'host:80', '').path.name == 'host_80/session_name.json'
    assert get_httpie_session('', "session_name", None, 'https://user@host:80').path.name == 'host_80/session_name.json'



# Generated at 2022-06-23 20:05:02.491288
# Unit test for constructor of class Session
def test_Session():
    pass

# Generated at 2022-06-23 20:05:04.543482
# Unit test for constructor of class Session
def test_Session():
    test = Session(path=DEFAULT_SESSIONS_DIR / 'google.json')
    assert type(test) == Session


# Generated at 2022-06-23 20:05:10.637414
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test')
    session['cookies'] = {'name1':{'value':'value1','path':'/'}}
    session.remove_cookies(names=['name1','name2'])
    assert session['cookies'] == {'name1':{'value':None,'path':'/'}}

# Generated at 2022-06-23 20:05:13.240664
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    with open('update_headers.json') as f:
        session = Session(f)
    session.update_headers()

# Generated at 2022-06-23 20:05:15.633124
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path("session.json"))
    session['cookies'] = {'a' : 'b'}
    session.remove_cookies(['b'])
    assert session != None

# Generated at 2022-06-23 20:05:22.583710
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/abc')
    req_headers = {'aaa': '11111', 'bbb': '22222', 'ccc': '33333'}
    session.update_headers(req_headers)
    assert session['headers']['aaa'] == '11111'  # test basic functionality
    assert session['headers']['bbb'] == '22222'
    assert session['headers']['ccc'] == '33333'

    # test if SESSION_IGNORED_HEADER_PREFIXES works as expected
    for prefix in SESSION_IGNORED_HEADER_PREFIXES:
        req_headers = {'aaa': '11111', 'bbb': '22222', 'ccc': '33333'}
        req_headers['If-Abc-Xyz'] = 'abcd'


# Generated at 2022-06-23 20:05:27.775064
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {
        'cookie1': {'value': 'value1'},
        'cookie2': {'value': 'value2'},
        'cookie3': {'value': 'value3'},
    }
    session.remove_cookies(('cookie1', 'cookie3'))
    assert session['cookies'] == {
        'cookie2': {'value': 'value2'},
    }

# Generated at 2022-06-23 20:05:33.782985
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/dev/null')
    session.update_headers({
        'X-HTTPie-1': 'A',
        'X-HTTPie-2': 'B',
        'Content-Length': '0',
        'Cookie': 'X-HTTPie-3=C',
        })
    assert session.headers == {'X-HTTPie-1': 'A', 'X-HTTPie-2': 'B'}
    assert session.cookies == RequestsCookieJar([
        create_cookie('X-HTTPie-3', 'C'),
    ])

# Generated at 2022-06-23 20:05:37.018869
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('foo')
    session['cookies'] = {'bar': {'value': 'baz'}, 'fuzz': {'value': 'bang'}}
    session.remove_cookies(['bar', 'fuzz'])
    assert session['cookies'] == {}



# Generated at 2022-06-23 20:05:42.139881
# Unit test for constructor of class Session
def test_Session():
    session = Session("abc.json")
    assert len(session) == 3
    assert len(session['headers']) == 0
    assert len(session['cookies']) == 0
    assert 'auth' in session
    assert session['auth']['type'] == None
    assert session['auth']['username'] == None
    assert session['auth']['password'] == None


# Generated at 2022-06-23 20:05:46.349663
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        config_dir=Path('/fake/config/dir'), session_name='my-sess',
        host='example.org', url='http://example.org/foo')
    assert session.path == Path('/fake/config/dir') / 'sessions' / 'example_org' / 'my-sess.json'

# Generated at 2022-06-23 20:05:56.375321
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'https://httpie.org/'
    session_names = [
        # Valid names
        'httpie.org',
        'example.com',
        '127.0.0.1',
        'localhost',
        'https://httpie.org/',
        'http://127.0.0.1/',
        # Invalid names
        './httpie.org',
        '../httpie.org',
        'example.org/../httpie.org',
        '/example.org',
        'https://localhost/',
        'http://localhost/',
    ]

# Generated at 2022-06-23 20:06:00.547615
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('./test.json'))
    request_headers = RequestHeadersDict({"Content-Length": None,
                                          "name": "value"})
    session.update_headers(request_headers)
    session.save()
    assert session.headers == {"name": "value"}, "session.headers == name:value"

# Generated at 2022-06-23 20:06:11.042778
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    def update_headers(s: Session, h: dict):
        s.update_headers(RequestHeadersDict(h))

    s = Session('~/.httpie/sessions/localhost/test_session.json')

    # Remove the cookie header
    update_headers(s, {
        'Cookie': 'username=johndoe;city=sunnyvale;',
        'Content-Type': 'text/plain',
        'Content-Length': '88',
    })
    assert s.cookies == RequestsCookieJar(
        [('username', 'johndoe'), ('city', 'sunnyvale')])
    assert s.headers == RequestHeadersDict({
        'Content-Type': 'text/plain',
        'Content-Length': '88'
    })

    # Update the cookie header
    update_headers

# Generated at 2022-06-23 20:06:20.091877
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from hypothesis import given, strategies as st

    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins.auth.basic import BasicAuth
    from httpie.plugins.core import HTTPBasicAuth, HTTPBasicAuthPlugin


    # Create a config file with a sessions directory.
    env = Environment()
    cfg = env.config
    cfg.load()
    cfg.config_dir = Path("/tmp/httpie-test")
    cfg.store()

    # Create a session file by calling the function we want to test.
    session = get_httpie_session(
        cfg.config_dir,
        "test",
        "https://httpbin.org",
        "https://httpbin.org/anything"
    )

    # The session file must exist.

# Generated at 2022-06-23 20:06:24.681729
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session['cookies'] = {'cookie1': 'value1'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:06:27.989626
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/foo.json')
    session['cookies'] = {
        'foo': {
            'value': 'foo'
        }
    }
    session.remove_cookies(['foo'])
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:06:29.877092
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert(DEFAULT_SESSIONS_DIR == Path("/home/sebastian/.config/httpie/sessions"))


# Generated at 2022-06-23 20:06:36.404656
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    cookie_test = Session('cookie_test')
    cookie_test['cookies'] = {'cookie1': {'value': 'value1'},
                              'cookie2': {'value': 'value2'}}
    # Act
    cookie_test.remove_cookies(['cookie1', 'cookie3'])
    # Assert
    assert cookie_test['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-23 20:06:45.885159
# Unit test for constructor of class Session
def test_Session():
    session = Session(Path('./sessions/test.json'))
    headers = {"X-Test1": "test1", "X-Test2": "test2"}
    session['headers'] = headers.copy()
    cookies = {"C-Test1": "test1", "C-Test2": "test2"}
    session['cookies'] = cookies.copy()
    auth_username = "username"
    auth_password = "password"
    session['auth'] = {"type": "http", "username": auth_username, "password": auth_password}
    session.save()

    session2 = Session(Path('./sessions/test.json'))
    session2.load()
    assert session == session2

    session2.remove_cookies(["C-Test1"])

# Generated at 2022-06-23 20:06:48.315686
# Unit test for constructor of class Session
def test_Session():
    session = Session(path = "session.json")
    assert session.helpurl == 'https://httpie.org/doc#sessions'

# Generated at 2022-06-23 20:06:58.314418
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.session import Session
    from requests.cookies import RequestsCookieJar

    s = Session('/tmp/test')

    r = RequestHeadersDict()
    r['Cookie'] = 'b=2; c=3'

    s.update_headers(r)

    j = RequestsCookieJar()
    j.update({'a': '1'})

    s.cookies = j

    assert 'a' in s.cookies
    assert 'b' in s.cookies
    assert 'c' in s.cookies

    s.remove_cookies(['d'])

    assert 'a' in s.cookies
    assert 'b' in s.cookies
    assert 'c' in s.cookies


# Generated at 2022-06-23 20:07:04.233645
# Unit test for constructor of class Session
def test_Session():
    path = 'sessions/test.json'
    session = Session(path)
    assert (session['headers'] == {})
    assert (session['cookies'] == {})
    assert (session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    })

# Generated at 2022-06-23 20:07:14.902773
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    obj = Session('session.json')
    obj['cookies']['name1'] = {'value': 'value1'}
    obj['cookies']['name2'] = {'value': 'value2'}
    obj['cookies']['name3'] = {'value': 'value3'}
    obj['cookies']['name4'] = {'value': 'value4'}
    obj.remove_cookies(['name2', 'name3'])
    assert obj['cookies']['name1'] == {'value': 'value1'}
    assert 'name2' not in obj['cookies']
    assert 'name3' not in obj['cookies']
    assert obj['cookies']['name4'] == {'value': 'value4'}

# Generated at 2022-06-23 20:07:23.710980
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sessions_dir = Path(__file__).parent / SESSIONS_DIR_NAME
    session = get_httpie_session(sessions_dir, 'my_session', 'httpie.org', 'http://httpie.org')
    assert session.keys() == ['headers', 'cookies', 'auth']
    assert session['headers'] == {'Accept-Encoding': 'gzip, deflate'}
    assert session['cookies'] == {'foo': {'value': 'bar'}}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-23 20:07:28.572448
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        path = Path(td)/'session'
        session = get_httpie_session(Path(td), td, None, '')
        print(session.path)
        assert session.path == path
        print(session)
        assert session == {}


# Generated at 2022-06-23 20:07:30.740647
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'default', '', '')
    assert type(session) is Session

# Generated at 2022-06-23 20:07:31.289288
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-23 20:07:34.536158
# Unit test for constructor of class Session
def test_Session():
    my_session = Session(path=Path('sessions/test.json'))
    assert my_session.name == 'sessions/test.json'

# Generated at 2022-06-23 20:07:39.204919
# Unit test for constructor of class Session
def test_Session():
    s = Session('./sessions_dir')

    assert isinstance(s['headers'], dict)
    assert isinstance(s['cookies'], dict)
    assert s['auth']['type'] == None
    assert s['auth']['username'] == None
    assert s['auth']['password'] == None

# Generated at 2022-06-23 20:07:43.237134
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_path = '/Users/leozhang/httpie-sessions'
    session_name = 's1'
    host = ''
    url = 'http://httpbin.org/get'
    assert get_httpie_session(config_path, session_name, host, url).get('cookies') == {}

# Generated at 2022-06-23 20:07:49.979482
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./test_session')
    headers = {'Content-Type': 'text/html; charset=utf-8',
               'If-Modified-Since': 'Tue, 01 Jun 2010 12:23:00 GMT',
               'User-Agent': 'HTTPie/0.9.3'}
    request_headers = RequestHeadersDict(headers)
    session.update_headers(request_headers)
    assert session.headers == {'User-Agent': 'HTTPie/0.9.3'}



# Generated at 2022-06-23 20:07:52.621622
# Unit test for constructor of class Session
def test_Session():
    sessionPath = os.path.join("/test/test_name")
    session = Session(sessionPath)


# Generated at 2022-06-23 20:07:55.090221
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session.update({'cookies': {'name1': 'value1', 'name2': 'value2'}})
    session.remove_cookies(['name1'])
    assert session == {'headers': {}, 'cookies': {'name2': 'value2'}}

# Generated at 2022-06-23 20:07:59.281593
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'content-type': 'application/json'})
    session.update_headers({'content-type': 'application/json'})
    assert session['headers']['content-type'] == 'application/json'

# Generated at 2022-06-23 20:08:05.591407
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('temp/session/session_test.json')
    session['cookies'] = {'a':{'value': 'b'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {}


# Generated at 2022-06-23 20:08:09.266740
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("")
    session['cookies']['a'] = 'a'
    session['cookies']['b'] = 'b'
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {}
# End of unit test


# Generated at 2022-06-23 20:08:18.506920
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    request_headers = RequestHeadersDict()
    request_headers['Content-Length'] = '0'
    request_headers['If-Match'] = '8d777f385d3dfec8815d20f7496026dc'
    request_headers['Cookie'] = 'token=1234; uid=1'
    request_headers['User-Agent'] = 'HTTPie/0.9.9'
    session.update_headers(request_headers)
    assert session.headers['Content-Length'] is None
    assert session.headers['If-Match'] is None
    assert len(session.headers) == 2
    assert len(session.cookies) == 2
    cookie = session.cookies.get('token')
    assert cookie is not None

# Generated at 2022-06-23 20:08:22.012129
# Unit test for function get_httpie_session
def test_get_httpie_session():
    DEFAULT_SESSIONS_DIR = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME
    Session.get_httpie_session(DEFAULT_SESSIONS_DIR, 'https://google.com')

# Generated at 2022-06-23 20:08:31.091756
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path = "")
    session.update_headers({"User-Agent": "HTTPie/0.9.9",
                            "Host": "www.google.com",
                            "Accept": "*/*",
                            "Accept-Encoding": "gzip, deflate"
                            })
    assert session.headers == {"User-Agent": "HTTPie/0.9.9",
                               "Host": "www.google.com",
                               "Accept": "*/*",
                               "Accept-Encoding": "gzip, deflate"
                               }

# Generated at 2022-06-23 20:08:42.608171
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {
        'Content-Length': '42',
        'Content-Type': 'text/plain; charset=utf-8',
        'If-Modified-Since': 'Mon, 03 Oct 2016 16:33:35 GMT',
        'If-Unmodified-Since': 'Mon, 03 Oct 2016 16:33:35 GMT',
        'User-Agent': 'HTTPie/0.9.7',
        'cookie': 'foo=bar;biz=baz',
        'Authorization': 'Basic Zm9vOmJheg==',
    }
    session = Session(path=Path('/path/to/session/file'))
    session.update_headers(request_headers)
    assert session['headers'] == {}
    assert session['cookies']['foo'] == {'value': 'bar'}
   

# Generated at 2022-06-23 20:08:46.427401
# Unit test for function get_httpie_session
def test_get_httpie_session():
    def test(s):
        assert get_httpie_session(Path("/"), s, None, None).path.name == s

    test("my_path/my_session.json")
    test("my_session")
    test("~/my_session.json")

# Generated at 2022-06-23 20:08:54.438180
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {
        'name1': {'value': 'value1'},
        'name2': {'value': 'value2'},
        'name3': {'value': 'value3'},
    }
    session.remove_cookies(['name1'])
    assert session['cookies'] == {
        'name2': {'value': 'value2'},
        'name3': {'value': 'value3'},
    }
    session.remove_cookies(['name2', 'name3'])
    assert session['cookies'] == {}
    session.remove_cookies(['name1'])  # do nothing
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:09:01.695763
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    class C(Session):
        def __init__(self):
            super().__init__(path=object())
            self['cookies'] = {'foo': {'value': 'bar'}}

    c = C()
    assert 'foo' in c['cookies']
    c.remove_cookies(['foo'])
    assert 'foo' not in c['cookies']

# Generated at 2022-06-23 20:09:12.900785
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'https://google.com'
    hostname = 'google.com'
    path = Path('/xyz/abc')
    config_dir = Path('/abc/xyz')
    assert get_httpie_session(config_dir, hostname, url, url).path == Path('/abc/xyz/sessions/google.com/google.com.json')
    assert get_httpie_session(config_dir, path, url, url).path == Path('/xyz/abc')
    assert get_httpie_session(config_dir, "~/abc", url, url).path == Path('/abc')
    assert get_httpie_session(config_dir, "test", url, url).path == Path('/abc/xyz/sessions/google.com/test.json')

# Generated at 2022-06-23 20:09:16.212402
# Unit test for constructor of class Session
def test_Session():
    a = Session('test')
    assert str(a._path) == 'test.json'


# Generated at 2022-06-23 20:09:22.889752
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import pytest
    from httpie.config import DEFAULT_CONFIG_DIR
    config_dir = DEFAULT_CONFIG_DIR
    session_name = "test3"
    host = "https://github.com"
    url = "https://github.com"
    session = get_httpie_session(config_dir, session_name, host, url)
    print(session)
    print(session['cookies'])


# Generated at 2022-06-23 20:09:25.896257
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('~/test_Session_remove_cookies.json')
    session['cookies'] = {'test': {'value': 'pass'}}
    session.remove_cookies(['test'])
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:09:32.771543
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    base = Path(__file__).parent / 'testsessions'
    path = base / 'test_Session_remove_cookies'
    session = Session(path)
    session.load()
    session.remove_cookies(['cookieName1', 'cookieName3'])

    assert 'cookieName1' not in session['cookies']
    assert 'cookieName3' not in session['cookies']

# Generated at 2022-06-23 20:09:42.829802
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/foo.json')
    session.load()
    if not session.is_valid_name('foo'):
        raise ValueError()
    session.update_headers({'User-Agent': 'HTTPie/foo'})
    for prefix in SESSION_IGNORED_HEADER_PREFIXES:
        if 'Content-Type'.lower().startswith(prefix.lower()):
            raise ValueError()
    session_headers = session['headers']
    request_headers = {'Content-Type': 'text/plain'}
    for name, value in request_headers.items():
        if type(value) is not str:
            raise ValueError()
        if name.lower() == 'cookie':
            raise ValueError()
    session_headers[name] = value

# Generated at 2022-06-23 20:09:53.293700
# Unit test for function get_httpie_session
def test_get_httpie_session():
    s = get_httpie_session(Path(os.getenv('HOME') + '/.config'), 'example', 'https://example.com', 'https://example.com')
    assert type(s) == Session
    assert s.path.name == 'example.json'
    assert s.path.parent.name == 'example.com'
    assert s.path.parent.parent.name == SESSIONS_DIR_NAME
    assert s.path.parent.parent.parent.name == '.config'
    assert s.path.parent.parent.parent.parent.name == 'home'
    assert type(s.headers) == RequestHeadersDict
    assert s.headers['abc'] == ''
    assert type(s.cookies) == RequestsCookieJar
    assert len(s.cookies) == 0

# Generated at 2022-06-23 20:09:58.614200
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Arrange
    config_dir = Path('config_dir_path')
    session_name = 'session_name'
    host = Path('host')
    url = 'url'
    
    # Act
    get_httpie_session(config_dir, session_name, host, url)

    # Assert
    return True

# Generated at 2022-06-23 20:10:10.063668
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from json import dumps
    from tempfile import TemporaryDirectory
    from .test import get_unixhttp_session
    from .test import get_httpbin_session
    from .test import get_httpie_session

    with TemporaryDirectory() as td:
        config_dir = Path(td)


# Generated at 2022-06-23 20:10:22.709671
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    request_headers = RequestHeadersDict()

    # Test input type 'headers'
    session.update_headers(request_headers)
    assert session.headers == {}

    # Test input type 'user-agent'
    request_headers['user-agent'] = 'HTTPie/0.9.9'
    session.update_headers(request_headers)
    assert session.headers == {}

    # Test input type 'cookie'
    request_headers['cookie'] = 'SessionID=123'
    session.update_headers(request_headers)
    assert session.cookies == {'SessionID': {'value': '123'}}

    # Test input type 'others'
    request_headers['headername'] = 'headervalue'
    session.update_headers(request_headers)
    assert session

# Generated at 2022-06-23 20:10:34.868556
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # test1
    headers = ['Accept-Encoding: gzip, deflate', 'User-Agent: HTTPie/0.9.9']
    session = Session('')
    session.update_headers(RequestHeadersDict(headers))
    assert session['headers'] == {'Accept-Encoding': 'gzip, deflate'}
    # test2
    headers = ['Content-Type: application/json', 'Accept-Encoding: gzip, deflate', 'User-Agent: HTTPie/0.9.9']
    session = Session('')
    session.update_headers(RequestHeadersDict(headers))
    assert session['headers'] == {'Accept-Encoding': 'gzip, deflate'}
    # test3

# Generated at 2022-06-23 20:10:39.789582
# Unit test for constructor of class Session
def test_Session():
    session = Session(os.path.sep.join("httpie","sessions","test"))
    assert (session == {'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}})


# Generated at 2022-06-23 20:10:41.872805
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'my-session', None, 'https://httpbin.org')


# Generated at 2022-06-23 20:10:44.259605
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict()
    session = Session('./testSession.json')
    session.load()
    session.update_headers(request_headers)
    print(session)

# Generated at 2022-06-23 20:10:51.390420
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.compat import OrderedDict
    from httpie.compat import str
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.sessions import Session
    session = Session(f'{SESSIONS_DIR_NAME}/hostname.json')
    session['headers'] = {
        'a': 'b',
        'c': 'd',
        'if-match': '*',
        'if-none-match': '*',
    }

# Generated at 2022-06-23 20:10:57.647176
# Unit test for constructor of class Session
def test_Session():
    session_path = '~/.config/httpie/sessions/baidu.json'
    session = Session(session_path)
    assert session.path == Path(session_path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-23 20:11:03.010106
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('foo')
    session.update_headers({'Header1': 'Value1', 'Header2': 'Value2'})
    assert session.headers == {'Header1': 'Value1', 'Header2': 'Value2'}
    session.update_headers({'Header1': None})
    assert session.headers == {'Header2': 'Value2'}
    session.update_headers({'Header2': None})
    assert session.headers == {}

# Generated at 2022-06-23 20:11:07.430732
# Unit test for constructor of class Session
def test_Session():
    session = Session('/a/b/c')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-23 20:11:14.747189
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_session = Session('')
    request_headers = {
        'user-agent': 'httpie/1.0.3',
        'Cookie': 'name=value; HttpOnly; Secure',
        'If-Match': '"e0023aa4e"',
        'Content-Type': 'application/json;charset=utf-8',
        'Accept': 'application/json, */*',
    }
    test_session.update_headers(request_headers)
    assert not test_session.headers
    assert test_session['cookies'] == {'name': {'value': 'value'}}

# Generated at 2022-06-23 20:11:18.567545
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {
        'name1': {'value': 'value1'},
        'name2': {'value': 'value2'},
        'name3': {'value': 'value3'}
    }
    session.remove_cookies(['name1', 'name2'])
    assert 'name1' not in session['cookies']
    assert 'name2' not in session['cookies']



# Generated at 2022-06-23 20:11:27.297880
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('~/path')
    req = {
        'header1': "value1",
        'header2': "value2",
        'Cookie': "cookie1=value1; cookie2=value2; cookie3=value3",
        'Another-Cookie': "anothercookie1=value1; anothercookie2=value2; anothercookie3=value3",
        'Content-Type': 'application/json',
        'If-Modified-Since': 'Wed, 21 Oct 2015 07:28:00 GMT',
        'If-Unmodified-Since': 'Wed, 22 Oct 2015 07:28:00 GMT',
    }
    session.update_headers(req)
    
    # Tests update of header1 and header2 and unset header3