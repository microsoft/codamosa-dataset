

# Generated at 2022-06-23 20:01:40.214601
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Creating Session object and adding cookies
    session = Session('test.json')
    session['cookies'] = {
        'cookie1': {'value': 'chocolate'},
        'cookie2': {'value': 'milk'},
        'cookie3': {'value': 'biscuit'},
    }

    # Checking cookies added
    assert 'cookie1' in session['cookies']
    assert 'cookie2' in session['cookies']
    assert 'cookie3' in session['cookies']

    # Deleting cookies
    session.remove_cookies('cookie2 cookie3'.split(' '))

    # Checking cookies deleted
    assert 'cookie1' in session['cookies']
    assert 'cookie2' not in session['cookies']
    assert 'cookie3' not in session['cookies']

# Generated at 2022-06-23 20:01:45.035430
# Unit test for constructor of class Session
def test_Session():
    assert Session("/home/peter/config_dir/sessions/google.cn_443/google.com_443.json")
    assert Session("/home/peter/config_dir/sessions/google.cn_443/google.com_443.json").headers == {}
    assert Session("/home/peter/config_dir/sessions/google.cn_443/google.com_443.json").cookies == {}

# Generated at 2022-06-23 20:01:49.017298
# Unit test for function get_httpie_session
def test_get_httpie_session():
    final_path = str(DEFAULT_SESSIONS_DIR / 'localhost' / 'test.json')
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', None, 'localhost') == final_path

# Generated at 2022-06-23 20:01:59.391587
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('~/.config/httpie').expanduser()
    session_name = 'test'
    host = 'foo.example.com'
    url = f'http://{host}'
    expected = Session(f'{config_dir}/sessions/foo_example_com/{session_name}.json')
    expected.load()
    actual = get_httpie_session(config_dir, session_name, host, url)
    assert actual == expected
    actual = get_httpie_session(config_dir, session_name, None, 'unix:///run/my.sock')
    assert actual.path == f'{config_dir}/sessions/localhost/{session_name}.json'
    assert actual == pathlib.Path(actual.path)

# Generated at 2022-06-23 20:01:59.917841
# Unit test for function get_httpie_session
def test_get_httpie_session():
    ...

# Generated at 2022-06-23 20:02:05.140840
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
	session = Session('path')
	session['cookies'] = {'abc':{'value': '1'}, 'def':{'value': '2'}}
	session.remove_cookies(['abc'])
	assert not 'abc' in session['cookies']
	assert 'def' in session['cookies']
	assert session['cookies']['def']['value'] == '2'

# Generated at 2022-06-23 20:02:14.103497
# Unit test for constructor of class Session
def test_Session():
    import json
    import shutil

    output = Path('./output')
    os.mkdir(output)
    output = Path('./output/test_session.json')
    sess = Session(path = output)
    sess['headers'] = {'user-agent': 'httpie/0.9.9'}
    sess['cookies'] = {'http-session': {'value': 'aaa'}}
    sess['auth'] = {'type': 'basic', 'username': 'user', 'password': 'pass'}
    sess.save()

    with open(output, 'r') as f:
        print(f.read()) 
    shutil.rmtree('./output')


# Generated at 2022-06-23 20:02:14.601204
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert True

# Generated at 2022-06-23 20:02:16.375408
# Unit test for constructor of class Session
def test_Session():
    config_dir = SESSIONS_DIR_NAME
    session_name = VALID_SESSION_NAME_PATTERN
    host = 'host'
    url = 'url'

    assert get_httpie_session(config_dir, session_name, host, url) == "host_port"

# Generated at 2022-06-23 20:02:27.564009
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class T(Session):
        def __init__(self):
            self.dict = {}
            self.ignore_header = False
            self.request_header = {
                'content-type': 'text/plain',
                'if-match': '*',
                'user-agent': 'HTTPie/1.0.2'
            }

        def set(self, key, value):
            if self.ignore_header:
                if key.lower() in SESSION_IGNORED_HEADER_PREFIXES:
                    self.dict[key] = 'xxx'
                else:
                    self.dict[key] = None
            else:
                self.dict[key] = value

    session = T()
    session.update_headers(session.request_header)
    # check headers fields in session

# Generated at 2022-06-23 20:02:36.683033
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path(""))
    request_headers = {
        'key1': 'value1',
        'key2': 'value2',
        'Content-Type': 'application/json',
        'Cookie': 'user=joe;',
        'User-Agent': 'HTTPie/1.0.0',
        'If-Match': '"e0023aa4e"',
        'If-None-Match': '"e0023aa4f"',
    }
    session.update_headers(request_headers)

# Generated at 2022-06-23 20:02:43.970468
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/test_session')
    s['cookies']['c1'] = {'value': None}
    s['cookies']['c2'] = {'value': None}
    s['cookies']['c3'] = {'value': None}
    s.remove_cookies(['c1', 'c3'])
    assert s['cookies'].keys() == {'c2'}
    s['cookies']['c1'] = {'value': None}
    s['cookies']['c2'] = {'value': None}
    s['cookies']['c3'] = {'value': None}
    s.remove_cookies(['c2', 'c1'])
    assert s['cookies'].keys() == {'c3'}


# Generated at 2022-06-23 20:02:46.896743
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session(Path('.'), 'https://api.getpostman.com/oauth2/callback', '', '')

# Generated at 2022-06-23 20:02:56.200280
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from httpie.config import DEFAULT_CONFIG_DIR
    test_sess_dir = DEFAULT_CONFIG_DIR / "sessions"
    test_sess_dir = Path(test_sess_dir).resolve(strict=True)
    name = "test"
    path = test_sess_dir / "test.json"
    sess = Session(path)
    assert sess
    assert sess["headers"] == {}
    assert sess["cookies"] == {}
    auth = sess["auth"]
    assert auth["type"] == None
    assert auth["username"] == None
    assert auth["password"] == None

    # TODO: assert Cookies is Returned

# Generated at 2022-06-23 20:03:01.421761
# Unit test for constructor of class Session
def test_Session():
    s = Session('test/test_httpie.json')
    assert s.path == Path('test/test_httpie.json')
    assert s.headers == {}
    assert s.cookies == RequestsCookieJar()
    assert s.auth == None


# Generated at 2022-06-23 20:03:07.684110
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArgType

    session = Session('/tmp/test_session')
    session.update_headers(KeyValueArgType().convert(
        ['a', 'b', 'c:d', 'User-Agent:e'], 'request_headers'))
    assert session['headers'] == {
        'a': 'b',
        'c': 'd',
        'User-Agent': 'e'
    }
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:03:11.143884
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("sessions/test/test.json")
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}

    session.remove_cookies(['cookie1'])

    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-23 20:03:16.694306
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    cookies = {
        'c1': {'value': 'v1', 'path': '/path1'},
        'c2': {'value': 'v2', 'path': '/path2'},
        'c3': {'value': 'v3', 'path': '/path3'},
        'c4': {'value': 'v4', 'path': '/path4'}
    }

    session['cookies'] = cookies

    # Verify cookies
    jar = session.cookies
    assert jar.get('c1').value == 'v1'
    assert jar.get('c2').value == 'v2'
    assert jar.get('c3').value == 'v3'
    assert jar.get('c4').value == 'v4'

    # Remove c1 & c2


# Generated at 2022-06-23 20:03:25.105466
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers(RequestHeadersDict({
        'Cookie': 'foo=bar',
        'Content-Type': 'application/json',
        'If-None-Match': '"12345"',
        'Accept-Encoding': 'gzip, deflate',
        'User-Agent': 'HTTPie/0.6.0',
    }))
    assert {
        'Accept-Encoding': 'gzip, deflate',
        'Content-Type': 'application/json',
        'If-None-Match': '"12345"'
    } == session['headers']

    assert {'foo': {'value': 'bar'}} == session['cookies']

# Generated at 2022-06-23 20:03:28.495445
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session()
    session['cookies'] = {'1': '1', '2': '2', '3': '3'}
    session.remove_cookies({'1', '3'})
    assert session['cookies'] == {'2': '2'}

# Generated at 2022-06-23 20:03:36.983955
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.models import ContentType
    from httpie.context import Environment
    from httpie.plugins import cookie
    from httpie.output.streams import Stream

    stream = Stream()

    env = Environment(
        stdin=None,
        stdout=stream,
        stderr=stream,
        content_type=ContentType.JSON,
        colors=False,
        defaults=None,
        config=None,
        is_windows=False,
        session=None,
        stdin_isatty=False,
        stdout_isatty=False,
        output_options={},
    )
    jar = RequestsCookieJar()
    cookie.plugin_instance.update_cookie_jar(env, jar, 'sess_id=123')
    session = Session('test_Session_remove_cookies')

# Generated at 2022-06-23 20:03:43.729658
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'test', 'localhost', 'http://localhost:8080/test')
    session.remove_cookies(['test'])
    assert session
    session.update_headers({'test': 'test'})
    assert session.headers.get('test') == 'test'
    assert session.cookies
    assert session.get('auth', None) == None
    session.auth = {'type': 'test', 'raw_auth': 'test'}
    assert session.auth.get('type') == 'test'

# Generated at 2022-06-23 20:03:54.808192
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test_Session_update_headers.json')
    # init with default headers
    assert session.headers == {}
    # basic test
    session.update_headers({'User-agent': 'test'})
    assert session.headers == {'User-agent': 'test'}
    # test two headers
    session.update_headers({'User-agent': 'test2', 'Host': 'a'})
    assert session.headers == {'User-agent': 'test2', 'Host': 'a'}
    # test HTTPie User-agent
    session.update_headers({'User-agent': 'HTTPie/0.9'})
    assert session.headers == {'Host': 'a', 'User-agent': 'test2'}
    # test HTTPie User-agent with prefix
    session.update_headers

# Generated at 2022-06-23 20:03:57.186606
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    a = {'a':1}
    names = ['a','b','c']
    Session.remove_cookies(a,names)
    print(a)

# Generated at 2022-06-23 20:04:03.115993
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    session.update_headers(RequestHeadersDict({'AUTHORIZATION': 'b'}))
    session.update_headers(
        RequestHeadersDict({'AUTHORIZATION': 'token a', 'COOKIE': 'c=d'}))

    assert session.headers ==\
        RequestHeadersDict({'authorization': 'token a'})
    assert session.cookies ==\
        RequestsCookieJar()
    session.cookies.set('c', 'd')
    assert session.cookies == RequestsCookieJar([('c', 'd')])

# Generated at 2022-06-23 20:04:10.984431
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = RequestsCookieJar()
    cookies.set('name1', 'value1')
    cookies.set('name2', 'value2')

    session = Session(path=Path('/path/to/session.json'))
    session.cookies = cookies
    assert set(session.cookies.keys()) == {'name1', 'name2'}

    session.remove_cookies(['name1'])
    assert set(session.cookies.keys()) == {'name2'}

# Generated at 2022-06-23 20:04:20.752081
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('abc')
    s.update_headers(RequestHeadersDict({"Content_Length": ["1"]}))
    assert s.headers == {}
    s.update_headers(RequestHeadersDict({"a": ["1"], "b": ["2"]}))
    assert len(s.headers) == 2
    assert s.headers == {"a": "1", "b": "2"}
    s.update_headers(RequestHeadersDict({"b": ["3"]}))
    assert len(s.headers) == 2
    assert s.headers == {"a": "1", "b": "3"}
    s.update_headers(RequestHeadersDict({"Cookie": "c=1"}))
    assert len(s.headers) == 2

# Generated at 2022-06-23 20:04:25.031200
# Unit test for constructor of class Session
def test_Session():
    session = Session("httpie.json")
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth']['type'] is None
    assert session['auth']['username'] is None
    assert session['auth']['password'] is None

# Generated at 2022-06-23 20:04:33.908346
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/httpie.json')
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    assert 'name1' in session.cookies
    assert 'name2' in session.cookies

    session.remove_cookies(['name1'])
    assert 'name1' not in session.cookies
    assert 'name2' in session.cookies

    session.remove_cookies(['name2'])
    assert 'name1' not in session.cookies
    assert 'name2' not in session.cookies

# Generated at 2022-06-23 20:04:38.251075
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    s['cookies'] = {'a': {'value': '1'}, 'b': {'value': '1'}, 'c': {'value': '1'}}
    s.remove_cookies(['b', 'c'])
    assert s['cookies'] == {'a': {'value': '1'}}

# Generated at 2022-06-23 20:04:41.061428
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(None, 'session-name', 'example.com', 'url').path.name

# Generated at 2022-06-23 20:04:52.416576
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    sess = Session('/path/to/session')

    # test empty source
    request_headers = {}
    sess.update_headers(request_headers)
    assert request_headers == {}
    assert sess['headers'] == {}

    # test simple source
    request_headers = {'Host': 'api.example.com'}
    sess.update_headers(request_headers)
    assert request_headers == {'Host': 'api.example.com'}
    assert sess['headers'] == {'Host': 'api.example.com'}
    assert sess['cookies'] == {}

    # test simple source with ignored header
    request_headers = {'Host': 'api.example.com', 'If-Match': '12345'}
    sess.update_headers(request_headers)
    assert request_

# Generated at 2022-06-23 20:05:01.579634
# Unit test for constructor of class Session
def test_Session():
    session = Session('/path/to/json')
    print(session)
    print(session.headers)
    print(session.cookies)
    print(session.auth)
    # session = Session(b'/path/to/json')
    # session = Session(u'/path/to/json')
    # session = Session(Path('/path/to/json'))
    session.update_headers({'foo': 'bar'})
    print(session.headers)
    session.cookies = {'foo': 'bar'}
    print(session.cookies)
    session.auth = {'type': 'foo', 'username': 'bar', 'password': 'baz'}
    print(session.auth)
    session.remove_cookies({'foo'})
    print(session.cookies)

# Generated at 2022-06-23 20:05:05.372592
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=str())
    session.update_headers(request_headers={
        'Cookie': 'a=b; c=d',
    })
    assert session['cookies'] == {
        'a': {'value': 'b'},
        'c': {'value': 'd'}
    }

# Generated at 2022-06-23 20:05:14.000826
# Unit test for function get_httpie_session
def test_get_httpie_session():
    try:
        session_name = 's1'
        host = 'github.com'
        url = 'github.com:443'
        config_dir = DEFAULT_SESSIONS_DIR
        session = get_httpie_session(config_dir, session_name, host, url)
        assert session['auth'] == {
            'username': None, 'password': None, 'type': None}
        assert not session['cookies']
    except:
        raise AssertionError('fail to execute')
    else:
        print('success')

# Generated at 2022-06-23 20:05:16.171117
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sess = get_httpie_session(
        Path('.config'), 'session', None, 'https://example.org/foo')
    print(sess)
    assert isinstance(sess, Session)



# Generated at 2022-06-23 20:05:26.926292
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict([('H1', 'V1'), ('H2', 'V2')])
    session = Session('/tmp/httpie_session.json')
    session.update_headers(request_headers)
    assert session.headers == RequestHeadersDict([('H1', 'V1'), ('H2', 'V2')])
    session.update_headers(RequestHeadersDict([('h1', 'v3'), ('H2', None), ('H3', 'V3')]))
    assert session.headers == RequestHeadersDict([('H1', 'v3'), ('H2', 'V2'), ('H3', 'V3')])

# Generated at 2022-06-23 20:05:28.499910
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(None, "test", None, "http://www.google.com")

# Generated at 2022-06-23 20:05:33.160590
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/')
    session['cookies'] = {'a': 'b', 'c': 'd', 'e': 'f'}
    session.remove_cookies(names=['a', 'e'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-23 20:05:40.811867
# Unit test for function get_httpie_session
def test_get_httpie_session():
    configuration_dir = Path.cwd()
    httpie_session = get_httpie_session(configuration_dir, 'test_session', 'host', 'url')
    assert isinstance(httpie_session['headers'], dict)
    assert isinstance(httpie_session['cookies'], dict)
    assert set(httpie_session['auth'].keys()) == {'type', 'username', 'password'}
    assert isinstance(httpie_session.headers, RequestHeadersDict)
    assert isinstance(httpie_session.cookies, RequestsCookieJar)
    assert isinstance(httpie_session.auth, AuthBase)
    assert isinstance(httpie_session.remove_cookies, object)


# Generated at 2022-06-23 20:05:46.790859
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_dict = {'cookies': {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}}
    session = Session('./sample_file')
    session.update(session_dict)
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1', 'cookie2'])
    assert 'cookies' not in session



# Generated at 2022-06-23 20:05:49.454491
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("/tmp/test_session.json")
    session['cookies'] = dict(cookie1='value1', cookie2='value2')
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == dict(cookie2='value2')


# Generated at 2022-06-23 20:06:00.268754
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config_dir = DEFAULT_SESSIONS_DIR
    session_name = 'test_Session_update_headers'
    host = "www.google.com"
    url = "http://www.google.com"
    session = get_httpie_session(config_dir, session_name, host, url)
    request_headers = RequestHeadersDict()
    request_headers['user-agent'] = "Mozilla/5.0"
    request_headers['content-length'] = '0'
    request_headers['If-mod'] = '0'
    session.update_headers(request_headers)
    assert 'user-agent' in session['headers']
    assert 'content-length' not in session['headers']
    assert 'If-mod' not in session['headers']
    # Clean up

# Generated at 2022-06-23 20:06:07.379909
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # create a session
    session = Session('~/toto.json')
    session.update_headers(request_headers={'Accept': 'image/*', 'Cookie': 'a=toto'})
    session.remove_cookies(names=['a'])
    assert 'a' not in session['cookies']
    assert 'Accept' in session['headers']
    assert session['headers']['Accept'] == 'image/*'

# Generated at 2022-06-23 20:06:12.782045
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test.json')
    s['cookies'] = dict(e=1, f=1)
    s.remove_cookies(['e', 'g'])
    assert s['cookies'] == dict(f=1)



# Generated at 2022-06-23 20:06:18.499637
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json
    s = Session("httpbin")
    f = open("httpbin.json", "r")
    session_json = json.load(f)
    s.cookies = RequestsCookieJar()
    for cookie in session_json["cookies"]:
        s.cookies.set_cookie(create_cookie(cookie, session_json["cookies"][cookie]["value"], **session_json["cookies"][cookie]))
    assert len(list(s.cookies)) == 1
    s.remove_cookies(["foo"])
    assert len(list(s.cookies)) == 0

# Generated at 2022-06-23 20:06:23.175638
# Unit test for constructor of class Session
def test_Session():
    test_path = 'temp/test.json'
    session = Session(test_path)
    session.load()
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-23 20:06:28.625116
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session.json')
    session['cookies']['name1'] = {}
    session['cookies']['name2'] = {}
    session['cookies']['name3'] = {}
    session['cookies']['name4'] = {}

    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'].keys() == dict_keys(['name2', 'name4'])

# Generated at 2022-06-23 20:06:39.033509
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # This test is to test if the session header will be overwrite by the request header
    session = Session("test.json")
    session['headers']['header1'] = 'session-value1'
    session['headers']['header2'] = 'session-value2'
    session['headers']['header3'] = 'session-value3'

    request_headers = RequestHeadersDict()
    request_headers['header1'] = 'request-value1'
    request_headers['header3'] = 'request-value3'

    session.update_headers(request_headers)
    value1 = session['headers']['header1']
    value2 = session['headers']['header2']
    value3 = session['headers']['header3']

    assert value1 == 'request-value1'

# Generated at 2022-06-23 20:06:42.606840
# Unit test for constructor of class Session
def test_Session():
    test_session = Session("test_session")
    assert test_session['auth']['type'] == None
    assert test_session['auth']['username'] == None
    assert test_session['auth']['password'] == None
    assert test_session['cookies'] == {}
    assert test_session['headers'] == {}

# Generated at 2022-06-23 20:06:48.967213
# Unit test for constructor of class Session
def test_Session():
    try:
        os.mkdir("./test/0")
    except OSError:
        pass
    test = Session(path='./test/0/session.json')
    assert test['headers'] == {}
    assert test['cookies'] == {}
    assert test['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-23 20:06:54.994234
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session({'cookies' : { 'cookie1' : 'value1', 'cookie2' : 'value2'}})
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2' : 'value2'}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:07:03.017327
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.config import FileConfig
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from requests.auth import AuthBase
    from requests.cookies import RequestsCookieJar, create_cookie
    from requests.structures import CaseInsensitiveDict
    from httpie.cli.dicts import RequestHeadersDict

    plugin_manager.register(HTTPBasicAuth)
    __headers = {'header_1': 'header_1_value', 'header_2': 'header_2_value'}
    __auth = {'type': 'basic', 'raw_auth': "username:password"}
    # Create a session file
    __file_config = FileConfig(path=Path('~/.httpie/sessions/dir1/dir2/dir3'))
    __

# Generated at 2022-06-23 20:07:10.306544
# Unit test for constructor of class Session
def test_Session():
    new_session=Session('test_name')
    print(new_session)
    print(new_session['auth']['type'])
    new_session['auth']['type']='Basic'
    new_session['auth']['username']='cwc'
    new_session['auth']['password']='cwc'
    print(new_session['auth']['type'])
    new_session.save()


# Generated at 2022-06-23 20:07:19.710636
# Unit test for constructor of class Session
def test_Session():
    # create a session
    session_name = 'hello'
    user = 'kristen'
    pwd = '123456'
    auth = 'Basic'
    raw_auth = 'QWxhZGRpbjpPcGVuU2VzYW1l'
    header = {
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Host': 'httpbin.org',
        'User-Agent': 'HTTPie/1.0.3'
    }
    cookie_header = 'test_session=test_value; test_session_2=test_value_2'

# Generated at 2022-06-23 20:07:24.402245
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/some/path')
    session['cookies'] = {
        'a' : {},
        'b' : {},
        'c' : {},
    }
    session.remove_cookies(['b', 'd'])
    assert set(session['cookies'].keys()) == {'a', 'c'}

# Generated at 2022-06-23 20:07:34.060745
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {"Accept": "application/json", "Content-Type": "application/json", "Cookie": "key1=value1; key2=value2", "Cache-Control": "no-cache"}
    session = Session(Path("./test"))
    session.update_headers(headers)
    assert session.get('headers', {}).get('Accept') == 'application/json'
    assert session.get('headers', {}).get('Content-Type') == 'application/json'
    assert session.get('headers', {}).get('Cookie') is None
    assert session.get('headers', {}).get('Cache-Control') is None
    assert session.get('cookies', {}).get('key1') == {'value': 'value1'}

# Generated at 2022-06-23 20:07:39.594738
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://httpbin.org/get'
    session_name = 'test'
    config_dir = './'
    session = get_httpie_session(config_dir, session_name, host=None, url=url)
    print(session)


if __name__ == '__main__':
    test_get_httpie_session()

# Generated at 2022-06-23 20:07:43.836007
# Unit test for function get_httpie_session
def test_get_httpie_session():
    test_session = get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='session',
        host=None,
        url='https://www.google.com/',
    )
    assert test_session is not None and isinstance(test_session, Session)


# Generated at 2022-06-23 20:07:46.443401
# Unit test for constructor of class Session
def test_Session():
    session = Session('localhost:3333/foo/bar')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-23 20:07:53.217834
# Unit test for constructor of class Session
def test_Session():
    
    config_dir = Path('~/.httpie/sessions')
    session_name = 'localhost/sessions'
    host = 'localhost'
    url = 'http://localhost/sessions'
    get_httpie_session(config_dir, session_name, host, url)
    Session(config_dir)

    path = '~'
    Session(path)
  
    path = '/home/loki/.httpie/sessions/localhost/sessions.json'
    Session(path)
   
    path = '/home/loki/.httpie/sessions/localhost/sessions.json'
    session = Session(path)
    session.update_headers(RequestHeadersDict(session['headers']))
    
    session['cookies'] = {}
    session.cookies = RequestsCookieJar()

   

# Generated at 2022-06-23 20:08:03.241918
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Note: The used class is a local class here - use the full path.
    """
    session = httpie.sessions.Session(
        Path('/') / 'foo' / 'bar' / 'baz.json'
    )
    session.load()
    session['cookies'] = {
        'foo' : {'value' : 'bar', 'path' : '/foo/'},
        'bar' : {'value' : 'baz', 'path' : '/bar/'},
        'baz' : {'value' : 'qux', 'path' : '/baz/'},
    }
    session.remove_cookies(['foo', 'baz'])

# Generated at 2022-06-23 20:08:07.432460
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session(path='test.json')
    sess['cookies'] = {'cookie1':{'value': 'value1'}, 'cookie2':{'value': 'value2'}}
    sess.remove_cookies(['cookie1', 'cookie3'])
    assert sess['cookies'] == {'cookie2':{'value': 'value2'}}



# Generated at 2022-06-23 20:08:14.638749
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'test_session_name'
    url = 'http://www.baidu.com'
    host = None
    session = get_httpie_session(
        config_dir,
        session_name,
        host,
        url
    )
    assert session.headers == {}
    assert session.auth == None
    assert session.cookies == RequestsCookieJar()

# Generated at 2022-06-23 20:08:20.588307
# Unit test for constructor of class Session
def test_Session():
    # JsonPath
    jsonPath = './config/sessions/www_google_com/-.json'
    session = Session(jsonPath)
    assert(session['headers'] == {})
    assert(session['cookies'] == {})
    assert(session['auth'] == {'type': None, 'username': None, 'password': None})


# Generated at 2022-06-23 20:08:33.291226
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_remove_cookies')
    session['cookies'] = {
        "SESSIONID": {
            "domain": ".test.com",
            "expires": None,
            "path": "/",
            "secure": False,
            "value": "12345"
        },
        "Personal": {
            "domain": ".test.com",
            "expires": None,
            "path": "/",
            "secure": False,
            "value": "personal"
        }
    }
    session.remove_cookies(["SESSIONID","Personal"])
    assert session['cookies'] == {}
    session2 = Session('test_remove_cookies')

# Generated at 2022-06-23 20:08:43.995176
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.output.streams import StdoutBytesIO
    from httpie.input import ParseError
    from httpie.plugins.builtin import FormattedKeyValue
    from httpie import ExitStatus
    from httpie.cli.parser import parse_items

    stdout = StdoutBytesIO()

    with ExitStatus.raise_for_status(stdout=stdout):
        if name == 'auth':
            if value is None:
                auth = None
            else:
                auth_plugin = plugin_manager.get_auth_plugin(value)()
                auth = auth_plugin.get_auth(
                    username='username' if auth_plugin.auth_require_username
                    else None,
                    password='password' if auth_plugin.auth_require_password
                    else None,

                )

# Generated at 2022-06-23 20:08:46.745796
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    names = ['name1', 'name2']
    session.remove_cookies(names)
    assert session == {'cookies': {}}



# Generated at 2022-06-23 20:08:50.860430
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("path")
    session['cookies'] = {'name1':'value1', 'name2':'value2'}
    print(session)
    session.remove_cookies({'name1','name3'})
    print(session)
    assert session['cookies'] == {'name2':'value2'}

# Generated at 2022-06-23 20:08:53.991091
# Unit test for constructor of class Session
def test_Session():
    s = Session(path='/a/b/c/d')
    assert s.about == 'HTTPie session file'
    assert s.helpurl == 'https://httpie.org/doc#sessions'
    assert s.path == '/a/b/c/d'

# Generated at 2022-06-23 20:08:59.243802
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, "session-file", None, "http://localhost") is not None
    assert get_httpie_session(DEFAULT_CONFIG_DIR, "/root/session-file", None, "http://localhost") is not None


# Generated at 2022-06-23 20:09:04.539943
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('dummy.json')
    s['cookies'] = { 'a' : {'value': 1}, 'b': {'value': 2} }
    s.remove_cookies(['b'])
    assert len(s['cookies']) == 1
    assert 'b' not in s['cookies']



# Generated at 2022-06-23 20:09:10.022603
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    cookie_items = {'name1':'value1', 'name2':'value2', 'name3':'value3'}
    session['cookies'] = cookie_items
    assert session['cookies'] == cookie_items

    session.remove_cookies(['name1', 'name2', 'name4'])
    assert session['cookies'] == {'name3':'value3'}

# Generated at 2022-06-23 20:09:14.216325
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session.json')
    request_headers = {'host': 'www.baidu.com', 'User-Agent': 'Mozilla/5.0'}
    session.update_headers(request_headers)
    print(session['headers'])


if __name__ == '__main__':
    test_Session_update_headers()

# Generated at 2022-06-23 20:09:25.634646
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    cookies = {}
    headers = {}
    request_headers = {'header1': 'value1', 'header2': 'value2'}
    s = Session("session_path")
    s.update_headers(request_headers)
    assert s['headers']['header1'] == 'value1'
    assert s['headers']['header2'] == 'value2'

    request_headers = {}
    s = Session("session_path")
    s.update_headers(request_headers)
    assert s['headers'] == {}

    # Add cookies to the session
    s.cookies = {'cookie1': 'value1', 'cookie2': 'value2'}
    assert s['cookies']['cookie1']['value'] == 'value1'
    assert s['cookies']['cookie2']['value']

# Generated at 2022-06-23 20:09:31.281534
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from tests.test_utils import MockRequest
    sess = Session(None)
    sess.update_headers(MockRequest().headers)
    assert list(sess.headers.keys()) == ['Content-Type', 'Host']


# Generated at 2022-06-23 20:09:38.002621
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sessions_dir = Path('/tmp/httpie/sessions')
    session_name = 'test_session'
    host = 'localhost'
    url = 'localhost:8080/test'

    expected_path = (
        sessions_dir / SESSIONS_DIR_NAME / host / f'{session_name}.json'
    )
    session_path = get_httpie_session(sessions_dir, session_name, host, url)
    assert session_path == expected_path

# Generated at 2022-06-23 20:09:42.441763
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path(__file__))
    session['cookies'] = {'c1': {}, 'c2': {}}
    session.remove_cookies(['c2'])
    assert session['cookies'] == {'c1': {}}

# Generated at 2022-06-23 20:09:46.518969
# Unit test for constructor of class Session
def test_Session():
    sess = Session('testing')
    assert sess.path == 'testing'
    assert sess.headers == {}
    assert sess.cookies == {}
    assert sess.auth == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-23 20:09:50.831853
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path.home()/'.config'
    url = 'https://www.yourdomain.com'
    session_name = 'my-session'
    host = 'dummyhost'
    session = get_httpie_session(config_dir, session_name, host, url)
    session.load()

# Generated at 2022-06-23 20:09:53.168540
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test.json')
    cookies = [('test', 'test')]
    session.cookies = create_cookie(cookies)
    assert 'test' in session.cookies
    session.remove_cookies(names=['test'])
    assert 'test' not in session.cookies



# Generated at 2022-06-23 20:10:02.291228
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    request_headers = {}
    request_headers['Content-Length'] = '12'
    request_headers['Accept-Encoding'] = 'gzip, deflate'
    request_headers['Cookie'] = 'session-id=123; name=456; expires=Thu, 01 Jan 1970 00:00:00 GMT'
    request_headers['User-Agent'] = 'HTTPie/0.9.9'
    request_headers['Key'] = 'Value'
    session.update_headers(request_headers)
    assert session['headers'] == {'Key': 'Value'}
    assert session['cookies'] == {'name': {'value': '456'}, 'session-id': {'value': '123'}}

# Generated at 2022-06-23 20:10:05.091401
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'asd', 'asd', 'asd') is not None


# Generated at 2022-06-23 20:10:17.249109
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from os import makedirs
    from tempfile import gettempdir
    from unittest.mock import Mock
    from pathlib import Path
    from httpie.context import Environment
    from httpie.sessions import Session

    session_name = 'test'
    host = 'host'
    tmp = Path(gettempdir())
    session_path = Path(tmp / 'httpie' / 'sessions' / host / f'{session_name}.json')
    config_dir = Path(tmp / 'httpie')
    makedirs(str(config_dir), exist_ok=True)
    makedirs(str(config_dir / 'sessions' / host), exist_ok=True)

    environment = Mock(Environment)
    environment.config_dir = config_dir
    environment.session = None
    environment.session_

# Generated at 2022-06-23 20:10:20.826990
# Unit test for constructor of class Session
def test_Session():
    session = Session(path='path')
    assert 'headers' in session.keys()
    assert 'cookies' in session.keys()
    assert 'auth' in session.keys()


# Generated at 2022-06-23 20:10:24.844168
# Unit test for constructor of class Session
def test_Session():
    session = Session('~/session.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-23 20:10:31.271722
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("sessions/host/session.json")
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}, 'c': {'value': '3'}}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': {'value': '3'}}

# Generated at 2022-06-23 20:10:34.965893
# Unit test for function get_httpie_session
def test_get_httpie_session():
    host = 'www.example.com'
    url = 'http://www.example.com/hello'
    session_name = 'test'
    session = get_httpie_session(DEFAULT_CONFIG_DIR, session_name, host, url)
    assert session.filename == os.path.join(SESSIONS_DIR_NAME, host, f'{session_name}.json')

# Generated at 2022-06-23 20:10:39.483969
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    session.update_headers({'X-Test': 'test'})

    assert 'X-Test' in session['headers']
    assert session['headers']['X-Test'] == 'test'

# Generated at 2022-06-23 20:10:41.311186
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert DEFAULT_SESSIONS_DIR == DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME

# Generated at 2022-06-23 20:10:46.641241
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/root/.config/httpie/sessions/abc.json'))
    session.load()
    request_headers = {'Content-Type': None, 'If-Non-Match': '123', 'If-None-Match': '123'}
    session.update_headers(request_headers)
    assert session['headers'] == {}
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:10:54.895957
# Unit test for constructor of class Session
def test_Session():   
    # session init
    session = Session("sessions")
    assert session.helpurl == "https://httpie.org/doc#sessions"
    assert session.path == "sessions"
    assert session.about == "HTTPie session file"
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-23 20:11:04.369652
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers_dict1 = {
        'content-type': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'host': 'search.yahoo.com',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0',
        'accept-language': 'en-US,en;q=0.5',
        'accept-encoding': 'gzip, deflate',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    }

# Generated at 2022-06-23 20:11:14.611964
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_object = Session(path='')
    session_object.headers['my_header'] = 'my_value'
    session_object.headers['my_header_2'] = 'my_value_2'
    session_object.headers['my_header_3'] = 'my_value_3'
    session_object.update_headers({
        'my_header': 'my_new_value',
        'my_header_4': 'my_value_4',
        'my_header_5': 'my_value_5',
        'my_header_6': 'my_value_6',
        'my_header_7': 'my_value_7',
        'my_header_8': 'my_value_8',
    })

# Generated at 2022-06-23 20:11:17.170775
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session')
    session['cookies'] = {"test_cookie": {"value":"test_value"}}
    assert session.remove_cookies(["test_cookie"]) == None
    assert session.get('cookies') == {}

# Generated at 2022-06-23 20:11:21.808888
# Unit test for constructor of class Session
def test_Session():
    a = Session(path="/var/tmp/test.json")
    assert a['headers'] == {}
    assert a['cookies'] == {}
    assert a['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }
    assert a.path == Path("/var/tmp/test.json")


# Generated at 2022-06-23 20:11:25.127969
# Unit test for constructor of class Session
def test_Session():
    session = Session('A')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth']['type'] == None
    assert session['auth']['username'] == None
    assert session['auth']['password'] == None


# Generated at 2022-06-23 20:11:26.851742
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session(DEFAULT_CONFIG_DIR, "test", "http://localhost", "http://localhost/test")

# Generated at 2022-06-23 20:11:33.443786
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    a = Session(path='/home/user/.httpie/sessions/localhost/test.json')
    a['cookies'] = {'cookie1':{'value':'testvalue'},'cookie2':{'value':'testvalue'},'cookie3':{'value':'testvalue'}, 'cookie4': {'value':'testvalue'}}
    a.remove_cookies(names=['cookie1','cookie2'])
    assert len(a['cookies'].keys()) == 2
