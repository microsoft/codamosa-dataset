

# Generated at 2022-06-23 20:01:34.033668
# Unit test for function get_httpie_session
def test_get_httpie_session():
    dir_name = Path('/Users/jingfu.chen/work/code/python/httpie/httpie/tests/data')
    get_httpie_session(dir_name, 'session_name', 'host', 'url')

# Generated at 2022-06-23 20:01:38.288164
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'a':'b', 'b': 'c', 'e':'f'}

    names = ['b', 'd', 'a']
    session.remove_cookies(names)

    assert session['cookies'] == {'e':'f'}



# Generated at 2022-06-23 20:01:47.106877
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Scenario 1: Cookie present in session is removed from session
    path1 = Path("/path1")
    s1 = Session(path1)
    s1['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    s1.remove_cookies(['cookie1'])
    assert 'cookie1' not in s1['cookies']
    assert 'cookie2' in s1['cookies']

    # Scenario 2: Cookie not present in session is not removed from session
    path2 = Path("/path2")
    s2 = Session(path2)
    s2['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    s2.remove_cookies(['cookie3'])

# Generated at 2022-06-23 20:01:58.375492
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.config import BaseConfigDict
    from httpie.plugins.registry import plugin_manager
    from httpie.sessions import Session
    from httpie.utils import get_best_encoding

    config_dic = BaseConfigDict(path=Path('.'))    
    session = Session("session.json")
    session.load()

    # Test case: update_headers: add new header
    request_headers = RequestHeadersDict({"test-a":"test-a"})
    session.update_headers(request_headers)
    assert session['headers'] == {"test-a":"test-a"}

    # Test case: update_headers: update old header
    request_headers = RequestHeadersDict({"test-a":"new-a"})

# Generated at 2022-06-23 20:02:05.801610
# Unit test for function get_httpie_session
def test_get_httpie_session():


    def get_session(dest, url, hostname):
        return get_httpie_session(
            config_dir=Path('~/.httpie'),
            session_name=dest,
            host=hostname,
            url=url
        )
    
    # Session is in ~/.httpie/sessions/hostname/default.json
    get_session('default','http://localhost','localhost')
    # Session is in ~/.httpie/sessions/hostname:8080/default.json
    get_session('default','http://localhost:8080','localhost:8080')
    # Session is in ~/.httpie/sessions/localhost/default.json
    get_session('default','http://localhost:8080','')
    # Session is in ~/.httpie/sessions/localhost_8080/default.json

# Generated at 2022-06-23 20:02:07.620568
# Unit test for function get_httpie_session
def test_get_httpie_session():
    with open('/tmp/httpie-session-example.json', 'r') as f:
        sessions = f.read()
    session = get_httpie_session('/tmp', 'test', None, 'http://www.example.com')
    assert session == sessions

# Generated at 2022-06-23 20:02:16.440434
# Unit test for constructor of class Session
def test_Session():
    from httpie.config import Config
    session = Session('sessions/test_session.json')

# Generated at 2022-06-23 20:02:22.325661
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_session = Session('/')
    test_session['cookies'] = {'a': {'value': 'a'}, 'b': {'value': 'b'}}
    test_session.remove_cookies(['a', 'c'])
    assert test_session['cookies'] == {'b': {'value': 'b'}}



# Generated at 2022-06-23 20:02:32.277008
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('asdf')
    s.load()
    r1 = RequestHeadersDict({"a":"b", "c":"d"})
    r2 = RequestHeadersDict({"a":"b", "c":"d"})
    s.update_headers(r1)
    s.update_headers(r2)
    assert r1 == r2
    assert s['headers'] == {"a":"b", "c":"d"}
    assert isinstance(s['headers'], dict)

    r3 = RequestHeadersDict({"a":"b", "c":"d"})
    s.update_headers(r3)
    assert r1 == r3
    assert s['headers'] == {"a":"b", "c":"d"}
    assert isinstance(s['headers'], dict)    
    

# Generated at 2022-06-23 20:02:38.613694
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session.cookies = RequestsCookieJar()
    session['cookies']['foo'] = {'value': 'bar'}
    session['cookies']['baz'] = {'value': 'qux'}
    session.remove_cookies(['foo'])
    assert 'foo' not in session['cookies']
    assert 'baz' in session['cookies']
    session.remove_cookies(['baz'])
    assert 'baz' not in session['cookies']



# Generated at 2022-06-23 20:02:41.349670
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.plugins.manager import plugin_manager
    plugin_manager.get_v1_plugins()
    print(get_httpie_session(DEFAULT_SESSIONS_DIR, 'default', None, 'http://localhost/_ping'))

# Generated at 2022-06-23 20:02:44.819921
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict({'Content-Type':'application/json'})
    session = Session('test')
    session.update_headers(request_headers)
    print(request_headers)
    print(session.headers)

# Generated at 2022-06-23 20:02:55.557320
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.request import Response
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import AuthPlugin
    import os
    import pickle
    import shutil
    import tempfile

    raw_auth = 'username:password'
    auth_plugin = plugin_manager.get_auth_plugin('basic')()
    auth_plugin.raw_auth = raw_auth
    auth = auth_plugin.get_auth(
            **{k: v for k, v in auth_plugin.parse_auth(raw_auth).items()
               if v}
    )

    session = Session('session')
    assert isinstance(session, BaseConfigDict)
    assert session

# Generated at 2022-06-23 20:03:07.532497
# Unit test for constructor of class Session
def test_Session():
    session = Session("./test_session.json")
    headers = RequestHeadersDict(session['headers'])
    cookie = RequestsCookieJar()
    session['cookies'] = cookie
    assert cookie == session.cookies
    
    cookie_ = RequestsCookieJar()
    auth = {'type': 'Basic',
            'raw_auth': 'username:password',
            'username': 'username',
            'password': 'password'}
    session['auth'] = auth
    cookies = {'username': 'username', 'password': 'password'}
    names = str()
    session.remove_cookies(names)
    assert session.headers == headers
    assert session.cookies == cookie_
    assert session.auth == auth
    
    session_name = ".test_session"
    auth = None
    url

# Generated at 2022-06-23 20:03:12.670404
# Unit test for constructor of class Session
def test_Session():
    s = Session(path = 'C:/Users/trung/AppData/Roaming/httpie/sessions/httpbin_org/user_password.json')
    assert s.path == Path('C:/Users/trung/AppData/Roaming/httpie/sessions/httpbin_org/user_password.json')
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-23 20:03:23.857627
# Unit test for constructor of class Session
def test_Session():
    from .doc import Doc
    from .main import get_config_dir
    import sys
    import json

    # test constructor
    path = 'test.json'
    session = Session(path)
    assert session.path == 'test.json'
    assert session.get('headers') == {}
    assert session.get('cookies') == {}
    assert session.get('auth') == {
        'type': None,
        'username': None,
        'password': None
    }
    # test load with empty file
    session = Session(path)
    with open(path, 'w') as fd:
        json.dump({}, fd)
    session.load()
    assert session['headers'] == {}
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:03:35.030258
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'test_Session_update_headers'
    host = None
    url = 'https://localhost'

    session = Session(config_dir / SESSIONS_DIR_NAME / session_name)
    session.load()

    headers_before = session['headers']

    # test if update_headers() ignores certain name prefixes
    headers_to_update = RequestHeadersDict({
        'Content-Type': 'application/json',
        'If-Modified-Since': 'Tue, 15 Nov 1994 12:45:26 GMT',
        'Accept': 'text/html'
    })
    session.update_headers(headers_to_update)
    session.save()

    headers_updated = session['headers']

    session.load()


# Generated at 2022-06-23 20:03:40.588071
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')
    print(session)
    request_headers = RequestHeadersDict({'User-Agent': 'test_UA',
        'content-length': '100', 'If-Match': 'test_match'})
    session.update_headers(request_headers)
    print(session)
    assert(len(session.headers.items()) == 1)
    assert(session.headers == {'User-Agent': 'test_UA'})

# Generated at 2022-06-23 20:03:45.401237
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path("/home/lhz2/Documents/httpie/config")
    session_name = "default"
    host = None
    url = "https://httpbin.org/post"

    session = get_httpie_session(config_dir, session_name, host, url)
    print(session.headers)


if __name__ == "__main__":
    test_get_httpie_session()

# Generated at 2022-06-23 20:03:53.658547
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager

    session = Session(None)
    request_headers = RequestHeadersDict()
    request_headers['Cookie'] = 'name=value'
    request_headers['User-Agent'] = 'HTTPie/0.9.2'
    session.update_headers(request_headers)
    assert session['headers']['User-Agent'] == 'HTTPie/0.9.2'
    assert session['cookies']['name']['value'] == 'value'

# Generated at 2022-06-23 20:03:59.481972
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    jar = RequestsCookieJar()
    session = Session("test_Session")
    cookie_names = ["cookie1", "cookie2"]
    for name in cookie_names:
        jar.set_cookie(create_cookie(name, "value"))
    session.cookies = jar
    session.remove_cookies(["cookie2"])
    assert len(session['cookies']) == 1
    assert "cookie1" in session['cookies']
    assert "cookie2" not in session['cookies']

# Generated at 2022-06-23 20:04:10.384931
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session.cookies = RequestsCookieJar()
    session.cookies.set('cookie_1', 'value1', path='/')
    session.cookies.set('cookie_2', 'value2', path='/')
    session.cookies.set('cookie_3', 'value3', path='/')
    session.cookies.set('cookie_4', 'value4', path='/')
    session.remove_cookies('cookie_1', 'cookie_2')

    assert 'cookie_1' not in session.cookies
    assert 'cookie_2' not in session.cookies
    assert 'cookie_3' in session.cookies
    assert 'cookie_3' == session.cookies['cookie_3'].value
    assert 'cookie_4' in session.cookies


# Generated at 2022-06-23 20:04:13.966373
# Unit test for constructor of class Session
def test_Session():
    assert Session.__name__ == 'Session'
    assert Session.__init__.__name__ == '__init__'
    assert Session.__module__ == __name__

    # Should be initialised by default
    Session('')

# Generated at 2022-06-23 20:04:16.689802
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies']['user'] = 'jsf'
    session.remove_cookies(['user'])
    assert 'user' not in session['cookies']

# Generated at 2022-06-23 20:04:21.255159
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('s1')
    s['cookies'] = {"c1": "v1", "c2": "v2", "c3": "v3"}
    s.remove_cookies(["c1", "c4"])
    assert s['cookies'] == {"c2": "v2", "c3": "v3"}

# Generated at 2022-06-23 20:04:32.690490
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.plugins.http import HTTPPlugin
    from httpie.plugins.auth.http import HTTPBasicAuth
    from httpie.plugins.auth.http import HTTPTokenAuth
    from httpie.plugins.auth.netrc import NetrcAuth, AUTH_MAPPING
    from httpie.plugins.auth.digest import HTTPDigestAuth

    request_headers = {
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    session = Session("http://example.com")
    session.update_headers(request_headers)

    assert session.headers == request_headers


# Generated at 2022-06-23 20:04:33.901211
# Unit test for constructor of class Session
def test_Session():
    session = Session(path='path')
    assert session


# Generated at 2022-06-23 20:04:41.651463
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/foo/bar')
    session_name = 'session_name'
    host = 'example.com'
    path = Path(f'{config_dir}/{SESSIONS_DIR_NAME}/{host}/{session_name}.json')
    url = f'http://{host}/baz'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.path == path
    assert session == {}
    assert session.path.parent.name == host
    assert session.path.parent.parent.name == SESSIONS_DIR_NAME
    assert session.path.parent.parent.parent == config_dir

# Generated at 2022-06-23 20:04:52.865406
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from inspect import signature

    if os.path.exists('/tmp/httpie'):
        os.system('rm -rf /tmp/httpie')

    os.system('mkdir -p /tmp/httpie/sessions/some.net_8000')
    f = open('/tmp/httpie/sessions/some.net_8000/aa.json', 'w')

# Generated at 2022-06-23 20:04:53.438685
# Unit test for constructor of class Session
def test_Session():
    pass

# Generated at 2022-06-23 20:04:57.246093
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=None)
    session['cookies'] = {
        'a': {'value': '1'},
        'b': {'value': '2'},
    }
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-23 20:04:59.072417
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert isinstance(get_httpie_session(DEFAULT_SESSIONS_DIR, 'session', 'localhost', 'http://localhost'), Session)

# Generated at 2022-06-23 20:05:04.882763
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    j = RequestsCookieJar()
    j.set_cookie(create_cookie('a', '1'))
    j.set_cookie(create_cookie('b', '2'))
    s = Session('s')
    s.cookies = j

    s.remove_cookies(['a'])
    assert 'a' not in s['cookies']

    s.remove_cookies(['a', 'b'])
    assert 'b' not in s['cookies']

# Generated at 2022-06-23 20:05:16.222164
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(os.devnull)
    session.update_headers([('X-Foo', 'one'), ('X-Foo', 'two')])
    assert session.headers['X-Foo'] == 'two'

    session.update_headers([('X-Foo', 'two'), ('X-Foo', None)])
    assert session.headers == {}

    session.update_headers([('X-Foo', 'one'), ('X-Bar', 'two')])
    assert session.headers == {
        'X-Foo': 'one',
        'X-Bar': 'two',
    }

    session.update_headers([('CookIE', 'fish=wish')])
    assert session.cookies['fish'].value == 'wish'

    session.update_headers([('cookie', 'cow=moo')])

# Generated at 2022-06-23 20:05:28.554478
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class DummyRequestHeadersDict(RequestHeadersDict):
        '''
        Dummy class that inherits from RequestHeadersDict to make testing easier.
        '''
        def __init__(self, *args, **kwargs):
            self.items = {}
            self.update(dict(*args, **kwargs))

        def __setitem__(self, key, val):
            self.items[key.lower()] = val

        def __getitem__(self, key):
            return self.items[key.lower()]

        def __delitem__(self, key):
            del self.items[key.lower()]

        def __iter__(self):
            return iter(self.items)

        def __len__(self):
            return len(self.items)


# Generated at 2022-06-23 20:05:33.567045
# Unit test for constructor of class Session
def test_Session():
    session = Session(path='')
    assert isinstance(session, BaseConfigDict)
    assert isinstance(session, dict)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-23 20:05:36.097402
# Unit test for constructor of class Session
def test_Session():
    s = Session('session1')
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-23 20:05:44.501341
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    test_headers = {
        'Host': 'httpbin.org',
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'HTTPie/6.1.8',
        'Content-Length': '0',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive'
    }
    session.update_headers(test_headers)
    assert session.headers == {
        'Host': 'httpbin.org',
        'Accept': 'application/json',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive'
    }

# Generated at 2022-06-23 20:05:48.294688
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(os.getcwd()+'/test_httpie_session.json')
    session.load()
    cookie_names = ['cook', 'biscuit']
    session.remove_cookies(cookie_names)
    assert session.get('cookies', {}) == {}
# end of test_Session_remove_cookies()

# Generated at 2022-06-23 20:05:49.657791
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session(Path('/home/user/.config/httpie/sessions'), 'session_name', 'localhost', 'http://localhost')

# Generated at 2022-06-23 20:05:55.513513
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('~/.config/httpie')
    session_name = 'test_session'
    host = 'https://www.baidu.com/'
    url = 'https://www.baidu.com/'
    result = get_httpie_session(config_dir, session_name, host, url)
    assert result



# Generated at 2022-06-23 20:05:58.592956
# Unit test for constructor of class Session
def test_Session():
    sess = Session('sessions.json')
    assert sess
    assert sess['headers'] == {}



# Generated at 2022-06-23 20:06:02.349062
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    # Test Path
    path = '/home/vagrant/httpie/sessions/shopping.json'
    # Test Path check
    session = Session(path)
    assert session.path == Path(path)


# Generated at 2022-06-23 20:06:12.246311
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from _pytest.tmpdir import TemporaryDirectory
    from httpie.config import Config
    from httpie.session import get_httpie_session
    url = 'http://domain.tld/path'
    session_name = 'name'

    with TemporaryDirectory() as config_dir:
        config = Config(config_dir=config_dir)
        # Create a session by going to a domain
        config.sessions.default_session_name = session_name
        session = get_httpie_session(config.config_dir, session_name, host=None, url=url)
        assert session.path == Path(config_dir) / SESSIONS_DIR_NAME / 'domain_tld' / 'name.json'
        # Create another session using the same name

# Generated at 2022-06-23 20:06:14.369462
# Unit test for function get_httpie_session
def test_get_httpie_session():
    s = get_httpie_session('/tmp', 'session name: one-two-three_four.five')
    assert s['path'] == Path('/tmp/sessions/session-name_one-two-three_four.five.json')

# Generated at 2022-06-23 20:06:19.481589
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(Path("fuck.json"))
    jar = RequestsCookieJar()
    jar.set("abc","abc")
    s.cookies = jar
    s.remove_cookies("abc")
    assert s["cookies"] == {}

# Generated at 2022-06-23 20:06:22.757462
# Unit test for constructor of class Session
def test_Session():
    request_headers = RequestHeadersDict()
    session = Session('~/.httpie/sessions')
    session.update_headers(request_headers)

# Generated at 2022-06-23 20:06:29.001206
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://lnkd.in/daily-newsletter'
    host = 'lnkd.in'
    session_name = 'daily-newsletter'

    session = get_httpie_session('~/.config/httpie',
                                 session_name,
                                 host,
                                 url)
    actual = session.path
    expected = '/Users/<username>/.config/httpie/sessions/lnkd_in/daily-newsletter.json'
    assert actual == expected

# Generated at 2022-06-23 20:06:35.442917
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class RequestHeadersDictDummy:
        def __init__(self, headers):
            self.headers = headers

        def items(self):
            return self.headers.items()

    session = Session('session.json')
    session.update_headers(RequestHeadersDictDummy({'a': '1', 'b': '2'}))
    assert (session.headers == {'a': '1', 'b': '2'})

# Generated at 2022-06-23 20:06:39.949968
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'my-session'
    host = 'localhost'
    url = 'http://localhost/'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.headers == {}
    assert session.cookies == RequestsCookieJar()
    assert session.auth == None

# Generated at 2022-06-23 20:06:43.574615
# Unit test for constructor of class Session
def test_Session():
    httpie_session = Session(path=Path('/tmp/abc.json'))
    assert httpie_session.get('headers') == {}
    assert httpie_session.get('cookies') == {}
    auth = {
            'type': None,
            'username': None,
            'password': None
        }
    assert httpie_session.get('auth') == auth



# Generated at 2022-06-23 20:06:50.517196
# Unit test for constructor of class Session
def test_Session():
    assert Session(Path(DEFAULT_CONFIG_DIR/"sessions/localhost/test.json")).get("headers") == {}
    assert Session(Path(DEFAULT_CONFIG_DIR/"sessions/localhost/test.json")).get("cookies") == {}
    assert Session(Path(DEFAULT_CONFIG_DIR/"sessions/localhost/test.json")).get("auth") == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-23 20:07:00.504311
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import ExitStatus
    from httpie.cli import parse_args
    from httpie.context import Environment
    from httpie.output.streams import write_file
    from httpie.plugins.standard import StandardPlugin
    from httpie.session import Session
    from httpie.stdin import StdinBytes

    class Plugin(StandardPlugin):
        def __init__(self):
            super().__init__()
            self.args = None
            self.sessions = {}

        def session_load_and_update(self, args):
            assert isinstance(args, Environment)
            self.args = args

        def session_save(self):
            session_name = self.args.session
            session = self.sessions.get(session_name)
            if session is None:
                session = Session('temp.json')


# Generated at 2022-06-23 20:07:05.019826
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('../../../config')
    session_name = 'session'
    host = 'https://httpbin.org'
    url = 'https://httpbin.org/post'
    get_httpie_session(config_dir, session_name, host, url)
    return



# Generated at 2022-06-23 20:07:09.677726
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('x')
    sess['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    sess.remove_cookies(['b', 'c'])
    assert sess['cookies'] == {'a': 1}



# Generated at 2022-06-23 20:07:16.918044
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session_remove_cookies')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    assert session['cookies'] == {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}
    session.remove_cookies(['name3'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-23 20:07:27.960901
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config.environment import Environment
    from httpie.config import Config
    import tempfile
    config_dir = Path(tempfile.mkdtemp())
    environment = Environment(
        env={
            'XDG_CONFIG_HOME': config_dir,
            'HOME': config_dir
        },
        stdin=None,
        stdout=None,
        stderr=None,
        stdin_isatty=False,
        stdout_isatty=False,
        stderr_isatty=False,
        should_pretty_print=True,
        config_dir=config_dir,
        config=Config(
            config_dir=config_dir,
            default_options=None
        )
    )
    assert environment.config_dir == config_dir


# Generated at 2022-06-23 20:07:31.637979
# Unit test for constructor of class Session
def test_Session():
    session = Session('test_session')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-23 20:07:38.901364
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/dev/null')
    session['cookies'] = {'cookie_1': True, 'cookie_2': True, 'cookie_3': True, 'cookie_4': True, 'cookie_5': True}
    session.remove_cookies(['cookie_1', 'cookie_2'])
    assert session['cookies'] == {'cookie_3': True, 'cookie_4': True, 'cookie_5': True}


# Generated at 2022-06-23 20:07:43.990507
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    filename = '/tmp/session-remove-cookies.json'
    mySession = Session(filename)
    mySession['cookies'] = {'cookie1': {'value': 1}, 'cookie2': {'value': 2}}
    mySession.remove_cookies(['cookie2', 'cookie3'])
    assert mySession['cookies'] == {'cookie1': {'value': 1}}
    os.remove(filename)

# Generated at 2022-06-23 20:07:49.560978
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """ Test Session.update_headers
    """
    session = Session('sessions/test_session')
    session['headers'] = {'ABC': 'DEF', 'GHI': 'JKL'}
    request_headers = RequestHeadersDict()
    request_headers['ABC'] = 'abc'
    request_headers['GHI'] = None
    request_headers['MNO'] = 'mno'
    request_headers['PQR'] = 'pqr'
    session.update_headers(request_headers)
    assert session['headers'] == {'ABC': 'abc', 'PQR': 'pqr'}

# Generated at 2022-06-23 20:07:53.584481
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('.config')
    session_name = 'test'
    host = 'localhost'
    url = 'http://www.example.com'
    get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-23 20:07:59.801155
# Unit test for constructor of class Session
def test_Session():
    config_dir = '/home/httpie/.config/httpie'
    session_name = 'session1'
    host = 'https://'
    url = '127.0.0.1:80'
    result = get_httpie_session(config_dir, session_name, host, url)
    assert result.get('headers') == {}
    assert result.get('cookie') == {}
    assert result.get('auth').get('type') == None
    assert result.get('auth').get('username') == None
    assert result.get('auth').get('password') == None



# Generated at 2022-06-23 20:08:03.647253
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test/test-session")
    session.cookies = RequestsCookieJar()
    session.cookies.set('test_cookie','test_value')

    assert 'test_cookie' in session.cookies
    assert session.cookies['test_cookie'].value == 'test_value'

    session.remove_cookies(['test_cookie'])
    assert 'test_cookie' not in session.cookies

# Generated at 2022-06-23 20:08:07.955080
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("./test_session.json")
    s['cookies'] = {"abc": {"value": "xyz"}}
    s.remove_cookies(["abc"])
    assert not s['cookies']


# Generated at 2022-06-23 20:08:10.581887
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')
    session.update_headers({'Content-Type': 'application/json', 'Cookie': 'foo=bar'})
    print(session.headers)
    print(session.cookies)


# Generated at 2022-06-23 20:08:21.387592
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    assert session['headers'] == {}
    assert session['cookies'] == {}

    # Test for httpie's user-agent
    req_headers = RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9'})
    session.update_headers(req_headers)
    assert session['headers'] == {}

    # Test for unset headers
    req_headers['Accept'] = None
    session.update_headers(req_headers)
    assert session['headers'] == {}

    # TODO: Test for request method headers

    # Test for cookies
    req_headers['Cookie'] = 'name1=value1; name2=value2'
    session.update_headers(req_headers)

# Generated at 2022-06-23 20:08:29.126475
# Unit test for constructor of class Session
def test_Session():
    session1 = Session('default-session.json')

    assert isinstance(session1, Session)

    assert 'headers' in session1
    assert 'cookies' in session1
    assert 'auth' in session1

    assert 'type' in session1['auth']
    assert 'username' in session1['auth']
    assert 'password' in session1['auth']
    assert 'raw_auth' not in session1['auth']



# Generated at 2022-06-23 20:08:35.770810
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sessionsdir = __file__.rstrip(os.path.basename(__file__)) + SESSIONS_DIR_NAME
    session = get_httpie_session(
        sessionsdir, 'test', 'example.com', 'http://example.com/')
    assert session.path == os.path.join(sessionsdir, 'example_com', 'test.json')



# Generated at 2022-06-23 20:08:40.211416
# Unit test for constructor of class Session
def test_Session():
    test_session = Session('session/test')
    assert test_session['headers'] == {}
    assert test_session['cookies'] == {}
    assert test_session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-23 20:08:46.563621
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp_httpie')
    session['cookies'] = {
        "session_cookie":{
            "value": "session_cookie_value",
            "path": "/"
        },
        "session_cookie2":{
            "value": "session_cookie2_value",
            "path": "/"
        },
    }
    session.remove_cookies(["session_cookie"])
    assert len(session['cookies'].keys()) == 1

# Generated at 2022-06-23 20:08:48.583469
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('my_session')
    session.update_headers({'custom_header': 'value', 'content-type': 'value2'})
    assert 'custom_header' in session.headers
    assert 'Content-Type' not in session.headers

# Generated at 2022-06-23 20:08:51.937082
# Unit test for constructor of class Session
def test_Session():
    session = Session('session.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-23 20:08:58.315015
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.context import Environment
    config_dir = Environment().config_dir
    session_name = 'x'
    host = None
    url = 'http://127.0.0.1:8080/post'
    session = get_httpie_session(
        config_dir,
        session_name,
        host,
        url,
          )
    assert session['headers'] == {}
    headers = RequestHeadersDict({'name':'hello'})
    session.update_headers(headers)
    assert session['headers'] == {'name':'hello'}
    assert session.headers == {'name':'hello'}
    session['cookies'] = {}
    assert session['cookies'] == {}
    # assert type(session.cookies

# Generated at 2022-06-23 20:09:04.983769
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from . import config_location
    from .config import ConfigDict

    config_dir = config_location()
    args = ['-c', config_dir]

    # CASE 1: session file does not exist.
    session_name = 'session_1'
    url = 'http://github.com/jakubroztocil/httpie'
    host = 'github.com'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert len(session) == 3
    assert not session.has_auth()

    # CASE 2: session file exists
    session.dump()
    session = get_httpie_session(config_dir, session_name, host, url)
    assert len(session) == 3
    assert not session.has_auth()

    # CASE 3: session file

# Generated at 2022-06-23 20:09:06.031546
# Unit test for function get_httpie_session
def test_get_httpie_session():
    print()
    pass



# Generated at 2022-06-23 20:09:12.292896
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session_headers = dict(
        headers=dict(
            Accept=0,
            Accept_Encoding=0,
            Accept_Language=0,
            Content_Type=0,
            Origin=0,
            Referer=0,
            User_Agent=0,
            Cookie=0,
        ),
        cookies=dict(
            a=0,
            b=0,
            c=0,
            d=0,
        ),
        auth=dict(
            type=None,
            username=None,
            password=None
        )
    )

# Generated at 2022-06-23 20:09:17.711492
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('temp')
    session['cookies'] = {'name1': 1, 'name2': 2}
    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'] == {'name2': 2}



# Generated at 2022-06-23 20:09:24.866976
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = "http://www.foo.com/path/to/resource?a=b&x=y"
    for host in (None, "www.foo.com", "www.foo.com:8080"):
        session = get_httpie_session(
            DEFAULT_SESSIONS_DIR,
            session_name="test",
            host=host,
            url=url,
        )
        assert session.path == DEFAULT_SESSIONS_DIR / "www.foo.com" / "test.json"

# Generated at 2022-06-23 20:09:29.194294
# Unit test for constructor of class Session
def test_Session():
    session = Session('test')
    assert {'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}} == session


# Generated at 2022-06-23 20:09:40.158229
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    This function is used to test the correctness of the method update_headers in class Session 
    """

    # create a Session obj     
    session = Session("./test_config/test_session_file")
    session["headers"] = {}
    session["cookies"] = {}
    session["auth"] = {
        'type': "Basic",
        'username': "weichen20",
        'password': "123456"
    }

    key_value_1 = "user-agent: HTTPie/1.0.2"
    key_value_2 = "cookie: name1=value1"
    request_headers = RequestHeadersDict()

    # test the normal case of update_headers
    request_headers[key_value_1] = None
    result1 = dict(session["headers"])
    session.update

# Generated at 2022-06-23 20:09:49.475310
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {
        "Accept": "text/html",
        "Accept-Language": "en-US,en;q=0.8",
        "Host": "httpbin.org",
        "Referer": "http://httpbin.org",
        "Cookie": "foo=bar; baz=qux"
    }
    session = Session("session.json")
    session.update_headers(headers)
    assert {"Accept": "text/html", "Accept-Language": "en-US,en;q=0.8"} == session["headers"]
    assert {"Cookie": {"foo": "bar", "baz": "qux"}} == session["cookies"]



# Generated at 2022-06-23 20:09:57.953831
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sessions_dir = Path('/tmp/httpie') / SESSIONS_DIR_NAME
    assert get_httpie_session(
        os.path.join(sessions_dir, '/'),
        'piggy'
    ).path == Path('/tmp/httpie/sessions/piggy.json')

    assert get_httpie_session(
        os.path.join(sessions_dir, '/'),
        'piggy',
        host='localhost'
    ).path == Path('/tmp/httpie/sessions/localhost/piggy.json')


# Generated at 2022-06-23 20:10:06.048117
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(config_dir=Path.home(), session_name='sess.json', host=None, url='http://localhost:8000')
    assert get_httpie_session(config_dir=Path.home(), session_name='sess.json', host=None, url='http://localhost:7000')
    assert get_httpie_session(config_dir=Path.home(), session_name='sess.json', host=None, url='http://localhost:5000')


# Generated at 2022-06-23 20:10:11.921980
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie import config
    from httpie.cli.parser import get_parser
    from httpie.client import Client
    from httpie.output.streams import StdoutBytesIO
    from httpie.input import JSONObject
    from httpie.plugins.manager import plugin_manager
    parser = get_parser()
    args = parser.parse_args(['--session=foo', 'https://httpbin.org/get'])
    client = Client(args, output_stream=StdoutBytesIO(),stdin_isatty=None)
    client.args.referer = False
    client.args.verbose = False
    client.args.output_options.remove_headers = False
    client.args.output_options.format = 'json'
    client.args.output_options.output_dir = None
    client.args

# Generated at 2022-06-23 20:10:19.895137
# Unit test for constructor of class Session
def test_Session():
    sess = Session('session')
    assert isinstance(sess['headers'], dict)
    assert isinstance(sess['cookies'], dict)
    assert isinstance(sess['auth'], dict)
    assert isinstance(sess['auth']['type'], None.__class__)
    assert isinstance(sess['auth']['username'], None.__class__)
    assert isinstance(sess['auth']['password'], None.__class__)

# Generated at 2022-06-23 20:10:28.193071
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Initialize session instance
    path = "session.json"
    session = Session(path)
    # Initialize request_headers
    request_headers = {'Host':'127.0.0.1', 'If-Match':'*', 'user-agent':'HTTPie/0.9.2', 'Authorization':'Basic YWRtaW46YWRtaW4xMjM0NTY=', 'Cookie':'PHPSESSID=6l0hg7voak9pnkk4q3q4i4qur4'}
    # Update headers
    session.update_headers(request_headers)
    # Check headers in session
    stored_headers = session.headers

# Generated at 2022-06-23 20:10:30.503563
# Unit test for constructor of class Session
def test_Session():
    sessionfile = 'my-session.json'
    session = Session(sessionfile)
    assert session.path == sessionfile
    assert session['headers'] == {}
    assert session['cookies'] == {}

# Generated at 2022-06-23 20:10:33.661587
# Unit test for constructor of class Session
def test_Session():
    try:
        path = Path('test.json')
        Session(path)
    except:
        assert False
    finally:
        try:
            if path.exists():
                path.unlink()
        except:
            assert False

# Generated at 2022-06-23 20:10:36.620227
# Unit test for constructor of class Session
def test_Session():
    try:
        Session('~/')
    except:
        assert False
    try:
        Session(Path('~/'))
    except:
        assert False


# Generated at 2022-06-23 20:10:45.319308
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/test.session')
    s['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    s.remove_cookies('a')
    assert s['cookies'] == {'b': 2, 'c': 3}
    s.remove_cookies('a', 'b', 'd', 'e')
    assert s['cookies'] == {'c': 3}
    s.remove_cookies('c', 'a', 'b', 'd', 'e')
    assert s['cookies'] == {}

# Generated at 2022-06-23 20:10:58.485307
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session1 = Session("session1.json")
    session1.update_headers({"test-cookie": "test-cookie-value"})
    assert session1['headers'] == {"test-cookie": "test-cookie-value"}
    assert session1['cookies'] == {}
    session1.update_headers({"Cookie": "test-cookie=test-cookie-value"})
    assert session1['headers'] == {"test-cookie": "test-cookie-value"}
    assert session1['cookies'] == {"test-cookie": {"value": "test-cookie-value"}}
    session1.update_headers({"Cookie": "test-cookie=test-cookie-value;"})
    assert session1['headers'] == {"test-cookie": "test-cookie-value"}

# Generated at 2022-06-23 20:11:06.319624
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # create a Session
    path = '/tmp/test'
    session = Session(path)
    # update the session cookies with a non-empty dict
    cookies = {'foo': {'value': 'bar'},
               'baz': {'value': 'qux'}}
    session.cookies = cookies
    # call the method remove_cookies
    session.remove_cookies(['foo'])
    # test the method remove_cookies
    assert session['cookies'] == {'baz': {'value': 'qux'}}

# Test for the method __init__ of class Session

# Generated at 2022-06-23 20:11:09.751149
# Unit test for constructor of class Session
def test_Session():
    session1 = Session('path1')
    session2 = Session('path2')
    assert session1['path'] == Path('path1')
    assert session2['path'] == Path('path2')

# Generated at 2022-06-23 20:11:20.588740
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # test single header
    session = Session('path')
    request_headers = {'random-header': 'random-value'}
    session.update_headers(request_headers)
    assert session['headers'] == {'random-header': 'random-value'}
    # test multiple headers
    session = Session('path')
    request_headers = {'random-header': 'random-value', 'random-header2': 'random-value2'}
    session.update_headers(request_headers)
    assert session['headers'] == {'random-header': 'random-value', 'random-header2': 'random-value2'}
    # test invalid headers
    session = Session('path')
    request_headers = {'cookie': 'random-value', 'random-header2': 'random-value2'}
    session.update_

# Generated at 2022-06-23 20:11:28.704779
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('~/.httpie/')
    session_name = 'sample_session'
    host = 'www.sample.com'
    url = 'https://www.sample.com/path/to/sample/resource'

    session = get_httpie_session(config_dir, session_name, host, url)
    assert session['path'] == Path('~/.httpie/sessions/www_sample_com/sample_session.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    session['headers']['test1'] = 'val1'
    assert session['headers'] == {'test1': 'val1'}
    assert session.headers['test1'] == 'val1'
    assert session['cookies'] == {}
    assert session.cookies == RequestsCookie

# Generated at 2022-06-23 20:11:32.072987
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'Cookie': 'name=value; othername=othervalue'})
    assert session['cookies'] == {'name': {'value': 'value'}, 'othername': {'value': 'othervalue'}}