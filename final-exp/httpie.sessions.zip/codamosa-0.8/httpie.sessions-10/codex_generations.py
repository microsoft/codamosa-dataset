

# Generated at 2022-06-12 00:19:46.910597
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test.json")
    session.update_headers(headers={"Accept": "application/json"})
    assert session["headers"] == {"Accept": "application/json"}

# Generated at 2022-06-12 00:19:54.144243
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./test.json')
    session.update_headers({'user-agent': 'Test/0.0.0', 'Cookie': None})
    assert {'user-agent': 'Test/0.0.0', } == session.headers
    session.update_headers({'user-agent': None, 'Cookie': 'a=b'})
    assert {'Cookie': 'a=b'} == session.headers
    assert {'a': {'value': 'b'}} == session.cookies.get_dict()

# Generated at 2022-06-12 00:20:02.052827
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    If update_headers is called with a header begining with a prefix from SESSION_IGNORED_HEADER_PREFIXES,
    this header is not stored in the session.
    """
    session = Session("path")
    session.update_headers({"content-type": "text/html"})
    session.update_headers({"user-agent": "HTTPie/1.0.2"})
    assert session["headers"] == {}

# Generated at 2022-06-12 00:20:08.951335
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from collections import OrderedDict
    import json
    from json import JSONDecodeError
    from httpie.compat import is_windows
    from . import process_config_dir

    s = Session('./sessions/test')
    s.load()
    assert OrderedDict({'headers': OrderedDict({}), 'cookies': OrderedDict({}), 'auth': {'type': None, 'username': None, 'password': None}}) == s._asdict()

    s.update_headers(OrderedDict([('User-Agent', 'HTTPie/1.0.3'), ('host', 'commandline'), ('Accept', '*/*'), ('a', 'b')]))

# Generated at 2022-06-12 00:20:12.322642
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    head={'user-agent': 'HTTPie/2.2.0'}
    session=Session('/')
    session['headers']={}
    session.update_headers(head)
    assert session['headers']=={}

# Generated at 2022-06-12 00:20:16.594186
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    inst = Session('test')
    inst.update_headers({'hi': 'hi'})
    assert inst['headers']['hi'] == 'hi'
    assert len(inst['headers']) == 1

# Generated at 2022-06-12 00:20:27.908724
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    #setup of objects
    session = Session("")
    request_headers = RequestHeadersDict({1:"2", 3:"4", "content-type":"application/json"})
    request_headers["user-agent"]= "web"
    request_headers["cookie"]="cook"
    request_headers["content-length"]= "a"
    request_headers["if-match"]= "b"
    #Expected result
    headers = {1: "2", 3: "4", 'content-type': 'application/json',
              'user-agent': 'web', 'if-match': 'b'}
    cookies = {'cook': {'value': 'cook'}}
    #Actual result
    session.update_headers(request_headers)
    #Check
    assert session.headers == headers and session.cookies == cookies



# Generated at 2022-06-12 00:20:33.891720
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.load()
    request_headers = RequestHeadersDict()
    request_headers['Content-Type'] = 'application/json'
    request_headers['User-Agent'] = 'curl/7.55.1'
    session.update_headers(request_headers)
    assert session.headers.get('Content-Type')

# Generated at 2022-06-12 00:20:43.427559
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    req = {'headers': {'Cache-Control': 'no-cache', 'Cookie': 'a=1; b=2; c=3', 'If-Modified-Since': 'Fri, 02 Nov 2018 00:00:00 GMT', 'Content-Type': 'application/json; charset=utf-8', 'Accept': '*/*'}}
    session = Session('testSession.json')
    session.update_headers(req['headers'])
    assert session['headers'] == {'Cache-Control': 'no-cache', 'Accept': '*/*', 'Content-Type': 'application/json; charset=utf-8'}
    assert session['cookies'] == {'a': {'value': '1'}, 'b': {'value': '2'}, 'c': {'value': '3'}}

# Generated at 2022-06-12 00:20:53.617660
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.headers import merge_headers

    session = Session('test.json')
    session['headers'] = { 'Content-Type': 'application/json' }
    session.update_headers({ 'Content-Type': 'application/x-www-form-urlencoded' })

    assert session.headers == { 'Content-Type': 'application/x-www-form-urlencoded' }

    session = Session('test.json')
    session['headers'] = { 'Content-Type': 'application/json' }
    session.update_headers({ 'Content-Type': None })

    assert 'Content-Type' not in session.headers

    session = Session('test.json')
    session['headers'] = { 'Content-Type': 'application/json' }

# Generated at 2022-06-12 00:21:04.933464
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/session.json')
    session['cookies'] = {'key1':'value', 'key2':'value'}
    session.remove_cookies(('key1', 'key2'))
    print(session['cookies'])

if __name__ == '__main__':
    test_Session_remove_cookies()

# Generated at 2022-06-12 00:21:08.948475
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path = Path("test"))
    session['cookies'] = {"a":"b"}
    session['cookies'] = {"c":"d"}
    assert len(session['cookies']) == 2
    session.remove_cookies(["a"])
    assert len(session['cookies']) == 1
    assert list(session['cookies'].keys()) == ["c"]

# Generated at 2022-06-12 00:21:13.741572
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookiename = 'name'
    session = Session(path=Path(''))
    session['cookies'] = {cookiename: {'value': 'value'}}
    assert len(session.cookies) == 1
    session.remove_cookies([cookiename])
    assert cookiename not in session['cookies']



# Generated at 2022-06-12 00:21:16.913797
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session.update_headers({
        'Cookie': 'alpha=123; beta=456',
    })
    session.remove_cookies(['alpha'])
    assert session['cookies'] == {'beta': {'value': '456'}}

# Generated at 2022-06-12 00:21:22.843713
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/Users/fis/Documents/Mestrado/Módulo 1/httpie/.httpie/sessions/www.example.com/abc.json')
    session.load()
    #session.remove_cookies(['_pk_id.1.15fb','_pk_ses.1.15fb'])
    #session.remove_cookies(['_pk_id.1.15fb'])
    session.save()

# Generated at 2022-06-12 00:21:29.146727
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    a_session = Session('a_session')
    a_session['cookies']['username'] = 'Doraemon'
    a_session['cookies']['password'] = 'Nobita'
    a_session.remove_cookies(['username'])
    assert a_session['cookies']['username'] != 'Doraemon'


# Generated at 2022-06-12 00:21:31.953833
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    session = Session('session')

    # Act
    session.remove_cookies(('good', 'evil'))

    # Assert
    pass

# Generated at 2022-06-12 00:21:36.240035
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("Test.json")
    session.cookies = {"cookie1": {"a":1}, "cookie2":{"b":2}}
    session.remove_cookies("cookie2")
    assert session.cookies == {"cookie1":{"a":1}}



# Generated at 2022-06-12 00:21:40.569808
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session1 = Session(1)
    session1_cookies = {'a': 1}
    session1['cookies'] = session1_cookies
    session2 = Session(2)
    names = ['a']
    session2.remove_cookies(names)
    assert session1['cookies'] == session1_cookies
    assert session2['cookies'] == {}



# Generated at 2022-06-12 00:21:50.795241
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session1 = Session('path')
    cookie_a = {
        'value' : '1',
        'path' : '/',
        'secure' : 'yes',
        'expires' : ''
    }
    session1['cookies'] = {'cookie_a' : cookie_a}
    session1.remove_cookies(['cookie_b', 'cookie_c'])
    assert session1['cookies'] == {'cookie_a' : cookie_a}
    session1.remove_cookies(['cookie_a'])
    assert session1['cookies'] == {}
    session1.remove_cookies([])
    assert session1['cookies'] == {}

# Generated at 2022-06-12 00:22:09.844505
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.context import Environment
    from httpie.plugins import AuthPlugin
    from pytest import raises
    from requests.auth import AuthBase

    sess = Session('/')
    sess.load()
    sess.update_headers({'Cookie': 'A=1; B=2; C=3'})
    assert len(sess.cookies) == 3
    sess.remove_cookies(['B'])
    assert len(sess.cookies) == 2
    assert 'B' not in sess.cookies



# Generated at 2022-06-12 00:22:14.080350
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    file_path = './mycookie'
    s = Session(file_path)
    # Test: delete one cookie
    s['cookies'] = {'mycookie' : {'value': 'www.baidu.com'}}
    s.remove_cookies(['mycookie'])
    assert s['cookies'] == {}
    # Test: delete multi cookies
    s['cookies'] = {'mycookie' : {'value': 'www.baidu.com'}, 'mycookie2' : {'value': 'www.baidu.com'}, 'mycookie3' : {'value': 'www.baidu.com'}}
    s.remove_cookies(['mycookie','mycookie2'])

# Generated at 2022-06-12 00:22:16.742813
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s['cookies'] = {'key': 'value'}
    s.remove_cookies(['key'])
    assert not s['cookies']

# Generated at 2022-06-12 00:22:27.585855
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    ses = Session('test')
    ses['cookies'] = {
        'name1': {'value': 'val1', 'path': '/', 'secure': True, 'expires': 9999},
        'name2': {'value': 'val2', 'path': '/', 'secure': False, 'expires': 8888},
        'name3': {'value': 'val3', 'path': '/', 'secure': False, 'expires': 7777},
        'name4': {'value': 'val4', 'path': '/', 'secure': False, 'expires': 6666}
    }
    ses.remove_cookies(['name2', 'name4'])

# Generated at 2022-06-12 00:22:37.308275
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies']['cookie_name'] = {'value': 'cookie_value'}
    session['cookies']['cookie_name2'] = {'value': 'cookie_value2'}
    session['cookies']['cookie_name3'] = {'value': 'cookie_value3'}
    session.remove_cookies(['cookie_name', 'cookie_name3'])
    assert 'cookie_name' not in session['cookies']
    assert 'cookie_name3' not in session['cookies']

# Generated at 2022-06-12 00:22:38.888641
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp')
    session['cookies'] = {'foo': 1, 'bar': 2}
    session.remove_cookies(('foo',))
    assert session['cookies'] == {'bar': 2}



# Generated at 2022-06-12 00:22:45.348858
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from os import remove
    from pathlib import Path
    from tempfile import NamedTemporaryFile
    from collections import OrderedDict

    session_file = Path(NamedTemporaryFile(delete=False).name)
    session_file.write_text('{"cookies": {"cookie_a": {"value": "value_a"}, "cookie_b": {"value": "value_b"}, "cookie_c": {"value": "value_c"}}}')

    session = Session(session_file)
    session.load()

    assert session['cookies'] == OrderedDict([('cookie_a', {'value': 'value_a'}), ('cookie_b', {'value': 'value_b'}), ('cookie_c', {'value': 'value_c'})])


# Generated at 2022-06-12 00:22:56.831198
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = "/Users/rongrong/Downloads/httpie-master/httpie-master/tests/sessions/httpie.org/test.json"
    session = Session(session_path)

    session['cookies'] = {'deleted_key':'test_value'}
    session.remove_cookies(['deleted_key'])
    assert session['cookies'] == {}
    session['cookies'] = {'deleted_key':'test_value','logged_in':'login_value'}
    session.remove_cookies(['deleted_key'])
    assert session['cookies'] == {'logged_in':'login_value'}
    session['cookies'] = {'deleted_key':'test_value','logged_in':'login_value'}
   

# Generated at 2022-06-12 00:23:02.008479
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'foo': 'bar', 'baz': 'qux'}
    session = Session('tests/sessions/example_session.json')
    session.cookies = RequestsCookieJar()
    for name, value in cookies.items():
        session.cookies.set_cookie(create_cookie(name, value))
    session.remove_cookies(['foo', 'baz'])
    assert len(session.cookies) == 0

# Generated at 2022-06-12 00:23:07.351413
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("/tmp/test.json")
    s['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    s.remove_cookies(['cookie2'])
    assert 'cookie2' not in s['cookies']
    assert 'cookie1' in s['cookies']

# Generated at 2022-06-12 00:23:31.961742
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_dict = {
        'cookies': {"cookie_1": "value_1",
                    "cookie_2": "value_2",
                    "cookie_3": "value_3"}
    }
    cookies_to_remove = ["cookie_2", "cookie_3"]
    session = Session("test.json")
    session.update(session_dict)
    session.remove_cookies(cookies_to_remove)
    assert session['cookies'] == {"cookie_1": "value_1"}



# Generated at 2022-06-12 00:23:36.752333
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./default_session')
    session['cookies'] = {'cookie1': 'value', 'cookie2': 'value'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'].keys() == {'cookie2'}



# Generated at 2022-06-12 00:23:38.045125
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    assert s.cookies == RequestsCookieJar()


# Generated at 2022-06-12 00:23:44.437521
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/test/test.json')
    session['cookies'] = {"one": 'one', "two": 'two', "three": 'three'}
    session.remove_cookies(['one', 'three'])
    assert session['cookies'] == {'two': 'two'}
# end of Unit test for method remove_cookies of class Session


# Generated at 2022-06-12 00:23:49.875748
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Setup
    session = Session('path')
    session['cookies'] = {
        'foo': 'bar'
    }
    # Test 1 - remove foo
    session.remove_cookies(['foo'])
    assert session['cookies'] == {}
    # Test 2 - nothing to remove
    session.remove_cookies(['foo'])
    assert session['cookies'] == {}



# Generated at 2022-06-12 00:23:55.311235
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = DEFAULT_SESSIONS_DIR / 'test_session.json'
    session = Session(session_path)
    session['cookies']['k1'] = 'v1'
    session['cookies']['k2'] = 'v2'
    session['cookies']['k3'] = 'v3'
    session.save()

    session.remove_cookies(['k1', 'k2'])
    assert session['cookies'] == {'k3': 'v3'}
    assert not session_path.exists()



# Generated at 2022-06-12 00:24:04.007683
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies_dict = {'a': {'value': 1}, 'b': {'value': 2}}
    # test if cookies is in session, remove it
    s = Session(path=' ')
    s['cookies'] = cookies_dict
    s.remove_cookies(names=['a'])
    assert 'a' not in s['cookies']
    assert 'b' in s['cookies']
    # test if cookies is not in session, nothing happends
    s.remove_cookies(names=['a'])
    assert 'a' not in s['cookies']
    assert 'b' in s['cookies']



# Generated at 2022-06-12 00:24:10.431339
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    session = Session(Path('/foo'))

    # no cookies in session
    session.remove_cookies(['cookie1', 'cookie2'])
    assert not session['cookies']

    # cookies in session
    session['cookies']['cookie1'] = 'cookie1_value'
    session['cookies']['cookie2'] = 'cookie2_value'
    session['cookies']['cookie3'] = 'cookie3_value'

    session.remove_cookies(['cookie1', 'cookie2'])
    assert session['cookies'] == {'cookie3':
                                  'cookie3_value'}

    session.remove_cookies(['cookie3'])
    assert not session['cookies']



# Generated at 2022-06-12 00:24:15.730384
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session1')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie3'])
    assert session['cookies'] == {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {'cookie1': {'value': 'value1'}}


# Generated at 2022-06-12 00:24:26.654787
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    input_name = [
        "JSESSIONID",
        "SRTRAN",
        "SRTASK",
        "sr-token"
    ]
    session = Session('session_path')

# Generated at 2022-06-12 00:25:09.577500
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("somesession")
    s["cookies"] = {"a": {"value": "b"}}
    s.remove_cookies(names=["a"])
    assert s["cookies"] == {}

# Generated at 2022-06-12 00:25:19.160170
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.config import Path
    from httpie.context import Environment
    from httpie.session import Session
    from httpie.cli.dicts import RequestHeadersDict

    # Test for method remove_cookies of class Session
    # Case 1: cookies exist
    config_dir = Path(r"C:\Users\lizhi\AppData\Roaming\httpie")
    session_name = "TestCase"
    host = "http://localhost"
    url = "http://localhost/TestCase"
    session = get_httpie_session(config_dir, session_name, host, url)
    session['headers'] = {}

# Generated at 2022-06-12 00:25:23.918667
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(Path('test.json'))
    s['cookies'] = {"test": "value"}
    names=["test", "non-existent"]
    s.remove_cookies(names)
    assert not "test" in s['cookies']
    assert len(s['cookies']) == 0

# Generated at 2022-06-12 00:25:28.339228
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.argtypes import KeyValueArg, KeyValueArgType
    from httpie.plugins.builtin import HTTPBasicAuth
    cookie_arg = KeyValueArg('cookie', KeyValueArgType.COOKIE)
    session = Session("ajit.json")
    session.remove_cookies(['user', 'pass'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:25:38.334207
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session['cookies'] = {
        'foo': {'value': 'bar'},
        'baz': {'value': 'qux'},
        'xuq': {'value': 'zab'},
    }
    session.remove_cookies(['foo', 'xuq'])
    assert session['cookies'] == {'baz': {'value': 'qux'}}


    session = Session(None)
    session['cookies'] = {
        'foo': {'value': 'bar'},
        'baz': {'value': 'qux'},
        'xuq': {'value': 'zab'},
    }
    session.remove_cookies(['foo', 'baz', 'xuq'])
    assert session['cookies']

# Generated at 2022-06-12 00:25:44.715100
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    #remove of a cookie that doesn't exist
    session = Session('path')
    session.remove_cookies(['name'])
    assert session['cookies'] =={}
    #remove of a cookie that is present
    session['cookies']['name'] = 'data'
    session.remove_cookies(['name'])
    assert session['cookies'] =={}


# Generated at 2022-06-12 00:25:54.910071
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test case 1 : remove 'name1'
    s = Session('')
    s['cookies'] = {
        'name1': {
            'value': 'value1'
        },
        'name2': {
            'value': 'value2'
        }
    }
    s.remove_cookies(['name1'])
    assert(s['cookies'] == {
        'name2': {
            'value': 'value2'
        }
    })

    # Test case 2 : remove 'name2'
    s = Session('')
    s['cookies'] = {
        'name1': {
            'value': 'value1'
        },
        'name2': {
            'value': 'value2'
        }
    }

# Generated at 2022-06-12 00:26:01.239051
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = ['cookie1', 'cookie2', 'cookie3']
    session = Session(path='')
    session.update_headers({"cookie": {cookies[0]: 'a', cookies[1]: 'b'},
                            "Cookie": {cookies[0]: 'a', cookies[1]: 'b'}})
    session.remove_cookies(cookies)
    assert session == {'headers': {}, 'cookies': {}, 'auth': {'type': None,
                                                             'username': None,
                                                             'password': None}}

# Generated at 2022-06-12 00:26:05.945593
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test-session.json')
    session.cookies = {"test": "test"}
    session.remove_cookies(["test"])
    assert(session.cookies=={})

# Generated at 2022-06-12 00:26:09.705337
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session.json')
    session['cookies'] = {'cookie1': {}, 'cookie2': {}}
    session.remove_cookies(['cookie1', 'cookie3'])
    assert session['cookies'] == {'cookie2': {}}

# Generated at 2022-06-12 00:27:30.501717
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path("test.json"))
    session['cookies'] = {
        "username": {
            "value": "test_name"
        },
        "password": {
            "value": "test_password"
        }
    }
    session.remove_cookies(["username", "password"])
    assert session['cookies'] == {}


# Generated at 2022-06-12 00:27:35.389545
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('SessionFile')
    test_cookie = {'name': 'test_cookie', 'value': 'test_cookie_value'}
    session.cookies.set_cookie(create_cookie(**test_cookie))
    assert test_cookie['name'] in session.cookies
    session.remove_cookies([test_cookie['name']])
    assert test_cookie['name'] not in session.cookies

# Generated at 2022-06-12 00:27:41.091606
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('toto')
    s.cookies = RequestsCookieJar()
    s.cookies.set('c1', 'v1')
    s.cookies.set('c2', 'v2')
    s.cookies.set('c3', 'v3')
    assert s.cookies == {'c1': 'v1', 'c2': 'v2', 'c3': 'v3'}
    s.remove_cookies(['c2', 'c3'])
    assert s.cookies == {'c1': 'v1'}
    assert s.cookies != {'c2': 'v2'}
    assert s.cookies != {'c3': 'v3'}
    

# Generated at 2022-06-12 00:27:47.850085
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("TEST")
    s['cookies'] = {"cookie1" : "value1"}
    s.remove_cookies(["cookie1"])
    assert len(s['cookies']) == 0
    s['cookies'] = {"cookie1" : "value1"}
    s.remove_cookies(["cookie2"])
    assert len(s['cookies']) == 1

# Generated at 2022-06-12 00:27:58.047081
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path="test_session")
    s['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    s.remove_cookies(['cookie1'])
    assert s == {'headers': {}, 'cookies': {'cookie2': 'value2'}, 'auth': {'type': None, 'username': None, 'password': None}}
    assert s.cookies == {'cookie2': 'value2'}
    s.remove_cookies(['cookie2'])
    assert s == {'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}
    assert s.cookies == {}
    s.remove_cookies([])

# Generated at 2022-06-12 00:28:01.921001
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test_test")
    session['cookies'] = {}
    session['cookies']['test'] = {"test": "test"}
    session['cookies']['test1'] = {"test": "test"}
    cookies = ['test', 'test1']
    session.remove_cookies(cookies)
    assert list(session['cookies'].keys()) == []

# Generated at 2022-06-12 00:28:07.709799
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    def inner(cookies_to_remove, expected_cookies_after_removal):
        s = Session('path')
        s['cookies'] = {'a': '1',
                        'b': '2'}
        s.remove_cookies(cookies_to_remove)
        return s['cookies'] == expected_cookies_after_removal

    assert inner(['a'], {'b': '2'})
    assert inner(['a', 'b'], {})
    assert inner(['c'], {'a': '1', 'b': '2'})

# Generated at 2022-06-12 00:28:11.977110
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='path')
    session['cookies'] = {
        'cookie1': {},
        'cookie2': {},
        'cookie3': {}
    }

    session.remove_cookies(['cookie1', 'cookie2'])
    assert session['cookies'] == {'cookie3': {}}



# Generated at 2022-06-12 00:28:12.575522
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert True

# Generated at 2022-06-12 00:28:22.456868
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_session = Session('test')
    test_session['cookies'] = {
        'session': {'value': '12345'},
        'user': {'value': 'nishan'},
        'token': {'value': '67890'}
    }
    assert test_session['cookies'] == {
        'session': {'value': '12345'},
        'user': {'value': 'nishan'},
        'token': {'value': '67890'}
    }
    test_session.remove_cookies(['session'])
    assert test_session['cookies'] == {
        'user': {'value': 'nishan'},
        'token': {'value': '67890'}
    }
