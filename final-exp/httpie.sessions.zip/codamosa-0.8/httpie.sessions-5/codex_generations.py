

# Generated at 2022-06-12 00:19:56.610183
# Unit test for method update_headers of class Session

# Generated at 2022-06-12 00:20:05.112509
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test')
    assert session['headers'] is not None

    request_header = RequestHeadersDict()
    request_header['TEST'] = 'string'
    request_header['TEST-1'] = 'string-1'

    session.update_headers(request_header)
    assert session.header['TEST'] is not None
    assert session.header['TEST-1'] is not None



# Generated at 2022-06-12 00:20:15.423227
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path('./test.json'))
    session.load()
    ### Tests:
    # Test 1:
    #   - request_headers: with the keys that are not specified in
    #       SESSION_IGNORED_HEADER_PREFIXES
    #   - Should be contained in self['headers']

# Generated at 2022-06-12 00:20:23.702979
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Given a Session instance s
    When update_headers is called on s with kvpair = [('key0', 'value0'), ('key1', 'value1')]
    Then s.headers should be {'key0', 'value0', 'key1', 'value1'}
    """
    s = Session()
    kvpair = [('key0', 'value0'), ('key1', 'value1')]
    s.update_headers(kvpair)
    assert s.headers == {'key0': 'value0', 'key1': 'value1'}

# Generated at 2022-06-12 00:20:30.721303
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {
        'User-Agent': 'HTTPie/0.9.2',
        'Host': 'example.org',
        'Content-Type': 'application/json',
        'Content-Length': '10',
        'If-Match': '"1234"',
        'date': 'Wed, 16 Nov 2016 18:33:17 GMT',
    }
    session = Session('test_session.json')
    session.update_headers(headers)

    expected = {
        'Host': 'example.org',
        'Content-Type': 'application/json',
        'Content-Length': '10',
        'date': 'Wed, 16 Nov 2016 18:33:17 GMT',
    }
    assert session['headers'] == expected
    assert session.headers == expected

# Generated at 2022-06-12 00:20:41.957594
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # update_headers(self, request_headers: RequestHeadersDict)
    session_headers = {"test_key1": "test_value1", "test_key2": "test_value2", "test_key3":"test_value3"}
    session = Session(path="")
    session['headers'] = session_headers

    headers_to_update = {"test_key1": "test_value1_updated", "test_key2":"test_value2", "test_key4":"test_value4"}
    session.update_headers(headers_to_update)

    # result of the function is nothing but updating the session_headers
    assert session_headers == {"test_key1": "test_value1_updated", "test_key2": "test_value2", "test_key4":"test_value4"}

# Generated at 2022-06-12 00:20:45.575228
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('a.json')
    session['cookies'] = {'c1': {'value': 'v1'}, 'c2': {'value': 'v2'}, 'c3': {'value': 'v3'}}
    session.remove_cookies(['c2', 'c4'])
    assert session['cookies'] == {'c1': {'value': 'v1'}, 'c3': {'value': 'v3'}}

# Generated at 2022-06-12 00:20:54.769505
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import ExitStatus
    from httpie.cli import exit_status

    session = Session('/tmp/httpie-session.json')
    assert session.get('headers', None) == {}
    assert session.get('cookies', None) == {}
    response_headers = {
        'x-header': 'foo',
        'content-type': 'application/json',
        'content-length': '42',
        'connection': 'close',
        'cookie': 'cookie1=value1; cookie2=value2',
        'user-agent': 'HTTPie/0.9.9'
    }
    session.update_headers(response_headers)
    assert session.get('headers', None) == {'x-header': 'foo'}

# Generated at 2022-06-12 00:21:03.151205
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    request_headers = RequestHeadersDict()
    request_headers['User-Agent'] = 'test_useragent'
    request_headers['Content-Type'] = 'test_contenttype'
    request_headers['If-Modified-Since'] = None
    request_headers['Cookie'] = 'test_cookie'
    request_headers['test-data'] = 'test_value'
    session.update_headers(request_headers)
    assert session.headers['User-Agent'] == 'test_useragent'
    assert session.headers['Content-Type'] == 'test_contenttype'
    assert 'If-Modified-Since' not in session.headers
    assert 'test-data' in session.headers

# Generated at 2022-06-12 00:21:08.586010
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers({'user-agent': '(HTTPie/0.9.4)', 'cookie': 'a=b;c=d'})
    assert session.headers == {'cookie': 'c=d'}
    assert session.cookies == {'a': 'b', 'c': 'd'}
    print('Test of method update_headers of class Session is passed')


# Generated at 2022-06-12 00:21:23.342026
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path(""))
    cookie_list = [
        ('name1', 'value1'),
        ('name2', 'value2'),
        ('name3', 'value3'),
        ('name4', 'value4'),
    ]
    for name, value in cookie_list:
        cookie = create_cookie(name, value)
        session['cookies'][name] = {'value': cookie.value}

    assert set(session['cookies'].keys()) == set([name for name, value in cookie_list])
    session.remove_cookies(['name1', 'name2'])
    assert set(session['cookies'].keys()) == set([name for name, value in cookie_list[2:]])
    session.remove_cookies([])
    assert set(session['cookies'].keys()) == set

# Generated at 2022-06-12 00:21:29.861451
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir = DEFAULT_SESSIONS_DIR
    session = Session(path = config_dir)
    session.update({"cookies": {"c1":{"value":"x1"},"c2":{"value":"x2"},"c3":{"value":"x3"}}})
    session.remove_cookies(names = ["c1","c2"])
    assert session.get("cookies") == {"c3":{"value":"x3"}}

# Generated at 2022-06-12 00:21:35.826304
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path="path")
    session["cookies"]["cookie1"] = "value1"
    session["cookies"]["cookie2"] = "value2"
    session.remove_cookies(["cookie1", "cookie3"])
    assert session["cookies"].get("cookie1") == None
    assert session["cookies"].get("cookie2") == "value2"

# Generated at 2022-06-12 00:21:42.654436
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session.cookies = RequestsCookieJar()
    session.cookies.set('cookie1', 'value1', domain='example.com',
            path='/path')
    session.cookies.set('cookie2', 'value2', domain='example.com')
    session.cookies.set('cookie3', 'value3')
    session.cookies.set('cookie4', 'value4')

    session.remove_cookies(['cookie1', 'cookie4'])
    for c in session.cookies:
        assert c.name not in ['cookie1', 'cookie4']
    assert 'cookie1' not in session['cookies']
    assert 'cookie4' not in session['cookies']



# Generated at 2022-06-12 00:21:47.509947
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_file = Session('/path/to/file')

    session_file['cookies'] = {'cookie1': {}, 'cookie2': {}, 'cookie3': {}}
    session_file.remove_cookies(['cookie1', 'cookie3'])
    assert session_file['cookies'] == {'cookie2': {}}



# Generated at 2022-06-12 00:21:56.900701
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    s['cookies'] = {'c1': {'value':'v1'}, 'c2': {'value':'v2'}}
    s.remove_cookies(['c2'])
    assert s['cookies'] == {'c1': {'value':'v1'}}, "Problem with method remove_cookies of class Session"
    assert s.cookies, "Problem with method remove_cookies of class Session"
    s.remove_cookies(['c1'])
    assert not s['cookies'], "Problem with method remove_cookies of class Session"
    assert not s.cookies, "Problem with method remove_cookies of class Session"



# Generated at 2022-06-12 00:22:06.701567
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Initialization
    import json
    import tempfile

    cookies = {"cookie1": "value1", "cookie2": "value2"}
    session = Session(tempfile.mktemp())
    session.update_cookies(cookies)
    session.save()

    # Testing
    with open(session.path, 'r') as f:
        json_readable = json.load(f)
    assert json_readable["cookies"] == cookies
    session.remove_cookies(['cookie1'])
    with open(session.path, 'r') as f:
        json_readable = json.load(f)
    assert json_readable["cookies"] == {"cookie2": "value2"}

# Generated at 2022-06-12 00:22:09.973900
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies']={'one':1,'two':2,'three':3}
    session.remove_cookies(['one','two','four'])
    assert session['cookies']=={'three':3}

# Generated at 2022-06-12 00:22:14.916157
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session.cookies = RequestsCookieJar()
    session.cookies.set('cookie1', 'value1')
    session.cookies.set('cookie2', 'value2')
    session.cookies.set('cookie3', 'value3')
    session.cookies.set('cookie4', 'value4')
    session.cookies.set('cookie5', 'value5')
    session.remove_cookies(['cookie1', 'cookie5'])
    assert ['cookie2', 'cookie3', 'cookie4'] == list(session.cookies.keys())

# Generated at 2022-06-12 00:22:22.053082
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.auth.plugins import AuthPluginTestHelper
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin

    def _create_session(username,
                        password,
                        realm,
                        nonce,
                        method,
                        url,
                        headers=None):
        session = Session(f'./{username}_session.json')
        session.save()
        session['auth']['type'] = 'basic'
        session['auth']['username'] = username
        session['auth']['password'] = password
        session['auth']['raw_auth'] = f'{username}:{password}'
        session['headers'] = headers or {}
        session.save()

# Generated at 2022-06-12 00:22:35.776688
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    x = Session(path='test.json')
    x['cookies'] = {}
    x['cookies']['cookie_1'] = {'value': 'value_1'}
    x['cookies']['cookie_2'] = {'value': 'value_2'}
    x['cookies']['cookie_3'] = {'value': 'value_3'}
    x.remove_cookies(['cookie_1'])
    assert len(x['cookies']) == 2



# Generated at 2022-06-12 00:22:41.440574
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies')
    session['cookies'] = {
        'A': {'value': '1'},
        'B': {'value': '2'},
    }
    session.remove_cookies(['A'])
    session.remove_cookies(['C'])
    assert session['cookies'] == {'B': {'value': '2'}}

# Generated at 2022-06-12 00:22:48.327276
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    print("\nSession.remove_cookies")
    session = Session('test')
    session.update_headers(RequestHeadersDict({
        'Cookie': 'name1=value1; name2=value2; name3=value3'
    }))
    print("Cookies:", session.cookies)
    session.remove_cookies(['name1', 'name3'])
    print("Cookies:", session.cookies)

# Generated at 2022-06-12 00:22:58.692042
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'abc': {'value': '123'}, 'def': {'value': '456'}}
    names = ['abc']
    session.remove_cookies(names)
    assert session['cookies'] == {'def': {'value': '456'}}

    session['cookies'] = {'abc': {'value': '123'}, 'def': {'value': '456'}}
    names = ['abc', 'def', 'ijk']
    session.remove_cookies(names)
    assert session['cookies'] == {}

    session['cookies'] = {}
    names = ['abc', 'def', 'ijk']
    session.remove_cookies(names)
    assert session['cookies'] == {}



# Generated at 2022-06-12 00:23:04.130769
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    session = Session("temp.json")
    session['cookies'] = {"a": 1, "b": 2}
    names = ["a"]
    # Act
    session.remove_cookies(names)
    # Assert
    assert session['cookies'] == {"b": 2}, "remove_cookies failed"

# Generated at 2022-06-12 00:23:10.662119
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session.update({'cookies': {
        'to_be_removed1': 'cookie_value1',
        'to_be_removed2': 'cookie_value2',
        'to_be_left': 'cookie_value3'}})
    assert len(session['cookies']) == 3
    session.remove_cookies(['to_be_removed1', 'to_be_removed2'])
    assert len(session['cookies']) == 1
    assert 'to_be_removed1' not in session['cookies']
    assert 'to_be_removed2' not in session['cookies']
    assert 'to_be_left' in session['cookies']

# Generated at 2022-06-12 00:23:19.305114
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    value = [
        {
            'name': ['user_id'],
            'value': ['37264319'],
            'path': ['/'],
            'expires': ['2019-08-24 23:59:48'],
            'httponly': [''],
            'secure': ['']
        },
        {
            'name': ['session'],
            'value': ['fake_value'],
            'path': ['/'],
            'expires': ['2019-08-24 23:59:48'],
            'httponly': ['1'],
            'secure': ['']
        }
    ]

    session = Session('/tmp/test.json')
    session['cookies'] = value

    assert session.cookies == value

    session.remove_cookies(['user_id'])

# Generated at 2022-06-12 00:23:26.932323
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    c = Session("/path/to/session/file")
    c['cookies'] = {
        'name1': { 'value': 'val1' },
        'name2': { 'value': 'val2' }
    }
    assert len(c['cookies']) == 2
    c.remove_cookies(['name1'])
    assert len(c['cookies']) == 1
    assert list(c['cookies'].keys())[0] == 'name2'

# Generated at 2022-06-12 00:23:33.408691
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session_test.json')
    session['cookies'] = {
        'a': {
            'value': 'aValue',
            'path': '/',
            'secure': False,
            'expires': '2020-01-01 00:00:00'
        },
        'b': {
            'value': 'bValue',
            'path': '/',
            'secure': False,
            'expires': '2020-01-01 00:00:00'
        },
        'c': {
            'value': 'cValue',
            'path': '/',
            'secure': False,
            'expires': '2020-01-01 00:00:00'
        }
    }
    session.remove_cookies(('a', 'c'))

# Generated at 2022-06-12 00:23:40.862612
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    HTTPIE_COOKIES_SESSION_PATH = '/Users/ajayshankar/.httpie/sessions/localhost/HTTPie-cookies.json'
    session = Session(HTTPIE_COOKIES_SESSION_PATH)
    session.load()

    #print(session['cookies'])
    cookie = session['cookies']
    for k,v in cookie.items():
        session.remove_cookies([k])
        #print(k)
        #del self['cookies'][name]

    session.save()
    session.load()
    print(session['cookies'])

# Generated at 2022-06-12 00:23:50.861865
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path('test'))
    session['cookies'] = {'csrftoken': {'value': '1'}, 'sessionid': {'value': '2'}}
    session.remove_cookies(('csrftoken',))
    assert session['cookies'] == {'sessionid': {'value': '2'}}



# Generated at 2022-06-12 00:23:54.112306
# Unit test for constructor of class Session
def test_Session():
    S = Session()
    assert type(S['headers']) == dict
    assert type(S['cookies']) == dict
    assert type(S['auth']) == dict
    auth = S['auth']
    assert auth['type'] == None
    assert auth['username'] == None
    assert auth['password'] == None

# Generated at 2022-06-12 00:24:05.166053
# Unit test for constructor of class Session
def test_Session():

    if os.path.exists(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME):
        os.rmdir(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME)

    if not os.path.exists(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME):
        os.makedirs(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME)

    path = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / "test.json"
    session = Session(path)
    session.load()

    print(session['headers'])
    session.update_headers({"test": "test"})
    print(session['headers'])

    session.save()

    session.load()
    print(session['headers'])

# Generated at 2022-06-12 00:24:13.566671
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {
        'cookie_name': {'value': 'cookie_value1'},
        'cookie_name2': {'value': 'cookie_value2'},
        'cookie_name3': {'value': 'cookie_value3'},
    }
    session.remove_cookies(names=['cookie_name', 'cookie_name3'])
    assert session['cookies'] == {'cookie_name2': {'value': 'cookie_value2'}}, \
        'remove_cookies() failed!'

test_Session_remove_cookies()

# Generated at 2022-06-12 00:24:22.288838
# Unit test for constructor of class Session
def test_Session():
    # Normal case
    session = Session(path='../test/test.json')
    assert session.path == Path('../test/test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

    # Abnormal case with path not str type
    try:
        Session(path=2)
    except Exception as e:
        assert isinstance(e, TypeError)
        assert 'path should be str' in str(e)


# Generated at 2022-06-12 00:24:27.727226
# Unit test for constructor of class Session
def test_Session():
    config_dir = "./"
    session_name = "session"
    host = "httpbin.org"
    url = "localhost:5000/get"

    session = get_httpie_session(config_dir, session_name, host, url)
    session.load()
    print(session)

    headers = {"Accept": "text/html", "Accept-Encoding": "gzip, deflate"}
    session.update_headers(headers)
    print(session)


if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-12 00:24:34.926037
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s['cookies'] = {
        'test': {'value': 'test'},
        'test1': {'value': 'test1'},
        'test2': {'value': 'test2'},
    }
    s.remove_cookies(['test1', 'test3'])
    assert s['cookies'] == {'test': {'value': 'test'}, 'test2': {'value': 'test2'}}

# Generated at 2022-06-12 00:24:36.414890
# Unit test for constructor of class Session
def test_Session():
    s = Session('.httpie/sessions/localhsot')



# Generated at 2022-06-12 00:24:43.898258
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(path='../test_sessions/test1.json')
    s.update_headers({
        'Accept': 'text/html',
        'Content-Type': 'text/plain',
        'Content-Length': '3',
        'User-Agent': 'HTTPie/1.0.0',
        'Cookie': 'c1=v1; c2=v2',
        'If-Match': '"123"'
    })
    assert s.headers == {
        'Accept': 'text/html',
        'Content-Type': 'text/plain',
        'Content-Length': '3',
        'Cookie': 'c1=v1; c2=v2',
    }

# Generated at 2022-06-12 00:24:47.774466
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_dict = {'user': 'admin'}
    session = Session(path=Path('session'))
    session.cookies = cookie_dict
    session.remove_cookies(['user'])
    assert session.cookies != cookie_dict

# Generated at 2022-06-12 00:24:59.186270
# Unit test for constructor of class Session
def test_Session():
    assert Session(None)

# Generated at 2022-06-12 00:25:05.122722
# Unit test for constructor of class Session
def test_Session():
    session = Session(path = "config.json")
    assert type(session['headers']) is dict
    assert type(session['cookies']) is dict
    assert type(session['auth']) is dict
    assert type(session.headers) is dict
    assert type(session.cookies) is dict
    assert type(session.auth) is dict


# Generated at 2022-06-12 00:25:09.622569
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.utils import get_config_dir
    path = os.path.join(get_config_dir(), 'sessions', 'session_name.json')
    session = Session(path)
    session.load()
    assert session.headers == {}
    session.update_headers({'Header': 'content'})
    assert session.headers == {'Header': 'content'}

# Generated at 2022-06-12 00:25:19.204348
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.helpers import (
        get_response_type,
        get_response_type_requests,
        guess_response_encoding,
        is_json,
        is_pretty,
        is_serialize_request_body_as_json,
    )
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.downloads import (
        Downloader,
        ResponseNotValidForRedirection,
        is_redirect_response,
        is_safe_url,
    )
    from httpie.output.streams import get_binary_stream
    from httpie.plugins.manager import get_auth_plugin_names, plugin_manager
    from httpie.status import ExitStatus
    from httpie.useragents import USER_AGENT

# Generated at 2022-06-12 00:25:26.692881
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(os.path.expanduser("~/.httpie"))
    session_name = "httpbin"
    host = None
    url = "http://httpbin.org/get?key=value"
    session = None
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session is not None
    assert type(session) is Session
    assert session.path.name == "httpbin.json"
    assert session.about == "HTTPie session file"


# Generated at 2022-06-12 00:25:37.542628
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from httpie.plugins.registry import auth_plugins
    from httpie import session
    import os

    s = session.Session('/home/benyue/.config/httpie/sessions/test.json')
    assert s['headers'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}
    
    s.update_headers({'test': 'abc'})
    assert s['headers'] == {'test': 'abc'}

    url='https://httpbin.org/cookies/set?k1=v1'
    s.update_headers({'Cookie': 'k2=v2'})
    assert s['cookies'] == {'k2': {'value': 'v2'}}


# Generated at 2022-06-12 00:25:44.590449
# Unit test for constructor of class Session
def test_Session():
    session = Session("./session.json")
    assert isinstance(session['headers'], dict)
    assert isinstance(session['cookies'], dict)
    assert session['auth'] == dict([('type', None), ('username', None), ('password', None)])
    assert session['auth']['type'] == None
    assert session['auth']['username'] == None
    assert session['auth']['password'] == None

# Generated at 2022-06-12 00:25:54.807012
# Unit test for constructor of class Session
def test_Session():
    # Using Path object as argument
    test_obj_1 = Session(Path("/home/USERNAME/.config/httpie/sessions/lambda.json"))
    assert test_obj_1['auth'] == {'type': None, 'username': None, 'password': None}
    assert test_obj_1.cookies == RequestsCookieJar()
    # Using str as argument
    test_obj_2 = Session("/home/USERNAME/.config/httpie/sessions/lambda.json")
    assert test_obj_2['auth'] == {'type': None, 'username': None, 'password': None}
    assert test_obj_2.cookies == RequestsCookieJar()
    # TypeError
    try:
        test_obj_3 = Session(223)
    except TypeError:
        pass

# Unit test

# Generated at 2022-06-12 00:26:01.380584
# Unit test for constructor of class Session
def test_Session():
    try:
        os.makedirs(r'D:\Python\httpie\test_dumps', mode=0o777, exist_ok=True)
    except FileExistsError:
        pass
    test_Session = Session(path=r'D:\Python\httpie\test_dumps')
    test_Session['headers'] = {}
    test_Session['cookies'] = {}
    test_Session['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }
if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-12 00:26:08.448873
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("/tmp/test.json")
    session['cookies'] = {'abc': '123', 'def': '456'}
    session.remove_cookies(['abc', 'def'])
    assert session['cookies'] == {}
    session['cookies'] = {'foo': 'bar'}
    session.remove_cookies(['foo'])
    assert session['cookies'] == {}


# Generated at 2022-06-12 00:26:34.597705
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/Session.json')
    request_headers = RequestHeadersDict()
    request_headers['User-agent'] = 'Mozilla/5.0'
    session.update_headers(request_headers)
    assert session.headers['User-agent'] == 'Mozilla/5.0'

# Generated at 2022-06-12 00:26:46.144802
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import json

    session = Session("/tmp/test_Session.json")
    session['headers'] = {'Host': 'localhost', 'Cookie': 'key=value'}
    session['cookies'] = {'key': {'value': 'value'}}
    session['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }

    session_old = json.loads(json.dumps(session))
    #print(session_old)

    request_headers = {'Host': 'localhost', 'Cookie': 'key=othervalue'}
    session.update_headers(request_headers)
    #print(session)

    assert session['headers'] == {'Host': 'localhost'}

# Generated at 2022-06-12 00:26:50.253814
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/test')
    session['cookies'] = {'test': 'value'}
    assert session['cookies']['test'] == 'value'
    session.remove_cookies(['test'])
    assert 'test' not in session['cookies']

# Generated at 2022-06-12 00:26:55.216642
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cj = RequestsCookieJar()
    cj.set('foo', 'bar')
    cj.set('bar', 'baz')
    s = Session('sessions/example.com.json')
    s.cookies = cj
    s.remove_cookies(names=['foo'])
    assert 1 == len(s.cookies)
    assert 'bar' == s.cookies.get('bar').value

# Generated at 2022-06-12 00:26:57.421679
# Unit test for function get_httpie_session
def test_get_httpie_session():
    s = get_httpie_session('/', 'httpie', 'httpie.org', 'httpie.org')
    assert s is not None

# Generated at 2022-06-12 00:27:07.612010
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_json = "{\"cookies\": {\"key1\": {\"value\": \"value1\"}, \"key2\": {\"value\": \"value2\"}}, \"auth\": {\"type\": null, \"username\": null, \"password\": null}}"
    session = Session(path='path')
    import json
    session.update(json.loads(session_json))
    assert session['cookies'] == {'key1': {'value': 'value1'}, 'key2': {'value': 'value2'}}
    session.remove_cookies(['key2'])
    assert session['cookies'] == {'key1': {'value': 'value1'}}

# Generated at 2022-06-12 00:27:11.342764
# Unit test for constructor of class Session
def test_Session():
    path = r'C:\Users\dbasd\AppData\Local\Programs\Python\Python38-32\Lib\site-packages\httpie\config.json'
    session = Session(path)
    # print(session)
    return session


# Generated at 2022-06-12 00:27:15.216281
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test.json')
    s['cookies'] = {
        'c1': 'val1',
        'c2': 'val2'
    }
    s.remove_cookies(['c1'])
    assert s['cookies'] == {
        'c2': 'val2'
    }

# Generated at 2022-06-12 00:27:20.896519
# Unit test for constructor of class Session
def test_Session():
    """test Session"""
    path = 'test_path'
    session = Session(path)
    assert session.path == Path(path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }



# Generated at 2022-06-12 00:27:23.718306
# Unit test for function get_httpie_session
def test_get_httpie_session():
  print(DEFAULT_SESSIONS_DIR)
  print(get_httpie_session(DEFAULT_CONFIG_DIR,"test_session","test.com","https://test.com/test"))

# Generated at 2022-06-12 00:28:13.248310
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(':memory:')
    session['cookies'] = {'cookie1': {}, 'cookie2': {}}
    assert session['cookies'] == {'cookie1': {}, 'cookie2': {}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {}}

# Generated at 2022-06-12 00:28:20.174568
# Unit test for constructor of class Session
def test_Session():
    session = Session(config_dir=DEFAULT_SESSIONS_DIR, session_name='test', host='httpbin.org', url='http://httpbin.org')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }
    assert session.headers == {}
    assert session.cookies == RequestsCookieJar()
    assert session.auth is None
    return

# Generated at 2022-06-12 00:28:23.864757
# Unit test for constructor of class Session
def test_Session():
    if not os.path.exists(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME):
        os.makedirs(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME)
    s = Session(DEFAULT_SESSIONS_DIR)
    print(s)

# Test for function get_httpie_session

# Generated at 2022-06-12 00:28:25.719312
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies']={"name1":"he","name2":"hi"}
    session.remove_cookies(["name1"])
    assert "name1" not in session['cookies']

# Generated at 2022-06-12 00:28:31.191309
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from unittest.mock import patch
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.sessions import get_httpie_session
    url = 'http://localhost:8080/a/b'
    session_name = 'abc'
    host = 'localhost'
    with patch('httpie.config.DEFAULT_CONFIG_DIR', '/tmp') as mock:
        session = get_httpie_session(DEFAULT_CONFIG_DIR, session_name, host, url)
        assert type(session) == Session
        assert type(session['cookies']) == dict

# Generated at 2022-06-12 00:28:37.308836
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)

    # Test if headers contain more than one entry and if entries are updated in the session
    assert session['headers'] == {}
    request_headers = {'a': 'b', 'c': 'd'}
    session.update_headers(request_headers)
    assert session['headers'] == {'a': 'b', 'c': 'd'}

    # Test if entries which match with ignored headers are not updated in the session
    session['headers'] = {}
    session.update_headers({'coNTent-length': '5'})
    assert session['headers'] == {}
    session['headers'] = {}
    session.update_headers({'if-mATCH': '7'})
    assert session['headers'] == {}

    # Test if cookie entry is not updated in the session but in the session['cookies']


# Generated at 2022-06-12 00:28:38.362629
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session()

# Generated at 2022-06-12 00:28:39.487401
# Unit test for function get_httpie_session
def test_get_httpie_session():
    print(get_httpie_session(DEFAULT_CONFIG_DIR, 'test_session', '127.0.0.1', 'http://localhost'))

# Generated at 2022-06-12 00:28:43.538212
# Unit test for constructor of class Session
def test_Session():
    s = Session('/test/test.json')
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth']['type'] == None
    assert s['auth']['username'] == None
    assert s['auth']['password'] == None



# Generated at 2022-06-12 00:28:52.702805
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert (
        get_httpie_session(
            DEFAULT_CONFIG_DIR,
            'test_get_httpie_session',
            host='example.com:8080',
            url='https://example.com/foo'
        ).path
    )\
        == (DEFAULT_CONFIG_DIR / 'sessions/example_com_8080/test_get_httpie_session.json')
    assert (
        get_httpie_session(
            DEFAULT_CONFIG_DIR,
            'test_get_httpie_session',
            host='example.com',
            url='https://example.com/foo'
        ).path
    )\
        == (DEFAULT_CONFIG_DIR / 'sessions/example_com/test_get_httpie_session.json')