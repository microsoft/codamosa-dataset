

# Generated at 2022-06-12 00:19:45.589598
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("session_file")
    session['cookies'] = {'H1' : {'value' : 'V1'}}
    session.remove_cookies(['H1', 'H2'])
    assert 'H1' not in session['cookies']

# Generated at 2022-06-12 00:19:48.109215
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    request_headers = {'A': '1', 'B': '2', 'C': '3'}
    session.update_headers(request_headers)
    assert session['headers'] == request_headers

# Generated at 2022-06-12 00:19:53.370518
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path('session.json'))
    headers = RequestHeadersDict([('Header1', 1), ('Header2', 2), ('Header3', 3)])
    session.update_headers(headers)
    assert(session['headers'] == {
        'Header1': '1',
        'Header2': '2',
        'Header3': '3'
    })


# Generated at 2022-06-12 00:20:01.310601
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='TestSession')
    session.update_headers({
        'Content-Type': 'application/vnd.ms-excel',
        'User-Agent': 'HTTPie/0.9.9',
        'Other': 'Value',
        'Cookie': 'cookies',
    })
    assert session.get('headers') == {'Other': 'Value'}
    assert session.get('cookies') == {'cookies': {'value': 'cookies'}}

# Generated at 2022-06-12 00:20:11.145344
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session['auth'] = {'type': 'basic'}
    session['cookies'] = {}
    session['headers'] = {}
    session.update_headers({
        'foo': 'bar',
        'content-type': 'text',
        'Cookie': 'a=b'
    })
    assert session['headers'] == {'foo': 'bar'}
    assert session['cookies'] == {'a': {'value': 'b'}}
    assert session['auth'] == {'type': 'basic'}
    session.update_headers({
        'foo': None,
        'Content-length': '16',
        'Cookie': 'a=b; c=d',
        'cookie': 'e=f'
    })

# Generated at 2022-06-12 00:20:23.468372
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('.')
    request_headers = RequestHeadersDict()
    request_headers['Cookie'] = 'bar1=baz1; bar2=baz2'
    request_headers['Content-Type'] = 'application/json; charset=UTF-8'
    request_headers['Host'] = 'google.com'
    request_headers['Connection'] = 'keep-alive'

    session.update_headers(request_headers)
    assert session.headers == RequestHeadersDict([('Content-Type', 'application/json; charset=UTF-8'), ('Host', 'google.com'), ('Connection', 'keep-alive')])
    assert session.cookies == RequestsCookieJar()
    session.cookies.set('bar1', 'baz1')

# Generated at 2022-06-12 00:20:26.795695
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(None)
    s['cookies'] = {'A':{'value': 'A'}, 'B': {'value': 'B'}}
    s.remove_cookies(['A'])
    assert s['cookies'] == {'B': {'value': 'B'}}
    s.remove_cookies(['C'])
    assert s['cookies'] == {'B': {'value': 'B'}}
    s.remove_cookies(['B', 'C'])
    assert s['cookies'] == {}

# Generated at 2022-06-12 00:20:33.006657
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers(dict(a=123, b=456))
    assert session.headers == dict(a=123, b=456)

    session.update_headers(dict(c=789))
    assert session.headers == dict(a=123, b=456, c=789)

    session.update_headers(dict(d=None))
    assert session.headers == dict(a=123, b=456, c=789, d=None)

    session.update_headers(dict(b=None, e=None))
    assert session.headers == dict(a=123, c=789, d=None, e=None)

# Generated at 2022-06-12 00:20:40.123180
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('C:\fakepath')
    session.update_headers({'content-type': 'appli_cation/json',
                            'cookie': 'foo=bar',
                            'if-none-match': 'abc'})
    assert 'content-type' not in session['headers']
    assert 'if-none-match' not in session['headers']
    assert 'cookie' not in session['headers']
    assert {'foo': {'value': 'bar'}} == session['cookies']

# Generated at 2022-06-12 00:20:47.293457
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {'Content-Type': 'image/jpeg', 'Host': 'www.abc.com'}
    session = Session()
    session.update_headers(request_headers)
    stored_headers = session.headers
    assert stored_headers == {'Host': 'www.abc.com'}
    assert session['cookies'] == {}

    cookies_str = 'test=test_value;test1=test1_value'
    request_headers['Cookie'] = cookies_str
    session.update_headers(request_headers)
    assert stored_headers == {'Host': 'www.abc.com'}
    assert session['cookies']['test']['value'] == 'test_value'
    assert session['cookies']['test1']['value'] == 'test1_value'

# Generated at 2022-06-12 00:20:55.692054
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """Testing the removal of cookies"""
    s = Session("~/.config/httpie/sessions/localhost/test_session.json")
    s['cookies'] = {
        "cookie1" : {"value" : "1"},
        "cookie2" : {"value" : "2"},
        "cookie3" : {"value" : "3"}
    }
    cookie = s.cookies
    s.remove_cookies(["cookie1","cookie3"])
    assert s.cookies == cookie

# Generated at 2022-06-12 00:20:59.549975
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session['cookies'] = {
                        'a': 1,
                        'b': 2,
                        'c': 3
                        }
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-12 00:21:03.340374
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/test/test.json')
    session['cookies'] = {'cookie1': 1, 'cookie2': 2}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 2}

# Generated at 2022-06-12 00:21:08.950811
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    instance_Session = Session(path=Path('path'))
    instance_Session['cookies'] = {'a': 'a', 'b': 'b'}
    instance_Session.remove_cookies(['a'])
    assert instance_Session['cookies'] == {'b': 'b'}
    instance_Session.remove_cookies(['c'])
    assert instance_Session['cookies'] == {'b': 'b'}



# Generated at 2022-06-12 00:21:12.866901
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("Session")
    s['cookies'] = {'cookie1': 1, 'cookie2': 2, 'cookie3': 3}
    s.remove_cookies(['cookie2'])
    assert s['cookies']['cookie2'] == 2


# Generated at 2022-06-12 00:21:16.609160
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path="")
    session['cookies'] = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    session.remove_cookies(['a', 'c', 'd'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-12 00:21:25.323844
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """ Unit test for method remove_cookies of class Session
        Parameters:
            None
        Returns:
            None
    """
    test_instance = Session('')
    session_cookies = {
        'key1': {
            'path': '/',
            'expires': 'dummy',
            'secure': True,
            'value': 'value1'
        },
        'key2': {
            'path': '/',
            'expires': 'dummy',
            'secure': True,
            'value': 'value2'
        },
        'key3': {
            'path': '/',
            'expires': 'dummy',
            'secure': True,
            'value': 'value3'
        }
        }
    test_instance['cookies'] = session_cookies
    test_instance

# Generated at 2022-06-12 00:21:27.798430
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # create Session instance
    # instance.cookies
    # instance.remove_cookies
    pass

# Generated at 2022-06-12 00:21:36.008716
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path="path")
    cookies = {}
    cookies['cookie1'] = {}
    cookies['cookie2'] = {}
    cookies['cookie3'] = {}
    cookies['cookie4'] = {}
    session['cookies'] = cookies
    session.remove_cookies(["cookie2", "cookie4"])
    assert "cookie1" in session['cookies']
    assert "cookie2" not in session['cookies']
    assert "cookie3" in session['cookies']
    assert "cookie4" not in session['cookies']



# Generated at 2022-06-12 00:21:42.543104
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('session')
    s.cookies = RequestsCookieJar()
    s.cookies.set_cookie(create_cookie('name1', 'value1'))
    s.cookies.set_cookie(create_cookie('name2', 'value2'))
    s.remove_cookies(['name1', 'name2'])
    assert s.cookies.__len__() == 0

    s.cookies.set_cookie(create_cookie('name1', 'value1'))
    s.cookies.set_cookie(create_cookie('name2', 'value2'))
    s.remove_cookies(['name3'])
    assert s.cookies.__len__() == 2

# Generated at 2022-06-12 00:21:54.093190
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    jar = RequestsCookieJar()
    jar.set_cookie(create_cookie('name1', 'value1'))
    jar.set_cookie(create_cookie('name2', 'value2'))

    s = Session('/tmp/session_temp')
    s.cookies = jar
    s.remove_cookies(['name1', 'name3'])
    assert 'name3' not in s['cookies']
    assert 'name2' in s['cookies']

# Generated at 2022-06-12 00:21:59.693290
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('sessions/test/test.json')
    session.update_headers({"Content-Type": "application/json",
                            "Cookie": "cookie1=value1; cookie2=value2"})
    session.remove_cookies(["cookie2"])
    assert "cookie2" not in session["cookies"]
    assert session["cookies"] == {'cookie1': {'value': 'value1'}}

# Generated at 2022-06-12 00:22:03.582700
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # prepare test data
    session = Session('test_sessions.json')
    session.save()

    # execute remove_cookies
    session.remove_cookies({'abc'})

    # assert
    assert 'abc' not in session.cookies

# Generated at 2022-06-12 00:22:11.408296
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_names = ['httpie', 'curl', 'wget']
    session = Session('test_session')
    session['cookies'] = {
        name: {'value': name} for name in cookie_names
    }
    session.remove_cookies(['httpie'])
    assert session['cookies'] == {
        'curl': {'value': 'curl'},
        'wget': {'value': 'wget'}
    }
    session.remove_cookies(cookie_names)
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:22:16.087801
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('.')
    session['cookies'] = {'a': 1, 'b': 2}
    session.remove_cookies({'a', 'c'})
    assert session['cookies'] == {'b': 2}



# Generated at 2022-06-12 00:22:26.911202
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'name1': {'value': 'value1'},
                          'name2': {'value': 'value2'}}
    session.remove_cookies(names=['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}
    session.remove_cookies(names=['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}
    session.remove_cookies(names=['name2'])
    assert session['cookies'] == {}
    session['cookies'] = {'name1': {'value': 'value1'},
                          'name2': {'value': 'value2'}}

# Generated at 2022-06-12 00:22:30.740947
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
  newSession = Session("/Users/Dhanushka/.httpie/sessions/a.json")
  newSession.cookies = {"Cookies":["a=b","c=d","e=f"]}
  newSession.remove_cookies(["a"])
  assert newSession.cookies == ["c=d","e=f"]



# Generated at 2022-06-12 00:22:38.009919
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('example.json')
    session['cookies']['abc'] = 'abc cookie'
    session['cookies']['def'] = 'def cookie'
    session.remove_cookies(['abc'])
    assert 'abc' not in session['cookies']
    assert 'def' in session['cookies']


# Generated at 2022-06-12 00:22:41.357432
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    cookies = {'one':1, 'two':2}
    names = ['one','three']

    session = Session("test_session")
    session['cookies'] = cookies
    session.remove_cookies(names)

    assert session['cookies'] == {'two':2}

# Generated at 2022-06-12 00:22:46.977890
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie = {'key1': 'value1', 'key2': 'value2'}
    session = Session('/path/to/session.json')
    session.cookies = cookie
    session.remove_cookies(['key1'])
    assert session['cookies'] == {'key2': 'value2'}



# Generated at 2022-06-12 00:23:02.139099
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_temp = Session("temp")
    session_temp['cookies'] = {'one': 1, 'two': 2, 'three': 3}
    session_temp.remove_cookies(['one', 'three'])
    assert session_temp['cookies'] == {'two': 2}
    session_temp.remove_cookies(['I do not exist'])
    assert session_temp['cookies'] == {'two': 2}
    session_temp.remove_cookies(['two'])
    assert session_temp['cookies'] == {}

# Generated at 2022-06-12 00:23:09.169533
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./session.json')
    session['cookies'] = \
        {'name': {'value': 'value', 'path': 'path'},
         'name2': {'value': 'value2', 'path': 'path2'}}
    assert len(session['cookies']) == 2
    session.remove_cookies(['name'])
    session.remove_cookies(['name3'])
    assert len(session['cookies']) == 1
    session.remove_cookies(['name2'])
    assert len(session['cookies']) == 0

# Generated at 2022-06-12 00:23:18.573370
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.test')
    session['cookies'] = {}
    session['cookies']['testcookie'] = {'testvalue': '1234'}
    session['cookies']['testcookie1'] = {'testvalue': '12345'}
    session['cookies']['testcookie2'] = {'testvalue': '12346'}
    session.remove_cookies(['testcookie1', 'testcookie2', 'testcookie3'])
    print(session)
    assert session['cookies']['testcookie'] == {'testvalue': '1234'}
    assert 'testcookie1' not in session['cookies']
    assert 'testcookie2' not in session['cookies']
    assert 'testcookie3' not in session['cookies']

# Generated at 2022-06-12 00:23:22.607566
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session')
    session['cookies'] = {'cookie1': {}, 'cookie2': {}}

    session.remove_cookies(['cookie2', 'cookie3'])

    assert session['cookies'] == {'cookie1': {}}

# Generated at 2022-06-12 00:23:29.360981
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/session1.json')
    assert s['cookies'] == {}
    s['cookies']['name1'] = 'value1'
    s['cookies']['name2'] = 'value2'
    s['cookies']['name3'] = 'value3'
    s.remove_cookies(['name1', 'name3'])
    assert s['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-12 00:23:34.351477
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'c1': {}, 'c2': {}, 'c3': {}}
    s = Session("s1")
    s["cookies"] = cookies
    s.remove_cookies(("c1", "c2"))
    assert s["cookies"] == {'c3': {}}



# Generated at 2022-06-12 00:23:40.418765
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path=DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME)
    s['cookies'] = {'name': 'value'}
    s.remove_cookies(['name'])
    assert s['cookies'] == {}
    assert s['cookies'] != {'name': 'value'}
    s['cookies'] = {'name': 'value'}
    assert s['cookies'] == {'name': 'value'}


# Generated at 2022-06-12 00:23:47.616243
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(__file__))
    session.update('cookies', {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}})
    session.remove_cookies(['cookie1', 'cookie3'])
    assert session.get('cookies') == {'cookie2': {'value': 'value2'}}



# Generated at 2022-06-12 00:23:55.506402
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = RequestsCookieJar()
    cookie = create_cookie('chocolate', 'chip')
    self.cookies.set_cookie(cookie)
    self.cookies.set_cookie(create_cookie('plain', 'vanilla'))
    self.cookies.set_cookie(create_cookie('oatmeal', 'raisin'))
    test = {}
    for cookie in name:
        test[cookie.name] = {'value': cookie.value}

    test_cookie = {'chocolate': {'value': 'chip'},
                   'oatmeal': {'value': 'raisin'},
                   'plain': {'value': 'vanilla'}}

    assert test == test_cookie

    self.remove_cookies(['chocolate', 'oatmeal'])

    test = {}

# Generated at 2022-06-12 00:24:01.990726
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("/tmp/test_Session_remove_cookies")
    session['headers'] = {'a': 'a'}
    session['cookies'] = {'b': 'b', 'c': 'c'}
    session.remove_cookies(['b', 'd'])
    assert session['cookies'] == {'c': 'c'}
    assert session['headers'] == {'a': 'a'}

# Generated at 2022-06-12 00:24:26.097541
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    c = create_cookie('test_name', 'test_value', domain='test_domain')
    session.cookies.set_cookie(c)

    assert 'test_name' in session.cookies.get_dict()
    session.remove_cookies(['test_name'])
    assert 'test_name' not in session.cookies.get_dict()



# Generated at 2022-06-12 00:24:37.687202
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from pathlib import Path
    from httpie.compat import is_py38
    import json
    import pytest

    if is_py38:
        pytest.skip("Skipping Session test on Python 3.8 because "
                    "pathlib.Path.read_bytes() crashes on 3.8 in Travis")

    session_path = Path("/tmp/test_session.json")
    if session_path.is_file():
        session_path.unlink()
    session = Session(session_path)
    session.update_headers({"Cookie": "c=0"})
    session.update_headers({"Cookie": "d=1"})
    session.update_headers({"Cookie": "e=2"})
    session.save()

# Generated at 2022-06-12 00:24:44.435947
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    This function tests the function remove_cookies of class Session. It tests different cases.
    """
    s = Session('test')
    s['cookies'] = {}
    # Check if it's possible to remove a cookie that is not in the dict
    s.remove_cookies(['a'])
    assert s['cookies'] == {}
    s['cookies'] = {'a': 'b'}
    # Remove cookie from dict
    s.remove_cookies(['a'])
    assert s['cookies'] == {}
    # Check if it is possible to remove multiple cookies
    s['cookies'] = {'a': 'b', 'c': 'd'}
    s.remove_cookies(['a'])
    assert s['cookies'] == {'c': 'd'}
    # Check if it

# Generated at 2022-06-12 00:24:49.545634
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('session.json')
    s['cookies'] = {'cookie1': {}, 'cookie2': {}}
    s.remove_cookies(['cookie1'])
    assert {'cookie2': {}} == s['cookies']
    s.remove_cookies(['cookie2'])
    assert {} == s['cookies']



# Generated at 2022-06-12 00:24:56.075103
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./test.json')
    session['cookies'] = {'cookie1': {},
                          'cookie2': {},
                          'cookie3': {},
                          'cookie4': {}}
    session.remove_cookies(names=['cookie1', 'cookie3'])
    assert session['cookies'] == {'cookie2': {},
                                  'cookie4': {}}


# Generated at 2022-06-12 00:25:01.901806
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    cookies = {
        'foo': {'value': 'bar'},
        'baz': {'value': 'bar'},
    }
    session['cookies'] = cookies
    session.remove_cookies(['baz'])
    assert session['cookies'] == {'foo': {'value': 'bar'}}

# Generated at 2022-06-12 00:25:12.432062
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.argtypes import AuthCredentials
    from httpie.auth import AuthPlugin, AuthCredentials, parse_auth
    from httpie.plugins.registry import plugin_manager
    import json, requests
    import os, shutil, tempfile

    #Save current directory
    current_dir = os.getcwd()

    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test'
        auth_parse = True
        def get_auth(self, username, password):
            return TestAuth(username, password)
        def get_auth_from_url(self, url):
            return TestAuth(url.username, url.password)

    class TestAuth(AuthBase):
        def __init__(self, username, password):
            self.username = username
            self.password = password

# Generated at 2022-06-12 00:25:16.967008
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./testSession')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2':{'value': 'value2'}}
    session.remove_cookies(('cookie1','cookie3'))
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}


# Generated at 2022-06-12 00:25:19.989873
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path="test")
    session['cookies'] = {'test':'cookie', 'test2':'cookie2'}
    session.remove_cookies(['test'])
    assert session['cookies'] == {'test2':'cookie2'}

# Generated at 2022-06-12 00:25:29.525455
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("david_test.json")
    s['cookies'] = {'cookie1': {'value': 'v1'}, 'cookie2': {'value': 'v2'}}
    assert len(s['cookies']) == 2
    s.remove_cookies(['cookie1', 'cookie2'])
    assert len(s['cookies']) == 0
    # If we call remove_cookies with a name not in the dict, it does not fail
    s.remove_cookies(['cookie1', 'cookie2'])
    assert len(s['cookies']) == 0
    # Now try with a cookie name in the dict

    s['cookies'] = {'cookie1': {'value': 'v1'}, 'cookie2': {'value': 'v2'}}

# Generated at 2022-06-12 00:26:12.640459
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_jar = RequestsCookieJar()
    cookie_jar.set('cookie1', 'value1')
    cookie_jar.set('cookie2', 'value2')
    session = Session("")
    session.cookies = cookie_jar
    session.remove_cookies(['cookie1'])
    assert(len(session.cookies) == 1)
    assert(session.cookies['cookie2'] == 'value2')

# Generated at 2022-06-12 00:26:16.069549
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s['cookies'] = {'abc':{'value':'123'},'def':{'value':'456'}}
    s.remove_cookies(['abc','def'])
    assert s['cookies'] == {}

# Generated at 2022-06-12 00:26:26.513222
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from unittest import TestCase, mock


    class TestSession(TestCase):

        @mock.patch('httpie.downloads.get_config_dir')
        def test_info(self, mock_get_config_dir):
            mock_get_config_dir.return_value = '/home/user/.config/httpie'
            session = Session('http://httpie.org/sessions/test')

# Generated at 2022-06-12 00:26:36.039357
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie1 = {'name': 'first_cookie', 'value': 'value1'}
    cookie2 = {'name': 'second_cookie', 'value': 'value2'}
    cookie3 = {'name': 'third_cookie', 'value': 'value3'}
    session = Session('~/')
    session['cookies'] = {
        cookie1['name']: cookie1,
        cookie2['name']: cookie2,
        cookie3['name']: cookie3
    }
    session.remove_cookies(['second_cookie', 'third_cookie'])
    assert ({
        cookie1['name']: cookie1,
    }) == session['cookies']


# Generated at 2022-06-12 00:26:42.225456
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('abc.json')
    for i in ['1', '2', '3', '4']:
        s['cookies'][i] = dict()
    assert len(s['cookies']) == 4
    s.remove_cookies(['1', '5', '3'])
    assert len(s['cookies']) == 2


# Unit test to validate the pattern for session names

# Generated at 2022-06-12 00:26:50.528620
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session(path = "/path/to/session")
    sess['cookies'] =  {'c1': {}, 'c2': {}, 'c3': {}}
    sess.remove_cookies(['c2'])
    assert sess['cookies'] == {'c1': {}, 'c3': {}}
    sess.remove_cookies(['c4'])
    assert sess['cookies'] == {'c1': {}, 'c3': {}}
    sess.remove_cookies(['c1', 'c3'])
    assert sess['cookies'] == {}

# Generated at 2022-06-12 00:27:01.120188
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session.json')
    # Initial settings
    session['cookies'] = {
        'my-cookie-1': {'value': 'Cookie-value-1', 'path': '/path-1'},
        'my-cookie-2': {'value': 'Cookie-value-2', 'path': '/path-2'},
        'my-cookie-3': {'value': 'Cookie-value-3', 'path': '/path-3'},
        'my-cookie-4': {'value': 'Cookie-value-4', 'path': '/path-4'},
        'my-cookie-5': {'value': 'Cookie-value-5', 'path': '/path-5'},
    }
    # Test 1

# Generated at 2022-06-12 00:27:06.301957
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(DEFAULT_SESSIONS_DIR / 's.json')
    session['cookies'] = {'a': {'value': 'b'}, 'b': {'value': 'c'}}

    assert session.remove_cookies('a') == True

    assert session['cookies'] == {'b': {'value': 'c'}}

# Generated at 2022-06-12 00:27:10.292215
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='sessions_test.json')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(names=['name2'])
    assert session['cookies'] == {'name1': 'value1'}

# Generated at 2022-06-12 00:27:15.354130
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/path/to/session.json')
    session['cookies'] = {'a': {}, 'b': {}, 'c': {}}
    assert set(session['cookies'].keys()) == {'a', 'b', 'c'}
    session.remove_cookies(['a', 'c'])
    assert set(session['cookies'].keys()) == {'b'}

# Generated at 2022-06-12 00:28:51.118391
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = Path('/home/sjoerd/.config/httpie/sessions/github.com.json')
    session = Session(path)
    session.load()
    session.remove_cookies(['over'])
    jar = session.cookies
    expected = [
        'tz', 'logged_in', 'dotcom_user', 'dotcom_user', 'dotcom_user', 'user_session', 'user_session', 'user_session_secure'
    ]
    actual = [cookie.name for cookie in jar]
    assert actual == expected

# Generated at 2022-06-12 00:28:55.435894
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    assert {} == session['cookies']
    session.remove_cookies(['a'])
    assert {} == session['cookies']
    session['cookies'] = {'a':{'value':'b'}}
    assert {'a':{'value':'b'}} == session['cookies']
    session.remove_cookies(['a'])
    assert {} == session['cookies']
    session['cookies'] = {'a':{'value':'b'}}
    assert {'a':{'value':'b'}} == session['cookies']
    session['cookies']['c'] = {'value': 'd'}
    assert {'a':{'value':'b'},'c':{'value':'d'}} == session['cookies']
   

# Generated at 2022-06-12 00:29:01.439765
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # test the case that the key `name` does not exist
    cookies = {}
    cookie_names = ['name1']
    for name in cookie_names:
        if name in cookies:
            del cookies[name]
    assert cookies == {}

    # test the case that the key `name` exist
    cookies = {'name1': ''}
    cookie_names = ['name1']
    for name in cookie_names:
        if name in cookies:
            del cookies[name]
    assert cookies == {}

test_Session_remove_cookies()



# Generated at 2022-06-12 00:29:07.194771
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/abc')
    session['cookies']['a'] = 1
    session['cookies']['b'] = 2
    session['cookies']['c'] = 3
    assert (len(session['cookies']) == 3)
    session.remove_cookies(['b', 'c'])
    assert (len(session['cookies']) == 1)
    for i in session['cookies']:
        assert (i == 'a')

# Generated at 2022-06-12 00:29:10.939060
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test')
    cookies = dict(foo = 'bar', baz = 'qux')
    session.cookies = cookies
    assert session.cookies == cookies
    session.remove_cookies(['foo'])
    assert session.cookies == {'baz': 'qux'}

# Generated at 2022-06-12 00:29:14.217113
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = BaseConfigDict({'cookies': {'foo': 'bar'}})
    assert s.get('cookies').get('foo') == 'bar'
    s.remove_cookies(['foo'])
    assert s.get('cookies').get('foo') is None

# Generated at 2022-06-12 00:29:18.078814
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('non-existent')
    s['cookies'] = { 'a': 1, 'b': 2, 'c': 3, 'd': 4 }
    assert len(s['cookies']) == 4
    s.remove_cookies(('a', 'b'))
    assert len(s['cookies']) == 2

# Generated at 2022-06-12 00:29:28.207058
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test_Session_remove_cookies.json")
    session['cookies'] = {
        'name2': {'value': 'value2', 'path': '/', 'secure': False, 'expires': None},
        'name1': {'value': 'value1', 'path': '/', 'secure': False, 'expires': None},
        'name3': {'value': 'value3', 'path': '/', 'secure': False, 'expires': None},
        'name4': {'value': 'value4', 'path': '/', 'secure': False, 'expires': None},
    }
    session.remove_cookies(['name1', 'name3'])

# Generated at 2022-06-12 00:29:35.254153
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./test')
    session['cookies'] = {}
    session['cookies']['test1'] = {'value': 'test1'}
    session['cookies']['test2'] = {'value': 'test2'}
    session['cookies']['test3'] = {'value': 'test3'}
    names = ['test1', 'test3']
    session.remove_cookies(names)
    assert 'test1' not in session.keys()
    assert 'test2' in session.keys()
    assert 'test3' not in session.keys()