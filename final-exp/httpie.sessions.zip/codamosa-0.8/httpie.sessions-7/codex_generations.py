

# Generated at 2022-06-12 00:19:51.096118
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='tmp/test_session.json')
    request_headers = RequestHeadersDict(
        {'Content-Type': 'application/json',
         'Etag': 'None',
         'Accept': 'text/html',
         'User-Agent': 'HTTPie/0.9.2',
         'Accept-Encoding': 'gzip, deflate',
         'Connection': 'keep-alive'})
    session.update_headers(request_headers)
    assert session['headers'] == {'Accept': 'text/html',
                                  'Accept-Encoding': 'gzip, deflate',
                                  'Connection': 'keep-alive',
                                  'Etag': 'None'}


# Generated at 2022-06-12 00:19:58.301401
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from collections import OrderedDict

    config_dir = DEFAULT_SESSIONS_DIR
    session_name = 'test'
    host = None
    url = 'http://httpbin.org/get'

    session = get_httpie_session(
        config_dir, session_name, host, url
    )
    assert session.headers == OrderedDict()

    request_headers = RequestHeadersDict(OrderedDict([
        ('Cookie', "a=1"),
        ('Cookie', "b=2"),
        ('If-None-Match', "\"foo\""),
        ('Accept', "text/html"),
    ]))

    session.update_headers(request_headers)

    assert session.headers == OrderedDict([
        ('accept', "text/html"),
    ])


# Generated at 2022-06-12 00:20:09.944324
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test 1: headers, None
    session = Session("abc")
    session.update_headers({"Content-Type": "application/json",
                            "Cookie":"a=1"})
    assert "Content-Type" not in session.headers
    assert "a" not in session.cookies

    # Test 2: headers, bytes
    session.update_headers({"Content-Type": b"application/json",
                            "Cookie": b"a=1"})
    assert "Content-Type" not in session.headers
    assert "a" not in session.cookies

    # Test 3: headers, str
    session.update_headers({"Content-Type": "application/json",
                            "Cookie": "a=1"})
    assert "Content-Type" not in session.headers

# Generated at 2022-06-12 00:20:20.434380
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.argtypes import KeyValueArg

    session = Session(path='/dev/null')
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie(
        'hoge', 'hoge_value', domain='localhost'))
    session.cookies.set_cookie(create_cookie(
        'fuga', 'fuga_value', domain='example.com'))

    session.remove_cookies(['hoge'])

    expected = 'Cookie: fuga=fuga_value'
    assert session.cookies.__repr__() == expected


# Generated at 2022-06-12 00:20:27.949400
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'a': 'b'})
    assert session['headers'] == {'a': 'b'}
    session.update_headers({'a': 'c'})
    assert session['headers'] == {'a': 'c'}
    session.update_headers({'a': None})
    assert session['headers'] == {'a': None}
    session = Session('test')
    session.update_headers({'Content-Type': 'text/xml'})
    assert 'Content-Type' not in session['headers']


# Generated at 2022-06-12 00:20:39.509177
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_request_headers = {
        'Content-Length': '0',
        'If-Modified-Since': 'Mon, 05 Nov 2018 16:52:52 GMT',
        'Accept-Encoding': 'gzip',
        'Cookie': 'a=b'
    }
    test_session_headers = {
        'accept': 'application/json',
        'Accept-Encoding': 'gzip'
    }
    expected_updated_session_headers = {
        'accept': 'application/json',
        'Accept-Encoding': 'gzip',
        'Cookie': 'a=b'
    }
    session = Session('test_session')
    session['headers'] = test_session_headers
    session.update_headers(test_request_headers)
    assert session['headers'] == expected_updated_session_headers

# Generated at 2022-06-12 00:20:46.998273
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Verify that we correctly access to the content of the dict
    """
    s = Session('path')
    d = RequestHeadersDict({'Content-Type': 'application/json'})
    d['Accept'] = 'text/plain'
    s.update_headers(d)
    assert s.headers['Accept'] == 'text/plain'
    assert (s.headers['Content-Type']== 'application/json')
    assert 'Accept' in s.headers
    assert 'Content-Type' in s.headers
    assert (s.headers['Accept'] is not 'application/json')
    assert (s.headers['Content-Type'] is not 'text/plain')
    assert s.headers['Content-Type'].encode('utf8') == b'application/json'

# Generated at 2022-06-12 00:20:55.420949
# Unit test for method update_headers of class Session

# Generated at 2022-06-12 00:21:03.747158
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.config import Config
    from httpie.core import get_response
    from httpie.input import ParseError
    from httpie.plugins import AUTH_PLUGIN_MAP
    from httpie.plugins import builtin
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.core import HTTPBasicAuth,HTTPTokenAuth
    from httpie.utils import get_headers
    from httpie.constants import DEFAULT_UA

    builtin.plugins.register(HTTPAuthPlugin())
    config = Config()
    args=(
        'google.com',
    )
    kwargs = {
        'method': 'GET',
        'session': None,
        'session_read_only': False,
        'auth': auth,
    }
    # Test update headers

# Generated at 2022-06-12 00:21:11.742305
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test method update_headers of class Session
    session = Session()
    r_headers = RequestHeadersDict()
    # add headers
    # update_headers will not throw Exception when it has no key 'header'
    session.update_headers(r_headers)
    # add headers again
    session['headers']['user-agent'] = 'Mozilla/5.0'
    r_headers['user-agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X x.y; rv:42.0) Gecko/20100101 Firefox/42.0'
    session.update_headers(r_headers)

# Generated at 2022-06-12 00:21:19.594410
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('file')
    s['cookies'] = {'a': 1, 'b': 2}
    s.remove_cookies(['a', 'c'])
    assert s['cookies'] == {'b': 2}

# Generated at 2022-06-12 00:21:26.761062
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = "fixed"
    host = "http://httpbin.org"
    url = "http://httpbin.org"

    session_object = get_httpie_session(config_dir, session_name, host, url)
    old_cookie_count = len(session_object['cookies'])
    old_cookie = session_object['cookies']['newCookie']

    session_object.remove_cookies(['newCookie'])
    new_cookie_count = len(session_object['cookies'])

    assert old_cookie_count > new_cookie_count
    assert old_cookie != session_object['cookies']['newCookie']

# Generated at 2022-06-12 00:21:32.049805
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('.')
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 'value2'}, \
        'Session remove_cookies failed'

# Generated at 2022-06-12 00:21:39.891379
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path = 'path')
    s.cookies = {'cookies_1':{'value':'cookies1'}, 'cookies_2':{'value':'cookies2'}}

    s.remove_cookies(['cookies_1'])
    assert s['cookies'] == {'cookies_2':{'value':'cookies2'}}

    s.remove_cookies(['cookies_1', 'cookies_2'])
    assert s['cookies'] == {}

    s.remove_cookies([])
    assert s['cookies'] == {}

# Generated at 2022-06-12 00:21:46.803163
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = 'config_dir_path/'
    session = Session(path)
    session['cookies'] = {'cookie1': {'path': '/'},
                          'cookie2': {'path': '/'},
                          'cookie3': {'path': '/'}}
    session.remove_cookies(['cookie1', 'cookie3'])
    assert session == {'headers': {},
                       'cookies': {'cookie2': {'path': '/'}}}

# Generated at 2022-06-12 00:21:50.987071
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {"c1":"cookie1","c2":"cookie2"}
    session.remove_cookies(['c1'])
    assert session['cookies'] == {"c2":"cookie2"}

# Generated at 2022-06-12 00:21:56.906237
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('x')
    session['cookies'] = {'a':None,'b':None,'c':None}
    session.remove_cookies(['a','b'])
    assert session['cookies'] == {'c':None}
    session.remove_cookies(['d'])
    assert session['cookies'] == {'c':None}
    session.remove_cookies([])
    assert session['cookies'] == {'c':None}

# Generated at 2022-06-12 00:22:04.824600
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    assert set() == session.cookies.keys()
    session['cookies'] = {}
    name_list = ['cookie_name', 'cookie_name2', 'cookie_name3']
    for name in name_list:
        session['cookies'][name] = {'value':'value'}
    assert set(name_list) == session.cookies.keys()
    session.remove_cookies(['cookie_name', 'cookie_name2'])
    assert set(['cookie_name3']) == session.cookies.keys()

# Generated at 2022-06-12 00:22:11.288750
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = '~/.httpie/sessions/example.org/session1.json'
    session = Session(path)
    session['cookies'] = {"c1": {'value': 'v1'}, "c2": {'value': 'v2'}, "c3": {'value': 'v3'}}
    session.remove_cookies(['c1','c3'])
    assert session['cookies'] == {"c2": {'value': 'v2'}}


# Generated at 2022-06-12 00:22:20.966214
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = [{"name":"testsession","value":"5b5d40a5-8d1a-4b45-9bdb-f718ff8c9a69"},
                {"name":"JSESSIONID","value":"6E341805D45C6B22E80551E8386E4B4B"},
                {"name":"__utmz","value":"26202481.1565565673.1.1.utmcsr=(direct)|utmccn=(direct)"}]
    session = Session("")
    session['cookies'] = cookies
    session.remove_cookies(["testsession"])

# Generated at 2022-06-12 00:22:34.473423
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass
    # session = Session('SESSION_FILE')
    # session.remove_cookies({'name1', 'name2', 'name3'})

# Generated at 2022-06-12 00:22:41.997072
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    c1 = {'name': 'c1', 'value': 'v1'}
    c2 = {'name': 'c2', 'value': 'v2'}
    c3 = {'name': 'c3', 'value': 'v3'}

    s = Session(path=None)
    for c in [c1, c2, c3]:
        s['cookies'][c['name']] = c['value']

    s.remove_cookies(['c1', 'c2'])

    assert s['cookies'] == {'c3': 'v3'}

# Generated at 2022-06-12 00:22:51.362247
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_session = Session('test_path')
    test_session['cookies'] = {
            "A": {'value': 'cookie_A'},
            "B": {'value': 'cookie_B'},
            "C": {'value': 'cookie_C'},
            "D": {'value': 'cookie_D'},
            "E": {'value': 'cookie_E'},
        }
    test_session.remove_cookies(['A', 'C', 'E'])
    assert test_session['cookies'] == {
            "B": {'value': 'cookie_B'},
            "D": {'value': 'cookie_D'},
        }

# Generated at 2022-06-12 00:22:57.315401
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test.json")
    session.cookies.set('test', 'test')
    session.cookies.set('test2', 'test2')
    assert len(session.cookies) == 2
    session.remove_cookies(['test'])
    assert len(session.cookies) == 1
    session.remove_cookies(['test2'])
    assert len(session.cookies) == 0

# Generated at 2022-06-12 00:22:59.957786
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('path')
    s['cookies'] = dict(name1='value1')
    s.remove_cookies(['name1'])
    assert s['cookies'] == {}

# Generated at 2022-06-12 00:23:09.243663
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test_ses")
    session['cookies'] = {"cookie1": {"value": "val1"},
                      "cookie2": {"value": "val2"}}
    session.remove_cookies(["cookie1"])
    assert session['cookies'] == {"cookie2": {"value": "val2"}}
    session.remove_cookies(["cookie1", "cookie3"])
    assert session['cookies'] == {"cookie2": {"value": "val2"}}
    session.remove_cookies(["cookie1", "cookie2"])
    assert session['cookies'] == {}
    session.remove_cookies(["cookie1", "cookie3"])
    assert session['cookies'] == {}



# Generated at 2022-06-12 00:23:14.332379
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path("/path/to/session.json"))
    session['cookies'] = {'b': {'value': 'value'}, 'a': {'value': 'value'}}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:23:17.762330
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    session = Session(Path())
    session['cookies'] = {'cookie1': None, 'cookie2': None}
    # Act
    session.remove_cookies(['cookie1', 'cookie2'])
    # assert
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:23:23.688689
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # prepare
    config_dir = Path('/etc')
    session_name = 'session_cookie_name'
    url ="http://foo/bar"
    self = get_httpie_session(config_dir,session_name,None,url)
    names = ['foo']
    self.remove_cookies(names)
    assert self['cookies'].get('foo',None) == None

# Generated at 2022-06-12 00:23:30.067021
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
	"""
	Checks if the method remove_cookies deletes cookies with the provided name. 
	"""
	session_dict = {'headers':{},'cookies':{},'auth':{'type':None,'username':None,'password':None}}
	session = Session(session_dict)
	session.remove_cookies(['set-cookie'])
	assert 'set-cookie' not in session['cookies'], 'Cookie has not been deleted'
	

# Generated at 2022-06-12 00:23:44.063580
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('hello.json')
    s['cookies'] = {'a': 1, 'b': 2}
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b': 2}



# Generated at 2022-06-12 00:23:47.657706
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='')
    session['cookies'] = {'a': 'a_value'}
    session.remove_cookies(names=['a','b','c'])
    assert 'a' not in session['cookies']

# Generated at 2022-06-12 00:23:52.609170
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'name1': 'value1', 'name2': 'value2', 'name3': 'value3'}
    sess = Session('test')
    sess['cookies'] = cookies
    assert sess['cookies'] == cookies
    sess.remove_cookies(['name1', 'name2'])
    assert sess['cookies'] == {'name3': 'value3'}

# Generated at 2022-06-12 00:24:03.625897
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'A': 'aaa', 'B': 'bbb'}
    session.remove_cookies(['A','C'])
    assert session['cookies'] == {'B': 'bbb'}
    session['cookies'] = {'A': 'aaa', 'B': 'bbb'}
    session.remove_cookies(['A', 'C', 'D'])
    assert session['cookies'] == {'B': 'bbb'}
    session['cookies'] = {'A': 'aaa', 'B': 'bbb', 'C': 'ccc'}
    session.remove_cookies(['B', 'C'])
    assert session['cookies'] == {'A': 'aaa'}
    session['cookies'] = {}
   

# Generated at 2022-06-12 00:24:06.517891
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_session.json')
    assert {'name': 'value'} == session['cookies']
    session.remove_cookies(['name', 'value'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:24:15.166537
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    assert session['cookies'] == {}
    jar = RequestsCookieJar()
    cookie = create_cookie('name', 'value')
    jar.set_cookie(cookie)
    session.cookies = jar
    assert session['cookies'] == {'name': {
        'value': 'value', 'path': '', 'secure': False, 'expires': None}}
    session.remove_cookies(['doesnotexist'])
    assert session['cookies'] == {'name': {
        'value': 'value', 'path': '', 'secure': False, 'expires': None}}
    session.remove_cookies(['name'])
    assert session['cookies'] == {}


# Generated at 2022-06-12 00:24:25.321955
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json
    test_cookie = {
        "cookies": {
            "bad_cookie": {
                "value": "bad",
                "path": "/",
                "secure": False,
                "expires": None
            },
            "good_cookie": {
                "value": "good",
                "path": "/",
                "secure": False,
                "expires": None
            }
        }
    }
    session_test = Session(json.dumps(test_cookie))
    session_test.remove_cookies(["bad_cookie"])
    assert "bad_cookie" not in session_test["cookies"]
    assert "good_cookie" in session_test["cookies"]

# Generated at 2022-06-12 00:24:32.146970
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./a.json')
    session['cookies']['cookies1'] = {'value': 'cookies1'}
    session['cookies']['cookies2'] = {'value': 'cookies2'}

    session.remove_cookies(['cookies2'])
    assert 'cookies1' == session['cookies']['cookies1']['value']
    assert not hasattr(session['cookies'], 'cookies2')
    session.save()

# Generated at 2022-06-12 00:24:38.767607
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {
        'foo': {'value': 'bar'},
        'baz': {'value': 'qux'}
    }
    session.remove_cookies(['foo'])
    assert session['cookies'] == {
        'baz': {'value': 'qux'}
    }

# Generated at 2022-06-12 00:24:43.535161
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie = {"cookie1": {"value":"cookie1"},
              "cookie2": {"value":"cookie2"},
              "cookie3": {"value":"cookie3"}}
    session = Session(path="/tmp/test_Session")
    session['cookies'] = cookie
    names = ['cookie1','cookie3']
    session.remove_cookies(names)
    assert session['cookies'] == {'cookie2': {'value': 'cookie2'}}
    session.remove_cookies(["cookie1"])
    assert session['cookies'] == {'cookie2': {'value': 'cookie2'}}


# Generated at 2022-06-12 00:25:08.901593
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    list_of_names = ['name1', 'name2']
    test = Session("")
    test['cookies']['name1'] = 'name1'
    test['cookies']['name2'] = 'name2'
    test['cookies']['name3'] = 'name3'
    test.remove_cookies(list_of_names)
    assert test['cookies']['name3'] == 'name3'



# Generated at 2022-06-12 00:25:13.432349
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_session = Session('save_session')
    test_session['cookies'] = {'a': {}, 'b': {}, 'c': {}}
    test_session.remove_cookies(['a', 'b'])
    assert test_session['cookies'] == {'c': {}}

# Generated at 2022-06-12 00:25:16.844267
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("test_session")
    s['cookies'] = {"test1":"cookie1", "test2":"cookie2"}
    s.remove_cookies(['test1'])
    assert s['cookies'] == {"test2":"cookie2"}



# Generated at 2022-06-12 00:25:23.632747
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.compat import urlparse
    from httpie.downloads import (
        parse_content_range, filename_from_content_disposition,
        filename_from_url
    )
    from httpie.context import Environment
    from httpie.models import Request, Response
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie import ExitStatus
    from httpie.output.streams import write_to_output
    from httpie.output.streams import get_binary_stream

    # Declare the instances of classes we may need
    env = Environment()
    headers = RequestHeadersDict()
    cookies = RequestsCookieJar()
    auth = None

# Generated at 2022-06-12 00:25:30.127112
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(os.path.expanduser('~/.config/httpie/test.session'))
    session.update_headers(RequestHeadersDict({'Cookie':
                                               'key1=value1; key2=; key3=value3'}))
    assert 'key1' in session['cookies']
    assert 'key2' in session['cookies']
    assert 'key3' in session['cookies']
    session.remove_cookies(['key2'])
    assert 'key1' in session['cookies']
    assert 'key2' not in session['cookies']
    assert 'key3' in session['cookies']

# Generated at 2022-06-12 00:25:38.537371
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    def mock_get_auth_plugin(type):
        return type
    plugin_manager.get_auth_plugin = mock_get_auth_plugin


    import json
    test_value = {'headers': {'User-Agent': 'test'}, 'cookies': {'a':None,
        'b':None}}
    test_session = Session('session.json')
    test_session.load()
    test_session['cookies'] = test_value['cookies']
    test_session.remove_cookies({'b'})
    del test_value['cookies']['b']
    assert json.dumps(test_session) == json.dumps(test_value)

# Generated at 2022-06-12 00:25:49.913613
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    #Arrange
    from httpie.cookies import CookieJar
    from httpie.compat import urlparse
    from httpie.models import Request
    from httpie.context import Environment
    from httpie.config import Config

    env = Environment(stdin=None, stdout=None, stderr=None,
                      vars={}, config=Config(DEFAULT_CONFIG_DIR))

    name_url_request = (("foo", "http://example.com", Request(method="GET", url="http://example.com/")),
                        ("bar", "http://example.com/test", Request(method="GET", url="http://example.com/test")),
                        ("baz", "http://example.com2", Request(method="GET", url="http://example.com2/")))


# Generated at 2022-06-12 00:25:55.770402
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Init Session
    session = Session("test_Session_remove_cookies")
    session['cookies'] = {'key1': {'value': 'value1'}, 'key2': {'value': 'value2'}}
    # Remove the cookies key1, key2 and key3
    session.remove_cookies(['key1', 'key2', 'key3'])
    # Check that the cookies key1, key2 and key3 have been deleted
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:26:02.361248
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Init class Session
    session = Session(path=Path())

    # Init dict for test
    dict_test = {}
    dict_test["cookies"] = {
        "cookie1": "hello",
        "cookie2": "world"
    }
    session.update(dict_test)

    # Init array for test
    array_test = ["cookie2", "cookie3"]

    # Remove cookies from session
    session.remove_cookies(array_test)

    # Check if removal is correct
    assert "cookie1" in session.get("cookies")
    assert "cookie2" not in session.get("cookies")
    assert "cookie3" not in session.get("cookies")

# Generated at 2022-06-12 00:26:09.872832
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("./test_session.json")
    session['cookies'] = {'name':'value'}
    session.remove_cookies(['name'])
    assert len(session['cookies']) == 0
    session['cookies'] = {'name':'value'}
    session.remove_cookies(['not-exist'])
    assert session['cookies'] == {'name':'value'}

# Generated at 2022-06-12 00:27:01.703211
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_jar = RequestsCookieJar()
    test_jar.set_cookie(create_cookie("cookie1", "value1"))
    test_jar.set_cookie(create_cookie("cookie2", "value2"))
    test_jar.set_cookie(create_cookie("cookie3", "value3"))

    test_session = Session("test-session.json")
    test_session.cookies = test_jar

    assert 3 == len(test_session["cookies"])
    test_session.remove_cookies(["cookie1", "cookie3"])
    assert 1 == len(test_session["cookies"])
    assert "cookie2" in test_session["cookies"]

    # test when removing cookies that are not in the session
    test_session.remove_cookies(["cookie1", "cookie3"])


# Generated at 2022-06-12 00:27:06.884626
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path(__file__))
    session['cookies'] = {'a': {'value': 'apple'}, 'b': {'value': 'banana'}}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': {'value': 'banana'}}

# Generated at 2022-06-12 00:27:10.480830
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path='path-to-session-file')
    s['cookies'] = {'a': 'b'}
    for name in ['a', 'c', 'd']:
        s.remove_cookies([name])
        assert name not in s['cookies']

# Generated at 2022-06-12 00:27:12.082996
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test")
    session.remove_cookies(['test', 'test'])

# Generated at 2022-06-12 00:27:15.327105
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session.update({
        'cookies': {
            'a': {'value': '1'},
            'b': {'value': '2'},
        },
    })
    session.remove_cookies(('a', 'c'))
    assert list(session['cookies'].keys()) == ['b']

# Generated at 2022-06-12 00:27:22.401682
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies']['one'] = '1'
    session['cookies']['two'] = '2'
    session['cookies']['three'] = '3'

    session.remove_cookies(['one', 'four', 'three'])

    assert len(session['cookies']) == 1
    assert list(session['cookies'].keys())[0] == 'two'
    assert session.cookies['two'] == '2'


# Generated at 2022-06-12 00:27:27.448163
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_session = Session(DEFAULT_SESSIONS_DIR / 'test_Session_remove_cookies.json')
    test_session['cookies'] = {'cookie0': {}, 'cookie1': {}, 'cookie2': {}, 'cookie3': {}}
    test_session.remove_cookies(['cookie0', 'cookie2'])
    assert test_session['cookies'] == {'cookie1': {}, 'cookie3': {}}

# Generated at 2022-06-12 00:27:32.343578
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    a_session = Session('/doesnt/matter')

    a_session['cookies'] = {'abc': 1, 'def': 2, 'ghi': 3, 'jkl': 4}
    a_session.remove_cookies(['def', 'ghi', 'mno'])
    assert a_session['cookies'] == {'abc': 1, 'jkl': 4}

# Generated at 2022-06-12 00:27:38.368322
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    session_path = '/tmp/httpie-sessions/httpie-sessions/example.com/test_session.json'
    test_session = Session(session_path)

    # Act
    test_session['cookies'] = { "name1": "value1", "name2": "value2" }
    test_session.remove_cookies(["name1"])

    # Assert
    assert test_session['cookies'] == { "name2": "value2" }

# Generated at 2022-06-12 00:27:47.385929
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session1 = Session('/Users/Daniel/.config/httpie/sessions/localhost/test.json')

    session1['cookies'] = {'name1': 'val1','name2':'val2','name3':'val3','name4':'val4','name5':'val5'}
    session1.remove_cookies(['name1','name2', 'name5'])

    assert sorted(session1['cookies']) == sorted(['name3','name4'])



# Generated at 2022-06-12 00:29:33.967844
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('testing.json')
    session.load()
    session['cookies'] = {'cookie1' : '1', 'cookie2' : '2', 'cookie3' : '3'}
    session.remove_cookies(['cookie1', 'cookie2'])
    assert session['cookies'] == {'cookie3' : '3'}


