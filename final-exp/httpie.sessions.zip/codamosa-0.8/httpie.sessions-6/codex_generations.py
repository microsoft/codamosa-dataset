

# Generated at 2022-06-12 00:19:57.055215
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from tempfile import TemporaryDirectory
    from httpie.config import Config
    from httpie.compat import os_path
    from pathlib import Path
    from httpie import cli

    with TemporaryDirectory() as tmpdir:
        config_dir = Path(tmpdir)
        config = Config(config_dir=config_dir)
        session_name = 'testSession'
        host = 'localhost'
        url = 'localhost'
        session = get_httpie_session(config_dir=config_dir, session_name=session_name, host=host, url=url)
        session.load()
        session_headers = session.headers
        # check if headers dict is empty
        assert not session_headers

        # check if updating of session headers works

# Generated at 2022-06-12 00:20:06.474335
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'HTTPie/0.9.9',
        'Cookie': 'foo=bar',
    }
    session = Session('path')
    session.update_headers(request_headers)
    assert session['headers'] == {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Cookie': 'foo=bar',
    }

# Generated at 2022-06-12 00:20:13.726717
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./test.json')

    request_headers_initial = {
        "cookie": "foo=bar; bar=baz",
        "if-Match": "foo",
        "Content-Type": "application/json",
        "USER-AGENT": "HTTPie/1.0.3"
    }

    session.update_headers(request_headers_initial)
    print(session['headers'])
    # request_headers_initial should be equal to session['headers']


test_Session_update_headers()

# Generated at 2022-06-12 00:20:20.780722
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/home/hung/.config/httpie/sessions/localhost/my_session.json')
    request_headers = {'header': 'value'}
    session.update_headers(request_headers)
    assert session.path == Path('/home/hung/.config/httpie/sessions/localhost/my_session.json')
    assert session.get('headers', None) == {'header': 'value'}

# Generated at 2022-06-12 00:20:30.338787
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_session = Session('test_session')
    assert test_session == Session('test_session')
    test_session.update_headers({})
    expected_session_after_null_headers = Session('test_session')
    expected_session_after_null_headers['headers'] = {}
    assert test_session == expected_session_after_null_headers
    test_session.update_headers({'one': '1'})
    expected_session_after_one_header = Session('test_session')
    expected_session_after_one_header['headers'] = {'one': '1'}
    assert test_session == expected_session_after_one_header
    test_session.update_headers({'two': '2'})
    expected_session_after_two_headers = Session('test_session')
    expected_session

# Generated at 2022-06-12 00:20:41.720706
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(os.path.expanduser('~/.httpie/sessions/localhost/test.json'))
    session.load()
    session.update_headers({'Cookie': 'test=test;test1=test1', 'A': 'test'})
    assert session.headers == {'A': 'test'}
    assert set(session.cookies.keys()) == {'test', 'test1'}

    session.update_headers({'Cookie': 'test2=test2', 'B': 'test'})
    assert session.headers == {'A': 'test', 'B': 'test'}
    assert set(session.cookies.keys()) == {'test', 'test1', 'test2'}


# Generated at 2022-06-12 00:20:48.171834
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    def get_headers(headers):
        return dict((key, [val for val in value]) for key, value in headers.items())

    sess = Session('/tmp/test.json')
    sess.update_headers({'user-agent': 'curl/7.64.0'})
    assert get_headers(sess.headers) == {'user-agent': ['curl/7.64.0']}

    sess.update_headers({'user-agent': 'curl/7.64.0', 'content-type': 'post',
                         'cookie': 'a=b; aa=bb'})

# Generated at 2022-06-12 00:20:54.708153
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.context import Environment
    env = Environment(config_dir=Path("/tmp"), color=False,
      style=None, default_options=None, vc_version_output=False,
      config_path=None, config_path_set_by_user=None)
    session = Session("/tmp/test_Session_update_headers")
    request_headers = RequestHeadersDict({"Content-Length": "0", "Accept": "*/*"})
    session.update_headers(request_headers)
    expected = {"headers": {"Accept": "*/*"}}
    assert session == expected

# Generated at 2022-06-12 00:20:57.639512
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {}
    session = Session(path="/test.json")
    session.update_headers(headers)
    assert session['headers'] == {}

# Generated at 2022-06-12 00:21:04.538704
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')
    session.update_headers({'a': '1', 'b': '2'})
    assert session.headers == {'a': '1', 'b': '2'}

    session.update_headers({'a': '3', 'b': None, 'c': '4'})
    assert session.headers == {'a': '3', 'c': '4'}

    session.update_headers({'Content-Type': 'foo/bar', 'Via': 'HTTPie/1.0'})
    assert session.headers == {'a': '3', 'c': '4', 'Content-Type': 'foo/bar'}

    session.update_headers({'Cookie': ['a=1', 'b=1']})
    # session.update_headers({'Cookie': cookie_string})

# Generated at 2022-06-12 00:21:13.432737
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path=Path('/tmp/'))
    s['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    s.remove_cookies(['a'])
    expect = {'b': {'value': '2'}}
    assert s['cookies'] == expect

# Generated at 2022-06-12 00:21:20.535379
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import pytest
    from httpie import ExitStatus
    from httpie.core import main
    from httpie.compat import is_windows
    from utils import http, HTTP_OK, COLOR, CRLF
    from utils import TestEnvironment, httpbin_secure
    from httpie.context import Environment
    env: Environment = TestEnvironment(colors=256)
    # ncookies = 3
    resp2 = http('--session=my-session', '--auth=username:password',
                 'GET', httpbin_secure + '/cookies/set?a=1&b=2&c=3',
                 env=env)
    print(resp2)
    assert HTTP_OK in resp2
    print(resp2.json)
    assert resp2.json['cookies']['a'] == "1"
    assert resp

# Generated at 2022-06-12 00:21:24.604027
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session['cookies'] = {'key1': 'value1', 'key2': 'value2'}
    session.remove_cookies(('key1','key2','key3'))
    assert session['cookies'] == {'key2': 'value2'}

# Generated at 2022-06-12 00:21:30.445506
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = Session("~/session.json")
    cookies["cookies"]["testcookie1"] = "value1"

    assert "cookies" in cookies
    assert "testcookie1" in cookies["cookies"]

    cookies.remove_cookies(["testcookie1"])

    assert "cookies" in cookies
    assert "testcookie1" not in cookies["cookies"]



# Generated at 2022-06-12 00:21:40.605104
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_object = Session('/path/to/session/file')
    session_object['headers']['Test-Header'] = 'Test-Header-Value'
    session_object['cookies']['Test-Cookie-Name'] = {'value': r'Test-Cookie-Value'}
    session_object['cookies']['Test-Cookie-Name1'] = {'value': r'Test-Cookie-Value1'}
    session_object['cookies']['Test-Cookie-Name2'] = {'value': r'Test-Cookie-Value2'}

    assert 'Test-Cookie-Name' in session_object['cookies']
    assert 'Test-Cookie-Name1' in session_object['cookies']

# Generated at 2022-06-12 00:21:44.872592
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='')
    session['cookies'] = {
        'foo': 'bar',
        'baz': 'quux'
    }
    session.remove_cookies(['foo', 'baz'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:21:50.311042
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = "test_Session_remove_cookies.json"
    session = Session(path)
    session['cookies'] = {'name': {'value': 'val'}}
    session.remove_cookies(['name'])
    assert 'cookies' in session
    assert not session['cookies']

# Generated at 2022-06-12 00:21:55.536150
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    auth_plugin = plugin_manager.get_auth_plugin('basic')()
    s = Session('path')
    s['cookies'] = {'c1': {'value': 1}, 'c2': {'value': 2}}
    s.remove_cookies(['c1'])
    assert s['cookies'] == {'c2': {'value': 2}}



# Generated at 2022-06-12 00:21:56.534676
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert 1==1

# Generated at 2022-06-12 00:22:07.093502
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(None)
    s.cookies = RequestsCookieJar()
    s.cookies.set('foo', 'foo', domain='httpie.org', path='/bar')
    s.cookies.set('bar', 'bar', domain='httpie.org', path='/bar')
    s.cookies.set('baz', 'baz', domain='httpie.org', path='/baz')

    s.remove_cookies(['foo'])
    assert s.cookies.get_dict() == {'bar': 'bar', 'baz': 'baz'}

    s.remove_cookies(['baz'])
    assert s.cookies.get_dict() == {'bar': 'bar'}

# Generated at 2022-06-12 00:22:13.554434
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    session = Session('.')
    session['cookies'] = {'foo': 'bar', 'baz': 'qux'}
    names = ['foo', 'bar']
    session.remove_cookies(names)
    assert 'foo' not in session['cookies']
    assert 'baz' in session['cookies']
    assert 'bar' not in session['cookies']

# Unit tests for method update_headers of class Session

# Generated at 2022-06-12 00:22:17.586201
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(".")
    session.load()
    session['cookies'] = {"foo":"bar"}
    if "foo" in session['cookies'].keys():
        session.remove_cookies(["foo"])
        assert "foo" not in session['cookies'].keys()
    else:
        assert False

# Generated at 2022-06-12 00:22:23.888495
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'foo': {'value': 'bar'}, 'baz': {'value': 'qux'}}
    names = ['foo', 'quux']
    expected_cookies = {'baz': {'value': 'qux'}}

    session = Session(path='foo/bar')
    session['cookies'] = cookies
    session.remove_cookies(names)

    assert session['cookies'] == expected_cookies


# Generated at 2022-06-12 00:22:31.595937
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    This method tests the functionality of remove cookies from
    session if the cookies exists.

    Returns:
        Returns True if test passed.
        Returns False if test failed.
    """

    session1 = Session("cookie1")
    session1['cookies']['cookiename1'] = {'value': 'value1'}
    session1['cookies']['cookiename2'] = {'value': 'value2'}
    session1['cookies']['cookiename3'] = {'value': 'value3'}
    session1['cookies']['cookiename4'] = {'value': 'value4'}

    session1.remove_cookies(['cookiename1', 'cookiename3'])

# Generated at 2022-06-12 00:22:37.608436
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('.')
    session.update({'cookies': {'i1': 1, 'i2': 2, 'i3': 3}})
    session.remove_cookies(['i1'])
    assert not session['cookies'] == {}



# Generated at 2022-06-12 00:22:41.633792
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.input import ParseResult
    from httpie.plugins.builtin import HTTPBasicAuth
    # create a session for testing
    httpie_session = Session(path=Path('test_session.json'))
    httpie_session.update_headers(ParseResult([]).headers)
    httpie_session.auth = HTTPBasicAuth().get_auth('user', 'pass')
    httpie_session['cookies'] = {'cook': {'expires': None,
                                          'path': '/', 'secure': False,
                                          'value': 'chocolate'}}
    httpie_session['cookies']['cook1'] = {'expires': None,
                                          'path': '/', 'secure': False,
                                          'value': 'chocolate'}

# Generated at 2022-06-12 00:22:45.548905
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("123")
    session['cookies'] = {"name1": "value1", "name2": "value2"}
    names = ["name2"]
    session.remove_cookies(names)
    assert session['cookies'] == {"name1": "value1"}

# Generated at 2022-06-12 00:22:51.870665
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("path")
    session['cookies'] = { 'name1' : {'value': 'val1'}, 'name2' : {'value': 'val2'}, 'name3' : {'value': 'val3'}}
    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'] == {'name2' : {'value': 'val2'}}

# Generated at 2022-06-12 00:23:00.508545
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json

    s = Session('test.json')
    s['cookies'] = {'test': {'value': 'ok', 'path': '/'}}
    s.remove_cookies(['test'])
    assert 'test' not in s['cookies']

    # Test if cookies in session persists after calling remove_cookies
    s['cookies'] = {'test': {'value': 'ok', 'path': '/'}}
    s.save()
    s = Session('test.json')
    assert json.loads(s.save())['cookies'] == {'test': {'value': 'ok', 'path': '/'}}
    os.remove('test.json')

# Generated at 2022-06-12 00:23:09.219313
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path('.'))
    session['cookies'] = {
        'A': {'value': '1', 'path': '/'},
        'B': {'value': '2', 'path': '/'},
        'C': {'value': '3', 'path': '/'}
    }
    session.remove_cookies(['A', 'C'])
    assert session['cookies'] == {
        'B': {'value': '2', 'path': '/'}
    }
    session.remove_cookies(['D'])
    assert session['cookies'] == {
        'B': {'value': '2', 'path': '/'}
    }

# Generated at 2022-06-12 00:23:24.742549
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('test.json'))
    cookies = {
        'expired': {'value': 'a', 'expires': 'Thu, 01 Jan 1970 00:00:00 GMT'},
        'present': {'value': 'b'},
        'present2': {'value': 'c'}
    }
    session['cookies'] = cookies
    session.remove_cookies(['expired', 'removed'])
    assert session['cookies'] == {'present': {'value': 'b'}, 'present2': {'value': 'c'}}

# Generated at 2022-06-12 00:23:31.631584
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    delete_cookie = "delete_cookie"
    session = Session("path/session_file")
    session["cookies"] = {"cookie_key_1": "value_1", delete_cookie: "value_2"}
    #remove cookie from session
    session.remove_cookies([delete_cookie])
    assert not delete_cookie in session["cookies"]
    assert session["cookies"] == {"cookie_key_1": "value_1"}
    #nothing to remove
    session.remove_cookies([delete_cookie])
    assert session["cookies"] == {"cookie_key_1": "value_1"}


# Generated at 2022-06-12 00:23:38.448281
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('tmp.cfg') # Fake session file
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}, 'name3': {'value': 'value3'}}
    session.remove_cookies(['name2', 'name4'])
    assert session['cookies'] == {'name1': {'value': 'value1'}, 'name3': {'value': 'value3'}}

# Generated at 2022-06-12 00:23:45.761517
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("./tests/fixtures/sessions/session.foobar")
    load_session(session, './tests/fixtures/sessions/session.foobar.json')
    assert 'foo' in session['cookies']
    assert 'bar' in session['cookies']
    session.remove_cookies(['foo'])
    assert 'foo' not in session['cookies']
    assert 'bar' in session['cookies']


# Generated at 2022-06-12 00:23:50.861714
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s.update({'cookies': {'name1':{'value':'val1'}, 'name2':{'value':'val2'}}})
    s.remove_cookies(['name1'])
    assert s.get('cookies') == {'name2':{'value':'val2'}}



# Generated at 2022-06-12 00:23:55.024625
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session.cookies = session.cookies.set('a', 'b')
    session.cookies = session.cookies.set('c', 'd')
    session.cookies = session.cookies.set('e', 'f')
    session.remove_cookies(['a', 'c'])
    assert len(session.cookies) == 1
    assert 'e' in session.cookies

# Generated at 2022-06-12 00:24:01.557885
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('session')
    sess.update({'cookies': {'name1': 'value1', 'name2': 'value2'}})
    assert 'name1' in sess['cookies']
    sess.remove_cookies(['name2', 'name3'])
    assert 'name1' in sess['cookies']
    assert 'name2' not in sess['cookies']
    sess.save()

# Generated at 2022-06-12 00:24:05.038359
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie = {"name": "value"}
    c = Session('/etc/fake.json')
    c.cookies = cookie
    assert c['cookies'] != {}
    c.remove_cookies(c['cookies'])
    assert c['cookies'] == {}


# Generated at 2022-06-12 00:24:11.360885
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path_to_config')
    session['cookies'] = {'cookie1': 'val', 'cookie2': 'val1'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 'val1'}
    session = Session('path_to_config')
    session['cookies'] = {'cookie1': 'val', 'cookie2': 'val1'}
    session.remove_cookies(['cookie1', 'cookie2'])
    assert session['cookies'] == {}
    session = Session('path_to_config')
    session['cookies'] = {'cookie1': 'val', 'cookie2': 'val1'}
    session.remove_cookies([])

# Generated at 2022-06-12 00:24:16.186904
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/Users/dewangga/Travail/httpie/httpie')
    session['cookies'] = {
        'name1': 'value1',
        'name2': 'value2'
    }
    assert session['cookies']['name1'] == 'value1'
    assert session['cookies']['name2'] == 'value2'

    session.remove_cookies(['name1'])

    assert 'name1' not in session['cookies']
    assert session['cookies']['name2'] == 'value2'

# Generated at 2022-06-12 00:24:40.525875
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    session = Session("/tmp/test_session.json")
    session['cookies'] = {'name': 'value', 'name2': 'value2'}
    session.remove_cookies(['name','name2','name3'])
    assert session['cookies'] == {}

    session = Session("/tmp/test_session.json")
    session['cookies'] = {'name': 'value', 'name2': 'value2'}
    session.remove_cookies(['name2'])
    assert session['cookies'] == {'name': 'value'}

# Generated at 2022-06-12 00:24:49.712544
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/home/')
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie('foo', 'foobar'))
    session.cookies.set_cookie(create_cookie('bar', 'barfoo'))
    assert 'foo' in session.cookies
    assert 'bar' in session.cookies
    session.remove_cookies(['foo'])
    assert 'foo' not in session.cookies
    assert 'bar' in session.cookies
    session.remove_cookies(['bar'])
    assert 'bar' not in session.cookies



# Generated at 2022-06-12 00:24:54.217440
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('dummy_path')
    session['cookies'] = {'foo': 'bar', 'plop': 'plip'}
    session.remove_cookies(['plop'])
    assert session['cookies'] == {'foo': 'bar'}

# Generated at 2022-06-12 00:24:58.537860
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path = 'path')
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie('name', 'value'))
    session.cookies.set_cookie(create_cookie('other_name', 'other_value'))
    session.remove_cookies(['name'])
    assert session.cookies.get('name') is None
    assert session.cookies.get('other_name') is not None

# Generated at 2022-06-12 00:25:04.269834
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('~/.httpie/sessions/example.org/foo.json')
    session.cookies = RequestsCookieJar()
    session.cookies.set('foo', 'bar')
    assert 'foo' in session['cookies']
    session.remove_cookies(['foo'])
    assert 'foo' not in session['cookies']



# Generated at 2022-06-12 00:25:08.177306
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(SESSIONS_DIR_NAME + '/test')
    session['cookies']['cookie_name'] = {'value': 'cookie_value'}
    new_cookies_map = session.remove_cookies(['cookie_name'])
    assert new_cookies_map == {}

# Generated at 2022-06-12 00:25:11.064219
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    d = Session(path=Path(""))
    d["cookies"] = {"d": "d"}
    d.remove_cookies(["d"])
    assert d["cookies"] == {}

# Generated at 2022-06-12 00:25:19.392607
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = '/tmp/test_httpie_session.json'
    assert(os.path.exists(session_path) is False)
    os.makedirs(os.path.dirname(session_path), exist_ok=True)
    session = Session(session_path)
    session['cookies'] = {'c1': {'value': '1'}, 'c2': {'value': '2'}}
    session.remove_cookies(['c1', 'c2'])
    assert (session['cookies'] == {})
    os.unlink(session_path)
    os.rmdir(os.path.dirname(session_path))


# Generated at 2022-06-12 00:25:19.907163
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert(True)

# Generated at 2022-06-12 00:25:29.525637
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('testing')
    session.cookies = RequestsCookieJar()
    session.cookies.set('cookie1', 'value1')
    session.cookies.set('cookie2', 'value2')
    session.cookies.set('cookie3', 'value3')
    session.cookies.set('cookie4', 'value4')
    assert len(session.cookies) == 4
    assert 'cookie1' in session.cookies
    assert 'cookie2' in session.cookies
    assert 'cookie3' in session.cookies
    assert 'cookie4' in session.cookies
    session.remove_cookies(['cookie1', 'cookie3'])
    assert 'cookie2' in session.cookies
    assert 'cookie4' in session.cookies
    assert 'cookie1' not in session.cookies

# Generated at 2022-06-12 00:26:13.669402
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(Path("/tmp"))
    assert {'cookies':{}} == s.__dict__
    s['cookies']['test'] = 1
    s.remove_cookies(['test'])
    assert {'cookies':{}} == s.__dict__
    s['cookies']['test2'] = 1
    s['cookies']['test3'] = 1
    s['cookies']['test4'] = 1
    s.remove_cookies(['test2','test4'])
    assert {'cookies':{'test3':1}} == s.__dict__



# Generated at 2022-06-12 00:26:17.876427
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {
        'session' : {'value': '123456'},
        'logout' : {'value': 'qwerty'},
    }
    session.remove_cookies(['session', 'logout'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:26:21.250352
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./tests/sessions/bjxing.com.json')
    session.load()

    session.remove_cookies(['SID'])

    assert 'SID' not in session['cookies']
    assert 'SID' not in session.cookies

# Generated at 2022-06-12 00:26:29.550491
# Unit test for method remove_cookies of class Session

# Generated at 2022-06-12 00:26:34.221033
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    headers = {'Set-Cookie': 'foo=bar; path=/'}
    assert Session.extract_cookies(headers)['foo'] == 'bar'
    Session.remove_cookies(headers, ['foo'])
    assert 'foo' not in Session.extract_cookies(headers)



# Generated at 2022-06-12 00:26:41.145740
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    my_session = Session('foo')
    my_session['cookies'] = {'foo': {'value': 'BAR'},
                             'bar': {'value': 'FOO'},
                             'baz': {'value': 'BAZ'}}
    my_session.remove_cookies(['bar', 'baz'])
    assert(my_session['cookies'] == {'foo': {'value': 'BAR'}})

# Generated at 2022-06-12 00:26:44.789889
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/test_Session_remove_cookies')
    s['cookies'] = {'a': 'b'}
    s.remove_cookies(names=['a'])
    assert 'a' not in s['cookies']

# Generated at 2022-06-12 00:26:51.308141
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    mysession = Session("TestSession")
    print(mysession['cookies'])
    cookie_name = 'TestName'
    mysession['cookies'][cookie_name] = {
                'value': 'TestValue',
                'path': 'TestPath',
                'secure': True,
                'expires': '201190723'
    }
    mysession.remove_cookies([cookie_name])
    assert cookie_name not in mysession['cookies']

# Generated at 2022-06-12 00:26:55.663711
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    Session_instance = Session('session_test.json')
    Session_instance['cookies'] = {'cookie_name': {'value': 'cookie_value'}}
    assert 'cookie_name' in Session_instance['cookies']
    Session_instance.remove_cookies(['cookie_name'])
    assert 'cookie_name' not in Session_instance['cookies']

# Generated at 2022-06-12 00:27:01.925483
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(DEFAULT_SESSIONS_DIR / 'testfile.json')
    session.update_headers({'Cookie': 'name1=value1; name2=value2'})
    session.remove_cookies(('name1', 'name3'))
    assert len(session['cookies']) == 1 and 'name1' not in session['cookies']

# Generated at 2022-06-12 00:28:34.557400
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('http://localhost/')
    session['cookies'] = {'foo': 1, 'bar': 2}
    session.remove_cookies(['baz', 'bar'])
    assert session['cookies'] == {'foo': 1}

    session['cookies'] = {'foo': 1, 'bar': 2}
    session.remove_cookies(['bar'])
    assert session['cookies'] == {'foo': 1}

# Generated at 2022-06-12 00:28:37.639468
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session.json')
    session['cookies'] = {
        'name1': {'value': 'value1'},
        'name2': {'value': 'value2'},
        'name3': {'value': 'value3'}
    }
    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}



# Generated at 2022-06-12 00:28:41.703042
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/path/to/session')
    session['cookies'] = {
        'foo': {'value': '1'},
        'bar': {'value': '2'}
    }
    session.remove_cookies(['foo'])
    assert session['cookies'] == {'bar': {'value': '2'}}

# Generated at 2022-06-12 00:28:45.500850
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('foo.json')
    session['cookies'] = {'foo': '1'}
    assert 'foo' in session['cookies']
    session.remove_cookies(['foo'])
    assert 'foo' not in session['cookies']

# Generated at 2022-06-12 00:28:49.965246
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {
        'name1': {'value': 'value1'},
        'name2': {'value': 'value2'}
    }
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}



# Generated at 2022-06-12 00:28:55.519885
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cwd = os.getcwd()
    os.chdir(os.path.abspath(os.path.join(os.getcwd(), "..")))
    s = Session('config/sessions/facebook.json')
    s.load()
    s.remove_cookies(['c_user', 'csm', 'datr', 'xs'])
    s.save()
    os.chdir(cwd)


# Generated at 2022-06-12 00:29:00.326549
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/home/jma/httpie/data/sessions/google/google.json')
    session.load()
    names = ["1P_JAR", "NID", "CONSENT"]
    session.remove_cookies(names)
    session.save()
    import json
    print(json.dumps(session))

if __name__ == "__main__":
    test_Session_remove_cookies()

# Generated at 2022-06-12 00:29:06.172293
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session')
    session['cookies'] = {"name1": "value1", "name2": "value2"}

    names = ["name1"]
    session.remove_cookies(names)

    assert {"name1": "value1", "name2": "value2"} == session['cookies']

    session.remove_cookies(["name2"])
    assert {} == session['cookies']

    session.remove_cookies(["name3"])
    assert {} == session['cookies']

# Generated at 2022-06-12 00:29:15.129700
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from copy import copy
    from unittest.mock import MagicMock
    from requests.cookies import RequestsCookieJar
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.plugins import plugin_manager

    plugin_manager.refresh()

    session = Session(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'test_session.json')
    session['cookies'] = {'cookie1': {'value': 1, 'domain': 'domain1', 'path': 'path1'}}
    session['cookies']['cookie2'] = copy(session['cookies']['cookie1'])
    session['cookies']['cookie2']['domain'] = 'domain2'

# Generated at 2022-06-12 00:29:18.644144
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session()
    session['cookies'] = {"cookieName": "value"}
    session.remove_cookies(["cookieName", "cookieName2"])
    # Deleting cookieName
    if session['cookies'] != {}:
        raise Exception("Failed to delete the cookie")
