

# Generated at 2022-06-12 00:19:47.597058
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("./tmp_file")
    s['cookies'] = {'a': {'value':1}, 'b': {'value': 2}}
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b': {'value': 2}}

# Generated at 2022-06-12 00:19:56.802961
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='test.json')
    session.update_headers(RequestHeadersDict([
        ('Test-Header', 'test value'),
        ('Content-Type', 'text/html'),
        ('If-Modified-Since', '123')
    ]))
    assert session['headers'] == {
        'Test-Header': 'test value'
    }
    assert session['cookies'] == {}

    session.update_headers(RequestHeadersDict([
        ('Test-Header', 'test value'),
        ('Cookie', 'cookie1=value1; cookie2=value2;')
    ]))
    assert session['headers'] == {}
    assert session['cookies'] == {
        'cookie1': {'value': 'value1'},
        'cookie2': {'value': 'value2'}
    }

# Generated at 2022-06-12 00:20:09.235929
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import json

    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.compat import is_windows

    config_dir = (
        DEFAULT_CONFIG_DIR
        if is_windows
        else DEFAULT_CONFIG_DIR.expanduser()
    )
    session = get_httpie_session(config_dir, 'test', None, 'https://www.example.org/')

    # TODO: Test cookies
    # TODO: Test User-Agent
    # TODO: Test auth

    # Test Content-Type

    # Method update_headers of class Session should not change the value
    # of the Content-Type header when it is set explicitely.
    request_headers = RequestHeadersDict({
        'Content-Type': 'application/json',
    })

# Generated at 2022-06-12 00:20:21.793316
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.compat import str
    from httpie.config import BaseConfigDict
    from httpie.session import Session
    import json
    import random
    import string
    import tempfile

    session = Session(path=tempfile.mktemp())

    cookies_dict_to_create = {}
    cookies_list = []
    cookie_name_to_remove = None

    for i in range(0, 5):
        cookie_name = ''.join(random.sample(string.ascii_letters, 5))
        cookie_value = ''.join(random.sample(string.ascii_letters, 5))
        cookies_list.append(cookie_name)

# Generated at 2022-06-12 00:20:22.691748
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/test/test.json')
    session.update_headers({'content-type': 'test'})


# Generated at 2022-06-12 00:20:31.665398
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    import httpie.session
    from httpie.context import Environment
    session = Session(Path('/home/pierre/.httpie/sessions/foo.json'))
    session.update_headers(RequestHeadersDict({'User-Agent': 'pierre'}))
    session.update_headers(RequestHeadersDict({'User-Agent': 'pierre'}))
    session['headers']['User-Agent'] = 'pierre'
    session['headers']['User-Agent']
    session_name = "foo"
    host = 'hobbes.ens.fr'
    url = 'http://hobbes.ens.fr'
    path = Path('foo.json')
    session = httpie.session.Session(path)

# Generated at 2022-06-12 00:20:41.247510
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.sessions import Session

    path = './session.json'
    session = Session(path)

    request_headers = RequestHeadersDict({
        'Content-Type': 'application/json',
        'Content-Length': '0',
        'If-Modified-Since': 'Fri, 22 Jul 2016 17:04:11 GMT'
    })
    session.update_headers(request_headers)
    assert('Content-Type' in session.headers) is True
    assert('Content-Length' in session.headers) is False
    assert('If-Modified-Since' in session.headers) is False


# Generated at 2022-06-12 00:20:49.102553
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # set up
    session = Session('/home/xxx/xxx/session.json')
    request_headers = RequestHeadersDict()
    request_headers['Cookie'] = 'xxxx'
    request_headers['If-Modified-Since'] = 'xxxx'
    # test
    session.update_headers(request_headers)
    #check
    assert request_headers['Cookie'] is None
    assert request_headers['If-Modified-Since'] is None

# Generated at 2022-06-12 00:20:56.352645
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(".")
    headers0 = {
        ':authority': 'www.baidu.com',
        ':method': 'GET',
        ':path': '/',
        ':scheme': 'http',
    }
    s.update_headers(headers0)

    assert s['headers'] == {
        ':authority': 'www.baidu.com',
        ':method': 'GET',
        ':path': '/',
        ':scheme': 'http',
    }


# Generated at 2022-06-12 00:21:04.008532
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    request_headers = {
        'Content-Type': 'application/json',
        'Content-Length': '52',
        'Host': 'localhost',
        'Json-Key': 'Json-Value',
        'User-Agent': 'httpie/0.9.8',
        'If-Match': 'something',
        'If-None-Match': 'something else',
    }

    session.update_headers(request_headers)

    for header in request_headers.keys():
        if header.startswith('Content-') or \
                header.startswith('If-') or \
                header == 'User-Agent':

            assert header not in session.headers
        elif header == 'Cookie':
            assert 'Cookie' not in session.headers


# Generated at 2022-06-12 00:21:12.402599
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'test': {'test': "test"}}
    session.remove_cookies(['test'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:21:18.481892
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    p = "~/.config/httpie/sessions/httpbin_org"
    session = Session(p)
    session['cookies'] = {
        "fake-session": dict(value="fake-value", expires=12345)
    }
    assert "fake-session" in session['cookies']
    assert "fake-session" in session.cookies.keys()

    session.remove_cookies(['fake-session'])
    assert "fake-session" not in session['cookies']
    assert "fake-session" not in session.cookies.keys()

# Generated at 2022-06-12 00:21:23.788400
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    s.setdefault('cookies', dict(k1='v1', k2='v2'))
    s.remove_cookies(['k1'])
    assert 'k1' not in s['cookies']
    assert 'k2' in s['cookies']
    s.remove_cookies(['k2'])
    assert 'k2' not in s['cookies']



# Generated at 2022-06-12 00:21:34.769397
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict({'Accept': None, 'Content-Type': 'application/json', 'Cookie': 'key1=val1; key2=val2', 'If-Modified-Since': 'Sat, 29 Oct 1994 19:43:31 GMT'})
    session_headers = RequestHeadersDict({'Accept': None, 'Content-Type': 'application/json', 'Cookie': 'key1=val1; key2=val2', 'If-Modified-Since': 'Sat, 29 Oct 1994 19:43:31 GMT'})
    my_session = Session('session.json')
    my_session.update_headers(request_headers)
    assert my_session['headers'] == session_headers

# Generated at 2022-06-12 00:21:42.155848
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    session.update_headers({
        'Content-Type': 'application/json',
        'X-Foo': 'bar',
        'Cookie': 'foo=bar; spam=eggs',
        'User-Agent': 'httpie/0.9.9'
    })

    assert session == {
        'headers': {'X-Foo': 'bar'},
        'cookies': {'foo': {'value': 'bar'}, 'spam': {'value': 'eggs'}},
        'auth': {
            'type': None,
            'username': None,
            'password': None
        }
    }

# Generated at 2022-06-12 00:21:51.929453
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path = Path(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME))
    session['cookies'] = {'cookie1': {'value': 'value1', 'path': '/'}, 'cookie2': {'value': 'value2', 'path': '/'}, 'cookie3': {'value': 'value3', 'path': '/'} }
    session.remove_cookies(['cookie3', 'cookie4'])
    assert 'cookie3' not in session['cookies']
    assert 'cookie4' not in session['cookies']
    assert 'cookie1' in session['cookies']
    assert 'cookie2' in session['cookies']

# Generated at 2022-06-12 00:21:58.971283
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import ExitStatus
    from httpie.context import Environment

    env = Environment(stdin=None, stdout=None, stderr=None, vars={})

    args = (
        "--session=abc",
        "https://httpbin.org/headers",
        "X-Session-Header:Session-Header-Value",
        "If-Modified-Since:Fri, 05 Apr 2019",
        "Content-Length:5",
        "Content-Type:text/plain; charset=utf-8",
        "User-Agent:HTTPie/1.0.2"
    )
    exit_status = env.start(args=args)
    assert exit_status == ExitStatus.OK


# Generated at 2022-06-12 00:22:04.627502
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session['cookies'] = {
        'test1': {'value': 'test1'},
        'test2': {'value': 'test2'},
        'test3': {'value': 'test3'}
    }

    session.remove_cookies(['test2'])
    assert 'test2' not in session['cookies']

# Generated at 2022-06-12 00:22:13.860305
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # explicit unset header won't be stored
    # WIP: user agent containing HTTPie will be ignored
    # WIP: cookie will be stored
    base_session = Session('')
    for prefix in SESSION_IGNORED_HEADER_PREFIXES:
        base_session.update_headers({prefix:None})
    assert len(base_session['headers']) == 0
    base_session.update_headers({'x-header':None})
    assert len(base_session['headers']) == 1
    base_session.update_headers({'x-header':'value'})
    assert len(base_session['headers']) == 1
    base_session.update_headers({'x-header':'new-value'})
    assert len(base_session['headers']) == 1
    base_session.update_headers

# Generated at 2022-06-12 00:22:21.601002
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('./test')
    assert s['cookies']=={}
    s.cookies = RequestsCookieJar()
    s.cookies.set('c1', 'v1')
    s.cookies.set('c2', 'v2')
    s.cookies.set('c3', 'v3')
    s.cookies.set('c4', 'v4')
    s.cookies.set('c5', 'v5')

# Generated at 2022-06-12 00:22:31.536967
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import pytest

    session = Session('test_Session_update_headers')
    session.update_headers({
        "Cookie" : "test_Session_update_headers",
        "User-Agent" : "HTTPie/test_Session_update_headers",
        "Content-Type" : "test_Session_update_headers",
        "If-Match" : "test_Session_update_headers",
        "Accept" : "test_Session_update_headers",
    })
    assert session.headers == {
        "Accept" : "test_Session_update_headers"
    }
    assert session['cookies'] == {"test_Session_update_headers" : {"value" : "test_Session_update_headers"}}

# Generated at 2022-06-12 00:22:42.812553
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    def get_expected_result(cookies, remove_cookies):
        expected_result = cookies
        if remove_cookies:
            for remove_cookie in remove_cookies:
                if remove_cookie in expected_result:
                    del expected_result[remove_cookie]
        return expected_result


# Generated at 2022-06-12 00:22:49.907855
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('')
    sess.cookies = RequestsCookieJar()
    sess.cookies.set_cookie(create_cookie('cookie1', 'value1'))
    sess.cookies.set_cookie(create_cookie('cookie2', 'value2'))
    sess.remove_cookies(['cookie1'])
    assert 'cookie1' not in sess.cookies
    assert 'cookie2' in sess.cookies

# Generated at 2022-06-12 00:22:56.967020
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict()
    request_headers['Content-Type'] = 'application/json'
    request_headers['Content-Length'] = 14
    request_headers['If-Match'] = "xyx"
    request_headers['Accept'] = 'application/json'
    print(request_headers)

    session = Session("abc")
    session.update_headers(request_headers)
    print(session['headers'])
#test_Session_update_headers()


# Generated at 2022-06-12 00:23:01.532949
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/sessions/localhost')
    session.update({"cookies": {"cookie1": "value1", "cookie2": "value2", "cookie3": "value3"}})
    names = ["cookie1", "cookie3"]
    session.remove_cookies(names)
    assert session['cookies'] == {'cookie2': 'value2'}


# Generated at 2022-06-12 00:23:08.154311
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s['cookies'] = {}
    test = {
        'first': {'value': 'one'},
        'second': {'value': 'two'},
        'third': {'value': 'three'},
    }
    s['cookies'] = test
    s.remove_cookies(['second', 'third'])
    assert s['cookies'] == {'first': {'value': 'one'}}

# Generated at 2022-06-12 00:23:16.251226
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(DEFAULT_SESSIONS_DIR)
    session.update_headers(RequestHeadersDict({'User-Agent': 'test'}))
    session.update_headers(RequestHeadersDict({'Cookie': 'a=b;c=d'}))
    assert session.headers == RequestHeadersDict({
            'User-Agent': 'test',
            'Cookie': 'a=b;c=d',
        })
    assert session.cookies == RequestsCookieJar()


# Generated at 2022-06-12 00:23:21.547127
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    session = Session('tmp/session')
    request_headers = RequestHeadersDict({'foo': '1', 'bar': 3})
    session.update_headers(request_headers)
    assert session == {'headers': {'foo': '1', 'bar': '3'}, 'cookies': {}}

# Generated at 2022-06-12 00:23:25.067591
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('sess')
    sess['cookies'] = {'1': 1, '2': 2}
    sess.remove_cookies(['2'])
    assert sess['cookies'] == {'1': 1}

# Generated at 2022-06-12 00:23:32.990716
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test")
    session['headers'] = {"test":"test"}
    # test if it doesn't modify when input equals to the content
    session.update_headers({"test":"test"})
    assert session['headers'] == {"test":"test"}

    session.update_headers({"test1":"test1"})
    assert session['headers'] == {"test":"test","test1":"test1"}

    session.update_headers({"content-length":"1"})
    assert session['headers'] == {"test":"test","test1":"test1"}

    session.update_headers({"test1":"test1.1"})
    assert session['headers'] == {"test":"test","test1":"test1.1"}

    # test if it can handle None as header value
    session.update_headers({"test":None})
    assert session

# Generated at 2022-06-12 00:23:47.783544
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import httpie.compat
    s = Session(path="")
    s.update_headers({"a": "b"})
    # Add a header
    s.update_headers({"a": "c"})
    s.update_headers({"a": "c"})
    assert s['headers']['a'] == 'c'
    # Unset a header
    s.update_headers({"a": None})
    assert s['headers']['a'] == 'c'
    # Add a header
    s.update_headers({"a": None})
    assert s['headers']['a'] == 'c'
    # Unset a header
    s.update_headers({"a": ""})
    assert 'a' not in s['headers']
    # Add a header

# Generated at 2022-06-12 00:23:53.553085
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('my-session.json')
    session['cookies'] = {'name': {'value': 'value'}, 'name2': {'value': 'value2'}}
    names = ['name', 'name3']
    session.remove_cookies(names)
    new_session = Session('my-session.json')
    new_session.load()
    assert new_session == {'cookies': {'name2': {'value': 'value2'}}}


# Generated at 2022-06-12 00:24:00.168261
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from unittest.mock import patch
    from requests.cookies import RequestsCookieJar
    from httpie.plugins.registry import plugin_manager

    s = Session(path='./mock')
    s['cookies'] = {
        'name': 'value',
    }

    s.remove_cookies(['name'])
    assert (s['cookies'] == {})


# Generated at 2022-06-12 00:24:04.426419
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('~/.config/httpie/sessions/github.com/test.json')
    session['cookies'] = {'cookie1': 'value', 'cookie2': 'value'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 'value'}

# Generated at 2022-06-12 00:24:06.592599
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session.cookies = [{'name':'changed'}]
    session.remove_cookies(['changed'])
    assert session.cookies == []

# Generated at 2022-06-12 00:24:11.553534
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/httpie_sessions/example.com/foo.json')
    session['cookies'] = {'foo': 'bar', 'baz': 'quux'}
    session.remove_cookies(('baz',))
    assert session['cookies'] == {'foo': 'bar'}

# Generated at 2022-06-12 00:24:16.453450
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_dict = {'cookies': {'sessionID': {'value': '123'}, 'name': {'value': '123'}}}
    s = Session('')
    s.update(session_dict)
    assert 'sessionID' in s['cookies']
    assert 'name' in s['cookies']
    s.remove_cookies(['name'])
    assert 'sessionID' in s['cookies']
    assert 'name' not in s['cookies']

# Generated at 2022-06-12 00:24:24.823151
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'a': {'value': 'qux'}, 'b': {'value': 'quux'}}
    assert session['cookies']['a']['value'] is 'qux'
    assert session['cookies']['b']['value'] is 'quux'
    session.remove_cookies(['a'])
    assert session['cookies']['b']['value'] is 'quux'
    assert 'a' not in session['cookies']

# Generated at 2022-06-12 00:24:28.127698
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('some_path')
    session['cookies'] = {'first': '1'}
    session.remove_cookies(['first'])
    assert not session['cookies'].get('first')



# Generated at 2022-06-12 00:24:33.144317
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    my_cookies = {"foo": "bar", "baz": "qux"}
    my_session = Session('my_session')
    my_session['cookies'] = my_cookies
    my_session.remove_cookies(['foo'])
    assert my_session['cookies'] == {"baz": "qux"}

# Generated at 2022-06-12 00:24:49.183735
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    A Session object's method update_headers updates its headers
    """
    # Create a session with headers
    session = Session(path="path/to/session_file")
    session['headers'] = dict(a=1, b=2, c=3)

    # Update the headers of the session with a request header
    session.update_headers(dict(d=4, a=7))

    # The header of the session should be updated
    assert session['headers'] == dict(a=7, b=2, c=3, d=4)



# Generated at 2022-06-12 00:24:58.591309
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path(''))
    request_headers = RequestHeadersDict({})
    session.update_headers(request_headers)
    assert session.headers == RequestHeadersDict({})

    request_headers = RequestHeadersDict({'content-type': 'application/json'})
    session.update_headers(request_headers)
    assert session.headers == RequestHeadersDict({})

    request_headers = RequestHeadersDict({'content-type': 'application/json', 'auth': 'auth value'})
    session.update_headers(request_headers)
    assert session.headers == RequestHeadersDict({'auth': 'auth value'})

    request_headers = RequestHeadersDict({'Cookie': 'CookieValue'})
    session.update_headers(request_headers)

# Generated at 2022-06-12 00:25:06.247535
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(Path('config_dir/sessions/foo'))
    s['cookies'] = {'foo': 'foo_value', 'bar': 'bar_value'}
    assert s['cookies'] == {'foo': 'foo_value', 'bar': 'bar_value'}

    s.remove_cookies(['bar'])
    assert s['cookies'] == {'foo': 'foo_value'}

    s.remove_cookies(['foo', 'bar'])
    assert s['cookies'] == {}

# Generated at 2022-06-12 00:25:16.128479
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('tests/session_test.tmp')
    session['headers'] = {'Accept-Encoding': 'gzip, deflate'}
    session.load()
    request_headers = {
        'Accept-Encoding': 'gzip, deflate',
        'If-Modified-Since': 'Wed, 01 Apr 2015 16:00:00 GMT',
        'Cookie': 'foo=bar; baz=quux'
    }
    session.update_headers(request_headers)
    assert session['headers'] == {
        'Accept-Encoding': 'gzip, deflate',
        'Cookie': 'foo=bar; baz=quux'
    }
    assert session['cookies'] == {'foo': {'value': 'bar'}, 'baz': {'value': 'quux'}}

# Generated at 2022-06-12 00:25:26.776361
# Unit test for method update_headers of class Session

# Generated at 2022-06-12 00:25:33.349728
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies.json')
    session.cookies = {'test_Session_remove_cookies': ''}
    # Check that the cookies have been saved in the session
    assert session['cookies']['test_Session_remove_cookies'] == ''

    session.remove_cookies(['test_Session_remove_cookies'])
    # Check that the cookies have been removed
    assert not session['cookies']

# Generated at 2022-06-12 00:25:39.631311
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = "sessions/testsession.json"
    testSession = Session(session_path)
    testSession['cookies'] = {'test1': {'value': 'test1', 'path': '/'},
                              'test2': {'value': 'test2', 'path': '/'}}
    assert testSession['cookies'] == {'test1': {'value': 'test1', 'path': '/'},
                                      'test2': {'value': 'test2', 'path': '/'}}
    testSession.remove_cookies(['test1', 'test2'])
    assert testSession['cookies'] == {}

# Generated at 2022-06-12 00:25:46.478129
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import httpie.session
    sess = httpie.session.Session('a_file')
    sess['cookies'] = {
        'foo': {'value': 'a'},
        'bar': {'value': 'b'},
        'baz': {'value': 'c'},
    }
    sess.remove_cookies(['bar', 'foo'])
    assert sess['cookies'] == {'baz': {'value': 'c'}}

# Generated at 2022-06-12 00:25:53.017091
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    print(session['cookies'])
    session['cookies'] = {'a': 'a', 'b': 'b'}
    print(session['cookies'])
    session.remove_cookies(['a'])
    print(session['cookies'])
    session.remove_cookies(['b'])
    print(session['cookies'])

if __name__ == '__main__':
    test_Session_remove_cookies()

# Generated at 2022-06-12 00:26:01.092665
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    class FakeCookieJar(RequestsCookieJar):

        def __init__(self, cookies):
            self.cookies = cookies

        def __iter__(self):
            return self.cookies.__iter__()

    jar1 = FakeCookieJar([create_cookie('Cookie1', '1234'), create_cookie('Cookie2', '5678')])
    jar2 = FakeCookieJar([create_cookie('Cookie5', '8901')])

    session = Session(Path(""))
    session.cookies = jar1
    assert session['cookies'] == {'Cookie1': {'value': '1234'}, 'Cookie2': {'value': '5678'}}
    session.remove_cookies(['Cookie1', 'Cookie2'])
    assert session['cookies'] == {}

   

# Generated at 2022-06-12 00:26:25.258091
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class TestSession(Session):
        def __init__(self, path=None):
            super().__init__(path)
            self['headers'] = {}
            self['cookies'] = {}
            self['auth'] = {
                'type': None,
                'username': None,
                'password': None
            }

    session = TestSession()
    session.update_headers({'content-type': 'application/json', 'cookie': 'a=a', 'user-agent': 'HTTPie/1.0.0'})
    assert session.get('headers') == {'content-type': 'application/json'}
    assert session.get('cookies') == {'a': {'value': 'a'}}



# Generated at 2022-06-12 00:26:31.205111
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test 1: When a cookie is present, it is deleted
    session = Session(path='/tmp/x')
    session['cookies'] = {'a': {'value': 'b'}}
    session.remove_cookies(['a'])
    assert 'a' not in session['cookies']

    # Test 2: When a cookie is not present, nothing happens
    session = Session(path='/tmp/y')
    assert ('a' not in session['cookies'])
    session.remove_cookies(['a'])
    assert ('a' not in session['cookies'])

    # Test 3: When names is empty, nothing happens
    session = Session(path='/tmp/z')
    session['cookies'] = {'a': {'value': 'b'}}

# Generated at 2022-06-12 00:26:36.721296
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("somesession")
    session.cookies = {'cookie1': {'value': 'value1', 'path': '/'}}
    session.cookies = {'cookie2': {'value': 'value2', 'path': '/'}}
    session.cookies = {'cookie3': {'value': 'value3', 'path': '/'}}
    session.remove_cookies(['cookie2','cookie3'])
    assert session.cookies == {'cookie1': {'value': 'value1', 'path': '/'}}

# Generated at 2022-06-12 00:26:40.661055
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(__file__)
    session.update_headers({'Name': 'Joe', 'Title': 'Mr'})
    assert session == {'headers': {'Name': 'Joe', 'Title': 'Mr'}, 'cookies': {}}

# Generated at 2022-06-12 00:26:47.421653
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import httpie.plugins.session
    session = Session('test_Session_remove_cookies.json')
    session['cookies'] = {
        'foo': {'value': 'foo-value'},
        'bar': {'value': 'bar-value'},
        'baz': {'value': 'baz-value'},
    }
    session.remove_cookies(['foo', 'baz'])
    assert session['cookies'] == {'bar': {'value': 'bar-value'}}

# Generated at 2022-06-12 00:26:56.693524
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArg

    # Initialize the session
    session_name = "test"
    session_obj = Session(Path("sessions") / session_name)

    # Initialize request headers
    request_headers = RequestHeadersDict()

    # Test 1: Ignore header if value is None
    #  header: header1
    #  value: None
    test_key = "header1"
    test_value = None
    request_headers[test_key] = test_value
    session_obj.update_headers(request_headers)
    assert test_key not in session_obj.headers

    # Test 2: Ignore header if value is not str
    #  header: header2
    #  value: 123
    test_key = "header2"
    test_value = 1
    request

# Generated at 2022-06-12 00:27:02.181570
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {"cookie1": {"value": "cookie_value"}, "cookie2": {"value": "cookie_value"}}
    session.remove_cookies(["cookie1", "cookie2"])
    assert session['cookies'] == {}


# Generated at 2022-06-12 00:27:06.964123
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/test_path')
    session['cookies'] = ["test_cookie_name", "test_cookie_name_2"]
    session.remove_cookies(['test_cookie_name'])
    assert session['cookies'] == ["test_cookie_name_2"]



# Generated at 2022-06-12 00:27:10.966854
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test')
    session['cookies'] = {'test_cookie1': 'test_value', 'test_cookie2': 'test_value'}
    session.remove_cookies(['test_cookie1'])
    assert 'test_cookie1' not in session['cookies'].keys()

# Generated at 2022-06-12 00:27:16.674027
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    session.update_headers(RequestHeadersDict({
        'Content-Type': None,
        'content-length': '0',
        'User-Agent': 'HTTPie/0.9.8',
        'cookie': 'foo=bar; baz=42',
        'if-match': '*'
    }))
    assert session['headers'] == {
        'content-length': '0',
        'if-match': '*'
    }
    assert session['cookies'] == {
        'baz': {'value': '42'},
        'foo': {'value': 'bar'},
    }

# Generated at 2022-06-12 00:27:36.905962
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    Session.remove_cookies(self, ['a', 'b'])
    assert self['cookies'] == {}


# Generated at 2022-06-12 00:27:48.552376
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from requests import cookies
    from requests.cookies import create_cookie
    from httpie.config import BaseConfigDict
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.cli.dicts import RequestHeadersDict
    session_path = Path(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'example.json').__str__()
    session = Session(session_path)
    headers = RequestHeadersDict()
    headers['Cookie'] = 'a=123; b=456'
    session.update_headers(headers)
    session['cookies']['c'] = {'value': 'cde'}
    cookie_jar = cookies.RequestsCookieJar()
    cookie_jar.set_cookie(create_cookie('c', 'cde'))
    cookie_

# Generated at 2022-06-12 00:27:54.145876
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'name_1':{'value':'value_1'},'name_2':{'value':'value_2'}}
    session.remove_cookies(['name_1'])
    assert session['cookies'] == {'name_2':{'value':'value_2'}}

# Generated at 2022-06-12 00:28:02.583888
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    name1 = "NAME1"
    name2 = "NAME2"
    name3 = "NAME3"
    session = Session("/tmp/test.json")
    cookies = session.cookies
    cookies[name1] = create_cookie(
        name1, "VALUE1", domain="COOKIE1.COM", path="PATH1")
    cookies[name2] = create_cookie(
        name2, "VALUE2", domain="COOKIE1.COM", path="PATH1")
    cookies[name3] = create_cookie(
        name3, "VALUE3", domain="COOKIE1.COM", path="PATH1")
    session.cookies = cookies

    assert len(session.cookies) == 3

    session.remove_cookies([name1])

    assert len(session.cookies) == 2

    session

# Generated at 2022-06-12 00:28:03.026611
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass


# Generated at 2022-06-12 00:28:08.094179
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = "session_example.json"
    session = Session(path)
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie("id", "value"))
    session.cookies.set_cookie(create_cookie("id2", "value2"))
    assert len(session.cookies) == 2
    session.remove_cookies(["id"])
    assert len(session.cookies) == 1
    session.remove_cookies(["id2"])
    assert len(session.cookies) == 0



# Generated at 2022-06-12 00:28:16.668414
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie('abc', 'abc'))
    session.cookies.set_cookie(create_cookie('def', 'def'))

    test_names = ['abc', 'def']

    session.remove_cookies(test_names)
    assert {'abc', 'def'}.issubset(session['cookies'])

    test_names = ['abc']

    session.remove_cookies(test_names)
    assert {'def'}.issubset(session['cookies'])

    test_names = ['abc', 'def']

    session.remove_cookies(test_names)
    assert {} == session['cookies']

# Generated at 2022-06-12 00:28:24.219949
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    session = Session("dummy")
    session['cookies'] = {'cookie-name': {}}
    names = ['cookie-name', 'cookie-name1']
    session.remove_cookies(names)
    assert session['cookies'] == {'cookie-name': {}}

    session = Session("dummy")
    session['cookies'] = {'cookie-name': {}}
    names = ['cookie-name', 'cookie-name1']
    session.remove_cookies(names)
    assert session['cookies'] == {'cookie-name': {}}

# Generated at 2022-06-12 00:28:29.370330
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/test.json')
    s.cookies = RequestsCookieJar()
    s.cookies.set('foo', '42', path='/')
    s.cookies.set('bar', '42', path='/')

    assert 'foo' in s.cookies
    assert 'bar' in s.cookies
    s.remove_cookies(['foo', 'bar'])
    assert 'foo' not in s.cookies
    assert 'bar' not in s.cookies

# Generated at 2022-06-12 00:28:34.028068
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.session')
    session['cookies'] = {
        'aa': {'value': '1'},
        'bb': {'value': '2'},
    }

    session.remove_cookies(['aa'])
    assert session['cookies'].keys() == {'bb'}


# Generated at 2022-06-12 00:29:31.282043
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('test'))
    session['cookies'] = {"a": "1", "b": "2", "c": "3"}
    session.remove_cookies(['b'])
    assert session['cookies'] == {"a": "1", "c": "3"}



# Generated at 2022-06-12 00:29:35.677712
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = '/path/to/session'
    session = Session(path=session_path)
    session.load()
    session['cookies'] = {'foo': {}, 'bar': {}}
    session.remove_cookies(names=('foo', 'baz'))
    assert session['cookies'] == {'bar': {}}