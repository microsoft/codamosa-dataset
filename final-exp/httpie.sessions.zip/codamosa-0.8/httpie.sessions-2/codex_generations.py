

# Generated at 2022-06-12 00:19:57.709846
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers({'Name': 'value'})
    assert session['headers'] == {
        'Name': 'value'
    }
    session.update_headers({'Name': None})
    assert session['headers'] == {}
    session.update_headers({'Content-Type': 'value'})
    assert session['headers'] == {}
    session.update_headers({'cookie': 'Name=value'})
    assert session['headers'] == {}
    assert session['cookies'] == {
        'Name': {
            'value': 'value'
        }
    }
    session.update_headers({'cookie': None})
    assert session['headers'] == {}
    assert session['cookies'] == {}
    session.update_headers({'Cookie': 'Name=value'})

# Generated at 2022-06-12 00:20:07.212797
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    sess = Session(path='/tmp/test.json')
    sess.update_headers(
        {':auth': 'test_user:test_password',
         ':method': 'POST',
         'Content-Type': 'text/plain',
         'Cookie': 'foo=bar; baz=qux'})
    assert list(sess.headers.keys()) == [':method', 'Content-Type']
    assert sess.cookies == RequestsCookieJar([
        create_cookie('foo', 'bar'),
        create_cookie('baz', 'qux')])

# Generated at 2022-06-12 00:20:19.368343
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Check that self['cookies'] is updated
    session = Session(path='file_path')
    session['cookies'] = {}
    session.remove_cookies(['test_cookie'])
    assert session['cookies'] == {}

    # Check that self['cookies'] is not updated
    session = Session(path='file_path')
    session['cookies'] = {'test_cookie': {'value': 'value'}}
    session.remove_cookies(['another_cookie'])
    assert session['cookies'] == {'test_cookie': {'value': 'value'}}

    # Check that self['cookies'] is updated
    session = Session(path='file_path')
    session['cookies'] = {'test_cookie': {'value': 'value'}}

# Generated at 2022-06-12 00:20:29.412014
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path("session.json"))
    session['headers'] = {}
    request = {'A': 'B', 'C': 'D', 'E': 'F', 'Cookie': 'cookie1=A; cookie2=B', 'If-Match': 'G'}
    request_headers = RequestHeadersDict(request)
    session.update_headers(request_headers)
    expect_result = {'A': 'B', 'C': 'D', 'E': 'F'}
    assert session['headers'] == expect_result
    assert session['cookies'] == {'cookie1': {'value': 'A'}, 'cookie2': {'value': 'B'}}
    assert request_headers == {'Cookie': 'cookie1=A; cookie2=B', 'If-Match': 'G'}

# Generated at 2022-06-12 00:20:41.523773
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import InputFile

    s = Session('test')
    s.update_headers(RequestHeadersDict({'Content-Type': 'a'}))
    assert s.headers == {'Content-Type': 'a'}

    s.update_headers(RequestHeadersDict({'Content-Type': 'b'}))
    assert s.headers == {'Content-Type': 'b'}

    # Content-Length and Content-Type are set by httpie automatically
    s.update_headers(RequestHeadersDict({
        'Content-Type': None,
        'Content-Length': None,
        'accept-language': None
    }))
    assert s.headers == {}

    s.update_headers(RequestHeadersDict({'Content-Type': 'b'}))

# Generated at 2022-06-12 00:20:50.325650
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/a.txt')
    session["headers"] = {}
    assert session["headers"] == {}
    session.update_headers(RequestHeadersDict({'a': 'b'}))
    assert session["headers"] == {"a": "b"}
    session.update_headers(RequestHeadersDict({'a': 'c'}))
    assert session["headers"] == {"a": "c"}
    session.update_headers(RequestHeadersDict({'a': None}))
    assert session["headers"] == {"a": "c"}

# Generated at 2022-06-12 00:20:59.790959
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session = Session('/tmp/test_Session_update_headers.josn')
    request_headers = {'Host': 'httpie.org', 'User-Agent': 'user-agent'}
    session.update_headers(request_headers)
    assert session['headers'] == {'Host': 'httpie.org',
                                  'User-Agent': 'user-agent'}

    request_headers = {'Content-Type': 'application/json',
                       'If-Modified-Since': '30-May-2013'}
    session.update_headers(request_headers)
    assert session['headers'] == {'Host': 'httpie.org',
                                  'User-Agent': 'user-agent'}

    request_headers = {'User-Agent': 'HTTPie',
                       'Connection': 'close'}

# Generated at 2022-06-12 00:21:07.161465
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    headers = RequestHeadersDict({
        'cookie': 'one=1; two=2; three=3'
    })
    session = Session('')
    session.update_headers(headers)
    assert session['cookies'] == {
        'one': {'value': '1'},
        'two': {'value': '2'},
        'three': {'value': '3'},
    }
    session.remove_cookies({'one', 'two'})
    assert session['cookies'] == {
        'three': {'value': '3'},
    }

# Generated at 2022-06-12 00:21:10.760144
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('.test')
    session['cookies'] = {'test':'test'}
    session.remove_cookies(['test'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:21:14.236781
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('path')
    s['cookies'] = {'name': 'cookie'}
    s.remove_cookies(['name'])
    assert 'name' not in s['cookies']

# Generated at 2022-06-12 00:21:25.992427
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path(DEFAULT_SESSIONS_DIR) / 'test')
    session.load()
    request_headers = RequestHeadersDict(
        {'User-Agent': 'HTTPie/0.9.9',
        'X-Test': 'testing',
        'Referer': 'http://pythontesting.net/',
        'Cache-Control': 'no-cache'}
        )
    session.update_headers(request_headers)
    assert(session['headers'] == {'User-Agent': 'HTTPie/0.9.9', 'X-Test': 'testing',
        'Referer': 'http://pythontesting.net/'})
    

# Generated at 2022-06-12 00:21:37.865848
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/root/httpie/config/httpie/sessions/g.json')
    session.update_headers({'COOKIE': 'abc'})
    session.update_headers({'Auth': 'abc'})
    session.update_headers({'Uset-agent': 'abc'})
    session.update_headers({'a': 'abc'})
    session.update_headers({'B': 'abc'})
    session.update_headers({'c': 'abc'})
    session.update_headers({'D': 'abc'})
    session.update_headers({'e': 'abc'})
    session.update_headers({'F': 'abc'})
    session.update_headers({'G': 'abc'})
    session.update_headers({'H': 'abc'})
    session.update_

# Generated at 2022-06-12 00:21:47.414200
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('session_path')

# Generated at 2022-06-12 00:21:57.605688
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Test the function update_headers of class Session
    """

    # Remove the unneccesary keys
    def get_expected_headers(headers):
        remove_keys = ['Host', 'Accept', 'User-Agent']
        for key in remove_keys:
            del headers[key]
        return headers

    # Test case 1: without Session-Ignored-Header-Prefixes in the request
    session = Session(Path('./test_output/test_session.json'))
    headers = {'Accept-Language': "en-US,en;q=0.5", 'Accept-Encoding': "gzip, deflate", 'Host': 'httpbin.org', 'Accept': '*/*', 'User-Agent': 'HTTPie/0.9.2'}
    expected_headers = get_expected_headers(headers)

# Generated at 2022-06-12 00:22:09.089936
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = Session.RequestHeadersDict()
    headers.update(
        {
            # https://tools.ietf.org/html/rfc7230#section-3.2.2:
            # "Each header field consists of a case-insensitive field name
            # followed by a colon (":"), optional leading whitespace,
            # the field value, and optional trailing whitespace."
            'X-Auth-Token': 'Secret',
            'Content-Type': 'application/json',
            'If-Modified-Since': 'Tue, 19 Sep 2017 21:06:30 GMT',
            'Cookie': 'language=en; username=jkbrzt'
        }
    )
    session = Session(path=Path('/dev/null'))
    session.update_headers(headers)

    # This is the same as session file

# Generated at 2022-06-12 00:22:13.427560
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/foo/bar')
    session['headers'] = {
        'User-Agent': 'test1',
        'Host': 'host',
        'Cookie': 'test_cookie',
        'Content-Type': 'test3',
        'Accept': 'test4',
        'If-Match': 'test5'
    }

    request_headers = RequestHeadersDict({
        'User-Agent': 'test2',
        'Cookie': 'test_cookie',
        'Content-Type': 'test3',
        'Accept': 'test4',
        'If-Match': 'test5',
        'Foo': 'test6'
    })
    session.update_headers(request_headers)


# Generated at 2022-06-12 00:22:20.797829
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_dict = {
        'headers': {'A': 'B', 'C': 'D'},
        'cookies': {},
        'auth': {'type': 'basic', 'username': 'C', 'password': 'D'}
        }
    session = Session(None)
    session.update(session_dict)
    request_headers = RequestHeadersDict({'A': 'B', 'C': 'D'})
    session.update_headers(request_headers)
    assert session.headers == {'A': 'B', 'C': 'D'}
    assert session['auth'] == {'type': 'basic', 'username': 'C', 'password': 'D'}


# Generated at 2022-06-12 00:22:30.801133
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test_Session_update_headers.json')
    request_headers_dict = {
        'Content-Type': 'application/json',
        'Content-Length': '12',
        'Connection': 'keep-alive',
        'Cookie': 'foo=bar'
    }
    session.update_headers(request_headers_dict)
    assert session.headers == {
        'Content-Type': 'application/json',
        'Content-Length': '12',
        'Connection': 'keep-alive',
    }
    assert session['cookies'] == {'foo': {'value': 'bar'}}

# Generated at 2022-06-12 00:22:38.832704
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    request_headers = { 'Content-Type': 'application/json', 'If-Match': 'fff' }
    request_headers['cookie'] = 'Cookie1=value1; Cookie2=value2'
    session.update_headers(request_headers)
    expected = { 'cookie': ['Cookie1=value1; Cookie2=value2'] }
    assert session['headers'] == expected

# Generated at 2022-06-12 00:22:45.329631
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers({
        'Content-Type': 'text/html',
        'User-Agent': 'Mozilla/5.0',
        'Cookie': 'foo=bar; baz=qux',
        'If-None-Match': '123',
        'If-Match': '456',
        'If-Unmodified-Since': '789',
        'If-Modified-Since': '012'
    })
    assert session.headers == {
        'Content-Type': 'text/html',
        'User-Agent': 'Mozilla/5.0'
    }
    assert session.cookies == RequestsCookieJar([
        create_cookie('foo', 'bar'),
        create_cookie('baz', 'qux')
    ])

# Generated at 2022-06-12 00:23:00.231026
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers(
                {
                    'User-Agent': 'HTTPie/0.9.8',
                    'Host': 'httpbin.org',
                    'Accept': '*/*',
                    'Accept-Encoding': 'gzip, deflate',
                    'Connection': 'keep-alive',
                    'Content-Length': '46',
                    'Content-Type': 'application/json',
                    'Cookie': 'c1=v1; c2=v2'
                }
            )
    assert session.headers == {
                'Host': 'httpbin.org',
                'Accept': '*/*',
                'Accept-Encoding': 'gzip, deflate',
                'Connection': 'keep-alive',
                'Content-Type': 'application/json'
            }
   

# Generated at 2022-06-12 00:23:05.271038
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict({'test': 'val',})
    session = Session('')
    session.update_headers(request_headers)
    assert session['headers'] == {'test': 'val',}



# Generated at 2022-06-12 00:23:09.429565
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./files/session.json')
    session.update_headers({"Content-Type": "application/json", "Accept": "application/json"})
    assert len(session.headers) == 1
    assert session.headers["Accept"] == "application/json"


# Generated at 2022-06-12 00:23:12.194291
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s=Session("0")
    s.update_headers({"a":"b"})
    print(s.headers)
    print(type(s.headers))

# Generated at 2022-06-12 00:23:18.056354
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session = Session('/dont_care')
    session['headers'] = {}
    session['cookies'] = {}
    request_headers = {
        'User-Agent': 'My-HTTPie/3.0.0',
        'HOST': 'www.example.com'
    }

    session.update_headers(request_headers)

    assert session['headers'] == request_headers, 'Headers not updated'



# Generated at 2022-06-12 00:23:29.324392
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.compat import str
    from httpie.utils import get_response_headers
    import os
    import json
    import six
    s = Session("test.json")
    os.remove("test.json")
    headers = RequestHeadersDict({'Cookie': 'foo=bar', 'Host': 'example.com'})
    s.update_headers(headers)
    assert headers.keys() == ['Host']
    assert len(s.keys()) == 3
    assert s['headers'] == {'Host': 'example.com'}
    assert len(s['cookies']) == 1
    assert s['cookies']['foo'] == {'value': 'bar'}
    # http-session-from should not create session file if a cookie


# Generated at 2022-06-12 00:23:35.945932
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_store = Session('.')
    session_store.update_headers({'Key1': 'Value1', 'Key2': 'Value2', 'Key3': 'Value3'})

    for key in session_store.keys():
        assert session_store[key]  == {'Key1': 'Value1', 'Key2': 'Value2', 'Key3': 'Value3'}

# Generated at 2022-06-12 00:23:46.783026
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('path_to_a_file')
    headers = Session('path_to_a_file').headers
    assert len(headers) == 0  # precondition
    assert session.headers['Cookie'] is None  # precondition
    request_headers = {'cookie' : 'a=b; domain=.x; path=/; expires=Tue, 01-Jan-2030 00:00:00 GMT; max-age=31104000; secure',
                       'content-type': 'application/json',
                       'Host': None,
                       'If-Modified-Since': None
                       }
    session.update_headers(request_headers)
    assert len(session.headers) == 4
    assert session.cookies == [None, None, None]

# Generated at 2022-06-12 00:23:55.053434
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from collections import OrderedDict
    header_dict = OrderedDict()
    header_dict["Content-Type"] = "text/plain"
    header_dict["accept-Charset"] = "utf-8"
    header_dict["Content-Length"] = 100
    header_dict["If-Match"] = "one"
    header_dict["User-Agent"] = "HTTPie/0.9.8"
    header_dict["cookie"] = "name=value"
    s = Session("")
    s.update_headers(header_dict)
    expected_dict = OrderedDict()
    expected_dict["Content-Type"] = "text/plain"
    expected_dict["accept-Charset"] = "utf-8"
    expected_dict["If-Match"] = "one"

# Generated at 2022-06-12 00:24:05.511429
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test normal condition - all headers should be kept
    session = Session("")
    request_headers_dict = RequestHeadersDict()
    session.update_headers(request_headers_dict)
    assert session['headers'] == {}
    assert session.headers == {}
    # Test user-agent header - should not be kept
    request_headers_dict = RequestHeadersDict()
    request_headers_dict["user-agent"] = "HTTPie/3.0.0"
    session.update_headers(request_headers_dict)
    assert session['headers'] == {}
    assert session.headers == {}
    # Test content-type header - should not be kept
    request_headers_dict = RequestHeadersDict()
    request_headers_dict["content-type"] = "application/json"

# Generated at 2022-06-12 00:24:11.419631
# Unit test for constructor of class Session
def test_Session():
    assert(Session('/tmp/foo.json') is not None)


# Generated at 2022-06-12 00:24:14.834121
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path('tests/file'))
    session['headers'] = {"Cookie": "foo=bar"}
    request_headers = {"Cookie": "foo=bar", "Cookie": "new_cookie"}
    session.update_headers(request_headers)
    assert session['headers']['Cookie'] == "foo=bar, new_cookie"

# Generated at 2022-06-12 00:24:24.022823
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('temp_file')
    session['cookies'] = {'session':{'value': 'first_value','path': '/'},
                          'session2':{'value': 'second_value', 'path': '/home'}}
    session.remove_cookies({'session'})
    print(session['cookies'])
    assert len(session['cookies']) == 1
    assert list(session['cookies'].keys()) == ['session2']
    assert list(session['cookies']['session2'].values()) == ['second_value', '/home']


# Generated at 2022-06-12 00:24:29.665035
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.plugins import AuthPlugin
    from httpie.plugins.builtin import HTTPBasicAuth
    import httpie
    import httpie.plugins
    import requests

    class HTTPBasicAuth_test(HTTPBasicAuth):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.username = 'testuser'
            self.password = 'testpass'
        @classmethod
        def auth_parse(cls, raw_auth):
            return requests.auth.HTTPBasicAuth('testuser', 'testpass')

    auth_plugin = HTTPBasicAuth_test()
    httpie.plugins._plugin_registry['basic'] = auth_plugin

    path = '/tmp/test.json'
    session = Session(path)
    session.load()

    headers = RequestHeadersDict()

# Generated at 2022-06-12 00:24:41.019522
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    from httpie.config import Config 
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.config import BaseConfigDict
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins import AuthPlugin, FormatterPlugin, TransportPlugin

    session_name ='TestSession'
    url = 'http://127.0.0.1/tests'
    host = '127.0.0.1'

    config = Config()
    env = Environment(vars(config), config_dir=Path('./config'))

    return_val = get_httpie_session(config.config_dir, session_name, host, url)

    assert isinstance(Config, type(return_val))

# Generated at 2022-06-12 00:24:46.042131
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('session')
    headers = {
        'cookie': 'foo=bar',
        'content-type': 'application/json',
        'if-modified-since': '123456'
    }
    session.update_headers(headers)

    assert session['headers'] == {}

# Generated at 2022-06-12 00:24:47.427453
# Unit test for constructor of class Session
def test_Session():
    path = Path('~/')
    test_session = Session(path)

# Generated at 2022-06-12 00:24:51.251599
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    cookie_list = [{'name': 'cookie1', 'value': 'value1'},{'name': 'cookie4', 'value': 'value4'}]

    session_obj = Session("temp/SessionTest/")
    session_obj['cookies'] = cookie_list

    session_obj.remove_cookies(['cookie1'])

    assert (len(session_obj['cookies']) == 1)

# Generated at 2022-06-12 00:24:57.863444
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sess = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', 'www.baidu.com', 'http://www.baidu.com')
    sess.load()
    print(sess)



if __name__ == '__main__':
    import sys
    print(sys.argv)
    sess = get_httpie_session(DEFAULT_SESSIONS_DIR, sys.argv[1], 'www.baidu.com', 'http://www.baidu.com')
    sess.load()

# Generated at 2022-06-12 00:25:05.040711
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('tests/sessions/test_session.json')
    names = ['cookie1', 'cookie2']
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2', 'cookie3': 'value3'}
    session.remove_cookies(names)
    assert 'cookie1' not in session['cookies']
    assert 'cookie2' not in session['cookies']
    assert 'cookie3' in session['cookies']

# Generated at 2022-06-12 00:25:14.148654
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path = 'foo')
    session['cookies'] = {'foo': 'bar'}
    session.remove_cookies(['foo'])
    assert 'foo' not in session['cookies']

# Generated at 2022-06-12 00:25:19.396556
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    session = Session("C:\Program Files\HTTPie\config\sessions\example.com\1.json")
    cookies = {'sessionId': {'value': '2738gjh'}, 'userId': {'value': 'jg37'}}
    session['cookies'] = cookies
    names = ['sessionId', 'userId']
    # Act
    session.remove_cookies(names)
    # Assert
    assert {} == session['cookies']

# Generated at 2022-06-12 00:25:29.195915
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.input import ParseResult
    from httpie.cli.argtypes import KeyValueArgType
    from urllib.parse import urlsplit


# Generated at 2022-06-12 00:25:37.351198
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names = ['testname1', 'testname2']
    session = Session(path="/test")
    session['cookies'] = {'testname1': 'testvalue1', 'testname2': 'testvalue2', 'testname3': 'testvalue3'}
    assert session['cookies'] == {'testname1': 'testvalue1', 'testname2': 'testvalue2', 'testname3': 'testvalue3'}

    session.remove_cookies(names)
    assert session['cookies'] == {'testname3': 'testvalue3'}

# Generated at 2022-06-12 00:25:37.938571
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-12 00:25:44.922070
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    auth = {'type': 'basic', 'raw_auth': 'admin:123456'}
    session = Session('../httpie/tests/fixtures/sessions/foo.json')
    session.update({'cookies': {'foo': {'value': 'bar'}}, 'auth': auth})
    session.remove_cookies(['foo'])
    assert session['cookies'] == dict()
    assert session['auth'] == auth



# Generated at 2022-06-12 00:25:48.165208
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    headers = RequestHeadersDict()
    headers['name'] = 'value'
    session.update_headers(headers)
    assert session['headers']['name'] == 'value'

# Generated at 2022-06-12 00:25:52.519533
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict([
        ('Cookie', 'foo=bar'),
        ('User-agent', 'HTTPie/1.0.0'),
        ('HTTP-Navigator-Language', 'de'),
        ('Content-Type', 'application/json'),
        ('If-Match', '2222222')
    ])
    session = Session('test.json')
    session.update_headers(request_headers)
    assert session['headers'] == {'HTTP-Navigator-Language': 'de'}
    assert session['cookies'] == {'foo': {'value': 'bar'}}

# Generated at 2022-06-12 00:25:58.087804
# Unit test for constructor of class Session
def test_Session():
    from httpie.config import DEFAULT_CONFIG_DIR
    path = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'google.com' / 'google.com.json'
    session = Session(path)
    print(session == {'headers': {},
                      'cookies': {},
                      'auth': {
                          'type': None,
                          'username': None,
                          'password': None

                      }
                      })

# Generated at 2022-06-12 00:26:07.678298
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    test_headers = RequestHeadersDict([
        ('Accept-Language', 'en-US,en;q=0.9'),
        ('DNT', '1'),
        ('Cookie', 'session-id-1=1')
    ])
    session.update_headers(test_headers)
    
    assert session['headers']['Accept-Language'] == 'en-US,en;q=0.9'
    assert session['headers']['DNT'] == '1'
    assert session['cookies']['session-id-1']['value'] == '1'

# Generated at 2022-06-12 00:26:23.589481
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    cookie_name = 'ck'
    session_headers = {
        'content-type': 'application/json',
        'cookie': f'{cookie_name}=3',
        'fooooooo': 'bar',
        'if-match': 'xxx',
        'if-none-match': 'yyy'
    }
    session_obj = Session('')
    session_obj['headers'] = session_headers
    session_obj.update_headers({
        'Content-Type': 'application/json',
        'Fooooooo': 'bar',
        'If-Match': 'xxx',
        'If-None-Match': 'yyy'
    })
    assert cookie_name in session_obj.cookies
    assert len(session_obj.cookies) == 1
    assert session_obj.cookies[cookie_name]

# Generated at 2022-06-12 00:26:26.331900
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    Session((Path.cwd()/'myfile.json')).update_headers({'Content-Type': 'application/x-www-form-urlencoded'})
    assert 0

# Generated at 2022-06-12 00:26:29.923707
# Unit test for constructor of class Session
def test_Session():
    session = Session("test.json")
    assert session == {'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}

# Generated at 2022-06-12 00:26:37.960198
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session['headers'] = {
        "User-Agent": "HTTPie/1.0.2",
        "Content-Type": "application/json",
        "Accept": "*/*",
        "If-None-Match": "W/\"68e-4nguJ+Aa/tWwyAifLB/A\""
    }

# Generated at 2022-06-12 00:26:48.740234
# Unit test for function get_httpie_session
def test_get_httpie_session():# pragma: no cover
    # session_name.json
    sess = get_httpie_session(DEFAULT_SESSIONS_DIR, 'foo', 'localhost:5000', 'http://localhost:5000/')
    assert sess.path == Path(DEFAULT_SESSIONS_DIR / 'sessions' / 'localhost_5000' / 'foo.json')
    sess = get_httpie_session(DEFAULT_SESSIONS_DIR, 'foo', None, 'http://localhost:5000/')
    assert sess.path == Path(DEFAULT_SESSIONS_DIR / 'sessions' / 'localhost_5000' / 'foo.json')

    # session_name.json has precedence over /path/to/file.json

# Generated at 2022-06-12 00:26:54.134273
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """
    Check that the function get_httpie_session return a Session object
    """

    config_dir = Path("~/.httpie")
    session_name = "default"
    host = "localhost"
    url = "http://example.com/sub/subsub"

    # Calling the function
    sess = get_httpie_session(config_dir, session_name, host, url)

    assert isinstance(sess, Session) == True

# Generated at 2022-06-12 00:26:58.777844
# Unit test for constructor of class Session
def test_Session():
    path = '~/.config/httpie/sessions/localhost/default.json'
    session = Session(path)
    assert session.get('headers') == {}
    assert session.get('cookies') == {}
    auth = session.get('auth')
    assert auth.get('type') is None
    assert auth.get('username') is None
    assert auth.get('password') is None

# Generated at 2022-06-12 00:27:02.903044
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert(str(get_httpie_session(Path('./'), 'test_session1_get_httpie_session', None, 'http://localhost:6969/')))


# Generated at 2022-06-12 00:27:10.810462
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('http://localhost/')
    s['cookies'] = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}

    s.remove_cookies(['a', 'b', 'c'])
    assert {'d': 'd'} == s['cookies']

    s.remove_cookies(['a', 'b', 'c'])
    assert {'d': 'd'} == s['cookies']

    s.remove_cookies(['d'])
    assert {} == s['cookies']



# Generated at 2022-06-12 00:27:14.487330
# Unit test for constructor of class Session
def test_Session():
    session = Session('.httpie/sessions/localhost/session.json')
    expected_value = {'headers' : {},
                      'cookies' : {},
                      'auth' : {'type': None,
                                'username': None,
                                'password': None}
                      }
    assert session == expected_value

# Generated at 2022-06-12 00:27:32.837398
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir_path = Path('~/.httpie/')
    session_name = 'test_session_name'
    host = 'https://httpie.org'
    url = 'https://httpie.org/doc'
    ret = get_httpie_session(config_dir_path, session_name, host, url)
    assert ret

# Generated at 2022-06-12 00:27:38.749686
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.txt')
    cookies = {
        'mycookie1': {'value': 'mycookievalue1'},
        'mycookie2': {'value': 'mycookievalue2'},
        'mycookie3': {'value': 'mycookievalue3'},
    }
    session['cookies'] = cookies
    session.remove_cookies(['mycookie1', 'mycookie2'])
    assert session['cookies'] == {'mycookie3': {'value': 'mycookievalue3'}}

# Generated at 2022-06-12 00:27:50.116375
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Default configuration directory
    assert get_httpie_session(
        DEFAULT_CONFIG_DIR, 'test_session', 'localhost', 'https://example.com'
    ).path == DEFAULT_SESSIONS_DIR / 'localhost/test_session.json'
    # Default configuration directory is passed as an absolute path
    assert get_httpie_session(
        '/httpie/config', 'test_session', 'localhost', 'https://example.com'
    ).path == Path('/httpie/config') / SESSIONS_DIR_NAME / 'localhost/test_session.json'
    # Custom configuration directory is passed as an absolute path
    assert get_httpie_session(
        '/custom/config', 'test_session', 'localhost', 'https://example.com'
    ).path == Path('/custom/config') / SESSIONS

# Generated at 2022-06-12 00:27:58.529725
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # correct config dir
    config_dir = Path(__file__).parent.parent.parent / '.config' / 'httpie'
    # session name
    session_name = 'session_token'
    # host
    host = 'https://api.github.com/'
    # url
    url = None

    sess = get_httpie_session(config_dir, session_name, host, url)

    # assert session name = session_token
    assert sess['name'] == session_name
    # assert session host = https://api.github.com/
    assert sess['host'] == host

# Generated at 2022-06-12 00:28:06.206253
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import http.cookies
    request_headers = {'Set-Cookie': 'foo=bar; baz=qux', 'Cookie': '1=2; 3=4; 5=6', 'Host': 'example.com'}
    current_session = {'cookies': {'name': 'value'}, 'headers': {'Host': 'example.org'}}
    session = Session()
    session.update_from_dict(current_session)
    session.update_headers(request_headers)
    assert request_headers == {'Host': 'example.com'}
    assert session.cookies == http.cookies.SimpleCookie(
        'Cookie=1=2; 3=4; 5=6; foo=bar; baz=qux')
    assert session.headers == {'Host': 'example.com'}

# Generated at 2022-06-12 00:28:10.571776
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(DEFAULT_SESSIONS_DIR)
    s['cookies'] = {'aaa': 1, 'bbb': 2, 'ccc': 3}
    s.remove_cookies(['bbb'])
    assert s['cookies'] == {'aaa': 1, 'ccc': 3}



# Generated at 2022-06-12 00:28:15.556254
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    class MockSession(Session):
        def __init__(self, path: Union[str, Path]):
            super().__init__(path="")
            self['cookies'] = {'cookie1': 'value1'}

    session = MockSession("")
    assert "cookie1" in session['cookies']
    session.remove_cookies(['cookie1'])
    assert "cookie1" not in session['cookies']

# Generated at 2022-06-12 00:28:19.207564
# Unit test for function get_httpie_session
def test_get_httpie_session():
    httpie_session = get_httpie_session(Path("."), "test_session", None, "http://github.com/jakubroztocil/httpie")
    assert httpie_session.save() == None

# Generated at 2022-06-12 00:28:24.399528
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(Path('.'), 'tmp', None, 'https://www.google.com').path == Path('.') / SESSIONS_DIR_NAME / 'www_google_com' / 'tmp.json'
    assert get_httpie_session(Path('.'), 'tmp', 'example.com', 'https://www.google.com').path == Path('.') / SESSIONS_DIR_NAME / 'example_com' / 'tmp.json'

# Generated at 2022-06-12 00:28:27.464862
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_path')
    session['cookies'] = {'name1': {}, 'name2': {}}
    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'] == {'name2': {}}



# Generated at 2022-06-12 00:29:03.685915
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('~') / '.config'
    session_name = 'test'
    host = 'www.baidu.com'
    url = 'https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&tn=baidu&wd=abc'
    session = get_httpie_session(config_dir, session_name, host, url)
    print('session:', session)
    print('header:', session.headers)
    print('auth:', session.auth)
    print('cookie:', session.cookies)
    print('cookies:', session['cookies'])

if __name__ == '__main__':
    test_get_httpie_session()

# Generated at 2022-06-12 00:29:08.557465
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    class MockSession(Session):
        def __init__(self):
            super().__init__(None)
            self['cookies'] = {'a': {}, 'b': {}, 'c': {}, 'd': {}}

    session = MockSession()
    session.remove_cookies(['a', 'b'])

    assert session['cookies'] == {'c': {}, 'd': {}}

# Generated at 2022-06-12 00:29:12.346123
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session(path=Path(''))
    sess['cookies'] = {"1":"v1", "2":"v2", "3":"v3"}
    sess.remove_cookies(["2", "4"])
    assert sess['cookies'] == {"1":"v1", "3":"v3"}

# Generated at 2022-06-12 00:29:16.468607
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path()
    session_name = 'httpie'
    host = 'httpbin.org'
    url = 'http://httpbin.org/get'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert str(session['path']) == 'httpie.json'

# Generated at 2022-06-12 00:29:26.584814
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('~/.config/httpie/sessions/localhost/test.json')
    assert session['headers'] == {}

    # only contain cookie
    request_headers = RequestHeadersDict({
        'cookie': 'foo=bar',
        'User-Agent': 'HTTPie/0.9.9',
        'Content-Type': 'application/json',
        'If-Match': '*',
    })
    session.update_headers(request_headers)
    assert session['headers'] == {}
    assert len(session['cookies']) == 1

    # contain cookies and other headers

# Generated at 2022-06-12 00:29:30.840269
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path(''))
    session['cookies'] = {'cookie_name': {'value': 'cookie_value'}, 'cookie_name2': {'value': 'cookie_value2'}}
    session.remove_cookies(['cookie_name'])
    assert session['cookies'] == {'cookie_name2': {'value': 'cookie_value2'}}

# Generated at 2022-06-12 00:29:34.903103
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('path')
    request_headers = RequestHeadersDict({'name1': 'value1', 'name2': 'value2'})
    session.update_headers(request_headers)
    assert session['headers'] == {'name1': 'value1', 'name2': 'value2'}