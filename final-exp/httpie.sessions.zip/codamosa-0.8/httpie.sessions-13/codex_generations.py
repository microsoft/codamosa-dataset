

# Generated at 2022-06-12 00:19:58.376286
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')

    headers_before = RequestHeadersDict({
            'User-Agent': 'HTTPie/0.9.9',
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Cookie': 'foo=bar',
            'Accept-Language': 'en-us'
        })

    session.update_headers(headers_before)

    assert session['headers']['Accept'] is not headers_before['Accept']

    # Remove prefix content
    assert 'Content-' not in session['headers']
    # Remove cookie
    assert 'Cookie' not in session['headers']
    # Remove User-Agent
    assert 'User-Agent' not in session['headers']

    # Ensure that session['cookies'] contains the

# Generated at 2022-06-12 00:20:03.360270
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(':memory:')

    # Test new style without cookies
    session.update_headers(
        RequestHeadersDict({'Accept': 'application/json', 'User-Agent': 'testing 123'}))
    assert session.headers == RequestHeadersDict({'Accept': 'application/json', 'User-Agent': 'testing 123'})

    # Test new style with cookies
    session.update_headers(
        RequestHeadersDict({'Accept': 'application/json', 'User-Agent': 'testing 123', 'Cookie': 'test=test'}))
    assert session.headers == RequestHeadersDict({'Accept': 'application/json', 'User-Agent': 'testing 123'})
    assert 'test=test' in session.cookies

    # Test old style
    session['headers'] = {}

# Generated at 2022-06-12 00:20:12.082360
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import json

    from httpie.cli.dicts import RequestHeadersDict
    from httpie.compat import urlunparse
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    from tests.test_examples import (
        EXAMPLES_DIR,
        EMPTY_RESPONSE,
        MOCK_RESPONSE_301,
        MOCK_RESPONSE_JSON,
        MOCK_RESPONSE_TXT,
        MOCK_RESPONSE_UNAUTHORIZED,
        get_mock_env,
    )

    example_dir = EXAMPLES_DIR / 'sessions'
    example_session = Session(example_dir / 'session')
    example_session.load()

    env = get_mock_env()
    env

# Generated at 2022-06-12 00:20:24.293109
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.context import Environment
    from httpie.plugins import builtin
    from httpie import ExitStatus

    # The test code is based on https://github.com/jakubroztocil/httpie/blob/9e6b1e08eb415f3a19b4bad84af8f4c060160548/tests/core/test_session.py#L116-L136
    # use environment to create the variables that are used in context.py

# Generated at 2022-06-12 00:20:32.659817
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    request_headers = {
        'Header1': 'value1',
        'Content-Type': 'text/plain',
        'If-Modified-Since': 'Sat, 29 Oct 1994 19:43:31 GMT',
        'Referer': 'http://httpbin.org/',
        'Cookie': 'name1=value1; name2=value2; name3=value3',
        'Host': 'httpbin.org',
        'Accept-Encoding': 'gzip',
        'User-Agent': 'HTTPie/1.0.3',
    }
    session.update_headers(request_headers)
    assert session['headers']['header1'] == 'value1'
    assert session['headers']['Referer'] == 'http://httpbin.org/'

# Generated at 2022-06-12 00:20:42.881138
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('')

    def assert_s_headers(s, expected_dict):
        assert s == expected_dict

    r = RequestHeadersDict()
    #   case 1:
    #           when request headers is None
    s.update_headers(r)
    assert_s_headers(s, {})

    #   case 2:
    #           when request headers has one fold-case key
    r['connection'] = 'keep-alive'
    s.update_headers(r)
    expected_dict = {'connection': 'keep-alive'}
    assert_s_headers(s, expected_dict)

    #   case 3:
    #           when request headers has same key
    #                                  but different values
    r['connection'] = 'close'
    s.update_headers(r)
   

# Generated at 2022-06-12 00:20:53.257821
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArgType

    session = Session(path='path')
    request_headers = RequestHeadersDict()
    request_headers['Content-Type'] = 'text/html; charset=utf-8'
    request_headers['Cookie'] = KeyValueArgType('set', 'cookie').convert(
        'foo=b', 'bar=c')
    session.update_headers(request_headers)
    assert session.get('headers') is not None
    assert session['headers'].get('Content-Type') is None
    assert session['headers'].get('Cookie') is None
    assert len(session['cookies']) == 2
    assert session['cookies']['foo'].get('value') == 'b'

# Generated at 2022-06-12 00:21:02.390491
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import tempfile
    stream = tempfile.NamedTemporaryFile(suffix='.json', delete=False)
    stream.close()

    session = Session(stream.name)
    session['cookies'] = {'c1': '', 'c2': ''}

    session.remove_cookies(['c1'])
    assert len(session['cookies']) == 1

    session.remove_cookies(['c2'])
    assert len(session['cookies']) == 0

    session['cookies'] = {'c1': ''}
    assert len(session['cookies']) == 1

    session.remove_cookies(['c1'])
    assert len(session['cookies']) == 0

    os.remove(stream.name)


# Generated at 2022-06-12 00:21:08.912506
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/home/user/.config/httpie/sessions/test.json')
    session['headers'] = {'a': '0', 'b': '4', 'c': '2'}

    session.update_headers({'A': '1', 'b': '3', 'c': '6', 'D': '8'})

    expected = {'a': '1', 'b': '3', 'c': '6', 'd': '8'}
    assert session['headers'] == expected

# Generated at 2022-06-12 00:21:18.144812
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_a = RequestHeadersDict()
    headers_b = RequestHeadersDict()
    session = Session("./test/test_Session_update_headers.json")
    session.update_headers(headers_a)
    assert session.headers == RequestHeadersDict()
    headers_a['Content-Type'] = 'application/json'
    session.update_headers(headers_a)
    assert session.headers == RequestHeadersDict()
    headers_a['Expect'] = '200-ok'
    session.update_headers(headers_a)
    assert session.headers == RequestHeadersDict()
    headers_a['Expect'] = ''
    session.update_headers(headers_a)
    assert session.headers == RequestHeadersDict()
    headers_a['Expect'] = ' '
   

# Generated at 2022-06-12 00:21:33.186006
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./testdata/test_session.json'))
    session.load()

    # Without cookies to remove
    session.remove_cookies([])
    assert len(session['cookies']) == 3

    # Remove cookies with name "banana" and "orange"
    session.remove_cookies(['banana', 'orange'])
    assert len(session['cookies']) == 1
    assert list(session['cookies'].keys()) == ['pear']

    # Remove all cookies
    session.remove_cookies(list(session['cookies'].keys()))
    assert len(session['cookies']) == 0



# Generated at 2022-06-12 00:21:38.012957
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./config/sessions/localhost/test.json')
    cookies = {
       'foo': {'value': 'bar1'},
       'bar': {'value': 'bar2'},
       'test': {'value': 'bar3'}
    }
    session['cookies'] = cookies
    session.remove_cookies(['foo'])
    assert 'foo' not in session['cookies']
    assert 'bar' in session['cookies']
    assert 'test' in session['cookies']

# Generated at 2022-06-12 00:21:41.337415
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session.json')
    session['cookies'] = {'a': 'a', 'b': 'b', 'c': 'c'}
    session.remove_cookies(['b', 'd'])
    assert session['cookies'] == {'a': 'a', 'c': 'c'}


# Generated at 2022-06-12 00:21:49.409832
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {}
    cookies['name1'] = {'value': 'value1'}
    cookies['name2'] = {'value': 'value2'}
    cookies['name3'] = {'value': 'value3'}
    session = Session('path')
    session['cookies'] = cookies
    session.remove_cookies(['name1'])
    assert len(session['cookies']) == 2
    for name in session['cookies']:
        assert name != 'name1'

# Generated at 2022-06-12 00:21:57.830877
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import tempfile
    _, session_path = tempfile.mkstemp()
    session = Session(session_path)
    session.update_headers(
        {
            'Cookie': """cookie1=value1; cookie2=value2; cookie3=value3""",
        }
    )
    session.remove_cookies(['cookie2', 'cookie4',])
    cookies_dict = session.cookies._cookies
    assert(
        len(cookies_dict) == 2
        and cookies_dict.get('cookie1') != None
        and cookies_dict.get('cookie3') != None
        and cookies_dict.get('cookie2') == None
        and cookies_dict.get('cookie4') == None
    )

# Generated at 2022-06-12 00:22:02.149086
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'sessionid': {'value': '123456', 'path': '/'}}
    session = Session('./test.json')
    session['cookies'] = cookies
    session.remove_cookies(['sessionid'])
    assert 'sessionid' not in session['cookies']

# Generated at 2022-06-12 00:22:09.088874
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session()
    s['cookies'] = {
        'session1': {
            'value': 'test1'
        },
        'session2': {
            'value': 'test2'
        }
    }
    s.remove_cookies(['session1'])
    assert len(s['cookies']) == 1
    assert s['cookies']['session2'] == {'value': 'test2'}

# Generated at 2022-06-12 00:22:12.752614
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session("/test")
    sess["cookies"] = dict()
    sess["cookies"]["c1"] = "v1"
    sess["cookies"]["c2"] = "v2"
    sess.remove_cookies(["c1"])
    assert len(sess["cookies"]) == 1
    assert sess["cookies"]["c2"] == "v2"
    sess.remove_cookies([])
    assert len(sess["cookies"]) == 1
    sess.remove_cookies(["c2", "c3"])
    assert len(sess["cookies"]) == 0

# Generated at 2022-06-12 00:22:18.157206
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('./foo')
    s['cookies'] = {'foo': {'value': 'test'}, 'bar': {'value': 'test'}}

    s.remove_cookies(['foo'])
    assert s == {'headers': {}, 'cookies': {'bar': {'value': 'test'}}, 'auth': {'type': None, 'username': None, 'password': None}}

# Generated at 2022-06-12 00:22:25.947359
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("")
    s["cookies"] = {'c1' : {'value' : 'a', 'path' : '/'},
                    'c2' : {'value' : 'b', 'path' : '/'},
                    'c3' : {'value' : 'c', 'path' : '/'}}
    s.remove_cookies(['c1', 'c2'])
    assert s["cookies"] == {'c3' : {'value' : 'c', 'path' : '/'}}

# Generated at 2022-06-12 00:22:40.750616
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("test")
    s['cookies'] = {'abc': {'value':'3', 'secure':'True', 'path':'/'},
                    'def': {'value':'4', 'secure':'True', 'path':'/'},
                    'ghi': {'value':'5', 'secure':'True', 'path':'/'}
                    }
    s.remove_cookies([ 'abc', 'def', 'ghi'])
    assert s['cookies'] == {}
    s['cookies'] = {'abc': {'value':'3', 'secure':'True', 'path':'/'},
                    'def': {'value':'4', 'secure':'True', 'path':'/'}
                    }
    s.remove_cookies([ 'abc', 'ghi'])
    assert s

# Generated at 2022-06-12 00:22:44.466793
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from pytest import raises
    sess = Session('')
    sess['cookies'] = {'cookie1':{'value' : '1'}}
    with raises(KeyError):
        sess.remove_cookies('cookie1')

# Generated at 2022-06-12 00:22:52.756471
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('s/s')
    s.cookies = RequestsCookieJar()
    s.cookies.set('a', '1')
    s.cookies.set('b', '2')
    s.cookies.set('c', '3')
    assert s.cookies == RequestsCookieJar([('a', '1'), ('b', '2'), ('c', '3')])
    s.remove_cookies(['a', 'c'])
    assert s.cookies == RequestsCookieJar([('b', '2')])



# Generated at 2022-06-12 00:22:57.701466
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    request_cookies = RequestHeadersDict()
    request_cookies['cookies'] = (
        'id=TESTID; foo=TESTFOO; bar=TESTBAR; foobar=TESTFOOBAR; big=TESTBIG'
    )
    session = Session('')
    session.update_headers(request_cookies)
    session.remove_cookies(['foobar', 'big'])
    assert len(session['cookies'].keys()) == 3
    assert not ('foobar' in session['cookies'])
    assert not ('big' in session['cookies'])


# Generated at 2022-06-12 00:23:07.787604
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path="")
    session.cookies = {
            'cookie3': {'value': 'value3'},
            'cookie1': {'value': 'value1'},
            'cookie2': {'value': 'value2'},
            'cookie4': {'value': 'value4'},
            }

    assert session['cookies']['cookie1']['value'] == 'value1'
    assert session['cookies']['cookie2']['value'] == 'value2'
    assert session['cookies']['cookie3']['value'] == 'value3'
    assert session['cookies']['cookie4']['value'] == 'value4'

    session.remove_cookies(['cookie1', 'cookie2'])

# Generated at 2022-06-12 00:23:15.788014
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(get_httpie_session('D:\Program Files\httpie-1.0.2',
                                         'test_Session_remove_cookies',
                                         'https://www.baidu.com',
                                         'https://www.baidu.com'))
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-12 00:23:18.813503
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_file')
    session['cookies'] = {'k1': 'v1', 'k2': 'v2'}
    session.remove_cookies(['k1','k2'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:23:27.800704
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session.cookies = RequestsCookieJar()
    session.cookies.set('cookie1', 'val')
    session.cookies.set('cookie2', 'val')
    session.cookies.set('cookie3', 'val')
    session.remove_cookies(['cookie2'])
    assert session.cookies.__class__.__name__ == 'RequestsCookieJar'
    assert session.cookies.get_dict() == {'cookie1': 'val', 'cookie3': 'val'}

# Generated at 2022-06-12 00:23:33.843139
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('~')
    s.load()
    s['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    s.remove_cookies(['a'])
    assert s == {'headers': {}, 'cookies': {'b': {'value': '2'}}, 'auth': {'type': None, 'username': None, 'password': None}}

# Generated at 2022-06-12 00:23:42.052019
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session.load()
    session.cookies.set_cookie(create_cookie('test', 'test'))
    session.cookies.set_cookie(create_cookie('test2', 'test2'))
    session.cookies.set_cookie(create_cookie('test3', 'test3'))
    session.cookies.set_cookie(create_cookie('test4', 'test4'))
    assert session.cookies['test4'].value == 'test4'
    session.remove_cookies(['test3'])
    assert session.cookies['test4'].value == 'test4'
    assert 'test3' not in session['cookies']
    session.remove_cookies(['test', 'test2'])
    assert 'test' not in session['cookies']

# Generated at 2022-06-12 00:24:09.231787
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.compat import Path
    import httpie.plugins
    s = Session(Path('session_file'))
    s['cookies'] = {
        'name': {
            'domain': 'www.baidu.com',
            'path': '/',
            'value': '123'
        },
        'name1': {
            'domain': 'www.baidu.com',
            'path': '/',
            'value': '123'
        }
    }
    s.remove_cookies(['name'])
    assert 'name' not in s['cookies']
    assert 'name1' in s['cookies']

# Generated at 2022-06-12 00:24:14.590091
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path = "temp.json")
    session['cookies'] = {'foo':{'value':'bar'}, 'bar':{'value':'foo'}}
    assert session['cookies'] ==  {'foo':{'value':'bar'}, 'bar':{'value':'foo'}}
    session.remove_cookies(['foo'])
    assert session['cookies'] ==  {'bar':{'value':'foo'}}

# Generated at 2022-06-12 00:24:19.225434
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = '~/httpie.session'
    session = Session(path)
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-12 00:24:26.495093
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = 'test_Session_remove_cookies.json'
    c = Session(path)
    c.load()
    print(c)
    c['cookies'] = {'a': 'b', 'c': 'd'}
    # c.save()
    print(c)
    c.remove_cookies(['a','c'])
    print(c)
    print(os.path.exists(path))

if __name__ == '__main__':
    test_Session_remove_cookies()


# Generated at 2022-06-12 00:24:30.470136
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('.'))
    session['cookies'] = {'a': 'b', 'b': 'c'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 'c'}

# Generated at 2022-06-12 00:24:35.108563
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    a = Session('test/test.json')
    a['cookies'] = {"a":1,"b":2}
    a.remove_cookies(["a","c"])
    assert a['cookies'] == {"b":2}

# Generated at 2022-06-12 00:24:39.943772
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies')
    session['cookies'] = {'some_cookie1': {}, 'some_cookie2': {}}
    names = ['some_cookie1', 'some_cookie2']
    session.remove_cookies(names)
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:24:44.343306
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_new.json')
    cookies = {'abc': {'value': 'abc'}}
    session['cookies'] = cookies
    session.remove_cookies(['abc'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:24:49.143737
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('sessions/test.json')
    names = ['cookie-name-1', 'cookie-name-2', 'cookie-name-3']
    for name in names:
        session['cookies'][name] = 'test'
    session.remove_cookies(names)
    assert 'cookies' not in session



# Generated at 2022-06-12 00:24:55.289323
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_cookies = {"_session_id": "1234"}
    session_cookies_to_remove = ["_session_id"]
    session_cookies_expected = {}
    session_cookies_removed = Session.remove_cookies(session_cookies, session_cookies_to_remove)
    assert session_cookies_removed == session_cookies_expected

# Generated at 2022-06-12 00:25:42.769254
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from collections import OrderedDict
    from pytest import raises
    session = Session("/tmp/test.json")
    session["cookies"] = OrderedDict([('test1', 'test1'), ('test2', 'test2')])
    session.remove_cookies(['test1'])
    assert session["cookies"] == OrderedDict([('test2', 'test2')])
    with raises(KeyError, match="'test'") as e:
        session.remove_cookies(['test'])

# Generated at 2022-06-12 00:25:50.495233
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_dict = {'alpha': {'value': 'first_cookie'},
                   'beta': {'value': 'second_cookie'}}
    session = Session(Path('./file.json'))
    session.cookies = cookie_dict
    session.remove_cookies(['alpha'])
    assert session['cookies'] == {'beta': {'value': 'second_cookie'}}
    session.remove_cookies(['gamma'])
    assert session['cookies'] == {'beta': {'value': 'second_cookie'}}


# Generated at 2022-06-12 00:25:58.896746
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('http://www.cwi.nl/')
    session['cookies'] = {'name1':'value1', 'name2':'value2'}

    assert len(session['cookies']) == 2
    assert 'name1' in session['cookies']
    assert 'name2' in session['cookies']
    assert session['cookies']['name1'] == 'value1'
    assert session['cookies']['name2'] == 'value2'

    session.remove_cookies(['name1'])

    assert len(session['cookies']) == 1
    assert 'name1' not in session['cookies']
    assert 'name2' in session['cookies']
    assert session['cookies']['name2'] == 'value2'

# Generated at 2022-06-12 00:26:02.574596
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    cookies = {'a': 'b'}
    session.cookies = cookies
    session.remove_cookies(['a'])
    assert 'a' not in session.cookies



# Generated at 2022-06-12 00:26:13.196907
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("")

    s['cookies'] = {'c1': {'value': 'v1'}}
    assert s['cookies'] == {'c1': {'value': 'v1'}}
    s.remove_cookies(['c1'])
    assert s['cookies'] == {}

    s['cookies'] = {'c1': {'value': 'v1'}, 'c2': {'value': 'v2'}}
    assert s['cookies'] == {'c1': {'value': 'v1'}, 'c2': {'value': 'v2'}}
    s.remove_cookies(['c2'])
    assert s['cookies'] == {'c1': {'value': 'v1'}}


# Generated at 2022-06-12 00:26:17.097976
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(('b', 'd'))
    assert session['cookies'] == {'a': 1, 'c': 3}

# Generated at 2022-06-12 00:26:24.051375
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    my_Session = Session("test_session")
    dict = {"cookie_1":"value 1",
            "cookie_2":"value 2",
            "cookie_3":"value 3"}
    my_Session['cookies'] = dict
    remove_list = ["cookie_1", "cookie_3"]
    my_Session.remove_cookies(remove_list)
    assert (my_Session['cookies'] == {"cookie_2":"value 2"}), \
        "Method remove_cookies of class Session does not work correctly."

    

# Generated at 2022-06-12 00:26:27.366824
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session("/tmp/test_Session_remove_cookies.json")
    sess['cookies'] = {"a": "apple"}
    sess.remove_cookies(['a'])
    assert 'a' not in sess.cookies



# Generated at 2022-06-12 00:26:36.796857
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    def test_remove_cookies(cookies: dict, cookie_names: list, expected: dict):
        session = Session('dummy-session-name')
        session['cookies'] = cookies
        session.remove_cookies(cookie_names)
        actual = session['cookies']
        assert actual == expected

    test_remove_cookies(
        cookies={},
        cookie_names=[],
        expected={})

    test_remove_cookies(
        cookies={},
        cookie_names=['cookie1'],
        expected={})

    test_remove_cookies(
        cookies={
            'cookie1': 'value1',
            'cookie2': 'value2'},
        cookie_names=['cookie1', 'cookie2'],
        expected={})


# Generated at 2022-06-12 00:26:41.752844
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = get_httpie_session("config_dir","session_name","host","url")
    session.cookies = RequestsCookieJar()
    assert type(session.cookies) == RequestsCookieJar
    session.remove_cookies(["test","test2"])
    assert type(session.cookies) == RequestsCookieJar

# Generated at 2022-06-12 00:28:22.181133
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session_set')
    test_cookies = {'cookie1': {'value': 'cookie1'},
                    'cookie2': {'value': 'cookie2'},
                    'cookie3': {'value': 'cookie3'}}
    session['cookies'] = test_cookies

    # Input names is empty
    session.remove_cookies([])
    assert session['cookies'] == test_cookies
    
    # Input names has one cookie which is in session
    session.remove_cookies(['cookie2'])
    del test_cookies['cookie2']
    assert session['cookies'] == test_cookies

    # Input names has one cookie which is not in session
    session.remove_cookies(['cookie5'])
    assert session['cookies'] == test_cookies

    #

# Generated at 2022-06-12 00:28:33.103590
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('session'))
    #setting cookies in session
    session['cookies'] = {
            'name1':{'value': 'name1'},
            'name2':{'value': 'name2'},
            'name3':{'value': 'name3'},
            'name4':{'value': 'name4'},
    }
    entries_of_cookies = list(session['cookies'].keys())
    session.remove_cookies(names=['name1', 'name3'])
    entries_of_cookies_after_removal = list(session['cookies'].keys())
    assert (len(entries_of_cookies_after_removal) == len(entries_of_cookies) - 2)

# Generated at 2022-06-12 00:28:35.547018
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session.json')
    session['headers'] = {'Content': 'content'}
    session['cookies'] = {'cookie': 'value'}

    session.remove_cookies(['cookie'])
    
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:28:44.841184
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('/not/a/path')
    assert sess['cookies'] == {}
    sess['cookies'] = {
        'cookie1': {
            'value': 'cookie1',
        },
        'cookie2': {
            'value': 'cookie1',
        },
    }
    sess.remove_cookies(['cookie2'])
    assert sess['cookies'] == {
        'cookie1': {
            'value': 'cookie1',
        },
    }

    sess.remove_cookies(['cookie1'])
    assert sess['cookies'] == {}


# Generated at 2022-06-12 00:28:47.443138
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("s.json")
    s["cookies"] = {"hello": "world"}
    s.remove_cookies(["hello"])
    assert "hello" not in s["cookies"]

# Generated at 2022-06-12 00:28:52.456629
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    assert not session['cookies']

    session['cookies'] = {'foo': {}, 'bar': {}}
    assert session['cookies'] == {'foo': {}, 'bar': {}}

    session.remove_cookies(['foo'])
    assert session['cookies'] == {'bar': {}}

    session.remove_cookies(['bar'])
    assert not session['cookies']



# Generated at 2022-06-12 00:28:57.916743
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = Path(__file__).parent / "../../../examples/session.json"
    session = Session(session_path)
    session.load()
    result = {"name1": "value1", "name2": "value2"}
    session.cookies = result
    session.remove_cookies(["name1", "name3"])
    assert session["cookies"] == {"name2": "value2"}



# Generated at 2022-06-12 00:29:05.527018
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path="test.json")
    session['cookies'] = {
        "cookie1": "value1",
        "cookie2": "value2",
    }
    session.remove_cookies([])
    assert session['cookies'] == {"cookie1": "value1", "cookie2": "value2"}
    session.remove_cookies(["cookie1"])
    assert session['cookies'] == {"cookie2": "value2"}
    session.remove_cookies(["cookie2"])
    assert session['cookies'] == {}
    session.remove_cookies(["cookie1"])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:29:13.448997
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test incorrect cases
    s = Session(path = "path/session/session.json")
    s['cookies'] = {}
    s.remove_cookies(['name1'])
    assert s == Session(path = "path/session/session.json")
    # Test correct cases
    s['cookies'] = {'name1': None, 'name2': None}
    s.remove_cookies(['name1'])
    assert s['cookies'] == {'name2': None}
    assert s['cookies'] == {'name2': None}
    s.remove_cookies(['name1', 'name4', 'name2'])
    assert s['cookies'] == {}

# Generated at 2022-06-12 00:29:16.256329
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('stdin')
    session['cookies'] = {'name': {}}
    session.remove_cookies(['name'])

    assert 'name' not in session['cookies']