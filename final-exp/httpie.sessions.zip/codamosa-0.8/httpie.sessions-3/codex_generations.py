

# Generated at 2022-06-12 00:19:51.953012
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('session/test/path')
    session['headers'] = {'A': 'a'}

    # Set header with value None does not update the session
    request_headers = RequestHeadersDict(
        {'A': 'a', 'B': None}
    )
    session.update_headers(request_headers)
    assert session['headers'] == {'A': 'a'}
    assert request_headers == RequestHeadersDict(({'A': 'a', 'B': None}))

    # Set header with value None does not update the session
    request_headers = RequestHeadersDict(
        ({'B': 'b'}),
    )
    session.update_headers(request_headers)
    assert session['headers'] == {'A': 'a', 'B': 'b'}
    assert request

# Generated at 2022-06-12 00:20:04.276523
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Tests update_headers method of Session class
    """

    # https://docs.python.org/3/library/unittest.mock.html
    import mock

    # https://pypi.org/project/freezegun/
    from freezegun import freeze_time
    import datetime
    import time

    # Create a session file
    mock_config_dir = mock.Mock(spec=Path)
    mock_config_dir.__truediv__ = mock.Mock(spec=Path)
    mock_config_dir.__truediv__.return_value.__truediv__ = mock.Mock(spec=Path)
    mock_config_dir.__truediv__.return_value.__truediv__.return_value = Path('/tmp')
    mock_config_

# Generated at 2022-06-12 00:20:06.664854
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert None == Session('./test_Session_remove_cookies.json').remove_cookies(['name1', 'name2'])

# Generated at 2022-06-12 00:20:18.598601
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # test case 1
    url = 'https://httpbin.org/anything'
    session_headers = {'x-test': 'true',
                       'X-Test-Header': 'True',
                       'X-test-header': 'True'}
    request_headers = {'X-test-header': 'True',
                       'X-New-Header': 'False',
                       'x-new-header': 'False',
                       'X-Test-Header': 'False',
                       'X-test-header': 'False',
                       'x-Test': 'False'}
    httpie_session = Session(url)
    httpie_session.update_headers(request_headers)
    assert httpie_session.headers == session_headers

    # test case 2
    url = 'https://httpbin.org/anything'
    session_headers

# Generated at 2022-06-12 00:20:28.912793
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Create a dummy session file
    path = Path("test.json")
    if not os.path.exists("test.json"):
        with open("test.json", "w") as jsonFile:
            jsonFile.write("{}")
    headers = {
        "Content-Type": 'application/x-www-form-urlencoded',
        "User-Agent": "HTTPie/0.9.9",
        "Cookie": "key1=value1; key2=value2; key3=value3"
    }
    session = Session(path)
    session.update_headers(RequestHeadersDict(headers))
    assert session.headers == {
        "Content-Type": 'application/x-www-form-urlencoded',
    }

# Generated at 2022-06-12 00:20:35.218455
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_dict = {
        "cookies": {
            "test1": "cookie1",
            "test2": "cookie2"
            }
        }
    session = Session.__new__(Session)
    session.__init__(config=test_dict)
    session.remove_cookies(names=["test1", "test2"])
    assert not session.cookies

# Generated at 2022-06-12 00:20:41.780216
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    data = {'headers':{'Content-type':'application/json', 'Content-Length':'1000', 'cookie':'test=test'}, 
            'cookies':{'test':{'value':'test'}}
            }
    request_headers = {'Content-Type':'text/html', 'Content-Length':'2000'}
    session = Session('test')
    session.update_headers(request_headers)
    assert(session == data)


# Generated at 2022-06-12 00:20:45.276849
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_headers = RequestHeadersDict({'key': 'value'})
    session = Session('test')
    session.update_headers(session_headers)
    assert session['headers'] == {'key': 'value'}

# Generated at 2022-06-12 00:20:50.089369
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Unit test for method update_headers of class Session
    """
    request_headers = {'If-Modified-Since': 'Tue, 1 Oct 2019 19:24:30 GMT'}
    session = Session(None)
    session.update_headers(request_headers)
    assert request_headers == {}

# Generated at 2022-06-12 00:20:56.785425
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    '''
    Test update_headers method of the Session class
    '''
    # Create a fake request_headers object
    request_headers = {
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US,en;q=0.5',
        'Cookie': '_gitlab_session=859e75c2dda44b4e4b3a09b9a9e7d1f3',
        'Host': 'localhost',
        'Referer': 'http://localhost/root/httpie/blob/master/httpie/cli.py',
        'User-agent': 'HTTPie/1.0.2',
        'X-Forwarded-For': '127.0.0.1'
    }
    request_

# Generated at 2022-06-12 00:21:06.737242
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(DEFAULT_SESSIONS_DIR)
    session['cookies'] = {'demo1': 'dummy1', 'demo2': 'dummy2'}
    names = ['demo1', 'demo2']
    session.remove_cookies(names)
    assert session['cookies'] == {}



# Generated at 2022-06-12 00:21:17.506326
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # create a Session object for testing
    session = Session('test')

    # create the headers to store in the session
    from httpie.cli.dicts import RequestHeadersDict
    headers = RequestHeadersDict()
    headers.update({'Accept': '*/*', 'Content-Type': 'application/x-www-form-urlencoded',
                    'User-Agent': 'HTTPie/0.9.9', 'Cookie': 'name=value'})

    # The update is done during the call to update_headers()
    session.update_headers(headers)

    # must have only one header
    assert len(session.headers) == 1
    # must be 'Accept'
    assert list(session.headers.keys())[0] == 'Accept'
    # must be equal to '*/*'

# Generated at 2022-06-12 00:21:25.510658
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    req_header = RequestHeadersDict(
        {
            'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
            'User-Agent': 'HTTPie/1.0.3',
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate',
            'Host': 'httpbin.org',
            'Content-Length': '16'
        }
    )

    session = Session("")
    session.update_headers(req_header)


# Generated at 2022-06-12 00:21:37.368845
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({
        'set-cookie': 'cookie1=value1; Path=/; Secure',
        'Set-Cookie': 'cookie2=value2; Path=/',
        'Cookie': 'cookie3=value3',
        'User-Agent': 'HTTPie/0.9.9',
        'authorization': 'Basic YWxhZGRpbjpvcGVuc2VzYW1l',
        'If-None-Match': '"737060cd8c284d8af7ad3082f209582d"'
    })

# Generated at 2022-06-12 00:21:43.492159
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.config import Config
    from httpie.plugins.auth import AuthPlugin, BasicAuth, DigestAuth
    from httpie.plugins.auth.core import BasicCredentials, DigestCredentials
    from httpie.plugins.auth.utils import auth_plugin_registry

    class BasicAuthPlugin(AuthPlugin):
        auth_type = 'basic-auth-plugin'
        auth_parse = True

        def get_auth(self, username=None, password=None):
            return BasicAuth(username, password)

    class DigestAuthPlugin(AuthPlugin):
        auth_type = 'digest-auth-plugin'
        auth_parse = True

        def get_auth(self, username=None, password=None):
            return DigestAuth(username, password)

    auth_plugin_registry.register(BasicAuthPlugin)
    auth_

# Generated at 2022-06-12 00:21:55.193119
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # 1) Update empty session_headers with request_headers
    session_headers = {}
    request_headers = {"x-header":"x-value"}
    session = Session("test_path")
    session.update_headers(request_headers)
    assert session_headers == session['headers']

    # 2) Keep none values in session_headers
    session_headers = {"x-header": "x-value", "y-header": None}
    request_headers = {"x-header": "x-new_value", "y-header": "y-value"}
    session = Session("test_path")
    session.update_headers(request_headers)
    assert session_headers == session['headers']

    # 3) Check strings encoding
    session_headers = {"x-header": "x-value"}

# Generated at 2022-06-12 00:22:02.617976
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("testfile")
    request_headers = {'Accept': 'something', 'Content-Length': None}
    session.update_headers(request_headers)
    assert request_headers == {'Accept': 'something', 'Content-Length': None}
    assert session.headers == {'Accept': 'something'}
    assert session == {'json': False, 'headers': {'Accept': 'something'}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}


# Generated at 2022-06-12 00:22:11.736687
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/path/to/session/file')
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie(
        'foo', 'bar', path='/', secure=True, expires=12345678))
    session.cookies.set_cookie(create_cookie(
        'baz', 'qux', expires=23456789))
    assert len(session.cookies) == 2
    session.remove_cookies(['foo', 'quux'])
    assert len(session.cookies) == 1
    for cookie in session.cookies:
        assert cookie.name == 'baz'



# Generated at 2022-06-12 00:22:21.019884
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    Headers = RequestHeadersDict
    session = Session('a_session.json')

    # test empty request headers
    session.update_headers(Headers({}))
    assert 'headers' not in session

    # test single request header and value
    session.update_headers(Headers({'Content-Type': 'application/json'}))
    assert Headers(session['headers']) == Headers({'Content-Type': 'application/json'})

    # test multiple request headers and values
    session.update_headers(Headers({'Content-Type': 'application/json', 'Cookie': 'sessionid=1'}))
    assert Headers(session['headers']) == Headers({'Content-Type': 'application/json'})

    # test ignoring of explicitly unset headers

# Generated at 2022-06-12 00:22:30.525450
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    request_headers = RequestHeadersDict({
        'Content-Type': 'application/test',
        'Host': 'test.test.test',
        'Content-Length': 20,
        'If-Modified-Since': 'test',
        'Connection': 'keep-alive',
        'Cookie': 'test=test'
    })
    session.update_headers(request_headers)
    assert session.update_headers({}) == {
        'Host': 'test.test.test',
        'Connection': 'keep-alive',
        'Content-Length': 20,
        'Cookie': {
            'test': {'value': 'test'}
        }
    }


# Generated at 2022-06-12 00:22:43.608262
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=DEFAULT_SESSIONS_DIR)
    session['cookies'] = {}
    session['cookies']['a'] = {'value': 'aaa'}
    session['cookies']['b'] = {'value': 'bbb'}
    session['cookies']['c'] = {'value': 'ccc'}
    session.remove_cookies(['a', 'b'])
    assert not any(('a', 'b') == (name, session['cookies'][name]['value']) for name in session['cookies'])
    assert session['cookies']['c']['value'] == 'ccc'
    session.remove_cookies(['c'])
    assert not session['cookies']

# Generated at 2022-06-12 00:22:53.870602
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(os.path.join(DEFAULT_SESSIONS_DIR, 'test', 'test.json'))
    s['cookies'] = {
        'cookie_name1': {'value': 'cookie_value1', 'path': '/'},
        'cookie_name2': {'value': 'cookie_value2', 'path': '/', 'secure': True},
        'cookie_name3': {'value': 'cookie_value3', 'path': '/', 'expires': 'Fri, 01-Jan-2038 08:00:00 GMT'},
    }
    s.remove_cookies(names=['cookie_name1', 'cookie_name2', 'cookie_name3'])
    assert len(s['cookies']) == 0



# Generated at 2022-06-12 00:23:03.079051
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from requests.cookies import RequestsCookieJar
    from httpie.sessions import Session
    session = Session(path = "test_session.json")
    session.load()
    tmp_cookies = RequestsCookieJar()
    tmp_cookies.set_cookie(create_cookie('name1', 'value1'))
    tmp_cookies.set_cookie(create_cookie('name2', 'value2'))
    tmp_cookies.set_cookie(create_cookie('name3', 'value3'))
    session.cookies = tmp_cookies
    session.save()
    session.remove_cookies(['name1', 'name3'])
    session.load()
    expect_cookies = RequestsCookieJar()

# Generated at 2022-06-12 00:23:08.873944
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = Path("test_session.json")
    session = Session(session_path)
    session['cookies'] = {"cookie1": {'value': 'value1', 'domain': 'cookie1.com'},
                          "cookie2": {'value': 'value2', 'domain': 'cookie2.com'}}
    session.remove_cookies(["cookie1"])
    assert session['cookies']['cookie2']['value'] == 'value2'
    os.remove(session_path)

# Generated at 2022-06-12 00:23:12.845933
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    s['cookies'] = {'a':{},'b':{}, 'c':{} }
    s.remove_cookies(['b','d','c'])
    assert s['cookies'] == {'a':{}}

# Generated at 2022-06-12 00:23:16.962395
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('session_test')
    s['cookies'] = {'a' : 2, 'b': 3}
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b' : 3}

# Generated at 2022-06-12 00:23:24.974592
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('.')
    sess['cookies'] = {
        'c1': {'value': 'v1', 'expires': 'e1'},
        'c2': {'value': 'v2', 'expires': 'e2'},
        'c3': {'value': 'v3', 'expires': 'e3'},
    }
    sess.remove_cookies(['c1', 'c2'])
    assert sess['cookies'] == {
        'c3': {'value': 'v3', 'expires': 'e3'}
    }

# Generated at 2022-06-12 00:23:32.179369
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path("/tmp/test.json"))
    session.update_headers({'Cookie':'a=1; b=2; c=3'})
    assert session.cookies.__repr__() == '<RequestsCookieJar[<Cookie a=1 for test.org/>, <Cookie b=2 for test.org/>, <Cookie c=3 for test.org/>]>'
    session.remove_cookies(('a', 'None'))
    assert session.cookies.__repr__() == '<RequestsCookieJar[<Cookie b=2 for test.org/>, <Cookie c=3 for test.org/>]>'

# Generated at 2022-06-12 00:23:39.241612
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # initialize
    session = Session(path = "session")
    session["cookies"] = {}
    session["cookies"]["a"] = {}
    session["cookies"]["b"] = {}
    session["cookies"]["c"] = {}

    # test
    session.remove_cookies(["a", "c"])

    # verify
    assert "a" not in session["cookies"]
    assert "b" in session["cookies"]
    assert "c" not in session["cookies"]

# Generated at 2022-06-12 00:23:46.693307
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/foo')
    cookies = {}
    for i in range(5):
        cookies['cookie' + str(i)] = {'value': i }
    s['cookies'] = cookies
    s.remove_cookies(['cookie0', 'cookie2', 'cookie4'])
    assert s['cookies'] == {'cookie1': {'value': 1 }, 'cookie3': {'value': 3 }}

# Generated at 2022-06-12 00:24:02.836199
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Prepare
    session = Session('testFile')
    session['cookie1'] = 'cookie1Value'
    session['cookie2'] = 'cookie2Value'

    # Assert
    assert session['cookie1'] is not None
    assert session['cookie2'] is not None
    
    # Execute
    session.remove_cookies(['cookie1'])
    # Assert
    assert session['cookie1'] is None
    assert session['cookie2'] is not None

# Generated at 2022-06-12 00:24:07.032967
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    session = Session("test")
    session['cookies'] = {'a':{'value':'1'}}
    # Act
    import json
    session.remove_cookies(['a'])
    'a' in json.dumps(session['cookies'])
    # Assert
    assert not 'a' in json.dumps(session['cookies'])

# Generated at 2022-06-12 00:24:09.534881
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    a=Session.remove_cookies('[username,password]')
    assert a=='None'

# Generated at 2022-06-12 00:24:16.494358
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/path')
    session['cookies'] = {'x': 1}
    assert session['cookies'] == {'x': 1}
    session.remove_cookies(names=['x'])
    assert session['cookies'] == {}
    session['cookies'] = {'x': 1, 'y': 2}
    assert session['cookies'] == {'x': 1, 'y': 2}
    session.remove_cookies(names=['x'])
    assert session['cookies'] == {'y': 2}
    session.remove_cookies(names=['z'])
    assert session['cookies'] == {'y': 2}
    session.remove_cookies(names=['y'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:24:27.000250
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Remove all cookies set in a session
    session: Session = Session(path='/home/user/.httpie/sessions/example.com/test.json')
    session.update_headers(request_headers={'Cookie': 'key1=value1; key2=value2'})
    assert len(session['cookies']) == 2
    session.remove_cookies(['key1', 'key2'])
    assert session['cookies'] == {}
    # Remove some cookies of a session
    session: Session = Session(path='/home/user/.httpie/sessions/example.com/test.json')
    session.update_headers(request_headers={'Cookie': 'key1=value1; key2=value2; key3=value3'})
    assert len(session['cookies']) == 3
    session

# Generated at 2022-06-12 00:24:31.814998
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}, 'c': {'value': '3'}}
    session.remove_cookies(['a', 'b'])
    assert len(session['cookies']) == 1



# Generated at 2022-06-12 00:24:39.364518
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Unit test for method remove_cookies of class Session
    """
    s = Session('')
    s['cookies'] = {'a':1}
    s.remove_cookies(['a'])
    assert s['cookies'] == {}
    s['cookies'] = {'a':1}
    s.remove_cookies(['b'])
    assert s['cookies'] == {'a':1}


# Generated at 2022-06-12 00:24:47.733735
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('sessions/test.json')
    session['cookies'] = {
        'name1': {'value': 'val1', 'httponly': True},
        'name2': {'value': 'val2', 'httponly': True}
    }
    session.remove_cookies(['name2'])
    assert 'name2' not in session['cookies']
    assert session['cookies'] == {
        'name1': {'value': 'val1', 'httponly': True}
    }



# Generated at 2022-06-12 00:24:51.222536
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie_one':'value_one', 'cookie_two':'value_two'}
    session.remove_cookies(['cookie_one'])
    assert session['cookies']['cookie_two'] == 'value_two'
    assert 'cookie_one' not in session['cookies']

# Generated at 2022-06-12 00:24:58.278920
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/path/1')
    session['cookies'] = {
        'cookie1': {'value': 'val1'},
        'cookie2': {'value': 'val2'},
    }
    assert session['cookies'] == {'cookie1': {'value': 'val1'}, 'cookie2': {'value': 'val2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {'cookie1': {'value': 'val1'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {}


# Generated at 2022-06-12 00:25:22.758841
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    import json

    s = Session('/tmp/test')
    s['cookies'] = {
        'a': {'value': '1'}, 'b': {'value': '2'}, 'c': {'value': '3'}
    }

    s.remove_cookies(['a'])
    assert json.loads(json.dumps(s, indent=4)) == {
        'headers': {}, 'cookies': {'b': {'value': '2'}, 'c': {'value': '3'}},
        'auth': {'type': None, 'username': None, 'password': None}
    }

    s.remove_cookies(['b', 'c'])

# Generated at 2022-06-12 00:25:24.784309
# Unit test for constructor of class Session
def test_Session():
    session = Session("/home/ahmedelgabri/.config/httpie/sessions/localhost/s.json")


# Generated at 2022-06-12 00:25:29.624394
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    path = Path('path1')
    s = Session(path)
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}
    assert s.path == path
    assert s.helpurl == 'https://httpie.org/doc#sessions'
    assert s.about == 'HTTPie session file'


# Generated at 2022-06-12 00:25:39.103084
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from requests.auth import HTTPBasicAuth

    filename = 'session.json'
    path = Path(filename).resolve()
    session = Session(path)

    assert session._path == path
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

    session.auth = {'type': 'basic', 'raw_auth': 'user:password'}
    assert session.auth == HTTPBasicAuth('user', 'password')

    headers = RequestHeadersDict({'Accept': 'application/json'})
    session.update_headers(headers)
    assert headers == RequestHeadersDict({'Accept': 'application/json'})
    assert session['headers']

# Generated at 2022-06-12 00:25:40.079871
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert True


# Generated at 2022-06-12 00:25:50.491871
# Unit test for constructor of class Session
def test_Session():
    import os
    import os.path
    import stat
    import json
    import pytest

    # Test constructor
    session = Session("test")
    assert type(session) == Session
    assert session.path != None
    assert session.path == "test.json"

    # Test case where file is not found
    # os.path.exists("test.json") == False
    assert os.path.exists("test.json") == False

    # Test case where file exists
    # os.path.exists("test.json") == True
    assert os.path.exists("test.json") == True

    # Test if loaded file is in JSON format
    with open("test.json") as json_file:
        # Test if loaded file is in dict format
        data = json.load(json_file)

# Generated at 2022-06-12 00:25:55.963875
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    testSession = Session('Session1')
    testSession['cookies'] = {'cookie1':{}}
    testSession.remove_cookies('cookie1')
    assert('cookie1' not in testSession['cookies'].keys())
    testSession['cookies'] = {'cookie1':{}}
    testSession.remove_cookies('cookie2')
    assert('cookie1' in testSession['cookies'].keys())



# Generated at 2022-06-12 00:26:02.187696
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = '/tmp/test_Session_remove_cookies/session.json'
    session = Session(session_path)
    jar = RequestsCookieJar()
    jar.set_cookie(create_cookie('cookie1', 'value1'))
    jar.set_cookie(create_cookie('cookie2', 'value2'))
    jar.set_cookie(create_cookie('cookie3', 'value3'))
    session.cookies = jar
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {'cookie1': {'value': 'value1'}, 'cookie3': {'value': 'value3'}}

# Generated at 2022-06-12 00:26:11.924434
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name1 = '123'
    host1 = 'www.baidu.com'
    url1 = "https://www.baidu.com"
    # url2 = "http://www.baidu.com"
    session_1 = get_httpie_session(config_dir, session_name1, host1, url1)
    # session_2 = get_httpie_session(config_dir, session_name1, host1, url2)
    # session_3 = get_httpie_session(config_dir, session_name1, None, url2)


test_get_httpie_session()

# Generated at 2022-06-12 00:26:20.289681
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    h = RequestHeadersDict()
    h['X-Arg'] = 'Value'
    h['X-FOO'] = 'bar'
    h['Content-Type'] = 'application/json'
    h['Cookie'] = 'key1=value1; key2=value2'
    s = Session('test_update_headers.json')
    s.update_headers(h)
    assert s['headers'] == {'X-Arg': 'Value', 'X-FOO': 'bar'}
    assert s['cookies'] == {'key1': {'value': 'value1'}, 'key2': {'value': 'value2'}}

# Generated at 2022-06-12 00:26:37.817970
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('somepath')
    session.update_headers({'some': 'value', 'Content-Type': 'text'})
    assert session.headers == {'some': 'value'}

# Generated at 2022-06-12 00:26:42.226843
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('./')
    session_name = "test"
    host = "https://httpie.org"
    url = host + "/hello"
    result = get_httpie_session(config_dir, session_name, host, url)
    assert isinstance(result, Session)

# Generated at 2022-06-12 00:26:52.561429
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('path')
    request_headers = {'Content-Length': '123', 'X-Foo': 'bar'}
    session.update_headers(request_headers)
    request_headers0 = {'Content-Length': '', 'X-Foo': 'bar'}
    session.update_headers(request_headers0)
    request_headers1 = {'Content-Length': None, 'X-Foo': 'bar'}
    session.update_headers(request_headers1)
    request_headers2 = {'Content-Type': 'application/json', 'X-Foo': 'bar'}
    session.update_headers(request_headers2)
    request_headers3 = {'Content-Type': 'application/json', 'X-Foo': 'bar', 'Cookie': 'name=value'}


# Generated at 2022-06-12 00:26:57.608733
# Unit test for constructor of class Session
def test_Session():
    session = Session('test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    assert session.helpurl == 'https://httpie.org/doc#sessions'
    assert session.about == 'HTTPie session file'



# Generated at 2022-06-12 00:27:09.221091
# Unit test for constructor of class Session
def test_Session():
    # Test 1: create a new session
    session1 = Session("session1")
    assert "session1" == session1.path
    assert {} == session1["headers"]
    assert {} == session1["cookies"]
    assert "None" == session1["auth"]["type"]
    assert "None" == session1["auth"]["username"]
    assert "None" == session1["auth"]["password"]
    assert session1.headers == RequestHeadersDict()
    assert session1.cookies == RequestsCookieJar()
    assert session1.auth == None
    session1.path = "session2"
    assert "session2" == session1.path
    session1.load()
    assert {} == session1["headers"]
    assert {} == session1["cookies"]

# Generated at 2022-06-12 00:27:12.201033
# Unit test for constructor of class Session
def test_Session():
    config_dir = DEFAULT_SESSIONS_DIR
    session_name = "test.json"
    
    session = get_httpie_session(config_dir, session_name, None, None)

# Generated at 2022-06-12 00:27:15.618648
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/home/leo/.config/httpie')
    session_name = 'session_name'
    host = 'http://httpbin.org/'
    url = 'http://httpbin.org/'
    x = get_httpie_session(config_dir, session_name, host, url)
    assert isinstance(x, Session)

# Generated at 2022-06-12 00:27:24.409220
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/home/InnoFang/.config')
    session_name = 'session_name'
    host = 'baidu.com'
    url = 'https://baidu.com'
    result = get_httpie_session(config_dir, session_name, host, url)
    assert result.path == Path('/home/InnoFang/.config/sessions/baidu_com/session_name.json')
    assert result.headers == {}
    assert result.cookies == RequestsCookieJar()
    assert result.auth == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-12 00:27:27.595351
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test55.json')
    s['cookies'] = {'name1':'value1', 'name2':'value2'}
    s.remove_cookies(['name1'])
    assert s['cookies'] == {'name2':'value2'}

# Generated at 2022-06-12 00:27:31.608444
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_session = Session('')
    test_session['cookies'] = {'1':'one','2':'two','3':'three'}
    test_session.remove_cookies(['1','2'])
    assert test_session['cookies'] == {'3':'three'}

# Generated at 2022-06-12 00:28:09.618141
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://www.example.com'
    session_folder = Path(os.path.expanduser('~/.config/httpie/sessions'))
    session_folder.mkdir()
    session_folder1 = session_folder / 'www.example.com'
    session_folder1.mkdir()
    session_folder2 = session_folder / 'www_example.com'
    session_folder2.mkdir()
    session_file = session_folder1 / 'session_1.json'
    session_file.touch()
    session_file2 = session_folder2 / 'session_2.json'
    session_file2.touch()
    host = 'www.example.com'
    session_name = 'session_2'


# Generated at 2022-06-12 00:28:19.489283
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test_session")
    session.update_headers(RequestHeadersDict({}))
    assert session['headers'] == {}
    assert session['cookies'] == {}

    session.update_headers(RequestHeadersDict({'content-length':'123'}))
    assert session['headers'] == {}
    assert session['cookies'] == {}

    session.update_headers(RequestHeadersDict({'Cookie':'test=test'}))
    assert session['headers'] == {}
    assert session['cookies'] == {'test': {'value': 'test'}}

    session.update_headers(RequestHeadersDict({'User-Agent':'test'}))
    assert session['headers'] == {'User-Agent': 'test'}

# Generated at 2022-06-12 00:28:24.260206
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('abc')
    cookies = { 'name1': {'value':'value1', 'path':'/path1', 'secure':True, 'expires':'expires1'},
                'name2': {'value':'value2', 'path':'/path2', 'secure':True, 'expires':'expires2'},
                'name3': {'value':'value3', 'path':'/path3', 'secure':True, 'expires':'expires3'} }
    s['cookies'] = cookies
    s.remove_cookies(['name1', 'name3'])
    assert s['cookies'] == {'name2': {'value':'value2', 'path':'/path2', 'secure':True, 'expires':'expires2'}}

# Generated at 2022-06-12 00:28:31.001997
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir = os.path.join(os.path.expanduser("~"), ".httpie")
    session_name = 'test_session'
    url = 'http://www.baidu.com'
    cookie_name = 'name'
    cookie_value = 'value'
    session = get_httpie_session(config_dir, session_name, None, url)
    session['cookies'] = {}
    session.cookies.set_cookie(create_cookie(
        name=cookie_name, value=cookie_value))
    assert session['cookies'][cookie_name]['value'] == cookie_value
    session.remove_cookies([cookie_name])
    assert cookie_name not in session['cookies']

# Generated at 2022-06-12 00:28:31.402902
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    pass

# Generated at 2022-06-12 00:28:34.078037
# Unit test for constructor of class Session
def test_Session():
    path = "test/test.json"
    session = Session(path)
    assert session['headers'] == {}
    assert session['cookies'] == {} 
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-12 00:28:36.315767
# Unit test for constructor of class Session
def test_Session():
    s = Session("/test/test.json")
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-12 00:28:44.761963
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    cookies = [
        {'name': 'a', 'value': '1'},
        {'name': 'b', 'value': '2'},
        {'name': 'c', 'value': '3'},
    ]
    session.cookies = RequestsCookieJar()
    for cookie in cookies:
        session.cookies.set_cookie(create_cookie(
            name=cookie['name'], value=cookie['value']))
    
    session.remove_cookies(['a', 'c'])
    cookies = [cookie for cookie in session.cookies]

    assert len(cookies) == 1
    assert cookies[0].value == '2'

# Generated at 2022-06-12 00:28:47.668100
# Unit test for constructor of class Session
def test_Session():
    session = Session("/tmp/test_session.json")
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-12 00:28:52.056694
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(session_name='xyz')
    s['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}, 'c': {'value': '3'}}
    s.remove_cookies(['a', 'b'])
    assert s['cookies'] == {'c': {'value': '3'}}