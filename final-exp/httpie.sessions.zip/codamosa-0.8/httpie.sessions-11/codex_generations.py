

# Generated at 2022-06-12 00:19:52.471401
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    sess = Session(path='test.json')
    sess['headers'] = {'X-debug': '42', 'X-my-header': 'my-val'}
    headers = RequestHeadersDict([('X-DEBUG', '3'), ('X-MY-HEADER', 'new')])
    sess.update_headers(headers)
    assert sess['headers'] == {'X-DEBUG': '3', 'X-MY-HEADER': 'new'}

# Generated at 2022-06-12 00:19:57.980745
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/foo.json')
    session.update_headers({'Some-Header': 'Some-Value', 'Cookie': 'Cookie1=Value1;'})

    assert session['headers'] == {'Some-Header': 'Some-Value'}
    assert session['cookies'] == {'Cookie1': {'value': 'Value1'}}

# Generated at 2022-06-12 00:20:05.908165
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path(__file__).parent / 'sample_session.json')
    print(session)
    session.update_headers({'teste': 'test', 'teste2': 'test2'})
    assert session['headers']['teste'] == 'test'
    assert session['headers']['teste2'] == 'test2'
    assert len(session.cookies) == len(session['cookies'])

# Generated at 2022-06-12 00:20:09.943932
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict({
        'Cookie': 'name=value',
        'Content-Length': '10'
    })
    session = Session('/')
    session.update_headers(headers)
    assert session.headers['Content-Length'] == '10'
    assert session.cookies['name'].value == 'value'

# Generated at 2022-06-12 00:20:22.427006
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('./session')
    s.headers['abcd'] = 'dddd'
    s.headers['Content-Type'] = 'aaaa'
    s.headers['If-Modified-Since'] = 'bbbb'
    s.headers['Accept'] = 'cccc'
    r = RequestHeadersDict()
    r['abcd'] = 'dddd'
    r['Content-Type'] = 'eeee'
    r['If-Modified-Since'] = 'ffff'
    r['Accept'] = 'hhhh'
    s.update_headers(r)
    assert s.headers['abcd'] == 'dddd'
    assert s.headers['Content-Type'] == 'eeee'
    assert s.headers['If-Modified-Since'] == 'ffff'
    assert s.headers['Accept'] == 'hhhh'


# Generated at 2022-06-12 00:20:24.243625
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_dict = RequestHeadersDict({'Content-Type':123,'Content-Length':456,'Content-Range':789})
    session = Session(path = 'http')
    session.update_headers(headers_dict)


# Generated at 2022-06-12 00:20:29.861703
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('~/')
    session.update_headers([
        ('accept', 'application/json'),
        ('cache-control', 'no_cache'),
        ('Cookie', 'session=123456')
    ])

    assert session['headers'] == {'accept': 'application/json', 'cache-control': 'no_cache'}
    assert session['cookies'] == {'session': {'value': '123456'}}

# Generated at 2022-06-12 00:20:32.035798
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='path')
    session.update_headers('')

# Generated at 2022-06-12 00:20:42.591052
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path())

    session.update_headers({
        'Client-Header': 'value',
        'Another-Header': 'anotherValue',
        'If-Unmodified-Since': 'Sun, 06 Nov 1994 08:49:37 GMT',
        'If-None-Match-Header': 'W/"abc"',
        'Cache-Control': 'max-age=0',
        'Cookie-Header': 'empty_cookie=',
        'Cookie-Header-2': 'name=value; path=/cookie_path'
    })

    assert session['cookies']['empty_cookie']['value'] == ''
    assert session['cookies']['name']['value'] == 'value'


# Generated at 2022-06-12 00:20:48.192523
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    set_headers = dict()
    set_headers['A'] = '1' 
    set_headers['B'] = '2'
    set_headers['If-Modified-Since'] = 'a'
    set_headers['Cookie'] = 'a=2; b=3'
    session = Session('/')
    session.update_headers(set_headers)
    assert session.headers['A'] == '1'
    assert session.headers['B'] == '2'
    assert not 'If-Modified-Since' in session.headers
    assert session.cookies['a'] == create_cookie('a', '2')
    assert session.cookies['b'] == create_cookie('b', '3')

# Generated at 2022-06-12 00:20:59.907298
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = Path(__file__).parent / 'files' / 'sessions' / 'tmp.json'
    if session_path.exists():
        session_path.unlink()
    s = Session(str(session_path))
    s.update({'cookies': {'a': {'value': 'aaa'}, 'b': {'value': 'bbb'}}})
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b': {'value': 'bbb'}}



# Generated at 2022-06-12 00:21:09.231337
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = "session0.json"
    session = Session(path=session_path)
    with open(session_path, 'w') as f:
        f.write("""\
{
    "headers": {},
    "cookies": {
        "cookie0": {
            "value": "value0"
        },
        "cookie1": {
            "value": "value1"
        }
    },
    "auth": {
        "type": null,
        "username": null,
        "password": null
    }
}
""")
    session.load()
    session.remove_cookies(["cookie0"])
    assert session["cookies"] == {
        "cookie1": {
            "value": "value1"
        }
    }

    session.remove_cookies([])

# Generated at 2022-06-12 00:21:13.975381
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict({'Content-Type': 'test-type'})
    session = Session(path='test')
    session.update_headers(request_headers)
    new_request_headers = RequestHeadersDict({'Content-Type': 'test-type'})
    assert session.headers == new_request_headers

# Generated at 2022-06-12 00:21:18.211420
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    session = Session(DEFAULT_SESSIONS_DIR)
    session['headers'] = {}
    assert session['headers'] == {}
    session.update_headers(RequestHeadersDict({'hello':'world'}))
    assert session['headers'] == {'hello':'world'}
# test_Session_update_headers()

# Generated at 2022-06-12 00:21:24.376787
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    session.update_headers({'a':'a','b':'b'})
    assert session['headers'] == {'a':'a','b':'b'}
    session.update_headers({'c':'c'})
    assert session['headers'] == {'a':'a','b':'b','c':'c'}
    session.update_headers({'C':'cc'})
    assert session['headers'] == {'a':'a','b':'b','c':'cc'}

# Generated at 2022-06-12 00:21:36.008286
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.compat import is_py26

    request_headers = RequestHeadersDict()
    request_headers['Content-Type'] = 'application/json'

    session = Session('')
    assert 'headers' not in session
    session.update_headers(request_headers)
    assert request_headers == session['headers']

    session = Session('')
    assert 'headers' not in session
    session.update_headers(None)

    # Test if headers with ignored prefixes are not stored in the session
    session = Session('')
    request_headers['Content-Type'] = 'application/json'
    request_headers['If-Match'] = '123'
    session.update_headers(request_headers)
    assert 'Content-Type' not in session['headers']

# Generated at 2022-06-12 00:21:39.274707
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = Path('')
    s = Session(session_path)
    s['cookies'] = {}
    s['cookies']['a'] = 'b'
    s.remove_cookies(['c'])
    s.remove_cookies(['a'])
    assert 'a' not in s['cookies']

# Generated at 2022-06-12 00:21:41.577035
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    HttpSession = Session()
    HttpSession.update_headers(RequestHeadersDict({"X-Kong": "Test"}))
    assert HttpSession.headers["X-Kong"] == "Test"


# Generated at 2022-06-12 00:21:49.550806
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # create a new instance of the class Session
    session = Session('/home/httpie/.httpie/sessions/localhost/httpbin.json')
    session.load()
    # assert that a cookie named my-cookie exists
    session['cookies']['my-cookie'] = {}
    assert 'my-cookie' in session['cookies']
    # unit test for method remove_cookies
    session.remove_cookies(['my-cookie'])
    assert 'my-cookie' not in session['cookies']



# Generated at 2022-06-12 00:21:51.487208
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Note: It is not easy to make a test that exhaustively tests this
    # function. For now, the most comprehensive test is to run its code in
    # the function "main" of httpie/cli/main.py.
    session = Session("")
    session.update_headers({"User-agent" : "Mozilla"})
    assert ("User-agent" in session['headers']) == True

# Generated at 2022-06-12 00:22:06.220814
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    key1 = 'key1'
    key2 = 'key2'
    value1 = 'value1'
    value2 = 'value2'

    sess = Session('.')
    sess.cookies = RequestsCookieJar()
    sess.cookies.set(key1, value1)
    sess.cookies.set(key2, value2)
    assert len(sess.cookies) == 2

    sess.remove_cookies([key2])
    assert len(sess.cookies) == 1
    assert key1 in sess.cookies

    sess.remove_cookies([key1])
    assert len(sess.cookies) == 0
    assert key1 not in sess.cookies

# Generated at 2022-06-12 00:22:12.471618
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    headers = {
        'Cookie': 'foo=bar; baz=42',
        'Content-Length': '24',
        'Content-Type': 'text/plain',
        'If-None-Match': 'foobar',
        'Accept-Language': 'en-US',
    }
    session.update_headers(headers)
    assert session.headers == {'Accept-Language': 'en-US'}
    assert session.cookies == {'foo': 'bar', 'baz': '42'}

# Generated at 2022-06-12 00:22:21.171395
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict()
    headers['name'] = 'value'
    headers['User-Agent'] = 'HTTPie/test'
    headers['content-type'] = 'application/json'
    session = Session(path=Path('test.json'))
    session.update_headers(headers)
    assert session.headers['name'] == 'value'
    assert 'User-Agent' not in session.headers
    assert 'Content-Type' not in session.headers
    assert session.auth == None
    assert session.cookies == RequestsCookieJar()
    session.prompting = False
    session['cookies']['name'] = {'value':'val', 'path':'path', 'secure':True, 'expires':0}
    assert session.cookies.get('name').value == 'val'
    session

# Generated at 2022-06-12 00:22:31.008932
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    headers = RequestHeadersDict()
    headers.append('User-Agent', 'httpie/0.9.3')
    session.update_headers(headers)
    assert not session.headers
    session = Session('')
    headers = RequestHeadersDict()
    headers.append('Content-Type', 'application/json')
    session.update_headers(headers)
    assert not session.headers
    session = Session('')
    headers = RequestHeadersDict()
    headers.append('Cookie', 'a=b')
    session.update_headers(headers)
    assert not session.headers
    session = Session('')
    headers = RequestHeadersDict()
    headers.append('Host', 'httpbin.org')
    session.update_headers(headers)
    assert session

# Generated at 2022-06-12 00:22:37.812055
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/path/to/session.json')
    session['cookies'] = {'cookie1': 'val1', 'cookie2': 'val2'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 'val2'}



# Generated at 2022-06-12 00:22:42.812567
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    jar = RequestsCookieJar()
    jar.set_cookie(create_cookie('deprecated', 'nope'))
    jar.set_cookie(create_cookie('bob', 'cool'))
    session = Session('/home/test/httpie_session.json')
    session.cookies = jar
    session.remove_cookies(['bob', 'deprecated'])
    assert ['deprecated'] == session.cookies.get_dict().keys()

# Generated at 2022-06-12 00:22:51.136866
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='')
    session['headers'] = {'hoge': 'huga'}
    session['cookies'] = {'hoge': 'huga'}

    session.update_headers({
        'test': 'test',
        'Content-Length': '100',
        'If-None-Match': 'a55',
        'Cookie': 'a=b'
    })

    assert session['headers'] == {'hoge': 'huga', 'test': 'test'}
    assert session['cookies'] == {'a': {'value': 'b'}}

# Generated at 2022-06-12 00:22:57.522173
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    header_1 = {'Accept': '*/*'}
    header_2 = {'User-Agent': 'curl/7.58.0'}
    header_3 = {'Host': 'httpbin.org'}
    header_4 = {'Content-type': 'application/json'}
    header_5 = {'Connection': 'keep-alive'}
    header_6 = {'If-Modified-Since': 'Tue, 27 Aug 2019 09:19:01 GMT'}
    header_7 = {'Cookie': 'Cookie_test'}
    #test case 1:
    session1 = Session('/test/test1.json')
    session1.update_headers(header_1)
    session1.update_headers(header_2)
    session1.update_headers(header_3)
   

# Generated at 2022-06-12 00:23:04.335515
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session.update_headers({'cookie': 'a=1; b=2; c=3; d=4'})
    assert session == {
        'auth': {'type': None, 'password': None, 'username': None},
        'cookies': {'a': {'value': '1'}, 'b': {'value': '2'}, 'c': {'value': '3'}, 'd': {'value': '4'}},
        'headers': {}
    }
    session.remove_cookies(['a', 'b'])

# Generated at 2022-06-12 00:23:12.145746
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    c = Session('/')
    c.cookies = RequestsCookieJar()
    c.cookies.set('bar', 'foo', path='/')
    c.cookies.set('foo', 'bar', domain='github.com')
    c.cookies.set('foo', 'baz')
    c.remove_cookies(['foo'])
    assert c.to_json() == '{"auth": {"type": null, "username": null, "password": null}, "cookies": {"bar": {"value": "foo", "path": "/"}}, "headers": {}}'

# Generated at 2022-06-12 00:23:27.753260
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # setup
    headers = RequestHeadersDict({"Content-type":"application/json", "Accept":"application/xml"})
    session = Session("session")
    session.update_headers(headers)
    # exercise
    stored_header = session.headers["Content-type"]
    # verify
    assert stored_header == "application/json"
    #cleanup


# Generated at 2022-06-12 00:23:38.951632
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    To test this method, we need to:
        1. we need to create headers and put them into a dict
        2. we need to create a Session object, S
        3. we need to call S.update_headers(headers)

    """
    headers = RequestHeadersDict({
        'User-Agent': 'curl/7.64.1',
        'Accept': '*/*',
    })
    header_names = []
    for header_name, header_value in headers.items(): 
        header_names.append(header_name)
        print(header_name, header_value)
    s = Session(path='Path')
    s.update_headers(b'headers')

    # assert len(header_names) == 1
    # assert header_names[0] == "User-Agent"

# Generated at 2022-06-12 00:23:45.250434
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(None)
    s.update_headers({"Content-Type": "application/json", "User-Agent": "HTTPie/X.X.X", "Cookie": "c1=v1;c2=v2"})
    assert s.headers == {"Content-Type": "application/json", "User-Agent": "HTTPie/X.X.X"}

# Generated at 2022-06-12 00:23:51.821101
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path('tests/fixtures/session.json'))
    session.load()
    cookies = session.cookies

    assert 'csrftoken' in cookies
    assert 'sessionid' in cookies

    session.remove_cookies(['csrftoken'])
    assert 'csrftoken' not in cookies
    assert 'sessionid' in cookies

    session.remove_cookies(['sessionid'])
    assert 'csrftoken' not in cookies
    assert 'sessionid' not in cookies

# Generated at 2022-06-12 00:23:55.160019
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict({
        'some-header': 'value',
        'other-header': 'value'
    })

    cookies = SimpleCookie({
        'key1': 'value1',
        'key2': 'value2'
    })

    s = Session(path='path')
    s.update_headers(headers)
    print(s)

# Generated at 2022-06-12 00:24:02.840830
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('irrelevant')
    session.update_headers({'auth': 'abc', 'content-type': 'application/json'})
    assert {'auth': 'abc', 'content-type': 'application/json'} == session['headers']
    session.update_headers({'auth': 'def', 'content-type': None})
    assert {'content-type': 'application/json'} == session['headers']
    session.update_headers({'auth': None})
    assert {'content-type': 'application/json'} == session['headers']

# Generated at 2022-06-12 00:24:10.180562
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/Users/yuhao/httpie/httpie/tests/resources/test.json')
    headers = {
        'Accept': 'application/json',
        'Cache-Contrl': 'no-cache',
        'Connection': 'keep-alive',
        'Content-Length': '0',
        'Content-Type': '*',
        'If-None-Match': '*',
        'Cookie': 'name=value',
        'User-Agent': 'HTTPie/0.9.9',
    }
    session.update_headers(headers)
    assert session['headers'] == {
        'Accept': 'application/json',
        'Cache-Contrl': 'no-cache',
        'Connection': 'keep-alive',
        'Content-Type': '*',
    }



# Generated at 2022-06-12 00:24:13.386458
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('dummy.json')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}



# Generated at 2022-06-12 00:24:24.625810
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_config_path = './test.config'
    test_session_name = 'test_update_headers'
    headers1 = {'Content-Type':'application/json', 'User-Agent': 'Request/python',
                'Cookie':'a=b'}
    headers2 = {'Content-Type':'application/json', 'User-Agent': 'Request/python',
                'Cookie':'c=d'}
    if os.path.exists(test_config_path):
        os.remove(test_config_path)
    s = Session(test_config_path)
    s.update_headers(headers1)
    assert s.headers['content-type'].lower() == 'application/json'
    assert s.headers['user-agent'].lower() == 'request/python'
    assert s

# Generated at 2022-06-12 00:24:30.805873
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session = Session(path='./test.json')
    session['headers'] = {'accept': 'application/json'}

    request_headers = RequestHeadersDict()
    request_headers['content-type'] = 'application/json'
    request_headers['accept'] = 'application/xml'

    session.update_headers(request_headers)

    assert session['headers']['content-type'] == 'application/json'
    assert session['headers']['accept'] == 'application/xml'



# Generated at 2022-06-12 00:24:50.719898
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = '~/.httpie/sessions/localhost/del_cookie.json'
    session = Session(path)
    session['cookies'] = {
        'cookie_1': {'value': 'cookie_1_value'},
        'cookie_2': {'value': 'cookie_2_value'},
        'cookie_3': {'value': 'cookie_3_value'},
        'cookie_4': {'value': 'cookie_4_value'},
    }
    session.remove_cookies(['cookie_1', 'cookie_2'])
    assert session['cookies'] == {
        'cookie_3': {'value': 'cookie_3_value'},
        'cookie_4': {'value': 'cookie_4_value'},
    }

# Generated at 2022-06-12 00:24:56.511957
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("./sessions/test.json")
    session.cookies.set('a', '1')
    session.cookies.set('b', '2')
    assert 'a' in session['cookies']
    assert 'b' in session['cookies']
    session.remove_cookies(['a'])
    assert 'a' not in session['cookies']
    assert 'b' in session['cookies']

# Generated at 2022-06-12 00:25:04.048128
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    session = Session("test")
    session['cookies'] = {'name1': 'value1', 'name2': 'value2', 'name3': 'value3'}

    # Act
    session.remove_cookies(['name1', 'name2'])

    # Assert
    # name1 and name2 should be deleted from the cookies, name3 should remain untouched
    assert session['cookies'] == {'name3': 'value3'}

# Generated at 2022-06-12 00:25:12.909922
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('dummy')
    import io
    file = io.StringIO(u'''{
        "headers": {
            "Content-Type" : "text/html; charset=UTF-8",
            "Content-Length" : "348"
        },
        "cookies" : {
            "cookie1" : {"value": "dummy"},
            "cookie2" : {"value": "dummy"},
            "cookie3" : {"value": "dummy"}
        }
    }''')

    session.load(file)
    session.remove_cookies(['cookie1', 'cookie3'])
    assert {'cookie1', 'cookie3'} == set(session['cookies'].keys())

# Generated at 2022-06-12 00:25:21.152362
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    '''
    This test removes cookies of the session and checks that they are
    removed successfully.
    '''
    # Cookies to add
    cookies = [
        create_cookie('test_cookie1', 'test_cookie1_val'),
        create_cookie('test_cookie2', 'test_cookie2_val'),
    ]
    # Exception message if the test fails
    exception_msg = 'The cookie was not removed successfully'

    # Init session
    session_path = 'test_Session_remove_cookies.json'
    session = Session(session_path)

    # Add cookies to session
    for cookie in cookies:
        session['cookies'][cookie.name] = {'value': cookie.value}

    # Check that the cookies are added
    assert len(session['cookies']) == len(cookies), exception_msg



# Generated at 2022-06-12 00:25:25.100173
# Unit test for method update_headers of class Session
def test_Session_update_headers():
  session = Session('config_dir/sessions/demo.json')
  session.load()
  session.update_headers({'Cookie': 'name=demo'})
  assert session['cookies'] == {'name': {'value': 'demo'}}

# Generated at 2022-06-12 00:25:29.393361
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test remove_cookies method
    session = Session('/tmp/test.json')
    session['cookies'] = {'c1': {'value': 'v1'}, 'c2': {'value': 'v2'}}
    session.remove_cookies(['c2'])
    assert session['cookies'] == {'c1': {'value': 'v1'}}


# Generated at 2022-06-12 00:25:35.252715
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies_dict = {'session':{'value':'xyz'},'visited':{'value':1}}
    session = Session(path='path')
    session['cookies'] = cookies_dict
    session.remove_cookies(['session'])
    assert session['cookies'] == {'visited':{'value':1}}

# Generated at 2022-06-12 00:25:38.303911
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    session.remove_cookies(['a', 'd'])
    assert session['cookies'] == {'b': 2, 'c': 3}

# Generated at 2022-06-12 00:25:48.123904
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json
    import os
    import tempfile
    temp = tempfile.gettempdir()
    filename = os.path.join(temp, 'test.json')

    session = Session(filename)
    session.update_headers({'Cookie': 'test=test'})

    # Remove test Cookie
    session.remove_cookies(['test'])

    # Check if cookie is removed
    assert session.headers.get('Cookie') is None

    # Remove non existing Cookie
    session.remove_cookies(['test2'])

    # Check if cookies is not set
    assert session.headers.get('Cookie') is None

# Generated at 2022-06-12 00:26:13.609421
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='')
    assert session['cookies'] == {}

    session['cookies'] = {'cookie1': '', 'cookie2': ''}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {'cookie1': ''}

    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {}

    session['cookies'] = {'cookie1': '', 'cookie2': '', 'cookie3': ''}
    session.remove_cookies(['cookie1', 'cookie3'])
    assert session['cookies'] == {'cookie2': ''}

# Generated at 2022-06-12 00:26:19.407131
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_remove_cookies')
    session['cookies'] = {'cookieA': {'value': 'valA', 'path': '/pathA'},
                          'cookieB': {'value': 'valB', 'path': '/pathB'}}
    session.remove_cookies(['cookieA'])
    assert 'cookieA' not in session['cookies']
    assert 'cookieB' in session['cookies']

# Generated at 2022-06-12 00:26:28.340406
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.models import CookiesDict
    from httpie.plugins.builtin import HTTPBasicAuth
    from requests.auth import HTTPBasicAuth as RequestsHTTPBasicAuth

    session_path = 'httpie/config/sessions/test.json'
    session = Session(session_path)
    session['cookies'] = {'name': 'value'}
    session['auth'] = {
        'type': "Basic",
        'username': "user",
        'password': "pass"
    }
    session['headers'] = {'Host': "www.example.com"}

    session.remove_cookies(['name'])
    assert session['cookies'] == {}
    assert isinstance(session.cookies, RequestsCookieJar)
    assert session.cookies == RequestsCookieJar()

# Generated at 2022-06-12 00:26:33.460221
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    cookies = {'name': '', 'name1': ''}
    session['cookies'] = cookies
    names = ['name']
    session.remove_cookies(names)
    assert len(session['cookies']) == 1
    assert session['cookies'] == {'name1': ''}

# Generated at 2022-06-12 00:26:39.070835
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    assert session['cookies'] == {}
    session['cookies']['test1'] = {'test1_1': 'test1_1'}
    session['cookies']['test2'] = {'test2_1': 'test2_1'}
    session['cookies']['test3'] = {'test3_1': 'test3_1'}
    session['cookies']['test4'] = {'test4_1': 'test4_1'}
    assert session['cookies'].keys() == {'test1', 'test2', 'test3', 'test4'}
    session.remove_cookies(['test2', 'test3'])

# Generated at 2022-06-12 00:26:44.292736
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('export')
    session['cookies'] = {'cookie1': {'value': 'cookie1_value'},
                          'cookie2': {'value': 'cookie2_value'}}
    names = ['cookie1']
    session.remove_cookies(names)
    assert session['cookies'] == {'cookie2': {'value': 'cookie2_value'}}

# Generated at 2022-06-12 00:26:50.489994
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path('./httpie/tests/test_session'))
    session.update_headers({'Cookie': 'clear=true'})
    session.update_headers({'Cookie': 'keep=true'})
    assert session.cookies == {'clear': 'true', 'keep': 'true'}
    session.remove_cookies(['clear'])
    assert session.cookies == {'keep': 'true'}

# Generated at 2022-06-12 00:26:51.081057
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass  # TODO

# Generated at 2022-06-12 00:26:54.365653
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path = 'path')
    s['cookies'] = {'a': None, 'b': 'cookie-b'}
    s.remove_cookies(['a', 'b', 'c', 'd'])
    assert s['cookies'] == {}


# Generated at 2022-06-12 00:27:01.189967
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/data/test/test.json')
    assert {'type': None, 'username': None, 'password': None} == s.get('auth', None)
    s['cookies'] = {'a': {'value': 'a'}, 'b': {'value': 'b'}}
    s.remove_cookies(['a']);
    assert s['cookies'] == {'b': {'value': 'b'}}

# Generated at 2022-06-12 00:27:29.399048
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    mySession = Session("C:\\Users\\dxt94\\.config\\httpie\\sessions\\localhost\\my-first-session.json")

    mySession['cookies'] = {'name': 'John', 'age': '30', 'car': 'None'}
    mySession.remove_cookies(['age', 'car'])
    assert mySession['cookies'] == {'name': 'John'}
    mySession.remove_cookies(['name'])
    assert mySession['cookies'] == {}

# Generated at 2022-06-12 00:27:38.571072
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.compat import is_windows
    from httpie.session import Session
    from pathlib import Path

    import os

    config_dir = Path(os.path.dirname(__file__))
    session = Session(config_dir/'../../../httpie/config/sessions/httpbin.org/test.json')
    request_headers = RequestHeadersDict({'User-Agent': 'Test-User_Agent'})
    session.update_headers(request_headers)
    assert session.headers == RequestHeadersDict({'User-Agent': 'Test-User_Agent'})
    session.save()
    session_path = config_dir/'../../../httpie/config/sessions/httpbin.org/test.json'
   

# Generated at 2022-06-12 00:27:49.107950
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_dict = {'cookies': {'Mozilla': {'value': 'Mozilla sdk'}, 'Chrome': {'value': 'Chrome sdk'}}}
    session_instance = Session('test')
    session_instance.update(session_dict)
    session_instance.remove_cookies(['Mozilla'])
    assert 'cookies' in session_instance.keys()
    cookies = session_instance.get('cookies')
    assert len(cookies) == 1
    assert 'Chrome' in cookies.keys()
    assert 'Mozilla' not in cookies.keys()
    assert 'Mozilla sdk' not in cookies.values()

# Generated at 2022-06-12 00:27:54.828322
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    d = {'a': 'b', 'c': 'd', 'user-agent': 'HTTPie/0.9.9', 'e': 'f'}
    s = Session(path=None)
    s.update_headers(RequestHeadersDict(d))
    assert s['headers'] == {'a': 'b', 'c': 'd', 'e': 'f'}

# Generated at 2022-06-12 00:28:03.051675
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session.update({
        'cookies': {
            'foo': {'value': '1', 'secure': '1'},
            'bar': {'value': '2', 'secure': '0'},
            'baz': {'value': '3', 'secure': '1'},
        }
    })
    names = ['bar', 'baz', 'qux']
    session.remove_cookies(names)
    assert session == Session(None).update({
        'cookies': {
            'foo': {'value': '1', 'secure': '1'},
        }
    })


_default_session = Session(None)

# Generated at 2022-06-12 00:28:06.456485
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    p = Path('./test_data/sessions/Example.json')
    s = Session(p)
    s.load()
    assert len(s.cookies) == 2
    s.remove_cookies(['sessionid', 'XDEBUG_SESSION'])
    assert len(s.cookies) == 0

# Generated at 2022-06-12 00:28:10.048231
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=None)
    session['cookies'] = {'abc': {'value': 'abc'}, 'xyz': {'value': 'xyz'}}
    session.remove_cookies(['abc', 'xyz'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:28:20.174288
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.config import DEFAULT_SESSIONS_DIR
    import json
    import pytest

    path = DEFAULT_SESSIONS_DIR / 'example_com' / 'example_session.json'
    path.parent.mkdir(parents=True, exist_ok=True)

# Generated at 2022-06-12 00:28:25.577633
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/session.json')
    session['cookies']['cookie1'] = {'value': 'value1'}
    session['cookies']['cookie2'] = {'value': 'value2'}
    session['cookies']['cookie3'] = {'value': 'value3'}
    session.remove_cookies(names=['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}, 'cookie3': {'value': 'value3'}}

# Generated at 2022-06-12 00:28:32.682436
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # Case 1 - test with headers in session
    session = Session(path = 'my_path')
    session['headers']['header1'] = 'value1'
    session['headers']['header2'] = 'value2'

    # update session
    request_headers = RequestHeadersDict()
    request_headers['header2'] = 'new_value2'
    request_headers['header3'] = 'value3'
    request_headers['header4'] = None
    request_headers['user-agent'] = 'HTTPie/0.9.6'
    request_headers['cookie'] = 'cookie1=value1; cookie2=value2'

    session.update_headers(request_headers)

    # check if session is updated appropriately
    assert session['headers']['header1'] == 'value1'

# Generated at 2022-06-12 00:29:38.404223
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1' : {'value' : 'cookie1_value'},
                          'cookie2' : {'value' : 'cookie2_value'},
                          'cookie3' : {'value' : 'cookie3_value'},
                          'cookie4' : {'value' : 'cookie4_value'},
                          }
    session.remove_cookies(['cookie2', 'cookie4'])
    assert session['cookies'] == {'cookie1' : {'value' : 'cookie1_value'},
                                  'cookie3' : {'value' : 'cookie3_value'},
                                  }