

# Generated at 2022-06-12 00:19:53.919209
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    temp_headers = {'host': 'host-name',
                    'if-modified-since': 'datetime',
                    'content-type': 'text',
                    'user-agent': 'HTTPie/0.9.7',
                    'cookie': 'name=eliot'
                    }

    temp_session = Session("session-file")
    temp_session.update_headers(temp_headers)
    headers = temp_session.headers
    print(headers)
    assert headers == {'host': 'host-name',
                    'if-modified-since': 'datetime',
                    'content-type': 'text',
                    'user-agent': 'HTTPie/0.9.7'
                    }

    assert temp_session.cookies == {}
    temp_headers['cookie'] = 'name=eliot'
    temp_session.update

# Generated at 2022-06-12 00:20:06.711284
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    import json

    with open("/home/noor/Desktop/Semester7/FYP/HTTPie/httpie/tests/sessions/input.json") as input_file:
        session_input_data = json.load(input_file)
    input_file.close()

    session = Session("/home/noor/Desktop/Semester7/FYP/HTTPie/httpie/tests/sessions/session.json")

    for name, value in session_input_data['headers'].items():
        session['headers'][name] = value

    session['url'] = 'https://api.github.com'
    request_headers = session.headers


# Generated at 2022-06-12 00:20:18.650115
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    user_name = 'username'
    password = 'password'
    host = 'localhost'
    path = 'path'
    session_path = f'{host}/{user_name}.json'
    header_dict = {'Content-Type': 'application/json',
                   'If-Modified-Since': 'Tue, 13 Aug 2019 11:09:45 GMT',
                   'User-Agent': 'HTTPie/0.9.9',
                   'Host': host,
                   'Authorization': 'xxxxxxxxxxxxxxxxxxxxxxxxx',
                   'Cookie': 'key=value'}
    update_dict = {'Content-Type': 'application/json',
                   'Host': host,
                   'Cookie': 'key=value'}

# Generated at 2022-06-12 00:20:24.458592
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='/new/path')
    session.update_headers({'one': '1', 'two': '2'})
    assert session['headers'] == {'one': '1', 'two': '2'}
    session.update_headers({'one': '3', 'Content-Type': 'application/json'})
    assert session['headers'] == {'one': '3', 'two': '2'}



# Generated at 2022-06-12 00:20:29.145709
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='/path')
    request_headers_dict = {
        'Content-Type': 'application/json',
        'If-Modified-Since': 'Thu, 01 Jan 1970 00:00:00 GMT'
    }
    session.update_headers(request_headers_dict)
    assert(session['headers'] == {})

# Generated at 2022-06-12 00:20:41.262513
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')
    session.update_headers(RequestHeadersDict(
        [('header1', '_value1_'), ('header2', '_value2_')]))
    assert session.headers == RequestHeadersDict(
        [('header1', '_value1_'), ('header2', '_value2_')])

    # Weaker test with a dictionary comparison because of the random key
    # "Accept-Encoding".
    session_dict = session.dump()
    session_dict['headers']['Accept-Encoding'] = 'gzip'

# Generated at 2022-06-12 00:20:52.678235
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Empty headers
    session = Session('abc')
    session.update_headers({})
    assert session['headers'] == {}
    assert session['cookies'] == {}

    # Nomal headers
    headers = {'key1': 'value1', 'key2': 'value2'}
    session.update_headers(headers)
    assert session['headers'] == {'key1': 'value1', 'key2': 'value2'}
    assert session['cookies'] == {}

    # Headers with value of type bytes
    headers = {'key': 'value1'.encode('utf-8')}
    session.update_headers(headers)
    assert session['headers'] == {'key': 'value1'}

    # Cookie headers
    headers = {'cookie': 'key1=value1; key2=value2'}


# Generated at 2022-06-12 00:21:02.290485
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('./session-file.json')
    r = {
            'User-Agent': 'httpie test request',
            'Content-Type': 'application/json',
            'If-Modified-Since': '2019-04-01 12:02:37',
            'Cookie': 'test_cookie_1=test_value_1;test_cookie_2=test_value_2',
            'User-Agent-2': 'httpie test request'
    }
    s.update_headers(r)
    dict_headers = dict(s['headers'])


# Generated at 2022-06-12 00:21:06.737268
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    request_headers = {'foo': 'bar', 'content-length': '0'}
    session.update_headers(request_headers)
    assert session['headers']['foo'] == 'bar'
    assert 'content-length' not in session['headers']

# Generated at 2022-06-12 00:21:17.504923
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    # Test to ignore explicitly unset headers
    session.update_headers({'Accept': None, 'User-Agent': 'HTTPie/2.0.0'})
    assert session.headers == {}
    session.update_headers({'Accept': 'application/json', 'User-Agent': 'HTTPie/2.0.0'})
    assert session.headers == {'Accept': 'application/json'}
    # Test to ignore the Cookie request header
    session.update_headers({'Cookie': 'foo=bar'})
    assert session.headers == {'Accept': 'application/json'}
    # Test to ignore headers that start with SESSION_IGNORED_HEADER_PREFIXES

# Generated at 2022-06-12 00:21:28.121267
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session({'headers':{}, 'cookies':{'name':{'value':'value'}}, 'auth':{'type':None, 'username':None, 'password':None}})
    s.remove_cookies(['name', 'other'])
    assert s.cookies == {}

# Generated at 2022-06-12 00:21:34.199438
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("")
    session.cookies = RequestsCookieJar()
    session.cookies.set("cookie0", "value0")
    session.cookies.set("cookie1", "value1")
    for cookie in session.cookies:
        assert cookie.name in session['cookies']

    session.remove_cookies(["cookie0", "cookie1"])
    for cookie in session.cookies:
        assert cookie.name not in session['cookies']

# Generated at 2022-06-12 00:21:38.711215
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/test/test.json')
    session['cookies'] = {'test':'test', 'test2':'test2'}
    session.remove_cookies(['test'])
    assert session['cookies'] == {'test2':'test2'}

# Generated at 2022-06-12 00:21:42.717250
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies.json')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}
    session.remove_cookies(['name2'])
    assert session['cookies'] == {}
    session.remove_cookies(['name3'])
    assert session['cookies'] == {}



# Generated at 2022-06-12 00:21:47.920369
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("test.json")
    s.update_headers(
        {'headers': {"set-cookie": "test=test; Session=test; test2=test2"}})
    s.remove_cookies(["test", "Session"])
    assert s["cookies"] == {'test2': {'value': 'test2'}}

# Generated at 2022-06-12 00:21:54.606472
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session_name')
    session.update_headers({'Cookie': 'name_1=XXX; name_2=YYY; name_3=ZZZ'})
    session.remove_cookies(['name_2'])
    assert 'name_1' in session['cookies']
    assert 'name_2' not in session['cookies']
    assert 'name_3' in session['cookies']


# Generated at 2022-06-12 00:22:01.718986
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("session.json")
    session['cookies'] = {}
    for num in range(10):
        session['cookies'][f'session{num}'] = num
    assert list(session['cookies']) == [f'session{num}' for num in range(10)]
    session.remove_cookies([f'session5', f'session8'])
    assert list(session['cookies']) == [f'session{num}' for num in range(10) if num not in [5, 8]]

# Generated at 2022-06-12 00:22:10.517660
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # GIVEN
    session = Session('test-session.json')
    session['cookies'] = dict(
        foo={'value': 'foo value', 'expires': 1},
        bar={'value': 'bar value', 'expires': 1},
        baz={'value': 'baz value', 'expires': 1},
    )
    # WHEN
    session.remove_cookies(['bar', 'baz', 'qux'])
    # THEN
    expected_cookies = dict(foo={'value': 'foo value', 'expires': 1})
    assert session['cookies'] == expected_cookies

# Generated at 2022-06-12 00:22:13.611504
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(('b', 'd', 'e'))
    assert session['cookies'] == {'a': 1, 'c': 3}

# Generated at 2022-06-12 00:22:16.994542
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/sessions/john.json')
    s['cookies'] = {'name': {'value': 'john', 'path': '/'}}
    s.remove_cookies(['name'])
    assert s['cookies'] == {}

# Generated at 2022-06-12 00:22:30.850127
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("./")
    assert(s['cookies'] == {})
    s['cookies'] = {'a': {'value': 'aa'}, 'b': {'value': 'bb'}}
    assert(s['cookies'] == {'a': {'value': 'aa'}, 'b': {'value': 'bb'}})
    s.remove_cookies(['a'])
    assert(s['cookies'] == {'b': {'value': 'bb'}})
    s.remove_cookies(['b'])
    assert(s['cookies'] == {})

# Generated at 2022-06-12 00:22:36.076384
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies']['a'] = 'b'
    session.remove_cookies(['a', 'c'])
    print(session)
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:22:40.289111
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-12 00:22:42.812025
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("")
    session['cookies'] = {"a": 1, "b": 2, "c": 3}
    session.remove_cookies(["a", "b"])
    assert {"c": 3} == session['cookies']

# Generated at 2022-06-12 00:22:48.229010
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('.httpie'))
    cookie_name = "test"
    cookie_value = "value"

    session['cookies'][cookie_name] = {
        'value': cookie_value,
    }
    session.remove_cookies([cookie_name])

    assert cookie_name not in session['cookies']

# Generated at 2022-06-12 00:22:53.754410
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('tests/sessions/test'))
    session.load()
    session.remove_cookies(['Key'])
    assert session.to_dict() == {'version': 1, 'headers': {}, 'auth': {'raw_auth': '', 'type': 'Basic'}, 'cookies': {'Value': {'secure': True, 'value': 'Value', 'path': '/', 'expires': None}}}

# Generated at 2022-06-12 00:23:00.687281
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='session.json')
    session['cookies'] = {'name1': [{'value': 'value1'}], 'name2': [{'value': 'value2'}], 'name3': [{'value': 'value3'}]}
    names = ['name2', 'name3']

    session.remove_cookies(names)

    assert len(session['cookies']) == 1
    assert session['cookies'] == {'name1': [{'value': 'value1'}]}

# Generated at 2022-06-12 00:23:05.815221
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('tests/sessions/test_Session_remove_cookies')
    session['cookies'] = {'a': 'b'}
    session.remove_cookies('a')
    assert session['cookies'] == {}



# Generated at 2022-06-12 00:23:09.049367
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("test.json")
    s["cookies"] = {'mycookie': 'myvalue'}
    s.remove_cookies(["mycookie"])
    assert {'mycookie'} != s["cookies"]


# Generated at 2022-06-12 00:23:14.558447
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("path")
    session['cookies'] = {"session": {"value": "asdf"}, "csrftoken": {"value": "asdf"}}
    session.remove_cookies(["session"])

    assert "session" not in session['cookies']
    assert "csrftoken" in session['cookies']

# Generated at 2022-06-12 00:23:40.837597
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.input import KeyValue
    from httpie.cli.arguments import Cookie

    config = Session('/dev/null')
    cookies = [KeyValue(None, 'c1=v1'), KeyValue(None, 'c2=v2'), KeyValue(None, 'c3=v3')]

    parsed_cookies = Cookie.parse(cookies)
    config['cookies'] = parsed_cookies

    assert config['cookies'] == RequestsCookieJar([Cookie('c1', 'v1'), Cookie('c2', 'v2'), Cookie('c3', 'v3')])

    config.remove_cookies(['c1'])

    assert config['cookies'] == RequestsCookieJar([Cookie('c2', 'v2'), Cookie('c3', 'v3')])

    config.remove_

# Generated at 2022-06-12 00:23:45.806453
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'x'])
    assert set(session['cookies'].keys()) == {'b', 'c'}

# Generated at 2022-06-12 00:23:51.637139
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/test_Session_remove_cookies.json')
    s.cookies = RequestsCookieJar()
    s.cookies.set('a', 'abc')
    s.cookies.set('b', 'abc')
    s.cookies.set('c', 'abc')
    s.remove_cookies(['a', 'b'])
    assert s.cookies.keys() == ['c']



# Generated at 2022-06-12 00:23:56.969289
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path = 'test_session.json')
    s['cookies'] = {
        'user': {'value':'username', 'path': '/'},
        'pwd': {'value':'password', 'path': '/'}
    }

    s.remove_cookies(('user', 'pwd'))
    assert s['cookies'] == {}

    s['cookies'] = {
        'user': {'value':'username', 'path': '/'},
        'pwd': {'value':'password', 'path': '/'}
    }
    s.remove_cookies(('user',))
    assert s['cookies'] == {'pwd': {'value':'password', 'path': '/'}}



# Generated at 2022-06-12 00:24:04.259545
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session')
    session['cookies'] = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3'
    }
    assert session['cookies'] == {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3'
    }

    session.remove_cookies(['key2', 'key3'])
    assert session['cookies'] == {
        'key1': 'value1'
    }



# Generated at 2022-06-12 00:24:07.032112
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {'cookie': {'value': 'abc'}}
    session.remove_cookies(['cookie'])
    assert session['cookies'] == {}


# Generated at 2022-06-12 00:24:12.931530
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies']['name1'] = {'value': '1'}
    session['cookies']['name2'] = {'value': '2'}
    session.remove_cookies(['name1'])
    assert 'name1' not in session['cookies']
    assert 'name2' in session['cookies']



# Generated at 2022-06-12 00:24:23.118887
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('test.json'))
    session['cookies'] = {
        'cookie1': {
            'value': 'value1',
            'path': '/',
            'secure': True,
            'expires': None
        },
        'cookie2': {
            'value': 'value2',
            'path': '/',
            'secure': True,
            'expires': None
        }
    }
    session.remove_cookies(['cookie1', 'cookie3'])
    assert session['cookies'] == {
        'cookie2': {
            'value': 'value2',
            'path': '/',
            'secure': True,
            'expires': None
        }
    }

# Generated at 2022-06-12 00:24:28.427577
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    dict_t = {'cookies': {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}, 'cookie3': {'value': 'value3'}}}
    session = Session(Path('dummy'))
    session.update(dict_t)
    session.remove_cookies(['cookie2', 'cookie3'])
    assert len(session['cookies']) == 1
    assert 'cookie1' in session['cookies'] and 'cookie2' not in session['cookies'] and 'cookie3' not in session['cookies']


# Generated at 2022-06-12 00:24:32.419711
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}



# Generated at 2022-06-12 00:25:14.430362
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'abc': 123, 'xyz': 456}
    assert session['cookies'] == {'abc': 123, 'xyz': 456}
    session.remove_cookies(['abc'])
    assert session['cookies'] == {'xyz': 456}
    session.remove_cookies(['xyz'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:25:18.378800
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """Test removing cookies"""
    session = Session("/tmp/test_session_remove_cookies")
    session.update_headers("Cookie: a=1")
    assert session['cookies']['a']['value'] == '1'
    session.remove_cookies("a")
    assert len(session['cookies']) == 0

# Generated at 2022-06-12 00:25:24.569448
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('cookie_test')
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie(
                'name', 'value', path='/'))
    session.cookies.set_cookie(create_cookie(
                'name1', 'value', path='/'))
    session.cookies.set_cookie(create_cookie(
                'name2', 'value', path='/'))
    for name in ['name', 'name1', 'name2']:
        if name in session.cookies.keys():
            del session.cookies[name]
    names = ['name', 'name1']
    session.remove_cookies(names)
    assert len(session['cookies'])  <= 1
    assert 'name2' in session['cookies'].keys()

# Generated at 2022-06-12 00:25:31.148410
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from requests.cookies import RequestsCookieJar
    from httpie import ExitStatus
    from httpie.core import main_parser
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.context import Environment
    import sys
    import json

    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Accept-Charset': 'UTF-8',
        'User-Agent': 'HTTPie/1.0.0-dev'
    }
    # parse arguments
    env = Environment()
    args = main_parser.parse_args(args=[])
    # create HTTPie session
    session = Session(path=Path("/tmp/httpie-test"))
    session.update_headers(headers)

# Generated at 2022-06-12 00:25:36.474129
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('file.json')
    session['cookies'] = {'c1':1, 'c2':2, 'c3':3}
    session.remove_cookies(['c1','c4','c5'])
    assert session['cookies'] == {'c2':2, 'c3':3}

# Generated at 2022-06-12 00:25:48.124529
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    base_sesssion = {
        'headers': {},
        'cookies': {
            'one': {'value': '1'},
            'two': {'value': '2'},
            'three': {'value': '3'},
        },
        'auth': {
            'type': None,
            'username': None,
            'password': None
        }
    }

    session = Session("test.json")
    session._dict = base_sesssion

    # removing an existing cookie
    base_sesssion['cookies'].pop('one')
    session.remove_cookies(['one'])
    assert base_sesssion == session._dict

    # removing non-existing cookie
    session.remove_cookies(['four'])
    assert base_sesssion

# Generated at 2022-06-12 00:25:54.876945
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    jar = RequestsCookieJar()
    jar.set_cookie(create_cookie('x', '2', path='/'))
    jar.set_cookie(create_cookie('y', '3', path='/'))
    jar.set_cookie(create_cookie('z', '4', path='/'))

    session = Session(Path('/some'))
    session.cookies = jar

    session.remove_cookies(['z', 'x'])
    assert session.cookies.get_dict() == {'y': '3'}

# Generated at 2022-06-12 00:25:58.693827
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies']['user'] = {'value': 'mike'}
    session.remove_cookies(names = ['user'])
    assert len(session['cookies']) == 0

# Generated at 2022-06-12 00:26:06.883760
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_path = "/home/mc/.httpie/sessions/httpbin_org/test-session.json"
    session = Session(test_path)
    session.load()
    session.remove_cookies(["test_cookie", "name"])
    assert "test_cookie" not in session["cookies"].keys()
    assert "name" not in session["cookies"].keys()
    assert len(session["cookies"].keys()) == 0
    session.save()

# Generated at 2022-06-12 00:26:13.077896
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(""))
    cookie1 = {'path': '/', 'value': 'secret'}
    cookie2 = {'path': '/', 'value': 'secret'}
    session['cookies'] = {'name1': cookie1, 'name2': cookie2}
    assert session['cookies']['name1'] == cookie1
    assert session['cookies']['name2'] == cookie2
    session.remove_cookies(['name1'])
    assert 'name1' not in session['cookies']
    assert 'name2' in session['cookies']

# Generated at 2022-06-12 00:26:54.517548
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('test_sys_config/test_sessions/test_localhost_test.json')
    sess.remove_cookies(['test_remove'])
    assert('test_remove' not in sess['cookies'])


# Generated at 2022-06-12 00:27:05.104360
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Remove cookies from a session.

    """
    S = Session(os.path.join(DEFAULT_SESSIONS_DIR, 'test.json'))
    S['cookies']['test'] = 'test'
    S['cookies']['test2'] = 'test2'
    S['cookies']['test3'] = 'test3'
    S.remove_cookies(['test'])

    assert 'test' not in S['cookies']
    assert 'test2' in S['cookies']
    assert 'test3' in S['cookies']

    S.remove_cookies(['test2', 'test3'])

    assert 'test2' not in S['cookies']
    assert 'test3' not in S['cookies']

# Generated at 2022-06-12 00:27:14.351963
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session.json')
    session.cookies = RequestsCookieJar()
    session['cookies'] = {
        'cookies1': {'value': 'value1'},
        'cookies2': {'value': 'value1'},
        'cookies3': {'value': 'value1'}
    }
    assert {'cookies1', 'cookies2', 'cookies3'} == set(session['cookies'].keys())

    session.remove_cookies(names=['cookies2'])
    assert {'cookies1', 'cookies3'} == set(session['cookies'].keys())

    session.remove_cookies(names=['cookies3', 'cookies1'])
    assert {} == session['cookies']

# Generated at 2022-06-12 00:27:23.676668
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('Session')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}

    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {}

    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-12 00:27:28.919565
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(config_dir='test')
    s.update_headers([('cookie', 'key1=value1; key2=value2')])
    assert len(s['cookies']) == 2
    s.remove_cookies(['key1'])
    assert len(s['cookies']) == 1
    assert s['cookies'] == {'key2': {'path': None, 'secure': False, 'value': 'value2', 'expires': None}}

# Generated at 2022-06-12 00:27:36.560611
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/path/to/session.json') 
    session['cookies']= {'name1':{'value':'value1'}, 'name2':{'value':'value2'}}
    session.remove_cookies(['name3'])
    assert session['cookies']=={'name1':{'value':'value1'}, 'name2':{'value':'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies']=={'name2':{'value':'value2'}}

# Generated at 2022-06-12 00:27:39.262228
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test = Session(path = os.path.expanduser("~/.config/httpie/localhost/session.json"))
    test['cookies'] = {'a': 1, 'b': 2}
    test.remove_cookies(['a', 'c'])
    assert test['cookies'] == {'b': 2}

# Generated at 2022-06-12 00:27:48.862244
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('dummy')
    jar = RequestsCookieJar()
    jar.set('key1', 'value1', path='/', domain='example.com')
    jar.set('key2', 'value2', path='/', domain='example.com')
    session.cookies = jar

    assert len(session['cookies']) == 2
    session.remove_cookies(['key1'])
    assert len(session['cookies']) == 1
    assert session['cookies']['key2']['value'] == 'value2'


# Generated at 2022-06-12 00:27:56.487962
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = RequestsCookieJar()
    cookies.set_cookie(create_cookie('a', '1'))
    cookies.set_cookie(create_cookie('a', '1', path='/b'))
    cookies.set_cookie(create_cookie('b', '2'))
    session = Session('/')
    session.cookies = cookies

    to_remove = ['a']
    session.remove_cookies(to_remove)
    assert session.cookies.get_dict() == {'b': '2'}

# Generated at 2022-06-12 00:28:04.878009
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(DEFAULT_SESSIONS_DIR / 'TEST' / 'test_Session_remove_cookies.json')
    session.remove_cookies(['key1', 'key2'])
    assert 'cookies' not in session
    session['cookies'] = dict(
        key1 = dict(value = 'value1', path = '/', secure = True, expires = 1234),
        key2 = dict(value = 'value2', path = '/', secure = True, expires = 1234),
        key3 = dict(value = 'value3', path = '/', secure = True, expires = 1234)
    )
    session.remove_cookies(['key1', 'key2'])