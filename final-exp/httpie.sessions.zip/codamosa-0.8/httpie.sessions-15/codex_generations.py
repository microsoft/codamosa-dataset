

# Generated at 2022-06-12 00:19:50.542469
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class RequestHeadersDict(dict):
        pass
    request_headers = RequestHeadersDict()
    request_headers['Content-Type'] = 'application/json'
    request_headers['If-None-Match'] = 'true'
    request_headers['Host'] = 'httpie.org'
    session = Session('toto')
    session.update_headers(request_headers)
    assert session['headers']['Content-Type'] == 'application/json'
    assert 'If-None-Match' not in session['headers']
    assert 'Host' in session['headers']

# Generated at 2022-06-12 00:19:58.038765
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValue, KeyValueArgType
    from httpie.core import request

    args = request.Request(
        'https://httpbin.org/post',
        'POST',
        'foo=bar',
        headers=[KeyValue(KeyValueArgType.ORIGIN, 'baz:qux')]
    )

    session = Session('/tmp/test_session')

    session.update_headers(args.headers)
    assert session.headers == {
        'Content-Length': '7',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Origin': 'baz:qux',
        'User-Agent': 'HTTPie/1.0.0'
    }

    # Only the cookie with the name 'CUSTOM-COOKIE' should

# Generated at 2022-06-12 00:20:09.829308
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    raw_headers = [
        ['user-agent', 'HTTPie/0.9.2'],
        ['content-type', 'application/json'],
        ['if-match', '5c5f7cf1f5c5e7d38bd1f9c9f53488b7'],
        ['cookie', 'xx=xx'],
        ['Cookie', 'xx=xx'],
        ['cookie', 'xx2=xx2'],
        ['cookie', 'xx3=xx3'],
        ['Cookie', 'xx3=xx3']
    ]
    request_headers = RequestHeadersDict(raw_headers)
    session_dict = {}
    session = Session(session_dict)
    session.update_headers(request_headers)

# Generated at 2022-06-12 00:20:18.372493
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path = "")
    request_headers = RequestHeadersDict()
    request_headers['User-agent'] = 'HTTPie/0.9.6'
    request_headers['Test-field'] = 'Some-value'
    request_headers['If-match'] = 'value1'
    request_headers['if-none-match'] = 'value2'
    session.update_headers(request_headers)
    assert session['headers'] == {'Test-field': 'Some-value'}

# Generated at 2022-06-12 00:20:28.756453
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('.')
    session.update_headers(RequestHeadersDict({'User-Agent': 'test'}))
    assert session.headers['User-Agent'] == 'test'
    session.update_headers(RequestHeadersDict({'User-Agent': 'test2'}))
    assert session.headers['User-Agent'] == 'test2'
    assert 'User-Agent' in session.headers
    session.update_headers(RequestHeadersDict({'cookie': 'foo=bar;'}))
    assert 'foo' in session.cookies
    session.update_headers(RequestHeadersDict({'Cookie': 'bar=foo;'}))
    assert 'foo' in session.cookies
    assert 'bar' in session.cookies

# Generated at 2022-06-12 00:20:36.616823
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session()
    session.update_headers(
        RequestHeadersDict([('Host', 'httpbin.org'), ('User-Agent', 'test'), (
            'Accept', '*/*'), ('Cookie', 'a=b'), ('Content-Type', 'x'), (
            'If-Match', '*')])
    )
    assert_that(session.headers, equal_to(
        RequestHeadersDict([('Host', 'httpbin.org'), ('Accept', '*/*')])))

# Generated at 2022-06-12 00:20:42.488373
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    d = Session("/")
    d.update_headers({"Content-Type": "application/json", "Host": "host", "Content-Encoding": "utf-8"})
    assert d['headers'] == {"Host": "host"}
    d.update_headers({"Content-Type": "application/json", "Host": "host", "Content-Encoding": "utf-8"})
    assert {"Host": "host"} == d['headers']

# Generated at 2022-06-12 00:20:52.992066
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('/tmp/test_Session_update_headers.json')
    s.update_headers({'User-Agent': b'HTTPie/1.0.0'})
    assert s['headers'] == {}

    s = Session('/tmp/test_Session_update_headers.json')
    s.update_headers({'User-Agent': 'HTTPie/1.0.0', 'Cookie': b'foo=bar'})
    assert s['headers'] == {}
    assert s['cookies'] == {'foo': {'value': 'bar'}}

    # With a multi-line Cookie header value, only the last cookie should
    # be stored.
    s = Session('/tmp/test_Session_update_headers.json')

# Generated at 2022-06-12 00:21:02.458403
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    request_headers = RequestHeadersDict()
    # Test for case when method update_headers removes an item from dictionary
    request_headers['If-Modified-Since'] = b'1407723924'
    session.update_headers(request_headers)
    assert session.headers == request_headers
    # Test for case when method update_headers doesn't change the dictionary
    request_headers['User-Agent'] = b'HTTPie/0.9.3'
    session.update_headers(request_headers)
    assert session.headers == RequestHeadersDict()
    # Test for case when method update_headers appends an item to a dictionary
    request_headers["Cookie"] = b'name=John%20Doe'
    session.update_headers(request_headers)

# Generated at 2022-06-12 00:21:07.237828
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(path='/')

    request_headers = {'User-Agent': 'HTTPie/1.0.0', 'content-length': '0'}
    s.update_headers(request_headers)
    assert 'User-Agent' not in s.headers
    assert 'content-length' in s.headers

# Generated at 2022-06-12 00:21:19.174690
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./tmp')
    session['headers'] = {}
    session['cookies'] = {}
    request_headers = RequestHeadersDict([('user-agent', 'HTTPie/1.0.3'),
                                          ('cookie', 'color=red;'),
                                          ('Cookie', 'color=green;')])
    session.update_headers(request_headers)
    assert session['headers']['user-agent'] == 'HTTPie/1.0.3'
    assert session['cookies']['color']['value'] == 'red'
    assert session['cookies']['color']['value'] == request_headers['cookie'].decode('utf8').split(';')[0].split('=')[1]

# Generated at 2022-06-12 00:21:26.537492
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("Test_Session")
    session.update_headers({})
    assert not session
    session.update_headers({"Cookie": "username=tom"})
    assert "Cookie" not in session['headers']
    assert session["cookies"] == {"username": {"value": "tom"}}
    session.update_headers({"Connection": "close", "Host": "127.0.0.1"})
    assert session['headers'] == {"Connection": "close", "Host": "127.0.0.1"}
    session.update_headers({"Content-Type": "text/html", "If-None-Match": "1234"})
    assert session['headers'] == {"Connection": "close", "Host": "127.0.0.1"}

# Generated at 2022-06-12 00:21:36.286393
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)

    cookie1 = dict(name='foo', value='bar')
    cookie2 = dict(name='bar', value='baz')
    cookie3 = dict(name='baz', value='quok')
    session['cookies'] = {f'{cookie1["name"]}': cookie1, f'{cookie2["name"]}': cookie2, f'{cookie3["name"]}': cookie3}
    session.remove_cookies(['foo', 'baz'])

    assert (session['cookies'].__len__() == 1) and (f'{cookie2["name"]}' in session['cookies'])

# Generated at 2022-06-12 00:21:40.868290
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    c = RequestsCookieJar()
    c.set('cookie', 'value', path='/')
    s = Session('session')
    s.cookies = c
    s.cookies = c
    assert 'cookie' in s.get('cookies')
    
    s.remove_cookies(['cookie'])
    assert not 'cookie' in s.get('cookies')



# Generated at 2022-06-12 00:21:46.291617
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("")
    session["cookies"] = {
        "foo": {"value": "bar"},
        "baz": {"value": "bla"},
    }
    session.remove_cookies(["foo", "bar"])
    assert session["cookies"] == {"baz": {"value": "bla"}}



# Generated at 2022-06-12 00:21:53.793316
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = 'test_session'
    session_test = Session(session_path)
    session_test['cookies'] = {
        'cookie1': {'value': 'test1'},
        'cookie2': {'value': 'test2'}
    }
    names = ['cookie1', 'cookie3']
    session_test.remove_cookies(names)
    assert session_test['cookies'] == {'cookie2': {'value': 'test2'}}

# Generated at 2022-06-12 00:21:55.142254
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    Session.update_headers(['Content-Type: application/json'])
    assert None



# Generated at 2022-06-12 00:22:06.793396
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict

    session = Session('.')

    # Test with no request headers
    session.update_headers(RequestHeadersDict())
    assert session['headers'] == {}

    # Test with single request header
    session['headers'] = {}
    request_headers = RequestHeadersDict()
    request_headers['Content-Type'] = 'text/plain'
    session.update_headers(request_headers)
    assert session['headers'] == {'Content-Type': 'text/plain'}
    session['headers'] = {}

    # Test with multiple request headers
    session['headers'] = {}
    request_headers = RequestHeadersDict()
    request_headers['Content-Type'] = 'text/plain'
    request_headers['If-Match'] = '*'
    session

# Generated at 2022-06-12 00:22:14.509460
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json
    import os
    import shutil
    import tempfile
    import unittest

    class TestSession(unittest.TestCase):

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.session_file_path = os.path.join(self.test_dir, 'test_Session')
            self.session = Session(self.session_file_path)

        def test_remove_cookies_empty(self):
            self.session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
            self.session.remove_cookies(['name1'])
            self.assertEqual(list(self.session['cookies'].keys()), ['name2'])


# Generated at 2022-06-12 00:22:18.558542
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = Path('/toto.json')
    session = Session(path)
    session.update_headers(RequestHeadersDict.from_raw({'Cookie': 'a=b'}))
    session.remove_cookies(['a'])
    assert not session.cookies
    assert not session.headers['Cookie']


# Generated at 2022-06-12 00:22:27.415718
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('./session.json')
    s['cookies'] = {
        'mock_cookie_name': 'mock_cookie_value',
    }
    s.remove_cookies(['mock_cookie_name'])
    assert 'cookies' not in s

# Generated at 2022-06-12 00:22:30.740783
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['d', 'b'])
    assert session['cookies'] == {'a': 1, 'c': 2}

# Generated at 2022-06-12 00:22:42.070846
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('abc')
    session['cookies'] = {
        'sid': {'value': 'aasjkd'},
        'b': {'value': 'b'},
        'c': {'value': 'c'},
    }
    assert session['cookies'] == {'sid': {'value': 'aasjkd'}, 'b': {'value': 'b'}, 'c': {'value': 'c'}}
    session.remove_cookies(['b', 'c'])
    assert session['cookies'] == {'sid': {'value': 'aasjkd'}}
    session.remove_cookies(['sid', 'd'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:22:52.877919
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from datetime import datetime, timedelta
    from time import mktime
    from uuid import uuid4

    dct = {}
    dct['headers'] = {}
    dct['cookies'] = {}
    dct['auth'] = {
            'type': None,
            'username': None,
            'password': None
        }
    from httpie.compat import str
    import json
    json_data = json.dumps(dct)
    data = json.loads(json_data)

    session = Session(data)
    headers = {}
    headers['test1'] = 'a test'
    headers['test2'] = 'another test'
    headers['test3'] = 'a test with prefix'
    headers['test4'] = 'another test with prefix'

    session.update_headers(headers)


# Generated at 2022-06-12 00:22:55.281344
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    s['cookies'] = {'first': 'foo', 'second': 'bar'}
    s.remove_cookies(['first'])
    assert s['cookies'] == {'second': 'bar'}

# Generated at 2022-06-12 00:23:01.354785
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_name = "session_name"
    config_dir = "/tmp"
    hostname = "http://google.com"
    url = "http://google.com"
    expected_value = {}

    x = get_httpie_session(config_dir, session_name, hostname, url)
    x.remove_cookies(names = ['cookie1'])

    actual_value = x['cookies']
    assert actual_value == expected_value

# Generated at 2022-06-12 00:23:05.648165
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies']['name'] = {'value': 'Jack'}
    session.remove_cookies(['name'])
    assert not session.get('cookies')

# Generated at 2022-06-12 00:23:16.393799
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    class MockFile(dict):
        def write(self, *_): pass
        def read(self): return '{}'
        def close(self): pass
    session = Session(path=MockFile())
    session.load()
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie('cookie1', 'value1'))
    session.cookies.set_cookie(create_cookie('cookie2', 'value2'))
    session.cookies.set_cookie(create_cookie('cookie3', 'value3'))
    session.remove_cookies(['cookie1', 'cookie3'])
    assert session.cookies.__str__() == "Set-Cookie: cookie2=value2\n"

# Generated at 2022-06-12 00:23:27.849048
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test.json')
    request_headers = {'User-Agent': 'HTTPie/0.9.9',
                       'Accept-Encoding': 'gzip, deflate',
                       'Connection': 'keep-alive',
                       'Accept': '*/*',
                       'If-None-Match': 'W/"5cc5d5f0-917"',
                       'Cookie': 'csrftoken=lw4SH4V7FjlkY2uGNY9ZJxSxEzgI1tLn; user_id=22914; sessionid=mjt2dfbq9e3qxlk1igje5ehc27p7yjpw'}

    session.update_headers(request_headers)

# Generated at 2022-06-12 00:23:30.279468
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='./session.json')
    session.cookies = RequestsCookieJar()
    assert session.remove_cookies(['cookie1']) is None

# Generated at 2022-06-12 00:23:47.614770
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir = Path('~/.config/httpie')
    session_name = 'test_session'
    host = 'host'
    url = 'http://host/'

    session = get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-12 00:23:52.870480
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies')
    # given
    session['cookies'] = {'httpie_cookie1':'value 1', 'httpie_cookie2':'value 2'}
    names = ['httpie_cookie1', 'httpie_cookie2']
    # when
    session.remove_cookies(names)
    # then
    assert len(session['cookies']) == 0

# Generated at 2022-06-12 00:24:03.886064
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.argtypes import KeyValue
    from httpie.plugins.builtin import HTTPBasicAuth

    # Case: remove a missing cookie
    session = Session('test_session')
    remove_cookies = ["test_cookie"]
    session.remove_cookies(remove_cookies)

    # Case: remove provided cookies
    session['cookies'] = {"test1": {"value": "test1"}, "test2": {"value": "test2"}}
    remove_cookies = ["test1"]
    session.remove_cookies(remove_cookies)
    assert len(session['cookies'].keys()) == 1 and session['cookies']['test2'] != None

    # Case: remove all cookies

# Generated at 2022-06-12 00:24:08.853888
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/')
    d = dict(cookies={'a': {'value': 1}, 'b': {'value': 2}, 'c': {'value': 3}})
    s._data = {**s._data, **d}
    s.remove_cookies(['a','b'])
    assert s._data == {'headers': {}, 'cookies': {'c': {'value': 3}}, 'auth': {'type': None, 'username': None, 'password': None}}

# Generated at 2022-06-12 00:24:13.636916
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'name_1': 'value', 'name_2': 'value'}
    names = ['name_1']
    result_cookies = {'name_2': 'value'}
    session = Session(path=Path(''), data={'cookies': cookies})
    session.remove_cookies(names)
    assert session['cookies'] == result_cookies

# Generated at 2022-06-12 00:24:24.903522
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {
        'a': {
            'value': 'A',
            'path': '/',
            'secure': True,
            'expires': None
        },
        'b': {
            'value': 'B',
            'path': '/',
            'secure': True,
            'expires': None
        },
    }

    assert session.cookies.get_dict() == {
        'a': {
            'value': 'A',
            'path': '/',
            'secure': True,
            'expires': None
        },
        'b': {
            'value': 'B',
            'path': '/',
            'secure': True,
            'expires': None
        },
    }


# Generated at 2022-06-12 00:24:28.288669
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'a1': 1, 'a2': 2}
    session.remove_cookies(['a1'])
    assert session['cookies'] == {'a2': 2}



# Generated at 2022-06-12 00:24:37.580233
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json
    import os
    import pytest

    http_session = Session("test")
    http_session['cookies'] = json.loads("{\"sessionId\":\"123\",\"userId\":\"456\"}") # Http session contains two cookies
    http_session.remove_cookies(['sessionId', 'userId']) # Removes all cookies in http session

    assert os.path.isfile("test")
    test_json = open("test", "r")
    assert test_json.read() == "{\"headers\": {}, \"cookies\": {}, \"auth\": {\"type\": None, \"username\": None, \"password\": None}}"

# Generated at 2022-06-12 00:24:44.413484
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.core import DEFAULT_HTTP_HEADERS
    from httpie.utils import get_response
    from httpie.output.streams import RawOrStdoutStreamWriter
    from httpie.context import Environment
    from httpie.input import ParseError
    from httpie.cli.argtypes import KeyValueArg
    from httpie.plugins.builtin import HTTPBasicAuth
    import io

    # Mocking environment
    env = Environment()
    env.stdin = io.StringIO()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdout_isatty = False
    env.colors = 0
    env.debug = True
    env.follow_redirects = True
    env.max_redirects = 10
    env.check_

# Generated at 2022-06-12 00:24:48.271061
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'test.json'
    session = Session(path)
    session.load()
    session.remove_cookies(['session_user_name'])

# Generated at 2022-06-12 00:25:00.872821
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import pytest
    from http.cookies import SimpleCookie

    s = Session(None)
    s.update_headers({'Cookie': SimpleCookie('foo=bar; baz=42')})
    s.remove_cookies(('foo', 'baz'))
    assert not s.cookies

# Generated at 2022-06-12 00:25:11.781463
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    counter = 0
    s = Session('../config/sessions/localhost/test.json')
    s['cookies'] = {'1': {'value': '1'}, '2': {'value': '2'}, '3': {'value': '2'}}
    names = ['1', '2']
    s.remove_cookies(names)
    for name in names:
        if name in s['cookies']:
            counter += 1

    assert counter == 0

    s['cookies'] = {'1': {'value': '1'}, '2': {'value': '2'}, '3': {'value': '2'}}
    names = ['1', '2', '3']
    s.remove_cookies(names)

# Generated at 2022-06-12 00:25:15.243197
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('Session_test')
    s.update({'cookies': {'coolio':{'value':'coolio'}}})
    s.remove_cookies(['coolio'])
    assert 'coolio' not in s['cookies']

# Generated at 2022-06-12 00:25:19.393171
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    session = Session("")
    session['cookies'] = {'key1':'value1','key2':'value2','key3':'value3'}
    session.remove_cookies(['key3','key4'])
    # Assert
    assert session['cookies'] == {'key1':'value1','key2':'value2'}

# Generated at 2022-06-12 00:25:24.691124
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    s = Session(path=Path('./test'))
    s['cookies'] = {'username': 'boby', 'password': 'p@ssw0rd'}
    names = ['username']
    s.remove_cookies(names)
    assert s['cookies'] == {'password': 'p@ssw0rd'}

# Generated at 2022-06-12 00:25:31.197041
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Create one session
    session_name = 'first-session'
    session = Session(str(DEFAULT_SESSIONS_DIR / f'{session_name}.json'))
    session['headers'] = {}
    session['cookies'] = {
        'cookie1': {'value': 'value1', 'expires': 'Fri, 01-Jan-2038 00:00:00 GMT'},
        'cookie2': {'value': 'value2', 'expires': 'Fri, 01-Jan-2038 00:00:00 GMT'},
    }
    session['auth'] = {
        'type': 'httpauth',
        'username': 'httpie',
        'password': 'password'
    }

    # Remove cookie1, cookie2 and cookie3 of the first session

# Generated at 2022-06-12 00:25:35.906476
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session["cookies"]={"name1":"value1", "name2":"value2"}
    session.remove_cookies(["name1"])
    assert session["cookies"] == {"name2":"value2"}

# Generated at 2022-06-12 00:25:47.433967
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Test if method remove_cookies of class Session works correctly,
    test case:
    check if the cookie name exist in the session and delete them
    """
    fake_session_path = Path('fake_session_path.json')
    fake_session = {
        'headers': {},
        'cookies': {'name1': 'value1', 'name2': 'value2', 'name3': 'value3'},
        'auth': {'type': None, 'username': None, 'password': None}
    }
    fake_names = ['name2']
    session = Session(path=fake_session_path)
    session.update(fake_session)
    assert session == fake_session
    session.remove_cookies(names=fake_names)

# Generated at 2022-06-12 00:25:50.943447
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path='path/to/session.json')
    s['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    s.remove_cookies('c')
    assert s['cookies'] == {'a': 1, 'b': 2}

# Generated at 2022-06-12 00:25:57.934269
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("~/.httpie/sessions/httpspike_github_com.json")
    session.load()
    cookie_names = [
        'dotcom_user',
        'logged_in',
        'has_recent_activity',
        'tz',
    ]
    session.remove_cookies(cookie_names)
    assert 'cookies' in session
    assert 'dotcom_user' not in session['cookies']
    assert 'logged_in' not in session['cookies']
    assert 'has_recent_activity' not in session['cookies']
    assert 'tz' not in session['cookies']


# Generated at 2022-06-12 00:26:15.934513
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test_sessions_dir')
    session['cookies'] = {'a': {'value': 1}, 'b': {'value': 2}, 'c': {'value': 3}}
    session.remove_cookies(['b', 'c'])
    assert session['cookies'] == {'a': {'value': 1}}


# Generated at 2022-06-12 00:26:23.004354
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_session = Session(path=DEFAULT_SESSIONS_DIR)
    test_session['cookies']['test_cookie'] = {'value': 'test_value'}
    test_session['cookies']['test_cookie2'] = {'value': 'test_value2'}
    test_session.remove_cookies(['test_cookie'])
    assert ('test_cookie' not in test_session['cookies'])
    assert ('test_cookie2' in test_session['cookies'])

# Generated at 2022-06-12 00:26:27.152889
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(".test")
    s['cookies']['a'] = "a"
    s['cookies']['b'] = "b"
    s.remove_cookies(["a"])
    assert("a" not in s['cookies'])
    assert("b" in s['cookies'])

# Generated at 2022-06-12 00:26:33.202774
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test')
    session['cookies'] = {'c1': 1, 'c2': 2, 'c3': 3, 'c4': 4}
    names = ['c1', 'c2']
    session.remove_cookies(names)
    assert session['cookies'] == {'c3': 3, 'c4': 4}


# Generated at 2022-06-12 00:26:36.004504
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(".httpiexxx.json")
    session['cookies'] = {'abc': 'abc', 'xyz': 'xyz'}
    session.remove_cookies(['xyz'])
    assert session['cookies'] == {'abc': 'abc'}

# Generated at 2022-06-12 00:26:46.105320
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/test/path')
    cookie_names = ['cookie_a', 'cookie_b', 'cookie_c', 'cookie_d']
    for name in cookie_names:
        session['cookies'][name] = {'value': 'value'}
    assert len(session['cookies']) == 4
    session.remove_cookies([cookie_names[1], cookie_names[3]])
    assert len(session['cookies']) == 2
    for name in cookie_names[0], cookie_names[2]:
        assert name in session['cookies']
    for name in cookie_names[1], cookie_names[3]:
        assert name not in session['cookies']

# Generated at 2022-06-12 00:26:50.958091
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("teste.json")
    session['cookies'] = {'name1': {'value': 'einstein'}, 'name2': {'value': 'newton'}}
    session.remove_cookies(['name2'])
    assert session['cookies'] == {'name1': {'value': 'einstein'}}


# Generated at 2022-06-12 00:26:54.249231
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/dev/null')
    s['cookies'] = dict(a=1, b=2, c=3)
    s.remove_cookies(['b'])
    assert s['cookies'] == dict(a=1, c=3)

# Generated at 2022-06-12 00:27:05.367420
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    json_path = r'..\config\sessions\test.json'
    session_test = Session(json_path)
    session_test['cookies']['test_1'] = {'value': 'test_value_1'}
    session_test['cookies']['test_2'] = {'value': 'test_value_2'}
    session_test['cookies']['test_3'] = {'value': 'test_value_3'}
    assert len(session_test['cookies']) == 3
    session_test.remove_cookies(['test_1'])
    assert len(session_test['cookies']) == 2
    session_test.remove_cookies(['test_2'])
    assert len(session_test['cookies']) == 1

# Generated at 2022-06-12 00:27:08.608154
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test/test.json')
    assert {'type', 'username', 'password'} == session.auth.keys()
    assert session.remove_cookies(['key']) == None

# Generated at 2022-06-12 00:27:49.514457
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='path')
    session['cookies'] = {'a':'b', 'c':'d'}
    # print(session['cookies'])
    session.remove_cookies(names=['c', 'd'])
    assert session['cookies'] == {'a':'b'}

# Generated at 2022-06-12 00:27:54.348598
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c', 'd'])
    assert session['cookies'] == {'b': 2}


# Generated at 2022-06-12 00:28:02.743111
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = {
      "auth": {"type": "basic"},
      "cookies": {
        "cookie1": {"value": "value1", "path": "/", "secure": "False", "expires": "1464489741"},
        "cookie2": {"value": "value2", "path": "/", "secure": "False", "expires": "1464489741"},
        "cookie3": {"value": "value3", "path": "/", "secure": "False", "expires": "1464489741"}
      }
    }
    session_object = Session("file")
    session_object.__dict__ = session

    assert session_object['cookies']['cookie1'] == {"value": "value1", "path": "/", "secure": "False", "expires": "1464489741"}

# Generated at 2022-06-12 00:28:05.736995
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'name1': '', 'name2': ''}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': ''}

# Generated at 2022-06-12 00:28:14.837125
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.session import Session
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.cli.argtypes import AuthCredentials
    from httpie.utils import get_response
    from .test_sessions import sessions_dir

    session = Session(sessions_dir / 'session')

    auth = HTTPBasicAuth()
    auth.get_auth = lambda username, password: (username, password)

    credentials = AuthCredentials('alice', 'password')
    auth.raw_auth = auth.raw_auth_header(credentials)

    session.auth = {
        'type': 'basic',
        'raw_auth': auth.raw_auth,
    }

    httpbin_url = 'http://httpbin.org/cookies/set'

# Generated at 2022-06-12 00:28:24.459239
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.client import _update_cookies_in_jar

    # Test for Session
    session_cookies = {'session_cookie1':'session_cookie1_value', 'session_cookie2':'session_cookie2_value'}

    session = Session(path='session_file')
    session['cookies'] = {'session_cookie1':{'value':'session_cookie1_value'}}

    # Test case1: if cookie is not in cookies, nothing happens
    cookie_jar = RequestsCookieJar()

    session.remove_cookies(['cookie_not_in_session'])
    _update_cookies_in_jar(session.header_data, cookie_jar)
    assert cookie_jar == RequestsCookieJar()

    # Test case2: if cookie is in cookies, it is removed
   

# Generated at 2022-06-12 00:28:31.559916
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from types import SimpleNamespace

    cookiejar = SimpleNamespace()
    cookiejar.Cookie = None
    cookiejar.clear = lambda : None
    session = Session("~/.httpie/sessions/test.json")
    assert len(session.keys()) == 3
    assert ('cookies' in session.keys())
    assert ('auth' in session.keys())
    assert ('headers' in session.keys())
    assert session.auth == None
    assert len(session.cookies.keys()) == 0
    assert len(session.headers.keys()) == 0
    assert len(session.keys()) == 3

    session.cookies = cookiejar
    assert len(session.keys()) == 3
    assert ('cookies' in session.keys())
    assert ('auth' in session.keys())
    assert ('headers' in session.keys())


# Generated at 2022-06-12 00:28:35.222232
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path("/tmp/session.json"))
    session['cookies'] = {
        'name1': {'value': 'value1', 'expires': '1'},
        'name2': {'value': 'value2'}
    }
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-12 00:28:41.357937
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir = Path(__file__).parent / '../../../httpie'
    session_name = 'httpbin'
    url = 'http://httpbin.org/'
    session = get_httpie_session(config_dir, session_name, None, url)
    session.remove_cookies(['_gauges_unique', '_gauges_unique_year'])
    assert '_gauges_unique' not in session.get('cookies', [])
    assert '_gauges_unique_year' not in session.get('cookies', [])

# Generated at 2022-06-12 00:28:50.887256
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir: Path = DEFAULT_SESSIONS_DIR
    session_name: str = 'test'
    host: Optional[str] = 'test.com'
    url: str = 'https://httpie.org/doc#sessions'
    session = get_httpie_session(config_dir, session_name, host, url)

    cookie_a = {
        'name': 'cookie_a',
        'value': 'cookie_a',
        'path': None,
        'secure': None,
        'expires': None,
    }

    cookie_b = {
        'name': 'cookie_b',
        'value': 'cookie_b',
        'path': None,
        'secure': None,
        'expires': None,
    }
