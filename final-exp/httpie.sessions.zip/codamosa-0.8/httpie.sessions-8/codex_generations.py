

# Generated at 2022-06-12 00:19:54.510512
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("")
    session.cookies = RequestsCookieJar()
    session.cookies.set("cookie1", "val1")
    session.cookies.set("cookie2", "val2")
    session.cookies.set("cookie3", "val3")

    session.remove_cookies(('cookie3', 'cookie4'))

    assert len(session.cookies) == 2
    assert 'cookie3' not in session.cookies



# Generated at 2022-06-12 00:20:03.603105
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # set up test objects
    headers = RequestHeadersDict({})
    headers['Cookie'] = ['foo:bar', 'baz:raz']
    session = Session('path')

    # test
    session.update_headers(headers)

    # check
    cookies = session.cookies
    assert len(cookies) == 2
    assert 'foo' in cookies
    assert cookies['foo'].value == 'bar'
    assert 'baz' in cookies
    assert cookies['baz'].value == 'raz'

# Generated at 2022-06-12 00:20:12.194122
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import ExitStatus
    from httpie.cli.exceptions import ParseError
    from httpie.cli.parser import Parser
    cli_parser = Parser()
    args = cli_parser.parse_args(args=[])
    args.output_options = cli_parser.get_default_output_options()
    args.debug = True
    stream = cli_parser.get_default_output_stream()
    config_dir = cli_parser.get_config_dir()
    config = cli_parser.get_config(config_dir=config_dir)
    config.merge(cli_parser.get_base_directory_config())
    config.merge(cli_parser.get_config_file(config_dir=config_dir))

# Generated at 2022-06-12 00:20:18.805221
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/session')
    session['cookies'] = {'a': 'va', 'b': 'vb', 'c': 'vc'}
    session.remove_cookies(['b', 'd'])
    assert session['cookies'] == {'a': 'va', 'c': 'vc'}



# Generated at 2022-06-12 00:20:23.193681
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    Session_instance = Session(path = Path('tests/sessions/test'))
    Session_instance['cookies'] = {'foo':{'value':'bar'}}
    Session_instance.remove_cookies(['foo'])
    assert Session_instance['cookies'] == {}


# Generated at 2022-06-12 00:20:25.777267
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    se= Session('./test.json')
    se['cookies']={'a':1}
    se.remove_cookies(['a'])
    assert 'a' not in se['cookies']

    se['cookies']={'b':2}
    se.remove_cookies(['a'])
    assert 'b' in se['cookies']



# Generated at 2022-06-12 00:20:33.289956
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from pytest import raises
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.utils import get_response_type
    from requests.structures import CaseInsensitiveDict

    from httpie.downloads import Downloader

    env = Environment(
        config=Config(config_dir=None, config_file=None),
        stdin_isatty=False,
        stdout_isatty=False,
        is_windows=(os.name == 'nt'),
        output_options=(get_response_type(), CaseInsensitiveDict()),
        log_level=('debug',),
        downloader=Downloader(),
        args=[]
    )

    session = Session('../config/sessions/httpbin.org_80/session_file.json')

# Generated at 2022-06-12 00:20:43.115146
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir = Path('~/.config/httpie')
    session_name = 'https://httpie.org/'
    session = get_httpie_session(config_dir, session_name, None, session_name)
    session.load()
    print(session)
    assert session['cookies']['HttpOnly']['value'] == '1'
    assert session['cookies']['_gid']['value'] == 'GA1.2.712922266.1589689856'
    assert session['cookies']['_ga']['value'] == 'GA1.2.1385524555.1589689856'
    session.remove_cookies(['HttpOnly'])

# Generated at 2022-06-12 00:20:50.418278
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./test.json')
    session.update_headers(RequestHeadersDict({'test1':123}))
    session.update_headers(RequestHeadersDict({'test1':456}))

    print(session.headers)
    assert(session.headers['test1'] == 456)
    print(session.cookies)
    print(session.cookies)
    # print(session.auth)

if __name__ == "__main__":
    test_Session_update_headers()

# Generated at 2022-06-12 00:20:53.295472
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers(RequestHeadersDict([('a', 'b'), ('c', 'd')]))
    assert session.headers == RequestHeadersDict([('a', 'b'), ('c', 'd')])

# Generated at 2022-06-12 00:21:06.498536
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict({'A': '1', 'B': '2', 'C': '3'})
    session = Session('tests/sessions/session')
    session.update_headers(headers)

    assert session.headers == {
        'A': '1',
        'B': '2',
        'C': '3',
    }

# Generated at 2022-06-12 00:21:17.474859
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie import ExitStatus
    from httpie.cli.exceptions import ParseError
    from httpie.client import HTTPie
    from httpie.plugins import AuthPlugin, plugin_manager
    from httpie.sessions import Session
    from tests.utils import http, HTTP_OK
    from tests.utils import TestEnvironment, start_server

    class BasicAuthPlugin(AuthPlugin):
        auth_type = 'basic'
        auth_parse = True

        def get_auth(self, username=None, password=None):
            self.raw_auth = 'basic ' + (username + ':' + password)
            return self

        def __call__(self, r):
            r.headers['Authorization'] = self.raw_auth
            return r

    plugin_manager.register(BasicAuthPlugin)


# Generated at 2022-06-12 00:21:25.992766
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session_path =  os.path.expanduser('~/.config/httpie/sessions/localhost/test.json')
    if os.path.isfile(session_path):
        os.remove(session_path)

    # Create new session with empty headers
    session = Session(session_path)
    session['headers'] = {}
    assert session.headers == {}
    session.save()

    # Add new header
    request_headers = {'Accept': 'text/html'}
    session.update_headers(request_headers)
    assert session.headers == {'Accept': 'text/html'}
    session.save()

    # Add new header
    request_headers = {'Accept-Encoding': 'gzip'}
    session.update_headers(request_headers)

# Generated at 2022-06-12 00:21:34.558609
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/')
    session['headers'] = {}
    session['cookies'] = {'0': {'value': '', 'path': '', 'secure': '', 'expires': ''}, '1': {'value': '', 'path': '', 'secure': '', 'expires': ''}}
    session['auth'] = {'type': None, 'username': None, 'password': None}
    session.remove_cookies(['0'])
    assert session['cookies'] == {'1': {'value': '', 'path': '', 'secure': '', 'expires': ''}}


# Generated at 2022-06-12 00:21:41.282399
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Create session
    session = Session('tmp.json')
    # Create empty HTTP headers
    request_headers = RequestHeadersDict({})
    # Add some headers to session
    request_headers['Content-Type'] = 'application/json'
    request_headers['If-None-Match'] = 'json'
    request_headers['cookie'] = 'cvd=23erf'
    # Update headers in session
    session.update_headers(request_headers)
    # Check that headers from session and request_headers are equal
    assert session.headers == request_headers

# Generated at 2022-06-12 00:21:47.001870
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(None)
    s['cookies'] = {"foo": {}, "bar": {}}
    s.remove_cookies(["foo", "baz"])
    assert s['cookies'] == {'bar': {}}
    s['cookies'] = {}
    s.remove_cookies(["foo", "bar"])
    assert s['cookies'] == {}

# Generated at 2022-06-12 00:21:50.845309
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./session')

    session.update_headers({'Content-Type': 'application/json'})
    session.update_headers({'Content-Length': 0})

    assert session['headers'] == {}

# Generated at 2022-06-12 00:21:55.685731
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    file = 'tests/session.json'
    session = Session(file)
    session.load()
    print(session)
    session.update_headers({'key1': 'value1', 'key2': 'value2'})
    print(session)


if __name__ == '__main__':
    test_Session_update_headers()

# Generated at 2022-06-12 00:21:59.491287
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('.test_test')
    session.update_headers({'foo': 'bar'})
    assert(session['headers'] == {'foo': 'bar'})

    session.update_headers({'foo': None})
    assert(session['headers'] == {})

# Generated at 2022-06-12 00:22:10.685958
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.auth import AuthCredentials
    from httpie.plugins import AuthPlugin

    class HTTPIEBasicAuth(HTTPBasicAuth):

        auth_type = 'httpie.CustomBasicAuthPlugin'

        def __init__(self):
            self.raw_auth = ""

        @AuthPlugin.raw_auth_parser(force_basic=True)
        def raw_auth_parser(self, raw_auth: str, **kwargs):
            self.raw_auth = raw_auth

        def get_auth(self, username=None, password=None):
            return super().get_auth(
                username=username, password=password
            )


# Generated at 2022-06-12 00:22:21.156487
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers({'name': 'value'})
    assert session['headers'] == {'name': 'value'}


# Generated at 2022-06-12 00:22:27.702213
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session.json')
    headers = RequestHeadersDict(
        {'User-Agent': 'Mozilla\/5.0', 'Accept': '*/*', 'Host': 'localhost'})
    session.update_headers(headers)
    print(session['headers'])


if __name__ == '__main__':
    test_Session_update_headers()

# Generated at 2022-06-12 00:22:35.524929
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {
        'Content-Type': 'application/json',
        'Cookie': "cookietest=test",
        'Ignore-Me': "dontstoreme"
    }
    session = Session("session.json")
    session.update_headers(headers)
    session['headers'] == {
        'Content-Type': 'application/json'
    }
    session['cookies'] == {
        'cookietest': {'value': 'test'}
    }

# Generated at 2022-06-12 00:22:36.823168
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert True

# Generated at 2022-06-12 00:22:41.160197
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./test/test_session')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a', 'e'])
    assert len(session['cookies']) == 1
    assert list(session['cookies'].keys()) == ['c']



# Generated at 2022-06-12 00:22:52.712239
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(path=Path(""))
    s['headers'] = {"Accept": [b"application/json", b"text/plain"]}
    s['cookies'] = {}
    s['auth'] = None

    h = RequestHeadersDict()
    h['user-agent'] = [b'session_test_update_headers']
    h['Accept'] = [b'application/json']
    h['Content-Length'] = [b'100']
    h['If-Match'] = [b'12345678']
    h['cookie'] = [b'foo=bar; baz=qux']

    expected_headers = {"Accept": "application/json", "Content-Length": "100"}
    expected_cookies = {"foo": {"value": "bar"}, "baz": {"value": "qux"}}


# Generated at 2022-06-12 00:22:58.476763
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    _s = Session(path=None)
    _r_h = RequestHeadersDict()
    _r_h['Accept'] = 'application/json'
    _r_h['Cookie'] = 'a=b; c=d'
    _r_h['User-Agent'] = 'HTTPie/0.9.9'
    _r_h['Content-Type'] = 'application/json'
    _r_h['If-Match'] = None
    _r_h['If-Modified-Since'] = None

    _s.update_headers(_r_h)


# Generated at 2022-06-12 00:23:05.295382
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.cli.context import Environment
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.exceptions import ParseError
    from httpie.cli.parser import parse_items

    args = parser.parse_args(args=[])
    env = Environment(vars(args), stdin=None, stdout=None, stderr=None)

    headers = {'Content-Type': 'application/json'}
    session = Session(path=DEFAULT_CONFIG_DIR / 'sessions/test_sessions.json')
    session.update_headers(headers)
    assert dict(session['headers']) == headers
    # Check whether the merged cookie didn't overwrite the previous one

# Generated at 2022-06-12 00:23:16.506016
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    test_headers_set = RequestHeadersDict({
        'status': 'code',
        'Accept': 'txt/html',
        'Cookie': 'CookieA=valueA; CookieB=valueB',
        'User-Agent': 'HTTPie/1.0.2',
        'If-Modified-Since': 'Wed, 21 Oct 2015 07:28:00 GMT'
    })
    session.update_headers(test_headers_set)

# Generated at 2022-06-12 00:23:27.943211
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class CookieMock:
        def __init__(self, name, value):
            self.name = name
            self.value = value
    class SimpleCookieMock:
        def __init__(self, value):
            import json
            decoded_value = json.loads(value)
            self.items = []
            for key in decoded_value.keys():
                self.items.append((key, CookieMock(key, decoded_value[key])))
            self.items = iter(self.items)
    class MockRequestHeadersDict(RequestHeadersDict):
        def __init__(self, headers):
            self.headers = headers
        def __iter__(self):
            return iter(self.headers.keys())

# Generated at 2022-06-12 00:23:41.153233
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    headers = {
        'a': '1',
        'b': '2',
        '3': '3',
        'User-Agent': 'Hello World',
        'Cookie': 'abc=123',
        'Content-Type': 'application/json',
        'If-Match': '*'
    }
    session.update_headers(RequestHeadersDict(headers))
    print(session.headers)
    print(session.cookies)
    assert session.headers == RequestHeadersDict({
        'a': '1',
        'b': '2',
        '3': '3',
    })
    assert session.cookies == RequestsCookieJar()
    session.cookies.set('abc', '123')
    session.cookies.set('def', '456')


# Generated at 2022-06-12 00:23:52.141905
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # First check an empty session
    session = Session('/tmp/test-session.json')
    session.remove_cookies(['a'])
    assert session['cookies'] == {}

    # Then check a session with two active cookies
    session = Session('/tmp/test-session.json')
    session['cookies'] = {}
    session['cookies']['a'] = {'value': '1'}
    session['cookies']['b'] = {'value': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {}
    session['cookies'] = {}
    session['cookies']['a'] = {'value': '1'}
    session['cookies']['b'] = {'value': '2'}
    session.remove_cook

# Generated at 2022-06-12 00:23:59.628524
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    names = ['name1', 'name2', 'name3']
    for name in names:
        session['cookies'][name] = {'value': 'test'}
    assert len(session['cookies']) == 3
    session.remove_cookies(['name1', 'name3'])
    assert len(session['cookies']) == 1
    assert 'name2' in session['cookies']
    session['cookies'].clear()



# Generated at 2022-06-12 00:24:05.165467
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path())
    assert type(session) is Session
    assert type(session['cookies']) is dict
    session['cookies']['aduck'] = 'quack'
    assert session['cookies']['aduck'] == 'quack'
    session.remove_cookies(['aduck'])
    with pytest.raises(KeyError):
        assert session['cookies']['aduck']

# Generated at 2022-06-12 00:24:11.065522
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    session = Session('/tmp/junk')
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie('cookie1', 'value1'))
    session.cookies.set_cookie(create_cookie('cookie2', 'value2'))
    session.cookies.set_cookie(create_cookie('cookie3', 'value3'))
    session.cookies.set_cookie(create_cookie('cookie4', 'value4'))

    session.remove_cookies(['cookie2', 'cookie3'])

    assert len(session.cookies) == 2
    assert session.cookies['cookie1'].value == 'value1'
    assert session.cookies['cookie4'].value == 'value4'

# Generated at 2022-06-12 00:24:17.120683
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=None)

    # already in session
    session['headers'] = {'some-header':'v1'}

    # not in session
    request_headers = RequestHeadersDict({'some-header':'v1', 'some-other-header':'v2'})
    session.update_headers(request_headers=request_headers)
    assert session['headers']['some-header'] == 'v1'
    assert session['headers']['some-other-header'] == 'v2'

    # use first value if header was already in request headers
    request_headers = RequestHeadersDict({'some-header':'v2', 'some-other-header':'v2'})
    session.update_headers(request_headers=request_headers)

# Generated at 2022-06-12 00:24:23.747123
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    class MySession(Session):
        pass
    session = MySession('./sessions.json')
    session['cookies'] = {'name1': 'cookie1', 'name2': 'cookie2', 'name3': 'cookie3'}
    session.remove_cookies(['name2'])
    assert session['cookies'] == {'name1': 'cookie1', 'name3': 'cookie3'}

# Generated at 2022-06-12 00:24:29.562948
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict()
    headers.add('Accept','text/html')
    headers.add('Host','httpbin.org')
    headers.add('Cookie','key1=value1')
    headers.add('Cookie','key2=value2')
    headers.add('Cookie2','key3=value3')
    headers.add('Content-Type','text/html')
    headers.add('content-type','text/html')
    headers.add('If-Match','xxxxxx')
    s = Session(path="testfile.json")
    s.update_headers(headers)

# Generated at 2022-06-12 00:24:37.358555
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session.update({'cookies': 
        {'cookie1': {'key1': 'value1'}, 
        'cookie2': {'key2': 'value2'},
        'cookie3': {'key3': 'value3'}}})
    session.remove_cookies(names=['cookie1', 'cookie2'])
    assert session.get_dict() == {'cookies': {'cookie3': {'key3': 'value3'}}}

# Generated at 2022-06-12 00:24:41.271811
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_dict = {'headers': {}, 'cookies': {'cookie_name': {}}}
    test_session = Session('/')
    test_session.update(test_dict)
    test_session.remove_cookies(['cookie_name'])
    assert test_dict['cookies'] == {}

# Generated at 2022-06-12 00:24:58.658655
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = '/test/test.json'
    test_session = Session(session_path)
    test_session['cookies'] = {
        'test_cookie1': {
            'domain': 'test_domain1.org',
            'value': 'test_value1'
        },
        'test_cookie2': {
            'domain': 'test_domain2.org',
            'value': 'test_value2'
        },
        'test_cookie3': {
            'domain': 'test_domain3.org',
            'value': 'test_value3'
        },
        'test_cookie4': {
            'domain': 'test_domain4.org',
            'value': 'test_value4'
        }
    }

# Generated at 2022-06-12 00:25:09.206320
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/nonexisting-file')
    assert {} == s.cookies
    s.cookies = RequestsCookieJar()
    s.cookies.set_cookie(create_cookie('a', '1'))
    s.cookies.set_cookie(create_cookie('b', '2'))
    assert {'a': {'value': '1'}, 'b': {'value': '2'}} == s.cookies
    
    s.remove_cookies(['a', 'b'])
    assert {} == s.cookies
    s.cookies = RequestsCookieJar()
    s.cookies.set_cookie(create_cookie('a', '1'))
    s.cookies.set_cookie(create_cookie('b', '2'))

# Generated at 2022-06-12 00:25:14.100371
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names=['a','b']  
    session_cookies = {'a':'1','b':'2','c':'3'}
    session = Session(path = "a/b")
    session.cookies = session_cookies
    session.remove_cookies(names)
    assert(session.cookies != session_cookies)

# Generated at 2022-06-12 00:25:17.088019
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'a', 'b':'b'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 'b'}

# Generated at 2022-06-12 00:25:23.375326
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies_dict = {
        'cookie1': {'value': 'val-cookie1', 'path': '/'},
        'cookie2': {'value': 'val-cookie2', 'path': '/'},
        'cookie3': {'value': 'val-cookie3', 'path': '/'},
    }
    cookies_names = ['cookie1', 'cookie2']

    session = Session('')
    session['cookies'] = cookies_dict
    session.remove_cookies(cookies_names)

    assert len(session['cookies']) == 1
    assert 'cookie1' not in session['cookies']
    assert 'cookie2' not in session['cookies']
    assert 'cookie3' in session['cookies']

# Generated at 2022-06-12 00:25:28.482632
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path = "test.json")
    session['cookies'] = {'cookie_1': {'value': 'abc', 'path': '/'}, 'cookie_2': {'value': 'def', 'path': '/'}}
    session._Session__remove_cookies(['cookie_1'])
    assert session._Session__cookies == {'cookie_2': {'value': 'def', 'path': '/'}}

# Generated at 2022-06-12 00:25:36.140453
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_session = Session('test.json')
    test_session['cookies'] = {
        'test_cookie': {'value': 'test_value'},
        'test_cookie_2': {'value': 'test_value_2'}
    }
    test_session.remove_cookies(['test_cookie_2'])
    assert test_session['cookies'] == {
        'test_cookie': {'value': 'test_value'}
    }
# End of unit test

# Generated at 2022-06-12 00:25:41.176904
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/httpie/test.json')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a', 'c'])
    assert session == {'cookies': {}, 'headers': {}}


# Generated at 2022-06-12 00:25:46.431019
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/path/to/session')
    session.cookies = RequestsCookieJar()
    session['cookies'] = {'cooki': '-1', 'cookie': '0', 'cookie2': '1'}
    session.remove_cookies('cookie')
    assert 'cookie' not in session['cookies']

# Generated at 2022-06-12 00:25:55.903935
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """Test updating session headers"""
    session = Session('/dev/null')
    session.update_headers(RequestHeadersDict.parse('Content-Type: text/plain'))
    assert session['headers'] == {}
    session.update_headers(RequestHeadersDict.parse('If-None-Match: abc'))
    assert session['headers'] == {}
    session.update_headers(RequestHeadersDict.parse('Cookie: abc'))
    assert session['cookies'] == {'abc': {'value': 'abc'}}
    session.update_headers(RequestHeadersDict.parse('Cookie: xyz'))
    assert session['cookies'] == {'abc': {'value': 'abc'}, 'xyz': {'value': 'xyz'}}

# Generated at 2022-06-12 00:26:13.380438
# Unit test for method update_headers of class Session

# Generated at 2022-06-12 00:26:15.716365
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {'Content-Type': 'text/xml'}
    session = Session(path=Path(''))
    session.update_headers(headers)
    assert session['headers'] == {}

# Generated at 2022-06-12 00:26:25.912248
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # init
    cookies_data = {}
    headers_data = {}
    cookies_jar = RequestsCookieJar()
    for cookie_name, cookie_value in cookies_data.items():
        cookies_jar.set_cookie(create_cookie(name=cookie_name, value=cookie_value))
    request_headers = RequestHeadersDict(headers_data)

    session = Session(path=os.path.join('.', 'test_session.json'))
    session.load()

    # test
    session.update_headers(request_headers)

    # verify
    assert session.headers == request_headers
    assert session.cookies == cookies_jar

    # delete
    os.remove(os.path.join('.', 'test_session.json'))

# Generated at 2022-06-12 00:26:34.950292
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import io
    import json

    new_Session = Session("Session_file")
    new_Session.headers = {'Accept': 'application/json'}
    new_Session.update_headers({'Accept': 'application/json',
                                'content-type': 'application/json'})
    new_Session.save(io.StringIO())

    s = json.load(io.StringIO())
    assert(s['headers']['Accept'] == 'application/json')
    assert('content-Type' in s['headers'])

if __name__ == "__main__":
    test_Session_update_headers()

# Generated at 2022-06-12 00:26:40.023224
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test")
    session["cookies"] = {'test': 'test'}
    assert session["cookies"] == {'test': 'test'}
    session.remove_cookies(['test'])
    assert session["cookies"] == {}



# Generated at 2022-06-12 00:26:48.099986
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('mock_session.json')

    cookies = {
        'cookie1': {
            'value': 'value1'
        },
        'cookie2': {
            'value': 'value2'
        },
        'cookie3': {
            'value': 'value3'
        },
    }
    session['cookies'] = cookies
    session.remove_cookies(['cookie1'])
    assert cookies == {
        'cookie2': {
            'value': 'value2'
        },
        'cookie3': {
            'value': 'value3'
        },
    }

# Generated at 2022-06-12 00:26:51.676670
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    container = Session(path='./test.json')
    container['cookies'] = {
        "name": {},
        "age": {},
    }
    container.remove_cookies(['name'])
    assert list(container['cookies'].keys()) == ["age"]

# Generated at 2022-06-12 00:26:54.365238
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("cookies")
    s['cookies'] = {'name': {'value':'test'}}
    s.remove_cookies(['name'])
    assert 'name' not in s['cookies']

# Generated at 2022-06-12 00:27:01.189219
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Test test_Session_remove_cookies removes cookies as expected when one of
    the cookies is not present in the session.
    """
    session = Session('session_path')
    session['cookies'] = {'present_cookie' : 'abc123'}
    session.remove_cookies(['present_cookie', 'not_present_cookie'])
    assert session['cookies'] == {'present_cookie' : 'abc123'}

# Generated at 2022-06-12 00:27:02.819841
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sesh = Session(path='sesh.json')
    sesh.remove_cookies(['cat'])

# Generated at 2022-06-12 00:27:22.811553
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session({'cookies':{'a': 1,'b': 2, 'c':3}})
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-12 00:27:27.372303
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json
    import tempfile

    tfile = tempfile.NamedTemporaryFile(mode="w", delete=False)

    session = Session(tfile.name)
    session.load()

    session.cookies = [{"name": "test", "value": "test"}]
    session.remove_cookies(["test"])

    assert session.cookies.__str__() == "[]"


# Generated at 2022-06-12 00:27:31.068475
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'foo': 'bar', 'baz': 'qux'}

    session.remove_cookies(['baz'])

    assert session['cookies'] == {'foo': 'bar'}



# Generated at 2022-06-12 00:27:39.599883
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test.json")
    assert len(session['cookies']) == 0
    session['cookies']['foo'] = {'value': 'bar'}
    assert len(session['cookies']) == 1
    assert session['cookies']['foo']['value'] == 'bar'
    session.remove_cookies(['foo'])
    assert len(session['cookies']) == 0
    session['cookies']['foo'] = {'value': 'bar'}
    assert len(session['cookies']) == 1
    assert session['cookies']['foo']['value'] == 'bar'
    session.remove_cookies(['bar'])
    assert len(session['cookies']) == 1

# Generated at 2022-06-12 00:27:48.225641
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_1 = Session(path='test.json')
    session_1['cookies'] =  {'cookie_1': {'value':'cookie_1'}, 'cookie_2': {'value':'cookie_2'}}
    session_1.remove_cookies(['cookie_1', 'cookie_3'])
    assert session_1.cookies == RequestsCookieJar([create_cookie('cookie_2', 'cookie_2')])



# Generated at 2022-06-12 00:27:58.647906
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    #Given
    session = Session('test_sessions/cookie_test.json')
    session['cookies'] = {
        'cookie1': {'value': 'value1', 'expires': 0},
        'cookie2': {'value': 'value2', 'expires': 0},
        'cookie3': {'value': 'value3', 'expires': 0},
        'cookie4': {'value': 'value4', 'expires': 0},
    }

    #When
    session.remove_cookies(['cookie2', 'cookie3'])
    #Then
    assert session['cookies'] == {
        'cookie1': {'value': 'value1', 'expires': 0},
        'cookie4': {'value': 'value4', 'expires': 0},
    }

# Generated at 2022-06-12 00:28:06.330418
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('a')
    a1 = {'value': 'a1', 'path': 'a1', 'secure': 'a1', 'expires': 'a1'}
    a2 = {'value': 'a2', 'path': 'a2', 'secure': 'a2', 'expires': 'a2'}
    b1 = {'value': 'b1', 'path': 'b1', 'secure': 'b1', 'expires': 'b1'}
    c1 = {'value': 'c1', 'path': 'c1', 'secure': 'c1', 'expires': 'c1'}
    session['cookies'] = {'a1': a1, 'a2': a2, 'b1': b1, 'c1': c1}

# Generated at 2022-06-12 00:28:11.005494
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('dummy/path')
    session['cookies'] = {
        'foo': {'value': 'bar'},
        'spam': {'value': 'eggs'},
    }
    session.remove_cookies(['spam'])
    assert session['cookies'] == {
        'foo': {'value': 'bar'},
    }



# Generated at 2022-06-12 00:28:14.035827
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('A')
    s['cookies'] = {'A': {}, 'B': {}, 'C': {}}
    s.remove_cookies(['A', 'C'])
    assert s['cookies'] == {'B': {}}

# Generated at 2022-06-12 00:28:18.154566
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_string = "key1=value1; key2=value2; key3=value3; key4=value4"
    session = Session('dummy_path')
    session.cookies = SimpleCookie(cookie_string)
    session.remove_cookies(['key4'])
    assert 'key4' not in session.cookies

# Generated at 2022-06-12 00:28:45.370736
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("/root/path")
    session["cookies"]["cookie1"] = { "value" : "cookie1-value"}
    session["cookies"]["cookie2"] = { "value" : "cookie2-value"}
    session["cookies"]["cookie3"] = { "value" : "cookie3-value"}
    session["cookies"]["cookie4"] = { "value" : "cookie4-value"}
    session["cookies"]["cookie5"] = { "value" : "cookie5-value"}
    session["cookies"]["cookie6"] = { "value" : "cookie6-value"}
    session["cookies"]["cookie7"] = { "value" : "cookie7-value"}

# Generated at 2022-06-12 00:28:51.499620
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/path/to/session/file')
    session['cookies'] = {
        'cookie1': {
            'value': 'value1',
            'key2': 'value2'
        },
        'cookie2': {
            'value': 'value3',
        }
    }
    session.remove_cookies(['cookie1'])
    session_cookies = session['cookies']
    assert 'cookie1' not in session_cookies
    assert 'cookie2' in session_cookies


# Generated at 2022-06-12 00:29:00.635755
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('tmp.json')
    session['cookies'] = {"cookie1": {'value': 'a', 'path': '/'},
                          "cookie2": {'value': 'b', 'path': '/'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {"cookie2": {'value': 'b', 'path': '/'}}
    assert session['cookies'].keys() == {"cookie2"}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}
    assert session['cookies'].keys() == set()
    session['cookies'] = {"cookie1": {'value': 'a', 'path': '/'},
                          "cookie2": {'value': 'b', 'path': '/'}}
    session.remove_

# Generated at 2022-06-12 00:29:06.170828
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path('~/.httpie/sessions/MockHost/my_session.json'))
    session['cookies'] = {'cookie_abc': {'value': 'abc', 'path': '/'}, 'cookie_def': {'value': 'def', 'path': '/'}}
    session.remove_cookies(['cookie_abc'])
    assert 'cookie_abc' not in session['cookies']
    assert 'cookie_def' in session['cookies']

# Generated at 2022-06-12 00:29:10.402166
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("tests/sessions/example.json")
    session.load()
    session.remove_cookies("bad_cookie")
    assert "a" in session.cookies
    assert session.cookies["a"].value == "b"
    assert "bad_cookie" not in session.cookies


# Generated at 2022-06-12 00:29:14.025013
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session({})
    session['cookies'] = {'c1': 'value1', 'c2': 'value2', 'c3': 'value3'}
    session.remove_cookies(['c1', 'c3'])

    assert session['cookies'] == {'c2': 'value2'}

# Generated at 2022-06-12 00:29:19.083856
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='path')
    session['cookies'] = {
        'name1': {'value': 'value'},
        'name2': {'value': 'value'},
        'name3': {'value': 'value'}
    }
    session.remove_cookies(('name1','name2','name4'))
    assert session['cookies'] == {'name3': {'value': 'value'}}

# Generated at 2022-06-12 00:29:24.025462
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import pytest
    s = Session("None")
    s['cookies'] = {'V1': '1', 'V2': '2'}
    s.remove_cookies(['V2'])
    assert s['cookies'] == {'V1': '1'}
    with pytest.raises(KeyError):
        s.remove_cookies(['NOT_FOUND'])

# Generated at 2022-06-12 00:29:27.574189
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('foo.json')
    session['cookies'] = {'foo': 'bar'}
    session.remove_cookies(['foo'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:29:32.672700
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_session = Session("./test_session.json")
    test_cookies = {"name":"value"}
    test_session['cookies'] = test_cookies
    test_session.remove_cookies(['not_the_name_of_any_cookie'])
    assert test_session['cookies'] == test_cookies
    test_session.remove_cookies(['name'])
    assert test_session['cookies'] == {}