

# Generated at 2022-06-12 00:19:49.039942
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    obj=Session('.httpie/sessions/test')
    obj.load()
    names=['Access-Token','User-Token','Cookie']
    obj.remove_cookies(names)
    assert 'Access-Token' not in obj.cookies
    assert 'User-Token' not in obj.cookies
    assert 'Cookie' not in obj.cookies

# Generated at 2022-06-12 00:19:53.725903
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict(
        {'Content-Type': 'application/json',
         'Content-Length': '2'})
    session = Session('a_file')
    session.update_headers(headers)

    assert len(session['headers']) == len(
        headers) - 2  # 2 headers ignored



# Generated at 2022-06-12 00:20:06.067925
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    request_headers = RequestHeadersDict(
        {'Content-Type': 'application/x-www-form-urlencoded'})
    session.update_headers(request_headers)

    assert session.get('headers') == {}

    request_headers = RequestHeadersDict(
        {'User-Agent': 'HTTPie/1.0.0'})
    session.update_headers(request_headers)

    assert session.get('headers') == {}

    request_headers = RequestHeadersDict(
        {'Host': 'www.google.com'})
    session.update_headers(request_headers)

    assert session.get('headers') == {
        'Host': 'www.google.com'
    }

# Generated at 2022-06-12 00:20:09.030109
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path())
    session['cookies'] = {'cookie_name': 'cookie_value'}
    session.remove_cookies(['cookie_name'])
    assert len(session['cookies']) == 0


# Generated at 2022-06-12 00:20:14.909084
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_dict=RequestHeadersDict()
    test_dict['test-name']='test-value'
    test_Session_update_headers=Session('../config')
    test_Session_update_headers.update_headers(test_dict)
    assert test_Session_update_headers.headers['test-name']=='test-value'

# Generated at 2022-06-12 00:20:25.885623
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Tests case when the header value is in string
    session = Session('test_session.json')
    session['headers']['test_header1'] = 'foo'
    session['headers']['content-type'] = 'application/json'
    session['headers']['if-match'] = 'some-etag'

    request_headers = RequestHeadersDict(
        {'test_header1': 'bar', 'Content-Type': 'text/html', 'If-Match': 'etag'}
    )
    session.update_headers(request_headers)
    assert session['headers'] == {
        'test_header1': 'bar', 'Content-Type': 'text/html', 'If-Match': 'etag'
    }
    
    # Tests case when the header value is in bytes

# Generated at 2022-06-12 00:20:30.445951
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path = "")
    request_headers = {"User-Agent": "HTTPie/1.0.3", "Host": "httpbin.org"}
    session.update_headers(request_headers)
    assert session.headers == {'user-agent': 'HTTPie/1.0.3', 'host': 'httpbin.org'}

# Generated at 2022-06-12 00:20:41.709438
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')

# Generated at 2022-06-12 00:20:48.149584
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import requests
    import requests.auth
    import requests.cookies
    import requests.structures
    from httpie.config import BaseConfigDict
    from httpie.plugins import AuthPlugin, HTTPBasicAuth
    from httpie.utils import get_response

    class SampleAuthPlugin(AuthPlugin):
        auth_type = 'sample'
        auth_parse = False
        auth_require = False
        auth_help = ''

        def get_auth(self, username, password):
            raise NotImplementedError()

    class TestSession(BaseConfigDict):
        about = 'Session for testing'

        def __init__(self, path):
            self.path = path
            self.headers = {}
            self.cookies = {}

# Generated at 2022-06-12 00:20:55.340738
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_path = Path('~/.httpie/sessions/www.google.com/google.json')
    session = Session(session_path)
    session.load()

    request_headers = RequestHeadersDict({
        'HTTPIE_SESSION_NAME': 'google',
        'Content-Type': None,
        'User-Agent': 'HTTPie/0.9.9',
        'Cookie': 'test=test',
        'If-Match': 'test'
    })

    session.update_headers(request_headers)

    print(session_path)
    print(session['headers'])


if __name__ == '__main__':
    test_Session_update_headers()

# Generated at 2022-06-12 00:21:06.244909
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path='/dev/null')
    s['cookies'] = {
        'cookie_name': {'value': 'cookie_value'},
        'cookie_name2': {'value': 'cookie_value2'}
    }
    s.remove_cookies(['cookie_name'])
    assert s['cookies'] == {'cookie_name2': {'value': 'cookie_value2'}}

# Generated at 2022-06-12 00:21:08.050484
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass

# Generated at 2022-06-12 00:21:12.814985
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test_Session_remove_cookies.json')
    s['cookies'] = {'a': {'value': 12}, 'b': {'value': 34}}
    s.remove_cookies(['b'])
    assert s['cookies'] == {'a': {'value': 12}}

# Generated at 2022-06-12 00:21:17.434109
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    a_dict = {}
    a_dict['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    a_Session = Session("test")
    a_Session['cookies'] = a_dict['cookies']
    names = ['a', 'b']
    a_Session.remove_cookies(names)
    assert a_Session['cookies'] == {'c': 3}

# Generated at 2022-06-12 00:21:21.462766
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.sessions import Session

    session = Session(Path('/dev/null'))
    session.update_headers({'Cookie': 'foo=bar'})
    assert session.cookies

    session.remove_cookies(['foo'])
    assert not session.cookies

# Generated at 2022-06-12 00:21:26.688199
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'one': 1, 'two': 2, 'three': 3}
    names = ['one', 'two', 'three']
    session = Session(None)
    session['cookies'] = cookies
    session.remove_cookies(names)

    assert session['cookies'] == {}

# Generated at 2022-06-12 00:21:38.441784
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test: remove a cookie inside session
    session = Session('session/path/123.json')
    session['cookies']['cookie1'] = 'cookie-value'
    session['cookies']['cookie2'] = 'cookie-value'
    session.remove_cookies(['cookie1'])
    assert list(session['cookies'].keys()) == ['cookie2']
    # Test: remove a cookie not inside session
    session.remove_cookies(['cookie3'])
    assert list(session['cookies'].keys()) == ['cookie2']
    # Test: remove all cookies inside session
    session.remove_cookies(['cookie2'])
    assert list(session['cookies'].keys()) == []
    # Test: remove cookies with empty cookie name

# Generated at 2022-06-12 00:21:43.292461
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session=Session("tests/session.json")
    assert session["headers"] == {'header1': 'value11', 'header2': 'value2'}
    session.update_headers({'header1': 'value12', 'header4': 'value4'})
    assert session["headers"] == {'header1': 'value12', 'header2': 'value2', 'header4': 'value4'}

# Generated at 2022-06-12 00:21:47.413773
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path = 'tester')
    session['cookies'] = {'a': 123, 'b': 234, 'c': 345}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 234}

# Generated at 2022-06-12 00:21:57.605457
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.plugins import AuthPlugin, plugin_manager
    from httpie.cli.argtypes import KeyValueArg
    from collections import namedtuple

    def l(s):
        return s.lower()

    class DummyAuthPlugin(AuthPlugin):
        auth_type = 'dummy'
        auth_parse = True
        auth_require = False
        auth_help = 'dummy help'

        def get_auth(self, username, password):
            from requests.auth import HTTPBasicAuth
            return HTTPBasicAuth(username, password)

        def get_auth_from_url(self, url):
            return KeyValueArg(url).key, 'password'

        def get_auth_from_args(self, args):
            return args['--auth-type'], args['--auth']


# Generated at 2022-06-12 00:22:07.636444
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('s')
    s['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}, 'c': {'value': '3'}}
    s.remove_cookies(['a', 'c'])
    assert s['cookies'] == {'b': {'value': '2'}}


# Generated at 2022-06-12 00:22:12.923272
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_file')
    session['cookies'] = {'cookie1':{'value':'value1'},'cookie2':{'value':'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2':{'value': 'value2'}}
    session.remove_cookies(['cookie3'])
    assert session['cookies'] == {'cookie2':{'value': 'value2'}}

# Generated at 2022-06-12 00:22:17.894477
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(path=Path('session_path'))
    headers = {'key1': ['val1', 'val2'], 'key2': 'val3', 'key3': ''}
    s.update_headers(RequestHeadersDict(headers))
    assert s.headers == {'key1': 'val2', 'key2': 'val3'}

# Generated at 2022-06-12 00:22:26.779838
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/new_session.json')
    assert not session.is_dirty()
    session['cookies'] = {
        'cookie1': {'value': 'value1'},
        'cookie2': {'value': 'value2'},
        'cookie3': {'value': 'value3'},
    }
    assert session.is_dirty()
    assert len(session['cookies']) == 3
    session.remove_cookies(['cookie2'])
    assert len(session['cookies']) == 2
    assert 'cookie2' not in session['cookies']

# Generated at 2022-06-12 00:22:30.241333
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/httpie.json')
    session['cookies'] = {'a':{'path':'/a'}, 'b':{'path':'/b'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b':{'path':'/b'}}

# Generated at 2022-06-12 00:22:42.431169
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import json
    import requests

    session = Session('/tmp/sessions/1/2/1.json')
    session.clear()

    url = 'https://httpbin.org/get'

    # 'Accept': 'application/json',
    headers = requests.utils.default_headers()
    headers.update({'Accept': 'application/json'})

    # 'Content-Type': 'application/json',
    headers.update({'Content-Type': 'application/json'})

    # 'Host': 'httpbin.org',
    headers.update({'Host': 'httpbin.org'})

    resp = requests.get(url, headers=headers)
    raw_resp = resp.raw
    resp = resp.json()

    # 'User-Agent': 'python-requests/2.24.0',
    headers.update

# Generated at 2022-06-12 00:22:53.246897
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test removing a single cookie
    session = Session("Test session")
    session['cookies'] = {'test_name': 'test_value'}
    session.remove_cookies(['test_name'])
    assert session['cookies'] == {}

    # Test removing multiple cookies
    session = Session("Test session")
    session['cookies'] = {'test_name': 'test_value'}
    session['cookies'] = {'test_name_2': 'test_value_2'}
    session.remove_cookies(['test_name', 'test_name_2'])
    assert session['cookies'] == {}

    # Test removing multiple cookies when cookies already removed
    session = Session("Test session")
    session['cookies'] = {'test_name': 'test_value'}

# Generated at 2022-06-12 00:22:56.931607
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_cookies = {'my_cookie1': {'value': 'my_value'}, 'my_cookie2': {'value': 'my_value2'}}
    session = Session('session.json')
    session['cookies'] = session_cookies
    session.remove_cookies(['my_cookie2'])
    assert 'my_cookie2' not in session['cookies']
    assert 'my_cookie1' in session['cookies']

# Generated at 2022-06-12 00:23:01.223987
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/httpie.')
    session.update_headers({'Content-Type': 'application/json', 'Cookie': 'a=1'})
    assert session['headers'].get('Content-Type') is None
    assert session['headers'].get('Cookie') is None
    assert session['cookies'].get('a') is not None

# Generated at 2022-06-12 00:23:10.091530
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    from httpie.context import Environment
    from httpie.cli.argtypes import KeyValueArg
    from httpie.plugins.core import get_response

    env = Environment(
        headers=[
        ],
        ignore_stdin=True,
        output_options={},
        stdin=None,
        stdin_isatty=False,
        stdout_isatty=False,
        verify=True,
        config_dir=Path('/home/httpie/.config/httpie'),
        config_path=None,
        config_dict={},
    )

    session = get_httpie_session(env.config_dir, 'localhost', 'localhost', 'http://localhost/')
    request_headers = RequestHeadersDict(env.headers)
    session.update_headers(request_headers)

    session_headers_

# Generated at 2022-06-12 00:23:21.637598
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = DEFAULT_SESSIONS_DIR / 'SessionTest.json'
    session = Session(path)
    session.load()
    assert session['cookies'] == {}
    session['cookies'] = {'c1' : '', 'c2': ''}
    assert session['cookies'] == {'c1' : '', 'c2': ''}
    session.remove_cookies(['c1'])
    assert session['cookies'] == {'c2': ''}
    session.remove_cookies(['c3'])
    assert session['cookies'] == {'c2': ''}

# Generated at 2022-06-12 00:23:25.477990
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'a': 1, 'b': 2}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-12 00:23:30.875918
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('tmp')
    names = ['name']

    session['cookies'] = {'name': {'value': 'value'}}
    session.remove_cookies(names)
    assert 'name' not in session['cookies']

    session['cookies'] = {'name': {'value': 'value'}}
    session.remove_cookies(['other'])
    assert session['cookies'] == {'name': {'value': 'value'}}

# Generated at 2022-06-12 00:23:38.576573
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("test")
    s['cookies'] = {'cookies1': {'value': 'cookies1'},
                    'cookies2': {'value': 'cookies2'}}

    assert s['cookies'] == {'cookies1': {'value': 'cookies1'},
                            'cookies2': {'value': 'cookies2'}}

    s.remove_cookies(['cookies1'])

    assert s['cookies'] == {'cookies2': {'value': 'cookies2'}}

# Generated at 2022-06-12 00:23:43.640184
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies']={'a':'a','b':'b','c':'c'}
    session.remove_cookies(['a','b'])
    assert session['cookies']=={'c':'c'}

# Generated at 2022-06-12 00:23:50.251829
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test.json')
    session.cookies = RequestsCookieJar()
    session.cookies.set('foo', 'value1')
    session.cookies.set('bar', 'value2')
    session.remove_cookies(['foo'])
    assert session.cookies.get_dict() == {'bar': 'value2'}
    session.remove_cookies(['bar'])
    assert session.cookies.get_dict() == {}



# Generated at 2022-06-12 00:23:54.437383
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s['cookies'] = {'c1':{'value': 'test'},'c2':{'value':'test'},'c3':{'value':'test'}}
    s.remove_cookies(['c2','c3'])
    assert 'c1' in s['cookies']
    assert 'c2' not in s['cookies']


# Generated at 2022-06-12 00:24:01.990850
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_data = {
        'headers': {'foo': 'bar'},
        'cookies': {'bar': 'foo', 'baz': 'qux'}
    }
    session = Session('/dev/null')
    session.update(session_data)
    assert session['cookies']['bar'] == 'foo'
    session.remove_cookies(['bar'])
    assert 'bar' not in session['cookies']
    assert session['cookies']['baz'] == 'qux'

# Generated at 2022-06-12 00:24:08.572778
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Normal case
    session = Session("filepath")
    session['cookies'] = {"A":1, "B":2}
    session.remove_cookies({"A"})
    assert session['cookies'] == {"B":2}
    # No cookies
    session = Session("filepath")
    session['cookies'] = {}
    session.remove_cookies({"A"})
    assert session['cookies'] == {}
    # remove the last cookie
    session = Session("filepath")
    session['cookies'] = {"A":1}
    session.remove_cookies({"A"})
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:24:13.144210
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = (DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'localhost' / 'session.json')
    session = Session(path)
    session.load()
    session.remove_cookies(['cookie_name'])
    assert not session.get('cookies', {}).get('cookie_name', {})



# Generated at 2022-06-12 00:24:25.618557
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='path')
    session.update({'cookies': {'first_cookie': 'first_value'}})
    session.remove_cookies(names=['first_cookie'])

    assert session.get('cookies').get('first_cookie') is None

# Generated at 2022-06-12 00:24:36.575885
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session("/path/to/sessions/file")
    # create test dictionary/session
    sess['cookies'] = {'c1':{'value': 'v1'}, 'c2':{'value': 'v2'}}
    # remove c2
    sess.remove_cookies(['c2'])
    assert 'c1' in sess['cookies']
    assert 'c2' not in sess['cookies']

    # remove c1 and c2 (non-existing)
    sess.remove_cookies(['c1', 'c2'])
    # test that c1 has been removed
    assert 'c1' not in sess['cookies']
    assert 'c2' not in sess['cookies']

# Generated at 2022-06-12 00:24:40.124528
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test_session.json')
    s['cookies'] = {'foo': 'bar'}
    s.remove_cookies(['foo'])
    assert s['cookies'] == {}

# Generated at 2022-06-12 00:24:43.871678
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = 'path'
    session = Session(path=path)
    names = ['1', '2', '3', '4']
    session.remove_cookies(names)



# Generated at 2022-06-12 00:24:52.095048
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies')
    session['headers'] = {'key1': 'value1'}
    session['cookies'] = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    session['auth'] = {'type': 'key1', 'username': 'key1', 'password': 'key1'}
    session.remove_cookies(values=[])
    assert len(session['cookies']) == 3
    session.remove_cookies(values=['key1', 'key2'])
    assert session['cookies'] == {'key3': 'value3'}
    # TODO: The code below is for demo only, please remove
    print('Session.remove_cookies:')
    print('Expected output:')

# Generated at 2022-06-12 00:24:56.063413
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('~/.config/httpie/sessions')
    session['cookies']['hello'] = "world"
    session.remove_cookies(['hello'])

    assert 'hello' not in session['cookies']


# Generated at 2022-06-12 00:25:03.217997
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path=Path(__file__))
    s.update_headers(RequestHeadersDict({'cookie': 'foo=bar;spam=egg'}))
    assert 'foo' in s['cookies']
    assert 'spam' in s['cookies']
    s.remove_cookies(['spam'])
    assert 'foo' in s['cookies']
    assert 'spam' not in s['cookies']

# Generated at 2022-06-12 00:25:08.860287
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(os.path.sep)
    session['cookies'] = {'a': 'valueA',
                          'b': 'valueB',
                          'c': 'valueC',
                          'd': 'valueD'}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 'valueC', 'd': 'valueD'}



# Generated at 2022-06-12 00:25:17.914058
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session.json')
    session['cookies'] = {
        'test1': {'value': 'test1', 'path': '/'},
        'test2': {'value': 'test2', 'path': '/'},
        'test3': {'value': 'test3', 'path': '/'},
        'test4': {'value': 'test4', 'path': '/'},
    }
    session.remove_cookies(['test1', 'test3'])
    assert session['cookies'] == {
        'test2': {'value': 'test2', 'path': '/'},
        'test4': {'value': 'test4', 'path': '/'},
    }


# Generated at 2022-06-12 00:25:24.919069
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    a_session: Session = Session('path')
    cookies_dict = dict()
    cookies_dict['name_to_remove'] = {'value': 'value'}
    cookies_dict['name_to_keep'] = {'value': 'value'}
    a_session['cookies'] = cookies_dict
    a_session.remove_cookies(['name_to_remove'])
    assert 'name_to_remove' not in a_session['cookies']
    assert 'name_to_keep' in a_session['cookies']



# Generated at 2022-06-12 00:25:47.309904
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('a')
    session['cookies'] = {'aaa' : 1, 'bbb' : 2, 'ccc' : 3}
    session.remove_cookies(['aaa', 'ccc'])

    assert session['cookies'] == {'bbb' : 2}

# Generated at 2022-06-12 00:25:52.701322
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}
    session.remove_cookies(['c'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:25:57.549655
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = DEFAULT_SESSIONS_DIR / 'localhost/my_session.json'
    session = Session(session_path)
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}, 'cookie3': {'value': 'value3'}}
    session.remove_cookies({'cookie2', 'cookie3'})
    assert session.cookies == {'cookie1': {'value': 'value1'}}


# Generated at 2022-06-12 00:26:02.491392
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import pytest
    session = Session(DEFAULT_SESSIONS_DIR)
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}



# Generated at 2022-06-12 00:26:11.888641
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='.')
    session['headers'] = {}
    session['cookies'] = {
        'session': {'value': '1'},
        'user': {'value': 'admin'}
    }
    session['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }

    session.remove_cookies(['session', 'user'])
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-12 00:26:18.054408
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session.__new__(Session)
    session['cookies'] = {'c1':{'value': '1'}, 'c2':{'value': '2'}, 'c3':{'value': '3'}}
    session.remove_cookies(['c2', 'c4'])
    assert session['cookies'] == {'c1':{'value': '1'}, 'c3':{'value': '3'}}



# Generated at 2022-06-12 00:26:21.828769
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    assert not s.remove_cookies(['cookie1', 'cookie2'])
    s['cookies'] = {'cookie1': {'value': '1'}}
    s.remove_cookies(['cookie1'])
    assert not s['cookies']



# Generated at 2022-06-12 00:26:28.796218
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = 'sessions/localhost/foo.json'
    session = Session(session_path)
    session['cookies'] = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

    session.remove_cookies(['key1'])
    assert session['cookies'] == {'key2': 'value2', 'key3': 'value3'}
    session.remove_cookies(['key2', 'key3'])
    assert session['cookies'] == {}
    session.remove_cookies(['key4'])
    assert session['cookies'] == {}



# Generated at 2022-06-12 00:26:32.908837
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('./test/session1.json')
    s.load()
    print(s.cookies)
    s.remove_cookies(['sessionid', 'token'])
    print(s.cookies)

# Generated at 2022-06-12 00:26:36.306449
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Tests the method remove_cookies of class Session.

    """
    session = Session(path=str())
    session['cookies'] = {'Cookie_A': {'value': '192.168.1.1'}}
    session.remove_cookies(['Cookie_A'])
    assert session['cookies'].keys() == []

# Generated at 2022-06-12 00:27:24.486600
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    class RequestCookies(RequestsCookieJar):
        def clear_expired_cookies(self):
            pass

    session = Session("test")
    session['cookies'] = {
        'name1': 'value1'
    }
    jar = RequestCookies()
    cookie = jar.set('name2', 'value2')
    session.cookies = jar
    session.remove_cookies(['name2'])
    assert session['cookies'] == {
        'name1': 'value1'
    }


# Generated at 2022-06-12 00:27:26.748966
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('');
    session['cookies'] = {'a': ['a'], 'b': ['b'], 'c': ['c']};
    names = ['a', 'b'];
    session.remove_cookies(names);
    assert session['cookies'] == {'c': ['c']};



# Generated at 2022-06-12 00:27:35.389655
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = get_httpie_session(DEFAULT_CONFIG_DIR,
        session_name = "test",
        host = "http://www.python.org",
        url = "http://www.python.org")
    try:
        session.save()
    except FileNotFoundError:
        pass
    with open(session.path, 'a') as f:
        f.write('{"cookies": {"a": {"value": "1"},'
                '"b": {"value": "2"},'
                '"c": {"value": "3"}}}')
    session.load()
    session.remove_cookies(('b','c','d'))
    assert (session['cookies'] == {'a': {'value': '1'}})

# Generated at 2022-06-12 00:27:39.283551
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("test_session")
    s['cookies'] = {'z': {'value': '1', 'path': '/'}, 'a': {'value': '2', 'path': '/'}, 'b': {'value': '3', 'path': '/'}}
    s.remove_cookies(['a', 'b'])
    x = {'z': {'value': '1', 'path': '/'}}
    assert s['cookies'] == x

# Generated at 2022-06-12 00:27:49.824038
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sesh = Session("./sesh.json")
    sesh['cookies']['c1'] = {
        'value': "42",
        'path': "/"
    }
    sesh['cookies']['c2'] = {
        'value': "1337",
        'path': "/"
    }
    sesh['cookies']['c3'] = {
        'value': "111",
        'path': "/"
    }
    sesh.remove_cookies(['c1', 'c3', 'c5'])
    assert(sesh['cookies'] == {'c2': {'value': '1337', 'path': '/'}})


# Generated at 2022-06-12 00:28:00.384468
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import requests
    s = Session('~/.httpie/sessions/google.com/google.json')
    cookie = requests.cookies.create_cookie(name='test_name', value='test_value')
    s.cookies.set_cookie(cookie)
    s.cookies.set_cookie(requests.cookies.create_cookie(name='test_name2', value='test_value2'))
    s.cookies.set_cookie(requests.cookies.create_cookie(name='test_name3', value='test_value3'))
    s.remove_cookies(['test_name2','test_name3'])
    assert 'test_name2' not in s.cookies
    assert 'test_name3' not in s.cookies
    assert 'test_name' in s.cookies

# Generated at 2022-06-12 00:28:08.541106
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Set up a mock configuration file
    import tempfile
    directory = tempfile.TemporaryDirectory()
    path = directory.name+'/test_session.json'
    s = Session(path)
    s.load()
    # Modify session "cookies"
    s['cookies'] = {'cookie1': {'value': 'value1'},
                    'cookie2': {'value': 'value2'},
                    'cookie3': {'value': 'value3'}}
    # Run remove_cookies
    s.remove_cookies(['cookie1', 'cookie2'])
    # Check if remove_cookies worked
    assert 'cookie1' not in s['cookies'].keys(), 'Cookie1 was not removed'

# Generated at 2022-06-12 00:28:13.952493
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    class TestSession(Session):
        def __init__(self, path: Union[str, Path]):
            super().__init__(path=Path(path))

    s = TestSession('/test.json')
    s['cookies'] = {'a': 'b', 'c': 'd'}
    s.remove_cookies(['a', 'c'])
    assert s['cookies'] == dict()



# Generated at 2022-06-12 00:28:23.766012
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    session = Session(path="")
    session["cookies"] = {}
    cookies = session["cookies"]
    assert cookies == {}

    session.remove_cookies(['name1', 'name2'])
    assert cookies == {}

    cookies["name1"] = {"value": 1}
    cookies["name2"] = {"value": 2}
    cookies["name3"] = {"value": 3}
    session.remove_cookies(['name2'])
    assert cookies == {"name1": {"value": 1}, "name3": {"value": 3}}

    session.remove_cookies(['name1', 'name2'])
    assert cookies == {"name3": {"value": 3}}

    session.remove_cookies(['name3', 'name4'])
    assert cookies == {}

# Generated at 2022-06-12 00:28:26.241340
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies']['name1'] = ['value1']
    session['cookies']['name2'] = ['value2']
    session.remove_cookies(['name1'])
    assert set(session['cookies'].keys()) == {'name2'}