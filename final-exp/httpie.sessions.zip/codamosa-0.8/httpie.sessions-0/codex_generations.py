

# Generated at 2022-06-12 00:19:53.033148
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict(
        {'Content-Type': 'application/json',
         'Accept': 'application/json',
         'client-version': '0.0.1'})
    session = Session('test_sessions.json')
    session.update_headers(request_headers)
    print(session)
    assert session.headers == ''

# Generated at 2022-06-12 00:20:03.232093
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("Testing")
    cookie1 = {"domain": "www.example.com", "name": "session_id", "path": "/", "expires": "-1", "value": "test"}
    cookie2 = {"domain": "www.example.com", "name": "session_token", "path": "/", "expires": "-1", "value": "test"}
    session['cookies'].update({cookie1['name']: cookie1, cookie2['name']: cookie2})
    session.remove_cookies(["session_id"])
    assert "session_id" not in session['cookies']

# Generated at 2022-06-12 00:20:11.993838
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(__file__)
    session.update_headers(RequestHeadersDict({"myheader": "myvalue"}))
    assert session["headers"] == {"myheader": "myvalue"}
    session.update_headers(RequestHeadersDict({"myheader": "myvalue2"}))
    assert session["headers"] == {"myheader": "myvalue2"}
    session.update_headers(RequestHeadersDict({"myheader2": "myvalue"}))
    assert session["headers"] == {"myheader": "myvalue2", "myheader2": "myvalue"}
    session.update_headers(RequestHeadersDict({"myheader": None}))
    assert session["headers"] == {"myheader2": "myvalue"}

# Generated at 2022-06-12 00:20:24.252571
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    class MockCookieJar(dict):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def clear_expired_cookies(self):
            pass

        def set_cookie(self, cookie):
            self[cookie.name] = cookie.value

        def iter_cookies(self, request):
            for cookie in self:
                yield cookie

        def clear(self):
            for cookie in self:
                del cookie

    session = Session('test.json')
    session.cookies = MockCookieJar(test1='abc', test2='def')
    session.remove_cookies(['test1'])
    assert session.cookies.test1 is None
    session.remove_cookies(['test2'])

# Generated at 2022-06-12 00:20:32.636240
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = '/dev/null'
    session = Session(path)
    session.load()
    session.update_headers({'header1': 'value1'})
    session.save()
    session.update_headers({'header2': 'value2'})
    session.save()
    session.update_headers({'session-header3': 'session-value3'})
    session.save()

    file_name = os.path.basename(path)
    file_path = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / file_name
    with open(file_path) as f:
        data = f.read()

    assert data.count('value1') == 1
    assert data.count('value2') == 1
    assert data.count('session-value3') == 1

# Generated at 2022-06-12 00:20:42.880038
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # create a mock session file
    session_path = './test_Session_remove_cookies.json'
    Session.create_empty(session_path)
    # create a session object
    session = Session(session_path)
    # populate fields 'cookies' with random values
    session['cookies']['blah'] = {'value': 'blah'}
    session['cookies']['blah2'] = {'value': 'blah2'}
    session['cookies']['blah3'] = {'value': 'blah3'}
    # remove cookies blah and blah2
    session.remove_cookies(['blah', 'blah2'])
    # validate cookies
    expected_cookies = {'blah3': {'value': 'blah3'}}

# Generated at 2022-06-12 00:20:53.219561
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test case 1
    key1 = '1st'
    val1 = 'val1'
    key2 = 'Cookie'
    val2 = 'val2'

    # Load session
    session = Session('session.json')
    session.load()

    # Test update_headers with request_headers that contain no cookies
    request_headers = {}
    request_headers[key1] = val1
    request_headers[key2] = val2
    session.update_headers(request_headers)

    # Check update_headers
    expect_headers = {}
    expect_headers[key1] = val1
    expect_headers[key2] = val2

    expect_cookies = {}
    expect_cookies[key1] = val1
    expect_cookies[key2] = val2


# Generated at 2022-06-12 00:20:57.594019
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict({"name": "jeff"})
    session = Session(Path('/test/session.json'))
    session.update_headers(headers)
    assert session.headers == RequestHeadersDict({"name": "jeff"})



# Generated at 2022-06-12 00:21:03.882888
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.config import BaseConfigDict

    # test for no attributes in session
    session = Session('../httpie/config')
    request_headers = BaseConfigDict({
        'Content-Type': 'application/json',
        'User-Agent': 'HTTPie/0.9.2',
        'Accept': None
    })
    session.update_headers(request_headers)

    assert session['headers'] == {}
    assert session['cookies'] == {
        'Content-Type': {'value': 'application/json'},
        'User-Agent': {'value': 'HTTPie/0.9.2'}
    }


# Generated at 2022-06-12 00:21:11.792727
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class Dict(dict):
        def __repr__(self):
            return str(self)

    session = Session('/tmp/test.json')

# Generated at 2022-06-12 00:21:19.510368
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('/path/to/session')
    request_headers = RequestHeadersDict({'Cookie': 'value'})
    s.update_headers(request_headers)
    return (s['cookies'], request_headers)

# Generated at 2022-06-12 00:21:26.995415
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Case 1. When header is a normal header, it should be stored in the session headers
    #         dictionary.
    session = Session('Session_test')
    request_headers = {'header1': 'bla', 'header2': 'bla', 'Header3': 'bla'}
    session.update_headers(request_headers)
    assert session.headers == {'header1': 'bla', 'header2': 'bla', 'Header3': 'bla'}

    # Case 2. When header is "cookie", it should be stored in the session cookies dictionary
    #         and shouldn't be stored in the session headers dictionary.
    session = Session('Session_test')
    request_headers = {'cookie': 'c=bla'}
    session.update_headers(request_headers)
    assert session.headers == {}

# Generated at 2022-06-12 00:21:38.636509
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # Given
    session = Session(path='ANY')
    request_headers = {}

    # When
    session.update_headers(request_headers)
    # Then
    assert session['headers'] == {}

    # Given
    session = Session(path='ANY')
    request_headers = {'ANY': None}

    # When
    session.update_headers(request_headers)
    # Then
    assert session['headers'] == {}

    # Given
    session = Session(path='ANY')
    request_headers = {'ANY': 'ANY'}

    # When
    session.update_headers(request_headers)
    # Then
    assert session['headers'] == {'ANY': 'ANY'}

    # Given
    session = Session(path='ANY')
    request_headers = {'ANY': 'ANY'}

    #

# Generated at 2022-06-12 00:21:40.866824
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session.json')
    session['cookies'] = {'name': 'value'}
    session.remove_cookies(['name'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:21:52.806090
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    my_session = Session('path/to/session.json')
    my_session.cookies = RequestsCookieJar()
    my_session.cookies.set('cookie_a', 'value_a', domain='localhost', path='/')
    my_session.cookies.set('cookie_b', 'value_b', domain='localhost', path='/')
    my_session.cookies.set('cookie_c', 'value_c', domain='localhost', path='/')
    my_assert(my_session.cookies, [('cookie_a', 'value_a'), ('cookie_b', 'value_b'), ('cookie_c', 'value_c')])
    my_session.remove_cookies(['cookie_a', 'cookie_c'])

# Generated at 2022-06-12 00:21:56.598516
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    path = 'test.json'
    session = Session(path)
    session['cookies'] = {'a' : 'a'}
    session['cookies']['b'] = 'b'
    session.remove_cookies(['b'])
    assert 'b' not in session['cookies']



# Generated at 2022-06-12 00:22:07.879012
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')

# Generated at 2022-06-12 00:22:14.817358
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session({})

    # Test ignoring certain name prefixes
    headers = RequestHeadersDict([
        ('Content-Type', 'application/json'),
        ('If-Match', '"a345"'),
        ('Accept', 'application/json'),
    ])
    session.update_headers(headers)
    assert session['headers'] == {'Accept': 'application/json'}

    # Test cookie
    headers = RequestHeadersDict([
        ('Cookie', 'foo=bar; spam=eggs'),
    ])
    session.update_headers(headers)
    assert session['cookies'] == \
        {'foo': {'value': 'bar'}, 'spam': {'value': 'eggs'}}
    assert headers == RequestHeadersDict([])



# Generated at 2022-06-12 00:22:20.414936
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    sess = Session('/var/lib/httpie/sessions/test.json')
    headers = {'Content-Type': 'application/json',
            'Cookie': 'k1=v1; k2=v2'}
    sess.update_headers(headers)
    assert sess.headers['Content-Type'] == 'application/json'
    assert sess['cookies']['k1'] == {'value': 'v1'}
    assert sess['cookies']['k2'] == {'value': 'v2'}

# Generated at 2022-06-12 00:22:30.526787
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.constants import DEFAULT_REQUEST_HEADERS
    session = Session("file.json")
    request_headers = RequestHeadersDict((
        ('Cookie', 'zap=5; zip=pow'),
        ('Cookie', 'zing=42'),
        ('Content-Length', '1024'),
        ('User-Agent', 'HTTPie/0.9.6'),
        ('Accept-Encoding', '   gzip, deflate'),
        ('Connection', 'keep-alive'),
        ('If-Modified-Since', 'Thu, 02 Feb 2012 23:26:42 GMT'),
    ))
    session.update_headers(request_headers)

    # check if the first cookie attribute zip is in the session
    assert session.headers['zip'] is not None

    # check if the other cookie attributes are in the session

# Generated at 2022-06-12 00:22:42.036549
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(DEFAULT_SESSIONS_DIR / 'test_session.json')
    s['cookies'] = {'c1': {'value': 'v1'}, 'c2': {'value': 'v2'}}
    assert s['cookies'] == {'c1': {'value': 'v1'}, 'c2': {'value': 'v2'}}
    s.remove_cookies(['c2'])
    assert s['cookies'] == {'c1': {'value': 'v1'}}

# Generated at 2022-06-12 00:22:50.556707
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # A Session instance for Unit test
    path = Path("/tmp/httpie/sessions/localhost/ut_session.json")
    session = Session(path)

    # Add a cookie to the session instance
    old_cookie = {"name": "old", "value": "old_value"}
    session["cookies"] = old_cookie

    # Remove a cookie from the session instance
    new_name = "new"
    session.remove_cookies([old_cookie["name"], new_name])

    assert new_name not in session["cookies"]
    assert len(session["cookies"]) == 0



# Generated at 2022-06-12 00:22:53.598341
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'test':{'value':'value'}}
    session.remove_cookies(['test'])
    assert 'test' not in session['cookies']


# Generated at 2022-06-12 00:23:02.889566
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('new')
    request_headers = {'User-Agent': 'Mozilla/5.0'}

    session.update_headers(request_headers)
    assert session['headers'] == {'User-Agent': 'Mozilla/5.0'}

    request_headers['User-Agent'] = None
    session.update_headers(request_headers)
    assert session['headers'] == {'User-Agent': 'Mozilla/5.0'}

    session = Session('new')
    request_headers = {'User-Agent': 'HTTPie/1.0.0'}
    session.update_headers(request_headers)
    assert session['headers'] == {}

    session = Session('new')
    request_headers = {'User-Agent': 'HTTPie/1.0.0'}
    session

# Generated at 2022-06-12 00:23:09.445039
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(os.path.sep))
    session['cookies'] = {
        'a': {'value': 1},
        'b': {'value': 2},
        'c': {'value': 3},
    }
    assert session['cookies'] == {
        'a': {'value': 1},
        'b': {'value': 2},
        'c': {'value': 3},
    }

    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {
        'b': {'value': 2},
    }



# Generated at 2022-06-12 00:23:15.227740
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Validate the method remove_cookies of class Session.
    """
    session = Session('')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-12 00:23:24.149729
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {
        'test1': {'value': 'test1', 'path': '/'},
        'test2': {'value': 'test2', 'path': '/'},
        'test3': {'value': 'test3', 'path': '/'},
    }
    session.remove_cookies(['test1', 'test3'])
    assert session == {
        'headers': {},
        'cookies': {'test2': {'value': 'test2', 'path': '/'}},
        'auth': {
            'type': None,
            'username': None,
            'password': None
        }
    }

# Generated at 2022-06-12 00:23:29.323398
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    S = Session(None)
    S['cookies'] = {'a': 1, 'b': 2}
    S.remove_cookies(['b'])
    assert len(S['cookies'].keys()) == 1
    assert 'b' not in S['cookies'].keys()
    assert 'a' in S['cookies'].keys()

# Generated at 2022-06-12 00:23:39.866628
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies_dict = {}
    cookies_dict["key1"] = "val1"
    cookies_dict["key2"] = "val2"
    cookies_dict["key3"] = "val3"
    cookies_dict["key4"] = "val4"
    
    session = Session("test")
    session["cookies"] = cookies_dict
    remove_cookies_names = ["key1", "key2"]
    session.remove_cookies(remove_cookies_names)
    test_cookies_dict = {}
    test_cookies_dict["key3"] = "val3"
    test_cookies_dict["key4"] = "val4"
    assert session["cookies"] == test_cookies_dict


# Generated at 2022-06-12 00:23:47.782624
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/session.json')
    session.update_headers({'user-agent': 'HTTPie/0.9.8', 'User-Agent': 'HTTPie/0.9.7', 'foo': 'bar', 'Content-Type': 'application/json'})

    headers = session.headers
    assert(headers['foo'] == 'bar')
    assert(not 'user-agent' in headers)
    assert(not 'Content-Type' in headers)

# Generated at 2022-06-12 00:24:03.667806
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies')
    session.cookies.set(name='test_cookie_name')
    session.cookies.set(name='test_cookie_name2')
    assert session.cookies['test_cookie_name'].name == 'test_cookie_name'
    assert session.cookies['test_cookie_name2'].name == 'test_cookie_name2'
    session.remove_cookies(['test_cookie_name'])
    # only test_cookie_name is cleared
    assert 'test_cookie_name' not in session.cookies
    assert session.cookies['test_cookie_name2'].name == 'test_cookie_name2'
    session.remove_cookies(['test_cookie_name2'])
    # all cookies are cleared

# Generated at 2022-06-12 00:24:13.974896
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from json import loads
    from os import remove
    from tempfile import NamedTemporaryFile
    from unittest import main, TestCase
    from unittest.mock import patch

    class UnitTest(TestCase):

        def setUp(self):
            self.tmp_file = NamedTemporaryFile()
            self.s = Session(path=self.tmp_file.name)

        def tearDown(self):
            self.tmp_file.close()

        def test_cookies_None(self):
            self.s.remove_cookies(['None'])

# Generated at 2022-06-12 00:24:19.225808
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/test/sessions')
    session['cookies'] = {'a': {'value': 'test'}, 'b': {'value': 'test1'}}
    session.remove_cookies(['a'])
    print(session['cookies'])
    #assert session['cookies'] == {'b': {'value': 'test1'}}

# Generated at 2022-06-12 00:24:28.145878
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session(path="foo/bar.json")
    sess.cookies.set('c1', 'v1', path='/p1')
    sess.cookies.set('c2', 'v2', path='/p2')
    sess.cookies.set('c3', 'v3', path='/p3')
    sess.cookies.set('c4', 'v4', path='/p4')
    sess.remove_cookies(['c1', 'c3'])
    assert sess['cookies'] == {'c2': {'value': 'v2'}, 'c4': {'value': 'v4'}}
    sess.remove_cookies(['c5']) # c5 not found

# Generated at 2022-06-12 00:24:35.633071
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Test class Session.

    """
    session = Session("")
    session['cookies']['foo'] = {}
    session['cookies']['bar'] = {}
    names = ('foo',)
    session.remove_cookies(names)
    assert set(session['cookies'].keys()) == set(['bar'])
    names = ('bar',)
    session.remove_cookies(names)
    assert set(session['cookies'].keys()) == set([])

# Generated at 2022-06-12 00:24:40.626149
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./test-httpie-session.json')
    session.load()
    session.remove_cookies(['session_id'])
    assert session['cookies'] == {'csrftoken': '123'}
    session.remove_cookies(['csrftoken'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:24:50.488587
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {
        'one': '',
        'two': '',
        'three': '',
    }
    session.remove_cookies(['one'])
    assert session['cookies'] == {
        'two': '',
        'three': ''
    }
    session.remove_cookies(['four', 'five'])
    assert session['cookies'] == {
        'two': '',
        'three': ''
    }
    session.remove_cookies(['three'])
    assert session['cookies'] == {
        'two': ''
    }
    session.remove_cookies(['two'])
    assert session['cookies'] == {}



# Generated at 2022-06-12 00:24:54.748473
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'c1': 1, 'c2': 2, 'c3': 3}
    session.remove_cookies(['c2', 'c3'])
    assert session['cookies'] == {'c1': 1}

# Generated at 2022-06-12 00:25:00.257007
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/path/to/session.json'))
    session['cookies'] = {'cookie-1': {'value': 'val-1'}, 'cookie-2': {'value': 'val-2'}}
    assert session.cookies['cookie-1'].value == 'val-1'
    session.remove_cookies(['cookie-1'])
    assert session.cookies['cookie-1'].value == 'val-1'
    assert session.cookies['cookie-2'].value == 'val-2'
    # Check that the cookies were actually removed from session
    assert session['cookies'] == {'cookie-2': {'value': 'val-2'}}
    session.remove_cookies(['cookie-2'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:25:08.010558
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import tempfile
    session_file = tempfile.NamedTemporaryFile()
    session_path = session_file.name
    session = Session(session_path)
    session["cookies"] = {"foo": "bar"}
    session.save()
    session = Session(session_path)
    session.load()
    #session_obj = json.loads(session_file.read().decode())
    assert {"foo": "bar"} == session["cookies"]
    session.remove_cookies(["foo"])
    assert {} == session["cookies"]

# Generated at 2022-06-12 00:25:21.151936
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['headers'] = dict()
    session['cookies'] = dict()

    cookie_a = {'value': 'test_value', 'version': 0, 'port': None, 'domain': '',
                'path': None, 'secure': False, 'expires': None, 'discard': True,
                'comment': None, 'comment_url': None, 'rest': {}, 'rfc2109': False}
    cookie_b = {'value': 'test_value', 'version': 0, 'port': None, 'domain': '',
                'path': None, 'secure': False, 'expires': None, 'discard': True,
                'comment': None, 'comment_url': None, 'rest': {}, 'rfc2109': False}

    session['cookies']['a']

# Generated at 2022-06-12 00:25:28.482162
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Removes cookie based on name and given list of names

    """
    # Arrange
    names = ['a', 'b', 'c']
    session = Session('local')
    session['cookies'] = {'a':'1', 'b':'2', 'c':'3'}
    # Act
    session.remove_cookies(names)
    # Assert
    assert 'cookies' in session
    assert 'a' not in session['cookies']
    assert 'b' not in session['cookies']
    assert 'c' not in session['cookies']



# Generated at 2022-06-12 00:25:33.998089
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    S = Session("test")
    S["cookies"]["c1"] = 1
    S["cookies"]["c2"] = 2
    S["cookies"]["c3"] = 3
    S.remove_cookies(["c1","c3"])
    assert len(S["cookies"]) == 1
    assert S["cookies"]["c2"] == 2

# Generated at 2022-06-12 00:25:37.605058
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = (DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME /
            'example.com/test.json')
    session = Session(path)

    # Init cookies
    cookies = session['cookies']
    cookies['test'] = {'value': 'test'}
    cookies['test2'] = {'value': 'test2'}

    session.remove_cookies(['test'])
    assert cookies['test'] == None
    assert cookies['test2'] == {'value': 'test2'}

# Generated at 2022-06-12 00:25:44.964020
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/sess')
    s['cookies'] = {
        'session': {'value': '1234'},
        'user_token': {'value': '1234'}
    }
    assert len(s['cookies']) == 2
    s.remove_cookies(['non_existent', 'user_token'])
    assert len(s['cookies']) == 1
    assert 'user_token' not in s['cookies']



# Generated at 2022-06-12 00:25:48.888240
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/foo')
    session['cookies'] = {'a': 'a', 'b': 'b', 'c': 'c'}
    session.remove_cookies(['c'])
    assert 'c' not in session['cookies']



# Generated at 2022-06-12 00:25:56.664198
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    js = {'headers': {}, 'cookies': {'a': {'value': '1'}, 'b': {'value': '2'}}, 'auth': {'type': None, 'username': None, 'password': None}}
    s = Session('test')
    s.update(js)
    assert dict(s.cookies)['a'].value == '1'
    assert dict(s.cookies)['b'].value == '2'
    s.remove_cookies(['a'])
    assert dict(s.cookies)['a'].value != '1'
    assert dict(s.cookies)['b'].value == '2'

# Generated at 2022-06-12 00:26:00.649613
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(Path(''))
    s['cookies'] = {
        'cook_1': {'value': 'val_1'},
        'cook_2': {'value': 'val_2'}
    }
    s.remove_cookies(['cook_1'])
    assert s['cookies'] == {'cook_2': {'value': 'val_2'}}

# Generated at 2022-06-12 00:26:08.319321
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # prepare for Session initialization
    path = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'sample_file'
    session = Session(path)
    # prepare for method remove_cookies
    name = 'username'
    # test method remove_cookies
    session['cookies'][name] = {'value': 'admin'}
    assert name in session['cookies']
    session.remove_cookies([name])
    assert name not in session['cookies']

# Generated at 2022-06-12 00:26:12.507768
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie('name', 'value'))
    assert len(session.cookies) == 1
    session.remove_cookies(['name'])
    assert len(session.cookies) == 0
    assert len(session['cookies']) == 0



# Generated at 2022-06-12 00:26:26.255173
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    current_path = "./test_sessions/"
    session_name = "test"
    host = None
    url ="test"
    session = get_httpie_session(current_path, session_name, host, url)
    session.remove_cookies()

# Generated at 2022-06-12 00:26:32.155387
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('.')
    s['cookies']={'Name1':'Value1', 'Name2':'Value2'}
    s.remove_cookies(['Name2'])
    expected = {'cookies': {'Name1': 'Value1'}}
    assert s == expected



# Generated at 2022-06-12 00:26:36.306659
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./'))
    session['cookies'] = {
        'cookie1': {'value': 'value1'},
        'cookie2': {'value': 'value1'},
    }
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {
        'cookie1': {'value': 'value1'}
    }



# Generated at 2022-06-12 00:26:47.503363
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session({})

    class DummyCookieJar():
        def __init__(self):
            self.cookies = [{'name': 'sesh', 'value': 'sesh-my-man'},
                            {'name': 'sesh2', 'value': 'sesh2-my-man'},
                            {'name': 'sesh3', 'value': 'sesh3-my-man'},
                            {'name': 'sesh4', 'value': 'sesh4-my-man'}
                            ]

    dummy_jar = DummyCookieJar()
    session.cookies = dummy_jar
    session.remove_cookies(['sesh', 'whatever', 'sesh3'])
    assert ('sesh' not in session.cookies)

# Generated at 2022-06-12 00:26:48.540793
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    Session.remove_cookies('anonymous')

# Generated at 2022-06-12 00:26:57.949898
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import pytest
    from httpie.config import Config
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie import ExitStatus
    from utils import TestEnvironment, http

    session_cookie_name = 'SESSION_TEST_COOKIE'
    session_name = 'test_session'
    session_content = {
        'type': 'httpie.plugins.builtin.HTTPBasicAuth',
        'raw_auth': 'username:password'
    }
    exit_status = ExitStatus.OK

    env = TestEnvironment(config_dir=False)
    config = Config()
    config.path = env.config_path / 'config.json'
    env.config = config
    env.stdout_encoding = 'utf8'

    jar = RequestsCookieJar()
    jar.set_cookie

# Generated at 2022-06-12 00:27:07.729592
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/nopath')
    names = ['cookie1', 'cookie2']
    session['cookies']['cookie1'] = {'value': '1'}
    session['cookies']['cookie2'] = {'value': '2'}
    session['cookies']['cookie3'] = {'value': '3'}
    session.remove_cookies(names)
    assert not session['cookies']['cookie1']
    assert not session['cookies']['cookie2']
    assert session['cookies']['cookie3']
    assert session['cookies']['cookie3']['value'] == '3'

# Generated at 2022-06-12 00:27:15.875293
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Remove all empty cookies
    session = Session('session.json')
    session.loaded = True
    session['cookies'] = {}

    session.remove_cookies([])
    assert session['cookies'] == {}

    # Remove all cookies
    session = Session('session.json')
    session.loaded = True
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}

    session.remove_cookies(['name1', 'name2'])
    assert session['cookies'] == {}

    # Remove cookie
    session = Session('session.json')
    session.loaded = True
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}

    session.remove_cookies(['name2'])
    assert session['cookies']

# Generated at 2022-06-12 00:27:20.858899
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_session = Session('test.json')
    test_session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    test_session.remove_cookies(['a', 'c'])
    assert test_session['cookies'] == {'b': 2}

# Generated at 2022-06-12 00:27:25.296246
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("session_1.json")
    a = [
        "cook",
        "book",
        "car",
        "mason"
    ]
    assert a == ["cook", "book", "car", "mason"]
    session.remove_cookies(a)
    assert a == ["cook", "book", "car", "mason"]

# Generated at 2022-06-12 00:27:39.355367
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=None)
    session['cookies'] = {'cookie1':'val1','cookie2':'val2','cookie3':'val3'}
    assert set(session['cookies'].keys()) == {'cookie1','cookie2','cookie3'}
    session.remove_cookies(['cookie1','cookie3'])
    assert set(session['cookies'].keys()) == {'cookie2'}



# Generated at 2022-06-12 00:27:44.707029
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_file')
    session['cookies'] = {'foo': {'value': 'bar'}}
    session.remove_cookies(['foo'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:27:51.833580
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    this test checks if cookies are remove from the session
    """
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.plugins.builtin import HTTPBasicAuth

    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'test_session'
    url = 'http://127.0.0.1'
    session = get_httpie_session(config_dir, session_name, None, url)

    session.cookies = session.cookies
    auth = HTTPBasicAuth()
    auth.get_auth(username='user', password='pass')
    session.auth = auth.auth()
    session.update_headers({'header1': 'test1', 'header2': 'test2'})

    session.remove_cookies(['header1', 'header2'])
    session

# Generated at 2022-06-12 00:27:57.722231
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session.cookies = RequestsCookieJar()
    session.cookies.set('cookie1', 'value1')
    session.cookies.set('cookie2', 'value2')
    session.cookies.set('cookie3', 'value3')
    session.remove_cookies(['cookie1','cookie2'])
    assert session['cookies'] == {'cookie3':{'value':'value3'}}

# Generated at 2022-06-12 00:28:05.677346
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {"test1":{},"test2":{},"test3":{},"test4":{}}
    session.remove_cookies(["test1","test3","test5"])
    assert "test1" not in session['cookies']
    assert "test2" in session['cookies']
    assert "test3" not in session['cookies']
    assert "test4" in session['cookies']
    assert "test5" not in session['cookies']
    session['cookies'] = {"test1":{},"test2":{},"test3":{},"test4":{}}
    session.remove_cookies(["test1","test3","test4","test5"])
    assert "test1" not in session['cookies']
    assert "test2" in session

# Generated at 2022-06-12 00:28:14.797731
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    # Base class to test on
    class Session_Extended(Session):
        def __init__(self, path: Union[str, Path]):
            super().__init__(path=Path(path))
            self['headers'] = {}
            self['cookies'] = {}
            self['auth'] = {
                'type': None,
                'username': None,
                'password': None
            }

    # Remove cookies
    session = Session_Extended("")
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie(
        'var_to_remove1', 'value'))
    session.cookies.set_cookie(create_cookie(
        'var_to_remove2', 'value'))

# Generated at 2022-06-12 00:28:17.989047
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'cookie1': {'value': 'value1'}}
    session.remove_cookies(['cookie1'])
    assert not len(session['cookies'])

# Generated at 2022-06-12 00:28:24.160164
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('')
    sess.cookies = RequestsCookieJar()
    sess.cookies.set_cookie(create_cookie('name1', 'value1'))
    sess.cookies.set_cookie(create_cookie('name2', 'value2'))
    sess.remove_cookies(['name1'])
    assert sess.cookies == RequestsCookieJar(
        [create_cookie('name2', 'value2')])

# Generated at 2022-06-12 00:28:29.805624
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'test.json'
    session = Session(session_path)
    session.load()

    session["cookies"] = {'test1': {'value': 'test'}, 'test2': {'value': 'test'}, 'test3': {'value': 'test'}}
    session.remove_cookies(['test2'])

    assert session["cookies"] == {'test1': {'value': 'test'}, 'test3': {'value': 'test'}}

# Generated at 2022-06-12 00:28:35.014579
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session(tempfile.mkstemp()[1])
    sess['cookies'] = {'foo':'value0', 'bar':'value1', 'baz':'value2'}
    sess.remove_cookies(('foo', 'bar'))
    assert ('foo' in sess['cookies']) == False
    assert ('bar' in sess['cookies']) == False
    assert ('baz' in sess['cookies']) == True


# Generated at 2022-06-12 00:29:08.015346
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("some_path")
    session.setdefault("cookies", {})
    session["cookies"]["foo"] = "bar"
    session["cookies"]["bar"] = "baz"
    session.remove_cookies(names=["bar"])
    assert len(session["cookies"]) == 1
    assert "foo" in session["cookies"]
    assert "bar" not in session["cookies"]

# Generated at 2022-06-12 00:29:16.308402
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/test')
    session['cookies'] = {
        'a': {'value': '1', 'path': '/'},
        'b': {'value': '2', 'path': '/'},
    }
    assert session['cookies'] == {
        'a': {'value': '1', 'path': '/'},
        'b': {'value': '2', 'path': '/'},
    }
    session.remove_cookies(['a'])
    assert session['cookies'] == {
        'b': {'value': '2', 'path': '/'},
    }
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {}



# Generated at 2022-06-12 00:29:26.394655
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.constants import DEFAULT_CONFIG_DIR
    from httpie.sessions import get_httpie_session
    import json

    url = "http://www.example.com"
    session_name = "test_session1"
    session = get_httpie_session(DEFAULT_CONFIG_DIR, session_name, None, url)

    session['cookies']['name1'] = {'value': 'value1'}
    session['cookies']['name2'] = {'value': 'value2'}
    session['cookies']['name3'] = {'value': 'value3'}
    session['cookies']['name4'] = {'value': 'value4'}

    session.remove_cookies(['name3', 'name4'])
    expected_value

# Generated at 2022-06-12 00:29:32.400483
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('~/.config/httpie/testing.json')
    session['cookies'] = {'1': '11', '2': '22', '3': '33'}

    session.remove_cookies(['1'])
    assert session['cookies'] == {'2': '22', '3': '33'}

    session.remove_cookies(['2'])
    assert session['cookies'] == {'3': '33'}

    session.remove_cookies(['3'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:29:36.188574
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Setup environnement
    session = Session("unit_test")
    session['cookies'] = {"a": "a", "b": "b", "c": "c"}
    session.remove_cookies(("a", "b", "d"))
    assert session['cookies'] == {"c": "c"}