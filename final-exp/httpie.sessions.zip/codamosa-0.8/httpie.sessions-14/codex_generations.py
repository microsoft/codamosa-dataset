

# Generated at 2022-06-12 00:19:48.940587
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path = None)
    session.cookies = RequestsCookieJar()
    session.cookies.set('some_cookie_name', 'some_cookie_value')
    assert session.cookies.get('some_cookie_name')
    session.remove_cookies(['some_cookie_name'])
    assert not session.cookies.get('some_cookie_name')

# Generated at 2022-06-12 00:19:57.259573
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('path/to/session.json')
    # empty
    session.update_headers({})
    assert session['headers'] == {}
    assert session['cookies'] == {}
    # name='Content-Type'
    session.update_headers({'Content-Type': 'text/html'})
    assert session['headers'] == {}
    assert session['cookies'] == {}
    # name='Cookie'
    session.update_headers({'Cookie': 'a=1; b=2'})
    assert session['headers'] == {}
    assert session['cookies'] == {'a': {'value': '1'}, 'b': {'value': '2'}}
    # name='User-Agent'
    session.update_headers({'User-Agent': 'HTTPie/1.0.0'})

# Generated at 2022-06-12 00:20:02.050657
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    session['headers'] = {}
    request_headers = RequestHeadersDict({})
    session.update_headers(request_headers)
    assert len(session['headers']) == 0

# Generated at 2022-06-12 00:20:11.391928
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path(""))

# Generated at 2022-06-12 00:20:18.755583
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies( ['name1'] )
    assert session['cookies'] == {'name2': 'value2'}
    session.remove_cookies( ['name1','name2'] )
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:20:24.212516
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {'name' : 'shashank'}
    s = Session('./')
    s.update_headers(headers)
    assert s.headers == {'name' :'shashank'}
    headers['name'] = 'gopakumar'
    s.update_headers(headers)
    assert s.headers == {'name' :'gopakumar'}


# Generated at 2022-06-12 00:20:32.610928
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict({
        'User-Agent': 'HTTPie/0.9.3',
        'Date': 'Thu, 05 Apr 2018 21:15:32 GMT',
        'Host': 'httpbin.org',
        'Cache-Control': 'max-age=259200',
        'Content-Type': 'application/json'
    })

    session = Session(None)
    session.update_headers(request_headers)

    assert session.headers == {
        'User-Agent': 'HTTPie/0.9.3',
        'Date': 'Thu, 05 Apr 2018 21:15:32 GMT',
        'Host': 'httpbin.org',
        'Cache-Control': 'max-age=259200',
        'Content-Type': 'application/json'
    }

# Generated at 2022-06-12 00:20:35.786115
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    assert session.update_headers(RequestHeadersDict({'Content-Type':'application/json'})) == {'Content-Type':'application/json'}

# Generated at 2022-06-12 00:20:42.416409
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('sessions/test.json')
    session.update_headers({'some-header': 'some-value', 'cookies': 'cookie2=biscuit; cookie1=cookie'})
    assert session['headers'] == {'some-header': 'some-value'}
    assert session['cookies'] == {
        'cookie2': {
            'value': 'biscuit'
        },
        'cookie1': {
            'value': 'cookie'
        }
    }

# Generated at 2022-06-12 00:20:47.469448
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Config.DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME)
    session['cookies'] = {'a': {'value': 1}}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {}


# Generated at 2022-06-12 00:20:58.863939
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path="path")
    session["cookies"] = {"one": "1", "two": "2", "three": "3"}
    session.remove_cookies(["one", "three"])
    assert session["cookies"] == {"two": "2"}


# Generated at 2022-06-12 00:21:01.836080
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('none')
    session['cookies'] = {'abc': {'value': 123}, 'cde': {'value': 456}}
    session.remove_cookies(['abc'])
    assert session['cookies'] == {'cde': {'value': 456}}

# Generated at 2022-06-12 00:21:10.696941
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir = Path(DEFAULT_CONFIG_DIR)
    # session_name = "DEFAULT_COOKIE"
    session_name = "DEFAULT_COOKIE"
    host = None
    url = ""
    session = Session.get_httpie_session(config_dir, session_name, host, url)
    session.load()
    config_file = open("config.json", "r")
    config = config_file.read()
    cookies = json.loads(config)
    expected = []
    session.remove_cookies(cookies.keys())
    actual = list(session['cookies'].keys())
    assert_equals(actual, expected)
#        print("\n")
#        print(session['cookies'])
#        print("\n")
#        print(cookies.

# Generated at 2022-06-12 00:21:14.192651
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('sess')
    s['cookies'] = {'a':1,'b':2}
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b':2}

# Generated at 2022-06-12 00:21:22.758695
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies')
    values = {
        'abc': 'valueabc',
        'def': 'valuedef',
        'ghi': 'valueghi',
    }
    for k, v in values.items():
        session['cookies'][k] = v

    session.remove_cookies(['abc'])
    assert len(session['cookies']) == 2
    assert 'abc' not in session['cookies']
    assert session['cookies']['def'] == 'valuedef'
    assert session['cookies']['ghi'] == 'valueghi'

    session = Session('/tmp/test_Session_remove_cookies')

# Generated at 2022-06-12 00:21:28.344533
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('foo')
    session['cookies'] = {
        'a': {},
        'b': {},
        'c': {},
    }
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': {}}



# Generated at 2022-06-12 00:21:33.356432
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path('./test/test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2'])

    assert(session['cookies'] == {'cookie1': {'value': 'value1'}})

# Generated at 2022-06-12 00:21:36.238149
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import tempfile
    session_path = tempfile.NamedTemporaryFile().name

    session = Session(path=session_path)
    session['cookies'] = {"a": {"value": "123"}, "b": {"value": "234"}}
    session.remove_cookies(["a", "d"])

    assert session['cookies'] == {"b": {"value": "234"}}

# Generated at 2022-06-12 00:21:40.178459
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session.json')
    cookies = {'a': 'b', 'c': 'd'}
    session['cookies'] = cookies
    to_remove = {'a', 'd'}
    session.remove_cookies(to_remove)
    assert not  ('a' in session['cookies'])
    assert ('c' in session['cookies'])
    assert 'd' not in session['cookies']


# Generated at 2022-06-12 00:21:47.186732
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path="test_session")
    session["cookies"] = {
        'test_cookie': {'value': 'value1'},
        'test_cookie2': {'value': 'value2'}
    }
    cookie_names = ['test_cookie', 'test_cookie_no_exist']
    session.remove_cookies(cookie_names)
    assert session["cookies"] == \
        {'test_cookie2': {'value': 'value2'}}

# Generated at 2022-06-12 00:22:02.305705
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/home/ubuntu/.config/httpie/sessions/localhost/default.json'))
    session_cookies = {'name':'value', 'name2': 'value2'}
    session['cookies'] = session_cookies
    removed_cookies = ['name']
    session.remove_cookies(removed_cookies)
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-12 00:22:08.361896
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
  session = Session("path")
  session['cookies'] = {'foo': 'bar'}
  session.remove_cookies(['foo'])
  assert len(session['cookies']) == 0
  session['cookies'] = {'foo': 'bar'}
  session.remove_cookies(['bar'])
  assert len(session['cookies']) == 1

# Generated at 2022-06-12 00:22:12.320958
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'cookie1':'cookie1 value', 'cookie2':'cookie2 value', 'cookie3':'cookie3 value'}
    session.remove_cookies(['cookie1', 'cookie3'])
    assert session['cookies'] == {'cookie2':'cookie2 value'}

# Generated at 2022-06-12 00:22:21.122251
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {
            'cookie1': {'value': 'value1'},
            'cookie2': {'value': 'value2'},
            'cookie3': {'value': 'value3'}
        }
    test_session = Session('/test/session/path')
    test_session['cookies'] = cookies

    test_session.remove_cookies(['cookie1'])
    assert test_session['cookies'] == {
            'cookie2': {'value': 'value2'},
            'cookie3': {'value': 'value3'}
        }
    test_session.remove_cookies(['cookie3'])
    assert test_session['cookies'] == {
            'cookie2': {'value': 'value2'}
        }

# Generated at 2022-06-12 00:22:29.420904
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('session_test')
    jar = RequestsCookieJar()
    jar.set('aaa', '111')
    jar.set('bbb', '222')
    jar.set('ccc', '333')
    sess.cookies = jar
    sess.remove_cookies(['aaa'])
    assert len(sess.cookies) == 2
    assert sess['cookies']['bbb'] == {'value': '222'}
    assert sess['cookies']['ccc'] == {'value': '333'}



# Generated at 2022-06-12 00:22:35.695981
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = "test.json"
    session = Session(path)
    session.update_headers({"Cookie": "cookie1=value1; cookie2=value2"})
    session.remove_cookies(["cookie1"])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:22:41.440854
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(SESSIONS_DIR_NAME)

    cookieName = 'cookie'
    cookies = session['cookies']
    cookies[cookieName] = {}
    session['cookies'] = cookies

    assert cookieName in session['cookies']
    session.remove_cookies([cookieName])
    assert cookieName not in session['cookies']


test_Session_remove_cookies()



# Generated at 2022-06-12 00:22:43.618482
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    Session.remove_cookies(self, ['name1', 'name2', 'name3'])

# Generated at 2022-06-12 00:22:52.925356
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("")
    session['cookies'] = {}
    session['cookies']['cookie1'] = {'value': 'foo1', 'expires': '1970-01-01T00:00:01', 'path': '/'}
    session['cookies']['cookie2'] = {'value': 'foo2', 'expires': '1970-01-01T00:00:01', 'path': '/'}
    session.remove_cookies(['cookie1', 'cookie3'])
    assert session['cookies'] == {'cookie2': {'value': 'foo2', 'expires': '1970-01-01T00:00:01', 'path': '/'}}

# Generated at 2022-06-12 00:22:56.486032
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session=Session("/path/to/file")
    session['cookies'] = {
        'session_id': {'value': '1234', 'secure': 'True'},
        'theme': {'value': 'dark', 'secure': 'True'}
    }
    names = ['session_id', 'theme']
    session.remove_cookies(names)
    assert not session['cookies']

# Generated at 2022-06-12 00:23:17.759924
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session("test")
    sess['cookies'] = {'abc' : 1, 'def' : 2, 'ghi' : 3}
    sess.remove_cookies(['abc', 'ghi'])
    assert sess['cookies'] == {'def' : 2}

# Generated at 2022-06-12 00:23:23.209370
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {'cookie1': {'value': 'somewhere'}, 'cookie2': {'value': 'somewhere2'}}
    names = ['cookie1']
    session.remove_cookies(names)
    assert session['cookies'] == {'cookie2': {'value': 'somewhere2'}}

# Generated at 2022-06-12 00:23:27.276508
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("test")
    s['cookies'] = {"test" : "test"}
    s.remove_cookies("test")
    assert("test" not in s['cookies'])


# Generated at 2022-06-12 00:23:33.034304
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path="")
    assert len(s["cookies"]) == 0
    s["cookies"]["cookie1"] = {}
    s["cookies"]["cookie2"] = {}
    assert len(s["cookies"]) == 2
    s.remove_cookies(["cookie1"])
    assert len(s["cookies"]) == 1
    assert "cookie1" not in s["cookies"]
    assert "cookie2" in s["cookies"]
    s["cookies"]["cookie1"] = {}
    assert len(s["cookies"]) == 2
    s.remove_cookies(["cookie1", "cookie2"])
    assert len(s["cookies"]) == 0

# Generated at 2022-06-12 00:23:39.963935
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_session = Session("test_session.json")
    test_session['cookies'] = {'key1': 'value1', 'key2': 'value2'}
    assert test_session['cookies']['key1'] == 'value1'
    test_session.remove_cookies(['key1'])
    assert not ('key1' in test_session['cookies'])
    assert test_session['cookies']['key2'] == 'value2'


# Generated at 2022-06-12 00:23:44.484219
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session.json')
    session['cookies'] = {'name': {'value': 'value'}}
    session.remove_cookies(['name'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:23:48.322123
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('.test')
    session.update_headers({'cookie': 'a=1; b=2; c=3'})
    session.remove_cookies(['b', 'c'])
    assert session['cookies'] == {'a': {'value': '1'}}

# Generated at 2022-06-12 00:23:53.719533
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session_test_file')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2', 'cookie3'])
    assert session['cookies'] == {}



# Generated at 2022-06-12 00:23:59.482729
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session_remove_cookies.json')
    session['cookies'] = {'c1': {'value': '10'}, 'c2': {'value': '20'}}
    session.remove_cookies(['c1', 'c2'])
    assert not session['cookies']


# Generated at 2022-06-12 00:24:08.312511
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import re
    import httpie
    httpie.SESSIONS_DIR_NAME='sessions'
    assertions = {
        'HTTPie/0.9.2': False,
        'HTTPie/1.0.0': True,
        'HTTPie/1.0.1': True,
        'HTTPie/1.0.2': True,
        'HTTPie/1.0.3': True,
        'HTTPie/1.0.4': True,
        'HTTPie/1.0.5': True,
        'HTTPie/1.0.6': True,
        'HTTPie/1.0.7': True,
        'HTTPie/1.0.8': True,
        'HTTPie/1.0.9': True
    }
    for version, assertion in assertions.items():
        http

# Generated at 2022-06-12 00:24:32.522139
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'a': {'value': 'b'}, 'c': {'value': 'd'}}
    session = Session('')

    session.cookies = RequestsCookieJar()
    session.cookies.set(name='a', value='b')
    session.cookies.set(name='c', value='d')

    assert session.cookies == cookies

    session.remove_cookies(['a', 'b'])
    assert session.cookies == {'c': {'value': 'd'}}

# Generated at 2022-06-12 00:24:34.430205
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session.update({'cookies': {'c1': {}, 'c2': {}}})
    session.remove_cookies(['c1'])
    assert 'cookies' in session and 'c1' not in session['cookies'] and 'c2' in session['cookies']

# Generated at 2022-06-12 00:24:39.405625
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session.update_headers(RequestHeadersDict({'Cookie': 'x=1'}))
    assert session['cookies']['x']
    session.remove_cookies(['x', ])
    assert 'x' not in session['cookies']

# Generated at 2022-06-12 00:24:44.113364
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test_session.json')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1', 'name2'])
    assert session['cookies'] == {}

# Generated at 2022-06-12 00:24:52.230736
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(Path(""))
    s['cookies'] = {'A': {'value': 'A'}, 'B': {'value': 'B'}}
    s.remove_cookies(['B', 'C'])
    assert s == Session(Path(""))
    s['cookies'] = {'A': {'value': 'A'}, 'B': {'value': 'B'}}
    s.remove_cookies(['B'])
    assert s == Session(Path(""))
    s['cookies'] = {'A': {'value': 'A'}, 'B': {'value': 'B'}}
    s.remove_cookies(['A', 'B'])
    assert s == Session(Path(""))
    s['cookies'] = {'A': {'value': 'A'}}
    s

# Generated at 2022-06-12 00:24:58.721986
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # We create a session, set some cookies in it and call remove_cookies method with some names
    myses = Session(path = 'path')
    myses['cookies'] = {'c4': {'value':'v4', 'path':'/path4'}, 'c5': {'value':'v5', 'path':'/path5'}}
    myses.remove_cookies(names=['c5'])
    # We expect that the cookie with name 'c5' is removed, but the cookie with name 'c4' is not
    assert list(myses['cookies'].keys()) == ['c4']

# Generated at 2022-06-12 00:25:04.145772
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("test")
    s['cookies'] = {'test1': {'value': 'test1'}, 'test2': {'value': 'test2'}}
    s.remove_cookies(['test1'])
    assert s['cookies'] == {'test2': {'value': 'test2'}}



# Generated at 2022-06-12 00:25:07.218689
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session()
    session['cookies'] = {'cookie1': [], 'cookie2': []}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': []}

# Generated at 2022-06-12 00:25:10.920818
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/home/fakepath/test.json')
    session['cookies'] = {'test1': {}, 'test2': {}}
    session.remove_cookies(['test1'])
    assert session['cookies'] == {'test2': {}}

# Generated at 2022-06-12 00:25:20.095216
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_1 = Session('session.json')
    session_1['cookies'] = {
        'COOKIE_NAME_1': {'value': 'COOKIE_VALUE_1', 'discard': True},
        'COOKIE_NAME_2': {'value': 'COOKIE_VALUE_2', 'secure': True},
        'COOKIE_NAME_3': {'value': 'COOKIE_VALUE_3', 'max-age': 0},
        'COOKIE_NAME_4': {'value': 'COOKIE_VALUE_4', 'secure': True}
    }
    session_1.remove_cookies(['COOKIE_NAME_1', 'COOKIE_NAME_2'])

# Generated at 2022-06-12 00:25:47.558410
# Unit test for constructor of class Session
def test_Session():
    sess = Session(path = "test")
    assert sess['headers'] == {}
    assert sess['cookies'] == {}
    assert sess['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-12 00:25:50.610111
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session=get_httpie_session("/home/claire/.config", "https://httpie.org/doc#sessions","/doc#sessions","/doc#sessions")
    session.remove_cookies("claire")
    assert True

# Generated at 2022-06-12 00:25:53.779718
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert (DEFAULT_SESSIONS_DIR / 'httpbin.org' / 'my_session.json') == get_httpie_session(DEFAULT_CONFIG_DIR, 'my_session', 'httpbin.org', 'http://httpbin.org/').path

# Generated at 2022-06-12 00:26:01.771282
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.plugins.manager import plugin_manager
    from httpie.config import EnvironmentDefaults, Config
    from json import loads
    from httpie.compat import is_windows
    config_dir = EnvironmentDefaults.CONFIG_DIR
    if is_windows:
        config_dir = config_dir.replace('\\', '/')
    config_dir = config_dir / 'sessions'
    session_name = 'localhost'
    host = 'localhost'
    url = 'http://localhost/'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert type(session) == dict
    assert type(session['headers']) == dict
    assert type(session['cookies']) == dict
    assert type(session['auth']) == dict

# Generated at 2022-06-12 00:26:07.331261
# Unit test for constructor of class Session
def test_Session():
    a=Session("/home/a")
    assert a["headers"]=={}
    assert a["cookies"]=={}
    assert a["auth"]=={
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-12 00:26:15.177811
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('path')
    update_headers_input_headers = {
        'User-Agent': 'HTTPie/0.9.9',
        'Cookie': 'SID=2xo2ksa',
        'X-FORWARDED-FOR': '127.0.0.1',
        'IF-NONE-MATCH': 'Foo',
        'Proxy-Authenticate': 'Foo'
    }
    s.update_headers(update_headers_input_headers)
    session_cookies = s.cookies
    headers = s.headers
    assert headers == {'x-forwarded-for': '127.0.0.1'}
    assert session_cookies == RequestsCookieJar()

# Generated at 2022-06-12 00:26:25.491787
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import ExitStatus
    from httpie.cli import parse_items
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPDate
    from httpie.plugins import plugin_manager
    from httpie.input import KeyValueArg
    from httpie.output.streams import StreamOutput
    from httpie.output.streams import StreamFormatter
    from httpie.core import main

    env = Environment(stdin=None, stdout=None, stderr=None, vars=None)
    plugin_manager.load_builtin_plugins()
    headers = parse_items(
            KeyValueArg(''), env
    )

    # Test the situation that we are trying to add a header with a prefix we
    # wish to ignore

# Generated at 2022-06-12 00:26:34.564616
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    print("Unit test for method remove_cookies of class Session")
    session = Session("")
    session['cookies'] = {'name1':'value1','name2':'value2','name3':'value3'}
    session.remove_cookies(['name2', 'name4'])
    print("Expected output: {'name1': 'value1', 'name3': 'value3'}")
    print("Actual Output: ", session['cookies'])
    if session['cookies'] == {'name1':'value1','name3':'value3'}:
        print("Unit test passed")
    else:
        print("Unit test failed")


# Generated at 2022-06-12 00:26:38.834678
# Unit test for constructor of class Session
def test_Session():
    h = Session("test")
    h['headers'] = {}
    h['cookies'] = {}
    h['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-12 00:26:49.736399
# Unit test for method update_headers of class Session
def test_Session_update_headers():  # pylint: disable=unused-variable
    """
    This unit test is not intended to be executed,
    it is just an experiment to let PyCharm
    inspect we want it to inspect.
    """

    # in
    cookies = 'foo; bar'

    # out
    request_headers = CIMultiDictProxy(CIMultiDict([('User-Agent', 'HTTPie/2.0.0'), ('Accept', '*/*'), ('Accept-Encoding', 'gzip, deflate; q=0.9, identity; q=0.8'), ('Host', '127.0.0.1:5000'), ('Connection', 'Keep-Alive')]))
    request_cookies = RequestsCookieJar()
    for cookie in SimpleCookie(cookies).values():
        request_cookies.set_cookie

# Generated at 2022-06-12 00:27:47.008538
# Unit test for constructor of class Session
def test_Session():
    assert (Session(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME).get('headers'))
    assert (Session(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME).get('cookies'))
    assert (Session(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME).get('auth'))


# Generated at 2022-06-12 00:27:55.345591
# Unit test for function get_httpie_session
def test_get_httpie_session():
    s = get_httpie_session(
        config_dir=DEFAULT_SESSIONS_DIR,
        session_name='test',
        host=None,
        url='https://httpie.org/redirect/4',
    )
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    assert isinstance(s.path, Path)
    assert s.path.name == 'test.json'
    assert s.path.parent.name == 'httpie_org'
    assert s.path.parent.parent.name == SESSIONS_DIR_NAME

# Generated at 2022-06-12 00:27:59.911791
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = {'cookies': {'name1': 'value1', 'name2': 'value2', \
                           'name3': 'value3', 'name4': 'value4'}}
    s = Session(path='')
    s.update(session)
    s.remove_cookies(('name3',))
    assert 'name3' not in s['cookies']

# Generated at 2022-06-12 00:28:01.594300
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, 'foo', 'example.com', 'http://example.com')

# Generated at 2022-06-12 00:28:09.936016
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("/test")
    request_headers = RequestHeadersDict({
        'user-agent': 'HTTPie/0.9.7',
        'accept-encoding': 'gzip,deflate',
        'content-type': 'application/json; charset=utf8',
        'Host': '127.0.0.1:8000',
        'Cookie': 'csrftoken=OvB8WK39JDDGMBiw9bJFzYtZhEtGzNcZpjtDmJt8W8x2GmjK9Xh2nGZLuBzKjmbq; sessionid=13xp50h1gmscifx43xho5n5j8g1zv7vf'})
    session.update_headers(request_headers)

# Generated at 2022-06-12 00:28:20.101779
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('~/test')
    session.update_headers({'key': 'new', 'Accept': 'new'})
    assert 'key' in session['headers']
    assert 'Accept' in session['headers']
    session.update_headers({'Accept': 'new'})
    assert 'Accept' in session['headers']
    session.update_headers({'Accept': 'new', 'If-modified-Since': 'new'})
    assert 'Accept' in session['headers']
    assert 'If-modified-Since' not in session['headers']
    session.update_headers({'Accept': 'new', 'If-modified-Since': 'new', 'If-none-Match': 'new'})
    assert 'Accept' in session['headers']
    assert 'If-modified-Since' not in session['headers']

# Generated at 2022-06-12 00:28:24.095022
# Unit test for constructor of class Session
def test_Session():
    path = '/tmp/testpath'
    session = Session(path)
    assert session.file_name == path
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth']['type'] == None
    assert session['auth']['username'] == None
    assert session['auth']['password'] == None


# Generated at 2022-06-12 00:28:31.273721
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    from httpie.core import main
    from tests.test_client import client

    # 1. Test for normal case
    #    Test for a session file that does not exist
    #    Create a session and test for content
    #    Test for overwriting an existing session
    #    Write and recall the session
    # 2. Test for special cases:
    #    Test for special characters in session name
    #    Test for session file that is a directory
    #    Test for session file that is a file
    #    Test for session file with a relative path
    #    Test for session file with absolute path
    #    Test for session file with a wildcard in the name
    home = str(Path.home())
    httpie_session_path = Path.home() / ".config/httpie/sessions"
    # Clean

# Generated at 2022-06-12 00:28:34.870441
# Unit test for constructor of class Session
def test_Session():
    path = '../tests/sessions/test_file.json'
    sess = Session(path)
    assert sess.path.name == 'test_file.json'
    assert sess['headers'] == {}
    assert sess['cookies'] == {}
    assert sess['auth'] == {'type': None, 'username': None, 'password': None}

# Test for method update_headers of class Session

# Generated at 2022-06-12 00:28:35.546478
# Unit test for constructor of class Session
def test_Session():
    assert Session("abc.json")