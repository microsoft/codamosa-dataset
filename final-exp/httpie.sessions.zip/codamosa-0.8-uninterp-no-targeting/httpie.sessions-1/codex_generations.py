

# Generated at 2022-06-21 14:45:11.733928
# Unit test for function get_httpie_session
def test_get_httpie_session():
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    config_dir = os.path.join(BASE_DIR, '..', 'config')
    session_name = 'my-session'
    host = '127.0.0.1'
    url = 'http://127.0.0.1/test_get_httpie_session'
    session = get_httpie_session(Path(config_dir), session_name, host, url)
    assert os.path.exists(session)
    assert session.path.name == 'my-session.json'
    assert session.path.parent.name == '127_0_0_1'
    assert session.path.parent.parent.name == SESSIONS_DIR_NAME

# Generated at 2022-06-21 14:45:15.469271
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import unittest
    class TestSession(unittest.TestCase):
        def setUp(self):
            self.session = Session('test')
        def tearDown(self):
            self.session = None
    def test_default(self):
        session = self.session
        session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
        self.assertEqual(session.headers, {})
    def test_with_cookie(self):
        session = self.session
        session.update_headers({
            'Cookie': ('SID="31d4d96e407aad42"; lang=en-US; '
                       'expires=Wed, 09 Jun 2021 10:18:14 GMT')
        })

# Generated at 2022-06-21 14:45:23.188229
# Unit test for function get_httpie_session
def test_get_httpie_session():
    test_config_dir = Path('~/.httpie/')
    test_url = 'http://localhost:80/api/v1/'
    test_session = get_httpie_session(test_config_dir, 'test', None, test_url)
    assert test_session['path'] == Path(os.path.expanduser('~/.httpie/sessions/localhost/test.json'))

    test_session2 = get_httpie_session(test_config_dir, '/tmp/test2.json', None, test_url)
    assert test_session2['path'] == Path(os.path.expanduser('/tmp/test2.json'))

# Generated at 2022-06-21 14:45:29.583033
# Unit test for constructor of class Session
def test_Session():
    session_name = 'test_session'
    url = 'http://www.example.com'
    hostname = urlsplit(url).netloc.split('@')[-1]
    path = (
        DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / hostname / f'{session_name}.json'
    )
    session = Session(path)
    session.load()
    assert session.headers

    # Store a session
    session.save()
    # Reload a session
    session.load()
    # Remove a session
    session.remove()

# Generated at 2022-06-21 14:45:31.520518
# Unit test for constructor of class Session
def test_Session():
    ses = Session("/tmp/session.txt")
    assert ses.get("headers") == {}

# Generated at 2022-06-21 14:45:39.715624
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_Session_update_headers')
    session.update_headers({'Accept': 'application/json'})
    assert session['headers']['Accept'] == 'application/json'
    session.update_headers({'Accept': 'text/html'})
    assert session['headers']['Accept'] == 'text/html'
    session.update_headers({'Content-Type': 'application/json'})
    assert 'Content-Type' not in session['headers']
    session.update_headers({'User-Agent': 'HTTPie/0.9.8'})
    assert 'User-Agent' not in session['headers']
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})

# Generated at 2022-06-21 14:45:51.457812
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    class A:
        def __init__(self, name, value):
            self.name = name
            self.value = value

        def __repr__(self):
            return "{0}(name={1}, value)".format(self.__class__.__name__, self.name, self.value)

        def keys(self):
            return [self.name]

        def __getitem__(self, k):
            return self.value

    class B:
        def items(self):
            return [('Cookie', A('Cookie', 'one=two'))]

    session = Session('')
    session.update_headers(B())
    assert session['headers'] == {}
    assert session['cookies'] == {'one': {'value': 'two'}}

# Generated at 2022-06-21 14:45:56.952183
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'test'
    host = 'www.google.com'
    url = 'http://www.google.com/'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
                'type': None,
                'username': None,
                'password': None
            }

# Generated at 2022-06-21 14:46:01.656861
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_Session = Session('test_Session')
    request_headers = RequestHeadersDict()
    test_Session.update_headers(request_headers)
    assert test_Session.headers == {}

# Generated at 2022-06-21 14:46:10.922926
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('config')
    session_name = 'session_1'
    host = 'http://www.baidu.com'
    url = 'https://www.baidu.com/'
    session = get_httpie_session(config_dir, session_name, host, url)

    # Check whether the Session object is created correctly
    assert session.path == Path(config_dir) / SESSIONS_DIR_NAME / 'www_baidu_com' / 'session_1.json'
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

    # Check whether the function returns the Session object correctly
    assert session.is_init() == False


# Generated at 2022-06-21 14:46:25.192827
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """
    Purpose:
        Unit test for function get_httpie_session.
    Pre-conditions:
        N/A.
    Test-cases:
        N/A.
    Return:
        N/A.
    Post-conditions:
        N/A.
    """

    # This section of code runs for the entirety of the testing.

# Generated at 2022-06-21 14:46:32.427626
# Unit test for constructor of class Session
def test_Session():
    config_dir = Path('~/httpie')
    session_name = 'session1'
    host = 'host.net'
    url = 'http://host.net/path'

    # testing session_name contains os separator
    path = str(config_dir) + os.path.sep + session_name + '.json'
    assert get_httpie_session(config_dir, session_name, host, url).path == Path(path)

    # testing session_name doesn't contain os separator
    path = os.path.join(str(config_dir), SESSIONS_DIR_NAME, host, session_name + '.json')
    assert get_httpie_session(config_dir, session_name, host, url).path == Path(path)



# Generated at 2022-06-21 14:46:44.501968
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session.cookies = RequestsCookieJar()
    session.cookies.set('c1', 'v1')
    session.cookies.set('c2', 'v2')
    session.cookies.set('c3', 'v3')

# Generated at 2022-06-21 14:46:56.129483
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # test example 1
    session_headers = {'header1': 'value1', 'header2': 'value2'}
    session = Session("")
    session.update_headers(session_headers)
    assert session['headers'] == {'header1': 'value1', 'header2': 'value2'}
    assert session['cookies'] == {}    

    # test example 2
    session_headers = {'cookie': 'test=test'}
    session.update_headers(session_headers)
    assert session['headers'] == {'header1': 'value1', 'header2': 'value2'}
    assert session['cookies'] == {'test': {'value': 'test'}}

    # test example 3

# Generated at 2022-06-21 14:46:59.585605
# Unit test for constructor of class Session
def test_Session():
    session = Session('session')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-21 14:47:06.287374
# Unit test for constructor of class Session
def test_Session():
    x = Session(Path('./fileName.txt'))
    assert x['headers'] == {}
    assert x['cookies'] == {}
    assert x['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }
    assert x.headers == RequestHeadersDict({})
    assert x.cookies == RequestsCookieJar()
    assert x.auth == None


# Generated at 2022-06-21 14:47:12.130046
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    s['cookies'] = {'csrftoken': 'H5X5KcmVmQ2hlYmFmJw=='}
    s.remove_cookies(['csrftoken'])
    assert len(s['cookies']) == 0, 'cookie has not been removed'

# Generated at 2022-06-21 14:47:14.708980
# Unit test for constructor of class Session
def test_Session():
    path = Path('/etc/config_test.json')
    session = Session(path)


# Generated at 2022-06-21 14:47:22.887082
# Unit test for constructor of class Session
def test_Session():
    s = Session('../sessions/localhost/test.json')

    # test ['headers']
    assert s['headers'] == {}

    # test ['cookies']
    assert s['cookies'] == {}

    # test ['auth']
    auth = {
        'type': None,
        'username': None,
        'password': None
    }
    assert s['auth'] == auth

    # test headers
    s.headers == RequestHeadersDict({})

    # test cookies
    assert s.cookies == RequestsCookieJar()

    # test auth
    assert s.auth == None

if __name__ == "__main__":
    test_Session()

# Generated at 2022-06-21 14:47:27.210412
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='./foo.json')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-21 14:47:43.185552
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/test/test.json')
    assert session.empty
    assert session.cookies == RequestsCookieJar()
    assert session['cookies'] == {}
    session._data['cookies'].update({'a': {'value': '1'}})
    session._data['cookies'].update({'b': {'value': '2'}})
    session._data['cookies'].update({'c': {'value': '3'}})
    assert len(session._data['cookies']) == 3
    session.remove_cookies(['b'])
    assert len(session._data['cookies']) == 2
    assert not session.empty
    assert session.cookies.get_dict().keys() == {'a', 'c'}

# Generated at 2022-06-21 14:47:47.638601
# Unit test for constructor of class Session
def test_Session():
    session = Session("test.txt")
    assert session["headers"] == {}
    assert session["cookies"] == {}
    assert session["auth"] == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-21 14:47:53.319823
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('tests.json')
    session['cookies']['a'] = {'value': 'b'}
    session['cookies']['d'] = {'value': 'e'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'d': {'value': 'e'}}


# Generated at 2022-06-21 14:48:05.030350
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sessions_dir = DEFAULT_SESSIONS_DIR
    assert get_httpie_session(sessions_dir, 'httpbin', 'httpbin.org', 'http://httpbin.org/') == get_httpie_session(sessions_dir, 'httpbin', None, 'http://httpbin.org/')
    assert get_httpie_session(sessions_dir, 'httpbin.org', 'httpbin.org', 'http://httpbin.org/') == get_httpie_session(sessions_dir, 'httpbin', 'httpbin.org', 'http://httpbin.org/')

# Generated at 2022-06-21 14:48:09.206828
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {'User-Agent': 'test'}
    session = Session(object())
    session.update_headers(request_headers)
    assert session.headers == {'User-Agent': 'test'}



# Generated at 2022-06-21 14:48:16.294302
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path="test")
    session['headers'] = {'accept': 'application/json'}
    session.update_headers({'content-type': 'application/json'})
    assert session['headers'] == {'accept': 'application/json',
                                  'content-type': 'application/json'}
    assert session['cookies'] == {}

    session['headers'] = {'accept': 'application/json'}
    session.update_headers({'cookie': 'username=admin'})
    assert session['headers'] == {'accept': 'application/json'}
    assert session['cookies'] == {'username': {'value': 'admin'}}


# Generated at 2022-06-21 14:48:22.722562
# Unit test for constructor of class Session
def test_Session():
    my_session = Session(path='config/sessions/www.google.com/test.json')
    my_session = Session(path='test.json')
    assert my_session['headers'] == {}
    assert my_session['cookies'] == {}
    assert my_session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-21 14:48:30.624451
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.context import Environment
    from httpie.downloads import parse_content_range
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.cli.argtypes import KeyValueArg

    # create the instance of Session
    test_session_1 = Session(path="test_session_1")

    # create a request headers dictionary
    request_headers = RequestHeadersDict()

    # Case 1, update headers when the request headers contains no previous headers
    test_session_1.update_headers(request_headers=request_headers)
    assert not test_session_1.headers

    # Case 2, update headers when the request headers contains previous headers
    request_headers['Accept'] = 'text/html,application/json'
    request_headers['Connection'] = 'keep-alive'

# Generated at 2022-06-21 14:48:38.107500
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s.update({
                'cookies': {
                            'name1': {'value': 'cookie1'},
                            'name2': {'value': 'cookie2'},
                            'name3': {'value': 'cookie3'}
                            }
                })
    s.remove_cookies(['name1', 'name3'])
    assert s['cookies'] == {'name2': {'value': 'cookie2'}}

# Generated at 2022-06-21 14:48:42.932748
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from unittest.mock import Mock

    session = Session(Mock())
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['b', 'c'])
    assert session['cookies'] == {'a': 1}



# Generated at 2022-06-21 14:48:56.811262
# Unit test for constructor of class Session
def test_Session():
    '''
    Test default value
    '''
    path = 'path'
    session = Session(path)
    assert session.headers == {}
    assert session.cookies == {}
    assert session.auth.get('type') == None
    assert session.auth.get('username') == None
    assert session.auth.get('password') == None


# Generated at 2022-06-21 14:49:01.220578
# Unit test for function get_httpie_session
def test_get_httpie_session():
    def name_to_path(name):
        config_dir = '/home/test/.config'
        host = 'example.com'
        url = 'https://example.com'
        session = get_httpie_session(config_dir, name, host, url)
        return session.path

    assert (
        name_to_path('foo') ==
        Path('/home/test/.config/sessions/example.com/foo.json')
    )
    assert (
        name_to_path('https://example.com/foo') ==
        Path('https://example.com/foo')
    )
    assert (
        name_to_path('~/foo') ==
        Path('/home/test/foo')
    )

# Generated at 2022-06-21 14:49:06.706837
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies']['name1'] = 'value1'
    session['cookies']['name2'] = 'value2'
    session.remove_cookies({'name2'})
    assert session['cookies'] == {'name1': 'value1'}


# Generated at 2022-06-21 14:49:17.017201
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/home/user/.httpie')
    session_name = 'session.txt'
    host = '127.0.0.1'
    url = '127.0.0.1'

    if os.path.sep in session_name:
        path = os.path.expanduser(session_name)
    else:
        hostname = host or urlsplit(url).netloc.split('@')[-1]
        if not hostname:
            # HACK/FIXME: httpie-unixsocket's URLs have no hostname.
            hostname = 'localhost'
        path = config_dir / SESSIONS_DIR_NAME / hostname / f'{session_name}.json'

    session = Session(path)
    session.load()

    print(session['headers'])

# Generated at 2022-06-21 14:49:22.313028
# Unit test for constructor of class Session
def test_Session():
    sess = Session('path')
    assert sess.get('headers') == {}
    assert sess.get('cookies') == {}
    assert sess.get('auth') == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-21 14:49:24.750964
# Unit test for constructor of class Session
def test_Session():
    s = Session('.httpie-sessions/local/test.json')
    print(s)

# Generated at 2022-06-21 14:49:29.406538
# Unit test for constructor of class Session
def test_Session():
    print("Inside test_Session()")
    s = Session("tests/data/sessions/0.json")
    print(s)
    print(s.path)
    print(s["headers"])
    print(s.headers)
    print(s["cookies"])
    print(s.cookies)
    print(s["auth"])
    print(s.auth)

test_Session()

# Generated at 2022-06-21 14:49:35.531196
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_dict = {'a': '1', 'b': '2', 'c': '3'}
    session = Session('a')
    session['cookies'] = cookie_dict
    session.remove_cookies(['a', 'b'])
    expected = {'c': '3'}
    assert session['cookies'] == expected



# Generated at 2022-06-21 14:49:46.643227
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')

    # Case I : none value headers
    request_headers = {
        'Content-Type': None,
        'Accept': None,
        'Content-Length': 123,
        'X-Foo': 'foo',
        'X-Bar': None,
        'X-Baz': 'baz'
    }

    session.update_headers(request_headers)

    assert session == {
        'headers': {'Content-Length': '123', 'X-Foo': 'foo', 'X-Baz': 'baz'},
        'cookies': {},
        'auth': {'type': None, 'username': None, 'password': None}
    }

    # Case II : HTTPie self headers
    session = Session('test')

# Generated at 2022-06-21 14:49:56.850917
# Unit test for constructor of class Session
def test_Session():
    config_dir = Path('/home/ubuntu/.httpie/sessions')
    host = 'localhost'
    url = 'http://localhost:8080'
    httpie_session = get_httpie_session(config_dir, 'my_session', host, url)
    file_path = httpie_session.file_path
    assert file_path == Path("/home/ubuntu/.httpie/sessions/localhost/my_session.json")
    session_dict = httpie_session.get_config_dict()
    assert session_dict['headers'] == {}
    assert session_dict['cookies'] == {}
    assert session_dict['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-21 14:50:16.884212
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')

# Generated at 2022-06-21 14:50:21.037186
# Unit test for constructor of class Session
def test_Session():
    path = "./.test"
    session = Session(path)
    assert session["headers"] == {}
    assert session["cookies"] == {}
    assert session["auth"] == {
        "type" : None,
        "username" : None,
        "password" : None
    }


# Generated at 2022-06-21 14:50:23.057659
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test")
    session.load()
    session['cookies'] = {'test1': {'value': 123}, 'test2': {'value': 456}}
    session.remove_cookies(['test1'])
    assert session['cookies'] == {'test2': {'value': 456}}

# Generated at 2022-06-21 14:50:24.922239
# Unit test for constructor of class Session
def test_Session():
    ssn = Session('~/.config/httpie/sessions/localhost/test.json')
    ssn.save()


# Generated at 2022-06-21 14:50:28.249966
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(Path('~/.config'), 'mysession', '', '')
    assert get_httpie_session(Path('~/.config'), 'mysession', 'http://localhost', '')

# Generated at 2022-06-21 14:50:37.438064
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    ses = Session('C:/Users/User1/AppData/Local/httpie/sessions/bookmark.json')
    request_headers = {'Accept': 'text/html,application/json',
                       'User-Agent': 'httpie',
                       'Content-Type': 'application/json',
                       'cookie': 'cookie'}
    ses.update_headers(request_headers)
    assert ses.headers == {'Accept': 'text/html,application/json',
                           'User-Agent': 'httpie',
                           'Content-Type': 'application/json'}

# Generated at 2022-06-21 14:50:41.165148
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_file')
    session['cookies'] = {'test': 'some_value'}
    session.remove_cookies(['test'])
    assert 'test' not in session['cookies']

# Generated at 2022-06-21 14:50:45.057878
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test.json")
    session['cookies'] = {'test': {'value': 'test'}, 'test2': {'value': 'test2'}}
    session.remove_cookies(['test', 'test2'])
    assert len(session['cookies']) == 0

# Generated at 2022-06-21 14:50:47.351488
# Unit test for constructor of class Session
def test_Session():
    assert isinstance(Session(path=Path('test')), BaseConfigDict)


# Generated at 2022-06-21 14:50:53.662507
# Unit test for constructor of class Session
def test_Session():
    '''
    >>> dir(Session)
    ['helpurl', 'path', 'to_json', 'update']
    >>> session = Session('./test.json')
    >>> session.path
    './test.json'
    >>> session.to_json()
    '{"headers": {}, "cookies": {}}'
    '''



# Generated at 2022-06-21 14:51:13.622302
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import tempfile
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins.registry import plugin_manager

    config_dir = Path(tempfile.mkdtemp())
    os.makedirs(config_dir / SESSIONS_DIR_NAME, exist_ok=True)

    config = Config(config_dir=config_dir, env=Environment())
    plugin_manager.load_installed_plugins(config)

    session_name = 'test'
    session = get_httpie_session(config_dir, session_name, None, 'http://httpie.org/resource')
    assert session['headers'] == {}
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:51:24.124134
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Verify the exception is raised if session_name has the directory separator in
    try:
        get_httpie_session(DEFAULT_CONFIG_DIR, 'httpbin.org/get', 'httpbin.org', 'httpbin.org/get')
        assert False, 'The exception is not raised'
    except ValueError:
        pass
    # Verify the exception is raised if host is not set and url doesn't contain a host
    try:
        get_httpie_session(DEFAULT_CONFIG_DIR, 'httpbin.org/get', '', 'httpbin.org/get')
        assert False, 'The exception is not raised'
    except ValueError:
        pass
    # Verify that a slash in the URL will be replaced by underscore

# Generated at 2022-06-21 14:51:36.169592
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.models import Request
    session = Session('session')

# Generated at 2022-06-21 14:51:38.207634
# Unit test for constructor of class Session
def test_Session():
    # arrange
    path = 'path'
    session = Session(path)
    # act & assert
    assert session['headers'] == {}

# Generated at 2022-06-21 14:51:43.663008
# Unit test for constructor of class Session
def test_Session():
    s = Session(path='/home/vladkim/python/httpie/httpie/.config/httpie')
    s['headers'] = {}
    s['cookies'] = {}
    s['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }
    assert isinstance(s, Session)


# Generated at 2022-06-21 14:51:47.961453
# Unit test for function get_httpie_session
def test_get_httpie_session():
    path = get_httpie_session(
        config_dir = "/Users/jakubdobis/.httpie/config",
        session_name = "session",
        host = "127.0.0.1",
        url = "http://127.0.0.1:8080/session",
        )
    assert "" == path

# Generated at 2022-06-21 14:51:56.060986
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/non-existent/session.json')
    cookies = {'c1': {}, 'c2': {}, 'c3': {}}
    s['cookies'] = cookies

    s.remove_cookies(['c1'])
    assert s['cookies'] == {'c2': {}, 'c3': {}}

    s.remove_cookies(['c1', 'c2', 'c3'])
    assert s['cookies'] == {}

# Generated at 2022-06-21 14:51:57.492695
# Unit test for constructor of class Session
def test_Session():
    path = 'test_path'
    sess = Session(path)


# Generated at 2022-06-21 14:52:07.387587
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/testing/session.json')
    # dict
    rheaders_dict = {'content-type': 'application/json', 'accept':'text/plain', 'User-Agent': 'HTTPie/0.9.9',
                     'Connection': 'keep-alive', 'Host': 'httpbin.org', 'Content-Length': '127'}
    # object
    rheaders_obj = RequestHeadersDict(rheaders_dict)
    # object
    session.update_headers(rheaders_obj)
    # dict
    session.update_headers(rheaders_dict)
    print(session.headers)

# Generated at 2022-06-21 14:52:14.160258
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_headers = {
        'Accept': 'text/html',
        'User-Agent': 'HTTPie/1.0',
        'If-Match': None
    }
    session = Session('unit_test')
    session.update_headers(RequestHeadersDict(test_headers))
    assert session.headers == {'Accept': 'text/html'}

# Generated at 2022-06-21 14:52:35.904276
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """Unit test for method remove_cookies of class Session

    """
    session = Session('session_x.json')
    session['cookies'] = {'key1': 1, 'key2': 2}
    session.remove_cookies(['key1'])
    assert 'key1' not in session['cookies']
    assert 'key2' in session['cookies']

# Generated at 2022-06-21 14:52:44.422982
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """Test that certain headers are ignored when stored in a session.

    """

# Generated at 2022-06-21 14:52:48.020414
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session')
    session['cookies'] = {'name':'value'}
    session.remove_cookies('name')
    assert session['cookies'] == {}
    session['cookies'] = {'name':'value', 'key':'value2'}
    session.remove_cookies('key')
    assert session['cookies'] == {'name':'value'}
    session['cookies'] = {'name':'value', 'key':'value2'}
    session.remove_cookies('key', 'name')
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:52:53.417041
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(Path('/tmp/test_Session_remove_cookies'))
    s['cookies'] = {'name1':{'value':'value1'}}
    s.remove_cookies(['name1'])
    assert s['cookies'] == {}


# Generated at 2022-06-21 14:52:57.195892
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/home/httpie/.config/httpie/sessions')
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1', 'name3'])
    assert 'name1' not in session['cookies']
    assert 'name2' in session['cookies']

# Generated at 2022-06-21 14:53:02.982702
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # create a session
    session = Session('/tmp/path.json')
    session['cookies'] = {
        'foo': {'value': 'foo_value'},
        'bar': {'value': 'bar_value'},
        'baz': {'value': 'baz_value'}
    }
    # remove_cookies() should remove all cookies which name is in names
    session.remove_cookies(['bar', 'baz'])
    assert session['cookies'] == {'foo': {'value': 'foo_value'}}
    # remove_cookies() should do nothing if param 'names' is empty
    session.remove_cookies([])
    assert session['cookies'] == {'foo': {'value': 'foo_value'}}

# Generated at 2022-06-21 14:53:07.922836
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session')
    session['cookies'] = {'foo': 'bar', 'boo': 'far'}
    session.remove_cookies(['boo'])
    assert session['cookies'] == {'foo': 'bar'}
    session.remove_cookies(['foo'])
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:53:19.388446
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test')
    assert {} == session['headers']
    session.update_headers(RequestHeadersDict([('k1', 'v1')]))
    assert {'k1': 'v1'} == session['headers']
    session.update_headers(RequestHeadersDict([('k1', None)]))
    assert {} == session['headers']
    session.update_headers(RequestHeadersDict([('k1', 'v1')]))
    assert {'k1': 'v1'} == session['headers']
    session.update_headers(RequestHeadersDict([('k2', 'v2')]))
    assert {'k1': 'v1', 'k2': 'v2'} == session['headers']

# Generated at 2022-06-21 14:53:28.688086
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import requests.models
    import requests.cookies

    sess = get_httpie_session(DEFAULT_CONFIG_DIR,
                              'test_session',
                              'localhost',
                              'http://localhost/')
    assert isinstance(sess, Session)

    sess['auth'] = {'type': 'basic',
                    'username': 'foo',
                    'password': 'bar'}

    sess['headers'] = {'Content-Type': 'application/json'}
    sess['cookies'] = requests.cookies.RequestsCookieJar()
    sess['cookies'].set('foo', 'bar')

    req = requests.models.PreparedRequest()
    sess.update_headers(req.headers)
    sess.cookies.update(req.cookies)
    assert hasattr

# Generated at 2022-06-21 14:53:39.722847
# Unit test for constructor of class Session
def test_Session():
    config_dir = Path('./test_config_dir')

    print(config_dir)
    print("./test_config_dir" == str(config_dir))

    session_name = "session1"
    url = "https://httpbin.org"
    host = urlsplit(url).netloc
    print(host)

    session = get_httpie_session(config_dir, session_name, host, url)

    # test headers
    headers = {'a': 2, 'b': 3}
    session.update_headers(headers)
    print(session["headers"])

    # test auth
    auth = {'a': 2, 'b': 3}
    # session.auth = auth
    print(session["auth"])
    # print(session.auth)

# Generated at 2022-06-21 14:54:03.902606
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://www.example.com/path/?foo=bar#fragment'
    config_dir = Path('/tmp/httpie_config')
    config_dir.mkdir(exist_ok=True)
    session_name = 'session-name'
    host = 'example.com'

    path = config_dir / SESSIONS_DIR_NAME / host / f'{session_name}.json'

    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.path == path



# Generated at 2022-06-21 14:54:10.416739
# Unit test for constructor of class Session
def test_Session():
    s = Session('http://www.google.com')
    assert s.helpurl is 'https://httpie.org/doc#sessions'
    assert s.about is 'HTTPie session file'
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-21 14:54:14.816973
# Unit test for constructor of class Session
def test_Session():
    path = Path("/home/user/.httpie/sessions/example.com/default")
    test_session = Session(path)
    assert test_session['headers'] == {}
    assert test_session['cookies'] == {}
    assert test_session['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-21 14:54:21.290464
# Unit test for function get_httpie_session
def test_get_httpie_session():
    path = Path("/some/path/to/cookies")
    session_name = 'some_session'
    host = 'www.example.com'
    url = 'http://localhost/some/path'

    expected_path = Path("/some/path/to/cookies/sessions/www_example_com/some_session.json")

    actual_path = get_httpie_session(path, session_name, host, url).path

    assert actual_path == expected_path

# Generated at 2022-06-21 14:54:32.939944
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Test with a valid token
    config_dir = Path("/tmp")
    session_name = "httpie"
    host = "google.com"
    url = "https://google.com"
    session = get_httpie_session(config_dir, session_name, host, url)
    session.load()
    assert isinstance(session["headers"], dict)
    assert isinstance(session["cookies"], dict)
    assert isinstance(session["auth"], dict)

    # Test with an invalid token
    session_name = "!"
    host = "google.com"
    url = "https://google.com"
    session = get_httpie_session(config_dir, session_name, host, url)
    session.load()
    assert isinstance(session["headers"], dict)

# Generated at 2022-06-21 14:54:40.747322
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class DummySession(Session):
        def __init__(self, path: Union[str, Path]):
            super().__init__(path=Path(path))
            self['headers'] = {}
        def store(self):
            pass

    from httpie.cli.parser import RequestParser
    from httpie.input import ParseError
    from httpie.context import Environment
    from httpie.compat import urlparse

    # Setup authentication
    env = Environment(parser=RequestParser())
    env.config.config_dir = Path('/fake/config/directory')
    auth = {'type': 'basic', 'raw_auth': 'user:password'}
    env.config['sessions'].update({'name': auth})

    # Testing cookie

# Generated at 2022-06-21 14:54:46.007467
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('')
    request_headers = [('header1', '1'), ('header2', '2'), ('Content-Type', '3')]
    request_headers = RequestHeadersDict(request_headers)
    print(request_headers)
    s.update_headers(request_headers)
    print(request_headers)

# test_Session_update_headers()