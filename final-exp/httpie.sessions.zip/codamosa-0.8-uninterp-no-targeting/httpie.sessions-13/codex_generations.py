

# Generated at 2022-06-21 14:45:02.518601
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(
        Path('/tmp/httpie'), 'default', 'httpie.org', 'httpie.org/')



# Generated at 2022-06-21 14:45:06.230789
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    foo = Session("foo")
    foo['cookies'] = {"abc": {"value": "123"}}
    foo.remove_cookies(["abc"])
    assert "abc" not in foo['cookies']

# Generated at 2022-06-21 14:45:17.025802
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.config import BaseConfigDict
    from httpie.plugins.registry import plugin_manager
    from requests.cookies import RequestsCookieJar, create_cookie

    ## testing for Session class

    # creating instance of session
    session = Session("./httpie_sessions/example.com/session1.json")
    session["headers"] = {}

# Generated at 2022-06-21 14:45:24.735283
# Unit test for function get_httpie_session
def test_get_httpie_session():
    s = get_httpie_session(DEFAULT_CONFIG_DIR, 'foo', 'example.com', 'http://example.com')
    s['headers']['baz'] = '1'
    s.save()
    s = get_httpie_session(DEFAULT_CONFIG_DIR, 'foo', 'example.com', 'http://example.com')
    assert s['headers'] == {'baz': '1'}
    s['headers']['baz'] = '2'
    s.save()
    s = get_httpie_session(DEFAULT_CONFIG_DIR, 'foo', 'example.com', 'http://example.com')
    assert s['headers'] == {'baz': '2'}

if __name__ == '__main__':
    test_get_httpie_session

# Generated at 2022-06-21 14:45:26.683487
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict({'accept': 'text/html', 'accept-encoding': 'gzip, deflate'})
    s = Session(path = './test-session.json')
    s.update_headers(headers=headers)
    assert s['headers'] == headers

# Generated at 2022-06-21 14:45:33.850238
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from os.path import expanduser
    from httpie.config import Config, FileNotFound
    from httpie.config import DEFAULT_CONFIG_DIR

    a = get_httpie_session(DEFAULT_CONFIG_DIR, 'test', 'http://localhost:8000',
                           'http://localhost:8000/')
    b = get_httpie_session(DEFAULT_CONFIG_DIR, 'test', 'http://localhost:8000',
                           'http://localhost:8000/')
    assert a == b
    assert a['auth'] == b['auth']

    c = get_httpie_session(expanduser('~/.config'), 'test', None,
                           'http://localhost/')
    assert a != c
    assert a['auth'] != c['auth']
    a['auth'] = c['auth']

# Generated at 2022-06-21 14:45:40.081291
# Unit test for function get_httpie_session
def test_get_httpie_session():
    test_url = '/test_url'
    config_dir = Path('.config')
    session_name = 'test'
    host = '127.0.0.1'
    session = get_httpie_session(config_dir, session_name, host, test_url)
    assert session

# Generated at 2022-06-21 14:45:52.247005
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # create a request_headers for "http -s https://httpie.org"
    request_headers = {
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Host': 'httpie.org',
        'If-None-Match': 'W/"353b8e8b"',
        'If-Modified-Since': 'Fri, 09 Jul 2010 00:00:02 GMT',
        'User-Agent': 'HTTPie/0.9.9',
    }
    # create a session
    path = 'test/test_session'
    session = Session(path)
    session.load()
    session.update_headers(request_headers)
    # check if the request_headers are correctly added to session

# Generated at 2022-06-21 14:45:58.913088
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import os
    import json
    url = 'http://www.google.com/'
    config_dir = '/tmp/httpie'
    os.environ['HTTPIE_CONFIG_DIR'] = config_dir
    session_name = 'my_session'
    session = get_httpie_session(config_dir, session_name, host=None, url=url)
    session.save()

    data = json.load(open('/tmp/httpie/sessions/www.google.com/my_session.json'))
    assert data['header'] == {}
    assert data['cookies'] == {}
    assert data['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-21 14:46:06.373508
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("./test.json")
    request_headers = RequestHeadersDict({'user-agent': 'HTTPie/1.0.2', 'Cookie': 'token=12345678'})
    session.update_headers(request_headers)
    assert session['headers'] == {}
    assert session['cookies'] == {'token': {'value': '12345678'}}
    assert request_headers == RequestHeadersDict({})

# Generated at 2022-06-21 14:46:16.338775
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('')
    session_name = 'session_name'
    host = None
    url = 'https://httpbin.org/get'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert isinstance(session, Session)

# Generated at 2022-06-21 14:46:23.236493
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./test.json')
    session['cookies'] = {'Cookie1':{
        'path': '/',
        'secure': False,
        'value': 'Cookie1_Value'
        }
    }
    # Assume that we want to remove cookie 'Cookie2'
    session.remove_cookies({'Cookie2'})
    assert session['cookies'] == {'Cookie1':{
        'path': '/',
        'secure': False,
        'value': 'Cookie1_Value'
        }
    }
    # Assume that we want to remove cookie 'Cookie1'
    session.remove_cookies({'Cookie1'})
    assert session['cookies'].keys() == set()

    # Assume that we want to remove cookies 'Cookie2' and

# Generated at 2022-06-21 14:46:34.464955
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Create sample session
    path = 'sessions/httpie/session.json'
    session = Session(path)

    session['cookies'] = {
        'A' : {'value' : '1'},
        'B' : {'value' : '2'},
        'C' : {'value' : '3'}
    }

    assert 'A' in session['cookies']
    assert 'B' in session['cookies']
    assert 'C' in session['cookies']

    # Remove cookie
    session.remove_cookies(['A', 'C'])

    assert 'A' not in session['cookies']
    assert 'C' not in session['cookies']
    assert 'B' in session['cookies']

# Generated at 2022-06-21 14:46:43.253570
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    mysession = Session(config_dir=DEFAULT_SESSIONS_DIR)
    mydict = {'test': {'value': 'value', 'path': 'path', 'secure': True},
              'test2': {'value': 'value2', 'path': 'path2', 'secure': False}}
    mysession['cookies'] = mydict
    mysession.remove_cookies(['test2'])
    assert mysession['cookies'] == {'test': {'value': 'value', 'path': 'path',
                                             'secure': True}}


# Generated at 2022-06-21 14:46:55.378372
# Unit test for constructor of class Session
def test_Session():
    from httpie.models import FormData

    path = Path("~/.httpie/sessions/s.json")
    session = Session(path)
    assert session.keys() == ['headers', 'cookies', 'auth']
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    assert session.helpurl == 'https://httpie.org/doc#sessions'
    assert session.about == 'HTTPie session file'

    session.update_headers(RequestHeadersDict({
        'content-type': 'application/x-www-form-urlencoded'
    }))

    data = FormData()

# Generated at 2022-06-21 14:46:59.739885
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies']['one'] = 'one_value'
    session['cookies']['two'] = 'two_value'
    session.remove_cookies(['one'])
    assert('one' not in session['cookies'])
    assert('two' in session['cookies'])



# Generated at 2022-06-21 14:47:01.280948
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session.__doc__ is not None

# Generated at 2022-06-21 14:47:08.572060
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {
        'foo': {'value': 'bar'},
        'baz': {'value': 'qux'}
    }
    session = Session(path=None)
    session['cookies'] = cookies
    assert session['cookies'] == cookies
    session.remove_cookies(names=['foo'])
    assert session['cookies'] == {'baz': {'value': 'qux'}}
    session.remove_cookies(names=['foo', 'baz'])
    assert session['cookies'] == {}



# Generated at 2022-06-21 14:47:20.059288
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(config_dir=Path(DEFAULT_CONFIG_DIR), session_name="test", host=None, url="http://foo.com")
    assert session.to_dict() == {'auth': {'type': None, 'username': None, 'password': None},
            'cookies': {},
            'headers': {}
            }
    # Try with a bad session name
    try:
        get_httpie_session(config_dir=Path(DEFAULT_CONFIG_DIR), session_name="test/../test", host=None, url="http://foo.com")
        assert False
    except ValueError:
        pass
    # Try with a bad host name

# Generated at 2022-06-21 14:47:25.994708
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
   s = Session(path='tests/session_test_1.json')
   s.load()
   # test with existing cookie
   s.remove_cookies(['mycookie'])
   assert 'mycookie' not in s.cookies
   # test with non existing cookie
   s.remove_cookies(['non_existing_cookie'])
   assert 'non_existing_cookie' not in s.cookies
   # test with empty list
   s.remove_cookies([])
   assert 'non_existing_cookie' not in s.cookies

# Generated at 2022-06-21 14:47:40.574507
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from requests.cookies import RequestsCookieJar
    cookie = RequestsCookieJar()
    cookie.set('name', 'value')
    session = Session(path='path')
    session['cookies'] = cookie

    headers = {'cookie': 'name=value; Expires=Wed, 09 Jun 2021 10:18:14 GMT',
               'user-agent': 'HTTPie/0.9.9',
               'content-type': 'application/json',
               'if-match': '*'
               }
    session.update_headers(headers)
    assert 'content-type' not in session['headers'].keys()
    assert 'user-agent' not in session['headers'].keys()
    assert 'if-match' not in session['headers'].keys()

# Generated at 2022-06-21 14:47:51.160780
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('__test_session__')
    session['headers'] = {'term': 'xterm-256color'}
    request_headers = RequestHeadersDict()
    request_headers['Accept-Encoding'] = 'gzip,deflate,lzma'
    request_headers['Content-Type'] = 'application/json'
    request_headers['Content-Length'] = '134'
    request_headers['If-Modified-Since'] = 'Thu, 29 Dec 2016 12:43:40 GMT'
    request_headers['If-Match'] = 'W/"a1abd1e4b1c58e2d894d434a33a38ba9"'

# Generated at 2022-06-21 14:47:57.438723
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', 'localhost', 'https://localhost/test')
    assert type(session) is Session
    assert session['cookies'] == {}
    assert session['headers'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }

# Generated at 2022-06-21 14:48:07.752534
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    from pathlib import Path
    import os
    config_app = Config()

    session_name = 'test'
    host = 'www.test.com'
    url = host
    config_app.config_dir = os.path.join('..', 'httpie')
    os.makedirs(os.path.join('..', 'httpie', 'sessions', host))
    Path(os.path.join('..', 'httpie', f'{session_name}.json')).touch()

    # Test when exists session file
    session = get_httpie_session(config_app.config_dir, session_name, host, url)
    assert session['headers'] != {} and session['cookies'] != {}

# Generated at 2022-06-21 14:48:12.414614
# Unit test for constructor of class Session
def test_Session():
	p = Path("/Users/chen/.config/httpie/sessions")
	p.mkdir(parents=True, exist_ok=True)
	s = Session("/Users/chen/.config/httpie/sessions/example.json")
	print(s)


# Generated at 2022-06-21 14:48:18.022732
# Unit test for constructor of class Session
def test_Session():
    fp = 'tests/sessions/t.json'
    session = Session(fp)
    assert session.path == fp
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
            }


# Generated at 2022-06-21 14:48:25.719597
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    cookies = dict()
    cookies['a'] = {'value': 'aaa'}
    cookies['b'] = {'value': 'bbb'}
    cookies['c'] = {'value': 'ccc'}
    cookies['d'] = {'value': 'ddd'}
    session['cookies'] = cookies
    session.remove_cookies(['b', 'c'])
    assert session['cookies'] == {'a': {'value': 'aaa'}, 'd': {'value': 'ddd'}}



# Generated at 2022-06-21 14:48:32.804034
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    session = Session('/fake/path')
    session['cookies'] = {'cookie1': {'expires': 'tomorrow'},
                          'cookie2': {'expires': 'tomorrow'},
                          'cookie3': {'expires': 'tomorrow'}}

    # Act
    session.remove_cookies(['cookie1', 'cookie3'])

    # Assert
    assert len(session['cookies']) == 1
    assert session['cookies']['cookie2'] == {'expires': 'tomorrow'}

# Generated at 2022-06-21 14:48:41.552535
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/tmp/config')
    session_name = 'session'

    # Test without host
    url = 'https://httpbin.org/'
    session = get_httpie_session(config_dir, session_name, None, url)
    assert session.path == config_dir / SESSIONS_DIR_NAME / 'httpbin.org' / 'session.json'

    # Test with host
    url = 'https://httpbin.org/'
    host = 'httpbin.org:80'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.path == config_dir / SESSIONS_DIR_NAME / 'httpbin.org_80' / 'session.json'



# Generated at 2022-06-21 14:48:48.164930
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=None)
    session['cookies']['a'] = {'value': 1}
    session['cookies']['b'] = {'value': 2}
    session['cookies']['c'] = {'value': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': {'value': 3}}



# Generated at 2022-06-21 14:48:58.766092
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("test")
    s.cookies = {'a':1, 'b':2}
    s.remove_cookies(['b'])
    assert s == {'cookies': {'a':1}}

# Generated at 2022-06-21 14:49:10.306398
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("/tmp/test_Session_update_headers")
    session.update_headers({'h':'v'})
    assert 'h' in session['headers']
    session.update_headers({'h':None})
    assert 'h' not in session['headers']
    session.update_headers({'h':'v', 'Cookie':"a=b; b=c"})
    assert 'h' in session['headers']
    assert 'a' in session['cookies']
    assert 'b' in session['cookies']
    assert session['cookies']['a']['value']=='b'
    assert session['cookies']['b']['value']=='c'


# Generated at 2022-06-21 14:49:17.641921
# Unit test for function get_httpie_session
def test_get_httpie_session():

    # session file not exists
    url = 'http://example.com'
    session_name = 'session-name'
    host = 'example.com'
    session = get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name=session_name,
        host=host,
        url=url,
    )
    assert session
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None,
    }

    # session file exists
    session.save()

# Generated at 2022-06-21 14:49:19.878789
# Unit test for constructor of class Session
def test_Session():
    s = Session('path')


# Generated at 2022-06-21 14:49:25.994137
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import mock
    import subprocess
    session_name = 'default'
    file_path = config_dir + '/sessions/' + session_name + '.json'
    with mock.patch('httpie.sessions.Session') as SessionMock:
        get_httpie_session(config_dir, session_name, '', '')
        SessionMock.assert_called_with(file_path)

# Generated at 2022-06-21 14:49:37.660345
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie import main
    from click.testing import CliRunner

    assert get_httpie_session(DEFAULT_CONFIG_DIR, "test", None, "https://httpie.org").headers == {}

    # Set up a session with a header
    runner = CliRunner()
    result = runner.invoke(main, ["--session=test", "--session-read-only", "https://httpie.org/get", "User-Agent:test-1"])
    assert result.exit_code == httpie.ExitStatus.OK
    assert get_httpie_session(DEFAULT_CONFIG_DIR, "test", None, "https://httpie.org").headers["User-Agent"] == "test-1"

    # Add another header
    result = runner.invoke

# Generated at 2022-06-21 14:49:46.548471
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/testing_session')
    session['cookies'] = {'a':{'path':'/', 'expires':1405263793.0,'name':'a', 'value':'b'}, 'c':{'path':'/', 'expires':1405263793.0,'name':'c', 'value':'d'}}
    session.remove_cookies(['c'])
    assert session['cookies'] == {'a':{'path':'/', 'expires':1405263793.0,'name':'a', 'value':'b'}}

# Generated at 2022-06-21 14:49:57.117651
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = os.path.expanduser('~/.config/httpie/auth.json')
    headers = {'Accept': "*/*", 'User-Agent': 'python-requests/2.20.0', 
    'Authorization': 'Basic amVmZmlja0BnbWFpbC5jb206WUp4Y1JHdGNiaTVKQ0JIWlFvSXpHUjhDaE1pWkJmakI', 'Host': 'httpbin.org', 
    'Connection': 'keep-alive', 'Accept-Encoding': 'gzip, deflate', 'Cookie': 'something=blah'
    }
    sess = Session(path)
    sess.update_headers(headers)
    print(sess.headers)

# Generated at 2022-06-21 14:50:01.795204
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session("sessions/test.json")
    s.update_headers({"User-Agent": "HTTPie/0.9.9", "Content-Type": "application/json", "If-Match": "*"})
    s.update_headers({"User-Agent": None})

    assert s['headers'] == {"Content-Type": "application/json", "If-Match": "*"}

# Generated at 2022-06-21 14:50:08.498858
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME
    session_name = config_dir / 'localhost' / 'sess-name.json'
    host = 'localhost:8080'
    url = 'http://localhost:8080/'

    assert get_httpie_session(config_dir, session_name, host, url).path == session_name

# Generated at 2022-06-21 14:50:47.866061
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import ExitStatus
    from httpie.cli.exceptions import ParseError
    from httpie.cli.input import ParseResult
    from httpie.cli.parser import parse_key_value_input
    from httpie.input import SEP_CREDENTIALS
    from httpie.plugins import AuthPlugin

    class UsernameAuth(AuthPlugin):

        auth_type = 'username'
        auth_parse = True

        def get_auth(self, username=None, password=None):
            auth = username if password is None else f'{username}{SEP_CREDENTIALS}{password}'
            return auth

    class UserAgentAuth(AuthPlugin):

        auth_type = 'user-agent'
        auth_parse = True

        def get_auth(self, useragent=None):
            auth = useragent


# Generated at 2022-06-21 14:50:57.288118
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path('/tmp/test_Session_remove_cookies.json'))
    session['cookies'] = {'cookieA': {'value': 'v1'}, 'cookieB': {'value': 'v3'}}
    session.remove_cookies(['cookieA', 'cookieC'])
    assert session['cookies'] == {'cookieB': {'value': 'v3'}}
    session.remove_cookies(['cookieB'])
    assert session['cookies'] == {}
    session.remove_cookies(['cookieX'])
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:51:03.198104
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = {'cookies': {'A': {'value':'a'}, 'B': {'value':'b'}}}
    session = Session('test_Session_remove_cookies')
    session.__dict__ = session
    session.remove_cookies(['A'])
    assert session['cookies'] == {'B': {'value':'b'}}

# Generated at 2022-06-21 14:51:08.777441
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/foo/bar')

    session['cookies'] = {'test': {'value': 'test'}, 'test2': {'value': 'test2'}}

    session.remove_cookies({'test', 'test3'})

    assert session['cookies'] == {'test2': {'value': 'test2'}}

# Generated at 2022-06-21 14:51:17.489456
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Given a request with Content and If headers
    from httpie.compat import str
    request_headers = RequestHeadersDict({
        b'Content-Type': b'application/json',
        b'If-Match': b'*',
        b"User-Agent": b"HTTPie/1.0.0",
        b"Cookie": b"id=000; token=abcde",
        b"Accept-Language": b"en-US,en;q=0.5"
    })

    # When we update the session headers
    session = Session('test.json')
    session.update_headers(request_headers)

    # Then the Content and If headers are not stored anymore

# Generated at 2022-06-21 14:51:26.491977
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    def read_file(path):
        with open(path) as f:
            return f.read()

    session_path  = './httpie/config/httpie_session.json'
    old_session = read_file(session_path)

    a_Session = Session(session_path)

    url = 'http://httpie.org/'
    request_headers = RequestHeadersDict({'Cookie': 'key1=value1; key2=value2'})

    a_Session.update_headers(request_headers)
    assert a_Session.headers['Cookie'] == 'key1=value1; key2=value2'
    assert a_Session['cookies'] == {'key1': {'value': 'value1'}, 'key2': {'value': 'value2'} }


# Generated at 2022-06-21 14:51:38.088609
# Unit test for constructor of class Session
def test_Session():
    test_file = 'httpie/sessions/test_file.json'
    s = Session(os.path.abspath(test_file))
    assert isinstance(s['cookies'], dict)
    assert isinstance(s['auth'], dict)
    assert isinstance(s['headers'], dict)
    assert s['auth']['type'] is None
    assert s['auth']['username'] is None
    assert s['auth']['password'] is None
    s['auth']['type'] = 'basic'
    s['auth']['username'] = 'test'
    s['auth']['password'] = 'test'
    s.save()
    s['auth']['type'] = None
    s['auth']['username'] = None
    s['auth']['password'] = None

# Generated at 2022-06-21 14:51:42.160052
# Unit test for constructor of class Session
def test_Session():
    # No profile should be created
    session = Session(path = '/tmp/DNE/non_existing_session.json')
    assert not os.path.exists('/tmp/DNE/non_existing_session.json')


# Integration test for constructor of class Session

# Generated at 2022-06-21 14:51:45.766492
# Unit test for constructor of class Session
def test_Session():
    import pytest
    from pprint import pprint
    new_session = Session(config_dir='config_dir', session_name='session_name', host=None, url='url')
    new_session.cookies = ''



# Generated at 2022-06-21 14:51:51.757174
# Unit test for constructor of class Session
def test_Session():
    path = os.getcwd() + "/test/test_file.test"
    new_session = Session(path)
    assert new_session['headers'] == {}
    assert new_session['cookies'] == {}
    assert new_session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-21 14:52:39.400446
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert Path(__file__).absolute() == Path(__file__).resolve()
    config_dir = Path(__file__).absolute().parents[1]
    # unit test for function get_httpie_session
    session = get_httpie_session(config_dir, "default", None, "https://www.baidu.com")
    # unit test for property cookie of Session instance
    assert(isinstance(session.cookies, RequestsCookieJar))
    # unit test for property headers of Session instance
    assert(isinstance(session.headers, RequestHeadersDict))
    # unit test for property auth of Session instance
    assert(isinstance(session.auth, AuthBase))
    # unit test for function update_headers of Session instance

# Generated at 2022-06-21 14:52:48.096287
# Unit test for constructor of class Session
def test_Session():
    session_1 = Session("path/to/session_1.json")
    assert session_1["headers"] == {}
    assert session_1["cookies"] == {}
    assert session_1["auth"] == {"type": None, "username": None, "password": None}

    session_2 = Session("path/to/session_2.json")
    assert session_2["headers"] == {}
    assert session_2["cookies"] == {}
    assert session_2["auth"] == {"type": None, "username": None, "password": None}


# Generated at 2022-06-21 14:52:52.536496
# Unit test for constructor of class Session
def test_Session():
    session_name = "mySession1"
    host = "localhost"
    url = "http://localhost:8080"
    assert get_httpie_session(Path(DEFAULT_SESSIONS_DIR), session_name, host, url)

# Generated at 2022-06-21 14:52:55.050566
# Unit test for constructor of class Session
def test_Session():
    print("Test Session Construction")
    path = '/tmp'
    sess = Session(path)
    assert sess.filepath == '/tmp'

# Generated at 2022-06-21 14:52:59.262784
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # initialisation
    session = Session('path')
    session['cookies'] = {'cookie1': {'value': 'cookie1_value', 'path': '/'},
        'cookie2': {'value': 'cookie2_value', 'path': '/'}}
    session.remove_cookies(['cookie1', 'cookie2'])
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:53:09.439053
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Create a session
    session = Session('./mySession.json')
    session.cookies = RequestsCookieJar()
    session.cookies.set_cookie(create_cookie('x', 'valueX'))
    session.cookies.set_cookie(create_cookie('y', 'valueY'))
    session.cookies.set_cookie(create_cookie('z', 'valueZ'))

    assert session['cookies'] == {'x': {'value': 'valueX', 'path': '/'}, 'y': {'value': 'valueY', 'path': '/'}, 'z': {'value': 'valueZ', 'path': '/'}}
    session.remove_cookies(['x'])

# Generated at 2022-06-21 14:53:16.720939
# Unit test for constructor of class Session
def test_Session():
    config_dir = Path(__file__).parent 
    session_name = 'test1'    
    host = 'www.baidu.com'
    url = 'http://www.baidu.com'

    session = Session(config_dir)
    session.update_headers('test1')

 
    assert (get_httpie_session(
    config_dir,
    session_name,
    host,
    url,
) == session)

# Generated at 2022-06-21 14:53:20.336058
# Unit test for constructor of class Session
def test_Session():
    s = Session('session_path')

    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-21 14:53:24.061345
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    my_session = Session("http://httpie.org")
    my_session['cookies'] = {
        'a': 'b',
        'c': 1
    }
    my_session.remove_cookies(['c', 'd'])
    assert my_session['cookies'] == {
        'a': 'b'
    }



# Generated at 2022-06-21 14:53:34.308173
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    session['headers'] = {}
    session['cookies'] = {}

    session.update_headers(RequestHeadersDict({'Cookie': None}))
    assert session['headers'] == {}
    assert session['cookies'] == {}

    session.update_headers(RequestHeadersDict({'Cookie': ''}))
    assert session['headers'] == {}
    assert session['cookies'] == {}

    session.update_headers(RequestHeadersDict({'Cookie': 'hello'}))
    assert session['headers'] == {}
    assert session['cookies'] == {}

    session.update_headers(RequestHeadersDict({'Cookie': 'foo=bar'}))
    assert session['headers'] == {}