

# Generated at 2022-06-21 14:45:06.594384
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as config_dir:
        session = get_httpie_session(
            config_dir,
            session_name="foo",
            host=None,
            url="https://httpbin.org"
        )
        assert Session(config_dir / SESSIONS_DIR_NAME / "httpbin.org" / "foo.json") == session
        assert session == Session(config_dir / SESSIONS_DIR_NAME / "httpbin.org" / "foo.json")

# Generated at 2022-06-21 14:45:10.185079
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'https://httpie.org/docs'
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'test_session', 'httpie.org', url)
    assert session['name'] == 'test_session'
    assert session['url'] == url

# Generated at 2022-06-21 14:45:17.848765
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('.')
    s.update({'cookies': {'name1':{'value':'value1'}, 'name2':{'value':'value2'}}})
    s.remove_cookies(['name2'])
    assert(s == {
        'cookies': {'name1':{'value':'value1'}},
        'auth': {'type': None, 'username': None, 'password': None},
        'headers': {},
        'path': Path('.')
    })

# Generated at 2022-06-21 14:45:27.766008
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    new_headers = {
        'Accept': 'application/json',
        'App-Secret': 'super-secret-key',
        'Cookie': 'token=12345; session=xyz',
        'If-Match': 'e70f8637',
        'User-Agent': 'HTTPie/0.9.9',
    }

    session.update_headers(new_headers)

    assert session.headers == {
        'Accept': 'application/json',
        'App-Secret': 'super-secret-key',
        'User-Agent': 'HTTPie/0.9.9',
    }

    assert session.cookies == {
        'token': {'value': '12345'},
        'session': {'value': 'xyz'}
    }

# Generated at 2022-06-21 14:45:33.554106
# Unit test for function get_httpie_session
def test_get_httpie_session():
    result = get_httpie_session(
        config_dir = "config",
        session_name = "session_name",
        host = "localhost",
        url = "https://www.google.com",
    )
    assert result.path.name == "localhost/session_name.json"
    assert "cookies" in result.keys()
    assert "headers" in result.keys()
    assert "auth" in result.keys()

# Generated at 2022-06-21 14:45:37.199888
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'test_session'
    host = 'localhost'
    url = 'http://' + host + ':8080/default'
    print(get_httpie_session(config_dir, session_name, host, url))

# Generated at 2022-06-21 14:45:42.125760
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config = Session('test.json')
    config['headers'] = {'key1':'value1', 'key2':'value2'}
    
    headers = {'key1': 'value1_1', 'key2': 'value2_1'}
    config.update_headers(headers)
    
    assert config['headers']['key1'] == headers['key1']

# Generated at 2022-06-21 14:45:53.578547
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json
    import unittest

    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager

    class SessionTest(unittest.TestCase):

        def setUp(self):
            self.config_dir = Path()
            self.path = self.config_dir / SESSIONS_DIR_NAME / 'test.json'
            self.session = Session(self.path)
            self.session.load()

        def test_remove_cookies(self):
            self.session['cookies'] = {'test': {'value': 'testvalue'}}
            self.session.remove_cookies(['test'])
            self.assertTrue('test' not in self.session['cookies'])


# Generated at 2022-06-21 14:46:05.152507
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session_name = 'httpie'
    # test for host
    host = 'www.google.com'
    url = None
    config_dir = DEFAULT_SESSIONS_DIR

    test_session = get_httpie_session(config_dir, session_name, host, url)
    assert(test_session.path.as_posix() ==
        '~/.config/httpie/sessions/www_google_com/httpie.json')

    # test for url
    host = None
    url = 'http://www.google.com'

    test_session = get_httpie_session(config_dir, session_name, host, url)
    assert(test_session.path.as_posix() ==
        '~/.config/httpie/sessions/www_google_com/httpie.json')

# Generated at 2022-06-21 14:46:09.582477
# Unit test for constructor of class Session
def test_Session():
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'default', None, "https://httpbin.org/get")
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-21 14:46:20.129607
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # given
    session = Session('session')
    cookies = {
        'a': {'value': 'b'},
        'c': {'value': 'd'},
        'e': {'value': 'f'}
    }
    session.update({'cookies': cookies})

    # when
    session.remove_cookies(['a', 'c'])

    # then
    assert session['cookies'] == {'e': {'value': 'f'}}




# Generated at 2022-06-21 14:46:25.366594
# Unit test for constructor of class Session
def test_Session():
    """
    Test constructor of class Session
    Return True if passed
    """
    test_session = Session('test_session')
    return test_session.about == 'HTTPie session file' and test_session.helpurl == 'https://httpie.org/doc#sessions'



# Generated at 2022-06-21 14:46:34.082426
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('/dev/null')
    headers = [('Authorization', 'Token 1234qwer'),
               ('Accept', 'text/html'),
               ('Cookie', 'name=value; anothername=anothervalue'),
               ('If-Match', '1234'),
               ('If-Modified-Since', 'Thu, 01 Dec 1994 16:00:00 GMT')]
    s.update_headers(RequestHeadersDict(headers))
    assert s.headers == {'Accept': 'text/html'}
    assert s.cookies == {'name': 'value', 'anothername': 'anothervalue'}

# Generated at 2022-06-21 14:46:38.287134
# Unit test for constructor of class Session
def test_Session():
    session = Session('/Users/zz/desktop/httpie/')
    assert session == {'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}


# Generated at 2022-06-21 14:46:46.889433
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    from httpie.config import Config
    from httpie.downloads import get_config_dir
    config_dir = get_config_dir(Config([]))
    session_name, host, url = 'test_get_httpie_session', 'host', 'host.com'
    session = get_httpie_session(config_dir, session_name, host, url)

    assert session.path == (config_dir / SESSIONS_DIR_NAME / host /
                            f'{session_name}.json')

# Generated at 2022-06-21 14:46:54.432293
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.sessions import get_httpie_session
    config_dir = DEFAULT_SESSIONS_DIR
    session_name = 'example.com'
    host = 'example.com'
    url = 'https://example.com/'
    assert get_httpie_session(
        config_dir, session_name, host, url
    ) == Session(path=config_dir / SESSIONS_DIR_NAME / 'example_com' / f'{session_name}.json')


# Generated at 2022-06-21 14:47:01.238015
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from py.path import local
    from httpie.client import DEFAULT_CONFIG_DIR
    base_url = 'http://httpbin.org/'
    url = 'http://httpbin.org/get'
    session_name = 'project_session'
    config_dir = local(DEFAULT_CONFIG_DIR)
    config_dir.ensure(dir=1)
    session_path = config_dir.join(url.split('/', 3)[2] + '.json')
    sessions_path = config_dir.join(SESSIONS_DIR_NAME)
    sessions_path.ensure(dir=1)
    sessions_path.join(session_name + '.json').write('{"test": 1}',
                                                     ensure=True)

# Generated at 2022-06-21 14:47:10.034588
# Unit test for constructor of class Session
def test_Session():
    import os
    import sys
    import tempfile
    temp_dir = tempfile.mkdtemp()
    temp_path = os.path.join(temp_dir,'sessions','test_session.json')
    temp_dir2 = os.path.join(temp_dir,'sessions','test_session2.json')
    session = Session(temp_path)
    assert isinstance(session, BaseConfigDict)
    assert isinstance(session, dict)
    assert session.path.name == 'test_session.json'
    assert session.path.parent.name == 'sessions'
    session['headers'] = [{'type':'test1'},{'type':'test2'}]
    session['cookies'] = [{'name':'test1'},{'name':'test2'}]
    session

# Generated at 2022-06-21 14:47:13.195883
# Unit test for constructor of class Session
def test_Session():
    test_path = Path('/home/allen/.config/httpie/sessions/github.com/github_session.json')
    session = Session(test_path)
    session.load()

# Generated at 2022-06-21 14:47:17.953868
# Unit test for constructor of class Session
def test_Session():
    session = Session('path')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-21 14:47:29.103015
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """Tests that Session.update_headers() updates
    session headers correctly

    """
    session_headers = RequestHeadersDict(Cookie='a=b; c=d',
                                         set_cookie='e=f')
    session = Session('/home/httpie/.config/configdir/sessions/hostname/session_name.json')
    session.update_headers(session_headers)

    assert session.headers['set-cookie'] == []
    assert session['cookies'] == {'a' : {'value': 'b'},
                                  'c' : {'value': 'd'}
                                  }

    assert len(session.headers.items()) == 2
    for (key, value) in session.headers.items():
        assert key == 'cookie' or key == 'set-cookie'

# Generated at 2022-06-21 14:47:34.167484
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(os.devnull)
    session['cookies'] = {'cookie_a': {}, 'cookie_b': {}, 'cookie_c': {}}
    session.remove_cookies(['cookie_a', 'cookie_c'])
    assert session['cookies'] == {'cookie_b': {}}

# Generated at 2022-06-21 14:47:37.823907
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(config_dir= DEFAULT_CONFIG_DIR,
                                 session_name="session_name",
                                 host=None,
                                 url="http://url.com")
    assert isinstance(session, Session)

# Generated at 2022-06-21 14:47:49.366393
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(Path(os.path.expandvars('$HOME')), 'httpie', 'http://foo.com', 'http://foo.com').path == Path(os.path.expandvars('$HOME')) / DEFAULT_SESSIONS_DIR_NAME / 'foo_com/httpie.json'
    assert get_httpie_session(Path(os.path.expandvars('$HOME')), 'httpie', 'http://foo.com', 'http://foo.com').path == Path(os.path.expandvars('$HOME')) / DEFAULT_SESSIONS_DIR_NAME / 'foo_com/httpie.json'

# Generated at 2022-06-21 14:47:56.596621
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('path'))
    session['cookies']['name1'] = {'value': 'val1'}
    session['cookies']['name2'] = {'value': 'val2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'val2'}}



# Generated at 2022-06-21 14:48:02.012836
# Unit test for constructor of class Session
def test_Session():
    session = Session('@test')

    # test value of 'headers'
    assert session.get('headers') == {}

    # test value of 'auth'
    assert session.get('auth') == {
        'type': None,
        'username': None,
        'password': None
    }

    # test value of 'cookies'
    assert session.get('cookies') == {}

# Generated at 2022-06-21 14:48:07.595540
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path

    from httpie.config import Config

    # Setup
    config = Config(config_dir=Path(__file__).parent)

    # Verify
    httpie_session = get_httpie_session(config.config_dir, 'example.com', 'example.com', 'https://example.com')
    assert isinstance(httpie_session, Session)

# Generated at 2022-06-21 14:48:15.932974
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from .credentials import Credentials
    from .config import Config
    config = Config(
            config_dir=DEFAULT_SESSIONS_DIR,
            env={},
            config_file=DEFAULT_SESSIONS_DIR / 'config.json'
    )
    session_name = 'test_session'
    host = 'http://localhost:8080'
    url = 'http://localhost:8080'
    session = get_httpie_session(config.config_dir, session_name, host, url)
    # check if session is saved in the right place
    assert session.path == DEFAULT_SESSIONS_DIR / 'localhost_8080' / 'test_session.json'

# Generated at 2022-06-21 14:48:26.829996
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='')
    # Make sure that headers without a value are ignored.
    session.update_headers(RequestHeadersDict(
        [('HOST', ''), ('HEADER', 'value')]
    ))
    assert session.headers == {'header': 'value'}
    # Make sure that cookie headers are parsed and stored in cookies.
    session.update_headers(RequestHeadersDict([
        ('COOKIE', 'cookie1=value1; cookie2=value2')
    ]))
    assert session.cookies.get_dict() == {
        'cookie1': 'value1',
        'cookie2': 'value2'
    }
    assert 'COOKIE' not in session.headers
    # Make sure that headers with ignored names are not added to session
    # headers.
    session.update

# Generated at 2022-06-21 14:48:34.906252
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import pytest
    from pytest import fixture
    from contextlib import ExitStack as does_not_raise
    from httpie.context import Environment
    from httpie.config import Config
    from tempfile import TemporaryDirectory

    @fixture
    def config(tmp_path):
        p = tmp_path / ".httpie"
        p.mkdir()
        return Config(p)

    def do_test(env: Environment, expected, tmp_path):
        assert get_httpie_session(config_dir=tmp_path.resolve(), session_name=env.session, host=env.host, url=env.url) == expected


# Generated at 2022-06-21 14:48:45.479848
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    header_one = {'Host': 'www.google.com'}
    header_two = {'Accept': 'text/html'}
    session_test = Session('')
    session_test.update_headers(header_one)
    session_test.update_headers(header_two)
    session_test.update_headers({})
    session_test.update_headers({'User-Agent': None})
    session_test.update_headers({'User-Agent': 'httpie'})
    session_test.update_headers({'Content-Length': '10000'})
    session_test.update_headers({'If-Match': 'None'})
    session_test.update_headers({'Cookie': 'test=test'})

# Generated at 2022-06-21 14:48:54.333535
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    assert session.cookies == None
    session.remove_cookies([])
    assert session.cookies == None

    session['cookies'] = {
        'name1': {
            'value': 'value1'
        },
        'name2': {
            'value': 'value2'
        },
        'name3': {
            'value': 'value3'
        }
    }
    session.remove_cookies([])
    assert session['cookies'] == {
        'name1': {
            'value': 'value1'
        },
        'name2': {
            'value': 'value2'
        },
        'name3': {
            'value': 'value3'
        }
    }


# Generated at 2022-06-21 14:49:00.271240
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('dummy')
    request_headers = RequestHeadersDict([('User-Agent', 'dummyagent'), ('Cookie', 'name=dummy')])
    session.update_headers(request_headers)
    assert dict(session.headers) == dict(request_headers)
    assert session['cookies'] == {'name': {'value': 'dummy'}}

# Generated at 2022-06-21 14:49:08.227739
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://bani.com/'
    session_name = 'bani'
    hostname = 'bani.com'
    path =  DEFAULT_SESSIONS_DIR / SESSIONS_DIR_NAME / hostname / f'{session_name}.json'
    #session = Session(str(path))
    #session.load()
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, session_name, hostname, url)
    print(session)

# Generated at 2022-06-21 14:49:11.837419
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        '.',
        'red',
        'https://httpbin.org',
        'https://localhost/red/123'
    )


if __name__ == '__main__':
    test_get_httpie_session()

# Generated at 2022-06-21 14:49:20.407808
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')

    # Test if header with prefix is not added to session
    session['headers'] = {}
    update_dict = {'Content-type': 'text/plain'}
    session.update_headers(update_dict)
    assert session.headers == {}

    # Test if header is added to session
    session['headers'] = {}
    update_dict = {'accept': 'text/plain'}
    session.update_headers(update_dict)
    assert session.headers == update_dict

    # Test if header are added to session
    session['headers'] = {}
    update_dict = {'accept': 'text/plain', 'accept-encoding': 'utf-8'}
    session.update_headers(update_dict)
    assert session.headers == update_dict

    # Test if cookie is added to session

# Generated at 2022-06-21 14:49:26.519740
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b', 'c': 'd', 'e': 'f'}
    assert session['cookies'] == {'a': 'b', 'c': 'd', 'e': 'f'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'e': 'f'}



# Generated at 2022-06-21 14:49:37.863044
# Unit test for constructor of class Session
def test_Session():
    default_sessions_dir=DEFAULT_SESSIONS_DIR
    default_session_name="test_session"
    default_host="https://httpbin.org"
    default_url=default_host + "/get"
    test_session=get_httpie_session(default_sessions_dir,default_session_name,default_host,default_url)
    session_path=test_session._path
    assert session_path.exists()
    session_name=session_path.name
    host_session_dir=session_path.parent
    host_dir=host_session_dir.parent
    assert host_dir.name=="httpbin.org".replace(':', '_')
    sessions_dir=host_dir.parent
    assert sessions_dir.name==SESSIONS_DIR_NAME
    session_

# Generated at 2022-06-21 14:49:46.323809
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("./test_file_path")
    # test it with a valid header
    session.update_headers({"Header1": "Value1", "Header2": "Value2"})
    assert session.headers == {"Header1": "Value1", "Header2": "Value2"}
    # test it with an invalid header (which should not be added to the session)
    session.update_headers({"Content-Length": "Value3"})
    assert session.headers == {"Header1": "Value1", "Header2": "Value2"}



# Generated at 2022-06-21 14:49:46.925167
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-21 14:50:03.782631
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/path/to/session')
    session.update_headers({'h1': 'v1', 'h2': 'v2'})
    assert session['headers'] == {'h1': 'v1', 'h2': 'v2'}

    # Headers with prefixes should not be stored
    session.update_headers({'h1': 'v1', 'h2': 'v2', 'content-type': 'ct'})
    assert session['headers'] == {'h1': 'v1', 'h2': 'v2'}

    # HTTPie specific headers should not be stored
    session.update_headers({'h1': 'v1', 'h2': 'v2', 'user-agent': 'HTTPie/1.0'})

# Generated at 2022-06-21 14:50:09.162742
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("")
    session['cookies'] = {"sessionid": {"value":"123"}}
    assert("sessionid" in session['cookies'])
    session.remove_cookies(["sessionid"])
    assert("sessionid" not in session['cookies'])

# Generated at 2022-06-21 14:50:14.529573
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from os.path import dirname, abspath
    config_dir = dirname(abspath(__file__))
    session_name = 'test.json'
    host = 'google.com'
    url = 'https://google.com'

    session = get_httpie_session(config_dir, session_name, host, url)
    assert session is not None

# Generated at 2022-06-21 14:50:18.866982
# Unit test for constructor of class Session
def test_Session():
    string1 = '{"test":1}'
    path1 = Path('test.json')
    obj_Session = Session(path1)
    obj_Session.update_headers(RequestHeadersDict(string1))
    return obj_Session

# Generated at 2022-06-21 14:50:24.921904
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./test.json')
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Cookie': 'username=admin; path=/',
        'If-None-Match': 'W/"123"',
        'User-Agent': 'HTTPie/0.9.8',
    }
    session.update_headers(headers)
    assert session['headers'] == {}
    assert session['cookies'] == {
        'username': {
            'value': 'admin',
            'path': '/'
        }
    }

# Generated at 2022-06-21 14:50:31.358042
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/config/dir/path')
    session['cookies']['a1'] = 'a1'
    session['cookies']['a2'] = 'a2'
    session['cookies']['a3'] = 'a3'
    session.remove_cookies(['a2'])
    assert list(session['cookies'].keys()) == ['a1', 'a3']

# Generated at 2022-06-21 14:50:43.186165
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test")
    session.update_headers({b'Content-Type': b'application/json'})
    assert session.headers == {}

    session = Session("test")
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}

    session = Session("test")
    session.update_headers({'Host': 'localhost'})
    assert session.headers == {'Host': 'localhost'}

    session = Session("test")
    session.update_headers({'Cookie': 'sid=123'})
    assert session.headers == {}
    assert session.cookies == {'sid': '123'}

    session = Session("test")
    session.update_headers('Accept: */*')
    assert session.headers == {'Accept': '*/*'}

# Generated at 2022-06-21 14:50:53.091736
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = "https://www.example.com"
    session_name = "test_session"
    sessions_dir = DEFAULT_SESSIONS_DIR
    host = 'www.example.com'
    session = get_httpie_session(sessions_dir, session_name, host, url)
    session = Session(sessions_dir / SESSIONS_DIR_NAME / host / f'{session_name}.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-21 14:51:01.979692
# Unit test for constructor of class Session
def test_Session():
    config_dir = Path(__file__).parent / 'data'
    name = 'default'
    host = 'POSTMAN'
    url = 'http://test'
    session = get_httpie_session(config_dir, name, host, url)
    print('call get_httpie_session(config_dir, name, host, url)')
    print('Session. __init__(path = pathlib.Path(path))')
    session.load()
    print('Session.load()')
    assert session
    assert session.headers
    assert session.cookies
    assert session.auth
    request_headers = RequestHeadersDict({'a': 1, 'b': 2})
    session.update_headers(request_headers)
    print('Session.update_headers(request_headers)')
    print('Session.headers')

# Generated at 2022-06-21 14:51:05.424679
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sess = get_httpie_session(DEFAULT_CONFIG_DIR, 'a', 'b', 'c')
    assert sess['headers'] == {}
    assert sess['cookies'] == {}

# Generated at 2022-06-21 14:51:26.810289
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    self = Session("/tmp/test_session.json")
    self['cookies'] = {'a': {}, 'b': {}}
    assert self['cookies'].keys() == {'a', 'b'}
    self.remove_cookies(['a'])
    assert self['cookies'].keys() == {'b'}

# Generated at 2022-06-21 14:51:38.286984
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # test remove cookies from empty jar
    session = Session(Path('test'))
    session['cookies'] = {}
    session.remove_cookies(names=['test'])
    assert session['cookies'] == {}
    # test remove cookies from not empty jar
    session = Session(Path('test'))
    session['cookies'] = {'test': 'test'}
    session.remove_cookies(names=['test'])
    assert session['cookies'] == {}
    # test remove cookies from jar with cookies which have to be not removed
    session = Session(Path('test'))
    session['cookies'] = {'test': 'test', 'other': 'other'}
    session.remove_cookies(names=['test'])
    assert session['cookies'] == {'other': 'other'}

# Generated at 2022-06-21 14:51:42.427845
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/dummy.json')
    assert s['cookies'] == {}
    s['cookies']['foo'] = {'value': 'bar'}
    s.remove_cookies(['foo'])
    assert s['cookies'] == {}

# Generated at 2022-06-21 14:51:50.419155
# Unit test for function get_httpie_session
def test_get_httpie_session():
    '''
    test the get_httpie_session function
    '''

    from httpie.config import DEFAULT_CONFIG_DIR
    from pathlib import Path
    from plot_http_sessions.http_sessions import get_httpie_session

    session_name = 'hack'
    host = 'localhost'
    url = 'http://localhost/'

    session = get_httpie_session(DEFAULT_CONFIG_DIR, session_name, host, url)
    if isinstance(session, Session):
        print("C'est un objet Session")
    else:
        print("Ce n'est pas un objet Session")


if __name__ == "__main__":
    test_get_httpie_session()

# Generated at 2022-06-21 14:51:54.315560
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='asd',
        host=None,
        url='http://www.google.com')

# Generated at 2022-06-21 14:52:06.441346
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    #1
    session = Session(DEFAULT_SESSIONS_DIR / 'localhost_8080/session.json')
    headers = {'Content-Type':'application/json','Accept':'application/json'}
    request_header = {'Content-Type':'application/json','Accept':'application/json'}
    session.update_headers(request_header)
    assert session['headers'] == headers
    #2
    session = Session(DEFAULT_SESSIONS_DIR / 'localhost_8080/session.json')
    headers = {'Accept':'application/json'}
    request_header = {'Accept':'application/json'}
    session.update_headers(request_header)
    assert session['headers'] == headers
    #3

# Generated at 2022-06-21 14:52:11.778092
# Unit test for constructor of class Session
def test_Session():
    test_session = Session('test_session.json')
    assert isinstance(test_session, BaseConfigDict)
    assert isinstance(test_session['headers'], dict)
    assert isinstance(test_session['cookies'], dict)
    assert isinstance(test_session['auth']['type'], type(None))
    assert isinstance(test_session['auth']['username'], type(None))
    assert isinstance(test_session['auth']['password'], type(None))
    # test path
    assert "test_session.json" in str(test_session.path)

# Generated at 2022-06-21 14:52:16.289225
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(DEFAULT_CONFIG_DIR)
    session_name = 'r1'
    host = 'www.google.com'
    url = 'www.google.com'
    get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-21 14:52:22.779716
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # test session header
    session = Session('/tmp')
    session.update_headers(RequestHeadersDict({'Host': 'host', 'Connection': 'connection'}))
    assert session['headers'] == {'Host': 'host', 'Connection': 'connection'}
    # test session cookie
    session = Session('/tmp')
    session.update_headers(RequestHeadersDict({'Cookie': 'key1=value1;key2=value2'}))
    assert session['cookies'] == {'key1': {'value': 'value1'}, 'key2': {'value': 'value2'}}



# Generated at 2022-06-21 14:52:34.174262
# Unit test for function get_httpie_session
def test_get_httpie_session():

    class _:
        ''' A simple class to simulate an object whose attributes are
        Context objects '''

        def __init__(self):
            self.config_dir = DEFAULT_CONFIG_DIR
            self.session = None
            self.auth = None

    class _Context:
        ''' A simple class to simulate a Context object '''

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # test with http as host

# Generated at 2022-06-21 14:53:22.727554
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_dict = {
        'Accept': 'text/html',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': 12,
        'User-Agent': 'HTTPie/0.9.2',
        'Cookie': 'q=test; a=1; b=2; c=3;'
    }
    cookies = {
        'q': {'value': 'test'},
        'a': {'value': '1'},
        'b': {'value': '2'},
        'c': {'value': '3'}
    }
    s = Session(path=None)
    headers = s.headers
    s.update_headers(headers)
    assert s['headers'] == headers
    assert s['cookies'] == {}


# Generated at 2022-06-21 14:53:32.365253
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.context import Environment
    from httpie.cli.context import Context

    env = Environment()
    context = Context(env=env)
    context.config_dir = Path('tests/resources/config_dir')

    session = get_httpie_session(
        config_dir = context.config_dir,
        session_name = 'test',
        host = None,
        url = 'http://httpbin.org/get'
    )
    assert session.get('headers') == {'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate'}
    assert session.get('cookies') == {'test': {'max-age': '-86400', 'path': '/'}}
    assert session.get('auth') == {'username': None, 'password': None, 'type': None}

# Generated at 2022-06-21 14:53:42.937742
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test case-1
    new_dict = {'Content-Type': 'application/json'}
    old_dict = {'Content-Type': 'application/json', 'User-Agent': 'python'}
    expected_output = {'Content-Type': 'application/json'}
    Session._update_headers(new_dict, old_dict)
    assert old_dict == expected_output

    # Test case-2
    new_dict = {'Content-Type': 'application/json', 'User-Agent': 'python'}
    old_dict = {'Content-Type': 'application/json'}
    expected_output = {'Content-Type': 'application/json', 'User-Agent': 'python'}
    Session._update_headers(new_dict, old_dict)
    assert old_dict == expected_output




# Generated at 2022-06-21 14:53:45.933093
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session("http://www.baidu.com")

# Generated at 2022-06-21 14:53:52.027550
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir: Path = Path('/home/user/.config')
    session_name: str = 'mysession'
    host: str = 'www.example.com'
    url: str = 'http://some.url.org/'

    session: Session = get_httpie_session(config_dir, session_name, host, url)
    assert session is not None
    assert session.path == config_dir / 'sessions' / 'www_example_com' / 'mysession.json'
    assert session.headers == {}

# Generated at 2022-06-21 14:53:59.519091
# Unit test for constructor of class Session
def test_Session():
    with pytest.raises(AssertionError):
        s = Session(path='/')
        s.auth = { 'type' : 'type', 'username_invalid' : 'username'}
    s = Session(path='/')
    assert s['auth'] == {'type': None, 'username': None, 'password': None}
    s.auth = { 'type' : 'type', 'username' : 'username'}
    assert s.auth == {'type': 'type', 'username': 'username', 'password': None}
    s.auth = { 'type' : 'type', 'username' : 'username', 'password' : 'password'}
    assert s.auth == {'type': 'type', 'username': 'username', 'password': 'password'}

# Generated at 2022-06-21 14:54:08.843597
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Method remove_cookies of class Session removes cookies with name in names.

    This test was done because this method was not tested and it responds an
    important role in the class.

    """
    s = Session('.')
    s.cookies = RequestsCookieJar()
    s.cookies.set_cookie(create_cookie(
        'name', 'value', domain='domain.com', path='/path'))
    assert 'name' in s['cookies']
    s.remove_cookies(['name'])
    assert 'name' not in s['cookies']
    
    

# Generated at 2022-06-21 14:54:13.491639
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    values = {'A': 1, 'B': 2, 'C': 3,'D':4}
    s = Session(path=Path('.'))
    s['cookies'] = values
    s.remove_cookies(['A', 'B'])
    assert s['cookies'] == {'C': 3, 'D': 4}

# Generated at 2022-06-21 14:54:20.159693
# Unit test for function get_httpie_session
def test_get_httpie_session():
    fname = 'test1.json'
    session = get_httpie_session(config_dir=os.path.expanduser('~/.httpie'), session_name=fname, host=None, url=None)
    assert 'headers' in session # Valid session contains headers
    assert 'cookies' in session # Valid session contains cookies
    assert 'auth' in session # Valid session contains auth

    with pytest.raises(TypeError) as excinfo:
        get_httpie_session(config_dir=os.path.expanduser('~/.httpie'), session_name=fname, host=None)
    with pytest.raises(TypeError) as excinfo:
        get_httpie_session(config_dir=os.path.expanduser('~/.httpie'), session_name=fname)

# Generated at 2022-06-21 14:54:22.387459
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = Session({}).update_headers(
        RequestHeadersDict([("Cookie", "a=1;b=2")])
    )