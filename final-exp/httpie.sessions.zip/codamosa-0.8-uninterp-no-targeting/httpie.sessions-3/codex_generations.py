

# Generated at 2022-06-21 14:45:04.694137
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArg
    headers = RequestHeadersDict()
    headers.appendlist('cookie', 'a=1')
    headers.append('cookie', 'c=3')
    headers.append('Content-Type', 'text/plain')
    headers.append('If-Match', 'foo')
    headers.append('User-Agent', 'HTTPie/0.9.9')
    session = Session(path='./')
    session.update_headers(headers)
    assert session['headers'] == {
        'Content-Type': 'text/plain',
        'If-Match': 'foo',
        'User-Agent': 'HTTPie/0.9.9',
    }
    assert session.cookies == RequestsCookieJar()

# Generated at 2022-06-21 14:45:10.102551
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {'Content-Type': 'application/json',
                'Authorization': 'Basic abcde'}
    session = Session('path')
    session.update_headers(headers)

    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}



# Generated at 2022-06-21 14:45:15.841919
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test/session.json'))
    session.update({
        "cookies" : {
            "Name1": {
                "value": "Value1"
            },
            "Name2": {
                "value": "Value2"
            }
        }
    })
    session.remove_cookies(["Name1"])

# Generated at 2022-06-21 14:45:24.317044
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Test the remove_cookies method of class Session in sessions.py
    """
    dummy_path = '/tmp/httpie/sessions/foo.json'
    my_session = Session(dummy_path)

    # the parameters passed to 'remove_cookies()' method don't exist in
    # the 'cookies' dictionary of the session
    my_session['cookies'] = {'some_cookie_name': {} }
    my_session.remove_cookies(['my_name'])
    assert 'my_name' not in my_session['cookies']

    # the parameters passed to 'remove_cookies()' method do exist in
    # the 'cookies' dictionary of the session
    my_session['cookies'] = {'some_cookie_name': {} }

# Generated at 2022-06-21 14:45:29.039793
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    This method test the update_headers method in Session class.
    """
    from httpie import ExitStatus
    from httpie.cli import parse_items
    from httpie.plugins.registry import plugin_manager
    from httpie.client import CLIClient
    from httpie import __main__

    # get the session
    session = Session("Temp")

    # create a header and add it to the session
    header = ["User-Agent:HTTPie/1.0.3", "Accept:*/*"]
    session.update_headers(RequestHeadersDict(parse_items(header)))

    # test if the header have been successfully stored in session
    assert session.headers == {'Accept': '*/*', 'User-Agent': 'HTTPie/1.0.3'}

# Generated at 2022-06-21 14:45:32.213674
# Unit test for constructor of class Session
def test_Session():
    session = Session('test.json')
    assert session['auth']['type'] == None
    assert session['auth']['username'] == None
    assert session['auth']['password'] == None

# Generated at 2022-06-21 14:45:37.646161
# Unit test for constructor of class Session
def test_Session():
    session_file = Session('./sessions.json')
    assert session_file['headers'] == {}
    assert session_file['cookies'] == {}
    assert session_file['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    session_file['auth'] = {
        'type': 'Basic',
        'username': 'qinshen',
        'password': 'qinshen'
    }


# Generated at 2022-06-21 14:45:42.338386
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names = ['name_1', 'name_2']
    s = Session(path = 'tmp.json')
    s['cookies'] = {'name_1': 'value_1', 'name_2': 'value_2', 'name_3': 'value_3'}
    s.remove_cookies(names)
    assert s['cookies'] == {'name_3': 'value_3'}

# Generated at 2022-06-21 14:45:47.271375
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {'1':'1', '2':'2', '3':'3'}
    session.remove_cookies(('1', '3'))
    assert {'2':'2'} == session['cookies']

# Generated at 2022-06-21 14:45:49.664967
# Unit test for constructor of class Session
def test_Session():
    path = '~/.httpie/sessions'
    session = Session(path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-21 14:45:58.391112
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    session = Session(Path('sessions.json'))
    assert 'headers' in session.keys()
    assert 'cookies' in session.keys()
    assert 'auth' in session.keys()
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth']['type'] == None
    assert session['auth']['username'] == None
    assert session['auth']['password'] == None

# Generated at 2022-06-21 14:46:09.523565
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session = Session('./tests/sessions/test_Session_update_headers')
    session['headers'] = dict()
    session['cookies'] = dict()
    session['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }

    request_headers = {
        'HOST': 'httpbin.org',
        'ACCEPT': '*/*',
        'ACCEPT-ENCODING': 'gzip, deflate',
        'COOKIE': 'theme=dark; sessionToken=abc123',
        'cache-control': 'no-cache'
    }

# Generated at 2022-06-21 14:46:16.660887
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sessions = get_httpie_session("/tmp", "foo", "bar", "baz")
    assert sessions.keys() == {
        "headers",
        "cookies",
        "auth"
    }
    assert sessions['headers'] == {}
    assert sessions['cookies'] == {}
    assert sessions['auth'] == {
        "type": None,
        "username": None,
        "password": None
    }

# Generated at 2022-06-21 14:46:23.905714
# Unit test for constructor of class Session
def test_Session():
    # Test cases
    path = "testpath"
    # Run tests
    assert Session(path)
    # Test if path is set to the value of parameter
    assert Session(path).path == path
    # Test if headers field is setted
    assert Session(path)["headers"] != ""
    # Test if cookies field is setted
    assert Session(path)["cookies"] != ""
    # Test if auth field is setted
    assert Session(path)["auth"] != ""
    # Test if the default value of auth field is setted
    assert Session(path)["auth"]["type"] == None


# Generated at 2022-06-21 14:46:31.362676
# Unit test for constructor of class Session
def test_Session():
    path = './session.json'
    session = Session(path)
    # print(session)
    # print(session.helpurl)
    # print(session.about)
    # print(session.headers)
    # print(session.cookies)
    # print(session.auth)
    # session.auth = {'type': 'basic', 'raw_auth': 'anonymous:test'}
    # print(session.auth)


# Generated at 2022-06-21 14:46:34.967418
# Unit test for constructor of class Session
def test_Session():
    session=Session('')
    assert session['headers']=={}
    assert session['cookies']=={}
    assert session['auth']=={'type':None,'username':None,'password':None}


# Generated at 2022-06-21 14:46:42.982783
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://httpbin.org/get'
    session_name = 'test_get_httpie_session'
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, session_name, host=None, url=url)
    assert type(session) == Session
    assert session._path == Path('/Users/dongsl/.config/httpie/sessions/httpbin.org_80/test_get_httpie_session.json')
    assert type(session.path) == Path

# Generated at 2022-06-21 14:46:51.839924
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('path/to/session.json')
    s.cookies = RequestsCookieJar()
    s.cookies.set_cookie(create_cookie('name1', 'value1'))
    s.cookies.set_cookie(create_cookie('name2', 'value2'))
    s.remove_cookies(['name2'])
    assert len(s['cookies']) == 1
    assert s['cookies'].get('name1', None)
    assert not s['cookies'].get('name2', None)

# Generated at 2022-06-21 14:46:56.003541
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('test')
    s.update_headers({'H1': 'V1', 'Cookie': 'A=B'})
    assert s['headers'] == {'H1': 'V1'}
    assert s['cookies'] == {'A': {'value': 'B'}}

# Generated at 2022-06-21 14:47:01.106971
# Unit test for constructor of class Session
def test_Session():
    session = Session('sessions/session.json')
    path = Path('sessions/session.json')
    assert session.path == path
    assert session['headers'] == {}
    assert session['cookies'] == {}
    auth = {'type': None, 'username': None, 'password': None}
    assert session['auth'] == auth
    return session


# Generated at 2022-06-21 14:47:11.663685
# Unit test for function get_httpie_session
def test_get_httpie_session():
    path = Path('testdata/sessions/test.json')
    session = Session(path)
    session.load()
    result = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', None, None)
    assert result.headers == session.headers
    assert result.cookies == session.cookies
    assert result.auth == session.auth


# Generated at 2022-06-21 14:47:18.793718
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s['cookies']={'name1': {'value': '123'}, 'name2': {'value':'456'}}
    assert s['cookies']=={'name1': {'value': '123'}, 'name2': {'value':'456'}}
    s.remove_cookies(['name2'])
    assert s['cookies']=={'name1': {'value': '123'}}


# Generated at 2022-06-21 14:47:19.407511
# Unit test for constructor of class Session
def test_Session():
    pass

# Generated at 2022-06-21 14:47:23.322314
# Unit test for constructor of class Session
def test_Session():
    session = Session("session_files/cacert.pem")
    session.load()
    assert session['cookies'] == {'session': 1, 'foo': 2}
    assert session['headers'] == {'test': 1, 'foo': "bar"}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-21 14:47:27.715315
# Unit test for constructor of class Session
def test_Session():
    session = Session("test.json")
    assert session["headers"] == {}
    assert session["cookies"] == {}
    assert session["auth"] == {
        'type': None,
        'username': None,
        'password': None
    }
    assert session.path == "test.json"
    assert session.helpurl == 'https://httpie.org/doc#sessions'
    assert session.about == 'HTTPie session file'



# Generated at 2022-06-21 14:47:32.625717
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class RequestHeadersDict(dict):
        def items(self):
            return [(b'Cookie', 'name=value')]

    session = Session('path')
    session.update_headers(RequestHeadersDict())
    assert session['cookies']['name']['value'] == 'value'

# Generated at 2022-06-21 14:47:38.475567
# Unit test for constructor of class Session
def test_Session():
    session = Session("example.json")
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}
    assert session.helpurl == 'https://httpie.org/doc#sessions'
    assert session.about == 'HTTPie session file'



# Generated at 2022-06-21 14:47:43.942138
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from requests.cookies import RequestsCookieJar
    from httpie.sessions import Session
    session = Session('test')
    cookie_jar = RequestsCookieJar()
    session.cookies = cookie_jar
    session.remove_cookies(['foo', 'bar'])
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:47:50.468697
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')

    # type str
    request_headers = RequestHeadersDict({
        'dummy': 'a',
        'Cookie': 'a=b; c=d;',
        'If-None-Match': '*'
    })

    # type bytes(utf-8)
    request_headers1 = RequestHeadersDict({
        'dummy': b'a',
        'cookie': b'a=b; c=d;',
        'If-None-Match': '*'
    })

    # type bytes(ascii)
    request_headers2 = RequestHeadersDict({
        'dummy': b'123',
        'cookie': b'a=b; c=d;',
        'If-None-Match': '*'
    })

    # type bytes(unic

# Generated at 2022-06-21 14:47:55.479495
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('fixtures/new.json')
    session.load()
    assert len(session['cookies'].keys()) == 2
    session.remove_cookies(['bar', 'baz'])
    assert len(session['cookies'].keys()) == 0

# Generated at 2022-06-21 14:48:02.818641
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('~/.config').expanduser()
    session = get_httpie_session(config_dir, 'test', 'localhost', 'http://localhost/test')
    assert isinstance(session, Session)
    assert session.headers == {}

# Generated at 2022-06-21 14:48:08.657642
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(Path.cwd() / "sessions" / "test_session"))
    session['cookies'] = {'cookie': {'value': '1'}}
    assert {'cookie': {'value': '1'}} == session['cookies']
    session.remove_cookies(names=['cookie'])
    assert {} == session['cookies']

# Generated at 2022-06-21 14:48:10.691284
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='test',
        host='cli',
        url='http://localhost/')
    assert isinstance(session, Session)

# Generated at 2022-06-21 14:48:15.236605
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/home/user/.config')
    session_name = 'session_name'
    host = 'localhost'
    url = 'http://localhost'
    session_path = config_dir / SESSIONS_DIR_NAME / host / (session_name + '.json')
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.path == session_path

# Generated at 2022-06-21 14:48:19.540356
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session.update({'cookies':{'foo':'bar'}})
    assert session['cookies'] == {'foo':'bar'}
    session.remove_cookies(['foo'])
    assert session['cookies'] == {}


# Generated at 2022-06-21 14:48:28.435297
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # create a fresh session
    session = Session('fresh')
    session['cookies'] = {
        'dog': {'value': 'woof'},
        'cat': {'value': 'miau'},
        'cow': {'value': 'moo'},
    }
    assert session['cookies'] == {
        'dog': {'value': 'woof'},
        'cat': {'value': 'miau'},
        'cow': {'value': 'moo'},
    }
    # remove some cookies
    session.remove_cookies(['cat', 'cow'])
    assert session['cookies'] == {
        'dog': {'value': 'woof'},
    }

# Generated at 2022-06-21 14:48:35.964809
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {
        'Content-Type': 'application/json',
        'Content-Length': '1',
        'User-Agent': 'HTTPie/0.9.9',
        'If-Modified-Since': 'Sat, 29 Oct 1994 19:43:31 GMT',
        'If-None-Match': 'e06c450f22d7596a7c77e1c1b8b6a52f',
        'Cookie': 'user=john; language=en-US;'
    }
    session = Session(':memory:')

    session.update_headers(request_headers)

    assert session['headers'] == {'user-agent': 'HTTPie/0.9.9'}

# Generated at 2022-06-21 14:48:46.635038
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_headers = RequestHeadersDict()
    request_headers = RequestHeadersDict()
    request_headers['Accept'] = 'application/json'
    session = Session('test_session_path')
    session.update_headers(request_headers)
    assert session.headers['Accept'] == 'application/json'
    request_headers['Accept'] = 'application/json2'
    session.update_headers(request_headers)
    assert session.headers['Accept'] == 'application/json2'
    request_headers['Accept'] = None
    session.update_headers(request_headers)
    assert 'Accept' not in session.headers
    request_headers['User-Agent'] = 'HTTPie/0.9.9'
    session.update_headers(request_headers)
    assert 'User-Agent' not in session.headers


# Generated at 2022-06-21 14:48:54.833148
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    _auth_password_mgr = [None]

    class FakeAuth(AuthBase):
        def __init__(self):
            self.auth = {
                'type': None,
                'username': None,
                'password': None
            }

        def get_auth(self, username, password):
            self.auth['username'] = username
            self.auth['password'] = password
            _auth_password_mgr[0] = self.auth
            return self

    session = Session('fake_session')

# Generated at 2022-06-21 14:48:59.118844
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path="session")
    request_headers = RequestHeadersDict({'key':'value'})
    session.update_headers(request_headers)
    assert session.headers['key'] == 'value'


# Generated at 2022-06-21 14:49:09.347867
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('""')
    session['headers'] = {'key1':'value1','key3':'value3'}
    request_headers = {'key1':'value1','key2':'value2','Content-Length':None}

    session.update_headers(request_headers)

    assert session['headers'] == {'key1':'value1','key2':'value2'}


# Generated at 2022-06-21 14:49:18.239660
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    class Session:
        def __init__(self):
            self.cookies = {'cookie1': {'value': 'value1'},
                            'cookie2': {'value': 'value2'},
                            'cookie3': {'value': 'value3'}}

        # Delete cookies with names 'cookie1' and 'cookie3'
        def remove_cookies(self, names):
            for name in names:
                if name in self.cookies:
                    del self.cookies[name]

    session = Session()
    session.remove_cookies(['cookie1', 'cookie3'])
    assert len(session.cookies) == 1
    assert session.cookies['cookie2']['value'] == 'value2'

# Generated at 2022-06-21 14:49:21.824460
# Unit test for constructor of class Session
def test_Session():
    res = Session('new')
    assert res['cookies'] == {}
    assert res['headers'] == {}
    assert res['auth'] == {'type': None, 'username': None, 'password': None}



# Generated at 2022-06-21 14:49:30.866514
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', '127.0.0.1', 'http://127.0.0.1/index')
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', '127.0.0.1', 'http://127.0.0.1:9000/index')
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', '127.0.0.1', 'http://127.0.0.1:9000:9000/index')
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', '127.0.0.1', 'http://127.0.0.1:9000:9000:9000/index')
    assert get_http

# Generated at 2022-06-21 14:49:38.371997
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Create a testing directory
    test_dir = os.path.join(os.environ['HOME'], '.config', 'httpie')
    os.makedirs(test_dir, mode=0o755)

    # Create a test session file
    test_session_file = os.path.join(test_dir, SESSIONS_DIR_NAME, 'localhost', 'test.json')
    with open(test_session_file, "w") as f:
        f.write('{"auth": {"type": "basic", "raw_auth": "testuser:testpass", "username": "testuser", "password": "testpass"}, "cookies": {}, "headers": {"User-Agent": "HTTPie/1.0.3"},"version": 1}\n')

    # Validate

# Generated at 2022-06-21 14:49:42.942104
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
  session = Session("dummy")
  session['cookies'] = { 'a' : 1, 'b' : 2, 'c' : 3, }
  session.remove_cookies(['b', 'd'])
  assert session['cookies'] == { 'a' : 1, 'c' : 3, }



# Generated at 2022-06-21 14:49:44.753570
# Unit test for constructor of class Session
def test_Session():
    session = Session(path=Path('config_dir'))
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-21 14:49:55.765660
# Unit test for constructor of class Session
def test_Session():
    import json
    import requests
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.config import BaseConfigDict
    from httpie.plugins.registry import plugin_manager

    dict={"a":"b"}
    session = Session(dict)
    assert session==dict
    assert session.path==Path(dict)
    assert isinstance(session,BaseConfigDict)

    session = Session("a/b")
    assert session.load()=={}
    assert session.headers==RequestHeadersDict({})
    assert session.cookies==RequestsCookieJar()
    assert session.auth==None
    assert session.get("auth")==None

    session["headers"]["a"]="b"
    assert session.headers==RequestHeadersDict({"a":"b"})


# Generated at 2022-06-21 14:49:59.663475
# Unit test for constructor of class Session
def test_Session():
    #obj = Session(os.path.join('C:\\', 'Users', 'Cristian', '.httpie', 'sessions'))
    obj = Session(os.path.join('C:\\', 'Users', 'Cristian', '.httpie', 'sessions', 'session.json'))
    assert obj is not None

# Generated at 2022-06-21 14:50:02.890165
# Unit test for constructor of class Session
def test_Session():
    session = Session('/home/httpie/sessions/')
    assert session.headers == {}
    assert session.cookies == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-21 14:50:11.711176
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-21 14:50:18.629058
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='.')
    session.load()

    request_headers = RequestHeadersDict()
    request_headers['X-MyHeader'] = 'foo'
    request_headers['Cookie'] = 'SID=foo'
    session.update_headers(request_headers)

    assert 'X-MyHeader' in session['headers']
    assert 'Cookie' not in session['headers']

# Generated at 2022-06-21 14:50:22.775607
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-21 14:50:26.452306
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("test.json")
    s['cookies'] = {"test": {"value": "test1"}, "test1": {"value": "test2"}}
    s.remove_cookies(["test"])
    assert (s['cookies']) == {"test1": {"value": "test2"}}



# Generated at 2022-06-21 14:50:33.161735
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("my_session.json")
    session['cookies'] = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3'
    }
    session.remove_cookies(['key1', 'key2'])
    assert session['cookies'] == {'key3': 'value3'}

# Generated at 2022-06-21 14:50:44.384643
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from urllib.parse import urlsplit
    from requests.auth import _basic_auth_str
    from requests.cookies import RequestsCookieJar
    from requests.cookies import create_cookie

    s = Session(Path('/tmp/abc.json'))
    s['headers'] = {}
    s['cookies'] = {}
    assert s['cookies'] == {}
    s['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }
    assert s['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-21 14:50:56.634111
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    session.update_headers({
        'Accept': 'application/json',
        'Accept-Language': 'en,zh;q=0.9',
        'Cookie': '_ga=GA1.2.1782862901.1525591513; _gid=GA1.2.886796133.1526805500',
        'If-None-Match': 'W/"1436f-M9mLfEZC2LE183Qo7Por3bq3rq0"',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36'
    })

# Generated at 2022-06-21 14:51:02.968694
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_file = os.path.dirname(os.path.realpath(__file__)) + '/sample-session.json'
    session = Session(session_file)
    session.load()
    assert 'cookie1' in session['cookies']
    assert 'cookie2' in session['cookies']
    assert 'cookie3' in session['cookies']
    assert 'cookie4' in session['cookies']

    session.remove_cookies(['cookie2', 'cookie3'])
    assert 'cookie1' in session['cookies']
    assert 'cookie2' not in session['cookies']
    assert 'cookie3' not in session['cookies']
    assert 'cookie4' in session['cookies']

# Generated at 2022-06-21 14:51:08.980982
# Unit test for constructor of class Session
def test_Session():
    session = Session(path = '~/.config/httpie/sessions/localhost/tester.json')
    assert session == {
        'headers': {},
        'cookies': {},
        'auth': {
            'type': None,
            'username': None,
            'password': None
        }
    }
    print('test_Session finished.')


# Generated at 2022-06-21 14:51:13.913666
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import httpie.config

    config_dir = httpie.config.DEFAULT_CONFIG_DIR
    session_name = 'test'
    host = 'httpbin.org'
    url = 'httpbin.org/get'

    path = get_httpie_session(config_dir, session_name, host, url).path
    assert path.name == 'test.json'
    assert path.parent.name == 'httpbin_org'

# Generated at 2022-06-21 14:51:39.602657
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Case1: header element is str
    session = Session('./test1')
    session.headers['name'] = 'ssss'
    request_headers = RequestHeadersDict()
    request_headers['name'] = 'bbbb'
    session.update_headers(request_headers)
    assert session.headers['name'] == 'bbbb'
    # Case2: header element is bytes
    session = Session('./test2')
    session.headers['name'] = 'ssss'
    request_headers = RequestHeadersDict()
    request_headers['name'] = b'bbbb'
    session.update_headers(request_headers)
    assert session.headers['name'] == 'bbbb'

# Generated at 2022-06-21 14:51:46.486084
# Unit test for constructor of class Session
def test_Session():
    # file exist
    path=DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'localhost' / f'{session_name}.json'
    session = Session(path, session_name)
    assert session.load() is True

    # file not exist
    path=DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'localhost' / f'{session_name}.json'
    session = Session(path, session_name)
    assert session.load() is False

# Generated at 2022-06-21 14:51:55.093214
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    headers = {}
    session.update_headers(headers)
    assert session.headers == {}
    assert session.cookies == RequestsCookieJar()

    headers = {'Set-Cookie': 'a=1; Path=/acc/'}
    session.update_headers(headers)
    assert session.headers == {}
    assert session.cookies == RequestsCookieJar()
    for cookie in session.cookies:
        if cookie.name == 'a':
            assert cookie.path == '/acc/'

# Generated at 2022-06-21 14:52:07.219602
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session = {}

    headers_dict = {
        'User-Agent': 'HTTPie/0.3.3-zx',
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate, identity',
        'Content-Type': 'application/json',
        'Content-Length': '167',
        'Host': 'httpbin.org',
        'Connection': 'keep-alive',
        'Cookie': '_gauges_unique_hour=1; _gauges_unique_day=1; _gauges_unique_month=1; _gauges_unique_year=1; _gauges_unique=1'
    }

    Session.update_headers(session, headers_dict)


# Generated at 2022-06-21 14:52:13.016958
# Unit test for constructor of class Session
def test_Session():
    path = Path('/test/test_json')
    session = Session(path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-21 14:52:16.465051
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("./test/sessions/test.json")
    session['cookies'] = {"session": {'value': '123'}}
    session.remove_cookies(['session'])
    assert 'session' not in session['cookies']

# Generated at 2022-06-21 14:52:19.704678
# Unit test for constructor of class Session
def test_Session():
    path = Path(".")
    session = Session(path)
    assert session["headers"] == {}
    assert session["cookies"] == {}
    session["auth"] = {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-21 14:52:30.411006
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(Path(os.path.expanduser('~/.config')),'test','','http://www.example.com')
    assert session['headers'] == {} and session['cookies'] == {} and session['auth'] == {'type':None,'username':None,'password':None}
    session = get_httpie_session(Path(os.path.expanduser('~/.config')),os.path.expanduser('~/.config/sessions/www.example.com/test.json'),'','http://www.example.com')
    assert session['headers'] == {} and session['cookies'] == {} and session['auth'] == {'type':None,'username':None,'password':None}

# Generated at 2022-06-21 14:52:41.701968
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookiejar = RequestsCookieJar()
    cookiejar.set_cookie(create_cookie('cookie1', 'value1', domain='test1.com'))
    cookiejar.set_cookie(create_cookie('cookie2', 'value2', domain='test1.com'))

    session = Session(path=Path("./temp.json"))
    session['cookies'] = cookiejar

    # remove cookie1
    session.remove_cookies(['cookie1'])
    assert session['cookies']['cookie1'] == None
    assert session['cookies']['cookie2'] != None
    # remove cookie2
    session.remove_cookies(['cookie2'])
    assert session['cookies']['cookie1'] == None
    assert session['cookies']['cookie2'] == None

# Generated at 2022-06-21 14:52:48.583142
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("abc")
    session.update_headers({"hello":"123","world":"456"})
    assert session.headers == {"hello":"123","world":"456"}
    session.update_headers({"h1":"1","h2":"2","h3":"3"})
    assert session.headers == {"hello":"123","world":"456","h1":"1","h2":"2","h3":"3"}

# Generated at 2022-06-21 14:53:26.350559
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'test'
    host = 'httpbin.org'
    url = 'https://httpbin.org/'

    session = get_httpie_session(config_dir, session_name, host, url)
    print(os.listdir(DEFAULT_CONFIG_DIR))
    print(session.path)
    print(session)

if __name__ == '__main__':
    test_get_httpie_session()

# Generated at 2022-06-21 14:53:28.403312
# Unit test for constructor of class Session
def test_Session():
    session = Session(path="D:\study\pythontest\httpie\sessions.json")
    print(session)

# Generated at 2022-06-21 14:53:32.445966
# Unit test for constructor of class Session
def test_Session():
    session = Session('/path/to/session')
    assert session.get('headers') == {}
    assert session.get('cookies') == {}
    assert session.get('auth') == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-21 14:53:41.875247
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.plugins import builtin
    from httpie.output.streams import STDOUT

    config_dir = DEFAULT_SESSIONS_DIR 
    host = 'localhost'
    url = 'http://localhost/cgi-bin/test'
    session_name = 'default'

    session = get_httpie_session(config_dir, session_name, host, url)
    session['headers']['Content-Type'] = 'application/json'
    session.save()

    session1 = get_httpie_session(config_dir, session_name, host, url)
    assert session1['headers']['Content-Type'] == 'application/json'

# Generated at 2022-06-21 14:53:46.464147
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test")
    fake_request_headers = {"hoge": "foobar"}
    session.update_headers(fake_request_headers)

    assert session["headers"] == {"hoge": "foobar"}

# Generated at 2022-06-21 14:53:52.522451
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """
    >>> ses = get_httpie_session(Path('~/.httpie/sessions'), 'foo', '', 'https://example.org')
    >>> ses.path
    PosixPath('/home/user/.httpie/sessions/example_org/foo.json')
    >>> ses = get_httpie_session(Path('~/.httpie/sessions'), 'foo/bar', '', 'https://example.org')
    >>> ses.path
    PosixPath('/home/user/foo/bar')
    """

# Generated at 2022-06-21 14:53:59.792966
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from requests.cookies import RequestsCookieJar
    from httpie.plugins import AuthPlugin

    class DummyAuthPlugin(AuthPlugin):
        name = 'dummy'

        def get_auth(self, username=None, password=None):
            return 'auth_obj'

    plugin_manager.register(DummyAuthPlugin)

    sess = get_httpie_session(DEFAULT_SESSIONS_DIR, 'session1', 'localhost', 'http://localhost')

    # TODO: The assert is really weak
    assert sess is not None

    # TODO: The assert is really weak
    assert sess['headers'] == {}

    # TODO: The assert is really weak
    assert sess['cookies'] == {}

    assert sess['auth']['type'] == None

# Generated at 2022-06-21 14:54:05.811228
# Unit test for constructor of class Session
def test_Session():
    session_file = (
        '{"headers": {}, "cookies": {"cookie_name": {"value": "cookie_value"}}}'
    )
    session = Session(session_file)
    assert session.headers == {}
    assert session.cookies == {"cookie_name": "cookie_value"}
    assert session.auth == None


# Generated at 2022-06-21 14:54:15.501855
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    from httpie.core import main_method
    from httpie.plugins import builtin
    from httpie.plugins import session

    plugin_manager.remove_plugin_instances(plugin_manager.get_plugins())
    from httpie.plugins.registry import plugin_manager
    # This makes the session plugin loaded first which is needed to set the
    # `save_auth' argument when running the session-related tests without
    # actually using HTTPie.
    plugin_manager.load_builtin_plugins()
    # load_builtin_plugins() overwrites the session.save_auth values
    plugin_manager.get_plugin_instances(
        [builtin.AuthPlugin, builtin.SessionPlugin]
    )[0].load_parser_arguments()
    plugin_manager.get_plugin_instances

# Generated at 2022-06-21 14:54:26.562228
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers({'foo': 'bar'})
    assert session['headers'] == {'foo': 'bar'}
    session.update_headers({'bar': 'foo'})
    assert session['headers'] == {'foo': 'bar', 'bar': 'foo'}
    session.update_headers({'Baz': 'qutx'})
    assert session['headers'] == {'foo': 'bar', 'bar': 'foo', 'Baz': 'qutx'}
    session.update_headers({'Content-Type': 'application/json'})
    assert 'Content-Type' not in session['headers']
    session.update_headers({'If-Modified-Since': '1 Jan 2020'})
    assert 'If-Modified-Since' not in session['headers']
    session