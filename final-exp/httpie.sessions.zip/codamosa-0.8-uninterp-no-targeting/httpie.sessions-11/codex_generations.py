

# Generated at 2022-06-21 14:45:12.481813
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names = ['cn']
    auth = {'type':'basic'}
    path = 'settings.json'
    session = Session(path)
    session['auth'] = auth
    cookie = create_cookie('cn', 'test')
    cookie_jar = RequestsCookieJar()
    cookie_jar.set_cookie(cookie)
    session.cookies = cookie_jar
    assert session['cookies'] == {'cn':{'value': 'test'}}, 'Test failed!'
    session.remove_cookies(names)
    assert not session['cookies'], 'Test failed!'



# Generated at 2022-06-21 14:45:22.107419
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import pytest
    session = Session(path='test')
    from httpie.cli.dicts import RequestHeadersDict
    session.update_headers(RequestHeadersDict({'name': 'value'}))
    assert session.headers['name'] == 'value'
    session.update_headers(RequestHeadersDict({'If-match': 'abcd'}))
    assert 'If-match' not in session.headers
    session.update_headers(RequestHeadersDict({'If-match': 'abcd'}))
    assert 'If-match' not in session.headers
    session.update_headers(RequestHeadersDict({'name': 'value2'}))
    assert session.headers['name'] == 'value2'
    session.update_headers(RequestHeadersDict({'name': None}))


# Generated at 2022-06-21 14:45:30.900361
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    session.update_headers({
        'Accept': '*/*',
        'Content-Type': 'application/json',
        'User-Agent': 'HTTPie/0.11.0',
        'If-None-Match': '"12345"',
        'Cookie': 'id_token=12345.67890; Path=/; Domain=abcd.com',
        'Authorization': 'Bearer 12345.67890',
        'Cache-Control': None
    })
    assert session.headers.keys() == {
        'Accept',
        'Content-Type',
        'Authorization',
        'Cache-Control',
    }
    assert session['cookies'].keys() == {
        'id_token',
    }

# Generated at 2022-06-21 14:45:34.684385
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test.json")
    session['cookies'] = {'a': 0, 'b': 1, 'c': 2}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 2}



# Generated at 2022-06-21 14:45:42.839195
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(os.devnull)
    session.remove_cookies({'name_2'})
    assert len(session['cookies'])==0
    session['cookies']={'name_1':'', 'name_2':'', 'name_3':'', 'name_4':''}
    session.remove_cookies({'name_1','name_3'})
    assert len(session['cookies'])==2
    assert session['cookies']['name_2']==''
    assert session['cookies']['name_4']==''

# Generated at 2022-06-21 14:45:53.995230
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Test that updating session headers works as expected:
    - session headers are updated with non-ignored headers from
      new request headers
    - request headers are ignored if they are explicitly unset
    - session headers are not updated with ignored headers from
      new request headers
    """

    class DummySession(Session):
        """A session for unit test."""

        def load(self):
            """Do nothing instead of loading."""

        def save(self):
            """Do nothing instead of saving."""

    orig_headers = {
        'header1-name': 'header1-value',
        'if-header-name': 'if-header-value',
        'content-header-name': 'content-header-value',
        'non-ignored-header-name': 'non-ignored-header-value'
    }
    session

# Generated at 2022-06-21 14:46:00.359244
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path('test.json'))
    session.update_headers({'Cookie': 'a=a; b=b; c=c'})
    session.remove_cookies(['a'])

# Generated at 2022-06-21 14:46:07.507403
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.client import Session as ClientSession
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.streams import BytesOutputStream

    class MockClientSession(ClientSession):
        def __init__(self, **kwargs):
            self._kwargs = kwargs


    def get_request(**kwargs):
        response = MockClientResponse(url=url)
        return MockRequest(response=response, **kwargs)

    class MockClientResponse(object):
        def __init__(self, **kwargs):
            self._kwargs = kwargs

        @property
        def request(self):
            return get_request(**self._kwargs)

    class MockRequest(object):
        def __init__(self, **kwargs):
            self._kwargs = kwargs
            self

# Generated at 2022-06-21 14:46:10.658714
# Unit test for constructor of class Session
def test_Session():
    ses = Session(path="test/test.json")
    ses.update_headers({"test":1, "test1":2})
    ses.cookies = ""
    ses.remove_cookies(["test", "test1"])
    ses.auth = ""


# Generated at 2022-06-21 14:46:21.081686
# Unit test for function get_httpie_session

# Generated at 2022-06-21 14:46:34.216942
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('~/.httpie/sessions/session_name.json')
    s['cookies'] = {'name1': {'value': '1', 'path': '/'}}
    s.remove_cookies(['name1', 'name2'])
    assert s['cookies'] == {}


# Generated at 2022-06-21 14:46:43.074662
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/path/to/sessions/localhost/session2.json')
    request_headers = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    session.update_headers(request_headers)

    assert 'key1' in session['headers']
    assert 'key2' in session['headers']
    assert 'key3' in session['headers']
    assert 'key1' in session['headers']
    assert 'key2' in session['headers']
    assert 'key3' in session['headers']



# Generated at 2022-06-21 14:46:47.478604
# Unit test for function get_httpie_session
def test_get_httpie_session():
    try:
        session = get_httpie_session(Path.cwd()/'test', 'session_httpie', host=None, url='http://www.google.com')
    except:
        raise Exception('get_httpie_session function failed')

# Generated at 2022-06-21 14:46:50.944728
# Unit test for constructor of class Session
def test_Session():
    path = "C:\\test_dir\\test_dir_1\\test.txt"
    session = Session(path)
    print(session)

# Generated at 2022-06-21 14:46:54.061194
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('s.json')
    s['cookies'] = {'cookie_name': 'cookie_value'}
    s.remove_cookies(['cookie_name'])
    assert s['cookies'] == {}

# Generated at 2022-06-21 14:47:04.808101
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict([
        ('Content-Type', 'application/json'),
        ('Cookie', 'name=value'),
        ('If-Match', '123456789')
    ])
    session_headers = {
        'Accept': 'text/html'
    }
    session = Session('test/test.json')
    session['headers'] = session_headers
    Session.update_headers(session, request_headers)
    expected_headers = {
        'Accept': 'text/html'
    }
    expected_cookies = {
        'name': {
            'value': 'value'
        }
    }
    assert session['headers'] == expected_headers
    assert session['cookies'] == expected_cookies
    assert request_headers == {'If-Match': '123456789'}

# Generated at 2022-06-21 14:47:17.494663
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("")
    s.cookies = RequestsCookieJar()
    s.cookies.set("name1", "value1")
    s.cookies.set("name2", "value2")
    s.cookies.set("name3", "value3")
    s.cookies.set("name4", "value4")
    assert s.cookies.get("name1").value == "value1"
    assert s.cookies.get("name2").value == "value2"
    assert s.cookies.get("name3").value == "value3"
    assert s.cookies.get("name4").value == "value4"
    assert len(s.cookies) == 4
    s.remove_cookies(["name1", "name3"])
    assert len(s.cookies)

# Generated at 2022-06-21 14:47:19.960672
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'Name': {'value': 'Value'}}
    session = Session(path=None)
    session['cookies'] = cookies
    session.remove_cookies(['Name'])
    assert session['cookies'] == {}



# Generated at 2022-06-21 14:47:27.903151
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    def test(path: Optional[str], headers: dict, expected: dict):
        session = Session(path)
        session.load()
        session.update_headers(headers)
        assert session['headers'] == expected
        session.clear()

    # test updating headers of an empty session with valid headers
    test(
        None,
        headers={
            'Header': 'Value',
            'Header-2': 'Value 2',
            'Content-Type': 'application/json',
            'Cookie': 'Cookie1=Value1; Cookie2=Value2'
        },
        expected={
            'Header': 'Value',
            'Header-2': 'Value 2',
        }
    )
    # test updating headers of a session with valid headers

# Generated at 2022-06-21 14:47:39.840479
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import unittest
    import os
    import tempfile
    this_folder = os.path.dirname(os.path.abspath(__file__))
    test_folder = tempfile.mkdtemp()
    print("test_folder:%s" % test_folder) #
    os.chdir(test_folder)
    shutil.copyfile(this_folder + '/config/httpie/config.json', test_folder + '/config/httpie/config.json')
    shutil.copyfile(this_folder + '/config/httpie/sessions/localhost/test.json', test_folder + '/config/httpie/sessions/localhost/test.json')
    import httpie.config
    httpie.config.load_config()
    from httpie.config import path as config_dir

# Generated at 2022-06-21 14:47:51.429785
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Arrange
    url = 'http://example.com/this?is=nice'
    config_dir = Path(__file__).parent
    session_name = 'test'

    # Act
    actual = get_httpie_session(config_dir, session_name, None, url)

    # Assert

# Generated at 2022-06-21 14:48:01.897856
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test case 1
    headers = RequestHeadersDict([('Header-1', 'Value1')])
    session = Session(path = 'example.json')
    session.update_headers(headers)
    assert session.headers['Header-1'] == 'Value1'

    # Test case 2
    headers = RequestHeadersDict([('Content-Type', 'application/json')])
    session.update_headers(headers)
    assert 'Content-Type' not in session.headers

    # Test case 3
    headers = RequestHeadersDict([('Cookie', 'value')])
    session.update_headers(headers)

# Generated at 2022-06-21 14:48:13.334878
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins.manager import SessionPluginManager
    from httpie.plugins.builtin import HTTPieSessionPlugin

    def mock_return_sessions_dir(key):
        return DEFAULT_SESSIONS_DIR

    # From http://stackoverflow.com/a/12260597/3234163
    orig__getitem__ = Config.__getitem__

    # Example of session file path:
    # ~/.config/httpie/sessions/github.com/test_session.json
    httpie_session_instance = None

# Generated at 2022-06-21 14:48:18.793454
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test.json")
    request_headers = RequestHeadersDict({'header1': 'value1', 'header2': 'value2'})
    session.update_headers(request_headers)
    expected_result = RequestHeadersDict({'header1': 'value1', 'header2': 'value2'})
    assert session.headers == expected_result

# Generated at 2022-06-21 14:48:28.865200
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.config import merge_dicts
    from httpie.models import Environment, KeyValue
    from httpie.plugins import AuthPlugin
    from httpie.plugins.registry import plugin_manager
    from httpie.utils import key2str
    from unittest.mock import Mock

    env = Environment(stdin=False, stdout=False, vars=["DUMMY"])

    # Mock an auth plugin
    auth_plugin_mock = Mock(spec=AuthPlugin)
    type(auth_plugin_mock).name = 'dummy-auth'
    type(auth_plugin_mock).auth_parse = True
    type(auth_plugin_mock).raw_auth = 'dummy-user'
    auth_plugin_mock.get_auth.return_value = 'dummy-auth'
    plugin

# Generated at 2022-06-21 14:48:32.018750
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s['cookies'] = {'k1': 'v1', 'k2': 'v2'}
    s.remove_cookies(['k1'])
    assert s['cookies'] == {'k2': 'v2'}

# Generated at 2022-06-21 14:48:39.561688
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers1 = {'A': 'v1', 'C': 'v1'}
    headers2 = {'A': 'v2', 'B': 'v2'}
    request_headers = RequestHeadersDict(headers1)
    session = Session('test_Session_update_headers')
    session.update_headers(request_headers)
    assert session['headers'] == headers1
    request_headers = RequestHeadersDict(headers2)
    session.update_headers(request_headers)
    assert session['headers'] == {'A': 'v2', 'B': 'v2', 'C': 'v1'}

# Generated at 2022-06-21 14:48:51.711252
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='path')
    headers = {
        'content-type': 'application/json',
        'Accept-Encoding': 'gzip, deflate',
        'set-cookie': 'a=b',
        'cookie': 'c=d; e=f',
        'authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='
    }
    session.update_headers(RequestHeadersDict(headers))

    assert session.headers == RequestHeadersDict({
        'accept-encoding': 'gzip, deflate',
        'authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='
    })

# Generated at 2022-06-21 14:48:56.761660
# Unit test for constructor of class Session
def test_Session():
    session = Session("./session")
    assert session.get('headers', "") == {}
    assert session.get('cookies', "") == {}
    assert session.get('auth', "") == {
        'type': None,
        'username': None,
        'password': None
    }
    assert type(session.headers) is RequestHeadersDict


# Generated at 2022-06-21 14:48:59.970379
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert not VALID_SESSION_NAME_PATTERN.match('Invalid!')
    assert VALID_SESSION_NAME_PATTERN.match('Valid-_.')

# Generated at 2022-06-21 14:49:08.185415
# Unit test for constructor of class Session
def test_Session():
    test_session = get_httpie_session(Path('./httpie'), 'test', None, 'http://test.test')
    assert type(test_session) is Session
    print(test_session)


# Generated at 2022-06-21 14:49:13.133165
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'name1': {'value': 'val1'}, 'name2': {'value': 'val2'}}
    session.remove_cookies(names=['name1'])
    assert session['cookies'] == {'name2': {'value': 'val2'}}

# Generated at 2022-06-21 14:49:18.955960
# Unit test for function get_httpie_session
def test_get_httpie_session():
    path = os.path.join(DEFAULT_SESSIONS_DIR, 'httpbin_org.json')
    session = Session(path)
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'httpbin_org', None, 'https://httpbin.org/post')
    assert session.headers == {}
    assert session.cookies == {}
    session = get_httpie_session('httpbin_org', 'https://httpbin.org/post')
    assert session.headers == {}
    assert session.cookies == {}

# Generated at 2022-06-21 14:49:23.770152
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import DEFAULT_CONFIG_DIR
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as dir_name:
        config_dir = Path(dir_name)
        session = get_httpie_session(config_dir, 'sep', 'host', 'url')
        assert session.path == (
            config_dir / SESSIONS_DIR_NAME / 'host' / 'sep.json'
        )
        session = get_httpie_session(config_dir, '../../other/sep', None, 'url')
        assert session.path == Path('other/sep.json')
        session = get_httpie_session(config_dir, '/etc/passwd', None, 'url')
        assert session.path == Path('/etc/passwd')
    assert get_httpie_session

# Generated at 2022-06-21 14:49:31.608446
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('dummy_path')
    assert session == {'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}
    session.update_headers(RequestHeadersDict({'Accept': 'hello', 'User-Agent': 'httpie'}))
    assert session == {'headers': {'Accept': 'hello'}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}
    session.update_headers(RequestHeadersDict({'Accept': None, 'User-Agent': 'httpie'}))
    assert session == {'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}

# Generated at 2022-06-21 14:49:36.452147
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies')
    session.new = True
    session.cookies = [('name', 'value'), ('name2', 'value')]
    names = ['name', 'name2']
    session.remove_cookies(names)
    assert session.cookies == {}

# Generated at 2022-06-21 14:49:40.406769
# Unit test for constructor of class Session
def test_Session():
    config = Session(path = "abcd.json")
    assert config['headers'] == {}
    assert config['cookies'] == {}
    assert config['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-21 14:49:52.124035
# Unit test for constructor of class Session
def test_Session():
    a = Session('a')
    assert a.load() is None
    a['headers']['a'] = 'a'
    a['headers']['b'] = 'b'
    assert a['headers']['a'] == 'a'
    a.save()
    b = Session('a')
    assert b.load() is None
    assert b['headers']['a'] == 'a'
    assert b['headers']['b'] == 'b'
    assert isinstance(b, BaseConfigDict)
    assert b.path == 'a'
    assert b.about == 'HTTPie session file'
    assert b.helpurl == 'https://httpie.org/doc#sessions'
    c = Session(b.path)
    assert c.load() is None
    assert c['headers']['a']

# Generated at 2022-06-21 14:49:59.410258
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Test SESSION_DIR_NAME is set to sessions
    assert SESSIONS_DIR_NAME == 'sessions'
    # Test DEFAULT_SESSIONS_DIR is set to ~/.config/httpie/sessions
    assert DEFAULT_SESSIONS_DIR == DEFAULT_CONFIG_DIR / 'sessions'
    # Test VALID_SESSION_NAME_PATTERN is set to [a-zA-Z0-9_.-]+
    assert VALID_SESSION_NAME_PATTERN.pattern == '^[a-zA-Z0-9_.-]+$'

# Generated at 2022-06-21 14:50:04.542672
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # create cookie jar
    jar = RequestsCookieJar()
    jar.set_cookie(create_cookie(
        name='cookie1', value='blabla'))
    jar.set_cookie(create_cookie(
        name='cookie2', value='blabla'))
    # create session
    test_ses = Session("blabla")
    test_ses.cookies = jar
    # remove cookies
    test_ses.remove_cookies(["cookie1"])
    assert len(test_ses['cookies']) == 1

# Generated at 2022-06-21 14:50:10.499969
# Unit test for constructor of class Session
def test_Session():
    test_session = Session(DEFAULT_SESSIONS_DIR)
    assert test_session.path == DEFAULT_SESSIONS_DIR

# Generated at 2022-06-21 14:50:14.821815
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('../../tests/fixtures/session.json')
    assert 'WASID' in s['cookies']
    s.remove_cookies(['WASID'])
    assert 'WASID' not in s['cookies']



# Generated at 2022-06-21 14:50:24.714512
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path(__file__).parent / 'sessions_dir' / 'test_session.json')
    session["headers"] = {}
    session["headers"]["accept"] = "text/html"
    session["headers"]["content-type"] = "text/html"
    session["headers"]["content-length"] = "10"
    session["headers"]["user-agent"] = "HTTPie/1.0.3"
    session["headers"]["if-match"] = "''"
    from httpie.cli.dicts import RequestHeadersDict

# Generated at 2022-06-21 14:50:26.243061
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, "test", "example.com", "test")

# Generated at 2022-06-21 14:50:34.682752
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Setup
    session = Session(path='Test')
    session_headers = {"name1": "value1", "name2": "value2"}
    session['headers'] = session_headers
    request_headers = {"name1": "value1", "name2": "value2", "Content-type": "application/json"}
    excluded_headers = ["Content-type"]
    session.update_headers(request_headers)
    # Test
    assert session_headers == session['headers']


# Generated at 2022-06-21 14:50:45.396913
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('a.json')
    s.update_headers({'User-Agent': 'Not HTTPie'})
    assert {'User-Agent': 'Not HTTPie'} == s['headers']

    # Overwrite existing headers
    s.update_headers({'User-Agent': 'another User-Agent'})
    assert {'User-Agent': 'another User-Agent'} == s['headers']

    # Append to existing session headers
    s.update_headers({'Authorization': 'Basic 1234567890'})
    assert {'User-Agent': 'another User-Agent', 'Authorization': 'Basic 1234567890'} == s['headers']

    s.update_headers({'User-Agent': None})
    assert {'Authorization': 'Basic 1234567890'} == s['headers']

    s.update_

# Generated at 2022-06-21 14:50:49.322489
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(('a', 'b'))
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-21 14:50:55.295496
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session()
    s['cookies'] = {"foo": "bar", "baz": "qux"}
    s.remove_cookies(['foo', 'test'])
    assert "foo" not in s['cookies']
    assert "test" not in s['cookies']
    assert "baz" in s['cookies']

# Generated at 2022-06-21 14:50:58.705666
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("")
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-21 14:51:06.932007
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Call the function get_httpie_session
    try:
        result = get_httpie_session(
            config_dir='.config',
            session_name='httpbin',
            host='httpbin.org',
            url='https://httpbin.org/get'
        )
    except Exception as e:
        print('Method get_httpie_session threw exception: {}'.format(e))
    else:
        print('Method get_httpie_session returned: {}'.format(result))


# Generated at 2022-06-21 14:51:18.444336
# Unit test for function get_httpie_session
def test_get_httpie_session():
    '''Test function get_httpie_session.
    Test cases:
    1. Test for session name with absolute path
    2. Test for session name with relative path
    3. Test for session name with no path
    '''
    sess_path_abs = '/tmp/httpie_session.json'
    sess_rel = 'relative_session.json'
    host_name = 'https://httpie.org'
    url_name = 'https://httpie.org/library'
    sess = get_httpie_session(Path(sess_path_abs), sess_path_abs, host_name, url_name)
    assert sess.path == Path(sess_path_abs)

# Generated at 2022-06-21 14:51:22.687949
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('path/to/session')
    s['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    s.remove_cookies(['cookie1'])
    assert s['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-21 14:51:27.250703
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Create empty Session
    session = Session('test')
    session['cookies'] = {}
    assert len(session['cookies']) == 0
    # Insert a cookie
    session['cookies']['cookie1'] = {}
    assert len(session['cookies']) == 1
    # Remove cookie
    names_to_remove = ['cookie1']
    session.remove_cookies(names_to_remove)
    assert len(session['cookies']) == 0

# Generated at 2022-06-21 14:51:32.863758
# Unit test for constructor of class Session
def test_Session():
    test_path = 'test_path'
    expected_path = Path('test_path')
    session = Session(test_path)
    assert session._path == expected_path
    assert session == {'auth': {'type': None, 'username': None, 'password': None}, 'cookies': {}, 'headers': {}}


# Generated at 2022-06-21 14:51:34.862720
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(None)
    s['cookies'] = {'c1': 'v1', 'c2': 'v2'}
    s.remove_cookies(('c1', 'foo'))
    assert s['cookies'] == {'c2': 'v2'}

# Generated at 2022-06-21 14:51:39.390467
# Unit test for constructor of class Session
def test_Session():
    import tempfile

    Session(tempfile.mktemp())
    try:
        Session(tempfile.mktemp("/"))
    except ValueError:
        print("Path can't contain a /")

    Session("/tmp")
    Session("~/some_dir")

    Session(Path("/tmp"))
    Session(Path("~/some_dir"))


# Generated at 2022-06-21 14:51:43.328866
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import pytest
    sess = Session(path='')
    union = {'a': '1', 'b': '2'}
    sess.update_headers(union)
    assert sess.headers == union



# Generated at 2022-06-21 14:51:51.377452
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {
        'Content-Type': 'application/json',
        'If-Match': '*',
        'Foo': '1',
        'User-Agent': 'HTTPie/1.0.2',
        'Host': 'www.example.com',
        'Accept': '*/*',
    }
    session_headers = {
        'Content-Type': 'text/html',
        'Accept-Encoding': 'gzip, deflate',
        'Accept': 'text/plain'
    }
    session = Session(path='test')
    session['headers'] = session_headers
    session.update_headers(request_headers)

# Generated at 2022-06-21 14:51:58.064903
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names = ['eng', 'pol']
    test_s = Session('sessions')
    test_s['cookies'] = {'eng': {'value': 't'}, 'pol': {'value': 't'}}
    assert test_s['cookies'] == {'eng': {'value': 't'}, 'pol': {'value': 't'}}
    test_s.remove_cookies(names)
    assert test_s['cookies'] == {}



# Generated at 2022-06-21 14:52:04.093397
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Given
    names = ['foo', 'bar']
    cookies = {name: "cookie_" + name for name in names}
    session = Session(path='foo')
    session['cookies'] = cookies
    assert session['cookies'] == cookies

    # When
    session.remove_cookies(names)

    # Then
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:52:19.209830
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli import parser

    # Test for method update_headers of class Session
    session = Session(__file__)
    session_headers = {'name1': 'value1', 'name2': 'value2'}
    for key, val in session_headers.items():
        session['headers'][key] = val

    request_headers = RequestHeadersDict({
        'name1': 'value1_1', 'name2': 'value2_1',
        'name3': 'value3_1', 'Cookie': 'name4=value4; path=/'
    })

    session.update_headers(request_headers)
    assert request_headers.mutable == False
    assert request_headers['name1'] == 'value1_1'

# Generated at 2022-06-21 14:52:22.927066
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_SESSIONS_DIR
    url = "http://www.baidu.com"
    session_name = "baidu"
    host = "www.baidu.com"
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.get('headers') == {'Host': 'www.baidu.com'}

# Generated at 2022-06-21 14:52:34.355680
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class Session(BaseConfigDict):
        helpurl = 'https://httpie.org/doc#sessions'
        about = 'HTTPie session file'

        def __init__(self, path: Union[str, Path]):
            super().__init__(path=Path(path))
            self['headers'] = {}
            self['cookies'] = {}
            self['auth'] = {
                'type': None,
                'username': None,
                'password': None
            }

    test_session = Session('~/test/')
    test_session['headers']['Host'] = '192.168.1.1'
    test_session['headers']['Connection'] = 'Keep-Alive'
    test_session['headers']['Accept'] = '*/*'

# Generated at 2022-06-21 14:52:41.253997
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    p = Path.cwd() / "test_session.json"
    s = Session(p)
    s['headers'] = {'a':'b'}
    s['cookies'] = {'a':'1', 'b':'2'}
    s['auth'] = {'type':None, 'username':None, 'password':None}
    s.remove_cookies(['a', 'c'])
    assert(s['cookies'] == {'b':'2'})

# Generated at 2022-06-21 14:52:42.964638
# Unit test for constructor of class Session
def test_Session():
    session = Session('test.json')
    assert session.path == DEFAULT_SESSIONS_DIR / 'test.json'

# Generated at 2022-06-21 14:52:49.530799
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session('/mock_dir', 'session_name', 'example.com', 'http://example.com/test')
    assert session._path.as_posix() == '/mock_dir/sessions/example_com/session_name.json'
    assert session._path.name == 'session_name.json'

# Generated at 2022-06-21 14:52:53.745688
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'name1':'value1', 'name2':'value2'}
    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'] == {'name2':'value2'}

# Generated at 2022-06-21 14:53:01.592727
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """Remove cookies in a session while preserving others."""
    s = Session('tests/fixtures/sessions/session1.json')  # type: ignore
    s.remove_cookies(['_pinterest_sess', 'csrftoken'])

    assert '_pinterest_sess' not in s
    assert 'csrftoken' not in s
    assert 'csrftoken' not in s['cookies']

# Generated at 2022-06-21 14:53:12.694509
# Unit test for function get_httpie_session

# Generated at 2022-06-21 14:53:16.721024
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('.')
    session_name = 'mock'
    host = 'localhost'
    url = 'https://localhost'

    session = get_httpie_session(config_dir, session_name, host, url)
    print(session)

# Generated at 2022-06-21 14:53:30.716403
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    d = dict(a=1, b=2)
    self = Session(path = "")
    self['headers'] = d
    new = dict(a=3, c=4)
    self.update_headers(new)
    # The method update_headers merge two dicts, but the order of the merge is not defined.
    # Since the dicts are changed in place, the check should be for equality, not for identity
    assert (self['headers'] == {'a': 3, 'c': 4}) or (self['headers'] == {'a': 1, 'c': 4})


# Generated at 2022-06-21 14:53:41.798438
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.plugins.auth.basic import BasicAuth

    headers = {
        'Content-Type': 'application/json',
        'set-cookie': 'test=test;test1=test1',
        'if-modified-since': 'test',
        'User-Agent': 'httpie/0.9.9',
        'Host': 'example.com',
        'Authorization': 'Basic dGVzdDp0ZXN0',
    }

    session = Session('test_Session_update_headers.json')
    session.update_headers(headers)

    assert session.headers['content-type'] == 'application/json'
    assert session.headers['host'] == 'example.com'
    assert session.headers['user-agent'] == 'httpie/0.9.9'
    assert session.headers['authorization']

# Generated at 2022-06-21 14:53:46.795584
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path='')
    names = ['a', 'b']
    s['cookies'] = {'a': '1'}
    s.remove_cookies(names)
    assert s['cookies'] == {}



# Generated at 2022-06-21 14:53:51.951542
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers1 = RequestHeadersDict({'Content-Length': '100'})
    headers2 = RequestHeadersDict({'Content-Type': 'application/json'})
    ses = Session(DEFAULT_SESSIONS_DIR / 'test')
    ses.update_headers(headers1)
    ses.update_headers(headers2)
    assert(ses.headers == {'Content-Type': 'application/json'})

# Generated at 2022-06-21 14:53:59.496429
# Unit test for constructor of class Session
def test_Session():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.plugins.registry import plugin_manager
    from httpie.session import Session
    from httpie.auth.registry import AuthPlugin

    class TestAuthPlugin(AuthPlugin):
        name = 'test'
        auth_type = 'test'
        auth_parse = False

    plugin_manager.register(TestAuthPlugin)
    session = Session(DEFAULT_CONFIG_DIR/'sessions'/'localhost'/'test.json')
    session.update_headers({'abc': '123', 'user-agent': 'HTTPie/0.9.2', 'cookie': 'name_1=value_1'})

# Generated at 2022-06-21 14:54:11.273034
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Create new session
    session_file_name = 'Test_Session_remove_cookies.json'
    session_file_path = DEFAULT_SESSIONS_DIR / session_file_name
    session = Session(session_file_path)

    # Update cookies
    cookies = RequestsCookieJar()
    cookie_name1 = 'cookie_name1'
    cookie_value1 = 'cookie_value1'
    cookie_name2 = 'cookie_name2'
    cookie_value2 = 'cookie_value2'
    cookie_name3 = 'cookie_name3'
    cookie_value3 = 'cookie_value3'
    cookie_name4 = 'cookie_name4'
    cookie_value4 = 'cookie_value4'
    cookies.set(cookie_name1, cookie_value1)
    cookies.set

# Generated at 2022-06-21 14:54:19.127010
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from pytest import raises
    from unittest.mock import MagicMock

    session = Session(path=MagicMock())

    session['cookies'] = {'a': 'b'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {}

    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {}

    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a', 'd'])
    assert session['cookies'] == {'c': 'd'}

    # KeyError
    session['cookies'] = {'a': 'b'}

# Generated at 2022-06-21 14:54:27.241760
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """Simulate request headers input by user"""
    request_headers_dict = {
        'Content-Encoding': 'compressed',
        'Content-Type': 'compressed',
        'If-Unmodified-Since': 'ifunmodifiedsince',
        'User-Agent': 'custom agent',
        'Cookie': 'SESSIONID=123456789; CUSTOMER=abc',
    }
    session = Session(None)
    session.update_headers(request_headers_dict)
    print(session)


if __name__ == "__main__":
    test_Session_update_headers()

# Generated at 2022-06-21 14:54:35.099832
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # test if the session is created
    config_dir = Path('./')
    session_name = 'test'
    url = 'http://localhost:9999'
    httpie_session = get_httpie_session(config_dir, session_name, None, url)
    path = config_dir / SESSIONS_DIR_NAME / 'localhost_9999' / f'{session_name}.json'
    #test if the session is stored in the correct path
    assert httpie_session.path == path


# Generated at 2022-06-21 14:54:39.197727
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        '/home/user/.httpie', 'session-name', 'www.google.com', 'www.google.com'
    )
    assert session == {
        'auth': {
            'type': None,
            'username': None,
            'password': None
        },
        'cookies': {},
        'headers': {}
    }