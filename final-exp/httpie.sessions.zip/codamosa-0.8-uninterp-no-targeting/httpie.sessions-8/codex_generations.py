

# Generated at 2022-06-21 14:45:04.975561
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    request_headers = RequestHeadersDict()
    request_headers.add('H1', [1, 2, 3])
    request_headers.add('h2', [4, 5, 6])
    request_headers.add('H3', 7)
    request_headers.add('If-Modified-Since', 8)
    session = Session(Path('/tmp'))
    session.update_headers(request_headers)
    assert session['headers'] == {'H1': '1, 2, 3', 'h2': '4, 5, 6', 'H3': '7'}

# Generated at 2022-06-21 14:45:13.773879
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    print("Test Session_remove_cookies")
    class reqCookieJar:
        def set_cookie(self, cookie):
            print("Cookies set")
    cookieJar = reqCookieJar()
    session = Session("testSession")
    session['cookies'] = {'test': 'value'}
    print("cookies: ")
    print(session['cookies'])
    session.remove_cookies(['test'])
    print("cookies: ")
    print(session['cookies'])
    assert( 'test' not in session['cookies'])
test_Session_remove_cookies()



# Generated at 2022-06-21 14:45:22.413275
# Unit test for constructor of class Session
def test_Session():
    """
    This function tests constructor of class Session.
    """
    # Prepare test data
    path = 'example.json'
    # Expected result
    expected = Session(path)
    expected['headers'] = {}
    expected['cookies'] = {}
    expected['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }

    # Create Session
    result = Session(path)
    assert result.path == expected.path, 'test path failed'
    assert result['headers'] == expected['headers'], 'test headers failed'
    assert result['cookies'] == expected['cookies'], 'test cookies failed'
    assert result['auth'] == expected['auth'], 'test auth failed'


# Generated at 2022-06-21 14:45:27.048659
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    import os
    
    my_path = Path("~/.config/httpie/sessions/example.com/something.json")
    path = os.path.expanduser(str(my_path))
    path = Path(path)
    assert path.exists()
    session = Session(path)
    session.load()



# Generated at 2022-06-21 14:45:33.000172
# Unit test for constructor of class Session
def test_Session():
    # test private method __init__()
    session_path = 'D:/abc.json'
    session = Session(session_path)
    assert session_path == session['path']
    assert 'headers' in session
    assert 'cookies' in session
    assert 'auth' in session
    assert 'type' in session['auth']
    assert 'username' in session['auth']
    assert 'password' in session['auth']


# Generated at 2022-06-21 14:45:43.375181
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.output.streams import get_binary_stream
    import requests
    from requests.cookies import cookiejar_from_dict
    from httpie.sessions import Session
    from httpie import input
    from httpie.request import Request
    from httpie.compat import is_windows
    session = Session('./tests/fixtures/cookies.json')
    request = Request(
        'GET',
        'http://httpbin.org/cookies',
        config=get_binary_stream('stdout'),
        options={},
        )
    session.cookies = cookiejar_from_dict(
        {
            'cookie-key': 'cookie-value',
            'cookie-key-2': 'cookie-value-2'
        })

# Generated at 2022-06-21 14:45:48.742690
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/test.json')
    s["cookies"] = {
        "a": 1,
        "b": 2,
        "c": 3,
    }
    s.remove_cookies(["b", "c"])
    assert {"a": 1} == s["cookies"]

# Generated at 2022-06-21 14:45:57.552408
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import pytest
    from httpie.config import BaseConfigDict
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    from httpie.auth import AuthPlugin
    from httpie import ExitStatus
    for file in DEFAULT_SESSIONS_DIR.iterdir():
        if file.is_file():
            file.unlink()
    for dir in DEFAULT_SESSIONS_DIR.iterdir():
        if dir.is_dir():
            os.rmdir(dir)
    session_name = 'test.test'
    config_dir = DEFAULT_CONFIG_DIR
    session_path = (config_dir / SESSIONS_DIR_NAME / 'localhost'
                    / f'{session_name}.json')
    host = 'localhost'


# Generated at 2022-06-21 14:46:09.116691
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/test_file')
    request_headers = RequestHeadersDict([('k1', 'v1'), ('k2', 'v2')])
    session.update_headers(request_headers)
    assert session['headers'] == {'k1': 'v1', 'k2': 'v2'}
    request_headers = RequestHeadersDict([('k1', 'v1'), ('k2', None)])
    session.update_headers(request_headers)
    assert session['headers'] == {'k1': 'v1', 'k2': 'v2'}
    request_headers = RequestHeadersDict([('k1', 'v3'), ('k2', None)])
    session.update_headers(request_headers)

# Generated at 2022-06-21 14:46:15.833649
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(Path('./'), 'session', 'localhost', 'http://localhost/').__dict__ == {
        'path': Path('./sessions/localhost/session.json'),
        '_content': {
            'headers': {},
            'cookies': {},
            'auth': {'type': None, 'username': None, 'password': None}
        }
    }

# Generated at 2022-06-21 14:46:28.929374
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path

    config_dir = Path("~/.config/httpie")
    session_name = "sessions"
    host = "http://www.abc.com"
    url = "https://www.abc.com/api/1"
    session = get_httpie_session(config_dir, session_name, host, url)

    assert session["auth"] == {"type": None, "username": None, "password": None}
    assert "user-agent" not in session["headers"]
    assert session["cookies"] == {}

# Generated at 2022-06-21 14:46:35.946269
# Unit test for constructor of class Session
def test_Session():
    session_path = Path(DEFAULT_SESSIONS_DIR, 'session.json')
    session = Session(session_path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}
    assert session._config_dir == DEFAULT_SESSIONS_DIR
    assert session._config_file_name == 'session.json'
    assert session._path == session_path



# Generated at 2022-06-21 14:46:48.363088
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    This test verifies that cookies are removed from the session
    """
    from typing import List
    from http.cookies import SimpleCookie
    from pathlib import Path
    from requests.cookies import create_cookie, RequestsCookieJar
    import os
    import tempfile

    # Generate a temporary file as the session.json
    with tempfile.TemporaryFile(mode='w+') as file:
        session = Session(file.name)

    # Populate the session with cookies

# Generated at 2022-06-21 14:46:58.563346
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('session.json')
    request_headers = RequestHeadersDict({'a': '1', 'b': '2'})
    session.update_headers(request_headers)

    assert session.headers == request_headers
    assert session.cookies == {}

    request_headers = RequestHeadersDict({'a': '3', 'c': '4'})
    session.update_headers(request_headers)

    assert session.headers == RequestHeadersDict({'a': '3', 'b': '2', 'c': '4'})
    assert session.cookies == {}

    # Append headers
    request_headers = RequestHeadersDict({'a': '5', 'a': '6'})
    session.update_headers(request_headers)

# Generated at 2022-06-21 14:47:01.848202
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, "test_session", "localhost",
                                 "http://localhost:3000")
    assert type(session) == Session

# Generated at 2022-06-21 14:47:09.747617
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("_test.json")
    session['cookies'] = {
        'session': {'value': '123', 'domain': 'httpie.org'},
        'cookies': {'value': 'banana', 'domain': 'httpie.org'},
        'cart': {'value': 'abcdef', 'domain': 'httpie.org'},
        'analytics': {'value': '5', 'domain': 'httpie.org'},
    }
    session.remove_cookies(['session', 'cookies', 'analytics'])
    assert session['cookies'] == {
        'cart': {'value': 'abcdef', 'domain': 'httpie.org'},
    }

# Generated at 2022-06-21 14:47:20.816909
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArgType
    import json

    session = Session(path='test_session.json')
    # Initialize session with the example headers
    session.__dict__['_config'] = {
        'headers': {
            'Content-Type': 'application/json',
            'Referer': 'http://httpbin.org/'
        }
    }
    session.__dict__['_dirty'] = False

    # Example of initial headers
    assert session.headers == {
        'Content-Type': 'application/json',
        'Referer': 'http://httpbin.org/'
    }

    # Example of request headers
    headers = KeyValueArgType().convert('Content-Type=application/xml',
                                        None, None)
    headers = dict(headers)

    # Call the

# Generated at 2022-06-21 14:47:26.351719
# Unit test for constructor of class Session
def test_Session():
    filename = "session_file_name"
    path = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / filename
    sess = Session(path)
    assert isinstance(sess, Session)
    assert sess.path == path
    assert sess['headers'] == {}
    assert sess['cookies'] == {}
    assert sess['auth'] == {'type': None, 'username': None, 'password': None}
    assert sess.auth == None


# Generated at 2022-06-21 14:47:34.215391
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session_name = 'test_httpie_session'
    host = 'httpbin.org'
    url = 'https://httpbin.org/get'
    config_dir = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / host
    Path(config_dir).mkdir(parents=True, exist_ok=True)
    path = config_dir / f'{session_name}.json'
    return get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-21 14:47:46.430016
# Unit test for constructor of class Session
def test_Session():
	RequestHeadersDict = {
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate',
		'Accept-Language': 'en-US,en;q=0.5',
		'Cache-Control': 'no-cache',
		'Connection': 'keep-alive',
		'Host': 'httpbin.org',
		'Pragma': 'no-cache',
		'Upgrade-Insecure-Requests': '1',
		'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:39.0) Gecko/20100101 Firefox/39.0',
	}
	cookies

# Generated at 2022-06-21 14:47:55.728008
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'web-api-connection'
    host = 'wwww.google.com'
    url = 'https://www.google.com/'

    get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-21 14:47:59.212516
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cook1 = {
        "key": "val",
        "key2": "val2"
    }
    cook2 = {
        "key3": "val3",
        "key4": "val4"
    }
    cook3 = {
        "key5": "val5",
        "key6": "val6"
    }
    session = Session("")
    session['cookies'] = {
        "cook1": cook1,
        "cook2": cook2,
        "cook3": cook3
    }
    names = ["cook1", "cook3"]
    session.remove_cookies(names)
    assert session['cookies'] == {
        "cook2": cook2
    }



# Generated at 2022-06-21 14:48:01.598735
# Unit test for constructor of class Session
def test_Session():
    assert Session('Session').path == Path('Session')
    assert Session(Path('Session')).path == Path('Session')


# Generated at 2022-06-21 14:48:04.209693
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://127.0.0.1:8080/index.html'
    host = '127.0.0.1'
    config_dir = Path('/home/alice/.config/httpie/sessions')
    
    assert get_httpie_session(config_dir, 'ns1', host, url)

# Generated at 2022-06-21 14:48:12.494485
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('./__test_session__.json')
    s['cookies'] = {
        'a': {'value': '1'},
        'b': {'value': '2'}
    }
    s.remove_cookies(['a'])
    assert s['cookies'] == {
        'b': {'value': '2'}
    }
    s.remove_cookies(['c'])
    assert s['cookies'] == {
        'b': {'value': '2'}
    }



# Generated at 2022-06-21 14:48:20.309431
# Unit test for constructor of class Session
def test_Session():
    p=Path('../config')
    s=Session('../config/sessions/hostname/session_name.json')
    assert s['headers']=={}
    assert s['cookies']=={}
    assert s['auth']['type']==None
    assert s['auth']['username']==None
    assert s['auth']['password']==None
    assert type(s['path'])==Path
    assert s.get_httpie_session(p,'session_name', 'hostname', 'url')==s


# Generated at 2022-06-21 14:48:30.058668
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {
        'X-Api-Key':'Api_key',
        'Accept': 'application/json',
        'Cookie': 'user_id=1; user_token=abcdef12345678',
        'If-Modified-Since': '2018-08-21T00:00:00.000Z',
        'Content-Length': '343',
        'Content-Type': 'application/json'
    }

    session = Session('/tmp/test_session.json')
    session.update_headers(headers)

    # Test if the headers saved in session is correct
    session_headers = session['headers']
    assert session_headers == {'Accept': 'application/json'}
    
    # Test if the cookies saved in session is correct
    cookies_list = session['cookies']

# Generated at 2022-06-21 14:48:36.268301
# Unit test for constructor of class Session
def test_Session():
    path = Path(DEFAULT_CONFIG_DIR) / 'sessions' / 'test.json'
    session = Session(path)
    assert session['headers'] == {}
    assert 'cookies' in session
    assert 'auth' in session
    assert 'type' in session['auth']
    assert 'username' in session['auth']
    assert 'password' in session['auth']


# Generated at 2022-06-21 14:48:40.244701
# Unit test for constructor of class Session
def test_Session():
    session = Session('session1')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert len(session['auth']) == 3
    assert session['auth']['type'] == None
    assert session['auth']['username'] == None
    assert session['auth']['password'] == None


# Generated at 2022-06-21 14:48:48.979220
# Unit test for function get_httpie_session
def test_get_httpie_session():
    request_headers = {
        'Host': 'example.org'
    }
    session_config_dir = Path('.httpie')
    session_name = 'this_project'
    url = 'https://example.org/'

    session = get_httpie_session(
        config_dir=session_config_dir,
        session_name=session_name,
        host=None,
        url=url
    )
    session.update_headers(request_headers)

# Generated at 2022-06-21 14:49:05.770792
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    def test_case(request_headers, session_headers_expected, cookies_expected):
        s = Session('')
        s.update_headers(request_headers)
        assert s['headers'] == session_headers_expected
        assert s['cookies'] == cookies_expected

    yield test_case, {'header1': 'value1'}, {'header1': 'value1'}, {}
    yield test_case, {'Cookie': 'name1=value1'}, {}, {'name1': {'value': 'value1'}}
    yield test_case, {'Cookie': 'name1=value1; name2=value2'}, {}, {
        'name1': {'value': 'value1'},
        'name2': {'value': 'value2'},
    }

# Generated at 2022-06-21 14:49:13.818637
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('SESSION_ID')
    sess['cookies'] = {
        'name1': {'value': 'value1'},
        'name2': {'value': 'value2'},
        'name3': {'value': 'value3'},
    }
    sess.remove_cookies(['name1', 'name3'])
    assert sess['cookies'] == {'name2': {'value': 'value2'}}


if __name__ == '__main__':
    test_Session_remove_cookies()

# Generated at 2022-06-21 14:49:16.903256
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    c = Session('test.json')
    c['cookies'] = {'test': 'test'}
    c.remove_cookies(['test', 'other'])
    assert not c['cookies']


# Generated at 2022-06-21 14:49:24.972789
# Unit test for constructor of class Session
def test_Session():
    a = Session(path = '/mnt/c/Users/Redwood/.config/httpie/sessions/eclipse.org/http_eclipse_org.json')
    assert a['headers'] == {}
    assert a['cookies'] == {}
    assert a['auth']['type'] == None
    assert a['auth']['username'] == None
    assert a['auth']['password'] == None
    assert a.auth == None


# Generated at 2022-06-21 14:49:31.762949
# Unit test for constructor of class Session
def test_Session():
    session_file_name = 'tmp/example.json'
    # Create session dir
    if not os.path.exists('tmp'):
        os.makedirs('tmp')
    # Create session file
    if os.path.exists(session_file_name):
        os.remove(session_file_name)
    os.mknod(session_file_name)
    # Create session object
    s = Session(session_file_name)
    assert s.path == 'tmp/example.json'

    assert len(s.keys()) == 3
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-21 14:49:36.251035
# Unit test for constructor of class Session
def test_Session():
    config_dir = Path('/home/test1')
    session_name = 'test2'
    host = 'test3'
    url = 'test4'
    get_httpie_session(config_dir, session_name, host, url)

test_Session()

# Generated at 2022-06-21 14:49:41.390148
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    the method remove_cookies of class Session removes cookies according to the names received.
    """
    session = Session('/test/test_session_test.json')
    session['cookies'] = {'test1': 'test1'}
    session.remove_cookies(['test1', 'test2'])
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:49:42.541676
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass


# Generated at 2022-06-21 14:49:47.066117
# Unit test for function get_httpie_session
def test_get_httpie_session():
    os.system("mkdir -p ~/.config/httpie/sessions/localhost")
    get_httpie_session(DEFAULT_SESSIONS_DIR, "test", None, "http://localhost")
    os.system("rm -rf ~/.config/httpie")



# Generated at 2022-06-21 14:49:50.064079
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./test.json')
    session.update_headers({'name': 'test'})
    assert session.headers['name'] == 'test'

# Generated at 2022-06-21 14:50:02.937510
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import tempfile

    def new_session():
        return Session(tempfile.NamedTemporaryFile().name)

    # --session
    session = new_session()
    session.update_headers(RequestHeadersDict({'A': 'a'}))
    assert dict(session.headers) == {'A': 'a'}

    # --ignore-stdin
    session = new_session()
    session.update_headers(RequestHeadersDict())
    assert dict(session.headers) == {}

    # New header
    session = new_session()
    session.update_headers(RequestHeadersDict({'B': 'b'}))
    assert dict(session.headers) == {'B': 'b'}

    # Existing header
    session = new_session()

# Generated at 2022-06-21 14:50:07.592983
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {'c-o-n-t-e-n-t-Type': 'application/json', 'host': '127.0.0.1', 'User-Agent': 'curl', 'Content-Type': 'text/html', 'Cookie': 'x=y'}
    test_sesssion = Session('test')
    test_sesssion.update_headers(request_headers)
    assert test_sesssion['headers'] == {'host': '127.0.0.1', 'Content-Type': 'text/html'}
    assert test_sesssion['cookies'] == {'x': {'value': 'y'}}

# Generated at 2022-06-21 14:50:19.455188
# Unit test for function get_httpie_session
def test_get_httpie_session():

    #Test negative case
    config_dir = Path('/')
    session_name = 'foobar'
    host = 'localhost'
    url = 'https://httpie.org/foo/bar'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session

    #Test: no host
    url = 'https://httpie.org/foo/bar'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session

    #Test: no host with localhost
    host = 'localhost'
    url = 'https://httpie.org/foo/bar'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session

    #Test: no host with localhost

# Generated at 2022-06-21 14:50:21.457167
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session()
    request_headers = RequestHeadersDict([
        ('Content-Type', 'application/json'),
        ('Content-Length', '0'),
        ('If-Match', '*'),
    ])
    session.update_headers(request_headers)
    assert session['headers'] == {}

# Generated at 2022-06-21 14:50:33.856616
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config, DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.plugins.manager import PLUGIN_MANAGER
    from httpie import ExitStatus
    from io import StringIO
    import shutil
    import sys
    import pytest
    import requests
    import os
    import json
    import httpie.input
    import httpie.output
    import httpie.downloads
    import httpie.sessions


    if not os.path.isdir(str(DEFAULT_CONFIG_DIR)):
        os.mkdir(str(DEFAULT_CONFIG_DIR))


# Generated at 2022-06-21 14:50:39.184908
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('sessions/test-session.json')
    session['cookies'] = {'cookie1': 1, 'cookie2': 2, 'cookie3': 3, 'cookie4': 4}
    names = ['cookie1', 'cookie2', 'cookie3']
    assert session['cookies'] == {'cookie4': 4}


# Generated at 2022-06-21 14:50:43.431629
# Unit test for constructor of class Session
def test_Session():
    dir_path = "/home/tomas/httpie/httpie-0.9.5/httpie-0.9.5/httpie"
    file_path = "/home/tomas/httpie/httpie-0.9.5/httpie-0.9.5/httpie/session.json"

    test_session = Session(file_path)
    test_session2 = Session(dir_path)
    
    print("Testing session class")

    print("Testing __init__ funtion")

    assert isinstance(test_session, Session)
    print("Test_session is instance of class Session")

    #assert os.path.isfile(test_session.path)
    #print("Test_session.path exists in the file system")

    assert isinstance(test_session2, Session)

# Generated at 2022-06-21 14:50:55.534180
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Example session file name
    session_name = 'a_session'

    # Path to a config directory
    path = Path(os.path.expanduser('~/.config/httpie'))

    # Session in the config directory
    config_dir_session = get_httpie_session(path, session_name,
                                            host='www.google.com',
                                            url='http://www.google.com/')

    # Session in the specified directory
    path = Path.home() / 'my_sessions'
    path.mkdir(exist_ok=True)
    custom_dir_session = get_httpie_session(path, session_name,
                                            host='www.google.com',
                                            url='http://www.google.com/')


# Generated at 2022-06-21 14:50:58.868444
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {"test": "header"}
    session = Session("test.json")
    session.update_headers(headers)
    for name, value in headers.items():
        assert (session.headers[name] == value)


# Generated at 2022-06-21 14:51:02.730445
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, "session_name", "host", "url").path == Path.joinpath(DEFAULT_SESSIONS_DIR, "host", "session_name.json")

# Generated at 2022-06-21 14:51:16.332403
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    sess = Session('')
    orig = {'key1': 'value1', 'key2': 'value2'}
    sess['headers'] = orig.copy()
    req = {
        'key1': 'value3',
        'key2': None,
        'key3': '',
        'key4': '4',
        'cookie': '',
        'key5': '5',
        'Content-Type': '',
        'If-Match': '',
    }
    expected = {
        'key1': 'value3',
        'key3': '',
        'key4': '4',
        'key5': '5',
    }
    sess.update_headers(req)
    assert sess['headers'] == expected
    assert sess['cookies'] == {}


# Unit

# Generated at 2022-06-21 14:51:25.713794
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.context import Environment
    import json
    import pytest
    extracted_name = 'token'
    extracted_value = '12345'
    test_session_name = 'test_session'
    test_url = 'https://www.baidu.com/'
    test_headers = RequestHeadersDict([
        (extracted_name, extracted_value),
        ('Content-Type', 'application/json'),
        ('Accept', 'application/json'),
        ('User-Agent', 'HTTPie/1.0.2'),
        ('Cookie', f'{extracted_name}={extracted_value}')
    ])

# Generated at 2022-06-21 14:51:35.448121
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path()
    assert get_httpie_session(config_dir, "test_session", None, "http://test.com").path == Path("sessions/test.com/test_session.json")
    assert get_httpie_session(config_dir, "test_session", "host", "http://test.com").path == Path("sessions/host/test_session.json")
    assert get_httpie_session(config_dir, "test_session", "host:80", "http://test.com").path == Path("sessions/host_80/test_session.json")

# Generated at 2022-06-21 14:51:45.907138
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Tests of method update_headers of class Session
    headers = RequestHeadersDict({"Accept-Language": "en"})
    session = Session(path='/tmp/sessions/test.json')
    session.update_headers(headers=headers)
    assert session == {'headers': {'Accept-Language': 'en'}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}

    session = Session(path='/tmp/sessions/test.json')
    headers = RequestHeadersDict({"Content-Length": "450"}) # starts with Content-
    session.update_headers(headers=headers)
    assert session == {'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}

    session = Session

# Generated at 2022-06-21 14:51:57.492671
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    def test_dont_remove(session):
        # session['cookies'] = {'a': 'b'}
        session.remove_cookies(['c'])
        assert session['cookies'] == {'a': 'b'}

    def test_remove_one(session):
        # session['cookies'] = {'a': 'b'}
        session.remove_cookies(['a'])
        assert session['cookies'] == {}

    def test_remove_many(session):
        # session['cookies'] = {'a': 'b', 'c': 'd'}
        session.remove_cookies(['a', 'b'])
        assert session['cookies'] == {'c': 'd'}


# Generated at 2022-06-21 14:52:09.117789
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import io
    import json

    n_null = 0
    n_pref = 0

    session_header = []
    with io.open('test_Session_update_headers.json', 'r', encoding='utf8') as f:
        session_header = json.load(f)
        f.close()

    raw_header = []
    with io.open('test_Session_update_headers_raw.json', 'r', encoding='utf8') as f:
        raw_header = json.load(f)
        f.close()

    test_s = Session('sess')
    test_s['headers'] = session_header

    for name, value in raw_header.items():
        if value is None:
            n_null += 1
            continue  # Ignore explicitly unset headers

# Generated at 2022-06-21 14:52:12.962232
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import pathlib
    assert isinstance(get_httpie_session(pathlib.Path(r"C:\Users\Admin\AppData\Local\httpie"), "session", "", ""), Session)

# Generated at 2022-06-21 14:52:22.022685
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_cases = [
            ({
                'user-agent': 'HTTPie/0.9.2',
                'Cookie': 'foo=bar;',
                'SESSION-ID': 'abc123',
                'Content-Type': 'text/html'
            },
            {
                'Cookie': 'foo=bar;',
                'SESSION-ID': 'abc123'
            }),
            ({
                'Cookie': 'foo=bar;',
                'If-Modified-Since': 'Fri, 01 Dec 2000 00:00:00 GMT',
                'Accept-Language': 'en-US'
            },
            {
                'Cookie': 'foo=bar;',
                'Accept-Language': 'en-US'
            })
    ]


# Generated at 2022-06-21 14:52:28.353870
# Unit test for function get_httpie_session
def test_get_httpie_session():
    test_session_name = 'test'
    test_host = 'test'
    test_url = 'http://localhost'
    test_sessions_dir = DEFAULT_SESSIONS_DIR
    assert get_httpie_session(test_sessions_dir, test_session_name,
                              test_host, test_url)
    assert get_httpie_session(test_sessions_dir, test_session_name,
                              test_host, test_url)

# Generated at 2022-06-21 14:52:30.207059
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert hasattr(get_httpie_session, '__call__')

# Generated at 2022-06-21 14:52:45.006761
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='.test_httpie_session.json',
        host='localhost',
        url='http://localhost/'
    ) == Session(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME
                 / 'localhost'
                 / '.test_httpie_session.json')
    assert get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name=f'~{DEFAULT_SESSIONS_DIR}/.test_custom_session.json',
        host=None,
        url='http:///'
    ) == Session(Path(DEFAULT_SESSIONS_DIR) / '.test_custom_session.json')

# Generated at 2022-06-21 14:52:47.550725
# Unit test for constructor of class Session
def test_Session():
    path = '/etc/httpie/sessions/localhost/sess_1.json'
    assert Session(path).path == path

# Generated at 2022-06-21 14:52:53.018561
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from collections import defaultdict

    temp_config_dir = Path(__file__).with_name('temp_httpie_config')

    session = get_httpie_session(temp_config_dir, 'sid', '', 'https://httpie.org/')

    session.update_headers(RequestHeadersDict(defaultdict(list, {
        'Content-Type': 'application/json',
        'Host': 'httpie.org',
        'If-Modified-Since': 'never',
        'X-Random': ['one', 'two', 'three'],
    })))

    assert session.headers == {
        'Content-Type': 'application/json',
        'Host': 'httpie.org',
        'X-Random': 'one,two,three'
    }

# Generated at 2022-06-21 14:52:57.615332
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        Path('/root/.config/httpie'), 'sessionname', '127.0.0.1', 'http://127.0.0.1/')
    assert(session.path =='/root/.config/httpie/sessions/127_0_0_1/sessionname.json')

# Generated at 2022-06-21 14:53:04.028455
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.args import HTTPieArgumentParser

    parser = HTTPieArgumentParser()
    request_headers = parser.parser_kwargs['request_headers']
    request_headers.update({'Content-Encoding':'myEncoding', 'If-Match':'*'})

    session = Session(path='test')
    session.update_headers(request_headers)

    assert session.headers == {'Content-Encoding':'myEncoding'}

# Generated at 2022-06-21 14:53:10.958982
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./test.json')
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Cookie': 'foo=bar; session=1', 'Content-Type': 'text/plain'})
    assert session.headers == {'User-Agent': 'HTTPie/0.9.9', 'Content-Type': 'text/plain'}
    assert session.cookies == {}
    assert session['cookies'] == {'foo': {'value': 'bar'}, 'session': {'value': '1'}}

# Generated at 2022-06-21 14:53:18.153159
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = Path(__file__)
    session = Session(path)
    session.update_headers({'aa': 'bb', 'cc': 'dd', "": "test", 'User-Agent': 'test', 'content-type': 'test'})
    print(session['headers'])
    assert session['headers'] == {'aa': 'bb', 'cc': 'dd'}

test_Session_update_headers()



# Generated at 2022-06-21 14:53:26.059613
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("/")
    request_headers = {
        'Content-Type': 'application/json'
    }
    session.update_headers(request_headers)
    assert session['headers'] == {}

    request_headers = {
        'User-Agent': 'HTTPie/0.9.2'
    }
    session.update_headers(request_headers)
    assert session['headers'] == {}

    request_headers = {
        'Host': 'httpbin.org',
        'Accept': 'application/json',
        'Cache-Control': 'max-age=60'
    }
    session.update_headers(request_headers)
    assert session['headers'] == request_headers

    request_headers = {
        'Cookie': 'theme=light'
    }
    session.update_headers(request_headers)

# Generated at 2022-06-21 14:53:30.672459
# Unit test for constructor of class Session
def test_Session():
    data = {
        "headers": {
            "X-Header": "X-Value"
        },
        "cookies": {},
        "auth": {
            "type": None,
            "username": None,
            "password": None
        }
    }
    session = Session("/tmp/test")
    assert session == data


# Generated at 2022-06-21 14:53:38.538764
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('~/.httpie/sessions/localhost/my_session.json')
    request_headers = RequestHeadersDict({'Content-Type': 'text/html', 'set-cookie': 'Cookie1=a1; Cookie2=a2'})
    session.update_headers(request_headers)

    assert session['headers'] == {'content-type': 'text/html'}
    assert session['cookies'] == {'cookie1': {'value': 'a1'}, 'cookie2': {'value': 'a2'}}

# Generated at 2022-06-21 14:53:52.521445
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(DEFAULT_CONFIG_DIR)
    session_name = "test"
    host = "test.example.com"
    url = "http://test.example.com"
    session = get_httpie_session(config_dir, session_name, host, url)



# Generated at 2022-06-21 14:53:56.965842
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session(DEFAULT_SESSIONS_DIR, "123", '', 'http://example.com/')

    print(VALID_SESSION_NAME_PATTERN)
    print(SESSION_IGNORED_HEADER_PREFIXES)


if __name__ == "__main__":
    test_get_httpie_session()

# Generated at 2022-06-21 14:54:02.742553
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        Path('config_dir'), 'test_session', 'localhost', 'http://localhost/test.txt'
    )

    assert type(session) == Session
    assert session.path == Path('config_dir/sessions/localhost/test_session.json')

    assert session.headers == {}
    assert session.cookies == {}
    assert session.auth == {}

# Generated at 2022-06-21 14:54:08.577115
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Test update_headers method of class Session
    """
    session = Session('~/.httpie/sessions/example.com/session.json')
    session.update_headers({'Set-Cookie': 'foo="bar"; Path=/; HttpOnly'})
    assert session['cookies'] == {'foo': {'value': 'bar'}}



# Generated at 2022-06-21 14:54:12.448598
# Unit test for constructor of class Session
def test_Session():
    a = Session('abc.json')
    a.load()
    print(a.path)
    print(a['headers'])
    print(a['auth'])
    print(a['cookies'])


if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-21 14:54:19.665061
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session_dir = Path('/tmp/httpie-test-dir')
    session_dir.mkdir()

    session = get_httpie_session(session_dir, 'test', 'localhost', 'http://localhost/')

    assert isinstance(session, Session)
    assert session.path == '/tmp/httpie-test-dir/sessions/localhost/test.json'

    session = get_httpie_session(session_dir, 'test', None, 'http://localhost/')

    assert isinstance(session, Session)
    assert session.path == '/tmp/httpie-test-dir/sessions/localhost/test.json'

    session = get_httpie_session(session_dir, 'test', 'localhost:1234', 'http://localhost:1234/')

    assert isinstance(session, Session)

# Generated at 2022-06-21 14:54:21.842195
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sess = get_httpie_session('.', 'hello', 'http://localhost/', '/')
    assert sess.headers == {}

# Generated at 2022-06-21 14:54:26.093335
# Unit test for constructor of class Session
def test_Session():
    session_test = Session('test.json')
    assert session_test['headers'] == {}
    assert session_test['cookies'] == {}
    assert session_test['auth'] == {'type': None,
                                    'username': None,
                                    'password': None}

# Generated at 2022-06-21 14:54:33.135407
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('mockFile')
    session.cookies = RequestsCookieJar()
    session['cookies']['test1'] = {}
    session['cookies']['test2'] = {}
    assert session['cookies'] == {'test1': {}, 'test2': {}}
    session.remove_cookies(['test2'])
    assert session['cookies'] == {'test1': {}}



# Generated at 2022-06-21 14:54:37.798569
# Unit test for constructor of class Session
def test_Session():
    # name_session not in assignment of dir_session
    dir_session = 'test_dir'
    session = Session(dir_session)
    assert session.__class__ == Session

    # name_session in assignment of dir_session
    dir_session = 'test_dir/test_session'
    session = Session(dir_session)
    assert session.__class__ == Session