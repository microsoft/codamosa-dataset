

# Generated at 2022-06-21 14:45:08.232447
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    headers = RequestHeadersDict({
        'Accept': 'text',
        'Content-Length': '5'
    })
    session.update_headers(headers)
    assert session.headers == RequestHeadersDict({'Accept': 'text'})
    headers = RequestHeadersDict({
        'Accept': 'text',
        'User-Agent': 'HTTPie/1.0.0',
        'Cookie': 'cookie1=value1'
    })
    session.update_headers(headers)
    assert session.headers == RequestHeadersDict({'Accept': 'text'})
    assert session.cookies == RequestsCookieJar([create_cookie(
        'cookie1', 'value1')])



# Generated at 2022-06-21 14:45:18.890567
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'https://httpie.org/get'
    session_name = 'test'
    session_path = Path(__file__).parent / 'httpie' / 'test_session'
    session_path.mkdir(parents=True, exist_ok=True)
    config_dir = session_path

    # https://httpbin.org/get?foo=bar
    session = get_httpie_session(config_dir, session_name, None, url)
    session.update_headers({'foo': 'bar'})
    print(session.headers)
    print(session.cookies)
    #session.save()

    # https://httpbin.org/get
    session = get_httpie_session(config_dir, session_name, None, url)
    print(session.headers)

# Generated at 2022-06-21 14:45:28.301900
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    def tString(s):
        return s.encode('utf8') if type(s) is str else s

    session = Session('test.json')
    session.update_headers(RequestHeadersDict({'content-type': 'text/html'}))
    assert session.headers == {}

    session = Session('test.json')
    session.update_headers(RequestHeadersDict({'content-type': 'text/html'}))
    assert session.headers == {}
    session.update_headers(RequestHeadersDict({'content-type': 'text/plain'}))
    assert session.headers == {}

    session = Session('test.json')
    session.update_headers(RequestHeadersDict({'if-modified-since': '15 Oct 19'}))
    assert session.headers == {}


# Generated at 2022-06-21 14:45:30.940424
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('../tests/fixtures/sessions/session1.json')
    session.remove_cookies('password')
    assert 'password' not in session['cookies']

# Generated at 2022-06-21 14:45:39.467787
# Unit test for function get_httpie_session
def test_get_httpie_session():
    dir = Path(DEFAULT_SESSIONS_DIR)
    dir.mkdir(parents=True, exist_ok=True)
    os.chdir(dir)
    
    name = 'test_session'
    host = '127.0.0.1'
    url = 'http://127.0.0.1/test'

    # Test file exists
    session = get_httpie_session(dir, name, None, None)
    assert os.path.isfile(session.path), 'Session file doesn\'t exist'
    assert session.path == dir / name / 'test_session.json', 'Session file doesn\'t exist'

    # Test file doesn't exist
    name = 'test_session'
    host = '127.0.0.1'

# Generated at 2022-06-21 14:45:41.640525
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session(DEFAULT_SESSIONS_DIR, 'foo', 'bar', 'baz')


# Generated at 2022-06-21 14:45:46.140787
# Unit test for constructor of class Session
def test_Session():
    session = Session('/path/to/session')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-21 14:45:49.525570
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test_get_httpie_session', None, 'http://localhost')
    assert session
    session.save()

# Generated at 2022-06-21 14:45:50.579579
# Unit test for constructor of class Session
def test_Session():
    pass


# Generated at 2022-06-21 14:45:55.963349
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('p')
    s.load()
    s.update_headers(RequestHeadersDict([('Accept', 'value')]))
    s.update_headers(RequestHeadersDict([('Accept-Encoding', 'value')]))
    s.update_headers(RequestHeadersDict([('Authorization', 'value')]))

    assert s.headers == RequestHeadersDict([
        ('Accept', 'value'),
        ('Accept-Encoding', 'value'),
    ])

# Generated at 2022-06-21 14:46:07.978606
# Unit test for method update_headers of class Session

# Generated at 2022-06-21 14:46:14.065858
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # This function is a stand-in for the get_httpie_session function.
    # The test_sessions.py file is given the name of this function, and then
    # uses the same arguments to test the real get_httpie_session function.
    def get_httpie_session(
        config_dir: Path,
        session_name: str,
        host: Optional[str],
        url: str,
    ) -> 'Session':
        if os.path.sep in session_name:
            path = os.path.expanduser(session_name)
        else:
            hostname = host or urlsplit(url).netloc.split('@')[-1]

# Generated at 2022-06-21 14:46:18.435210
# Unit test for constructor of class Session
def test_Session():
    url = 'www.google.com'
    path = './tests/sessions/google'
    session = Session(path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-21 14:46:26.210550
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = "test-session"
    host = "https://httpbin.org"
    url = "https://httpbin.org/get"
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session["headers"] == {}
    assert session["cookies"] == {}
    assert session["auth"] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-21 14:46:36.050055
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/path')
    request_headers = RequestHeadersDict(
        {
            'Content-Type': 'application/json',
            'If-Modified-Since': 'Sat, 29 Oct 1994 19:43:31 GMT',
            'User-Agent': 'HTTPie/0.6.0',
            'Accept': '*/*',
            'Cookie': 'type=ninja',
        }
    )

    session.update_headers(request_headers)

    assert session.headers == {
        'Accept': '*/*',
    }

    assert session.auth is None
    assert session.cookies == {'type': 'ninja'}

    session.cookies = {}

# Generated at 2022-06-21 14:46:43.446773
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session(f"{SESSIONS_DIR_NAME}.json")
    cookies = {"key1": {"value": "value1"}, "key2": {"value": "value2"}}
    sess['cookies'] = cookies
    print(sess['cookies'])
    sess.remove_cookies(["key2"])
    assert sess['cookies'] == {"key1": {"value": "value1"}}
test_Session_remove_cookies()

# Generated at 2022-06-21 14:46:50.068404
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = 'tests/fixtures/sessions/session-1.json'
    session = Session(path)
    session.load()
    session.remove_cookies(['sessionid', 'sessionid2'])
    assert 'sessionid' not in session['cookies']
    assert 'sessionid2' not in session['cookies']
    assert 'sessionid3' in session['cookies']
    session.save()

# Generated at 2022-06-21 14:46:51.172832
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert True

# Generated at 2022-06-21 14:46:56.781526
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path= 'test')
    session['headers'] = {'Cookie': 'a=1', 'User-Agent': 'b=2'}
    session.update_headers(RequestHeadersDict({'Cookie': 'c=1', 'User-Agent': 'HTTPie/test'}))
    assert session['headers'] == {'Cookie': 'c=1', 'User-Agent': 'b=2'}

# Generated at 2022-06-21 14:47:04.754966
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/foo/.httpie')
    session_name = 'bar'
    host = None
    url = 'http://foobar.com/foo/bar'

    # expect
    exp_path = config_dir / SESSIONS_DIR_NAME / 'foobar_com' / 'bar.json'
    # act
    act_path = get_httpie_session(config_dir, session_name, host, url).path
    # assert
    assert act_path == exp_path

# Generated at 2022-06-21 14:47:22.701318
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session(Path('~/.httpie/'), 'session_name', None, 'http://www.google.com')


# Generated at 2022-06-21 14:47:23.759970
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass



# Generated at 2022-06-21 14:47:36.040496
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    c = Session('a')
    c.update_headers({'dd':'ss'})
    assert c.headers == {'dd':'ss'}
    assert c.cookies == RequestsCookieJar()
    c.update_headers({'cookie':'dd=ss'})
    assert c.headers == {'dd':'ss'}
    assert c.cookies in [RequestsCookieJar(), RequestsCookieJar({'dd': 'ss'})]
    c.update_headers({'Cookie':'a=b'})
    assert c.headers == {'dd':'ss'}
    assert c.cookies in [RequestsCookieJar({'dd': 'ss'}), RequestsCookieJar({'a': 'b'})]
    c.update_headers({'Dd':'a'})


# Generated at 2022-06-21 14:47:42.918622
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("/home/nishant/foo.json")
    cookies = {'name1': {'value': 'something1'}, 'name2': {'value': 'something2'}}
    session['cookies'] = cookies
    names_to_be_removed = ['name1', 'name2']
    session.remove_cookies(names_to_be_removed)
    assert len(session['cookies']) == 0

# Generated at 2022-06-21 14:47:45.621745
# Unit test for constructor of class Session
def test_Session():
    s = Session('/home/sm/Desktop/header.json')
    assert type(s) == Session

# Generated at 2022-06-21 14:47:46.268803
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session()

# Generated at 2022-06-21 14:47:56.306585
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from datetime import datetime, timezone, timedelta
    from httpie.compat import is_py36

    session = Session('.')
    request_headers = {'X-Foo': 'bar'}
    session.update_headers(request_headers)
    assert session['headers'] == {'X-Foo': 'bar'}
    assert request_headers == {}

    session = Session('.')
    request_headers = {'content-type': 'text/plain; charset=UTF8'}
    session.update_headers(request_headers)
    assert session['headers'] == {}
    assert request_headers == {'content-type': 'text/plain; charset=UTF8'}

    session = Session('.')

# Generated at 2022-06-21 14:48:07.529859
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = "http://www.example.com"
    parsed_url = urlsplit(url)
    # Test version 1: session_name is file path
    session_name = "test.json"
    session = get_httpie_session(DEFAULT_CONFIG_DIR, session_name, None, url)
    assert session.__dict__["path"] == Path(session_name)
    # Test version 2: host is provided with session_name
    session_name = "test2.json"
    host = parsed_url.netloc
    session = get_httpie_session(DEFAULT_CONFIG_DIR, session_name, host, url)

# Generated at 2022-06-21 14:48:12.885227
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test/test.json")
    session['cookies'] = {"cookie1": "cookie1value", "cookie2": "cookie2value"}
    session.remove_cookies(("cookie2",))
    assert session['cookies'] == {"cookie1": "cookie1value"}
    assert isinstance(session['cookies'], dict)

# Generated at 2022-06-21 14:48:17.770393
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(config_dir=DEFAULT_CONFIG_DIR)
    session['cookies'] = {'name': {'value': 'value'}}
    assert session['cookies'] == {'name': {'value': 'value'}}
    session.remove_cookies(['name'])
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:48:44.873776
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='./')
    cookies = {
        'name1': {
            'value': 1,
            'path': 'toto',
            'expires': 2,
            'secure': 3,
        },
        'name2': {
            'value': 4,
            'path': 'toto',
            'expires': 5,
            'secure': 6,
        }
    }
    session['cookies'] = cookies
    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'] == {'name2': {
        'value': 4,
        'path': 'toto',
        'expires': 5,
        'secure': 6,
    }}

# Generated at 2022-06-21 14:48:46.074923
# Unit test for constructor of class Session
def test_Session():
    pass


# Generated at 2022-06-21 14:48:52.237102
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/path')
    session['cookies'] = {
        'cookie1': {'value': 'cookie1-val'},
        'cookie2': {'value': 'cookie2-val'},
        'cookie3': {'value': 'cookie3-val'}
     }

    session.remove_cookies(['cookie2', 'cookie3'])
    assert session['cookies'] == {'cookie1': {'value': 'cookie1-val'}}

# Generated at 2022-06-21 14:49:01.498706
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path = 'path')
    s['cookies'] = {'c1': 'v1', 'c2': 'v2'}
    s.remove_cookies(['c1'])
    assert (s['cookies'] == {'c2': 'v2'})
    s.remove_cookies(['c2'])
    assert (s['cookies'] == {})
    s['cookies'] = {'c1': 'v1', 'c2': 'v2'}
    s.remove_cookies(['c1', 'c2'])
    assert (s['cookies'] == {})

# Generated at 2022-06-21 14:49:06.106870
# Unit test for constructor of class Session
def test_Session():
    s = Session('abc')
    assert(s.get('headers') == {})
    assert(s.get('cookies') == {})
    assert(s.get('auth') == {'type': None, 'username': None, 'password': None})


# Generated at 2022-06-21 14:49:06.770097
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass

# Generated at 2022-06-21 14:49:10.351323
# Unit test for constructor of class Session
def test_Session():
    default_sessions_dir = DEFAULT_SESSIONS_DIR / 'test.json'
    session = Session(default_sessions_dir)
    assert session.path == Path(default_sessions_dir)



# Generated at 2022-06-21 14:49:17.855638
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_cookies = {'cookie1': {'value': 'value'},
                    'cookie2': {'value': 'value'},
                    'cookie3': {'value': 'value'}}
    test_session = Session('test_session')
    test_session['cookies'] = test_cookies
    assert test_session['cookies'] == test_cookies

    test_session.remove_cookies(['cookie1', 'cookie2'])
    expected_cookies = {'cookie3': {'value': 'value'}}
    assert test_session['cookies'] == expected_cookies


# Generated at 2022-06-21 14:49:29.050400
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    [{'name': 'name', 'value':'value'},..] and
    {'name': 'name', 'value':'value'} and
    {'name': 'name', 'value':'value', 'prefix':'prefix', 'anything':'anything'}
    are all valid ways to express one header. 
    """
    s = Session(path='test')
    s.update_headers(request_headers=[{'name': 'a', 'value':'1'}, {'name': 'b', 'value':'2'}])
    assert(s['headers']['a'] == '1')
    assert(s['headers']['b'] == '2')
    s.update_headers(request_headers=[{'name': 'a', 'value':'1'}])

# Generated at 2022-06-21 14:49:37.089236
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = get_httpie_session(
        DEFAULT_CONFIG_DIR,
        'test',
        'httpbin.org',
        'http://httpbin.org/get'
    )
    assert isinstance(config_dir, Session)
    assert config_dir['headers'] == {}
    assert config_dir['cookies'] == {}
    assert config_dir['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-21 14:50:21.457116
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = HeadersDict({
        'user-agent': 'HTTPie/0.9.6'
    })
    session = Session('/home/foo/bar.json')
    session.update_headers(headers)
    assert session.headers == {}

# Generated at 2022-06-21 14:50:33.864441
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('.')
    session.update_headers({'foo': 'bar', 'baz': 'abc'})
    assert session.headers() == {'foo': 'bar',
                                 'baz': 'abc'}

    session.update_headers({'foo': None, 'baz': 'xyz'})
    assert session.headers() == {'baz': 'xyz'}

    session.update_headers({'Cookie': 'pie=tasty'})
    assert 'Cookie' not in session.headers()
    assert session.cookies() == {'pie': 'tasty'}

    session.update_headers({'Cookie': 'cookie=sweet'})
    assert session.cookies() == {'pie': 'tasty',
                                 'cookie': 'sweet'}


# Generated at 2022-06-21 14:50:40.270107
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    headers = {'key': 'value', 'Cookie': 'cookie=value'}
    request_headers = RequestHeadersDict(headers)
    session.update_headers(request_headers)
    assert dict(session.headers) == {'key': 'value'}
    assert dict(session['cookies']) == {'cookie': {'value': 'value'}}

# Generated at 2022-06-21 14:50:48.055590
# Unit test for constructor of class Session
def test_Session():
    import json
    import os
    import requests
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp()
    temp_session_path = os.path.join(temp_dir, 'test.json')
    test_session = {
        'headers': {
            'Accept': 'text/json'
        },
        'cookies': {
            'test_cookie': {
                'value': 'test_value',
                'path': '/',
                'domain': '.example.com',
                'secure': True,
                'expires': 1800
            }
        },
        'auth': {
            'type': 'basic',
            'username': 'test_username',
            'password': 'test_password'
        }
    }

# Generated at 2022-06-21 14:50:49.094785
# Unit test for constructor of class Session
def test_Session():
    assert Session('aa')


# Generated at 2022-06-21 14:50:54.710965
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(None, 'my-session', None, 
                              'https://httpie.org').headers == {}
    assert get_httpie_session(None, 'my-session', None, 
                              'https://httpie.org').cookies == RequestsCookieJar()


# Generated at 2022-06-21 14:50:59.539247
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    jar = RequestsCookieJar()
    jar.set('a', 'a')
    jar.set('b', 'b')
    session = Session('testSession.json')
    session.cookies = jar
    session.remove_cookies(['c', 'a'])
    assert session['cookies'] == {'b': {'value': 'b'}}

# Generated at 2022-06-21 14:51:10.175217
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='')

    assert len(session['cookies']) == 0

    session['cookies']['TestCookie'] = {}
    session['cookies']['TestCookie2'] = {}

    assert len(session['cookies']) == 2
    session.remove_cookies(['TestCookie'])

    assert len(session['cookies']) == 1
    assert 'TestCookie' not in session['cookies']
    assert 'TestCookie2' in session['cookies']

    session.remove_cookies(['TestCookie2'])

    assert 'TestCookie2' not in session['cookies']
    assert len(session['cookies']) == 0



# Generated at 2022-06-21 14:51:13.073917
# Unit test for constructor of class Session
def test_Session():
    session = Session("data/session.json")
    assert session['headers'] != None
    assert session['cookies'] != None
    assert session['auth'] != None


# Generated at 2022-06-21 14:51:19.945392
# Unit test for constructor of class Session
def test_Session():
    s = Session('./session.json')
    assert s['auth'] == {'type': None, 'username': None, 'password': None}
    assert s['headers'] == {}
    assert s['cookies'] == {}
    s = Session('./session_1.json')
    assert s['auth'] == {'type': None, 'username': None, 'password': None}
    assert s['headers'] == {}
    assert s['cookies'] == {}



# Generated at 2022-06-21 14:52:50.964690
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from .sessions import Session
    session = Session(path = '/path')
    session.update({'headers': {}, 'cookies': {}})
    session.update_headers({'Cookie': 'a=b; c=d'})
    session.remove_cookies(('a', 'e'))
    assert session.get('cookies') == {'c': {'value': 'd'}}

# Generated at 2022-06-21 14:52:55.791739
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/some/path')

    session.cookies = RequestsCookieJar()
    session.cookies.set('foo', 'bar', path='/')

    assert 'foo' in session.cookies
    session.remove_cookies(['foo'])
    assert 'foo' not in session.cookies



# Generated at 2022-06-21 14:53:04.078825
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('httpbin.org')
    s['cookies'] = {'a': 'b'}
    assert s['cookies'] == {'a': 'b'} # sanity check
    s.remove_cookies(['a'])
    assert s['cookies'] == {}

    s = Session('httpbin.org')
    s['cookies'] = {'a': 'b', 'c': 'd'}
    assert s['cookies'] == {'a': 'b', 'c': 'd'} # sanity check
    s.remove_cookies(['a', 'b', 'c'])
    assert s['cookies'] == {'c': 'd'}

# Generated at 2022-06-21 14:53:09.987237
# Unit test for constructor of class Session
def test_Session():
    session = Session('/home/louis/.config/httpie/sessions/host_port/session_name.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}
    assert session.path == '/home/louis/.config/httpie/sessions/host_port/session_name.json'



# Generated at 2022-06-21 14:53:17.970882
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(Path('~/.httpie'), 'testing', 'localhost', 'http://www.google.com:8080/index.html')
    print(session)
    session['headers']['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.89 Safari/537.36'
    session.store()
    print(session)

# Generated at 2022-06-21 14:53:25.915538
# Unit test for constructor of class Session
def test_Session():
    # test for session name
    session_name = 'sess1'
    host = 'http://www.example.com'
    url = host + '/'
    config_dir = Path(DEFAULT_CONFIG_DIR)
    session = get_httpie_session(config_dir, session_name, host, url)
    path = Path(config_dir / SESSIONS_DIR_NAME / 'www_example_com' / f'{session_name}.json')
    assert session.path == path
    assert VALID_SESSION_NAME_PATTERN.match(session_name)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-21 14:53:26.467040
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert True

# Generated at 2022-06-21 14:53:31.708281
# Unit test for constructor of class Session
def test_Session():
    session = Session(path = Path('~/httpie/sessions/127.0.0.1_8080/basic.json'))
    print(session)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-21 14:53:42.375654
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from tempfile import TemporaryDirectory
    import json

    with TemporaryDirectory() as tempdir:
        path = os.path.join(tempdir, 'test.json')
        session = {'key': 'value'}
        with open(path, 'w') as f:
            json.dump(session, f)

        # without host
        session_name = 'test'
        url = 'http://example.com'
        parsed_session = get_httpie_session(Path(tempdir), session_name, None, url)
        assert parsed_session['key'] == 'value'

        # with host
        session_name = 'test'
        url = 'http://example.com'
        host = 'example.com'
        parsed_session = get_httpie_session(Path(tempdir), session_name, host, url)


# Generated at 2022-06-21 14:53:49.276130
# Unit test for constructor of class Session
def test_Session():
    test = Session('tests\\sessions\\test.json')
    #Test that the __init__ function is not broken
    assert(test['headers'] == {})
    assert(test['auth'] == {'type': None, 'username': None, 'password': None})
    assert(test['cookies'] == {})
    #Test that the path is truly stored in the object
    assert(test.path == Path('tests\\sessions\\test.json'))
