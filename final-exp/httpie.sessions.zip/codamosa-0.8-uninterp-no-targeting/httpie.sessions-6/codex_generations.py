

# Generated at 2022-06-21 14:45:02.986182
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict()
    request_headers['Accept'] = 'application/json'
    request_headers['Content-Length'] = '3'
    session = Session
    session.update_headers(request_headers)
    assert session.headers['Accept'] == 'application/json'

# Generated at 2022-06-21 14:45:05.947953
# Unit test for constructor of class Session
def test_Session():
    s = Session('/home/user/python/httpie/config/sessions/localhost/se.json')
    s.load()
    print(s)

# Generated at 2022-06-21 14:45:13.104776
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    actualSession = Session("")
    actualSession["headers"] = {"header1":"value1", "header2":"value2"}
    h1 = {'header1': 'newValue', "header3":"value3", "header4":"value4"}
    actualSession.update_headers(h1)
    expectedSesion = Session("")
    expectedSesion["headers"] = {"header1":"newValue", "header2":"value2", "header3":"value3", "header4":"value4"}
    assert actualSession == expectedSesion

# Generated at 2022-06-21 14:45:15.014526
# Unit test for function get_httpie_session
def test_get_httpie_session():
    f = get_httpie_session('a', 'b', 'c', 'd')
    assert f == {}

# Generated at 2022-06-21 14:45:17.521291
# Unit test for constructor of class Session
def test_Session():
    session = Session('t/my_session.json')
    session.headers = {}
    session.cookies = {}
    session.auth = {}

# Generated at 2022-06-21 14:45:22.868855
# Unit test for constructor of class Session
def test_Session():
    sess = Session('httpie/doc')
    assert sess['headers'] == {}
    assert sess['cookies'] == {}
    assert len(sess['auth']) == 3
    assert sess['auth']['type'] == None
    assert sess['auth']['username'] == None
    assert sess['auth']['password'] == None

# Generated at 2022-06-21 14:45:26.485693
# Unit test for constructor of class Session
def test_Session():
    path = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'slack.json'
    # assert os.path.isfile(path) is False
    Session(path)

if __name__ == "__main__":
    test_Session()

# Generated at 2022-06-21 14:45:33.742287
# Unit test for constructor of class Session
def test_Session():
    a = Session('sessions/default.json')
    assert a['auth']['type'] == None
    assert a['auth']['username'] == None
    assert a['auth']['password'] == None
    assert a['cookies'] == {}
    assert a['headers'] == {}
    assert a.helpurl == 'https://httpie.org/doc#sessions'
    assert a.about == 'HTTPie session file'
    assert a.path == 'sessions/default.json'
    assert a.headers['Content-Type'] == 'text/html; charset=utf-8'
    assert a.headers['Content-Length'] == '0'
    assert a.headers['Content-Length'] != '1'
    assert a.headers['Accept'] == 'title'

# Generated at 2022-06-21 14:45:37.036729
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {'foo': 'bar'}
    session = Session(path='')
    session.headers = headers
    headers['foo'] = 'bar2'
    session.update_headers(headers)
    assert session.headers['foo'] == 'bar2'

# Generated at 2022-06-21 14:45:40.347528
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(
        Path('httpie'),
        'test',
        'http://127.0.0.1',
        'http://127.0.0.1/test'
    )

# Generated at 2022-06-21 14:45:56.076459
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    assert {} == session['headers']

    session.update_headers({'Host': 'example.org'})
    assert {'Host': 'example.org'} == session['headers']

    session.update_headers({'Host': 'example.com'})
    assert {'Host': 'example.com'} == session['headers']

    session.update_headers({'Cookie': 'foo=bar'})
    assert {'Host': 'example.com', 'Cookie': 'foo=bar'} == session['headers']
    assert {'foo': {'value': 'bar'}} == session['cookies']

    session.update_headers({'If-Match': 'foo'})
    assert {'Host': 'example.com', 'Cookie': 'foo=bar'} == session['headers']

# Generated at 2022-06-21 14:46:01.858638
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    session.remove_cookies(['cookie1'])
    cookies = session['cookies']
    assert not 'cookie1' in cookies


# Generated at 2022-06-21 14:46:07.314000
# Unit test for constructor of class Session
def test_Session():
    c = Session(path="test_Session.json")
    assert c['headers'] == {}, "headers should be empty"
    assert c['cookies'] == {}, "cookies should be empty"
    assert c['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }, "auth should be empty"


# Generated at 2022-06-21 14:46:10.510381
# Unit test for constructor of class Session
def test_Session():
    x = Session('hello');
    assert x.path == 'hello'
    assert x['headers'] == {}
    assert x['cookies'] == {}
    assert x['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-21 14:46:20.491501
# Unit test for constructor of class Session
def test_Session():
    try:
        from httpie.compat import is_windows
    except:
        # Windows is not supported at the moment
        pass
    dir_path = os.path.dirname(os.path.realpath(__file__))
    if not is_windows:
        if os.geteuid() != 0:
            assert get_httpie_session(dir_path, 'localhost_8181', 'localhost', 'http://localhost:8181')
        else:
            assert get_httpie_session(dir_path, 'localhost_8181', 'localhost', 'http://localhost:8181')
    else:
        assert get_httpie_session(dir_path, 'localhost_8181', 'localhost', 'http://localhost:8181')

# Generated at 2022-06-21 14:46:32.402044
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Create test session
    config_dir = Path(os.path.expanduser("~")) / ".httpie"
    session_name = "test_session"
    host = "http://httpbin.org"
    url = "http://httpbin.org/get"

    try:
        os.mkdir(os.path.join(config_dir, "sessions"))
    except Exception:
        pass
    try:
        os.mkdir(os.path.join(config_dir, "sessions", "httpbin_org"))
    except Exception:
        pass
    session = get_httpie_session(config_dir, session_name, host, url)

    # Make sure session exists

# Generated at 2022-06-21 14:46:37.329092
# Unit test for function get_httpie_session
def test_get_httpie_session():
    path = get_httpie_session.__code__.co_filename
    os.system("pytest tests/test_sessions.py::test_get_httpie_session")
    if os.path.exists("tests/.coverage"):
        os.remove("tests/.coverage")


# Generated at 2022-06-21 14:46:49.237979
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('Dummy path')
    test_request_headers = RequestHeadersDict([('User-Agent', 'httpie/1.0.2'),
                                               ('Authorization', 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='),
                                               ('Content-Type', 'application/json'),
                                               ('If-Modified-Since', 'Sat, 29 Oct 1994 19:43:31 GMT'),
                                               ('If-Match', '"737060cd8c284d8af7ad3082f209582d"')])
    session.update_headers(test_request_headers)

# Generated at 2022-06-21 14:46:53.479099
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path="test_Session_update_headers")
    session.update_headers({"Content-type": "application/json"})
    assert session.headers == {}

    session.update_headers({"Content-type": None})
    assert session.headers == {}

    session.update_headers({"Host": "host"})
    assert session.headers == {}

    session.update_headers({"Accept": "Accept"})
    assert session.headers == {"Accept": "Accept"}

    session.update_headers({"Accept": None})
    assert session.headers == {"Accept": None}

    session.update_headers({"User-Agent": "HTTPie/0.9.2"})
    assert session.headers == {"Accept": None}


# Generated at 2022-06-21 14:46:55.330086
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, 'test', None, 'https://httpbin.org')

# Generated at 2022-06-21 14:47:07.524260
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://localhost:8080/'
    path = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', None, url)
    path_str = str(path)
    assert path_str == f'{str(DEFAULT_SESSIONS_DIR)}/{SESSIONS_DIR_NAME}/localhost/test.json'


# Generated at 2022-06-21 14:47:15.848353
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session["cookies"] = {'c1': {'value': 'v1'},'c2': {'value': 'v2'}}
    session.remove_cookies(['c2'])
    # Test the case of no cookies in session
    session.remove_cookies(['c2'])

    assert session['cookies'] == {'c1': {'value': 'v1'}}


# Generated at 2022-06-21 14:47:22.981865
# Unit test for constructor of class Session
def test_Session():
    httpie_session = Session('~/.httpie/sessions/www.google.com/google.json')
    assert isinstance(httpie_session['headers'], dict)
    assert isinstance(httpie_session['cookies'], dict)
    assert isinstance(httpie_session['auth']['type'], None) #type is None
    assert isinstance(httpie_session['auth']['username'], None) #username is None
    assert isinstance(httpie_session['auth']['password'], None) #password is None


# Generated at 2022-06-21 14:47:31.676571
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import pprint
    session_dict = {'headers': {'Accept': 'application/json'}, 'cookies': {}}
    session = Session('')
    session.update(session_dict)
    pprint.pprint(session)

    request_headers = [('Accept', 'text/json'), ('Content-Type', 'application/json'), ('Cookie', 'session_id=123456')]
    session.update_headers(request_headers)
    pprint.pprint(session)


if __name__ == '__main__':
    test_Session_update_headers()

# Generated at 2022-06-21 14:47:44.155626
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import tempfile
    from httpie.plugins import plugin_manager
    from httpie.input import ParseError
    from httpie.auth import AuthPlugin

    class FakeAuthPlugin(AuthPlugin):
        name = 'fake'
        auth_type = 'fake'

        def get_auth(self, username: str, password: str):
            return (username, password)

        def get_auth_from_url(self, url: str):
            return url

    plugin_manager.register(FakeAuthPlugin)

    class TestCase:
        def __init__(self, input_headers, output_headers):
            self.input_headers = input_headers
            self.output_headers = output_headers

        def run(self, session):
            session.update_headers(self.input_headers)
            assert session.headers.to_dict()

# Generated at 2022-06-21 14:47:51.190542
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test case 1
    s = Session('test')
    s['cookies'] = {'key1': '1', 'key2': '2', 'key3': '3'}
    names = ['key1', 'key2']
    s.remove_cookies(names)
    expacted_cookies = {'key3': '3'}
    assert s['cookies'] == expacted_cookies
    # Test case 2
    s = Session('test')
    s['cookies'] = {'key1': '1', 'key2': '2', 'key3': '3'}
    names = ['key1', 'key2', 'key3', 'key4']
    s.remove_cookies(names)
    expacted_cookies = {}
    assert s['cookies'] == expacted_cookies
   

# Generated at 2022-06-21 14:47:56.097196
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    data = {1: 'a', 2: 'b', 3: 'c'}
    headers = RequestHeadersDict(data)
    session = Session('sessions/test')
    session.update_headers(headers)
    assert session.headers == headers



# Generated at 2022-06-21 14:48:03.247565
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir = Path('/home/joe/.config')
    session_name = 'hello'
    url = 'https://www.google.com'
    sessions = get_httpie_session(config_dir, session_name, host=None, url=url)
    cookies = {'foo': {'value': 'bar'}}
    sessions['cookies'] = cookies
    name_to_remove = 'foo'
    sessions.remove_cookies([name_to_remove])
    assert sessions['cookies'] == {}

# Generated at 2022-06-21 14:48:06.669027
# Unit test for constructor of class Session
def test_Session():
    path = os.path.join(DEFAULT_CONFIG_DIR, SESSIONS_DIR_NAME, 'localhost')
    session = Session(path)
    session.load()


# Generated at 2022-06-21 14:48:12.257492
# Unit test for constructor of class Session
def test_Session():
    s = Session('path')
    assert len(s['headers']) == 0
    assert len(s['cookies']) == 0
    assert len(s['auth']) == 3
    assert s['auth']['type'] == None
    assert s['auth']['username'] == None
    assert s['auth']['password'] == None

# Generated at 2022-06-21 14:48:24.666974
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json
    session = Session('./test_file')
    session['cookies'] = {'session': {'value': '123456789'}, 'httpie': {'value': 'abcdef'}}
    session.remove_cookies(['session'])
    assert session['cookies']['httpie']['value'] == 'abcdef'
    assert 'session' not in session['cookies']



# Generated at 2022-06-21 14:48:28.143745
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {"cookieA": {"value": "A"}}
    session = Session(path='test_session')
    session["cookies"] = cookies
    assert session["cookies"] == cookies
    session.remove_cookies(["cookieA"])
    assert session["cookies"] == {}

# Generated at 2022-06-21 14:48:35.769974
# Unit test for method update_headers of class Session

# Generated at 2022-06-21 14:48:43.532016
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Create a dummy directory structure
    config_dir = Path(__file__) / '../../../fixtures'
    session_name = 'get_httpie_session'
    host = 'localhost'
    url = 'http://localhost/get_httpie_session'

    # Get the session from the dummy directory
    session = get_httpie_session(
        config_dir,
        session_name,
        host,
        url
    )

    # Check if the session is valid
    assert session.path == Path(
        'fixtures/httpie/sessions/localhost/get_httpie_session.json'
    )
    assert session.name == 'get_httpie_session'
    assert session.headers == {}
    assert session.cookies == RequestsCookieJar()
    assert session.auth['type'] is None

# Generated at 2022-06-21 14:48:49.472955
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """
    This test case tests whether get_httpie_session() return a session object or not
    """

    config_dir = ''
    session_name = ''
    host = ''
    url = 'http://127.0.0.1'
    session = get_httpie_session(config_dir, session_name, host, url)

    assert isinstance(session, Session)

# Generated at 2022-06-21 14:48:52.681456
# Unit test for constructor of class Session
def test_Session():
    s = Session('C:/Users/Administrator/.config/httpie/sessions/github.com/httpie_github.session')
    assert s['headers'] == {}
    assert s.auth == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-21 14:48:53.929364
# Unit test for constructor of class Session
def test_Session():
    s = Session("session.json")
    assert s


# Generated at 2022-06-21 14:49:06.217174
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from httpie.config import BaseConfig
    from json import dump
    from os import remove
    from tempfile import gettempdir, NamedTemporaryFile
    from unittest import TestCase

    from httpie.sessions import Session, get_httpie_session
    from httpie.cli.dicts import RequestHeadersDict

    class Test_Session(TestCase):
        httpie_session = None

        def setUp(self):
            self.session_path = f'{gettempdir()}/httpie_session'
            self.httpie_session = Session(path=Path(self.session_path))

        def tearDown(self):
            if self.httpie_session.path.exists():
                self.httpie_session.save()
                self.httpie_session.path.un

# Generated at 2022-06-21 14:49:16.672140
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from collections import OrderedDict
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.output.streams import StdoutBytesIO
    from httpie.client import CLIClient
    from requests.cookies import RequestsCookieJar

    class TestSession(Session):
        def __init__(self):
            super().__init__('')

    def run(args, **kwargs):
        stdout = kwargs.pop('stdout', StdoutBytesIO())
        stderr = kwargs.pop('stderr', StdoutBytesIO())
        exit_status = kwargs.pop('exit_status', 0)

# Generated at 2022-06-21 14:49:24.971531
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = "https://httpbin.org/get?abc=def"
    default_config_dir = Path(DEFAULT_CONFIG_DIR)
    session = get_httpie_session(config_dir=default_config_dir, session_name="test", host=None, url=url)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-21 14:49:35.127618
# Unit test for function get_httpie_session
def test_get_httpie_session():
    expected = 'http://www.google.com'
    config_dir = Path("/user/home/")
    session_name = "default"
    host = None
    url = 'https://www.google.com'

    result = get_httpie_session(config_dir, session_name, host, url)
    assert result.path == config_dir / SESSIONS_DIR_NAME/"google.com"/"default.json"

# Generated at 2022-06-21 14:49:42.325255
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """ Remove cookies specified by name. """
    jar = RequestsCookieJar()
    jar.set_cookie(create_cookie('A', '1'))
    jar.set_cookie(create_cookie('B', '2'))
    jar.set_cookie(create_cookie('C', '3'))
    session = Session(Path("path"))
    session.cookies = jar
    session.remove_cookies(['A', 'C'])
    assert {'B': {'value': '2'}} == session.cookies.get_dict()

# Generated at 2022-06-21 14:49:54.275020
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from pathlib import Path
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    plugin_manager.get_auth_plugin('basic')().raw_auth='username:password'
    cookie1 = {'type': 'basic',
               'raw_auth': 'username:password'}

    cookie2 = {'type': 'basic',
               'raw_auth': 'username2:password2'}
    ses = Session(DEFAULT_CONFIG_DIR / 'sessions' / 'test.json')
    ses['cookies'] = [cookie1, cookie2]

    names = ['username:password', 'username2:password2']
    ses.remove_cookies(names)
    assert ses

# Generated at 2022-06-21 14:49:59.307815
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('test.json')
    s.update_headers({'a': 'b'})
    assert s.get('headers') == {'a': 'b'}
    s.update_headers({'a': 'b', 'c': None})
    assert s.get('headers') == {'a': 'b'}
    s.update_headers({'a': 'b', 'c': 'd'})
    assert s.get('headers') == {'a': 'b', 'c': 'd'}
    s.update_headers({'c': 'd', 'a': 'b', 'e': 'f'})
    assert s.get('headers') == {'a': 'b', 'c': 'd', 'e': 'f'}

# Generated at 2022-06-21 14:50:02.438368
# Unit test for constructor of class Session
def test_Session():
    path = Path('.httpie/sessions')
    test = Session(path)
    assert isinstance(test, BaseConfigDict)

    print(test)
    test['headers'] = {1: 2}
    assert test['headers'] == {1: 2}



# Generated at 2022-06-21 14:50:08.635104
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    cookie_bar = {'value': 'bar'}
    cookie_baz = {'value': 'baz'}
    cookie_zoo = {'value': 'zoo'}
    session = Session(Path('/tmp/test_session.json'))
    session['headers'] = {'foo': 'bar', 'bar': 'baz'}
    session['cookies'] = {'bar': cookie_bar, 'baz': cookie_baz}
    session.update_headers({'foo': None, 'bar': 'zoo', 'zoo': 'foo'})
    assert session['headers'] == {'zoo': 'foo'}
    assert session['cookies']['zoo'] == cookie_zoo
    assert session['cookies']['bar'] == cookie_bar

# Generated at 2022-06-21 14:50:13.359476
# Unit test for constructor of class Session
def test_Session():
    import os
    config_dir = os.path.expanduser('~/.config/httpie/sessions')
    session_name = 'local'
    host = 'localhost'
    url = 'https://httpbin.org/get'

    get_httpie_session(config_dir, session_name, host, url)

#test_Session()

# Generated at 2022-06-21 14:50:19.445725
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('../test')
    s['cookies'] = {'test': {'path': '/', 'domain': 'test.com', 'value': 'test'}}
    assert s['cookies']['test']['value'] == 'test'
    s.remove_cookies(['test'])
    assert 'test' not in s['cookies']


# Generated at 2022-06-21 14:50:25.067027
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Test that the session headers are updated with the request headers
    while ignoring certain name prefixes.

    :return:
    """
    session = Session('')
    session.update_headers({'User-Agent': 'HTTPie/0.9.9',
                            'content-type': 'application/json',
                            'Accept-Encoding': 'gzip,deflate',
                            'cookie': 'csrftoken=asdfghjkl1234567890'})
    print(session.headers)

    session.save()

# Generated at 2022-06-21 14:50:30.772900
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_cookies = {'cookies': {'name1': 'value1', 'name2': 'value2'}}
    session = Session(None)
    session.update(session_cookies)
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-21 14:50:54.807264
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test')
    session.update_headers({'Accept': 'application/json'})
    assert session.headers == {'Accept': 'application/json'}
    session.update_headers({})
    assert session.headers == {'Accept': 'application/json'}
    session.update_headers({'Accept': 'application/xml'})
    assert session.headers == {'Accept': 'application/xml'}
    session.update_headers({'Accept': None})
    assert session.headers == {}
    session.update_headers({'Accept': 'application/json', 'Content-Type': 'text/plain'})
    assert session.headers == {'Accept': 'application/json', 'Content-Type': 'text/plain'}

# Generated at 2022-06-21 14:50:58.294135
# Unit test for constructor of class Session
def test_Session():
    s = Session('test_file')
    assert(s['headers'] == {})
    assert(s['cookies'] == {})
    assert(s['auth'] == {'type': None, 'username': None, 'password': None})


# Generated at 2022-06-21 14:51:10.363323
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class Dict(dict): pass
    header = Dict({
        'host':'127.0.0.1',
        'accept':'application/json',
        'content-length':0,
        'connection':'keep-alive',
        'user-agent':'HTTPie/0.9.7',
        'authorization':'Basic xxx',
        'if-modified-since':'xxx',
        'content-type':'application/json',
        'COOKIE':'name=Mann; age=20'
    })
    h = RequestHeadersDict(header)
    s = Session('session.json')
    s.update_headers(h)
    assert s.headers['host'] == '127.0.0.1'
    assert s.headers['accept'] == 'application/json'
   

# Generated at 2022-06-21 14:51:14.540313
# Unit test for function get_httpie_session
def test_get_httpie_session():
  config_dir = Path("~/.config/httpie")
  session_name = 'test'
  host = None
  url = 'https://github.com/jakubroztocil/httpie'
  session = get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-21 14:51:16.708771
# Unit test for constructor of class Session
def test_Session():
    s = Session('.httper/sessions/localhost/default.json')
    print(s)

# Generated at 2022-06-21 14:51:20.275670
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'test', 'httpie.org', 'http://httpie.org/')
    session['headers'] = {}
    session['cookies'] = {}
    session.save()

# Generated at 2022-06-21 14:51:24.038990
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = "/home/m/"
    session_name = "test1"
    host = "test2" #can be None
    url = "http://test3/" #can be None

    #returns Session
    get_httpie_session(config_dir, session_name, host, url)


# Generated at 2022-06-21 14:51:33.431709
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)

    request_headers = {
        'name1': 'spam',
        'name2': 'eggs',
        'Content-Length': 123
    }

    session.update_headers(request_headers)

    assert 'name1' in session['headers']
    assert 'name2' in session['headers']
    assert 'Content-Length' not in session['headers']

    # These headers are required to be strings in ``RequestHeadersDict``
    # and encoding them needs to be done in ``Request``.
    assert type(session['headers']['name1']) is str



# Generated at 2022-06-21 14:51:37.422328
# Unit test for constructor of class Session
def test_Session():
    path = 'path'
    s = Session(path)
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-21 14:51:38.681388
# Unit test for constructor of class Session
def test_Session():
    assert Session({'headers': {}}).headers == {}



# Generated at 2022-06-21 14:52:03.848074
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'session', 'httpie.org', 'http://httpie.org')
    assert session is not None
    assert not isinstance(session, BaseConfigDict)

if __name__ == "__main__":
    test_get_httpie_session()

# Generated at 2022-06-21 14:52:09.740750
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Test get_httpie_session
    session_name = 'test_session_name'
    host = None
    url = 'http://www.google.com'
    config_dir = DEFAULT_SESSIONS_DIR / 'www_google_com'
    config_dir.mkdir(parents=True, exist_ok=True)
    session = get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-21 14:52:15.130499
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    config_dir = DEFAULT_SESSIONS_DIR / 'test'
    session_name = 'test'
    assert get_httpie_session(config_dir, session_name, 'host:port', 'http://host:port/')



# Generated at 2022-06-21 14:52:23.173224
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import os
    from pathlib import Path
    # test session_name is empty
    session_name = ""
    url = "http://www.example.com"
    try:
        assert get_httpie_session(Path(os.getcwd()), session_name, "", url)
    except ValueError as e:
        assert "The session name must be a non-empty string." in str(e)
    # test session_name is invalid
    session_name = "aaa bbb"
    try:
        assert get_httpie_session(Path(os.getcwd()), session_name, "", url)
    except ValueError as e:
        assert "The session name must be a non-empty string." in str(e)
    # test session_name is valid
    session_name = "my_session"
   

# Generated at 2022-06-21 14:52:32.240065
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.plugins.builtin import HTTPieUnixSocketPlugin
    from httpie.output.streams import UnsupportedEnvironment

    assert get_httpie_session(DEFAULT_CONFIG_DIR, 'test', '', 'http://example.com')

    # with unix socket url
    url = 'unixsocket:///path/to/socket.sock/resource'
    plugin = HTTPieUnixSocketPlugin()
    try:
        plugin.output_stream_class()
    except UnsupportedEnvironment:
        pass
    else:
        assert get_httpie_session(DEFAULT_CONFIG_DIR, 'test', '', url)

# Generated at 2022-06-21 14:52:42.740817
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    def check_headers(sess: Session, **kwargs):
        assert sess.headers.items() == kwargs.items()

    # Test headers
    sess = Session('/')
    sess['headers'] = RequestHeadersDict()
    req_headers = RequestHeadersDict()
    # Test ignored headers
    sec_headers = [
        'Content-Type',
        'Content-Length',
        'If-Match',
        'If-None-Match',
        'If-Modified-Since',
        'If-Unmodified-Since'
    ]
    for h in sec_headers:
        req_headers[h] = 'test'
    sess.update_headers(req_headers)
    assert sess.headers == RequestHeadersDict()
    # Test update_headers with cookie header
    req

# Generated at 2022-06-21 14:52:51.161923
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./session.json')
    session['cookies'] = {
        'foo': {'value': 'bar'},
        'baz': {'value': 'qux'},
        'x': {'value': 'y'},
    }
    session.remove_cookies(['foo'])
    assert session['cookies'] == {
        'baz': {'value': 'qux'},
        'x': {'value': 'y'},
    }

# Generated at 2022-06-21 14:52:56.407015
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {
        'Content-Type': 'application/json',
        'If-Match': '"abcd1234"',
        'If-None-Match': '"abcd1234"',
        'User-Agent': 'HTTPie/0.10.0',
    }
    session = Session('path')
    session.update_headers(headers)
    assert headers == session.headers

# Generated at 2022-06-21 14:53:02.253394
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import create_config_dir
    create_config_dir()
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'test', 'localhost:1337', 'http://localhost:1337')
    session.path.mkdir(parents=True)
    session.save()
    session = get_httpie_session(DEFAULT_CONFIG_DIR, './test/test', 'localhost:1337', 'http://localhost:1337')
    assert session.path == DEFAULT_CONFIG_DIR / 'test/test.json'
    session.path.parent.rmdir()
    session.path.parent.parent.rmdir()


# Generated at 2022-06-21 14:53:05.919657
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'foo': {}, 'bar': {}}
    session.remove_cookies(['foo'])
    assert 'foo' not in session['cookies']
    assert 'bar' in session['cookies']

# Generated at 2022-06-21 14:53:48.942266
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('test.json')
    s.update_headers({'Content-Type':'application/json', 'Host':'example.com'})
    assert s.headers == {'Host': 'example.com'}


# Generated at 2022-06-21 14:53:57.304481
# Unit test for function get_httpie_session
def test_get_httpie_session():
    if 'HTTPIE_TEST_SESSION_DIR' in os.environ:
        sessions_dir = Path(os.environ.get('HTTPIE_TEST_SESSION_DIR'))
    else:
        sessions_dir = DEFAULT_SESSIONS_DIR / 'example.org'
        if not sessions_dir.exists():
            sessions_dir.mkdir(parents=True)
    s = get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='mysession',
        host='example.org',
        url='https://example.org/path',
        )
    s.save()
    assert (sessions_dir/'mysession.json').exists()



# Generated at 2022-06-21 14:54:02.197951
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test.json")
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    names = ['name1', 'name3']
    session.remove_cookies(names)
    assert session['cookies'] == {'name2': 'value2'}



# Generated at 2022-06-21 14:54:13.026944
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Create the session file
    s = get_httpie_session(DEFAULT_SESSIONS_DIR, "bob", None, "http://localhost")
    assert s.path == Path('~/.config/httpie/sessions/localhost/bob.json')
    # Create the session file
    s = get_httpie_session(DEFAULT_SESSIONS_DIR, "~/bob", None, "http://localhost:8000")
    assert s.path == Path('~/bob.json')
    # Create the session file
    s = get_httpie_session(DEFAULT_SESSIONS_DIR, "~/bob", "localhost", "http://localhost:8080/index.html")
    assert s.path == Path('~/bob.json')



# Generated at 2022-06-21 14:54:19.954603
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie import ExitStatus
    from tests.tools import http

    try:
        config_dir = Path(http('--config-dir', '--debug'))
    except SystemExit as e:
        assert e.code == ExitStatus.ERROR
        output = http.stderr.getvalue()
        assert BINARY_SUPPRESSED_NOTICE in output
    else:
        assert 'config' in config_dir.parts
        session = get_httpie_session(config_dir, session_name='my', host='www.example.com', url='https://www.example.com/hello')
        assert session['headers'] == {}
        assert session['cookies'] == {}

# Generated at 2022-06-21 14:54:25.762216
# Unit test for function get_httpie_session
def test_get_httpie_session():
    path = get_httpie_session(
        config_dir='/home/shivang/.config',
        session_name="session-1",
        host='127.0.0.1',
        url='http://www.google.com',
    )
    assert path == '/home/shivang/.config/sessions/127_0_0_1/session-1.json'


# Generated at 2022-06-21 14:54:35.952071
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dict = {
        'cookies': {
            'name1': 'value1',
            'name2': 'value2',
            'name3': 'value3',
            'name4': 'value4',
        },
    }
    session = Session(path='')
    session.update(config_dict)
    assert 'cookies' in session

    session.remove_cookies(('name2', 'name4'))
    assert 'name2' not in session['cookies']
    assert 'name4' not in session['cookies']
    assert session['cookies']['name1'] == 'value1'
    assert session['cookies']['name3'] == 'value3'



# Generated at 2022-06-21 14:54:41.080288
# Unit test for constructor of class Session
def test_Session():
    s = Session(Path('~/.httpie/sessions/httpbin.org/sess1.json'))
    s.load()
    assert type(s) == Session
    assert type(s.headers) == RequestHeadersDict
    assert type(s.cookies) == RequestsCookieJar
    assert type(s.auth) == AuthBase
    assert s.get('auth', None) == {'type': None, 'username': None, 'password': None}
    assert s.get('cookies', None) == {}
    assert s.get('headers', None) == {}


# Generated at 2022-06-21 14:54:44.023335
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session(Path(__file__), 'test_get_httpie_session', 'http://www.abc.com', 'http://www.abc.com')

# Generated at 2022-06-21 14:54:55.180898
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import collections

    # parameters
    session = Session("C:\\Users\\Simon\\.config\\httpie\\sessions\\httpie.json")

    headers = collections.OrderedDict()

    # set request headers
    headers.update({
        'content-type': 'text/html'
    })
    headers.update({
        'If-none-match': '123'
    })
    headers.update({
        'set-cookie': 'cookie'
    })
    headers.update({
        'set-cookie': 'cookie2'
    })
    headers.update({
        'cookie': 'cookie3'
    })
    headers.update({
        'content-length': '0'
    })

    # call function
    session.update_headers(headers)

    # check result