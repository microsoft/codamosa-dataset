

# Generated at 2022-06-21 14:45:06.051237
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path(r'C:\Users\User\httpie\sessions\test.json'))
    headers = RequestHeadersDict({'Host': 'host.com', 'Accept': 'application/json',
            'Content-Type': 'application/json', 'If-None-Match': 'etag'})
    session.update_headers(headers)
    assert session['headers'] == {'Host': 'host.com', 'Accept': 'application/json'}

# Generated at 2022-06-21 14:45:16.654080
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from plumbum import local
    from tempfile import TemporaryDirectory
    from pathlib import Path
    import configargparse
    # FIXME: Move the code of `get_httpie_session()`
    # here, so the function is tested properly,
    # and use the session fixtures like httpsession_plain_txt.
    config_dir = local.path(TemporaryDirectory().name)
    config_dir.mkdir()
    sessions_dir = config_dir / SESSIONS_DIR_NAME
    sessions_dir.mkdir()
    config_file = config_dir / 'config.ini'
    config_file.write('')
    p = configargparse.get_arg_parser()
    p.add_argument('--config', default=str(config_file))
    config = p.parse_args([])
    session_

# Generated at 2022-06-21 14:45:22.001844
# Unit test for constructor of class Session
def test_Session():
    from httpie.config import Config

    config = Config(path='')
    config.__setattr__('return_relative_config_path', True)
    
    session_name = 'test_session'
    test_host = 'testhost.com'
    test_url = 'https://testhost.com'
    output = get_httpie_session(config, session_name, test_host, test_url)

    assert output is not None



# Generated at 2022-06-21 14:45:30.746231
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArgType
    session = Session('')
    session.load()

    session.update_headers(KeyValueArgType.parse('foo:bar'))
    assert session.headers == {'foo': 'bar'}

    session.update_headers(KeyValueArgType.parse('foo:baz'))
    assert session.headers == {'foo': 'baz'}

    session.update_headers(KeyValueArgType.parse('Content-Type:abc'))
    assert 'Content-Type' not in session.headers

    session.update_headers(KeyValueArgType.parse('User-Agent:'))
    assert 'User-Agent' not in session.headers

    session.update_headers(KeyValueArgType.parse('User-Agent:HTTPie/0.9.9'))
   

# Generated at 2022-06-21 14:45:39.349976
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    oSession = Session('./test')
    oSession['headers'] = {'A': 'a', 'B': 'b', 'C': 'c'}

    oSession.update_headers()
    assert oSession['headers'] == {'A': 'a', 'B': 'b', 'C': 'c'}

    oSession.update_headers({'C': 'c2', 'D': 'd'})
    assert oSession['headers'] == {'A': 'a', 'B': 'b', 'C': 'c2', 'D': 'd'}

    oSession.update_headers({'C': 'c3'})
    assert oSession['headers'] == {'A': 'a', 'B': 'b', 'C': 'c3', 'D': 'd'}


# Generated at 2022-06-21 14:45:51.369018
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path(DEFAULT_SESSIONS_DIR))
    session['headers']['user-agent'] = "curl/httpie"
    session['headers']['accept-encoding'] = 'HTTPie/test'
    session['headers']['content-length'] = '8'
    session['headers']['cookie'] = 'a=b; c=d'
    session['headers']['content-type'] = 'application/json'

    request_headers = RequestHeadersDict()
    request_headers['user-agent'] = "HTTPie/1.0.3"
    request_headers['accept-encoding'] = "gzip, deflate"

    session.update_headers(request_headers)

    assert session['headers']['user-agent'] == "HTTPie/1.0.3"


# Generated at 2022-06-21 14:45:54.405293
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers({"Accept": "text/html", "If-None-Match": "xxx"})
    print(session)


if __name__ == '__main__':
    test_Session_update_headers()

# Generated at 2022-06-21 14:45:57.317053
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session_name = 'session_name'
    host = None
    url = 'url'
    config_dir = Path(DEFAULT_CONFIG_DIR)
    session = get_httpie_session(config_dir, session_name, host, url)



# Generated at 2022-06-21 14:46:06.604851
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session('/home/sessions', 'sess1', None, 'www.example.com')
    assert get_httpie_session('/home/sessions', 'sess1', 'www.example.com', 'https://hello.example.com')
    assert not get_httpie_session('/home/sessions', 'sess1', None, 'www.example.com')
    assert not get_httpie_session('/home/sessions', 'sess1', 'www.example.com', 'https://hello.example.com')


# Generated at 2022-06-21 14:46:10.322392
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session.__new__(Session)
    session['cookies'] = {'bob': {'value': 'Bob'}, 'alice': {'value': 'Alice'}}
    session.remove_cookies(['bob'])
    assert session['cookies'] == {'alice': {'value': 'Alice'}}

# Generated at 2022-06-21 14:46:19.870637
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_Session_update_headers.json')
    r = RequestHeadersDict({'header': 'value'})
    session.update_headers(r)
    assert session['headers'] == r

# Generated at 2022-06-21 14:46:32.041818
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import context

    from httpie.cli.argtypes import KeyValueArgType
    from httpie.plugins.builtin import HTTPBasicAuth

    session = Session(Path('/dev/null'))
    session.load()

    # Make sure headers added directly to `session` are preserved.
    session['headers']['Foo'] = 'BAR'

    # Add cookies to `session` to make sure they are updated instead of
    # overwritten.
    context.update_cookies({'foo': create_cookie('foo', 'bar')})
    session.cookies = context.cookies

    # Add the basic auth plugin.
    plugin_manager.add_plugin(HTTPBasicAuth)

    # Run the tested code.

# Generated at 2022-06-21 14:46:43.802964
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test data
    # Test data
    request_headers: RequestHeadersDict = {
        'User-Agent': 'HTTPie/0.9.6',
        'Content-Type': 'application/json',
    }

    session_old_headers: RequestHeadersDict = {
        'Host': 'www.httpbin.org',
        'Content-Type': 'text/plain',
    }

    session = Session('httpbin.org')
    session['headers'] = session_old_headers

    # Update headers
    session.update_headers(request_headers)

    # Check result
    session_new_headers: RequestHeadersDict = {
        'Host': 'www.httpbin.org',
        'Content-Type': 'application/json',
    }

    assert session['headers'] == session_new_headers

# Generated at 2022-06-21 14:46:53.494782
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict({
        'content-type': 'text/plain',
        'cookie': 'foo=bar;',
        'if-none-match': 'baz',
        'user-agent': 'HTTPie/1.0.0'
    })

    session_headers = {}

    session = Session('')
    session.update_headers(request_headers)
    print(session['headers'])
    print(session['cookies'])
    assert session['headers'] == session_headers
    assert session['cookies'] == {'foo': {'value': 'bar'}}

# Generated at 2022-06-21 14:46:56.570415
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('sessions/login/test.json')
    request_headers = RequestHeadersDict()
    request_headers['Cookie'] = 'test=test'
    session.update_headers(request_headers)
    cookie_test = session.cookies['test']
    assert cookie_test.value == 'test'

# Generated at 2022-06-21 14:47:00.105397
# Unit test for constructor of class Session
def test_Session():
    assert Session('test.json')['headers'] == {}
    assert Session('test.json')['cookies'] == {}
    assert Session('test.json')['auth'] == { 'type': None, 'username': None, 'password': None }

# Generated at 2022-06-21 14:47:04.305008
# Unit test for constructor of class Session
def test_Session():
    session = Session('tests/tmp/session.json')
    assert os.path.exists('tests/tmp/session.json')
    session.remove_cookies('1')


# Generated at 2022-06-21 14:47:06.521218
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('tests/sessions/base_session.json')
    session.remove_cookies(['test_cookie'])
    assert 'test_cookie' not in session['cookies']

# Generated at 2022-06-21 14:47:18.892559
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    from httpie.models import Environment

    class Env(Environment):
        def __init__(self):
            self.config_dir = '/'

    env = Env()
    env.config.default_options.merge({'session': 'test'})
    session = get_httpie_session(env.config_dir, 'test', None, '')
    session.update_headers({'hello': 'world'})
    assert 'hello' in session.headers
    session.update_headers({'hello-world': 'hello'})
    assert 'hello' in session.headers
    assert 'hello-world' in session.headers
    session.update_headers({'hello-world-hello': ''})
    assert 'hello' in session.headers
    assert 'hello-world' in session.headers
    assert 'hello-world-hello'

# Generated at 2022-06-21 14:47:29.386559
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.client.auth import BasicAuth
    Session.headers = None
    Session.cookies = None
    Session.auth = None
    request_headers = RequestHeadersDict({
        'User-Agent': 'HTTPie/1.0.2',
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate',
        'Cookie': 'a=1',
        'Cookie': 'b=2',
        'Cookie': 'c=init'
    })
    request_headers.headers = None
    request_headers.load_config_file = lambda path, *arg1, **arg2: None
    request_headers.load_config_dir = lambda path, *arg1, **arg2: None
    request_

# Generated at 2022-06-21 14:47:37.972826
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, '', '',
                              'https://github.com/jakubroztocil/httpie') == DEFAULT_CONFIG_DIR / 'sessions' / 'github.com' / 'jakubroztocil' / 'httpie'

# Generated at 2022-06-21 14:47:41.353118
# Unit test for function get_httpie_session
def test_get_httpie_session():
    s = get_httpie_session(DEFAULT_CONFIG_DIR,'test',None,'http://httpbin.org/get')
    file = open(s.path)
    assert file.read() == '{}\n'

# Generated at 2022-06-21 14:47:48.315045
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('untitled')
    session.update({'cookies': {'a': {}, 'b': {}}})
    session.remove_cookies(['a'])
    assert session == {'cookies': {'b': {}}, 'headers': {}}


VALID_SERVER_NAMES = ['local', 'remote']
VALID_SERVER_NAME_PATTERN = re.compile('^(local|remote)$')

# Generated at 2022-06-21 14:47:51.533457
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """Test basic Session class methods."""
    headers = {"header1": "value1"}
    session = Session("path")
    session.update_headers(headers)
    assert session["headers"] == {"header1": "value1"}
    # Check a session property
    assert session.headers == {"header1": "value1"}

# Generated at 2022-06-21 14:47:55.896953
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.cli.utils import get_config_dir
    session = get_httpie_session(get_config_dir(), 'a', 'b', 'http://localhost')
    assert session is not None
    assert session['headers'] == {}

# Generated at 2022-06-21 14:48:00.744419
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    my_Session = Session(path='~')
    my_Session['cookies'] = {'abc': 'value', 'def': 'value', 'ghi': 'value'}
    my_Session.remove_cookies(('abc', 'ghi'))
    assert set(my_Session['cookies'].keys()) == {'def'}

# Generated at 2022-06-21 14:48:07.843329
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/Users/syerram/httpie/sessions/test.json')
    session['cookies'] = {'key1': {'value': 'value1'}, 'key2': {'value': 'value2'}, 'key3': {'value': 'value3'}}
    session.remove_cookies(['key2', 'key3'])
    assert session['cookies'] == {'key1': {'value': 'value1'}}



# Generated at 2022-06-21 14:48:09.885002
# Unit test for constructor of class Session
def test_Session():
    Session(path="../../../httpie/config.json")

# Generated at 2022-06-21 14:48:17.351705
# Unit test for function get_httpie_session
def test_get_httpie_session():

    from httpie.context import Environment, Environment
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_config_dir:
        config_dir = Path(temp_config_dir)
        config_dir.mkdir('sessions')
        config_dir.mkdir('sessions/www.example.com')
        session_name = 'test'
        session_file = config_dir / SESSIONS_DIR_NAME / 'www.example.com' / f'{session_name}.json'
        session_file.write_text('{"headers": {}}')

        url = 'http://www.example.com'
        session = get_httpie_session(config_dir, session_name, None, url)

        assert session.headers == {}
        assert session_name in config_dir.read_text()

# Generated at 2022-06-21 14:48:22.198731
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/foo')
    session['cookies'] = {'email': 'foo@bar.com', 'user_id': '123'}
    session.remove_cookies(['user_id'])
    assert session['cookies'] == {'email': 'foo@bar.com'}

# Generated at 2022-06-21 14:48:29.695079
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, 'localhost', None, 'http://localhost') is not None

# Generated at 2022-06-21 14:48:33.861274
# Unit test for constructor of class Session
def test_Session():
    path = 'data.json'
    session = Session(path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }

# Generated at 2022-06-21 14:48:38.868674
# Unit test for constructor of class Session
def test_Session():
    name = 'test'
    session = Session(name)
    assert session.get('headers', {}) == {}
    assert session.get('cookies', {}) == {}
    assert session.get('auth', {}) == {
        'type': None,
        'username': None,
        'password': None
    }
    assert session.path == Path('test.json')



# Generated at 2022-06-21 14:48:44.591592
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.input import KeyValueArg
    session = Session(path='.test')
    headers = {'a': 'A', 'b': 'B', 'C': 'c', 'D': 'd', 'E': 'e', 'f': 'F'}
    expected = {'a': 'A', 'b': 'B', 'f': 'F'}
    request_headers = RequestHeadersDict()
    for k, v in headers.items():
        request_headers.add(KeyValueArg(k, v))
    session.update_headers(request_headers)
    session_headers = session['headers']
    print(session_headers)
    assert session_headers == expected

# Generated at 2022-06-21 14:48:46.736202
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session('.', 'test', 'www.baidu.com', '/')



# Generated at 2022-06-21 14:48:53.632567
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_headers = RequestHeadersDict({
        'H1': 'h1', 'H2': 'h2', 'H3': 'h3', 'H4': 'h4', 'Accept-Encoding': 'z'})
    request_headers = RequestHeadersDict({
        'H1': 'h1', 'H2': None, 'H3': 'h3', 'H4': 'h4', 'Accept-Encoding': 'z'})
    session = Session('test_update_headers')
    session.update_headers(request_headers)
    assert session.headers == session_headers



# Generated at 2022-06-21 14:48:58.387114
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {}

    session = Session(path=DEFAULT_SESSIONS_DIR / 'test_sessions.json')
    session['cookies'] = cookies
    session.remove_cookies(['test', 'test2'])

    assert session['cookies'] == {}

# Generated at 2022-06-21 14:49:02.656673
# Unit test for constructor of class Session
def test_Session():
    path = '/'
    session = Session(path)
    assert session == {
        'headers': {},
        'cookies': {},
        'auth': {
            'type': None,
            'username': None,
            'password': None
        }
    }



# Generated at 2022-06-21 14:49:06.330121
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = None
    session_name = 'test_session'
    session = Session(session_path)
    session.remove_cookies(['key1', 'key3'])



# Generated at 2022-06-21 14:49:16.750661
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from contextlib import contextmanager

    from tempfile import mkdtemp

    from httpie.config import Config
    from httpie.sessions import get_httpie_session

    @contextmanager
    def env(**kwargs):
        backup = dict(os.environ)
        os.environ.update(kwargs)
        yield
        os.environ.clear()
        os.environ.update(backup)

    with env(HTTPIE_CONFIG_DIR=mkdtemp()):
        conf = Config()
        conf.load()
        conf.config_dir.joinpath('sessions').mkdir()

    with env(HTTPIE_CONFIG_DIR=str(conf.config_dir)):
        session = get_httpie_session(conf.config_dir,"sessions","localhost")
        assert session.auth


# Generated at 2022-06-21 14:49:38.609410
# Unit test for constructor of class Session
def test_Session():
    # Arrange
    path = 'test_session_file'
    config = Session(path)

    # Act 
    headers = config['headers']
    cookies = config['cookies']
    auth = config['auth']
    config_path = config.path
    config_helpurl = config.helpurl
    config_about = config.about

    # Assert
    assert path == config_path
    assert 'https://httpie.org/doc#sessions' == config_helpurl
    assert 'HTTPie session file' == config_about
    assert isinstance(headers, dict)
    assert isinstance(cookies, dict)
    assert isinstance(auth, dict)

# Generated at 2022-06-21 14:49:50.535876
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import re
    import requests
    class ConfigDir(object):
        def __init__(self, path):
            self.path = path
        def __truediv__(self, other):
            return ConfigDir(os.path.join(self.path, other))
    config_dir = ConfigDir("/home/kenneth/.config/httpie")
    session_name = "test_session"
    url = "https://httpbin.org"
    #host = "https://httpbin.org"

    # Test exception for invalid session name
    with pytest.raises(ValueError):
        httpie_session = get_httpie_session(config_dir, "invalid_session_name", url)
    # Test exception for invalid host
    with pytest.raises(ValueError):
        httpie_session = get_

# Generated at 2022-06-21 14:49:52.782872
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test/session')
    session.load()
    session.remove_cookies(['name'])
    assert 'name' not in session['cookies']

# Generated at 2022-06-21 14:49:56.034576
# Unit test for constructor of class Session
def test_Session():
    sess = Session("../test/test_data/test_session.json")
    assert sess['headers']
    assert sess['cookies']
    assert sess['auth']['type'] == "basic"

# Generated at 2022-06-21 14:49:59.580816
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    SESSION = Session("")
    SESSION['headers'] = {0: 1}
    SESSION.update_headers({0: 2, 'asdf': 1, 'Content-Type': 'text', 'If-Match': '*'})
    assert SESSION['headers'] == {0: 1}

# Generated at 2022-06-21 14:50:05.689160
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    request_headers = RequestHeadersDict()
    request_headers['Content-Type'] = 'application/json'
    request_headers['Content-Length'] = '120'
    request_headers['Host'] = '127.0.0.1'
    session = Session('session_test')
    session.update_headers(request_headers)
    assert 'Content-Type' in session['headers']
    assert 'Content-Length' in session['headers']
    assert 'Host' in session['headers']
    assert 'Content-Type' not in request_headers
    assert 'Content-Length' not in request_headers
    assert 'Host' in request_headers

# Generated at 2022-06-21 14:50:12.036198
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    SESSIONS_DIR_NAME = 'sessions'
    path = Path('testPath')
    session = Session(path)
    assert session.path == Path('testPath')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-21 14:50:17.310819
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('dummy.file')
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 'value2'}

# Generated at 2022-06-21 14:50:24.485641
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import create_config_dir
    from httpie.utils import mkdir_p

    config_dir = create_config_dir()

    s = get_httpie_session(
        config_dir=config_dir,
        host="https://some.host.com:1200",
        session_name="session1",
        url="https://some.host.com:1200"
    )
    assert s._path == config_dir / SESSIONS_DIR_NAME / "some_host_com_1200" / "session1.json"
    assert s["headers"]["Accept-Encoding"] == "gzip, deflate"

# Generated at 2022-06-21 14:50:34.683339
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('./tests/configs/')
    session_name = 'test_session'
    host = 'http://www.httpbin.org'
    url = ''
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }
    assert session['headers'] == {}
    assert session.headers == {}
    assert session.cookies != None
    session.remove_cookies(['test_cookies'])


test_get_httpie_session()

# Generated at 2022-06-21 14:51:08.572335
# Unit test for constructor of class Session
def test_Session():
    path = 'C:\\Users\\Administrator\\AppData\\Local\Programs\\Python\\Python37\\Lib\\site-packages\\httpie\\config\\sessions\\localhost\\v1_0.json'
    s = Session(path)
    headers = {}
    cookies = {}
    auth = {
        'type': None,
        'username': None,
        'password': None
    }
    assert s['headers'] == headers
    assert s['cookies'] == cookies
    assert s['auth'] == auth

test_Session()


# Generated at 2022-06-21 14:51:13.494910
# Unit test for constructor of class Session
def test_Session():
    config_dir = DEFAULT_SESSIONS_DIR
    session_name = 'test'
    host = 'www.baidu.com'
    url = 'http://www.baidu.com'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session['headers'] is not None

# Generated at 2022-06-21 14:51:19.270962
# Unit test for constructor of class Session
def test_Session():
    input_path = "path"
    session = Session(input_path)
    assert session.about == "HTTPie session file"
    assert session.path == input_path
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-21 14:51:22.688384
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(os.devnull)
    s['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    s.remove_cookies(['a', 'c'])
    assert s['cookies'] == {'b': 2}

# Generated at 2022-06-21 14:51:28.351895
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    with open(DEFAULT_CONFIG_DIR / 'sessions/localhost/test_cookie.json', 'r') as f:
        session = Session(f)
        session.load()
    assert 'session' in session['cookies'].keys()
    session.remove_cookies(['session'])
    assert 'session' not in session['cookies'].keys()

# Generated at 2022-06-21 14:51:35.864571
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(config.DEFAULT_CONFIG_DIR)
    session_name = 'test_session'
    host = 'test.com'
    url = 'http://test.com/path'

    # test with default config dir
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.path == Path(config_dir / SESSIONS_DIR_NAME / host / 'test_session.json')



# Generated at 2022-06-21 14:51:39.790565
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie import ExitStatus
    from httpie.cli.constants import EXIT_OK
    from httpie.cli.parser import parse_args
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.session import Session
    import json
    import stat

    class Args(object):
        def __init__(self):
            self.session = None
            self.session_read_only = False
            self.session_write_only = False
    args = Args()
    parsed_args = parse_args(args=[], env={"ASSUME_UNICODE": "1"},
                             stdin=None, stdin_isatty=False,
                             config_dir=Path(":totally-nonexistent"), args=args)

# Generated at 2022-06-21 14:51:48.924654
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test_session.json')
    s['cookies'] = {
        'c1': {'value': 'v1', 'path': '/path1'},
        'c2': {'value': 'v2', 'path': '/path2'},
        'c3': {'value': 'v2', 'path': '/path2'},
    }
    s.remove_cookies(['c3', 'c4'])
    expected = {
        'c1': {'value': 'v1', 'path': '/path1'},
        'c2': {'value': 'v2', 'path': '/path2'},
    }
    assert s['cookies'] == expected

# Generated at 2022-06-21 14:52:00.867568
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('path/to/session')

# Generated at 2022-06-21 14:52:02.931212
# Unit test for constructor of class Session
def test_Session():
    sess = Session(os.path.expanduser('./data.json'))
    print(sess.path)
    sess.load()
    print(sess)


if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-21 14:52:39.612470
# Unit test for constructor of class Session
def test_Session():
    path='./test_session'
    test_file=open(path, 'w')
    test_content="""
    {
    "headers": {},
    "cookies": {},
    "auth": {
        "type": None,
        "username": None,
        "password": None
    }
}
    """
    test_file.write(test_content)
    test_file.close()
    test_Session = Session(path)
    assert test_Session['headers'] == {}
    assert test_Session['cookies'] == {}
    assert test_Session['auth'] == {'type': None, 'username': None, 'password': None}
    os.remove(path)


# Generated at 2022-06-21 14:52:42.659149
# Unit test for constructor of class Session
def test_Session():
    SAMPLE_SESSION_PATH = DEFAULT_SESSIONS_DIR/"www.google.com"/"test_session.json"
    test_session = Session(SAMPLE_SESSION_PATH)
    return test_session

# Generated at 2022-06-21 14:52:55.267588
# Unit test for method update_headers of class Session
def test_Session_update_headers():
  from httpie.plugins.registry import plugin_manager
  from httpie import config
  from httpie.config import Config
  from httpie.plugins import AuthPlugin, AuthPluginManager

  class DummyPlugin(AuthPlugin):
    auth_type = 'foo'
    auth_parse = True
    def get_auth(self, username, password):
        return None
  plugin_manager.authentication_plugins[DummyPlugin.auth_type] = DummyPlugin

  config_obj = config.Config()
  config_obj.__dict__['config_dir'] = None
  config_obj.config_dir = None
  config_obj.__dict__['config_dir'] = None
  config_obj.__dict__['config_path'] = None
  config_obj.__dict__['filename'] = None
  config_obj.__

# Generated at 2022-06-21 14:52:59.431011
# Unit test for constructor of class Session
def test_Session():
    obj = Session('session')
    assert len(obj) == 3
    assert obj['headers'] == {}
    assert obj['cookies'] == {}
    assert 'auth' in obj
    assert obj['auth']['type'] == None
    assert obj['auth']['username'] == None
    assert obj['auth']['password'] == None



# Generated at 2022-06-21 14:53:09.591948
# Unit test for function get_httpie_session
def test_get_httpie_session():
    DEFAULT_SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    session = get_httpie_session(
        DEFAULT_SESSIONS_DIR,
        'my_session',
        'http://example.com',
        'http://example.com/',
    )
    session_path = Path(DEFAULT_SESSIONS_DIR / SESSIONS_DIR_NAME / 'example.com' / 'my_session.json')
    assert session.path == session_path
    assert session_path.exists()

    # test session generated even when host is not specified
    session = get_httpie_session(
        DEFAULT_SESSIONS_DIR,
        'my_session',
        None,
        'http://example.com/',
    )
    assert session.path.exists

# Generated at 2022-06-21 14:53:20.730517
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict

    session = Session('/tmp/httpie_session.json')
    session_headers = session.headers
    session_headers['Accept'] = 'application/json'
    session_headers['User-Agent'] = 'HTTPie/1.0.0'

    # request_headers
    request_headers = RequestHeadersDict({
        'Accept': 'application/json',
        'If-Match': '"abc123"',
        'Content-Type': 'application/json',
        'If-Unmodified-Since': 'Sat, 29 Oct 1994 19:43:31 GMT',
        'User-Agent': 'Created by httpie-session'
    })

    session.update_headers(request_headers)

    # session_headers = session.headers

# Generated at 2022-06-21 14:53:26.078146
# Unit test for constructor of class Session
def test_Session():
    config_dir = '/home/user/.config'
    session_name = 'test_session'
    host = 'host'
    url = 'http://host'
    session = get_httpie_session(Path(config_dir), session_name, host, url)
    assert session.auth is None
    assert session.headers == RequestHeadersDict()
    assert list(session.cookies) == []
    assert session.cookies == RequestsCookieJar()
    assert session.path == Path('/home/user/.config/sessions/host/test_session.json')

# Generated at 2022-06-21 14:53:34.307613
# Unit test for constructor of class Session
def test_Session():
    arg = "C:/Users/henan/httpie/doc/httpie.org/static/img/httpie_wheel.svg"
    session = Session(arg)
    assert(isinstance(session, Session) == True)
    assert(isinstance(session.headers, RequestHeadersDict) == True)
    assert(isinstance(session.cookies, RequestsCookieJar) == True)
    assert(isinstance(session.auth, type(None)) == True)
    assert(isinstance(session.remove_cookies({"name"}), type(None)) == True)



# Generated at 2022-06-21 14:53:42.904908
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers({'Content-Type': 'test', 'Onek': '1',  'Twok': '2'})
    assert session.headers == {'Onek': '1', 'Twok': '2'}
    session.update_headers({'Onem': '1', 'Twom': '2'})
    assert session.headers == {'Onek': '1', 'Twok': '2', 'Onem': '1', 'Twom': '2'}
    session.update_headers({'Twom': None})
    assert session.headers == {'Onek': '1', 'Twok': '2', 'Onem': '1'}

# Generated at 2022-06-21 14:53:48.737978
# Unit test for constructor of class Session
def test_Session():
    path_to_session = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'default.json'
    s = Session(path_to_session)
    assert s.path == path_to_session
    assert s.headers == {}
    assert s.cookies == {}
    assert s.auth == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-21 14:54:14.048761
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_session = Session()
    test_session.update_headers(test_session)

# Generated at 2022-06-21 14:54:16.772043
# Unit test for constructor of class Session
def test_Session():
    s = Session('./test.json')
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-21 14:54:21.492367
# Unit test for constructor of class Session
def test_Session():
    print("Test Session()")
    try:
        newSession = Session(path=Path("/home/terway/.config/httpie/sessions/192.168.1.124/debug.json"))
    except Exception:
        print("Exception: ", sys.exc_info()[0])


# Generated at 2022-06-21 14:54:26.449916
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("session")
    s.update({"cookies": {'foo': {'value': 'bar'}, 'baz': {'value': 'qux'}}})
    assert 'baz' in s['cookies']
    s.remove_cookies(['baz'])
    assert 'baz' not in s['cookies']

# Generated at 2022-06-21 14:54:28.945109
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(Path(DEFAULT_CONFIG_DIR), session_name='first', host='localhost', url='')
    print(session)

# Generated at 2022-06-21 14:54:37.797671
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """Test for function get_httpie_session"""
    config_dir = Path('/home/liudeng1/.config/httpie')
    session_name = 'scrapy'
    host = None
    url = 'http://www.baidu.com/index.php'

    target_path = config_dir / SESSIONS_DIR_NAME / 'www_baidu_com'
    target_path = target_path / f'{session_name}.json'

    assert target_path == get_httpie_session(
        config_dir, session_name, host, url).path

# Generated at 2022-06-21 14:54:42.443344
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'session_name'
    host = 'host'
    url = 'url'
    assert get_httpie_session(config_dir, session_name, host, url)



# Generated at 2022-06-21 14:54:51.207873
# Unit test for constructor of class Session
def test_Session():
    # Test empty constructor
    ses = Session('test')
    assert type(ses) == Session
    assert ses['headers'] == {}
    assert ses['cookies'] == {}
    assert ses['auth'] == {'type': None, 'username': None, 'password': None}
    # Test constructor with path argument
    ses = Session(path='./test/test')
    assert type(ses) == Session
    assert ses['headers'] == {}
    assert ses['cookies'] == {}
    assert ses['auth'] == {'type': None, 'username': None, 'password': None}