

# Generated at 2022-06-21 14:45:06.321123
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers(dict(name='zhang'))
    assert session['headers'] == {
        'name': 'zhang'
    }
    session.update_headers(dict(name=None))
    assert session['headers'] == {
        'name': 'zhang'
    }
    session.update_headers(dict(name=b'zhang'))
    assert session['headers'] == {
        'name': 'zhang'
    }
    session.update_headers(dict(Cookie="foo=bar"))
    assert session['cookies'] == {
        'foo': {'value': 'bar'}
    }
    assert session['headers'] == {
        'name': 'zhang'
    }
    session.update_headers(dict(If_Match="foo"))


# Generated at 2022-06-21 14:45:17.124722
# Unit test for constructor of class Session
def test_Session():
    test_dir = Path('test_session')
    test_sessions_dir = test_dir / SESSIONS_DIR_NAME
    session_name = 'temp_session'
    path = test_sessions_dir / session_name
    if test_sessions_dir.exists():
        for file in os.listdir(test_sessions_dir):
            os.remove(os.path.join(test_sessions_dir, file))
    test_sessions_dir.mkdir(parents=True)
    test_session = Session(path)
    test_session['headers'] = {'Content-Type': 'text/html'}
    test_session['cookies'] = {'session_id': '1111-2222-3333'}
    test_session.save()

# Generated at 2022-06-21 14:45:24.814525
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test")
    session.update_headers(RequestHeadersDict({'Accept': 'json', 'Origin': 'www.example.com'}))
    assert session['headers'] == {'Accept': 'json', 'Origin': 'www.example.com'}
    session.update_headers(RequestHeadersDict({'Accept': 'html'}))
    assert session['headers'] == {'Origin': 'www.example.com', 'Accept': 'html'}
    session.update_headers(RequestHeadersDict({'Content-Type': 'application/json', 'If-Match': '2014'}))
    assert session['headers'] == {'Origin': 'www.example.com', 'Accept': 'html'}

# Generated at 2022-06-21 14:45:34.355460
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.load()

    request_headers = RequestHeadersDict()
    request_headers['Content-Type'] = "application/json"
    request_headers['Content-Length'] = "100"
    request_headers['Cookie'] = "session=3f3c84de-23f5-4199-b63d-e5e5c9e9b1d9; domain=localhost; expires=Tue, 06-Oct-2020 06:10:54 GMT; Path=/; HttpOnly;"

    session.update_headers(request_headers)


# Generated at 2022-06-21 14:45:44.288292
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # cookie_jar contains Cookie A, B, C.
    # Cookie A and Cookie D will be removed in this function.
    # Cookie D does not exists in the jar.
    cookie_dicts = {
        'A': {
            'value': 'a',
            'path': '/',
            'secure': 'False',
            'expires': '2019-01-01'
        },
        'B': {
            'value': 'b',
            'path': '/',
            'secure': 'False',
            'expires': '2019-01-02'
        },
        'C': {
            'value': 'c',
            'path': '/',
            'secure': 'False',
            'expires': '2019-01-03'
        }
    }
    cookie_jar = RequestsCookieJar()


# Generated at 2022-06-21 14:45:46.439008
# Unit test for constructor of class Session
def test_Session():
    s = Session('session.json')

    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}



# Generated at 2022-06-21 14:45:49.369176
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    index = Path("index")
    session = Session(index)
    cookies = {'cookies': {'name1': 'value1', 'name2': 'value2'}}
    session.update(cookies)
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-21 14:45:55.652851
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    session = get_httpie_session(Path.home(), 'sess', 'abc.com', 'abc.com')
    assert session.remove_cookies(['X']) == None
    session['cookies'] = {'token': '123', 'password': '456'}
    assert session.remove_cookies(['token']) == None
    assert session['cookies'] == {'password': '456'}
    assert session.remove_cookies(['password', 'token']) == None
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:46:07.813768
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test for Session.update_headers
    # Preparing data
    request_headers = [
        ('Cookie', 'a=b'),
        ('Cookie', 'c=d'),
        ('vary', 'content-encoding'),
        ('User-Agent', 'HTTPie/0.9.9'),
        ('User-Agent', 'test/test'),
        ('Content-Type', 'text/test')
    ]
    request_headers = RequestHeadersDict(request_headers)
    # Create a session
    session = Session('test_Session_update_headers')
    # Load the session
    session.load()
    # Update the headers
    session.update_headers(request_headers)
    # Check the result

# Generated at 2022-06-21 14:46:18.810883
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from httpie.plugins.registry import plugin_manager
    import json
    
    session = Session('test.json')
    d = session.dump()
    with open('test.json', 'w') as f:
        json.dump(d, f)

    with open('test.json', 'r') as f:
        d = json.load(f)

    session_test = Session('test.json')
    session_test.load(d)

    # Tester
    # session_test.auth = {'type': None, 'username': None, 'password': None}
    # session_test.auth = {'type': 'none', 'username': None, 'password': None}
    r = session_test.auth


if __name__ == "__main__":
    test_Session()

# Generated at 2022-06-21 14:46:30.855322
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/sessions/default/test_remove_cookies.json')
    session['cookies'] = {
        'username': {'value': 'thomas'},
        'password': {'value': 'pass'},
    }
    for name in ['username', 'password']:
        assert name in session['cookies']
    session.remove_cookies(['username', 'password'])
    for name in ['username', 'password']:
        assert name not in session['cookies']

# Generated at 2022-06-21 14:46:42.677972
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('config')
    session_name = 'test'
    host = '127.0.0.1'
    url = 'http://127.0.0.1:8080/index.html'

    result = get_httpie_session(config_dir, session_name, host, url)
    wanted_path = Path('config') / SESSIONS_DIR_NAME / '127_0_0_1' / 'test.json'
    assert isinstance(result, Session)
    assert result.path == wanted_path
    assert result.config_dir == Path('config')
    assert result.helpurl == 'https://httpie.org/doc#sessions'
    assert result.about == 'HTTPie session file'
    assert result['headers'] == {}
    assert result['cookies'] == {}

# Generated at 2022-06-21 14:46:54.830525
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Arrange
    request_headers = {
        'Host': 'www.example.com',
        'Content-Type': 'text/plain',
        'User-Agent': 'HTTPie/0.9.2',
        'Accept-Encoding': 'gzip, deflate',
        'Accept': '*/*',
        'Content-Length': '160',
        'Host1': 'www.example.com',
        'Content-Type1': 'text/plain',
        'User-Agent1': 'HTTPie/0.9.2',
        'Accept-Encoding1': 'gzip, deflate',
        'Accept1': '*/*',
        'Content-Length1': '160',
        'Cookie': 'foo=bar; baz=quz'
    }
    session = Session(path=None)
   

# Generated at 2022-06-21 14:46:56.780733
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert Session == get_httpie_session(DEFAULT_CONFIG_DIR, "test", None, "http://localhost/").__class__

# Generated at 2022-06-21 14:47:05.448853
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        config_dir='~/.config',
        session_name='session.json',
        host='httpbin.org',
        url='http://httpbin.org',
    )
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    assert session.helpurl == 'https://httpie.org/doc#sessions'
    assert session.about == 'HTTPie session file'

# Generated at 2022-06-21 14:47:17.798736
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=None)
    session_dict = session

    # First check: the method update_headers updates
    # the dictionary session with headers of the request
    # which are not in SESSION_IGNORED_HEADER_PREFIXES.

    # 1 The session starts empty
    assert session_dict['headers'] == {}

    request_headers = {'Accept': 'application/json'}

    session.update_headers(request_headers)

    # 2 The session contains the header of the request
    assert session_dict['headers'] == {'Accept': 'application/json'}

    request_headers = {'Content-Type': 'application/json'}
    session.update_headers(request_headers)

    # 3 The session contains the header of the request

# Generated at 2022-06-21 14:47:22.595204
# Unit test for constructor of class Session
def test_Session():
    """test Session constructor"""
    config_dir = DEFAULT_CONFIG_DIR
    session_name = "test"
    host = "localhost"
    url = "http://localhost"

    session = get_httpie_session(config_dir, session_name, host, url)

    assert session == Session(config_dir / SESSIONS_DIR_NAME / 'localhost' / f"{session_name}.json")

# Generated at 2022-06-21 14:47:27.386128
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    jar = RequestsCookieJar()
    for name in ['a', 'b', 'c']:
        jar.set_cookie(create_cookie(
            name, name, **{'path': '/'}))
    assert jar['a'], jar['b']

    session = Session(None)
    session.cookies = jar
    session.remove_cookies(['a', 'b'])
    assert 'a' not in session.cookies, 'a' not in session.cookies

# Generated at 2022-06-21 14:47:32.722270
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path(__file__))
    session['cookies']['foo'] = 'bar'
    session['cookies']['foo2'] = 'bar2'
    session.remove_cookies(['foo'])
    assert 'foo' not in session['cookies']
    assert 'foo2' in session['cookies']

# Generated at 2022-06-21 14:47:36.340770
# Unit test for function get_httpie_session
def test_get_httpie_session():
    DEFAULT_SESSIONS_DIR = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME
    get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', 'localhost', '/')

# Generated at 2022-06-21 14:47:47.551754
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://localhost:8000/'
    session_name = 'test_session'
    sessions_dir = '/tmp/.httpie/sessions'
    session = get_httpie_session(sessions_dir, session_name, None, url)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth']['type'] is None
    assert session['auth']['username'] is None
    assert session['auth']['password'] is None

# Generated at 2022-06-21 14:47:54.115489
# Unit test for function get_httpie_session
def test_get_httpie_session():
    param_list = [
        (
            DEFAULT_CONFIG_DIR,
            'default',
            'httpie.org',
            'https://httpie.org/get',
        ),
        (
            DEFAULT_CONFIG_DIR,
            '/tmp/default',
            'httpie.org',
            'https://httpie.org/get',
        ),
        (
            DEFAULT_CONFIG_DIR,
            'default',
            None,
            'http://httpie.org/get',
        ),
        (
            DEFAULT_CONFIG_DIR,
            'default',
            None,
            'http://localhost:8080/get',
        ),
    ]
    for param in param_list:
        config_dir, session_name, host, url = param
        session = get_httpie

# Generated at 2022-06-21 14:48:05.774541
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie import __version__
    from httpie.output.streams import get_bytes_stdin, get_bytes_stderr
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.config import Config, DEFAULT_CONFIG_DIR
    from httpie.sessions import Session, get_httpie_session, VALID_SESSION_NAME_PATTERN, SESSIONS_DIR_NAME
    from httpie.cli.argtypes import KeyValueArg, KeyValue
    from httpie import ExitStatus

    config = Config()
    env = Environment(__version__, config, StdinBytesIO(), get_bytes_stderr(), ExitStatus())

    assert SESSIONS_DIR_NAME == 'sessions'

# Generated at 2022-06-21 14:48:12.887149
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s.cookies = {'name1': 'value1', 'name2': 'value2'}
    assert s.cookies == {'name1': 'value1', 'name2': 'value2'}
    assert s.remove_cookies(['name1', 'name2']) == None
    assert s.cookies == {}

if __name__ == '__main__':
    test_Session_remove_cookies()

# Generated at 2022-06-21 14:48:18.185268
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class test_headers(RequestHeadersDict):
        def __init__(self):
            items = {'test_header': 'test_value'}
            super().__init__(items)

    request_headers = test_headers()
    session = Session(path='test')
    session.update_headers(request_headers)
    print(session['headers'])


# Generated at 2022-06-21 14:48:22.571711
# Unit test for constructor of class Session
def test_Session():
    s = Session('a.json')
    assert s.path == Path('a.json')
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}



# Generated at 2022-06-21 14:48:29.335603
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # arrange
    session = Session(path='')
    request_headers = {
    	'Host': 'example.com',
    	'Accept': '*/*',
    	'Content-Type': 'application/json'
    }
    # act
    session.update_headers(request_headers)
    # assert
    assert request_headers['Host'] == session['headers']['Host']
    assert request_headers['Accept'] == session['headers']['Accept']
    assert request_headers['Content-Type'] == session['headers']['Content-Type']
    

# Generated at 2022-06-21 14:48:31.829498
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test_session.json')
    a = RequestHeadersDict([('name', 'value')])
    session.update_headers(a)
    assert len(session['headers']) == 1

# Generated at 2022-06-21 14:48:41.307567
# Unit test for function get_httpie_session
def test_get_httpie_session():
    path_correct_session = os.path.join(
        os.path.expanduser("~"), 
        '.config/httpie/sessions/www.google.com/google.json'
    )
    path_incorrect_session = os.path.join(
        os.path.expanduser("~"), 
        '.config/httpie/sessions/www.google.com/google_session.json'
    )
    if not os.path.exists(path_correct_session):
        os.makedirs(os.path.dirname(path_correct_session))
        with open(path_correct_session, 'w') as f:
            f.write("")
    if os.path.exists(path_incorrect_session):
        os.remove(path_incorrect_session)


# Generated at 2022-06-21 14:48:45.467987
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, "basic", "127.0.0.1:8080", "http://127.0.0.1:8080/").cookies == []

# Generated at 2022-06-21 14:48:59.435413
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import json
    from requests.cookies import RequestsCookieJar
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.config import Config

    config = Config({
        'config_dir': '~/.config/httpie',
        'default_options': [
            '--session=session', '--auth-type=basic',
        ]
    })

    session = get_httpie_session(
        config_dir=config.config_dir,
        session_name=config.default_options['--session'],
        host='https://httpbin.org',
        url='https://httpbin.org/headers'
    )

    # Test that the session file is created
    session_path = session.path

    # Test that the session can be saved
    session.save()
    assert session_path.ex

# Generated at 2022-06-21 14:49:07.209492
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'session'
    host = 'www.github.com'
    url = 'https://www.github.com'

    session = get_httpie_session(config_dir, session_name, host, url)
    assert session
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }

# Generated at 2022-06-21 14:49:11.434682
# Unit test for constructor of class Session
def test_Session():
    path = "/home/user/Desktop/temp/sessions/localhost"
    session = Session(path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}



# Generated at 2022-06-21 14:49:16.012280
# Unit test for constructor of class Session
def test_Session():
    path = './session'
    session = Session(path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }



# Generated at 2022-06-21 14:49:21.872237
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert str(get_httpie_session('/tmp', 'foo', 'www.example.com', 'https://www.example.com/rest/user')) == \
"""{'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}"""

# Generated at 2022-06-21 14:49:30.893351
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_url = "http://example.com"
    test_session_name = "test_session"
    test_path = DEFAULT_SESSIONS_DIR / "example_com" / test_session_name + ".json"
    test_session = Session(test_path)
    test_request_headers = {"Test-Header-1": ["Test-Value-1-1", "Test-Value-1-2"], "Test-Header-2": ["Test-Value-2"]}
    test_session.update_headers(test_request_headers)
    test_headers = test_session.headers
    assert test_headers.get("Test-Header-1") == "Test-Value-1-1,Test-Value-1-2"
    assert test_headers.get("Test-Header-2") == "Test-Value-2"


# Generated at 2022-06-21 14:49:32.709202
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, 'test', 'www.localhost.com', 'http://www.localhost.com')



# Generated at 2022-06-21 14:49:42.219527
# Unit test for constructor of class Session
def test_Session():
    assert not os.path.exists('./aaa/.httpie/sessions')
    sess = Session(path='./aaa/.httpie/sessions/test.json')
    assert os.path.exists('./aaa/.httpie/sessions')
    assert os.path.isfile('./aaa/.httpie/sessions/test.json')
    with open('./aaa/.httpie/sessions/test.json', 'r', encoding='utf-8') as f:
        assert f.read() == '{}'
    sess.save()
    os.remove('./aaa/.httpie/sessions/test.json')
    os.rmdir('./aaa/.httpie/sessions')
    os.rmdir('./aaa/.httpie')


# Generated at 2022-06-21 14:49:46.440973
# Unit test for constructor of class Session
def test_Session():
    config_dir = '/Users/zhengl/Downloads/httpie-http/tests/sessions'
    session_name = 'hehe'
    url = 'https://github.com'
    host = None
    assert get_httpie_session(config_dir, session_name, host, url) is not None
    session_name = 'hehehe'
    host = None
    assert get_httpie_session(config_dir, session_name, host, url) is not None
    session_name = 'hehe'
    host = 'https://github.com'
    assert get_httpie_session(config_dir, session_name, host, url) is not None

if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-21 14:49:51.737913
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {
        'Content-Type': 'application/json; charset=utf-8',
        'Cookie': 'foo=bar'
    }
    session = Session('')
    session.update_headers(request_headers)
    assert session.headers == {}
    assert session.cookies == {}
    

# Generated at 2022-06-21 14:50:04.026781
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager

    path='/home/ubuntu/httpie/httpie/session/localhost/'
    s=Session(path)
    assert s.helpurl == 'https://httpie.org/doc#sessions'
    assert s.about == 'HTTPie session file'
    assert s['auth']['username'] == None
    assert s['auth']['password'] == None
    assert s['auth']['type'] == None

    s.update_headers(RequestHeadersDict({'user-agent':'HTTPie/2.2.0'}))
    assert type(s['headers']) == dict
    assert s['auth']['username'] == None

# Generated at 2022-06-21 14:50:08.544513
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers={"HTTPie.org":"Hello World"}
    session = Session(path="/tmp/sessions")
    session.update_headers(request_headers)
    assert session.headers == request_headers

# Generated at 2022-06-21 14:50:15.645786
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = "https://www.google.com/search?q=httpie"
    config_dir = Path("~/.config/httpie/")
    config_dir = config_dir.expanduser()
    session_name = "mytestsssssssssssss"
    host = "www.google.com"
    mysession = get_httpie_session(config_dir, session_name, host, url)
    assert mysession
    assert mysession.path.name == session_name + ".json"

# Generated at 2022-06-21 14:50:20.373391
# Unit test for constructor of class Session
def test_Session():
    session = Session("test/test_files/test.json")
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-21 14:50:25.199435
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import request_headers_dict

    request_headers = request_headers_dict({"Content-Type": "application/json"})
    session = Session(None)
    session.update_headers(request_headers)
    print(request_headers)
    #assert request_headers == {'Content-Type': 'application/json'}
    #assert session.headers == {'Content-Type': 'application/json'}



# Generated at 2022-06-21 14:50:37.600657
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Initialize Session
    session = Session('/tmp/httpie-session-1.json')
    assert session.headers == {}

    # Set header, this header should be ignored
    request_header_ignore = RequestHeadersDict({"host": "example.com"})
    session.update_headers(request_header_ignore)
    assert session.headers == {}

    # Set header, this header should be ignored
    request_header_ignore = RequestHeadersDict(
        {"Content-Type": "application/json"})
    session.update_headers(request_header_ignore)
    assert session.headers == {}

    # Set header, should be stored
    request_header_store = RequestHeadersDict({"Accept": "*/*"})
    session.update_headers(request_header_store)

# Generated at 2022-06-21 14:50:39.325692
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(
        config_dir=Path(r'~/.httpie'), session_name='', host='', url=''
    ).helpurl == 'https://httpie.org/doc#sessions'

# Generated at 2022-06-21 14:50:44.265156
# Unit test for function get_httpie_session
def test_get_httpie_session():
    httpie_session = get_httpie_session(
        DEFAULT_SESSIONS_DIR, 'my_session', 'host_name', 'url')
    assert httpie_session is not None
    assert httpie_session.path.as_posix() == DEFAULT_SESSIONS_DIR / 'my_session.json'



# Generated at 2022-06-21 14:50:44.897144
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-21 14:50:57.135819
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import json

    config_dir = Path('~/.config/httpie').expanduser()
    session_name = 'example'
    url = 'http://example.org/path?query'
    host = 'example.org'
    if not config_dir.exists():
        config_dir.mkdir()
    sessions_dir = config_dir / SESSIONS_DIR_NAME
    if not sessions_dir.exists():
        sessions_dir.mkdir()
    path = sessions_dir / f'{host}/{session_name}.json'
    data = {'headers': {'accept': 'application/json'},
            'cookies': {},
            'auth': {'type': None,
                     'username': None,
                     'password': None}}

# Generated at 2022-06-21 14:51:04.818108
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Setup
    session = Session('test')
    request_headers = RequestHeadersDict({'Content-Type': 'text/plain'})
    session.update_headers(request_headers)
    # Test
    assert session['headers'] == {}

# Generated at 2022-06-21 14:51:07.962007
# Unit test for constructor of class Session
def test_Session():
    session = Session(path="~/.config/httpie/sessions")
    assert session.headers == {}
    assert session.cookies == {}
    assert session.auth == None



# Generated at 2022-06-21 14:51:12.978046
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_session = Session(path='temp.json')
    test_headers = {'Foo': 'bar', 'Baz': None}

    try:
        test_session.update_headers(test_headers)
        assert test_session['headers'] == {'Foo': 'bar'}
    finally:
        os.remove('temp.json')



# Generated at 2022-06-21 14:51:18.056032
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies')
    session.update({'cookies': {'abc': '123', 'def': '456', 'ghi': '789'}})
    session.remove_cookies(['def', 'ghi'])
    assert session.get('cookies', {}) == {'abc': '123'}

# Generated at 2022-06-21 14:51:25.466531
# Unit test for constructor of class Session
def test_Session():
    thisFile = Path(__file__)
    thisPath = thisFile.parent
    configPath = thisPath / "sessions" / "localhost" / "test.json"
    session = Session(thisPath)
    session['headers'] = {}
    session['cookies'] = {}
    session['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }
    session.update_headers(request_headers = request_headers)
    session.headers = request_headers
    session.cookies = cookies
    session.auth = auth_type
    session.remove_cookies(names = names)


# Generated at 2022-06-21 14:51:32.431339
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers=RequestHeadersDict({'Content-Type':'application/json',
                                          'connection':'keep-alive',
                                          'auth':'username:password',
                                          'cookie':'user_id=123456;user_name=hero'})
    s=Session('')
    s.update_headers(request_headers)
    print(s.headers)

# Generated at 2022-06-21 14:51:43.198531
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.config import Loader
    from httpie.context import Environment
    config = Loader().load_config()
    env = Environment(config)
    s = Session(config.config_dir / SESSIONS_DIR_NAME / 'test_Session_remove_cookies.json')
    s.load()
    s['cookies']['key1'] = {'value': 'value1'}
    s['cookies']['key2'] = {'value': 'value2'}
    s['cookies']['key3'] = {'value': 'value3'}
    assert len(s['cookies']) == 3
    s.remove_cookies(['key2', 'key3'])
    assert len(s['cookies']) == 1

# Generated at 2022-06-21 14:51:50.163554
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import json
    import os
    session = Session('test.json')
    session['cookies'] = {
        'cookie_name':{
            'value': 'cookie_value',
            'path': '/'
        },
        'cookie_name2':{
            'value': 'cookie_value2',
            'path': '/'
        }
    }
    session.remove_cookies(['cookie_name'])
    assert session['cookies'] == {
        'cookie_name2':{
            'value': 'cookie_value2',
            'path': '/'
        }
    }
    os.remove('test.json')

# Generated at 2022-06-21 14:51:56.701431
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('.')
    session['cookies'] = {'cookie1': 1, 'cookie2': 2, 'cookie3': 3}
    assert session['cookies'] == {'cookie1': 1, 'cookie2': 2, 'cookie3': 3}

    session.remove_cookies(['cookie1', 'cookie2'])
    assert session['cookies'] == {'cookie3': 3}

test_Session_remove_cookies()

# Generated at 2022-06-21 14:51:59.367546
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import copy
    args = ['GET', 'https://httpbin.org/headers', 'User-Agent:' 'terminal1e']
    session = Session('/tmp/httpie_session.json')
    request_headers = RequestHeadersDict(args)
    session_headers = copy.deepcopy(session.headers)
    session.update_headers(request_headers)
    assert session.headers == session_headers
    session_headers.update(request_headers)
    assert session.headers == session_headers

# Generated at 2022-06-21 14:52:19.001046
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert "http://127.0.0.1:8080" == get_httpie_session('/path/to/config/dir', 'test', 'http://127.0.0.1:8080', 'http://127.0.0.1:8080').get("url")
    assert "http://127.0.0.1:8080" != get_httpie_session('/path/to/config/dir', 'test', 'http://127.0.0.1:8080', 'http://127.0.0.1:8080').get("url")

# Generated at 2022-06-21 14:52:25.032624
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Do "pip install -e ." to install httpie in development mode.
    # And then run this test.
    from httpie.core import build_request_headers
    from httpie.cli.dicts import RequestHeadersDict

    session = Session(Path('./test_data/sessions/test.json'))
    session.clear()
    session.save()

    test_config_path = './test_data/sessions'
    test_url = 'https://httpbin.org/post'

    request_headers = build_request_headers(test_config_path, test_url)

    session.update_headers(request_headers)
    assert set(session.headers.keys()) == {'header-a0', 'header-b1'}

    session.clear()

# Generated at 2022-06-21 14:52:28.306910
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies.json')
    session.load()
    session.remove_cookies(['foo', 'bar'])
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:52:32.340224
# Unit test for constructor of class Session
def test_Session():
    path = Path("test") / Path("test.json")
    session = Session(path)
    assert session['path'] == path
    assert session['headers'] == {}
    assert session['cookies'] == {}


# Generated at 2022-06-21 14:52:42.800363
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # initialize the Session object
    s = Session("test")
    s['cookies'] = {"name1": "value1", "name2": "value2", "name3": "value3"}
    print("original s['cookies'] = " + str(s['cookies']))

    # test for removing only one cookie
    r1 = ["name1"]
    s.remove_cookies(r1)
    print("after removing one cookie, s['cookies'] = " + str(s['cookies']))
    assert s['cookies'] == {"name2": "value2", "name3": "value3"}

    # test for removing multiple cookies
    s['cookies'] = {"name1": "value1", "name2": "value2", "name3": "value3"}

# Generated at 2022-06-21 14:52:43.949765
# Unit test for constructor of class Session
def test_Session():
    assert Session(path = "file")

# Generated at 2022-06-21 14:52:49.169417
# Unit test for constructor of class Session
def test_Session():
    path = Path('test')
    _Session = Session(path)
    assert _Session['headers'] == {}
    assert _Session['cookies'] == {}
    assert _Session['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-21 14:52:55.096549
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'a': 23, 'b': 26, 'c': 42}
    ses = Session('')
    ses['cookies'] = cookies.copy()
    ses.remove_cookies(['a', 'c'])
    assert ses['cookies'] == {'b': 26}
    ses.remove_cookies(['b'])
    assert ses['cookies'] == {}

# Generated at 2022-06-21 14:52:58.750263
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('my_session')
    session.update('cookies', {'name1': 'value1', 'name2': 'value2'})
    session.remove_cookies(['name1'])
    assert session.get('cookies') == {'name2': 'value2'}



# Generated at 2022-06-21 14:53:02.783866
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path=Path('/home/dou/.config/httpie/sessions/localhost/default.json'))
    s.load()
    s.remove_cookies(names=('_ga',))
    assert '_ga' not in s.cookies
    s.save()
    return



# Generated at 2022-06-21 14:53:18.639187
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from tempfile import TemporaryDirectory
    from httpie.config import HTTPieConfig
    from httpie.plugins.registry import plugin_manager

    with TemporaryDirectory() as tempdir:
        httpie_config = HTTPieConfig(config_dir=tempdir)
        plugin_manager.load_installed_plugins(httpie_config.config_dir)
        session = get_httpie_session(
            config_dir=httpie_config.config_dir,
            session_name='test-session',
            host=None,
            url='https://httpbin.org/'
        )
        assert session

# Generated at 2022-06-21 14:53:23.803950
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./Session')
    session.update_headers({'c' : 'a'})
    assert session['headers'] == {'c' : 'a'}
    session.update_headers({'c' : 'b'})
    assert session['headers'] == {'c' : 'a'}
    session.update_headers({'a' : 'b'})
    assert session['headers'] == {'c' : 'a', 'a' : 'b'}

# Generated at 2022-06-21 14:53:28.545187
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import EnvironmentConfig
    EnvironmentConfig(dir=DEFAULT_CONFIG_DIR, env={})
    session = get_httpie_session(
        DEFAULT_CONFIG_DIR, session_name='test', host=None, url='https://github.com'
    )
    dict(session)
    dict(session.cookies)
    dict(session.headers)

# Generated at 2022-06-21 14:53:39.588745
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    plugin_manager._clear()
    # Load all plugins
    from httpie.plugins.builtin import HttpiePlugin
    plugin_manager.load_installed_plugins(HttpiePlugin)

    # Load test session
    config_dir = 'tests/sessions'
    session_name = 'test'
    host = None
    url = 'http://www.google.com'
    session = get_httpie_session(
        config_dir, session_name, host, url)
    assert session

    # Load test request_header
    request_headers=RequestHeadersDict()
    request_headers['Content-Type'] = 'text/html'

# Generated at 2022-06-21 14:53:44.347435
# Unit test for constructor of class Session
def test_Session():
    """
    Ensure class Session has been created.
    """
    path = "tests/unit_tests/test_sessions/test.json"
    session = Session(path)
    assert session.path == "tests/unit_tests/test_sessions/test.json"
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-21 14:53:50.774115
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s=Session(path="1.json")
    s.update_headers({'header1':'h1', 'header2':'h2', 'header3':'h3'})
    # s.headers.update(request_headers)
    # assert s.headers == request_headers
    assert s.headers['header1'] == 'h1'
    assert s.headers['header2'] == 'h2'
    assert s.headers['header3'] == 'h3'


# Generated at 2022-06-21 14:53:58.685586
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='')
    session.update_headers(RequestHeadersDict({"Accept": "*/*", "User-Agent": "HTTPie/1.0.3"}))
    assert session.headers == RequestHeadersDict({"Accept": "*/*", "User-Agent": "HTTPie/1.0.3"})
    session.update_headers(RequestHeadersDict({"Accept": "application/json", "User-Agent": "HTTPie/1.0.3", "Content-Type": "application/json"}))
    assert session.headers == RequestHeadersDict({"Accept": "application/json", "User-Agent": "HTTPie/1.0.3", "Content-Type": "application/json"})

# Generated at 2022-06-21 14:53:59.215917
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    pass

# Generated at 2022-06-21 14:54:01.451267
# Unit test for constructor of class Session
def test_Session():
    for _path in [Path.cwd(), '.']:
        assert Session(_path).path == Path.cwd()

# Generated at 2022-06-21 14:54:12.789340
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("session.json")

    print("--------------Case 1 --------------")
    headers1 = {"Content-Type": "application/json", "Set-Cookie": "Test1=1;domain=127.0.0.1;path=/"}
    session.update_headers(RequestHeadersDict(headers1))
    print("headers is: ", session.headers)
    print("cookies is: ", session.cookies)

    print("--------------Case 2 --------------")
    headers2 = {"If-Modified-Since": "Wed, 21 Oct 2015 07:28:00 GMT", "User-Agent": "HTTPie/1.0.3"}
    session.update_headers(RequestHeadersDict(headers2))
    print("headers is: ", session.headers)
    print("cookies is: ", session.cookies)

    print

# Generated at 2022-06-21 14:54:27.995713
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArgType
    headers = RequestHeadersDict()
    headers.update({'Set-Cookie': 'name=value'})
    headers.update(KeyValueArgType(None)('session=1')) 
    assert headers.get('cookie', None) == None
    assert headers.get('session', '0') == '1'
    session = Session('path')
    session.update_headers(headers)
    assert session.get('headers', {}).get('session') == '1'
    assert session.get('cookies', {}).get('name') != None

# Generated at 2022-06-21 14:54:34.129425
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', host='test.com', url='https://test.com')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-21 14:54:45.282435
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    cookies = [
        {'name': 'a', 'value': '1', 'path': '/'},
        {'name': 'b', 'value': '2', 'path': '/'},
        {'name': 'c', 'value': '3', 'path': '/'}
    ]
    for cookie in cookies:
        session['cookies'][cookie['name']] = cookie
    assert len(session['cookies']) == 3
    assert set(session['cookies'].keys()) == set(['a', 'b', 'c'])
    session.remove_cookies(['a', 'b', 'x'])
    assert len(session['cookies']) == 1
    assert set(session['cookies'].keys()) == set(['c'])

# Generated at 2022-06-21 14:54:56.258506
# Unit test for constructor of class Session
def test_Session():
    session1 = {
        'headers': {'header1': 'value1', 'header2': 'value2'},
        'cookies': {'cookies1': {'value': 'value1'},
                    'cookies2': {'value': 'value2'}},
        'auth': {'type': 'auth1', 'username': 'username1',
                 'password': 'password1'},
    }
    session2 = {
        'headers': {'header1': 'value1', 'header2': 'value2'},
        'cookies': {'cookies1': {'value': 'value1'},
                    'cookies2': {'value': 'value2'}},
        'auth': {'type': 'auth1', 'username': 'username1',
                 'password': 'password1'},
    }