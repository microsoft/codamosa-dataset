

# Generated at 2022-06-21 14:45:06.095150
# Unit test for constructor of class Session
def test_Session():
    default_sessions_dir = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME
    default_sessions_dir.mkdir(exist_ok=True)
    session = get_httpie_session(default_sessions_dir, 'test_session', '', '')
    print(session)
    assert(session.cookies == RequestsCookieJar())

if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-21 14:45:11.031258
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(config_dir = DEFAULT_CONFIG_DIR, session_name = '', host = None, url = 'http://localhost')
    assert s['cookies']['A'] == {'value': '1'}
    assert 'A' not in s['cookies']
    s.remove_cookies(['B'])
    assert 'B' not in s['cookies']

# Generated at 2022-06-21 14:45:13.055562
# Unit test for constructor of class Session
def test_Session():
    val = Session("sessions/test.json")
    print(val)

test_Session()

# Generated at 2022-06-21 14:45:17.665914
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names = ["test1", "test2"]
    session = Session("test.json")
    session['cookies'] = {"test1": {"value": "test1"}, "test2": {"value": "test2"}}
    session.remove_cookies(names)
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:45:20.010009
# Unit test for constructor of class Session
def test_Session():
    session = Session("http://www.baidu.com")
    print("session:", session)


# Generated at 2022-06-21 14:45:29.022806
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    from httpie.cli import parse_args
    from httpie.cli.parser import KeyValueArg
    p = Path.home() / '.config/httpie'
    print(p)
    session_name = 'my_session'
    args = parse_args(args=['--session', session_name, 'https://httpie.org'])
    print(args)
    print(args.session)
    print(args.session.headers)
    print(args.session.cookies)
    print(args.session.auth)

    # Save user agent
    args.session.headers['User-Agent'] = 'blah'
    args.session.save()

    # Update session with request headers
    args.headers['x-request'] = 'blah'

# Generated at 2022-06-21 14:45:33.735803
# Unit test for constructor of class Session
def test_Session():
    session = Session("httpie/test_session.json")
    assert session['headers'] == {}, "headers not a empty list"
    assert session['cookies'] == {}, "cookies not a empty list"
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-21 14:45:43.959858
# Unit test for constructor of class Session
def test_Session():
    import datetime
    assert Session('static/session.json').items() == dict({}).items()
    assert Session('static/session.json') == dict({})
    assert Session('static/session.json')['headers'] == {}
    assert Session('static/session.json')['cookies'] == {}
    assert Session('static/session.json')['auth'] == {'type': None, 'username': None, 'password': None}
    Ses = Session('static/session.json')
    Ses.update_headers(RequestHeadersDict({'Host': 'httpbin.org', 'Connection': 'keep-alive'}))
    assert Ses['headers'] == {'Host': 'httpbin.org', 'Connection': 'keep-alive'}

# Generated at 2022-06-21 14:45:48.375727
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Check if session cookies has been removed
    """
    session = Session('test_remove_cookies')
    session['cookies']['cookie1'] = {'value': 'value1'}
    session['cookies']['cookie2'] = {'value': 'value2'}
    assert 'cookie1' in session['cookies']
    assert 'cookie2' in session['cookies']
    session.remove_cookies(['cookie1'])
    assert 'cookie2' in session['cookies']
    assert 'cookie1' not in session['cookies']

# Generated at 2022-06-21 14:45:52.984464
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = str(get_httpie_session(DEFAULT_SESSIONS_DIR, 'test_httpie_session', '0.0.0.0', 'http://127.0.0.1:8080'))
    assert 'test_httpie_session.json' in session
    assert '127_0_0_1' in session

# Generated at 2022-06-21 14:46:09.104720
# Unit test for constructor of class Session
def test_Session():
    from pathlib import Path
    from urllib.parse import urlunsplit, urlsplit
    from tempfile import TemporaryDirectory
    from httpie.config import Config, DEFAULT_CONFIG_DIR
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.session import Session

    class TempConfig(Config):
        def __init__(self, config_dir=DEFAULT_CONFIG_DIR):
            super().__init__(load_config=False)
            self.config_dir = config_dir

    def get_httpie_session(config_dir: Path, session_name: str, url: str):
        host = urlsplit(url).netloc.split('@')[-1]
        if not host:
            host = 'localhost'
        # host:port => host_port

# Generated at 2022-06-21 14:46:14.740702
# Unit test for constructor of class Session
def test_Session():
    session = Session('/home/xx/.config/httpie/sessions/localhost/test.json')
    assert session.helpurl == 'https://httpie.org/doc#sessions'
    assert session.about == 'HTTPie session file'
    assert session.path == '/home/xx/.config/httpie/sessions/localhost/test.json'

# Generated at 2022-06-21 14:46:18.408333
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    Exercise update_headers of Session.
    """
    s = Session('')
    s.update_headers(RequestHeadersDict({"key": "value"}))
    assert s['headers']['key'] == 'value'

# Generated at 2022-06-21 14:46:22.514389
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.request import PreparedRequest
    import json

    session = Session('/tmp/session.json')
    session.load()
    request = PreparedRequest()
    # Prepare a request with HEADERS
    with open('tmp.json', 'r') as file:
        r_headers = json.load(file)
        for header in r_headers.items():
            request.headers.add(header[0], header[1])

    session.update_headers(request.headers)

# Generated at 2022-06-21 14:46:27.888507
# Unit test for constructor of class Session
def test_Session():
    obj = Session("path")
    assert obj['headers'] == {}
    assert obj['cookies'] == {}
    assert obj['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-21 14:46:33.768225
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(None)
    headers = {"Accept": "*/*", "Cookie": "a=1,b=2"}
    s.update_headers(headers.copy())
    assert len(s['headers']) == 1
    assert s['headers']["Accept"] == "*/*"
    assert s['cookies'] == {"a": {"value": "1"}, "b": {"value": "2"}}



# Generated at 2022-06-21 14:46:40.031079
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('s.json')
    s['cookies'] = {'session_id': {'value': 'random'}, 'password': {'value': '123456'}, 'username': {'value': 'root'}}
    s.remove_cookies(['session_id', 'username'])
    assert s['cookies'] == {'password': {'value': '123456'}}


# Generated at 2022-06-21 14:46:49.337517
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Test with no host but an URL
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', None, 'http://localhost')
    assert session.path == DEFAULT_SESSIONS_DIR / SESSIONS_DIR_NAME / 'localhost' / 'test.json'

    # Test with a hostname
    session = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', 'localhost', 'http://localhost')
    assert session.path == DEFAULT_SESSIONS_DIR / SESSIONS_DIR_NAME / 'localhost' / 'test.json'

# Generated at 2022-06-21 14:46:59.207295
# Unit test for method update_headers of class Session

# Generated at 2022-06-21 14:47:03.895830
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('~')
    session_name = 'default'
    host = None
    url = 'http://localhost:80'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session

# Generated at 2022-06-21 14:47:15.545572
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Arrange
    config_dir = Path('~/.httpie').expanduser()
    session_name = 'test-session'

    # Act
    session = get_httpie_session(config_dir, session_name, 'example.com', 'http://example.com')

    # Assert
    assert session
    assert session['path'] == Path(str(config_dir) + '/sessions/example_com/test-session.json')



# Generated at 2022-06-21 14:47:25.835162
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from requests.utils import CaseInsensitiveDict
    import json
    import os
    def read_cookies_file(sess_obj):
        print(sess_obj.cookies)
        cookies_file = os.path.join(os.path.expanduser("~"), '.config', 'httpie' , 'sessions', 'test_host', 'test_session.json')
        with open(cookies_file, 'r') as f:
            try:
                json_obj = json.load(f)
            except:
                return None
            else:
                return json_obj
    
    def remove_saved_session_file(sess_obj):
        path = sess_obj['path']
        if not path.parent.is_dir():
            return

# Generated at 2022-06-21 14:47:31.098790
# Unit test for constructor of class Session
def test_Session():
    session = Session('session.json')
    headers = session['headers']
    cookies = session['cookies']
    # auth = session['auth']
    assert session
    assert headers
    assert cookies
    print('headers = ', headers)
    print('cookies = ', cookies)
    assert headers == {}
    assert cookies == {}



# Generated at 2022-06-21 14:47:41.231217
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_path = Path('/home/user/.config/httpie/sessions/example/test.json')
    session = Session(path=session_path)
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    assert session['cookies']['cookie1']['value'] == 'value1'
    assert session['cookies']['cookie2']['value'] == 'value2'
    session.remove_cookies(['cookie1', 'cookie3'])
    assert 'cookie1' not in session['cookies']
    assert session['cookies']['cookie2']['value'] == 'value2'

# Generated at 2022-06-21 14:47:51.567113
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='/path/to/session_file')
    session.update_headers({
        'Content-Type': 'application/json',
        'x-api-key': '',
        'x-timestamp': '2019-08-08T00:00:00+00:00',
        'Cookie': 'userid=${uid}; token=${token}'
    })
    assert session['headers'] == {
        'x-api-key': '',
        'x-timestamp': '2019-08-08T00:00:00+00:00'
    }
    assert session['cookies'] == {
        'userid': {'value': '${uid}'},
        'token': {'value': '${token}'}
    }


# Generated at 2022-06-21 14:47:59.014407
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session("hahaha")
    s['cookies'] = { "a" : 1, "b" : 2, "c" : 3}
    s.remove_cookies(["b"])
    assert s['cookies'] == { "a" : 1, "c" : 3}
    s.remove_cookies(["d"])
    assert s['cookies'] == { "a" : 1, "c" : 3}



# Generated at 2022-06-21 14:48:06.251344
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("/tmp/test_httpie_session_update_headers.json")
    session.update_headers({'X-X': None})
    session.update_headers({'User-Agent': "HTTPie/1.0.3"})
    session.update_headers({'User-Agent': "HTTPie/1.0.3"})
    session.update_headers({'User-Agent': "HTTPie/1.0.3"})
    session.update_headers({'If-Modified-Since': "Mon, 01 Jun 2020 20:21:29 GMT"})
    session.update_headers({'If-Not-Match': "*"})
    session.update_headers({'Content-Type': "application/x-www-form-urlencoded"})

# Generated at 2022-06-21 14:48:08.257329
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(Path('~/.httpie'), 'localhost', 'http://localhost')


# Generated at 2022-06-21 14:48:12.713337
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    from httpie.config import DEFAULT_CONFIG_DIR
    assert get_httpie_session(DEFAULT_CONFIG_DIR, 'test', None, 'http://127.0.0.1/') is not None



# Generated at 2022-06-21 14:48:23.919635
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    cookie_string = 'key1=val1; key2=val2; key3=val3'
    request_headers = {
        'user-agent': 'HTTPie/x.x.x',
        'content-type': 'application/json',
        'Host': 'httpbin.org',
        'Accept': 'application/json',
        'Connection': 'keep-alive',
        'Cookie': cookie_string,
        'Set-Cookie': cookie_string,
        'If-Match': hash('value'),
        'If-None-Match': hash('value'),
        'Content-Length': 1024,
    }
    self = Session('/path/to/session')
    self.update_headers(request_headers)

# Generated at 2022-06-21 14:48:30.484857
# Unit test for constructor of class Session
def test_Session():
    assert Session('test.json')
    assert Session(Path('test.json'))

# Generated at 2022-06-21 14:48:34.608414
# Unit test for constructor of class Session
def test_Session():
    ses = Session('/home/test')
    assert {'headers': {}, 'cookies': {}, 
            'auth': {'type': None, 'username': None, 'password': None}} == ses


# Generated at 2022-06-21 14:48:37.137849
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(Path('.'), Path('test'), 'host.com', 'http://host.com/') == Session('test.json')

# Generated at 2022-06-21 14:48:38.383399
# Unit test for constructor of class Session
def test_Session():
    assert Session('test/test.json') is not None



# Generated at 2022-06-21 14:48:44.298100
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session_name = 'test.json'
    host = 'localhost'
    url = 'http://localhost/abc'
    config_dir = Path('~/config').expanduser()
    expected = Session(config_dir / SESSIONS_DIR_NAME / host / session_name)
    assert get_httpie_session(config_dir, session_name, host, url) == expected
    url = 'http://www.example.com/abc'
    expected = Session(config_dir / SESSIONS_DIR_NAME / 'www_example_com' / session_name)
    assert get_httpie_session(config_dir, session_name, host, url) == expected



# Generated at 2022-06-21 14:48:50.645139
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_file = str(Path(__file__).absolute())
    session = Session(path_file + ".json")
    session.update({
        'headers': {},
        'cookies': {
            'session': {
                'value': 'abc',
                'secure': True,
                'path': '/'
            }
        },
        'auth': {}
    })
    session.remove_cookies(['session'])
    print(session)

# Generated at 2022-06-21 14:48:53.558573
# Unit test for constructor of class Session
def test_Session():
    assert isinstance(Session("test.json"), Session)
    assert isinstance(Session("test"), Session)
    assert isinstance(Session(Path("test.json")), Session)
    assert isinstance(Session(Path("test")), Session)



# Generated at 2022-06-21 14:48:55.963031
# Unit test for constructor of class Session
def test_Session():
    """
    >>> session = Session('/home/u/.config/httpie/sessions/test_session.json')
    >>> session
    {}
    """

# Generated at 2022-06-21 14:49:05.448151
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    httpie_session = Session("/home/test_user/test_session.json")
    httpie_session['cookies'] = {'key1':'value1', 'key2':'value2', 'key3':'value3'}
    length_before_remove = len(httpie_session['cookies'])
    httpie_session.remove_cookies(['key1','key3'])
    length_after_remove = len(httpie_session['cookies'])
    assert length_after_remove == 1
    assert length_before_remove > length_after_remove



# Generated at 2022-06-21 14:49:14.687391
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = r'https://detectportal.firefox.com/success.txt'
    config_dir = Path(DEFAULT_CONFIG_DIR)
    
    # Test session_name contains slash
    session_name = r'~/.httpie/sessions/detectportal.firefox.com/session_slash.json'
    session = get_httpie_session(config_dir, session_name, host=None, url=url)
    
    # Test session_name does not contains slash
    session_name = r'session_no_slash'
    session = get_httpie_session(config_dir, session_name, host=None, url=url)


# Generated at 2022-06-21 14:49:29.148571
# Unit test for function get_httpie_session
def test_get_httpie_session():

    # a valid new session name
    mock_base_dir = Path("./tests/")
    mock_sessions_dir = mock_base_dir / SESSIONS_DIR_NAME
    assert get_httpie_session(mock_base_dir, session_name="123456789", host=None,
                              url="http://www.example.com")
    mock_session_dict = (mock_sessions_dir / "www_example_com" / "123456789.json")
    assert mock_base_dir.is_dir()
    assert mock_session_dict.is_file()

    # using unix socket
    mock_base_dir = Path("./tests/")

# Generated at 2022-06-21 14:49:40.217638
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {
        'Accept': '*/*',
        'Content-Type': 'application/json',
        'Content-Length': '30',
        'User-Agent': 'HTTPie/0.9.2',
        'Connection': 'keep-alive',
        'Cookie': 'session=somelongstring'
    }
    session = Session('test')
    session.update_headers(request_headers)
    assert session['headers']['Accept'] == '*/*'
    assert session['headers']['User-Agent'] == 'HTTPie/0.9.2'
    assert session['headers']['Connection'] == 'keep-alive'
    assert 'Cookie' not in session['headers']
    assert session['cookies']['session'] == {'value': 'somelongstring'}

# Generated at 2022-06-21 14:49:44.943833
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(None)
    s['cookies'] = {'foo': {}, 'bar': {}, 'baz': {}}
    s.remove_cookies(['foo','baz'])
    assert s['cookies'] == {'bar':{}}

# Generated at 2022-06-21 14:49:51.868712
# Unit test for constructor of class Session
def test_Session():
    # test null
    Session1 = Session(None)
    assert Session1['headers'] == {}
    assert Session1['cookies'] == {}
    # test str
    Session2 = Session("/test/test")
    assert Session2['headers'] == {}
    assert Session2['cookies'] == {}
    # test path
    Session3 = Session(Path("/test/test"))
    assert Session3['headers'] == {}
    assert Session3['cookies'] == {}

# Generated at 2022-06-21 14:50:00.846269
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import DEFAULT_SESSIONS_DIR
    import os
    import shutil
    config_dir = Path('.httpie')
    config_dir.mkdir(exist_ok=True)
    DEFAULT_SESSIONS_DIR.mkdir(exist_ok=True)
    url = 'https://example.com'
    session = get_httpie_session(config_dir, 'test_session', None, url)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth']['type'] == None
    assert session['auth']['username'] == None
    assert session['auth']['password'] == None
    shutil.rmtree(config_dir)
    return

# Generated at 2022-06-21 14:50:05.888227
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from scripts.tests.functional.utils import get_test_config_dir
    config_dir = get_test_config_dir()
    session_name = 's'
    host = 'localhost'
    url = 'http://localhost/'
    assert get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-21 14:50:18.234418
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    print(session.headers)
    print(session.cookies)
    print(session.auth)


    headers = {}
    session.update_headers(headers)
    print(session.headers)
    print(session.cookies)
    print(session.auth)

    headers = {
        'key1': 'value1',
        'key2': 'value2',
    }
    session.update_headers(headers)
    print(session.headers)
    print(session.cookies)
    print(session.auth)


    headers = {
        'key2': 'value2',
    }
    session.update_headers(headers)
    print(session.headers)
    print(session.cookies)
    print(session.auth)


# Generated at 2022-06-21 14:50:20.943183
# Unit test for constructor of class Session
def test_Session():
    session_instance = Session('an instance of Session')
    assert 'headers' in session_instance.keys()
    assert 'cookies' in session_instance.keys()
    assert 'auth' in session_instance.keys()
    assert 'type' in session_instance['auth'].keys()
    assert 'username' in session_instance['auth'].keys()
    assert 'password' in session_instance['auth'].keys()


# Generated at 2022-06-21 14:50:23.894081
# Unit test for function get_httpie_session
def test_get_httpie_session():
    test_session = get_httpie_session(
        Path(__file__).parent, 'test', 'google.com', 'http://google.com')
    assert test_session['path'] == Path(__file__).parent / 'test.json'

# Generated at 2022-06-21 14:50:31.452632
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    # For testing purposses
    config_dir = Path(__file__).parent
    session_name = "session"
    host = "example.com"
    url = "https://example.com"
    session = get_httpie_session(config_dir, session_name, host, url)
    assert isinstance(session, Session)
    assert session.path == Path(__file__).parent / SESSIONS_DIR_NAME / "example_com" / "session.json"

# Generated at 2022-06-21 14:50:41.110212
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('session_file_path')
    session.load()
    request_headers = {}
    request_headers['user-agent'] = 'HTTPie/0.9.2'
    request_headers['content-type'] = 'application/json'
    session.update_headers(request_headers)
    assert session.headers == {}

# Generated at 2022-06-21 14:50:42.241476
# Unit test for constructor of class Session
def test_Session():
    assert Session('/')


# Generated at 2022-06-21 14:50:45.738513
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('session')
    s.update({'cookies': {'a': {'value': '1'}, 'b': {'value': '2'}}})
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-21 14:50:57.238157
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='')
    session.update_headers(RequestHeadersDict({
        'Accept-Language': 'zh-CN',
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': '0',
        'Cookie': 'foo=bar',
        'User-Agent': 'HTTPie/2.2.0'
    }))
    assert session.headers == {
        'Accept-Language': 'zh-CN',
        'Content-Type': 'application/json; charset=utf-8',
        'User-Agent': 'HTTPie/2.2.0'
    }
    assert session.cookies.get('foo') == {'value': 'bar'}

# Generated at 2022-06-21 14:51:09.328954
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(0)
    assert (s.headers == {})
    s.update_headers({'a':'b', 'c': 'd'})
    assert (s.headers == {'a': 'b', 'c': 'd'})
    s.update_headers({'a':'b'})
    assert (s.headers == {'a': 'b', 'c': 'd'})
    s.update_headers({'c':'e'})
    assert (s.headers == {'a': 'b', 'c': 'e'})
    s.update_headers({'user-agent':'HTTPie/0.9.3'})
    assert (s.headers == {'a': 'b', 'c': 'e'})

# Generated at 2022-06-21 14:51:16.666208
# Unit test for constructor of class Session
def test_Session():
    path = '/Users/wang/.httpie/sessions/localhost/test.json'
    test = Session(path)
    test['headers'] = {'a': 'b'}
    assert(test['headers'] == {'a': 'b'})
    test['cookies'] = {'a': 'b'}
    assert(test['cookies'] == {'a': 'b'})
    test['auth'] = {'type': 'a', 'username': 'b', 'password': 'c'}
    assert(test['auth'] == {'type': 'a', 'username': 'b', 'password': 'c'})



# Generated at 2022-06-21 14:51:25.914982
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path("test.json"))
    session['cookies'] = {
        'cookie_name1':{'value':'cookie_value1','expires': None},
        'cookie_name2':{'value':'cookie_value2','expires': None},
        'cookie_name3':{'value':'cookie_value3','expires': None},
        'cookie_name4':{'value':'cookie_value4','expires': None},
        'cookie_name5':{'value':'cookie_value5','expires': None},
    }
    session.remove_cookies(names=['cookie_name1', 'cookie_name2'])

# Generated at 2022-06-21 14:51:30.342152
# Unit test for constructor of class Session
def test_Session():
    # not exist session
    a = Session('/Users/some_path/some_session.json')
    a['headers']={'a': 1, 'b': 2}
    assert a['headers'] == {'a': 1, 'b': 2}



# Generated at 2022-06-21 14:51:37.051945
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies')
    session['cookies'] = {'cookie1': {'value':'value1'}, 'cookie2': {'value':'value2'}}
    session.remove_cookies(['cookie1'])
    session.remove_cookies(['cookie2'])
    session.remove_cookies(['cookie3'])

    assert session['cookies'] == {}


# Generated at 2022-06-21 14:51:40.634205
# Unit test for constructor of class Session
def test_Session():
    # Call constructor of Session
    session = Session(path='./sessions/localhost/session_0.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-21 14:51:51.510767
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert isinstance(get_httpie_session(Path(), 'session_name', 'localhost', 'http://localhost/'), Session)

# Generated at 2022-06-21 14:51:55.849194
# Unit test for constructor of class Session
def test_Session():
    s = Session("dummy")
    assert s.get('headers') == {}
    assert s.get('cookies') == {}
    assert s.get('auth') == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-21 14:51:57.523299
# Unit test for constructor of class Session
def test_Session():
    session = Session('abc')
    assert session.path == 'abc'
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}

test_Session()

# Generated at 2022-06-21 14:52:04.041260
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(__file__).parent.parent / 'tests/fixtures' / 'config'
    session = get_httpie_session(config_dir, 'test-session', '', '')
    assert session.name == 'test-session'
    assert session.path == Path(
        config_dir / SESSIONS_DIR_NAME / 'test_session.json')


# Generated at 2022-06-21 14:52:12.280534
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import json
    session = Session('')

    request_headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "If-None-Match": "xxx",
        "Cookie": "key1=value1; key2=value2",
        "user-agent": "HTTPie/1.0.3"
    }
    session.update_headers(request_headers)
    session_json = json.loads(json.dumps(session))
    assert session_json["headers"] == {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "user-agent": "HTTPie/1.0.3"
    }

# Generated at 2022-06-21 14:52:19.500646
# Unit test for constructor of class Session
def test_Session():
    """Tests the constructor of class Session"""
    my_path = Path('/home/user/.httpie/sessions/localhost/my_session.json')
    my_session = Session(my_path)
    assert my_session.path == my_path
    assert my_session['headers'] == {}
    assert my_session['cookies'] == {}
    assert my_session['auth']['type'] == None
    assert my_session['auth']['username'] == None
    assert my_session['auth']['password'] == None


# Generated at 2022-06-21 14:52:23.267420
# Unit test for constructor of class Session
def test_Session():
    session = Session('.config_file')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth']['type'] == None
    assert session['auth']['username'] == None
    assert session['auth']['password'] == None

# Generated at 2022-06-21 14:52:27.448496
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session_name = 'example_session'
    url = 'https://httpbin.org/get'
    session = get_httpie_session(
        DEFAULT_SESSIONS_DIR, session_name, None, url
    )
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:52:33.060911
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    s.remove_cookies(['a', 'd'])

    assert 'a' not in s['cookies']
    assert 'd' not in s['cookies']
    assert s['cookies'] == {'b': 2, 'c': 3}

# Generated at 2022-06-21 14:52:41.133101
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/')
    s.cookies = RequestsCookieJar()
    s.cookies.set('name1', 'value1')
    s.cookies.set('name2', 'value2')
    s.cookies.set('name3', 'value3')
    assert len(s.cookies) == 3
    s.remove_cookies(['name1', 'name2'])
    assert len(s.cookies) == 1
    assert s.cookies == ['name3', 'value3']



# Generated at 2022-06-21 14:52:55.803507
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict({
        'Host': 'example.org',
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'X-Custom-Header': 'Custom-Value',
        'If-None-Match': 'something',
        'If-Modified-Since': 'whatever',
        'User-Agent': 'HTTPie/0.9.9',
        'Connection': 'close'
    })
    url = 'https://example.org/get?foo=bar'
    session = get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='example.org',
        host='example.org',
        url=url
    )
    session.update_headers(request_headers)

# Generated at 2022-06-21 14:53:00.473769
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(__file__).parent.parent.parent / 'config'
    config_dir.mkdir(exist_ok=True)
    session_name = 'session_1'
    host = 'www.example.com'
    url = 'http://www.example.com/'
    assert get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-21 14:53:04.292095
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'test_session', 'hostname', 'https://httpie.org').path == DEFAULT_SESSIONS_DIR / 'hostname' / 'test_session.json'




# Generated at 2022-06-21 14:53:09.813821
# Unit test for function get_httpie_session
def test_get_httpie_session():
    import os
    from httpie.config import DEFAULT_CONFIG_DIR
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'sessions', 'host', 'url')
    assert os.path.isdir(DEFAULT_CONFIG_DIR / 'sessions')
    assert (DEFAULT_CONFIG_DIR / 'sessions' / 'host' / 'sessions.json').exists()

# Generated at 2022-06-21 14:53:13.850916
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    session = Session('test.json')
    session.update_headers(RequestHeadersDict({'a': 1, 'b': '2'}))

# Generated at 2022-06-21 14:53:23.393239
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    config = Config(config_dir=None)
    session_name = 'test_session'
    session_path = (config.config_dir / SESSIONS_DIR_NAME / session_name)
    session_path.mkdir(parents=True)
    session_path = (config.config_dir / SESSIONS_DIR_NAME / session_name /
                    f'{session_name}.json')
    session_file = Path(__file__).parent / 'test_session.json'
    session_file.touch()
    session_file.rename(session_path)
    session = get_httpie_session(config.config_dir, session_name, None, "https://httpbin.org/cookies/set?k1=v1")

# Generated at 2022-06-21 14:53:27.037941
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('.')
    request_headers = {
        'content-length': None,
        'content-type': 'application/json'
    }

    session.update_headers(request_headers)

    assert 'Content-Length' in session.headers
    assert 'Content-Type' in session.headers

# Generated at 2022-06-21 14:53:31.869859
# Unit test for constructor of class Session
def test_Session():
    """ Test the constructor of Session class """
    session = Session(path='./')
    assert session.get('headers') == {}
    assert session.get('cookies') == {}
    assert session.get('auth') == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-21 14:53:34.680860
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='path')
    assert session.remove_cookies(['name1','name2']) == None
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:53:37.750308
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert Session.remove_cookies(None, []) == None
    test_Session = Session("/tmp/test.json")
    assert test_Session.remove_cookies(['test']) == None

# Generated at 2022-06-21 14:53:56.386832
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(Path("."), "test", "localhost", "http://localhost") is not None

# Generated at 2022-06-21 14:54:07.624793
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='s01',
        host='example.com',
        url='http://example.com/'
    ) == Session(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'example.com' / 's01.json')
    assert get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='s02',
        host='1.2.3.4:20',
        url='http://1.2.3.4:20/'
    ) == Session(DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / '1_2_3_4_20' / 's02.json')

# Generated at 2022-06-21 14:54:13.797186
# Unit test for constructor of class Session
def test_Session():
    sess = Session(path=Path('sessions/test_Session.json'))
    assert sess['headers'] == {}
    assert sess['cookies'] == {}
    assert sess['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    assert sess.headers == {}
    assert sess.cookies == {}
    assert sess.auth is None
    sess.remove_cookies([])


# Generated at 2022-06-21 14:54:18.121969
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = "https://www.google.com"
    session_name = "google"
    host = "google.com"
    path = '/Users/subhastin/.config/httpie/sessions/google/google.json'
    expected_result = Session(path)
    expected_result.load()
    result = get_httpie_session(DEFAULT_CONFIG_DIR, session_name, host, url)
    assert result == expected_result

# Generated at 2022-06-21 14:54:28.934109
# Unit test for constructor of class Session
def test_Session():
    # test_session_1
    config_dir = Path('./config/')
    session_name = 'session_1'
    host = None
    url = 'http://www.baidu.com'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert isinstance(session, Session)
    # test_session_2
    config_dir = Path('./config/')
    session_name = 'session_2'
    host = 'www.baidu.com'
    url = 'http://www.baidu.com'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert isinstance(session, Session)
    # test_session_3
    config_dir = Path('./config/')


# Generated at 2022-06-21 14:54:39.439662
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.output.streams import write_response_headers_to_output,\
        write_response_body_to_output
    from httpie.sessions import get_httpie_session

    # Test 1
    env = Environment()
    conf = Config(env)
    conf.output_options.output_dir = "./test"
    conf.output_options.output_options = ["session=session1"]
    conf.output_options.output_options_as_json = False
    conf.output_options.output_options_as_table = False
    conf.output_options.output_options_as_values = False
    conf.output_options.output_options_as_code = False
    conf.output_options.output_file_options

# Generated at 2022-06-21 14:54:40.476618
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-21 14:54:42.780441
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session(Path("/root/.config/httpie/sessions"), "testSession", "testSession", "testSession")

# Generated at 2022-06-21 14:54:48.031283
# Unit test for function get_httpie_session
def test_get_httpie_session():
    '''
    Test get_httpie_session.
    '''
    session = get_httpie_session('C:\\Users\\Username\\.httpie',
                                 'my session',
                                 'local.com',
                                 'http://local.com/test')
    assert session.path == 'C:\\Users\\Username\\.httpie\\sessions\\local_com\\my_session.json'

# Generated at 2022-06-21 14:54:57.588389
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    from httpie.compat import urlunparse

    config = Config()
    config.config_dir.mkdir(parents=True)
    session = get_httpie_session(config.config_dir, 'session-name', '', '')
    session.save()
    assert (config.config_dir / 'sessions' / 'session-name.json').exists()

    session = get_httpie_session(
        config.config_dir, '/tmp/session-name', '',
        urlunparse(('http', 'example.com', '', '', '', ''))
    )
    session.save()
    assert Path('/tmp/session-name.json').exists()

