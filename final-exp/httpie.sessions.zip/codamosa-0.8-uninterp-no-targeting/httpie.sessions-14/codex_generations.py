

# Generated at 2022-06-21 14:45:02.318483
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(Path(''), 'session_name', 'example.com', 'url')



# Generated at 2022-06-21 14:45:08.720739
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = { "Content-Type": "application/json" }
    session = Session("/tmp/test_Session_update_headers")
    session["headers"] = headers
    request_headers = {
        "Content-Type": "application/json",
        "If-Match": "*"
    }
    session.update_headers(request_headers)
    assert session["headers"] == { "Content-Type": "application/json" }

# Generated at 2022-06-21 14:45:13.203712
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # arrange
    default_config_dir = DEFAULT_CONFIG_DIR
    session_name = 'session name'
    host = 'host'
    url = 'url'

    result = get_httpie_session(default_config_dir, session_name, host, url)

    assert type(result) is Session

# Generated at 2022-06-21 14:45:20.835785
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path = 'test')
    req = RequestHeadersDict({
        'accept': 'application/json',
        'cookie': 'foo=bar; name=val'
    })

    session.update_headers(req)

    assert req == RequestHeadersDict({'accept': 'application/json'})
    assert session.cookies == RequestsCookieJar([
        create_cookie(name='name', value='val'),
        create_cookie(name='foo', value='bar')
    ])
    assert session.headers == RequestHeadersDict({'accept': 'application/json'})

# Generated at 2022-06-21 14:45:24.429646
# Unit test for constructor of class Session
def test_Session():
    ses = Session('tests/sessions/foo.json')
    assert str(ses.path) == 'tests/sessions/foo.json'
    ses = Session('tests/sessions/bar.json')
    assert str(ses.path) == 'tests/sessions/bar.json'

# Generated at 2022-06-21 14:45:29.133981
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from copy import copy
    from httpie.compat import urlunparse

    url = urlunparse(('http', 'example.org', '/', '', '', ''))
    request_headers = RequestHeadersDict([('Content-Type', 'application/json')])
    request_headers['Content-Length'] = '10'
    request_headers['Content-Encoding'] = 'gzip'
    request_headers['If-Match'] = '"abc123"'
    request_headers['Cookie'] = 'a=2'
    request_headers['User-Agent'] = 'Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0'
    request_headers['host'] = 'example.org'

# Generated at 2022-06-21 14:45:33.781741
# Unit test for constructor of class Session
def test_Session():
    print(Session(Path.cwd()))
    x=Session(Path.cwd())
    print(x.load())
    print(x.headers)
    print(x.cookies)
    print(x.auth)
    print(x.remove_cookies(1))

if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-21 14:45:40.650033
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./test')
    session['headers'] = {}
    request_headers = {'Content-Type': 'application/json','If-MatcH': 'all','Accept': 'application/json'}
    session.update_headers(request_headers)
    keys = session['headers'].keys()
    assert (len(keys) == 1)
    assert ('Accept' in keys)

# Generated at 2022-06-21 14:45:52.794937
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import unittest

    from httpie.cli.dicts import RequestHeadersDict

    class SessionTest(unittest.TestCase):

        def test_update_headers(self):
            from httpie.cli.dicts import RequestHeadersDict

            session = Session('./')

            session.update_headers(RequestHeadersDict({}))
            self.assertEqual(session['headers'], {})

            session.update_headers(RequestHeadersDict({'User-Agent': 'HTTPie/y'}))
            self.assertEqual(session['headers'], {})

            # value is None
            session.update_headers(RequestHeadersDict({'User-Agent': None}))
            self.assertEqual(session['headers'], {})


# Generated at 2022-06-21 14:45:53.848834
# Unit test for function get_httpie_session
def test_get_httpie_session():
    get_httpie_session = get_httpie_session('', '', '', '')

# Generated at 2022-06-21 14:46:09.143605
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import ExitStatus
    from httpie.core import main

    session = Session('test_session_file')

    config_dir = Path('test_dir')
    config_dir.mkdir()
    DEFAULT_SESSIONS_DIR.mkdir()
    DEFAULT_SESSIONS_DIR / 'localhost'.replace(':', '_')
    DEFAULT_SESSIONS_DIR / 'localhost'.replace(':', '_') / 'test_session_file.json'
    DEFAULT_SESSIONS_DIR / 'localhost'.replace(':', '_') / 'test_session_file.json'


# Generated at 2022-06-21 14:46:14.878311
# Unit test for function get_httpie_session
def test_get_httpie_session():
    test_config_dir = Path("config_dir")
    test_url = "http://localhost:80/path?arg=val"

    default_session = get_httpie_session(test_config_dir, "default", None, test_url)
    assert str(default_session.path) == "config_dir/sessions/localhost/default.json"

    test_session = get_httpie_session(test_config_dir, "test", None, test_url)
    assert str(test_session.path) == "config_dir/sessions/localhost/test.json"

    test_2_session = get_httpie_session(test_config_dir, "test_2", None, test_url)

# Generated at 2022-06-21 14:46:21.201669
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('./config_dir')
    session_name = 'test_session'
    url = 'https://www.baidu.com?wd=test'
    session = get_httpie_session(config_dir, session_name, None, url)
    assert session.path == config_dir / SESSIONS_DIR_NAME / 'www_baidu_com' / f'{session_name}.json'
    assert session.headers is not None
    assert session.cookies is not None
    assert session.auth is not None

# Generated at 2022-06-21 14:46:28.493594
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('Path')
    request_headers = {
        'Content-Type': 'application/json',
        'Cookie': 'key=value',
        'If-Match': 'value'
    }
    session.update_headers(request_headers)
    assert session.headers['Content-Type'] != 'application/json'
    assert session.headers['Cookie'] != 'key=value'
    assert session.headers['If-Match'] != 'value'

# Generated at 2022-06-21 14:46:32.097565
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test1 = Session('/')
    request_headers = {'Content-Type': 'test'}
    test1.update_headers(request_headers)
    assert test1['headers'] == {'Content-Type': 'test'}

# Generated at 2022-06-21 14:46:41.384711
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    host = 'foo.com'
    url = f'http://{host}'
    session_name = 'foo'
    session = get_httpie_session(DEFAULT_CONFIG_DIR, session_name, host, url)
    path = (
        DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME
        / host / f'{session_name}.json'
    )
    assert session.path == path.resolve()
    assert session == {'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}

# Generated at 2022-06-21 14:46:43.702432
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert isinstance(get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', None, 'http://httpbin.org/get'), Session)

# Generated at 2022-06-21 14:46:53.808946
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('t.json')
    s.update_headers({'A': 'B', 'Cookie': 'D=E'})
    assert s['headers'] == {'A': 'B'}
    assert s['cookies'] == {'D': {'value': 'E'}}
    s.update_headers({'A': 'B', 'Cookie': 'D=E', 'Cookie': 'F=G'})
    assert s['headers'] == {'A': 'B'}
    assert s['cookies'] == {'D': {'value': 'E'}, 'F': {'value': 'G'}}



# Generated at 2022-06-21 14:46:58.632712
# Unit test for constructor of class Session
def test_Session():
    session = Session("/path/to/session")
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}

    assert isinstance(session.headers, RequestHeadersDict)
    assert isinstance(session.cookies, RequestsCookieJar)
    assert isinstance(session.auth, Optional)

# Generated at 2022-06-21 14:47:09.045787
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_Session_update_headers')
    session.update_headers({'name': 'John'})
    assert session['headers'] == {'name': 'John'}
    session.update_headers({'name': 'Jane'})
    assert session['headers'] == {'name': 'Jane'}
    session.update_headers({'name': None})
    assert session['headers'] == {}
    session.update_headers({'Cookie': 'name=John'})
    assert session['cookies'] == {'name': {'value': 'John'}}
    session.update_headers({'Cookie': 'name=Jane'})
    assert session['cookies'] == {'name': {'value': 'Jane'}}

# Generated at 2022-06-21 14:47:13.505576
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass

# Generated at 2022-06-21 14:47:23.734397
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import CaseInsensitiveDict
    from requests.cookies import RequestsCookieJar
    from requests.models import PreparedRequest

    request_headers=CaseInsensitiveDict({
        'Content-Type': 'application/json',
        'Content-Length': '100',
        'Cookie': 'name=value',
        'Authorization': 'Basic 1234',
        'X-Custom-Header': '12345',
        'If-Match': '*',
        'If-None-Match': '*',
        'If-Modified-Since': '12345',
        'If-Unmodified-Since': '123456'
    })

    session = Session(path=Path('path/to/sessions'))
    session.update_headers(request_headers)


# Generated at 2022-06-21 14:47:29.863283
# Unit test for constructor of class Session
def test_Session():
    import os
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.auth.basic import BasicAuthPlugin
    username = 'admin'
    password = 'password'
    url = 'http://httpbin.org'
    hostname = urlsplit(url).netloc.split('@')[-1]
    path = os.path.expanduser('~/.config/httpie/sessions/' + hostname + '/test.json')
    session = Session(path)
    request_header = {'User-Agent': 'HTTPie/0.9.3'}
    session.update_headers(request_header)
    jar = RequestsCookieJar()
    jar.set_cookie(create_cookie('cookie_name', 'cookie_value'))
    session.cookies = jar
    plugin

# Generated at 2022-06-21 14:47:33.437248
# Unit test for constructor of class Session
def test_Session():
    session = Session("/home/httpie/.config/httpie/sessions/google.com:80/my.json")
    print(session['headers'])
    print(session['cookies'])
    print(session['auth'])


# Generated at 2022-06-21 14:47:36.189766
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Call the get_httpie_session function with arguments.
    get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-21 14:47:47.088620
# Unit test for constructor of class Session
def test_Session():
    # test correct session name
    s = Session('/home/tester/.config/httpie/sessions/example.com/test_session.json')
    assert s.path == Path('/home/tester/.config/httpie/sessions/example.com/test_session.json')
    assert s['cookies'] == {}
    assert s['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

    # test incorrect session name
    try:
        s = Session('/home/tester/.config/httpie/sessions/example.com/incorrect/session.json')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-21 14:47:53.913493
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    from httpie.plugins import builtin
    from httpie import __file__ as httpie_path

    httpie_path = os.path.dirname(os.path.abspath(httpie_path))
    conf = Config(httpie_path, 'default')

    for name in builtin.AUTH_PLUGINS:
        conf.env['HTTPIE_AUTH_' + name.upper()] = 'ignore'

    session = get_httpie_session(conf.config_dir, 'yandex', '', '')

    # check loaded session
    assert session.path == conf.config_dir / SESSIONS_DIR_NAME / 'yandex.json'

    # check session _store

# Generated at 2022-06-21 14:47:59.368848
# Unit test for constructor of class Session
def test_Session():
    session = Session('./configuration.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    assert session.headers == RequestHeadersDict(session['headers'])


# Generated at 2022-06-21 14:48:03.994686
# Unit test for constructor of class Session
def test_Session():
    dir_ = Path("~/.config")
    session_name = "test"
    host = "httpbin.org"
    url = "http://httpbin.org"
    s = get_httpie_session(dir_, session_name, host, url)
    assert s


# Generated at 2022-06-21 14:48:14.797411
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    new_session = Session('./test_session.json')
    new_session['cookies'] = dict()
    new_session['cookies']['session'] = {
        'value': 's%3A3oqg2nsdvnxjxfnkm7hg8pf9e11vkpknp.zKiF%2FHRzkPZo'
        'mQa8n1X9USm%2FyAaf0yYIYwYaMK7aqo'
    }
    new_session.remove_cookies(['session'])
    import json

# Generated at 2022-06-21 14:48:23.771599
# Unit test for constructor of class Session
def test_Session():
    testSession = SESSIONS_DIR_NAME + '/' + 'session.json'
    session = Session(testSession)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}



# Generated at 2022-06-21 14:48:30.343045
# Unit test for constructor of class Session
def test_Session():
    test_Session_instance = Session('/home/ihoswate/.httpie/sessions/localhost_80/test.json')
    test_Session_instance['headers'] = {}
    test_Session_instance['cookies'] = {}
    test_Session_instance['auth'] = {'type': None, 'username': None, 'password': None}
    assert test_Session_instance['headers'] == {}
    assert test_Session_instance['cookies'] == {}
    assert test_Session_instance['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-21 14:48:35.321816
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_test = Session('test')
    session_test.cookies = {'a':'b','c':'d','e':'f'}
    session_test.remove_cookies(['a','c'])
    assert session_test.cookies == {'e':'f'}

# Generated at 2022-06-21 14:48:38.981259
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPBasicAuth

    # Create temp version of /usr/local/lib/python3.7/site-packages/httpie/config.json
    temp_path = f'/tmp/httpie-config-{os.getpid()}.json'
    temp_path_exists = False


# Generated at 2022-06-21 14:48:43.867312
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_names = ["foo", "bar"]
    session = Session("test/fixtures/sessions/test.json")
    session.load()
    session.remove_cookies(cookie_names)
    for name in cookie_names:
        assert name not in session['cookies']

# Generated at 2022-06-21 14:48:49.770059
# Unit test for constructor of class Session
def test_Session():
    session_test = Session('test_session')
    assert (
        session_test['headers'] == {}
    )
    assert (
        session_test['cookies'] == {}
    )
    assert (
        session_test['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }
    )


# Generated at 2022-06-21 14:48:57.700649
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    sess = Session(Path())
    sess['headers'] = {'A': '1', 'B': '2'}

    headers = RequestHeadersDict()
    headers['C'] = '3'
    headers['A'] = '0'
    headers['Content-Type'] = 'application/x-www-form-urlencoded'
    sess.update_headers(headers)
    assert sess['headers'] == {'A': '0', 'B': '2', 'C': '3'}

    # TODO: Test cookies
    # TODO: Test auth

# Generated at 2022-06-21 14:49:05.770385
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session({'cookies': {'one':{'value':'1'}, 'two':{'value':'2'}, 'three':{'value':'3'}}})
    assert session.cookies == {'one':{'value':'1'}, 'two':{'value':'2'}, 'three':{'value':'3'}}
    session.remove_cookies(['two'])
    assert session.cookies == {'one':{'value':'1'}, 'three':{'value':'3'}}

# Generated at 2022-06-21 14:49:11.343934
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess = Session('./sessions/hostname/name.json')
    sess.cookies = RequestsCookieJar()
    sess.cookies.set('a', '1')
    assert sess['cookies']['a']['value'] == '1'

    sess.remove_cookies(['a'])
    assert 'a' not in sess['cookies']



# Generated at 2022-06-21 14:49:13.274880
# Unit test for constructor of class Session
def test_Session():
    session = Session('/test/test.json')
    assert session['headers'] == {}

# Generated at 2022-06-21 14:49:29.907542
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='./test.json')
    session.update_headers({"Hello": "World"})
    assert session["headers"] == {"Hello": "World"}
    session.update_headers({"Content-Length": "1234"})
    assert session["headers"] == {"Hello": "World"}
    session.update_headers({"If-Match": "19980213"})
    assert session["headers"] == {"Hello": "World"}
    session.update_headers({"cookie": "123"})
    assert session["headers"] == {"Hello": "World"}

# Generated at 2022-06-21 14:49:36.043257
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Create an empty Session
    session = Session(path="/tmp/test_update_headers.json")

    # Add headers
    session.update_headers({'Header1': 'Value1', 'Header2': 'Value2'})

    # Check
    assert session['headers'] == {'Header1': 'Value1', 'Header2': 'Value2'}



# Generated at 2022-06-21 14:49:47.113283
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    auth = {'type': None, 'username': None, 'password': None}
    session_headers1 = {}
    session_headers2 = {}
    session_headers3 = {}
    session_headers4 = {}
    headers1 = {}
    headers2 = {}
    headers3 = {}
    headers4 = {}
    headers5 = {}
    headers6 = {}
    headers7 = {}
    headers8 = {}
    session1 = Session(path = "")
    session2 = Session(path = "")
    session3 = Session(path = "")
    session4 = Session(path = "")
    session1['headers'] = session_headers1
    session2['headers'] = session_headers2
    session3['headers'] = session_headers3
    session4['headers'] = session_headers4

# Generated at 2022-06-21 14:49:52.584239
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test.json')
    s['cookies'] = {
        'cookie1': {'value': 'test1'},
        'cookie2': {'value': 'test2'},
    }
    s.remove_cookies(['cookie1'])
    assert s['cookies'] == {
        'cookie2': {'value': 'test2'},
    }

# Generated at 2022-06-21 14:50:02.142262
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Creating a Session object
    session = Session('tests/sessions/test_session_update_headers.json')
    # Creating a RequestHeadersDict object
    request_headers = RequestHeadersDict()
    # Adding headers to the RequestHeadersDict object
    request_headers['Content-Type'] = 'application/json'
    request_headers['Accept'] = '*/*'
    request_headers['Accept-Encoding'] = 'gzip, deflate'
    request_headers['Accept-Language'] = 'en-US,en;q=0.5'
    request_headers['If-Modified-Since'] = 'Tue, 05 Jun 2018 12:50:00 GMT'
    request_headers['User-Agent'] = 'HTTPie/1.0.3'
    # Calling the update_headers method
    session.update_headers

# Generated at 2022-06-21 14:50:14.092217
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.plugins.builtin import HTTPBasicAuth
    # None type value
    s = Session('/test.json')
    s.update_headers({'user-agent': None, 'test': 'test'})
    assert s['headers'] == {'test': 'test'}

    # remove cookies type value
    s = Session('/test.json')
    s.update_headers({'cookie': 'user=test; pwd=123'})
    assert s['cookies'] == {'user': {'value': 'test'}, 'pwd': {'value': '123'}}

    # ignored headers
    s = Session('/test.json')
    s.update_headers({'Content-Length': '123'})
    assert s['headers'] == {}

# Generated at 2022-06-21 14:50:18.913459
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path('/tmp'))
    session['cookies'] = {'a': 1, 'b': 2}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': 2}


# Generated at 2022-06-21 14:50:23.607347
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        DEFAULT_CONFIG_DIR, 'test_session', '', 'http://example.com/')
    assert isinstance(session, Session)
    assert VALID_SESSION_NAME_PATTERN.match(session.path.name)
    assert session.path == DEFAULT_CONFIG_DIR / 'sessions/example.com/test_session.json'

# Generated at 2022-06-21 14:50:35.134245
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('.'))
    # Test updating a cookie from the request headers
    request_headers = RequestHeadersDict()
    request_headers.add_header('Cookie', 'a=b')
    session.update_headers(request_headers)
    assert session['cookies'] == {'a': {'value': 'b'}}

    # Test updating a cookie from the request headers along with other headers
    request_headers = RequestHeadersDict()
    request_headers.add_header('Cookie', 'a=b')
    request_headers.add_header('Content-Type', 'application/json')
    request_headers.add_header('If-None-Match', 'etag')
    session.update_headers(request_headers)

# Generated at 2022-06-21 14:50:43.229165
# Unit test for constructor of class Session
def test_Session():
    session = Session('unit_test.json')
    assert session.__contains__('headers') == True
    assert session['headers'] == {}
    assert session.__contains__('cookies') == True
    assert session['cookies'] == {}
    assert session.__contains__('auth') == True
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
    }
    assert os.path.exists('unit_test.json') == None


# Generated at 2022-06-21 14:51:01.209762
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    session.update_headers({'content-length': '123'})
    assert session.headers == {}

    session.update_headers({'user-agent': 'HTTPie/1.1'})
    assert session.headers == {}

    session.update_headers({'cookie': 'name=value'})
    assert session.headers == {}

    session.update_headers({'Host': 'hello.com'})
    assert session.headers == {'Host': 'hello.com'}

    session.update_headers({'If-None-Match': '123'})
    assert session.headers == {'Host': 'hello.com'}

    session.update_headers({'content-length': '456', 'host': 'HOST.COM'})

# Generated at 2022-06-21 14:51:06.648239
# Unit test for constructor of class Session
def test_Session():
    s = Session("/foo/bar")
    assert {"headers": {}, "cookies": {}} == s
    s = Session("/foo/bar")
    s["headers"] = {"a": "b"}
    assert {"headers": {"a": "b"}, "cookies": {}} == s


# Unit tests for function get_httpie_session

# Generated at 2022-06-21 14:51:09.096861
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/tmp/httpie')
    session_name = 'test'
    host = 'www.baidu.com'
    url = 'http://www.baidu.com/index.html'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session['headers']['Host'] == host
    assert session_name in session.path.name
    assert 'httpie-session' in session.about

# Generated at 2022-06-21 14:51:17.699122
# Unit test for function get_httpie_session
def test_get_httpie_session():

    # Set up variables
    config_dir = DEFAULT_CONFIG_DIR
    session_name = "test_session"
    url = "http://localhost:1234/test/test"

    # Check simple call for default httpie
    session = get_httpie_session(config_dir, session_name, None, url)
    assert session is not None
    assert session_name in str(session)

    # Check simple call for httpie with a host
    session = get_httpie_session(config_dir, session_name, "test.com", url)
    assert session is not None
    assert session_name in str(session)

    # Check simple call for https call
    session = get_httpie_session(config_dir, session_name, None, "https://localhost")
    assert session is not None
    assert session_

# Generated at 2022-06-21 14:51:25.608156
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='/tmp/httpie-test.json')
    session.update_headers({})
    assert session['headers'] == {}
    session.update_headers({'HOST': 'www.example.com'})
    assert session['headers'] == {'HOST': 'www.example.com'}
    session.update_headers({'If-Match': 'a'})
    assert session['headers'] == {'HOST': 'www.example.com'}
    session.update_headers({'Content-Type': 'text/html; charset=UTF-8'})
    assert session['headers'] == {'HOST': 'www.example.com'}

# Generated at 2022-06-21 14:51:30.340692
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test")
    session.update_headers(RequestHeadersDict({"Ansible": "3.4.4", "Kubernetes": "1.10"}))
    assert session.headers["Ansible"][0] == '3.4.4'

# Generated at 2022-06-21 14:51:34.377768
# Unit test for function get_httpie_session
def test_get_httpie_session():
    name = 'test'
    host = 'www.baidu.com'
    url = 'https://www.baidu.com'
    get_httpie_session(DEFAULT_SESSIONS_DIR, name, host, url)

# Generated at 2022-06-21 14:51:39.016211
# Unit test for constructor of class Session
def test_Session():
    s = Session('/Users/nen/.config/httpie/sessions/localhost/default.json')
    print(s)
    print(s['headers'])
    print(s['cookies'])
    print(s['auth'])


if __name__ == '__main__':
    test_Session()

# Generated at 2022-06-21 14:51:49.099325
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(__file__).parent.parent / 'docs' / '_static' / 'httpie' / 'config' / 'http'
    session_name = 'test1'
    host = None
    url = 'http://localhost:8000/headers'
    s = get_httpie_session(config_dir, session_name, host, url)
    assert s['auth']['type'] is None
    assert s['auth']['username'] is None
    assert s['auth']['password'] is None
    assert s['auth']['raw_auth'] is None
    assert s['auth'].keys() == {'type', 'username', 'password', 'raw_auth'}
    assert s['cookies'] == {}

# Generated at 2022-06-21 14:51:55.974644
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("C:/Users/Mortil/Desktop/session.json")
    headers = {"Cookie":"baidu.com","Referer":"https://www.baidu.com","User-Agent":"mozilla"}
    session.update_headers(headers)
    assert session.headers == {"Cookie": "baidu.com", "Referer": "https://www.baidu.com", "User-Agent": "mozilla"}

# Generated at 2022-06-21 14:52:26.645750
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(Path("test.json"))
    session.load()
    session['cookies'] = {'cookies1': 'cookies2'}
    session.remove_cookies(["cookies1"])
    assert (session['cookies'] == {})

# Generated at 2022-06-21 14:52:38.906820
# Unit test for function get_httpie_session
def test_get_httpie_session():
    def get_httpie_session(config_dir: Path, session_name: str, host: Optional[str], url: str) -> 'Session':
        if os.path.sep in session_name:
            path = os.path.expanduser(session_name)
        else:
            hostname = host or urlsplit(url).netloc.split('@')[-1]
            if not hostname:
                # HACK/FIXME: httpie-unixsocket's URLs have no hostname.
                hostname = 'localhost'

            # host:port => host_port
            hostname = hostname.replace(':', '_')
            path = (
                    config_dir / SESSIONS_DIR_NAME / hostname / f'{session_name}.json'
            )
        session = Session(path)


# Generated at 2022-06-21 14:52:51.772096
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    h={'User-Agent': 'HTTPie/1.0.2', 'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*', 'Connection': 'keep-alive'}
    h1={'Content-Length': '0', 'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*', 'Connection': 'keep-alive', 'Host': 'httpbin.org', 'User-Agent': 'HTTPie/1.0.2'}
    s=Session("temp.json")
    s.update_headers(h)
    assert s['headers']=={}
    s.update_headers(h1)
    assert s['headers']=={'host': 'httpbin.org'}
    s.update_headers(h1)

# Generated at 2022-06-21 14:52:56.989116
# Unit test for constructor of class Session
def test_Session():
    my_session = Session("test.json")
    assert my_session['headers'] == {}
    assert my_session['cookies'] == {}
    assert my_session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }
    assert my_session.path == "test.json"



# Generated at 2022-06-21 14:53:01.208789
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = [('header1', 'value1'), ('header2', 'value2')]
    # Session should not have headers before calling update method
    session = Session(path=Path("./test-session.json"))
    session.load()
    assert not session.headers
    session.update_headers(request_headers)
    # Now session should have headers
    assert session.headers == {'header1': 'value1', 'header2': 'value2'}


# Generated at 2022-06-21 14:53:03.802569
# Unit test for constructor of class Session
def test_Session():
    path = Path(r'C:\Users\hayoung\PycharmProjects\myHTTPie')
    session = Session(path=path)
    assert session.path == path

# Generated at 2022-06-21 14:53:09.728514
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/dummy')
    session.cookies = RequestsCookieJar()
    session.cookies.set('foo', 'bar')
    session.cookies.set('hello', 'world')
    assert 'foo' in session.cookies
    assert 'hello' in session.cookies
    session.remove_cookies(['foo'])
    assert 'foo' not in session.cookies
    assert 'hello' in session.cookies

# Generated at 2022-06-21 14:53:15.122810
# Unit test for constructor of class Session
def test_Session():
    obj = Session('test_Session')
    assert obj.path == 'test_Session'
    assert obj['headers'] == {}
    assert obj['cookies'] == {}
    assert obj['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

# Generated at 2022-06-21 14:53:24.243107
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='')
    session.update_headers(['Cookie: key=value', 'cookie: key1=value1'])
    assert session['cookies']['key'] == {'value': 'value'}
    assert session['cookies']['key1'] == {'value': 'value1'}
    assert session['headers'] == {'Cookie': 'cookie: key1=value1'}

    headers = RequestHeadersDict()
    headers.update({
        'Cookie': '',
        'If-Match': '',
        'Content-Type': '',
        'User-Agent': 'HTTPie/0.9.9',
        'TEST': 'TEST'
    })
    session.update_headers(headers)

# Generated at 2022-06-21 14:53:30.302940
# Unit test for constructor of class Session
def test_Session():
    config_dir = Path('.config')
    session_name = 'mysession'
    host = 'httpie.org'
    url = 'https://httpie.org/test'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.__class__ == Session
    assert session.path == (
        config_dir / SESSIONS_DIR_NAME / 'httpie_org' / f'{session_name}.json')

# Generated at 2022-06-21 14:54:03.613233
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-21 14:54:11.382645
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b'}
    session.remove_cookies(['a'])
    assert not session['cookies']
    session['cookies'] = {'c': 'd'}
    session.remove_cookies(['c'])
    assert not session['cookies']
    session['cookies'] = {'e': 'f'}
    session.remove_cookies(['c'])
    assert session['cookies'] == {'e': 'f'}

# Generated at 2022-06-21 14:54:19.168143
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class FakeRequestHeaders(dict):
        def __init__(self, data):
            self.data = data
            super(FakeRequestHeaders, self).__init__(data)

        def items(self):
            return self.data.items()

        def __iter__(self):
            return iter(self.data)


# Generated at 2022-06-21 14:54:23.017745
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(path = '')
    d = RequestHeadersDict([('key1', 'value1'), ('key2','value2')])
    s.update_headers(d)
    for name, value in d.items():
        assert value == s.headers.get(name)


# Generated at 2022-06-21 14:54:26.598993
# Unit test for constructor of class Session
def test_Session():
    path = "sessions/test_Session"
    session = Session(path)
    print(session['headers'])
    print(session['cookies'])
    print(session)


# Generated at 2022-06-21 14:54:32.798293
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    s.cookies = RequestsCookieJar()
    s.cookies.set('key-1', 'value-1')
    s.cookies.set('key-2', 'value-2')

    s.remove_cookies(['key-1'])
    assert list(s.cookies.keys()) == ['key-2']

# Generated at 2022-06-21 14:54:33.540899
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass

# Generated at 2022-06-21 14:54:37.476439
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {
        'Content-Type': 'text',
        'DNT': '1',
        'Accept-Encoding': 'gzip, deflate',
        'Accept': '*/*'
    }
    session = Session(None)
    session.update_headers(headers)
    print(session)

# Generated at 2022-06-21 14:54:41.849858
# Unit test for constructor of class Session
def test_Session():
    """
    Because the class Session is from `config.py`, so we use the `test_config.py` to test this.
    """
    path = Path(__file__)
    test_session = Session(path)
    assert isinstance(test_session, Session)

# Generated at 2022-06-21 14:54:48.388339
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = '/tmp/httpie'
    session_name = 'foo'
    host = 'test.com'
    url = 'https://httpie.org/test'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }