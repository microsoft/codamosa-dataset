

# Generated at 2022-06-21 14:44:59.913021
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./session.json')
    session['cookies'] = {'cookie1' : 'cookie1', 'cookie2' : 'cookie2'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2' : 'cookie2'}

# Generated at 2022-06-21 14:45:06.879160
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'name1' : 'value1', 'name2' : 'value2'}
    auth = {'type' : 'default', 'username' : 'username', 'password' : 'password'}

    session = Session('dummy.json')
    session['cookies'] = cookies
    session['auth'] = auth

    session.remove_cookies(['name1'])

    assert session['cookies'] == {'name2' : 'value2'}
    assert session['auth'] == auth

# Generated at 2022-06-21 14:45:12.206834
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict()
    session = Session(Path)
    # First add a cookie
    headers['Cookie'] = 'sessionID=12345'
    # Now update the session with the headers
    session.update_headers(headers)
    # Get the cookies from the session
    cookies = session.cookies
    assert cookies.get('sessionID',None)
    # Now remove the cookies from the session
    session.remove_cookies(['sessionId'])
    # Get the cookies  of the session
    cookies = session.cookies
    assert not cookies.get('sessionID',None)

# Generated at 2022-06-21 14:45:20.979030
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('.')
    session['cookies'] = {
        'a': {
            'secure': True,
            'expires': 1548476800,
            'path': '/',
            'value': 'a'
        },
        'b': {
            'secure': False,
            'expires': 1548476800,
            'path': '/',
            'value': 'b'
        }
    }
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {
        'secure': False,
        'expires': 1548476800,
        'path': '/',
        'value': 'b'
    }}

# Generated at 2022-06-21 14:45:27.262053
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    Session._Session__fields__ = []
    d = {
        'url': 'https://www.baidu.com/',
        'headers': {'Accept': 'application/json'}
    }

    for item in ('', u'', [], (), {}):
        with pytest.raises(TypeError):
            Session('/tmp/test_update_headers') \
                .update_headers(item)

    assert Session('/tmp/test_update_headers') \
        .update_headers(d['headers']) is None



# Generated at 2022-06-21 14:45:32.558442
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path=None)
    s['cookies'] = {'key1': 'val1', 'key2': 'val2', 'key3': 'val3' }
    s.remove_cookies(['key2'])
    assert s['cookies'] == {'key1': 'val1', 'key3': 'val3' }


# Generated at 2022-06-21 14:45:42.334604
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    DIR = Path('testSession_remove_cookies')
    if DIR.exists():
        DIR.unlink()
    DIR.mkdir()
    s = Session(DIR / 'test.json')
    for i in range(5):
        s['cookies']['test_'+str(i)] = 'test'
    s['cookies']['test_2'] = 'test_2'
    assert(len(s.cookies) == 5)
    s.remove_cookies(['test_0','test_1'])
    assert(len(s.cookies) == 3)
    s.remove_cookies(['test_2'])
    assert(len(s.cookies) == 2)



# Generated at 2022-06-21 14:45:46.335622
# Unit test for constructor of class Session
def test_Session():
    try:
        os.makedirs("test")
    except:
        pass
    session = Session("test/test.json")
    print("session: {}".format(session))
    session.save()


# Generated at 2022-06-21 14:45:47.007163
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass


# Generated at 2022-06-21 14:45:51.763390
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sess = get_httpie_session(Path("/home/user/.config"), "session_name", "n.com", "http://n.com")
    assert sess
    assert sess.about
    assert sess.helpurl
    assert sess.path
    assert sess.get("auth")


# Generated at 2022-06-21 14:46:03.774549
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='/dev/null')
    session.update_headers({'Accept': 'application/json'})
    assert session['headers'] == {'Accept': 'application/json'}


# Unit test to verify that the method update_headers of class
# Session honors the SESSION_IGNORED_HEADER_PREFIXES

# Generated at 2022-06-21 14:46:09.180632
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path='')
    s['cookies'] = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert(set(s['cookies'].keys()) == {'a', 'b', 'c', 'd'})

    s.remove_cookies(['b', 'd'])
    assert(set(s['cookies'].keys()) == {'a', 'c'})

# Generated at 2022-06-21 14:46:18.275791
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # test normal remove
    session = Session('/home/test/test.json')
    session['cookies'] = {'test': {'value': 'test_val'}, 'test_1': {'value': 'test_val_1'}}
    session.remove_cookies(['test'])
    assert session['cookies'] == {'test_1': {'value': 'test_val_1'}}

    # test remove not exist cookie
    session.remove_cookies(['test_2'])
    assert session['cookies'] == {'test_1': {'value': 'test_val_1'}}

# Generated at 2022-06-21 14:46:20.818802
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("tests/config/test.json")
    session.load()
    session.remove_cookies("abc")
    assert("abc" not in session['cookies'])

# Generated at 2022-06-21 14:46:28.607683
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./test_session.json')
    session.update_headers({'header1': '1', 'header2': '2'})
    assert session['headers'] == {'header1': '1', 'header2': '2'}
    session.update_headers({'header1': '3', 'header2': '4'})
    assert session['headers'] == {'header1': '3', 'header2': '4'}


# Generated at 2022-06-21 14:46:34.313944
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import DEFAULT_CONFIG_DIR
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'x.json'
    host = 'www.cnn.com'
    url = 'http://www.cnn.com'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.__class__ == Session

# Generated at 2022-06-21 14:46:43.602210
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies_dict = {'cookies': {
        'C1': {'value': 'C1-value'},
        'C2': {'value': 'C2-value'},
        'C3': {'value': 'C3-value'},
    }}
    session = Session('/')
    session.__dict__.update(cookies_dict)
    session.remove_cookies(['C1', 'C2'])
    assert session.__dict__ == {
        'cookies': {'C3': {'value': 'C3-value'}},
        'headers': {}
    }

# Generated at 2022-06-21 14:46:48.373987
# Unit test for constructor of class Session
def test_Session():
    conf = Session('test.json')
    conf['test'] = 'test'
    conf.save()
    conf = Session('test.json')
    conf.load()
    print(conf)
    assert conf['test'] == 'test'


# Generated at 2022-06-21 14:46:58.598708
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from pathlib import Path
    from httpie.compat import is_windows
    config_dir = Path(os.getcwd())
    session_name = 'temp_session'
    host = '127.0.0.1:8000'
    url = 'http://127.0.0.1:8000'
    session = get_httpie_session(config_dir, session_name, host, url)
    session['cookies'] = {'cookie1': {'value': '1.1'}, 'cookie2': {'value': '2.2'}}
    session.save()

    session2 = get_httpie_session(config_dir, session_name, host, url)
    assert session == session2
    session2.remove_cookies(['cookie1'])

# Generated at 2022-06-21 14:46:59.782808
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass

# Generated at 2022-06-21 14:47:08.764596
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert get_httpie_session(DEFAULT_CONFIG_DIR, 'test_Session_remove_cookies', '', '').remove_cookies(['name']) == None

# Generated at 2022-06-21 14:47:11.769001
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('sample')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {'Content-Type': 'application/json'}

# Generated at 2022-06-21 14:47:17.748338
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("1")
    session['cookies'] = {'Cookie1': 'Value1', 'Cookie2': 'Value2', 'Cookie3': 'Value3'}
    session.remove_cookies(['Cookie2'])
    assert session['cookies'] == {'Cookie1': 'Value1', 'Cookie3': 'Value3'}

# Generated at 2022-06-21 14:47:23.241298
# Unit test for constructor of class Session
def test_Session():
    s = Session('~/sessions/foo-site/bar.json')
    assert type(s) == Session, "s is not of type Session"
    assert s['headers'] == {}, "s['headers'] is not empty"
    assert s['cookies'] == {}, "s['cookies'] is not empty"
    assert s['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }, "s['auth'] is not as expected"

# Generated at 2022-06-21 14:47:25.887123
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = 'http://domain'
    session_name = 'test_session'
    get_httpie_session(config_dir=Path(),
                       session_name=session_name,
                       host=None,
                       url=url)

# Generated at 2022-06-21 14:47:35.794649
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.core import httpie_version
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.httpie import  HTTPieQueryAuth
    from httpie.plugins.httpheader import HTTPHeaderAuth
    headers = ' '.join(["-H", f"Host: www.bing.com", "-H", f"Connection: close", "-H", f"User-Agent: HTTPie/{httpie_version}"])
    #print(headers)

    session = Session(path="test-session")
    session.update_headers(headers.split())
    session.save()

    #print(session['headers'])


# Unit test

# Generated at 2022-06-21 14:47:40.911965
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_names = ['sessionID', 'sessionId']
    session = Session("./test")
    session['cookies'] = {
        'sessionID': None,
        'sessionId': None,
        'other': None
    }
    session.remove_cookies(cookie_names)
    assert session['cookies'] == {'other': None}

# Generated at 2022-06-21 14:47:44.315194
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')

    # test without existing session headers
    session.update_headers({'Content-Type': 'application/json',
                            'Content-Length': '10'})
    assert session.headers['Content-Type'] == 'application/json'
    assert session.headers['Content-Length'] == '10'

    # test with existing session headers
    request_headers = { 'User-Agent': 'HTTPie/0.9.9', 'Cookie': 'abcd=efgh' }
    session.update_headers(request_headers)
    assert session.headers['User-Agent'] == 'HTTPie/0.9.9'
    assert session.cookies == {'abcd':'efgh'}

# Generated at 2022-06-21 14:47:48.523885
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_old = Session(path='sample.json')
    session_old['cookies'] = {'cookie_name1': {'value': 'cookie_value1'}, 'cookie_name2': {'value': 'cookie_value2'}, 'cookie_name3': {'value': 'cookie_value3'}}
    session_old.remove_cookies(['cookie_name1', 'cookie_name3'])
    assert len(session_old['cookies']) == 1
    assert 'cookie_name2' in session_old['cookies']


# Generated at 2022-06-21 14:48:00.518503
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Create two session file, one in the default directory and other in the
    # current directory.
    #
    # The one in the current directory is checked first, and then the one with
    # the same name in the default directory.
    #
    # In the default directory, the name is modified to add the hostname,
    # which is replaced by the default hostname if no one is given.
    #
    # The directory is created if it doesn't already exist.
    #
    # Finally, all the sessions are checked for load and path, and then
    # removed.

    current_dir = Path('.') / SESSIONS_DIR_NAME
    current_dir_name = current_dir.name

    if not current_dir.exists():
        current_dir.mkdir()


# Generated at 2022-06-21 14:48:12.106622
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path('test'))
    session.update_headers({'test': 'test'})
    assert session.headers
    assert session['headers']
    assert 'test' in session.headers

# Generated at 2022-06-21 14:48:23.435980
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test_session.json')
    s.cookies = RequestsCookieJar()
    s.cookies.set('hi', 'there', path='/')
    s.cookies.set('wassup', 'man', path='/')
    s.remove_cookies(['hi'])
    assert s.cookies == RequestsCookieJar()
    s.cookies.set('hi', 'there', path='/')
    s.cookies.set('wassup', 'man', path='/')
    s.remove_cookies(['hi', 'what'])
    assert s.cookies == RequestsCookieJar()
    s.cookies.set('hi', 'there', path='/')
    s.cookies.set('wassup', 'man', path='/')

# Generated at 2022-06-21 14:48:27.111149
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'test_session', None, None)
    # TODO: Set up default config dir just for the test
    #assert(session == Session(DEFAULT_SESSIONS_DIR / 'test_session.json'))

# Generated at 2022-06-21 14:48:32.929578
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path = None)
    session.update({"cookies":
            {"a": {"value": "1", "path": "/", "secure": False, "expires": None},
            "b": {"value": "2", "path": "/", "secure": False, "expires": None}}})
    session.remove_cookies(["a", "c", "d"])
    assert session["cookies"] == {"b": {"value": "2", "path": "/", "secure": False, "expires": None}}

# Generated at 2022-06-21 14:48:37.852651
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'cookie1': {'value': 'first'},
                          'cookie2': {'value': 'second'},
                          'cookie3': {'value': 'third'}}

    session.remove_cookies(['cookie2', 'cookie3'])

    assert 'cookie2' not in session['cookies']
    assert 'cookie3' not in session['cookies']
    assert session['cookies']['cookie1']['value'] == 'first'

    session.remove_cookies(['cookie1'])

    assert 'cookie1' not in session['cookies']



# Generated at 2022-06-21 14:48:38.295772
# Unit test for constructor of class Session
def test_Session():
    pass



# Generated at 2022-06-21 14:48:40.394951
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(Path('test/data/test-config-dir'),'test-session','httpbin.org', 'https://httpbin.org')

# Generated at 2022-06-21 14:48:48.981068
# Unit test for constructor of class Session
def test_Session():
    sess = Session(path='./')
    assert type(sess['headers']) == dict
    assert type(sess['cookies']) == dict
    assert sess['auth']['type'] == None
    assert sess['auth']['username'] == None
    assert sess['auth']['password'] == None
    assert type(sess.headers) == RequestHeadersDict
    assert type(sess.cookies) == RequestsCookieJar


# Generated at 2022-06-21 14:48:59.391483
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import os
    import tempfile
    import json
    from httpie.config import BaseConfigDict
    from httpie.cli.dicts import RequestHeadersDict
    # create temporary file
    fd, path = tempfile.mkstemp()

    # instantiate the class Session
    session_test = Session(path)

    # create a fake request_headers with some specific headers
    request_headers = RequestHeadersDict()
    request_headers['Name'] = "value"
    request_headers['User-Agent'] = "httpie/0.6.0"
    request_headers['Content-Type'] = "text/html; charset=utf-8"
    request_headers['Content-Length'] = "0"
    request_headers['Cookie'] = "cookie=value"

    # update the query string from the request_

# Generated at 2022-06-21 14:49:07.842679
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(Path('test1.json'))
    s.update_headers(RequestHeadersDict([('X-Test', 1), ('X-Test2', 2)]))
    assert s.headers == RequestHeadersDict([('X-Test', 1), ('X-Test2', 2)])
    s.update_headers(RequestHeadersDict([('X-Test', None), ('X-Test2', 3)]))
    assert s.headers == RequestHeadersDict([('X-Test2', 3)])



# Generated at 2022-06-21 14:49:16.053907
# Unit test for constructor of class Session
def test_Session():
    s = Session('~/.httpie/sessions')
    assert s.path == Path(os.path.expanduser('~/.httpie/sessions'))
    assert s.cookies == RequestsCookieJar()


# Generated at 2022-06-21 14:49:28.268219
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from tempfile import TemporaryDirectory
    from requests.cookies import RequestsCookieJar
    from pathlib import Path
    import time


    with TemporaryDirectory() as tmpdir:
        tmpdir2 = os.path.join(tmpdir, 'test')
        session = get_httpie_session(Path(tmpdir2), 'test', 'localhost:8080', 'http://localhost:8080/test')
        session.headers = {'test': 'test'}
        session.cookies = RequestsCookieJar()
        session.cookies.set_cookie(create_cookie('test', 'test', domain='localhost:8080'))
        session.save()
        assert os.path.isfile(os.path.join(tmpdir2, 'sessions', 'localhost_8080', 'test.json'))
        session.update_

# Generated at 2022-06-21 14:49:38.170370
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    ses = Session('/tmp/session')
    ses.update({'cookies': {
        'cookie1': {
            'value': 'val1'
        },
        'cookie2': {
            'value': 'val2'
        }
    }})
    ses.remove_cookies(['cookie1'])
    assert ses['cookies'] == {'cookie2': {'value': 'val2'}}
    ses.remove_cookies(['cookie2'])
    assert ses['cookies'] == {}
    ses.remove_cookies(['cookie'])
    assert ses['cookies'] == {}


# Generated at 2022-06-21 14:49:49.886419
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    try:
        from httpie.compat import str
        from httpie.cli.dicts import RequestHeadersDict
    except ImportError:
        print("Can't load RequestHeadersDict")
    # Unit test 1
    session = Session(path="temp.json")

# Generated at 2022-06-21 14:49:54.981521
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test/test_data/test_cookies.json')
    assert 'cookie1' in session['cookies'] and 'cookie2' in session['cookies']
    session.remove_cookies(['cookie1','cookie2'])
    assert 'cookie1' not in session['cookies'] and 'cookie2' not in session['cookies']

# Generated at 2022-06-21 14:49:57.787026
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = {'content': 'a'}
    session = Session('test_session.json')
    session.update_headers(headers)
    assert session['headers'] == {'content': 'a'}



# Generated at 2022-06-21 14:50:03.967898
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = 'c:\my_session.json'
    sesh = Session(path)
    sesh['cookies'] = {'name_1': 'value_1', 'name_2': 'value_2'}
    assert sesh.cookies.get_dict() == {'name_1': 'value_1', 'name_2': 'value_2'}
    names = ['name_1', 'name_3']
    sesh.remove_cookies(names)
    # Should remove name_1 only
    assert sesh.cookies.get_dict() == {'name_2': 'value_2'}

# Generated at 2022-06-21 14:50:11.125413
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Normal case
    r = get_httpie_session(Path("./"), "session", "https://httpbin.org", "https://httpbin.org/get")
    assert type(r) is Session

    # No host (httpie-unixsocket)
    r = get_httpie_session(Path("./"), "session", None, "unix:httpbin.org:80")
    assert type(r) is Session

# Generated at 2022-06-21 14:50:22.367891
# Unit test for constructor of class Session
def test_Session():
    from unittest import TestCase
    from pathlib import Path
    from os import path
    from tempfile import TemporaryDirectory

    class SessionTest(TestCase):
        def setUp(self):
            self.test_dir = TemporaryDirectory()
            self.config_dir = Path(self.test_dir.name)
            self.session_file = self.config_dir / SESSIONS_DIR_NAME / 'session.json'

        def tearDown(self):
            self.test_dir.cleanup()

        def test_create_session(self):
            session = Session(self.session_file)
            self.assertEqual(session['headers'], {})
            self.assertEqual(session['cookies'], {})

# Generated at 2022-06-21 14:50:25.542552
# Unit test for constructor of class Session
def test_Session():
    ss = Session(Path('/usr/local/etc/httpie/sessions/example.com/foo.json'))
    assert ss['headers'] == {}
    assert ss['cookies'] == {}
    assert ss['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }

# Generated at 2022-06-21 14:50:37.263106
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session()
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a', 'b'])
    assert session == {'cookies': {}}


# Generated at 2022-06-21 14:50:37.924435
# Unit test for function get_httpie_session
def test_get_httpie_session():
    pass



# Generated at 2022-06-21 14:50:42.194097
# Unit test for constructor of class Session
def test_Session():
    session_dict = Session('/Users/liuliangjun/.config/httpie/sessions/localhost/default.json')
    assert session_dict == {'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}

# Generated at 2022-06-21 14:50:48.816965
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session = Session(path='./temp.json')

    class MockRequestHeadersDict(dict):
        def __init__(self, *args, **kwargs):
            super(MockRequestHeadersDict, self).__init__(*args, **kwargs)
            self.instance_count = 0

            def to_utf8(value):
                return value if type(value) is str else value.decode('utf8')

            self.update({'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:80.0) Gecko/20100101 Firefox/80.0'})
            self.update({'If-Modified-Since': 'Tue, 11 Aug 2020 08:27:33 GMT'})
            self.update({'Content-Length': '0'})


# Generated at 2022-06-21 14:50:56.243127
# Unit test for function get_httpie_session
def test_get_httpie_session():
    expected_session_name = "test_session"
    expected_host = "localhost"
    expected_url = "htto://localhost/api"
    actual_session = get_httpie_session(
        DEFAULT_CONFIG_DIR, expected_session_name, expected_host, expected_url)
    actual_session_name = actual_session
    assert not actual_session_name is None
    assert expected_session_name == actual_session_name

# Generated at 2022-06-21 14:51:01.531231
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(DEFAULT_SESSIONS_DIR)
    s['cookies']['A'] = 'someValueA'
    s['cookies']['B'] = 'someValueB'
    s.remove_cookies(['A'])
    assert (len(s['cookies']) == 1 and s['cookies']['B'] == 'someValueB')
    s.remove_cookies(['A', 'B'])
    assert len(s['cookies']) == 0

# Generated at 2022-06-21 14:51:07.910894
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(None)
    session.update_headers({'Content-type': 'text/html', "Content-Length": '100'})
    assert session.headers == {}
    session.update_headers({'Host': 'httpbin.org', "User-Agent": 'httpie'})
    assert session.headers == {'Host': 'httpbin.org', "User-Agent": 'httpie'}

# Generated at 2022-06-21 14:51:17.025350
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=None)
    raw_headers = {
        'Connection': 'keep-alive',
        'Accept': '*/*',
        'Content-Type': 'application/x-www-form-urlencoded',
        'If-Match': 'xyz',
        'If-Modified-Since': 'Sat, 29 Oct 1994 19:43:31 GMT',
        'If-None-Match': 'xyz'
    }

    request_headers = RequestHeadersDict(raw_headers)
    session.update_headers(request_headers)
    result = {
        'Accept': '*/*',
        'Connection': 'keep-alive',
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    assert session.headers == result

# Generated at 2022-06-21 14:51:26.196954
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session(None)
    r = RequestHeadersDict()
    r['Host'] = 'httpbin.org'
    r['User-Agent'] = 'HTTPie/1.0.3'

    s.update_headers(r)
    assert len(s.headers) == 1
    assert s.headers['Host'] == 'httpbin.org'

    r['Content-Type'] = 'application/json'
    r['If-Match'] = 'xxx'
    s.update_headers(r)
    assert len(s.headers) == 1

    r['Accept'] = 'application/json'
    s.update_headers(r)
    assert len(s.headers) == 2
    assert s.headers['Host'] == 'httpbin.org'
    assert s.headers['Accept'] == 'application/json'

   

# Generated at 2022-06-21 14:51:35.269864
# Unit test for constructor of class Session
def test_Session():
    with open('sessions/httpbin_org/get.json') as f:
        x = eval(f.read())
    session = Session('httpbin_org/get.json')
    assert session == x
    assert session.path == Path('httpbin_org/get.json')
    assert session.headers == {
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Host': 'httpbin.org'
    }
    assert session.cookies == RequestsCookieJar()
    assert session.auth == None

# Generated at 2022-06-21 14:51:59.050939
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session.cookies = RequestsCookieJar()
    session.cookies.set({'cookies': 'cookies'})
    session.cookies.set({'cookies1': 'cookies1'})
    session.cookies.set({'cookies2': 'cookies2'})
    assert len(session.cookies) == 3
    session.remove_cookies(['cookies'])
    assert len(session.cookies) == 2
    assert 'cookies2' in session.cookies
    assert 'cookies1' in session.cookies
    assert 'cookies' not in session.cookies


# Generated at 2022-06-21 14:52:08.617169
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """set headers"""
    headers = {b'header1': b'value1', 'header2': 'value2'}
    request_headers = {'header1': 'newVal1', 'header2': 'newVal2'}
    set_value = [b'newVal1', 'newVal2']
    s = Session('test')
    s.update_headers(headers)
    s.update_headers(request_headers)
    assert s['headers'] == {
                            'header1': set_value[0],
                            'header2': set_value[1]
                            }


# Generated at 2022-06-21 14:52:15.901027
# Unit test for constructor of class Session
def test_Session():
    session_path = "~/.httpie/sessions/test.json"
    session = Session(session_path)
    assert session.path == os.path.expanduser(session_path)
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }

test_Session()

# Generated at 2022-06-21 14:52:19.826964
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('sessions')
    session['cookies'] = {'test':'test'}
    session.remove_cookies(['test'])
    assert session['cookies'] == {}
    assert session.name == 'sessions'
    assert session.path == Path('sessions')




# Generated at 2022-06-21 14:52:23.307677
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
  s = Session('test')
  s.cookies = RequestsCookieJar()
  s.cookies['test'] = create_cookie('test', 'test')
  s.remove_cookies(['test'])
  assert s.cookies[''] == ''

# Generated at 2022-06-21 14:52:34.792758
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from pathlib import Path
    from httpie.plugins import builtin
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()
    builtins = builtin.load_default_plugins()
    for plugin in builtins:
        plugin_manager.register(plugin)
    # Load sessions dir
    config_dir = Path("/tmp/httpie-test")
    if config_dir.exists():
        import shutil
        shutil.rmtree(config_dir)
    config_dir.mkdir()

    # Load session
    session_name = "test"
    url = "http://localhost:9090"
    host = "localhost"
    session = get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-21 14:52:43.854462
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.input import KeyValue, ParseResult
    from httpie.cli.argtypes import KeyValueArgType

    method = 'POST'

# Generated at 2022-06-21 14:52:47.551821
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'a': 'valuea', 'user-agent': 'HTTPie/1.0.2'})
    assert session.headers == {'a': 'valuea'}

# Generated at 2022-06-21 14:52:54.622024
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'test'
    host = 'host'
    url = 'http://host:80'
    expected = Session(config_dir / SESSIONS_DIR_NAME / 'host' / f'{session_name}.json')
    actual = get_httpie_session(config_dir, session_name, host, url)
    assert expected == actual

# Generated at 2022-06-21 14:52:57.785251
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_Session = Session('')
    test_Session.update_headers(
        {'a': 'b', 'content-type': 'application/json'})
    assert test_Session.headers == {'a': 'b'}

# Generated at 2022-06-21 14:53:17.700501
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    sess={"cookies":{"a":"a","b":"b"}}
    s=Session("")
    s.update(sess)
    s.remove_cookies(["a"])
    assert s["cookies"]["a"] is None
    assert s["cookies"]["b"]=="b"

# Generated at 2022-06-21 14:53:23.004421
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Arrange
    config_dir = Path('~/.httpie')
    session_name = 'dummy'
    host = 'www.example.com'
    url = 'http://www.example.com'

    # Act
    session = get_httpie_session(config_dir, session_name, host, url)

    # Assert
    assert session.path == Path('~/.httpie/sessions/www_example_com/dummy.json')

# Generated at 2022-06-21 14:53:27.510745
# Unit test for constructor of class Session
def test_Session():
    test_path = "test/test.txt"
    test_session = Session(test_path)
    assert test_session.path == Path(test_path)
    assert test_session['headers'] == {}
    assert test_session['cookies'] == {}
    assert test_session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-21 14:53:38.285846
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.compat import urlunparse
    import os
    import shutil

    SESSIONS_DIR_NAME = 'sessions'
    DEFAULT_SESSIONS_DIR = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME
    VALID_SESSION_NAME_PATTERN = re.compile('^[a-zA-Z0-9_.-]+$')
    # Request headers starting with these prefixes won't be stored in sessions.
    # They are specific to each request.
    # <https://en.wikipedia.org/wiki/List_of_HTTP_header_fields#Requests>

# Generated at 2022-06-21 14:53:43.593311
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s['cookies'] = {}
    s['cookies']['one'] = {'value': 'one'}
    s['cookies']['two'] = {'value': 'two'}
    s['cookies']['three'] = {'value': 'three'}
    s.remove_cookies(['one', 'three'])
    assert s['cookies'] == {'two': {'value': 'two'}}



# Generated at 2022-06-21 14:53:54.450961
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    fn = 'test_Session_remove_cookies.json'
    session = Session(fn)
    session['cookies'] = {'name_1': {'value': 'value_1'},
                          'name_2': {'value': 'value_2'},
                          'name_3': {'value': 'value_3'},
                          'name_4': {'value': 'value_4'},
                          'name_5': {'value': 'value_4'}}
    names = ['name_1', 'name_3', 'name_5', 'name_7']
    session.remove_cookies(names)
    assert session['cookies'] == {'name_2': {'value': 'value_2'},
                                  'name_4': {'value': 'value_4'}}
   

# Generated at 2022-06-21 14:53:58.462701
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp'))
    session.load()

    test_set_headers = RequestHeadersDict({'a': 1, 'b': 2,
                                           'Content-Type': 'text/xml'})
    session.update_headers(test_set_headers)
    assert session.headers == RequestHeadersDict({'a': 1, 'b': 2})

# Generated at 2022-06-21 14:54:00.022624
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(Path('/'), 'a', 'b', 'c')

# Generated at 2022-06-21 14:54:11.553488
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Test 1: Check if the data is loaded correctly
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'my_session', None, None)
    expected = {'headers': {}, 'cookies': {}, 'auth': {
        'type': None, 'username': None, 'password': None}}
    assert session == expected, 'session.json is not loaded correctly!'
    # Test 2: Check ignore header prefixes
    headers = RequestHeadersDict()
    headers['Content-Type'] = 'application/json'
    headers['content-type'] = 'application/xml'
    headers['user-agent'] = 'HTTPie/1.0.2'
    headers['USER-AGENT'] = 'HTTPie/1.0.2'
    headers['If-Match'] = 'etag'

# Generated at 2022-06-21 14:54:14.434894
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session({"cookies": {"cookie1": 1, "cookie2": 2}})
    session.remove_cookies(["cookie1"])
    assert session.dict() == {"cookies": {"cookie2": 2}}

# Generated at 2022-06-21 14:54:51.553328
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("")
    request_headers = {b'cookie': b'"a=123"; b=456', 'accept': 'application/json'}
    session.update_headers(request_headers)
    assert session.cookies.get_dict() == {'a': '123', 'b': '456'}
    assert session.headers.get_all('accept') == ['application/json']