

# Generated at 2022-06-21 14:45:08.097370
# Unit test for constructor of class Session
def test_Session():
    print(FullPath('test').path)
    config_dir = Path.cwd() / 'config'
    session_name = 'test'
    url = 'http://example.com'
    host = 'example.com'

    # Create session file
    session = get_httpie_session(config_dir, session_name, host, url)

    # Add session items
    session.headers = {'one': 1}
    session.cookies = RequestsCookieJar()
    session.auth = {'type': 'TestAuth', 'raw_auth': 'user:pwd'}

    # Save session file
    session.save()

    # Load session file
    session.load()

    # Load session file with attribute
    session.update_headers(session.headers)
    session.update_headers({'two': 2})
   

# Generated at 2022-06-21 14:45:15.399504
# Unit test for constructor of class Session
def test_Session():
    from httpie.cli.dicts import RequestHeadersDict
    Header = RequestHeadersDict({'a': 3})

    session = Session(Path(""))

    assert session['headers'] == {}

    assert session['cookies'] == {}

    assert session['auth'] == {'type': None, 'username': None, 'password': None}

    session.update_headers(Header)
    assert session['headers'] == {'a': '3'}

    session['cookies'] = RequestsCookieJar()
    assert session['cookies'] == {}

# Generated at 2022-06-21 14:45:23.609162
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict({"Cookie": "le=10;cookie=cream;le=20"})
    session = Session("/tmp/test")
    assert session.headers == RequestHeadersDict({})
    assert session.cookies == RequestsCookieJar()
    session.update_headers(request_headers)
    assert session.headers == RequestHeadersDict({})
    assert session.cookies.__dict__['_cookies']['/']['cookie'].value == 'cream'
    assert session.cookies.__dict__['_cookies']['/']['le'].value == '20'
    assert session.cookies.__dict__['_cookies']['/']['le'].value != '10'

# Generated at 2022-06-21 14:45:28.483434
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='/dev/null')
    session.update_headers({'Content-Length': '0', 'Cookie': 'foo=BAR'})
    assert session == {
        'headers': {},
        'cookies': {'foo': {'value': 'BAR'}},
        'auth': {'type': None, 'username': None, 'password': None},
    }


# Generated at 2022-06-21 14:45:37.940015
# Unit test for function get_httpie_session
def test_get_httpie_session():
    DEFAULT_SESSIONS_DIR_TEST = DEFAULT_SESSIONS_DIR.absolute()
    config_dir = DEFAULT_SESSIONS_DIR_TEST.joinpath('config')
    session_name = 'test_session'
    host = 'http://127.0.0.1'
    url = f'{host}:5000/test'
    if not os.path.exists(config_dir):
        os.mkdir(config_dir)
    if not os.path.exists(DEFAULT_SESSIONS_DIR_TEST):
        os.mkdir(DEFAULT_SESSIONS_DIR_TEST)
    path = (
        config_dir / SESSIONS_DIR_NAME / host.replace(':', '_') /
        f'{session_name}.json'
    )
   

# Generated at 2022-06-21 14:45:41.612765
# Unit test for constructor of class Session
def test_Session():
    path = Path('/home/kushal/httpie/.httpie/sessions/localhost')
    test = Session(path)
    assert test.path == Path('/home/kushal/httpie/.httpie/sessions/localhost'), "test_Session for class Session Failed"


# Generated at 2022-06-21 14:45:47.102305
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = "default"
    url = "http://get_httpie_session/test"
    host = "test"
    print(get_httpie_session(config_dir, session_name, host, url))

# Generated at 2022-06-21 14:45:52.983584
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {
        "key1" : "value1",
        "key2" : "value2",
        "key3" : "value3",
    }
    assert(len(session['cookies']) == 3)
    session.remove_cookies(["key1","key2","key4"])
    assert(session['cookies']=={"key3":"value3"})

# Generated at 2022-06-21 14:45:54.195329
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert isinstance(get_httpie_session('~/.httpie', 'session', '', ''), Session)

# Generated at 2022-06-21 14:46:04.228026
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """update_headers() - update headers dict while ignoring some header names.
    """
    requested_headers = RequestHeadersDict()
    requested_headers.update({
        'Accept': 'text/html',
        'Accept-encoding': 'gzip, deflate',
        'Content-length': '0'
    })

    session = Session('/tmp/test.json')
    session.update_headers(requested_headers)

    expected_session_headers = {
        'Accept': 'text/html',
        'Accept-encoding': 'gzip, deflate'
    }
    assert session.headers == expected_session_headers

# Generated at 2022-06-21 14:46:21.082037
# Unit test for constructor of class Session
def test_Session():
    # Initialize the Session
    url = 'http://httpbin.org/cookies'
    session_path = 'sessions/httpbin.org/default.json'
    session = Session(session_path)
 
    # Test if the Session is created successfully
    assert True == os.path.exists('sessions')
    assert True == os.path.exists(session_path)
    assert True == os.path.isdir('sessions')
    assert True == os.path.isfile(session_path)

    # Test if the Session is correctly initalized
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}

    # Test if the Session can be updated

# Generated at 2022-06-21 14:46:23.151801
# Unit test for constructor of class Session
def test_Session():
    s = Session('/path/to/session.json')
    assert(s.config_dir == '/path/to')



# Generated at 2022-06-21 14:46:35.317898
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.plugins import builtin
    from httpie.plugins.manager import plugin_manager
    plugin_manager.load_builtin_plugins()
    plugin_manager.load_external_plugins()

    plugin_manager.register(builtin.Form, 'form')

    session = Session(path=Path('/path/to/session'))
    session.update_headers(request_headers={
        'Cookie': 'key=value',
        'Content-Type': 'application/json',
        'If-None-Match': '17a3201566c79da6b406a8a9e4491d2c',
        'user-agent': 'HTTPie/1.0.2',
        'Form': 'a=b&c=d'
    })

# Generated at 2022-06-21 14:46:43.330432
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    headers = {
        'Content-Length': '15',
        'Content-Type': 'utf8',
        'Accept': '*/*',
        'Cookie': 'name=value',
        'User-Agent': 'HTTPie/1.0.2'
    }
    session.update_headers(headers)
    assert session['headers'] == {'Accept': '*/*'}
    assert session['cookies'] == {'name': {'value': 'value'}}

# Generated at 2022-06-21 14:46:50.886782
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test_sessions")
    session['cookies'] = {
        'one': {'value': '1'},
        'two': {'value': '2'},
        'three': {'value': '3'}
    }
    session.remove_cookies(['one', 'three'])
    assert session['cookies'] == {
        'two': {'value': '2'}
    }

# Generated at 2022-06-21 14:46:59.603834
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    p = Path('sessions/test.json')
    s = Session(p)

    # Create a custom request headers
    request_headers = RequestHeadersDict({'Custom-Header-1': 'test_value_1'})
    # Call method update_headers of class Session
    s.update_headers(request_headers)

    # Verify that the header was added to the session
    # headers, and that the cookie attribute does not exist
    assert {'Custom-Header-1': 'test_value_1'} == s['headers']
    assert 'cookies' not in s

    # Create a custom request headers
    request_headers = RequestHeadersDict({'Cookie': 'test_value_2'})
    # Call method update_headers of class Session
    s.update_headers(request_headers)

    # Verify that the cookie

# Generated at 2022-06-21 14:47:09.294400
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import json
    import os
    import tempfile

    """\
    @test_Session_update_headers
    def test_Session_update_headers():
    """
    session = Session(os.path.join(tempfile.gettempdir(),'"./sessions"/xxxx'))
    print(os.path.exists("../sessions"))
    d = { "headers" : {}, "cookies": {}, "auth": {"type": None, "username": None, "password": None } }
    session.update(d)
    session.update_headers({"content-type": "text/plain", "content-length": "100"})
    session.update_headers({"content-type": "text/html", "content-length": "200"})

# Generated at 2022-06-21 14:47:10.884634
# Unit test for constructor of class Session
def test_Session():
	assert Session('./tests/sessions-dir/localhost/default.json') is not None

# Generated at 2022-06-21 14:47:12.792364
# Unit test for function get_httpie_session
def test_get_httpie_session():
    DEFAULT_SESSIONS_DIR = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME

# Generated at 2022-06-21 14:47:21.882479
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Arrange
    session = Session(Path("test.json"))
    session["headers"] = {"test1": "testV1", "test2": "testV2"}
    request_headers = RequestHeadersDict()
    request_headers.add("test1", "testV3")
    request_headers.add("test3", "testV3")
    # Act
    session.update_headers(request_headers)
    # Assert
    assert(session["headers"] == {"test1": "testV3", "test2": "testV2", "test3": "testV3"})
    assert(request_headers == {"test3": "testV3"})

# Generated at 2022-06-21 14:47:50.044017
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Arrange
    class Session(BaseConfigDict):
        helpurl = 'https://httpie.org/doc#sessions'
        about = 'HTTPie session file'
        def __init__(self, path: Union[str, Path]):
            super().__init__(path=Path(path))
            self['headers'] = {"aaa":"111", "ccc":"333"}
            self['cookies'] = {}
            self['auth'] = {'type': None, 'username': None, 'password': None}
        @property
        def headers(self) -> RequestHeadersDict:
            return RequestHeadersDict(self['headers'])
        @property
        def cookies(self) -> RequestsCookieJar:
            jar = RequestsCookieJar()

# Generated at 2022-06-21 14:48:02.170959
# Unit test for function get_httpie_session
def test_get_httpie_session():
    mock_event_loop = {"httpie_cmd": "http --session=mock_session http://localhost:8080/test"}

# Generated at 2022-06-21 14:48:13.535356
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.context import Environment
    from httpie.compat import HTTPHeaderDict
    from pytest import raises

    env = Environment(stdin=None,
                      stdout=None,
                      stderr=None,
                      stdin_isatty=False,
                      stdout_isatty=False,
                      stdin_bytes_size=None,
                      stdin_is_bytes=False)
    session = Session(path='./tests/fixtures/sessions/test_Session_update_headers.json')

# Generated at 2022-06-21 14:48:14.535496
# Unit test for constructor of class Session
def test_Session():
    assert Session('/tmp/test.json')

# Generated at 2022-06-21 14:48:20.019314
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'Cookie': 'SessionID=123; Expires=Mon, 01-Jan-2020 00:00:00 GMT'})
    assert 'Cookie' not in session.headers
    assert 'SessionID' in session.cookies
    assert session.cookies['SessionID'].value == '123'


# Generated at 2022-06-21 14:48:29.500600
# Unit test for constructor of class Session
def test_Session():
	s = Session('/home/jabba/Desktop/sfile')
	print(s)
	print(s['headers'])
	print(s['cookies'])
	print(s['auth'])
	s['headers']['testheader'] = 'testvalue'
	s['headers']['testheader2'] = 'testvalue2'
	s['cookies']['testcookie'] = 'testvalue'
	s['cookies']['testcookie2'] = 'testvalue2'
	s['auth']['testauth'] = 'testvalue'
	s['auth']['testauth2'] = 'testvalue2'
	print(s)
	print(s['headers'])
	print(s['cookies'])
	print(s['auth'])

# Generated at 2022-06-21 14:48:38.156888
# Unit test for function get_httpie_session
def test_get_httpie_session():

    # Case 1: session_name includes os.path.sep
    expected_path = '~/foo/bar.json'
    result_path = get_httpie_session(Path(), '~/foo/bar.json', None, '').path
    assert result_path == expected_path

    # Case 2: session_name does not include os.path.sep
    expected_path = '~/.config/httpie/sessions/foo/bar.json'
    result_path = get_httpie_session(Path('~/.config/httpie'), 'foo/bar', None, '').path
    assert result_path == expected_path

# Generated at 2022-06-21 14:48:44.575355
# Unit test for constructor of class Session
def test_Session():
    s = Session(path='httpie/config/sessions/localhost/session.json')
    if (s['headers'] == {}) and (s['cookies'] == {}) and \
            (s['auth'] == {'type': None, 'username': None, 'password': None}):
        print("private attribute initialization successed")
    else:
        print("private attribute initialization failed")

# Generated at 2022-06-21 14:48:52.473824
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Set up
    session = Session('')
    cookie_name_1 = 'cookie_name_1'
    cookie_name_2 = 'cookie_name_2'
    cookies = {}
    cookies[cookie_name_1] = {'value': 'value'}
    cookies[cookie_name_2] = {'value': 'value'}
    session['cookies'] = cookies
    # Test
    session.remove_cookies(['cookie_name_1'])
    # Verify
    assert session['cookies'] == {cookie_name_2: {'value': 'value'}}

# Generated at 2022-06-21 14:49:04.335336
# Unit test for constructor of class Session
def test_Session():
    assert VALID_SESSION_NAME_PATTERN.match('a-1_2.3')
    assert not VALID_SESSION_NAME_PATTERN.match('/a-1_2.3')
    assert not VALID_SESSION_NAME_PATTERN.match('/a-1_2.3/')
    assert not VALID_SESSION_NAME_PATTERN.match('./a-1_2.3')
    assert not VALID_SESSION_NAME_PATTERN.match('../a-1_2.3')
    # If a file exists already, it should be opened.
    temp_file = os.path.join(os.path.dirname(__file__), '..', 'temp', 'a-1_2.3.json')

# Generated at 2022-06-21 14:49:36.594440
# Unit test for function get_httpie_session
def test_get_httpie_session():
    """Test to see if the session file gets created"""
    if not DEFAULT_SESSIONS_DIR.is_dir():
        DEFAULT_SESSIONS_DIR.mkdir()

    s = get_httpie_session(DEFAULT_CONFIG_DIR, 'test', 'httpbin.org', 'http://httpbin.org/get')
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }
    assert DEFAULT_SESSIONS_DIR.joinpath('httpbin_org/test.json').is_file()

# Generated at 2022-06-21 14:49:38.330906
# Unit test for constructor of class Session
def test_Session():
    session = Session(path='./test.json')
    print(session)
    pass

# Main function

# Generated at 2022-06-21 14:49:48.809129
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session.cookies = RequestsCookieJar()
    cookie1 = create_cookie('key1', 'value1')
    session.cookies.set_cookie(cookie1)
    cookie2 = create_cookie('key2', 'value2')
    session.cookies.set_cookie(cookie2)
    cookie3 = create_cookie('key3', 'value3')
    session.cookies.set_cookie(cookie3)
    session.remove_cookies(['key2'])
    assert len(session.cookies) == 2
    for c in session.cookies:
        assert c.name != 'key2'
    assert cookie1 in session.cookies

# Generated at 2022-06-21 14:49:59.139332
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # case 1: path = "/home/user/.config/httpie/sessions/test.json"
    assert get_httpie_session(Path('/home/user/.config'), 'test', None, None).path == Path('/home/user/.config/httpie/sessions/test.json')
    # case 2: path = "/home/user/.config/httpie/sessions/test.json"
    assert get_httpie_session(Path('/home/user/.config'), '/home/user/.config/httpie/sessions/test.json', None, None).path == Path('/home/user/.config/httpie/sessions/test.json')
    # case 3: path = "/home/user/.config/httpie/sessions/localhost/test.json"

# Generated at 2022-06-21 14:50:01.402947
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('path')
    session.update_headers({'Connection': 'websocket'})
    assert session['headers'] == {'Connection': 'websocket'}



# Generated at 2022-06-21 14:50:07.362370
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    def assert_session(session_name: str,
                       request_headers: RequestHeadersDict,
                       expected: RequestHeadersDict):
        session = Session(session_name)
        session.update_headers(request_headers)
        assert session.headers == expected


# Generated at 2022-06-21 14:50:15.541929
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Test the Session class for method remove_cookies.
    """
    session = Session(path='test')
    session['cookies'] = {'cookie1': 'value1'}
    session['cookies']['cookie2'] = {'path': '/', 'value': 'value2'}
    session['cookies']['cookie3'] = {'path': '/', 'value': 'value3'}
    session.remove_cookies(['cookie2', 'cookie3'])
    assert not session['cookies']

# Generated at 2022-06-21 14:50:19.981465
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    s['cookies'] = {'test1': 'test1', 'test2': 'test2'}
    s.remove_cookies(['test1'])
    assert s['cookies'] == {'test2': 'test2'}

# Generated at 2022-06-21 14:50:22.912345
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DummyConfigDir({}), 'test_session', None, 'https://www.google.com/')
    assert get_httpie_session(DummyConfigDir({}), 'test_session', 'httpbin.org', 'https://httpbin.org/')
    assert not get_httpie_session(DummyConfigDir({}), 'test_session', 'httpbintest.org', 'https://httpbin.org/')



# Generated at 2022-06-21 14:50:26.533694
# Unit test for function get_httpie_session
def test_get_httpie_session():
    Session = get_httpie_session(
        config_dir='/path/to/config',
        session_name='httpbin_0_10_0',
        host='httpbin.org',
        url='http://www.httpbin.org/'
    )
    assert isinstance(Session, Session)

# Generated at 2022-06-21 14:51:01.469870
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('C:\\Users/user-name/httpie/sessions/session_name.json')

    # test case #1
    request_headers = {
        'cookie' : 'foo=bar; session=123',
        'user-agent' : 'HTTPie/1.0.0',
        'foo' : 'bar',
        'Content-Type' : 'text/html',
        'If-Match' : '*'
    }
    session.update_headers(request_headers)
    assert session['cookies'] == {'foo': {'value': 'bar'}, 'session': {'value': '123'}}
    assert session.headers == {'foo': 'bar'}

    # test case #2

# Generated at 2022-06-21 14:51:13.031552
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    session = Session("~/config/dir")
    request_headers = RequestHeadersDict({'Content-Lenght': 0, 'If-Modified-Since': 'Fri, 02 Nov 2018 18:06:58 GMT', 
        'Host': 'localhost', 'Accept': '*/*', 'Content-Type': 'application/x-www-form-urlencoded', 
        'User-Agent': 'HTTPie/1.0.0-dev'})
    assert len(session.headers) == 0
    session.update_headers(request_headers)

# Generated at 2022-06-21 14:51:18.342523
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # Not sure that this test is unit test, because it call many functions
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'test'
    host = None
    url = 'http://example.com' # the url can be anything

    get_httpie_session(config_dir, session_name, host, url)

# Generated at 2022-06-21 14:51:24.097740
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/dev/null')
    cookies_to_delete = ['cookie_1', 'cookie_2']
    # Test that an exception is thrown if name is not in self['cookies']
    try:
        session.remove_cookies(cookies_to_delete)
    except KeyError:
        assert True
    # Test that an exception is NOT thrown if name is in self['cookies']
    session['cookies'] = {'cookie_1': {'value': 'cookie_value'}}
    session.remove_cookies(cookies_to_delete)
    assert True



# Generated at 2022-06-21 14:51:36.169997
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('./')
    session_name = "sjtu"
    host = "https://github.com"
    url = host + "/zhaochenxu"
    assert str(get_httpie_session(config_dir, session_name, host, url)) == '{}'

    config_dir = Path('./')
    session_name = "sjtu"
    host = "https://github.com"
    url = host
    assert str(get_httpie_session(config_dir, session_name, host, url)) == '{}'

    config_dir = StringIO()
    session_name = "sjtu"
    host = "https://github.com"
    url = host

# Generated at 2022-06-21 14:51:46.576049
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path(''))
    session.update_headers({'Content-Type': "application/json"})
    assert not session.headers


    session.update_headers({'User-Agent': "HTTPie/1.0.0"})
    assert not session.headers


    session.update_headers({'Cookie': "user=123"})
    assert not session.headers


    session.update_headers({'User-Agent': "HTTPie/1.0.0", "a" : "b"})
    assert session.headers['a'] == 'b'


    session.update_headers({'Content-Type': "application/json", 'a': "b"})
    assert session.headers['a'] == 'b'



# Generated at 2022-06-21 14:51:56.270948
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./')
    session['headers'] = {}
    request_headers = {
        'Host': 'httpbin.org',
        'content-type': 'text',
        'content-Length': '100',
        'If-Match': 'xyz',
        'Connection': 'keep-alive',
        'Accept': '*/*'
    }
    session.update_headers(request_headers)
    correct = {
        'Host': 'httpbin.org',
        'content-type': 'text',
        'Connection': 'keep-alive',
        'Accept': '*/*'
    }
    assert session['headers'] == correct

# Generated at 2022-06-21 14:52:00.687228
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('')
    s['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    s.remove_cookies(['a', 'c'])
    assert s['cookies'] == {'b': 2}


# Generated at 2022-06-21 14:52:03.742356
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(
        DEFAULT_SESSIONS_DIR, '', None, ''
        )
    assert type(session) == Session


# Generated at 2022-06-21 14:52:12.169185
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('~/.httpie/sessions/example.com/default.json')
    session['cookies'] = {
        'key1': {'value': 1},
        'key2': {'value': 2},
        'key3': {'value': 3}
    }

    # remove one cookie from the session file
    session.remove_cookies(['key1'])
    assert session['cookies'] == {'key2': {'value': 2},
                                  'key3': {'value': 3}}

    # then remove a second cookie
    session.remove_cookies(['key3'])
    assert session['cookies'] == {'key2': {'value': 2}}

    # finally remove the third cookie and it should be empty
    session.remove_cookies(['key2'])
    assert session

# Generated at 2022-06-21 14:52:44.611325
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'biscuit': {'value': 'sweet'}, 'cake': {'value': 'tasty'}}
    session.remove_cookies(names=['biscuit', 'cake'])
    session.remove_cookies(names=['biscuit'])
    assert 0 == len(session['cookies'])



# Generated at 2022-06-21 14:52:54.529293
# Unit test for constructor of class Session
def test_Session():

        from pathlib import Path
        from httpie.cli.dicts import RequestHeadersDict

        s = Session('/tmp')
        s['auth'] = {'type': 'basic', 'username': None, 'password': None}
        s['headers'] = {}
        s['cookies'] = {}
        assert s.path == Path('/tmp')
        assert s['auth'] == {'type': 'basic', 'username': None, 'password': None}
        assert s['headers'] == {}
        assert s['cookies'] == {}
        assert type(s.headers) == RequestHeadersDict


# Generated at 2022-06-21 14:52:57.030208
# Unit test for function get_httpie_session
def test_get_httpie_session():
    sess = get_httpie_session(DEFAULT_CONFIG_DIR, 'test', 'test.com', 'http://test.com')
    assert isinstance(sess, Session)

# Generated at 2022-06-21 14:52:59.330475
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_data/sessions/sample.json')
    session.remove_cookies(['_gitlab_session'])

    assert '_gitlab_session' not in session['cookies']

# Generated at 2022-06-21 14:53:02.738857
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Arrange
    session = Session(path=None)

    # Act
    session.update_headers({'headers_json': '{}'})

    # Assert
    assert session['headers']['headers_json'] == '{}'

# Generated at 2022-06-21 14:53:03.319568
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert False

# Generated at 2022-06-21 14:53:08.211065
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session_name = "httpie_session"
    host  = 'httpbin.org'
    url = 'http://httpbin.org/headers'
    session = get_httpie_session(
        config_dir = Path.cwd(),
        session_name= session_name,
        host= host,
        url= url
    )
    assert type(session) == Session

# Generated at 2022-06-21 14:53:13.941676
# Unit test for constructor of class Session
def test_Session():
    path = 'sessions/localhost/default.json'
    session = Session(path)
    assert session.path == path
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }



# Generated at 2022-06-21 14:53:20.577148
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Prepare
    test_session = Session('/tmp/test_Session_remove_cookies.json')
    test_cookie_name = 'test_cookie_name'
    test_cookie_value = 'test_cookie_value'
    test_session['cookies'][test_cookie_name] = {'value': test_cookie_value}

    # Execute
    test_session.remove_cookies([test_cookie_name])

    # Oversee
    assert test_session['cookies'] == {}

# Generated at 2022-06-21 14:53:27.250763
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Remove the specified cookies from a session JSON file
    """
    test_dict = {
        'headers': {},
        'cookies': {
            'cookie-0': {'value': 'Cookie-0-Value'},
            'cookie-1': {'value': 'Cookie-1-Value'},
            'cookie-2': {'value': 'Cookie-2-Value'}
        },
        'auth': {
            'type': None,
            'username': None,
            'password': None
        }
    }
    test_sess = Session('./')
    test_sess.update(test_dict)
    cookies_before_remove = len(test_sess['cookies'])
    # test case 1

# Generated at 2022-06-21 14:54:22.733586
# Unit test for function get_httpie_session
def test_get_httpie_session():
    # TODO: Improve this test coverage
    from httpie.compat import Path

    path = Path('.httpie/sessions/example.com/foo.json')
    s = get_httpie_session(path.parent.parent, 'example.com/foo', None, None)
    assert s._path == path

# Generated at 2022-06-21 14:54:28.280977
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {'Content-Type': 'text/plain', 'Cookie': 'a=b; c=d'}
    session = Session("dummy")
    session.update_headers(request_headers)
    assert("Content-Type" not in session.headers)
    assert("Cookie" not in session.headers)
    assert(len(session.cookies) == 1)

# Generated at 2022-06-21 14:54:39.019711
# Unit test for function get_httpie_session
def test_get_httpie_session():
    target_dir = Path(__file__).parent.parent / SESSIONS_DIR_NAME
    target_dir.mkdir(parents=True, exist_ok=True)
    target_file = target_dir / 'foo_session.json'
    session = Session(target_file)
    session.load()
    session['headers'].update({'a': '1'})
    session['cookies'] = {'name': 'value'}
    session['auth'] = {'type': 'basic'}
    session.save()

    loaded_session = get_httpie_session(target_dir, 'foo_session', 'host1', 'http://host1')
    assert loaded_session['headers']['a'] == '1'
    assert loaded_session['cookies']['name'] == {'value': 'value'}

# Generated at 2022-06-21 14:54:50.829938
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Create the Session object
    session = Session(path='default')
    my_cookie_dict = {
        'key1': {
            'value': 'val1',
            'path': '/path1'
        },
        'key2': {
            'value': 'val2',
            'path': '/path2'
        }
    }
    session['cookies'] = my_cookie_dict
    assert session['cookies']['key1']['value'] == 'val1', "Key1 not added"
    assert session['cookies']['key2']['value'] == 'val2', "Key2 not added"

    # Remove key1 from cookies
    names = ['key1']
    session.remove_cookies(names)