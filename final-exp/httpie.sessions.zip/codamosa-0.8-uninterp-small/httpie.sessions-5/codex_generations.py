

# Generated at 2022-06-25 19:21:01.665585
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'f'
    session_0 = Session(str_0)
    str_1 = '8.%c:+'
    str_2 = '1.7Qkwx'
    str_3 = '5.5'
    list_0 = [str_1, str_2, str_3]
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:21:04.187407
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'R=g'
    session_0 = Session(str_0)
    str_1 = 'Q'
    names = (str_1,)
    session_0.remove_cookies(names)


# Generated at 2022-06-25 19:21:15.698170
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'L'
    str_1 = 'y'
    str_2 = 'R'
    str_3 = 'X'
    str_4 = 'Y'
    str_5 = 'x'
    str_6 = 'b'
    str_7 = 'u'
    str_8 = 'Q'
    str_9 = 'w'
    str_10 = 'o'
    str_11 = '@'
    str_12 = 'm'
    str_13 = 'S'
    str_14 = 'I'
    str_15 = 'F'
    str_16 = 'e'
    str_17 = '.'
    str_18 = '-'
    str_19 = 'a'
    str_20 = 't'
    str_21 = 'h'
    str_

# Generated at 2022-06-25 19:21:19.458282
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'R=g'
    session_0 = Session(str_0)
    a = ['H']
    session_0.remove_cookies(a)

test_Session_remove_cookies()

# Generated at 2022-06-25 19:21:26.741354
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'R=g'
    session_0 = Session(str_0)
    str_1 = 'R=\x00\x00'
    session_0.remove_cookies(str_1)
    exception_0 = None
    try:
        str_2 = 'R=\x00\x00'
        session_0.remove_cookies(str_2)
    except Exception as exception_0:
        pass
    assert exception_0 is None



# Generated at 2022-06-25 19:21:28.727361
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(str())
    session_0.update_headers(RequestHeadersDict())


# Generated at 2022-06-25 19:21:40.196951
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print("Testing start")
    # 1st test case
    session_0 = Session("testing1.json")
    session_0.update_headers({"Content-Type":"application/json"})
    if session_0.headers == {}:
        print("Test Case 1: Pass")
    else:
        print("Test Case 1: Fail")
    # 2nd test case
    session_1 = Session("testing2.json")
    session_1.update_headers({"Content-Length":"16"})
    if session_1.headers == {}:
        print("Test Case 2: Pass")
    else:
        print("Test Case 2: Fail")
    # 3rd test case
    session_2 = Session("testing3.json")

# Generated at 2022-06-25 19:21:40.756917
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert True

# Generated at 2022-06-25 19:21:43.305439
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    a = Session('a')
    a['cookies'] = {'b': {'value': 'c'}}
    a.remove_cookies(['b', 'd'])
    assert 'b' not in a['cookies']

# Generated at 2022-06-25 19:21:54.961394
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import pytest
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins import builtin
    from httpie.output.streams import StdoutBytesIO

    error_msg = None

# Generated at 2022-06-25 19:22:14.522234
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Ensure that header 'Cookie' is extracted to the cookie jar.
    session_1 = Session('n_1')
    session_1.load()
    request_headers_1 = RequestHeadersDict([('Cookie', 'R=g')])
    session_1.update_headers(request_headers_1)
    cookies_1 = session_1.cookies
    cookie_1 = next(iter(cookies_1))
    assert cookie_1.name == 'R'
    assert cookie_1.value == 'g'
    # Ensure that header 'Cookie' is overwritten from the cookie jar.
    session_2 = Session('n_2')
    session_2.load()
    request_headers_2 = RequestHeadersDict([('Cookie', 'S=h')])

# Generated at 2022-06-25 19:22:19.079297
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('./abc')
    session_0._headers = {}
    session_0.update_headers("O")
    print ('headers:', session_0.headers)
    print ('cookies:', session_0.cookies)
    print ('auth:', session_0.auth)



if __name__ == '__main__':
    test_Session_update_headers()

# Generated at 2022-06-25 19:22:27.135246
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    assert session.headers == {}
    session.update_headers({'a': 'b'})
    assert session.headers == {'a': 'b'}
    session.update_headers({'a': None})
    assert session.headers == {}
    session.update_headers({'a': 'b c'})
    assert session.headers == {'a': 'b c'}
    session.update_headers({'a': 'e g'})
    assert session.headers == {'a': 'e g'}
    session.update_headers({'Content-Type': 'd f'})
    assert session.headers == {'a': 'e g'}
    session.update_headers({'a': 'i k'})
    assert session.headers == {'a': 'i k'}

# Generated at 2022-06-25 19:22:35.037049
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    print('Testing for method remove_cookies of class Session')

    # Case 1
    str_0 = 'R=g'
    session_0 = Session(str_0)
    session_0['cookies'] = {'httpbin.org': 'http://httpbin.org'}
    try:
        import random
        names = random.sample(session_0['cookies'].keys(), len(session_0['cookies']))
        session_0.remove_cookies(names)
    except TypeError:
        print('TypeError')
        return

test_Session_remove_cookies()

# Generated at 2022-06-25 19:22:43.842242
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'E5%8C%85%E5%BC%8F+%E8%AE%BE%E8%AE%A1.pdf'
    session_0 = Session(str_0)
    session_0.headers = '])'
    session_0.cookie_dictionary = {'&': '|4b7V', '-^': '+[K2C'}
    str_1 = '{Mw7'
    session_0.cookie_dictionary = str_1
    str_2 = '&:0'
    session_0.cookie_dictionary = str_2
    str_3 = ';1'
    session_0.cookie_dictionary = str_3
    str_4 = '=X9B'
    session_0.cookie_dictionary = str_4


# Generated at 2022-06-25 19:22:51.640607
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'R=g'
    session_0 = Session(str_0)
    headers_0 = RequestHeadersDict({})
    str_1 = 'Content-Encoding:'
    assert str_1 not in headers_0
    str_2 = 'Content-Encoding'
    str_3 = 'Content-Encoding'
    str_4 = 'Content-Encoding'
    str_5 = 'Content-Encoding'
    str_6 = 'Content-Encoding'
    str_7 = 'Content-Encoding'

# Generated at 2022-06-25 19:22:54.231985
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('Sessions/TSU.json')
    names_0 = ['']
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:22:58.153584
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Check if the attr cookies is not empty
    assert session_0.cookies is not None
    assert session_0.remove_cookies(cookies) == session_0.cookies
    # Check if the attr cookies is empty
    assert session_0.cookies == {}

# Generated at 2022-06-25 19:23:00.240377
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_0 = 'R=g'
    session_0 = Session(cookie_0)
    cookie_1 = ['R']
    session_0.remove_cookies(cookie_1)


# Generated at 2022-06-25 19:23:03.082827
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'R=g'
    session_0 = Session(str_0)
    headers = {'X-B': 'I'}
    session_0.update_headers(headers)
    assert session_0.headers == {'X-B': 'I'}

# Generated at 2022-06-25 19:23:16.698438
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('|>+b2kJ0')
    str_0 = 'W)I`O@e'
    str_1 = 'W)I`O@e'
    str_2 = 'W)I`O@e'
    str_3 = 'W)I`O@e'
    str_4 = 'W)I`O@e'
    str_5 = 'W)I`O@e'
    str_6 = 'W)I`O@e'
    str_7 = 'W)I`O@e'
    str_8 = 'W)I`O@e'
    str_9 = 'W)I`O@e'
    str_10 = 'W)I`O@e'
    str_11 = 'W)I`O@e'
    str

# Generated at 2022-06-25 19:23:23.121195
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names = ["name2","name1"]
    session_0 = Session("path")
    session_0.__setattr__("cookies",{("name1","value1"),("name2","value2")})
    session_0.remove_cookies(names)
    #order is not important to the output
    assert {("name1","value1"),("name2","value2")} == session_0.__getattribute__("cookies")


# Generated at 2022-06-25 19:23:26.028785
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.compat import is_windows
    import json
    import requests

    path_test_json = 'sessions/test.json'
    with open(path_test_json, 'r') as f:
        d_test = json.load(f)
    
    session_test = Session(path_test_json)
    session_test.update(d_test)
    session_test.remove_cookies(('Z',))
    session_test.save()

    cookies_test = session_test.cookies
    assert len(cookies_test) == 2

# Generated at 2022-06-25 19:23:31.594786
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'G'
    session_0 = Session(str_0)
    str_1 = 'o'
    request_headers_0 = RequestHeadersDict(str_1)
    session_0.headers = request_headers_0
    str_2 = 'o'
    session_0.update_headers(request_headers_0)
    str_3 = 'g'
    str_4 = 'l'
    request_headers_1 = RequestHeadersDict({str_3: str_4})
    session_0.update_headers(request_headers_1)
    str_5 = 'E'
    str_6 = 'N'
    session_0.headers = RequestHeadersDict({str_5: str_6})
    str_7 = 'e'
    session_0.update_headers

# Generated at 2022-06-25 19:23:33.899237
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("example.com")
    
    session.remove_cookies("cookie1")
    assert session.get("cookies") == {}
    

# Generated at 2022-06-25 19:23:43.219923
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session_0 = Session('dummy')
    request_headers = {
        'Content-Type': 'application/json',
        'if-match': 'ea4d4dd4-4a92-4d9f-a752-9262e2ccc984',
    }
    session_0.update_headers(request_headers)
    assert session_0['headers'] == {
        'Content-Type': 'application/json',
        'if-match': 'ea4d4dd4-4a92-4d9f-a752-9262e2ccc984',
    }

    session_1 = Session('dummy')
    request_headers = {
        'Content-Type': 'application/json',
        'if-match': '0',
    }

# Generated at 2022-06-25 19:23:46.617027
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = Path('/root/test_Session_update_headers/test')
    config_0 = BaseConfigDict(path = path_0)
    session_0 = Session(config_0)
    session_0.update_headers(path_0)

# Generated at 2022-06-25 19:23:57.634062
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'R=g'
    session_0 = Session(str_0)
    session_0.update_headers(RequestHeadersDict())
    str_1 = 'h:p'
    str_2 = 'p'
    str_3 = 'p'
    session_0.headers[str_1] = str_2
    session_0.headers[str_3] = None
    session_0.update_headers(RequestHeadersDict())
    str_4 = 'R=g'
    session_1 = Session(str_4)
    session_1.update_headers(RequestHeadersDict())
    str_5 = 'h:p'
    str_6 = 'p'
    str_7 = 'p'
    session_1.headers[str_5] = str_6
   

# Generated at 2022-06-25 19:24:01.097631
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('x')
    session.update_headers({'foo': 'bar'})
    assert session['headers'] == {'foo': 'bar'}



# Generated at 2022-06-25 19:24:03.339011
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'R=g'
    session_0 = Session(str_0)
    assert session_0.update_headers('wc') == None

# Generated at 2022-06-25 19:24:16.082767
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(str_0)
    session_0.update_headers({'X-Forwarded-For': None})
    assert session_0.headers == {'X-Forwarded-For': None}


# Generated at 2022-06-25 19:24:21.604174
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '2'
    request_headers = {str_0:'1'}
    obj = httpie.config.Session(str_0)
    if len(request_headers) < 1:
        obj.update_headers(request_headers)
        assert True
    else:
        obj.update_headers(request_headers)
        assert True


# Generated at 2022-06-25 19:24:33.806263
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test_session")
    assert session.headers == {}
    # expect header to be added
    session.update_headers({"Foo": "bar"})
    assert session.headers == {"Foo": "bar"}
    # expect header to be updated
    session.update_headers({"Foo": "baz"})
    assert session.headers == {"Foo": "baz"}
    # expect header to be added
    session.update_headers({"Baz": "qux"})
    assert session.headers == {"Foo": "baz", "Baz": "qux"}
    # expect header to be removed
    session.update_headers({"Baz": None})
    assert session.headers == {"Foo": "baz"}
    # expect header to be removed

# Generated at 2022-06-25 19:24:37.354256
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'E'
    session_0 = Session(str_0)
    str_1 = 'Ve'
    request_headers_0 = {str_1: 'S'}
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:24:43.129593
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = 'R=g'
    session_1 = Session(str_1)
    dict_2 = {'A': 'g'}
    session_1.update_headers(dict_2)
    dict_3 = {'B': 'g'}
    session_1.update_headers(dict_3)
    dict_4 = {'B': 'g'}
    session_1.update_headers(dict_4)


# Generated at 2022-06-25 19:24:52.747386
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from json import loads
    from pathlib import Path
    from urllib.parse import urlparse
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.config import load_config
    from httpie.plugins.registry import plugin_manager
    from httpie.session import Session
    from httpie.utils import get_response
    from httpie.utils import PathEnviron
    from httpie.utils import unicode_printer
    from requests.auth import HTTPBasicAuth
    from requests.auth import HTTPDigestAuth
    from requests.auth import AuthBase
    plugin_manager._load_local_plugins()
    plugin_manager._discover_external_plugins()
    plugin_manager._instantiate_plugins()
    cookies = None
   

# Generated at 2022-06-25 19:24:54.831339
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = 'R=s'
    session_0 = Session(str_1)
    request_headers = {}
    session_0.update_headers(request_headers)



# Generated at 2022-06-25 19:24:59.576651
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    TODO
    """
    session_0 = Session('c_0')
    headers_0 = RequestHeadersDict([])
    session_0.update_headers(headers_0)
    assert session_0.headers == headers_0


# Generated at 2022-06-25 19:25:03.109141
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = RequestHeadersDict()
    request_headers["Connection"] = "Keep-Alive"

    session = Session('path')
    session.update_headers(request_headers)
    assert session.headers["Connection"] == "Keep-Alive"

# Generated at 2022-06-25 19:25:06.422169
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'R=g'
    dict_0 = {'Accept': '*/*'}
    session_0 = Session(str_0)
    session_0.update_headers(dict_0)


# Generated at 2022-06-25 19:25:28.402536
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class TestSession(Session):
        def update_headers(self, request_headers: RequestHeadersDict):
            assert request_headers['Foo'] == 'Bar', 'Request headers is wrong'
            assert self['headers']['Foo'] == 'Bar', 'Session header is wrong'

    session_0 = TestSession('requests_auth_plugin')
    session_0['Foo'] = 'Bar'
    session_0.update_headers({'Foo': 'Bar'})
    session_1 = TestSession('/tmp/session.json')
    session_1.update_headers({'Foo': 'Bar'})



# Generated at 2022-06-25 19:25:33.214867
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config_dir = Path('./config_dir')
    session_name = 'session_name'
    host = 'www.baidu.com'
    url = 'http://www.baidu.com'
    session = get_httpie_session(config_dir, session_name, host, url)
    session.update_headers({})


# Generated at 2022-06-25 19:25:36.392675
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers_0 = {}
    str_0 = 'S'
    session_0 = Session(str_0)
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:25:39.827186
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    str_0 = 'R=g'
    str_1 = '69'
    str_2 = '5v'
    session_0 = Session(str_0)
    session_0.update_headers(RequestHeadersDict(str_0))


# Generated at 2022-06-25 19:25:50.503751
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'R=g'
    session_0 = Session(str_0)
    session_0.update_headers(RequestHeadersDict({"key": "value", "cookie": "h=cookie_value"}))
    # cookie=h=cookie_value gets parsed and stored in cookies dictionary
    assert session_0.cookies == {"h": {"expires": None, "path": None, "secure": False, "value": "cookie_value"}}
    # key=value gets stored in headers dictionary
    assert session_0.headers == {"key": "value"}
    session_0.update_headers(RequestHeadersDict({"content-type": "x-new-type"}))
    # content-type=x-new-type gets ignored and not stored in headers dictionary

# Generated at 2022-06-25 19:25:57.376862
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test with header "User-Agent"
    header_0 = {'User-Agent': 'HTTPie/0.9.6'}
    session_0 = Session('Json')
    session_0.headers = header_0
    assert session_0.headers['User-Agent'] == 'HTTPie/0.9.6'
    # Test with header "Cookie"
    header_1 = {'Cookie': 'SID=test;'}
    session_1 = Session('Json')
    session_1.headers = header_1
    assert session_1.headers['Cookie'] == 'SID=test;'
    assert 'SID' in session_1.cookies.keys()
    assert session_1.cookies['SID'].value == 'test'
    # Test with headers "Content-Type" and "

# Generated at 2022-06-25 19:26:07.360552
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('session.json')
    session['headers'] = {'new-data':'test data'}
    session.update_headers({'data':'test data'})
    assert session['headers'] == {'new-data':'test data', 'data':'test data'}
    session.update_headers({'if':'test data'})
    assert session['headers'] == {'new-data':'test data', 'data':'test data'}
    session.update_headers({'Content-type':'test data'})
    assert session['headers'] == {'new-data':'test data', 'data':'test data'}


# Generated at 2022-06-25 19:26:14.172424
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    cookie = SimpleCookie()
    cookie['my_cookie'] = 'my_cookie_value'
    session = Session('R=g')
    session.update_headers({'cookie': cookie})
    assert session['cookies']['my_cookie']['value'] == 'my_cookie_value'


# Generated at 2022-06-25 19:26:21.256918
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'R=g'
    session_0 = Session(str_0)
    request_headers_0 = {}
    request_headers_0['User-Agent'] = 'HTTPie/0.9.3'
    request_headers_0['Content-Length'] = '31'
    request_headers_0['Host'] = 'httpbin.org'
    request_headers_0['Accept-Encoding'] = 'gzip, deflate, compress'
    request_headers_0['Accept'] = 'application/json'
    request_headers_0['Content-Type'] = 'application/json'
    session_0.update_headers(request_headers_0)



# Generated at 2022-06-25 19:26:26.158872
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = 'sessions/localhost/test.json'
    session_0 = Session(path_0)
    str_0 = 'I=am!a test!'
    request_headers_0 = RequestHeadersDict({'I': 'am!a test!'})
    session_0.update_headers(request_headers_0)
    str_1 = 'I=yes+i+am'
    request_headers_1 = RequestHeadersDict({'I': 'yes i am'})
    session_0.update_headers(request_headers_1)


# Generated at 2022-06-25 19:26:49.760285
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_1 = Session("R=g")
    session_1['headers'] = {}
    session_1['cookies'] = {}
    session_1['auth'] = {}
    session_1.headers = {"x": "y"}
    RequestHeadersDict_0 = session_1.headers.copy()
    RequestHeadersDict_0.update({"x": "y"})
# test method Session.update_headers
    session_1.update_headers({})
# test method Session.update_headers
    session_1.update_headers({"x": "y"})
# test method Session.update_headers
    session_1.update_headers({"x": None})
# test method Session.update_headers
    session_1.update_headers({"x-header": "y"})
# test method Session.update_

# Generated at 2022-06-25 19:27:02.056323
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'Z'
    s_0 = Session(str_0)
    name_0 = 'Y'
    value_0 = '5'
    s_0.headers[name_0] = value_0
    s_0.headers[name_0] = value_0
    name_1 = 'auth'
    value_1 = {'type': 'basic', 'username': 'admin', 'password': 'admin'}
    s_0.auth = value_1
    value_2 = 'B'
    request_headers_0 = {name_1: value_2}
    s_0.update_headers(request_headers_0)
    from requests.cookies import RequestsCookieJar
    jar_0 = RequestsCookieJar()

# Generated at 2022-06-25 19:27:08.136808
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'C:\\PROGRA~1\\JAVA\\JAVA37~1\\jre\\bin'
    str_1 = 'C:\\PROGRA~1\\JAVA\\JAVA37~1'
    session_0 = Session(str_0)
    session_0.update_headers(str_1)


# Generated at 2022-06-25 19:27:11.111400
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'W<'
    session_0 = Session(str_0)
    headers = {}
    session_0.update_headers(headers)

# Generated at 2022-06-25 19:27:14.564771
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    request_headers = RequestHeadersDict({'Accept': 'text/html'})
    session.update_headers(request_headers)
    assert session.headers['Accept'] == 'text/html'

# Generated at 2022-06-25 19:27:21.052700
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'C'
    dict_0 = {}
    dict_0[''] = None
    dict_0['l'] = None
    session_0 = Session(str_0)
    session_0.update_headers(dict_0)
    print(session_0.headers)

# Generated at 2022-06-25 19:27:30.441982
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'R': 'g'})
    assert session['headers'] == {'R': 'g'}
    session.update_headers({'R': 'c'})
    assert session['headers'] == {'R': 'c'}
    session.update_headers({'C': 'f'})
    assert session['headers'] == {'R': 'c', 'C': 'f'}
    parsed_cookie = SimpleCookie('Y=2')
    cookie_name = next(iter(parsed_cookie))
    morsel = parsed_cookie[cookie_name]
    cookie = {'value': morsel.value}
    assert session.get('cookies') == {cookie_name: cookie}
    session.update_headers({'R': None})

# Generated at 2022-06-25 19:27:40.433720
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    new_session = Session('{}')
    new_session.update_headers({"Accept" : "text/html"})
    assert new_session['headers'] == {"Accept" : "text/html"}
    new_session.update_headers({'Accept-Encoding': 'gzip, deflate'})
    assert new_session['headers'] == {"Accept" : "text/html", "Accept-Encoding": "gzip, deflate" }
    new_session.update_headers({'Accept-Language': 'en-US,en;q=0.9'})
    assert new_session['headers'] == {"Accept" : "text/html", "Accept-Encoding": "gzip, deflate", "Accept-Language": "en-US,en;q=0.9" }

# Generated at 2022-06-25 19:27:42.526066
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'H'
    session_0 = Session(str_0)
    # no assertions yet


# Generated at 2022-06-25 19:27:51.990028
# Unit test for method update_headers of class Session

# Generated at 2022-06-25 19:28:23.549073
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Create an instance of Session
    session = Session(Path('/home/test'))
    session.update_headers({'test' : 'test'})

    assert session.header == {'test' : 'test'}


# Generated at 2022-06-25 19:28:28.872538
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict()
    headers['Accept'] = 'text/html'
    headers['Accept'] = 'application/json'
    headers['User-Agent'] = 'httpie/0.9.9'
    headers['Cookie'] = 'foo=bar; spam=eggs'
    session = Session('./')
    session.update_headers(headers)
    assert session['headers'] == {'Accept': 'application/json'}
    assert session['cookies']['foo']['value'] == 'bar'
    assert session['cookies']['spam']['value'] == 'eggs'

# Generated at 2022-06-25 19:28:38.879854
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Case 0.
    session_0 = Session('R=g')
    session_0.update_headers({'C': 'd', 'E': 'f', 'If-Match': '*'})
    assert session_0['headers'] == {'C': 'd', 'E': 'f'}

    # Case 1.
    session_1 = Session('Q=f')
    session_1.update_headers({'If-Match': '*', 'If-Modified-Since': 'Fri, 22 Apr 2016 15:27:48 GMT', 'User-Agent': 'HTTPie/0.9.8'})
    assert session_1['headers'] == {'If-Modified-Since': 'Fri, 22 Apr 2016 15:27:48 GMT'}

    # Case 2.
    session_2 = Session('P=e')
    session

# Generated at 2022-06-25 19:28:48.436196
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Session.update_headers()
    str_0 = 'R=@'
    session_0 = Session(str_0)
    session_0.load()
    assert session_0.headers == {}
    str_1 = 'Content-Type: text/plain; charset=utf-8'
    request_headers_0 = RequestHeadersDict.from_str(str_1)
    session_0.update_headers(request_headers_0)
    assert session_0.headers == {'Content-Type': 'text/plain; charset=utf-8'}
    str_2 = 'Content-Length: 100'
    session_0.headers['Content-Length'] = 100
    assert session_0.headers == {'Content-Type': 'text/plain; charset=utf-8', 'Content-Length': 100}


# Generated at 2022-06-25 19:28:55.904280
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Arrange
    str_0 = 'R=g'
    session_0 = Session(str_0)
    request_headers_0 = {'r': '"a"', 'eb': '"a"', 'm': '"a"'}
    # Act
    session_0.update_headers(request_headers_0)
    # Assert


# Generated at 2022-06-25 19:28:58.601307
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s0 = Session('/test')
    headers = RequestHeadersDict()
    headers['cookie'] = 'test=test'
    s0.update_headers(headers)
    assert s0['cookies'] == {'test': {'value': 'test'}}

# Generated at 2022-06-25 19:29:09.106155
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # Session without headers
    session_0 = Session('test_0')
    request_headers_0 = RequestHeadersDict(
        [('test_0', 'value_0'), ('test_1', 'value_1')],
    )
    session_0.update_headers(request_headers_0)
    assert True == session_0['headers']['test_0'] == \
        request_headers_0['test_0']
    assert True == session_0['headers']['test_1'] == \
        request_headers_0['test_1']

    # Session with headers
    session_1 = Session('test_1')
    request_headers_1 = RequestHeadersDict([('test_0', 'value_0')])

# Generated at 2022-06-25 19:29:13.090995
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = None
    request_headers_0 = {}
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:29:18.984277
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'R=g'
    session_0 = Session(str_0)
    dict_0 = dict()
    dict_0['st'] = 'apiy'
    dict_0['Dz'] = 'Fu'
    dict_0['Ek'] = 'st'
    dict_0['st'] = 'zU'
    dict_0['oa'] = 'zdY'
    dict_0['jo'] = 'DF,p'
    dict_0['zr'] = 'ttCk'
    dict_0['qb'] = 'gJ'
    dict_0['zR'] = 'm'
    dict_0['Pb'] = 'w'
    dict_0['lK'] = 'NXFx'
    dict_0['YK'] = 'J'
    dict_0

# Generated at 2022-06-25 19:29:21.950877
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '*'
    session_0 = Session(str_0)
    session_0.update_headers('4')


# Generated at 2022-06-25 19:29:57.415082
# Unit test for constructor of class Session
def test_Session():
    assert isinstance(test_case_0(), Session)

# Generated at 2022-06-25 19:30:01.970307
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = Path(__file__)
    str_0 = 'R=g'
    dict_0 = {'a': 'r'}
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict(dict_0)
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:30:05.716171
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('./')
    session_name = 'session_0'
    host = ''
    url = 'http://httpbin.org/get?test'
    httpie_session = get_httpie_session(config_dir, session_name, host, url)
    print (httpie_session)


# Generated at 2022-06-25 19:30:08.707249
# Unit test for function get_httpie_session
def test_get_httpie_session():
    url = "http://www.httpie.org/cookies"
    session_0 = get_httpie_session(DEFAULT_CONFIG_DIR, "default", None, url)
    assert session_0.headers['Host'] == url.split('/')[2]


# Generated at 2022-06-25 19:30:09.679474
# Unit test for constructor of class Session
def test_Session():
    str_0 = 'R=g'
    session_0 = Session(str_0)
    session_0.load()

# Generated at 2022-06-25 19:30:11.676082
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'M=1'
    session_0 = Session(str_0)
    map_0 = RequestHeadersDict()
    session_0.update_headers(map_0)


# Generated at 2022-06-25 19:30:15.597560
# Unit test for function get_httpie_session
def test_get_httpie_session():
    global config_dir, url
    config_dir = Path('.')
    url = ''
    global session_name
    session_name = 'localhost_8080.json'
    get_httpie_session(config_dir, session_name, 'localhost', url)

# Generated at 2022-06-25 19:30:22.973273
# Unit test for function get_httpie_session
def test_get_httpie_session():
    path_1 = Path('/')
    str_2 = 'R=g'
    value_0 = get_httpie_session(
        path_1,
        str_2,
        None,
        None
    )
    assert isinstance(value_0, Session)
    assert value_0.get('auth') == {
        'type': None,
        'username': None,
        'password': None
    }
    assert isinstance(value_0.get('cookies'), dict)
    assert isinstance(value_0.get('headers'), dict)



# Generated at 2022-06-25 19:30:26.028468
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'y'
    session_0 = Session(str_0)
    array_0 = ['fVj', '=N', 'JLwg']
    session_0.remove_cookies(array_0)


# Generated at 2022-06-25 19:30:34.250440
# Unit test for constructor of class Session
def test_Session():
    sess = Session("test")
    assert type(sess['headers']).__name__ == 'dict'
    assert type(sess['cookies']).__name__ == 'dict'
    assert type(sess['auth']).__name__ == 'dict'
    assert type(sess['auth']['type']).__name__ == 'NoneType'
    assert type(sess['auth']['username']).__name__ == 'NoneType'
    assert type(sess['auth']['password']).__name__ == 'NoneType'
