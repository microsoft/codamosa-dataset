

# Generated at 2022-06-25 19:21:02.432133
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # str_0[0] is an ASCII string
    str_0 = '3'
    # str_1[0] is a Unicode string
    str_1 = '\u0100'
    # list_0[0] is an ASCII string
    list_0 = []
    # list_1[0] is a Unicode string
    list_1 = []
    list_0.insert(0, str_0)
    list_0.append(str_1)
    list_1.insert(0, str_1)
    list_1.append(str_0)
    # list_2[0] is a Unicode string
    list_2 = ['9', 'Z']
    # tuple_0[0] is a Unicode string
    tuple_0 = ()
    # tuple_1[0] is a Unicode string
    tuple_

# Generated at 2022-06-25 19:21:08.801241
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    arr_0 = []
    session_0.remove_cookies(arr_0)
    assert session_0 == {'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}}


# Generated at 2022-06-25 19:21:19.346799
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    path_0 = Path(str_0)
    session_0 = Session(path_0)
    list_0 = ['Content-Type', 'Content-Length', 'Host', 'Connection', 'User-Agent', 'X-Request-ID', 'Via', 'Accept-Encoding', 'Cache-Control', 'Authorization', 'Cookie']
    list_1 = [None, None, None, None, None, None, None, None, None, None, None]
    dict_0 = dict(zip(list_0, list_1))
    request_headers_dict_0 = RequestHeadersDict(dict_0)
    session_0.update_headers(request_headers_dict_0)
    assert session_0['headers']

# Generated at 2022-06-25 19:21:30.905500
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '(Tz~2T'
    session_0 = Session(str_0)
    str_1 = 'application/x-www-form-urlencoded'
    list_0 = [('Content-Type', str_1)]
    dict_0 = dict(list_0)
    headers_0 = RequestHeadersDict(dict_0)
    session_0.update_headers(headers_0)
    str_2 = 'x-www-form-urlencoded'
    list_1 = [('content-type', str_2)]
    list_2 = list_1
    dict_1 = dict(list_2)
    bool_0 = not cmp(dict_0, dict_1)
    str_3 = 'application/x-www-form-urlencoded'

# Generated at 2022-06-25 19:21:41.499295
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Setup
    str_0 = 'z~Dq3m@A'
    session_0 = Session(str_0)
    session_0['headers'] = {}
    session_0['cookies'] = {}
    headers_0 = RequestHeadersDict()
    headers_0['Accept'] = '*/*'
    headers_0['Content-Type'] = 'application/json'
    headers_0['Cookie'] = 'SID=31d4d96e407aad42'

    # Testing
    session_0.update_headers(headers_0)

    assert session_0 == {
        'headers': {'Accept': '*/*', 'Content-Type': 'application/json'},
        'cookies': {'SID': {'value': '31d4d96e407aad42'}}
    }

# Generated at 2022-06-25 19:21:53.360663
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'Z}n,GQ*qqT#k-b_`W8.)'
    session_0 = Session(str_0)
    dict_0 = RequestHeadersDict({})
    dict_0['referer'] = 'https://google.com'
    dict_0['if-range'] = '"Sun, 05 Aug 2018 00:27:22 GMT"'
    dict_0['content-type'] = 'application/json'

# Generated at 2022-06-25 19:22:04.365659
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    data = [['ÿZ¿', '+Ö'], ['ÿ¸¾ÿ', 'ÿÿ'], ['ÿ¸¾ÿ', '¾¾ÿ']]

    for (i,data) in enumerate(data):
        session_0 = Session("test_session")
        session_0.update_headers(data)
        if len(session_0.keys()) == 0:
            print("passed test: %d" % i)
        else:
            j = 0
            for key in session_0.keys():
                if session_0[key] != data[j]:
                    print("failed test: %d" % i)
                    break
                else:
                    print("passed test: %d" % i)
                j += 1


# Generated at 2022-06-25 19:22:13.831043
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('x{x')
    request_headers_0 = RequestHeadersDict()
    request_headers_0['authorization'] = 's8s'
    request_headers_0['Cookie'] = 'k/d]*'
    str_0 = 'BXm,'
    str_1 = 'zq3y'
    request_headers_0['Connection'] = 'close'
    request_headers_0['Connection'] = 'Upgrade'
    request_headers_0['Authorization'] = 'Basic cGhwOmJhc2lj'
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:22:18.851408
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test for parameter request_headers
    session_0 = Session('')
    request_headers_0 = {'User-Agent': 'httpie/1.0.0'}
    session_0.update_headers(request_headers_0)
    expected_value_0 = {'User-Agent': 'httpie/1.0.0'}
    assert(expected_value_0 == session_0.headers)


# Generated at 2022-06-25 19:22:24.695990
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    # MagicMock instance for dict

# Generated at 2022-06-25 19:22:34.451866
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    session_0.remove_cookies(['fQP!7'])


# Generated at 2022-06-25 19:22:37.879510
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_1 = Session('XYZ')
    session_1.update_headers({'X_AUTH_TOKEN': 'ABC'})

    session_1.headers


if __name__ == "__main__":
    test_case_0()
    test_Session_update_headers()

# Generated at 2022-06-25 19:22:42.186966
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session("29H")
    session_0.load()
    arg_0 = ['PeRJ7wv+yE', '8kJXln;p' , ']4#Z0^8B>M*Jb?Y|S']
    session_0.remove_cookies(arg_0)



# Generated at 2022-06-25 19:22:46.782981
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test that cookie with name `name` is removed from session
    name = 'mycookie'
    session = Session('test')
    session['cookies'] = {name: 'value'}
    assert name in session['cookies']
    session.remove_cookies(['mycookie'])
    assert name not in session['cookies']


# Generated at 2022-06-25 19:22:51.821849
# Unit test for method update_headers of class Session
def test_Session_update_headers():
	s = Session('./test')
	s.headers = {'user-agent':'foo','accept-encoding':'bar'}
	s.update_headers(s.headers)
	assert s.headers == {'user-agent':'foo','accept-encoding':'bar'}


# Generated at 2022-06-25 19:23:01.427434
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'gQz$x!{?!qP9UyvrE'
    path_1 = Path(str_0)
    host_2 = '8uc0J*?R[{Ky:E:<dj!-k'
    str_3 = 'F?t$;G@d[O>SRX|tJdgf+2'
    session_4 = get_httpie_session(
        path_1,
        host_2,
        str_3,
    )
    str_5 = 'Q}*J/]x;jm&u_tM[1~T'
    path_6 = Path(str_5)
    str_7 = 'x;j&u_tM[1~T'

# Generated at 2022-06-25 19:23:11.874906
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('0')
    str_0 = 'Garjld>8W'
    session_0.remove_cookies((str_0,))
    str_1 = '<#Pldj-&n'
    session_0.remove_cookies((str_1,))
    str_2 = '*r'
    session_0.remove_cookies((str_2,))
    str_3 = 'I#gZmK'
    session_0.remove_cookies((str_3,))
    str_4 = 'T<'
    session_0.remove_cookies((str_4,))
    str_5 = 'XK]Bky'
    session_0.remove_cookies((str_5,))
    str_6 = ':^'
    session_0.remove

# Generated at 2022-06-25 19:23:14.265132
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('l;j^`3{=pOSr|UW7-uYg')
    session_0.remove_cookies(['liu'])

# Generated at 2022-06-25 19:23:15.469638
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    assert Session.update_headers() == Exception 
    



# Generated at 2022-06-25 19:23:25.531390
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    data = [
        ((), {
            'headers': {}
        }),
        (({
            'Accept':           ['*/*'],
            'Accept-Encoding':  ['gzip, deflate'],
            'Content-Length':   ['0'],
            'User-Agent':       ['curl/7.47.0'],
            'X-Hello':          [''],
            'X-Unset':          [None],
        }), {
            'headers': {
                'Accept':           '*/*',
                'Accept-Encoding':  'gzip, deflate',
                'Content-Length':   '0',
                'User-Agent':       'curl/7.47.0',
                'X-Hello':          '',
            }
        }),
    ]

# Generated at 2022-06-25 19:23:42.583755
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    try:
        from httpie.cli.argtypes import KeyValue, KeyValueArgType
    except:
        from httpie.cli.argtypes import KeyValue, KeyValueArgType
    try:
        from httpie.cli.argtypes import KeyValue, KeyValueArgType
    except:
        from httpie.cli.argtypes import KeyValue, KeyValueArgType
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    keyvals = [KeyValue(key='Authorization', val='token abc123')]
    request_headers = RequestHeadersDict(KeyValueArgType.keyvalue_items(keyvals))
    session_0.update_headers(request_headers)

# Generated at 2022-06-25 19:23:43.423827
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    pass


# Generated at 2022-06-25 19:23:46.189337
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'ThS,>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    session_0.remove_cookies([])


# Generated at 2022-06-25 19:23:57.171595
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = 'abc'
    session = Session(path)
    request_headers = RequestHeadersDict()
    request_headers['cmd'] = 'ls'
    request_headers['option'] = '--al'
    # Test for prefix
    for prefix in SESSION_IGNORED_HEADER_PREFIXES:
        request_headers[f'{prefix}test'] = 'test'
    session.update_headers(request_headers)
    # Test for cookie
    request_headers['cookie'] = 'test_cookie=test'
    session.update_headers(request_headers)
    # Test for user-agent
    request_headers['user-agent'] = 'test_user_agent'
    session.update_headers(request_headers)
    # Test for non-prefix and non-cookie

# Generated at 2022-06-25 19:24:06.751460
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Given str_0 is set to constant string 'rkU^j6<d*m8?b|A$\c07j'
    str_0 = 'rkU^j6<d*m8?b|A$\c07j'
    # And session_0 is set to a new instance of class Session initialized with str_0
    session_0 = Session(str_0)
    # And str_1 is set to constant string '7S_`nye;(kq3X\'KF4x4"'
    str_1 = '7S_`nye;(kq3X\'KF4x4"'
    # And str_2 is set to constant string 'L{Z/s7/c%@M|P,<b\x07\x05\x12\x14\x1f\x

# Generated at 2022-06-25 19:24:15.954377
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    print("Unit test for Session.remove_cookies()")
    cookies_0 = {'name1' : 'value1', 'name2' : 'value2', 'name3' : 'value3'}
    names_0 = ['name3', 'name2']
    session = Session('session_0')
    session['cookies'] = cookies_0
    session.remove_cookies(names_0)
    cookies_0.pop('name3', None)
    cookies_0.pop('name2', None)
    print("Unit test for Session.remove_cookies() passed!")


# Generated at 2022-06-25 19:24:19.152537
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    session_0.remove_cookies(['3f{|iNb$N#'])


# Generated at 2022-06-25 19:24:24.302416
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    list_0 = ['id', 'url', 'method']
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:24:33.929337
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_1 = Session("C:\\Users\\chilam\\PycharmProjects\\httpie\\httpie\\cli\\config.json")
    headers_1 = {}
    headers_1["user-agent"] = "Httpie/1.0.3"
    headers_1["host"] = "localhost:8080"
    headers_1["Cookie"] = "a"
    session_1.update_headers(headers_1)
    print(session_1["headers"])


if __name__ == "__main__":
    test_Session_update_headers()

# Generated at 2022-06-25 19:24:43.370968
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import unittest
    from httpie.compat import is_py2

    class Session_update_headers_TestCase(unittest.TestCase):
        def test_no_such_header(self):
            from httpie.cli.dicts import RequestHeadersDict
            from requests.cookies import RequestsCookieJar
            from copy import copy

            headers = RequestHeadersDict()
            session_path = 'CESWQr'
            session = Session(session_path)
            session.update_headers(headers)

            if is_py2:
                self.assertEqual(
                    session.headers,
                    RequestHeadersDict(),
                )

            self.assertEqual(
                session.cookies,
                RequestsCookieJar(),
            )


# Generated at 2022-06-25 19:25:01.174053
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    str_1 = 'Q!=KxZDvND8a.W:6U'
    str_2 = 'y-W=pH1S7'
    requestHeadersDict_0 = RequestHeadersDict({str_2: str_1})
    session_0.update_headers(requestHeadersDict_0)


# Generated at 2022-06-25 19:25:02.033965
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    pass


# Generated at 2022-06-25 19:25:09.809483
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'IoFn|w?_gA[2c%8X'
    str_1 = 'J*0i_:8'
    headers_dict_0 = {}
    str_2 = 'Z_zR,7~(6`'
    str_3 = 'r@Fw?\rT0mjK'
    session_0 = Session(str_0)
    session_0.update_headers(headers_dict_0)
    assert session_0.headers == headers_dict_0
    #assert session_0.cookies == session_0.cookies
    #assert session_0.auth == session_0.auth
    #assert session_0.auth == session_0.auth



# Generated at 2022-06-25 19:25:12.159075
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s = Session('b')
    s.update_headers([('a', '1')])
    assert s['headers'] == {'a': '1'}


# Generated at 2022-06-25 19:25:20.178661
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(DEFAULT_SESSIONS_DIR)
    session_0.update_headers({'Content-Type': None})
    assert hasattr(session_0, 'headers')
    assert not callable(session_0.headers)
    assert isinstance(session_0.headers, RequestHeadersDict)
    session_0.update_headers({'Content-Type': 'application/x-www-form-urlencoded'})
    session_0.update_headers({'Accept': '*/*'})
    session_0.update_headers({'Accept': 'image/webp,*/*'})
    session_0.update_headers({'Accept-Encoding': 'deflate'})
    session_0.update_headers({'Accept-Language': 'en-US,en;q=0.5'})
   

# Generated at 2022-06-25 19:25:22.554314
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("http://httpbin.org")
    request_headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    session.update_headers(request_headers)
    assert session['headers'] == request_headers
    assert len(session['headers']) == len(request_headers)


# Generated at 2022-06-25 19:25:26.767506
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'json-session', 'localhost', "http://localhost/")
    request_headers = {'date':'Thu Jun 07 11:29:47 2018','service':'UserService','method':'FindAllUsers'}
    session.update_headers(request_headers)
    return request_headers



# Generated at 2022-06-25 19:25:35.996379
# Unit test for method update_headers of class Session
def test_Session_update_headers():
  try:
    s = Session('./test_file')
    s.update_headers({'User-Agent':'Test','Content-Type':'Test','Accept':'Test','Cookie':'Test','Accept-Encoding':'Test','Accept-Language':'Test','Connection':'Test','Cache-Control':'Test','Custom-Header':'Test'})
    assert(s.get('headers')['User-Agent'] == 'Test')
    assert(len(s.get('headers')) == 5)
    assert(s.get('headers')['Custom-Header'] == 'Test')
    assert(s.get('cookies')['Test'] == {'value':'Test'})
    assert(len(s.get('cookies')) == 1)
  except Exception as e:
    print(e)
    assert(False)
 

# Generated at 2022-06-25 19:25:46.187239
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.context import Environment
    from httpie.input import ParseError
    instance = Environment()
    assert type(instance.stdout) == io.TextIOWrapper
    assert instance.stdout.buffer.raw == sys.stdout.buffer
    assert isinstance(instance.stdin_isatty, bool)
    assert instance.stdin_isatty is sys.stdin.isatty()
    assert isinstance(instance.stdout_isatty, bool)
    assert instance.stdout_isatty is sys.stdout.isatty()
    assert isinstance(instance.is_windows, bool)
    assert instance.is_windows == (os.name == 'nt')
    assert isinstance(instance.output_encoding, str)
    assert instance.output_encoding == sys.stdout.enc

# Generated at 2022-06-25 19:25:49.000949
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    param_0 = Session('Test')
    param_1 = ['tester']
    param_0.remove_cookies(param_1)


# Generated at 2022-06-25 19:26:08.739757
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    str_1 = 'y7V#Xn6u'
    RequestHeadersDict_0 = RequestHeadersDict(str_1)
    RequestHeadersDict_1 = RequestHeadersDict(str_0)
    assert RequestHeadersDict_0 == RequestHeadersDict_1
    session_0.update_headers(RequestHeadersDict_0)
    str_2 = 'YxF>*&Ka-W&eRo{fQP!7'
    RequestHeadersDict_2 = RequestHeadersDict(str_2)
    RequestHeadersDict_3 = RequestHeadersDict(str_1)
    assert Request

# Generated at 2022-06-25 19:26:19.374651
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Reset static variable total_requests
    str_1 = 'CrbRj5GxF*&Ka-W&eRo{fQP!7'
    session_1 = Session(str_1)
    session_1[b'headers'] = {b'X-Forwarded-For': [b'172.31.84.142, 127.0.0.1'], b'X-Forwarded-Port': [b'443, 80'], b'X-Forwarded-Proto': [b'https, http'], b'X-Forwarded-Host': [b'example.com']}
    str_2 = "t{[^+%c$'J9?R,gdB.!@K#f"

# Generated at 2022-06-25 19:26:21.754885
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    session_0.update_headers({'Cookie': 'foo=bar'})
    assert session_0['cookies'] == {'foo': {'value': 'bar'}}

# Generated at 2022-06-25 19:26:27.861757
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    headers_0 = {'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'Host': 'httpbin.org', 'User-Agent': 'HTTPie/1.0.0-dev', 'X-Amzn-Trace-Id': 'Root=1-5f741e1d-46d7a890a9b138c30135d7b8'}
    str_1 = 'sessions/httpbin.org/always'
    session_0 = Session(str_1)
    headers_1 = RequestHeadersDict(headers_0)
    session_0.update_headers(headers_1)

# Generated at 2022-06-25 19:26:30.357772
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    Session_test = Session('')
    headers = RequestHeadersDict({'header': 'value'})
    Session_test.update_headers(headers)


# Generated at 2022-06-25 19:26:35.032838
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('')
    cookies_0 = session_0.cookies
    remove_cookies_0 = session_0.remove_cookies
    names_0 = int()
    remove_cookies_0(names_0)


# Generated at 2022-06-25 19:26:41.515356
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_1 = Session("test_session.json")
    session_1.update_headers({"Accept": "application/json", "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "en-US,en;q=0.8", "Connection": "keep-alive", "Host": "httpbin.org"})
    assert session_1.headers == {"Accept": "application/json", "Accept-Language": "en-US,en;q=0.8"}


# Generated at 2022-06-25 19:26:43.694906
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert True
    # session = Session('session path')
    # names = 
    # session.remove_cookies(names)

# Generated at 2022-06-25 19:26:46.198232
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    _headers = RequestHeadersDict({'content-type': 'application/json'})
    _headers.clear()
    if 'content-type' in _headers:
        raise AssertionError("'content-type' in _headers")


# Generated at 2022-06-25 19:26:53.513620
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    name_0 = '+uPP,'
    jar_0 = 'Yt8_F3L'
    session_0 = Session(name_0)
    name_1 = 'GOdhH+'
    jar_1 = 'Bv+A,='
    session_1 = Session(name_1)
    name_2 = '>U8^6r'
    jar_2 = 'oi@h$+'
    session_2 = Session(name_2)

    session_2.remove_cookies({jar_2})


# Generated at 2022-06-25 19:27:11.753809
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # first, create some session
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    # fix a name
    name_0 = '&'
    # remove it (shouldn't do anything)
    session_0.remove_cookies([name_0])
    # fix a name
    name_0 = 'x'
    # remove it (shouldn't do anything)
    session_0.remove_cookies([name_0])
    # fix a name
    name_0 = 'o'
    # remove it (shouldn't do anything)
    session_0.remove_cookies([name_0])
    # fix a name
    name_0 = 'R'
    # remove it (shouldn't do anything)


# Generated at 2022-06-25 19:27:13.736484
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    Test_Session_remove_cookies = Session("")
    Test_Session_remove_cookies.remove_cookies(['name'])


# Generated at 2022-06-25 19:27:20.845152
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    list_0 = ['YxF>*&Ka-W&eRo{fQP!7']
    assert not session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:27:30.251005
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)

    dict_0 = {}
    str_1 = 'k7g@,'
    dict_0['type'] = str_1

    str_2 = 'SOLm'
    dict_0['raw_auth'] = str_2

    session_0.auth = dict_0

    dict_1 = {}
    dict_1['type'] = str_2

    dict_1['username'] = str_2

    dict_1['password'] = str_1

    session_0.auth['auth'] = dict_1

    session_0.auth['auth'] = dict_0

    dict_2 = {}
    dict_2['type'] = str_1

    dict_2

# Generated at 2022-06-25 19:27:40.308699
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    Test_Cookies = RequestsCookieJar()
    create_cookie('cookie1','cookie1')
    Test_Cookies.set_cookie(create_cookie('cookie2','cookie2'))
    Test_Cookies.set_cookie(create_cookie('cookie3','cookie3'))
    # Test 1: Check that no exception is raised when non-existent cookie is removed
    try:
        session_0.remove_cookies(["cookie1"])
    except:
        exception_raised_0 = True
    else:
        exception_raised_0 = False
    assert exception_raised_0 == False
    # Test 2: Check correct removal of cookie
    Test_Cookies.set_cookie(create_cookie('cookie2','cookie2'))
    session_0.cookies = Test_Cookies
    session_0.remove_cookies

# Generated at 2022-06-25 19:27:42.219557
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('s') 
    session.remove_cookies(['c1', 'c2'])

# Generated at 2022-06-25 19:27:47.046437
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('default')
    names = ['http://example.com', 'test']
    assert session_0.remove_cookies(names) == session_0

    session_0 = Session('default')
    names = []
    assert session_0.remove_cookies(names) == session_0



# Generated at 2022-06-25 19:27:55.710955
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie = 'cookie'
    cookie_0 = 'cookie_0'
    cookie_1 = 'cookie_1'
    cookie_2 = 'cookie_2'
    cookie_3 = 'cookie_3'
    cookie_4 = 'cookie_4'
    cookie_5 = 'cookie_5'
    cookie_6 = 'cookie_6'
    cookie_7 = 'cookie_7'
    cookie_8 = 'cookie_8'
    cookie_9 = 'cookie_9'
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    str_1 = './httpie_session_test.py'

# Generated at 2022-06-25 19:27:58.293941
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)


# Generated at 2022-06-25 19:28:05.268883
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    str_1 = 'YxF>*&Ka-W&eRo{fQP!7'
    str_2 = 'YxF>*&Ka-W&eRo{fQP!7'
    str_3 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    session_0.remove_cookies(str_1)


# Generated at 2022-06-25 19:28:26.493102
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('edit')
    session_remove_cookies = session.remove_cookies
    session_remove_cookies(['x-wsse', 'x-twilio-signature'])
    assert session_remove_cookies(
        ['x-wsse', 'x-twilio-signature']) == None


# Generated at 2022-06-25 19:28:33.425983
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(str_0)

# Generated at 2022-06-25 19:28:36.615945
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/home/thai/httpie/tests/sessions/session_cookies_test')
    session.load()
    session.remove_cookies(['test-cookie'])
    assert 'test-cookie' not in session['cookies']

# Generated at 2022-06-25 19:28:38.917709
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_case_0()
    test_case_1()

test_case_0()

test_case_1()


# Generated at 2022-06-25 19:28:43.322792
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'Qb]qH<XQQ'
    session_0 = Session(str_0)
    list_0 = ['N', 'N', '9<jn8aM{', '', '>n', 'tGv', 'z=w', '', 'tG2']
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:28:52.895753
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    str_1 = 'y=6u8Q6U*&6u&c%rZFfn1'
    str_2 = '#`1D<a}$"aP`<(Y{@i\'~'
    str_3 = 'A;1Fk]T=Tc%H2"&t!I^t'
    str_4 = 'x>1s@s;s|p<f_wv!bm~h'
    str_5 = 'X874@Z2?\\a$7hsOq:6UV'
    str_6 = 'B7`U2F6X8rDFNxN{C5h5'

# Generated at 2022-06-25 19:28:57.852227
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    v0 = None
    v1 = []
    v2 = 'q'
    session_0 = Session.__new__(Session)
    session_0.remove_cookies(v0, v1, v2)
    v0_1 = None
    v1_1 = []
    v2_1 = 'q'
    session_0.remove_cookies(v0_1, v1_1, v2_1)



# Generated at 2022-06-25 19:29:08.167392
# Unit test for method remove_cookies of class Session

# Generated at 2022-06-25 19:29:14.164107
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    session_0.load()
    session_0.remove_cookies(["a","aaaaaa"])
    assert session_0.get('cookies') == {}


# Generated at 2022-06-25 19:29:17.045003
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    list_0 = []
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:29:54.276559
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test that a cookie is deleted when needed
    #   Arrange
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)
    session_0['cookies'] = {'one':'two','three':'four','five':'six'}
    test_cookies = ['one','three']
    #   Act
    session_0.remove_cookies(test_cookies)
    #   Assert
    assert session_0['cookies'] == {'five':'six'}


# Generated at 2022-06-25 19:29:57.883610
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('HTTPie-Session-user1')
    assert session.remove_cookies(['SSID', 'guid']) == None


# Generated at 2022-06-25 19:30:06.093638
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'Zc%^KdQ)|O],9GgHS-l*'
    session_0 = Session(str_0)
    str_1 = 'Pu*]X:,b<|vx>xNw-@2E'
    str_2 = 'r1Z._h*Ee7Xn(R^uV7gj'
    list_0 = [str_1, str_2]
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:30:09.751295
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '<lCj0Aey-o@,}Ji/"=b%j'
    session_0 = Session(str_0)
    names_0 = [
                   'z6f-L8Ex&', '_hU6*{U>M', '8T%h*w_,:', 'S-%dW8~}*', 'X9[mv4Q4G'
           ]
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:30:11.798661
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s_cookie = Session('test_cookie')
    s_cookie['cookies']['1'] = 1
    assert '1' in s_cookie['cookies']
    s_cookie.remove_cookies(['1'])
    assert '1' not in s_cookie['cookies']


# Generated at 2022-06-25 19:30:22.042525
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'dQ2{W8_vw&qpA[,O(g'
    session_0 = Session(str_0)
    session_0.load()

# Generated at 2022-06-25 19:30:33.066254
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'YxF>*&Ka-W&eRo{fQP!7'
    session_0 = Session(str_0)

    names_0 = ['vpFo)P']
    names_1 = ['k$Yp@}']
    names_2 = ['k$Yp@}', 'Dh;le']
    names_3 = ['vpFo)P']
    names_4 = ['Dh;le']
    names_5 = ['vpFo)P']

    session_0.remove_cookies(names_0)
    session_0.remove_cookies(names_1)
    session_0.remove_cookies(names_2)
    session_0.remove_cookies(names_3)
    session_0.remove_cookies(names_4)
   

# Generated at 2022-06-25 19:30:37.429001
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'q3j}l9^[(Z8Rb109!2'
    str_1 = '~Y;1^'
    str_2 = 'D{a[N*8WbQP'
    session_0 = Session(str_0)
    session_0.remove_cookies([str_1])
    session_0.remove_cookies([str_2])


# Generated at 2022-06-25 19:30:44.797460
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '7Vn/eBBS'
    session_0 = Session(str_0)
    str_1 = '@G^y*p6btTWsR]u-L*'
    session_1 = Session(str_1)
    # Clear cookies
    session_1.remove_cookies([])
    # Clear cookies
    session_0.remove_cookies('')
