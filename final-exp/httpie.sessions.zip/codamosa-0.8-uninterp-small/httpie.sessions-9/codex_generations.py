

# Generated at 2022-06-25 19:21:05.415080
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'b3QB4gc(S'
    dict_0 = {
        'param1': 'val1',
        'param2': 'val2-val3',
        'param3': 'val4=val5',
    }
    request_headers_0 = RequestHeadersDict(dict_0)
    session_0 = Session(str_0)
    req_headers_0 = session_0.update_headers(request_headers_0)
    assert {'param1': 'val1', 'param3': 'val4=val5', 'param2': 'val2-val3'} == session_0['headers']
    assert req_headers_0 == {'param1': 'val1', 'param3': 'val4=val5', 'param2': 'val2-val3'}
# END Unit

# Generated at 2022-06-25 19:21:16.188296
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    expected_0 = {}
    expected_1 = {}
    expected_2 = {'Content-Type': 'application/json'}
    expected_3 = {'Content-Type': 'application/json'}
    expected_4 = {'Content-Type': 'application/json', 'Authorization': 'Basic c3VwZXI6cGFzcw==', 'Host': '127.0.0.1:5000'}
    expected_5 = {'Content-Type': 'application/json', 'Authorization': 'Basic c3VwZXI6cGFzcw==', 'Host': '127.0.0.1:5000', 'Content-Length': '5'}

# Generated at 2022-06-25 19:21:23.323440
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'b3QB4gc(S'
    session_0 = Session(str_0)
    str_1 = 'X9YhZ(g|E'
    str_2 = 'lNy|+-O%)'
    dict_0 = {str_1: str_2}
    class_0 = RequestHeadersDict(dict_0)
    session_0.update_headers(class_0)


# Generated at 2022-06-25 19:21:29.492469
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '7rt:t,jb'
    Path_0 = Path(str_0)
    str_1 = 'iG!#c%B@j'
    RequestHeadersDict_0 = RequestHeadersDict(str_1)
    Session_0 = Session(Path_0)
    Session_0.update_headers(RequestHeadersDict_0)
    assert Path_0 == Path(str_0)


# Generated at 2022-06-25 19:21:38.486435
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'b3QB4gc(S'
    session_0 = Session(str_0)
    json_0 = simplejson.loads('{"a": {"b": "c"}}')
    session_0.update_cookies(json_0)
    json_1 = simplejson.loads('{"c": {"d": "e"}}')
    session_0.update_cookies(json_1)
    raw_1 = session_0.cookies.items()
    print()
    pprint.pprint(raw_1)
    print()


# Generated at 2022-06-25 19:21:45.470100
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_1 = '/directory/directory/directory'
    session_2 = Session(path_1)
    path_3 = '/directory/'
    session_4 = Session(path_3)
    session_5 = Session('wAVf1')
    str_6 = 'J9X!x^*'
    session_7 = Session(str_6)
    session_8 = Session('EbW')
    session_9 = Session('tE')
    session_10 = Session('-L')
    str_11 = 'KQ4u'
    session_12 = Session(str_11)
    session_13 = Session('K3')
    session_14 = Session('6l')
    session_15 = Session('yv')
    session_16 = Session('8E')
    session_17 = Session('zm')

# Generated at 2022-06-25 19:21:55.414463
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_Session_update_headers')

    test_dict = {'a': None, 'b': '1', 'c': '2', 'Content-Length': '3'}
    session.update_headers(test_dict)
    assert test_dict == session.headers
    assert session['headers'] == {'b': '1', 'c': '2'}

    session.update_headers({'d': '4', 'User-Agent': 'HTTPie/1.0.2',
                            'Content-Type': '5'})
    assert {'b': '1', 'c': '2', 'd': '4'} == session.headers
    assert session['headers'] == {'b': '1', 'c': '2', 'd': '4'}


# Generated at 2022-06-25 19:21:59.372173
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session: Session = Session('')
    rd: RequestHeadersDict = {'hello': 'world'}
    session.update_headers(rd)
    assert session['headers'] == rd

# Generated at 2022-06-25 19:22:01.594021
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_1 = Session('d2QW84ZJl')
    session_1.update_headers(None)


# Generated at 2022-06-25 19:22:04.419397
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(
        '~/sessions/localhost/httpie-unixsocket.json')
    session_0.remove_cookies('SESSION')


# Generated at 2022-06-25 19:22:13.028755
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    body_0 = Session('Y9ZdoW@')
    body_0.update_headers({'jKaz54u': 'VJHrp+', 'VfP1': ''})



# Generated at 2022-06-25 19:22:16.309906
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_dict_0 = dict()
    session_0 = Session('.')
    session_0.update_headers(headers_dict_0)
    assert session_0._modified == True


# Generated at 2022-06-25 19:22:21.248139
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # initialising the session
    path = Path(__file__)
    session = Session(path)

    # initialising the request
    # https://httpie.org/doc#sessions
    request_headers = {'content-type': 'application/json'}

    # calling the function
    session.update_headers(request_headers)

    # Checking the result
    if session['headers']['content-type']:
        assert 1
    else:
        assert 0

# Generated at 2022-06-25 19:22:23.792657
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'q&=v6NhU2'
    session_0 = Session(str_0)
    session_0.update_headers(session_0['headers'])


# Generated at 2022-06-25 19:22:25.698485
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('jPGL-H')


# Generated at 2022-06-25 19:22:34.610344
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print('Test for method update_headers of class Session')
    session_0 = Session('b3QB4gc(S')
    str_0 = 'Q[[N|'
    request_headers_0 = RequestHeadersDict(str_0)
    # Call method Session.update_headers with request_headers_0 as the argument. Store the result in session_0
    try:
        session_0.update_headers(request_headers_0)
    except TypeError:
        print(r'[error] The mthod has a return value, but you did\'t save it.')
    print('[result] The method run successfully.')

# Generated at 2022-06-25 19:22:43.541939
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'b3QB4gc(S'
    session_0 = Session(str_0)
    str_1 = ''.join(reversed('context'))
    list_0 = ['context', str_1, 'context']
    session_0.remove_cookies(list_0)
    str_2 = '&]d?#M!((tEX,'
    str_3 = 'F\'0k]Nxz\\'
    dict_0 = {str_2: 'context', str_3: 'context'}
    session_0.remove_cookies(dict_0)
    str_4 = 'P@`8W`7X'
    dict_1 = {str_4: 'context'}
    session_0.remove_cookies(dict_1)

# Generated at 2022-06-25 19:22:45.995232
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class_0 = Session('S5Z5QRN')
    class_0.update_headers(dict())


# Generated at 2022-06-25 19:22:52.437559
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # These two assertions are only for static checks.
    # The actual tests are found in the second test case.
    assert type(Session('').remove_cookies(('',))) is None
    assert type(Session.remove_cookies) is type
    try:
        Session('test_Session_remove_cookies').remove_cookies(('',))
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 19:22:56.364517
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'a'
    session_0 = Session(str_0)
    str_1 = 'b'
    dict_0 = {str_1: str_1}
    session_0.update_headers(dict_0)


# Generated at 2022-06-25 19:23:11.080486
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    print('Testing remove_cookies ...', end='')
    session = Session('test.txt')
    session['cookies'] = {
        'a': {},
        'b': {},
        'c': {},
    }

    session.remove_cookies(['a', 'b', 'c'])
    assert session['cookies'] == {}
    session['cookies'] = {
        'a': {},
        'b': {},
        'c': {},
    }
    session.remove_cookies(['a', 'd', 'c'])
    assert session['cookies'] == {
        'a': {},
        'c': {},
    }
    session.remove_cookies(['a'])
    assert session['cookies'] == {
        'c': {},
    }


# Generated at 2022-06-25 19:23:20.996677
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.config import RequestConfig
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from requests.auth import AuthBase
    import requests
    import requests.exceptions
    import requests.sessions
    import requests.structures
    import typing
    import urllib3.request

    class Response:
        """The :class:`Response <Response>` object, which contains a
        server's response to an HTTP request.
        """

        def __init__(self):
            self.status_code = None
            self.headers = None
            self.encoding = None
            self.raw = None

    class SessionRedirectMixin:
        """Provides facilities for controlling redirections."""


# Generated at 2022-06-25 19:23:23.925313
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_1 = Session("/home/jm/.config/httpie/sessions/jm_github_com.json")
    session_1.update_headers("jm")


# Generated at 2022-06-25 19:23:29.575838
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    case_0 = 'User-Agent -> Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:73.0) Gecko/20100101 Firefox/73.0'
    case_1 = 'User-Agent -> Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:73.0) Gecko/20100101 Firefox/73.0'
    session_0 = Session('session_0')
    session_0.update_headers(case_0)
    assert session_0.headers == case_1


# Generated at 2022-06-25 19:23:33.645976
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    Path_str = 'XWsohJsKj'
    str_0 = 'i1tHpMt.L'
    session_0 = Session(Path_str)
    list_0 = [str_0]
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:23:43.052467
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    test_cases = [
        # (input1, input2, expected)
        ([('x-A', '1'), ('X-B', '2'), ('X-C', '3')], [('x-a', '1'), ('x-d', '4'), ('x-b', '2'), ('x-c', '3')]),
    ]

    for test_case in test_cases:
        test_input1 = test_case[0]
        test_input2 = test_case[1]
        test_expected = test_case[2]
        print('Input')
        print(test_input1)
        print(test_input2)
        session_0 = Session(test_input1)
        session_0.update_headers(test_input2)
        assert session_0.headers == test_expected

#

# Generated at 2022-06-25 19:23:53.129489
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = 'b3QB4gc(S'
    session_1 = Session(path_0)

# Generated at 2022-06-25 19:24:00.660071
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # session_0 = Session(Path('config_dir') / 'sessions_dir' / 'host' / str('name.json'))
    path_0 = Path('config_dir')
    session_0 = get_httpie_session(path_0, 'name.json', 'host', '')
    headers_0 = RequestHeadersDict([])
    session_0.update_headers(headers_0)
    assert headers_0 == headers_0


# Generated at 2022-06-25 19:24:04.545419
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'b3QB4gc(S'
    session_0 = Session(str_0)
    headers_0 = {}
    session_0.update_headers(headers_0)
    int_0 = 1
    assert session_0['cookies'] == int_0


# Generated at 2022-06-25 19:24:10.446246
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'M(]S<tXq}'
    p_0 = Path(str_0)
    session_0 = Session(p_0)
    str_1 = '{,O'
    l_0 = [str_1, str_0]
    session_0.remove_cookies(l_0)


# Generated at 2022-06-25 19:24:18.013219
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    name = 'unit-test'
    cookies = {'cookie1': 'value1', 'cookie2': 'value2'}

    session = Session(name)
    session['cookies'] = cookies

    names = ['cookie1']
    session.remove_cookies(names)

    del cookies['cookie1']
    assert session['cookies'] == cookies

# Generated at 2022-06-25 19:24:19.152617
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('.httpie')
    session.update_headers()


# Generated at 2022-06-25 19:24:23.633912
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # session_0
    str_0 = 'b3QB4gc(S'
    session_0 = Session(str_0)
    # names_0
    names_0 = []


# Generated at 2022-06-25 19:24:31.616096
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    cookies = {}
    for cookie in ['pN6E4FzfC', 'lFCXf', 'UZjIuZ', '3V7', 'A0m0V7', '?5q3v']:
        cookies.update({cookie: cookie})
    session_0 = Session(cookies)
    session_1 = Session(cookies)
    session_1.update_headers(session_0)

# Generated at 2022-06-25 19:24:41.382895
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = 'sessions'
    path_1 = 'sessions/httpbin.org'
    path_2 = 'sessions/httpbin.org/test'
    path_3 = 'sessions/httpbin.org/test'
    path_4 = 'sessions/httpbin.org/test.json'
    session_0 = Session(path_4)
    try:
        cookies_0 = {}
        session_0.cookies = cookies_0
    except Exception as e:
        print(e)

    try:
        names_0 = []
        session_0.remove_cookies(names_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 19:24:45.386558
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'u0E-R6-FtpVJ'
    path_0 = (str_0).lower()
    session_0 = Session(path_0)
    str_1 = 'r{z(b'
    request_headers_0 = RequestHeadersDict(str_1)
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:24:48.991845
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    list_0 = ['Ny#', 'F,{', '0:K', 'h8[', 'dKv', 'I;n', 'Sp,', 'yC(']
    dict_0 = dict()
    for str_0 in list_0:
        dict_0[str_0] = str_0
    session_0 = Session(dict_0)
    for str_0 in list_0:
        session_0.remove_cookies(list_0)

# Generated at 2022-06-25 19:24:56.094869
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    jar = RequestsCookieJar()
    jar.set('name1', 'value1', path='/', secure=True, expires=123)
    jar.set('name2', 'value2', path='/')
    session = Session('name')
    session.cookies = jar
    session.remove_cookies(['name2'])
    print(session.cookies)
    #assert session.cookies == jar




# Generated at 2022-06-25 19:24:58.092524
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'L:j_'
    session_0 = Session(str_0)
    session_0.update_headers('1g,B')

# Generated at 2022-06-25 19:25:01.670753
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '<P$9A=,R'
    session_0 = Session(str_0)
    session_0.remove_cookies([])


# Generated at 2022-06-25 19:25:11.778519
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Assert that the first header received is not ignored after the second header is received
    str_0 = 'b3QB4gc(S'
    session_0 = Session(str_0)
    dct_0 = {}
    dct_0['Cookie'] = ' = '.join(['Content-Type', 'application/json'])
    dct_1 = {}
    dct_1['Cookie'] = ' = '.join(['Connection', 'Keep-Alive'])
    session_0.update_headers(dct_0)
    session_0.update_headers(dct_1)
    assert session_0.headers == dct_0


# Generated at 2022-06-25 19:25:17.001095
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'wF1zcqZOd'
    session_0 = Session(str_0)
    session_0.load()
    # self.remove_cookies(names)
    str_1 = 'AnC.r9G2f'
    int_0 = -10
    names = [str_1, int_0]
    session_0.remove_cookies(names)



# Generated at 2022-06-25 19:25:19.528165
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = "HGKVA$A0wY"
    session_0 = Session(path_0)
    session_0.update_headers("<Mzb6K@UWwS8")


# Generated at 2022-06-25 19:25:23.431200
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('test.json')
    session_0.remove_cookies(list())


if __name__ == '__main__':
    test_case_0()
    test_Session_remove_cookies()

# Generated at 2022-06-25 19:25:28.541899
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    # Setup
    session = {}
    session['cookies'] = {
        'foo': 'foo',
        'bar': 'bar'
    }
    names = ['foo']
    # Exercise
    session.remove_cookies(names)
    # Verify
    actual = session['cookies']
    expected = {
        'bar': 'bar'
    }
    assert actual == expected, 'Test failed!'

# Generated at 2022-06-25 19:25:37.415280
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # <https://github.com/psf/black/pull/2269>
    from . import explain_traceback
    from .utils import (
        get_response_data,
        get_response_download_filename,
        get_response_text,
        get_response_type,
        write_file_bytes,
        write_file_str,
        FileWriteError,
    )
    command = 'http --session=https://github.com/psf/black/pull/2269'
    command += ' --download'

# Generated at 2022-06-25 19:25:43.809884
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(os.path.sep)
    session_0.cookies = RequestsCookieJar()
    # Form name_0
    str_0 = 'x-z.fZ`}1'
    # Form name_1
    str_1 = '6NhUw*>'
    # Form name_2
    str_2 = 'i9{=v>D7M'
    # Form name_3
    str_3 = 'jW8G~]i#'
    # Form name_4
    str_4 = '@2,#x+zZ'
    # Form name_5
    str_5 = '~6Uf[6|'
    # Form name_6
    str_6 = '&:a1*A'
    # Form name_7
    str_

# Generated at 2022-06-25 19:25:53.995896
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('OoIA:9X')
    session_0._content = [
        '\x1b~r\x15_',
        'z(*\x7fZ',
        'Q7\x1e\x1d\x17\x16',
        '\x1d\x07\x18\x09\x04\x0e\x17\x12\x1c\x1d']
    session_0._content_length = 11
    session_0.__init__('qu\x1c\x12\x11\x1e\x19\x13\x01\x10\x0c\x1b')
    request_headers = {'X-Amz-Algorithm': 'AWS4-HMAC-SHA256'}
    session_0.update_

# Generated at 2022-06-25 19:25:57.587089
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '_ubl_o+'
    session_0 = Session(str_0)
    request_headers_0 = {}
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:26:01.755072
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'b3QB4gc(S'
    list_0 = ['!sDNg']
    session_0 = Session(str_0)
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:26:19.374702
# Unit test for method remove_cookies of class Session

# Generated at 2022-06-25 19:26:24.083271
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '/sessions/'
    path_0 = Path(str_0)
    str_1 = 'str_1'
    str_2 = 'str_2'
    list_0 = ['str_0', 'str_1', 'str_2']
    dict_0 = dict(zip(list_0, list_0))
    request_headers_dict_0 = RequestHeadersDict(dict_0)
    str_3 = 'netloc'
    str_4 = 'scheme'
    str_5 = 'host'
    str_6 = 'port'
    str_7 = 'username'
    str_8 = 'password'
    str_9 = 'path'
    str_10 = 'query'
    str_11 = 'fragment'

# Generated at 2022-06-25 19:26:25.803377
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '2@(j%I/'
    session_0 = Session(str_0)
    session_0.update_headers({})


# Generated at 2022-06-25 19:26:36.525182
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = ':=H'
    dict_0 = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8'}
    path_0 = Path('C:/Users/BenD/.httpie/sessions')
    dict_1 = {'password': None, 'username': None, 'type': None}
    dict_2 = {'password': '', 'username': '', 'type': 'Basic'}
    dict_3 = {'password': None, 'username': '', 'type': None}
    dict_4 = {'password': '', 'username': None, 'type': 'Basic'}

# Generated at 2022-06-25 19:26:45.904167
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session_0 = Session('O#')
    request_headers_0 = {
        'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'br, gzip, deflate',
        'Connection': 'keep-alive',
        'Cookie': 'abcdef=123456; foo=bar; qwerty=uiop'
    }
    session_0.update_headers(request_headers_0)



# Generated at 2022-06-25 19:26:54.829411
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('test_Session_0.json')
    str_0 = 'test_Session_1.json'
    session_0 = Session(str_0)

    # Test for SESSION_IGNORED_HEADER_PREFIXES
    str_1 = 'https://twitter.com/'
    session_0.update_headers({'Host': str_1})
    str_1 = 'test_Session_2.json'
    session_1 = Session(str_1)
    str_2 = 'Host'
    session_1.update_headers({str_2: 'test_Session_3.json'})
    str_3 = 'test_Session_4.json'
    str_4 = 'Host'
    str_5 = 'test_Session_5.json'
    session_1.update_headers

# Generated at 2022-06-25 19:26:59.146548
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '8f }W#`l'
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict({})
    headers_0 = session_0.headers
    # pass
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:27:06.023380
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'o@g2aSK8'
    session_0 = Session(str_0)
    str_1 = 'v181Zs(s'
    requests_headers_dict_0 = RequestHeadersDict.from_str(str_1)
    session_0.update_headers(requests_headers_dict_0)
    str_2 = 'CUi3;r5U'
    session_1 = Session(str_2)
    str_3 = '6@yxU-:8'
    requests_headers_dict_1 = RequestHeadersDict.from_str(str_3)
    session_1.update_headers(requests_headers_dict_1)
    str_4 = 'R}#U6`lU'
    session_2 = Session(str_4)
    str

# Generated at 2022-06-25 19:27:10.473075
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # session_1 = Session(str_1)
    assert 1 == 0


# Generated at 2022-06-25 19:27:18.507615
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from http.cookies import SimpleCookie
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    from httpie import output
    from httpie.output.formats import JSON, JSONLines
    from httpie import client, context
    from httpie import __version__ as HTTPIE_VERSION
    from httpie.compat import urljoin
    from httpie.downloads import (
        parse_content_range, filename_from_content_disposition, filename_from_url,
        get_unique_filename, ContentRangeError, Downloader,
    )
    from httpie.plugins import AuthPlugin, plugin_manager
    from httpie.models import Environment
    import json
    import os
    import pytest
    from tempfile import gettempdir

# Generated at 2022-06-25 19:27:29.691125
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'zkKj:o@'
    session_0 = Session(str_0)
    list_0 = ['Z.e'*8, 'zF:2'*8, 'i'*10, 'lx'*8]
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:27:36.545333
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session("X9q3Dd7p")
    list_0 = ["xIJ3C6F5U", "WOa8ikv6y", "QNjO6JWl", "71v6Zf", "eA(0Y1Dz8", "4XkJdbf1m", "wS0Bx", "c6Fq3KR", "U6zWUJ9", "g2fkAPR"]
    session_0.remove_cookies(list_0)

# unit test for method cookies of class Session

# Generated at 2022-06-25 19:27:43.829906
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.compat import is_windows

    if is_windows:
        name_0 = 'C:\\dir_3\\dir_4\\dir_7\\dir_1\\dir_7'
    else:
        name_0 = '/home/alexandra/tabs/dir_3/dir_3/dir_2/dir_7'

    session_0 = Session(name_0)
    list_0 = []
    # Asserts that session_0.remove_cookies(list_0) raises TypeError
    try:
        session_0.remove_cookies(list_0)
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError not raised.'


# Generated at 2022-06-25 19:27:48.164726
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'yJ>gP+XpD|]tqdJ5Z*'
    session_0 = Session(str_0)
    str_1 = 'S+F)o*PZ'
    list_0 = ['S+F)o*PZ']
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:27:56.901693
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    print('Test for method remove_cookies in class Session')


# Generated at 2022-06-25 19:28:01.909472
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'Rv*(W)K8GQ'
    name_0 = 'jK%cF8b!(T'
    names_0 = [name_0]
    session_0 = Session(str_0)
    session_1 = Session(str_0)
    session_1.remove_cookies(names_0)


# Generated at 2022-06-25 19:28:05.542563
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'b3QB4gc(S'
    session_0 = Session(str_0)
    str_1 = 'q3q&l)]]'
    list_0 = [str_1]
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:28:08.841525
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'ldFfmQh$-n'
    session_0 = Session(str_0)
    Iterable_0 = ['z', 'r', '%', 'h']
    session_0.remove_cookies(Iterable_0)


# Generated at 2022-06-25 19:28:19.895548
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session')
    cookie = create_cookie('test', 'value')
    cookie.expires = 1000
    session['cookies'] = {'test': cookie}
    assert len(session['cookies']) == 1
    session.remove_cookies(['test'])
    assert len(session['cookies']) == 0
    session['cookies'] = {'test': cookie}
    assert len(session['cookies']) == 1
    session.remove_cookies([])
    assert len(session['cookies']) == 1
    session.remove_cookies(['test2'])
    assert len(session['cookies']) == 1
    session['cookies'] = {'test': cookie, 'test2': cookie}
    assert len(session['cookies']) == 2

#

# Generated at 2022-06-25 19:28:24.978086
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'W^*v/C[%X'
    session_0 = Session(str_0)
    assert session_0
    names = ['Jf,6F.0', 'Jf,6F.0', '.I=`:a', 'Jf,6F.0', '.I=`:a', 'C#Ld?j^']
    session_0.remove_cookies(names)


# Generated at 2022-06-25 19:28:42.688873
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    args = ['b3QB4gc(S', ['hgdD9XW$y', 'hgdD9XW$y']]
    if args[1] is None:
        assert False
    else:
        session_0 = Session(args[0])
        session_0.remove_cookies(args[1])


# Generated at 2022-06-25 19:28:52.348859
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # test object with initial values
    obj = Session('g')

# Generated at 2022-06-25 19:28:58.479223
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test_session")
    cookies = {
        'test_cookie': {
            'value': 'something'
        },
        'second_cookie': {
            'value': 'something'
        },
        'third_cookie': {
            'value': 'something'
        }
    }
    session['cookies'] = cookies
    session.remove_cookies(['test_cookie', 'second_cookie'])
    assert len(session['cookies']) == 1
    assert session['cookies'].get('third_cookie') != None


# Generated at 2022-06-25 19:29:05.009441
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('x')
    session['cookies'] = {'a': 'b', 'c': 'd'}

    # Normal
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}
    session.remove_cookies(['c'])
    assert session['cookies'] == {}

    # Nothing to remove
    session['cookies'] = {'x': 'y'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'x': 'y'}



# Generated at 2022-06-25 19:29:16.775401
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    param_0 = '=thS'
    param_1 = 'j4h'
    param_2 = 'l9'
    param_3 = 'fjc'
    param_4 = 'Dd5'
    param_5 = 'ZgJ'
    param_6 = 't'
    param_7 = 'vaJr2'
    param_8 = 'Z'
    param_9 = 'G'
    param_10 = '3'
    param_11 = 'cIj'
    param_12 = 'R'
    param_13 = 'r'
    param_14 = 'I'
    param_15 = 't'
    param_16 = 'c'
    param_17 = '1'
    param_18 = 'D'
    session_0 = Session(param_0)
    session

# Generated at 2022-06-25 19:29:18.464695
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(0)
    # TODO: fix this
    # str_0 = 'b3QB4gc(S'
    # str_1 = session_0.remove_cookies([str_0])


# Generated at 2022-06-25 19:29:28.735255
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '$'
    str_1 = 'W2,*'
    str_2 = 'z@-^yQ>O'
    # session_0 = Session(str_0)
    # session_1 = Session(str_1)
    # session_2 = Session(str_2)
    str_3 = '&n6UYX6#\'d}n'
    str_4 = 'H?M-39%6(`'
    # session_3 = Session(str_3)
    # session_4 = Session(str_4)
    # session_5 = Session(str_5)
    # session_6 = Session(str_6)
    # session_7 = Session(str_7)
    # session_8 = Session(str_8)
    # session_9 = Session(

# Generated at 2022-06-25 19:29:30.402671
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'b3QB4gc(S'
    session_0 = Session(str_0)


# Generated at 2022-06-25 19:29:36.344214
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    x = Session('n/a')
    x['cookies'] = {'name': {'value': 'a'}, 'name1': {'value': 'a1'}, 'name2': {'value': 'a2'}, 'name3': {'value': 'a3'}}
    x.remove_cookies(['name1'])
    assert x['cookies'] == {'name':{'value':'a'}, 'name2': {'value': 'a2'}, 'name3': {'value': 'a3'}}

# Generated at 2022-06-25 19:29:38.277264
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_1 = Session(str)
    session_1.remove_cookies(str)


# Generated at 2022-06-25 19:30:11.648344
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(None)

    # try-except-finally block to handle exceptions and resource clean-up
    try:
        # block
        test_Session_remove_cookies_block_0(session_0)
    except Exception as e:
        if True:
            raise e
    finally:
        pass

# Unit test from Session.remove_cookies
#

# Generated at 2022-06-25 19:30:15.486684
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'b3QB4gc(S'
    session_0 = Session(str_0)
    str_1 = '9'
    set_0 = {str_1}
    session_0.remove_cookies(set_0)


# Generated at 2022-06-25 19:30:19.685682
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = 'gk~l_/WB_+:#nN'
    session_0 = Session(path_0)
    str_0 = 'C.4'
    list_0 = [str_0]
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:30:30.872991
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'rKrRbY1G'
    session_0 = Session(str_0)
    list_0 = ['vJ8)S,0^', 'TKq3J=v^', 'U4R6]`yL', 'v,Nd^A,O', 'jN0Zz>!e']
    session_0.remove_cookies(list_0)
    list_1 = ['L^|>!!', 'Mx?vX8b', '<y_Sn2', 'a)wvS8W']
    session_0.remove_cookies(list_1)

# Generated at 2022-06-25 19:30:32.933900
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session("/u/s")
    session_0.remove_cookies("f0w")


# Generated at 2022-06-25 19:30:40.011610
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'b3QB4gc(S'
    session_0 = Session(str_0)

# Generated at 2022-06-25 19:30:42.449260
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(str_0)
    session_0.remove_cookies((str_1,))
