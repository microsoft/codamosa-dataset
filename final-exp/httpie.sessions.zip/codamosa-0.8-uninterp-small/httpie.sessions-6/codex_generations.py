

# Generated at 2022-06-25 19:21:02.350309
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    dict_0 = {'username': None, 'password': None, 'type': None}
    cookies_0 = None
    headers_0 = None
    path_0 = None
    session_0 = Session(path_0)
    session_0.headers = headers_0
    session_0.cookies = cookies_0
    session_0.auth = dict_0
    request_headers_0 = None
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:21:13.717893
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli import RequestHeadersDict
    from httpie.config import merge_extra_headers
    config_dir_0 = os.path.dirname(os.path.dirname(__file__))
    config_dir_0 = os.path.join(config_dir_0, *("utils", "test", 'fixtures', 'config', 'user'))
    config_dir_0 = os.path.abspath(config_dir_0)
    config_dir_0 = pathlib.Path(config_dir_0)
    session_name_0 = 'httpbin_net'
    host_0 = None
    url_0 = 'https://httpbin.net'
    session_0 = get_httpie_session(config_dir_0, session_name_0, host_0, url_0)


# Generated at 2022-06-25 19:21:16.747590
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    dict_0 = None
    path_0 = module_0.Path(**dict_0)
    session_0 = Session(path_0)
    list_0 = [session_0]
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:21:25.562349
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    dict_0 = {'auth': {'password': None, 'type': None, 'username': None}, 'headers': {}, 'cookies': {'cookie_0': {'path': None, 'secure': True, 'expires': None, 'value': 'value_0'}}}
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    session_0 = dict(session_0, **dict_0)
    names_0 = [None]
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:21:37.457357
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    dict_0 = {'name': 'name-0'}
    path_0 = module_0.Path(**dict_0)
    session_0 = Session(path_0)
    dict_1 = {'name': 'name-1'}
    dict_0.update(dict_1)
    path_0 = module_0.Path(**dict_0)
    names_0 = path_0
    session_0.remove_cookies(**names_0)
    dict_1 = {'name': 'name-2', 'type': 'type-0'}
    dict_0.update(dict_1)
    path_0 = module_0.Path(**dict_0)
    names_0 = path_0
    session_0.remove_cookies(**names_0)


# Generated at 2022-06-25 19:21:42.610877
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import pathlib as module_0
    import collections
    import typing as module_1
    import unittest as module_2
    import typing as module_3
    dict_0 = None
    path_0 = module_0.Path(**dict_0)
    session_0 = Session(path_0)
    names_0 = collections.abc.Iterable(module_1.Iterable[str])
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:21:49.879847
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    dict_0 = None
    path_0 = module_0.Path(**dict_0)
    session_0 = Session(path_0)
    dict_0_0 = None
    request_headers_0 = RequestHeadersDict(**dict_0_0)
    session_0.update_headers(request_headers_0)



# Generated at 2022-06-25 19:21:53.127270
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.utils import get_response_dict
    from httpie.compat import OrderedMultiDict
# test case 0
    session_0 = Session(path_0)
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:21:55.897471
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    dict_0 = None
    path_0 = module_0.Path(**dict_0)
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:22:00.868931
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    dict_0 = None
    path_0 = module_0.Path(**dict_0)
    session_0 = Session(path_0)

    # Test 1
    request_headers_0 = None
    session_0.update_headers(**request_headers_0)


# Generated at 2022-06-25 19:22:11.844817
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    dict_0 = None
    path_0 = module_0.Path(**dict_0)
    session_0 = Session(path_0)
    dict_1 = None
    request_headers_0 = RequestHeadersDict(**dict_1)
    session_0.update_headers(request_headers_0)



# Generated at 2022-06-25 19:22:19.954448
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # ---------- setup code below ---------- #
    
    class mock_iterable_0():
        def __init__(self):
            self.iter_count = 0
        def __iter__(self):
            while True:
                if self.iter_count == 5: raise StopIteration
                yield self.iter_count
                self.iter_count += 1

    # ---------- setup code above ---------- #
    names = mock_iterable_0()
    try:
        session_0 = Session(path_0)
        try:
            session_0.remove_cookies(names)
        except NameError:
            pass
    except NameError:
        pass


# Generated at 2022-06-25 19:22:23.311699
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    dict_0 = None
    path_0 = module_0.Path(**dict_0)
    session_0 = Session(path_0)
    dict_0 = None
    request_headers_0 = None
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:22:28.324162
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # Test for update_headers method of Session class
    session_0 = Session(**dict_0)
    dict_0 = None
    request_headers_0 = RequestHeadersDict(dict_0)
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:22:30.535111
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(None)
    arg_0 = None
    session_0.remove_cookies(arg_0)

# Generated at 2022-06-25 19:22:40.709506
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    dict_0 = None
    path_0 = module_0.Path(**dict_0)
    session_0 = Session(path_0)
    str_0 = None
    request_headers_dict_0 = RequestHeadersDict(str_0)
    dict_1 = None
    path_1 = module_0.Path(**dict_1)
    session_1 = Session(path_1)
    str_1 = None
    request_headers_dict_1 = RequestHeadersDict(str_1)
    dict_2 = None
    path_2 = module_0.Path(**dict_2)
    session_2 = Session(path_2)
    str_2 = None
    request_headers_dict_2 = RequestHeadersDict(str_2)
    dict_3 = None
    path_

# Generated at 2022-06-25 19:22:51.464667
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_0 = RequestHeadersDict(**{'User-Agent': 'test_user_agent'})
    headers_1 = RequestHeadersDict(**{'User-Agent': u'test_user_agent'})
    headers_2 = RequestHeadersDict(**{'User-Agent': 'test_user_agent'})
    headers_3 = RequestHeadersDict(**{'User-Agent': 'test_user_agent'})
    headers_4 = RequestHeadersDict(**{'User-Agent': 'test_user_agent'})
    headers_5 = RequestHeadersDict(**{'User-Agent': 'test_user_agent'})
    headers_6 = RequestHeadersDict(**{'User-Agent': u'test_user_agent'})
    headers_7 = RequestHeaders

# Generated at 2022-06-25 19:23:01.114331
# Unit test for method update_headers of class Session

# Generated at 2022-06-25 19:23:05.457294
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    dict_0 = {}
    path_0 = module_0.Path(**dict_0)
    path_2 = module_0.Path(**dict_0)
    session_0 = Session(path_0)
    session_0.update_headers(path_2)


# Generated at 2022-06-25 19:23:11.331721
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    dict_0 = None
    path_0 = module_0.Path(**dict_0)
    session_0 = Session(path_0)
    string_0 = 'eLiw=q*'
    string_1 = ':N'
    request_headers_dict_0 = RequestHeadersDict({string_0: string_1})
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:23:26.967492
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    var_0 = None
    session_0 = Session(var_0)
    var_0 = ('', '', '', '', '')
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    module_0.RequestHeadersDict.__init__(var_1, var_2, var_3, var_4)
    module_0.RequestHeadersDict.__init__(var_1, *var_0)
    del var_1, var_0, var_2, var_3, var_4
    var_0 = ('', '', '', '', '')
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    module_0.RequestHeadersDict.__init

# Generated at 2022-06-25 19:23:30.430650
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = {'path': '', 'headers': {}, 'cookies': {}}
    request_headers = {'Accept': 'text/html'}
    test_0 = Session(session)
    test_0.update_headers(request_headers)
    assert test_0['headers'] == {'Accept': 'text/html'}


# Generated at 2022-06-25 19:23:32.424694
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    var_0 = Session(str())
    var_0.remove_cookies(iter([]))

# Generated at 2022-06-25 19:23:38.452985
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    httpie_session_0 = get_httpie_session('/Users/cj/.httpie', 'def', 'localhost', 'http://localhost')
    request_headers_dict_0 = httpie_session_0.headers
    httpie_session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:23:40.296585
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(path_0)
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:23:44.270405
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_0 = {'user-agent': None, 'content-type': 'application/json', 'accept': 'application/json'}
    var_1 = {'user-agent': None, 'content-type': 'application/json', 'accept': 'application/json'}
    request_headers_dict_0 = module_0.RequestHeadersDict(var_1)


# Generated at 2022-06-25 19:23:54.495843
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import datetime

    # Cookie with a non-ascii value
    non_ascii_cookie = create_cookie('foo', '%c3%a6')

    # Cookie with just an expiration time
    expires_cookie = create_cookie('foo', 'bar')
    expires_cookie['expires'] = 1

    # Cookie with just a domain  time
    domain_cookie = create_cookie('foo', 'bar')
    domain_cookie['domain'] = 'example.com'

    # Cookie with just a path time
    path_cookie = create_cookie('foo', 'bar')
    path_cookie['path'] = '/'

    # Cookie with just a secure flag
    secure_cookie = create_cookie('foo', 'bar')
    secure_cookie['secure'] = True

    # Cookie with everything

# Generated at 2022-06-25 19:24:01.433299
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_0 = None
    var_1 = None
    response_headers_dict_0 = module_0.ResponseHeadersDict(var_1)
    request_headers_dict_0 = module_0.RequestHeadersDict(var_0)
    session_0 = Session(request_headers_dict_0)
    session_0.load()
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:24:05.952178
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config_dir = DEFAULT_SESSIONS_DIR
    session_name = 'session_name'
    host = 'host'
    url = 'url'
    session_0 = get_httpie_session(config_dir, session_name, host, url)
    request_headers_dict_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:24:07.341547
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert True


# Generated at 2022-06-25 19:24:16.649373
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'np>LA}'
    session_0 = Session(str_0)

    str_1 = '@mDt]u'
    session_0.remove_cookies(str_1)



# Generated at 2022-06-25 19:24:17.568350
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_case_0()

# Generated at 2022-06-25 19:24:23.222043
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('')
    dict_0 = {'Content-Length': '605', 'Host': 'example.com', 'Content-Type': 'application/json', 'If-Modified-Since': 'Mon, 15 Jun 2020 17:00:00 GMT', 'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*'}
    session_0.update_headers(dict_0)
    return

# Generated at 2022-06-25 19:24:27.321189
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Case0
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_0 = Session(str_0)
    session_0.update_headers(RequestHeadersDict(tuple()))


# Generated at 2022-06-25 19:24:38.908486
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.auth.basic import HTTPBasicAuth
    from httpie.auth import BasicAuth
    headers_0 = RequestHeadersDict()
    headers_0.add('Cookie', 'nnO*W=1\\l^U=O&X<]NtX')
    headers_0.add('If-Modified-Since', 'Thu, 23 Jul 2015 13:44:11 GMT')
    headers_0.add('User-Agent', 'curl/7.37.1')
    headers_0.add('Host', 'httpbin.org')
    headers_0.add('Content-Type', 'application/xml')

# Generated at 2022-06-25 19:24:46.975563
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    #
    # I. Create a Session instance
    #
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_0 = Session(str_0)
    #
    # II. Create a RequestHeadersDict instance
    #
    dict_0 = {}
    dict_0['Content-Type'] = 'text/plain'
    request_headers = RequestHeadersDict(dict_0)
    #
    # III. Call the method
    #
    session_0.update_headers(request_headers)
    #
    # IV. Check the result
    #
    headers = session_0.headers
    assert isinstance(headers, RequestHeadersDict)
    headers_0 = headers
    assert len(headers_0) == 1
    assert headers_

# Generated at 2022-06-25 19:24:54.657418
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Setup
    from io import StringIO
    from requests.structures import CaseInsensitiveDict
    from httpie.core import main
    import pytest
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.sessions import get_httpie_session, Session
    from httpie.plugins.auth.basic import AuthBasicPlugin
    from httpie.plugins.auth.digest import AuthDigestPlugin
    from httpie.plugins.auth.oauth1 import AuthOAuth1Plugin
    from httpie.plugins.auth.ntlm import AuthNTLMPlugin

    config_dir = DEFAULT_CONFIG_DIR
    session_name = "session_name"
    host = "localhost"
    url = "http://localhost:8080/"
   

# Generated at 2022-06-25 19:25:05.683822
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    str_1 = 'tnF.S^S?hUEmBm+<>|5#5'
    str_2 = 'W`:8n\\DkhN*hb_f>N/xi;'
    str_3 = '/T9D+YVdJ:2k}0V7~wM+[u'
    str_4 = 'F6Uc?6RX:z:kfw1O!3qr+2'
    str_5 = '<dJ6CcU6kgIy|IGz~6aM>q'
    str_6 = 'Lhf6`<;T@f&D9Y?N)8AiFX'
    session_

# Generated at 2022-06-25 19:25:15.457658
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.compat import urlopen
    from httpie.context import Environment
    from httpie.cli.constants import DEFAULT_UA as USER_AGENT
    from httpie.plugins.builtin import HTTPBasicAuth

    env = Environment(stdin=None, stdout=None, stdout_isatty=True,
                      stderr=None, stderr_isatty=True,
                      stdin_isatty=True, stdin_is_ttylike=True)
    session_0 = Session('/path/to/session')
    session_0.update_headers({'User-Agent': user_agent})

# Generated at 2022-06-25 19:25:23.698895
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '0'
    var_1 = (str_0,)
    dict_2 = dict(var_1)
    dict_3 = dict_2
    requestHeadersDict_4 = RequestHeadersDict(dict_3)
    str_5 = 'baI(g>1$7Vu'
    session_6 = Session(str_5)
    session_6.update_headers(requestHeadersDict_4)


# Generated at 2022-06-25 19:25:41.954299
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test valid session file name
    path_1 = 'C:\\Users\\user_1\\.httpie\\sessions\\some_file_name.json'
    session_1 = Session(path_1)
    request_headers_1 = dict()
    request_headers_1['Accepts'] = 'Some String'
    request_headers_1['Content-type'] = 'Some String'
    request_headers_1['If-None-Match'] = 'Some String'
    assert 'Accepts' not in session_1.headers
    assert 'Content-type' not in session_1.headers
    assert 'If-None-Match' not in session_1.headers
    session_1.update_headers(request_headers_1)
    assert request_headers_1['Accepts'] == session_1.headers['Accepts']

# Generated at 2022-06-25 19:25:46.414611
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_0 = Session(str_0)
    session_0.remove_cookies({'Authors', 'Authors', 'Authors'})

# Generated at 2022-06-25 19:25:51.687208
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict(('content-type',
        'application/x-www-form-urlencoded'), ('Q', '9'))
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:25:53.197490
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # s.remove_cookies(names)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 19:25:55.844316
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('../httpie/config/sessions/http_localhost/default.json')
    session_0.update_headers('headers')
    session_0.update_headers('headers')



# Generated at 2022-06-25 19:26:07.962019
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '5plX0S?hv{_W'
    RequestHeadersDict_0 = RequestHeadersDict()
    str_1 = 'User-Agent'
    int_0 = 0
    str_2 = 'HTTPie/0.9.9'
    RequestHeadersDict_0.__setitem__(str_1, str_2)
    str_3 = 'Accept-Encoding'
    str_4 = 'gzip, deflate'
    RequestHeadersDict_0.__setitem__(str_3, str_4)
    str_5 = 'Host'
    str_6 = 'httpbin.org'
    RequestHeadersDict_0.__setitem__(str_5, str_6)
    str_7 = 'Connection'

# Generated at 2022-06-25 19:26:19.335314
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = 's'
    session_0 = Session(path_0)
    dict_0 = dict()
    dict_0['Connection'] = 'keep-alive'
    dict_0['DNT'] = '1'
    dict_0['Host'] = 'localhost:8080'
    dict_0['Referer'] = 'http://localhost:8080/login'
    dict_0['Upgrade-Insecure-Requests'] = '1'
    dict_0['User-Agent'] = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36'
    dict_1 = dict()
    dict_1['Content-Length'] = '22'

# Generated at 2022-06-25 19:26:20.741258
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('Z')
    session_0.update_headers({})


# Generated at 2022-06-25 19:26:26.202301
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_0 = RequestHeadersDict()
    session_0 = Session(('',))
    headers_0.__setitem__('X-Xss-Protection', '1; mode=block')
    headers_0.__setitem__('Upgrade-Insecure-Requests', '1')
    headers_0.__setitem__('Content-Length', '0')
    headers_0.__setitem__('X-Content-Type-Options', 'nosniff')
    headers_0.__setitem__('Pragma', 'no-cache')
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:26:28.735279
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    input = ["x0","x1","x2","x3","x4","x5","x6","x7","x8","x9"]
    result = len(input)
    assert result == 10

# Generated at 2022-06-25 19:26:35.781301
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    pass


# Generated at 2022-06-25 19:26:45.318954
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'D\\<MYH^fo+'
    session_0 = Session(str_0)
    str_1 = 'lJpG)W!1cm@3#x'
    session_1 = Session(str_1)
    str_2 = '!I$Gktmc%(V?k;'
    session_2 = Session(str_2)
    str_3 = 'y<CJbH~D'
    session_3 = Session(str_3)
    str_4 = '2TbT1J(R'
    session_4 = Session(str_4)
    str_5 = '@Iq\\1a'
    session_5 = Session(str_5)
    str_6 = '{}g:fM'

# Generated at 2022-06-25 19:26:53.033581
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from collections import OrderedDict
    from httpie.compat import OrderedDict
    from httpie.input import ParseError
    from httpie.output import REQUEST_ITEMS
    from httpie.plugins import plugin_manager
    from httpie.plugins.core import AuthPlugin
    from httpie.plugins.registry import plugin_manager
    from httpie.utils import get_response_type
    import os
    import time
    session_0 = Session('test_file.json')
    session_0.update_headers(dict())


# Generated at 2022-06-25 19:26:55.254439
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names = ["abc", "def"]
    session = Session("test")
    session.remove_cookies(names)


# Generated at 2022-06-25 19:27:03.401881
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert VALID_SESSION_NAME_PATTERN.match('cookies')
    assert VALID_SESSION_NAME_PATTERN.match('-')
    assert VALID_SESSION_NAME_PATTERN.match('2015-04-27-15-33-26')
    assert not VALID_SESSION_NAME_PATTERN.match('2015-04-27-15-33-2/6')
    assert not VALID_SESSION_NAME_PATTERN.match('2015-04-27-15-33-2\\6')
    assert not VALID_SESSION_NAME_PATTERN.match('../cookies')
    assert not VALID_SESSION_NAME_PATTERN.match('cookies/')
    assert not VALID_SESSION_NAME_PATTERN.match('cookies\\')
   

# Generated at 2022-06-25 19:27:13.091206
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '"a'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}


# Generated at 2022-06-25 19:27:15.868875
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_0 = Session(str_0)
    assert session_0.update_headers([]) == {'headers': {}}


# Generated at 2022-06-25 19:27:23.946355
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from random import randint, choice
    from string import ascii_letters, digits
    alphabet = ascii_letters + digits
    len_0 = randint(1, 10)
    str_0 = ''.join([choice(alphabet) for _ in range(len_0)])
    session_0 = Session(str_0)
    len_1 = randint(1, 10)
    str_1 = ''.join([choice(alphabet) for _ in range(len_1)])
    session_0.remove_cookies(str_1)


# Generated at 2022-06-25 19:27:31.565122
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'dNtX'
    str_1 = 'l^U=O&X<]NtX'
    str_2 = 'nnO*W=1\\'
    session_0 = Session(str_0)
    session_0.remove_cookies(['l^U=O&X<]NtX'])
    assert session_0['cookies'][str_2] == 'nnO*W=1\\'
    assert session_0['cookies'][str_0] == 'dNtX'
    assert session_0['cookies'][str_1] == None

# Generated at 2022-06-25 19:27:41.349794
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_1 = 'rnL-^Kq3*'
    session_1 = Session(str_1)
    str_2 = 'tT*Xs1#KjBqin=^\\p%'
    str_3 = 'Gvf<'
    str_4 = '@j=z1^\\h*d%zP'
    str_5 = 'cB_jF)'
    str_6 = 'G%%7'
    str_7 = 'VwbD'
    str_8 = 'k<.G'
    str_9 = 'A]N4'
    session_1.remove_cookies([str_2, str_3, str_4, str_5, str_6, str_7, str_8, str_9])


# Generated at 2022-06-25 19:27:51.905927
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    req_1 = {'User-Agent': 'test/test'}
    result_1 = None
    result_2 = None
    result_3 = None
    result_4 = None
    result_final = None
    assert result_1 == result_2 == result_3 == result_4 == result_final


# Generated at 2022-06-25 19:27:58.628381
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_0 = Session(str_0)
    str_1 = '{"headers": {},"cookies": {},"auth": {"type": null, "username": null, "password": null}}'
    session_0.update_headers(str_1)
    assert len(session_0['headers'].keys()) == 0
    assert len(session_0['cookies'].keys()) == 0
    assert len(session_0['auth'].keys()) == 3


# Generated at 2022-06-25 19:28:02.224091
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cases = [
            str(i) + '.json'
            for i in range(0, 9)
            ]
    for case in cases:
        session = Session(case)
        session.remove_cookies({})


# Generated at 2022-06-25 19:28:04.869134
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)



# Generated at 2022-06-25 19:28:08.175631
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'gBf&x]kv^'
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:28:11.191008
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(DEFAULT_SESSIONS_DIR)
    assert (session_0.update_headers() == None)


# Generated at 2022-06-25 19:28:19.016782
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_0 = Session(str_0)
    str_1 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_1 = Session(str_1)
    list_0 = []
    for i in range(10):
        item_0 = str(i)
        list_0.append(item_0)
    session_0.remove_cookies(list_0)
    assert (session_0 == session_1) == True


# Generated at 2022-06-25 19:28:20.591978
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('./session.json')


# Generated at 2022-06-25 19:28:25.089161
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'jX9Z%bE6:3v6YW'
    session_0 = Session(str_0)
    str_1 = '9GZ@H/'
    str_2 = 'gxLn=De]}'
    class___ = session_0.remove_cookies
    assert class___([str_1, str_2]) == None



# Generated at 2022-06-25 19:28:29.678812
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_0 = Session(str_0)

    str_1 = 'o7p0$rq3'
    str_2 = 'c0u8Z'
    str_3 = '6Uoh7'
    lst_0 = [str_1, str_2, str_3]

    # Test case 0
    session_0.remove_cookies(lst_0)
    assert session_0.cookies == {}



# Generated at 2022-06-25 19:28:49.681241
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    # Set up session
    session = Session('test.json')
    session.cookies['session'] = {'value': '123abc'}
    session.cookies['debug'] = {'value': 'false'}
    session.cookies['name'] = {'value': 'Alex'}

    # Test that cookies are still in the session
    assert(session.cookies['session'] is not None)
    assert(session.cookies['debug'] is not None)
    assert(session.cookies['name'] is not None)

    # Remove cookies
    session.remove_cookies('session', 'name')

    # Test that cookies were removed from the session
    assert(session.cookies['session'] is None)
    assert(session.cookies['name'] is None)

    # Test that other cookies are still in the session

# Generated at 2022-06-25 19:28:55.770781
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'test.json'
    session_0 = Session(str_0)
    session_0.load()
    session_0.update_headers({'HEADER_0': 'VALUE_0'})
    session_0.save()
    session_1 = Session(str_0)
    session_1.load()
    assert session_1.headers == {'HEADER_0': 'VALUE_0'}, 'AssertionError'


# Generated at 2022-06-25 19:29:06.779563
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Session.update_headers(request_headers)

    str_0 = '#\\pV!4u$Pv'
    session_0 = Session(str_0)
    list_0 = []
    list_1 = []
    list_1_0 = (53, 10, '~', 'r', ']', 17, 'g', '}', 'vP', 35)
    list_1.append(list_1_0)
    list_1_1 = (25, 15)
    list_1.append(list_1_1)
    list_1_2 = (12, '"', '_t')
    list_1.append(list_1_2)
    tuple_0 = (list_0, list_1)
    str_1 = 'g8E[S'

# Generated at 2022-06-25 19:29:08.454849
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_case_0()


# Generated at 2022-06-25 19:29:17.469389
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '@9Rh5#`KP7MLu{^N'
    session_0 = Session(str_0)
    list_0 = []
    dict_0 = {}
    session_0.cookies = dict_0
    list_0.append(session_0)
    list_2 = []
    str_2 = '@9Rh5#`KP7MLu{^N'
    result = session_0.remove_cookies(list_2)
    assert result == list_0


# Generated at 2022-06-25 19:29:25.793535
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    req_hdrs_dict_0 = RequestHeadersDict({'Cookie': 'Cookie-2', 'a': 'b', 'Content-Type': 'text/html; charset=UTF-8', 'User-Agent': 'HTTPie/0.9.9', 'Cookie-1': 'Cookie-1', 'Cookie-2': 'Cookie-2'})

    # Case 1:
    session_0 = Session('gbQ"z:R!G0h1.Tj(7Ys{')
    session_0.update_headers(req_hdrs_dict_0)

# Generated at 2022-06-25 19:29:34.039166
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # cookiedict_0 = dict()
    # cookiedict_0 = {'Z_': {'value': 'v'}}
    cookiedict_0 = {'Z_': {'value': 'v'}, 'Z_1': {'value': 'v_1'}}
    names_0 = []
    # session_0 = Session('tRz')
    session_0 = Session('tRz')
    session_0['cookies'] = cookiedict_0
    session_0.remove_cookies(names_0)
    assert session_0['cookies'] == cookiedict_0
    names_1 = ['Z_']
    # session_0 = Session('aLk')
    session_0 = Session('aLk')
    session_0['cookies'] = cookiedict_0
    session

# Generated at 2022-06-25 19:29:41.782097
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    str_1 = 'A|r*z.T;Tg[sM=!$agKvJ'
    str_2 = 'V\\hN0 \\0zV7|U6.g/=>'
    session_0 = Session(str_0)
    # params == [str_1]
    # actual = session_0.remove_cookies([str_1])
    # expected = None
    # assert actual == expected


# Generated at 2022-06-25 19:29:42.636997
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert True


# Generated at 2022-06-25 19:29:46.008576
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_0 = Session(str_0)
    str_1 = 'nnO*W=1\\l^U=O&X<]NtX'
    # Calling RequestHeadersDict(...)
    # RequestHeadersDict()
    # RequestHeadersDict(headers=None)
    # RequestHeadersDict(raw_headers=None)
    headers_0 = RequestHeadersDict(arg_0=str_1)
    session_0.update_headers(headers=headers_0)


# Generated at 2022-06-25 19:30:00.463431
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'MvavOp]*Oa'
    instance_0 = Session(str_0)
    str_1 = 'dr\\'
    list_0 = [str_1]
    session_0 = instance_0.remove_cookies(list_0)

# Generated at 2022-06-25 19:30:06.045528
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    data = [
        (({'Host': 'localhost:5000', 'Cookie': 'foo=bar'}, {'Host': 'localhost:5000', 'Cookie': 'foo=bar'}), None),
        (({'User-Agent': 'HTTPie/0.9.9', 'Content-Type': 'text/plain'}, {'Content-Type': 'text/plain'}), None),
    ]
    session_1 = Session('/usr/local/etc/httpie/sessions/localhost/session_1.json')
    for ((arg1, arg2), wtf) in data:
        result = session_1.update_headers(arg1)
        assert result == arg2


# Generated at 2022-06-25 19:30:09.300355
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_0 = Session(str_0)
    request_headers_0 = session_0['headers']
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:30:11.494195
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('E6l}Nl^')
    session_0['headers'] = {'Cookie': 'Cookie: Cookie=;'}
    session_0['cookies'] = {}
    session_0['cookies']['Cookie'] = {}
    session_0.remove_cookies(['Cookie'])


# Generated at 2022-06-25 19:30:16.804482
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("test_file")
    case_0 = {"Content-type" : "text/html", "User-Agent" : "HTTPie/1.0.0"}
    case_1 = {"Header" : "value", "Content-type" : "text/html"}
    case_2 = {"Header" : "value", "Accept" : "application/json"}
    case_3 = {"User-Agent" : "HTTPie/1.0.0", "Content-Type" : "application/json"}
    test_cases = [case_0, case_1, case_2, case_3]

# Generated at 2022-06-25 19:30:22.541435
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    print("Testing remove_cookies")
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_0 = Session(str_0)
    str_1 = 'G]p5L<,5e6YXev`~[?6k'
    list_2 = [str_1]
    session_0.remove_cookies(list_2)

# Generated at 2022-06-25 19:30:26.800285
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    src = b'Hello'
    str_0 = 'content-type'
    dict_1 = {'headers': {str_0: src}}
    session_0 = Session(str_0)
    session_0.update(dict_1)
    session_0.update_headers(src)

# Generated at 2022-06-25 19:30:32.300976
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    session_0 = Session(str_0)
    request_headers_dict_0 = session_0.request_headers_dict()
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:30:39.266445
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'nnO*W=1\\l^U=O&X<]NtX'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['headers'] = dict_0
    dict_0 = dict()
    dict_1['cookies'] = dict_0
    dict_0 = dict()
    dict_0['type'] = None
    dict_0['username'] = None
    dict_0['password'] = None
    dict_1['auth'] = dict_0
    session_0 = Session(str_0)
    session_0._Session__data = dict_1
    list_0 = list()
    session_0.remove_cookies(list_0)
