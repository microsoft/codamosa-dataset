

# Generated at 2022-06-25 19:20:58.330688
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)
    iterable_0 = [session_0.cookies, session_0.headers]
    session_0.remove_cookies(iterable_0)
    session_0.add_cookies(session_0.auth)


# Generated at 2022-06-25 19:21:06.701307
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'jK9Xv:yGk'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}


# Generated at 2022-06-25 19:21:08.837846
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    print('Testing remove_cookies')
    names = ['abc', '123']
    # Execute remove_cookies and check result
    


# Generated at 2022-06-25 19:21:12.200836
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('test_0')
    session_0.update_headers({'Content-Type': 'application/json'})
    assert(session_0.headers['Content-Type'] == 'application/json')

# Generated at 2022-06-25 19:21:18.227157
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # set up context
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)
    # set up context
    request_headers_0 = RequestHeadersDict()
    # set up context
    name_0 = 'Xr,aTz^'
    value_0 = 'Pn^u_|VH#'
    request_headers_0[name_0] = value_0
    # invoke the method
    session_0.update_headers(request_headers_0)



# Generated at 2022-06-25 19:21:22.224604
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'E.7F'
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)



# Generated at 2022-06-25 19:21:26.697662
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '~Q'
    session_0 = Session(str_0)
    request_headers_0 = dict()
    assert session_0.update_headers(request_headers_0) == None
    assert session_0.headers == dict()


# Generated at 2022-06-25 19:21:29.828726
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)
    request_headers = {}
    session_0.update_headers(request_headers)


# Generated at 2022-06-25 19:21:34.675679
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_headers = ('Content-Length: 50', 'User-Agent: PyPy Http Client')
    test_session = Session('test.session')
    test_session.update_headers(test_headers)
    results = test_session.headers
    assert results == test_headers


# Generated at 2022-06-25 19:21:42.346278
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_1 = Path('./sessions/www.example.com/test_Session_update_headers.json')
    path_1.parent.mkdir(parents=True, exist_ok=True)
    session_1 = Session(path_1)
    request_headers_1 = {'b': 2, 'a': 1, 'd': 3, 'c': 4}
    session_1.update_headers(request_headers_1)
    assert session_1['headers'] == {'a': '1', 'b': '2', 'c': '4', 'd': '3'}


# Generated at 2022-06-25 19:21:49.209277
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Puts test here
    pass

# Generated at 2022-06-25 19:21:53.395058
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'kwP:.[!8;'
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict('Accept-Encoding', 'o#.ZJ')
    session_0.update_headers(request_headers_0)
    assert 'Accept-Encoding' in session_0.headers


# Generated at 2022-06-25 19:22:04.367257
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import ItemSpec
    session_0 = Session('test')
    request_headers_0 = RequestHeadersDict()
    ItemSpec.validate = lambda self, value: (
        KeyValueArg.validate(value) or
        KeyValueArg.validate(value + '=')
    )
    request_headers_0._store = {'User-Agent': 'HTTPie/0.9.8'}
    request_headers_0.parser_hooks = [
        lambda headers: [
            ItemSpec.parse(key_value)
            for key_value in headers
        ],
        ItemSpec.validate
    ]
    session_0.update_headers(request_headers_0)
    assert session_0['headers'] == {}


# Generated at 2022-06-25 19:22:09.614287
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_1 = Session('test_session_1')
    session_1.update_headers(
        {'content-type': 'text/plain', 'content-length': '123'}
    )
    assert session_1.headers['content-type'] == 'text/plain'
    assert session_1.headers['content-length'] == '123'

    # Teardown
    del session_1


# Generated at 2022-06-25 19:22:20.069580
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Declare the class Session
    class Session:
        # Declare the function update_headers
        def update_headers(self, request_headers):
            self.request_headers = request_headers

    # Declare a function merge_dictionaries
    def merge_dictionaries(dict1, dict2):
        for key, value in dict2.items():
            if value is not None:
                dict1[key] = value
        return dict1

    # Declare a function read_dictionary_from_file
    def read_dictionary_from_file(filename):
        txtfile = open(filename)
        contents = txtfile.read()
        dictionary = eval(contents)
        return dictionary

    # Declare a function write_dictionary_to_file

# Generated at 2022-06-25 19:22:27.560416
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # both are instances of Session
    assert isinstance(session_0, Session)
    assert isinstance(session_1, Session)
    # both are instances of dict
    assert isinstance(session_0, dict)
    assert isinstance(session_1, dict)

    # both have the same keys
    assert session_0.keys() == session_1.keys()
    assert session_0.keys() == {'headers', 'cookies', 'auth'}
    # both have the same values
    assert session_0.values() == session_1.values()
    assert session_0.values() == ({'Content-Type': 'text/plain'}, {}, {'type': None, 'username': None, 'password': None})
    # both have the same items
    assert session_0.items() == session_1.items()
   

# Generated at 2022-06-25 19:22:37.673459
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'Mk-`'
    session_0 = Session(str_0)
    header_0 = RequestHeadersDict()
    header_0.update(
        {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'})
    header_0.update(
        {'Accept-Encoding': 'gzip, deflate, sdch'})
    header_0.update(
        {'Accept-Language': 'en-US,en;q=0.8'})
    header_0.update({'Connection': 'keep-alive'})

# Generated at 2022-06-25 19:22:45.404350
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = Path() / "abc.json"
    path_0 = Path() / "abc.json"
    session_0 = Session(path_0)
    session_1 = Session(path)
    dict_0 = dict()
    dict_1 = dict()
    dict_0["he"] = "he"
    dict_0["hello"] = "hello"
    dict_1["goodbye"] = "goodbye"
    dict_1["good"] = "good"
    dict_1["hello"] = "hello"
    dict_1["hello"] = "hello"
    dict_1["bye"] = "bye"
    dict_1["BYE"] = "BYE"
    dict_1["Content-Ty"] = "Content-Ty"
    dict_1["Content-Type"] = "Content-Type"
    dict_

# Generated at 2022-06-25 19:22:56.274258
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = ';a}>'
    session_0 = Session(str_0)
    session_0.update_headers({'Host': '"Ce3q'})
    session_0.cookies = RequestsCookieJar()
    session_0.cookies.set('Set-Cookie', 'f\'j(o')
    str_1 = 'L1jK'
    session_0.cookies.set('Set-Cookie', str_1)
    str_2 = 'YI&,A'
    session_0.cookies.set('Set-Cookie', str_2)
    str_3 = 'YI&,A'
    session_0.cookies.set('Set-Cookie', str_3)
    session_0.cookies.clear_expired_cookies()
   

# Generated at 2022-06-25 19:23:00.124342
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'http://127.0.0.1:8080/'
    session_0 = Session(str_0)
    str_1 = 'http://127.0.0.1:8080/'
    session_0.update_headers(str_1)


# Generated at 2022-06-25 19:23:05.945661
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names = [1, 2, '', '123']
    session = Session('123')
    session.remove_cookies(names)


# Generated at 2022-06-25 19:23:15.726194
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'bqDk~#'
    str_1 = 'X'
    str_2 = 'yb'
    str_3 = 'PZ'
    str_4 = 'aS'
    dict_0 = dict()
    dict_0['I'] = str_0
    dict_0['E'] = str_1
    dict_0['Bm'] = str_2
    dict_0['V'] = str_3
    dict_0['p'] = str_4
    dict_1 = dict()
    dict_1['Y'] = dict_0
    dict_1['r'] = dict_0
    dict_1['f'] = dict_0
    dict_1['N'] = dict_0
    dict_1['Nc'] = dict_0

# Generated at 2022-06-25 19:23:23.463461
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Setup
    cookie_names = ['LWD-cookie-1', 'LWD-cookie-2']
    session = Session('/tmp/httpie-tests-session-0.json')
    for name in cookie_names:
        session.cookies.set(name, 'test', domain='localhost')
    assert len(session.cookies) == len(cookie_names)

    # Exercise
    session.remove_cookies(cookie_names)

    # Verify
    for name in cookie_names:
        assert not name in {cookie.name for cookie in session.cookies}

# Generated at 2022-06-25 19:23:26.111295
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)
    str_1 = 'wuK$|'
    array_0 = ['dV=%P', 'bqDk~#', 'bQ*9U']
    session_0.remove_cookies(array_0)
    # This should fail due to assertion
    str_2 = 'U-%gG'
    session_0.remove_cookies(str_2)


# Generated at 2022-06-25 19:23:29.292219
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '0?y6o5'
    session_0 = Session(str_0)
    val_0 = {'A': 'B', 'C': 'D'}
    session_0.update_headers(val_0)
    assert(session_0.headers == val_0)


# Generated at 2022-06-25 19:23:40.373274
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test: If a session exists, the request headers will be merged with it.
    dict_0 = {'headers': {'Accept': 'text/plain'}}
    dict_1 = {'Accept-Charset': 'utf-8'}
    session_0 = Session(dict_0)
    session_1 = session_0.update_headers(dict_1)
    dict_2 = dict_0
    dict_2['headers'] = {'Accept': 'text/plain', 'Accept-Charset': 'utf-8'}
    assert dict_2 == session_1
    dict_3 = {'headers': {'Accept': 'text/plain'}}
    session_2 = session_0.update_headers(dict_3)
    dict_4 = dict_3

# Generated at 2022-06-25 19:23:49.693612
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = '/Tkf>u'
    session_1 = Session(str_1)
    str_2 = 'Bp@Ng\x1c'
    list_1 = [('User-Agent', 'httpie/0.9.2'), ('Accept', '*/*')]
    header_1 = RequestHeadersDict(list_1)
    session_1.update_headers(header_1)
    assert session_1['headers'] == {'User-Agent': 'httpie/0.9.2', 'Accept': '*/*'}
    str_3 = 'ZQLsO'
    list_2 = [('Accept', 'Q/t@R'), ('Accept-EncodinG', 'Y/eSz'), ('User-Agent', 'httpie/0.9.2')]
    header_

# Generated at 2022-06-25 19:23:55.577402
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print('In test_Session_update_headers')
    str_0 = '<lx'
    session_0 = Session(str_0)
    str_1 = 'bqDk~#'
    dict_0 = {str_1: str_0}
    session_0.update_headers(dict_0)
    dict_1 = session_0.headers
    print(dict_1)


# Generated at 2022-06-25 19:24:04.979353
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import pytest
    import json
    import re

    str_0 = 'y.J+Q'
    Path_1 = Session(str_0)
    request_headers_0 = {
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Accept': '*/*',
        'User-Agent': 'python-requests/2.9.1'
    }
    Path_1.update_headers(request_headers_0)
    list_0 = [
        'Connection',
        'Accept',
        'User-Agent'
    ]
    for i in list_0:
        assert i in Path_1


# Generated at 2022-06-25 19:24:10.862264
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'q7|dS<'
    session_0 = Session(str_0)
    list_0 = []
    dict_0 = dict(list_0)
    request_headers = RequestHeadersDict(dict_0)
    session_0.update_headers(request_headers)


# Generated at 2022-06-25 19:24:23.969527
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('O`x}`LA')
    request_headers_0 = {'Host': ['127.0.0.1'], 'User-Agent': ['HTTPie/0.9.8']}
    session_0.update_headers(request_headers_0)
    assert session_0.headers == {'Host': '127.0.0.1', 'User-Agent': 'HTTPie/0.9.8'}, "Test session_0.headers"
    assert session_0.get('headers', {}) == {'Host': '127.0.0.1', 'User-Agent': 'HTTPie/0.9.8'}, "Test session_0.get('headers', {})"
    session_1 = Session('')

# Generated at 2022-06-25 19:24:33.241693
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Create a session
    session_0 = Session('test')
    # Create a dictionary of strings
    dictionary_0 = {'one': '1', 'two': '2'}
    # Add the dictionary to the session
    session_0['cookies'] = dictionary_0
    # Create a list of strings
    string_list_0 = ['one']
    # Remove the strings from the session
    session_0.remove_cookies(string_list_0)
    assert session_0['cookies'] == {'two': '2'}


# Generated at 2022-06-25 19:24:36.465907
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'Session'
    session_0 = Session(str_0)
    request_headers_0 = {}
    session_0.update_headers(request_headers_0)
    assert session_0['headers'] == {}



# Generated at 2022-06-25 19:24:40.431502
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '?PzF['
    session_1 = Session(str_0)
    str_1 = '`'
    request_headers_0 = RequestHeadersDict(str_1)
    session_1.update_headers(request_headers_0)


# Generated at 2022-06-25 19:24:51.347712
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'bqDk~#'
    names_0 = [
        'blah',
        'b',
        'c',
        'd',
        'e',
        'f',
        'g',
        'h',
        'i',
        'j',
        'k',
        'l',
        'm',
        'n',
        'o',
        'p',
        'q',
        'r',
        's',
        't',
        'u',
        'v',
        'w',
        'x',
        'y',
        'z',
        'a',
        'a',
        'a',
        'a',
        'a',
        'a',
    ]

# Generated at 2022-06-25 19:24:58.456541
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_1 = Session('5QfQUk')
    str_1 = '4?4o4'
    session_1.remove_cookies(['5QfQUk', 'f*'])
    str_2 = 'Are%'
    session_1.remove_cookies([str_1, str_2])


# Generated at 2022-06-25 19:25:08.225730
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # session_0
    str_0 = '0_'
    session_0 = Session(str_0)
    # names_0
    str_1 = '3'
    # names_1
    str_2 = 'k'
    names_1 = [str_2]
    session_0.remove_cookies(names_1)
    # names_2
    str_3 = 'E'
    names_2 = [str_3]
    session_0.remove_cookies(names_2)
    # names_3
    str_4 = 'xl'
    names_3 = [str_4]
    session_0.remove_cookies(names_3)
    # names_4
    str_5 = 'mP'
    names_4 = [str_5]

# Generated at 2022-06-25 19:25:18.677483
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '|'
    session_0 = Session(str_0)
    se_0 = '7VY<'
    session_0.cookies = se_0
    str_1 = ')?'
    session_0.auth = str_1
    str_2 = '9h'
    headers_0 = RequestHeadersDict(str_2)
    session_0.update_headers(headers_0)
    session_0.save()
    str_3 = 'Ua&F'
    session_1 = Session(str_3)
    str_4 = '=Uq~'
    headers_1 = RequestHeadersDict(str_4)
    session_1.update_headers(headers_1)
    str_5 = ';j'
    session_1.cookies = str_

# Generated at 2022-06-25 19:25:28.305281
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print('Testing update_headers():')
    config_dir = Path.home() / '.config' / 'httpie'
    session_name = 'test1'
    host = 'localhost'
    url = 'http://www.google.com'
    http_session = get_httpie_session(config_dir,session_name, host, url)
    request_headers = {'Cookie': None, 'Connection': 'keep-alive', 'Host': 'www.google.com', 'User-Agent': 'HTTPie/0.9.9'}
    http_session.update_headers(request_headers)
    print(type(http_session.headers))
    assert type(http_session.headers) == dict

test_Session_update_headers()

test_case_0()

# Generated at 2022-06-25 19:25:31.122133
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('64i.iqK')
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:25:38.199962
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = ''
    str_1 = 'XbY+dR|_'
    session_0 = Session(str_0)
    session_1 = Session(str_1)
    session_0.update_headers(session_1)


# Generated at 2022-06-25 19:25:46.474153
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    dict_0 = {
        'User-Agent': 'HTTPie/0.9.9',
        'Accept-Encoding': 'gzip, deflate',
        'Accept': '*/*',
        'Connection': 'keep-alive'
    }
    dict_1 = {
        'User-Agent': 'HTTPie/0.9.9',
        'Accept-Encoding': 'gzip, deflate',
        'Accept': '*/*',
        'Connection': 'keep-alive'
    }
    session_0 = Session(str_0)
    session_0.update_headers(dict_0)


# Generated at 2022-06-25 19:25:51.041665
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)
    request_headers_0 = {}
    request_headers_0['Content-Type'] = None
    session_0.update_headers(request_headers_0)
    assert_equal(session_0['headers'], {})


# Generated at 2022-06-25 19:25:57.653100
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = '$'
    path_0 = Path(str_1)
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    request_headers_0['Content-Length'] = '0'
    request_headers_1 = RequestHeadersDict()
    request_headers_1['If-Match'] = '*'
    request_headers_2 = RequestHeadersDict()
    request_headers_2['User-Agent'] = 'HTTPie/1.0.3'
    request_headers_3 = RequestHeadersDict()
    request_headers_3['Cookie'] = 'session-id=123455'
    request_headers_4 = RequestHeadersDict()
    request_headers_4['Referer'] = 'https://httpie.org/posts'

# Generated at 2022-06-25 19:26:07.048469
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'q(7nxWK~u.7V*HA'
    session_0 = Session(str_0)
    str_1 = '|gKj=(z(>Ci1H'
    request_headers_0 = RequestHeadersDict(str_1)
    session_0.update_headers(request_headers_0)
    exception_0 = None
    try:
        session_0.update_headers(request_headers_0)
        session_0.update_headers(request_headers_0)
    except Exception as exception_0:
        pass
    assert exception_0 is None


# Generated at 2022-06-25 19:26:09.003194
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert 'cu9pBv' == Session.remove_cookies('wHqe#*')


# Generated at 2022-06-25 19:26:11.658134
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session("./session.json")
    session_0.load()
    session_0.remove_cookies(["a"])


# Generated at 2022-06-25 19:26:15.565569
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'JGKu'
    path_0 = Path(str_0)
    session_0 = Session(path_0)
    request_headers_0 = None

    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:26:16.776484
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(str_0)
    session.update_headers()

# Generated at 2022-06-25 19:26:19.411810
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)
    session_0.load()
    session_0.save()
    return


# Generated at 2022-06-25 19:26:27.566375
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\t(1)'
    session_0 = Session(str_0)
    session_0.update_headers({})

# Generated at 2022-06-25 19:26:39.009710
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import io, sys
    from contextlib import redirect_stdout
    from io import StringIO
    f = StringIO()
    with redirect_stdout(f):
        session_0 = Session('/fjwk;!CQ-/n^')
        session_0.update_headers({'Content-Length': '0', 'Host': '7VlY9hJ0c', 'jgo0UHb6': None, 'Accept-Encoding': 'gzip, deflate, br', 'Accept-Language': 'en-US,en;q=0.5', 'Referer': 'https://www.linkedin.com/', 'Connection': 'keep-alive' })
        session_0.update_headers({'Host': 'JpC' })
        out = f.getvalue()
        sys.stdout = sys.__

# Generated at 2022-06-25 19:26:40.947486
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    obj = Session('a')
    request_headers = RequestHeadersDict({'value': 'test'})
    obj.update_headers(request_headers)

# Generated at 2022-06-25 19:26:48.425724
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)
    session_0['headers'] = {}
    session_0['cookies'] = {}
    session_0['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }
    session_0['auth']['type'] = 'digest'
    session_0['auth']['raw_auth'] = ':~'
    request_headers_0 = RequestHeadersDict(None)
    if type(request_headers_0) is not RequestHeadersDict:
        raise TypeError
    if type(session_0) is not Session:
        raise TypeError
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:26:52.997984
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)
    str_1 = 'H>'
    str_1 = str_1.split(',')
    # Action
    session_0.remove_cookies(str_1)
    # Assert


# Generated at 2022-06-25 19:27:02.185307
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print('Running test_Session_update_headers')
    session_0 = Session('xUJ8bU')
    session_0.update_headers({'Host': 'JffA+'})
    assert session_0['headers'] == {'Host': 'JffA+'}
    session_0.update_headers({'Host': 'c'})
    assert session_0['headers'] == {'Host': 'JffA+'}
    session_0.update_headers({'host': 'c'})
    assert session_0['headers'] == {'Host': 'c'}
    session_0.update_headers({'Host': 'c', 'Host': 'd', 'X-Host': 'e'})
    assert session_0['headers'] == {'Host': 'd', 'X-Host': 'e'}


# Generated at 2022-06-25 19:27:08.592395
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('')
    # RequestHeadersDict _headers is not a dict, but a list
    request_header_dict_0 = RequestHeadersDict()
    # Exception raised when trying to access one of the Session data members
    try:
        session_0.update_headers(request_header_dict_0)
        assert False
    except KeyError as e:
        assert True


# Generated at 2022-06-25 19:27:17.717314
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
	print('Testing remove_cookies()')
	str_0 = 'bqDk~#'
	session_0 = Session(str_0)
	str_1 = 'Bc%5f'
	str_2 = '!l@JB'
	str_3 = 'zKDt}'
	str_4 = '*KXHZ'
	str_5 = '"HN!}'
	str_6 = 'fL-_<'
	str_7 = 'A~;{%'
	str_8 = '_3-m:'
	str_9 = '5?Ych'
	str_10 = 'NIu~w'
	str_11 = '8Uv7-'
	str_12 = '{jq:8'
	str_13 = 'L-BDe'

# Generated at 2022-06-25 19:27:18.739952
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert True


# Generated at 2022-06-25 19:27:28.009452
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    obj = Session('/Users/david_luk/.httpie/sessions/api.github.com/david_luk.json')
    assert obj.cookies == RequestsCookieJar()
    assert isinstance(obj.cookies, RequestsCookieJar)
    assert isinstance(obj.cookies, RequestsCookieJar)
    obj.remove_cookies(['oktaugrp', '_octo', '_gh_sess', 'logged_in', 'tz'])
    assert obj.cookies == RequestsCookieJar()
    assert isinstance(obj.cookies, RequestsCookieJar)
    assert isinstance(obj.cookies, RequestsCookieJar)

# Generated at 2022-06-25 19:27:43.080935
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print("Testing update_headers")
    header_list_0 = []
    header_0 = [None, None]
    header_list_0.append(header_0)
    header_0 = [None, None]
    header_list_0.append(header_0)

# Generated at 2022-06-25 19:27:48.504647
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)
    request_headers_0 = dict([('user-agent', 'HTTPie/1.0.2'), ('accept-encoding', ''), ('host', 'www.example.com'), ('content-type', 'application/json'), ('content-length', '9001')])
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:27:49.952765
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(None)
    session_0.update_headers(None)



# Generated at 2022-06-25 19:27:54.443053
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    
    # Call of update_headers method
    tt = get_httpie_session(DEFAULT_CONFIG_DIR, '/Users/weiming/Documents/2019/httpie-test/test_test.ssession', 'test', 'test')
    tt.update_headers({'tt': 'test'})
    print(tt.headers)
    print(tt.cookies)
    print(tt.auth)

# Generated at 2022-06-25 19:28:01.910796
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'K.A.O.'
    str_1 = '{1, 2, 3}'
    str_2 = '|^'
    str_3 = ''
    str_4 = '{1, 2, 3}'
    str_5 = '|^'
    session_0 = Session(str_0)
    session_0.headers = {str_1: str_2, str_3: str_4}
    session_0.update_headers({str_1: str_2, str_3: str_4})


# Generated at 2022-06-25 19:28:04.908274
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    str_0 = 'bqDk~#'

    session_0 = Session(str_0)
    assert session_0.remove_cookies('bqDk~#') == 1



# Generated at 2022-06-25 19:28:08.015877
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '=5'
    request_headers_0 = RequestHeadersDict()
    dict_0 = request_headers_0
    dict_1 = dict_0
    session_0 = Session(str_0)
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:28:11.445601
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    cookie_0 = SimpleCookie(None)
    session_0 = Session('Nj7r>B')
    session_0.update_headers(cookie_0)


# Generated at 2022-06-25 19:28:16.073110
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_1 = '8W)xJ:'
    session_1 = Session(str_1)
    assert session_1.cookies == {}
    assert session_1.headers == {}
    assert session_1.auth == {'type': None, 'username': None, 'password': None}
    session_1.remove_cookies(set())



# Generated at 2022-06-25 19:28:25.346781
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test without session, without request
    session_0 = Session('example_0')
    request_headers_0 = {'header': 'value'}
    session_0.update_headers(request_headers_0)
    assert session_0.headers == {'header': 'value'}

    # Test without session, with request
    session_1 = Session('example_1')
    request_headers_1 = {'header': 'value'}
    session_1.update_headers(request_headers_1)
    assert session_1.headers == {'header': 'value'}

    # Test with session, without request
    session_2 = Session('example_2')
    request_headers_2 = {}
    session_2.update_headers(request_headers_2)
    assert session_2.headers == {}

    # Test

# Generated at 2022-06-25 19:28:34.452810
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    
    # Call test case 0 of method remove_cookies of class Session, using session_0 as argument
    test_case_0()



# Generated at 2022-06-25 19:28:43.854059
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = Path('/usr/lib/systemd/system/httpie.service')
    session_0 = Session(path_0)
    session_1 = Session(path_0)
    session_2 = Session(path_0)
    request_headers_0 = session_0.headers
    request_headers_1 = session_1.headers
    request_headers_2 = session_2.headers
    name_0 = 'Proxy-Connection'
    value_0 = 'keep-alive'
    dict_0 = session_2.headers
    dict_0[name_0] = value_0
    dict_0 = session_1.headers
    dict_0[name_0] = value_0
    dict_0 = session_0.headers
    dict_0[name_0] = value_0
    dict_

# Generated at 2022-06-25 19:28:47.897569
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)
    names_0 = ['uc#pc3[Ai_o*' for _ in range(3755)]
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:28:54.618192
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'uqDk~#'
    session_0 = Session(str_0)
    session_0.remove_cookies(['cookie_name'])


# Generated at 2022-06-25 19:29:02.998592
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)

    # Test with a string and a string list.
    session_0.remove_cookies('gbTA;')
    session_0.remove_cookies(['GwrX', 'vT'])
    # Test with a string and a tupel with a string.
    session_0.remove_cookies('a/HG')
    session_0.remove_cookies(('IZNK',))
    # Test with a string and a tupel with two strings.
    session_0.remove_cookies(']i^')
    session_0.remove_cookies(('uV1"', 'Z'))


# Generated at 2022-06-25 19:29:06.058553
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)
    # exceptions.NotFoundError: No such file or directory: 'bqDk~#'
    # session_0.load()



# Generated at 2022-06-25 19:29:16.023420
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Given
    str_0 = '$!oGPW'
    session_0 = Session(str_0)
    lst_0 = ["", "9mB0", "c#!@", "", "bqDk~#", "", "CYe:8", "7Vh$O`", "bqDk~#", "", "", "", "", "c#!@", "", "bqDk~#"]
    # When
    session_0.remove_cookies(lst_0)
    # Then
    str_1 = 'bqDk~#'
    assert session_0.path == str_1



# Generated at 2022-06-25 19:29:22.085260
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    i = 'pA4}k'
    c = 'y_sao'
    session_0 = Session(i)
    session_0.remove_cookies(c)


# Generated at 2022-06-25 19:29:31.161066
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'bqDk~#'
    session_0 = Session(str_0)
    str_1 = 'Cnk#'
    str_2 = '4'
    str_3 = 'Dp6j'
    str_4 = '0;'
    str_5 = '~H4@'
    str_6 = 'pK'
    str_7 = '@aA'
    str_8 = ',*'
    str_9 = 'vKz'
    str_10 = '2'
    str_11 = '>b8K'
    str_12 = 't,M'
    str_13 = '1'
    str_14 = 'T}N'
    str_15 = '1'
    str_16 = 'c*~'

# Generated at 2022-06-25 19:29:33.810973
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'R'
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:29:50.218754
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    s0 = Session('bqDk~#')
    r0 = RequestHeadersDict('User-Agent=HTTPie/1.0.0')
    s0.update_headers(r0)
    assert s0['headers'] == dict()
    r0['User-Agent'] = 'HTTPie/1.0.0'
    s0.update_headers(r0)
    assert s0['headers'] == dict()
    r0['Host'] = 'httpie.org'
    s0.update_headers(r0)
    assert s0['headers'] == dict()
    r0['User-Agent'] = 'HTTPie/1.0.0'
    s0.update_headers(r0)
    assert s0['headers'] == dict()

# Generated at 2022-06-25 19:29:51.865014
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # session_0.update_headers(request_headers_0)
    pass


# Generated at 2022-06-25 19:29:54.554771
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'P]a6R'
    list_0 = [str_0]
    session_0 = Session(str_0)
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:30:01.442322
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(str_0)
    

# Generated at 2022-06-25 19:30:02.856878
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('l~+Q[')
    session_0.update_headers({})


# Generated at 2022-06-25 19:30:05.714736
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('~/.config/httpie/sessions/httpbin.org')
    session_0.update_headers({'Accept': '*/*', 'User-Agent': 'HTTPie/1.0.2'})


# Generated at 2022-06-25 19:30:09.807568
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('K30E')
    str_0 = 'W8-v}'
    tuple_0 = (str_0,)
    session_0.remove_cookies(tuple_0)
    str_1 = '<2wK'
    tuple_1 = (str_1,)
    session_0.remove_cookies(tuple_1)


# Generated at 2022-06-25 19:30:18.147468
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('VsnW?&w}')
    session_0.update_headers({'Cookie': 'b)#T,=v-$fjC(8'})
    session_0.update_headers({'If-Match': '_<&0V7zl?.KW[V'})
    session_0.update_headers({'If-None-Match': '}F>hYl2m,q3-'})
    session_0.update_headers({'If-Modified-Since': '1/t.K>o:N'})
    session_0.update_headers({'If-Unmodified-Since': 'g<-JL!j+O'})
    session_0.update_headers({'If-Range': 'x{y,(|hLX9>'})


#

# Generated at 2022-06-25 19:30:28.027257
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    cookie_str_0 = 'User-Agent=HTTPie/0.9.8'
    cookie_str_1 = 'Cookie=_octo=GH1.1.1672848861.1469111755; logged_in=no; dotcom_user=swalladge; _ga=GA1.2.2079050515.1469111757; tz=Australia%2FMelbourne; _gat=1; __Host-user_session_same_site=HEQtA5Ipy9XH2siZ1Dk~#'
    cookie_str_2 = 'accept-encoding=gzip, deflate'
    cookie_str_3 = 'Accept=*/*'
    cookie_str_4 = 'Connection=keep-alive'

# Generated at 2022-06-25 19:30:37.026809
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cookies import CookieJar

    from httpie.core import main

    from httpie.core import main
    from httpie.input import ParseError
    from utils import http, HTTP_OK
    http('--print=BhH', '--session=test', '--auth=username:password',
         'GET', httpbin.url + '/cookies/set?hello=world')
    http('--print=BH', '--session=test', '--auth=username:password',
         'GET', httpbin.url + '/headers')
    http('--print=BhH', '--session=test', '--auth=username:password',
         'GET', httpbin.url + '/cookies')

