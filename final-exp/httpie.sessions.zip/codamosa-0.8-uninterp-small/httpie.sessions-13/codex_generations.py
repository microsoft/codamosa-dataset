

# Generated at 2022-06-25 19:20:54.541257
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    method_test_1 = session_0.remove_cookies(names)
    assert {"cookies": {}} == session_0
    method_test_2 = session_0.remove_cookies(names)
    assert {"cookies": {}} == session_0


# Generated at 2022-06-25 19:20:59.011256
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names_0 = list()
    session_0 = Session('')
    assert session_0.remove_cookies(names_0) == None


# Generated at 2022-06-25 19:21:01.641666
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:21:05.246291
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import pathlib as module_0
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    import httpie.cli.dicts
    request_headers_0 = httpie.cli.dicts.RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:21:14.010461
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    path_0 = module_0.Path()
    session_0 = Session(path_0)
    requests_cookies_1 = session_0.cookies
    httpie_cli_dicts_3 = session_0.headers
    session_0.update_headers(httpie_cli_dicts_3)
    requests_auth_6 = session_0.auth
    # FIXME: Dict does not have attribute remove_cookies
    #session_0.remove_cookies(names_5)
    #assert(session_0.get('cookies') == None)

# Generated at 2022-06-25 19:21:16.212908
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = ("foo")
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:21:19.825077
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(None)
    request_headers_0 = RequestHeadersDict(None)
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:21:31.272029
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager

    path_1 = module_0.Path()
    session_1 = Session(path_1)
    request_headers_0 = RequestHeadersDict()
    request_headers_0.add('User-Agent', 'HTTPie/1.0.0')
    session_1.update_headers(request_headers_0)
    assert session_1['headers'] == {}

    path_2 = module_0.Path()
    session_2 = Session(path_2)
    request_headers_1 = RequestHeadersDict()
    request_headers_1.add('User-Agent2', 'HTTPie/1.0.0.2')
    session_2.update_headers(request_headers_1)

# Generated at 2022-06-25 19:21:35.539877
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Instantiating a class object
    path = module_0.Path()
    session = Session(path)
    # Calling remove_cookies method
    session.remove_cookies(names = ['test'])


# Generated at 2022-06-25 19:21:42.242372
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Arrange:
    #   Create a Session object.
    path_0 = Path()
    path_0.absolute()
    session_0 = Session(path_0)
    #   Create a RequestHeadersDict object.
    request_headers_0 = RequestHeadersDict()
    def case(request_header_dict):
        return request_header_dict.keys()
    case(request_headers_0)

    # Act:
    #   Call the method update_headers on the Session object.
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:21:47.936760
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert callable(Session().remove_cookies)


# Generated at 2022-06-25 19:21:50.879128
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('mwpt4k4')
    # Should not throw exception for invalid name arg
    session_0.update_headers('', {'If-Match': '*'})


# Generated at 2022-06-25 19:21:53.505847
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    _session_0 = Session('example.com')
    request_headers_dict_0 = module_0.RequestHeadersDict()
    _session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:21:55.705990
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = 'Session'
    session = Session(path)
    request_headers = 'RequestHeadersDict'
    result = session.update_headers(request_headers)
    assert result == None


# Generated at 2022-06-25 19:21:57.071723
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path = Path(DEFAULT_SESSIONS_DIR, 'test.json'))
    session.update_headers({})


# Generated at 2022-06-25 19:21:59.160383
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(path='/Users/duckworthd/Projects/httpie/httpie/utils.py')
    names = (session_0, session_0)
    session_0.remove_cookies(names=names)


# Generated at 2022-06-25 19:22:03.648958
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    name = 'print'
    request_headers_dict_0 = module_0.RequestHeadersDict()
    session_0 = Session(path='http.session')
    session_0.update_headers(request_headers=request_headers_dict_0)

    saved_cookies = session_0.cookies
    session_0.remove_cookies(names=(name,))
    assert session_0.cookies != saved_cookies

# Generated at 2022-06-25 19:22:06.413807
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('')
    request_headers_dict_0 = module_0.RequestHeadersDict()
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:22:10.960784
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path = './test_Session')

    # Test case 0
    test_case_0()

    session.update_headers(request_headers = request_headers_dict_0)


session = Session(path = './test_Session')


# Generated at 2022-06-25 19:22:20.511102
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/home/user/.cache/httpie/sessions/test_Session_update_headers.json')
    session.load()
    request_headers_dict_0 = module_0.RequestHeadersDict()
    request_headers_dict_0['User-Agent'] = 'HTTPie/0.9.9'
    request_headers_dict_0['Content-Type'] = 'text/csv'
    session.update_headers(request_headers_dict_0)
    session.save()
    request_headers_dict_1 = module_0.RequestHeadersDict()
    request_headers_dict_1['User-Agent'] = 'HTTPie/0.9.9'
    request_headers_dict_1['Cookie'] = 'foo=bar'

# Generated at 2022-06-25 19:22:30.114407
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('home/user/httpie/.httpie/sessions/example.com/example_session.json')

    # Case 001
    request_headers_dict_0 = module_0.RequestHeadersDict()
    # Test setup
    # test body
    result = session_0.update_headers(request_headers_dict_0)
    assert result == None


# Generated at 2022-06-25 19:22:33.511255
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('session_0')
    request_headers_dict_1 = module_0.RequestHeadersDict()
    session_0.update_headers(request_headers_dict_1)



# Generated at 2022-06-25 19:22:42.654647
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import json
    import os.path
    from tempfile import mkdtemp
    from pathlib import Path

    session_path = Path(mkdtemp()) / 'session.json'
    config_dir = mkdtemp()
    config_dir = Path(config_dir)
    session_path = config_dir / 'session.json'
    session_name = 'name'

    session = get_httpie_session(config_dir, session_name, 'host', 'url')
    session['headers'] = {}
    session['cookies'] = {}
    session['auth'] = {
        'type': None,
        'username': None,
        'password': None,
        'raw_auth': None,
    }

    session.update_headers({'Content-Type': 'json'})
    session.save()


# Generated at 2022-06-25 19:22:46.337344
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.dicts import RequestHeadersDict
    session = Session('config.json')
    session.update_headers(RequestHeadersDict())
    names = ['test']
    session.remove_cookies(names)



# Generated at 2022-06-25 19:22:57.429347
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.config import DEFAULT_CONFIG_DIR, get_config_dir
    from httpie.plugins.registry import plugin_manager
    from httpie.session import Session
    from httpie.utils import get_response

    config_dir = get_config_dir()

    session_path = config_dir / 'sessions' / 'httpie' / 'example.org.json'
    session = Session(session_path)
    session.load()

    session.cookies['foo'] = {'value': 'bar'}
    assert len(session.cookies) == 1

    url = 'http://127.0.0.1'
    result = get_response(url)
    assert result.cookies.get('foo')
    assert result.cookies['foo'].value == 'bar'

    session.remove_cook

# Generated at 2022-06-25 19:23:00.328459
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    request_headers_dict_0 = module_0.RequestHeadersDict()
    session = Session('t.json')
    result = session.remove_cookies(request_headers_dict_0)
    assert result is None


# Generated at 2022-06-25 19:23:02.615157
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(path=None)
    request_headers_dict_0 = module_0.RequestHeadersDict()
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:23:04.889127
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(path='path_0')
    session_0.remove_cookies(names='names_0')


# Generated at 2022-06-25 19:23:07.526454
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session("test_Sessions_update_headers_path")
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:23:10.629285
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('/home/pablo/.config/httpie/sessions/localhost/my_session.json')
    request_headers_dict_0 = module_0.RequestHeadersDict()


# Generated at 2022-06-25 19:23:21.948532
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test")
    session['cookies'] = {'test_key': 'test_cookie'}
    assert 'test_key' in session['cookies']
    session.remove_cookies(['test_key'])
    assert 'test_key' not in session['cookies']

# Generated at 2022-06-25 19:23:23.967092
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path(path=None))
    request_headers_dict = module_0.RequestHeadersDict()


# Generated at 2022-06-25 19:23:26.966764
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session("")
    session_0.update_headers(request_headers_dict_0)

import httpie.config as module_1

dict_0 = module_1.BaseConfigDict("")


# Generated at 2022-06-25 19:23:30.161673
# Unit test for method update_headers of class Session

# Generated at 2022-06-25 19:23:32.466184
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_instance = Session(path_0)
    session_instance.remove_cookies(names_0)


# Generated at 2022-06-25 19:23:39.513288
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = ''
    session = Session(path)
    session['cookies'] = {'foo': {}, 'bar': {}}
    session.remove_cookies(('foo',))
    assert session['cookies'] == {'bar': {}}
    session.remove_cookies(('bar',))
    assert session['cookies'] == {}
    session.remove_cookies(('baz',))
    assert session['cookies'] == {}

# Generated at 2022-06-25 19:23:42.576767
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_instance_0 = Session('/.config/httpie/sessions/example.com_80/test_0.json')
    session_instance_0.load()
    session_instance_0.remove_cookies('HbNX9XLK')


# Generated at 2022-06-25 19:23:44.034897
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(None)
    session_0.remove_cookies(None)


# Generated at 2022-06-25 19:23:54.366742
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from requests.cookies import RequestsCookieJar
    session_0 = Session(path=Path())
    session_0['headers'] = {}
    session_0['cookies'] = {}
    session_0['auth'] = {'type': None, 'username': None, 'password': None}
    request_headers_dict_0 = RequestHeadersDict()
    request_headers_dict_0['User-Agent'] = 'HTTPie/1.0.2'
    request_headers_dict_0['Accept'] = '*/*'
    request_headers_dict_0['Accept-Encoding'] = 'gzip, deflate'
    request_headers_dict_0['Connection'] = 'keep-alive'
    request_headers_dict_0['Cookie'] = 'foo=bar; baz=quux'
    session_

# Generated at 2022-06-25 19:23:57.465653
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(path=Path())
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers=request_headers_0)

# Generated at 2022-06-25 19:24:21.640691
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('/home/user/httpie/doc')
    request_headers_0 = module_0.RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:24:27.713762
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_ = get_httpie_session(
        config_dir=DEFAULT_CONFIG_DIR,
        session_name='session_1',
        host=None,
        url=(),
    )
    request_headers_dict_0 = module_0.RequestHeadersDict()
    session_.update_headers(request_headers_dict_0)
    assert session_.headers == request_headers_dict_0


# Generated at 2022-06-25 19:24:28.506246
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    pass

# Generated at 2022-06-25 19:24:33.199013
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(session_name = 'username')
    request_headers_dict_0 = module_0.RequestHeadersDict()
    session_0.update_headers(request_headers_dict_0)

# Generated at 2022-06-25 19:24:40.139525
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli import name_to_openers
    headers = {'Host': 'httpbin.org'}
    auth = ('user', 'password')
    proxies = {'http': 'http://proxy.example.org:3128/'}
    verify = True
    cert = ('/path/client.crt', '/path/client.key')
    opener = name_to_openers['http'](auth, proxies, verify, cert)
    session = Session('http://example.org/')
    session.update_headers(headers)



# Generated at 2022-06-25 19:24:42.235703
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path="/httpie")
    session.remove_cookies(names=['h', 'l'])


# Generated at 2022-06-25 19:24:47.875854
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # `param` may be of any type
    # [instance]
    request_headers_dict_0 = module_0.RequestHeadersDict()
    session_0 = Session(str())
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:24:51.789159
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    session_0 = Session(path=Path(path='./test/test_sessions.json'))
    request_headers_dict_0 = RequestHeadersDict()
    session_0.update_headers(request_headers=request_headers_dict_0)

# Generated at 2022-06-25 19:24:58.196498
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from os import path
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.session import Session
    from httpie.plugins.registry import plugin_manager

    session_1 = Session(path)
    session_1.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:25:06.994067
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(path=Path(path='MyTmp/'))

    request_headers_dict_0 = module_0.RequestHeadersDict()
    request_headers_dict_0['Accept'] = '*/*'
    request_headers_dict_0['Accept-Encoding'] = 'gzip, deflate'
    request_headers_dict_0['Connection'] = 'keep-alive'
    request_headers_dict_0['Host'] = 'httpbin.org'
    request_headers_dict_0['User-Agent'] = 'HTTPie/0.9.8'
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:25:40.123915
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    session_0.update_headers({})

# Unit test 
if __name__ == '__main__':
    module_name = 'Test.test_Session'
    module_name = module_name.split('.')
    print('Running ' + module_name[len(module_name) - 1])
    for module_func in dir():
        if module_func.startswith('test'):
            print('Running ' + module_func)
            globals()[module_func]()

# Generated at 2022-06-25 19:25:41.942212
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = None
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:25:46.354813
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Declare parameters
    session_0 = Session('config')
    request_headers_0 = RequestHeadersDict()
    # Set up and invoke the function
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:25:48.560918
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # session_0 = Session(0)
    # request_headers_0 = RequestHeadersDict()
    pass


# Generated at 2022-06-25 19:25:51.859307
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:25:56.410171
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import pathlib as module_0
    path_0 = module_0.Path()
    session_0 = Session(path_0)

    import requests.cookies as module_1
    jar_0 = module_1.RequestsCookieJar()
    session_0.cookies = jar_0
    import httpie.cli.dicts as module_2
    request_headers_0 = module_2.RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:25:57.005409
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass

# Generated at 2022-06-25 19:26:08.730240
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    # Test case with arguments: <names=[0]>
    test_case_0 = [0]
    # Test case with arguments: <names=[0]>
    test_case_1 = [0]
    # Test case with arguments: <names=[0]>
    test_case_2 = [0]
    # Test case with arguments: <names=[0]>
    test_case_3 = [0]
    # Test case with arguments: <names=[0]>
    test_case_4 = [0]
    # Test case with arguments: <names=[0]>
    test_case_5 = [0]
    # Test case with arguments: <names=[0]>
    test_case_6 = [0]


# Generated at 2022-06-25 19:26:12.589070
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = {}
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:26:15.519610
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = pathlib.Path("path")
    session = Session(path)
    session.update_headers(RequestHeadersDict({}))


# Generated at 2022-06-25 19:27:00.442256
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert 1 == 1


# Generated at 2022-06-25 19:27:02.604720
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path('A')
    session_0 = Session(path_0)
    url_0 = 'http://localhost'
    session_0.update_headers(url_0)


# Generated at 2022-06-25 19:27:07.633901
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = (0,0,0,0,0)
    # replace above line with real inputs
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:27:17.595794
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.dicts import RequestHeadersDict
    session_0 = Session(pathlib.Path())
    request_headers_0 = RequestHeadersDict()
    headers_0 = session_0.headers
    name_list = []
    value_list = []
    name_list.append(str())
    value_list.append(str())
    name_list.append(str())
    value_list.append(str())
    name_list.append(str())
    value_list.append(str())
    name_list.append(str())
    value_list.append(str())
    name_list.append(str())
    value_list.append(str())
    name_list.append(str())

# Generated at 2022-06-25 19:27:21.243477
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    # first name passed as argument
    assert True

    # second name passed as argument
    assert True

# Generated at 2022-06-25 19:27:23.908946
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path("nnn")
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:27:28.553820
# Unit test for method update_headers of class Session
def test_Session_update_headers():
   path_2 = pathlib.Path()
   session_2 = Session(path_2)
   request_headers_2 = httpie.cli.dicts.RequestHeadersDict()
   assert isinstance(session_2.update_headers(request_headers_2), None) == True


# Generated at 2022-06-25 19:27:38.147918
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import ExitStatus
    from json import loads
    from tests import http, HTTP_OK
    session_path = '/tmp/httpie-z5P5o5'
    session_name = 'kennethreitz'
    raw_headers = {
        'Accept-Encoding': 'gzip, deflate',
        'Accept': '*/*',
        'User-Agent': 'python-requests/2.18.4'
    }
    headers = (
        'GET /get HTTP/1.1\r\n'
        'Accept-Encoding: gzip, deflate\r\n'
        'Accept: */*\r\n'
        'User-Agent: python-requests/2.18.4\r\n'
    )

# Generated at 2022-06-25 19:27:49.609309
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test 1
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)
    assert False
    # Test 2
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)
    assert False
    # Test 3
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)
    assert False
    # Test 4

# Generated at 2022-06-25 19:27:52.140190
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers = {}
    session_0.update_headers(request_headers)


# Generated at 2022-06-25 19:29:22.853721
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import re
    import urllib.parse
    path = pathlib.Path()
    session = Session(path)
    request_headers = {"key": "value"}
    session.update_headers(request_headers)


# Generated at 2022-06-25 19:29:27.072183
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = [('adventures'), ('delight'), ('theorist')]
    try:
        session_0.remove_cookies(names_0)
    except Exception:
        raise


# Generated at 2022-06-25 19:29:29.500602
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # Arrange
    request_headers = {}

    # Act
    session = Session(module_0.Path())
    session.update_headers(request_headers)


# Generated at 2022-06-25 19:29:32.182154
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    req_headers_0 = RequestHeadersDict()
    session_0.update_headers(req_headers_0)



# Generated at 2022-06-25 19:29:34.381173
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    headers_0 = RequestHeadersDict()
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:29:37.947027
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = Path()
    session_0 = Session(path_0)

    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)



# Generated at 2022-06-25 19:29:40.813347
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    assert session_0.remove_cookies([]) == None

import copy


# Generated at 2022-06-25 19:29:43.998485
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:29:44.550581
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    cookie_to_cookie

# Generated at 2022-06-25 19:29:46.711685
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)