

# Generated at 2022-06-25 19:20:52.857990
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('test_session')
    result = session_0.remove_cookies(None)
    assert result is None


# Generated at 2022-06-25 19:20:54.419886
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('')
    session_0.remove_cookies(dict_0)


# Generated at 2022-06-25 19:21:05.350757
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # <https://docs.python.org/3/library/unittest.mock.html>
    import unittest.mock as mock

    cookies = RequestsCookieJar()
    session_0 = Session(str())
    session_0.cookies = cookies

    headers_0 = RequestHeadersDict()
    headers_0['Content-Type'] = 'text/plain'
    headers_0['Host'] = 'localhost'
    headers_0['Authorization'] = 'Basic Sm9obiBEb2U6cGFzc3dvcmQ='
    session_0.update_headers(headers_0)

    for header in headers_0:
        assert header.lower() not in map(str.lower, SESSION_IGNORED_HEADER_PREFIXES)
    assert not session_0.headers

# Generated at 2022-06-25 19:21:06.924242
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = None
    session_1 = Session(str_1)
    dict_2 = None
    session_1.update_headers(dict_2)


# Generated at 2022-06-25 19:21:08.367630
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    headers_0 = None
    session_0.update_headers(headers_0)

# Generated at 2022-06-25 19:21:11.713868
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict(None)
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:21:13.677252
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    session_0.update_headers(None)


# Generated at 2022-06-25 19:21:17.016667
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    str_1 = 'Cookie'
    str_2 = 'Cookie'
    iterable_0 = [str_1, str_2]
    session_0.remove_cookies(iterable_0)


# Generated at 2022-06-25 19:21:20.872227
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(str())
    session.update_headers(dict())
    with raises(Exception):
        session.update_headers(dict())


# Generated at 2022-06-25 19:21:23.970517
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    param_0 = None
    session_0 = Session(param_0)
    param_0 = None
    assert session_0.update_headers(param_0) == None


# Generated at 2022-06-25 19:21:31.324711
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_3 = Session('headers')
    assert session_3.update_headers(session_3.headers) == None


# Generated at 2022-06-25 19:21:34.476772
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    str_1 = None
    names_0 = (str_1, )
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:21:38.440467
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    iterable_0 = None
    session_0.remove_cookies(iterable_0)



# Generated at 2022-06-25 19:21:43.051552
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_case_0()
    session_0 = Session(None)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)
    # Test cases and assertions follow
    # Test cases and assertions follow
    # Test cases and assertions follow
    # Test cases and assertions follow
    # Test cases and assertions follow
    # Test cases and assertions follow
    # Test cases and assertions follow


# Generated at 2022-06-25 19:21:49.296020
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    x = 0
    y = 0
    z = 0
    session_1 = Session(x)
    headers_1 = RequestHeadersDict(y)
    session_1.update_headers(headers_1)


# Generated at 2022-06-25 19:21:52.266823
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    str_1 = "abort"
    names_0 = [str_1]
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:21:54.674508
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    names_0 = None
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:22:01.144527
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'nWU6RiU6.Q&6'
    session_0 = Session(str_0)
    str_0 = 'jA'
    str_1 = 'lj'
    session_0.remove_cookies(str_0)
    assert 'cookies' in session_0


# Generated at 2022-06-25 19:22:12.001703
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli import DEFAULT_UA
    from httpie.compat import Mapping
    from httpie.models import Request, Response

    str_0 = ''
    session_0 = Session(str_0)
    str_1 = ''
    arg_0 = KeyValueArg(str_1)
    str_2 = ''
    arg_1 = KeyValueArg(str_2)
    request_headers_0 = RequestHeadersDict((arg_0, arg_1))
    session_0.update_headers(request_headers_0)
    str_3 = "Connection"
    str_4 = "keep-alive"
    request_header_0 = {str_3: (str_4,)}
    str_5 = "custom-header-2"

# Generated at 2022-06-25 19:22:21.215030
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    path_0 = Path(str_0)
    session_0 = Session(path_0)
    dict_0 = dict()
    dict_0['Accept-Encoding'] = None
    dict_0['Accept'] = None
    dict_0['User-Agent'] = None
    dict_0['Cookie'] = 'foo=bar;baz=42'
    dict_0['If-Range'] = None
    dict_0['If-Unmodified-Since'] = None
    dict_0['Host'] = None
    dict_0['Content-Type'] = None
    dict_0['Cache-Control'] = None
    dict_0['Connection'] = None
    dict_0['Content-Length'] = None
    request_headers_0 = RequestHeadersDict(dict_0)
    session_0

# Generated at 2022-06-25 19:22:34.650730
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    request_headers_0 = None
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:22:36.740257
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = None
    session_0 = Session(path_0)
    assert session_0.update_headers('headers_0') is None

# Generated at 2022-06-25 19:22:38.815358
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session()
    headers_0 = RequestHeadersDict()
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:22:41.964355
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    args_0 = []
    #Test session_0
    try:
        session_0
    except NameError:
        session_0 = Session(str_0)
    session_0.remove_cookies(args_0)


# Generated at 2022-06-25 19:22:44.502391
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'sessions/localhost/default.json'
    session_0 = Session(str_0)
    session_0.load()
    session_0.remove_cookies()

# Generated at 2022-06-25 19:22:55.470291
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    input_headers = None
    session = Session(None)
    assert session.headers == {}
    session.update_headers(input_headers)
    assert session.headers == {}
    input_headers = {}
    session.update_headers(input_headers)
    assert session.headers == {}
    input_headers = {'abc': 'abc', 'def': 'def'}
    session.update_headers(input_headers)
    assert session.headers == {'abc': 'abc', 'def': 'def'}
    input_headers = {'abc': 'def'}
    session.update_headers(input_headers)
    assert session.headers == {'abc': 'def', 'def': 'def'}
    input_headers = {'If-Match': 'def'}
    session.update_headers(input_headers)
   

# Generated at 2022-06-25 19:23:01.996847
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Get and set the Content-Type header
    host_0 = None
    url_0 = 'http://httpbin.org/get'
    arg_0 = get_httpie_session(DEFAULT_CONFIG_DIR, 'httpbin', host_0, url_0)
    arg_1 = RequestHeadersDict({'Content-Type': 'application/json'})
    assert arg_0.update_headers(arg_1) == None
    assert arg_0.get('headers') == {'Content-Type': 'application/json'}


# Generated at 2022-06-25 19:23:08.478945
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config_dir_0 = Path()
    session_name_0 = ''
    host_0 = 'localhost'
    url_0 = 'http://localhost/'
    session_0 = get_httpie_session(
        config_dir_0,
        session_name_0,
        host_0,
        url_0,
    )
    headers_0 = RequestHeadersDict(str())
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:23:18.983809
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    # cookies: {str_0: {dict_0_dummy_0}}
    # value:

# Generated at 2022-06-25 19:23:22.952670
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    str_1 = None
    session_0 = Session(str_0)
    str_2 = None
    list_0 = [
        str_2,
        str_1,
    ]
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:23:40.373183
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Given a new Session object
    session = Session("")
    # Given a new RequestHeadersDict object
    request_headers = RequestHeadersDict()

    # When the method update_headers is called with both objects as arguments
    session.update_headers(request_headers)

    # Then the result should be None
    assert session.headers == request_headers


# Generated at 2022-06-25 19:23:48.722205
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    case_0 = dict(
        return_value=test_case_0()
    )
    cases = {
        0: case_0
    }
    for case_id, case in cases.items():
        var_0 = Session.remove_cookies(**case['input'])
        if var_0 == case['return_value']:
            print("Passed for input: {0}".format(case['input']))
        else:
            print("Failed for input: {0}".format(case['input']))
            print("Expected: {0}".format(case['return_value']))
            print("Got: {0}".format(var_0))



# Generated at 2022-06-25 19:23:57.978441
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import os
    import requests
    import requests_cookiejar
    from httpie.session import Session
    from httpie import ExitStatus
    from utils import http

    session = Session(path='test_session_update_headers')
    config = httpie.client.CONFIG_DIR / 'config.json'
    config.write_text('')
    env = TestEnvironment(no_config=True, httpie_config_dir=httpie.client.CONFIG_DIR)
    r = http('GET', 'https://httpbin.org/headers', session=session, env=env)
    if r.exit_status == 0:
        pass
    else:
        print(r)
        assert r


# Generated at 2022-06-25 19:24:00.315528
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    this = Session('')
    this.update_headers({})


# Generated at 2022-06-25 19:24:03.980560
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    var_0 = []
    var_1 = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test_Session_remove_cookies', None, 'test_Session_remove_cookies')
    var_1.remove_cookies(var_0)

# Generated at 2022-06-25 19:24:08.176210
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Unit test for method remove_cookies of class Session
    httpie_session = Session("")
    httpie_session.remove_cookies("hello")


# Generated at 2022-06-25 19:24:11.706370
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # default case
    session = Session('f8WdC3yqh3y1')
    request_headers = {}
    session.update_headers(request_headers)


# Generated at 2022-06-25 19:24:13.960450
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_1 = Session(path)
    var_2 = RequestHeadersDict()
    var_1.update_headers(var_2)


# Generated at 2022-06-25 19:24:15.267583
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    var_1 = get_httpie_session()
    var_2 = []


# Generated at 2022-06-25 19:24:16.818935
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    o = test_case_0()
    o.remove_cookies([])


# Generated at 2022-06-25 19:24:34.141902
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # A test case for method update_headers of class Session
    obj = Session('/home/brian/.config/httpie/sessions/localhost/test.json')
    request_headers = {'User-Agent': 'HTTPie/1.0.0', 'Accept': '*/*'}
    obj.update_headers(self, request_headers)

# Generated at 2022-06-25 19:24:37.354566
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_0 = Session("test_case_0")
    # var_0 = Session()
    var_1 = var_0.update_headers({})
    print(var_1)

test_Session_update_headers()

# Generated at 2022-06-25 19:24:38.359249
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_case_0()

# Generated at 2022-06-25 19:24:49.507588
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_0 = Session(Path('/Users/x/.httpie/sessions/localhost/session.json'))
    var_1 = RequestHeadersDict(var_0['headers'])
    var_2 = {}
    for var_3 in var_2:
        var_4 = var_0['headers'].items()
        for var_5 in var_4:
            var_6 = str(var_5)
            var_7 = var_6.startswith('Content-')
            var_8 = var_6.startswith('If-')
            if var_7 or var_8:
                pass
            else:
                var_1[var_3] = var_5
    var_0['headers'].update(var_1)
    var_9 = var_0['headers']

# Unit

# Generated at 2022-06-25 19:24:56.504924
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    arg_0 = Session(Path('/tmp/test_httpie_session0.json'))
    arg_1 = {'If-Modified-Since': 'Fri, 15 Sep 2017 08:36:28 GMT', 'Content-Length': '0', 'Keep-Alive': 'timeout=5, max=100', 'Accept-Language': 'en-US,en;q=0.5', 'Accept-Encoding': 'gzip, deflate', 'Connection': 'keep-alive', 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'HTTPie/0.9.9', 'Accept': 'application/json'}
    arg_0.update_headers(arg_1)
    var_0 = arg_0

# Generated at 2022-06-25 19:25:08.116776
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_0 = Session([])
    var_0.var_0 = {"Content-Encoding": "gzip", "Content-Type": "application/json"}
    var_1 = RequestHeadersDict({"Content-Encoding": "gzip", "Content-Type": "application/json"})
    var_0.update_headers(var_1)
    var_0.var_0 = {"Content-Encoding": "gzip", "Content-Type": "application/json"}
    var_1 = RequestHeadersDict({"Content-Encoding": "gzip", "Content-Type": "application/json"})
    var_0.update_headers(var_1)
    var_0.var_0 = {"Content-Encoding": "gzip", "Content-Type": "application/json"}
    var_1 = Request

# Generated at 2022-06-25 19:25:12.344588
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_0 = Session(os.getcwd())
    var_1 = SimpleCookie()
    var_1 = var_1.output()
    var_0.update_headers(var_1)


# Generated at 2022-06-25 19:25:16.862832
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # one line comment
    session = Session('C:\\Users\\ohadk\\PycharmProjects\\httpie-sessions\\httpie\\sessions.json')
    # one line comment
    request_headers = 'Authorization: Bearer JWT'
    # TODO:
    # assert session.update_headers(request_headers) == None



# Generated at 2022-06-25 19:25:18.948947
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 19:25:21.367364
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Setup
    class_0 = Session(var_0)
    var_1 = []

    # Testing
    class_0.remove_cookies(var_1)



# Generated at 2022-06-25 19:25:40.703605
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import sys
    import io
    import unittest

    class SessionTests(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_000(self):
            var_0 = []
            # Variable(s) used in test case:
            test_case_0 = [1,2,3]
            # Test case 0 setup:
            # Buffer(s) used in test case:
            var_0.append(test_case_0)

            # Test case 0 assertion(s):
            self.assertIs(var_0, [1,2,3])

    files = {
        '__main__':
"""
if __name__ == '__main__':
    unittest.main()
""",
    }


# Generated at 2022-06-25 19:25:46.293755
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_0 = RequestsCookieJar()
    var_1 = {}
    var_1['httpbin.org'] = {}
    var_1['httpbin.org']['/cookies'] = var_0

# Generated at 2022-06-25 19:25:47.382892
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_case_0()

# Generated at 2022-06-25 19:25:50.461096
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    args = []
    kwargs = {
        "request_headers": RequestHeadersDict()
    }
    target = Session(Path())
    target.update_headers(*args, **kwargs)


# Generated at 2022-06-25 19:25:57.354522
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    var_0 = []
    var_0.append(create_cookie('bar', '2', expires=None, secure=False,
                               path='/'))
    var_0.append(create_cookie('foo', '1', expires=None, secure=True,
                               path='/'))
    var_0.append(create_cookie('baz', '3', expires=None, secure=False,
                               path='/'))
    var_0 = RequestsCookieJar()
    for var_1 in var_0:
        var_0.set_cookie(var_1)
    var_0.add_cookie_header({})
    var_0.clear_expired_cookies()
    var_1 = RequestsCookieJar()
    var_1.update(var_0)
    var_2

# Generated at 2022-06-25 19:26:01.106151
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Initialization
    var_0 = Session('')
    var_1 = []
    # Call function update_headers of var_0 for parameter var_1
    test_case_0()


# Generated at 2022-06-25 19:26:02.572019
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print("Testing update_headers of class Session")
    # initializing simple variables, the most complex being a class object
    self = test_case_0()
    request_headers = {}

    # executing the method under test
    self.update_headers(request_headers)


# Generated at 2022-06-25 19:26:03.569369
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_case_0()

# Generated at 2022-06-25 19:26:10.883387
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('path'))
    session.session_name='6e1b6c5ab6a5f6f65bdbfd95fdcec5fd'
    headers = RequestHeadersDict({'X-Forwarded-For': '192.0.2.1'})
    session.update_headers(request_headers=headers)
    # See if the method is working properly
    assert session.headers==headers

test_case_0()

# Generated at 2022-06-25 19:26:14.037375
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    #some values for method
    var_0 = []
    for name in var_0:
        if name in self['cookies']:
            del self['cookies'][name]


# Generated at 2022-06-25 19:26:46.324840
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # var_0: Session = Session('/root/.httpie/sessions/httpie.org/default.json')
    var_0 = Session('./data/sessions/httpie.org/default.json')
    var_0.load()
    # var_1: RequestHeadersDict = {}
    var_1 = {}
    # var_2: str = 'User-Agent'
    var_2 = 'User-Agent'
    # var_3: str = 'HTTPie/0.9.8'
    var_3 = 'HTTPie/0.9.8'
    var_1.setdefault(var_2, var_3)
    # var_4: str = 'Accept'
    var_4 = 'Accept'
    # var_5: str = '*/*'

# Generated at 2022-06-25 19:26:51.696989
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_0 = Session('')
    var_1 = ''
    var_0.update_headers(var_1)
    # Expected Exception: AssertionError
    # - The method update_headers should throw an AssertionError when called with var_1 as argument
    assert False


# Generated at 2022-06-25 19:26:57.753805
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import _httpie.sessions
    var_0 = _httpie.sessions.RequestHeadersDict({'User-Agent': 'Mozilla'})
    var_1 = _httpie.sessions.Session(Path('/path/to/file.json'))
    var_2 = var_1.update_headers(var_0)

# Generated at 2022-06-25 19:27:00.761814
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Init var_0
    var_0 = []

    # Local variable declarations
    var_1 = []
    var_2 = None

    # Class init
    session = Session(path=var_0)
    session.load()

    # Method test
    var_2 = session.remove_cookies(var_1)
    return var_2

# Generated at 2022-06-25 19:27:03.171249
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    var_1 = [Session({})]
    test_case_0()
    var_1[0].remove_cookies(var_0)


# Generated at 2022-06-25 19:27:08.858365
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print("testing whether Session can update headers")
    # Test case 0
    session = Session("test")
    headers = {'test': 'test', 'test2': 'test2'}
    session.update_headers(headers)
    assert session['headers'] == headers
    print("Session can succesfully update headers")


# Generated at 2022-06-25 19:27:11.847213
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_0 = Session('/tmp/some.json')
    var_1 = []
    var_0.update_headers(var_1)


# Generated at 2022-06-25 19:27:22.900127
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import inspect
    import sys
    import string

    def signature(f):
        return inspect.getsource(f).split('=')[0].strip()

    def deindent(s):
        lines = s.strip().splitlines()
        return '\n'.join(line.lstrip() for line in lines)

    def check(test, expected_signature, expected_doc):
        got_signature = signature(test)
        if got_signature != expected_signature:
            print('ERROR: signature[{0}][{1}]'.format(test.__name__, got_signature))

        got_doc = deindent(test.__doc__ or '')

# Generated at 2022-06-25 19:27:32.364461
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config_dir = DEFAULT_CONFIG_DIR
    session_name = 'default'

    # test_case0
    httpie_session = get_httpie_session(config_dir, session_name)
    # RequestHeadersDict
    request_headers = RequestHeadersDict({'Content-Type': 'application/json', 'Host': 'httpbin.org'})
    httpie_session.update_headers(request_headers)
    # AssertionError:  != {'connection': 'keep-alive', 'accept': '*/*'}
    httpie_session.headers
    # AssertionError:  != {'Content-Type': 'application/json', 'Host': 'httpbin.org'}
    request_headers    # RequestHeadersDict

    # test_case1
    httpie_session = get

# Generated at 2022-06-25 19:27:36.594710
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    pass
    # var_0 = Session()  # TODO: mock instance of Session
    # var_1 = []  # TODO: mock instance of RequestHeadersDict
    # var_0.update_headers(var_1)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 19:28:11.288524
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('path_0')
    request_headers_0 = {'Accept': 'text/html', 'Accept-Encoding': 'gzip, deflate'}
    session_0.update_headers(request_headers_0)
    assert session_0 == {'cookies': {}, 'headers': {'Accept': 'text/html',
        'Accept-Encoding': 'gzip, deflate'}, 'auth': {'type': None, 'username':
        None, 'password': None}}
    session_1 = Session(((DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME) / 'hostname_0')
        / 'session_name.json')
    session_1.set('headers', 'value_0')
    session_1.set('cookies', 'value_1')
    session_1

# Generated at 2022-06-25 19:28:21.578439
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.compat import str
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins import plugin_manager
    from httpie.output.streams import StdoutBytesIO
    from httpie import ExitStatus
    from mock import patch
    from requests.structures import CaseInsensitiveDict
    from tempfile import TemporaryDirectory
    config = Config(colors=256)
    env = Environment(
        stdin=None,
        stdout=StdoutBytesIO(),
        stderr=StdoutBytesIO(),
        verify=True,
        config=config
    )
    # Assigning arguments and context:
    args = []
    args.append(str('http'))

# Generated at 2022-06-25 19:28:24.640198
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    directory_0 = None
    str_0 = None
    str_1 = None
    str_2 = None
    session_0 = Session(directory_0)
    session_0.update_headers(str_0, str_1, str_2)


# Generated at 2022-06-25 19:28:30.499831
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    names_0 = ()
    session_0.remove_cookies(names_0)
    # unit-tests.py::test_Session_remove_cookies::<locals>::None
    names_1 = ()
    session_0.remove_cookies(names_1)
    # unit-tests.py::test_Session_remove_cookies::<locals>::ValueError
    names_2 = ()
    session_0.remove_cookies(names_2)
    # unit-tests.py::test_Session_remove_cookies::<locals>::TypeError
    names_3 = ()
    session_0.remove_cookies(names_3)
    # unit-tests.py::test_Session_remove_cookies::<

# Generated at 2022-06-25 19:28:32.585598
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    session_0.update_headers(str_0)

# Generated at 2022-06-25 19:28:39.893569
# Unit test for method update_headers of class Session
def test_Session_update_headers(): 
    # Arrange
    str_0 = None
    session_0 = Session(str_0)
    request_headers_0 = {}
    request_headers_0 = {}
    request_headers_0['Content-Type'] = 'Content-Type'
    request_headers_0['user-agent'] = 'user-agent'
    request_headers_0['cookie'] = 'cookie'
    expected_value_0 = session_0

    # Act
    session_0.update_headers(request_headers_0)

    # Assert
    assert session_0 == expected_value_0


# Generated at 2022-06-25 19:28:49.403629
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    headers_0: RequestHeadersDict = {}
    session_0.update_headers(headers_0)
    str_1 = None
    session_1 = Session(str_1)
    headers_1: RequestHeadersDict = {'key': 'value'}
    session_1.update_headers(headers_1)
    str_2 = None
    session_2 = Session(str_2)
    headers_2: RequestHeadersDict = {'key': 'value'}
    session_2.update_headers(headers_2)
    str_3 = None
    session_3 = Session(str_3)
    headers_3: RequestHeadersDict = {'key': 'value'}
    session_3.update_headers

# Generated at 2022-06-25 19:28:51.173786
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    names_0 = [None]
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:28:53.415205
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    dict_0 = None
    session_0.update_headers(dict_0) # Possibly null pointer dereference

# Generated at 2022-06-25 19:28:59.483116
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:30:02.962717
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.compat import is_py26
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.request import Request
    from httpie.plugins.builtin import HTTPBasicAuth
    from requests.auth import AuthBase

    session_0 = Session('7XH*tjd]x)@2eC')
    session_0.load()
    if is_py26:
        str_0 = ';'
    else:
        str_0 = ': '
        str_1 = 'b'
    request_headers_0 = RequestHeadersDict()
    request_headers_0['Host'] = 'www.example.com'
    request_headers_0['user-agent'] ='HTTPie/1.0.0'

# Generated at 2022-06-25 19:30:05.477076
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    arg0 = Session('/home/src_dst/')
    arg1 = {'Host': 'httpbin.org'}
    arg0.update_headers(arg1)


# Generated at 2022-06-25 19:30:07.913530
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = None
    session_1 = Session(str_1)
    body_params_1 = None
    headers_1 = {}
    session_1.update_headers(headers_1)


# Generated at 2022-06-25 19:30:10.081516
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = None
    session_1 = Session(str_1)
    headers_1 = RequestHeadersDict()
    session_1.update_headers(headers_1)


# Generated at 2022-06-25 19:30:15.858992
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from unittest import TestCase
    from unittest import main as unit_test_main

    from httpie.plugins.builtin import HTTPBasicAuth

    class TestSessionRemoveCookies(TestCase):
        def test_remove_cookies(self):
            http_auth = HTTPBasicAuth()
            session = Session('')

            session.cookies = RequestsCookieJar()
            session.cookies.set_cookie(create_cookie(
                'cookie-name', 'cookie-value'
            ))
            session.auth = {
                'type': 'Basic',
                'raw_auth': 'basic-auth-value'
            }
            session.remove_cookies({'cookie-name'})
            self.assertNotIn('cookie-name', session['cookies'])

# Generated at 2022-06-25 19:30:19.077675
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    request_headers_0 = None
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:30:29.235895
# Unit test for method remove_cookies of class Session

# Generated at 2022-06-25 19:30:31.203995
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert True

# Generated at 2022-06-25 19:30:38.822212
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = None
    session_0 = Session(path_0)
    dict_0 = {"Accept-Language": "en-US,en;q=0.5", "Accept-Charset": None, "Accept-Encoding": "gzip, deflate", "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:57.0) Gecko/20100101 Firefox/57.0", "Connection": "close"}
    dict_1 = {"Accept-Language": "en-US,en;q=0.5", "Accept-Charset": None, "Accept-Encoding": "gzip, deflate"}
    session_0.update_headers(dict_0)
    assert dict_1 == dict_0

# Generated at 2022-06-25 19:30:44.827613
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    var_0 = str()
    str_0 = str()
    str_1 = None
    session_0 = Session(str_1)
    bytes_0 = bytes()
    class_0 = create_cookie(var_0, str_0, bytes_0)
    assert class_0.value == str()
    assert class_0.name == str()
    assert class_0.path == str()
