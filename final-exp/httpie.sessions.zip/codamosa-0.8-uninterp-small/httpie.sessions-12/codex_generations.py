

# Generated at 2022-06-25 19:20:58.453110
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_1 = Path('/Users/daviddangelo/.config/httpie/sessions/localhost/github.json')
    session_1 = Session(path_1)
    headers_1 = RequestHeadersDict({'Head': b'Er'})
    session_1.update_headers(headers_1)


# Generated at 2022-06-25 19:21:02.668972
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_1 = None
    request_headers_0 = {
        'x-2': '4',
        ':method': 'GET',
        'x-1': '3',
        'x-0': '2'
    }
    session_1.update_headers(request_headers_0)


# Generated at 2022-06-25 19:21:05.781986
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('/bin')
    request_headers_0 = RequestHeadersDict(dict)
    RequestHeadersDict.__init__(request_headers_0, '/bin', 'host')
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:21:09.316323
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config_dir = Path(r'./')
    session_name = 'httpie'
    host = None
    url = 'http://127.0.0.1/api/'
    httpie_session = get_httpie_session(config_dir, session_name, host, url)
    httpie_session.update_headers({'a': 'b'})
    assert httpie_session['headers'] == {'a': 'b'}, '__main__.Session.update_headers failed'

# Generated at 2022-06-25 19:21:10.400813
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_case_0()

# Generated at 2022-06-25 19:21:17.434729
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    with open("test_Session_update_headers.json", "r+") as f:
        data = json.load(f)
        f.seek(0)
        json.dump(fix_json(data, "test_Session_update_headers"), f, indent=2, sort_keys=True)
        f.truncate()
    print("Returns nothing, modifies internal structure")


# Generated at 2022-06-25 19:21:20.330886
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('session.json')
    session_0.update_headers(session_0)

# Generated at 2022-06-25 19:21:25.269526
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    str_1 = '\n\n    '
    request_headers_0 = RequestHeadersDict(str_1)
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:21:27.189579
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('.')
    session_0.update_headers(RequestHeadersDict())


# Generated at 2022-06-25 19:21:35.955904
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session("/tmp/azcpi1iz/")
    session_0.headers["accept-encoding"] = "gzip"
    session_0.headers["content-type"] = "application/json"
    session_0.headers["accept"] = "*/*"
    session_0.headers["user-agent"] = "HTTPie/0.11.0"
    session_0.headers["content-length"] = "0"
    session_0.headers["host"] = "127.0.0.1:45355"
# unit tests end here


# Generated at 2022-06-25 19:21:41.808889
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('sessions')
    assert session_0.update_headers({}) == None


# Generated at 2022-06-25 19:21:53.685163
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\b\n"4\x19\x1f\x1d\n=\x1f\\\x03\x01:\x18\'\x18\x06\x1d\x1b\x17\x16\x1b\x18\x06\x10\x01\n\x1a\n\x1b\x1f\x18\x10\x1d\x1b\x1c\x0f\x06\x06'
    path_1 = Path(str_0)
    dict_0 = {}
    request_headers_0 = RequestHeadersDict(dict_0)
    session_0 = Session(path_1)
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:21:55.362374
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(str_0)
    # assert all(session_0.update_headers() == str_0)


# Generated at 2022-06-25 19:21:56.961393
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:22:01.840840
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Retrieve a session file.
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    # Retrieve a list of cookie names.
    str_1 = '\n\n    '
    list_0 = str_1.split('\n')
    # Remove the cookies from the session
    session_0.remove_cookies(list_0)
    # Check that the cookies have been removed from the session.


# Generated at 2022-06-25 19:22:03.986188
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('hypotheses')
    session_0.update_headers({})


# Generated at 2022-06-25 19:22:06.733155
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_value_0 = list()
    session_0 = Session(Path())
    name_0 = list(session_0.keys())[0]
    session_0.remove_cookies(name_0)


# Generated at 2022-06-25 19:22:08.267311
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(str_0)
    session_0.update_headers(arg_0)


# Generated at 2022-06-25 19:22:12.427464
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    dict_0 = dict()
    session_0.update_headers(dict_0)


# Generated at 2022-06-25 19:22:16.086732
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    names_0 = ['names_0']
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:22:27.738747
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/httpie_2018-02-01_20-08-42.json')
    session.load()
    session.remove_cookies([])
    assert False

import httpie.plugins.registry as module_1


# Generated at 2022-06-25 19:22:32.204782
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Setup
    session = Session('sessions/example.org/test_Session_remove_cookies_0.json')
    session.load()
    names = {}

    # Exercise
    session.remove_cookies(names)

    # Verify
    assert True


# Generated at 2022-06-25 19:22:33.468404
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass



import httpie.cli.dicts as module_1


# Generated at 2022-06-25 19:22:35.564092
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(path=Path())
    session_0.update_headers(request_headers=request_headers_dict_0)


# Generated at 2022-06-25 19:22:38.128751
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_Session_update_headers_0_arg_0 = Session( )
    test_Session_update_headers_0_arg_1 = module_0.RequestHeadersDict()


# Generated at 2022-06-25 19:22:41.255555
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(None)
    request_headers_dict_0 = module_0.RequestHeadersDict()
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:22:48.778676
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    session_0 = Session(None)
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    # boiler plate ()
    session_0.remove_cookies(None)


# Generated at 2022-06-25 19:22:51.550595
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(path=Path(path_0))
    session_0.update_headers(request_headers=request_headers_dict_0)


# Generated at 2022-06-25 19:22:54.490471
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session.cookies = {'name': 'value'}
    session.remove_cookies(['name'])
    assert session.cookies != {'name': 'value'}

# Generated at 2022-06-25 19:23:02.511136
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('')
    request_headers_dict_0 = module_0.RequestHeadersDict()
    request_headers_dict_0['Host'] = '127.0.0.1:8000'
    request_headers_dict_0['User-Agent'] = 'HTTPie/0.12.0'
    request_headers_dict_0['Accept-Encoding'] = 'gzip, deflate'
    request_headers_dict_0['Accept'] = '*/*'
    request_headers_dict_0['Connection'] = 'keep-alive'
    session_0.update_headers(request_headers_dict_0)

import httpie.config as module_0


# Generated at 2022-06-25 19:23:14.703733
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    request_headers_dict_0 = RequestHeadersDict({'User-Agent': 'httpie/0.9.3', 'Foo': 'bar'})
    # session_0.update_headers(request_headers_dict_0)
    assert session_0.headers == RequestHeadersDict({'User-Agent': 'httpie/0.9.3', 'Foo': 'bar'})


# Generated at 2022-06-25 19:23:19.672877
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Set up test values
    session_0 = Session(str_1)
    session_0.update_headers(request_headers_0)
    # Call the method
    session_1 = session_0.update_headers(request_headers_1)
    # Verify the results
    assert(session_0 == session_1)



# Generated at 2022-06-25 19:23:23.629898
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 19:23:26.026674
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    session_0 = Session(str)
    str_0 = '\n\n    '
    session_0.remove_cookies(str_0)


# Generated at 2022-06-25 19:23:29.744412
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    strlist_0 = ['    ', 'header', 'header']
    strlist_0_copy = strlist_0.copy()
    session_0.remove_cookies(strlist_0)
    assert strlist_0 == strlist_0_copy


# Generated at 2022-06-25 19:23:40.835018
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    _arg_request_headers = RequestHeadersDict()
    _arg_request_headers['Content-Type'] = 'application/json'
    _arg_request_headers['Accept'] = '*/*'
    _arg_request_headers['Cookie'] = 'secret=123456789'
    _arg_request_headers['User-Agent'] = 'HTTPie/2.2.0'
    _arg_request_headers['X-GitHub-OTP'] = '123456'
    _arg_request_headers['X-Requested-With'] = 'XMLHttpRequest'
    _arg_request_headers['X-Requested-With'] = 'XMLHttpRequest'
    path_0 = '/home/httpie/.config/httpie/sessions/heapoverflow_com/test.json'
    session_0

# Generated at 2022-06-25 19:23:43.199743
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path('path'))
    request_headers: RequestHeadersDict = {}
    session.update_headers(request_headers)
    assert isinstance(session, Session)


# Generated at 2022-06-25 19:23:49.731686
# Unit test for method update_headers of class Session
def test_Session_update_headers():
  json_dict = {
    'auth': {
      'password': None,
      'type': None,
      'username': None},
    'cookies': {},
    'headers': {}}
  session = Session(json_dict)
  request_headers = RequestHeadersDict()
  session.update_headers(request_headers)
  assert session.headers == RequestHeadersDict()
  assert session.cookies == RequestsCookieJar()
  assert session.auth == None


# Generated at 2022-06-25 19:23:51.853997
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_0 = Session(str_0)

# Draw a nested map of data structures

# Generated at 2022-06-25 19:24:03.369104
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Create a new session s with a base configuration
    s = Session('config.json')
    # Define new request headers for s
    request_headers = {
        'User-Agent': 'HTTPie/0.9.9',
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate'
    }
    # Verify that s has no headers at the beginning
    assert len(s['headers']) == 0

    # Update s's headers with the new request headers
    s.update_headers(request_headers)

    # Verify that s's headers have been updated with the new headers
    assert len(s['headers']) == 3
    for name, value in s['headers'].items():
        assert name in request_headers.keys()
        assert value == request_headers[name]

# Generated at 2022-06-25 19:24:14.790278
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict()
    try:
        session_0.update_headers(request_headers_0)

    except Exception as e:
        print('Cannot execute function update_headers')
        print(e)
        assert False


# Generated at 2022-06-25 19:24:22.243093
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    requestHeadersDict_0 = {'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'Cache-Control': 'max-age=0', 'Connection': 'keep-alive', 'Host': 'httpbin.org', 'User-Agent': 'HTTPie/0.9.9'}
    session_0.update_headers(requestHeadersDict_0)

# Generated at 2022-06-25 19:24:34.329099
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    with open('test/sessions/test_update_headers') as f:
        data = f.read()
    config = json.loads(data)

    # Initialize the headers dict with data from test file
    headers = {}
    for header in config['headers']:
        headers[header['name']] = header['value']
    request_headers = RequestHeadersDict(headers)

    session_0 = Session('test_session_0')
    session_0.update_headers(request_headers)

    with open('test/sessions/test_update_headers_output') as f:
        data = f.read()
    config = json.loads(data)
    expected_headers = {}
    for header in config['headers']:
        expected_headers[header['name']] = header['value']


# Generated at 2022-06-25 19:24:37.190973
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    names_0 = []
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:24:39.721605
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = '\n\n    '
    session_1 = Session(str_1)
    assert session_1.headers == {}


# Generated at 2022-06-25 19:24:47.473699
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    str_1 = '\n\n    '
    request_headers_0 = RequestHeadersDict(str_1)
    session_0.update_headers(request_headers_0)
    str_2 = '\n\n    '
    request_headers_1 = RequestHeadersDict(str_2)
    session_0.update_headers(request_headers_1)
    request_headers_0 = RequestHeadersDict()
    request_headers_0['Content-TyPe'] = 'application/json'
    request_headers_0['User-AgeNt'] = 'HTTPie/1.0.3'
    request_headers_0['Content-TyPe'] = 'text/html'
    request_

# Generated at 2022-06-25 19:24:49.002062
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_1 = '\n\n    '
    session_1 = Session(str_1)
    list_0 = ['\n\n    ']
    session_1.remove_cookies(list_0)


# Generated at 2022-06-25 19:24:51.049108
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:24:57.240405
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    request_headers_0 = {}
    session_0.update_headers(request_headers_0)
#

# Generated at 2022-06-25 19:25:08.116484
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test case for method update_headers of class Session
    import httpie.__main__
    from unittest.mock import patch

    text = (
        '\n        HTTP/1.1 200 OK\n        Content-Type: '
        'application/json\n        Date: Sun, 20 Sep 2020 '
        '21:43:08 GMT\n        Connection: keep-alive\n        '
        'Content-Length: 294\n        \n        {\n            '
        '"message": "Hello World",\n            "status": 200\n        '
        '}\n        '
    )
    str_0 = '\n    '
    str_1 = '\n        HTTP/1.1 200 OK\n        Content-Type: '

# Generated at 2022-06-25 19:25:21.019168
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session("cookie")
    #unit test for argument type Iterable
    try:
        names_0 = "cookie"
        session_0.remove_cookies(names_0)
    except TypeError as error_0:
        print(error_0)


# Generated at 2022-06-25 19:25:22.618141
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_case_0()

# Generated at 2022-06-25 19:25:24.364554
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    names_0 = [
        'a',
        'y',
        'a'
    ]
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:25:34.035951
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from random import randint, random
    from string import ascii_lowercase as lowercase
    from http.cookies import SimpleCookie
    from pathlib import Path
    from urllib.parse import urlsplit
    sessions_dir_name = 'sessions'
    default_sessions_dir = DEFAULT_CONFIG_DIR / sessions_dir_name
    valid_session_name_pattern = re.compile('^[a-zA-Z0-9_.-]+$')
    session_ignored_header_prefixes = ['Content-', 'If-']
    str_2 = '\n\n    '
    session_0 = Session(str_2)
    str_3 = '\n\n    '
    session_2 = Session(str_3)

# Generated at 2022-06-25 19:25:40.093765
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_1 = Session(str_0)
    session_1.load()
    
    # Case 0
    request_headers_0 = {
        'Cookie' : '',
        'Content-Type' : 'application/json',
        'Origin' : 'http://www.httpbin.org'
        }
    
    session_1.update_headers(request_headers_0)

    
    

# Generated at 2022-06-25 19:25:45.580857
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test when case of headers is none
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    request_headers_dict_0 = {
        'If-Match': '"737060cd8c284d8af7ad3082f209582d"',
    }
    session_0.update_headers(request_headers_dict_0)



# Generated at 2022-06-25 19:25:51.897303
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config_dir_0 = Path('./config')
    session_name_0 = 'session_name'
    host_0 = 'www.example.com'
    url_0 = 'https://httpie.org/'
    session_0 = get_httpie_session(config_dir_0, session_name_0, host_0, url_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:25:54.656797
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    # Step 0: Initialization
    session_0.update_headers()
    # Step 1: Test post-condition assertion
    assert False


# Generated at 2022-06-25 19:25:57.876637
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    def test():
        request_headers_0 = RequestHeadersDict()
        session_0 = Session()
        session_0.update_headers(request_headers_0)
    test()


# Generated at 2022-06-25 19:26:08.179526
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    param_0 = {'key': 'value'}
    cookie_0 = SimpleCookie()
    jar_0 = RequestsCookieJar()
    for name_0, morsel_0 in cookie_0.items():
        jar_0.set_cookie(create_cookie(name_0, morsel_0.value))
    cookie_0 = jar_0.clear_expired_cookies()
    names_0 = {'value'}
    print(cookie_0)
    print(names_0)
    session_0 = Session({'value'})
    session_0.cookies = cookie_0
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:26:17.859668
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('sessions/localhost/default')

    # Test 1 : check if remove_cookies updates the session with the new value
    cookie = {'cookie_name': 'cookie_value'}
    session.update(cookie)
    assert session['cookie_name'] == 'cookie_value'

    # Test 2 : check if remove_cookies actually deletes the cookie from session
    session.remove_cookies(['cookie_name'])
    assert 'cookie_name' not in session.keys()


# Generated at 2022-06-25 19:26:25.373261
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '7w?'
    str_1 = ')'
    path_0 = Path(str_0)
    str_2 = "h+a'\x1c\t\x1b\x1c"
    list_0 = [str_0, str_1, str_2]
    name_0 = '@\x1b'
    num_0 = -54
    tuple_0 = (num_0,)
    set_0 = set(tuple_0)
    dict_0 = {
        path_0: set_0,
        name_0: list_0,
        '_?#i': name_0
    }
    names_0 = dict_0.values()
    str_3 = ','
    path_1 = Path(str_3)

# Generated at 2022-06-25 19:26:28.852923
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    list_0 = ['\x0e', '\x0e', '\x0e', '\x0e', '\x0e']
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:26:40.318209
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./sessions/httpie/sometest.json')
    # Test case 0, remove_cookies
    # Necessary for test case
    str = '\n\n    '
    session = Session(str)
    str = '\n\n\t cookies\n\n\n\'[]'
    assert session.remove_cookies(str) == None
    # Necessary for test case
    str = '\n\n\t cookies\n\n\n\'[]'
    session = Session(str)
    str = '\n\n\t cookies\n\n\n\'[]'
    assert session.remove_cookies(str) == None
    # Necessary for test case
    str = '\n\n\t cookies\n\n\n\'[]'
    session

# Generated at 2022-06-25 19:26:43.605989
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names_0 = 'zdfg'
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:26:45.903295
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Initialization
    str_0 = ''
    session_0 = Session(str_0)
    # Check the method call
    session_0.remove_cookies(['cookies'])


# Generated at 2022-06-25 19:26:53.118719
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(Path('/tmp/testsession.json'))
    session_0['headers'] = {'hello': 'world'}
    session_0['cookies'] = {'hello': 'world'}
    session_0['auth'] = {'type': None, 'username': None, 'password': None}
    session_0.remove_cookies({'hello'})
    assert [('hello', 'world')] == list(session_0['cookies'].items())


# Generated at 2022-06-25 19:26:54.413739
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert True


# Generated at 2022-06-25 19:26:58.047988
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    file_0 = 'f08c71da-0119-11eb-8faf-2000c9d4344a'
    instance = Session(file_0)
    instance.update_headers(None)


# Generated at 2022-06-25 19:27:01.743396
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    # Initialize argument.
    names = ['Px_'+('%q' % str(i)) for i in range(100)]
    # Call function.
    session_0.remove_cookies(names)


# Generated at 2022-06-25 19:27:07.248162
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('./foo')
    assert True  # TODO: implement your test here



# Generated at 2022-06-25 19:27:15.603328
# Unit test for method remove_cookies of class Session

# Generated at 2022-06-25 19:27:24.651282
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    header_0 = RequestHeadersDict()
    header_1 = RequestHeadersDict()
    header_1['User-Agent'] = 'HTTPie/0.9.3'
    header_1['Accept'] = '*/*'
    header_1['Content-Type'] = 'application/x-www-form-urlencoded; charset=utf-8'
    header_1['Content-Length'] = '46'
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    session_0.update_headers(header_1)
    assert type(session_0) == Session
    

# Generated at 2022-06-25 19:27:28.167421
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    request_headers_0 = {}
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:27:31.086378
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('session_0')
    session_0.load()
    request_headers_0 = {'Accept': 'application/json'}
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:27:35.214146
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    optional_str_0 = 'O;E2{.XNXJ"2u'
    str_0 = "\n\t\r\t\r"
    session_0 = Session(str_0)
    names_0 = ['nMw!+']
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:27:40.609516
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    str_1 = '\n'
    list_0 = [str_1]
    session_0.remove_cookies(list_0)

if __name__ == '__main__':
    test_case_0()
    test_Session_remove_cookies()

# Generated at 2022-06-25 19:27:50.102670
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    url_0 = 'http://127.0.0.1:80/'
    session_0 = get_httpie_session(Path('C:\\Users\\Benjamin\\PycharmProjects\\httpie_plugins\\httpie_pkce_auth_plugin\\tests'), 'pytest_httpie', '', url_0)

# Generated at 2022-06-25 19:27:54.295864
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Initialize a Session object.
    session_0 = Session('localhost')
    # Create a RequestHeadersDict object.
    request_headers_dict_0 = RequestHeadersDict()
    # Update the session headers with the request ones while ignoring certain name prefixes.
    assertTrue(session_0.update_headers(request_headers_dict_0))


# Generated at 2022-06-25 19:28:04.171973
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('.')
    str_0 = 'ep-k78ge'
    str_1 = 'UjVmU'
    request_headers_0 = session_0.headers
    session_0.update_headers(request_headers_0)
    session_0 = Session('.')

    request_headers_1 = {
        'qw7': ':Accept',
        'User-Agent': 'httpie/0.9.8',
        str_0: '"d-2xi"',
        'Content-Type': 'application/json'
    }
    session_0.update_headers(request_headers_1)
    session_0 = Session('.')


# Generated at 2022-06-25 19:28:17.912215
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    def method_under_test(str_0 = '\n\n    '):
        session_0 = Session(str_0)
        names = [method_under_test.__name__, method_under_test.__doc__]
        session_0.remove_cookies(names)
# test cases
test_case_0()
test_Session_remove_cookies()

# Generated at 2022-06-25 19:28:21.057657
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Initialization
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    # Execution
    assert session_0.remove_cookies([])


# Generated at 2022-06-25 19:28:28.560179
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test for method update_headers of class Session
    print('Unit tests for method update_headers of class Session')
    # Test #0
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    print('Test #0:')
    try:
        session_0.update_headers()
        print('Success: update_headers worked without raising exceptions')
    except:
        print('FAILED: update_headers raises exceptions')
    # Test #1
    headers_1 = {'host': 'host'}
    str_1 = '\n\n    '
    session_1 = Session(str_1)
    print('Test #1:')

# Generated at 2022-06-25 19:28:38.191967
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test for method remove_cookies(self, names: Iterable[str])
    session_0 = Session('/tmp/httpie5359057641025722466.json')
    str_0 = 'foo'
    str_1 = 'bar'
    str_2 = 'baz'
    dict_0 = dict({str_0: str_0, str_1: str_1, str_2: str_2})
    session_0.cookies = dict_0
    list_0 = []
    list_1 = [str_0, str_1]
    session_0.remove_cookies(list_1)
    dict_1 = dict({str_2: str_2})
    assert dict_1 == session_0.cookies


# Generated at 2022-06-25 19:28:47.780399
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    str_1 = '\n    # HTTPie session file\n    # https://httpie.org/doc#sessions\n    \n    {\n        \n        \n    }\n\n    '
    session_0.save(path=str_1)
    str_2 = '    # HTTPie session file\n    # https://httpie.org/doc#sessions\n    \n    {\n        \n        \n    }\n\n    '
    str_3 = '\n    # HTTPie session file\n    # https://httpie.org/doc#sessions\n    \n    {\n        \n        \n    }\n\n    '

# Generated at 2022-06-25 19:28:56.307779
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import random
    for i in range(1000):
        session_0 = Session("\n\n    ")
        #random str
        names_0 = [str(i) for i in range(random.randint(0, 100))]
        session_0.remove_cookies(names_0)


try:
    from httpie.plugins.registry import plugin_manager
except ImportError:
    pass
else:
    # Unit test for method get_auth of class Session
    def test_Session_get_auth():
        import random
        auth_0 = {'username':None,'password':None,'type':None}
        session_1 = Session("\n\n    ")
        auth_1 = session_1.auth

# Generated at 2022-06-25 19:29:02.299535
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Case 0:
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    names_0 = ''
    session_0.remove_cookies(names_0)
    assert isinstance(session_0, Session)
    assert session_0.path == str_0


# Generated at 2022-06-25 19:29:05.728343
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('TestSession/test')
    session_0.save()
    session_0.load()
    request_headers = {'User-Agent': 'Test User-Agent'}
    session_0.update_headers(request_headers)
    session_0.save()

# Generated at 2022-06-25 19:29:11.575585
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('~/.httpie/sessions')
    str_0 = 'HW\x00LD'
    str_1 = 'X-QVu^L-c%7<;C6~DJ\x7fI'
    str_2 = '\x05\x7f'
    str_3 = '\x00\x7f\x7f\x7f\x00'
    str_4 = '\x7f\x05\x05\x7f\x05\x7f'

# Generated at 2022-06-25 19:29:12.813654
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    session_0.remove_cookies(str_0)


# Generated at 2022-06-25 19:29:24.270300
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test when arg "names" does not exist
    test_sessions_dir = '/var/lib/httpie/sessions'
    test_Sessions = Session(test_sessions_dir)
    assert test_Sessions.remove_cookies("test")


# Generated at 2022-06-25 19:29:32.788932
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session({'path': Path('/home/benjello/httpie/.httpie/sessions/httpbin.org/httpbin.json'), 'headers': {}, 'cookies': {}, 'auth': {'type': None, 'username': None, 'password': None}})
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    str_4 = 'e'
    str_5 = 'f'
    str_6 = 'g'
    str_7 = 'h'
    str_8 = 'i'
    str_9 = 'j'
    str_10 = 'k'
    str_11 = 'l'
    str_12 = 'm'
    str_13 = 'n'
    str_

# Generated at 2022-06-25 19:29:35.896946
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_instance_0 = Session('jaflo.4xw')
    session_instance_0.load()
    request_headers_instance_0 = RequestHeadersDict({})
    session_instance_0.update_headers(request_headers_instance_0)



# Generated at 2022-06-25 19:29:44.751974
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    str_1 = 'Cookie'
    list_0 = [str_1]
    session_0.remove_cookies(list_0)
    list_1 = [str_1]
    list_2 = [str_1]
    dict_0 = {list_1: list_2}
    dict_1 = session_0.cookies
    int_0 = dict_0 == dict_1
    bool_0 = False
    if int_0:
        bool_0 = True

if __name__ == '__main__':
    test_case_0()
    test_Session_remove_cookies()

# Generated at 2022-06-25 19:29:47.152275
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    str_1 = '\n\n    '
    session_0.remove_cookies(str_1)




# Generated at 2022-06-25 19:29:55.846122
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    input_0 = {
        'key': 'value'
    }
    input_1 = {
        'key': 'value',
        'Set-Cookie': 'key=value'
    }
    session_0 = Session('')
    session_0.update_headers(input_0)
    session_0.update_headers(input_1)
    output_0 = '{\n    "settings": {}, \n    "headers": {\n        "key": "value"\n    }, \n    "cookies": {}\n}'
    session_0.save()
    with open('session_0.json', 'r') as file:
        line = file.read()
        assert line == output_0


# Generated at 2022-06-25 19:29:57.725577
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert False


# Generated at 2022-06-25 19:29:59.737260
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # session_0.remove_cookies(names_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 19:30:02.049165
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    global filter_0
    filter_0 = 'a'
    session = Session('/foo/bar')
    session.remove_cookies([filter_0])


# Generated at 2022-06-25 19:30:05.796100
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    names_0 = []
    names_0.append('\t'),
    names_0.append('\n'),
    names_0.append('\n\n')
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:30:15.627657
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    session_0.remove_cookies(list())



# Generated at 2022-06-25 19:30:18.484559
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('localhost_8080')
    session_0.update_headers({'User-Agent': 'HTTPie/0.9.8'})


# Generated at 2022-06-25 19:30:22.042926
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test 0
    str_0 = '\n\n    '
    session_0 = Session(str_0)
    names_0 = ['\n\n    ', '\n\n    ']
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:30:26.669191
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(Path('/home/runner/work/httpie/httpie/docs/config'))
    session.load()

    request_headers = RequestHeadersDict()
    for key, value in session['headers'].items():
        request_headers[key] = value
    
    session.update_headers(request_headers)


# Generated at 2022-06-25 19:30:36.960199
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert SESSION_IGNORED_HEADER_PREFIXES

    # Test with empty StringIO and StringIO with content
    from io import StringIO
    stream = StringIO()
    session_0 = Session(stream)
    assert session_0.remove_cookies(names=stream) > 0
    session_1 = Session(stream)
    assert session_1.remove_cookies(names=stream) > 0

    # Test with valid and invalid types for the parameter names
    session_2 = Session(stream)
    assert session_2.remove_cookies(names=None) > 0
    session_3 = Session(stream)
    assert session_3.remove_cookies(names=1234) > 0

    # Test the return type. Is the return value of the function equal to the
    # expected result?
    from io import StringIO

# Generated at 2022-06-25 19:30:40.360902
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert True


# Generated at 2022-06-25 19:30:44.725124
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n\n    '
    obj_0 = Session(str_0)
    str_1 = '\n\n    '
    obj_1 = RequestHeadersDict(str_1)
    obj_0.update_headers(obj_1)
