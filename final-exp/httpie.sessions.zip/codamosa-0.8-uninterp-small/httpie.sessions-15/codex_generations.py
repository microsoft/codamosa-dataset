

# Generated at 2022-06-25 19:21:03.841971
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    str_1 = 'POST'
    list_1 = [('Content-Type', 'application/json'), ('Host', 'httpbin.org'), ('Accept-Encoding', 'gzip,deflate'), ('Accept', '*/*'), ('User-Agent', 'HTTPie/0.9.2')]
    request_headers_0 = RequestHeadersDict(list_1)
    session_0.update_headers(request_headers_0)
    session_0.to_json('session.json')


# Generated at 2022-06-25 19:21:15.349759
# Unit test for method remove_cookies of class Session

# Generated at 2022-06-25 19:21:16.479802
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    pytest.skip('Method not implemented.')


# Generated at 2022-06-25 19:21:22.128671
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # setup
    session = Session('sessions/test_session')
    session['headers'] = {}
    request_headers = {'test_header': 'test_value'}

    # action
    session.update_headers(request_headers)

    # assert
    assert session['headers'] == {'test_header': 'test_value'}

# Generated at 2022-06-25 19:21:31.227059
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_instance = Session(
        '/home/httpie/.httpie/sessions/foo.com/foo.json')
    request_headers_instance = RequestHeadersDict(
        {'Content-Type': 'application/json',
         'Accept': 'application/json',
         'Host': 'httpbin.org'})
    session_instance.update_headers(request_headers_instance)
    assert session_instance.headers == {'Content-Type': b'application/json',
                                        'Accept': b'application/json',
                                        'Host': b'httpbin.org'}


# Generated at 2022-06-25 19:21:41.770989
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.input import SEP_CREDENTIALS
    from httpie.plugins import AuthPlugin, plugin_manager


    class BasicAuthPlugin(AuthPlugin):
        name = 'Basic HTTP Auth'
        auth_type = 'basic'
        prompt_password = True
        description = 'Basic auth using a password'

        def get_auth(self, username=None, password=None):
            import base64
            return base64.b64encode(
                ('%s:%s' % (username, password)).encode('utf8')
            ).decode('utf8')

    username, password = 'user', 'password'
    auth_plugin = BasicAuthPlugin()
    auth = auth_plugin.get_auth(username, password)
    assert auth == 'dXNlcjpwYXNzd29yZA=='

# Generated at 2022-06-25 19:21:49.713900
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'ie'
    str_1 = 'kN_D'
    str_2 = 'q~)z'
    session_0 = Session(str_0)
    session_0.update_headers(str_1)
    session_0.update_headers(str_2)
    ret_0 = session_0.update_headers(str_1)


# Generated at 2022-06-25 19:21:56.050419
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    request_headers_0 = RequestHeadersDict(str_1)
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:22:01.132403
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict(dict())
    session_0 = Session('\t')
    session_0.update_headers(headers)


# Generated at 2022-06-25 19:22:12.003112
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # Iterate sections
    dict_0 = dict()
    dict_0[('auth', 'password')] = {'type': 'basic', 'username': 'username', 'password': 'password'}
    dict_0[('auth', 'username')] = {'type': 'basic', 'username': 'username', 'password': 'password'}
    dict_0[('auth', 'type')] = {'type': 'basic', 'username': 'username', 'password': 'password'}
    for name_0 in dict_0.keys():
        path_0 = './Session/%s' % name_0[0]
        os.makedirs(path_0, exist_ok=True)

# Generated at 2022-06-25 19:22:23.311712
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = Path(__file__).parent.parent.parent / SESSIONS_DIR_NAME / 'some_authentication_url.json'
    session = Session(path)
    session.load()
    # NotImplementedError
    try:
        session.update_headers(None)
        flag = False
    except NotImplementedError:
        flag = True
    assert flag


# Generated at 2022-06-25 19:22:30.452941
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = '91c-W8#v@o\\zG7m'
    session_name_0 = '~*p&5nA_t<'
    url_0 = 'http://httpbin.org/redirect/1'
    request_headers_0 = {}
    get_httpie_session(path_0, session_name_0, None, url_0).update_headers(request_headers_0)


# Generated at 2022-06-25 19:22:38.940978
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Case 0
    self_0 = Session(Path('./config/httpie/'))
    self_1 = RequestHeadersDict() # headers to be set
    self_1.update({"User-Agent": "User-Agent",
                   "Accept-Encoding": "Accept-Encoding",
                   "Accept": "Accept"})
    self_1.update({"Accept-Language": "Accept-Language",
                   "Referer": "Referer",
                   "DNT": "DNT"})
    self_1.update({"Cookie": "Cookie"})
    self_2 = self_0.update_headers(self_1)


# Generated at 2022-06-25 19:22:41.438768
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = None
    session = Session(path)
    request_headers = None
    result = session.update_headers(request_headers)
    assert result == None


# Generated at 2022-06-25 19:22:43.490958
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # check if the method update_headers exists
    assert callable(getattr(Session, "update_headers", None))


# Generated at 2022-06-25 19:22:46.586356
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/Users/wayne/.config/httpie/sessions/localhost/httpie.json')
    names = ['w', 'W']
    session.remove_cookies(names)


# Generated at 2022-06-25 19:22:57.688811
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_0 = RequestHeadersDict()
    headers_0.add('host', 'www.google.com')
    headers_0.add('Accept-Encoding', 'gzip, deflate')
    headers_0.add('Accept', '*/*')
    headers_0.add('Connection', 'close')
    headers_0.add('user-agent', 'Python-urllib/3.7')
    headers_0.add('foo', 'bar')

    session_0 = Session(path='/Users/maksim/Downloads/httpie-1.0.0/examples/00_httpie_session.json')

    session_0.update_headers(headers_0)

    assert session_0['headers']['host'] == 'www.google.com'

# Generated at 2022-06-25 19:22:59.634889
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # assert test_case_0() == "Method not implemented."
    print("Unit test for method remove_cookies of class Session passed!")



# Generated at 2022-06-25 19:23:04.220468
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session0 = Session('/Usrs/d2k7')

    assert_equal(session0['cookies']['username']['value'], 'value0')
    assert_equal(session0['cookies']['username']['path'], 'path0')
    assert_equal(session0['cookies']['username']['secure'], 'secure0')
    assert_equal(session0['cookies']['username']['expires'], 'expires0')


# Generated at 2022-06-25 19:23:14.304488
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    tst_Sess_inst = Session('/tmp/foo')
    r_h_0 = RequestHeadersDict({'foo': 'bar'})
    r_h_1 = RequestHeadersDict({'foo': 'bar'})
    r_h_2 = RequestHeadersDict({'foo': 'bar'})
    r_h_3 = RequestHeadersDict({'foo': 'bar'})
    r_h_4 = RequestHeadersDict({'foo': 'bar'})
    r_h_5 = RequestHeadersDict({'foo': 'bar'})
    r_h_6 = RequestHeadersDict({'foo': 'bar'})
    r_h_7 = RequestHeadersDict({'foo': 'bar'})

# Generated at 2022-06-25 19:23:30.430652
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_1 = Session('./test/test_file_0')
    var_2 = RequestHeadersDict()
    var_2['Host'] = 'www.example.com'
    var_2['Accept-Encoding'] = 'gzip, deflate'
    var_2['Connection'] = 'keep-alive'
    var_2['Upgrade-Insecure-Requests'] = '1'
    var_2['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'

# Generated at 2022-06-25 19:23:41.328890
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    target_1 = 'Content-Type'
    str_1 = 'text/html; charset=utf-8'
    str_2 = 'HTTPie/1.0.0'
    target_2 = 'Set-Cookie'
    str_3 = 'key=value'
    target_3 = 'Connection'
    str_4 = '127.0.0.1'
    str_5 = 'localhost'
    str_6 = 'X-Test'
    str_7 = 'abc'

    class test_Session_update_headers_class_0(object):
        headers = {target_1: str_1}
    var_0 = test_Session_update_headers_class_0()  
    var_1 = {target_1: str_1}

    var_2 = Session('')
    var_2

# Generated at 2022-06-25 19:23:46.578757
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    args = []
    ret_expected = None

    # Setup mock
    class MockRequestHeadersDict(RequestHeadersDict):
        def __init__(self):
            pass

    mock_headers = MockRequestHeadersDict()
    mock_request_headers = RequestHeadersDict()

    session = Session('path')
    ret = session.update_headers(mock_request_headers)

    # Assert
    assert(ret == ret_expected)


# Generated at 2022-06-25 19:23:50.727869
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    fp_0 = Session(0, 'http://httpbin.org/')

    # TODO: what should this look like?
    input_0 = {}
    expected_0 = {}

    # TODO: add more test cases
    # test_case_0()


# Generated at 2022-06-25 19:24:02.287690
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print("Begin Unit Test for method update_headers of class Session")
    print('Test Case 0')
    # Test Case 0
    # assertion expected:
    # 1. cookies should not be stored into session
    # 2. user-agent should not be stored into session
    # 3. if-range should not be stored into session
    # 4. content-type should not be stored into session
    request_headers = {
        'Content-Type': 'application/json',
        'If-Range': 'W/"a1d3c1809218f22"',
        'Cookie': '__cfduid=d7655f8e7d0d4e39c6399b984b4b661741508720441',
        'User-Agent': 'HTTPie/0.9.9',
    }

# Generated at 2022-06-25 19:24:06.691349
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(Path(''))
    headers_0 = RequestHeadersDict(session_0['headers'])
    name_0 = 'user-agent'
    session_0.update_headers(headers_0)
    assert name_0 in session_0['headers']
    name_1 = 'Cookie'
    session_0.update_headers(headers_0)
    assert name_1 in session_0['headers']


# Generated at 2022-06-25 19:24:17.943728
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # http://www.json.org/JSON_checker/test/pass2.json
    JSON_object_str_0 = '''{
  "JSON Test Pattern pass2": {
    "The outermost value": "must be an object or array.",
    "In this test": "It is an object."
  }
}'''
    JSON_object_0 = json.loads(JSON_object_str_0)
    assert_equal(JSON_object_0, json.loads(JSON_object_0))

    JSON_object_str_1 = '''{
  "JSON Test Pattern pass2": {
    "The outermost value": "must be an object or array.",
    "In this test": "It is an object."
  }
}'''

# Generated at 2022-06-25 19:24:21.971496
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class_0 = Session('Plain text')
    class_0.update_headers('x-amz-glacier-version')


# Generated at 2022-06-25 19:24:34.096747
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    if not VALID_SESSION_NAME_PATTERN.match('foo=bar'):
        assert False
    if not VALID_SESSION_NAME_PATTERN.match('9'):
        assert False
    if not VALID_SESSION_NAME_PATTERN.match('example.com'):
        assert False
    if VALID_SESSION_NAME_PATTERN.match(' '):
        assert False
    if VALID_SESSION_NAME_PATTERN.match('\x1c'):
        assert False
    if VALID_SESSION_NAME_PATTERN.match('foo\x18'):
        assert False
    if VALID_SESSION_NAME_PATTERN.match('\x00foo'):
        assert False

# Generated at 2022-06-25 19:24:43.519391
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n        Remove cookies with the specified names.\n\n        '
    str_1 = '\n        '
    str_2 = '\n        '
    _slice_0 = slice(2, None)
    str_3 = '\n        '
    str_4 = '\n        '
    str_5 = '\n        '
    str_6 = '\n        '
    str_7 = '\n        '
    str_8 = '\n        '
    str_9 = '\n        '
    str_10 = '\n        '
    str_11 = '\n        '
    str_12 = '\n        '
    str_13 = '\n        '
    str_14 = '\n        '

# Generated at 2022-06-25 19:25:09.522882
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    request_headers_0 = {}
    session_0.update_headers(request_headers_0)
    request_headers_1 = {}
    session_0.update_headers(request_headers_1)
    request_headers_2 = {}
    session_0.update_headers(request_headers_2)
    request_headers_3 = {}
    session_0.update_headers(request_headers_3)
    request_headers_4 = {}
    session_0.update_headers(request_headers_4)
    request_headers_5 = {}
    session

# Generated at 2022-06-25 19:25:14.664164
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    list_0 = [127, 58, 1, 2, 3]
    session_0.remove_cookies(list_0)
    str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_1 = Session(str_1)
    list_1 = [1, 2, 3]
    session_1.remove_cookies(list_1)

# Generated at 2022-06-25 19:25:25.324348
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    dict_1 = {
        'c': 'd'
    }
    dict_2 = {
        'a': 'b',
        'c': 'd'
    }
    dict_2.update(dict_1)
    request_headers_0 = RequestHeadersDict(dict_2)
    session_0.update_headers(request_headers_0)




# Generated at 2022-06-25 19:25:31.401808
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    str_1 = '\n    '
    names_0 = [str_1]
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:25:37.566477
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    session_0.remove_cookies(['expires'])


# Generated at 2022-06-25 19:25:47.723467
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import pytest
    from requests.cookies import RequestsCookieJar

    jar = RequestsCookieJar()
    jar.extract_cookies({'Set-Cookie': 'a=b; c=d'}, 'https://example.com/')
    session = Session('https://example.com/')

    session.cookies = jar
    assert 'a' in session['cookies']
    assert 'c' in session['cookies']
    assert session.cookies.get_dict() == {'a': 'b', 'c': 'd'}

    session.remove_cookies(['a'])
    assert 'a' not in session['cookies'] or session['cookies']['a'] is None
    assert 'c' in session['cookies']

# Generated at 2022-06-25 19:25:56.013364
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '"/\\\\X" is an invalid group reference'
    session_0 = Session(str_0)

    str_1 = '\'c:\\\\Users\\\\sgrzywna\\\\Documents\\\\repos\\\\EHR\\\\node_modules\\\\.bin\\\\electron;\' is not recognized as an internal or external command,'
    str_2 = 'operable program or batch file.'
    str_3 = 'Package babel-minify has an invalid \"main\" entry'
    str_4 = '\'C:\\\\Users\\\\sgrzywna\\\\AppData\\\\Roaming\\\\npm\\\\electron.cmd\' is not recognized as an internal or external command,'
    str_5 = 'operable program or batch file.'

# Generated at 2022-06-25 19:26:01.962035
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    A transport adapter that allows Requests to make HTTP requests\n    via a proxy which supports the PROXY protocol.\n\n    '
    session_0 = Session(str_0)
    int_0 = -13
    names_0 = [int_0]
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:26:04.613202
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('')
    session_0.update_headers({'test': 'value'})
    session_0.remove_cookies(tuple())


# Generated at 2022-06-25 19:26:13.625843
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.compat import is_windows

    # Sample input
    session_0 = Session('~/.httpie/sessions/full-date-format.json')
    str_0 = '\n    Prettify the date format of headers that include a timestamp.\n    Uses the full date format\n    '
    str_1 = '\n    Prettify the date format of headers that include a timestamp.\n    Uses the short date format\n    '
    str_2 = '\n    Prettify the date format of headers that include a timestamp.\n    Uses the ISO8601 format\n    '

    output = session_0.remove_cookies(
        input = ['full-date-format', 'short-date-format', 'iso8601-date-format'],
    )

    assert output == None


#

# Generated at 2022-06-25 19:26:42.448476
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    str_1 = 'bool_0'
    names_0 = [str_1]
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:26:46.324001
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    list_0 = []
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:26:51.707959
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('/Users/david/httpie/.httpie/sessions/www_example_com/example.json')
    names = ['pygments', 'colorize']
    try:
        session_0.remove_cookies(names)
        assert False
    except:
        assert True


# Generated at 2022-06-25 19:26:55.550579
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # session = Session(str)

    names = []


    # session.remove_cookies(names)
    # assert False # TODO: implement your test here


# Generated at 2022-06-25 19:27:03.593993
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    session_0.load()
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    list_0 = ['\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    ']
    # Call the method
    session_0.remove_cookies(list_0)
    # Assert

# Generated at 2022-06-25 19:27:06.926198
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    str_1 = '456'
    names_0 = [str_1]
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:27:14.651779
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    str_1 = ''
    session_0 = Session(str_0)
    if session_0:
        pass
    str_2 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    str_3 = ''
    session_0 = Session(str_2)
    if session_0:
        pass

# Generated at 2022-06-25 19:27:23.872145
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    list_0 = [str_1]
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:27:33.365354
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    str_1 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    str_2 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0.remove_cookies([
        str_1,
        str_2])


# Generated at 2022-06-25 19:27:35.868339
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # remove_cookies(names: Iterable[str])
    class_0 = Session('0')
    assert class_0 is not None


# Generated at 2022-06-25 19:28:04.129735
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # str_0 head
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)

    # str_1 head
    str_1 = 'This is a session'
    # str_1 tail
    str_2 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    str_1 = str_1 + str_2

    # str_2 head
    str_2 = 'This is a session'
    # str_2 tail

# Generated at 2022-06-25 19:28:07.241834
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    parameter_0 = {'type': '', 'raw_auth': '', 'username': '', 'password': ''}
    session_0 = Session(parameter_0)
    parameter_1 = session_0.remove_cookies(str())
    assert parameter_1 is True


# Generated at 2022-06-25 19:28:12.449997
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    session_0.remove_cookies(session_0)


# Generated at 2022-06-25 19:28:17.780626
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    # No exception should be thrown in this case
    session_0.remove_cookies(0)



# Generated at 2022-06-25 19:28:24.499695
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    str_1 = 'ey'
    return_value_1 = session_0.remove_cookies(str_1)
    assert return_value_1 == None
    return_value_2 = session_0.remove_cookies(str_1)
    assert return_value_2 == None


# Generated at 2022-06-25 19:28:30.156204
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n\n    Replace a string in the response body using a regular expression.\n\n    This processor is useful for cases where a web service returns an error\n    message that does not provide useful information, or for test purposes.\n\n    '
    session_0 = Session(str_0)
    list_0 = ['f', 'd']
    session_0.remove_cookies(list_0)
    assert str(session_0) == '\n\n    Replace a string in the response body using a regular expression.\n\n    This processor is useful for cases where a web service returns an error\n    message that does not provide useful information, or for test purposes.\n\n    '


# Generated at 2022-06-25 19:28:39.702160
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Verify error messages match
    assert str(TypeError("iterable argument required")) == "iterable argument required"
    assert str(KeyError("name not found")) == "name not found"
    assert str(TypeError("argument of type 'str' is not iterable")) == "argument of type 'str' is not iterable"
    assert str(KeyError("name not found")) == "name not found"
    assert str(KeyError("name not found")) == "name not found"
    try:
        str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
        session_0 = Session(str_0)
    except TypeError as err_0:
        print(err_0.args)

# Generated at 2022-06-25 19:28:44.172897
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '

    # Test with the default value of the second parameter
    session_0 = Session('xPzmVD5u5')
    session_0.remove_cookies(names)

# Generated at 2022-06-25 19:28:48.812637
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    '
    session_0 = Session(str_0)
    names = [10, 2, 4, 2, 0, 7, 4, 2, 1, 6, 0, 1, 7, 4, 5, 2, 6, 7, 0, 2, 6, 3]
    session_0.remove_cookies(names)

# Generated at 2022-06-25 19:28:56.167063
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    list_0 = ['\u001E', 'alloy']
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:29:25.759722
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('/dummy/path')
    session_0.__setitem__('cookies', {'cookies': {'path':
                                                  '/',
                                                  'secure':
                                                  False,
                                                  'value':
                                                  'value_0',
                                                  'expires':
                                                  None}})
    assert session_0.__getitem__('cookies') == {'cookies': {'path':
                                                            '/',
                                                            'secure':
                                                            False,
                                                            'value':
                                                            'value_0',
                                                            'expires':
                                                            None,
                                                            'max-age': None}}
    session_0.remove_cookies(['cookies'])
    assert session

# Generated at 2022-06-25 19:29:29.823090
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)

    # Parameters
    names_0 = ('\n', '')



# Generated at 2022-06-25 19:29:38.915922
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('path_0')
    session_0.cookies = RequestsCookieJar()
    session_0.cookies.set_cookie(create_cookie('path_0', 'value_0'))
    session_0.cookies.set_cookie(create_cookie('path_1', 'value_1'))
    session_0.cookies.set_cookie(create_cookie('path_2', 'value_2'))
    session_0.cookies.set_cookie(create_cookie('path_3', 'value_3'))
    session_0.cookies.set_cookie(create_cookie('path_4', 'value_4'))
    session_0.remove_cookies(['path_0', 'path_2', 'path_4'])

# Generated at 2022-06-25 19:29:47.375031
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    remove_cookies_cookie_names = {'path': '',
                                    'name': '',
                                    'httpOnly': True,
                                    'domain': '',
                                    'expires': None,
                                    'maxAge': None,
                                    'secure': True,
                                    'version': 0,
                                    'comment': None,
                                    'comment_url': None,
                                    'port': None}
    remove_cookies_session_0 = Session(remove_cookies_cookie_names)

    # Test case 0:
    remove_cookies_cookie_names[remove_cookies_session_0.remove_cookies()] = 'path', 'name', 'httpOnly', 'domain', 'expires', 'maxAge', 'secure', 'version', 'comment', 'comment_url', 'port'

# Generated at 2022-06-25 19:29:53.828772
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(Path)
    session_0.headers = RequestHeadersDict({})
    assert session_0.cookies == RequestsCookieJar()
    jar = RequestsCookieJar()
    jar.set_cookie(create_cookie('name', 'value'))
    jar.clear_expired_cookies()
    session_0.cookies = jar
    session_0.remove_cookies(['name'])
    assert session_0.cookies == RequestsCookieJar({})


# Generated at 2022-06-25 19:30:03.583339
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    str_1 = '\n    Set the Accept header to ``application/json``.\n\n    """\n    '
    session_1 = Session(str_1)
    list_0 = ['\n    Set the Authorization header with HTTP Basic authentication credentials.\n\n    Usage::\n\n        http --auth-type=basic --auth=username:password example.org\n\n    \n    From the command line this corresponds to ``Basic YWRtaW46YWRtaW4=``.\n\n    ']
    session_1.remove_cook

# Generated at 2022-06-25 19:30:11.255539
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    args_0 = [
        'Cookie',
        'Cookie'
    ]
    session_0 = Session(args_0)
    args_1 = [
        'Cookie',
        'Cookie'
    ]
    session_1 = Session(args_1)
    args_2 = [
        'Cookie',
        'Cookie'
    ]
    session_2 = Session(args_2)
    try:
        session_2.remove_cookies(args_2)
    except NameError as exception_0:
        exception_0 = 'None'
    exception_0 = 'None'
    try:
        session_2.remove_cookies(args_2)
    except NameError as exception_0:
        exception_0 = 'None'
    exception_0 = 'None'

# Generated at 2022-06-25 19:30:21.030848
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(DEFAULT_CONFIG_DIR)
    session_0.update_headers(request_headers=RequestHeadersDict(dict({'Content-Type': 'text/html; charset=UTF-8', 'Accept-Encoding': 'gzip, deflate, br', 'Accept': '*/*', 'User-Agent': 'HTTPie/0.9.0'})))
    assert session_0.headers == RequestHeadersDict(dict({'Content-Type': 'text/html; charset=UTF-8', 'Accept-Encoding': 'gzip, deflate, br', 'Accept': '*/*', 'User-Agent': 'HTTPie/0.9.0'}))
    session_0.remove_cookies(names=set({'Accept', 'User-Agent'}))
    assert session_0.headers

# Generated at 2022-06-25 19:30:25.589777
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    session_0 = Session(str_0)
    names = []
    session_0.remove_cookies(names)


# Generated at 2022-06-25 19:30:36.224923
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('str_0')
    str_0 = '\n    Colorize using Pygments\n\n    This processor that applies syntax highlighting to the headers,\n    and also to the body if its content type is recognized.\n\n    '
    str_1 = str_0
    str_2 = 'tolvk9-kf2j4d-4g4j36-t5wf8w-ztjd5t-7v9kz5'
    str_3 = 'tolvk9-kf2j4d-4g4j36-t5wf8w-ztjd5t-7v9kz5'