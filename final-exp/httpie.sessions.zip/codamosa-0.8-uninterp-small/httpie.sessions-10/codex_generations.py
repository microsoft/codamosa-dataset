

# Generated at 2022-06-25 19:21:02.709708
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_0 = None
    session_0 = Session(None)
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:21:14.050990
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.client import Client
    from httpie.cli.parser import get_parser
    from httpie.plugins.builtin import HTTPBasicAuth

    # Create an instance of the parser
    parser_0 = get_parser()
    # Create an instance of the Client
    client_0 = Client(parser_0)
    # Create an instance of the Session
    session_0 = Session(DEFAULT_SESSIONS_DIR / 'test')
    # Create an instance of the HTTPBasicAuth
    httpbasicauth_0 = HTTPBasicAuth()
    # Create an instance of the RequestHeadersDict
    requestheadersdict_0 = RequestHeadersDict({'Accept-Encoding': 'gzip, deflate', 'User-Agent': 'HTTPie/1.0.3'})
    session_0.update_headers(requestheadersdict_0)

# Generated at 2022-06-25 19:21:16.112987
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('')
    headers_0 = {}
    session_0.update_headers(headers_0)
    assert True


# Generated at 2022-06-25 19:21:19.659061
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_1 = Session(str_0)
    list_0 = []
    session_1.remove_cookies(list_0)


# Generated at 2022-06-25 19:21:31.136501
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    str_1 = ""
    str_2 = "|"
    str_3 = "N"
    str_4 = "J"
    str_5 = "K"
    str_6 = "-"
    str_7 = "1"
    str_8 = "5"
    str_9 = "2"
    str_10 = "O"
    str_11 = "S"
    str_12 = "E"
    str_13 = "Z"
    str_14 = "C"
    str_15 = "0"
    str_16 = "i"
    str_17 = "n"
    str_18 = "o"
    str_19 = "W"
    str_20 = "4"
    str_

# Generated at 2022-06-25 19:21:36.217257
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = "*jlAQB"
    session_0 = Session(str_0)
    str_1 = "asdasd"
    list_0 = [str_1]
    session_0.remove_cookies(list_0)

# Test method Session.update_headers

# Generated at 2022-06-25 19:21:38.971084
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    headers_0 = None
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:21:41.156223
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cases = [
        (1,),
        (2,),
        (3,),
    ]
    for case in cases:
        session_0 = Session(case)



# Generated at 2022-06-25 19:21:42.877942
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session("/tmp/session")
    session_0.update_headers(RequestHeadersDict(None))


# Generated at 2022-06-25 19:21:51.316962
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '0,i=;a=l'
    path_0 = Path(str_0)
    session_0 = Session(path_0)
    str_1 = '1,yR=9X'
    request_headers_0 = RequestHeadersDict(str_1)
    session_0.update_headers(request_headers_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 19:22:06.534365
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_1 = None
    session_1 = Session(str_1)
    list_0 = []
    session_1.remove_cookies(list_0)



# Generated at 2022-06-25 19:22:17.481704
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    dict_1 = {
        'path': '/',
        'secure': False,
        'expires': None,
        'value': 'username=a&password=a',
    }
    dict_0 = {
        'auth': {
            'type': 'basic',
            'username': 'a',
            'password': 'a',
            'raw_auth': 'a:a',
        },
        'cookies': {
            'username': dict_1,
        },
        'headers': {},
    }
    str_0 = '~/.httpie/sessions'
    dict_2 = dict_0
    dict_2['cookies'] = {}
    session_0 = Session(str_0)
    session_0.update(dict_0)

# Generated at 2022-06-25 19:22:21.209181
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    dict_0 = RequestHeadersDict({})
    session_0.update_headers(dict_0)


# Generated at 2022-06-25 19:22:23.755136
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    with pytest.raises(AttributeError):
        session_0.remove_cookies(None)


# Generated at 2022-06-25 19:22:27.682667
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    rq_headers_0 = None
    session_0.update_headers(rq_headers_0)


# Generated at 2022-06-25 19:22:30.370778
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    str_1 = None
    session_0.remove_cookies(str_1)


# Generated at 2022-06-25 19:22:33.425089
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)

    dict_1 = {}
    session_0.update_headers(dict_1)

# Generated at 2022-06-25 19:22:41.085415
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    names = None
    str_1 = None
    session_0 = Session(str_1)
    session = session_0
    names = None
    session = session_0
    try:
        session.remove_cookies(names)
    except NameError:
        pass
    except IndexError:
        str_2 = None
        session_1 = Session(str_2)
        session = session_1
        names = None
        session.remove_cookies(names)
    except AttributeError:
        pass
    else:
        assert False


# Generated at 2022-06-25 19:22:45.259534
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    str_1 = None
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict(str_1)
    session_0.update_headers(request_headers_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 19:22:51.683567
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('test_file')
    session_0.update_headers({'Accept-Encoding': 'deflate, gzip', 'Accept': '*/*', 'User-Agent': 'HTTPie/0.9.3'})
    assert session_0['headers'] == {'Accept-Encoding': 'deflate, gzip', 'Accept': '*/*', 'User-Agent': 'HTTPie/0.9.3'}


# Generated at 2022-06-25 19:23:16.122355
# Unit test for method update_headers of class Session

# Generated at 2022-06-25 19:23:19.789164
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = 'sessions/httpbin.org/cookies'
    session_0 = Session(path)
    headers_0 = {}
    session_0.update_headers(headers_0)



# Generated at 2022-06-25 19:23:20.700620
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert True



# Generated at 2022-06-25 19:23:29.239370
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.parser import parse_items
    from httpie.context import Environment
    from httpie.input import KeyValueArg
    from httpie.plugins.builtin import JSONStreams
    from httpie.plugins.registry import plugin_manager
    from httpie.types import KeyValue
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tempdir:
        env = Environment(
            config_dir=tempdir,
            colors=256,
            config_path=None,
            defaults=False,
            debug=False,
            download_dir='',
            output_file=None,
            verbose=False
        )

        request_headers = parse_items(env, args=['foo', 'bar'])
        session_1 = Session(tempdir + 'session1.json')

        session_1.update_

# Generated at 2022-06-25 19:23:33.556290
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    str_1 = "sessions/zodiac/session.json"
    session_0 = Session(str_1)
    str_2 = "sessions/"
    session_0 = Session(str_2)
    cookies_0 = []


# Generated at 2022-06-25 19:23:39.871824
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_0 = Session('C:\\U5C5E\\U6027')
    var_1 = {'X-Test-Header': None}
    var_0.update_headers(var_1)

    var_1 = {'X-Test-Header': 'x'}
    var_0.update_headers(var_1)


# Generated at 2022-06-25 19:23:42.294414
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = Path('_')
    session_0 = Session(str_0)
    headers_0 = RequestHeadersDict()
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:23:44.072818
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    d = dict()
    session_0.update_headers(d)

# Generated at 2022-06-25 19:23:46.834187
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    iterable_0 = None
    # state = session_0.remove_cookies(iterable_0)


# Generated at 2022-06-25 19:23:53.915110
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test with some valid data
    path = '/usr/home'
    request_headers = {
        'User-Agent': 'HTTPie/0.9.1'
    }
    session = Session(path)
    session.update_headers(request_headers)
    expected = {
        'User-Agent': 'HTTPie/0.9.1'
    }
    actual = session.headers
    assert expected == actual, 'Expected: %s, Actual: %s' % (expected, actual)



# Generated at 2022-06-25 19:24:12.466094
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    request_headers_0 = None
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:24:14.840084
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    names_0 = None
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:24:19.078426
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    # TypeError raised when the first argument is of type
    # NoneType, deprecated since version 3.1.
    try:
        session_0.remove_cookies(str_0)
    except TypeError:
        pass


# Generated at 2022-06-25 19:24:22.497438
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(str())
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:24:33.149908
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict()
    str_1 = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
    request_headers_0.add('User-Agent', str_1)
    request_headers_0.add('Cookie', 'Chrome/58.0.3029.110 Safari/537.36')
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:24:42.651587
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = 'y'
    config_dir_1 = DEFAULT_CONFIG_DIR
    session_1 = get_httpie_session(config_dir_1, str_1, None, '/home/darth/my_projects/httpie/')
    request_headers_1 = RequestHeadersDict({'Content-Length': '1', 'Cookie': 'key0=value0', 'User-Agent': 'HTTPie/0.9.8', 'Host': '127.0.0.1:5000', 'Accept': '*/*', 'Connection': 'keep-alive'})
    session_1.update_headers(request_headers_1)
    session_1.path
# EDGE CASE
# None is not a valid value for parameter session_name.
# None is not a valid value for parameter host.
# Unit test

# Generated at 2022-06-25 19:24:47.916299
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    request_headers_0 = {}
    try:
        session_0.update_headers(request_headers_0)
    except TypeError:
        assert False
    else:
        assert True


# Generated at 2022-06-25 19:24:49.541907
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names = [3.14]
    session_0 = Session(str_0)
    str_0 = None
    result = session_0.remove_cookies(names)
    assert result == None


# Generated at 2022-06-25 19:24:53.613366
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    requests_headers_dict_0 = None
    session_0 = Session('')
    request_headers_dict_0 = {'Test-Case': '0'}
    assert session_0.update_headers(request_headers_dict_0, requests_headers_dict_0) == None
    assert session_0.headers == {'Test-Case': '0'}
    request_headers_dict_1 = {'Test-Case': '1'}
    assert session_0.update_headers(request_headers_dict_1, requests_headers_dict_0) == None
    assert session_0.headers == {'Test-Case': '0'}
    request_headers_dict_2 = {'Test-Case': '2'}

# Generated at 2022-06-25 19:24:56.049591
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    request_headers_0 = None
    try:
        session_0.update_headers(request_headers_0)
    except NameError:
        pass


# Generated at 2022-06-25 19:25:33.846364
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    dict_0 = RequestHeadersDict()
    dict_0['Authorization'] = 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c'
    dict_0['User-Agent'] = 'HTTPie/0.9.9'
    dict_0['Accept'] = '*/*'


# Generated at 2022-06-25 19:25:37.898850
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = None
    session_1 = Session(str_1)
    str_2 = ''
    request_headers_2 = RequestHeadersDict(str_2)
    session_1.update_headers(request_headers_2)



# Generated at 2022-06-25 19:25:42.217060
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'remove_cookies'
    session_0 = Session(str_0)
    # Session.__init__() -> None
    str_1 = None
    session_0.__init__(str_1)
    # Session.__init__() -> None
    list_0 = ['a', 'b', 'c']
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:25:52.928782
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.compat import urlparse
    from httpie.plugins.registry import plugin_manager
    import json
    import requests
    session_0 = Session('session.json')
    parsedurl_0 = urlparse('https://example.com:80/')
    str_0 = 'https://example.com:80/'
    str_1 = 'http://example.com:80/'
    cachecontrol_0 = requests.utils.default_headers()
    headers_0 = cachecontrol_0
    parsedurl_1 = urlparse('http://example.com:80/')
    headers_1 = cachecontrol_0
    session_0.request('GET', parsedurl_0, params = '', headers = headers_0, data = '', redirect = True)

# Generated at 2022-06-25 19:25:55.427899
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    p = Path(None)
    session = Session(p)
    headers = {'Host': 'httpbin.org', 'Content-Type': 'text/json'}
    session.update_headers(headers)
    return session

# Generated at 2022-06-25 19:26:06.984888
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    str_1 = None
    session_0 = Session(str_1)
    str_2 = None

    # Verify that empty types are set properly
    assert session_0.cookies is not None

    # Test for method remove_cookies(names: Iterable[str])
    cookie_1 = create_cookie('Test', 'Value', path='/',
                             expires=None,
                             secure=False,
                             discard=True)
    cookie_2 = create_cookie('Test2', 'Value2', path='/',
                             expires=None,
                             secure=False,
                             discard=True)
    cookie_3 = create_cookie('Test3', 'Value3', path='/',
                             expires=None,
                             secure=False,
                             discard=True)
    jar

# Generated at 2022-06-25 19:26:14.412140
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    # user input should be a list of strings, not a NoneType
    try:
        session_0.remove_cookies(None)
    except Exception:
        pass
    # user input should be a list of strings, not an integer
    try:
        session_0.remove_cookies(10)
    except Exception:
        pass
    # user input should be a list of strings, not a string
    try:
        session_0.remove_cookies('arg1')
    except Exception:
        pass
    # user input should be a list of strings, not a string
    try:
        session_0.remove_cookies('arg2')
    except Exception:
        pass
    # user input should be a list of strings, not a string

# Generated at 2022-06-25 19:26:16.320323
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_0 = None
    session_0 = Session('/')
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:26:21.331008
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session = Session(str_0)

    jar = RequestsCookieJar()
    assert not jar
    session.cookies = jar
    assert not session.cookies

    jar.set('foo', 'bar', path='/')
    jar.set('bar', 'foo', path='/')
    assert jar

    session.cookies = jar
    assert session.cookies
    session.remove_cookies(['foo',])
    assert not session.cookies

# Generated at 2022-06-25 19:26:22.790410
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = ''
    path_0 = Path(str_0)
    session_0 = Session(path_0)
    session_0.update_headers() # fill in the blanks


# Generated at 2022-06-25 19:27:26.254531
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # TODO
    pass


# Generated at 2022-06-25 19:27:30.401534
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # Inputs
    session_0 = Session('')
    request_headers_0 = RequestHeadersDict({'Host' : 'localhost'})
    
    # Invoke the method under test
    session_0.update_headers(request_headers_0)
    
    # Validating method update_headers of class Session
    assert 'Host' in session_0['headers']

# Generated at 2022-06-25 19:27:40.385490
# Unit test for method remove_cookies of class Session

# Generated at 2022-06-25 19:27:44.550189
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)

    # test 0
    headers = None
    session_0.update_headers(headers)
    assert (session_0 == session_0)


# Generated at 2022-06-25 19:27:47.047506
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    request_headers_0 = None
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:27:49.264243
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    str_1 = None
    session_0.update_headers(str_1)


# Generated at 2022-06-25 19:27:52.066022
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('data/session.json')
    headers_0 = dict()
    headers_1 = dict()
    session_0.update_headers(headers_0)
    session_0.update_headers(headers_1)

# Generated at 2022-06-25 19:27:54.560686
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_1 = 'abc'
    session_1 = Session(str_1)
    list_1 = ['abc']
    session_1.remove_cookies(list_1)


# Generated at 2022-06-25 19:27:57.334595
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Setup
    session_0 = None
    request_headers = None
    # Invocation
    session_0.update_headers(request_headers)
    # Verification
    pass

# Generated at 2022-06-25 19:28:04.744409
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    dict_0 = {'Headers.A': 'Value.A', 'Headers.B': 'Value.B', 'Headers.C': 'Value.C'}
    session_0 = Session(dict_0)
    dict_1 = {'Headers.C': 'Value.C', 'Headers.D': 'Value.D', 'Headers.E': 'Value.E'}
    dict_2 = {'Headers.D': 'Value.D', 'Headers.E': 'Value.E'}
    session_0.update_headers(dict_1)
    assert dict_2 == dict_1

# Generated at 2022-06-25 19:30:08.388928
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Setup
    str_0 = None
    session_0 = Session(str_0)

    req_headers = {'name': 'value'}

    # Invocation
    session_0.update_headers(req_headers)

    # Verification
    assert session_0['headers']['name'] == 'value'

# Generated at 2022-06-25 19:30:14.972633
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_1 = None
    session_1 = Session(path_1)
    dict_2 = None
    session_1.update_headers(dict_2)
    dict_3 = RequestHeadersDict()
    session_4 = Session(path_1)
    session_4.update_headers(dict_3)
    dict_5 = RequestHeadersDict()
    dict_5['Accept'] = '*/*'
    dict_5['Accept'] = '*/*'
    dict_5['Accept-Encoding'] = 'gzip, deflate'
    dict_5['Connection'] = 'keep-alive'
    dict_5['Host'] = 'httpbin.org'
    dict_5['User-Agent'] = 'python-requests/2.22.0'
    session_6 = Session(path_1)

# Generated at 2022-06-25 19:30:19.564092
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Arguments
    session_0 = Session('C:\\Users\\sarah\\Desktop\\session_0.json')
    request_headers_0 = {}
    # Function call
    session_0.update_headers(request_headers_0)
    # verify the result
    assert {"headers":{}} == session_0


# Generated at 2022-06-25 19:30:23.773711
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = None
    session_0 = Session(str_0)
    request_headers_dict_0 = RequestHeadersDict({'Content-Type': 'application/json', 'Content-Length': '45'})
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:30:26.724227
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(str())
    session_0.load()
    str_0 = None
    session_0.remove_cookies(str_0)

test_case_0()

# Generated at 2022-06-25 19:30:31.203611
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = None
    session_0 = Session(str_0)
    session_0.load()
    session_0.cookies
    list_1 = []
    session_0.remove_cookies(list_1)


# Generated at 2022-06-25 19:30:39.050169
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """Test that update_headers stores only request headers that do not match
    any of the prefixes in `Session.SESSION_IGNORED_HEADER_PREFIXES`.

    """
    config = {
        'headers': None,
        'auth': None
    }
    session = Session(config)

    from httpie.cli.dicts import RequestHeadersDict
    request_headers = RequestHeadersDict()

    # First session load.
    request_headers['Content-Type'] = 'text/plain'
    request_headers['Content-Length'] = str(123)
    request_headers['User-Agent'] = 'curl/7.54.0'
    request_headers['If-None-Match'] = '*'
    request_headers['x-session-test'] = 'foo'