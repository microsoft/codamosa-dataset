

# Generated at 2022-06-25 19:21:08.592219
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert 1 == 1

# Generated at 2022-06-25 19:21:13.398483
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Create an instance of Session
    session_0 = Session('')
    # prepare the request_headers input
    request_headers_0 = httpie.cli.dicts.RequestHeadersDict()
    with pytest.raises(KeyError):
        session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:21:16.428272
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Initialization
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    # Call the method
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:21:17.246745
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert True


# Generated at 2022-06-25 19:21:22.321774
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    request_headers = {}
    session_0 = Session(path_0)
    assert isinstance(session_0, Session)
    # TODO: cover edge cases

    session_0.update_headers(request_headers)


# Generated at 2022-06-25 19:21:25.268769
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path_0)
    request_headers = {}
    session.update_headers(request_headers)


# Generated at 2022-06-25 19:21:28.727241
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_1 = pathlib.Path()
    session_1 = Session(path_1)
    request_headers_1 = RequestHeadersDict()
    session_1.update_headers(request_headers_1)



# Generated at 2022-06-25 19:21:31.848199
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    test_instance_0 = Session(path_0)

    request_headers = RequestHeadersDict()
    test_instance_0.update_headers(request_headers)

# Generated at 2022-06-25 19:21:36.164218
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict(path_0)
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:21:39.903444
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    # Test for method remove_cookies(self, names: Iterable[str])

    path_1 = pathlib.Path()
    session_1 = Session(path_1)
    assert session_1.remove_cookies() == None

import typing as module_0


# Generated at 2022-06-25 19:21:51.700696
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    request_headers_0 = httpie.cli.dicts.RequestHeadersDict('User-Agent=HTTPie/1.0.2')
    session_0.update_headers(
        request_headers_0
    )


# Generated at 2022-06-25 19:21:55.516508
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    try:
        request_headers_0 = RequestHeadersDict()
        session_0 = Session(None)
        session_0.update_headers(request_headers_0)
    except NameError as e:
        if "global name 'RequestHeadersDict' is not defined" not in e.args:
            raise


# Generated at 2022-06-25 19:22:02.311743
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_1 = module_0.Path()
    session_1 = Session(path_1)
    import json as module_1
    with open('sessions/localhost/my-session.json', 'r') as infile:
        session_1 = module_1.load(infile)
    session_1['cookies'] = {'q': {'value': 'search'}}
    normalized_0 = session_1['cookies']
    import requests as module_2
    cookies_0 = module_2.cookies.RequestsCookieJar()
    iterable_0 = normalized_0.items()
    names_0 = ['q']
    session_1.remove_cookies(names_0)


# Generated at 2022-06-25 19:22:06.986381
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict(session_0.headers)
    session_0.update_headers(request_headers_0)
    assert session_0.headers == {}


# Generated at 2022-06-25 19:22:11.293690
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    headers_0 = httpie.cli.dicts.RequestHeadersDict()
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:22:14.673210
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers = RequestHeadersDict()
    session_0.update_headers(request_headers)


# Generated at 2022-06-25 19:22:17.056029
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    # Act
    session_0 = Session(module_0.Path())
    session_0.remove_cookies([])


# Generated at 2022-06-25 19:22:18.743900
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    session_0.update_headers()


# Generated at 2022-06-25 19:22:21.729506
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Calling the method.
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    cookie_name_0 = "Cookie0"
    session_0.remove_cookies(cookie_name_0)


# Generated at 2022-06-25 19:22:24.995453
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    data_0 = pathlib.Path()
    session_0 = Session(data_0)
    str_0 = "Catarina"
    request_headers_0 = RequestHeadersDict(str_0)
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:22:32.550721
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config_dir_0 = Path()
    session_0 = get_httpie_session(config_dir_0, session_name=str(), host=str(), url=str())
    request_headers_0 = RequestHeadersDict()
    # pass the assertions
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:22:35.177022
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = ['cookies']
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:22:36.229585
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert 1 == 1


# Generated at 2022-06-25 19:22:40.667840
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_2 = ['REMOVE_COOKIE_0', 'REMOVE_COOKIE_1', 'REMOVE_COOKIE_2']
    session_0.remove_cookies(names_2)
    


# Generated at 2022-06-25 19:22:41.815018
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    method_0 = Session.remove_cookies
    assert callable(method_0)

# Generated at 2022-06-25 19:22:52.675926
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    request_headers_0 = {"key_0": "value_0"}
    session_0.update_headers({0: 0})
    assert session_0.headers == {}
    request_headers_0 = {"Content-Type": "application/json"}
    session_0.update_headers({0: 0})
    assert session_0.headers == {}
    request_headers_0 = {"user-agent": "HTTPie/0.9.8"}
    session_0.update_headers({0: 0})
    assert session_0.headers == {}
    request_headers_0 = {"cookie": "key_0=value_0"}
    session_0.update_headers({0: 0})
    assert session_0.headers == {}
   

# Generated at 2022-06-25 19:22:57.118599
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    names_0 = ['']
    session_0.remove_cookies(names_0)
    assert isinstance(session_0, Session)


import requests.cookies as module_0


# Generated at 2022-06-25 19:22:59.056775
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    session_0.update_headers()


# Generated at 2022-06-25 19:23:01.854578
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:23:08.295182
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    global path_0
    global session_0
    global request_headers_0
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    #test_Session_update_headers.py:99: 
    #        TypeError: 'dict_values' object does not support indexing
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:23:21.412072
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    pass  # Replace with real test

import jsonschema as module_2


# Generated at 2022-06-25 19:23:26.187358
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    with mock.patch.object(Session, 'save') as mocked_Session_save:
        mocked_Session_save.return_value = None
        path_0 = module_0.Path()
        session_0 = Session(path_0)
        input_0 = RequestHeadersDict()
        session_0.update_headers(input_0)


# Generated at 2022-06-25 19:23:36.845529
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Implementation details
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = []
    session_0.remove_cookies(names_0)
    path_1 = module_0.Path()
    session_1 = Session(path_1)
    names_1 = []
    session_1.remove_cookies(names_1)
    path_2 = module_0.Path()
    session_2 = Session(path_2)
    names_2 = []
    session_2.remove_cookies(names_2)
    path_3 = module_0.Path()
    session_3 = Session(path_3)
    names_3 = []
    session_3.remove_cookies(names_3)
    path_4 = module_0.Path

# Generated at 2022-06-25 19:23:41.679927
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    cookies_0 = RequestsCookieJar()

    def func_0(headers_0):
        return dict(headers_0)

    request_headers_0 = (func_0, func_0)
    session_0 = Session(path_0)

    # Update the session headers with the request ones while ignoring
    # certain name prefixes
    session_0.update_headers(request_headers_0)

    response_headers_0 = session_0.headers


# Generated at 2022-06-25 19:23:44.111952
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers = {}
    session_0.update_headers(request_headers)


# Generated at 2022-06-25 19:23:46.933555
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = set()
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:23:51.855289
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import pathlib as module_1
    path_1 = module_1.Path()
    session_1 = Session(path_1)
    import requests.structures as module_2
    request_headers_0 = module_2.CaseInsensitiveDict()
    session_1.update_headers(request_headers_0)


# Generated at 2022-06-25 19:23:55.447000
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = module_0.Path()
    session = Session(path)
    request_headers = RequestHeadersDict()

    # Test body
    session.update_headers(request_headers)



# Generated at 2022-06-25 19:23:57.726908
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(path_0)
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:24:02.450693
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    module_0 = module_0
    path_0 = Session(module_0.Path())
    request_headers_0 = RequestHeadersDict(path_0)
    path_0.update_headers(request_headers_0)
    # more specific test here.


# Generated at 2022-06-25 19:24:36.769782
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    class RequestHeadersDict_0(object):
        def __init__(self, keys_0, values_0):
            self.keys = keys_0
            self.values = values_0

        def items(self):
            return zip(self.keys, self.values)

    headers_0 = RequestHeadersDict_0(("Host", "Content-Type", "Accept", "Accept-Encoding"),("127.0.0.1:8000", "application/json", "application/json", "gzip,deflate"))
    class RequestHeadersDict_1(object):
        def __init__(self, keys_0, values_0):
            self.keys = keys_0
            self.values = values_0

        def items(self):
            return zip(self.keys, self.values)

    headers_1

# Generated at 2022-06-25 19:24:39.999622
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print(1)

    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = {
    }
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:24:42.783090
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    headers_0 = RequestHeadersDict()
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:24:48.880122
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)

    request_headers = {"User-Agent": "HTTPie/1.0.2"}
    session_0.update_headers(request_headers)
    assert session_0.headers == {"User-Agent": "HTTPie/1.0.2"}


# Generated at 2022-06-25 19:24:49.327153
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass


# Generated at 2022-06-25 19:24:50.745301
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(path_0)
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:24:58.571620
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_1 = DEFAULT_SESSIONS_DIR/'httpie_session.json'
    session_1 = Session(path_1)
    request_headers_0 = RequestHeadersDict()
    session_1.update_headers(request_headers_0)

    assert isinstance(session_1, Session)
    # if the header is not a header, then skip this header
    assert isinstance(session_1, Session)


# Generated at 2022-06-25 19:25:07.678062
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict("test_headers")
    session_0.update_headers(request_headers_0)
    path_1 = module_0.Path()
    session_1 = Session(path_1)
    request_headers_1 = RequestHeadersDict("test_headers")
    session_1.update_headers(request_headers_1)
    path_2 = module_0.Path()
    session_2 = Session(path_2)
    request_headers_2 = RequestHeadersDict("test_headers")
    session_2.update_headers(request_headers_2)


# Generated at 2022-06-25 19:25:12.679392
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:25:16.254631
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)

    # Call the method on the object with args:
    # request_headers={}
    # request_headers={}
    session_0.update_headers({})


# Generated at 2022-06-25 19:25:59.167394
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = session_0['cookies']
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:26:02.757468
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
  path_0 = 'fake'
  session_0 = Session(path_0)
  names_0 = []
  session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:26:03.394137
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert True


# Generated at 2022-06-25 19:26:08.179311
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Tests for basic functionality
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    request_headers_0 = httpie.cli.dicts.RequestHeadersDict(dict())

    # TODO: implement test
    pass


# Generated at 2022-06-25 19:26:13.696552
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    cookie_names_0 = iter()
    session_0 = Session(path_0)
    session_0.remove_cookies(cookie_names_0)
    assert (cookie_names_0 is None)


# Generated at 2022-06-25 19:26:16.733926
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = []
    # Calling function remove_cookies of class Session
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:26:24.518891
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import requests.cookies as cookies_module_0
    import httpie.cli.dicts as dicts_module_0
    import httpie.plugins.registry as plugins_module_0
    import httpie.config as module_0
    import httpie.plugins.builtin as module_1
    import requests as module_2
    path_0 = module_0.path_to_config_dir
    session_0 = Session(path_0)
    request_headers_0 = dicts_module_0.RequestHeadersDict()
    request_headers_0['set-cookie'] = 'username=JohnDoe; Max-Age=3600; Path=/; Secure'
    session_0.update_headers(request_headers_0)
    assert cookies_module_0.RequestsCookieJar() == session_0.cookies


# Generated at 2022-06-25 19:26:24.964462
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass


# Generated at 2022-06-25 19:26:30.262444
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.compat import OrderedDict
    from httpie.plugins import builtin
    from httpie.cli.argtypes import KeyValueArg
    cli_args = KeyValueArg(('Authorization:Basic', 'username:password'), 'basic')
    plugin_manager.set_plugins(tuple(builtin.plugins))
    plugin_manager.get_auth_plugin(cli_args.key)().update_auth(cli_args, OrderedDict(), tuple())

# Generated at 2022-06-25 19:26:36.093055
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Get session object at path_0
    path_0 = module_0.Path()
    session_0 = Session(path_0)

    # Get request_headers object at path_0
    request_headers_0 = RequestHeadersDict(path_0)

    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:27:01.743243
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    def test_case_7():
        path_0 = module_0.Path()
        session_0 = Session(path_0)
        request_headers_0 = RequestHeadersDict()
        session_0.update_headers(request_headers_0)
        return request_headers_0
    request_headers_0 = test_case_7()


# Generated at 2022-06-25 19:27:06.392034
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = module_0.Path()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:27:10.251809
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    path_0 = module_0.Path()
    str_0 = str()
    str_1 = str()
    session_0 = Session(path_0)
    session_0.remove_cookies(str_0)
    session_0.remove_cookies(str_1)


# Generated at 2022-06-25 19:27:11.411246
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    pass

import requests as module_0


# Generated at 2022-06-25 19:27:19.094609
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)

# Generated at 2022-06-25 19:27:23.379420
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from unittest.mock import Mock
    session_0 = Session("string")
    assert not hasattr(session_0, "remove_cookies")
    session_0.remove_cookies("Iterable")
    assert hasattr(session_0, "remove_cookies")

# Generated at 2022-06-25 19:27:26.674881
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)

# Generated at 2022-06-25 19:27:31.485641
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import httpie.cli.dicts
    
    # Test for issue #1004
    class _RequestHeadersDict(httpie.cli.dicts.RequestHeadersDict):
        def _key_normalize(self, name):
            return name.upper()
    
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    session_0.update_headers(_RequestHeadersDict())



# Generated at 2022-06-25 19:27:32.949255
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(__file__)
    session_0.update_headers()
    

# Generated at 2022-06-25 19:27:42.375924
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import CaseInsensitiveDict
    from httpie.compat import str
    from httpie.models import Request
    from httpie.plugins import plugin_manager
    from httpie import ExitStatus
    import requests
    from requests.auth import HTTPBasicAuth
    from requests.compat import urljoin
    from requests.cookies import RequestsCookieJar
    from httpie.config import Config
    from httpie.input import SEP_CREDENTIALS
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.compat import is_windows
    from httpie import ExitStatus
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from utils import TestEnvironment, http, HTTP_OK, COLOR, CRLF

# Generated at 2022-06-25 19:28:34.801532
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:28:44.215824
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.compat import str
    from httpie import cli
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins import plugin_manager
    from httpie import ExitStatus

    config = Config(
        options={
            'implicit_content_type': 'application/json',
            'default_options': ['--json'],
        },
    )
    plugin_manager.load_installed_plugins()

    env = Environment(
        stdin=cli.FileBytesIO(b'{"key_0": "value_0"}'),
        stdout=cli.FileBytesIO(),
        stderr=cli.FileBytesIO(),
        config=config,
        vars={},
        run_once=True,
    )

    # Test with valid session_name and host (expect

# Generated at 2022-06-25 19:28:48.550724
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:28:54.645787
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = []
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:28:59.273519
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Setup
    path_0 = pathlib.Path()
    session_0 = Session(path_0)

    # Actual
    session_0.update_headers()

# Generated at 2022-06-25 19:29:02.784322
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = iter([])
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:29:07.284387
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Clear the session cookies
    # if there is any
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    test_case_0()
    test_case_0()
    assert session_0.get_cookies() == dict()

# Generated at 2022-06-25 19:29:09.953654
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = None  # type: pathlib.Path
    session_0 = Session(path_0)
    names_0 = None  # type: Iterable[str]
    session_0 = Session(path_0)
    session_0.remove_cookies(names_0)

import requests
import pathlib as module_0


# Generated at 2022-06-25 19:29:14.474382
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path.home()
    session_0 = Session(path_0)
    names_0 = [module_0.Path("/home")]
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:29:14.962640
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    pass