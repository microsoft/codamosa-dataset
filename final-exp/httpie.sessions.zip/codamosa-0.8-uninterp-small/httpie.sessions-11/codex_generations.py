

# Generated at 2022-06-25 19:21:02.509026
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test-session')
    session.update_headers(
        {'Cookie': 'a=b; c=d; e=f', 'User-Agent': 'HTTPie/1.0'})
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {'cookie': 'a=b; c=d; e=f'}
    assert session['cookies'] == {'a': {'value': 'b'},
                                  'c': {'value': 'd'},
                                  'e': {'value': 'f'}}

# Generated at 2022-06-25 19:21:04.818895
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '2,U'
    session_0 = Session(str_0)
    request_headers_0 = {}
    session_0.update_headers(request_headers_0)

# Generated at 2022-06-25 19:21:13.638861
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_1 = Session('session_1.json')
    session_1.update_headers(RequestHeadersDict({'key_0':'value_0',
                                                 'key_1':'value_1',
                                                 'Content-Type':'application/json',
                                                 'User-Agent':'HTTPie/1.0.3',
                                                 'If-None-Match':'*'}))
    # Expect that Test-header is not in headers
    assert 'Test-header' not in session_1.headers


# Generated at 2022-06-25 19:21:16.332402
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'test': 'test'}
    test_Session = Session('')
    test_Session.cookies = cookies
    name = ['test']
    test_Session.remove_cookies(name)


# Generated at 2022-06-25 19:21:17.133255
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print("Testing method update_headers")


# Generated at 2022-06-25 19:21:29.295545
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('return_path')

# Generated at 2022-06-25 19:21:34.527913
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    print("test_Session_update_headers completed")


# Generated at 2022-06-25 19:21:39.191050
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(None)
    session['cookies'] = {'a': {'value': 'foo'}, 'b': {'value': 'bar'}}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {}

# Generated at 2022-06-25 19:21:43.334131
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '_\t=>0'
    session_0 = Session(str_0)
    session_0.remove_cookies(['v'])
    assert session_0.to_dict() == {
        "headers": "{}",
        "cookies": "{}",
        "auth": {
            "type": None,
            "username": None,
            "password": None
        }
    }


# Generated at 2022-06-25 19:21:54.231352
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # Strings
    string_0 = '0	0	0	'
    string_1 = '+++y	'

    # Headers
    header_0 = {'0': '0'}
    header_1 = {'+++y': '+++y'}
    header_2 = {'+++y': '+++y'}

    # Creating a Session
    session_0 = Session(string_0)

    # Calling the method
    session_0.update_headers(header_0)
    session_0.update_headers(header_1)
    session_0.update_headers(header_2)

    # Checking the result
    assert session_0.headers == {'+++y': '+++y'}

# Generated at 2022-06-25 19:22:05.824824
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    url = 'http://127.0.0.1:5000/'
    host = 'http://127.0.0.1:5000'
    dict_0 = {'Accept': 'application/json'}
    session_0 = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', host, url)
    session_0.update_headers(dict_0)
    dict_1 = {'Accept': 'application/json'}
    assert dict_0 == dict_1
    assert session_0['headers'] == dict_1
    session_1 = get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', host, url)
    dict_2 = {'Accept': 'application/json'}
    session_1.update_headers(dict_2)

# Generated at 2022-06-25 19:22:08.874459
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/test')
    request_headers = {'content-type': 'text'}
    session.update_headers(request_headers)
    assert session['headers'] == {'content-type': 'text'}


# Generated at 2022-06-25 19:22:16.936878
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_1 = Session("test_config")
    session_1['cookies'] = {
        'test1': 'test1',
        'test2': 'test2',
        'test3': 'test3'
    }
    session_2 = session_1
    session_2.remove_cookies(['test1'])

    assert (session_1['cookies'] == session_2['cookies'] and
            session_1['cookies'] == {'test2': 'test2', 'test3': 'test3'})

# Generated at 2022-06-25 19:22:26.324398
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
  session = Session(None)
  session['headers'] = {'myHeader': 'myValue'}
  session['auth'] = {'type': 'basic', 'username': 'me', 'password': 'password'}
  session['cookies'] = {'a': 'b', 'c': 'd'}
  session.remove_cookies({'a'})
  assert not 'a' in session['cookies']
  assert 'c' in session['cookies']
  assert 'myHeader' in session['headers']
  assert 'myValue' == session['headers']['myHeader']
  assert 'basic' == session['auth']['type']
  assert 'me' == session['auth']['username']
  assert 'password' == session['auth']['password']

# Generated at 2022-06-25 19:22:36.994485
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path = Path('/home/nishant/.config/httpie/sessions/google.com/a.json')
    session = Session(path)
    jar = RequestsCookieJar()
    name1 = 'session'
    cookie_dict1 = {
        'name': name1,
        'value': 'value',
        'path': '/',
        'expires': 'Fri, 26 Apr 2036 07:18:46 GMT'
    }
    name2 = 'session-token'
    cookie_dict2 = {
        'name': name2,
        'value': 'value',
        'path': '/',
        'expires': 'Fri, 26 Apr 2036 07:18:46 GMT'
    }
    jar.set_cookie(create_cookie(**cookie_dict1))

# Generated at 2022-06-25 19:22:43.412001
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """
    headers=[('Content-Length', '0'), ('Server', 'None')]
    """

    session = Session('session_test')
    request_headers = dict(
        [('Content-Length', '0'), ('Server', 'None')]
    )

    session.update_headers(request_headers)

    assert(session.get('headers') == {})
    assert(session.get('cookies') == {})
    assert(session.get('auth') == {
        'type': None,
        'username': None,
        'password': None
    })



# Generated at 2022-06-25 19:22:54.369909
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print("\n")
    print("************************************************************")
    print("Testing update_headers of Session class")
    print("************************************************************")
    #Error Case with invalid argument
    try:
        s = Session("Session_1")
        h = 'User-Agent'
        s.update_headers(h)
        print("Test failed!")
    except TypeError:
        print("Test passed!")
    #Positive Case

# Generated at 2022-06-25 19:23:03.195293
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test Case #0
    str_0 = '_\t=>0'
    session_0 = Session(str_0)
    session_0['cookies'] = {}
    session_0['cookies']['>'] = {},
    session_0['cookies']['y'] = {},
    session_0['cookies']['Z'] = {},
    session_0['cookies']['P'] = {},
    session_0['cookies']['f'] = {},
    session_0['cookies']['u'] = {},
    session_0['cookies']['`'] = {},
    session_0['cookies']['N'] = {},
    session_0['cookies']['C'] = {},

# Generated at 2022-06-25 19:23:13.565273
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {
        'Host': 'httpbin.org',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'HTTPie/2.0.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,'
        'image/webp,*/*;q=0.8',
        'Accept-Encoding': 'gzip, deflate, sdch, br',
        'Accept-Language': 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4,zh-TW;q=0.2',
    }

    session_1 = Session('./test_session.json')
    session_1.update_headers

# Generated at 2022-06-25 19:23:16.110285
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '_\t=>0'
    session_0 = Session(str_0)
    names = []
    session_0.remove_cookies(names)


# Generated at 2022-06-25 19:23:31.766262
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass


# Generated at 2022-06-25 19:23:41.933982
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '_\t=>0'
    session_0 = Session(str_0)
    assert session_0.path == Path(str_0)

    session_0['cookies'] = {}
    names = []
    session_0.remove_cookies(names)

    session_0['cookies'] = {}
    names = ['a']
    session_0.remove_cookies(names)

    session_0['cookies'] = {}
    names = ['a']
    session_0.remove_cookies(names)

    session_0['cookies'] = {'a':'a'}
    names = ['a']
    session_0.remove_cookies(names)

    session_0['cookies'] = {'a':'a'}
    names = []
    session_0.remove_

# Generated at 2022-06-25 19:23:49.366370
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = '/etc/profile'
    str_0 = 'vw}u/'
    session_0 = Session(path_0)
    assert VALID_SESSION_NAME_PATTERN.match(str_0)
    assert type(os.path.expanduser(str_0)) is str
    assert type(os.path.sep) is str
    assert type(os.path.expanduser(str_0)) is str
    assert type(os.path.sep) is str
    assert session_0.remove_cookies([str_0]) == None


# Generated at 2022-06-25 19:23:53.120683
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("test.json")
    session["cookies"] = {"ABC": {"value": "123"}}
    session.remove_cookies(["ABC"])
    assert("ABC" not in session["cookies"])
# vim: %s et ts=4 sw=4 sts=4

# Generated at 2022-06-25 19:23:57.811613
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    session = Session("Test")
    session.cookies = RequestsCookieJar()
    session.cookies.set('name', 'value')

    # Assert
    session.remove_cookies(['name'])
    assert session.cookies == RequestsCookieJar()

# Generated at 2022-06-25 19:24:05.953085
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    list_0 = list()
    list_0.append('_\t=>0')
    list_0.append('[')
    list_0.append(']')
    list_0.append('1')
    list_0.append('\x7f‹')
    session_0 = Session(list_0, False)
    session_0.remove_cookies('[')
    session_0.remove_cookies('1')
    session_0.remove_cookies('_\t=>0')
    session_0.remove_cookies(']')
    session_0.remove_cookies('\x7f‹')

# Generated at 2022-06-25 19:24:12.885922
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import random
    import string

    random_str = ''.join([random.choice(string.printable) for n in range(100)])
    session_0 = Session('\t=>0')

    len_0 = random.randint(0, 100)
    var_0 = tuple([random.choice(string.printable) for n in range(len_0)])

    session_0.remove_cookies(var_0)


# Generated at 2022-06-25 19:24:21.230653
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies_dict = {
        'abc': {'value': '123'},
        'xyz': {'value': '123'},
        'def': {'value': '123'}}
    session_0 = Session('test')
    session_0['cookies'] = cookies_dict
    assert len(session_0['cookies'].keys()) == 3
    session_0.remove_cookies(['abc', 'xyz'])
    assert len(session_0['cookies'].keys()) == 1
    assert 'def' in session_0['cookies'].keys()

# Generated at 2022-06-25 19:24:33.589532
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('')
    strs = []

    # IN
    strs.append(['a'])
    strs.append(['a', 'b'])
    # OUT
    strs.append([])
    strs.append(['a'])
    # IN + OUT
    strs.append(['a', 'b'])
    
    for str in strs:
        session_0.cookies = RequestsCookieJar()
        for name in str:
            session_0['cookies'][name] = {'value': 'a'}

        session_0.remove_cookies(str)

        if len(str) == 0:
            assert len(session_0['cookies']) == 0

# Generated at 2022-06-25 19:24:38.664845
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # session_0 => 0
    str_0 = '_\t=>0'
    session_0 = Session(str_0)
    # names_0 => 0
    str_1 = '_\t=>0'
    names_0 = str_1.split(',')
    # call method remove_cookies
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:24:49.697446
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '_\t=>0'
    session_0 = Session(str_0)
    assert isinstance(session_0, Session)

    str_1 = '_\t=>1'
    session_0.remove_cookies((str_1,))


# Generated at 2022-06-25 19:24:55.812088
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '_\t=>0'
    session_0 = Session(str_0)

    # Test execution

    test_result = session_0.remove_cookies(('3z', '+5'))

    assert test_result is None


# Generated at 2022-06-25 19:24:59.673287
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    from httpie.session import Session
    from httpie.cli.argtypes import KeyValueArg
    from httpie.compat import str

    instance = Session(Path('/a/b'))
    instance.cookies = {'a': 'b'}

    assert instance.cookies['a'] == 'b'

    instance.remove_cookies(['a'])
    assert 'a' not in instance.cookies

# Generated at 2022-06-25 19:25:04.551740
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '_\t=>0'
    session_0 = Session(str_0)
    str_1 = 'this_is_not_a_key'
    list_0 = []
    list_0.append(str_1)
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:25:07.687987
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {'foo': {}, 'bar': {}}
    names = ['foo', 'baz']
    session.remove_cookies(names)
    assert session['cookies'] == {'bar': {}}

# Generated at 2022-06-25 19:25:16.367070
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies_0 = {}
    cookie_0 = {}
    cookie_1 = {}
    cookie_2 = {}
    cookies_0.update({'0': cookie_0, '1': cookie_1, '2': cookie_2})
    session_0 = Session('../../test')
    session_0.__setitem__('cookies', cookies_0)
    session_1 = Session('../../test')
    session_1.__setitem__('cookies', cookies_0)
    session_0.remove_cookies(['0', '1', '2'])



# Generated at 2022-06-25 19:25:24.953045
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    session_0 = Session('')
    session_0.cookies = RequestsCookieJar()
    session_0.cookies.set('test_name', 'test_value', path='/test_path')
    session_0.cookies.set('test_name2', 'test_value2', path='/test_path2')

    # Act
    session_0.remove_cookies(['test_name'])

    # Assert
    assert 'test_name' not in session_0.cookies
    assert 'test_name2' in session_0.cookies

# Generated at 2022-06-25 19:25:33.725770
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    # Testing if we can add cookies without a problem
    string_0 = '_\t=>0'
    session_0 = Session(string_0)

    # Testing if we can add cookies without a problem
    string_0 = '_\t=>0'
    session_0 = Session(string_0)
    if 'cookies' not in session_0:
        session_0['cookies'] = {}

    # Testing if we can add cookies without a problem
    string_0 = '_\t=>0'
    session_0 = Session(string_0)
    if 'cookies' not in session_0:
        session_0['cookies'] = {}

    # Testing if we can add cookies without a problem
    string_0 = '_\t=>0'
    session_0 = Session(string_0)

# Generated at 2022-06-25 19:25:37.776591
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    test = Session('')
    test.cookies = {'key0': {'value': 'value0'}}

    test.remove_cookies(['key0'])
    assert test.cookies['key0'] != ['value0']


# Generated at 2022-06-25 19:25:47.185440
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    data = {
        'cookies': {
            'name_0': 'value_0',
            'name_1': 'value_1',
            'name_2': 'value_2'
        }
    }
    obj = Session(data)
    list_0 = []
    obj.remove_cookies(list_0)
    assert obj.cookies['name_0'] == 'value_0'
    assert obj.cookies['name_1'] == 'value_1'
    assert obj.cookies['name_2'] == 'value_2'
    list_1 = ['name_1', 'name_0']
    obj.remove_cookies(list_1)
    assert len(obj.cookies) == 1


# Generated at 2022-06-25 19:26:05.402894
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/Users/paul/.httpie/sessions/')
    session.remove_cookies(['cookies'])

# Generated at 2022-06-25 19:26:13.507527
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'mJc@}Be(9~s<'
    session_0 = Session(str_0)
    dict_0 = {'g2N4Z': '', 'A+{6U': '6'}
    session_0.update_cookies(dict_0)
    session_0.remove_cookies('[I0W|')
    str_1 = 'H&O8O'
    str_2 = '-B_R#'
    str_3 = '~U%Y6'
    str_4 = '?'
    session_0.set_auth(str_1, str_2, str_3, str_4)
    session_0.dump()


# Generated at 2022-06-25 19:26:17.300097
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    _ = (
        '_\t=>0'
    )
    _0 = (
        '_\t=>0'
    )
    _1 = (
        '_\t=>0'
    )
    session_0 = Session(_)
    session_0.remove_cookies(_0)



# Generated at 2022-06-25 19:26:24.450416
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test case 0
    session_cookies = {'Authorization': 'EDSSSSB-F60F-4ACB-B796-1499D7FFCE8E',
                       'B': '9',
                       'C': '37',
                       'D': '3',
                       'User': 'A'}
    session = Session({})
    session.session = {}
    session.session["headers"] = {'A': '10', 'B': '20'}
    session.session["cookies"] = session_cookies
    names = ["Authorization",
             "B",
             "User"]
    session.remove_cookies(names)
    assert session.session['cookies'] == {'C': '37', 'D': '3'}

# Generated at 2022-06-25 19:26:34.012947
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = [('my_cookie', 'my_value'), ('my_cookie1', 'my_value1')]
    session_0 = Session('my_url')
    session_0['cookies'].update(cookies)
    session_0.remove_cookies(['my_cookie'])
    remove_val = True
    try:
        assert session_0['cookies']['my_cookie'] == None
    except:
        remove_val = False

    assert remove_val
    session_0.remove_cookies(['my_cookie1'])
    remove_val2 = False
    try:
        assert session_0['cookies']['my_cookie1'] == None
    except:
        remove_val2 = True
    assert remove_val2

# Generated at 2022-06-25 19:26:44.076027
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    print('Test Session.remove_cookies')
    # Constructor with arguments
    str_0 = '_\t=>0'
    session_0 = Session(str_0)
    # Set cookies
    dict_0 = {}
    dict_0['path'] = '_\t=>0'
    dict_0['secure'] = False
    dict_1 = {}
    dict_1['path'] = ' _\t=>0'
    dict_1['secure'] = False
    dict_2 = {}
    dict_2['path'] = ' _\t=>0'
    dict_2['secure'] = False
    list_0 = [dict_0, dict_1, dict_2]
    session_0.cookies = list_0
    # Call method remove_cookies

# Generated at 2022-06-25 19:26:50.069412
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    """
    Session.remove_cookies()

    # 0
    """
    str_0 = '_\t=>0'
    session_0 = Session(str_0)
    class_8 = session_0.get('cookies', None)
    class_8 = copy.copy(class_8)
    var_43 = class_8.pop(var_22)
    class_8.update({var_22: var_43})
    # 0
    session_0.set('cookies', class_8)
    str_0 = '_\t=>0'
    str_1 = '_\t=>1'
    session_0 = Session(str_0)
    session_1 = Session(str_1)
    class_8 = session_0.get('cookies', None)
    class_8 = copy

# Generated at 2022-06-25 19:26:54.924807
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(str)
    str_1 = '_\t=>0'
    session_0.remove_cookies(str_1)

# Generated at 2022-06-25 19:26:57.555887
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session(str_0)
    session_0.remove_cookies(str_1)


# Generated at 2022-06-25 19:27:00.964205
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_1 = '_\t=>0'
    session_1 = Session(str_1)
    names_1 = ('[', ')', '{', '$', 'i', '^', 'v', 'W', '-', 'x')
    session_1.remove_cookies(names_1)

# Generated at 2022-06-25 19:27:46.823269
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_1 = Session("")
    dict_0 = {'cookies': ['value_0'], 'headers': 'value_1'}
    session_1.__dict__ = dict_0
    iterator_0 = ['value_2']
    session_1.remove_cookies(iterator_0)
    dict_1 = {'cookies': ['value_2'], 'headers': 'value_1'}
    assert session_1.__dict__ == dict_1


# Generated at 2022-06-25 19:27:51.154641
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    keys = ['abc', 'def', 'ghi']
    values = ['123', '456', '789']
    s = Session(0)
    s['cookies'] = {x: {'value': y} for x, y in zip(keys, values)}
    s.remove_cookies([keys[0], keys[2]])
    assert s['cookies'].keys() == {keys[1]}

# Generated at 2022-06-25 19:27:55.329445
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session.cookies = [
        {'name': 'a', 'value': 1},
        {'name': 'b', 'value': 2},
        {'name': 'c', 'value': 3},
    ]
    session.remove_cookies(['b'])
    print(session)



# Generated at 2022-06-25 19:27:59.479055
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test case 0
    session = Session(path = "test_case_0")
    session['cookies'] = {'_': {'value': 0}}
    assert session['cookies'] == {'_': {'value': 0}}
    session.remove_cookies('_')
    assert session['cookies'] == {}



# Generated at 2022-06-25 19:28:02.138195
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session("session_file")
    session_0.load()
    session_0.remove_cookies([])

# Generated at 2022-06-25 19:28:12.083859
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie1 = dict(name='cookie1', value='example')
    cookie2 = dict(name='cookie2', value='example')
    cookie3 = dict(name='cookie3', value='example')
    cookie4 = dict(name='cookie4', value='example')
    cookie5 = dict(name='cookie5', value='example')

    cookies_list = [cookie1, cookie2, cookie3, cookie4, cookie5]
    cookie_names_list = []

    for item in cookies_list:
        cookie_names_list.append(item['name'])

    jar = RequestsCookieJar()
    for cookie in cookies_list:
        jar.set_cookie(create_cookie(cookie['name'], cookie['value']))


    session_drop = Session('test_Session_remove_cookies')

# Generated at 2022-06-25 19:28:22.436238
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '_\t=>0'
    session_0 = Session(str_0)
    session_0['cookies'] = {}
    session_0['cookies']['_'] = {}
    session_0['cookies']['_']['value'] = '\t'
    session_0['cookies']['_']['path'] = '=>0'
    session_0['cookies']['_']['secure'] = False
    session_0['cookies']['_']['expires'] = None
    session_0['cookies']['_']['comment'] = None
    session_0['cookies']['_']['comment_url'] = None
    session_0['cookies']['_']['rest'] = {}

# Generated at 2022-06-25 19:28:23.549964
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert Session.remove_cookies('ABC') == 'CBA'



# Generated at 2022-06-25 19:28:29.986431
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '_\t=>0'
    session_0 = Session(str_0)
    str_1 = 'RAHU'
    session_0.remove_cookies(str_1)
    str_2 = '_\x0a=>0'
    session_0.remove_cookies(str_2)
    str_3 = '_\x0b=>0'
    session_0.remove_cookies(str_3)
    str_4 = '_\x0c=>0'
    session_0.remove_cookies(str_4)
    str_5 = '_\x0e=>0'
    session_0.remove_cookies(str_5)
    str_6 = '_\x0f=>0'

# Generated at 2022-06-25 19:28:34.608812
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    name_0 = 'test_name'
    # Test for raise_for_status()
    # Test for remove_cookies()
    session_0 = Session(name_0)
    session_0.remove_cookies([name_0])

if __name__ == '__main__':
    test_case_0()
    test_Session_remove_cookies()

# Generated at 2022-06-25 19:30:00.011362
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '_\t=>0'
    cookie_name_0 = '_\t=>0'
    session_0 = Session(str_0)
    session_0.remove_cookies(cookie_name_0)


# Generated at 2022-06-25 19:30:05.557168
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    dict_0 = Session(0)
    dict_0['cookies'] = {'0': {}, '1': {}, '2': {}, '3': {}, '4': {}}
    dict_0.remove_cookies(['0', '2', '4'])
    assert dict_0['cookies'] == {'1': {}, '3': {}}

test_case_0()
test_Session_remove_cookies()

# Generated at 2022-06-25 19:30:07.985432
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from pytest import raises
    from httpie.plugins.session import Session

    with raises(Exception, match='not yet implemented'):
        session_0 = Session()
        session_0.remove_cookies()

# Generated at 2022-06-25 19:30:12.808683
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.compat import is_py2

    key_value_arg_0 = KeyValueArg(('(', ')'))
    key_value_arg_0.formatter = '<{name}={value}>'
    session__0 = Session('test_cases/test_case_0')
    session__0.cookies = [('_', '\t=>0')]
    session__0.assert_headers({})
    session__0.remove_cookies(['_'])



# Generated at 2022-06-25 19:30:23.221390
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'name1':{'value': 'val1'}, 'name2':{'value': 'val2'}}
    
    session_1 = Session('Sessionname')
    session_1['cookies'] = cookies
    assert session_1['cookies'] == cookies

    session_1.remove_cookies(('name1',))
    cookies.pop('name1')
    assert session_1['cookies'] == cookies
    
    cookies = {'name1':{'value': 'val1'}, 'name2':{'value': 'val2'}}
    
    session_2 = Session('Sessionname')
    session_2['cookies'] = cookies
    assert session_2['cookies'] == cookies
    
    session_2.remove_cookies(('name3',))
    cookies.pop('name3')

# Generated at 2022-06-25 19:30:28.464384
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_1 = 'RFC6265'
    session_1 = Session(str_1)
    cookies_3 = {'RFC6265': {'value': 'RFC6265', 'comment': 'RFC6265'}}
    session_1['cookies'] = cookies_3
    name_1 = ['RFC6265', 'RFC6265']
    session_1.remove_cookies(name_1)


# Generated at 2022-06-25 19:30:36.763222
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    #test cases
    session = Session('test')
    #case 0: cookies not set
    session.remove_cookies([])
    assert session['cookies'] == {}
    #case 1: cookies set
    session['cookies'] = {'a': 1, 'b': 2}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': 2}
    #case 2: cookies set with cookies to remove not in cookies
    session['cookies'] = {'a': 1, 'b': 2}
    session.remove_cookies(['c'])
    assert session['cookies'] == session['cookies']

# Generated at 2022-06-25 19:30:42.673061
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '_\t=>0'
    session_0 = Session(str_0)

    session_0.remove_cookies(('_\t=>0',))
