

# Generated at 2022-06-25 19:20:57.086910
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(Path('client.json'))
    session_0.update_headers(RequestHeadersDict({'User-Agent': 'HTTPie/1.0.2', 'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*', 'Host': 'localhost:8000'}))

# Generated at 2022-06-25 19:21:01.083437
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Setup
    str_0 = 'q+enhs/~;mas2'
    session_0 = Session(str_0)

    # Actual test
    session_0.remove_cookies(['q+enhs/~;mas2'])



# Generated at 2022-06-25 19:21:03.585642
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('Session_0')
    request_headers = RequestHeadersDict({'Host': 'www.example.com'})
    session.update_headers(request_headers)
    assert session.headers == request_headers

# Generated at 2022-06-25 19:21:05.781703
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies_name_list = []
    session_object = Session('./httpie/session.json')
    session_object.remove_cookies(cookies_name_list)


# Generated at 2022-06-25 19:21:16.188917
# Unit test for method update_headers of class Session

# Generated at 2022-06-25 19:21:27.710024
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'q+enhs/~;mas2'
    key_0 = 'fIk-XE[=}x'
    val_0 = 'I++s/s:s'
    session_0 = Session(str_0)
    headers_0 = {key_0: val_0}
    session_0.update_headers(headers_0)
    print(">>TEST_CASE_0\n>>The value of var session_0 is: {}".format(session_0))
    print(">>TEST_CASE_0\n>>The value of var headers_0 is: {}".format(headers_0))

if __name__ == '__main__':
    test_case_0()
    test_Session_update_headers()

# Generated at 2022-06-25 19:21:30.296741
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '/'
    session_0 = Session(str_0)
    session_0.remove_cookies(Iterable[str])

# Generated at 2022-06-25 19:21:41.151706
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'q+enhs/~;mas2'
    session_0 = Session(str_0)
    dict_0 = dict(**{('sanctus', 'laudantium'): 7936, 'voluptate': 'harum', 'aliquam': 'nemo', 'incidunt': 'dolore', 'eius': 'quia'})
    dict_1 = dict(**{('sanctus', 'laudantium'): 7936, 'voluptate': 'harum', 'aliquam': 'nemo', 'incidunt': 'dolore', 'eius': 'quia'})

# Generated at 2022-06-25 19:21:51.739720
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    url = "http://httpbin.org/get"
    headers = {"accept": "application/json"}
    req_headers = {"accept": "application/json", "user-agent": "HTTPie/1.0.6"}
    session = get_httpie_session(DEFAULT_CONFIG_DIR, "foo", None, url)
    session.update_headers(req_headers)
    assert session.headers == headers
    session = get_httpie_session(DEFAULT_CONFIG_DIR, "foo", None, url)
    session.update_headers(req_headers)
    session.update_headers(req_headers)
    assert session.headers == headers


# Generated at 2022-06-25 19:21:54.673877
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test/session.json')
    session.update_headers({'Accept': 'application/json', 'Accept-Encoding': '*'})
    assert session['headers'] == {"Accept": "application/json", "Accept-Encoding": "*"}


# Generated at 2022-06-25 19:22:04.226294
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_1 = Session('q+enhs/~;mas2')
    session_1.cookies = RequestsCookieJar()
    session_1['cookies']['first'] = 'first'
    session_1['cookies']['second'] = 'second'
    session_1['cookies']['third'] = 'third'
    session_1.remove_cookies(['first', 'third'])
    assert session_1['cookies'] == {'second': 'second'}
    session_1.remove_cookies(['second'])
    assert session_1['cookies'] == {}


# Generated at 2022-06-25 19:22:06.653027
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {'Accept': '*/*', 'User-Agent': 'HTTPie/0.9.9'}
    Session.update_headers(request_headers)


# Generated at 2022-06-25 19:22:17.595012
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = {'chocolate':{'value':'chip'}, 'snickerdoodle':{'value':'chewy'}}
    s = Session('fun')
    s['cookies'] = cookies
    s.remove_cookies(('chocolate'))
    print(s['cookies'])
    s.remove_cookies(tuple('snickerdoodle'))
    print(s['cookies'])
    s['cookies'] = cookies
    s.remove_cookies(['chocolate'])
    print(s['cookies'])
    s.remove_cookies(['snickerdoodle'])
    print(s['cookies'])
    s['cookies'] = cookies
    s.remove_cookies(('chocolate','snickerdoodle'))
    print(s['cookies'])
   

# Generated at 2022-06-25 19:22:22.314821
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'q+enhs/~;mas2'
    session_0 = Session(str_0)
    str_1 = 'S`+(|y+Ql'
    dict_0 = {'f': str_1}
    session_0.update_headers(dict_0)


# Generated at 2022-06-25 19:22:34.736544
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # Test Session: parameter 1
    class TestSession_update_headers_parameter_1:
        def __init__(self, request_headers):
            self.request_headers = request_headers

    # Test Session: parameter 1 value
    class TestSession_update_headers_parameter_1_value:
        def __init__(self, name, value):
            self.name = name
            self.value = value

    # Test Session: parameter 1.request_headers
    class TestSession_update_headers_parameter_1_request_headers:
        def __init__(self, items):
            self.items = items

    # Test Session: parameter 1.request_headers.items
    class TestSession_update_headers_parameter_1_request_headers_items:
        def __init__(self, name, value):
            self

# Generated at 2022-06-25 19:22:41.361531
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    cookie_0 = 'q+enhs/~;mas2'
    name_0 = 'dwqe'
    value_0 = 'q+enhs/~;mas2'
    request_headers_0 = {name_0: value_0}
    str_0 = 'q+enhs/~;mas2'
    Session_0 = Session(str_0)
    request_headers_0['Cookie'] = cookie_0
    Session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:22:47.689434
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'q+enhs/~;mas2'
    session_0 = Session(str_0)
    dict_0 = {
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'User-Agent': 'HTTPie/0.1.0',
        'User-Agent': 'HTTPie/0.1.0',
    }
    session_0.update_headers(dict_0)


# Generated at 2022-06-25 19:22:56.416013
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
	str_0 = 'k5(ac6wc%6'
	session_0 = Session(str_0)
	names_0 = ['7i/%:*' , '7i/%:*' , '7i/%:*' , '7i/%:*' , '7i/%:*' , '7i/%:*' , '7i/%:*' , '7i/%:*' , '7i/%:*' , '7i/%:*' , '7i/%:*' , '7i/%:*']
	session_0.remove_cookies(names_0)



# Generated at 2022-06-25 19:23:00.242536
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'uf'
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict(str_0)
    session_0.update_headers(request_headers_0)
    assert session_0.headers == RequestHeadersDict(str_0)


# Generated at 2022-06-25 19:23:09.848146
# Unit test for method update_headers of class Session

# Generated at 2022-06-25 19:23:18.716821
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'y7qe'
    path = Path(str_0)
    session_0 = Session(path)

    str_1 = 'users'
    headers_0 = RequestHeadersDict({str_1: str_1})
    session_0.update_headers(headers_0)



# Generated at 2022-06-25 19:23:22.351421
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'q+enhs/~;mas2'
    session_0 = Session(str_0)
    names_0 = ['n9a|;7V,b']
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:23:30.046853
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # Create a new session object
    session = Session('/path/to/session.json')

    # Create two headers dictionaries to compare
    headers1 = {
        'A': 'value1',
        'C': 'value3',
        'Cookies': 'Cookie1=value1, Cookie2=value2'
    }
    headers2 = {
        'A': 'value1',
        'C': 'value3'
    }

    # Create cookie jar to compare after adding cookies
    cookies1 = RequestsCookieJar()
    cookie1 = create_cookie('Cookie1', 'value1')
    cookie2 = create_cookie('Cookie2', 'value2')
    cookies1.set_cookie(cookie1)
    cookies1.set_cookie(cookie2)

    # Call the method
    session.update_headers

# Generated at 2022-06-25 19:23:33.050108
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('q+enhs/~;mas2')
    session_0.remove_cookies(['q+enhs/~', '~;mas2'])


# Generated at 2022-06-25 19:23:42.706965
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test case 1 (run locally)
    str_1 = 'httpbin.org'
    session_1 = Session(str_1)
    session_dict_1 = {'json': '{"key": "value"}'}
    session_1.update_headers(session_dict_1)
    assert session_1.headers == {'json': '{"key": "value"}'}
    assert session_1.cookies == RequestsCookieJar()
    assert session_1.auth == None

    # Test case 2 (run locally)
    str_2 = 'httpbin.org'
    session_2 = Session(str_2)
    session_dict_2 = {'json': '{"key": "value"}'}
    session_2.update_headers(session_dict_2)

# Generated at 2022-06-25 19:23:44.781309
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('#/')
    request_headers = {}
    session_0.update_headers(request_headers)

# Generated at 2022-06-25 19:23:48.752548
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    str_0 = 'sjt;m*_a$9t.f'
    session_0 = Session(str_0)

    str_1 = 'i00N;4Nj4|X'
    session_0.remove_cookies([str_1])



# Generated at 2022-06-25 19:23:55.950597
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_2 = 'q+enhs/~;mas2'
    session_2 = Session(str_2)
    headers_2 = {'Accept': '*/*', 'User-Agent': 'HTTPie/1.0.2'}
    session_2.update_headers(headers_2)
    headers_2 = {'Accept': '*/*', 'User-Agent': 'HTTPie/1.0.2'}
    session_2.update_headers(headers_2)
    session_2 = None


# Generated at 2022-06-25 19:24:00.710493
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = ':'
    session_0 = Session(str_0)

    path_0 = Path(str_0)
    session_1 = Session(path_0)

    path_1 = Path()
    session_2 = Session(path_1)



# Generated at 2022-06-25 19:24:03.328161
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Tests if the return type is correct
    names_0 = ['mag']
    assert isinstance(Session.remove_cookies(names_0), None)



# Generated at 2022-06-25 19:24:23.405996
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    cookies_0 = RequestsCookieJar()

    config_dir_0 = Path(None)
    session_name_0 = 'session'
    headers_0 = RequestHeadersDict()
    host_0 = 'host'
    url_0 = 'http://host/path'

    session_1 = get_httpie_session(config_dir_0, session_name_0, host_0, url_0)

    # Test where method update_headers of class Session ArgumentTypeError
    # error

    class session_2(session_1):

        def update_headers(self, request_headers):
            raise ArgumentTypeError('Method update_headers of class Session\n')

    with pytest.raises(ArgumentTypeError):
        session_2.update_headers(headers_0)


# Generated at 2022-06-25 19:24:33.383738
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('')
    str_0 = 'b:tkp^EEIgWb!'
    str_1 = '?yMoQlD-L^F[v'
    str_2 = 'T{#NPE=H_G?|c'
    str_3 = '{@6/?'
    str_4 = '3<5"lS=2a'
    str_5 = 'q?;4'
    session_0.remove_cookies((str_0, str_1, str_2, str_3, str_4, str_5))


# Generated at 2022-06-25 19:24:41.430060
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'Some string'
    session_0 = Session(str_0)
    session_0['headers'] = {'Some string': 'dhEj+L', 'dhEj+L': 'dhEj+L', 'j$|;': 'j$|;'}
    str_1 = 'j$|;'
    str_2 = 'j$|;'
    str_3 = 'j$|;'
    dict_0 = {str_1: str_2, str_3: str_2}
    assert_equal(dict_0, session_0['headers'], "session_0['headers'] did not equal: expected: %s actual: %s" % (dict_0, session_0['headers']))


# Generated at 2022-06-25 19:24:48.429665
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import ExitStatus, __version__
    from httpie.client import JSON_ACCEPT
    from httpie.compat import urlopen
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from tests.test_client import TestClient
    from httpie.output.streams import NoopStream, StdoutBytesIO
    http_1_1 = 'HTTP/1.1'
    env = Environment(stdout=NoopStream, stderr=NoopStream)
    # Call method HTTPie.get_response of class Client
    str_1 = 'http://httpbin.org/headers'
    str_2 = 'GET'
    str_3 = 'Accept'
    str_4 = 'application/json'
    config_dict_0 = {
    }
    client_0 = Test

# Generated at 2022-06-25 19:24:52.868634
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = "Session"
    session_0 = Session(str_0)
    session_0.headers = {
        'Accept': 'application/json', 
        'Content-Type': 'application/json', 
        'X-Something': 'foo'}
    session_0.update_headers({
        'Content-Type': 'application/json', 
        'If-Modified-Since': 'Sat', 
        'X-Something': 'foobar'})

# Generated at 2022-06-25 19:24:57.947605
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'q+enhs/~;mas2'
    session_0 = Session(str_0)
    names_1 = 'q+enhs/~;mas2'
    session_0.remove_cookies(names_1)


# Generated at 2022-06-25 19:25:05.642532
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers = RequestHeadersDict()
    headers['Accept'] = 'text/html'
    headers['Host'] = 'httpie.org'
    headers['Cookie'] = 'name=HTTPie'
    session = Session('session')
    session.update_headers(headers)
    assert session['headers']['Accept'] == 'text/html'
    assert session['headers']['Host'] == 'httpie.org'
    assert session['cookies']['name']['value'] == 'HTTPie'


# Generated at 2022-06-25 19:25:16.862676
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(os.path.dirname(os.path.dirname(os.path.realpath(__file__))) + '/configs/sessions/127.0.0.1/foo.json')
    headers = {
        "Content-Length": "0",
        "Content-Type": "text/plain; charset=utf-8",
        "Host": "httpbin.org",
        "User-Agent": "HTTPie/1.0.0-dev",
        "X-Amzn-Trace-Id": "Root=1-5e4b4e4c-c1f8f9da35b9a9a2a2fcfac8"
    }
    session.update_headers(headers)
    keys = session.get("headers").keys()
    assert "Content-Length" not in keys


# Generated at 2022-06-25 19:25:19.794671
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    credentials = {'username': None, 'password': None}
    assert {'username', 'password'} == credentials.keys()
    session_1 = Session(credentials)


# Generated at 2022-06-25 19:25:30.611000
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'q+enhs/~;mas2'
    session_0 = Session(str_0)

# Generated at 2022-06-25 19:25:43.998896
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # create a cookies instance
    cookie_test = RequestsCookieJar()
    cookie_test.set('test1', 'test11', domain='test.domain')
    cookie_test.set('test2', 'test22', domain='test.domain')
    # create a headers instance
    headers_test = RequestHeadersDict({'host': 'test.host', 'content-type': 'text', 'cookie': cookie_test})
    # create a auth instance
    auth_test = {'type': 'basic', 'username': 'test', 'password': 'test'}
    # create a session instance
    session_test = Session('test')
    session_test.auth = auth_test
    session_test.cookies = cookie_test
    print(session_test.headers)
    session_test.update_headers(headers_test)

# Generated at 2022-06-25 19:25:54.132720
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = 'x;+2w-k@8$(2!h1a)9'
    str_0 = '.4=&*htxk)1a+d;y8'
    session_0 = Session(path_0)
    dict_0 = {str_0: '^*w_tb8a((m)v$(d', str_0: '^*w_tb8a((m)v$(d', str_0: '^*w_tb8a((m)v$(d'}
    request_headers = dict_0
    session_0.update_headers(request_headers)
    str_1 = '&^1jxzt;w0t)y*n%i2'

# Generated at 2022-06-25 19:25:59.437933
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_0 = RequestHeadersDict()
    cookie_str_0 = 'q=enhs/~;mas2'
    headers_0['cookie'] = cookie_str_0
    session_1 = Session('/srv/httpie/tests/fixtures/sessions/.~')
    session_1.update_headers(headers_0)


# Generated at 2022-06-25 19:26:03.389266
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert VALID_SESSION_NAME_PATTERN.match('a-zA-Z0-9_.-')
    assert not VALID_SESSION_NAME_PATTERN.match('/a-zA-Z0-9_.-')

# Generated at 2022-06-25 19:26:11.809553
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import os
    from pathlib import Path
    from httpie.plugins.registry import plugin_manager

    # arrange
    os.environ["TESTING"] = "true"
    path = Path(__file__).parent / "sessions" / "Session_update_headers_0.json"
    session = Session(path)
    request_headers = {
        'Content-Type': 'application/json'
    }

    # act
    session.update_headers(request_headers)

    # assert
    assert Path(path).read_text() == '{"headers": {"Content-Type": "application/json"}}'

# Generated at 2022-06-25 19:26:17.377359
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 's%sessions/example.com/session.json' % os.path.sep
    session_0 = Session(str_0)
    request_headers = {'user-agent': None, 'Accept': 'application/json'}
    session_0.update_headers(request_headers)
    value = session_0['headers']
    assert value == {'Accept': 'application/json'}


# Generated at 2022-06-25 19:26:25.041456
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    str_0 = 'n#x.F>)SQvaX}>J'
    session_0 = Session(str_0)
    str_0 = 'xew)e?/Y'
    list_0 = []
    list_0.append(str_0)
    request_headers_0 = RequestHeadersDict(list_0)
    session_0.update_headers(request_headers_0)

    str_0 = '&p~Kd'
    session_0 = Session(str_0)
    str_0 = 'Hc%T'
    list_0 = []
    list_0.append(str_0)
    request_headers_0 = RequestHeadersDict(list_0)
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:26:28.165661
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'a+h,a.i'
    arg_0 = {'l':'5_5,5'}
    session_0 = Session(str_0)
    session_0.update_headers(arg_0)


# Generated at 2022-06-25 19:26:32.747536
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'Lf2!E+jy@'
    session_0 = Session(str_0)
    request_headers_dict_0 = RequestHeadersDict(
        {'Host': 'user1:_8kKj`'})
    session_0.update_headers(request_headers_dict_0)

# Generated at 2022-06-25 19:26:37.275001
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'q+enhs/~;mas2'
    session_0 = Session(str_0)
    names_0 = []
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:26:57.098486
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'name1': 'value1', 'name2': 'value2'})
    assert session.value['headers'] == {'name1': 'value1', 'name2': 'value2'}


# Generated at 2022-06-25 19:27:02.740155
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    url = 'http://localhost:8080/json'
    request_headers = {'Content-Type': 'application/json',
                       'User-Agent': 'HTTPie/1.0.3',
                       'Accept': 'application/json',
                       'Connection': 'keep-alive'}
    session = get_httpie_session(Path('.'), 'localhost_8080', 'localhost', url)
    session.update_headers(request_headers)
    assert session.headers == {'accept': 'application/json',
                               'connection': 'keep-alive'}

# Generated at 2022-06-25 19:27:12.462845
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
	str_0 = 'j7;4m4}'
	str_1 = '8HjtS'
	str_2 = 'N{j%c@T-`'
	str_3 = 'w=*'
	session_0 = Session(str_0)
	assert set(session_0.keys()) == {'cookies', 'headers', 'auth'}
	session_0.cookies[str_2] = str_2
	session_0.cookies[str_3] = str_3
	session_0.cookies[str_1] = str_3
	session_0.cookies[str_0] = str_2
	path_0 = Path('Qkf:')
	session_0.update(path_0)

# Generated at 2022-06-25 19:27:22.814450
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '~x%c0rv'
    Path_1 = DEFAULT_SESSIONS_DIR / SESSIONS_DIR_NAME / str_0
    Session_2 = Session(Path_1)
    dict_3 = {}
    dict_3['qatq'] = 'ay7p1!m&#'
    dict_3['(0e'] = 'l!1@w'
    dict_3['>*hk&0=9@f'] = '4sz4oh4'
    RequestHeadersDict_4 = RequestHeadersDict(dict_3)
    Session_2.update_headers(RequestHeadersDict_4)


# Generated at 2022-06-25 19:27:27.699706
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers = {'a': '1', 'b': '2'}
    str_0 = 'abc'
    session_0 = Session(str_0)
    session_0.update_headers(request_headers)
    assert (session_0['headers'] == {'a': '1', 'b': '2'})



# Generated at 2022-06-25 19:27:36.890799
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import unittest

    class TestSession(unittest.TestCase):
        """
        Test class Session.

        """
        def setUp(self):
            self.session = Session('test_Session')

        def test_update_headers(self):
            import requests
            headers = requests.utils.default_headers()
            headers.update({'Accept': 'application/json'})
            headers.update({'Content-Type': 'application/json'})
            self.session.update_headers(headers)
            session_headers = self.session.headers
            self.assertIn('Accept', session_headers)
            self.assertIn('Content-Type', session_headers)
            self.assertNotEqual(session_headers['Accept'], 'text/plain')

# Generated at 2022-06-25 19:27:44.393506
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    # Arrange
    session = Session()
    headers = {
        'Accept': 'text/html',
        'Host': 'httpbin.org',
        'User-Agent': 'HTTPie/0.9.9',
        'Cache-Control': 'no-cache',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Length': '0'
    }

    # Act
    session.update_headers(headers)
    
    # Assert

# Generated at 2022-06-25 19:27:46.898050
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = ''
    session_0 = Session(str_0)
    request_headers_0 = {}
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:27:49.070365
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    request_headers_0 = RequestHeadersDict()
    session_0 = Session(Path(''))
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:27:52.472474
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'q+enhs/~;mas2'
    session_0 = Session(str_0)
    set_0 = {'foo', 'hello'}
    session_0.remove_cookies(set_0)
    assert session_0['cookies'] == {}


# Generated at 2022-06-25 19:28:23.360539
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'q+enhs/~;mas2'
    session_0 = Session(str_0)

    str_arr_0 = ['a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a']
    session_0.remove_cookies(str_arr_0)


# Generated at 2022-06-25 19:28:29.162796
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_sessions_Session')

    headers_0 = RequestHeadersDict({
        'X-Sprint-GID': '',
        'X-Sprint-AID': '',
        'X-Sprint-HDR': '',
        'User-Agent': 'HTTPie/1.0.0'
    })
    session.update_headers(headers_0)
    # check 'User-Agent' is ignored
    # a new header should not be added, but the existing one should be
    # updated
    assert 'User-Agent' not in session.get('headers').keys()
    assert len(session.get('headers')) == 3



# Generated at 2022-06-25 19:28:34.373037
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '$w`8[QW@|O<d'
    int_0 = 1019

    str_1 = 'A_h=GrcZ8)c%!|'
    int_1 = -54
    session_0 = Session(str_0)
    session_0.update_headers(str_1)

# Test case for attribute cookies of class Session
# Test setter

# Generated at 2022-06-25 19:28:39.544757
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'q+enhs/~;mas2'
    session_0 = Session(str_0)
    headers_0 = RequestHeadersDict([('User-Agent', 'HTTPie/0.8.0'), (
        'Content-Type', 'application/json'), ('Accept', 'application/json')])
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:28:49.069464
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print('start test')
    from httpie.config import BaseConfigDict
    from httpie.config import Config
    config = Config()
    config['config-dir'] = 'D:\\Documents\\RIT\\ITWS-4400-Agile\\httpie-master\\httpie-master\\httpie'
    print(config['config-dir'])
    session_0 = Session('D:\\Documents\\RIT\\ITWS-4400-Agile\\httpie-master\\httpie-master\\httpie\\sessions\\httpbin.org\\test_0.json')
    session_0['headers'] = {'Host': 'httpbin.org'}
    session_0['cookies'] = {'test_cookie': {'value': 'test_cookie_value'}}

# Generated at 2022-06-25 19:28:51.289262
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'q+enhs/~;mas2'
    session_0 = Session(str_0)
    session_0.update_headers(['q+enhs/~;mas2'])


# Generated at 2022-06-25 19:28:59.652169
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_1 = Path('/home/elan/.config/httpie/sessions//localhost/test_case_2.json')
    session_1 = Session(path=path_1)

    dict_1 = {
        'accept': '*/*',
        'accept-encoding': 'gzip, deflate',
        'cache-control': 'no-cache',
        'content-length': '25',
        'content-type': 'application/x-www-form-urlencoded',
        'dnt': '1',
        'if-none-match': 'W/"91e-c7zZrCfY9DsMFGd5qIaAq5yHY"',
        'pragma': 'no-cache',
        'user-agent': 'HTTPie/2.0.0',
    }



# Generated at 2022-06-25 19:29:03.006896
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    c = Session
    assert c.remove_cookies('q+enhs/~') == 'ms2'
    assert c.remove_cookies('q+enhs/~;mas2') == None



# Generated at 2022-06-25 19:29:10.850778
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    config_dir_0 = Path('/2')
    str_0 = ''
    path_0 = Path(str_0)
    session_0 = Session(path_0)
    session_0.load()
    session_0.save()

    session_0.update_headers(headers_0)
    session_0.save()

    str_1 = ''
    path_1 = Path(str_1)
    session_1 = Session(path_1)
    session_1.load()
    session_1.save()

    session_1.update_headers(headers_1)

    headers_0 = {'a': 'b', 'c': 'd'}
    headers_1 = {'e': 'f', 'g': 'h'}

    session_1.update_headers(headers_1)
    session

# Generated at 2022-06-25 19:29:15.094858
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_1 = Session('m1m0u23/~')
    str_1 = 'pzsls/~;kxsw'
    RequestHeadersDict_1 = RequestHeadersDict(str_1)
    session_1.update_headers(RequestHeadersDict_1)



# Generated at 2022-06-25 19:30:28.223412
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # test_case_0
    dict_0 = {}
    dict_1 = {'User-Agent': 'HTTPie/0.9.9'}
    dict_2 = {'Cookie': 'foo=bar; spam=eggs'}
    dict_3 = {'content-type': 'application/json', 'Cookie': 'foo=bar; spam=eggs'}
    dict_4 = {'If-Match': '*'}
    dict_5 = {'Content-Type': 'application/json', 'Cookie': 'foo=bar; spam=eggs'}
    dict_6 = {}
    dict_7 = {'If-Match': '*', 'content-type': 'application/json'}
    dict_8 = {'Content-Type': 'application/json'}
    dict_9 = {}
   

# Generated at 2022-06-25 19:30:31.426396
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('Lucy')
    names = ['Orange']
    session_0.remove_cookies(names)


# Generated at 2022-06-25 19:30:34.475667
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('[' + str(Path(DEFAULT_CONFIG_DIR) / 'sessions' / 'localhost') + ']')
    session_0.remove_cookies(['kvye8'])


# Generated at 2022-06-25 19:30:35.745512
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    print("Testing Session.remove_cookies")
    test_case_0()


# Generated at 2022-06-25 19:30:40.368268
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '`PWl;zr%\r#'
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict.from_dict({
        'X-HTTPIE-TEST': 'OK',
        'x-httpie-test-none': None,
        'Content-Length': '127',
        'None': None,
        'If-Match': '*',
        'User-Agent': 'HTTPie/1.0.2',
    })
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:30:42.629083
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'm>Yug'
    session_0 = Session(str_0)


# Generated at 2022-06-25 19:30:45.528673
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    h = {'a': 'b', 'A-B': 'c'}
    session = Session('')
    session.update_headers(h)
    headers = session.headers
    assert headers == {'a': 'b', 'A-B': 'c'}

