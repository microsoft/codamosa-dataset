

# Generated at 2022-06-25 19:21:05.350512
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    
    # Test case 6
    request_headers = {'Content-Type': 'application/json'}
    session_0.update_headers(request_headers)
    
    # Test case 7
    headers = {'Content-Type': 'application/json'}
    session_0.headers = headers
    
    # Test case 9
    headers = {'User-Agent': 'HTTPie/0.9.9'}
    session_0.headers = headers
    
    # Test case 10
    cookies = {'key': 'value'}
    session_0.cookies = cookies
    
    # Test case 12
    cookies = {'key': 'value'}
    session_0.cookies = cookies
    
    #

# Generated at 2022-06-25 19:21:13.358826
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.compat import is_py38

    path_1 = module_0.Path()
    session_1 = Session(path_1)
    names_1 = ['a', 'b', 'c']
    session_1.remove_cookies(names_1)
    # assert session_1.headers is None
    # assert session_1.cookies is None
    # assert session_1.auth is None


# Generated at 2022-06-25 19:21:16.398529
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.PosixPath()
    session_0 = Session(path_0)
    cookies_0 = session_0.cookies
    names_0 = cookies_0.list_domains()
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:21:28.395762
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    path_0 = module_0.Path()
    session_0 = Session(path_0)

    # Checking expected values
    assert session_0.headers == {'headers': {}}

    # Checking expected exception
    # Exception: Invalid dict value for attribute 'Session.headers'
    session_0.headers = {0,}

    # Checking expected exception
    # Exception: Invalid dict value for attribute 'Session.headers'
    session_0.headers = ''

    # Checking expected exception
    # Exception: Invalid dict value for attribute 'Session.headers'
    session_0.headers = {'',}

    # Checking expected exception
    # Exception: Invalid dict value for attribute 'Session.headers'
    session_0.headers = {0, 0}

    # Checking expected exception
    # Exception: Invalid dict value for attribute 'Session.headers'
    session_

# Generated at 2022-06-25 19:21:31.467165
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names = []
    session_0.remove_cookies(names)


# Generated at 2022-06-25 19:21:33.753082
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_0 = RequestHeadersDict()
    session_0 = Session()
    session_0.update_headers(headers_0)
    pass

# Generated at 2022-06-25 19:21:36.758461
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from requests.structures import CaseInsensitiveDict as RequestHeadersDict
    assert True # TODO: implement your test here


# Generated at 2022-06-25 19:21:40.156000
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    path_1 = pathlib.Path()
    session_1 = Session(path_1)
    request_headers_1 = {} # type: RequestHeadersDict
    session_1.update_headers(request_headers_1)
    

# Generated at 2022-06-25 19:21:46.379143
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    str_0 = 'fprhjjwkyd'
    str_1 = 'mkmtjzcftm'
    str_2 = 'iohtbwzwjr'
    str_3 = 'fgnhqvjgof'
    str_4 = 'qeulqypkrj'
    str_5 = 'lkzgbgnjws'
    str_6 = 'qbmgqtvqfq'
    str_7 = 'zguswxokty'
    str_8 = 'uugfaxyavr'
    str_9 = 'rloznydsgp'
    str_10 = 'xzqqvvojoo'

# Generated at 2022-06-25 19:21:49.834110
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:22:02.259963
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    path_1 = module_0.Path()
    session_1 = Session(path_1)
    request_headers = {"user-agent" : "HTTPie/1.0.3"}
    session_0.update_headers(request_headers)
    assert not isinstance(session_0.update_headers(request_headers), RequestHeadersDict)


# Generated at 2022-06-25 19:22:05.239771
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = list()
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:22:08.006823
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = Path(__name__)
    session_0 = Session(path_0)
    session_0.load()


# Generated at 2022-06-25 19:22:11.287028
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    arg0 = [None]
    session_0 = Session(None)
    session_0.remove_cookies(arg0)


# Generated at 2022-06-25 19:22:16.185097
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    config_dir = module_0.Path()
    session_name = ''
    host = ''
    url = ''
    httpie_session = get_httpie_session(
        config_dir, session_name, host, url,
    )
    names = []
    httpie_session.remove_cookies(names)


# Generated at 2022-06-25 19:22:24.685293
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Local variable declarations
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    request_headers_0 = requests.structures.CaseInsensitiveDict()
    request_headers_0['Host'] = 'www.example.com'
    request_headers_0['Content-Type'] = 'application/json'

    # Method call
    session_0.update_headers(request_headers_0)

    # Call trace
    #  File
    #  line
    #  trace format
    #  end of trace
    #  end of method call

# Generated at 2022-06-25 19:22:35.773474
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)



# C:\Users\Jason\PycharmProjects\httpie-linter\httpie\sessions.py:104: [D105, Session.auth] Missing docstring in magic method
# C:\Users\Jason\PycharmProjects\httpie-linter\httpie\sessions.py:104: [D107, Session.auth] Missing __setattr__ method
# C:\Users\Jason\PycharmProjects\httpie-linter\httpie\sessions.py:103: [D104, Session.auth] Missing docstring in public method
# C:\Users\Jason\PycharmProject

# Generated at 2022-06-25 19:22:40.073668
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict()
    assert not hasattr(session_0, "headers")
    session_0.update_headers(request_headers_0)
    assert hasattr(session_0, "headers")


# Generated at 2022-06-25 19:22:42.046358
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = pathlib.Path()
    session_0 = Session(path_0)

    # Call tested method
    session_0.remove_cookies([])


# Generated at 2022-06-25 19:22:45.950303
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    path_0 = 'session'
    session_0 = Session(path_0)

    names_0 = session_0.cookies

    session_0.remove_cookies(names_0)

import collections as module_1

import unittest as module_2


# Generated at 2022-06-25 19:22:54.672350
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_1 = pathlib.Path()
    session_1 = Session(path_1)
    request_headers_1 = RequestHeadersDict()
    session_1.update_headers(request_headers_1)
    assert isinstance(request_headers_1, RequestHeadersDict)
    assert isinstance(session_1.headers, RequestHeadersDict)


# Generated at 2022-06-25 19:22:57.563070
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path = pathlib.Path()
    request_headers = {}
    session = Session(path)
    session2 = session.update_headers(request_headers)


# Generated at 2022-06-25 19:23:00.123021
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path_0)
    request_headers = request_headers_0 = RequestHeadersDict({'Accept': '*/*'})
    session.update_headers(request_headers)


# Generated at 2022-06-25 19:23:01.341355
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('')
    test_case_0()


# Generated at 2022-06-25 19:23:08.051248
# Unit test for method update_headers of class Session
def test_Session_update_headers():
  request_headers_0 = RequestHeadersDict(config_dir_0=config_dir_0, session_name_0=session_name_0, host_0=host_0, url_0=url_0)
  session_0 = Session(path_0=path_0)
  session_0.update_headers(request_headers=request_headers_0)
  headers_0 = session_0.headers
  #<class 'httpie.cli.dicts.RequestHeadersDict'>


# Generated at 2022-06-25 19:23:12.010717
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    path_1 = module_0.Path()
    session_1 = Session(path_1)
    session_1.update_headers(session_0)


# Generated at 2022-06-25 19:23:18.409998
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    # 1. Test for wrong number of arguments
    try:
        session_0.update_headers(1)
    except TypeError:
        pass
    else:
        raise AssertionError()
    # 2. Test for correct number of arguments
    try:
        session_0.update_headers(())
    except TypeError:
        pass


# Generated at 2022-06-25 19:23:27.475542
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    items_0 = [
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
    ]
    items_1 = [
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
        ('', ''),
    ]
    session_0 = Session(tuple(items_0))
    session_0.remove_cookies(items_1)
    assert (session_0['cookies'].keys() == ([]))

# Generated at 2022-06-25 19:23:30.949620
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    from httpie.cli.dicts import RequestHeadersDict
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:23:38.452424
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers = {'Host': 'httpbin.org', 'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'Connection': 'keep-alive', 'Cookie': 'foo=bar; bar=baz', 'User-Agent': 'HTTPie/0.9.9'}
    session_0.update_headers(request_headers)

# Generated at 2022-06-25 19:23:42.768262
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert True


# Generated at 2022-06-25 19:23:46.139402
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    import json
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = json.loads('{}')
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:23:50.930334
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # path_0 = module_0.Path()
    # session_0 = Session(path_0)
    # request_headers_0 = RequestHeadersDict()
    # session_0.update_headers(request_headers_0)
    # assert session_0.headers == RequestHeadersDict()
    return


# Generated at 2022-06-25 19:23:54.452543
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    # Argument values
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    names_0 = [None]

    # Call function
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:23:59.867001
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import pathlib as module_0
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    import typing as module_1
    names_0 = module_1.Iterable[str]()
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:24:07.764929
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from random import seed, randint
    from string import ascii_letters, digits
    from httpie.compat import is_py3

    seed(0)
    chars = ascii_letters + digits
    path_0 = module_0.Path()
    session_0 = Session(path_0)

    names = (''.join(chars[randint(0, len(chars))] for _ in range(randint(1, 10))) for _ in range(randint(0, 10)))
    names = set(names)

    cookies = {name: {'value': ''} for name in names}
    session_0['cookies'] = cookies

    remove_names = names.pop() if len(names) > 0 else None


# Generated at 2022-06-25 19:24:17.106040
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from unittest import mock
    from pathlib import Path
    from httpie import ExitStatus
    from httpie import ExitStatus
    class Cookie:
        pass
    path_0 = Path()
    session_0 = Session(path_0)

    cookie_0 = Cookie()
    # mock the return value of method remove_cookies of class Session
    with mock.patch('httpie.sessions.Session.remove_cookies',
                    return_value=cookie_0) as mock_method:
        session_0.remove_cookies([])
    assert cookie_0 is session_0.remove_cookies.return_value

import pathlib as module_1


# Generated at 2022-06-25 19:24:21.047659
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = []
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:24:28.043149
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Get an instance
    session_instance = Session.__new__(Session)
    session_instance.path = pathlib.Path()
    session_instance['headers'] = {}
    session_instance['cookies'] = {}
    session_instance['auth'] = {'type': None, 'username': None, 'password': None}
    # Prepare the arguments
    names_0 = [pathlib.Path()]
    # Call the method
    session_instance.remove_cookies(names_0)


# Generated at 2022-06-25 19:24:32.045170
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    request_headers_0 = {}


# Generated at 2022-06-25 19:24:41.013891
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    r'''
    Test case remove_cookies
    '''
    # Arrange
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = ['1', '2']

    # Act
    session_0.remove_cookies(names_0)

import unittest.mock as module_1


# Generated at 2022-06-25 19:24:46.082301
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    session_0.load()
    session_0.remove_cookies([])


# Generated at 2022-06-25 19:24:53.750731
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
  def test_case_0():
    session_0 = Session('/tmp')
    session_0.remove_cookies()
  def test_case_1():
    session_0 = Session('/tmp')
    session_0.remove_cookies()
  def test_case_2():
    session_0 = Session('/tmp')
    session_0.remove_cookies()
  def test_case_3():
    session_0 = Session('/tmp')
    session_0.remove_cookies()
  def test_case_4():
    session_0 = Session('/tmp')
    session_0.remove_cookies()
  def test_case_5():
    session_0 = Session('/tmp')
    session_0.remove_cookies()
  def test_case_6():
    session_0

# Generated at 2022-06-25 19:24:56.391767
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import pathlib as module_0
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = session_0
    Session.remove_cookies(session_0, names_0)


# Generated at 2022-06-25 19:24:59.232546
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    assert session_0.get('cookies')
    names_0 = []
    assert session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:25:02.153974
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    session_0.remove_cookies({})


# Generated at 2022-06-25 19:25:03.338857
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    module_0 = pathlib.Path()
    session_0 = Session(module_0)

# Generated at 2022-06-25 19:25:05.899770
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    names_0 = []
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:25:10.597684
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names = None
    session_0.remove_cookies(names)


# Generated at 2022-06-25 19:25:19.263147
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Create and populate session
    session = Session('')

# Generated at 2022-06-25 19:25:30.610623
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 19:25:41.990386
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from typing import Iterable
    from http.cookies import SimpleCookie
    from requests.cookies import RequestsCookieJar, create_cookie
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.config import BaseConfigDict, DEFAULT_CONFIG_DIR
    from httpie.plugins.registry import plugin_manager
    SESSIONS_DIR_NAME = 'sessions'
    DEFAULT_SESSIONS_DIR = DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME
    VALID_SESSION_NAME_PATTERN = re.compile('^[a-zA-Z0-9_.-]+$')
    # Request headers starting with these prefixes won't be stored in sessions.
    # They are specific to each request.
    # <https://en.wikipedia.org/wiki

# Generated at 2022-06-25 19:25:52.814199
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import pathlib as module_0
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    import requests as module_1
    jar_0 = module_1.cookies.RequestsCookieJar()
    session_0.cookies = jar_0
    import requests as module_2
    jar_0 = module_2.cookies.RequestsCookieJar()
    import pathlib as module_3
    path_0 = module_3.Path()
    session_0 = Session(path_0)
    import requests as module_4
    jar_0 = module_4.cookies.RequestsCookieJar()
    session_0.cookies = jar_0
    import requests as module_5
    jar_0 = module_5.cookies.RequestsCookieJar()
   

# Generated at 2022-06-25 19:25:55.558090
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    # Setup
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = set()

    # Test
    session_0.remove_cookies(names_0)

    # Verify
    assert True


# Generated at 2022-06-25 19:26:01.106199
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    val_0 = '/etc/httpie/sessions/foo.json'
    path_0 = module_0.Path(val_0)
    session_0 = Session(path_0)
    val_1 = 'bar'
    val_2 = [val_1]
    session_0.remove_cookies(val_2)


# Generated at 2022-06-25 19:26:11.849599
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    path_0 = module_0.Path()
    session_0 = Session(path_0)

# Generated at 2022-06-25 19:26:17.780140
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Set-up
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    path_1 = module_0.Path()
    session_1 = Session(path_1)
    # Assertion 1
    try:
        assert path_0 == path_1
    except AssertionError:
        raise AssertionError(path_0 + " != " + path_1)

import requests as module_1


# Generated at 2022-06-25 19:26:19.098580
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert True

import requests as module_1


# Generated at 2022-06-25 19:26:22.152183
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # cookie_0 = 
    # cookie_1 = 
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    session_1 = Session(path_0)
    session_2 = Session(path_0)

    # CASE 0:
    session_0.remove_cookies(cookie_0)
    # the following check should be performed:
    # check that cookie_0 was removed from Session object


# Generated at 2022-06-25 19:26:23.509218
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    names_0 = list()
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:26:40.877371
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    iterable_0 = iter((session_0["cookies"]))
    session_0.remove_cookies(iterable_0)


# Generated at 2022-06-25 19:26:41.559826
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass

# Generated at 2022-06-25 19:26:43.726464
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from pathlib import Path
    session_0 = Session(Path())
    session_0.remove_cookies(None)


# Generated at 2022-06-25 19:26:52.402937
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names_0 = []
    session_0 = Session()
    # Test that the session stores the cookies successfully.
    session_0.cookies = get_new_cookies()
    assert len(session_0.cookies) == 3
    # Remove one of the cookies.
    session_0.remove_cookies(names_0)
    # The session no longer contains the removed cookie.
    assert len(session_0.cookies) == 2

test_case_0()
test_Session_remove_cookies()

# Generated at 2022-06-25 19:26:56.537906
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path("")
    session_0 = Session(path_0)
    #cookies_0 = RequestsCookieJar()
    assert session_0.remove_cookies("cookiename") == None


# Generated at 2022-06-25 19:27:00.093043
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import pathlib as module_1
    path_1 = module_1.Path()
    session_1 = Session(path_1)
    import collections.abc as module_2
    keys_0 = module_2.Sequence([])
    session_1.remove_cookies(keys_0)


# Generated at 2022-06-25 19:27:01.816773
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import collections

    names_0 = collections.Iterable()
    Session.remove_cookies(names_0)


# Generated at 2022-06-25 19:27:09.836041
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from pathlib import Path
    import pathlib as module_0
    path_0 = Path('sessions/localhost/default.json')
    session_0 = Session(path_0)
    names_0 = module_0.Path()
    try:
        # line 211
        session_0.remove_cookies(names_0)
    except TypeError:
        pass

if __name__ == "__main__":
    import sys
    import typing
    typing.no_type_check = True
    test_case_0()
    test_Session_remove_cookies()

# Generated at 2022-06-25 19:27:13.572666
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import requests.cookies as module_0
    path_0 = pathlib.Path()
    session_0 = Session(path_0)
    names = iter(module_0.RequestsCookieJar())
    session_0.remove_cookies(names)


# Generated at 2022-06-25 19:27:16.014692
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = ()
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:27:46.300326
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = iter()
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:27:49.158252
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = [None]
    # test case remove_cookies
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:27:51.990255
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # This tests passing an empty iterable of names to remove from the session
    from pytest import raises
    session_1 = Session(str())
    with raises(NameError):
        session_1.remove_cookies(iter(()))


# Generated at 2022-06-25 19:27:56.052485
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = session_0
    try:
        session_0.remove_cookies(names_0)
    except Exception as e:
        print('An exception of type {} occurred'.format(type(e)))
    else:
        pass


# Generated at 2022-06-25 19:27:59.282975
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies_0 = {'string_0':'string_0', 'string_1':'string_1', 'string_2':'string_2'}
    names_0 = ["string_0", "string_10"]
    return


# Generated at 2022-06-25 19:28:04.989374
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # arrange
    names = ["name_0", "name_1", "name_2"]
    session = Session('')
    session['cookies'] = {"name_0": 42, "name_1": 42, "name_2": 42}

    # act
    session.remove_cookies(names)

    # assert
    assert session['cookies'] == {"name_0": 42, "name_1": 42}


# Generated at 2022-06-25 19:28:07.019758
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path_0)
    with patch.object(ModuleType, 'iterable_set', create=True):
        session.remove_cookies(iterable_set_0)

# Generated at 2022-06-25 19:28:11.729296
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = session_0.headers
    try:
        session_0.remove_cookies(names_0)
    except TypeError:
        pass



# Generated at 2022-06-25 19:28:16.638105
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    # path_0 = module_0.Path()
    session_0 = Session(module_0.Path())
    # names_0 = ["a", "b", "c"]
    names_0 = ['a', 'b', 'c']

    # Act
    session_0.remove_cookies(names_0)



# Generated at 2022-06-25 19:28:19.372533
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = []
    session_0.remove_cookies(names_0)

# Generated at 2022-06-25 19:29:25.759725
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    path_0 = Path("sessions/session_0.json")
    session_0 = Session(path_0)
    session_0.load()
    obj_0 = io.StringIO("#!/usr/bin/env python3")
    obj_1 = io.StringIO("\n")
    obj_2 = io.StringIO("# Generated by pyreverse 0.6.1 (http://www.logilab.org/project/pyreverse), a package and GUI for reverse engineering Python source code - (C) 2005-2008 Logilab S.A. (GPL, freeware)")
    obj_3 = io.StringIO("\n")

# Generated at 2022-06-25 19:29:28.660391
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    names_0 = set()
    session_0.remove_cookies(names_0)


# Generated at 2022-06-25 19:29:31.625514
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_1 = Session(path_0)
    session_1['cookies'] = {'name_0': 'value_0', 'name_1': 'value_1'}
    session_1.remove_cookies(['name_0'])


# Generated at 2022-06-25 19:29:34.413338
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    # AssertionError: AssertionError: Object of type Generator is not JSON serializable
    # assert session_0.remove_cookies(('_',)) == {}


# Generated at 2022-06-25 19:29:44.580747
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    module_0 = pathlib.Path
    path_0 = module_0()
    str_0 = "Sessions"
    var_0 = path_0 / str_0
    str_1 = "session_name"
    str_2 = "localhost"
    str_3 = "url"
    url = get_httpie_session(var_0, str_1, str_2, str_3)
    str_4 = "headers"
    str_5 = "cookies"
    str_6 = "auth"
    str_7 = "type"
    str_8 = "username"
    str_9 = "password"
    str_10 = "user-agent"
    str_11 = "HTTPie/"
    str_12 = "None"
    str_13 = "cookie"

# Generated at 2022-06-25 19:29:45.059715
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert True



# Generated at 2022-06-25 19:29:47.184339
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.PurePath()
    session_0 = Session(path_0)
    list_0 = ['', '']
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:29:47.661587
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    pass


# Generated at 2022-06-25 19:29:49.348282
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Set up mock objects
    pass

    # Invoke the target method
    pass


# Generated at 2022-06-25 19:29:52.161079
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    path_0 = module_0.Path()
    session_0 = Session(path_0)
    string_0 = []
    session_0.remove_cookies(string_0)
