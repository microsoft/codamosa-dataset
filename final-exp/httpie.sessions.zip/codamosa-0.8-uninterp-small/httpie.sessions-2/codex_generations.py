

# Generated at 2022-06-25 19:21:03.622943
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = 'p_{h,7*[Bc%@pFJ^zL'
    session_0 = Session(path_0)
    request_headers_0 = {}
    request_headers_0['user-agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:45.0) Gecko/20100101 Firefox/45.0'
    request_headers_0['host'] = 'www.google.com'
    request_headers_0['accept'] = '*/*'
    request_headers_0['referer'] = 'http://www.google.com/'

# Generated at 2022-06-25 19:21:09.716121
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Initialize the arguments required for the test
    default_value_0 = RequestHeadersDict()
    args = [default_value_0]

    # Define the arguments required for the test
    session_0 = Session(args[0])

    # Call the method under test
    session_0.update_headers(args[0])



# Generated at 2022-06-25 19:21:12.596353
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session("S:/03-Development/python/httpie/httpie-1.0.3/sessions")
    session.update_headers({})


# Generated at 2022-06-25 19:21:17.318058
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'pB3]u3LVV'
    session_0 = Session(str_0)
    str_1 = '~1:d:f:54!J=o'
    request_headers_0 = RequestHeadersDict(str_1)
    session_0.update_headers(request_headers_0)
    assert session_0['headers'] == {}
    assert request_headers_0 is not None


# Generated at 2022-06-25 19:21:22.705695
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'h5V/K/Ec/U{6* !(~'
    str_1 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)

    session_0.remove_cookies((str_1))


# Generated at 2022-06-25 19:21:33.436278
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'https://example.org/'
    str_1 = 'ClientError, NotModified'
    dict_0 = {'raw_auth': str_1, 'type': 'token'}
    session_0 = Session(str_0)
    session_0.headers = []
    session_0.auth = dict_0
    session_0.cookies = dict()
    session_0.cookies = dict()
    assert str_0 == str_0
    assert str_1 == str_1
    assert dict_0 == dict_0
    assert session_0 == session_0
    assert dict_0 == dict_0
    assert dict_0 == dict_0
    assert dict_0 == dict_0


# Generated at 2022-06-25 19:21:41.883689
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    _base_path_0 = Path("/home/ivan/.httpie/config/sessions/localhost/session_1.json")
    _base_path_1 = Path("/home/ivan/.httpie/config/sessions/localhost/session_2.json")

    _base_path_2 = Path("/home/ivan/.httpie/config/sessions/localhost")

    _base_path_3 = Path("/home/ivan/.httpie/config/sessions")

    _base_path_4 = Path("/home/ivan/.httpie/config")

    _base_path_5 = Path("/home/ivan/.httpie")


# Generated at 2022-06-25 19:21:53.755549
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():

    # Test case 1
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    str_1 = 'Z'
    assert session_0.remove_cookies(str_1) == None

    # Test case 2
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    str_1 = '\\'
    assert session_0.remove_cookies(str_1) == None

    # Test case 3
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    str_1 = 'h5V/K/Ec/U{6* !(~'

# Generated at 2022-06-25 19:21:58.733269
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = 'T+h'
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_27 = {}
    dict_28 = {}

# Generated at 2022-06-25 19:22:03.211367
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # This test uses the faker library so that we can have realistic data for
    # our tests without the need for a lot of boilerplate code to create the
    # data.
    name = faker.company.name()
    assert Session.remove_cookies(name) == Session.remove_cookies(name)
    assert Session.remove_cookies(name) != Session.remove_cookies(name)


# Generated at 2022-06-25 19:22:17.365283
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '9Y#N<+@xO'
    session_0 = Session(str_0)
    bool_8 = bool()
    bool_7 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_9 = bool()
    bool_5 = bool()
    bool_1 = bool()
    bool_0 = bool()
    bool_6 = bool()
    session_0.update_headers(bool_0)


# Generated at 2022-06-25 19:22:21.966453
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '8ej"'
    path_0 = Path(str_0)
    req_headers_0 = RequestHeadersDict()
    session_0 = Session(path_0)
    session_0.update_headers(req_headers_0)


# Generated at 2022-06-25 19:22:26.252194
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Preconditions
    str_0 = 'n/1.X.N/<N:t>?%c=HsI'
    session_0 = Session(str_0)

    path_0 = Path() / 'r' / '`O(`'
    request_headers_0 = RequestHeadersDict.from_file(path_0)
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:22:36.955083
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie import config
    from httpie.cli.args import Namespace
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.config import Config
    from httpie.downloads import get_response_stream
    from httpie.plugins.base import AuthPlugin
    from httpie.plugins.registry import plugin_manager

    namespace = Namespace()
    namespace.allow_redirects = False
    namespace.auth = None
    namespace.auth_type = None
    namespace.config_dir = config.DEFAULT_CONFIG_DIR
    namespace.download = False
    namespace.follow = False
    namespace.headers = RequestHeadersDict()
    namespace.ignore_stdin = False
    namespace.method = None
    namespace.output_dir = None
    namespace.output_file = None

# Generated at 2022-06-25 19:22:39.031022
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session("session_0")
    session_0.update_headers({"a", "b"})
    pass



# Generated at 2022-06-25 19:22:42.652471
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.cli.dicts import RequestHeadersDict
    from requests.cookies import RequestsCookieJar
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    str_1 = '+{6* !(~:h5V/K/Ec'
    session_0.headers = RequestHeadersDict(str_1)
    assert session_0.headers == RequestHeadersDict(str_1)
    session_0.cookies = RequestsCookieJar()
    str_2 = 'Yr& G=UZ@vD`0'
    str_3 = '+{6* !(~:h5V/K/Ec'
    session_0.headers = RequestHeadersDict(str_1)

# Generated at 2022-06-25 19:22:47.733355
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    url_0 = 'http://www.example.com/'
    session_0 = Session(url_0)
    class_0 = session_0.__class__
    value_0 = class_0.update_headers(session_0)
    assert value_0 == None, "Expected None, got %s" % repr(value_0)


# Generated at 2022-06-25 19:22:52.775427
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    '''
    Method remove_cookies of class Session
    '''
    str_0 = 'sstt22'
    session_0 = Session(str_0)
    str_1 = '~TQi!]'
    session_0.remove_cookies(str_1)


# Generated at 2022-06-25 19:22:59.276933
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.parser import Parser
    parser = Parser()
    config_dir = str(Path(DEFAULT_CONFIG_DIR))
    args = parser.parse_args(['/dev/null', '-H', 'Host:localhost'], env=None)
    session = get_httpie_session(config_dir, '', '', '')
    session.update_headers(args.headers)
    assert session.headers == {'host': 'localhost'}



# Generated at 2022-06-25 19:23:00.123215
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_case_0()

# Generated at 2022-06-25 19:23:14.500583
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # session_0 = Session('test_data/test_Session/test_Session_1.ini')
    from httpie.utils import strip_basic_auth
    from httpie.cli.constants import DEFAULT_UA
    from httpie import ExitStatus
    from httpie.output.streams import UnsupportedResponseEncoding
    import requests.hooks
    session_0 = Session('/home/user/.config/httpie/sessions/localhost/test_Session_update_headers.json')
    session_0.load()
    request_headers_0 = RequestHeadersDict({})
    request_headers_0['Content-Length'] = '1I;'
    request_headers_0['Proxy-Authorization'] = 'Basic Zm9vOmJhcg=='
    request_headers_0['User-Agent'] = DE

# Generated at 2022-06-25 19:23:20.084866
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_arg_0 = 'dZ,~A5D5U6_*U,F:p'
    session_arg_0 = Session(path_arg_0)
    request_headers_arg_0 = ''
    try:
        session_arg_0.update_headers(request_headers_arg_0)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 19:23:28.822847
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookie_0 = RequestsCookieJar()
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    str_1 = 'p#M\\j'
    str_2 = '#O'
    session_0.cookies = cookie_0
    # satisfiable preconditions (2 matching variants possible)
    # 0 == len(list(cookie_0))
    # 1 == len(list(cookie_0))
    # 1 == len(list(cookie_0))
    cookie_0.set(str_1, str_2)
    session_0.remove_cookies(list(cookie_0))
    # satisfiable preconditions (2 matching variants possible)
    # 0 == len(list(cookie_0))
    # 1 ==

# Generated at 2022-06-25 19:23:33.008620
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arguments
    str_0 = ''
    list_0 = []

    # Method call
    str_1 = str_0
    # add_header(str_1, list_0)
    str_1 = '--session=' + str_1
    # remove_cookies(str_1, list_0)


# Generated at 2022-06-25 19:23:38.995313
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(Path('/\\V;N.K?H~V7/{_P:uK[EYoC`R'))
    request_headers_0 = RequestHeadersDict({})
    session_0.update_headers(request_headers_0)
    assert session_0['headers'] == dict({})


# Generated at 2022-06-25 19:23:42.653438
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Test 1
    str_0 = 'L-}yqqI,w}&Y5z0#q9X'
    session_0 = Session(str_0)
    # Should throw an exception
    try:
        session_0.update_headers(dict())
    except KeyError as e:
        print(e)


# Generated at 2022-06-25 19:23:46.995738
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    list_0 = ['W8:E', '?', '3eN-', 'W8:E', '3eN-', '?', 'W8:E']
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:23:51.855192
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '!n:!*!-?7#}K'
    path = Path(str_0)
    session_0 = Session(path)
    str_1 = ''
    request_headers = RequestHeadersDict({str_1: str_0})
    session_0.update_headers(request_headers)


# Generated at 2022-06-25 19:24:03.367156
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '!*PJV]O-<'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['cookies'] = dict_0
    dict_1['headers'] = dict_0
    session_0 = Session(str_0)
    session_0.update_headers(dict_1)
    dict_2 = dict()
    dict_2['content-type'] = 'foo/bar'
    dict_1 = dict()
    dict_1['cookies'] = dict_2
    dict_1['headers'] = dict_2
    session_0.update_headers(dict_1)
    dict_2 = dict()
    dict_2['content-type'] = 'foo/bar'
    dict_1 = dict()
    dict_1['cookies'] = dict_2


# Generated at 2022-06-25 19:24:09.352504
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.context import Environment
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    url = httpbin('/get')

    def get_env():
        return Environment(stdin_isatty=False, stdout_isatty=False)

    def request(session_name=None):
        return http(
            '--session=%s' % session_name,
            '--print=h',
            env=get_env(),
            session_as_json=True,
            ignore_stdin=True,
        )

    r = request('test')
    assert HTTP_OK in r
    assert '"Cookie": "a=1"' in r
    r = request('test')
    assert HTTP_OK in r
    assert '"Cookie": "a=1"' in r




# Generated at 2022-06-25 19:24:23.752880
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Setup
    session_0 = Session('test.json')
    session_0['headers'] = ''
    session_0['cookies'] = ''

    request_headers_0 = RequestHeadersDict()
    request_headers_0['Content-Type'] = 'text/html; charset=UTF-8'
    request_headers_0['Connection'] = 'keep-alive'

# Generated at 2022-06-25 19:24:36.049206
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('session_0')

    # Test 1: Ensure that the request headers are added to the session headers
    request_headers_0 = RequestHeadersDict([
        ['X-Request-Header-0', 'Value-0']
    ])
    session_0.update_headers(request_headers_0)
    assert session_0.headers == request_headers_0

    # Test 2: Ensure that an empty request headers does not add keys and values
    # to a non-empty session headers
    request_headers_1 = RequestHeadersDict()
    session_0.update_headers(request_headers_1)
    assert session_0.headers == request_headers_0

    # Test 3: Ensure that the request cookies are added to the session cookies
    print(session_0.cookies)
    assert False
    # Test

# Generated at 2022-06-25 19:24:46.604790
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.context import Environment
    from httpie.cli.parser import get_parser
    from httpie.plugins import plugin_manager
    plugin_manager.authentication_plugins = {
        'httpie_httpie-unixsocket': HTTPUnixSocketAuth,
        'httpie_httpie_shell': HTTPShellAuth,
        'httpie_builtin_basic': HTTPBasicAuth,
        'httpie_builtin_digest': HTTPDigestAuth
    }
    args = get_parser().parse_args(
        args=[
            '--session=/tmp/httpie.sessions/httpie-unixsocket/session.json',
            'http://example.com'
        ]
    )
    env = Environment(config_dir=None)
    session_

# Generated at 2022-06-25 19:24:48.880168
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('str_0')
    session.update_headers({'str_1': 'str_2', 'str_3': 'str_4'})



# Generated at 2022-06-25 19:24:56.020075
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    str_0 = 'Q\\&l<a%'
    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = []
    list_4 = []
    list_5 = []

    local_headers = []

    list_0.append(('Accept', 'application/json'))
    list_0.append(('User-Agent', 'HTTPie/1.0.2'))
    list_0.append(('Host', 'localhost:8080'))
    list_0.append(('Connection', 'keep-alive'))
    list_0.append(('Cache-Control', 'no-cache'))
    list_0.append(('Content-Type', 'application/json'))
    list_0.append(('Content-Length', '0'))


# Generated at 2022-06-25 19:25:02.310626
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.sessions import Session
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.cookies import RequestsCookieJar
    from httpie.config import Config
    from httpie.plugins import plugin_manager
    import os
    import re
    import tempfile
    path_0 = tempfile.gettempdir()
    session_0 = Session(path_0)
    session_0.update_headers(RequestHeadersDict())
    name_0 = '.hdfs.elementLeafGram'
    def replace_string(s):
        return s.replace('.', '_')
    name_1 = replace_string(name_0)
    sessions_dir_name_0 = 'sessions'
    default_sessions_dir_0 = DEFAULT_CONFIG_DIR / sessions

# Generated at 2022-06-25 19:25:10.496967
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'JN`WO&I>|wR(P/cB8fw#Y@"L0'
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_3 = bool()
    bool_2 = bool_3
    bool_1 = bool_2
    bool_0 = bool_1
    bool_0 = bool_5
    bool_0 = bool_3
    bool_0 = bool_5
    bool_0 = bool_4
    bool_0 = bool_4
    bool_0 = bool_4
    bool_0 = bool_4
    bool_0 = bool_4
    bool_0

# Generated at 2022-06-25 19:25:17.069540
# Unit test for method update_headers of class Session
def test_Session_update_headers():

    session_1 = Session('dWw+D|x&[!E(;M8')
    session_1.update_headers({'User-Agent': 'HTTPie/0.9.2'})
    headers = session_1.headers

    bool_var_0 = 'User-Agent' in headers.keys()
    assert bool_var_0

    session_1.update_headers({'Host': 'httpbin.org'})
    headers = session_1.headers

    bool_var_0 = 'Host' not in headers.keys()
    assert bool_var_0

# Generated at 2022-06-25 19:25:21.665803
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    val_0 = None
    session_0 = Session(val_0)
    dict_0 = dict()
    dict_0['Accept'] = str_list_0[0]
    dict_0['Accept'] = str_list_0[0]
    dict_0['Accept'] = str_list_0[0]
    dict_0['Accept'] = str_list_0[0]
    dict_0['Accept'] = str_list_0[0]
    val_1 = RequestHeadersDict(dict_0)
    session_0.update_headers(val_1)

# Generated at 2022-06-25 19:25:23.288262
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert callable(Session.update_headers)


# Generated at 2022-06-25 19:25:30.133497
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print('Testing Session.update_headers')
    # Tests for methods with basic functionality
    assert True 


# Generated at 2022-06-25 19:25:41.955451
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    bytes_0 = b'\xfc\xdb\x91O\xbd\xa6\xb3\xa9\xc2\x8b\xca\xf3\x94\x08\x8f'
    bytes_1 = b'\xd5\xb8\x0e\x93\x82\xbd'
    bytes_2 = b'\xd4\x9b\x8e\x8aQ\x83'
    str_0 = '[1.0.0.0,)'
    int_0 = -813275512
    int_1 = 1101654312
    session_0, session_1 = Session(int_0), Session(int_1)
    buffer = bytearray(89)
    view = memoryview(buffer)

# Generated at 2022-06-25 19:25:52.814680
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '!TKBf1q-w[#j'
    str_1 = '&)@pH-9MZEjBn}f,T1'
    str_2 = '?i`Y)`~*&x_P'
    str_3 = 'y V=2]|!CwI[JM>%a?<'
    str_4 = 'D/1~WpK8_v$-;N'
    str_5 = '/@{!HEQ!xqc%7XQ'
    str_6 = 'Cm;'
    str_7 = 'u4"VlK!|'
    str_8 = 'W?kPzv'
    str_9 = 'Yh<~'
    str_10 = '$2n_`'
   

# Generated at 2022-06-25 19:25:58.542827
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    headers_dict_0 = {
        'Host': 'host1',
        'User-Agent': 'agent1',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Content-Type': 'application/xml; charset=UTF-8',
        'Content-Length': '0',
        'SOAPAction': 'urn:sap-com:document:sap:soap:functions:mc-style:ZS_EVENT_SERVICE:EventQueryRequest',
        'Connection': 'keep-alive',
        'Cache-Control': 'max-age=0'
    }

# Generated at 2022-06-25 19:26:06.261860
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_obj = Session('ClV7JW8q/gxIj+n/ivJzt2')
    session_obj.update_headers({'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*', 'User-Agent': 'HTTPie/0.11.0'})
    assert session_obj['headers'] == {'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'User-Agent': 'HTTPie/0.11.0'}


# Generated at 2022-06-25 19:26:10.452391
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    class_ = Session
    arg_0 = ';'
    arg_1 = {'j4L)G*0'}
    session_ = class_(arg_0)
    session_.remove_cookies(arg_1)


# Generated at 2022-06-25 19:26:17.300557
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    default_headers = {
        'Host': 'httpbin.org',
        'Accept': 'application/json',
        'User-Agent': 'HTTPie/2.0.0'
    }
    request_headers = {
        'Host': 'httpbin.org',
        'Accept': 'application/json',
        'User-Agent': 'HTTPie/2.0.0'
    }
    path_0 = 'httpbin.org'
    session_0 = Session(path_0)
    session_0.update_headers(request_headers)



# Generated at 2022-06-25 19:26:19.902425
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    session = Session()
    session.update_headers(RequestHeadersDict())


# Generated at 2022-06-25 19:26:26.092838
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('session-0.json')

    session_0.remove_cookies(['name-0', 'name-1'])

    session_0.remove_cookies(['name-0', 'name-1'])

    session_0.remove_cookies(['name-0', 'name-1'])

    session_0.remove_cookies(['name-0', 'name-1'])

    session_0.remove_cookies(['name-0', 'name-1'])

    session_0.remove_cookies(['name-0', 'name-1'])

    session_0.remove_cookies(['name-0', 'name-1'])


# Generated at 2022-06-25 19:26:28.931559
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    data = []
    data.append('"jhg\\\\"\\"fhg"')
    rs = (session_0.remove_cookies(data))
    assert rs is None, 'Line 24, test_case_0'

# Generated at 2022-06-25 19:26:42.079275
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session("./data/sessions/http/localhost/empty")
    headers_0 = {'accept-encoding': 'gzip, deflate', 'accept': '*/*', 'User-Agent': 'HTTPie/1.0.2'}
    session_0.update_headers(headers_0)

    expected_result = {'accept': '*/*'}
    actual_result = session_0['headers']
    assert actual_result == expected_result, f"\nFailed: test_Session_update_headers\nexpected: {expected_result}\nactual:   {actual_result}"


# Generated at 2022-06-25 19:26:48.905449
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('h5V/K/Ec/U{6* !(~')

    # Test 1

# Generated at 2022-06-25 19:26:55.573496
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'rFkx@LRIIfCtY,p17z%'
    session_0 = Session(str_0)
    str_1 = 'Sb1.NLGwH!V1@8N^;$'
    str_2 = 'V/Ll(1[)iCV#x,i43w.'
    str_3 = '){@tO~3i,9Xsrc2S[5_'
    str_4 = 'M8,OLH$}]KjV^y)E.%e'
    str_5 = '.,!N_T)d6Kj).6#;,n:'
    str_6 = '1@^G/e*}c-q3ZwzCmQM'

# Generated at 2022-06-25 19:26:59.286847
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:27:05.924288
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # 1st test
    str_1 = 'h5V/K/Ec/U{6* !(~'
    session_1 = Session(str_1)
    dict_1 = {}
    dict_1['User-Agent'] = 'HTTPie/1.0.2'
    dict_1['Host'] = 'httpbin.org'
    req_hdr_dict_1 = RequestHeadersDict(dict_1)
    session_1.update_headers(req_hdr_dict_1)
    assert session_1 == {'auth': {'password': None, 'type': None, 'username': None}, 'cookies': {}, 'headers': {'User-Agent': 'HTTPie/1.0.2', 'Host': 'httpbin.org'}}


# Generated at 2022-06-25 19:27:13.661216
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print('test_Session_update_headers')
    ConfigDict_0 = BaseConfigDict(
        path=Path('/home/user/.config/httpie/sessions/localhost/test.json'))
    # Case 1:
    session_0 = Session(ConfigDict_0)

    # Case 1:
    request_headers_0 = RequestHeadersDict({
        'Cookie': 'cookie_0=val_0; cookie_1=val_1',
        'Content-Type': 'application/json',
        'user-agent': 'HTTPie/1.0.3',
        'If-Match': '*'
    })
    session_0.update_headers(request_headers_0)

    # Case 2:

# Generated at 2022-06-25 19:27:17.658499
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    desired_return_value_0 = None
    session_0 = Session("PZN")
    session_0.remove_cookies(["4M#", "zE", "h", "H>'`fk;$", "q3:E[=Y", "G", "fy", "n", ")R{", "F)/k", "Hw", "(U", ":)"])


# Generated at 2022-06-25 19:27:21.899958
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session.__new__(Session)
    session.__dict__['cookies'] = None
    session.__dict__['auth'] = None
    session.__dict__['headers'] = {}
    session.remove_cookies(['1', '2', '3'])

# Generated at 2022-06-25 19:27:26.373695
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Case 0 - remove all names
    session_0 = Session('abc')
    session_0['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session_0.remove_cookies(['a', 'b', 'c'])
    assert session_0['cookies'] == {}

# Generated at 2022-06-25 19:27:32.157227
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    path_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(path_0)
    request_headers_0 = RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9'})
    request_headers_0.update_headers(request_headers_0)
    try:
        session_0.update_headers(request_headers_0)
    except NameError:
        print('NameError exception')
    except Exception:
        print('Other exception')


# Generated at 2022-06-25 19:27:41.903843
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(str())
    headers_0 = RequestHeadersDict()
    session_0._Session__setitem__('headers', headers_0)
    headers_0['User-Agent'] = ('HTTPie/1.0.2')
    headers_0['Connection'] = ('keep-alive')
    headers_1 = headers_0
    session_0['headers'] = headers_0
    request_headers = headers_1
    session_0.update_headers(request_headers)



# Generated at 2022-06-25 19:27:51.154681
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'R]$#8[okWpYB'
    str_1 = '/|1b}y5'
    int_0 = 0
    dict_0 = dict()
    dict_0[str_0] = int_0
    dict_1 = dict()
    dict_1[str_1] = dict_0
    str_2 = 'Xy'
    dict_1[str_2] = dict_0
    str_3 = 'k@UQ7.sz'
    dict_0[str_3] = int_0
    str_4 = 'JU6_ZT7:'
    dict_1[str_4] = dict_0
    set_0 = set()
    session_0 = Session(set_0)
    session_0.update(dict_1)


# Generated at 2022-06-25 19:27:52.991294
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    try:
        Session.remove_cookies()
    except TypeError:
        pass
    else:
        raise RuntimeError


# Generated at 2022-06-25 19:28:02.935861
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.context import Environment
    from httpie.context import Environment as ContextEnvironment

    env_0 = Environment(
        Color=None,
        ConfigDir=None,
        Formatter=None,
        IsWindows=None,
        OutputFile=None,
        StdErr=None,
        StdIn=None,
        StdOut=None,
        Style=None,
        Variables=None,
        arg_config_dir=None,
        auths=None,
        headers=None,
        ignore_stdin=None,
        json=None,
        method=None,
        params=None,
        stdin_isatty=None,
        url=None,
        verify=None
    )

# Generated at 2022-06-25 19:28:06.134525
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    dict_0 = {}
    dict_1 = dict_0
    session_0.update_headers(dict_1)


# Generated at 2022-06-25 19:28:17.154380
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    list_0 = list()
    session_0.remove_cookies(list_0)
    list_1 = list()
    session_0.remove_cookies(list_1)
    list_2 = list()
    session_0.remove_cookies(list_2)
    list_3 = list()
    session_0.remove_cookies(list_3)
    list_4 = list()
    session_0.remove_cookies(list_4)
    list_5 = list()
    session_0.remove_cookies(list_5)
    list_6 = list()
    session_0.remove_cookies(list_6)
    list_

# Generated at 2022-06-25 19:28:22.477309
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    """When called with argument "request_headers" of type RequestHeadersDict, this method returns
    nothing.
    """
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:28:28.746778
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print('\n## Testing method update_headers of class Session')
    session_0 = Session('diaOQV7|R;>`uV7th=T')
    session_0._is_loaded = True
    session_0['headers'] = {}
    headers_0 = RequestHeadersDict()
    headers_0.add('Content-Type', 'text/plain; charset=utf-8')
    session_0.update_headers(headers_0)
    print(session_0['headers'])
    print(session_0.headers)


if __name__ == '__main__':
    test_Session_update_headers()


# vim:sts=4:sw=4:et:

# Generated at 2022-06-25 19:28:31.648495
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('')
    request_headers_0 = RequestHeadersDict()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:28:33.662828
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_1 = Session('/tmp/session.json')
    assert session_1.update_headers({}) == None


# Generated at 2022-06-25 19:28:40.746880
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Setup
    path = "C:/Users/mmcgrath/httpie/httpie/sessions/session.json"
    session = Session(path)
    request_headers = {}

    # Test
    session.update_headers(request_headers)


# Generated at 2022-06-25 19:28:47.050818
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_0 = Session('session')
    var_1 = dict()
    var_2 = list()
    var_2.append(('1', '2'))
    var_2.append(('2', '3'))
    var_2.append(('3', '4'))
    var_1.update(var_2)
    var_0.update_headers(var_1)
    var_0.var_1
    assert True


# Generated at 2022-06-25 19:28:49.727887
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    var_1 = Session(path = './sessions/default')

    var_2 = RequestHeadersDict({'Content-Type': 'application/json'})
    var_1.update_headers(var_2)


# Generated at 2022-06-25 19:28:56.716348
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Setup mock
    response = requests.Response()
    response.headers = {'Cookie': 'PHPSESSID=1'}
    response.cookies = requests.cookies.RequestsCookieJar()
    response.cookies.set('PHPSESSID', '1', path='/')

    session = Session('test_session')
    session.update_headers(headers={'Accept': '*/*', 'cookie': response.cookies})

    assert session.headers == {'accept': '*/*'}
    assert session.cookies == response.cookies


# Generated at 2022-06-25 19:28:57.492844
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert True == True

# Generated at 2022-06-25 19:29:07.658734
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # 1
    var_0 = Session("C:\\Users\\dell\\Desktop\\test\\test.json")
    var_1 = RequestHeadersDict()
    var_1 = {'content-length': '0', 'content-type': 'text/plain; charset=UTF-8', 'date': 'Mon, 04 Feb 2019 14:49:32 GMT', 'server': 'Apache', 'set-cookie': 'PHPSESSID=8b9e9cb85eb46a920a16da89a8b100d7; path=/; HttpOnly'}
    var_0.update_headers(var_1)
    assert var_0.headers["content-length"] == 0
    assert var_0.headers["content-type"] == 'text/plain; charset=UTF-8'

# Generated at 2022-06-25 19:29:12.793038
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Declare arguments
    config_dir = Path('./')
    session_name = 'test_Session_update_headers'
    host = '127.0.0.1'
    url = 'http://127.0.0.1/'
    s = get_httpie_session(config_dir, session_name, host, url)
    # Add a header explicitly
    s.update_headers({'authorization':'bob'})
    # Check that it is set
    assert s.headers['authorization'] == 'bob'
    # See if it is stored
    s.save()
    s = get_httpie_session(config_dir, session_name, host, url)
    assert s.headers['authorization'] == 'bob'
    # Check that the cookie headers are parsed out
    s.update_

# Generated at 2022-06-25 19:29:16.234829
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = get_httpie_session('/home/dietpi/.config', 'session-name', 'host', 'url')
    names = ['abc']

    session.remove_cookies(names)
    

# Generated at 2022-06-25 19:29:25.583286
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    var_0 = {}
    var_0.setdefault('__class__', type(var_0))
    var_0.setdefault('__qualname__', type(var_0).__qualname__)
    var_1 = 123
    var_0.setdefault(var_1, var_1)
    var_2 = {}
    var_2.setdefault('host', 'example.com')
    var_3 = {}
    var_3.setdefault('type', 'basic')
    var_3.setdefault('username', 'user')
    var_3.setdefault('password', 'password')
    var_2.setdefault('auth', var_3)
    var_4 = {}
    var_4.setdefault('User-Agent')

# Generated at 2022-06-25 19:29:26.449475
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 19:29:34.169552
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    headers_0 = {}
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:29:39.111813
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'Z[uV7I|'
    session_0 = Session(str_0)
    str_1 = 'h5V/K/Ec/U{6* !(~'
    headers_0 = RequestHeadersDict(str_1)
    session_0.update_headers(headers_0)


# Generated at 2022-06-25 19:29:42.481181
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    names = []
    session_0.remove_cookies(names)


# Generated at 2022-06-25 19:29:50.745278
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Create a Session object and get it's associated cookies dictionary
    # The cookies dictionary contains a name as a key and an associated cookie information
    # as a value
    # The cookie information is a dictionary containing:
    #   a value associated with the cookie name
    #   the path of the cookie
    #   some other information

    #   The value of the cookie is the data stored by the cookie in the browser
    #   The remaining information are related to the function of the cookie
    session = Session("")
    session["cookies"] = {}
    cookie_dictionary = session["cookies"]

    # We create a list with the names of the cookies that we now add the dictionary
    # The cookies are added to the dictionary one by one
    cookie_name_list = ["hello","hello2","hello3","hello4"]

# Generated at 2022-06-25 19:29:53.155171
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 19:29:58.895484
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('mock')
    session['cookies']['session-id'] = {'value': 'random'}
    session['cookies']['phpsess'] = {'value': 'random'}
    session.remove_cookies(['nonce', 'phpsess'])
    assert session['cookies'] == {'session-id': {'value': 'random'}}

# Generated at 2022-06-25 19:30:03.286196
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    str_1 = 'Bzd7V\t&IE@2lV'
    str_2 = '<;RF!u*M}yU6T'
    session_0.remove_cookies(names=[str_1, str_2])


# Generated at 2022-06-25 19:30:08.283025
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    request_headers_0 = {}
    request_headers_0['User-Agent'] = 'HTTPie/0.9.5'
    request_headers_0['Accept'] = '*/*'
    class_0 = request_headers_0.__class__
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:30:13.875874
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    print('\nTesting update_headers of Session')
    x = Session('/home/user/.config/httpie/sessions/localhost/session.json')
    x.update_headers({'remote': '0.0.0.0'})
    assert x['headers'] == {'remote': '0.0.0.0'}
    x.update_headers({'Content-Type': 'text/html; charset=UTF-8'})
    assert x['headers'] == {'remote': '0.0.0.0'}
    x.update_headers({'user-agent': 'HTTPie/0.10.0'})
    assert x['headers'] == {'remote': '0.0.0.0'}

# Generated at 2022-06-25 19:30:14.652551
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    assert True

# Generated at 2022-06-25 19:30:26.840687
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'Qgf&G"<'
    session_0 = Session(str_0)
    session_0.load()
    session_0.remove_cookies(['CookieName'])


# Generated at 2022-06-25 19:30:36.189402
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)

    request_headers_0 = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:12.0) Gecko/20100101 Firefox/21.0',
                         'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                         'Accept-Language': '*'}
    session_0.update_headers(request_headers_0)

# The instance method update_headers of class Session has not yet been implemented

# Generated at 2022-06-25 19:30:42.113350
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('sessions.json')
    session.load()
    str_0 = 'h5V/K/Ec/U{6* !(~'
    session_0 = Session(str_0)
    names = ['bzR']
    session.remove_cookies(names)
    assert session == session_0
