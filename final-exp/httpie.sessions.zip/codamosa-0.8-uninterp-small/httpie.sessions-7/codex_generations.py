

# Generated at 2022-06-25 19:21:01.166468
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'f'
    session_0 = Session(str_0)
    class RequestHeadersDict_0:
        def values():
            return [255, 255, 255]
    request_headers_0 = RequestHeadersDict_0()
    session_0.update_headers(request_headers_0)


# Generated at 2022-06-25 19:21:04.186954
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '',
    int_1 = 5
    str_2 = '',
    session_3 = Session(str_0)
    session_3.set('httpbin.org', str_2, int_1)
    session_3.remove_cookies((str_2,))



# Generated at 2022-06-25 19:21:15.698431
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'd6cvH;%c(n)n>9'
    int_0 = -2
    path_0 = Path(str_0)
    session_0 = Session(path_0)
    session_0['headers'] = {}
    session_0['cookies'] = {}
    session_0['auth'] = {
        'type': None,
        'username': None,
        'password': None
    }
    str_1 = 'OjP:V7\x0c'
    str_2 = "c%=4\t"
    str_3 = "^Z@\x0c"
    int_1 = 2
    request_headers_dict_0 = RequestHeadersDict({str_1: str_2, str_3: int_1})
    session_0.update

# Generated at 2022-06-25 19:21:20.765749
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session("")
    session_0.update_headers(RequestHeadersDict())
    session_0.update_headers(RequestHeadersDict())
    session_0.update_headers(RequestHeadersDict())
    session_0.update_headers(RequestHeadersDict())


# Generated at 2022-06-25 19:21:26.100889
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'n'
    RequestHeadersDict_1 = RequestHeadersDict()
    session_1 = Session(str_0)
    with pytest.raises(AttributeError):
        session_1.headers = RequestHeadersDict_1
    session_1.update_headers(RequestHeadersDict_1)


# Generated at 2022-06-25 19:21:28.811755
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'V'
    session_0 = Session(str_0)
    int_0 = session_0.update_headers(session_0)


# Generated at 2022-06-25 19:21:38.574867
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # Create an instance of the class Session
    session_0 = Session('e')
    # Create an instance of the class RequestHeadersDict
    request_headers_0 = RequestHeadersDict()
    # Create an instance of the class RequestHeadersDict
    request_headers_1 = RequestHeadersDict()
    # Invoke method update_headers of session_0 instance with request_headers_0 parameter
    session_0.update_headers(request_headers_0)
    # Invoke method update_headers of session_0 instance with request_headers_1 parameter
    session_0.update_headers(request_headers_1)


# Generated at 2022-06-25 19:21:39.487817
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    pass


# Generated at 2022-06-25 19:21:41.614676
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    #Arrange
    obj = Session(str_0)
    #Act
    obj.update_headers(str_0)
    #Assert


# Generated at 2022-06-25 19:21:42.382292
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    test_case_0()


# Generated at 2022-06-25 19:21:56.338960
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '$'
    session_0 = Session(str_0)
    dict_0 = {'Host': 'localhost:8080', 'User-Agent': 'httpie', 'Accept': '*/*'}
    session_0.update_headers(dict_0)


# Generated at 2022-06-25 19:21:57.440212
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    names = '[""]'
    obj = Session()
    obj.remove_cookies(names)


# Generated at 2022-06-25 19:22:01.215064
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'cP'
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict({'Content-Type': 'text/plain'})
    session_0.update_headers(request_headers_0)
    assert session_0.headers == {'Content-Type': 'text/plain'}


# Generated at 2022-06-25 19:22:04.747893
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_1 = '8C'
    session_1 = Session(str_1)
    str_2 = 'reQ'
    list_1 = [str_2]
    session_1.remove_cookies(list_1)


# Generated at 2022-06-25 19:22:07.420909
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'jIEJ'
    session_0 = Session(str_0)
    str_1 = 'V'
    session_0.remove_cookies([str_1])


# Generated at 2022-06-25 19:22:12.628376
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = 'R'
    session_1 = Session(str_1)
    dict_2 = {str_1: str_1}
    dict_3 = dict_2
    session_1.headers = dict_2
    session_1.update_headers(dict_3)


# Generated at 2022-06-25 19:22:16.975637
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session(Path('/C:/Users/Administrator/PycharmProjects/httpie'))
    request_headers = {}
    request_headers['User-Agent'] = 'HTTPie/0.9.2'
    session_0.update_headers(request_headers)


# Generated at 2022-06-25 19:22:26.575089
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # 'headers': {}
    str_0 = '8C'
    session_0 = Session(str_0)
    session_0['headers'].clear()
    # 'headers': {}
    str_1 = '8C'
    session_1 = Session(str_1)
    session_1['headers'].clear()
    # 'headers': {'Host': 'httpie.org', 'Accept': 'application/json'}
    str_2 = '8C'
    session_2 = Session(str_2)
    session_2['headers']['Host'] = 'httpie.org'
    session_2['headers']['Accept'] = 'application/json'
    # 'headers': {'Host': 'httpie.org', 'Accept': 'application/json'}
    str_3 = '8C'


# Generated at 2022-06-25 19:22:34.146729
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    cookies = RequestsCookieJar()
    cookie_0 = create_cookie('foo', 'bar')
    cookie_1 = create_cookie('baz', 'qux')
    cookies.set_cookie(cookie_0)
    cookies.set_cookie(cookie_1)
    session_0 = Session('/x8')
    session_0.cookies = cookies
    str_0 = 'baz'
    str_1 = 'foo'
    session_0.remove_cookies([str_0, str_1])


# Generated at 2022-06-25 19:22:37.142879
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '8'
    session_0 = Session(str_0)
    str_1 = '/'
    headers_1 = RequestHeadersDict()
    headers_1['Content-Length'] = '7'
    headers_1['Content-Type'] = 'application/x-www-form-urlencoded'
    headers_2 = RequestHeadersDict()
    headers_2['Content-Length'] = '5'
    headers_2['Content-Type'] = 'application/x-www-form-urlencoded'
    headers_1.update(headers_2)
    session_0.update_headers(headers_1)


# Generated at 2022-06-25 19:22:52.964929
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # <https://github.com/jakubroztocil/httpie/issues/336>
    str_0 = '8C'
    session_0 = Session(str_0)
    session_0.load()
    str_1 = ';'
    # case_0
    session_0.remove_cookies(str_1)


# Generated at 2022-06-25 19:22:56.083541
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    names_0 = ['8C']
    session_0.remove_cookies(names_0)



# Generated at 2022-06-25 19:22:58.644192
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    assert hasattr(Session, 'remove_cookies')
    str_0 = '8C'
    session_0 = Session(str_0)


# Generated at 2022-06-25 19:23:05.348420
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '"'
    str_1 = '`'
    str_2 = '%'
    str_3 = 'W8'
    session_0 = Session(str_3)
    cookie_dict_0 = {}
    jar_0 = RequestsCookieJar()
    jar_0.set(cookie_dict_0)
    session_0.cookies = jar_0
    str_4 = 'j'
    str_5 = 'F<#>'
    str_6 = 'j/3'
    session_0.headers[str_6] = str_4
    list_0 = []
    str_7 = '"i'
    list_0.append(str_7)
    str_8 = 't'
    list_0.append(str_8)

# Generated at 2022-06-25 19:23:08.648768
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = 'v'
    session_0 = Session(str_0)
    request_headers_dict_0 = Session(str_0)
    session_0.update_headers(request_headers_dict_0)


# Generated at 2022-06-25 19:23:12.423502
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'a'
    session_0 = Session(str_0)
    str_1 = 'b'
    assert_equal(session_0.remove_cookies(str_1), None)



# Generated at 2022-06-25 19:23:16.930962
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'Bn^'
    session_0 = Session(str_0)
    str_1 = 'z!5>'
    iterable_0 = str_1
    assert_raises(TypeError, session_0.remove_cookies, iterable_0)

test_case_0()
test_Session_remove_cookies()


# vim:ts=4 sts=4 sw=4 et

# Generated at 2022-06-25 19:23:20.914235
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('\Session')
    session_0.remove_cookies(['remove_cookies', 'remove_cookies'])
    assert session_0 == '\Session', 'remove_cookies #0'


# Generated at 2022-06-25 19:23:28.377533
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    host_0 = 'adomain.com'
    url_0 = 'http://example.com/'
    str_0 = '8C'
    path_0 = os.path.expanduser(str_0)
    path_1 = Path(path_0)
    path_1 = (path_1 / 'sessions')
    path_1 = (path_1 / 'adomain.com')
    path_1 = (path_1 / '8C.json')
    session_0 = Session(path_1)
    session_0.load()
    assert type(session_0.remove_cookies([host_0])) is None


# Generated at 2022-06-25 19:23:38.954792
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    # This var contains the test data for update_headers of Session
    test_data = {}
    # The actual data returned by update_headers:
    actual_result = {}
    # The expected data:
    expected_result = {}
    # Iterate over the test data:
    for test_input, test_output in test_data.items():
        # Update the headers of session_0 with the data:
        session_0.update_headers(test_input)
        # Store the actual data in actual_result:
        actual_result[test_input] = session_0.headers
        # Store the expected data in expected_result:
        expected_result[test_input] = test_output
    # Assert the test results:
    assert actual_result == expected_result


# Generated at 2022-06-25 19:23:56.283539
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session_0 = Session('')
    url_0 = 'http://localhost:5000/'
    redirects_0 = 1
    cookies_0 = ''
    headers_0 = {'Content-Type': 'application/json', 'Accept': '*/*', 'Connection': 'keep-alive', 'Content-Length': '15', 'User-Agent': 'HTTPie/2.0.0'}
    auth_0 = ''
    data_0 = ''
    debug_0 = 1
    follow_0 = 1
    verbose_0 = 1
    verify_0 = 1
    proxy_0 = ''
    adb_0 = ''
    session_0.update_headers(headers_0)

# Generated at 2022-06-25 19:24:00.660270
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_1 = 'f'
    HeadersDict_1 = RequestHeadersDict()
    session_1 = Session(str_1)
    session_1.update_headers(HeadersDict_1)


# Generated at 2022-06-25 19:24:09.496268
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    expected_0 = {'Gandalf': 'You shall not pass!'}
    session_0 = Session('c:/')
    session_0.update_headers({'Gandalf': 'You shall not pass!'})
    actual_0 = session_0.headers
    assert actual_0 == expected_0

# def test_Session_update_headers_2():
#     expected_0 = (
#         {'Gandalf': 'You shall not pass!', 'Authorization':
#          'Basic YmFyOmJhego='})
#     session_0 = Session('c:/')
#     session_0.update_headers({'Gandalf': 'You shall not pass!',
#                               'Authorization': 'Basic YmFyOmJhego='})
#     actual_0 = session_0.headers


# Generated at 2022-06-25 19:24:21.344168
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = "SESSION"
    session_0 = Session(str_0)
    request_headers = {
        'Host': 'fc8b2a3c-a7a3-4f33-9084-d4af2b4f34b4'
    }
    session_0.update_headers(request_headers)
    str_1 = 'MARKET_DEPTH_PAIR.dDw1'
    session_1 = Session(str_1)
    request_headers = {
        'Host': 'b8d7a8a8-1a7c-4453-9e8e-d8854b6bc5b6'
    }
    session_1.update_headers(request_headers)
    str_2 = 'H"G'

# Generated at 2022-06-25 19:24:24.637684
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # assertions
    assert 'session_0' == 'session_0'
    assert 0 == 0
    assert 'cookies' == 'cookies'
    assert 'session_0' == 'session_0'
    assert 0 == 0


# Generated at 2022-06-25 19:24:27.669526
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    iterable = []
    session_0.remove_cookies(iterable)


# Generated at 2022-06-25 19:24:35.962544
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'src7621+'
    test_Session_remove_cookies_0 = Session(str_0)
    str_return_0 = '|$e'
    str_return_1 = '{4'
    str_return_2 = '9lH'
    result_0 = test_Session_remove_cookies_0.remove_cookies(str_return_0,str_return_1,str_return_2)
    assert result_0 == None


# Generated at 2022-06-25 19:24:45.037200
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    key_0 = 'f.n(d'
    dict_0 = dict()
    dict_0[key_0] = key_0
    session_0['cookies'] = dict_0
    session_0['auth'] = dict_0
    session_0.remove_cookies(dict_0)
    str_1 = '8C'
    session_1 = Session(str_1)
    key_1 = 'f.n(d'
    dict_2 = dict()
    dict_2[key_1] = key_1
    session_1['cookies'] = dict_2
    session_1['auth'] = dict_2
    session_1.remove_cookies(dict_2)


# Generated at 2022-06-25 19:24:50.644729
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '<'
    str_1 = 'Gx1'
    str_2 = '5'
    tuple_0 = (str_1,)
    bytes_0 = b'\x1c'

# Generated at 2022-06-25 19:24:53.308949
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    str_0 = '4U6YkUjK'
    session_0 = Session(str_0)
    request_headers_0 = RequestHeadersDict({})
    session_0.update_headers(request_headers_0)



# Generated at 2022-06-25 19:25:11.121276
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    user_0 = Session('gT')
    user_0.remove_cookies(['x'])
    str_0 = 'Gu'
    str_1 = 'Un'
    str_2 = 'Gx'
    str_3 = 'GQ'
    str_4 = '5p'
    str_5 = 'n9'
    str_6 = 'G_'
    str_7 = 'dR'
    str_8 = 'GS'
    str_9 = 'gnu'
    str_10 = 'y_'
    str_11 = 'U6'
    str_12 = '1b'
    str_13 = 'Uy'
    str_14 = 'iO'
    str_15 = 'Ux'
    str_16 = 'Un'

# Generated at 2022-06-25 19:25:15.573891
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '4n'
    session_0 = Session(str_0)
    setattr(session_0, '_Session__path', str_0)
    iterable_0 = [3083, 67, str_0, 67]
    session_0.remove_cookies(iterable_0)


# Generated at 2022-06-25 19:25:20.737689
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('8C')
    str_0 = '\x00\x01'
    str_1 = '9'
    list_0 = []
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:25:24.471419
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    names_0 = []
    session_0.remove_cookies(names_0)
    names_1 = []
    session_0.remove_cookies(names_1)


# Generated at 2022-06-25 19:25:28.402715
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    names_0 = ['8C']
    session_0.remove_cookies(names_0)
    #assert False # TODO: implement your test here


# Generated at 2022-06-25 19:25:35.210598
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    list_0 = ['9X', ']'*521, '/j', '{'*527, u'\u00B3', '=j', '.'*250, '/E', ";xr<"*247, '%'*446, '()'[::-1]]
    session_0.remove_cookies(list_0)
    int_0 = len(list_0)
    int_1 = len(session_0['cookies'])
    assert int_0 == int_1



# Generated at 2022-06-25 19:25:44.780264
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    str_1 = '0'
    str_2 = 'j'
    str_3 = 'M'
    str_4 = 'K'
    str_5 = 'q'
    str_6 = 'o'
    str_7 = 'w'
    str_8 = 'f'
    str_9 = 'f'
    str_10 = '&'
    str_11 = 's'
    str_12 = 'l'
    str_13 = 'y'
    str_14 = '7'
    str_15 = 'A'
    str_16 = 'x'
    str_17 = 'h'
    str_18 = 'v'
    str_19 = 'i'

# Generated at 2022-06-25 19:25:48.213289
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('')
    str_0 = 'hDK'
    list_0 = []
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:25:50.831964
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0 = Session('B')
    session_0.put('u', 'r')
    session_0.remove_cookies(['r'])



# Generated at 2022-06-25 19:25:54.204383
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '5C'
    session_0 = Session(str_0)
    list_0 = ['V3WK4vVO5Gh5', '', '', '-1', '', '']
    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:26:21.695843
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = 'Z'
    session_0 = Session(str_0)
    session_0.update_headers({'User-Agent': 'elinks/0.12pre1 (textmode; Linux 2.6.32-22-generic i686; 80x24-2)'})
    session_0.remove_cookies(['User-Agent', 'Location'])
    session_0.update_headers({'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240'})
    session_0.remove_cookies(['User-Agent', 'X-Gae-ID'])



# Generated at 2022-06-25 19:26:24.181553
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test cases
    # Test case 0
    try:
        test_case_0()
    except Exception as exception:
        print(exception)

if __name__ == '__main__':
    test_Session_remove_cookies()

# Generated at 2022-06-25 19:26:32.983322
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from httpie.context import Environment
    from httpie.cli.parser import parse_args
    from httpie.plugins.registry import builtin_plugins, plugin_manager

    plugin_manager.clear_caches()
    plugin_manager.load_builtin_plugins(builtin_plugins)
    plugin_manager.load_from_config_dir()
    env = Environment()
    args = parse_args(['--debug'], env=env)
    env.config.load_config(args)
    session_0 = get_httpie_session(env.config.config_dir, 'test', None, 'http://127.0.0.1:8080/test')
    session_0.load()

    str_0 = ''

# Generated at 2022-06-25 19:26:43.996789
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Test 1
    str_0 = 'B'
    session_0 = Session(str_0)

    str_1 = 'Co'
    str_2 = 'x'
    str_3 = '!q'
    str_4 = 'p'
    str_5 = 'M'
    str_6 = 'm\\m'
    str_7 = 'B'
    str_8 = 'G'
    str_9 = 'T'
    str_10 = 'g'
    str_11 = 'n'
    str_12 = '1'
    str_13 = '['
    str_14 = '@'
    str_15 = 'S'
    str_16 = 'p'
    str_17 = 'q'
    str_18 = 'O'
    str_19 = 'M'


# Generated at 2022-06-25 19:26:50.484337
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    try:
        session =  Session()
        session.remove_cookies('*')
    except TypeError as e:
        print(e)
        if 'remove_cookies' in str(e):
            print('Function remove_cookies of class Session is not callable')


# Generated at 2022-06-25 19:26:57.391481
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    str_1 = 'supero_ma'
    assert not session_0.remove_cookies(['supero_ma']), 'session.remove_cookies returned an incorrect value: False'


# Generated at 2022-06-25 19:27:01.124476
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Path of the file to be created
    temp_path = Path('/tmp/test_file0.tmp')

    # Create the file if it doesn't exist
    if not temp_path.exists():
        temp_path.touch()

    # Get name of temp file
    temp_path = temp_path.name

    str_0 = '_X'
    session_0 = Session(temp_path)
    session_0.remove_cookies(str_0)



# Generated at 2022-06-25 19:27:11.485362
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    str_1 = '>'
    tuple_0 = (str_1,)
    session_0.remove_cookies(tuple_0)
    session_0.remove_cookies(tuple_0)
    dict_0 = {
        'V': '5zv{7%@Upk-*-'
    }
    tuple_1 = (dict_0,)
    str_2 = 'Jf'
    dict_1 = {
        'xj*pk-': '~W;{_93R',
        '~W;{_93R': '3f@',
        '3f@': 'V<'
    }
    str_3 = 'a'

# Generated at 2022-06-25 19:27:13.477213
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    session_0.load()
    str_1 = 'h7'
    session_0.remove_cookies(str_1)

# Generated at 2022-06-25 19:27:16.737373
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '=oX'
    str_1 = '1'
    str_2 = '2'
    session_0 = Session(str_0)
    session_0.remove_cookies(str_1)
    session_0.remove_cookies(str_2)


# Generated at 2022-06-25 19:28:05.770918
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    list_0 = ['ᅤ', '\xcf\xc8\xd5\xb4Y', 'm', '\xab\xcc\xbb\xee', '\t\xc5\x95']
    session_0.remove_cookies(list_0)
    dict_0 = dict()

# Generated at 2022-06-25 19:28:16.685332
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    iterable_0 = []
    session_0.remove_cookies(iterable_0)
    session_0.path = Path('/home/benjamin/.config/httpie/sessions')
    dct_0 = {
        'username': 'benjamin',
        'password': 'benjamin'
    }
    session_0.auth = dct_0
    session_0.load()
    assert session_0.path.exists()
    assert session_0.auth
    assert session_0.auth == dct_0
    assert session_0.auth['username'] == 'benjamin'
    assert session_0.auth['password'] == 'benjamin'

# Generated at 2022-06-25 19:28:20.453461
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    # constant values
    str_1 = 'httpbin.org'
    list_0 = []

    session_0.remove_cookies(list_0)


# Generated at 2022-06-25 19:28:23.775729
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    names = list()
    session_0.remove_cookies(names)
    str_1 = '__main__.Session'
    assert_equal(str(session_0), str_1)

# Generated at 2022-06-25 19:28:28.410705
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Arrange
    arg0 = dict()
    arg0 = {"cookies": {"user": "John", "password": "S3cur3_Pa55w0rd"}}
    arg1 = dict()
    arg1 = {"cookies": {"user": "John", "password": "S3cur3_Pa55w0rd"}}
    # Act
    session = Session(arg0)
    session.remove_cookies(["user"])
    # Assert
    assert session == arg1



# Generated at 2022-06-25 19:28:38.314585
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    # Case 1:
    str_0 = '8C'
    names_0 = ['a','b','c']
    session_0 = Session(str_0)
    session_0.remove_cookies(names_0)
    assert session_0 == Session(str_0)
    # Case 2:
    str_0 = '8C'
    names_0 = ['a','b','c']
    session_0 = Session(str_0)
    session_0.remove_cookies(names_0)
    assert session_0 == Session(str_0)
    # Case 3:
    str_0 = '8C'
    names_0 = ['a','b','c']
    session_0 = Session(str_0)
    session_0.remove_cookies(names_0)
    assert session_0

# Generated at 2022-06-25 19:28:47.896266
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    str_1 = '3\u0004\u0004 \u0004\u0004!\u0004\u0004\u0012\u0004\u0004\u0004\u0004\u0004\u0004\u0004\u0004\u0004\u0004'
    str_2 = 'A\u0004\u0004,\u0004\u0004I\u0004\u0004\u0011\u0004\u0004\u0004\u0004\u0004\u0004\u0004\u0004\u0004\u0004'

# Generated at 2022-06-25 19:28:58.169876
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    from itertools import repeat
    
    # Case 0:
    str_0 = '8C'
    session_0 = Session(str_0)
    names_0 = ['auth', 'headers', 'cookies']
    session_0.remove_cookies(names_0)

    # Case 1:
    str_1 = 'r1d'
    session_1 = Session(str_1)
    names_1 = ['dX', 'vB', 'oO']
    session_1.remove_cookies(names_1)

    # Case 2:
    str_2 = '8W'
    session_2 = Session(str_2)
    names_2 = ['auth', 'headers', 'cookies']
    session_2.remove_cookies(names_2)

    # Case 3:
    str_

# Generated at 2022-06-25 19:29:07.513388
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    session_0.remove_cookies(['', '', '', '', '', '', '', ''])
    session_0.remove_cookies(['', '', '', '', '', '', '', '', '', ''])
    session_0.remove_cookies(['', '', '', '', '', '', '', '', '', ''])
    session_0.remove_cookies(['', '', '', '', '', '', '', '', '', ''])
    session_0.remove_cookies(['', '', '', '', '', '', '', ''])
    session_0.remove_cookies(['', '', '', '', '', ''])
    session_0.remove_

# Generated at 2022-06-25 19:29:10.561517
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '8C'
    session_0 = Session(str_0)
    args_0 = ['lrazY', 'lWU-A', 'b_6[M', '5G5nD', 'fIol7']
    expected_0 = None
    actual_0 = session_0.remove_cookies(args_0)
    assert expected_0 == actual_0


# Generated at 2022-06-25 19:30:39.959932
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session_0: Session = Session('http://www.example.com')
    cookies_0: RequestsCookieJar = RequestsCookieJar()  # default constructor

    # Test default constructor
    create_cookie_0: http.cookies.Morsel = create_cookie(
        'example_0', 'example_1')
    cookies_0.set_cookie(create_cookie_0)

    session_0.cookies: RequestsCookieJar = cookies_0

    # Test str constructor
    str_0: str = 'http://www.example.com'
    session_0: Session = Session(str_0)
    str_1: str = 'example_2'
    str_2: str = 'example_3'
    session_0.remove_cookies(str_1, str_2)



# Generated at 2022-06-25 19:30:40.836205
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    boolean_0 = Session.remove_cookies(str_0)

# Generated at 2022-06-25 19:30:47.835714
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    str_0 = '7a'
    session_0 = Session(str_0)