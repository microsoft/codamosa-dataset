

# Generated at 2022-06-17 21:06:43.231412
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=None)
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'Content-Type': 'application/json', 'User-Agent': 'HTTPie/1.0.2'})
    assert session.headers == {'User-Agent': 'HTTPie/1.0.2'}
    session.update_headers({'Content-Type': 'application/json', 'User-Agent': 'HTTPie/1.0.2', 'Cookie': 'a=b'})
    assert session.headers == {'User-Agent': 'HTTPie/1.0.2'}
    assert session.cookies.get_dict() == {'a': 'b'}

# Generated at 2022-06-17 21:06:51.417928
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path(''))
    session.update_headers(RequestHeadersDict({
        'Content-Type': 'application/json',
        'Cookie': 'foo=bar',
        'If-Match': '*',
        'User-Agent': 'HTTPie/0.9.9',
        'X-Custom': 'abc',
    }))
    assert session.headers == {
        'Cookie': 'foo=bar',
        'X-Custom': 'abc',
    }
    assert session.cookies == RequestsCookieJar([create_cookie(
        'foo', 'bar',
    )])

# Generated at 2022-06-17 21:06:59.799509
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'content-type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers({'user-agent': 'HTTPie/1.0.2'})
    assert session['headers'] == {}
    session.update_headers({'cookie': 'foo=bar'})
    assert session['cookies'] == {'foo': {'value': 'bar'}}
    session.update_headers({'foo': 'bar'})
    assert session['headers'] == {'foo': 'bar'}
    session.update_headers({'if-match': '*'})
    assert session['headers'] == {'foo': 'bar'}

# Generated at 2022-06-17 21:07:08.180855
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test_session.json')
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session['headers'] == {}
    session.update_headers({'Accept': 'application/json'})
    assert session['headers'] == {'Accept': 'application/json'}
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})
    assert session['cookies'] == {'foo': {'value': 'bar'}, 'baz': {'value': 'qux'}}
    assert session['headers'] == {'Accept': 'application/json'}

# Generated at 2022-06-17 21:07:13.681360
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path(''))
    session.update_headers(RequestHeadersDict({'Content-Type': 'application/json', 'Cookie': 'a=b'}))
    assert session.headers == {'Content-Type': 'application/json'}
    assert session.cookies == RequestsCookieJar()
    session.cookies.set('a', 'b')
    assert session.cookies == RequestsCookieJar()

# Generated at 2022-06-17 21:07:17.510741
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:07:23.663911
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp/test.json'))

# Generated at 2022-06-17 21:07:27.468571
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:07:32.999199
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp/test.json'))
    session.update_headers(RequestHeadersDict({'Content-Type': 'application/json', 'Cookie': 'a=b; c=d'}))
    assert session['headers'] == {'Content-Type': 'application/json'}
    assert session['cookies'] == {'a': {'value': 'b'}, 'c': {'value': 'd'}}

# Generated at 2022-06-17 21:07:37.365120
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.2'})
    assert session['headers'] == {}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session['cookies'] == {'foo': {'value': 'bar'}}
    session.update_headers({'Accept': 'application/json'})
    assert session['headers'] == {'Accept': 'application/json'}
    session.update_headers({'Accept': 'application/xml'})
    assert session['headers'] == {'Accept': 'application/xml'}
    session.update_headers({'Accept': None})
    assert session['headers']

# Generated at 2022-06-17 21:07:47.659685
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-17 21:07:55.927666
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}
    session.remove_cookies(['c'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:08:03.335913
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:08.894623
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test_Session_remove_cookies.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:12.888025
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:15.933671
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-17 21:08:19.715510
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:23.044261
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:08:29.150112
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:32.462733
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_session.json')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:08:46.423094
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:50.279084
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:58.208322
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:00.235489
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    session.remove_cookies(['cookie1', 'cookie3'])
    assert session['cookies'] == {'cookie2': 'value2'}

# Generated at 2022-06-17 21:09:03.672713
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:08.037612
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'a', 'b': 'b', 'c': 'c'}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 'c'}

# Generated at 2022-06-17 21:09:12.741744
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('test.json'))
    session['cookies'] = {'a': '1', 'b': '2', 'c': '3'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:09:15.867625
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'a', 'b': 'b'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': 'b'}

# Generated at 2022-06-17 21:09:22.014338
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'foo': {'value': 'bar'}, 'baz': {'value': 'qux'}}
    session.remove_cookies(['foo'])
    assert session['cookies'] == {'baz': {'value': 'qux'}}

# Generated at 2022-06-17 21:09:26.046272
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test_Session_remove_cookies')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:49.231419
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:55.729901
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(''))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:01.312704
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:10:05.724544
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:09.557987
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}


# Generated at 2022-06-17 21:10:13.163637
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_session.json')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:10:18.291114
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:22.650276
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:27.624946
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:10:32.694878
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:11:17.475840
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test.json')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:11:21.758621
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:11:26.520098
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'foo': 'bar', 'baz': 'qux'}
    session.remove_cookies(['foo'])
    assert session['cookies'] == {'baz': 'qux'}

# Generated at 2022-06-17 21:11:30.673280
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test_session.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:11:34.786272
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(''))
    session['cookies'] = {'a': '1', 'b': '2', 'c': '3'}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': '3'}

# Generated at 2022-06-17 21:11:38.663720
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:11:40.679042
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-17 21:11:45.384769
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:11:49.287294
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:11:55.045074
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 'value2'}

# Generated at 2022-06-17 21:13:30.009778
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': 'a'}, 'b': {'value': 'b'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': 'b'}}

# Generated at 2022-06-17 21:13:33.643767
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:13:40.034683
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:13:42.500283
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'foo': {'value': 'bar'}, 'baz': {'value': 'qux'}}
    session.remove_cookies(['foo'])
    assert session['cookies'] == {'baz': {'value': 'qux'}}

# Generated at 2022-06-17 21:13:45.573545
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': '1', 'b': '2', 'c': '3'}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': '3'}

# Generated at 2022-06-17 21:13:50.463755
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:13:59.061601
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'name1': {'value': 'value1'},
                          'name2': {'value': 'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:14:00.924580
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:14:03.209867
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_session.json')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:14:08.290998
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}