

# Generated at 2022-06-17 21:06:40.017897
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')
    session.update_headers({'Content-Type': 'application/json', 'Cookie': 'a=b'})
    assert session['headers'] == {'Content-Type': 'application/json'}
    assert session['cookies'] == {'a': {'value': 'b'}}

# Generated at 2022-06-17 21:06:45.844776
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')
    session.update_headers({'Content-Type': 'application/json', 'Cookie': 'test=test'})
    assert session.headers == {'Content-Type': 'application/json'}
    assert session.cookies == {'test': 'test'}

# Generated at 2022-06-17 21:06:53.915740
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session.headers == {'Accept': '*/*'}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*', 'Cookie': 'a=b'})
    assert session.headers == {'Accept': '*/*'}
    assert session.cookies == RequestsCookieJar()

# Generated at 2022-06-17 21:07:04.268265
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test_Session_update_headers.json')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {'Content-Type': 'application/json'}
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {'Content-Type': 'application/json'}
    session.update_headers({'Content-Type': 'application/json', 'Content-Length': '0'})
    assert session.headers == {'Content-Type': 'application/json', 'Content-Length': '0'}
    session.update_headers({'Content-Type': 'application/json', 'Content-Length': '0'})

# Generated at 2022-06-17 21:07:15.920292
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session.headers == {'Accept': '*/*'}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*', 'Cookie': 'foo=bar'})
    assert session.headers == {'Accept': '*/*'}
    assert session.cookies == RequestsCookieJar([create_cookie('foo', 'bar')])

# Generated at 2022-06-17 21:07:20.561794
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')
    session.update_headers({'Cookie': 'a=b; c=d', 'User-Agent': 'HTTPie/1.0.2'})
    assert session['headers'] == {'User-Agent': 'HTTPie/1.0.2'}
    assert session['cookies'] == {'a': {'value': 'b'}, 'c': {'value': 'd'}}

# Generated at 2022-06-17 21:07:25.413054
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:07:29.413093
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:07:34.857582
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:07:42.088800
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test.json')
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {}

    session.update_headers({'Content-Type': 'application/json', 'User-Agent': 'HTTPie/1.0.0'})
    assert session['headers'] == {}

    session.update_headers({'Content-Type': 'application/json', 'User-Agent': 'HTTPie/1.0.0', 'Accept': 'application/json'})
    assert session['headers'] == {'Accept': 'application/json'}

    session.update_headers({'Content-Type': 'application/json', 'User-Agent': 'HTTPie/1.0.0', 'Accept': 'application/json', 'Cookie': 'a=b'})

# Generated at 2022-06-17 21:07:54.398447
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test.json'))
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:07:59.720957
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:03.548227
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:13.323685
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test.json')
    session.update_headers({'Content-Type': 'application/json'})
    assert 'Content-Type' not in session['headers']
    session.update_headers({'User-Agent': 'HTTPie/1.0.0'})
    assert 'User-Agent' not in session['headers']
    session.update_headers({'User-Agent': 'curl/7.54.0'})
    assert 'User-Agent' in session['headers']
    session.update_headers({'Cookie': 'foo=bar'})
    assert 'foo' in session['cookies']
    assert session['cookies']['foo']['value'] == 'bar'
    session.update_headers({'Cookie': 'foo=baz'})

# Generated at 2022-06-17 21:08:17.228378
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:20.396368
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:23.241956
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:08:31.164640
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {
        'cookie1': {'value': 'value1'},
        'cookie2': {'value': 'value2'},
        'cookie3': {'value': 'value3'},
    }
    session.remove_cookies(['cookie2', 'cookie3'])
    assert session['cookies'] == {
        'cookie1': {'value': 'value1'},
    }

# Generated at 2022-06-17 21:08:35.046683
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': '1', 'b': '2', 'c': '3'}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': '3'}

# Generated at 2022-06-17 21:08:40.296099
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:58.466995
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:00.609402
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('')
    session['cookies'] = {'a': {}, 'b': {}, 'c': {}}
    session.remove_cookies(['b', 'c'])
    assert session['cookies'] == {'a': {}}

# Generated at 2022-06-17 21:09:05.452529
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:10.708516
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:15.690691
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:26.360284
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_Session_update_headers')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session.headers == {'Accept': '*/*'}
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})
    assert session.headers == {'Accept': '*/*'}
    assert session.cookies == RequestsCookieJar()
    session.cookies.set('foo', 'bar')

# Generated at 2022-06-17 21:09:36.400862
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session.headers == {'Accept': '*/*'}
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})
    assert session.headers == {'Accept': '*/*'}
    assert session.cookies == RequestsCookieJar([
        create_cookie('foo', 'bar'),
        create_cookie('baz', 'qux'),
    ])

# Generated at 2022-06-17 21:09:41.913577
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp/test_session.json'))
    session.update_headers(request_headers={'Content-Type': 'application/json', 'Content-Length': '0', 'Cookie': 'test=test'})
    assert session.headers == {'Content-Type': 'application/json', 'Content-Length': '0'}
    assert session.cookies == {'test': 'test'}

# Generated at 2022-06-17 21:09:48.265858
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp/test.json'))
    session.update_headers(request_headers={'Content-Type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers(request_headers={'User-Agent': 'HTTPie/0.9.9'})
    assert session['headers'] == {}
    session.update_headers(request_headers={'User-Agent': 'HTTPie/1.0.0'})
    assert session['headers'] == {'User-Agent': 'HTTPie/1.0.0'}
    session.update_headers(request_headers={'Accept': 'application/json'})
    assert session['headers'] == {'User-Agent': 'HTTPie/1.0.0', 'Accept': 'application/json'}
    session.update_

# Generated at 2022-06-17 21:09:55.936898
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test_Session_update_headers.json')
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.2'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.2', 'Accept': '*/*'})
    assert session['headers'] == {'Accept': '*/*'}
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})
    assert session['cookies'] == {'foo': {'value': 'bar'}, 'baz': {'value': 'qux'}}

# Generated at 2022-06-17 21:10:28.312574
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'foo': {'value': 'bar'}, 'baz': {'value': 'qux'}}
    session.remove_cookies(['foo'])
    assert session['cookies'] == {'baz': {'value': 'qux'}}

# Generated at 2022-06-17 21:10:32.268986
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-17 21:10:34.941888
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:10:40.180999
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test_Session_remove_cookies.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}
    session.remove_cookies(['b'])
    assert session['cookies'] == {}
    session.remove_cookies(['c'])
    assert session['cookies'] == {}


# Generated at 2022-06-17 21:10:45.193046
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:49.154973
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:10:56.946253
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test_Session_remove_cookies.json'))
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:11:01.731567
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {
        'cookie1': {'value': 'value1'},
        'cookie2': {'value': 'value2'},
        'cookie3': {'value': 'value3'},
    }
    session.remove_cookies(['cookie1', 'cookie3'])
    assert session['cookies'] == {
        'cookie2': {'value': 'value2'},
    }

# Generated at 2022-06-17 21:11:07.296889
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:11:11.023762
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:12:04.281413
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:12:09.673425
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:12:13.007897
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:12:16.297190
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:12:20.612834
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_session.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:12:24.948328
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:12:28.022088
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test.json'))
    session['cookies'] = {'a': 1, 'b': 2}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:12:30.617816
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:12:36.371480
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:12:41.135864
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:14:39.327709
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'a': {'value': 'b'}, 'c': {'value': 'd'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': {'value': 'd'}}

# Generated at 2022-06-17 21:14:45.662029
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:14:48.625015
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:14:56.685883
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test.json')
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:15:00.741547
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(''))
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:15:05.121976
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:15:07.235345
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:15:11.725125
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:15:15.967721
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/test_Session_remove_cookies')
    s['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:15:19.166024
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}