

# Generated at 2022-06-17 21:06:45.758399
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp/test.json'))
    session.update_headers(RequestHeadersDict({'Content-Type': 'application/json'}))
    assert session.headers == {}
    session.update_headers(RequestHeadersDict({'Accept': 'application/json'}))
    assert session.headers == {'Accept': 'application/json'}
    session.update_headers(RequestHeadersDict({'Accept': 'application/json'}))
    assert session.headers == {'Accept': 'application/json'}
    session.update_headers(RequestHeadersDict({'Accept': 'text/html'}))
    assert session.headers == {'Accept': 'text/html'}
    session.update_headers(RequestHeadersDict({'Accept': 'text/html'}))


# Generated at 2022-06-17 21:06:53.296526
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session.headers == {'Accept': '*/*'}
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})
    assert session.headers == {'Accept': '*/*'}
    assert session.cookies == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-17 21:06:56.181181
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test.json')
    session.update_headers({'Cookie': 'a=b; c=d'})
    assert session['cookies'] == {'a': {'value': 'b'}, 'c': {'value': 'd'}}
    assert session['headers'] == {}

# Generated at 2022-06-17 21:07:01.770229
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test_session.json'))
    session.load()
    session.remove_cookies(['cookie1', 'cookie2'])
    assert session['cookies'] == {'cookie3': {'value': 'value3'}}

# Generated at 2022-06-17 21:07:08.081208
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('./test_session.json'))
    session.update_headers(request_headers={
        'Content-Type': 'application/json',
        'If-Match': '"abc"',
        'User-Agent': 'HTTPie/0.9.9',
        'Cookie': 'session=abc; csrftoken=def',
        'Accept': 'application/json'
    })
    assert session.headers == {
        'Accept': 'application/json'
    }
    assert session.cookies == {
        'session': 'abc',
        'csrftoken': 'def'
    }

# Generated at 2022-06-17 21:07:13.258811
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}
    session.remove_cookies(['name2'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:07:21.283215
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp/test.json'))
    session.update_headers(RequestHeadersDict({'Content-Type': 'application/json'}))
    assert session.headers == {}
    session.update_headers(RequestHeadersDict({'Cookie': 'foo=bar;'}))
    assert session.headers == {}
    assert session['cookies'] == {'foo': {'value': 'bar'}}
    session.update_headers(RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9'}))
    assert session.headers == {}
    session.update_headers(RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'}))
    assert session.headers == {'Accept': '*/*'}

# Generated at 2022-06-17 21:07:26.600697
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('./test.json'))
    session.update_headers(request_headers={'Content-Type': 'application/json', 'Cookie': 'name=value'})
    assert session['headers'] == {'Content-Type': 'application/json'}
    assert session['cookies'] == {'name': {'value': 'value'}}

# Generated at 2022-06-17 21:07:35.814020
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session.headers == {'Accept': '*/*'}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*', 'Cookie': 'foo=bar'})
    assert session.headers == {'Accept': '*/*'}
    assert session.cookies == RequestsCookieJar([create_cookie('foo', 'bar')])
    session.update_

# Generated at 2022-06-17 21:07:41.271732
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    from httpie.cli.dicts import RequestHeadersDict
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPNTLMAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyBasicAuth
    from httpie.plugins.builtin import HTTPProxyDigestAuth
    from httpie.plugins.builtin import HTTPProxyNTLMAuth
    from httpie.plugins.builtin import HTTPProxyPassAuth
    from httpie.plugins.builtin import HTTPProxyPassBasicAuth
    from httpie.plugins.builtin import HTTPProxyPassDig

# Generated at 2022-06-17 21:07:52.582076
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/test_Session_remove_cookies.json')
    s['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b': {'value': '2'}}
    s.remove_cookies(['b'])
    assert s['cookies'] == {}
    s.remove_cookies(['c'])
    assert s['cookies'] == {}

# Generated at 2022-06-17 21:07:58.770980
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:00.665968
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 'value2'}

# Generated at 2022-06-17 21:08:04.185668
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:08.084767
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:08:12.153560
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:17.494977
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:08:20.360693
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('./test_session.json')
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:08:24.003574
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:30.115779
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:43.499133
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:08:46.795286
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:49.613587
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:08:57.116365
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:59.551441
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path("test.json"))
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-17 21:09:01.513803
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:06.217525
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:10.615926
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(''))
    session['cookies'] = {'foo': 'bar', 'baz': 'qux'}
    session.remove_cookies(['foo'])
    assert session['cookies'] == {'baz': 'qux'}

# Generated at 2022-06-17 21:09:14.844735
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(''))
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:09:20.388869
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test.json'))
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:44.393495
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies')
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:48.311916
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:55.362633
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:58.881623
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:02.683702
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:10:06.146980
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:10:09.372697
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-17 21:10:13.117047
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 'value2'}

# Generated at 2022-06-17 21:10:18.248456
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:21.417309
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 'value2'}

# Generated at 2022-06-17 21:11:01.147763
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test_Session_remove_cookies')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:11:06.586634
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:11:12.034429
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session("/tmp/test_Session_remove_cookies")
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}
    session.remove_cookies(['b'])
    assert session['cookies'] == {}
    session.remove_cookies(['c'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:11:16.935571
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:11:20.710472
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:11:24.791717
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:11:27.160126
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:11:30.092788
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:11:33.970142
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:11:37.566978
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:12:57.987796
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:12:59.808021
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:13:01.755917
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:13:09.901750
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}
    session.remove_cookies(['cookie3'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:13:13.865131
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:13:20.394174
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:13:25.415680
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:13:29.868965
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:13:33.534238
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:13:36.493536
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': {'value': '2'}}