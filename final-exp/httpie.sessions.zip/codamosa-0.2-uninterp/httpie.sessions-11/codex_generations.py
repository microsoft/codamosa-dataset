

# Generated at 2022-06-17 21:06:57.834664
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp/test_session.json'))
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.2'})
    assert session.headers == {}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session.headers == {}
    session.update_headers({'Accept-Encoding': 'gzip, deflate'})
    assert session.headers == {'Accept-Encoding': 'gzip, deflate'}

# Generated at 2022-06-17 21:07:03.307568
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test_session.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:07:10.066093
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp/test_Session_update_headers.json'))
    session.update_headers(RequestHeadersDict({
        'Content-Type': 'application/json',
        'Content-Length': '0',
        'If-Match': '"etag"',
        'Cookie': 'foo=bar; baz=qux',
        'User-Agent': 'HTTPie/0.9.9',
        'X-Custom': 'foo',
        'X-Custom-2': 'bar',
    }))
    assert session.headers == RequestHeadersDict({
        'X-Custom': 'foo',
        'X-Custom-2': 'bar',
    })

# Generated at 2022-06-17 21:07:14.168652
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_session.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:07:20.169569
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers(RequestHeadersDict({'Content-Type': 'application/json'}))
    assert 'Content-Type' not in session.headers
    session.update_headers(RequestHeadersDict({'Cookie': 'a=b'}))
    assert 'a' in session.cookies
    assert session.cookies['a'].value == 'b'
    session.update_headers(RequestHeadersDict({'User-Agent': 'HTTPie/0.9.9'}))
    assert 'User-Agent' not in session.headers
    session.update_headers(RequestHeadersDict({'User-Agent': 'HTTPie/0.9.8'}))
    assert 'User-Agent' in session.headers

# Generated at 2022-06-17 21:07:25.983578
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:07:35.380191
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.2'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.2', 'Accept': '*/*'})
    assert session['headers'] == {'Accept': '*/*'}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session['cookies'] == {'foo': {'value': 'bar'}}
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})

# Generated at 2022-06-17 21:07:42.569930
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session.headers == {'Accept': '*/*'}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*', 'Cookie': 'foo=bar'})
    assert session.headers == {'Accept': '*/*'}
    assert session.cookies == RequestsCookieJar([create_cookie('foo', 'bar')])

# Generated at 2022-06-17 21:07:52.365063
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test.json')
    session.update_headers({'Accept': 'application/json'})
    assert session.headers['Accept'] == 'application/json'
    session.update_headers({'Accept': 'text/html'})
    assert session.headers['Accept'] == 'text/html'
    session.update_headers({'Accept': None})
    assert 'Accept' not in session.headers
    session.update_headers({'Content-Type': 'application/json'})
    assert 'Content-Type' not in session.headers
    session.update_headers({'If-Match': '"123"'})
    assert 'If-Match' not in session.headers
    session.update_headers({'Cookie': 'foo=bar'})
    assert 'Cookie' not in session.headers
    assert session.cook

# Generated at 2022-06-17 21:07:54.876189
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test_Session_remove_cookies.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:07.952689
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:08:12.360087
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test_session.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:15.728786
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:08:20.754279
# Unit test for constructor of class Session
def test_Session():
    session = Session('/home/user/.config/httpie/sessions/localhost/test.json')
    assert session.path == Path('/home/user/.config/httpie/sessions/localhost/test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-17 21:08:23.290003
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:08:33.082879
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test.json')
    session.update_headers({
        'Content-Type': 'application/json',
        'If-Match': '"abc123"',
        'User-Agent': 'HTTPie/1.0.0',
        'Cookie': 'foo=bar; baz=qux',
    })
    assert session.headers == {
        'Content-Type': 'application/json',
        'If-Match': '"abc123"',
        'User-Agent': 'HTTPie/1.0.0',
    }
    assert session.cookies == RequestsCookieJar([
        create_cookie('foo', 'bar'),
        create_cookie('baz', 'qux'),
    ])

# Generated at 2022-06-17 21:08:42.341296
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager

# Generated at 2022-06-17 21:08:45.465645
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'test', 'http://localhost', 'http://localhost')
    assert session.path == DEFAULT_CONFIG_DIR / SESSIONS_DIR_NAME / 'localhost' / 'test.json'

# Generated at 2022-06-17 21:08:50.154179
# Unit test for constructor of class Session
def test_Session():
    session = Session('/home/user/.config/httpie/sessions/localhost/test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-17 21:08:59.017909
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path(__file__).parent
    session_name = 'test_session'
    host = 'httpbin.org'
    url = 'http://httpbin.org/get'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.path == Path(__file__).parent / SESSIONS_DIR_NAME / 'httpbin_org' / 'test_session.json'

# Generated at 2022-06-17 21:09:13.961029
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'Cookie': 'a=b'})
    assert session.cookies == {'a': 'b'}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session.headers == {'Accept': '*/*'}

# Generated at 2022-06-17 21:09:19.506255
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test_session.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:24.402227
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:27.411887
# Unit test for constructor of class Session
def test_Session():
    session = Session('/tmp/test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-17 21:09:30.368680
# Unit test for constructor of class Session
def test_Session():
    session = Session("test.json")
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-17 21:09:39.860554
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp/test.json'))
    session.update_headers(request_headers={
        'Content-Type': 'application/json',
        'If-Match': '"123"',
        'User-Agent': 'HTTPie/1.0.2',
        'Cookie': 'foo=bar; baz=qux',
    })
    assert session.headers == {
        'Content-Type': 'application/json',
        'If-Match': '"123"',
        'User-Agent': 'HTTPie/1.0.2',
    }
    assert session.cookies == {
        'foo': 'bar',
        'baz': 'qux',
    }

# Generated at 2022-06-17 21:09:43.120540
# Unit test for constructor of class Session
def test_Session():
    session = Session('/tmp/test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-17 21:09:47.552628
# Unit test for constructor of class Session
def test_Session():
    session = Session(path=Path('/home/user/.config/httpie/sessions/localhost/session.json'))
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-17 21:10:00.613194
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp/test.json'))
    session.update_headers(RequestHeadersDict({
        'Content-Type': 'application/json',
        'If-Match': '"abc"',
        'Cookie': 'a=b; c=d',
        'User-Agent': 'HTTPie/0.9.9',
        'X-Custom': 'foo',
        'X-Custom-2': 'bar'
    }))
    assert session['headers'] == {
        'X-Custom': 'foo',
        'X-Custom-2': 'bar'
    }
    assert session['cookies'] == {
        'a': {'value': 'b'},
        'c': {'value': 'd'}
    }

# Generated at 2022-06-17 21:10:04.935036
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:21.045162
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:10:25.333018
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('./test.json'))
    session.update_headers({'Content-Type': 'application/json', 'Cookie': 'name=value'})
    assert session['headers'] == {'Content-Type': 'application/json'}
    assert session['cookies'] == {'name': {'value': 'value'}}


# Generated at 2022-06-17 21:10:35.117358
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.plugins import builtin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.manager import PluginManager
    from httpie.plugins import builtin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins import builtin
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.manager import PluginManager
    from httpie.plugins import builtin
    from httpie.plugins.builtin import HTTPBasicAuth

# Generated at 2022-06-17 21:10:36.548973
# Unit test for function get_httpie_session
def test_get_httpie_session():
    assert get_httpie_session(DEFAULT_SESSIONS_DIR, 'test', '', '')

# Generated at 2022-06-17 21:10:47.811956
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('./test.json'))
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.2'})
    assert session.headers == {}
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})
    assert session.headers == {}
    session.update_headers({'Accept': 'application/json'})
    assert session.headers == {'Accept': 'application/json'}
    session.update_headers({'Accept': 'application/json'})
    assert session.headers == {'Accept': 'application/json'}
    session.update_headers({'Accept': 'text/html'})

# Generated at 2022-06-17 21:10:53.030178
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path(''))
    session.update_headers(RequestHeadersDict({'Content-Type': 'application/json', 'Accept': 'application/json'}))
    assert session.headers == {'Accept': 'application/json'}

# Generated at 2022-06-17 21:10:54.946242
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:10:57.548956
# Unit test for constructor of class Session
def test_Session():
    session = Session('/home/user/.config/httpie/sessions/localhost/test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-17 21:10:59.734451
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('./')
    session_name = 'test'
    host = 'http://www.baidu.com'
    url = 'http://www.baidu.com'
    session = get_httpie_session(config_dir, session_name, host, url)
    print(session)

# Generated at 2022-06-17 21:11:08.724460
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp/test.json'))
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.2'})
    assert session.headers == {}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session.headers == {}
    session.update_headers({'Accept': 'application/json'})
    assert session.headers == {'Accept': 'application/json'}

# Generated at 2022-06-17 21:11:37.526730
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:11:41.223481
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test_session.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:11:45.429353
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:11:50.657087
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/home/user/.config')
    session_name = 'test'
    host = 'httpbin.org'
    url = 'https://httpbin.org/get'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.path == Path('/home/user/.config/sessions/httpbin_org/test.json')

# Generated at 2022-06-17 21:12:02.249524
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers({'Content-Type': 'application/json', 'User-Agent': 'HTTPie/1.0.2'})
    assert session['headers'] == {'User-Agent': 'HTTPie/1.0.2'}
    session.update_headers({'Content-Type': 'application/json', 'User-Agent': 'HTTPie/1.0.2', 'Cookie': 'a=b'})
    assert session['headers'] == {'User-Agent': 'HTTPie/1.0.2'}
    assert session['cookies'] == {'a': {'value': 'b'}}

# Generated at 2022-06-17 21:12:06.865399
# Unit test for constructor of class Session
def test_Session():
    session = Session(path='/home/httpie/sessions/test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-17 21:12:11.441456
# Unit test for function get_httpie_session
def test_get_httpie_session():
    config_dir = Path('/home/user/.config')
    session_name = 'session_name'
    host = 'host'
    url = 'http://host/path'
    session = get_httpie_session(config_dir, session_name, host, url)
    assert session.path == Path('/home/user/.config/sessions/host/session_name.json')

# Generated at 2022-06-17 21:12:18.793409
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.2'})
    assert session['headers'] == {}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session['cookies'] == {'foo': {'value': 'bar'}}
    session.update_headers({'Accept': 'application/json'})
    assert session['headers'] == {'Accept': 'application/json'}
    session.update_headers({'Accept': 'application/xml'})
    assert session['headers'] == {'Accept': 'application/xml'}

# Generated at 2022-06-17 21:12:23.269719
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:12:27.188953
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:13:26.649542
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': '2'}
    session.remove_cookies(['b'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:13:31.459632
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:13:34.399561
# Unit test for constructor of class Session
def test_Session():
    session = Session('/tmp/test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-17 21:13:37.017315
# Unit test for constructor of class Session
def test_Session():
    session = Session('/tmp/test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
        'type': None,
        'username': None,
        'password': None
    }


# Generated at 2022-06-17 21:13:39.487746
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:13:45.225385
# Unit test for function get_httpie_session
def test_get_httpie_session():
    from httpie.config import Config
    config = Config()
    config.config_dir = Path('/home/user/.config/httpie')
    session = get_httpie_session(config.config_dir, 'test', 'example.com', 'https://example.com/')
    assert session.path == Path('/home/user/.config/httpie/sessions/example_com/test.json')
    assert session.headers == {}
    assert session.cookies == RequestsCookieJar()
    assert session.auth == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-17 21:13:53.166381
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session.headers == {'Accept': '*/*'}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session.headers == {'Accept': '*/*'}
    assert session.cookies == {'foo': 'bar'}
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})

# Generated at 2022-06-17 21:13:55.881290
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:14:01.052601
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:14:03.480188
# Unit test for function get_httpie_session
def test_get_httpie_session():
    session = get_httpie_session(DEFAULT_CONFIG_DIR, 'test_session', '', '')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {'type': None, 'username': None, 'password': None}

# Generated at 2022-06-17 21:16:24.503168
# Unit test for constructor of class Session
def test_Session():
    s = Session('/tmp/test.json')
    assert s['headers'] == {}
    assert s['cookies'] == {}
    assert s['auth'] == {'type': None, 'username': None, 'password': None}


# Generated at 2022-06-17 21:16:29.147096
# Unit test for constructor of class Session
def test_Session():
    session = Session('test.json')
    assert session['headers'] == {}
    assert session['cookies'] == {}
    assert session['auth'] == {
            'type': None,
            'username': None,
            'password': None
        }


# Generated at 2022-06-17 21:16:33.382943
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='/tmp/test_Session_update_headers.json')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session.headers == {'Accept': '*/*'}
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})
    assert session.headers == {'Accept': '*/*'}
    assert session.cookies == RequestsCookieJar()