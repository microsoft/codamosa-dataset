

# Generated at 2022-06-17 21:06:47.957877
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:06:55.594455
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='/tmp/test.json')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'Accept': 'application/json'})
    assert session.headers == {'Accept': 'application/json'}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session.headers == {'Accept': 'application/json'}
    assert session['cookies'] == {'foo': {'value': 'bar'}}
    session.update_headers({'Cookie': 'baz=qux'})

# Generated at 2022-06-17 21:07:06.467955
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test.json')
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session['headers'] == {}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session['cookies'] == {'foo': {'value': 'bar'}}
    session.update_headers({'Accept': 'application/json'})
    assert session['headers'] == {'Accept': 'application/json'}
    session.update_headers({'Accept': 'application/xml'})
    assert session['headers'] == {'Accept': 'application/xml'}
    session.update_headers({'If-Match': '*'})

# Generated at 2022-06-17 21:07:10.875557
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='/tmp/test_session.json')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.0'})
    assert session.headers == {}
    session.update_headers({'Accept': 'application/json'})
    assert session.headers == {'Accept': 'application/json'}
    session.update_headers({'Accept': 'text/html'})
    assert session.headers == {'Accept': 'text/html'}
    session.update_headers({'Accept': None})
    assert session.headers == {}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session.headers == {}

# Generated at 2022-06-17 21:07:19.581703
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=None)
    session.update_headers(request_headers={'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers(request_headers={'Accept': 'application/json'})
    assert session.headers == {'Accept': 'application/json'}
    session.update_headers(request_headers={'Accept': 'text/html'})
    assert session.headers == {'Accept': 'text/html'}
    session.update_headers(request_headers={'Accept': None})
    assert session.headers == {}
    session.update_headers(request_headers={'Cookie': 'foo=bar'})
    assert session.headers == {}
    assert session['cookies'] == {'foo': {'value': 'bar'}}
    session.update_headers

# Generated at 2022-06-17 21:07:25.460786
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:07:34.966688
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path(""))
    session.update_headers(RequestHeadersDict({"Content-Type": "application/json", "If-Match": "*"}))
    assert session.headers == {}
    session.update_headers(RequestHeadersDict({"Content-Type": "application/json", "If-Match": "*", "User-Agent": "HTTPie/1.0.3"}))
    assert session.headers == {}
    session.update_headers(RequestHeadersDict({"Content-Type": "application/json", "If-Match": "*", "User-Agent": "HTTPie/1.0.3", "Cookie": "foo=bar"}))
    assert session.headers == {}

# Generated at 2022-06-17 21:07:39.259824
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:07:44.245728
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'Content-Type': 'application/json', 'Cookie': 'key=value'})
    assert session['headers'] == {'Content-Type': 'application/json'}
    assert session['cookies'] == {'key': {'value': 'value'}}

# Generated at 2022-06-17 21:07:48.846674
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:03.602680
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:07.412808
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-17 21:08:11.163798
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(''))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:13.803335
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:20.754133
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {
        'name1': {'value': 'value1'},
        'name2': {'value': 'value2'},
        'name3': {'value': 'value3'},
    }
    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:24.942665
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:30.106227
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:32.974922
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-17 21:08:36.104695
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:41.100936
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:06.539193
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_session.json')
    session['cookies'] = {'a': {'value': 'a'}, 'b': {'value': 'b'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': 'b'}}

# Generated at 2022-06-17 21:09:11.948747
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:13.773042
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:18.534205
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:23.432740
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:26.993640
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'foo': 'bar', 'baz': 'qux'}
    session.remove_cookies(['foo', 'qux'])
    assert session['cookies'] == {'baz': 'qux'}

# Generated at 2022-06-17 21:09:30.682276
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:41.444571
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test_Session_remove_cookies.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}
    session.remove_cookies(['cookie3'])
    assert session['cookies'] == {}
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1', 'cookie2'])
   

# Generated at 2022-06-17 21:09:44.043845
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:09:48.022649
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:10:33.546987
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': 'a'}, 'b': {'value': 'b'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': 'b'}}

# Generated at 2022-06-17 21:10:36.230762
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:10:38.979167
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:44.755170
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:10:48.253226
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:53.679346
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-17 21:10:57.922559
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'test': {'value': 'test'}}
    session.remove_cookies(['test'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:11:01.277978
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test_session.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:11:06.902134
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path = 'test')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:11:10.339909
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:12:39.815190
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:12:43.971386
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path("/tmp/test.json"))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:12:46.976618
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:12:51.908180
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:12:57.303038
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:13:00.993955
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}


# Generated at 2022-06-17 21:13:07.571900
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': {'value': 1}, 'b': {'value': 2}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': 2}}

# Generated at 2022-06-17 21:13:11.471558
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:13:15.322831
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:13:20.394084
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}