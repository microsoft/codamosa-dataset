

# Generated at 2022-06-17 21:06:38.541805
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'foo': 'bar', 'baz': 'qux'}
    session.remove_cookies(['foo', 'baz'])
    assert session['cookies'] == {}


# Generated at 2022-06-17 21:06:45.972939
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_Session_update_headers')
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.2'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.2', 'Accept': '*/*'})
    assert session['headers'] == {'Accept': '*/*'}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session['cookies'] == {'foo': {'value': 'bar'}}
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})

# Generated at 2022-06-17 21:06:54.015832
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.0'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/1.0.0', 'Accept': '*/*'})
    assert session['headers'] == {'Accept': '*/*'}
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})
    assert session['cookies'] == {'foo': {'value': 'bar'}, 'baz': {'value': 'qux'}}
    session.update_headers({'Cookie': 'foo=baz'})

# Generated at 2022-06-17 21:07:04.305995
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session['headers'] == {'Accept': '*/*'}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*', 'Content-Type': 'application/json'})
    assert session['headers'] == {'Accept': '*/*', 'Content-Type': 'application/json'}

# Generated at 2022-06-17 21:07:15.956960
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session['cookies'] == {'foo': {'value': 'bar'}}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session['headers'] == {}
    session.update_headers({'Accept': 'application/json'})
    assert session['headers'] == {'Accept': 'application/json'}
    session.update_headers({'If-Match': '*'})
    assert session['headers'] == {'Accept': 'application/json'}
    session.update_headers({'Content-Type': 'application/json'})

# Generated at 2022-06-17 21:07:22.965875
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test_session')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'Accept': 'application/json'})
    assert session.headers == {'Accept': 'application/json'}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session.headers == {'Accept': 'application/json'}
    assert session.cookies == RequestsCookieJar([create_cookie('foo', 'bar')])
    session.update_headers({'Cookie': 'foo=baz'})
    assert session.headers == {'Accept': 'application/json'}
   

# Generated at 2022-06-17 21:07:27.626436
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:07:31.714303
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test_session.json')
    session.update_headers({'Content-Type': 'application/json', 'Cookie': 'a=b'})
    assert session.headers == {'Content-Type': 'application/json'}
    assert session.cookies == {'a': 'b'}

# Generated at 2022-06-17 21:07:33.685241
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='/tmp/test_Session_update_headers.json')
    session.update_headers(RequestHeadersDict({'Content-Type': 'application/json', 'User-Agent': 'HTTPie/0.9.9'}))
    assert session.headers == RequestHeadersDict({'Content-Type': 'application/json'})

# Generated at 2022-06-17 21:07:35.601906
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:07:48.012441
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 'd'}
    session.remove_cookies(['c'])
    assert session['cookies'] == {}
    session.remove_cookies(['c'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:07:54.907441
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path = 'test.json')
    s['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:01.704887
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:04.481754
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('session.json')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:08:10.741006
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'},
                          'cookie2': {'value': 'value2'},
                          'cookie3': {'value': 'value3'}}
    session.remove_cookies(['cookie1', 'cookie3'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:14.453563
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:08:17.566797
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_Session_remove_cookies')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:08:21.005484
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:08:23.497307
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s['cookies'] = {'a': 1, 'b': 2}
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:08:28.556035
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:08:40.745774
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:44.338824
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test_Session_remove_cookies')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:08:47.427285
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:08:54.032605
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:08:59.939779
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:03.451136
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:08.604033
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:13.253995
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:17.772181
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:24.973646
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}
    session.remove_cookies(['cookie3'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:09:43.194334
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:09:46.186384
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:09:49.808164
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:10:01.418310
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(''))
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}
    session.remove_cookies(['name2'])
    assert session['cookies'] == {}
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1', 'name2'])
    assert session['cookies'] == {}
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1', 'name3'])

# Generated at 2022-06-17 21:10:05.772330
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:10:09.294179
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:11.710792
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:10:17.526838
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:10:20.496475
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:10:23.382200
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:10:56.240390
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:58.515146
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:11:04.490367
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:11:08.646549
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:11:11.882778
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:11:17.184025
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': '1', 'b': '2', 'c': '3'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:11:21.019254
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:11:24.222610
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test_Session_remove_cookies.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:11:28.364055
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('path')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:11:32.607380
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:12:37.924930
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:12:44.144216
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_session')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}
    session.remove_cookies(['name2'])
    assert session['cookies'] == {}
    session.remove_cookies(['name3'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:12:45.964500
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:12:48.758601
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test_Session_remove_cookies.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:12:54.215583
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(''))
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:13:00.166656
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:13:07.731931
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:13:11.935336
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test_session.json'))
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:13:15.956778
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:13:20.686468
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session.update_headers({'Cookie': 'a=1; b=2; c=3'})
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': {'value': '3'}}

# Generated at 2022-06-17 21:15:59.620515
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:16:04.616360
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:16:07.962759
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:16:12.063634
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:16:14.046112
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'a': {'value': 'a'}, 'b': {'value': 'b'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': 'b'}}

# Generated at 2022-06-17 21:16:18.862044
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:16:21.103775
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test_session.json'))
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:16:25.572127
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1', 'name3'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:16:31.170449
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path("test_session.json"))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}