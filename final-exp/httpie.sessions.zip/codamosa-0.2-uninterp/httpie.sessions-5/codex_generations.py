

# Generated at 2022-06-17 21:06:46.559374
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:06:50.334396
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='/tmp/test.json')
    session.update_headers(request_headers={'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers(request_headers={'Accept': 'application/json'})
    assert session.headers == {'Accept': 'application/json'}

# Generated at 2022-06-17 21:06:53.190423
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 'value2'}

# Generated at 2022-06-17 21:06:58.122160
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': 'a'}, 'b': {'value': 'b'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': 'b'}}

# Generated at 2022-06-17 21:07:02.770075
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path='test')
    session.update_headers(request_headers={'Content-Type': 'application/json', 'Cookie': 'session=12345'})
    assert session.headers == {'Content-Type': 'application/json'}
    assert session.cookies == {'session': '12345'}

# Generated at 2022-06-17 21:07:06.357676
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:07:16.628220
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('/tmp/test_Session_update_headers.json')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session.headers == {'Accept': '*/*'}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session.headers == {'Accept': '*/*'}
    assert session.cookies == RequestsCookieJar([create_cookie('foo', 'bar')])

# Generated at 2022-06-17 21:07:26.904530
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session('test')
    session.update_headers({'Content-Type': 'application/json'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session.headers == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session.headers == {'Accept': '*/*'}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session.headers == {'Accept': '*/*'}
    assert session.cookies == RequestsCookieJar()
    session.update_headers({'Cookie': 'foo=bar', 'Accept': '*/*'})

# Generated at 2022-06-17 21:07:35.915328
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path(''))
    session.update_headers({'Content-Type': 'application/json'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9'})
    assert session['headers'] == {}
    session.update_headers({'User-Agent': 'HTTPie/0.9.9', 'Accept': '*/*'})
    assert session['headers'] == {'Accept': '*/*'}
    session.update_headers({'Cookie': 'foo=bar'})
    assert session['cookies'] == {'foo': {'value': 'bar'}}
    session.update_headers({'Cookie': 'foo=bar; baz=qux'})

# Generated at 2022-06-17 21:07:40.034068
# Unit test for method update_headers of class Session
def test_Session_update_headers():
    session = Session(path=Path('/tmp/test_Session_update_headers.json'))
    session.load()
    session.update_headers({'Content-Type': 'application/json', 'Cookie': 'test=test'})
    assert session['headers'] == {'Content-Type': 'application/json'}
    assert session['cookies'] == {'test': {'value': 'test'}}

# Generated at 2022-06-17 21:07:49.955413
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test_session.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:07:57.941497
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:03.335959
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:07.101120
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:08:10.178274
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:08:13.151998
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': 2}

# Generated at 2022-06-17 21:08:17.381680
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:21.773189
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:29.194282
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:08:34.111458
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie2'])
    assert session['cookies'] == {}

# Generated at 2022-06-17 21:08:46.041476
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test.json'))
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:08:49.830347
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 'value2'}

# Generated at 2022-06-17 21:08:56.001572
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:09:01.115695
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:06.575104
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_session.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:11.947923
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:15.148650
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': '1', 'b': '2'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:09:19.969601
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:24.848427
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:09:28.285805
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:09:46.443018
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:09:49.160079
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-17 21:09:55.068429
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:10:00.184324
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:04.106709
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:08.184826
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:11.202904
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:16.349315
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:20.373631
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'name1': {'value': 'value1'}, 'name2': {'value': 'value2'}}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': {'value': 'value2'}}

# Generated at 2022-06-17 21:10:24.038491
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test.json')
    session['cookies'] = {'key1': 'value1', 'key2': 'value2'}
    session.remove_cookies(['key1'])
    assert session['cookies'] == {'key2': 'value2'}

# Generated at 2022-06-17 21:10:56.376406
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test_session.json'))
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:10:58.895621
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:11:04.401103
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    session.remove_cookies(['a', 'b'])
    assert session['cookies'] == {'c': 3}

# Generated at 2022-06-17 21:11:08.565974
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:11:11.547975
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(''))
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:11:16.888156
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test.json')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:11:20.673939
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path(''))
    session['cookies'] = {'a': '1', 'b': '2', 'c': '3'}
    session.remove_cookies(['a', 'c'])
    assert session['cookies'] == {'b': '2'}

# Generated at 2022-06-17 21:11:23.284256
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test_session.json'))
    session.load()
    session.remove_cookies(['test_cookie'])
    assert 'test_cookie' not in session['cookies']

# Generated at 2022-06-17 21:11:29.199820
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:11:32.945686
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('/tmp/test.json')
    s['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:12:39.911804
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:12:45.952986
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session(path=Path('/tmp/test_Session_remove_cookies.json'))
    s['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    s.remove_cookies(['a'])
    assert s['cookies'] == {'b': {'value': '2'}}
    s.remove_cookies(['b'])
    assert s['cookies'] == {}
    s.remove_cookies(['c'])
    assert s['cookies'] == {}

# Generated at 2022-06-17 21:12:52.230608
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:12:58.658166
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('/tmp/test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:13:01.199312
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:13:07.895990
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:13:11.778808
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='/tmp/test.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:13:16.077576
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session')
    session['cookies'] = {'name1': 'value1', 'name2': 'value2'}
    session.remove_cookies(['name1'])
    assert session['cookies'] == {'name2': 'value2'}

# Generated at 2022-06-17 21:13:20.686970
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path='test')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:13:25.454340
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:16:06.368122
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:16:09.132454
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': 'value1', 'cookie2': 'value2'}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': 'value2'}

# Generated at 2022-06-17 21:16:12.062970
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test_session.json')
    session['cookies'] = {'cookie1': {'value': 'value1'}, 'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:16:16.662167
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'a': 'b', 'c': 'd'}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'c': 'd'}

# Generated at 2022-06-17 21:16:18.883505
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session(path=Path('./test.json'))
    session['cookies'] = {'cookie1': {'value': 'value1'},
                          'cookie2': {'value': 'value2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'value2'}}

# Generated at 2022-06-17 21:16:20.931379
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('/tmp/test_Session_remove_cookies.json')
    session['cookies'] = {'a': {'value': '1'}, 'b': {'value': '2'}}
    session.remove_cookies(['a'])
    assert session['cookies'] == {'b': {'value': '2'}}

# Generated at 2022-06-17 21:16:24.127123
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    s = Session('test')
    s['cookies'] = {'a': 1, 'b': 2, 'c': 3}
    s.remove_cookies(['a', 'b'])
    assert s['cookies'] == {'c': 3}

# Generated at 2022-06-17 21:16:30.215065
# Unit test for method remove_cookies of class Session
def test_Session_remove_cookies():
    session = Session('test')
    session['cookies'] = {'cookie1': {'value': 'val1'}, 'cookie2': {'value': 'val2'}}
    session.remove_cookies(['cookie1'])
    assert session['cookies'] == {'cookie2': {'value': 'val2'}}