

# Generated at 2022-06-22 09:01:04.946899
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    src = '''function test(b){var c=function(a){return function(){return a}};c(b+1)}'''
    js = JSInterpreter(src)
    f = js.build_function(['b'], 'var c=function(a){return function(){return a}};c(b+1)')
    assert f((1,)) == 1
    assert f((2,)) == 2

# Generated at 2022-06-22 09:01:14.855284
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('')

    # test for method interpret_expression
    assert interpreter.interpret_expression('5') == 5
    assert interpreter.interpret_expression('2+3') == 5
    assert interpreter.interpret_expression('true') == True
    assert interpreter.interpret_expression('false') == False
    assert interpreter.interpret_expression('null') == None
    assert interpreter.interpret_expression('"hello world"') == "hello world"
    assert interpreter.interpret_expression('[1,2,3]') == [1, 2, 3]
    assert interpreter.interpret_expression('{1:"hello",2:"world"}') == {1: "hello", 2: "world"}

    # test for method interpret_statement
    assert interpreter.interpret_statement('var a = 1+2')[0] == 3
    assert interpreter.interpret_statement

# Generated at 2022-06-22 09:01:24.648874
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    assert (JSInterpreter.interpret_statement(self, "var a = b + c - d * e / f % g >> h << i", {"b":1,"c":2,"d":3,"e":4,"f":5,"g":6,"h":7,"i":8}) == ((2 - 3 * 4 / 5 % 6 >> 7 << 8), False))
    assert (JSInterpreter.interpret_statement(self, "var a = b | c ^ d & e", {"b":1,"c":2,"d":3,"e":4}) == ((1 | 2) ^ 3 & 4, False))

# Generated at 2022-06-22 09:01:30.223800
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('function b(a,d){"use strict";var c=a[0];a[0]=a[1];a[1]=c}')
    func = js.extract_function('b')
    assert func((234, 789)) == (789, 234)

# Generated at 2022-06-22 09:01:40.698618
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_interpreter = JSInterpreter(
        '''
            function test(a, b) {
                return a + b;
            }
        ''',
        {}
    )
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-22 09:01:50.137488
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        var a = 10;
        var b = 20;
        var c = a*b+a**b/b;
        return c;
    '''
    interpreter = JSInterpreter(code)

    assert interpreter.interpret_expression('a', {}) == 10
    assert interpreter.interpret_expression('b', {}) == 20
    assert interpreter.interpret_expression('a*b+a**b/b', {}) == 205
    assert interpreter.interpret_expression('a+b', {}) == 30
    assert interpreter.interpret_expression('c', {}) == 205
    assert interpreter.interpret_expression('c*2', {}) == 410
    assert interpreter.interpret_expression('a+b', {'c': 100}) == 30
    assert interpreter.interpret_expression('c%c/c', {}) == 0

# Generated at 2022-06-22 09:02:02.545548
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:02:15.487697
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    s = '''
    function test(a, b) {
        return a[0] + b[1];
    }
    function test2(a,b){
        return [
            a[0][0],
            a[1][1] + "test",
            b.test,
        ];
    }
    function test3(a,b){
        return {test: "test"};
    }
    '''

    i = JSInterpreter(s)
    test = i.extract_function('test')
    assert test([0, 1], [2, 3]) == 3
    test2 = i.extract_function('test2')
    assert test2([[0], [3]], {'test': 'test'}) == [0, '3test', 'test']
    test3 = i.extract

# Generated at 2022-06-22 09:02:24.061593
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter(None)
    
    resf = js_interpreter.build_function(['a','b'], 'var c = a+b; var d = c;')
    assert resf((1,2))==3
    resf = js_interpreter.build_function(['a'], 'c=a;')
    assert resf(('$a',))=='$a'
    resf = js_interpreter.build_function(['a'], 'c=a.join(\'\');')
    assert resf(([32,87,39,86,53],))=='2W\'V5'
    resf = js_interpreter.build_function(['a'], 'c=a.slice(1);')

# Generated at 2022-06-22 09:02:27.296118
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
        function func(a,b){
            return a+b;
        }

    """
    i = JSInterpreter(code)
    assert i.call_function("func",2,3) == 5

# Generated at 2022-06-22 09:03:15.713329
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = '''
    function f(a, b) {
        return a + b;
    }
    function g(a) {
        return a * a;
    }

    function h(a, b) {
        return g(a) + g(b);
    }

    var i = 1;
    var j = function(a, b) {
        return a * b;
    };
    var k = {
        a: '1',
        b: 2,
        c: function(a, b) {
            return a * b;
        },
        d: function(a) {
            return a;
        }
    };
    '''
    interpreter = JSInterpreter(js_code)
    assert interpreter.call_function('f', 4, 5) == 9
    assert interpreter.call

# Generated at 2022-06-22 09:03:27.950978
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    """Test the build_function method of the JSInterpreter class"""

    interpreter = JSInterpreter("")
 
    def check_build_function(funcname, args, code, expected_res):
        resf = interpreter.build_function(args, code)
        assert resf(expected_res) == expected_res

    check_build_function("f1", ("a", "b"), "return a + b", ("a", 2))

    check_build_function("f1", ("a", "b"), "return a + b + 1", ("a", 2))
    check_build_function("f2", ("a",), "return a + 1", ("a",))
    check_build_function("f3", ("a", "b"), "return a + b + 1", (1, 2))

# Generated at 2022-06-22 09:03:36.053117
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    """
    A unit test by passing function function name and arguments.

    """
    code = """
    function myFunction(a, b) {
        return a * b;
    }

    function myFunction2(a, b) {
        return a + b;
    }

    """
    interpreter = JSInterpreter(code)
    result = interpreter.call_function('myFunction', 2, 3)
    assert result == 6
    result = interpreter.call_function('myFunction2', 2, 3)
    assert result == 5



# Generated at 2022-06-22 09:03:47.760294
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = '''
        function w(a,b) {
            var c=a.length,d=c,e="";
            while(d--) {
                var f=a[d];
                if(f>="A"&&f<="Z"){f=String.fromCharCode((f.charCodeAt(0)-65+b)%26+65);}
                else if(f>="a"&&f<="z"){f=String.fromCharCode((f.charCodeAt(0)-97+b)%26+97);}
                e+=f;
            }
            return e;
        }
        '''

    my_js = JSInterpreter(js_code)
    assert my_js.extract_function('w')(['Secret', 13]) == 'Frperg'



# Generated at 2022-06-22 09:03:59.140927
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def test(expr, expected_output):
        assert (JSInterpreter("").interpret_expression(
            expr, {"a": "hello", "b": {"c": "world"}, "d": [1, 2, 3], "e": 1}) ==
            expected_output)
    test("a", "hello")
    test("a.split('')", ["h", "e", "l", "l", "o"])
    test("a[3]", "l")
    test("b.c", "world")
    test("b['c']", "world")
    test("b.c[0]", "w")
    test("a.concat(b.c)", "helloworld")
    test("b.c.concat(a)", "worldhello")

# Generated at 2022-06-22 09:04:06.442415
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
        var b = function() {return 1}
        ke = function(a) {
            return a;
        }'''
    js_interpreter = JSInterpreter(js_code)

    func = js_interpreter.build_function(['a'], 'return a;')
    assert func(('a',)) == 'a'

    func = js_interpr

# Generated at 2022-06-22 09:04:14.230534
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    """Build javascript functions with JSInterpreter.build_function."""
    interpreter = JSInterpreter('')

    # most basic function
    f = interpreter.build_function(
        ['a', 'b'],
        '(a + b)')
    assert f((1, 2)) == 3

    # simple example with assignment and function call
    f = interpreter.build_function(
        ['a'],
        'b = a + c; return d.reverse()')
    assert f(([1, 2, 3], 4, 5)) == [1, 2, 3]

    # test higher precedence of unary + and -
    f = interpreter.build_function(
        ['a'],
        'return +(-a)')
    assert f((1,)) == -1

    # test right-to-left associativity

# Generated at 2022-06-22 09:04:24.853463
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_test = """
        abc(1234, true);
        var a = function(x, y) {
            return (('_' + '_').slice(1));
        }

        var b = function () {
            return [1,2,3,4];
        }

        var c = function (x,y) {
            return x + y;
        }

        var d = function (x,y) {
            var a = x+y;
            return a;
        }
        """
    inter = JSInterpreter(js_test)
    assert inter.call_function('a', 'a', 'b') == '__abc'
    assert inter.call_function('b') == [1,2,3,4]
    assert inter.call_function('c', 2, 3) == 5

# Generated at 2022-06-22 09:04:32.062469
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    try:
        JSInterpreter('var a = [1, 2];').interpret_expression("a[0]", {})
    except Exception as e:
        print("JSInterpreter.interpret_expression: Failed")
        print(e)
        return False

    print("JSInterpreter.interpret_expression: OK")
    return True


# Generated at 2022-06-22 09:04:38.268988
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = r'''
        var a = 5;
        var b = 4;
        var c = a + b;
    '''
    interpreter = JSInterpreter(js_code)
    local_vars = {"a": 5, "b": 4}
    stmt_list = js_code.split(';')
    result = []
    for stmt in stmt_list:
        res, abort = interpreter.interpret_statement(stmt, local_vars)
        result.append(res)

    assert result == [None, None, 9]


# Generated at 2022-06-22 09:05:05.109046
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interp = JSInterpreter('var a = 1; var b = 2; var c = a + b;')
    local_vars = {}
    res, abort = interp.interpret_statement('a = 1;', local_vars)
    assert res == 1
    assert abort == False
    res, abort = interp.interpret_statement('b = 2;', local_vars)
    assert res == 2
    assert abort == False
    res, abort = interp.interpret_statement('c = a + b;', local_vars)
    assert res == 3
    assert abort == False
    res, abort = interp.interpret_statement('return a + b;', local_vars)
    assert res == 3
    assert abort



# Generated at 2022-06-22 09:05:12.572483
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = r'''
        var a = "you are on your own";
        var b = "use self.code"
        var c = a;
        return a;
    '''

    class Self:
        code = code

    js_interpreter = JSInterpreter(code, objects={'self': Self})
    assert js_interpreter.interpret_statement(code, {}) == ('you are on your own', True)


# Generated at 2022-06-22 09:05:21.124338
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    from .jsinterpreter import JSInterpreter
    code = '''
        var a = {
            b : 3,
            c : function(){
                return b;
            }
        }
    '''
    objects = {}
    jsinterpreter = JSInterpreter(code, objects)
    jsinterpreter.extract_object('a')

# Generated at 2022-06-22 09:05:30.066375
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
            function decodeTags(a) {
                b = a;
                if (b)
                    for (var c = 0; c < b.length; c += 2)
                        b[c + 1] = "";
                return b
            }"""
    inter = JSInterpreter(code)
    f = inter.extract_function("decodeTags")
    assert f(("a", "b")) == ["a", "", "b", ""]


if __name__ == '__main__':
    test_JSInterpreter_extract_function()

# Generated at 2022-06-22 09:05:40.454157
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-22 09:05:47.031940
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:05:57.074979
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = """
        var $ = {
            decodeURI: function (str) {
                return decodeURI(str);
            },
            itoa: function (a) {
                return a.toString(10);
            }
        };
    """
    js_interpreter = JSInterpreter(js)
    f = js_interpreter.build_function('a'.split(','), 'return a;')
    assert f([42]) == 42
    f = js_interpreter.build_function(
        'a,b'.split(','),
        'a=a.toString(10);return b;')
    assert f([42, 'foo']) == 'foo'


# Generated at 2022-06-22 09:06:05.926569
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """var a = 1; var b = 2"""
    jsinterpreter = JSInterpreter(code)
    arg_names = []
    code = """a; b;"""
    f = jsinterpreter.build_function(arg_names, code)
    assert f([]) == 2

    code = """var c = 3"""
    jsinterpreter = JSInterpreter(code)
    arg_names = ["a"]
    code = """c; a;"""
    f = jsinterpreter.build_function(arg_names, code)
    assert f([2]) == 2

    code = """var d = {a : "hello", b : "world"}"""
    jsinterpreter = JSInterpreter(code)
    arg_names = ["obj"]

# Generated at 2022-06-22 09:06:10.715809
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter('', None)
    res = jsi.build_function(["a", "b"], "a+b")
    assert res([1, 2]) == 3
    res = jsi.build_function(["a"], "return a*a")
    assert res([5]) == 25


# Generated at 2022-06-22 09:06:23.033957
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:06:53.011777
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    INTERPRETER = JSInterpreter('')
    assert INTERPRETER.interpret_expression('1', {}) == 1
    assert INTERPRETER.interpret_expression('abc', {'abc': 35}) == 35
    assert INTERPRETER.interpret_expression('1+2', {}) == 3
    assert INTERPRETER.interpret_expression('1-2', {}) == -1
    assert INTERPRETER.interpret_expression('1*2', {}) == 2
    assert INTERPRETER.interpret_expression('1/2', {}) == 0.5
    assert INTERPRETER.interpret_expression('1%2', {}) == 1
    assert INTERPRETER.interpret_expression('1==1', {}) is True
    assert INTERPRETER.interpret_expression('1<2', {}) is True

# Generated at 2022-06-22 09:06:57.970867
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    jsi = JSInterpreter(
        r'''
            function foo(a, b) {
                 var c = a + b;
                 return a + b;
            }''')

    f = jsi.extract_function('foo')
    assert f((1, 2)) == 3


# Generated at 2022-06-22 09:07:09.960064
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = r'''
        abc = function(p, a, c, k, e, r) {
            e = function(c) {
                return c.split("").reverse().join("")
            };
            if (!(!c || c < 0)) {
                var f = this.abc;
                while (c--) {
                    if (k[c]) {
                        p = p.replace(new RegExp(e(c)), k[c])
                    }
                }
            }
            return p;
        }
    '''
    js_interpreter = JSInterpreter(code)
    result = js_interpreter.interpret_statement(r'abc("abc")', {'abc': 'abc'})
    assert result[0] == 'abc'
    result = js_interpreter.interpret_statement

# Generated at 2022-06-22 09:07:16.065128
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objname = 'a'
    code = 'abcdefgh'
    js_interpreter = JSInterpreter(code)
    extracted_obj = js_interpreter.extract_object(objname)
    assert extracted_obj == {}, 'Extracted object {} should be empty.'.format(extracted_obj)


# Generated at 2022-06-22 09:07:24.584799
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:07:36.448183
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    
    from decoder import JSInterpreter
    js = JSInterpreter('function test(a,b) { return a + b ;}')
    res = js.call_function('test',1,2)
    assert(res == 3)
    js = JSInterpreter('function test(a,b) { return a.split("") ;}')
    res = js.call_function('test','1234')
    assert(res == ['1', '2', '3', '4'])
    js = JSInterpreter('var test = function(a,b) { return a.split("") ;}')
    res = js.call_function('test','1234')
    assert(res == ['1', '2', '3', '4'])

if __name__ == '__main__':
    test_JSInter

# Generated at 2022-06-22 09:07:48.818233
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():

    test_code = '''
    function foo() {
        return "bar";
    }
    '''

    def js_extract_function(funcname, code):
        return JSInterpreter(code).extract_function(funcname)

    code = test_code
    funcname = 'foo'
    exp_result = 'bar'
    result = js_extract_function(funcname, code)()
    assert result == exp_result, 'Unexpected result'

    code = '''
    var obj = {};
    obj.foo = function () {
        return "bar"
    };
    '''
    exp_result = 'bar'
    result = JSInterpreter(code, {'obj': {}}).call_function('obj.foo')
    assert result == exp_result, 'Unexpected result'



# Generated at 2022-06-22 09:07:56.368314
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r'''
            var a = {};
            a.b = function(p){};
            a.c = function(p,q){};
            var c = {};
            c.e = function(p){};
            c.d = function(p,q){};
            d.e = function(){};
            '''

# Generated at 2022-06-22 09:08:06.805312
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = '''
        var obj = {
            a: '5',
            b: function(x) {
                return x * 2;
            }
        };
        var func = function(x, y) {
            return x + y;
        };
        '''
    interpreter = JSInterpreter(js_code)
    assert interpreter.call_function('func', 3, 5) == 8
    assert interpreter.interpret_expression('obj.a', {}) == '5'
    assert interpreter.interpret_expression('obj.b(3)', {}) == 6

if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-22 09:08:17.255682
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    obj = """
        _0x1d975=function(_0x10e298,_0x188e4b)
        {
            var _0x1d4a7a='';
            for(var _0x1d70bc=0x0;_0x1d70bc<_0x10e298.length;_0x1d70bc++)
            {
                _0x1d4a7a+=String['fromCharCode'](_0x10e298['charCodeAt'](_0x1d70bc)^(_0x188e4b['charCodeAt'](_0x1d70bc%_0x188e4b.length)));
            }
            return _0x1d4a7a;
        }
        ;
        """

    js_interpreter = JSInterpre

# Generated at 2022-06-22 09:08:58.047342
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_test = JSInterpreter('''
        var a = "abcdef";
        var b = a.split("");
        var c = b.reverse();
        var d = c.join("");
        var e = d.slice(1);
        ''')
    res = js_test.call_function('e', 'abcdef')
    assert res == 'fedcba'

    js_test2 = JSInterpreter('''
        var a = "abcdef";
        var b = a.split("");
        var c = b.splice(1,3);
        var d = c.join("");
        ''')
    res = js_test2.call_function('d', 'abcdef')
    assert res == 'bcd'


# Generated at 2022-06-22 09:09:10.339288
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = '''
        var c = function(a,b)
        {
            return a+b;
        }

        var d = function(a,b)
        {
            return a-b;
        }

        var e = function(a,b)
        {
            return a*b;
        }

        var f = function(a,b)
        {
            return a/b;
        }
        '''

    js_in = JSInterpreter(js)
    assert js_in.call_function('c', 1, 2) == 3
    assert js_in.call_function('d', 1, 2) == -1
    assert js_in.call_function('e', 1, 2) == 2
    assert js_in.call_function('f', 1, 2) == 0.5

# Generated at 2022-06-22 09:09:17.357555
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    from .common import NO_DEFAULT
    from .utils import urljoin

    data = NO_DEFAULT

    # Test 1
    code = "var y = '1' + '1'; var z = x + y;"
    data = {
        'x': '10',
    }
    JSInterpreter(code).interpret_statement(z, data)
    assert data['z'] == '1011'

    # Test 2

# Generated at 2022-06-22 09:09:28.683420
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:09:38.350473
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:09:45.273718
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():

    code1 = """
        var foo = {};
        function runSomething() {
            foo.bar = {
                big_bang: function(arg1, arg2) {
                    return arg1 + arg2;
                }
            };

        }
        runSomething();
        """

    jsint = JSInterpreter(code1)
    obj = jsint.extract_object('foo')
    assert obj['bar']['big_bang'](6, 6) == 12


# Generated at 2022-06-22 09:09:51.961745
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test case 1
    js_interpreter = JSInterpreter(code="var a = 1;return a;")
    assert js_interpreter.interpret_statement("a = 1;return a;", {})[0] == 1
    # Test case 2
    js_interpreter = JSInterpreter(
        code="var a = {\"a\":1};return a.a;return a[\"a\"];")
    assert js_interpreter.interpret_statement("var a = {\"a\":1};return a.a;return a[\"a\"];", {})[0] == 1
    # Test case 3
    js_interpreter = JSInterpreter(
        code="var a = [1,2,3];return a.length;return a[1];")

# Generated at 2022-06-22 09:10:03.420671
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterpreter = JSInterpreter('var abc = function(a, b, c) {};')
    assert jsinterpreter.interpret_expression('abc(3, 4, 5)', {}, 10) == (3, 4, 5)

    jsinterpreter = JSInterpreter('var k = {a: 1, b: 2};')
    assert jsinterpreter.interpret_expression('k', {}, 10) == {'a': 1, 'b': 2}
    assert jsinterpreter.interpret_expression('k.a', {}, 10) == 1
    assert jsinterpreter.interpret_expression('k[\'b\']', {}, 10) == 2

    jsinterpreter = JSInterpreter('var a = [1,2,3];')

# Generated at 2022-06-22 09:10:13.943138
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # A simple test case
    test_code = """
        utils_test = {
            func_one: function(a, b, c) {
                return a + b*c;
            },
            func_two: function(a, b) {
                return a + b;
            }
        };
        """
    func_one = JSInterpreter(test_code).extract_object("utils_test")["func_one"]
    func_one_result = func_one((1, 2, 3))
    assert func_one_result == 7, "func_one_result should be 7"

    # A more complex test case