

# Generated at 2022-06-22 09:01:07.052331
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:01:18.538132
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:01:27.934268
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    argnames = ['a', 'b', 'c']
    code1 = '''
        var x;
        x = a + b;
        d = c;
        return d;
    '''
    f = js_interpreter.build_function(argnames, code1)
    assert f([1, 2, 3]) == 3
    assert f([11, 12, 13]) == 13

    code2 = '''
        var x;
        x = a + b;
        d = c;
        return d + 10;
    '''
    f = js_interpreter.build_function(argnames, code2)
    assert f([1, 2, 3]) == 13
    assert f([11, 12, 13]) == 23


# Generated at 2022-06-22 09:01:36.357685
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = r'''
    var a = '1';
    var b = [2, 3, 4];
    var c = {
        a: 1,
        b: '2',
        c: function(x) {
            return 'abc' + x;
        }
    };
    var d = function() {
        return 4;
    };
    function e(a, b) {
        return a + b;
    }
    var f = function(a, b) {
        return a - b;
    }
    var g = function() {
        return '5';
    }
    ''';
    interpreter = JSInterpreter(code);

# Generated at 2022-06-22 09:01:41.626064
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''var a=function(){};
var b={};b.c=function(){};var d={};d.e={};d.e.f=function(){}'''
    interp = JSInterpreter(code)
    for _funcname in ['a', 'b.c', 'd.e.f']:
        interp.extract_function(_funcname)

# Generated at 2022-06-22 09:01:50.920493
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    class JSInterpreterTest(object):
        def test_an_object(self, objname):
            obj = {'b': 2, 'a': [1, 2, 3]}
            obj_code = '''
                var %s = {};
                %s.a = [1, 2, 3];
                %s.b = 2;
            ''' % (objname, objname, objname)

            interpreter = JSInterpreter(obj_code)
            interpreter._objects[objname] = obj

            check_obj = interpreter.extract_object(objname)
            assert(check_obj == obj)

        def test_a_function(self, funcname):
            def func(args):
                a, b = args
                return a + b


# Generated at 2022-06-22 09:01:58.723768
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
            var f = function (a,b,c){
                var e=function(n){
                    return n*11
                };
                var g=function(u){
                    return u*u
                };
                return e(a)+g(b)+c
            };
            """
    jsi = JSInterpreter(code)
    f = jsi.extract_function('f')
    assert f((1, 2, 3)) == 38

# Generated at 2022-06-22 09:02:09.838180
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_interpreter = JSInterpreter('''
        var kPjX9c = function(a) {
            return a;
        };
    ''')
    assert 'kPjX9c' in locals()
    assert 'kPjX9c' not in globals()
    assert 'kPjX9c' not in js_interpreter.__dict__
    kPjX9c = js_interpreter.extract_function('kPjX9c')
    assert 'kPjX9c' in locals()
    assert 'kPjX9c' not in globals()
    assert 'kPjX9c' not in js_interpreter.__dict__
    assert kPjX9c(3) == 3

# Generated at 2022-06-22 09:02:20.865186
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:02:30.655969
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Test 1
    js_code = '''
    function some_name(a, b){
        a = b + 5;
        var c = a * 2;
        var d = c + 10;
        return a / c - d;
}
    '''
    js = JSInterpreter(js_code)
    func = js.extract_function('some_name')
    assert func((5, 6)) == 0.3
    # Test 2
    js_code = '''
    var some_name = function(a, b){
        a = b + 5;
        var c = a * 2;
        var d = c + 10;
        return a / c - d;
}
    '''
    js = JSInterpreter(js_code)

# Generated at 2022-06-22 09:02:57.859307
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    script = """
        function calc(pp) {
            var aa = pp[0];
            var bb = pp[1];
            var cc = pp[2];
            var dd = pp[3];
            var re = {};
            var tmp;
            tmp = bb;
            bb = (tmp + "").split("").reverse().join("");
            tmp = cc;
            cc = (tmp + "").split("").reverse().join("");
            tmp = bb;
            bb = cc;
            cc = tmp;
            re.a = parseInt(aa, 10);
            re.b = parseInt(bb, 10);
            re.c = parseInt(cc, 10);
            re.d = parseInt(dd, 10);
            return re;
        }
        """
    interpreter = JSInter

# Generated at 2022-06-22 09:03:04.640752
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    obj = JSInterpreter(
        '''function obj(a){
            var b = function(c, d){
                var e;
                return a + c + d;
            };
            return b;
        }
        var f = obj(1)
        ''')
    assert obj.extract_function('obj')(2, 3) == 6
    assert obj.extract_function('obj')(3, 4) == 8
    assert obj.extract_function('f')(5, 6) == 12

# Generated at 2022-06-22 09:03:15.804326
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var b = function(c) {
            var d = function(e) {
                return e
            }
            return d(c)
        }
        var a = {
            'b': function(c) {
                return b(c)
            },
            'd': function(e) {
                return e * 2
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter is not None
    assert len(js_interpreter._functions) == 0
    assert len(js_interpreter._objects) == 1

    objects = js_interpreter._objects
    assert 'a' in objects
    a = objects['a']
    assert len(a) == 2
    assert a['b'](3) == 3

# Generated at 2022-06-22 09:03:27.952414
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Note: This test case can be a fixture, but I don't want to bring
    # dependency just for testing a few lines of code.
    code = '''
    function Mu6kD9(q) {
        function M6kD9(q) {
            function kD9(q) {
                return q.split("").reverse().join("");
            }
            var A7kD9 = "deboced_" + kD9(q);
            return A7kD9;
        }
        var u6kD9 = "edoced_" + M6kD9(q);
        return u6kD9;
    }
    '''
    js = JSInterpreter(code)
    f = js.extract_function('Mu6kD9')
    assert f(('abc',))

# Generated at 2022-06-22 09:03:36.053427
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = r'''var a = [1,2,3,4,5];
    var b = function(n1, n2) {
        while(n1 < n2) {
            n1 ++;
        }
    };
    var c = a.map(b);
    return c;'''
    exp = [2,3,4,5,6]
    ji = JSInterpreter(code)
    result = ji.interpret_statement(code, {})[0]
    assert result == exp


# Generated at 2022-06-22 09:03:47.760229
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = """
        function meow(){
            return 'meow';
        }

        function bark(animal){
            return 'bark'+animal;
        }

        var feed = function(animal){
            return 'feed' + animal;
        }

        var log = function(data){
            console.log(data);
        }

        function eat(food, amount){
            return 'eat'+amount+food;
        }

        function createObject(name, age, country){
            var obj = {};
            obj.name = name;
            obj.age = age;
            obj.country = country;
            return obj;
        }
    """
    interpreter = JSInterpreter(js_code)
    # test function without any argument
    assert interpreter.call_function('meow') == 'meow'


# Generated at 2022-06-22 09:03:59.141759
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def run_test(js_code, js_func, args):
        interpreter = JSInterpreter(js_code)
        return interpreter.call_function(js_func, args)

    assert run_test('function add(a, b) { return a + b; }', 'add', (1, 2)) == 3
    assert run_test('function add(a, b) { return a - b; }', 'add', (1, 2)) == -1
    assert run_test('function add(a, b) { return a * b; }', 'add', (1, 2)) == 2
    assert run_test('function add(a, b) { return a / b; }', 'add', (4, 2)) == 2

# Generated at 2022-06-22 09:04:01.214926
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsi = JSInterpreter('')
    assert jsi.interpret_statement('return 3', {}) == (3, True)



# Generated at 2022-06-22 09:04:09.632319
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = r"""
    var a = 3;
    var b = 'foo';

    var obj = {
        c: 'foobar',
        d: function(x) {
            return x + 1;
        },
        e: function(x, y) {
            return x + y;
        },
        f: function(x, y) {
            return x + y;
        }
    };

    function f(x) { return x; }
    """
    interp = JSInterpreter(js_code)
    assert interp.interpret_expression('a', {}) == 3
    assert interp.interpret_expression('b', {}) == 'foo'
    assert interp.interpret_expression('obj.c', {}) == 'foobar'

# Generated at 2022-06-22 09:04:22.916773
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Define two test functions
    def test_function_1(x, y):
        return x + y

    def test_function_2(x, y, z):
        return x + y + z
    # Define test code for JSInterpreter()
    js_test_1 = '''
        function test_function_1(x, y){
            return x + y
        }
    '''
    js_test_2 = '''
        function test_function_2(x, y, z){
            return x + y + z
        }
    '''
    # Initialize JSInterpreter, call function and test result
    js_interpreter_1 = JSInterpreter(js_test_1)

# Generated at 2022-06-22 09:04:54.596057
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objects = {}
    js_code = """
        a = {b:1,c:function(d){return d+1;},e:function(a){return this.c(a)*this.b;}};
        f=3;
    """
    js_interpreter = JSInterpreter(js_code, objects)
    a = js_interpreter.extract_object('a')
    assert a['b'] == 1
    assert a['c'](2) == 3
    assert a['e'](2) == 6
    assert js_interpreter.interpret_expression('f', objects) == 3


# Generated at 2022-06-22 09:05:05.490992
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = r'''
        var obj1 = {
            obj1member1: "test",
            obj1member2: 25,
            obj1member3: function (a, b) {
                return a + b;
            },
            obj1member4: function () {
                return "hello";
            }
        };
        '''
    obj_interpreter = JSInterpreter(js)
    obj1 = obj_interpreter.extract_object('obj1')
    assert obj1 == {'obj1member1': 'test', 'obj1member2': 25, 'obj1member3':
                    lambda args: args[0] + args[1], 'obj1member4': lambda: 'hello'}

# Generated at 2022-06-22 09:05:17.551225
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    objects = {
        'a': {
            'b': {
                'c': {
                    'd': 'abcde',
                },
            },
            'length': 5,
        },
    }

    # Test an expression statement
    code = 'var a = b.c.d.length - 2;'
    js_interpreter = JSInterpreter(code, objects)
    local_vars = {}
    res, should_abort = js_interpreter.interpret_statement(
        code, local_vars, allow_recursion=100)
    assert res == 3
    assert should_abort == False

    # Test a return statement
    code = 'return c;'
    js_interpreter = JSInterpreter(code, objects)
    local_vars = {'c': 5}
   

# Generated at 2022-06-22 09:05:23.087888
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    jsi = JSInterpreter('function a(b){return b;};')
    assert jsi.call_function('a', 'aaa') == 'aaa'

    # Test type of variables
    jsi = JSInterpreter('function a(b){c=b;return c;}; function d(e){return e+1;};')
    assert jsi.call_function('a', 'aaa') == 'aaa'
    assert jsi.call_function('d', 1) == 2
    assert jsi.call_function('d', '1') == '11'

    # Test operator
    jsi = JSInterpreter('function a(b){b=b+1; return b;};')
    assert jsi.call_function('a', 1) == 2

    # Test function calling

# Generated at 2022-06-22 09:05:33.398194
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Function definition 1
    js_code = '''
    var a = 1;
    var b = 2;
    var f = function(x,y){
        var z = 3;
        return x * y + z + a;
    };'''
    interpreter = JSInterpreter(js_code)

    assert(interpreter.extract_function('f')((1, 2)) == 4)
    assert(interpreter.extract_function('f')((2, 3)) == 8)
    assert(interpreter.extract_function('f')((5, 6)) == 19)

    # Function definition 2

# Generated at 2022-06-22 09:05:44.886413
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_i = JSInterpreter("""
        function f(a, b, c) {
          var d = {
            'a': 0,
            'b': 1,
            'c': 2,
            'd': 3
          };
          a = [5, 4, 3, 2, 1][0];
          b = d['c'];
          return 4;
        }
        var x = 3;
        function f2(a, b) {
          return a + b;
        }
    """)
    assert js_i.interpret_expression("x", {}) == 3
    assert js_i.interpret_expression("a", {"a": 5, "b": 6}) == 5
    assert js_i.interpret_expression("f2(a,b)", {"a": 5, "b": 6}) == 11

   

# Generated at 2022-06-22 09:05:55.333803
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = """
        x = function() {
            return 1;
        }
    """
    js_inter = JSInterpreter(js_code)
    assert js_inter.call_function('x') == 1

    js_code = """
        f123 = function() {
            return 2;
        }
    """
    js_inter = JSInterpreter(js_code)
    assert js_inter.call_function('f123') == 2

    js_code = """
        f123456 = function(a,b) {
            return a+b;
        }
    """
    js_inter = JSInterpreter(js_code)
    assert js_inter.call_function('f123456', 2, 3) == 5


# Generated at 2022-06-22 09:05:59.924467
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('function f(a,b){return a+b;}')
    assert js_interpreter.call_function('f',1,3) == 4


if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-22 09:06:06.734705
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code1 = '''
        function func(a, b) {
            var c = a + b;
            var d = a - b;
            return c + d;
        }
        '''

    js = JSInterpreter(code1)
    f = js.build_function(['a', 'b'], 'var c = a + b;var d = a - b;return c + d;')
    assert f((1, 2)) == 3



# Generated at 2022-06-22 09:06:18.956896
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:07:00.560879
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
        var split = function(x, y) {
            z = x*y;
            return z;
        };
        s.split(3, 3);"""
    jsi = JSInterpreter(code)
    split = jsi.build_function('x,y'.split(','), 'z = x*y; return z;')
    assert(split((3, 3)) == 9)



# Generated at 2022-06-22 09:07:07.681296
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    extractor = JSInterpreter("""
        function shift(arr) {
            var shift = arr[0];
            for (var i = 0; i < arr.length - 1; i++) {
                arr[i] = arr[i + 1];
            }
            arr.length--;
            return shift;
        }
    """)

    array = [1, 2, 3, 4, 5]
    assert extractor.call_function('shift', array) == 1
    assert array == [2, 3, 4, 5]


if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-22 09:07:20.031094
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter('')
    v, abort = interpreter.interpret_statement('var anObject = {};', {'anObject': {}})
    assert v == None
    assert abort == False
    v, abort = interpreter.interpret_statement('anObject.foo = 0;', {'anObject': {}})
    assert v == 0
    assert abort == False
    v, abort = interpreter.interpret_statement('function aFunction() { return null; }', {})
    assert v == None
    assert abort == True
    assert isinstance(v, type(None))
    v, abort = interpreter.interpret_statement('return true;', {})
    assert v == True
    assert abort == True
    assert isinstance(v, type(True))


# Generated at 2022-06-22 09:07:28.278263
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:07:38.121681
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Basic functions test
    js_interpreter = JSInterpreter('''
        {
            "hello": function(a){return a},
            "world": function(){return "abc"}
        }''')
    assert js_interpreter.interpret_expression('f.hello(3)', {'f': {}}, 0) == 3
    assert js_interpreter.interpret_expression('f.world()', {'f': {}}, 0) == 'abc'

    # Test operator
    js_interpreter = JSInterpreter('function(){a=b+c;return a*d}', {})
    assert js_interpreter.interpret_expression('a=b+c', {'b': 2, 'c': 3}, 0) == 5

# Generated at 2022-06-22 09:07:46.685124
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    """Test function for JSInterpreter.interpret_statement"""
    # Note: only tested some random branches in the if-else

    # Test 1: simple assignment
    jsi = JSInterpreter('a = 0;')
    jsi.interpret_statement('a = 0;', {})
    print('Test 1 passed')

    # Test 2: multiple assignment
    jsi = JSInterpreter('a = b = c = 0;')
    jsi.interpret_statement('a = b = c = 0;', {})
    print('Test 2 passed')

    # Test 3: complex assignment
    jsi = JSInterpreter('a[2] = b = 0;')
    jsi.interpret_statement('a[2] = b = 0;', {'a': [1, 2, 3]})
    print('Test 3 passed')



# Generated at 2022-06-22 09:07:55.639460
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:08:08.482067
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:08:12.555364
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = "function test(var1, var2) {return var1+var2;}"
    jsi = JSInterpreter(code)
    assert jsi.call_function('test', 1, 2) == 3
    assert jsi.call_function('test', 'hello', ' world!') == 'hello world!'

test_JSInterpreter_call_function()

# Generated at 2022-06-22 09:08:18.424427
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
var a='a'
function test1(x)
{
  var b;
  if(x.indexOf(a)==4)
    return x+'ss';
  else
    return x;
}
    """
    js = JSInterpreter(js_code)
    assert js.call_function('test1', 'bbaaaa') == 'bbaaasss'
    assert js.call_function('test1', 'bbbaaaa') == 'bbbaaaa'

# Generated at 2022-06-22 09:09:13.311289
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter(
        JS_CODE_1,
        {'baz': ['(', ')'], 'quux': {'foobar': ['(', ')']}}
    )

    ## Testing functions
    # Function: Na, Nb, Nd
    # Input: (a, b, d)
    # Output: a + b / d
    assert interpreter.call_function('Na', 5, 10, 2) == 7.5

    # Function: Nc
    # Input: (a, b, c)
    # Output: a + b + c
    assert interpreter.call_function('Nc', 1, 2, 3) == 6

    # Function: R
    # Input: (a, b)
    # Output: a % b
    assert interpreter.call_function('R', 7, 3) == 1

# Generated at 2022-06-22 09:09:21.378608
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    obj = {
        "a": {
            "b": {
                "c": 5
            },
            "e": "test"
        },
        "f": [2, 3, 5],
        "g": "hello"
    }
    jsi = JSInterpreter("var o={};o.a={};o.a.b={};o.a.b.c=5;o.a.e='test';o.f=[2,3,5];o.g='hello';")
    assert jsi.call_function("o", obj) == obj


if __name__ == '__main__':
    import sys
    from .utils import js_to_json
    import json


# Generated at 2022-06-22 09:09:33.253725
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # test case 1
    test_input_1 = (
        'var a = function() {};',
        dict(),
        5,
    )
    test_output_1 = (
        None,
        False,
    )
    test_result_1 = JSInterpreter.interpret_statement(test_input_1[0], test_input_1[1], test_input_1[2])
    assert test_result_1 == test_output_1, test_result_1
    # test case 2
    test_input_2 = (
        'return;',
        dict(),
        5,
    )
    test_output_2 = (
        None,
        True,
    )

# Generated at 2022-06-22 09:09:40.719778
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    from .common import DummyIE

    ie = DummyIE({'url': 'http://example.com/',
                  'js': '''
                     function f(a,b,c) {
                       return a + b + c;
                     }
                  '''})
    jsi = JSInterpreter(ie._DOWNLOADER.cache['http://example.com/']['js'])
    assert jsi.call_function('f', 'a','b','c') == 'abc'

# Generated at 2022-06-22 09:09:44.577363
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = 'var a = function(a){return function(b){return a;}};'
    jsinterpreter = JSInterpreter(js_code)
    f = jsinterpreter.extract_function('a')
    assert f(('a',))('b') == 'a'


# Generated at 2022-06-22 09:09:54.214164
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Tests valid/invalid expressions, assignment and return

    interpreter = JSInterpreter("""var test = {
        f: function() {
            a = (1 + 2);
            b = 'c';
            c = 0;
            d = ['e'];
            e = [1, 2];
            f = {g: 'h'};
            g = {'i': 'j'};
            h = 0;
            h += 3;
            h += 4;
            h += 5;
            return h;
        }
    };""")

    # Test for res,abort = interpreter.interpret_statement("...", local_vars)

# Generated at 2022-06-22 09:10:00.493027
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = "function test(a,b,c) {var d = a + b * c; return d;};"
    jsinterpreter = JSInterpreter(js_code)
    test_a = 2
    test_b = 3
    test_c = 4

    result = jsinterpreter.extract_function('test')((test_a, test_b, test_c))
    assert result == test_a + test_b * test_c



# Generated at 2022-06-22 09:10:09.463400
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # build_function test case 1
    funcname1 = 'f1'
    argnames1 = ['a', 'b', 'c']
    code1 = 'a+b+c'
    jsint1 = JSInterpreter('', None)
    f1 = jsint1.build_function(argnames1, code1)
    if f1((1,2,3)) != 6:
        print("An error occurred in build_function test case 1")
    else:
        print("build_function test case 1 passed")

    # build_function test case 2
    funcname2 = 'f2'
    argnames2 = ['a', 'b', 'c']
    code2 = 'a*b*c'
    jsint2 = JSInterpreter('', None)