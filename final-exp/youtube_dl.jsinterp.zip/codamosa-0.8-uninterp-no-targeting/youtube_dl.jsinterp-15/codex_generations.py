

# Generated at 2022-06-22 09:01:02.166009
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:01:12.454666
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:01:19.384423
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Function to test:
    #    f_name = "function str_reverse(s) { return s.split("").reverse().join("") }"

    func = """function str_reverse(s) {
        var t = "";
        for (var i = 0; i < s.length; i++) {
            t = s.charAt(i) + t;
        }
        return t;
    }"""
    JSI = JSInterpreter(func)
    assert JSI.extract_function('str_reverse')(('abc',)) == 'cba'



# Generated at 2022-06-22 09:01:33.364752
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-22 09:01:38.426043
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsinterpreter1 = JSInterpreter("""
        var u2k = {
            qC: function () {
                return [0, 1, 2];
            }
        }
    """)
    print(jsinterpreter1.call_function('u2k.qC', None))


# Generated at 2022-06-22 09:01:47.023566
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
    function a(x,y){
        z = x+y
        z = z-1
        z = z*10
        z = z/10
        if(z<0) return -1
        return z
    }
    """
    js_interpreter = JSInterpreter(code)
    func_m = re.search(
        r'\bfunction\s+a\s*\((?P<args>[^)]*)\)\s*'
        r'\{(?P<code>[^}]+)\}',
        code)
    argnames = func_m.group('args').split(',')
    func = js_interpreter.build_function(argnames, func_m.group('code'))
    assert func((1,2)) == 1


# Generated at 2022-06-22 09:01:58.678380
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test_case(code, argnames, args, expected):
        resf = JSInterpreter('', {}).build_function(argnames, code.strip())
        assert resf(args) == expected

    test_case(
        'return a;', ['a'], [1], 1)
    test_case(
        '''
        var myVar = a;
        return myVar;
        ''', ['a'], [1], 1)
    test_case(
        '''
        var myVar = a;
        myVar = myVar + 1;
        return myVar;
        ''', ['a'], [1], 2)

# Generated at 2022-06-22 09:02:10.191413
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:02:21.096843
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:02:30.929218
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = '''
    function func(a,b,c) {
        var d = a + b;
        d += c;
        return d;
    }
    '''
    jsi = JSInterpreter(js)
    f = jsi.extract_function('func')
    assert f((1,2,3)) == 6

    js = '''
    var func = function(a,b) {
        return a + b;
    }
    '''
    jsi = JSInterpreter(js)
    f = jsi.extract_function('func')
    assert f((1,2)) == 3

    js = '''
    var func = function(a,b) {
        var c = a + b;
        return c;
    }
    '''
    jsi = JSInterpre

# Generated at 2022-06-22 09:02:58.359703
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter('var a = 1;')
    assert interpreter.interpret_statement('return a;') == (1, True)
    assert interpreter.interpret_statement('return a == 1;') == (True, True)
    assert interpreter.interpret_statement('return a == 2;') == (False, True)
    interpreter = JSInterpreter('var a = 1; var b = 1;')
    assert interpreter.interpret_statement('a = 2;') == (2, False)
    assert interpreter.interpret_statement('return a;') == (2, True)
    assert interpreter.interpret_statement('return a == 2;') == (True, True)
    assert interpreter.interpret_statement('return a == 1;') == (False, True)
    assert interpreter.interpret_statement('a = a + b;') == (3, False)


# Generated at 2022-06-22 09:03:07.774641
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = r'''
        function test(a) {
            var b = function() { return 3; };
            function inner() { return 1; };
            return a + b() + inner();
        }
        function test2(a, b, c) {
            var d = a + b;
            var e = a + c;
            return d + e;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.extract_function('test')((4,)) == 8
    # Test function with multiple arguments
    assert js_interpreter.extract_function('test2')((1, 2, 3)) == 9

# Generated at 2022-06-22 09:03:17.488286
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    test_text = r'''
        function f1(a, b, c) {
            return a + b + c;
        }
        var f2 = function (a, b) {
            return a - b;
        }
        window.f3 = function (a) {
            return a * a;
        }
        '''
    assert JSInterpreter(test_text).call_function('f1', 1, 2, 3) == 6
    assert JSInterpreter(test_text).call_function('f2', 6, 2) == 4
    assert JSInterpreter(test_text).call_function('f3', 8) == 64
    return True

# Generated at 2022-06-22 09:03:25.549803
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter("var a = 'abc';var b = function(z,y){return 2+z+y;};var c = b(5,'b');a[2] = 'z';return a;")
    assert js.interpret_statement("var a = 'abc';var b = function(z,y){return 2+z+y;};var c = b(5,'b');a[2] = 'z';return a;",{})[0] == "abz"


# Generated at 2022-06-22 09:03:31.342064
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    result = JSInterpreter('var a = {c:function(d,e){return d+e}};').extract_function('a.c')
    assert result((1,2)) == 3, result
    result = JSInterpreter('var a = {c:function(d,e){return d+e}};').extract_function('a.d')
    assert result((1,2)) == 3, result


# Generated at 2022-06-22 09:03:37.353330
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = ('''function fromCharCode(a) {
        for (var b = [], c = 0;c < a.length; c++)b.push(String.fromCharCode(a[c]));
        return b.join("")
    };
    ''')
    interpreter = JSInterpreter(code)
    func = interpreter.build_function(['a'], ('var b=[];for(var c=0;c<a.length;c++)b.push(String.fromCharCode(a[c]));return b.join("")',))
    result = func([[116,101,115,116]])
    assert result == 'test'



# Generated at 2022-06-22 09:03:42.461435
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
        function r(a, b){
            return a+b;
        }
    """
    js = JSInterpreter(code)
    assert js.call_function('r', 1, 2) == 3


# Generated at 2022-06-22 09:03:50.953066
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Simple example of JS code
    js_code = "var c = ab; c = abc; var a; a = 12; a = a + 34; var b = 'def'; b = b + gh;"
    # Extract JS code with function name
    func_m = re.search(
            r'''(?x)
                (?:function\s+%s|[{;,]\s*%s\s*=\s*function|var\s+%s\s*=\s*function)\s*
                \((?P<args>[^)]*)\)\s*
                \{(?P<code>[^}]+)\}''' % ('test', 'test', 'test'), js_code)
    # Test build_function method with an argument 'argnames' = ['c'], 'code' = 'c = ab

# Generated at 2022-06-22 09:04:00.151936
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    ji = JSInterpreter('''\
        abcdef = function (A, B) {
            return A * B;
        };
        "ghijkl" = function (A, B) {
            return A / B;
        };
        var mnopqr = function (A, B) {
            return A + B;
        };
        ''')
    assert ji.extract_function('abcdef')((5, 6)) == 30
    assert ji.call_function('"ghijkl"', 50, 6) == 8.333333333333334
    assert ji.call_function('mnopqr', 55, -6) == 49

# Generated at 2022-06-22 09:04:05.893152
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    test_str = r'''function test_function(arg1, arg2) {
            var tmp1 = arg1;
            var tmp2 = tmp1 + arg2;
            return tmp2;
        }'''
    jsi = JSInterpreter(test_str)
    assert jsi.extract_function('test_function')((3, 5)) == 8


# Generated at 2022-06-22 09:04:34.048362
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():

    code = '''
        function w (u){
            function A(c) {
                function D() {
                    return c[0]
                }
                function F() {
                    return c[1]
                }
                return D() + F();
            }
            return A([1,2]);
        }
    '''
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('w', [1]) == 3

# Generated at 2022-06-22 09:04:39.813732
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    obj = JSInterpreter('''
        var x = {
            y: 123,
            z: function(){
                return y - 90;
            },
            s: "abcd"
        }
    ''').extract_object('x')
    assert obj['y'] == 123
    assert obj['z']() == 33
    assert obj['s'] == 'abcd'


# Generated at 2022-06-22 09:04:48.823220
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = r'''
        someFunc = function (a) {
                a = 1;
                var c = [1,2,3]
                if (a > 0) {
                    c.reverse();
                    return c;
                }
            }'''

    interpreter = JSInterpreter(js_code)
    func = interpreter.build_function(['a'], 'a = 1; var c = [1,2,3]; if (a > 0) { c.reverse(); return c; }')
    assert func(1) == [3,2,1]


# Generated at 2022-06-22 09:04:55.250049
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print('Unit test for method interpret_expression of class JSInterpreter')
    js_code = r'''
        function f(a,b,c) {
            var d = a + b;
            return d;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    v = js_interpreter.interpret_expression('f(1,"a",1)', {})
    assert v == 2
    print("test_JSInterpreter_interpret_expression() passed.\n")



# Generated at 2022-06-22 09:05:06.466691
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:05:18.196220
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    # The code we want to analyze
    code = r'''
        function someFunc() {
            var v1 = obj["key"];
            return v1;
        }
        var obj = {
            "key": "value",
            "fn2": function (arg) {
                return arg;
            }
        }
        let obj2 = {
            "key": "value",
            "fn2": function (arg) {
                return arg;
            }
        }
        '''

    # Create a new JSInterpreter object instance
    jsi = JSInterpreter(code)

    # Extract functions of the code
    some_func = jsi.extract_function('someFunc')
    obj_fn2 = jsi.extract_object('obj')['fn2']

# Generated at 2022-06-22 09:05:23.572490
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter.build_function((), '')(tuple()) is None
    assert JSInterpreter.build_function(('x',), 'x = 0')((1,)) == 0



# Generated at 2022-06-22 09:05:27.554736
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = JSInterpreter("""
        function foo(){
            return 'foo';
        }
    """)
    func = js.extract_function('foo')
    assert func() == 'foo'


# Generated at 2022-06-22 09:05:32.034060
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    argnames = ["a", "b"]
    code = 'c = a + b; return c'
    js_interpreter = JSInterpreter("")
    built_function = js_interpreter.build_function(argnames, code)
    assert built_function((1,2)) == 3


# Generated at 2022-06-22 09:05:43.774030
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    CODE = r'''
    var s = "abcdefghij";
    var a = [];
    a.push(s.slice(0, 3));
    a.push(s.slice(-4));
    a.push(s.slice(-4, -2));
    var b = "";
    for (var i = 0; i < a.length; i++)
        b += ((i == a.length - 1) ? " and " : ", ") + a[i];
    b = b.substr(2);
    var c = [];
    c["0"] = "zero";
    c[1] = "one";
    c.push("two");
    '''
    obj = JSInterpreter(CODE)
    assert obj.call_function('s.slice(0, 3)') == 'abc'
   

# Generated at 2022-06-22 09:08:49.563316
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    from .common import FileDownloader
    from .compat import compat_urllib_request
    # The code that is being interpreted
    #url = 'https://www.youtube.com/yts/jsbin/player-en_US-vflU6RN4g/base.js'
    url = 'https://www.youtube.com/yts/jsbin/player-vflD7gN8e/en_US/base.js'
    request = compat_urllib_request.Request(url)
    request.add_header('User-Agent', FileDownloader.user_agent())
    request.add_header('Accept-Charset', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7')

# Generated at 2022-06-22 09:08:56.335573
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = {
            b: function() {},
            c: function() {},
            d: function() {}
        };
    """

    js = JSInterpreter(code)
    obj = js.extract_object('a')

    assert obj['b'] == js.build_function([], '')
    assert obj['c'] == js.build_function([], '')
    assert obj['d'] == js.build_function([], '')

# Generated at 2022-06-22 09:09:08.962917
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter('function test(a) { return a + 1; }')
    assert JSInterpreter('test = function() { return 1; }')
    assert JSInterpreter('var test = function() { return 1; }')
    assert JSInterpreter('var test = function() { return 1; }, test2 = function() { return 1; }')
    assert JSInterpreter('var test = function() { return 1; }\ntest2 = function() { return 1; }')
    assert JSInterpreter('var test = function() { return 1; }\ntest2 = function() { return 1; }')
    assert JSInterpreter('var test = function() { return 1; }\ntest = function() { return 2; }')

# Generated at 2022-06-22 09:09:14.412861
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    JSInterpreter("""\
    var obj1 = {
        'str': 'string',
        'int': 1,
        'list': ['el1', 'el2'],
        'obj2': obj2,
        'func': function(arg) {
            return 'func(' + arg + ')';
        },
        'func2': function() {
            return this.str + ' ' + this.int;
        }
    };
    """)
# End of unit test



# Generated at 2022-06-22 09:09:26.351954
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:09:35.469341
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    def check(stmt, expected):
        actual = JSInterpreter('').interpret_statement(stmt, {})[0]
        assert expected == actual, 'Expected %r but got %r' % (expected, actual)

    check('var a = b + c', None)
    check('a = b + c', None)
    check('return b + c', None)
    check('return b + c', None)
    check('var a = b = 10', 10)
    check('return b = 10', 10)
    check('return a = b = 10', 10)
    check('return 1', 1)
    check('return 1 + 2', 3)
    check('return 1 + 2 * 3', 7)
    check('return 1 + 2 * 3 + 4', 11)

# Generated at 2022-06-22 09:09:37.397093
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    jsinterpreter = JSInterpreter("")
    assert jsinterpreter


# Generated at 2022-06-22 09:09:46.069992
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    obj = {'a': 2, 'b': 3}
    jsi = JSInterpreter('''
        var ytplayer = {
            a: 2,
            b: function(arg1, arg2) { return arg1*arg2 }
        };
    ''', {'obj': obj})
    o = jsi.extract_object('ytplayer')
    for k, v in obj.items():
        assert k in o
        assert o[k] == v
    assert callable(o['b'])
    assert o['b'](3, 4) == 12


# Generated at 2022-06-22 09:09:55.500454
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Test case 1.1: A func with the exact name.
    code_11 = '''function abc(){ return "abc"; };'''
    interpreter = JSInterpreter(code_11)
    f_11 = interpreter.extract_function('abc')
    assert f_11() == 'abc'

    # Test case 1.2: A func with the exact name.
    code_12 = '''function abc(){ return "abc"; };'''
    interpreter = JSInterpreter(code_12)
    f_12 = interpreter.extract_function('abc')
    assert f_12() == 'abc'

    # Test case 1.3: A func with the exact name.
    code_13 = '''function abc(){ return "abc"; };'''
    interpreter = JSInterpreter(code_13)
    f_

# Generated at 2022-06-22 09:10:04.644214
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('', {})
    local_vars = {}
    exprs_and_results = [
        ('x = "asdf" + 123', 'asdf123'),
        ('y = x.slice(2)', 'df123'),
        ('x[1] == "s"', True),
    ]
    for expr, expected_result in exprs_and_results:
        result, _ = js_interpreter.interpret_statement(expr, local_vars)
        assert result == expected_result
        print('Test for expr %r passed' % (expr))

if __name__ == '__main__':
    test_JSInterpreter_interpret_statement()
    pass