

# Generated at 2022-06-22 09:01:05.605098
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = """
        a = Math.round(b);
    """

    js = JSInterpreter(code)
    assert js is not None

# Generated at 2022-06-22 09:01:09.973397
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():

    # Code from YouTube (TODO: add more tests)
    code = 'function test(a) { var b = "123"; this.obj = {foo: function(arg) {return arg + b;}};}'
    test_JSInterpreter = JSInterpreter(code)
    test_function = test_JSInterpreter.build_function(["a"], "var b = '123'; this.obj = {foo: function(arg) {return arg + b;}};")
    assert test_function([])["obj"]["foo"]("test") == "test123"

# Generated at 2022-06-22 09:01:13.328609
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    #testfile=open('js-interpreter-test.js', 'r')
    #js_code=testfile.read()
    #Testing a sample of the file
    js_code='''
    function a()
    {
          return 0
    }
    function b(a,b)
    {
        return a+b
    }
    '''
    js_interpreter=JSInterpreter(js_code)
    assert js_interpreter.call_function('a')==0
    assert js_interpreter.call_function('b',1,2)==3

# Generated at 2022-06-22 09:01:21.827393
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:01:30.652562
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    objcode = r"""var obj1 = {
    "a": function (b, c){
        return 3 + b;
    },
    "b": function (d, e){
        return d + 5;
    }
}"""
    obj2code = r"""var obj2 = {
    "a": function (b, c){
        return 3 * b;
    },
    "b": function (d, e){
        return d - 5;
    }
}"""
    fcode = r"""var f1 = function (b){
    return b + 3;
}"""
    jsi = JSInterpreter(objcode)
    assert jsi._objects['obj1'] == {'a': lambda b, c: 3 + b, 'b': lambda d, e: d + 5}


# Generated at 2022-06-22 09:01:38.367029
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:01:48.370282
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:01:57.686492
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    class TestJSInterpreter(JSInterpreter):
        def __init__(self):
            JSInterpreter.__init__(self, '')
        def extract_function(self, name):
            if name == 'foo':
                def foo(a):
                    return a[0]
                return foo
            else:
                return JSInterpreter.extract_function(self, name)
    js = TestJSInterpreter()
    assert js.call_function('foo', (1,)) == 1


# Generated at 2022-06-22 09:02:03.195920
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    _DESERIALIZE_FUNC_NAME = "deserialize"
    _JS_CODE = """
    function deserialize(a){
        return a;
    }
    """
    _TEST_VALUE = "test"
    js_interpreter = JSInterpreter(_JS_CODE)
    res = js_interpreter.call_function(_DESERIALIZE_FUNC_NAME, _TEST_VALUE)
    assert res == _TEST_VALUE


# Generated at 2022-06-22 09:02:12.943396
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        Object.prototype.a = 0;
        Object.prototype.b = 1;
        Object.prototype.c = "c";
        Object.prototype.d = {};
        Object.prototype.d.e = 2;
        ({
            e: 3,
            f: function(g){
                return g * 2;
            }
        })
    '''
    obj = JSInterpreter(code).interpret_expression(code, {})
    assert obj['e'] == 3
    assert obj['f'](5) == 10
    assert obj['a'] == 0
    assert obj['b'] == 1
    assert obj['c'] == 'c'
    assert obj['d']['e'] == 2


# Generated at 2022-06-22 09:02:43.764157
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    objects = {}
    JSInterpreter(None, objects)
    assert objects == {}, "Objects should be empty if no input of JSInterpreter"


# Generated at 2022-06-22 09:02:49.170433
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = """
        var example = {
            "a": 5,
            "b": "asdf",
            "f": function() {
                return "test";
            }
        }
    """
    j = JSInterpreter(js_code)
    assert j.call_function("example.f") == "test"


# Generated at 2022-06-22 09:02:52.140591
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    try:
        JSInterpreter('){alert(1)}//', {})
    except ExtractorError as e:
        assert 'Unsupported JS expression' in str(e)


# Generated at 2022-06-22 09:03:02.715346
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
    a = 5;
    var b = function foo(x) {
        a = a + 1;
        return a + x;
    }

    var c = function bar(x, y) {
        return a + x + y;
    }
    '''

    interp = JSInterpreter(code, {})
    f = interp.build_function(['x'], 'a = a + 1; return a + x;')
    assert f([4]) == 10

    g = interp.build_function(['x', 'y'], 'return a + x + y;')
    assert g([4, 5]) == 14





if __name__ == '__main__':
    import sys
    test_JSInterpreter_build_function()

# Generated at 2022-06-22 09:03:11.952987
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:03:17.113546
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsi = JSInterpreter('''
        var a=5;
        var b=10;
        var my_func=function(p1,p2){
            var s=p1+p2;
            return s;
        };
    ''')
    assert jsi.call_function('my_func', 5, 10)==15


# Generated at 2022-06-22 09:03:22.494368
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = '''
        var a = 1;
        var b = a + 2;
        var c = b + "hello";
    '''
    interpreter = JSInterpreter(js)
    for v in ('a', 'b', 'c'):
        assert interpreter.interpret_expression(v, {}) == v


if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-22 09:03:33.123621
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
    var a = {
        foo: function (arg1, arg2) {
            var bar = "hello";
            var baz = arg1 + arg2;
            return baz;
        }
    };
    '''

    class FakeObj(object):
        def __init__(self, v):
            self.v = v

        def __str__(self):
            return 'FakeObj(%r)' % self.v

        def __len__(self):
            return len(self.v)

        def __getitem__(self, idx):
            return self.v[idx]

        def __setitem__(self, idx, value):
            self.v[idx] = value

    objects = {'a': FakeObj(['foo', 'bar', 'baz'])}

# Generated at 2022-06-22 09:03:36.477101
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsinterpreter = JSInterpreter('''
        function test_function(arg1, arg2, arg3){
            var var1 = arg1*arg2;
            var var2 = arg1+arg3;
            return var1+var2;
        }'''
    )
    assert jsinterpreter.call_function('test_function', 1, 2, 3) == 7


# Generated at 2022-06-22 09:03:47.923913
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interp = JSInterpreter('')
    assert interp.interpret_statement('return abc', {'abc': 'def'}) == ('def', True)
    assert interp.interpret_statement('return abc;def', {'abc': 'def'}) == ('def', True)
    assert interp.interpret_statement('def', {'abc': 'def'}) == (None, False)
    assert interp.interpret_statement('def', {'abc': 'def'}) == (None, False)
    assert interp.interpret_statement('(abc)', {'abc': 'def'}) == ('def', False)
    assert interp.interpret_statement('(abc+def);ghi', {'abc': 'd', 'def': 'ef'}) == ('def', False)

# Generated at 2022-06-22 09:04:23.762209
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    window.ytplayer.config = {"args":{"a":"b"}};
    window.s = "abc";
    window.object1 = {"a":1,"b":2, "callable_func": function() { a = 1; }};
    window.object2 = {"c":3,"d":4};
    function func(a,b) { return a+b; }
    '''
    inter = JSInterpreter(code)
    assert inter.extract_function('func')((1,2)) == 3
    assert inter.interpret_expression('window.s', {}) == 'abc'
    assert inter.interpret_expression('window.s.length', {}) == 3
    assert inter.interpret_expression('func(1,2)', {}) == 3

# Generated at 2022-06-22 09:04:26.932919
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    jsi = JSInterpreter('''var t12 = function() {var a = function(c, d) {return c};return a};''')
    assert jsi.call_function('t12') is not None


# Generated at 2022-06-22 09:04:35.381855
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    objects = {'sig1': ['a1', 'b1', 'c1']}

# Generated at 2022-06-22 09:04:40.078693
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:04:51.710027
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:04:55.718475
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter(
        code='''
        var a = [1, 2, 3]
        function b(x) { return x.map(function(y) { return y + 1 }) }
        var c = b(a);
        ''')
    with pytest.raises(ExtractorError, match='Unsupported JS expression'):
        js.interpret_expression('d', {})
    js.call_function('b', 1)

# Generated at 2022-06-22 09:05:06.820967
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:05:12.229925
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = r'''function abcd(a, b, c) {
        var d = 10;
        return d * (a + b + c);
    }'''
    f = JSInterpreter(code).extract_function('abcd')
    assert f((1, 2, 3)) == 50


# Generated at 2022-06-22 09:05:18.899012
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_intepreter = JSInterpreter(None)

    local_vars = {
        'a': 5,
        'b': 6,
        'c': 7,
        'd': [1, 2, 3],
        'e': {
            'f': 11,
            'g': 12,
            'h': [4, 5, 6],
        }
    }


# Generated at 2022-06-22 09:05:31.946150
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def get_resf(argnames, code):
        return JSInterpreter('', {}).build_function(argnames, code)
    assert get_resf(['a'], 'return a')([2]) == 2
    assert get_resf(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert get_resf(['t'], 'return t.join(" ")')([['abc', 'def', 'ghi']]) == 'abc def ghi'
    assert get_resf(['a'], 'return a[0]')([[1, 2, 3, 4]]) == 1
    assert get_resf(['a'], 'var b = a+a; return b')([2]) == 4

# Generated at 2022-06-22 09:06:02.742256
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:06:09.219449
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter(code=None)
    assert js_interpreter.interpret_expression("a", {}) == "a"
    assert js_interpreter.interpret_expression("a.b", {'a': {'b': 'c'}}) == 'c'
    assert js_interpreter.interpret_expression("a.b.c", {'a': {'b': {'c': 'd'}}}) == 'd'
    try:
        js_interpreter.interpret_expression("a.b.c", {'a': {'b': 'd'}})
        assert False
    except AssertionError:
        pass

# Generated at 2022-06-22 09:06:19.146067
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:06:24.958061
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:06:28.388323
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = 'function example(arg1, arg2) {var arg3 = arg1 + arg2; return arg3;}'
    jst = JSInterpreter(code)
    func = jst.extract_function('example')
    assert func((1, 2)) == 3


# Generated at 2022-06-22 09:06:34.181975
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
        var obj = {
            "a":function(x,y){ return x**y; },
        };"""
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('obj.a', 2, 3) == 8.0


# Generated at 2022-06-22 09:06:45.806573
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('').interpret_expression('1', {}) == 1
    assert JSInterpreter('').interpret_expression('"1"', {}) == '1'
    assert JSInterpreter('').interpret_expression('true', {}) is True
    assert JSInterpreter('').interpret_expression('false', {}) is False
    assert JSInterpreter('').interpret_expression('[1,2]', {}) == [1, 2]
    assert JSInterpreter('').interpret_expression('{a:1}', {}) == {'a': 1}
    assert JSInterpreter('').interpret_expression('a', {'a': 1}) == 1
    assert JSInterpreter('').interpret_expression('a in b', {'a': 1, 'b': [1]}) is True
   

# Generated at 2022-06-22 09:06:51.750207
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinterpreter = JSInterpreter("""
        var a = {};
        a.b = function(x, y) {
            return x * y;
        };
    """)
    f = jsinterpreter.build_function(['x', 'y'], "return x * y;")
    # function f(x, y) {
    #     return x * y;
    # }
    f(2, 3) == 6



# Generated at 2022-06-22 09:06:56.468505
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''var f = function(x) { return x + 1; }'''
    r = JSInterpreter(code)
    f = r.extract_function('f')
    assert f((1,)) == 2
    assert f((2,)) == 3


# Generated at 2022-06-22 09:07:02.027091
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    with open('js_interpreter/dw_function.js') as f:
        code = f.read()
    interpreter = JSInterpreter(code)
    func = interpreter.extract_function('dw')
    assert func('DW') == 'd-w'


# Generated at 2022-06-22 09:07:32.665564
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:07:35.357493
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    from .jsinterp_test import test_build_function
    test_build_function()



# Generated at 2022-06-22 09:07:42.098296
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:07:50.943109
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:07:57.616736
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    from .common import FORMAT_VERSION

# Generated at 2022-06-22 09:08:09.897459
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:08:12.765529
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsInt = JSInterpreter("")
    assert jsInt.interpret_statement("var a = 1") == [None, False]
    assert jsInt.interpret_statement("return \"smth\"") == ["smth", True]


# Generated at 2022-06-22 09:08:21.365765
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    try:
        js_interpreter.interpret_expression('1;2', {})
        assert False
    except ExtractorError:
        return

    assert js_interpreter.interpret_expression('var a = 1', {}) == None
    assert js_interpreter.interpret_expression('return 1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('return a = 1', {'a': 3}) == 1
    assert js_interpreter.interpret_expression('return a = 1', {'a': 3}) == 1
    assert js_interpreter.interpret_expression('return a = 1', {'a': 3}) == 1
    assert js_interpreter

# Generated at 2022-06-22 09:08:27.014975
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
        function f(x, y) {
            var z = [x, [y]];
            z[0] = z[0] + z[1][0];
            z[1][0] = 5;
            return z[0] + z[1][0];
        }
    """
    interpreter = JSInterpreter(code)
    f = interpreter.extract_function('f')
    assert f((3, 7)) == 15

    code_ = """
        function f(a, b) {
            var c = a[0];
            a[0] = b[0];
            b[0] = c;
            return 'ok';
        }
    """
    interpreter = JSInterpreter(code_)
    f = interpreter.extract_function('f')
    a = [42]

# Generated at 2022-06-22 09:08:32.452066
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code_test = (
        '''
            function a(){
                function b(){
                    var c={};
                }
            }
        '''
    )
    test_jsi = JSInterpreter(code_test)
    test_obj = test_jsi.extract_object('c')
    assert test_obj == {}


# Generated at 2022-06-22 09:09:28.028979
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    def assert_result(stmt, varmap, result):
        _assert_result(interpreter, stmt, varmap, result)

    obj = {
        'join': lambda *args: ''.join(args[0]),
        'splice': lambda *args: args[0][1:],
    }
    interpreter = JSInterpreter(
        "var a = lang.split(' '); var b = a.splice(1, 1); var c = a.join('')"),

# Generated at 2022-06-22 09:09:35.654496
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    interpreter = JSInterpreter("""
        var $ = {
            "foo":"bar",
            "baz":{"qux":"quux"},
        };
        var __ = {
            "corge":(function() {
                return [1,2,3];
            })(),
        };
    """)
    assert interpreter._objects == {
        "$": {"foo": "bar", "baz": {"qux": "quux"}},
        "__": {"corge": [1,2,3]},
    }

# Unit tests extracted from https://www.youtube.com/watch?v=2V7JU6bFSUY

# Generated at 2022-06-22 09:09:43.500813
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:09:50.163729
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_js_code = '''
    bla = {
        k1: function (arg1) {
            return arg1 * 2;
        },
        k2: function (arg2) {
            return arg2 * 3;
        }
    }
    '''
    js_interpreter = JSInterpreter(test_js_code)
    obj = js_interpreter.extract_object('bla')
    assert callable(obj['k1'])
    assert obj['k1'](4) == 8


# Generated at 2022-06-22 09:09:56.681208
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:10:01.565319
# Unit test for method interpret_statement of class JSInterpreter