

# Generated at 2022-06-22 09:01:01.260427
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:01:08.785924
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:01:19.148787
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:01:24.653366
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    i = JSInterpreter('')
    for fname in ['A', 'B', 'C']:
        def empty_func(args):
            return args
        i._functions[fname] = empty_func

    assert i.call_function('A', 1, 2, 3) == (1, 2, 3)
    assert i.call_function('B') == tuple()
    assert i.call_function('C') == tuple()

# Generated at 2022-06-22 09:01:30.644133
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter('')
    interpreter.build_function(['abc', 'def'], '')
    interpreter.build_function(['abc'], '')
    interpreter.build_function(['abc', 'def', 'xyz'], '')
    interpreter.build_function([], '')



# Generated at 2022-06-22 09:01:38.367343
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('')
    local_vars = {}

# Generated at 2022-06-22 09:01:46.993528
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    "Testing JSInterpreter's constructor"

# Generated at 2022-06-22 09:01:58.630471
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = """
        var a = [];
        a[0] = 0;
        a[5] = 5;
        b = 10;
        c = 20;
        a[c + 3] = b + c;
    """
    objects = {}
    js_interpreter = JSInterpreter(js_code, objects)
    print(js_interpreter)

    local_vars = {}
    js_interpreter.interpret_statement(js_code, local_vars)
    print(local_vars)

    expr = 'a[c + 3]'
    val = js_interpreter.interpret_expression(expr, local_vars)
    print(val)

    expr = 'a[c + 2]'

# Generated at 2022-06-22 09:02:10.143770
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        a = {
            b: function (a, b){
                if (a.length != b.length) {
                    return false;
                }
                for (var c = 0; c < a.length; c++) {
                    if (a[c] != b[c]) {
                        return false;
                    }
                }
                return true;
            },
            c: function (a, b){
                return a.length == b.length && this.b(a, b);
            }
        }
    '''

    js_interpreter = JSInterpreter(js_code)
    a = js_interpreter.extract_object('a')

    assert a['b']([0], [0])

# Generated at 2022-06-22 09:02:21.097202
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    u"""
    Method build_function of class JSInterpreter should be able to turn the following JS code into python code:
            var sr = 'sr=';
            var bl = 'bl=';
            var swf = 'swf=';
            var a = 1;
            var c = '';
            function l(b) {
                var a = Math.floor(b / 26);
                if (a > 1) {
                    return l(a - 1) + String.fromCharCode(97 + (b % 26))
                } else {
                    return String.fromCharCode(97 + b % 26)
                }
            }
    """

# Generated at 2022-06-22 09:02:39.739115
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def f(args):
        local_vars = dict(zip(['a', 'b'], args))
        for stmt in code.split(';'):
            res, abort = self.interpret_statement(stmt, local_vars)
            if abort:
                break
        return res
    return f


# Generated at 2022-06-22 09:02:47.768118
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    t = JSInterpreter('''
var a = {
  b : function(args1, args2) {
    c = args1 + args2;
  },
  
  d : function(args1, args2) {
    c = args1 - args2;
  },
  
  e : function(args1, args2) {
    c = args2 - args1;
  }
}
''')
    obj = t.extract_object('a')
    assert len(obj) == 3
    assert obj['b'](1, 2) == 3
    assert obj['d'](3, 5) == -2
    assert obj['e'](1, 2) == 1


# Generated at 2022-06-22 09:02:58.454284
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
    function abc(a,b) {
        var aa = a + 2 * b;
        var bb = a * 2 + b;
        return aa + bb;
    }"""
    interpreter = JSInterpreter(code)
    result = interpreter.interpret_expression('abc(2,3)', {})
    assert(result == 23)

    code = """
    function abc(a,b) {
        var aa = a + 2 * b;
        a[12] = 25;
        return a;
    }
    """
    interpreter = JSInterpreter(code)
    result = interpreter.interpret_expression('abc([1, 2, 3], 2)', {})

# Generated at 2022-06-22 09:03:05.798666
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("function func1(a, b) { return a + b; }")
    func = js_interpreter.build_function([], """return a + b;""")
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(["a", "b"], """return a + b;""")
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(["b", "a"], """return a + b;""")
    assert func([2, 1]) == 3

# Generated at 2022-06-22 09:03:10.870861
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        function somefunction() {
            var abc = 3;
            return abc;
        }
        
        function test() {
            var message = "test";
            return message;
        }
        """

    interpreter = JSInterpreter(code)
    assert interpreter.extract_function("test")() == "test"
    assert interpreter.extract_function("somefunction")() == 3


# Generated at 2022-06-22 09:03:23.852116
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:03:33.982819
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    def test_object(obj):
        if 'init' not in obj:
            return obj.get('default')
        # test code
        init = obj['init']
        if 'key' in init:
            return init['key']
        if 'iframe_url' in init:
            return init['iframe_url']
        if 'source' in init:
            return init['source']
        return None

    def extract_obj_name(code):
        res = []
        key = None
        for line in code.splitlines():
            line = line.strip()
            if re.match(r'^[a-zA-Z_$][a-zA-Z_$0-9]*=', line):
                key = line.split('=')[0].strip()

# Generated at 2022-06-22 09:03:46.017820
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:03:54.686733
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    test_cases = [
        (('abcde',), 3, ),
        (('abcde', '', ), 5, ),
        (('abcde', 'd', ), 4, ),
    ]
    js_code = '''
        var f = function(input, opt_substr) {
            var res = 0;
            var i = 0;
            while (input.indexOf(opt_substr, i) != -1) {
                i++;
                res++;
            }
            return res;
        }
    '''
    jsInterpreter = JSInterpreter(js_code)
    for args, expected_result in test_cases:
        assert jsInterpreter.call_function('f', *args) == expected_result

# Generated at 2022-06-22 09:04:05.809746
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    print("testing JSInterpreter.call_function()")

    # This is a sample code from the javascript file that YouTube loads in the browser

# Generated at 2022-06-22 09:04:24.884019
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # given
    code = 'function test(a,b){return a+b}';
    # when
    jsInterpreter = JSInterpreter(code);
    f = jsInterpreter.build_function(['a','b'], 'return a+b');
    # then
    assert f((3,5)) == 8;



# Generated at 2022-06-22 09:04:35.204626
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        e = {"o": function(a) { return a.length; },
             "a": function(a) { return a.split(''); },
             "s": function(a, b) { return a.join(b); },
             "r": function(a) { return a.reverse(); },
             "S": function(a) { return a.slice(0); },
             "P": function(a, b) { return a.splice(b, 1)[0]; }
        };
    """
    jsi = JSInterpreter(code)
    print(jsi.extract_object('e'))


# Generated at 2022-06-22 09:04:44.446535
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = JSInterpreter('''
        function hello(a, b) {
            return "hello " + a + " " + b;
        }
        function add(a, b) {
          return a + b;
        }
        function hello2(name) {
          return "hello " + name;
        }''')
    assert js.call_function('hello', 'mrs.', 'green') == 'hello mrs. green'
    assert js.call_function('add', 5, 7) == 12
    assert js.call_function('hello2', 'sir') == 'hello sir'
    print('test_JSInterpreter_call_function passed')

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-22 09:04:50.664532
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter("var a = b + 1; return a;")
    locals = {"b" : 1}
    assert interpreter.interpret_statement("var a = b + 1; return a;", locals) == (2, True), "JSInterpreter test failed"
    assert interpreter.interpret_statement("var a = b + 1; return a;", {"b" : 3}) == (4, True), "JSInterpreter test failed"


# Generated at 2022-06-22 09:04:59.435332
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''var base64DecodeUnicode = function(str) {
        return decodeURIComponent(atob(str).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
    };

    var base64DecodeUnicode = function(str) {
        return decodeURIComponent(atob(str).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
    };'''
    jsi = JSInterpreter(code)

# Generated at 2022-06-22 09:05:08.245473
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Arrange
    test_functions = [
        'function f(args) { arg1 = arguments[0]; arg2 = arguments[1]; return; }',
        'g = function(args) { arg1 = arguments[0]; arg2 = arguments[1]; return; }',
        'var h = function(args) { arg1 = arguments[0]; arg2 = arguments[1]; return; }',
        'function f(a, b) {return a + b;}',
        'f = function(a, b) {return a + b;}',
        'var f = function(a, b) {return a + b;}'
    ]
    test_function_names = ['f', 'g', 'h', 'f', 'f', 'f']
    stub_returns = [None, None, None, 7, 7, 7]

# Generated at 2022-06-22 09:05:19.545359
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:05:30.067304
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsi = JSInterpreter('''
                        var f = function(p){
                            var a = {1: function(){return 1 + p;}, 2: function(){return 2 + p;}};
                            return a;
                        };
                        var o = f(10);
                        var a = o[1]();
                        var b = o[2]();
                        var c = o.length;
                        ''')
    o = jsi.extract_object('o')
    assert o['1']() == 11
    assert o['2']() == 12
    assert len(o) == 2


# Generated at 2022-06-22 09:05:40.454138
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''function test1() {
        var s_hexcase = "abc";
        var s_b64pad = "A";
        var s = 'abc=')+1;
        return s;
    }
    function test2(a, b) {
        return a + b;
    }
    function test3(a, b) {
        var a = 10
        return a + b;
    }
    '''
    jsint = JSInterpreter(code)
    assert 'test1' in jsint._functions
    assert 'test2' in jsint._functions
    assert 'test3' in jsint._functions

    assert jsint._functions['test1']() == "abc=')+1"
    assert jsint._functions['test2'](1, 2) == 3

# Generated at 2022-06-22 09:05:46.196914
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''

    var a = {
        tt: function(p){return p},
        gg: function(p){return p}
    }

    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    print('tt:', obj['tt']('test'))
    print('gg:', obj['gg']('test'))


# Generated at 2022-06-22 09:06:11.389379
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    #testcase1: different type of operators
    s = 'a = 10; b = (a + 3) * 2; return b'
    js_interpreter = JSInterpreter(s, objects=None)
    assert js_interpreter.interpret_statement(s, {})[0] == 26, "testcase1 failed"
    
    #testcase2: should abort
    s = '''a = 10; b = 2; return a; c = b; return c'''
    js_interpreter = JSInterpreter(s, objects=None)
    assert js_interpreter.interpret_statement(s, {})[0] == 10 and js_interpreter.interpret_statement(s, {})[1] == True, "testcase2 failed"
    
    #testcase3: interpret_statement get the result of interpret_

# Generated at 2022-06-22 09:06:20.116569
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
    function hello (name) {
        return name + "_haha";
    }
    function hello (name, age) {
        return name + "_haha" + age;
    }

    var hello = function (name,age) {
        return name + "_haha" + age;
    }

    var hello = function (name,age) {
        return name + "_haha" + age;
    }

    test = {
        temp: function (name,age) {
            return name + "_haha" + age;
        }
    };
    '''
    jsi = JSInterpreter(js_code)
    assert jsi.call_function('hello', 'shenmegui') == 'shenmegui_haha'

# Generated at 2022-06-22 09:06:29.939994
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter("")
    assert interpreter.interpret_expression("2*4+8", {}) == 14
    assert interpreter.interpret_expression("2**4+8", {}) == 20
    assert interpreter.interpret_expression("var a = 4;a*(2+8)", {}) == 48
    assert interpreter.interpret_expression("var a = 4;if(a>2){a=3}", {}) == 3
    assert interpreter.interpret_expression("var a = 4;var b = [1, 2, 3];b[a]", {}) == 3
    assert interpreter.interpret_expression("var a = 4;var b = [1, 2, 3];b[a-2]", {}) == 2

# Generated at 2022-06-22 09:06:41.836457
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """var f1 = function(a, b) {return a+b;};
            var f2 = function(c, d) {return f1(c, d);};
            var f3 = function(e, f) {
                var g = e+f;
                return g;
            };"""
    # test code with no return statement
    code += """var f4 = function(h, i) {var j = h+i;};"""
    # test code with complex expression
    code += """var f5 = function(k, l) {return k*2+l/2;};"""
    # test code with nested function

# Generated at 2022-06-22 09:06:52.847871
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    import sys
    import pytest
    from .compat import compat_str
    from .utils import strip_jsonp, js_to_json

    # a = 5;
    test_js_code = 'a = 5;'
    interpreter = JSInterpreter(test_js_code)
    test_local_vars = {}
    interpreter.interpret_statement(test_js_code, test_local_vars)
    assert 5 == test_local_vars['a']

    # a = 5; b = 10; c = a + b;
    test_js_code = 'a = 5; b = 10; c = a + b;'
    interpreter = JSInterpreter(test_js_code)
    test_local_vars = {}

# Generated at 2022-06-22 09:07:02.913951
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    '''Unit test for method interpret_expression of class JSInterpreter'''
    # Many tests require a JSInterpreter instance, so we create a dummy instance
    class DummyJSInterpreter(JSInterpreter):
        def __init__(self):
            super(DummyJSInterpreter, self).__init__('', {})

    # Function to convert a numeric string to an integer
    def to_int(string):
        return int(string)

    # Function to test a JS expression and check its result
    def test_eval_JS(interpreter, expression, check_function, message=None):
        if message is None:
            message = expression
        result = interpreter.interpret_expression(expression, {})

# Generated at 2022-06-22 09:07:13.616485
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Testcase 1
    code = '''(function () {
        return {
        st: function (a, b) {
            return new n.Deferred(function (c) {
                var d = {
                    captype: b,
                    lang: a
                };
                this.call("ncaptcha", d, c)
            }.bind(this))
        },
        sv: function (a, b, c) {
            return new n.Deferred(function (d) {
                var e = {
                    csessionid: a,
                    value: b,
                    captype: c
                };
                this.call("ncaptcha/check", e, d, "POST")
            }.bind(this))
        }
        };
    }.call(n));
    '''

    interpreter = JSInterpreter

# Generated at 2022-06-22 09:07:22.158533
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = r'''
        function x(a) {
            var b = a;
            var c = b;
            var d = c;
            return d;
        }
        var e = x(6);
        var f = e;
        var g = f;
        var h = g;'''

    expected_result = 'a'
    inter = JSInterpreter(js_code)
    function_x = inter.extract_function('x')
    result = function_x((expected_result,))
    assert result == expected_result


# Generated at 2022-06-22 09:07:27.544868
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code_1 = '''\
    var oo = {h: function(p) {return p.join('')}};
    var ss = '';
    var ii = 0;
    while (true) {
        if (ii >= oo.length) {
            break;
        }
        ss += oo[ii];
        ii++;
    }
    return ss;'''
    js_code_2 = '''\
    var oo = {h: function(p) {return p.join('')}};
    var ss = '';
    var ii = 0;
    while (ii < oo.length) {
        ss += oo[ii];
        ii++;
    }
    return ss;'''

# Generated at 2022-06-22 09:07:37.753585
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:08:17.027714
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    jsinterpreter = JSInterpreter("""
        function test () { return 123; }
    """)
    assert jsinterpreter.call_function('test') == 123

    jsinterpreter = JSInterpreter("""
        function test (a, b) { return a+b; }
    """)
    assert jsinterpreter.call_function('test', 1, 2) == 3

    jsinterpreter = JSInterpreter("""
        test = function (a, b) { return a+b; }
    """)
    assert jsinterpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-22 09:08:27.702906
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # A simple JS object
    js_code = 'var obj1={strval: "hello", numval: 42, boolval: true, arrval: [1, "hello", false]};'
    test_interpreter = JSInterpreter(js_code)
    # Test interpret_expression
    js_expr = 'obj1.strval'
    test_output = test_interpreter.interpret_expression(js_expr, None)
    assert test_output == 'hello'
    js_expr = 'obj1.boolval'
    test_output = test_interpreter.interpret_expression(js_expr, None)
    assert test_output == True
    js_expr = 'obj1.numval'
    test_output = test_interpreter.interpret_expression(js_expr, None)
    assert test_output

# Generated at 2022-06-22 09:08:34.399541
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
    function test(a,b,c) {
        a = b[0];
        b[0] = c[0];
        a = b[0] + c[1];
        b[0] = b[1] + c[0];
        a = b[0] + b[1];
    }
    '''
    js = JSInterpreter(code)
    return js.extract_function('test')((1,2,3))



# Generated at 2022-06-22 09:08:40.343808
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        function function1(x, y){};
        var object_name = {
            function1: function(x, y) {
                console.log("hello world")
            },
            function2: function(x, y) {
                console.log("hello china")
            }
        };
    '''

    interpreter = JSInterpreter(code)
    assert isinstance(interpreter, JSInterpreter)

    object_name = interpreter.extract_object("object_name")
    assert isinstance(object_name, dict)
    assert len(object_name) == 2

    function1 = object_name["function1"]
    assert function1("a", "b") is None
    function2 = object_name["function2"]
    assert function2("a", "b") is None

#

# Generated at 2022-06-22 09:08:43.852258
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    c = '''
        var func = function(a, b) {
            return a + b;
        };
    '''
    assert JSInterpreter(c).call_function('func', 1, 2) == 3


# Generated at 2022-06-22 09:08:50.250841
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js1 = 'function abc(a, b) {return a*b}'
    js2 = 'function abc(a,b) {return a*b} var bnc = function (a,b) {return a}}}'

    js_interpreter = JSInterpreter(js1)
    f1 = js_interpreter.extract_function('abc')
    assert f1((1, 2)) == 2

    js_interpreter = JSInterpreter(js2)
    f2 = js_interpreter.extract_function('bnc')
    assert f2((1, 2)) == 2


# Generated at 2022-06-22 09:08:58.595100
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def assert_result(expr, expected):
        res = JSInterpreter('').interpret_expression(expr, {})
        assert (res == expected or (
            isinstance(res, list) and isinstance(expected, list)
            and res.count == expected.count and set(res).issubset(expected))), (
            'Interpreted %r, expected %r, got %r' % (expr, expected, res))

    assert_result('1', 1)
    assert_result('["a", -2, 3.4]', ['a', -2, 3.4])
    assert_result('a', 'a')
    assert_result('a.b', 'b')
    assert_result('a.b.c', 'c')

# Generated at 2022-06-22 09:09:03.020142
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """var func = function (s, i) {
                var a = s.split("");
                var b = i;
                var c = [i, "ab"];
                var d = c[0];
                a[0] = b;
                a[b] = c[1];
                a[d] = "cd";
                return a.join("");
            };
            """
    interpreter = JSInterpreter(code)
    func = interpreter.build_function(['s', 'i'], code)
    assert func(['abc', 1]) == 'bac'


# Generated at 2022-06-22 09:09:13.103932
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = '''var table={"1":"Y","2":"N","4":"A","8":"D","16":"F","32":"K","64":"P","128":"R","256":"Q","512":"E","1024":"*"};'''
    jsi = JSInterpreter(js)
    local_vars = {}
    stmt = 'var n=this.n;'
    jsi.interpret_statement(stmt, local_vars)
    stmt = 'var e=this.e.slice(0);'
    jsi.interpret_statement(stmt, local_vars)
    stmt = 'this.characters+=1;'
    jsi.interpret_statement(stmt, local_vars)
    stmt = 'var t=this.characters%3==0?'
    jsi.interpret_statement

# Generated at 2022-06-22 09:09:19.113379
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    # test for constructor
    obj = JSInterpreter('var a = function(){}')
    assert obj.code == 'var a = function(){}'

    # failure test for method call_function
    try:
        JSInterpreter('var a = function(){}').call_function('test')
    except:
        pass
    else:
        assert False, 'method call_function successed when it should have failed'

# unit test for the method extract_function

# Generated at 2022-06-22 09:09:53.190447
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''var a = 1; var b = 2; var c = a + b; return true;'''
    js = JSInterpreter(code)
    # Test interpretation of code 
    assert(js.interpret_expression(code, {}, 100) == True)
    
    # Test interpretation of assignment
    expr = '''var a = 10;'''
    assert(js.interpret_expression(expr, {}, 100) == 10)
    
    # Test interpretation of addition 
    expr = '''var c = a + b;'''
    assert(js.interpret_expression(expr, {}, 100) == 3)
    
    # Test interpretation of variable names
    expr = '''a'''
    assert(js.interpret_expression(expr, {}, 100) == 1)
    
    # Test interpretation of negative numbers


# Generated at 2022-06-22 09:10:00.857798
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    fname = 'rev'
    code = '''
        var r = "";
        for (var i = 0; i < this.length; i++) {
            r = this[i] + r;
        }
        return r;
    '''
    interpreter = JSInterpreter('', {'f': {}}) # an object is needed
    f = interpreter.build_function([], code)
    assert f([]) == ''

    f = interpreter.build_function(['s'], code)
    assert f(['test']) == 'tset'



# Generated at 2022-06-22 09:10:07.595147
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var  A = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p + 1;
            }
        };
    """
    jsinter = JSInterpreter(code)
    assert {'b': jsinter.extract_object('A')['b'],
            'c': jsinter.extract_object('A')['c']} == {'b': lambda p: p,
                                                      'c': lambda p: p + 1}
