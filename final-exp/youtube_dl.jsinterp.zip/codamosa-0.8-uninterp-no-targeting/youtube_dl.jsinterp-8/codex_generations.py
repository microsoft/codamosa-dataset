

# Generated at 2022-06-22 09:01:35.395570
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        var a = '5';
        var b = 6;
        var c = {
            'foo': [1, 2, 3],
            'bar': function(arg1, arg2) {
                var d = arg1 + arg2;
                var e = arg1 - arg2;
                return d + e;
            },
            'baz': {
                'hello': 'world',
            },
        }
    '''
    jsi = JSInterpreter(code)
    assert jsi.interpret_expression('5', {}) == 5
    assert jsi.interpret_expression('a', {}) == '5'
    assert jsi.interpret_expression('b', {}) == 6
    assert jsi.interpret_expression('[1, "foo"]', {}) == [1, "foo"]
   

# Generated at 2022-06-22 09:01:42.744373
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinterp = JSInterpreter(
        "var r=function(a){var b=a.length;a=a[b-1];b=a.length;var c=a[b-1]; return c};")
    function = jsinterp.build_function(['a'], "var b=a.length;a=a[b-1];b=a.length;var c=a[b-1]; return c")
    assert function([[1, 2, 3]]) == 3


# Generated at 2022-06-22 09:01:47.197130
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    JSInterpreter("""
    var a = 'b';
    """)
    JSInterpreter("""
    var a = {
    b: {
        c: function() {
        }
    }
    }
    """)

if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-22 09:01:58.955089
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter("""
var abcd = {
    "1234": function() {return "abcd1" + arguments[0]},
    "5678": function() {return "abcd2" + arguments[0]}
}""")
    assert js.interpret_expression("abcd.1234(42)", {}) == "abcd142"
    assert js.interpret_expression("abcd[\"1234\"](42)", {}) == "abcd142"
    assert js.interpret_expression("abcd['1234'](42)", {}) == "abcd142"
    assert js.interpret_expression("abcd[5678](42)", {}) == "abcd242"
    assert js.interpret_expression("abcd[5678]('42')", {}) == "abcd242"

# Generated at 2022-06-22 09:02:07.421993
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = r'''function f(a,b){return a+b};var test1=10;f(test1,20);'''
    jsi = JSInterpreter(js)
    res = jsi.call_function('f', 2, 3)
    assert res == 5
    res = jsi.call_function('f', 0x101, 0x20)
    assert res == 0x101 + 0x20

if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-22 09:02:13.554549
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_code = """
        function test_func(a,b){
            var c = a + '_' + b;
            return c;
        }
    """
    js_iterpreter = JSInterpreter(test_code)
    func = js_iterpreter.build_function(['a', 'b'], "var c = a + '_' + b;return c;")
    assert func(('c', 'd')) == 'c_d'


# Generated at 2022-06-22 09:02:23.226904
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code_test = '''
        function test (a,b,c,d) {
            var e = d(a[1]);
            f = a[0];
            return [g,h];
        };'''
    interpreter = JSInterpreter(code_test, {
        'g': 'hello',
        'h': 'world'
    })

    def d(x):
        return 'd(' + x + ')'
    res = interpreter.build_function(['a', 'b', 'c', 'd'], code_test[code_test.index('{')+1:-2])((['f', 'test'], 'test2', 'test3', d))
    assert res == ['hello', 'world']

# Generated at 2022-06-22 09:02:34.411361
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    """Test the interpreter for building a function"""

# Generated at 2022-06-22 09:02:36.810254
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = r'''
        function func(a,b) {
            var c = function(a,b) {
                return a+b;
            };
            e.f(function(){}, "test");
            return c(a,b);
        }
    '''
    JSI = JSInterpreter(code)
    assert JSI.call_function("func", 3, 7) == 10



# Generated at 2022-06-22 09:02:45.057165
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:03:11.721345
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    o = JSInterpreter('', None)

    f = o.build_function(['a', 'b'],
        'var c=a+b;var d=a-b;var e=a*b;var f=a/b;var g=a%b;var h=a>>b;var i=a<<b;var j=a&b;var k=a^b;var l=a|b;return c;')

    assert f([2, 3]) == 5
    assert f([-2, 3]) == -5
    assert f([2, -3]) == -1

    f = o.build_function(['a', 'b'], 'return a+b;')
    assert f([2, 3]) == 5
    assert f([-2, 3]) == 1
    assert f([2, -3])

# Generated at 2022-06-22 09:03:17.689716
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r'''
        var someObj = {
            'foo': function (x, y) { return x + y; },
            'bar': function (x, y) { return x - y; }
        };
    '''
    obj = JSInterpreter(code).extract_object('someObj')
    assert obj['foo'](2, 3) == 5
    assert obj['bar'](2, 3) == -1


# Generated at 2022-06-22 09:03:27.155799
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    test_code = '''
        var b0="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
        var c=[];
        for(var a=0;a<b0.length;a++){
            c[b0.charAt(a)]=a;
        }
        function d(b){
            var a=0;
            for(var e=b.length-1;e>=0;e--){
                a=a*64+c[b.charAt(e)]
            }
            return a
        }'''

    js_interpreter = JSInterpreter(test_code)
    assert js_interpreter.call_function('d', 'M') == 48
    assert js

# Generated at 2022-06-22 09:03:36.120040
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_code_1 = """
        var b = {
            "a": "foo",
            "b": "bar",
            "c": [1, 2, 3]
        };
    """
    code_m = re.search(r'var\s*b\s*=\s*({.*})', test_code_1, re.DOTALL)
    b = JSInterpreter(code_m.group(0))
    assert b.interpret_expression('b.a', {}) == 'foo'
    assert b.interpret_expression('b.c[1]', {}) == 2



# Generated at 2022-06-22 09:03:45.222297
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''(function() {
        var e = {
            A: function(r) {
                return r + 1
            }
        }
    })();
    e.A(1)'''
    assert JSInterpreter(code).call_function(
        'A', 1) == 2

    code = '''(function() {
        var e = {
            A: (r) => {
                return r + 1
            }
        }
    })();
    e.A(1)'''
    assert JSInterpreter(code).call_function(
        'A', 1) == 2

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-22 09:03:56.458261
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''
        var obj = {a: function(){a = a + b;}, b: b.b()};
        var b;
        var c = "c";
        var d = "d";
        var a = "a" + (1 + 2 - c + d) + b;
        var obj2 = {obj3: obj.a + b};
        var abc = "a" + "b" + "c";'''
    js = JSInterpreter(code)
    assert js.interpret_statement('return 1 + 2;', {}) == (3, True)
    assert js.interpret_statement('var x = 1;', {}) == (1, False)
    assert js.interpret_statement('var x = 1; return x + 2;', {}) == (3, True)
    assert js.interpret_statement

# Generated at 2022-06-22 09:04:03.359603
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test_case(f):
        func = JSInterpreter(f).build_function(["a", "b"], "return a + b;")
        assert 2 == func([1, 1])
        assert 3 == func([2, 1])

    fs = [
        "a + b",
        "return a + b",
        "return a + b;"
    ]
    for f in fs:
        yield test_case, f

# Generated at 2022-06-22 09:04:10.401263
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:04:18.468635
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    jsinter = JSInterpreter(
        "var obj = {a:function(){},b:function(){}}",
        {'arg': [3, 4, 5]})
    assert isinstance(jsinter, JSInterpreter)
    assert isinstance(jsinter.code, str)
    assert isinstance(jsinter._functions, dict)
    assert isinstance(jsinter._objects, dict)


# Generated at 2022-06-22 09:04:22.185500
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter(code = 'var a = function(a, b){var c=a+b; var d = b; c=d; return c}')
    assert js_interpreter.call_function('a', 1, 2) == 2

# Generated at 2022-06-22 09:04:40.819144
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test values in case there is no space after 'return'
    code = 'return12;'
    interpreter = JSInterpreter(code)
    v, abort = interpreter.interpret_statement(code, {})
    print (v)
    assert v == 12


# Generated at 2022-06-22 09:04:52.171418
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-22 09:05:04.441679
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    def _test_JSInterpreter_interpret_expression(expr, expected, local_vars,
                                                 allow_recursion=100):
        interpreter = JSInterpreter('', {})
        actual, _ = interpreter.interpret_statement(
            expr, local_vars, allow_recursion)
        assert actual == expected, '{0}, {1}'.format(actual, expected)

    local_vars = {
        'a': 0,
        'b': [1, 2],
    }
    # Test for statement 'var'
    _test_JSInterpreter_interpret_expression(
        'var n=1',
        None,
        local_vars,
        allow_recursion=100,
    )
    assert local_vars['n'] == 1
    # Test for statement 'var'
    _

# Generated at 2022-06-22 09:05:14.575957
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def f(*args):
        return args
    def g(*args):
        return args
    def h(*args):
        return args
    code = '''var hello = function(a,b,c) {return true;}
              var hello2 = function(d) {return false;}
              var a = 10;
              var b = 20;
              var c = [30,40];
              var d = ['hello','world'];
              var e = {hello:a,world:b};
              var f = [a,b,c,d,e];'''
    js = JSInterpreter(code,{'f':f,'g':g,'h':h})
    assert js.interpret_expression('100', {}) == 100
    assert js.interpret_expression('"100000"', {}) == '100000'
    assert js

# Generated at 2022-06-22 09:05:16.636669
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    interp = JSInterpreter('var a=true; var b=5; var c=a+b;')
    assert interp.call_function('c') == 5

# Generated at 2022-06-22 09:05:25.934492
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
        var a = b[number];
        var f = function () {
            var a = 3;
            var args = Array.prototype.splice.call(arguments, 0);
            var c = args.slice(0, 1);
            var str = c[0];
            var d = str.split('');
            var e = [];
            for (var i = 0; i < d.length; i++) {
                e[i] = d[i];
            }
            e = e.reverse();
            var f = e.join('');
            return f;
        }
        """

    interpreter = JSInterpreter(code)

    local_vars = {'number': 0, 'b': [3]}


# Generated at 2022-06-22 09:05:34.730353
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code1 = '''
    var a = {
        "b": function(p) {
            return p;
        }
    };
    '''
    code2 = '''
    function b() {
        return 1;
    }
    '''
    code3 = '''
    var a = function(p) {
        return p + 1;
    };
    '''
    code = code1 + code2 + code3
    js = JSInterpreter(code)

    b1 = js.extract_function('a.b')
    assert b1(1) == 1
    b2 = js.extract_function('b')
    assert b2() == 1
    a = js.extract_function('a')
    assert a(1) == 2


# Generated at 2022-06-22 09:05:42.339454
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        function test(a){
            var b = [1, 2];
            return a[b[1]];
        }
    ''' 
    js = JSInterpreter(code)
    expr = 'a[b[1]]'
    local_vars = {
        'a': ['foo', 'bar'],
        'b': [1, 2],
    }
    res = js.interpret_expression(expr, local_vars)
    assert res == 'bar'


# Generated at 2022-06-22 09:05:53.069853
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('var a = 1; var b = 2;')
    
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('a', {}) == 1
    assert js_interpreter.interpret_expression('a + b', {}) == 3
    assert js_interpreter.interpret_expression('a + b & 3', {}) == 3
    assert js_interpreter.interpret_expression('a + b & c', {'c': 3}) == 3
    assert js_interpreter.interpret_expression('a + (1 + 2 + 3) & c', {'c': 3}) == 3
    assert js_interpreter.interpret_expression('(a + 3) & c', {'c': 3}) == 6
    


# Generated at 2022-06-22 09:06:03.861292
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    print('Test JSInterpreter extract_function')

    # test 1
    code = """
        function add(a,b) {
            return a+b;
        }
    """
    # function add
    func = JSInterpreter(code).extract_function('add')
    assert func((1,2)) == 3

    # test 2
    code = """
        var add = function(a,b) {
            return a+b;
        }
    """
    # function add
    func = JSInterpreter(code).extract_function('add')
    assert func((2,3)) == 5

    # test 3
    code = """
        function add(a,b) {
            return a+b;
        }
        var basic = {
            add: add
        }
    """
    # function

# Generated at 2022-06-22 09:06:32.798488
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    interpreter = JSInterpreter('var obj = {};')
    assert isinstance(interpreter, JSInterpreter)


# Generated at 2022-06-22 09:06:44.548795
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:06:48.345386
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    try:
        js = JSInterpreter('var foo = 5; var bar = "foobar"; var baz = true;')
    except:
        return False
    return True


# Generated at 2022-06-22 09:06:56.112147
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:07:04.375189
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
        var p, a = function() {};
        function q(a, b) {
            var c = a + b;
            p = function() {
                return c;
            }
        }
    """
    jsinterpreter = JSInterpreter(code)
    f = jsinterpreter.build_function(["a", "b"], 'var c = a + b; p = function() {return c;}')
    assert f([1, 2]) == None
    assert jsinterpreter._objects["p"]() == 3

    code2 = '''
        function test() {
            return {
                a: function() {
                    return this.b;
                },
                b: "abcd"
            };
        }
    '''
    jsinterpreter2 = JSInterpreter(code2)

# Generated at 2022-06-22 09:07:17.065310
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    obj_result = {
        'a': 'A',
        'b': 'B',
        'c': 'C',
    }
    obj_interpreter = JSInterpreter("""
            var a="A";
            b="B";
            c=a+b;""")
    obj_local_vars = {}
    for stmt in obj_interpreter.code.split(";"):
        obj_interpreter.interpret_statement(stmt, obj_local_vars, 0)
    for key in obj_result.keys():
        assert obj_local_vars[key] == obj_result[key]

    obj_result = {
        'c': 2,
        's': 'HelloWorld',
        'x': 2,
        'y': 1,
        'z': 3,
    }

# Generated at 2022-06-22 09:07:25.553574
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    jsi = JSInterpreter('''
        function transpose(a) {
            return Object.keys(a[0]).map(function(c) {
                return a.map(function(r) { return r[c]; });
            });
        }
    ''')

    a = [['a', 'b', 1],
         ['c', 'd', 2],
         ['e', 'f', 3]]
    assert jsi.call_function('transpose', a) == [['a', 'c', 'e'],
                                                 ['b', 'd', 'f'],
                                                 [1, 2, 3]]


# Generated at 2022-06-22 09:07:31.799959
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = """
        var a;
        if(a != null) {
            a = a + 2;
        }
    """
    js_interpreter = JSInterpreter(js)
    js_interpreter.interpret_expression('a = a + 2', {})


if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-22 09:07:41.206664
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    var a_var = 5;
    var b_var = 8;
    function my_func(arg1, arg2, arg3) {
        var tmp1 = arg1 + arg2;
        return arg3 + tmp1;
    }
    '''
    interp = JSInterpreter(code, {'a_var': 1})
    assert interp.extract_function('my_func')((3, 5, 2)) == 10
    assert interp.call_function('my_func', 3, 5, 2) == 10
    assert interp.call_function('my_func', 3, 1, 2) == 6
    assert interp.interpret_expression('a_var', {'a_var': 1}) == 1

# Generated at 2022-06-22 09:07:50.262899
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:08:16.853913
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:08:23.910347
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        function encrypt1(a, b, c) {
            c = a + b + c;
            return c;
        }
    ''')
    assert js_interpreter.call_function('encrypt1', 'a', 'b', 'c') == 'abc'


# Generated at 2022-06-22 09:08:35.161779
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsInterpreter = JSInterpreter('',{})
    local_vars = {
        "a": 'a',
        "b": 'b'
    }
    assert jsInterpreter.interpret_expression("a",local_vars,100) == 'a'
    assert jsInterpreter.interpret_expression("b",local_vars,100) == 'b'
    assert jsInterpreter.interpret_expression("a+b",local_vars,100) == 'ab'
    assert jsInterpreter.interpret_expression("a+b+a",local_vars,100) == 'abab'
    assert jsInterpreter.interpret_expression("a-b+a",local_vars,100) == 'a-b+a'


# Generated at 2022-06-22 09:08:41.454173
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Initializing local variables for JSInterpreter
    code = ''
    objects = {}
    JSInterpreter_instance = JSInterpreter(code, objects)

    # Testing first if statement (var a = 5)
    stmt = 'var a=5'
    local_vars = {}
    allow_recursion = 100
    expected_result = ('', False)
    result = JSInterpreter_instance.interpret_statement(stmt, local_vars, allow_recursion)
    assert result == expected_result

    # Testing second if statement (var b = a)
    stmt = 'var b=a'
    local_vars = {'a': '5'}
    allow_recursion = 100
    expected_result = ('', False)

# Generated at 2022-06-22 09:08:44.622856
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''function test(arg1, arg2){
        var a = arg1 + arg2;
        return a;
    }
    '''
    func = JSInterpreter(code).extract_function('test')
    assert func((3, 5)) == 8


# Generated at 2022-06-22 09:08:52.320597
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsinterpreter = JSInterpreter("")
    jsinterpreter.interpret_statement("")
    jsinterpreter.interpret_statement("var a = 0")
    jsinterpreter.interpret_statement("return true;")
    jsinterpreter.interpret_statement("var a = 0 || b")
    jsinterpreter.interpret_statement("return (a || b)")
    jsinterpreter.interpret_statement("if(a || b){}")
    jsinterpreter.interpret_statement("a[b+c] = d")
    jsinterpreter.interpret_statement("a[b+c] = a[b+c] ^ d")
    jsinterpreter.interpret_statement("a[b+c] ^= a[b+c] ^ d")

# Generated at 2022-06-22 09:08:56.030557
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''var f = function(a,b) {var c=a+b;return c+1};'''
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('f', 1, 2) == 4

    code = '''var obj={'f': function(a){return a+1}};'''
    interpreter = JSInterpreter(code)
    assert interpreter.extract_object('obj')['f'](1) == 2


# Generated at 2022-06-22 09:09:03.567269
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter("""
            function reverseString(a) {
                var c, b = "";
                for (var d = a.length - 1; d > -1; d--) {
                    c = a[d];
                    b += c
                }
                return b
            }
            """)
    res = jsi.call_function("reverseString", "Hello World")
    assert res == "dlroW olleH"

# Generated at 2022-06-22 09:09:14.139922
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function test1(arg1, arg2) {
            var a = arg1;
            var b = arg2;
            return a + b;
        }
        function test2(arg1, arg2) {
            var a = arg1;
            var b = arg2;
            var c = test1;
            return c(a, b);
        }
        function test3(arg1, arg2) {
            var a = arg1;
            var b = arg2;
            var c = test1(a, b);
            var d = test2(a, b);
            return a + b + c + d;
        }
    '''
    jsi = JSInterpreter(code)
    assert jsi.call_function('test3', 1, 2) == 12
    assert j

# Generated at 2022-06-22 09:09:26.351798
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter('', {})
    assert js.interpret_statement('x', {})[1] is True
    assert js.interpret_statement('return x', {})[1] is True
    assert js.interpret_statement('return x;', {'x': 5}) == (5, True)
    assert js.interpret_statement('x = y', {})[1] is False
    assert js.interpret_statement('x = y', {'y': 5})[0] == 5
    assert js.interpret_statement('x = y', {'x': 5, 'y': 6})[0] == 6
    assert js.interpret_statement('x <<= y', {'x': 4, 'y': 1})[0] == 8
    assert js.interpret_statement('x = 5', {'x': 4})[0] == 5
   

# Generated at 2022-06-22 09:09:51.910283
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = '''\
        var a = [1, 2, 3];
        var b = {foo: "bar"};

        var c = [a, [4, 5, [b, 6], 7], 8, 9];
        var d = "abcdef";

        var e = function () {};
        function foo(a, b, c) {}
    '''
    jsi = JSInterpreter(js)
    assert jsi.interpret_expression('d', {}) == 'abcdef'
    assert jsi.interpret_expression('d.length', {}) == 6
    assert jsi.interpret_expression('b.foo', {}) == 'bar'
    assert jsi.interpret_expression('a[0]', {}) == 1

# Generated at 2022-06-22 09:10:02.458851
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        o_0 = [0];
        b_0 = {a: function() { return 0; }, b: function(x, y) { return x * y; }};
        b_1 = {c: function(x, y) { return x + y; }};
    '''
    interpreter = JSInterpreter(code)
    assert interpreter.extract_object('b_0') == {'a': lambda: 0, 'b': lambda x, y: x * y}
    assert interpreter.extract_object('b_1') == {'c': lambda x, y: x + y}
    assert interpreter.extract_object('o_0') == [0]
