

# Generated at 2022-06-22 09:00:53.671717
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Object with 4 functions
    code1 = '''
    var _hf7 = {
        _4y: function (a, b) {
            this._6a = a;
            this._6b = b;
        },
        _6: function (a) {
            this._2x = a;
        },
        _2: function (a) {
            return this._2x < a._2x;
        },
        _7: function (a, b) {
            return a._y + b._y;
        }
    };
'''

    js = JSInterpreter(code1)
    obj = js.extract_object('_hf7')
    assert len(obj) == 4
    _4y = obj['_4y']
    assert _4y(6, 8) == None


# Generated at 2022-06-22 09:01:04.324579
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:01:07.670773
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter('', {})
    resf = jsi.build_function([], 'return 1')
    assert resf([]) == 1

if __name__ == '__main__':
    raise RuntimeError('This test needs to be completed.')

# Generated at 2022-06-22 09:01:17.871625
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = '''
    mix = [3, 4, 7];
    mix[0] = mix.shift();
    mix[1] = mix.shift();
    function f(a, b) { return a * b; };
    function g(a, b) { return f(a + b, a) - b; };
    function h(a, b) { return g(b, a); };
    '''
    interp = JSInterpreter(js)
    # test complex expression
    mix = interp.interpret_expression('mix', {})
    assert mix == [4, 7, 3]
    # test function call
    h = interp.interpret_expression('h', {})
    assert h([1, 2]) == 10

# Generated at 2022-06-22 09:01:23.169192
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = """var obj = {
            a:'b', c: function(arg1){ this.d = arg1;}, e: function(arg1){ return arg1;}
            }
    """
    js_interpreter = JSInterpreter(js)
    assert js_interpreter._objects['obj'] == {'a': 'b', 'c': {}, 'e': {}}


# Generated at 2022-06-22 09:01:29.595269
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_code = r'''
        function testFunc(arg1, arg2) {
            var a, b, c, d;
            a = arg1;
            b = arg2;
            c = a + b;
            d = "test";
            return d + c;
        }
    '''
    interpreter = JSInterpreter(test_code)
    func = interpreter.extract_function('testFunc')
    assert func((1, 2)) == 'test3'
    assert func((4, 5)) == 'test9'


# Generated at 2022-06-22 09:01:37.161495
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    class TestInterpreter(JSInterpreter):
        def __init__(self, code, objects=None):
            super(TestInterpreter, self).__init__(code, objects)
            self.functions = {}

    js_code = '''
        a = 3;
        b = "a";
        c = function(arg) {
            return arg + " world";
        };
        d = [1,2,3,4,5];
        e = {a: 3, b: function(arg) { return arg+1; }};
        f = function(a, b) {
            return a+b;
        };
        var g = function(a, b, c) {
            return c*(a+b);
        };
    '''

    interpreter = TestInterpreter(js_code)


# Generated at 2022-06-22 09:01:46.904813
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        function func(a,b) {
            return a + b;
        }
        var obj = {
            "str": "hello world",
            "get": function() {
                return this.str;
            },
            "test": function(a) {
                return a == this.str;
            }
        };
    '''
    jsi = JSInterpreter(code)
    local_vars = {'a': 0, 'b': 1, 'obj': jsi._objects['obj']}
    assert jsi.interpret_expression('1+a', local_vars) == 1
    assert jsi.interpret_expression('func', local_vars) == 2
    assert jsi.interpret_expression('a+b', local_vars) == 1

# Generated at 2022-06-22 09:01:51.083920
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    from .jsinterp_test import jsinterp_test
    failures = []
    for expression, expected in jsinterp_test:
        try:
            result = JSInterpreter('', {}).interpret_expression(expression, {})
            if result != expected:
                failures.append((expression, result, expected))
        except Exception as e:
            if isinstance(expected, Exception):
                if expected.__class__ == e.__class__:
                    continue
            failures.append((expression, e, expected))
    if failures:
        print('Total failures: ', len(failures))
        for failure in failures:
            print(failure)
    else:
        print('All tests passed')

# Generated at 2022-06-22 09:02:02.687048
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:02:21.567412
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function testfunc(a, b) {
            a + b
        }
    '''
    intgr = JSInterpreter(code)
    f = intgr.extract_function('testfunc')
    assert f((3, 7)) == 10

# Generated at 2022-06-22 09:02:28.009829
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    interpreter = JSInterpreter(
        '''\
            //test_JSInterpreter_covert_to

            var func_test1 = function(a, b){
                return a+b;
            }
        '''
    )
    v1 = interpreter.call_function('func_test1', 12, 23)
    assert v1 == 35



# Generated at 2022-06-22 09:02:29.081288
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter



# Generated at 2022-06-22 09:02:34.264807
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function(){
            var n;
        }'''
    extr = JSInterpreter(code)
    f = extr.extract_function('n')
    print(f)


# Generated at 2022-06-22 09:02:43.018116
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code1 = '''
    hd_src = '';
    '''
    code2 = """
    var s = {
      'length': 5,
      '0': 'h',
      '1': 'd'
    };
    """
    code3 = '''
    function swap(a,b) {
      var c = a[0];
      a[0] = b[0];
      b[0] = c;
    }
    '''
    code4 = '''
    (function(){
      var a=[];
      for (var i=0; i < s.length; i += 2) {
        a.push(s[i]);
      }
    })()
    '''

# Generated at 2022-06-22 09:02:51.817376
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    test_code = '''
        var a = {
            "b": function(p){return function(q){return p+q;}},
            "c": function(p){return p*p;}
        }
        var d = 1;
        var e = 2;
        return a.b(d)(e)+a.c(e);
    '''
    v, abort = JSInterpreter(test_code).interpret_statement(test_code, {})
    assert v == 6
    assert abort == True
    print ("test_JSInterpreter_interpret_statement() passed.")

# unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:03:01.357006
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:03:05.646161
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test interpret_expression
    js_code = """
        var c = 1234;
        var d = [5,6];
        var e = [5,6, [7,8]];
        var f = {
            'a': 'b',
            'c': function(x) {return x}
        };
        function g(x,y) {
            var z = x+y;
            return z;
        }
        function h(x,y) {
            return x*y;
        }
        window.i = "test";
    """
    jsinter = JSInterpreter(js_code)
    # Test simple variable
    assert jsinter.interpret_expression("c", {}) == 1234
    # Test variable with index
    assert jsinter.interpret_expression("d[1]", {}) == 6

# Generated at 2022-06-22 09:03:10.758660
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsInterpreter = JSInterpreter('')
    lst = [0, 1]
    method_res_true = jsInterpreter.interpret_statement('lst[0]++', locals()) == (1, False)
    method_res_false = jsInterpreter.interpret_statement('lst[0]++', locals()) == (1, False)
    return method_res_true and method_res_false


# Generated at 2022-06-22 09:03:21.476060
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter("""
    var xyzabc_0={"a":1,"b":"2"};
    var xyzabc_1={"a":[1,2,3,4],"b":"2"};
    var xyzabc_2={"a":[1,2,3,4],"b":"2","c":{"d":5,"e":6}};

    """)
    test_js = """
    var y = xyzabc_0.a + xyzabc_1.a[2];
    var z = xyzabc_2.c.d + xyzabc_2.c.e;

    """
    local_vars = {}
    for line in test_js.split('\n'):
        line = line.strip()
        if not line:
            continue

# Generated at 2022-06-22 09:04:05.693288
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = JSInterpreter('''
    window.WH = window.WH || {};
    WH.whvid = {
        // [snipped]
        hasH264Support: function() {
            function hasH264Support() {
                var v = document.createElement('video');
                return !!(v.canPlayType && v.canPlayType('video/mp4; codecs="avc1.42E01E, mp4a.40.2"').replace(/no/, ''));
            }

            return hasH264Support();
        },

        // [snipped]
        getVideoInfo: function(v) {
            return {
                // [snipped]
            }
        }
    };
    ''')

# Generated at 2022-06-22 09:04:13.541009
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    import unittest

    class JSInterpreterTest(unittest.TestCase):
        def setUp(self):
            self.j = JSInterpreter('', {'a': [2, 3, 4], 'b': 2})

        def test_simple_expressions(self):
            self.assertEqual(self.j.interpret_statement('var g = 5;', {}), (5, False))
            self.assertEqual(self.j.interpret_statement('return a;', {}), ([2, 3, 4], True))
            self.assertEqual(self.j.interpret_statement('return a; g = 5;', {}), ([2, 3, 4], True))
            self.assertEqual(self.j.interpret_statement('var g = 5; return g;', {}), (5, True))


# Generated at 2022-06-22 09:04:20.202069
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var obj = {
            "f": function(name, val) {
                return name + "=" + val;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    assert len(interpreter._functions) == 0
    assert len(interpreter._objects) == 1
    assert interpreter._objects['obj']['f']('test', 'value') == 'test=value'

# Generated at 2022-06-22 09:04:30.726601
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsInterpreter = JSInterpreter('')
    # similiar to interpret_expression
    local_vars = {'a': 2, 'b': 3}
    stmt = 'a+b'
    res = jsInterpreter.interpret_statement(stmt, local_vars)
    assert res[0] == 5
    stmt = 'var c = a+b'
    res = jsInterpreter.interpret_statement(stmt, local_vars)
    assert res[0] == 5
    assert local_vars['c'] == 5
    stmt = 'var d = a*b'
    res = jsInterpreter.interpret_statement(stmt, local_vars)
    assert res[0] == 6
    assert local_vars['d'] == 6

# Generated at 2022-06-22 09:04:38.973396
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = """
        var a = {
            b: function() {
                return 1;
            },
            c: 2,
            "d": function() {
                return 3;
            },
            'e': function() {
                return 4;
            },
            'f': function(x, y) {
                return x + y;
            },
        };
        a.c = 3;
    """
    interpreter = JSInterpreter(js_code)
    obj = interpreter.extract_object('a')
    assert obj['b']() == 1
    assert obj['c'] == 3
    assert obj['d']() == 3
    assert obj['e']() == 4
    assert obj['f'](1, 2) == 3


# Generated at 2022-06-22 09:04:42.849807
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = """
    function a(a, b) {
        var c = b;
        return a + c;
    }
    function b(a, b) {
        return a + a + b;
    }
    var b = {'0': a, '1': b};
    """
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('a', 1, 2) == 3
    assert interpreter.call_function('b', 1, 2) == 4
    assert interpreter.call_function('b', 1, 3) == 5

# Generated at 2022-06-22 09:04:52.088805
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = r'''
        // Some comment
        (function(hello) {
            var a = function() { return 3; };
            var b = {
                x: function(y) { return y + 1; }
            }
            var ccc = function() {
                return a() + b.x(hello);
            }
            return ccc();
        })'''
    js_interpreter = JSInterpreter(js_code)
    f = js_interpreter.extract_function('ccc')
    assert f((1,)) == 5


if __name__ == '__main__':
    test_JSInterpreter_extract_function()

# Generated at 2022-06-22 09:04:58.887517
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = '''
        var a={
            b: function(p){
                var o = {a:p};
                return o;
            },
            c: function(p){
                var o = {a:p, b:2};
                return o;
            }
        };

        a.d = function(p){
            var o = {a:p};
            return o.a;
        };
        '''
    b = {}
    a = JSInterpreter(js, b)

    res = a.extract_object('a')

    assert 'b' in res
    # Test that a is not a reference to b
    assert res != b
    assert res['b'] != b['b']
    assert res['b']({'a': 1}) == {'a': 1}
    assert res['b']

# Generated at 2022-06-22 09:05:03.980366
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('var ab = {a:1, b:2}',
                        objects={"_a": [1], "ab": [2], "_c": {'d': 3, 'e': 4}})
    assert jsi.interpret_expression('_a + 1', {'_a': 1}) == 2
    assert jsi.interpret_expression('ab[1]', {}) == 2
    assert jsi.interpret_expression('"4"[0]', {}) == '4'
    assert jsi.interpret_expression('_c.d', {}) == 3
    assert jsi.interpret_expression('"x" + 1', {}) == 'x1'
    assert jsi.interpret_expression('a', {'a': 2, 'b': 1}) == 2

# Generated at 2022-06-22 09:05:14.547120
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter('', {})
    argnames = ['kl', 'kh', 'gl', 'gh']

# Generated at 2022-06-22 09:05:43.517863
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test 1
    test_expr = ''
    exp_result = None
    js_interpreter = JSInterpreter(code='')
    assert js_interpreter.interpret_expression(
        test_expr, local_vars={}, allow_recursion=100) == exp_result
    # Test 2
    test_expr = '1'
    exp_result = 1
    assert js_interpreter.interpret_expression(
        test_expr, local_vars={}, allow_recursion=100) == exp_result
    # Test 3
    test_expr = '"1"'
    exp_result = '1'
    assert js_interpreter.interpret_expression(
        test_expr, local_vars={}, allow_recursion=100) == exp_result
    # Test 4

# Generated at 2022-06-22 09:05:53.501406
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # test when function name is not in escaped form
    code = """
    var f = function(a, b) { return a + b; };
    """
    js = JSInterpreter(code)
    f = js.extract_function('f')
    assert f((1, 2)) == 3

    # test when function name is in escaped form
    code = """
    var f = function(a, b) { return a + b; };
    """
    js = JSInterpreter(code)
    f = js.extract_function('f')
    assert f((1, 2)) == 3

    # test when function is nested

# Generated at 2022-06-22 09:06:02.694493
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print('#test_JSInterpreter_interpret_expression')
    sample = {}
    sample['b'] = 0
    sample['c'] = 1
    sample['d'] = 4
    sample['e'] = []
    sample['e.f'] = 1
    sample['e.f.g'] = 2
    sample['e.f.g.h'] = 3
    sample['e.f.g.h[1]'] = 4
    sample['e.f.g.h[2]'] = 5
    sample['e.f.g.h.length'] = 3

    for var in sample:
        print('expr: %s' % var)
        expr = var
        js = JSInterpreter('', sample)
        print('  res: %s' % js.interpret_expression(expr, {}))

# Generated at 2022-06-22 09:06:06.648524
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    test_JSInterpreter_code = """
        var myFunc = function(a){
            return a;
        }
    """
    jsi = JSInterpreter(test_JSInterpreter_code)
    assert jsi.call_function('myFunc', 0) == 0
    assert jsi.call_function('myFunc', 1) == 1

# Generated at 2022-06-22 09:06:17.682540
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        var abc = function(a,b) { return true; };
        function def(a,b) {
            return a + b;
        }
        var xyz = function(a,b) {
            return function(c,d) {
                return a + b + c + d;
            };
        };
        var pqr = {"foo": function(a,b) { return a + b; }};
    """
    i = JSInterpreter(code)
    f = i.extract_function('def')
    assert (f((1, 2)) == 3)
    f = i.extract_function('xyz')
    assert (f((1, 2))(3, 4) == 10)
    f = i.extract_function('abc')

# Generated at 2022-06-22 09:06:28.072999
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code="""
    function decode(data) {
        var lines = data.split("\n");
        var re = /^\s*([a-zA-Z0-9$_]+)\s*=\s*(.+?)\s*$/;
        for (var i = 0; i < lines.length; i++) {
            var match = re.exec(lines[i]);
            if (match) {
                lines[i] = "this." + lines[i];
            }
        }
        data = lines.join("\n");
        return eval(data);
    }
    """
    assert JSInterpreter(code).extract_function("decode")

if __name__ == '__main__':
    import sys
    test_JSInterpreter_extract_function()

# Generated at 2022-06-22 09:06:41.201610
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    from .utils import urlhandle_detect_extractor

    def test_url(url, expected_funcname=None, expected_args=None, expected_code=None):
        for ie in urlhandle_detect_extractor(url):
            obj = ie.js_to_json(url)
            if not obj:
                continue
            obj_m = re.search(r'(?:["\']signature["\']\s*:\s*|\.sig\s*|\.signature\s*=|signature\s*=|.)([a-zA-Z0-9$]+)\(', obj)
            if not obj_m:
                continue
            funcname = obj_m.group(1)
            f = ie._js_helpers.extract_function(funcname)
            code = f.__

# Generated at 2022-06-22 09:06:51.312601
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    """Unit test for constructor of class JSInterpreter
    """

# Generated at 2022-06-22 09:06:55.805132
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''
        a = 1; b = 2; c = 3;
        var x = a + b * (4 / c);
        return x;
        return y;
    '''
    interp = JSInterpreter(code)
    res, abort = interp.interpret_statement(
        code.strip().split('\n')[-1], locals())
    assert res == 1 + 2 * (4 / 3)
    assert abort


# Generated at 2022-06-22 09:07:04.328567
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert  JSInterpreter("").build_function(("var1","var2"), "var1 + var2;")([1, 2]) == 3
    assert  JSInterpreter("").build_function(("var1","var2"), "return var1 + var2;")([1, 2]) == 3
    assert  JSInterpreter("").build_function(("var1","var2"), "var3 = var1 + var2; return var3")([1, 2]) == 3
    assert  JSInterpreter("").build_function(("var1","var2"), "var3 = var1 + var2; return var3;")([1, 2]) == 3

# Generated at 2022-06-22 09:07:41.939870
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('var x').interpret_expression('x', {}, 100) == None
    assert JSInterpreter('var x=1').interpret_expression('x', {}, 100) == 1
    assert JSInterpreter('var x=1').interpret_expression('1', {}, 100) == 1

    assert JSInterpreter('var x').interpret_expression('x=1', {}, 100) == 1
    assert JSInterpreter('var x=1').interpret_expression('x=2', {}, 100) == 2

    assert JSInterpreter('var x=1,y=2').interpret_expression('x+y', {}, 100) == 3
    assert JSInterpreter('var x=1,y=2').interpret_expression('x-y', {}, 100) == -1

# Generated at 2022-06-22 09:07:50.817970
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_function = 'function test(a,b,c) { return function(x,y) {return x + y;}(a,b) + c; }'
    js_function2 = 'function test2(a,b,c) {return a.length + b.length + c.length; }'
    js_function3 = 'function test3(x,y) { return x + y; }'
    js_function4 = 'function test4() { return 5; }'
    js = js_function + js_function2 + js_function3 + js_function4
    interpreter = JSInterpreter(js)

    # method extract_function
    func = interpreter.extract_function('test')
    func2 = interpreter.extract_function('test2')
    func3 = interpreter.extract_function('test3')


# Generated at 2022-06-22 09:07:54.955323
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var abc = {
            "def": function(arg) {
                return arg*3;
            },
            "foo": "bar",
            "baz": 2
        };
    '''
    obj = JSInterpreter(code)
    assert obj.extract_object('abc')["def"](3) == 9



# Generated at 2022-06-22 09:08:03.139405
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('function aa(a,b){return b;}\
                                                    function bb(a){return a.split("").reverse().join("");}')
    assert js_interpreter.interpret_expression('aa(bb("abc"), 3)',{}) == 3
    assert js_interpreter.interpret_expression('ab(bb("abc"), 3)',{}) == None

if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-22 09:08:10.679599
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
    function decode(s) {
        var t = "";
        for (var i = 0; i < s.length; i++) {
            t += String.fromCharCode(
                s.charCodeAt(i) - s.length);
        }
        return t
    }
    """

    jsi = JSInterpreter(code)
    assert jsi.call_function('decode', "7z1(6y9V4)4*4") == "hoge"


# Generated at 2022-06-22 09:08:16.851213
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = """
        var obj = {
            f1: function(a, b) {
                return a + b;
            },
            f2: function(a) {
                return -a;
            }
        };
    """
    interp = JSInterpreter(code=js)
    obj = interp.extract_object("obj")
    assert callable(obj["f1"])
    assert callable(obj["f2"])
    assert obj["f1"]("ciao", "miao") == "ciaomiao"
    assert obj["f2"]("miao") == "-miao"


# Generated at 2022-06-22 09:08:26.180778
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = """
        function f1(arg1, arg2, arg3) {
            var g = function() {
                return arg1;
            }
            if (arg3 > 2)
                return g() + arg2;
            else
                return g() - arg2;
        }
        """
    js_interpreter = JSInterpreter(code)
    f1 = js_interpreter.extract_function("f1")
    assert f1((1, 2, 3)) == 3

if __name__ == '__main__':
    test_JSInterpreter_interpret_statement()

# Generated at 2022-06-22 09:08:36.822435
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:08:47.082850
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    obj = {
        'a': {
            'b': [1, 2, 3],
            'c': lambda x: x,
        },
        'd': {
            'e': lambda x, y: x * y,
            'f': lambda x, y: x + y,
        },
        'g': lambda x, y, z: x + y + z,
        'h': lambda x: x,
    }
    ji = JSInterpreter('')
    ji._objects = obj

# Generated at 2022-06-22 09:08:54.826486
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter("function a(a, b) {var x; x = a; x = b; return x;}")
    assert 40 == interpreter.build_function("a,b".split(","), "var x; x = a; x = b; return x;")(["30","40"])


# Unit tests for method interpret_expression of class JSInterpreter