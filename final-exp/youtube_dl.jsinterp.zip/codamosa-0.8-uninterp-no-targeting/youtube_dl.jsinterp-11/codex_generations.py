

# Generated at 2022-06-22 09:00:52.835733
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter("x='abc';abc=x.") is not None


# Generated at 2022-06-22 09:01:03.552916
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter('')
    local_vars = {
        'a': 1,
        'b': 2,
        'c': 3,
        'j': 4,
        'k': 5,
        'l': 6,
    }
    # Test assignment
    js.interpret_statement('a=2', local_vars)
    assert local_vars['a'] == 2
    # Test calculation
    assert js.interpret_statement('a=b+c', local_vars)[0] == 5
    # Test if-else
    js.interpret_statement('if(a>b){j=k}else{l=k}', local_vars)
    assert local_vars['j'] == 5
    # Test return
    assert js.interpret_statement('return 1', local_vars)[0]

# Generated at 2022-06-22 09:01:13.583309
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    obj = { 'abc': 123, 'xyz': 789 }

    def test_func(param1, param2):
        res = param1 + param2
        return res

    js = '''
        var func1 = function (param1, param2) {
            var abc = 123;
            var xyz = 789;
            return param1 + param2;
        };
        var func2 = function (param1, param2, param3) {
            var def = 456;
            return param1 + param2 + param3
        };
    '''
    js_interpreter = JSInterpreter(js, objects=obj)
    assert js_interpreter.extract_function('func1')(1, 2) == 3

# Generated at 2022-06-22 09:01:24.514931
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:01:35.070763
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:01:45.959009
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''function o(a){if(!a||"object"!=typeof a)return[];var c=[],d=[];for(var e in a)null!=Object.prototype[e]&&d.push(e);for(;;){var e=d.shift(),b;if(b=null!=e)b=e in a,b=!b||null==a[e]||"object"!=typeof a[e];if(b)break;c.push(e);try{for(var f in a[e])d.push(e+"."+f)}catch(g){}}}return o({"9d5d5c":16,"abcd":5})'''
    js_interpreter = JSInterpreter(js_code)

# Generated at 2022-06-22 09:01:52.769114
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    interpreter = JSInterpreter('''
        function test(a, b) {
            return a + b;
        }
        var object = {
            field: 'value'
        };
        var object2 = {
            method: function(a, b) {
                return a + b;
            }
        };
        var object3 = {
            method: function(a, b) {
                return a + b;
            },
            method2: function(a) {
                return a * a;
            }
        };
        object.method = function(a, b) {
            return a * b;
        };
    ''')
    assert interpreter.call_function('test', 2, 3) == 5

# Generated at 2022-06-22 09:01:57.874807
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    from pytube import JSInterpreter as JSI
    jsi = JSI('')
    # Warning: difficult to test
    jsi.build_function(['a', 'b', 'c'], 'return a + b * c;')
    return


# Generated at 2022-06-22 09:02:08.642700
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsint = JSInterpreter('')
    assert jsint.interpret_statement('var x = 4;', {}, 100)[0] == 4
    assert jsint.interpret_statement('return x;', {'x': 1}, 100)[0] == 1

    # It is not possible to parse js expressions, so use json instead
    assert jsint.interpret_statement('var x = { "a": 1, "b": 2 };', {}, 100)[0] == { "a": 1, "b": 2 }
    assert jsint.interpret_statement('return x[y];', {'x': { "a": 1, "b": 2 }, "y": "b"}, 100)[0] == 2

# Generated at 2022-06-22 09:02:19.052923
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:03:01.996710
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(str) {
            return str.length;
        }
    '''
    js_code2 = '''
        var test = function(str) {
            return str.length;
        }
    '''
    js_code3 = '''
        var a = function(str) {
            return str.length;
        }
        a("");
    '''
    js_code4 = '''
        var a = {"hello": function(str) {
            return str.length;
        }};
        a.hello("");
    '''
    js_code5 = '''
        var a = {hello: function(str) {
            return str.length;
        }};
        a.hello("");
    '''

# Generated at 2022-06-22 09:03:11.784882
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interp = JSInterpreter(code="var m;var n=1;var a=2;var b=2;var c=2;var d=2;var f=2;var g=2;var h=3;return h;")
    assert interp.interpret_statement("h", {})[0] == 3
    assert interp.interpret_statement("c=a+b", {})[0] == 4
    assert interp.interpret_statement("m=a+b", {})[0] == 4
    assert interp.interpret_statement("return h", {})[0] == 3
    assert interp.interpret_statement("d=a+b", {})[0] == 4
    assert interp.interpret_statement("return a+b", {})[0] == 4

# Generated at 2022-06-22 09:03:14.049574
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter(None).code == None
    assert JSInterpreter(None, None)._objects == {}



# Generated at 2022-06-22 09:03:15.541011
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter('function abc(a){a+1;}') is not None

# Generated at 2022-06-22 09:03:27.775533
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = (
        'function myFunc(a, b) {'
        '   var c = a + b;'
        '   return c;'
        '}'
    )
    js = JSInterpreter(code)
    func = js.extract_function('myFunc')
    assert func((1, 2)) == 3
    assert func(('hello ', 'world')) == 'hello world'

    code = (
        'function myFunc(a, b) {'
        '   var c = ["a", "b", "c"];'
        '   var d = c[a + 1];'
        '   var e = d.split("");'
        '   e.reverse();'
        '   return e.join("");'
        '}'
    )
    js = JSInterpre

# Generated at 2022-06-22 09:03:34.469616
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
    hello = function(name) {
        return "Hello " + name + "!";
    }
    '''
    js = JSInterpreter(js_code)
    assert js.call_function('hello', 'JSInterpreter') == 'Hello JSInterpreter!', (
        'JSInterpreter.call_function() failed')


# Generated at 2022-06-22 09:03:46.102756
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    global_vars = {}
    local_vars = {'a': 1, 'b': 2, 'c': [1, 2, 3], 'd': 'abcde'}
    expression = 'a==1'
    code = 'var a = 1;'
    js = JSInterpreter(code, global_vars)
    assert js.interpret_expression(expression, local_vars, 100)

    expression = 'a+b'
    assert js.interpret_expression(expression, local_vars, 100) == 3

    expression = 'a == 1 && b == 2 || b == 1'
    assert js.interpret_expression(expression, local_vars, 100)

    expression = 'c[b] == 3 && c[0] == 1'
    assert js.interpret_expression(expression, local_vars, 100)



# Generated at 2022-06-22 09:03:50.993254
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = r'''
        function a(b, c, d) {
            e = function(a) {
                return a
            };
            return e(c);
        }
        '''
    jsi = JSInterpreter(code)
    fun = jsi.extract_function('a')
    assert fun((1, 2, 3)) == 2

# Generated at 2022-06-22 09:04:01.966957
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    jsInterpreter = JSInterpreter(
        "this.model_main_0_0=function(a,b){return a.split(\"\").reverse().join(\"\")}",
        objects={"args": ['abcdefg', 'hijklmn']})
    assert jsInterpreter.call_function('model_main_0_0', *jsInterpreter._objects["args"]) == 'gnirtsabcdefg'

    # test split and join
    jsInterpreter2 = JSInterpreter(
        'this.reverse = function(s){return s.split("").reverse().join("")};',
        objects={'s': 'abcdefg'})
    assert jsInterpreter2.call_function('reverse', *jsInterpreter2._objects['s']) == 'gfedcba'

    #

# Generated at 2022-06-22 09:04:09.872992
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    #Test 1: simple test without function call
    test_statement = "a = 3; b = 4; c = a + b"
    interpreter = JSInterpreter(code="")
    local_vars = {}
    for stmt in test_statement.split(";"):
        res, abort = interpreter.interpret_statement(stmt, local_vars)
    assert local_vars["a"] == 3 and local_vars["b"] == 4 and local_vars["c"] == 7

    #Test 2: simple test with function call
    test_statement = "a = 3; b = 4; c = a + b; d = c*2 + a"
    interpreter = JSInterpreter(code="")
    local_vars = {}

# Generated at 2022-06-22 09:04:34.830788
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:04:44.646145
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter('')
    assert interpreter.interpret_statement('a = 0', {}) == (0, False)
    assert interpreter.interpret_statement('a = "HELLO"', {}) == ('HELLO', False)
    assert interpreter.interpret_statement('a = 0; b = "HELLO"', {}) == ('HELLO', False)
    assert interpreter.interpret_statement('a = 0; b = "HELLO"; c = 0', {}) == (0, False)
    assert interpreter.interpret_statement('a = 0; return "HELLO"', {}) == ('HELLO', True)
    assert interpreter.interpret_statement('a = 0; b = "HELLO"; return "WORLD"', {}) == ('WORLD', True)
    interpreter = JSInterpreter('')
   

# Generated at 2022-06-22 09:04:54.834819
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var a = 10;
        var b = 20;
        var arr = [2, 3, 4];
        var myfun = function(x) {
            return x * (a + b);
        };
        var myobj = {
            _a: b,
            f1: function(x, y) {
                return x * y + this._a;
            },
            f2: function() {
                return this._a * 2;
            }
        };
        var main = function() {
            return myfun(a) - myobj.f1(arr[1], arr[2]) - myobj.f2();
        };
    '''
    js = JSInterpreter(code)
    assert js.interpret_expression('1 + 1', {}) == 2
    assert js.interpret_expression

# Generated at 2022-06-22 09:05:01.754166
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
	interpreter_1=JSInterpreter("var a=2, b=3;", objects={})
	res1, res2=interpreter_1.interpret_statement("a=b+2", {'a':2, 'b':3}, 100)
	print(res1)
	print(res2)


# Generated at 2022-06-22 09:05:10.867769
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('a = 0', {})
    assert js_interpreter.interpret_statement('a = 1', js_interpreter._objects, allow_recursion=100)[0] == 1
    assert js_interpreter.interpret_statement('a += 1', js_interpreter._objects, allow_recursion=100)[0] == 2
    assert js_interpreter.interpret_statement('a -= 1', js_interpreter._objects, allow_recursion=100)[0] == 1
    assert js_interpreter.interpret_statement('a *= 2', js_interpreter._objects, allow_recursion=100)[0] == 2

# Generated at 2022-06-22 09:05:14.834420
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = JSInterpreter(
        'function abc(a, b, c) { return a + b + c; }')
    assert js.extract_function('abc')((1, 2, 3)) == 6


# Generated at 2022-06-22 09:05:24.674553
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:05:34.147512
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:05:41.752135
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = r'''
        a = 5, b = 6, c = 7;
        hello = function(x) {
            return x * 5;
        };
        hello2 = function(x, y) {
            var m = x * y;
            return m;
        }
        '''
    js = JSInterpreter(code)
    assert js.call_function('hello', 5) == 25
    assert js.call_function('hello2', 5, 2) == 10


# Generated at 2022-06-22 09:05:48.541680
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = """
    a = {a: function(x) {return x * 2}};
    b = {
        "b": function(x) {
            return x * 3;
        }
    };
    """
    interpreter = JSInterpreter(js_code)
    assert interpreter.extract_object("a") == {"a": lambda x: x * 2}
    assert interpreter.extract_object("b") == {"b": lambda x: x * 3}


# Generated at 2022-06-22 09:06:07.345018
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Create an interpreter
    code = '''
        (function(){
            var a = "a";
            var b = "b";
            var c = function(x,y){return "" + x + "-" + y + "-";};
            return c(a,b) + c(b,a);
        })();
    '''
    jsi = JSInterpreter(code)
    # call the interpret_expression method
    expr = 'c("a","b") + c("b","a")'
    local_vars = {}
    allow_recursion = 100
    assert jsi.interpret_expression(expr, local_vars, allow_recursion) == "a-b-b-a-"

if __name__ == "__main__":
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-22 09:06:19.633332
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interp = JSInterpreter('')

    # Test case 1
    stmt = 'var a = 3, b = 4;'
    local_vars = {}
    res, should_abort = interp.interpret_statement(stmt, local_vars)
    assert res is None
    assert should_abort is False
    assert local_vars['a'] == 3
    assert local_vars['b'] == 4

    # Test case 2
    stmt = 'var a = 3; return this.a + 1;'
    local_vars = {'a': 2}
    res, should_abort = interp.interpret_statement(stmt, local_vars)
    assert res == 4
    assert should_abort is True

    # Test case 3
    stmt = 'var a = 3'


# Generated at 2022-06-22 09:06:25.343696
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    a = JSInterpreter("""
        var a = 0;
        var b = function(arg1, arg2) {
            var c = arg1 + arg2;
            return c;
        }
        var d = function () {
            var i;
            for (i = 1; i < 10; i++) {
                b = i * 5;
                return b;
            }
        }
        var e = {
            'c': 3,
            'f': function(arg) {
                return arg;
            }
        }
    """)
    assert (a.call_function('b', 1, 2) == 3)
    assert (a.interpret_statement('d()', {})[0] == 5)
    assert (a.interpret_statement('e.f(88)', {})[0] == 88)
   

# Generated at 2022-06-22 09:06:29.301002
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interp = JSInterpreter("")
    assert interp.interpret_expression("1+1", {}, 100) == 2
    assert interp.interpret_expression("1+1", {}, 100) == 2
    assert interp.interpret_expression(
        "(function(){return 'a';})()", {}, 100) == 'a'
    assert interp.interpret_expression(
        "Number('1')", {}, 100) == 1

# Generated at 2022-06-22 09:06:37.904478
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    local_vars = dict(zip(['abc', 'def'], [123, 456]))
    js_interpreter = JSInterpreter('', {})

    def resf(args):
        local_vars = dict(zip(['abc', 'def'], [123, 456]))
        for stmt in args[0].split(';'):
            res, abort = js_interpreter.interpret_statement(stmt, local_vars)
            if abort:
                break
        return res
    assert resf == js_interpreter.build_function(['abc', 'def'], "abc * def")

# Generated at 2022-06-22 09:06:49.584843
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    content = 'this.html5media.MIXED_PLAYER_JS = {volume:function(e){return zb(e)},pan:function(e){return eb(e)},mute:function(e){return e},loop:function(e){return e},source:function(e){return e}};'
    js = JSInterpreter(content)
    m = js.extract_object('html5media.MIXED_PLAYER_JS')


# Generated at 2022-06-22 09:06:53.344699
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
        function func(args) {
            var a = 1;
            var b = 2;
            return a + b;
        }
    '''
    interp = JSInterpreter(js_code)
    func = interp.extract_function('func')

    assert func(()) == 3


# Generated at 2022-06-22 09:06:59.580599
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    interp = JSInterpreter('''
        a = {
            x: function(a){return a*2},
            y: function(a){return a+3},
        };
        b = {
            z: function z(a) {return a+4},
        };
    ''')
    res = interp.extract_object('a')

    # Invoke method
    assert res['x'](2) == 4
    assert res['y'](2) == 5
    assert res.get('z') is None

    # Modify object
    res['y'] = res['x']
    assert res['y'](2) == 4

    # Try with a different object
    res = interp.extract_object('b')
    assert res['z'](3) == 7


# Generated at 2022-06-22 09:07:11.816781
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = '''
        function qswfv2(raw_args) {
            var args = {};
            for (var i = 0; i < raw_args.length; i++) {
                var arg = raw_args[i];
                if (arg.indexOf('--') == 0) {
                    var keyval = arg.slice(2).split('=');
                    var key = keyval[0];
                    var val = keyval[1];
                    val = val || "true";
                    args[key] = val;
                }
            }
            return args;
        }'''

    local_vars = {'raw_args': ['--a=1', '--b=2', '--c']}
    interpreter = JSInterpreter(js_code)

# Generated at 2022-06-22 09:07:23.723529
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:07:42.491718
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinter = JSInterpreter('')
    def js_func(arg1, arg2):
        return arg1 + arg2
    for i in range(1, 1000):
        assert jsinter.build_function(('arg1', 'arg2'), 'return arg1 + arg2')((i, i)) == i * 2

# Generated at 2022-06-22 09:07:53.120751
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:08:02.165615
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
    var reverse = function(input) {
        input = input.split('');
        var ret = [];
        for (var i = input.length - 1; i >= 0; i--) {
            ret.push(input[i]);
        }
        return ret.join('');
    };'''

    js_interpreter = JSInterpreter(code)
    result = js_interpreter.call_function('reverse', 'abcde')
    assert result == 'edcba'

# Generated at 2022-06-22 09:08:13.465327
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-22 09:08:19.812914
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsInterpreter = JSInterpreter('''
    var abc = "abc";
    var a = [abc, abc];
    var b = {"abc": [1, 2, 3, 4]};
    return a[0];
    return b["abc"][1];
    var idx = 2;
    return b["abc"][idx];
    var c = {"foo": function (a, b) { return a + b; }};
    return c.foo(2, 3);
    var d = [1,2,3,4];
    d.splice(0,3);
    return d;
    return d.join(",");
    ''')
    assert jsInterpreter.interpret_statement('var a = 1', {})[0] == 1

# Generated at 2022-06-22 09:08:28.392129
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    program = '''
        function func(a,b,c) {
            e = (true && false) || true;
            x = a + b + c;
            y = ((((3-1))));
            z = a << 2;
            z = z >> 2;
            z = z % 35;
            z = z / 2;
            return e + x + y + z;
        }
        '''
    inter = JSInterpreter(program)
    assert inter.call_function('func', 2,3,4) == (1+2+3+4+2)
    # try:
    #     inter.call_function('func', 1,2,3,-4)
    #     assert(0)
    # except:
    #     assert(1)
    return 'test_JSInterpreter passed'



# Generated at 2022-06-22 09:08:36.868142
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """var a = 0;
    var b = 5;
    var c = 0;
    var d = function(x, y) {
        return 5 * x + y;
    };
    d(2, 3);
    """
    js = JSInterpreter(code)
    assert js.interpret_expression('a', dict()) == 0
    assert js.interpret_expression('a + 1', dict()) == 1
    assert js.interpret_expression('a + b', dict()) == 5
    assert js.interpret_expression('a++ + b', dict()) == 5
    assert js.interpret_expression('b++', dict()) == 5
    assert js.interpret_expression('a + b', dict()) == 6
    assert js.interpret_expression('b', dict()) == 6
    assert js.interpret_expression('b + c', dict())

# Generated at 2022-06-22 09:08:46.692199
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = '''
        var a = [0, 1, 2];
        var b = {
            c: [3, 4, 5],
            a: 6,
            f: function(x) { return x * x; }
        };
        function g(x, y) {
            return x + y;
        }
    '''
    interp = JSInterpreter(js_code)
    # Test simple operations
    assert interp.interpret_expression(' 100  ', {}, 100) == 100
    assert interp.interpret_expression('1 + 2', {}, 100) == 3
    assert interp.interpret_expression('1 + 2 * 3', {}, 100) == 7
    assert interp.interpret_expression('(1 + 2) * 3', {}, 100) == 9
    # Test variables
    assert interp

# Generated at 2022-06-22 09:08:58.229431
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_code = '''
    var a = 5;
    var b = 3;
    var c;
    c = a + b * 11;

    var d = function(p){
        return p * 2;
    };

    var e = d(c + 4) + d(3);

    var f = function(p){
        return function(q){
            return p + q;
        }
    };

    var g = f(1);
    var h = g(e);
    '''

    i = JSInterpreter(js_code)
    assert i.interpret_statement('', {}) == (None, False)
    assert i.interpret_statement('var a = 5;', {}) == (5, False)
    assert i.interpret_statement('return 5;', {}) == (5, True)
   

# Generated at 2022-06-22 09:09:10.480011
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test case 1
    jsi = JSInterpreter('var a = 10;')
    local_vars = {}
    res, abort = jsi.interpret_statement('var a = 10;', local_vars)
    assert res == 10
    assert local_vars['a'] == 10

    # Test case 2
    jsi = JSInterpreter('var a = 10;')
    local_vars = {}
    res, abort = jsi.interpret_statement('var a = b - 1;', local_vars)
    assert res == 9
    assert local_vars['a'] == 9

    # Test case 3
    jsi = JSInterpreter('var a = 10;')
    local_vars = {}

# Generated at 2022-06-22 09:09:26.954860
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        var res = [];
        while (el = els.pop()) {
            res.push(el);
        }
        return res;
    '''
    assert(JSInterpreter(js_code).call_function('', [1, 2, 3]) == [1, 2, 3])


# Generated at 2022-06-22 09:09:36.336608
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''\
function test(a,b) {
    var c = a + b;
    var d = (a + b).toString();
    var e = d + ', or not';
    return {a: c, b: d, c: e};
}
function fact(x, y) {
    return x * y + 2;
}
fact(4, fact(3, fact(2, fact(1, fact(0, 1)))));
'''
    inter = JSInterpreter(code)
    assert inter.extract_function('test')(('hello', 'world')) == {'a': 'helloworld', 'b': 'helloworld', 'c': 'helloworld, or not'}
    assert inter.call_function('fact', 4, 30) == 5 * 30 + 2
    assert inter

# Generated at 2022-06-22 09:09:43.821167
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = '''
        function func1(arg1) { return arg1 }
        function func2(arg1, arg2) { return arg1 + arg2 }
        var fun3 = function(arg1, arg2) { return arg1 - arg2 }
        var fun4 = function() { return 1 + 2 }
        tv_player.func5 = function(arg1) { return 1 + 2 }
    '''

    js_interpreter = JSInterpreter(js)

    assert js_interpreter.extract_function('func1')([1]) == 1
    assert js_interpreter.extract_function('func2')([1, 2]) == 3
    assert js_interpreter.extract_function('fun3')([1, 2]) == -1
    assert js_interpreter.extract

# Generated at 2022-06-22 09:09:53.612765
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:10:03.928087
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    # We test this code:
    #   var a = {
    #       "b": function(p) {
    #           return function(q) {
    #               return function(r) {
    #                   return p + q + r;
    #               };
    #           };
    #       }
    #   };
    #   var f = a.b;
    #   var g = f(1);
    #   var h = g(2);
    #   var i = h(3);

    code = 'var a={\"b\":function(p){return function(q){return function(r){return p+q+r}}}};var f=a.b;var g=f(1);var h=g(2);var i=h(3);'
    jsi = JSInterpreter(code)
   

# Generated at 2022-06-22 09:10:09.588030
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Given
    interpreter = JSInterpreter('''
        function a(arg) {
            var b = arg;
            return b / 2;
        }
        ''')

    # When and then
    assert (interpreter.build_function(['arg'], 'var b = arg; return b / 2;')
            (['2'])) == 1
