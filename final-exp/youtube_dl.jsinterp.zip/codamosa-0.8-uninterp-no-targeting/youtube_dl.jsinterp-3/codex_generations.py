

# Generated at 2022-06-22 09:01:19.863812
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:01:33.445539
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    def _extract_object():
        obj = {
            'a': 1,
            'b': 2,
            'c': 'c',
            'func': lambda x, y: x+y,
        }
        print("obj['a']: ", obj['a']) # 1
        print("obj['c']: ", obj['c']) # c
        print("obj['func'](1, 2): ", obj['func'](1, 2)) # 3
        print("obj['a']['b']: ", obj['a']['b']) # raise Exception
    _extract_object_code = _extract_object.__code__.co_consts[1]

    class MockJSInterpreter(JSInterpreter):
        def __init__(self):
            pass


# Generated at 2022-06-22 09:01:44.117691
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    assert ( JSInterpreter('var a={"a":{"a":{"a":{"a":"b"}}}}').call_function('a') == {"a":{"a":{"a":"b"}}} )
    assert ( JSInterpreter('var a={"a":{"a":{"a":{"a":"b"}}}}').call_function('a.a') == {"a":{"a":"b"}} )
    assert ( JSInterpreter('var a={"a":{"a":{"a":{"a":"b"}}}}').call_function('a.a.a') == {"a":"b"} )
    assert ( JSInterpreter('var a={"a":{"a":{"a":{"a":"b"}}}}').call_function('a.a.a.a') == "b" )

# Generated at 2022-06-22 09:01:50.383029
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    test_code = \
    """/**
 * some comment
 * @param {Object} object
 * @param {Number} id
 * @return {?}
 */
function testFunc(object, id) {
    if (object[id] !== undefined) {
        return object[id];
    }
    if (object.layers) {
        for (var i = 0; i < object.layers.length; i++) {
            var result = testFunc(object.layers[i], id);
            if (result !== undefined) {
                return result;
            }
        }
    }
    return null;
}"""
    jsinterpreter = JSInterpreter(test_code)
    func = jsinterpreter.extract_function('testFunc')
    assert(callable(func))
   

# Generated at 2022-06-22 09:02:02.616624
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:02:13.167364
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = """var a = "xyz";
        var b = {
            c: function (d, e) {
                var f = function (g) {
                    return g + 1;
                }
                return d + e + f(0);
            },
            i: [1, 2, 3],
        };
        var h = function (k, l) { return k + l; };
    """
    interpreter = JSInterpreter(js_code)
    assert(interpreter.interpret_expression('"xyz"', {}) == "xyz")
    assert(interpreter.interpret_expression('43', {}) == 43)
    assert(interpreter.interpret_expression('a', {}) == "xyz")

# Generated at 2022-06-22 09:02:22.645398
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        qt = {
            "name": "QT",
            "api": "player_api",
            "url": function() {
                var a = $("player video");
                if (a.length) {
                    var b = a.data("config");
                    return "object" == typeof b ? null == b.url ? b.stream_hls : b.url : b
                }
            }
        };
    """
    jsi = JSInterpreter(code, {})
    obj = jsi.extract_object('qt')
    assert obj['name'] == 'QT'
    assert obj['api'] == 'player_api'
    # This is not a str, but a callable
    assert not isinstance(obj['url'], str)
    obj['url']()

# Unit

# Generated at 2022-06-22 09:02:27.296801
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    JSInterpreter.call_function(
        "this.decryptSignature", "4768", "0a2573e2056232b62f8f88c5c5ebffc2b9d9b513")


# Generated at 2022-06-22 09:02:37.512311
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Test that the value of field '__type' of object
    # 'yt.playerConfig.args' can be extracted with extract_object method
    # of class JSInterpreter
    test_code = '''
        function test_function(a) {
            return function_a(a);
        }
    '''
    def function_a(x):
        return x
    interpreter = JSInterpreter(test_code, objects={'function_a': function_a})
    test_function = interpreter.extract_function('test_function')
    assert test_function(1) == 1
    assert test_function('function_a') == function_a
    assert test_function(['function_a', 2]) == ['function_a', 2]
    # Test that if an illegal function name is given, an AttributeError
    # is

# Generated at 2022-06-22 09:02:45.711812
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_intrp = JSInterpreter('a=100;b=200;')
    local_vars = {}
    js_intrp.interpret_statement('a=100', local_vars)
    js_intrp.interpret_statement('b=200', local_vars)
    assert local_vars == {'a': 100, 'b': 200}
    
    js_intrp = JSInterpreter('a=100', {'a': 200})
    local_vars = {}
    js_intrp.interpret_statement('a=100', local_vars)
    assert local_vars == {'a': 100}
    assert js_intrp._objects == {'a': 100}

    js_intrp = JSInterpreter('a=100', {'a': 200})


# Generated at 2022-06-22 09:03:01.323589
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = "function test(a,b) { return a + b; }"
    js = JSInterpreter(code)
    assert js.call_function("test", 1, 2) == 3

# Generated at 2022-06-22 09:03:03.323045
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = 'function abc(a,b,c) { return a+b+c; }'
    interpreter = JSInterpreter(js_code)
    func_abc = interpreter.call_function("abc", 4, 5, 6)
    assert func_abc == 15



# Generated at 2022-06-22 09:03:12.282888
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterpreter = JSInterpreter('var a = function b(c){};')

    # Test for normal expression 
    assert jsinterpreter.interpret_expression('1;', {}) == 1
    assert jsinterpreter.interpret_expression('4.5;', {}) == 4.5 
    assert jsinterpreter.interpret_expression('[1,2,3];', {}) == [1,2,3]
    assert jsinterpreter.interpret_expression('{a:1,b:2};', {}) == {'a':1,'b':2}
    assert jsinterpreter.interpret_expression('a(1,2);', {}) == None

    # Test for operator expression
    assert jsinterpreter.interpret_expression('1+2', {}) == 3

# Generated at 2022-06-22 09:03:16.201178
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
  jsinterpreter = JSInterpreter("""
  var a = function() {
    var code = 12;
    var a = code;
    return a;
  };
  """)

  print(jsinterpreter.extract_function("a")())


# Generated at 2022-06-22 09:03:25.917118
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interp = JSInterpreter(code)
    func_name = 'get_items'
    res = js_interp.call_function(func_name)
    expected = [
        '5w5A61o5AS46KjP5oGF5Zue5Zyo6YGT5a6J5YWo5Lmw',
        '5pWZ5pWZ5a6J5YWo5Lmw6YGT5a6J5YWo5Lmw',
    ]
    assert res == expected


# Generated at 2022-06-22 09:03:31.548612
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsint = JSInterpreter('var x = 1; y = x; z = x; return z;')
    res1, abort1 = jsint.interpret_statement('var x = 1', {})
    assert res1 == 1
    assert not abort1
    res2, abort2 = jsint.interpret_statement('y = x; z = x; return z', {'x': 2})
    assert res2 == 2
    assert abort2


# Generated at 2022-06-22 09:03:37.356230
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    o = JSInterpreter('''
    function test(a, b) {
      var c = a + 3;
      var d = b + "a";
      return d;
    }''')

    f = o.build_function(['a', 'b'], '''
      var c = a + 3;
      var d = b + "a";
      return d;
    ''')

    assert f((1, "abc")) == "abca"


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 09:03:48.021121
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    from .jsinterp import JSInterpreter

    assert JSInterpreter('').call_function('', 0) is None

    assert JSInterpreter('function x(){}').call_function('x', 0) is None

    assert JSInterpreter(
        'function y(a){return a+1;}').call_function('y', 3) == 4

    assert JSInterpreter(
        'function y(a){return a+1;}').call_function('y', 3) == 4

    assert JSInterpreter(
        'function y(a){return a.length;}').call_function('y', 'abc') == 3

    assert JSInterpreter(
        'function y(a){return a.length;}').call_function('y', ['a', 'b', 'c']) == 3


# Generated at 2022-06-22 09:03:59.091481
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Tests for the implementation of JSInterpreter.extract_object
    # The following is an example of code that can be interpreted by this method
    code =r'''
        var a = {
                b: function(c){return c+1},
                d: function(e){return e+2},
                f: function(g){return g+3},
                h: function(i){return i+4}
            }
    '''

    jsinter = JSInterpreter(code)
    obj = jsinter.extract_object('a')
    assert obj['b'](1) == 2
    assert obj['d'](1) == 3
    assert obj['f'](1) == 4
    assert obj['h'](1) == 5



# Generated at 2022-06-22 09:04:07.316604
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('true', {}) is True
    assert js_interpreter.interpret_expression('false', {}) is False
    assert js_interpreter.interpret_expression('"abc"', {}) == 'abc'
    assert (js_interpreter.interpret_expression('[1,2]', {}) ==
            [1, 2])
    assert (js_interpreter.interpret_expression('{"1":2}', {}) ==
            {"1": 2})
    assert (js_interpreter.interpret_expression('{"1":2,"3":4}', {}) ==
            {"1": 2, "3": 4})

# Generated at 2022-06-22 09:04:34.393514
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = r'''function ff(a,b){a=a*a;b=b+3;return a/b;};function test(a,b){return ff(a,b);};'''
    interpreter = JSInterpreter(code)
    # test.ff(a,b) test.ff(1,2)
    assert interpreter.call_function('test', 1, 2) == 2/5


# Generated at 2022-06-22 09:04:42.025631
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
  jsint = JSInterpreter('var a = "hello"; a.split("");')
  # Traceback (most recent call last):
  #   File "<input>", line 1, in <module>
  #   File "jswraper.py", line 37, in interpret_expression
  #       raise ExtractorError('Unsupported JS expression %r' % expr)
  #   jswraper.ExtractorError: 'Unsupported JS expression 'a.split("")''

# Generated at 2022-06-22 09:04:53.112456
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:04:59.646157
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:05:08.431473
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    from .common import compat_str
    js = '''
        function f(i){
            var v = '1';
            return i + v;
        }
        function g(i, j){
            return f(i + j);
        }
        '''
    interpreter = JSInterpreter(js)
    f = interpreter.extract_function('f')
    assert '11' == f(['1'])
    assert '12' == f(['2'])
    assert '13' == f(['3'])
    assert '14' == f(['4'])
    assert '15' == f(['5'])
    g = interpreter.extract_function('g')
    assert '21' == g(['1', '2'])
    assert '32' == g(['2', '3'])


# Generated at 2022-06-22 09:05:12.131942
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = JSInterpreter("""
A= {};
B= {};
C= {};
D= {};
E= {};
""")
    assert js.interpret_statement("A.u", {}) == None

# Unit tests for the methods of class JSInterpreter

# Generated at 2022-06-22 09:05:22.560611
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:05:27.264319
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''var abc = {def: function(x, y) {return 3;}};'''

    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('abc.def', 1, 2) == 3

# Generated at 2022-06-22 09:05:35.166810
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:05:44.640032
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    abc = {def: function(x){return x+1;}};
    function abc(){return 3;}
    function dec(a,c){return a-c;}
    function func(def,ghi){
        return "1";
    };
    obj = {'a': 'b'};
    var arr = [1,2,3];
    foo = function(){return "1";};
    '''
    obj = JSInterpreter(code)._objects

# Generated at 2022-06-22 09:06:22.258967
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert json.loads(JSInterpreter('false').interpret_expression('json.dumps(false)', {})) == False
    assert json.loads(JSInterpreter('false').interpret_expression('json.dumps(false ? "false" : "true")', {})) == "true"
    assert JSInterpreter('false').interpret_expression('false ? 1 : 0', {}) == 0

test_JSInterpreter()

# Generated at 2022-06-22 09:06:30.405062
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('', {'a': 1, 'b': 2, 'n': [1, 2, 3]})
    assert js.interpret_expression('a', {}) == 1
    assert js.interpret_expression('a + b', {}) == 3
    assert js.interpret_expression('1 + 2', {}) == 3
    assert js.interpret_expression('n[0]', {}) == 1
    assert js.interpret_expression('[1, 2][0]', {}) == 1
    assert js.interpret_expression('abc', {'abc': 3}) == 3
    assert js.interpret_expression('abc + 1', {'abc': 3}) == 4
    assert js.interpret_expression('true', {}) is True
    assert js.interpret_expression('false', {}) is False

# Generated at 2022-06-22 09:06:41.989866
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-22 09:06:52.934333
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:07:02.941589
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    myCode = """
    function decode(a,b) {
        if (null == a)
            return "";
        for (var c = [], d = 0; d < a.length; d++) {
            var e = a[d],
                f = e >> 4 & 15,
                g = e & 15;
            c.push(f.toString(16) + g.toString(16))
        }
        return c.join("")
    }
    function decode2(a,b) {
        return decode(a)
    }

    function decode3() {
        var a = [12, 13, 12, 13];
        var b = decode2(a, 1);
        return b;
    }
    """
    exp_value = 'c'

# Generated at 2022-06-22 09:07:15.496600
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:07:21.745474
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Input data
    funcname = 'o'
    code = '''function o(a){a.onload=function(){console.log("Youtube JS player is ready")}}'''
    args = ['a']

    # Initialization
    jsInterpreter = JSInterpreter(code)
    func = jsInterpreter.extract_function(funcname)
    func(args)

    return True

# Generated at 2022-06-22 09:07:27.350234
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # The following code is from https://github.com/ytdl-org/youtube-dl/blob/master/youtube_dl/extractor/mtv.py
    code = '''
        function x1() {}
        function x2() {}
        function x3() {}

        var p = {
            k1: function(a) {
                return a;
            },
            k2: function(b) {
                return b;
            }
        };

        p.k2(x2());
        p.k1(x1());
    '''
    local_vars = {
        'x1': lambda: 1,
        'x2': lambda: 2,
        'x3': lambda: 3,
        'p': None,
    }
    interpreter = JSInterpreter(code, local_vars)

# Generated at 2022-06-22 09:07:36.447990
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    sample_js = '''
        function test(a, b) {
            return a + "!"
        }
    '''
    jsi = JSInterpreter(sample_js)
    test_result = jsi.call_function('test', 'foo', 'bar')
    assert test_result == 'foo!'

    sample_js = '''
        function test(a) {
            var b = a + "1";
            var c = b + "2";
            return c;
        }
    '''
    jsi = JSInterpreter(sample_js)
    test_result = jsi.call_function('test', 'foo')
    assert test_result == 'foo12'


# Generated at 2022-06-22 09:07:48.818645
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:08:43.477341
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        decodeURIComponent("%26%23x2F%3B%3D")
        function test() {
            return 1;
        }
        function test2(a,b) {
            return a;
        }
        '''
    jsInt = JSInterpreter(code)
    assert jsInt.extract_function('test')() == 1
    assert jsInt.extract_function('test2')(1,2) == 1

if __name__ == '__main__':
    test_JSInterpreter_extract_function()

# Generated at 2022-06-22 09:08:49.912786
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    assert JSInterpreter("""
            function a(x, y) {}
            b = {
                c: function(x) {},
                d: function(x, y) {}
            }
            """).extract_object("b")["c"].__name__ == "resf"
    assert JSInterpreter("""
            function a(x, y) {}
            b = {
                c: function(x) {},
                d: function(x, y) {}
            }
            """).extract_object("b")["d"].__name__ == "resf"


# Generated at 2022-06-22 09:08:58.285739
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''var a = function(x) { return x; }'''
    jsi = JSInterpreter(code)
    f1 = jsi.build_function(['x'], 'return x;')
    assert f1('hello') == 'hello'

    code = '''var a = function(x,y) { return x + y; }'''
    jsi = JSInterpreter(code)
    f2 = jsi.build_function(['x', 'y'], 'return x + y;')
    assert f2('a', 'b') == 'ab'

    code = '''var a = function(x) { return x && x.responseText; }'''
    jsi = JSInterpreter(code)

# Generated at 2022-06-22 09:09:10.820528
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    import unittest

# Generated at 2022-06-22 09:09:17.505809
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''
        function A(arg1, arg2) {
            var obj1 = {obj1var1: function(){}};
            var localvar1 = arg1 * arg2;
            var localvar2 = localvar1 * obj1['obj1var1']();
            return localvar2;
        }
    '''
    interpreter = JSInterpreter(code)

    def _test(stmt, local_vars, expected):
        global _functions
        value, abort = interpreter.interpret_statement(stmt, local_vars)
        if value != expected:
            raise ExtractorError('JSInterpreter.interpret_statement failed: value %r != expected %r' % (value, expected))
        if abort:
            raise ExtractorError('JSInterpreter.interpret_statement failed: abort should be False')



# Generated at 2022-06-22 09:09:26.093437
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''  function s(a) {
    function get(a) {
        return a.split('')
    }
    function reverse(a) {
        return a.reverse()
    }
    function join(a) {
        return a.join('')
    }
    var b = get(a);
    reverse(b);
    var c = join(b)
    return c
}
'''
    inter = JSInterpreter(code)
    res = inter.call_function('s', 'hello')
    assert res == 'olleh'

# Generated at 2022-06-22 09:09:35.163488
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:09:43.448022
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
function test_function(arg1, arg2) {
    var var1, var2, var3
    var1 = arg1
    var2 = arg2
    var3 = var1 + var2
    return var3
}
'''
    assert JSInterpreter(code).call_function('test_function', 10, 20) == 30

    code = '''
var a = [1, 2, 3, 4, 5]
var b = a.slice(1)
return b
'''
    assert JSInterpreter(code).interpret_statement(code, {})[0] == [2, 3, 4, 5]

    code = '''
var a = [1, 2, 3, 4, 5]
var b = a.splice(1, 2)
return b
'''
    assert JSInter

# Generated at 2022-06-22 09:09:53.327113
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:10:03.679063
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
    function test(a, b, c) {
        if (a == 0) {
            return b;
        }
        return test(a - 1, c, b + c);
    }
    """
    i = JSInterpreter(code)
    f = i.build_function(['a', 'b', 'c'], """
        if (a == 0) {
            return b;
        }
        return test(a - 1, c, b + c);
    """)
    assert f([0, 1, 2]) == 1
    assert f([1, 1, 2]) == 2
    assert f([2, 1, 2]) == 3
    assert f([3, 1, 2]) == 5
    assert f([4, 1, 2]) == 8

