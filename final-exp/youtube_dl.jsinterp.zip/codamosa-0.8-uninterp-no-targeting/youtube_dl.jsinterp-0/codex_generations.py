

# Generated at 2022-06-22 09:01:15.278039
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    test_interpreter = JSInterpreter('', )
    assert test_interpreter.interpret_expression('function () { return "hello world" }', {}, 100) == None
    assert test_interpreter.interpret_expression('1', {}, 100) == 1
    assert test_interpreter.interpret_expression('"test"', {}, 100) == 'test'
    assert test_interpreter.interpret_expression('"test" + 1', {}, 100) == 'test1'
    assert test_interpreter.interpret_expression('+1 + 1 - 1', {}, 100) == 1
    assert test_interpreter.interpret_expression('+1 + 1 - 1', {}, 100) == 1
    assert test_interpreter.interpret_expression('{ test: 123}["test"]', {}, 100) == 123
   

# Generated at 2022-06-22 09:01:25.179132
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_interpreter = JSInterpreter(
        """
        function stefan(a) {
            return a*a;
        }
        function oliver(a) {
            return a+a;
        }
        function doIt(action) {
            return action('Oliver');
        }
        function sayHello(name) {
            return "Hello " + name + "!";
        }
        function calc(a,b,c) {
            return ((a+b)*c);
        }
        """)
    assert(js_interpreter.call_function('stefan', 4) == 16)
    assert(js_interpreter.call_function('oliver', 2) == 4)

# Generated at 2022-06-22 09:01:31.824620
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var A = {
            "b": function(p) {return p},
            "c": function(p) {return p}
        };
    '''
    obj = JSInterpreter(js_code).extract_object("A")
    assert obj["b"]("test") == "test"
    assert obj["c"]("test") == "test"


# Generated at 2022-06-22 09:01:43.755488
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('', {}).interpret_expression(
        'var a=b', {'b': 5}, 10) == 5
    assert JSInterpreter('', {}).interpret_expression(
        'var a=b+1', {'b': 5}, 10) == 6
    assert JSInterpreter('', {}).interpret_expression(
        'var a=b+c', {'b': 5, 'c': 2.5}, 10) == 7.5
    assert JSInterpreter('', {}).interpret_expression(
        'var a=b/c', {'b': 5, 'c': 2}, 10) == 2.5

    # Test with object and function

# Generated at 2022-06-22 09:01:49.550762
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:01:55.227751
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    jsi = JSInterpreter(r'''
        var test1 = function(a,b){
            return a+b;
        };
    ''')
    f = jsi.extract_function('test1')
    assert f((1, 2)) == 3

    jsi = JSInterpreter(r'''
        var test2 = function(a){
            return a*a;
        };
    ''')
    f = jsi.extract_function('test2')
    assert f((3,)) == 9

    jsi = JSInterpreter(r'''
        function test3(a){
            return a/2;
        }
    ''')
    f = jsi.extract_function('test3')
    assert f((10,)) == 5


# Generated at 2022-06-22 09:02:07.049791
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        a = 5;
        b = 6;
        c = a + b;
        d = a * b;
        e = function(x, y) {return x * y;}
        f = function(x) {return e(x, x);}
        g = a - b;
        h = f(g);
    '''

    js_interp = JSInterpreter(code)
    js_interp.interpret_expression('a', {})
    js_interp.interpret_expression('c', {})
    js_interp.interpret_expression('d', {})
    js_interp.interpret_expression('f(a)', {})
    js_interp.interpret_expression('g', {})
    js_interp.interpret_expression('h', {})

    assert js_inter

# Generated at 2022-06-22 09:02:18.926430
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    ji = JSInterpreter('')

    # addition
    assert ji.interpret_expression('1 + 1', dict()) == 2
    assert ji.interpret_expression('1 + 1 + 1', dict()) == 3
    assert ji.interpret_expression('1 + 1 + 1 + 1', dict()) == 4
    assert ji.interpret_expression('1 + 1 + 1 + 1 + 1', dict()) == 5
    assert ji.interpret_expression('a + b', dict(a = 1, b = 1)) == 2
    assert ji.interpret_expression('a + b + c', dict(a = 1, b = 1, c = 1)) == 3
    assert ji.interpret_expression('a + b + c + d', dict(a = 1, b = 1, c = 1, d = 1)) == 4
    assert j

# Generated at 2022-06-22 09:02:26.664262
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:02:39.301670
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:03:19.707751
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    """Unit test for method call_function of class JSInterpreter.
    """
    def test_js_interpreter(code, funcname, expected_result, *args):
        js_interpreter = JSInterpreter(code)
        result = js_interpreter.call_function(funcname, *args)
        assert result == expected_result, 'the result of function %r should be %r, but got %r' % (funcname, expected_result, result)

    # test 1: call a simple function without argument and without return
    code = '''function test_function() {
        if (1) {
            return;
        }
    }'''
    funcname = 'test_function'
    expected_result = None
    test_js_interpreter(code, funcname, expected_result)

    #

# Generated at 2022-06-22 09:03:31.040830
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = JSInterpreter(
        '''function abc(a, b){
              return a + b;
           };
           var obj = {
                "field": function(l) {
                    return this.length + l;
                }
           };
           function r(a){
              return a.reverse();
           };
           function s(a, b){
              return a.slice(b);
           };
           function j(a, b){
              return a.join(b);
           };
        ''')
    # func abc
    result = js.call_function("abc", 1, 2)
    assert(result == 3)

    # func r, obj.field
    result = js.call_function("r", [1,2,3])
    result2 = result[0]([1,2,3])

# Generated at 2022-06-22 09:03:38.500596
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code_1 = """
    var abc = {
        "a": 1,
        "b": function() {
            return 2;
        }
    }
    """
    js_interpreter = JSInterpreter(code_1)
    assert js_interpreter.call_function('abc.b') == 2

    code_2 = """
    function myfunc(x, y) {
        return x * y;
    }
    """
    js_interpreter = JSInterpreter(code_2)
    assert js_interpreter.call_function('myfunc', 3, 4) == 12

    code_3 = """
    var a = 1, b = 2;
    function myfunc(x, y) {
        return a * b * x * y;
    }
    """
    js_inter

# Generated at 2022-06-22 09:03:48.352463
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    objects = {
        'window.navigator.userAgent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36',
        'navigator.platform': 'MacIntel',
        'navigator.plugins.length': 0,
        'navigator.plugins': [],
    }
    jsInterpreter = JSInterpreter(code = '''
        var testResult = navigator.userAgent.indexOf('Macintosh') > 0;
        function test(){
            return testResult;
        }
    ''', objects = objects)
    assert jsInterpreter.call_function('test')

if __name__ == '__main__':
    test_JSInterpreter_

# Generated at 2022-06-22 09:03:53.029970
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = 'function f(a){var b=a;b=b+1;return b;}'
    jsi = JSInterpreter(code)
    f = jsi.build_function(['a'], 'var b=a;b=b+1;return b;')
    assert f(1) == 2

# Generated at 2022-06-22 09:03:59.328831
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r'''
        o = {
            func1: function(a, b){return a+b},
            func2: function(){return 0},
        }
    '''

    js = JSInterpreter(code)
    obj = js.extract_object('o')
    assert obj['func2']() == 0
    assert obj['func1'](1, 2) == 3


# Generated at 2022-06-22 09:04:09.841150
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = '''
    function a() { var x = {}; x.a = function(a, b) { return a + b; }; return x; }
    var y = {}; y.b = function(a, b) { return b - a };
    var z = {}; z.c = function(a) { return true; };
    '''

    interpreter = JSInterpreter(js_code, {'y': y})
    assert interpreter.call_function('a', 'x', 'y').a('x', 'y') == 'xy'
    assert interpreter.call_function('y.b', 'x', 'y') == 'y'
    assert interpreter.call_function('z.c', 'x') == True

# Generated at 2022-06-22 09:04:23.089126
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:04:35.239523
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    """Tests the implementation of the method build_function of class JSInterpreter.

    The function tested here is extracted from the YouTube Javascript file:
    http://s.ytimg.com/yts/jsbin/html5player-vfl-oXcRj/html5player-en_US-vflM0cmyQ.js

    """

    # Expected results
    expected_result = {'a': '73b6fe08', 'b': 'e7db354b', 'c': '7acd2030'}

    # Parameter to pass to the function
    s = "fe0873b6-e7db-354b-7acd-2030"

    # Code of the function to test

# Generated at 2022-06-22 09:04:43.031513
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:05:09.866153
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:05:15.520033
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Test case 1
    code = 'function f(a){return a+1;}'
    assert JSInterpreter(code).extract_function('f')([1]) == 2

    # Test case 2
    code = 'function g(a){return a+a;}'
    assert JSInterpreter(code).extract_function('g')([2]) == 4


# Generated at 2022-06-22 09:05:25.140555
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    print('Test build_function:')
    js_interpreter = JSInterpreter('')
    def assertFunc(argnames, code, expected):
        f = js_interpreter.build_function(argnames, code)
        print('    Function:', f)
        args = tuple(range(len(argnames)))
        res = f(args)
        print('         in:', args)
        print('        out:', res)
        assert res == expected
        
    assertFunc(['a', 'b'], 'return a + b', 3)
    assertFunc(['a', 'b'], 'return a + b; return a - b', -1)
    assertFunc(['a', 'b'], 'return a + b; {}', 3)

# Generated at 2022-06-22 09:05:32.658923
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
        var a = [1, 2, 3];
        a.length;
        var c = function(arg1, arg2) {
            var a = arg1;
            return a + arg2;
        };
        c(a[1], a[0])+1;
        """
    js = JSInterpreter(code)
    expr = 'c(a[1], a[0])+1'
    local_vars = {'a': [1, 2, 3]}
    js.interpret_expression(expr, local_vars) == 4

# Generated at 2022-06-22 09:05:43.052576
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Create an instance of JSInterpreter
    stmts = """
            var a = 5;
            var b = a + 1;
            return a + b;
            """
    jsinterpreter = JSInterpreter(stmts)
    # Test if execution of the statements gives the right result
    assert jsinterpreter.interpret_statement(stmts) == 11
    # Test if execution of the statements returns the right value of a
    stmts_return_a = """
            var a = 5;
            return a + 1;
            var b = a + 1;
            """
    assert jsinterpreter.interpret_statement(stmts_return_a) == 6
    # Test if execution of the statements returns the right value of b

# Generated at 2022-06-22 09:05:53.325199
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:06:00.454604
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    local_vars = {'j': '', 'x': 1, 'y': 2, 'a': [1, 2, 3], 'r': [0, 0, 0]}
    # Test 1: test var m = re.match(r'(?!if|return|true|false)(?P<name>%s)$' % _NAME_RE, expr):
    expr = 'x'
    res = js_interpreter.interpret_expression(expr, local_vars)
    assert res == 1

    # Test 2: test m = re.match(r'(?P<in>%s)\[(?P<idx>.+)\]$' % _NAME_RE, expr):
    expr = 'a[2]'

# Generated at 2022-06-22 09:06:11.290486
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test Statement
    # "a=function(p){var d=[];var s='abc';for(var i=0;i<s.length;i++){d.push(s.charCodeAt(i))};return d};a()"
    # from:
    # https://www.youtube.com/watch?v=zJMvgYwjfY4
    js_interpreter = JSInterpreter("a=function(p){var d=[];var s='abc';"
                                   "for(var i=0;i<s.length;i++){d.push(s.charCodeAt(i))}"
                                   ";return d};a()")
    local_vars = {}

# Generated at 2022-06-22 09:06:14.262460
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():

    jsinterpreter = JSInterpreter('var string = "";')
    def myfunction(args):
        return resf(args)

    assert myfunction(('0',)) == 0


if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-22 09:06:25.688206
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = r'''
        var r = {};
        r.a = function (a, b) { return a + b; }
        r.b = function (a, b) { return a - b; }
        var y = {};
        y.c = function (a, b) { return a * b; }
        y.d = function (a, b) { return a / b; }
    '''
    js_interpreter = JSInterpreter(js_code)
    a = js_interpreter.call_function('r.a', 1, 2)
    b = js_interpreter.call_function('r.b', 1, 2)
    c = js_interpreter.call_function('y.c', 1, 2)

# Generated at 2022-06-22 09:07:19.447113
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    test_JS_code = """
    function A(a1, a2, a3) {
        this.a1 = a1;
        this.a2 = a2;
        this.a3 = a3;
        return this.a1 + this.a2 + this.a3;
    };
    """
    test_args = ('x', 'y', 'z')
    expect_result = ''.join(test_args)
    js_interpreter = JSInterpreter(test_JS_code)
    result = js_interpreter.call_function('A', *test_args)
    assert result == expect_result


# Generated at 2022-06-22 09:07:29.933659
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function f(a, b, c) {
            var d = a + b + c;
            return d - 1;
        }'''
    js = JSInterpreter(code)
    f = js.build_function('a,b,c'.split(','), '''
        var d = a+b+c;
        return d-1;''')
    assert f((1, 2, 3)) == 5
    assert f((0, 1, 2)) == 3
    assert f((0, 0, 0)) == -1
    assert f((0, 0, 0)) == -1
    assert f((-1, -1, -1)) == -3


# Generated at 2022-06-22 09:07:33.220015
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    JSInterpreter(''.join([
        "var obj = {",
        "    'test': function(args) {"
        "        return args[0];"
        "    }",
        "};",
    ]))



# Generated at 2022-06-22 09:07:42.451272
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # test 1
    c = JSInterpreter("""
        var n = n.split("").reverse().join("");
        var n = n.split("").reverse().join("");
    """)
    n = 'abc'
    x, abort = c.interpret_statement('var n = n.split("").reverse().join("");', {'n': n})
    assert x == 'cba'
    assert abort == False
    y, abort = c.interpret_statement('var n = n.split("").reverse().join("");', {'n': n})
    assert y == 'abc'
    assert abort == False

    # test 2

# Generated at 2022-06-22 09:07:46.648447
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
	code = """
			var f1 = function(arg1, arg2) {
            	if(arg1) return arg1*arg2;
            }
			"""
	assert JSInterpreter(code).build_function(['arg1', 'arg2'], 'if(arg1) return arg1*arg2;')((2, 3)) == 6



# Generated at 2022-06-22 09:07:51.758207
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
  js_code = '''
    function add(x, y){
      return x+y;
    }
  '''
  interpreter = JSInterpreter(js_code)
  result = interpreter.call_function('add',3,4)
  assert result == 7, 'Should return 7 and returned %s' % result


# Generated at 2022-06-22 09:07:57.097367
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''function test(some_var,some_other_var){if(some_var){some_other_var++}return some_other_var}function other(var_1){var_1=var_1*2;return var_1}'''
    interpreter = JSInterpreter(code)
    functions = {}
    functions['test'] = interpreter.extract_function('test')
    functions['other'] = interpreter.extract_function('other')
    assert functions['test'](0,0)==0
    assert functions['test'](1,1)==2
    assert functions['other'](3)==6


# Generated at 2022-06-22 09:08:06.661691
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    sample_code = '''
        var qwert = {
            l: function(a){
                return a + 1;
            },
            r: function() {
                return 'qwert';
            }
        };
    '''
    interpreter = JSInterpreter(sample_code)
    object = interpreter.extract_object('qwert')
    # object should have 2 functions, 'l' and 'r', with keys '0' and '1' respectively
    assert object[0](0) == 1
    assert object[1]() == 'qwert'



# Generated at 2022-06-22 09:08:17.187997
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_interpreter = JSInterpreter("""
    var test_obj1 = {
            a: function (x, y) { return x+y; },
            b: function (x) { return x + 1; },
            c: function (x) { return x + 2; }
        };
    var test_obj2 = {
            a: function (x) { return x * 10; },
            b: function (x) { return x * 100; },
            c: function (x) { return x * 1000; }
        };
    """)
    obj1 = js_interpreter.extract_object('test_obj1')
    obj2 = js_interpreter.extract_object('test_obj2')
    assert obj1['a'](1, 2) == 3

# Generated at 2022-06-22 09:08:27.732288
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        el = {"getActions":function(a){return a[1].actions},
            "getStream":function(a){return a[1].stream},
            "getVideoData":function(a){return{video_id:a[1].video_id,
                               video_title:a[1].title,length_seconds:a[1].length_seconds}},
            "getInitConfig":function(a){return a[0]}};
    '''
    jsinterpreter = JSInterpreter(code)
    obj = jsinterpreter.extract_object("el")
    assert obj is not None
    obj = obj["getVideoData"](("",{"video_id":"1","title":"title","length_seconds":600}))
    assert obj is not None
    assert obj["video_id"]

# Generated at 2022-06-22 09:09:12.464260
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter("var b = f('a')", {'f': lambda x: 'a'})
    assert js.interpret_expression('b', {}) == 'a'
    js = JSInterpreter("var b = a[0]", {'a': [1, 2, 3]})
    assert js.interpret_expression('b', {}) == 1
    js = JSInterpreter("var b = 'abcde'", {})
    assert js.interpret_expression('b', {}) == 'abcde'
    js = JSInterpreter("""var c = 'abcde';
        c = c.split('');
        c = c.reverse();
        var b = c.join('');
        """, {})
    assert js.interpret_expression('b', {}) == 'edcba'


# Generated at 2022-06-22 09:09:15.074639
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    if __name__ == "__main__":
        import doctest
        doctest.testmod()


# Generated at 2022-06-22 09:09:24.230944
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''\
        var m1=function(a,b){return a*b};
        var obj={foo: function(a1, a2) { return m1(a1*a2, a1-a2); }}'''

    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('m1', 2, 3) == 6
    assert js_interpreter._objects['obj']['foo'](1, 2) == -1


if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-22 09:09:28.524462
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = """
        var d = function(a, b) {
            return a * b * 10;
        };
    """
    ex = JSInterpreter(js)
    f = ex.extract_function('d')
    assert f((1, 2)) == 20


# Generated at 2022-06-22 09:09:35.531683
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    test_js = r'''
        function test(abc, def) {
            var ghi = 123;
            var jkl = abc + def + ghi;
            if (jkl == 246) {
                return "pass"
            }
            return "fail";
        };
    '''
    js_res = JSInterpreter(test_js).call_function('test', 123, 123)
    assert js_res == 'pass'

    js_res = JSInterpreter(test_js).call_function('test', 0, 123)
    assert js_res == 'fail'


# Generated at 2022-06-22 09:09:41.184917
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:09:50.725243
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    from .utils import ExtractorError
    code = '''
        function test(a, b) {
            return a + b;
        }
        testobj = {
            "v":5,
            "f":function(a) { return a - 3; }
        }
        function test2(a, b) {
            return testobj.f(b);
        }
        function test3(a, b) {
            var c = test(a, b);
            c = c + testobj["v"];
            c = test2(a, testobj["v"]);
            testobj.v = 42;
            return c + testobj.v;
        }
        '''
    jsi = JSInterpreter(code)
    assert jsi.call_function('test', 3, 4) == 7
    assert j

# Generated at 2022-06-22 09:10:03.302034
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter.interpret_expression('2+2', {}, 100) == 4
    assert JSInterpreter.interpret_expression('(23)', {}, 100) == 23
    assert JSInterpreter.interpret_expression('(1 + 2 * 3 + 5 ) / 2', {}, 100) == 6
    assert JSInterpreter.interpret_expression('12*3', {}, 100) == 36
    assert JSInterpreter.interpret_expression('12+3', {}, 100) == 15
    assert JSInterpreter.interpret_expression('14-10', {}, 100) == 4
    assert JSInterpreter.interpret_expression('4%3', {}, 100) == 1
    assert JSInterpreter.interpret_expression('4/3', {}, 100) == 1