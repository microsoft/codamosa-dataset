

# Generated at 2022-06-22 09:00:59.438831
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        function func(arg) {
            var arr = [];
            arr.push(arg);
            arr.shift();
            return {
                "test1": function(a) {
                    return a.join('');
                },
                "test2": function(b) {
                    return b.split('a');
                }
            }
        }'''
    i = JSInterpreter(code)
    func = i.extract_function('func')
    func(('a', 'b', 'c'))

# Generated at 2022-06-22 09:01:08.157426
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = r'''
        var x;
        var y;
        var z = 1;
        var h = true;
        var o = {
            'a': function(w, k) {
                if (1) {
                    return 123;
                } else {
                    return 456;
                }
            },
            'b': function() {
                return 's';
            }
        };
        var i = '4';
        var j = 'str';
        var w = 'str2';
        var k = 'str3';
        var l = 'str4';
        x = 5;
        y = 6;
        z = parseInt(i) + x + y;
        return z;
    '''
    jsi = JSInterpreter(code)

# Generated at 2022-06-22 09:01:11.442601
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    statement = 'return (1+2)'
    interpreter = JSInterpreter('', {})
    print(interpreter.interpret_statement(statement, {}))



# Generated at 2022-06-22 09:01:21.865520
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Return nothing
    code1 = '''function nothing() {
      var x = 1;
    }'''
    js_interpreter1 = JSInterpreter(code1)
    js_interpreter1.build_function(['x'], code1)
    func1 = js_interpreter1.build_function(['x'], code1)
    assert func1('x') == None
    
    # Return nothing, and pass parameters
    code2 = '''function nothing(arg1, arg2, arg3, arg4) {
      var x = arg1 + arg2;
    }'''
    js_interpreter2 = JSInterpreter(code2)

# Generated at 2022-06-22 09:01:33.762808
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Test 1
    js = '''
    var A;
    var B = {
        c: function(d) {
            return d;
        },
        e: function(f) {
            return f;
        }
     };
    var C = {
        d: function(e) {
            return e;
        }
     };
    '''
    extractor = JSInterpreter(js)
    B = extractor.extract_object('B')
    C = extractor.extract_object('C')
    assert(B['c']('d') == 'd')
    assert(B['e']('f') == 'f')
    assert(C['d']('e') == 'e')
    print('Unit test 1 for method extract_object of class JSInterpreter passed!')

    # Test 2

# Generated at 2022-06-22 09:01:40.676165
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'if(!a){return b};a=a-b;return a')
    assert func([0, 5]) == 5
    assert func([1, 1]) == 0
    assert func([2, 3]) == -1

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-22 09:01:44.081979
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:01:49.781648
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:02:02.507500
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('').interpret_expression('1') == 1
    assert JSInterpreter('').interpret_expression('3+3') == 6
    assert JSInterpreter('').interpret_expression('1 + 3') == 4
    assert JSInterpreter('').interpret_expression('1+3*3') == 10
    assert JSInterpreter('').interpret_expression('(1+3)*3') == 12
    assert JSInterpreter('').interpret_expression('6/2*2+1 + 3') == 11
    assert JSInterpreter('').interpret_expression('3 + 1') == 4
    with pytest.raises(ExtractorError):
        JSInterpreter('').interpret_expression('1 + 3 return')

# Generated at 2022-06-22 09:02:13.080945
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    <script>
    bar = function(x, y) {
        a = x + 1;
        return b * y;
    }
    foo = {
        init: function(x, y) {
            return this.bar(x, y);
        },
        bar: function(x, y) {
            f = function() {
                return y;
            }
            return x * f();
        }
    }
    foo.baz = 'baz';
    </script>
    '''
    p = JSInterpreter(code)
    assert p.call_function('bar', 10, 20) == 210
    assert p.call_function('foo.init', 10, 20) == 200
    assert p.call_function('foo.bar', 10, 20) == 200

# Generated at 2022-06-22 09:02:30.758005
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = (
        "function test_function(arg1, arg2) { " +
        "var test_variable = 1;" +
        "var arr = [arg1, arg2];" +
        "return arr;" +
        "}"
    )
    i = JSInterpreter(code)
    f = i.extract_function("test_function")
    assert f(1, 2) == [1, 2]
    assert f(3, 4) == [3, 4]

# Generated at 2022-06-22 09:02:37.297538
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    obj = JSInterpreter(
        "var a = 'abcdef'; var b = 'ghijkl'; var obj = {\n"
        "    func: function(n) {return a[n];},\n"
        "}; var func = function(n) {return obj.func(n);};\n"
    )
    assert obj.call_function('func', 0) == 'a'

if __name__ == '__main__':
    test_JSInterpreter_extract_function()

# Generated at 2022-06-22 09:02:44.915288
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_script = """
    d1 = {
        a: function(arg1, arg2) {return arg1 * arg2 + 5;},
        b: function(arg1, arg2) {return arg1 * arg2;},
        c: function(arg1, arg2) {return arg1 - arg2;},
    }
    """
    js_interpreter = JSInterpreter(test_script)
    d1 = js_interpreter.extract_object('d1')
    assert(d1['a'](2, 3) == 11)
    assert(d1['b'](2, 3) == 6)
    assert(d1['c'](2, 3) == -1)


# Generated at 2022-06-22 09:02:53.720731
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
        function o() {};
        o.a0 = function(a) {return a};
        o.a1 = function(a, b) {return a + b};
        o.a2 = function(a, b, c) {return a + b + c};
    """

    js = JSInterpreter(code)
    assert js.call_function('o.a0', 12) == 12
    assert js.call_function('o.a1', 12, 34) == 46
    assert js.call_function('o.a2', 12, 34, 56) == 102


# Generated at 2022-06-22 09:03:04.244548
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    JSInterpreterTest_extract_object = '''
        function function_1 () {
            var object_1 = {
                "key_1": "value_1",
                "key_2": "value_2",
                "key_3": function (arg) {
                    return arg;
                },
                "key_4": function () {
                    return 5;
                },
                "key_5": function (arg1, arg2) {
                    return arg1 + arg2;
                }
            }
        }
    '''
    js_interpreter_object = JSInterpreter(JSInterpreterTest_extract_object)
    result = js_interpreter_object.extract_object('object_1')

# Generated at 2022-06-22 09:03:11.459124
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = """
        function func_1(a, b) {
            return a + b;
        }
        var func_2 = function(a, b) {
            return a + b;
        }
    """
    cases = [
        ('func_1', (1, 2), 3),
        ('func_2', (3, 4), 7),
    ]
    for funcname, func_args, expected in cases:
        jsInterpreter = JSInterpreter(js_code)
        function = jsInterpreter.extract_function(funcname)
        assert function(func_args) == expected

# Generated at 2022-06-22 09:03:21.764986
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # variable_list
    interp = JSInterpreter("var test1=1, test2='2';", {})
    expr = 'test1'
    local_vars = {}
    local_vars = interp.interpret_statement(expr, local_vars)[0]
    print("local_vars:")
    print(local_vars)
    print("assert local_vars['test1'] == 1")
    print("assert local_vars['test2'] == 2")

    # if_statement
    interp = JSInterpreter("var a=1;if(a){a=2};", {})
    expr = 'a'
    local_vars = {}
    local_vars = interp.interpret_statement(expr, local_vars)[0]
    print("local_vars:")

# Generated at 2022-06-22 09:03:33.161360
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-22 09:03:41.300628
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = JSInterpreter('''
        function f1(arg1) {
            function f2(arg2) {
                return arg2*2;
            }
            return arg1 + f2(arg1)
        }
    ''')
    assert js.call_function('f1', 4) == 12
    assert js.call_function('f2', 8) == 16

# Generated at 2022-06-22 09:03:51.040746
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    assert JSInterpreter('').call_function(
        'swapNumbers', 5, 6) == 6
    assert JSInterpreter('').call_function(
        'swapNumbers', 7, 8) == 8
    assert JSInterpreter('').call_function(
        'add', 3, 5) == 8
    assert JSInterpreter('').call_function(
        'add', 15, 8) == 23
    assert JSInterpreter('').call_function(
        'getInt', '123') == 123
    assert JSInterpreter('').call_function(
        'getInt', '456') == 456
    assert JSInterpreter('').call_function(
        'hello', 'Peter') == 'Hello Peter! How are you?'

# Generated at 2022-06-22 09:04:26.475866
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    def interpret(stmt, local_vars, allow_recursion=100):
        interpreter = JSInterpreter('')
        if local_vars is None:
            local_vars = {}
        return interpreter.interpret_statement(stmt, local_vars, allow_recursion)

    assert interpret('var a = b', {'b': 2}) == (2, False)
    assert interpret('var a = 1, b = 2', {'b': 2}) == (2, False)
    assert interpret('var a = 1, b = 2, c = 3', {'b': 2}) == (3, False)
    assert interpret('return', {}) == (None, True)
    assert interpret('return 1', {}) == (1, True)
    assert interpret('return 1', {'a': 2}) == (1, True)

# Generated at 2022-06-22 09:04:34.669259
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    javascript_code = '''
        var a = 5;
        var b = 'test';
        var c = function(x) {
            return 'foo' + x + 'bar';
        };
    '''

    jsint = JSInterpreter(javascript_code)
    d = jsint.interpret_expression('c("xx")', {})
    assert d == 'fooxxbar'
    d = jsint.interpret_statement('return a', {})
    assert d == (5, True)
    d = jsint.interpret_statement('return "hello"', {})
    assert d == ('hello', True)
    d = jsint.interpret_statement('c("xx");return a', {})
    assert d == (5, True)


# Generated at 2022-06-22 09:04:41.695320
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''function a(a){return a};a.z=function(){};a.y={"s":"s"};a.x=function(b){return b};'''
    jsinterpreter = JSInterpreter(code)
    a = jsinterpreter.extract_object("a")
    assert len(a) == 3
    assert callable(a['x'])
    assert a['y']['s'] == "s"
    assert callable(a['z'])


# Generated at 2022-06-22 09:04:52.729676
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter('')
    local_vars = {}

    assert (js.interpret_statement('a = 5', local_vars) == (5, False))
    assert (local_vars['a'] == 5)
    assert (js.interpret_statement('b = (5 * 2) | 1', local_vars)[0] == 11)
    assert (local_vars['b'] == 11)
    assert (js.interpret_statement('return a', local_vars)[0] == 5)
    assert (js.interpret_statement('return a', local_vars, allow_recursion=-1)[0] == 5)
    assert (js.interpret_statement('return a', local_vars, allow_recursion=0)[0] == 5)

# Generated at 2022-06-22 09:05:02.387312
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = "var a = function(p1,p2) {return p1 + p2;}"
    # create a JSInterpreter
    exampleInterpreter = JSInterpreter(code)
    # name of function to be tested
    funcname = "a"
    # name of arguments of function f
    argnames = ["p1", "p2"]
    # body of function f
    code = exampleInterpreter.call_function(funcname,2, 3)
    assert code == 5


# Generated at 2022-06-22 09:05:08.444572
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
    function f1(a,b,c) {
        var out = a + b - c;
        var arr = [1,2,3,4];
        out = out << arr[out];
    }

    abc = function f2(a) {
        return a * a;
    }
    """
    
    assert JSInterpreter(code).extract_function('f1')((1,2,3)) == None
    assert JSInterpreter(code).extract_function('f2')((3,)) == 9


# Generated at 2022-06-22 09:05:18.192101
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    local_vars = {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-22 09:05:24.674294
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = 'function test(arg1, arg2) { arg1 = arg2 + arg1; return arg1; }'
    interpreter = JSInterpreter(code)
    argnames = ['arg1', 'arg2']
    code = 'arg1 = arg2 + arg1; return arg1;'
    resf = interpreter.build_function(argnames, code)
    assert resf((1, 2)) == 3

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-22 09:05:31.502402
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('function test(a,b){return a+b;}')
    assert js.call_function('test', 2, 3) == 5
    js = JSInterpreter('''function test(a,b){
        return a+"_"+b;
    }''')
    assert js.call_function('test', 'x', 'y') == "x_y"
    js = JSInterpreter('function test(a,b){return [a,b];}')
    assert js.call_function('test', 'x', 'y') == ['x', 'y']
    js = JSInterpreter('function test(a,b){return {a:a,b:b};}')

# Generated at 2022-06-22 09:05:40.985689
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        var a = function () {
            var b = function (arg) {
              return arg
            }
            var c = function () {
              return b("Hello");
            }
            return c()
        }
        var e = function (arg) {
            return arg
        }
        var f = function () {
            return a();
        }'''
    interpreter = JSInterpreter(code)
    assert interpreter.call_function("a") == 'Hello'
    assert interpreter.call_function("e", "Hello") == 'Hello'
    assert interpreter.call_function("f") == 'Hello'

# Generated at 2022-06-22 09:06:28.220008
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''\
        print(1);
        var a = 'abc';
        function funcname(b, c, d) {
            var e = b + c;
        }
        funcname(1, 2, 3);
        print(a);
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('funcname', '1', '2', '3') == None

# Generated at 2022-06-22 09:06:38.633551
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('')
    assert js.interpret_expression('[1, 2, 3]', {}) == [1, 2, 3]
    assert js.interpret_expression('1^2==3', {}) == True
    assert js.interpret_expression('["a", "b"].join("")', {}) == 'ab'
    assert js.interpret_expression('["a", "b"].join()', {}) == ['a', 'b']
    assert js.interpret_expression('[1, 2, 4, 8][1+1]', {}) == 4
    assert js.interpret_expression('["zero", "one", "two", "three"][3-2]', {}) == 'two'

# Generated at 2022-06-22 09:06:44.602429
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    global code
    with open('test_SJISU.js') as myfile:
        test_code = myfile.read()
    code = test_code
    test_interpreter = JSInterpreter(test_code)
    assert(test_interpreter.code == test_code)
    print('JSInterpreter constructor test passed')


# Generated at 2022-06-22 09:06:48.815241
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    from .jsinterp import JSInterpreter
    jsi = JSInterpreter(
        """function f(a,b) { return a*3; }""")

    assert jsi.call_function('f', 7, 2) == 21
    return True


# Generated at 2022-06-22 09:06:55.456563
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    test_code = """
    var a = function(b){
        return b;
    };
    var c = function d(b){
        return b;
    };
    function e(f){
        return f;
    };
    """
    a_func = JSInterpreter(test_code).extract_function("a")
    assert a_func("b") == "b"

    c_func = JSInterpreter(test_code).extract_function("d")
    assert c_func("b") == "b"

    e_func = JSInterpreter(test_code).extract_function("e")
    assert e_func("f") == "f"

# Generated at 2022-06-22 09:07:00.560633
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = 'var a = 5; b = 3; c = a + b; d = c;'
    interpreter = JSInterpreter(code)
    local_vars = dict()
    interpreter.interpret_statement(code, local_vars)
    assert isinstance(local_vars['d'], int)
    assert local_vars['d'] == 8


# Generated at 2022-06-22 09:07:08.319689
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    
    js_code = """
    var c = function () {
        var a = arguments;
        return a[0] + a[1];
    }
    """
    jsi = JSInterpreter(js_code)
    assert jsi.call_function('c', 2, 4) == 6

    js_code = """
    var c = function (a, b) {
         return a + b;
    }
    """
    jsi = JSInterpreter(js_code)
    assert jsi.call_function('c', 2, 4) == 6

    js_code = """
    var d = function (a, b) {
         return a + b;
    };
    """
    jsi = JSInterpreter(js_code)
    assert jsi.call_function('d', 2, 4)

# Generated at 2022-06-22 09:07:16.063285
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    t = JSInterpreter('function test(a,b,c){var x=a;var y="hello";return x+" "+y+" "+c}', objects={})
    f = t.build_function(['a', 'b', 'c'], 'var x=a;var y="hello";return x+" "+y+" "+c;')
    assert f(['world', 'b', 'c']) == 'world hello c'

# Generated at 2022-06-22 09:07:22.879194
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    test_code = '''
    var a = 1;
    var b = 2;
    function a () {
        var c = 4;
        var d = 2;
        if (1 < 2) {
            var e = 3;
            var f = 4;
        }
    }
    '''
    resf = JSInterpreter(test_code).build_function('', test_code)
    assert resf(()) == 4


# Generated at 2022-06-22 09:07:26.448417
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    JSInterpreter("var x = 0; x = 5; return 1;").interpret_statement("return 1;", {}, 100)


# Generated at 2022-06-22 09:07:55.266128
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter.interpret_expression('var a = 1 + 2', {}) == 3
    assert JSInterpreter.interpret_expression('var a = 1 + b', {'b': 2}) == 3
    assert JSInterpreter.interpret_expression('var a = 1 + 2; a', {}) == 3
    assert JSInterpreter.interpret_expression('var a = 1 + b; a', {'b': 2}) == 3
    assert JSInterpreter.interpret_expression('var a = 1 + 2; return a', {}) == 3
    assert JSInterpreter.interpret_expression('var a = 1 + b; return a', {'b': 2}) == 3
    assert JSInterpreter.interpret_expression('var a = 1 + b; c = a', {'b': 2}) == 3
    assert JSInterpreter.interpret

# Generated at 2022-06-22 09:08:08.086831
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    t = JSInterpreter("var b=a+36;")
    t._objects['a'] = [1,2,3,4,5,6,7,8,9]
    b = t.interpret_expression('a.slice(2)', {'a': [1,2,3,4,5,6,7,8,9]})
    assert b == [3,4,5,6,7,8,9]
    t._objects['a'] = [1,2,3,4,5,6,7,8,9]
    assert t.interpret_expression("a.length", {"a": [1,2,3,4,5,6,7,8,9]}) == 9
    assert t.interpret_expression("e", {'a': 'abcde', 'e':5}) == 5
   

# Generated at 2022-06-22 09:08:15.926323
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = '''function func1(x) { return x; }'''
    f = JSInterpreter(js).extract_function('func1')
    assert f(('abcd',)) == 'abcd'
    js = '''function add(x, y) { return x + y; }'''
    add = JSInterpreter(js).extract_function('add')
    assert add((1, 2)) == 3
    js = '''function add(x, y) { return x + y; }
    function sub(x, y) { return x - y; }'''
    add = JSInterpreter(js).extract_function('add')
    sub = JSInterpreter(js).extract_function('sub')
    assert add((1, 2)) == 3

# Generated at 2022-06-22 09:08:19.642937
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # simple function
    stmt = """function test(arg1){  return arg1;  }"""
    js = JSInterpreter(stmt)
    res_func = js.build_function(['arg1'], stmt)
    assert res_func([1]) == 1


if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-22 09:08:28.341208
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    t = JSInterpreter('''
        function test_name() {
            return 'yeah';
        }
    ''')
    assert t.extract_function('test_name')() == 'yeah'

    t = JSInterpreter('''
        var test_name = function() {
            return 'yeah';
        }
    ''')
    assert t.extract_function('test_name')() == 'yeah'

    t = JSInterpreter('''
        test_name = function() {
            return 'yeah';
        }
    ''')
    assert t.extract_function('test_name')() == 'yeah'

    t = JSInterpreter('''
        var test_name = function names_are_irrelevant() {
            return 'yeah';
        }
    ''')

# Generated at 2022-06-22 09:08:38.724464
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:08:48.512937
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    mydir = os.path.dirname(os.path.realpath(__file__))
    js_file_path = os.path.join(mydir, 'js_files', 'signature-function.js')
    with io.open(js_file_path, 'rt', encoding='utf-8') as js_file:
        js_code = js_file.read()
    interpreter = JSInterpreter(js_code)
    
    local_vars = {'a': 1, 'b': 2}
    res, abort = interpreter.interpret_statement('return a + b;', local_vars)
    assert res == 3
    assert abort
    
    res, abort = interpreter.interpret_statement('c = a + b', local_vars)
    assert res == 3
    assert not abort
    assert local_v

# Generated at 2022-06-22 09:08:58.661502
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:09:01.191078
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    sample_js = '''
        function test_function(){
            var arr = [];
            arr[0] = 10;
            return arr;
        }
    '''
    js_interpreter = JSInterpreter(sample_js)
    res, abort = js_interpreter.interpret_function('test_function')
    assert res == [10]


# Generated at 2022-06-22 09:09:11.819923
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function foo() {
            return 'foo';
        }
        var bar = function() {
            return 'bar';
        };
        var baz = {
            'hello': function(arg1, arg2) {
                return 'hello ' + arg1 + arg2;
            },
        };
        function hello() {
            return 'hello';
        }
    '''
    obj = JSInterpreter(code)
    assert obj.extract_function('foo')() == 'foo'
    assert obj.extract_function('bar')() == 'bar'
    assert obj.extract_function('baz.hello')('world', '2') == 'hello world2'
    assert obj.call_function('hello') == 'hello'