

# Generated at 2022-06-22 09:01:06.871147
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    test_object = """
        var a = {'test': function(test,test2){return test+test2;}};
    """
    interpreter = JSInterpreter(test_object)
    function = interpreter.extract_function('a.test')
    assert function((1,1)) == 2

if __name__ == '__main__':
    import sys
    test_JSInterpreter_extract_function()
    print('Passed the tests.')

# Generated at 2022-06-22 09:01:14.699063
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    i = JSInterpreter('')
    expr = "a.b + a['c'] + d.e[0] + a.f()"
    local_vars = {
        'a': {
            'b': 1,
            'c': 2,
            'f': lambda x: 3
        },
        'd': {
            'e': [4]
        }
    }
    res = i.interpret_expression(expr, local_vars)
    assert res == 15


# Generated at 2022-06-22 09:01:24.650219
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    obj_code = '''
        function a (b,c){
            var d = 5;
            var e = {"a":"b"};
            var f = [1,2,3];
            var g = {"h":function(j){return j;}};
            var k = function(l){return l+1;};
            var m = n("o");
            return {a:b,c:c,d:d,e:e,f:f,g:g,k:k};
        }
        function n(l){
            return l+1;
        }
    '''
    objname = 'g'
    exp_obj = {
        'h': lambda args: args[0],
    }
    jsinterpreter = JSInterpreter(obj_code)
    assert jsinterpreter.extract

# Generated at 2022-06-22 09:01:30.983124
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = 'function hello(){return 1;}'
    interpreter = JSInterpreter(js)
    assert interpreter.extract_function('hello')() == 1
    with pytest.raises(Exception) as excinfo:
        interpreter.extract_function('hello2')()
    assert 'could not find' in str(excinfo.value).lower()


# Generated at 2022-06-22 09:01:41.418834
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        function func(a, b) {
            var d = 4, e = a + b;
            return c
        }

        var c = [1, 2, 3];

        var obj = {
            f1: function(a,b) {
                var d = 4, e = a + b;
                return c
            }
        }

        var anotherObj = {};
        anotherObj.f2 = function(a, b) {
            var d = 4, e = a + b;
            return c
        };
    '''
    interp = JSInterpreter(code)

    # Test build_function
    assert(interp.build_function(['a', 'b'], 'return a + b')([1, 2]) == 3)

# Generated at 2022-06-22 09:01:49.512435
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    try:
        jsi = JSInterpreter('''
            var a = 10;
            var b = 20+20;
            var c = {
              "aa": function(str) {return str;}
            }
        ''')
        assert jsi.call_function('c.aa', 'hello world') == 'hello world'
        assert jsi.call_function('a') == 10
        assert jsi.call_function('b') == 40
    except ExtractorError as e:
        print('Error: ' + str(e))
    else:
        print('Passed!')

if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-22 09:01:55.206116
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    local_vars = {
        's': 'abcde'
    }
    js_interpreter = JSInterpreter('')
    result = js_interpreter.interpret_statement('s.split("")', local_vars)
    assert result == (['a', 'b', 'c', 'd', 'e'], False)
    local_vars = {
        's': 'abcde',
        'u': None,
        'v': None
    }
    js_interpreter = JSInterpreter('')
    result = js_interpreter.interpret_statement('u = s.split("")', local_vars)
    assert result == (['a', 'b', 'c', 'd', 'e'], False)

# Generated at 2022-06-22 09:02:04.353617
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:02:17.603350
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:02:24.625524
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    '''test class JSInterpreter, method build_function'''
    test_code = '''
        function test() {
            var a = "";
            if (a) {return a}
            return null
        }
    '''
    js = JSInterpreter(test_code)
    f = js.build_function([], '''
        var a = "";
        if (a) {return a}
        return null
    ''')
    assert f(tuple()) is None

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-22 09:03:03.404017
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''
        var a = 5;
        var b = -3;
        return a + b;
        return a + b - 1;
        '''
    js_interpreter = JSInterpreter(code)
    assert 2 == js_interpreter.interpret_expression('a + b', {'a': 5, 'b': -3})
    assert 1 == js_interpreter.interpret_expression('a + b - 1', {'a': 5, 'b': -3})


# Generated at 2022-06-22 09:03:12.335867
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    my_js = '''
        function func1(args) {
            console.log(args);
            return args;
        }
        var func2 = function(args) {
            console.log(args);
            return args;
        }
        var func3 = function func4(args) {
            console.log(args);
            return args;
        };
        func3.a = 4;
        func3.b = function func5(args) {
            console.log(args);
            if (args == 0)
                return 5;
            return func5(args - 1) + func5(args - 2);
        }
        '''
    jsint = JSInterpreter(my_js)
    # Test func1

# Generated at 2022-06-22 09:03:24.160796
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    global throwaway
    def test_interpreter(code):
        interpreter = JSInterpreter(code)
        return interpreter.interpret_expression('abc', {'abc': 5})

    assert test_interpreter('var abc = 5;') == 5
    assert test_interpreter('var abc = 5; abc;') == 5
    assert test_interpreter('var abc = {a: 5}; abc;') == {'a': 5}
    assert test_interpreter('var abc = {a: {b: 5}}; abc;') == {'a': {'b': 5}}
    assert test_interpreter('abc;') == 5

    assert test_interpreter('abc + 3;') == 8
    assert test_interpreter('3 + abc;') == 8
    assert test

# Generated at 2022-06-22 09:03:29.800221
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    ji = JSInterpreter('''
        Aa = {
            ab: function(a) {return a + 1},
            bc: function(a, b) {return a - b}
        };
    ''')
    assert ji.extract_object('Aa') == {
        'ab': lambda a: a + 1,
        'bc': lambda a, b: a - b,
    }


# Generated at 2022-06-22 09:03:36.243772
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = """
        var obj1 = {
            func1: function(arg1, arg2) {
                return arg1 + arg2;
            }
        }

        function func2(arg1, arg2) {
            return arg1 - arg2;
        }
    """
    js = JSInterpreter(js_code)
    assert js.extract_function('func2')((2, 3)) == -1
    assert js.extract_function('func1')((2, 3)) == 5

# Generated at 2022-06-22 09:03:47.857913
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_code = '''
        function my_func(a, b) {
            var c = 3;
            return a - b + c;
        }
    '''
    input_args = [5, 8]
    expected_output = test_code.split('{')[1].split('}')[0].split(';')[-1].lstrip()
    expected_output = expected_output[expected_output.find('return')+len('return'):]
    expected_output = expected_output.strip()
    expected_output = JSInterpreter(test_code).interpret_expression(expected_output, dict(zip(['a','b','c'],input_args)), 10)
    output_args = JSInterpreter(test_code).extract_function('my_func')(input_args)
    assert expected

# Generated at 2022-06-22 09:03:59.237379
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:04:10.721398
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    local_vars = {
        'mt': [],
        'ox': 'o',
        'ut': [],
        'b': [],
        'ot': [],
        'i': 10,
        'u': 'o',
        'm': [],
        'a': 'o',
        'o': [],
        'l': 'o',
        'lt': [],
    }

# Generated at 2022-06-22 09:04:23.325973
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = ''
    jsi = JSInterpreter(code)
    assert(jsi.interpret_expression('2', {'a': 1}) == 2)
    assert(jsi.interpret_expression('var', {'var': 1}) == 1)
    assert(jsi.interpret_expression('var + 2', {'var': 1}) == 3)
    assert(jsi.interpret_expression('2 - 1', {'var': 1}) == 1)
    assert(jsi.interpret_expression('4 * 5', {'var': 1}) == 20)
    assert(jsi.interpret_expression('(4)', {'var': 1}) == 4)
    assert(jsi.interpret_expression('!false', {}) == True)
    assert(jsi.interpret_expression('true', {}) == True)

# Generated at 2022-06-22 09:04:32.786168
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
        function func(a,b,c) {
            a = b + c;
            return b;
        }
        """
    js = JSInterpreter(code)
    assert js.call_function('func', 4, 5, 6) == 5
    assert js.call_function('func', 4, 5, 6) == 5
    assert js.call_function('func', 4, 5, 6) == 5

if __name__ == "__main__":
    test_JSInterpreter_call_function()

# Generated at 2022-06-22 09:04:56.276456
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    func_code = '''
        function f(a, b) {
            function g(c, d) {
                return a * b + (c - d) / (a + b);
            }
            return g;
        }
        function h(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(func_code)
    _f_res = js_interpreter.call_function('f', 2, 3)
    assert _f_res(2, 3) == 1.0
    _h_res = js_interpreter.call_function('h', 4, 5)
    assert _h_res == 9



# Generated at 2022-06-22 09:05:06.851660
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:05:18.587358
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def assert_interpret_statement(self, stmt, local_vars, allow_recursion=100,
                                   shouldEvaluateResult = True):
        res, abort = self.interpret_statement(stmt, local_vars, allow_recursion)
        if shouldEvaluateResult:
            return res
        return "" # Return empty to avoid printing

    def assert_interpret_expression(self, expr, local_vars, expectedResult,
                                    allow_recursion=100):
        res = self.interpret_expression(expr, local_vars, allow_recursion)
        if res != expectedResult:
            raise Exception("Result: " + str(res) + ", expected: " + str(expectedResult))


# Generated at 2022-06-22 09:05:31.945884
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:05:38.632372
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_interpreter = JSInterpreter("""\
        var k = function (arg1, arg2) {
        var a = arg1;
        var b = arg2;
        return a + b;
        }
    """)
    assert js_interpreter.call_function('k', 1, 2) == 3
    assert js_interpreter.call_function('k', 7, 5) == 12


# Generated at 2022-06-22 09:05:45.587506
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = r'''
        e=document.createElement("div");
        e.innerHTML="<a></a>";
        e=e.firstChild;
        e.href="http://foo.com";
        e.setAttribute("download","bar");
        e.click()'''.replace('\n', '')
    js_interpreter = JSInterpreter(code)
    print(js_interpreter.interpret_expression('e.href'))

# Generated at 2022-06-22 09:05:54.368645
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    import sys
    import os
    import pytest
    import json
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data/extract_object.js')
    test_code = open(path, 'r').read()
    # test_code = self.code
    test_code = re.sub(r'\/\*.*?\*\/', '', test_code, flags=re.DOTALL)
    js_interpreter = JSInterpreter(test_code)
    assert 'decodeURIComponent' in test_code

    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data/test_object_expected.json')
    expected = open(path, 'r').read().dec

# Generated at 2022-06-22 09:06:01.205524
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('3 + 4', {}) == (7, False)
    assert js_interpreter.interpret_statement('x = 3 + 4', {}) == (7, False)
    assert js_interpreter.interpret_statement('x', {'x': 5}) == (5, False)
    assert js_interpreter.interpret_statement('return 3 + 4', {}) == (7, True)

# Generated at 2022-06-22 09:06:11.989249
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    i = JSInterpreter('')
    i.interpret_statement(
        'var a = "hello"',
        {})
    i.interpret_statement(
        'var a = 0',
        {})

    assert i.interpret_statement(
        'return 0',
        {}) == (0, True)
    assert i.interpret_statement(
        'return "hello"',
        {}) == ('hello', True)

    a = dict()
    i.interpret_statement(
        'var a = {}',
        {})
    a = dict()
    i.interpret_statement(
        'var a = {b:1,c:2}',
        {})
    assert a == {'b': 1, 'c': 2}


# Generated at 2022-06-22 09:06:17.614641
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = """
    foo = function(bar) {
        return bar + 1;
    }

    function baz(qux) {
        return qux + 2;
    }
    """
    interp = JSInterpreter(js_code)
    print("foo(3)", interp.call_function("foo", 3))
    print("baz(3)", interp.call_function("baz", 3))


# Generated at 2022-06-22 09:06:37.584331
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsCode = '''
        function test(thing) {
            return thing * 2;
        }
        function test2(thing, other) {
            return thing + other;
        }
        function test3(){
            return 10;
        }
    '''
    interpreter = JSInterpreter(jsCode)
    assert interpreter.call_function('test', 2) == 4
    assert interpreter.call_function('test2', 2, 3) == 5
    assert interpreter.call_function('test3') == 10



# Generated at 2022-06-22 09:06:45.857332
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = r'''
        var a = {
            "b": function(arg) {
                return arg + this.w;
            },
            "c": function() {
                return 2;
            }
        }
    '''
    js_interp = JSInterpreter(code)
    func = js_interp.extract_object('a')
    assert func['c']() == 2
    assert func['b'](1) == 3


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 09:06:54.487238
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('a = function (x,y){\n'
                                   '  return x + y;\n'
                                   '}\n')
    result = js_interpreter.build_function(['x', 'y'], 'return x + y;')
    assert result((1, 2)) == 3

    js_interpreter = JSInterpreter('a = function (x,y){\n'
                                   '  return x + y;\n'
                                   '  return x - y;\n'
                                   '}\n')
    result = js_interpreter.build_function(['x', 'y'], 'return x + y;')
    assert result((1, 2)) == 3


# Generated at 2022-06-22 09:07:04.138804
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    funcs = {}
    objs = {}

    def define_func(fname, args, code):
        funcs[fname] = JSInterpreter(code, objs).build_function(args, code)

    def define_obj(objname, code):
        obj = {}
        obj_m = re.search(
                r'''(?x)
                    (?<!this\.)%s\s*=\s*{
                        (?P<fields>(?:[a-zA-Z$0-9]+\s*:\s*function\s*\(.*?\)\s*{.*?}(?:,\s*)?)*)
                    }\s*;
                ''' % re.escape(objname),
                code)
        objfields = obj_m.group('fields')
        # Currently,

# Generated at 2022-06-22 09:07:10.462857
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        d.n = function(a) {
            this.e = a;
            this.j = {}
        };
        d.n.prototype.getVideoData = function () {
            this.j.r = this.e.e("VIDEO");
            this.j.r.width = document.getElementsByTagName("BODY")[0].offsetWidth;
            this.j.r.height = document.getElementsByTagName("BODY")[0].offsetHeight - 50;
            return this.j;
        }
    '''
    extractor = JSInterpreter(code)

    obj = extractor.extract_object("d.n")

# Generated at 2022-06-22 09:07:13.090536
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter('var a = 1; a=2; return a;')


# Generated at 2022-06-22 09:07:24.508563
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    objects = {
        'c': {
            'split': lambda args: [int(x) for x in args[0].split(',')]
        }
    }
    ji = JSInterpreter('', objects)
    local_vars = {
        'b': {
            'reverse': lambda args: None
        }
    }
    statements = (
        'a = 1',
        'a += 2',
        'a &= 3',
        'a = (1)',
        'a = 1 + 2',
        'a = 1 - 2',
        'a = b',
        'a = b.reverse()',
        'a = b.reverse().f',
        'a = c.split(\'0\')',
        'a = c.split(\'0\')[42]'
    )


# Generated at 2022-06-22 09:07:36.384545
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:07:40.834006
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
    function foo(a, b) {
        var c;
        c = (a + b) / 2;
        return c;
    }
    '''
    interpreter = JSInterpreter(code)
    f = interpreter.build_function(['a', 'b'], '''
        var c;
        c = (a + b) / 2;
        return c;
    ''')
    assert f((1, 2)) == 1.5
    assert f((-4, 5)) == 0.5



# Generated at 2022-06-22 09:07:44.864394
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_sample = '''function foo() {
            var bar = 1;
            return bar;
        }
    '''
    interpreter = JSInterpreter(js_sample)
    foo = interpreter.extract_function('foo')
    assert foo() == 1

# Generated at 2022-06-22 09:08:04.573467
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    JSInterpreter = JSInterpreterCompiled
    interpreter = JSInterpreter('', {'const': {'a': 'A'}})
    res, should_abort = interpreter.interpret_statement('a;', {})
    assert res == 'A'
    assert should_abort is False
    res, should_abort = interpreter.interpret_statement('var b;', {})
    assert res is None
    assert should_abort is False
    res, should_abort = interpreter.interpret_statement('var b=1;', {})
    assert res == 1
    assert should_abort is False
    res, should_abort = interpreter.interpret_statement('return b;', {})
    assert res == 1
    assert should_abort is True

# Generated at 2022-06-22 09:08:16.279380
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(["a", "b"], "return a+b;")(
        [1, 2]) == 3
    assert js_interpreter.build_function(
        ["a", "b"], "return a*b;")([2, 3]) == 6
    assert js_interpreter.build_function(
        ["a", "b"], "return a-b;")([3, 2]) == 1
    assert js_interpreter.build_function(
        ["a", "b", "c"], "return a*b+b*c;")([1, 2, 3]) == 8

# Generated at 2022-06-22 09:08:27.313616
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-22 09:08:34.844438
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter('').build_function([], '')() is None
    assert JSInterpreter('').build_function(['a'], 'return a')(1) == 1
    assert JSInterpreter('').build_function(['a'], 'a=1')() == 1
    assert JSInterpreter('').build_function(['a'], 'a=a+1')(1) == 2
    assert JSInterpreter('').build_function(['a'], 'return a;a=a+1')(1) == 1


# Generated at 2022-06-22 09:08:45.490056
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # test interpret_statement of class JSInterpreter

    # set the code
    code = '''
        var d = "98a1e3a3d782c987facd86f0";
        var e = function (f) {
            var g = "";
            for (var h = f.split(""), i = 0; i < h.length; i += 2) {
                g += String.fromCharCode(parseInt(h[i] + h[i + 1], 16));
            }
            return g;
        };
        var j = e(d);
        '''

    # set the local_vars
    local_vars = {}

    # set the should_abort
    should_abort = False

    # set the objects
    objects = {}

    # set the statement3

# Generated at 2022-06-22 09:08:51.583363
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    test_stmts = {
        'a': 'var a=1',
        'b': 'var b=a',
        'c': 'return c',
        'd': 'return d + 1',
        'e': 'return e + 3;',
        'f': 'return /*comment*/ 1 /*comment*/',
        'g': 'return 1;',
        'h': 'return 1'
    }

    for (var, stmt) in test_stmts.items():
        expected = var
        interpreter = JSInterpreter(stmt)
        actual, _ = interpreter.interpret_statement(stmt, {})
        assert actual == expected, (
            'Wrong result for JS Interpreter %s' % var)


# Generated at 2022-06-22 09:08:58.595406
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = """
        var aa = {
            a: function(p){
                return p
            },
            b: function(p){
                return p
            },
            c: function(p){
                return p
            }
        }
        var bb = {
            a: function(p){
                return p
            },
            b: function(p){
                return p
            },
            c: function(p){
                return p
            }
        }
    """
    jsi = JSInterpreter(code)
    print(jsi)
    obj = jsi.extract_object("aa")
    print(obj)



# Generated at 2022-06-22 09:09:03.542494
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    _INTERPRETER_TEST_CODE = '''\
        yt.a.e = function (a, b) {
            return a[b]
        };
        yt.a.f = function (a, b) {
            return a[b]
        };
        yt.a.g = function (a, b) {
            return a[b]
        };
        yt.a.d = function (a) {
            return a
        }
        yt.a.h = function (a) {
            return a
        }
        yt.a.k = function (a) {
            return a
        }
        '''

    from .jsinterpreter import JSInterpreter
    interpreter = JSInterpreter(_INTERPRETER_TEST_CODE)

# Generated at 2022-06-22 09:09:13.100063
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        this.spf = {
            'script': function (src, f) {},
            'get': function (url, callback, errback) {},
            'getScript': function (url, callback, errback) {}
        };
        this.spf.init = function(config) {
            this.config_ = config || {};
            if (this.config_['animation-class']) {
                this.animationClass = this.config_['animation-class'];
            }
        };
    '''
    obj = JSInterpreter(code).extract_object('spf')
    assert obj == {
        'script': {},
        'get': {},
        'getScript': {},
        'init': {}
    }

# Generated at 2022-06-22 09:09:21.380577
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    # Create an js interpreter with code below
    code = '''
    var a = {
        x : 1,
        y : 'foo',
        z : true,
        print : function() {
            return this.x + this.y + this.z
        }
    };
    function add(x, y) {
        return x + y;
    }
    '''
    interpreter = JSInterpreter(code)

    # Check objects collected in interpreter
    a = interpreter.extract_object('a')
    assert a['x'] == 1
    assert a['y'] == 'foo'
    assert a['z'] == True
    assert a['print']() == '1fooTrue'
    add = interpreter.extract_function('add')
    assert add((1, 2)) == 3


# Generated at 2022-06-22 09:09:52.142678
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
    var obj = {}
    obj.a = 1
    obj.b = 2
    obj.func1 = function () {return 3}
    obj.func2 = function () {return 4}
    """
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object("obj")
    assert(obj['a'] == 1)
    assert(obj['b'] == 2)
    assert(obj['func1']() == 3)
    assert(obj['func2']() == 4)


# Generated at 2022-06-22 09:09:59.702639
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    test_js = '''
        function f(a,b,c){
            d = a + b;
            return d;
        }'''
    f = js_interpreter.build_function(['a','b','c'], test_js.strip())
    assert f((1,2,3)) == 3
    assert f((4,5,6)) == 9
    return True


# Generated at 2022-06-22 09:10:08.997213
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    def test_code(code, wanted):
        func_name = 'funcname'
        intp = JSInterpreter(code)
        func = intp.extract_function(func_name)
        if func(wanted[0]) == wanted[1]:
            return True
        else:
            raise ExtractorError('JSInterpreter_extract_function')

    # test if-else statement
    code = 'function funcname(arg){\
                if(arg > 4) return 2;\
                else return 3;\
            }'
    assert test_code(code, [5, 2])
    assert test_code(code, [4, 3])

    # test for statement