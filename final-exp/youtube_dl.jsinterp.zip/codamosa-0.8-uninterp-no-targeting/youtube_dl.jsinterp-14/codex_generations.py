

# Generated at 2022-06-22 09:01:24.649610
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    import unittest
    import ykdl.util.jsinterp as jsinterp
    import ykdl.util.html as htmlutil
    
    class TestJSInterpreter(unittest.TestCase):
        def _test_js(self, js, expected):
            js_code = htmlutil.find_js(js, 'script', 'src')
            self.assertIsNotNone(js_code, msg='Not found in the page:\n' + js)
            js_interp = jsinterp.JSInterpreter(js_code)
            actual = js_interp.call_function('d', 0, 0, 0)
            self.assertEqual(expected, actual, msg='When calling d(0, 0, 0)')
    

# Generated at 2022-06-22 09:01:35.169970
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():

    objects = {
        'XMLHttpRequest': {
            'prototype': {
                'open': lambda args: args,
                'setRequestHeader': lambda args: args,
                'send': lambda args: 'url=%s' % args,
            }
        }
    }


# Generated at 2022-06-22 09:01:46.054320
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interp = JSInterpreter(
        code='''var a = 1;''')

    # Test with an empty string
    assert js_interp.interpret_statement(
        stmt='',
        local_vars={},
        allow_recursion=100) == (None, False)

    # Test with a var
    assert js_interp.interpret_statement(
        stmt='var a = 1;',
        local_vars={},
        allow_recursion=100) == (1, False)

    # Test with a return
    assert js_interp.interpret_statement(
        stmt='return;',
        local_vars={},
        allow_recursion=100) == (None, True)

    # Test with a return with an expression

# Generated at 2022-06-22 09:01:51.147313
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    regular_test = JSInterpreter(
        '''var obj1={a:1,b:function(){return this.a;}}''')
    assert regular_test.call_function("obj1.b") == 1

    # Test for variable arguments

# Generated at 2022-06-22 09:01:59.138996
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('var test = function (arg1, arg2, arg3) { var arg4 = arg1.split(); arg4.reverse(); return arg4.join(arg2); }')
    func = js.build_function(('arg1', 'arg2', 'arg3'), 'var arg4 = arg1.split(); arg4.reverse(); return arg4.join(arg2);')
    assert func('abcd') == ['d', 'c', 'b', 'a']

# Generated at 2022-06-22 09:02:10.590137
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    local_vars = {"str": 'abc', "str2": 'cde', "a": "5", "b": "5", "c": "2", "d": '5', "e": '5'}
    js_interpreter = JSInterpreter(None)
    assert js_interpreter.interpret_expression("abc", local_vars, 100) == "abc"
    assert js_interpreter.interpret_expression("'abc'", local_vars, 100) == "abc"
    assert js_interpreter.interpret_expression("'abcdef'", local_vars, 100) == "abcdef"
    assert js_interpreter.interpret_expression("str", local_vars, 100) == "abc"

# Generated at 2022-06-22 09:02:15.059165
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    ret = JSInterpreter('function a(){return a + 1;}', {})
    assert ret.code == 'function a(){return a + 1;}'
    assert ret._functions == {}
    assert ret._objects == {}



# Generated at 2022-06-22 09:02:23.749700
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var a = 5, b = 2, c = {
            "d": function(a) { return a * 12; },
            "e": function(a, b) { return a * a + b * b; },
            "f": function() { return 3;}
        };
        var g = function(a, b, c){ return a + b + c;};
        var h = function(a, b, c) {
            var d = 12;
            return a + b * c + d;
        };
        var i = function(){
            var a = 1;
            return c.d(a);
        }
        var j = function(){
            var a = 10, b = 20, c = 30;
            return h(a, b, c);
        };
    '''


# Generated at 2022-06-22 09:02:26.218246
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    interpreter = JSInterpreter("a=20")
    assert interpreter.interpret_expression("a", {}) == 20


# Generated at 2022-06-22 09:02:36.667544
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
    function test(arg1, arg2) {
        var a = arg1;
        var b = 0;
        function test2(arg3, arg4) {
            var c = arg3;
            var d = b;
            var e = arg4;
            return (d + e) * c;
        }
        return a + test2(b, a);
    }
    '''
    js = JSInterpreter(code)
    extracted_func = js.extract_function('test')
    assert extracted_func(1, 2) == 2 + 0 * 1, 'Failed to extract function test() for args 1 and 2 with result 4'
    assert extracted_func(2, 1) == 1 + 2 * 1, 'Failed to extract function test() for args 2 and 1 with result 3'



# Generated at 2022-06-22 09:03:04.542607
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:03:08.917040
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = r'''
        {
            encodeURIComponent:function(a){return a},
            h:function(a){return a}
        }
    '''
    assert JSInterpreter(code).build_function(['a'], 'return a')(['foo']) == 'foo'


# Generated at 2022-06-22 09:03:17.841823
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        function myFunc(a, b, c) {
            var d = a;
            var e = b;
            return a + b/c;
        }
    """
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.extract_function('myFunc')([3, 7, 2]) == 5
    assert js_interpreter.call_function('myFunc', 3, 7, 2) == 5
    assert js_interpreter.interpret_expression('myFunc(3, 7, 2)', {}, 5) == 5


# Generated at 2022-06-22 09:03:29.273671
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    # 0
    expr = '0'
    local_vars = {}
    result = js_interpreter.interpret_expression(expr, local_vars, 100)
    assert result == 0
    # 1+2
    expr = '1+2'
    local_vars = {}
    result = js_interpreter.interpret_expression(expr, local_vars, 100)
    assert result == 3
    # 3*3-3
    expr = '3*3-3'
    local_vars = {}
    result = js_interpreter.interpret_expression(expr, local_vars, 100)
    assert result == 6
    # (1+2)*3-3
    expr = '(1+2)*3-3'
    local_v

# Generated at 2022-06-22 09:03:33.682657
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    test_code = '''function f() {return 'test'}'''
    js = JSInterpreter(test_code)
    res = js.call_function('f')
    assert res == 'test'


# Generated at 2022-06-22 09:03:46.379532
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:03:55.684188
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:04:04.735857
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
    var a = 0; var b = 2; a = b; var c = {
        "a": 1,
        "b": function(x) {
            return x * 2
        }
    }
    """
    ctx = JSInterpreter(code)
    ctx.interpret_expression('a', {}) == 2
    ctx.interpret_expression('b', {}) == 2
    ctx.interpret_expression('c["a"]', {}) == 1
    ctx.interpret_expression('c["b"](5)', {}) == 10
    ctx.interpret_expression('c["b"]', {})(5) == 10

# Generated at 2022-06-22 09:04:13.857948
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test function call
    func_code = '''
    function() {
        function f(a, b) {
            return a + b;
        }

        return f(5, 6);
    }
    '''
    assert JSInterpreter(func_code).call_function('', '') == 11

    # Test object member access
    func_code = '''
    function() {
        var a = {
            x: 5
        };

        return a.x;
    }
    '''
    assert JSInterpreter(func_code).call_function('', '') == 5

    # Test object member function call

# Generated at 2022-06-22 09:04:24.609397
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code_var = r'''(function() {
            var kz = function () {
                return 'dxYfPG4MC9Kj3q3djm_L-pPfTg'
            };
            function f(b) {
                return 7 << 3;
            };
            function g(b) {
                return b << 3;
            };
        })();'''
    code_window = r'''(function() {
            var kz = {
                f: function (b) {
                    return 7 << 3;
                },
                g: function (b) {
                    return b << 3;
                }
            };
        })();'''
    # Test 'kz' defined as var
    js_interpreter = JSInterpreter(code_var)

# Generated at 2022-06-22 09:04:47.165769
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:04:53.131026
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    JS_CODE = '''foo = {
        bar : function(a,b){
            return b;
        },
        zzz : function(){
            return 42;
        }
    }'''
    jsi = JSInterpreter(JS_CODE)
    obj = jsi.extract_function('foo')
    assert obj == {"bar": lambda args: args[1], "zzz": lambda args: 42}


# Generated at 2022-06-22 09:05:03.968170
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('''
        function foo(a,b,c) {
            d = a + b + c;
            return d;
        }
    ''')
    actual = js.build_function(['a', 'b', 'c'], 'd = a + b + c; return d;')([1, 1, 1])
    assert actual == 3
    actual = js.build_function(['a', 'b', 'c'], 'd = a + b + c; return d;')([2, 3, 4])
    assert actual == 9


# Generated at 2022-06-22 09:05:05.622120
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter is not None


# Generated at 2022-06-22 09:05:17.553252
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # TODO: Add more tests and assertions
    def test(code, objects=None):
        js_interpreter = JSInterpreter(code, objects)
        return js_interpreter.interpret_expression('x', {'x': 23})

    assert test('var x=1+2') == 3
    assert test('x') == 23
    assert test('1+5*3') == 16
    assert test('true') is True
    assert test('(function(){return 23;})()') == 23
    assert test('x.split("")') == list('23')
    assert test('x.charAt(0)') == '2'
    assert test('x[1]') == '3'
    assert test('x.length') == 2
    assert test('x.reverse()') == list('32')

# Generated at 2022-06-22 09:05:23.106168
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:05:28.277546
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    input = '''
        function func(arg1, arg2) {
            var a = arg1 * 2;
            return arg1 * arg2;
        }'''
    result = JSInterpreter(input).call_function('func', 3, 5)
    assert result == 15



# Generated at 2022-06-22 09:05:35.716592
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:05:46.195999
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        x = {
            y: function(a, b){
                return a + b;
            },
            z: function(b, c) {
                return b - c;
            }
        }
    '''
    js = JSInterpreter(js_code)

    x = js.extract_object('x')

# Generated at 2022-06-22 09:05:56.443760
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var a = 1;
        var b = 'hello';
        var c = {one: 1, two: 2};
        var d = "function(){return 1}";
        var e = [1,2];
        var f = [function(){return 1},function(){return 2;},function(){return 3;}];
        var g = function(h){return h+1;};
        '''
    objects = {}
    interpreter = JSInterpreter(code, objects)
    assert interpreter._objects == {'d': 'function(){return 1}'}
    assert objects['d'] == 'function(){return 1}'
    assert objects.get('e') is None
    assert interpreter.extract_object('c') == {'one': 1, 'two': 2}

# Generated at 2022-06-22 09:06:28.004725
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:06:41.200213
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = '''
    function hello(){
        return "hello";
    }

    function oops(a){
        return "oops" + a;
    }

    var obj = {
        fa: function(arg1, arg2){
            return arg1 + arg2;
        },
        fb: function(){
            return "fb";
        }
    }

    var arr = [1, 2, 3];

    function compose(f, g){
        return function(x){
            return f(g(x));
        }
    }

    function mult(a, b){
        return a * b;
    }
    '''

    def assertAlmostEqual(a, b):
        assert abs(a - b) < 1e-6

    jsi = JSInterpreter(js_code)

# Generated at 2022-06-22 09:06:52.338596
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    objects = {
        'foo': {'bar': lambda x: 'baz{0}'.format(x)},
        'obj': ['a', 'b', 'c'],
        }
    js = '''
        function fuz(index,a,b) {
            var c = b[index];
            c = c.replace("\\n", "");
            c = foo["bar"](c);
            if (c.substr(0, 3) == "fp_") {
                return c.slice(3);
            }
            return;
        }
    '''
    interp = JSInterpreter(js, objects)
    local_vars = {'index': 1, 'b': ['a', '\nb', 'c']}

# Generated at 2022-06-22 09:06:57.077191
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
var a = {
    "b": {
        "c": function(arg) {
            if (arg == 10) {
                return "ten";
            }
            return "something else";
        }
    }
}
'''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('a.b.c', 10) == 'ten'
    assert js_interpreter.call_function('a.b.c', 11) == 'something else'

# Generated at 2022-06-22 09:07:08.785262
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    assert JSInterpreter('').interpret_statement('1', {})[0] == 1
    # Test boolean logic
    assert JSInterpreter('').interpret_statement('1 && 0', {})[0] == 0
    assert JSInterpreter('').interpret_statement('1 || 0', {})[0] == 1
    assert JSInterpreter('').interpret_statement('1 | 0', {})[0] == 1
    assert JSInterpreter('').interpret_statement('1 & 0', {})[0] == 0
    assert JSInterpreter('').interpret_statement('1 ^ 0', {})[0] == 1
    # Test arithmetic
    assert JSInterpreter('').interpret_statement('2 + 2', {})[0] == 4

# Generated at 2022-06-22 09:07:21.538854
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:07:25.386817
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter(r'').build_function([], 'return 1')() == 1
    assert JSInterpreter(r'').build_function(['a', 'b'], 'return a + b')(1, 2) == 3
    assert JSInterpreter(r'').build_function(['a', 'b'], '''
        var t = 2;
        return a + b + t;
        ''')(1, 2) == 5


# Generated at 2022-06-22 09:07:36.158363
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def test(expr, expected_result, objects=None):
        if objects is None:
            objects = {}
        jsinterpreter = JSInterpreter(code='', objects=objects)
        result = jsinterpreter.interpret_expression(expr, {}, 100)
        assert expected_result == result
    test("1+1", 2)
    test("true", True)
    test("'a'+'b'", "ab")
    test("'a'.length", 1)
    test("'a b'.split(' ')", ['a', 'b'])
    test("'abc'.slice(2)", 'c')
    test("['a','b','c'].join('.')", 'a.b.c')
    test("['a','b','c'].reverse()", ['c', 'b', 'a'])
   

# Generated at 2022-06-22 09:07:44.865445
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsi = JSInterpreter('')
    assert jsi.interpret_statement('123')[0] == 123
    assert jsi.interpret_statement('-123')[0] == -123
    assert jsi.interpret_statement('1+1')[0] == 2
    assert jsi.interpret_statement('1+1;2+3')[0] == 5
    assert jsi.interpret_statement('-123')[0] == -123
    assert jsi.interpret_statement('var s=123;s+1')[0] == 124
    assert jsi.interpret_statement('return 123', {})[0] == 123
    assert jsi.interpret_statement('var x=1;return x;2+3')[0] == 1

# Generated at 2022-06-22 09:07:54.381159
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter.build_function(['a', 'b'], 'a+b')((1, 2)) == 3
    assert JSInterpreter.build_function(['a', 'b'], 'a+b')((3, 3)) == 6

_PROPERTY_EXTRACTOR_RE = re.compile(
    r'(?:[a-zA-Z$0-9]+|"[a-zA-Z$0-9]+"|\'[a-zA-Z$0-9]+\')\s*:\s*function\s*\((?P<args>[^)]*)\)\s*{(?P<body>[^}]+)}')


# Generated at 2022-06-22 09:08:52.404007
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:08:55.418428
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    jsint = JSInterpreter("""
        function test(v) {
            return v+1;
        }
    """)
    assert jsint.call_function("test", 1) == 2

# Generated at 2022-06-22 09:09:06.374449
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():

    code = """
        function test_1(a) {
            return a + 1;
        }

        function test_2(a, b) {
            function internal_1(a, b) {
                return a + b;
            }

            return internal_1(a, b);
        }
    """

    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('test_1', 1) == 2
    assert js_interpreter.call_function('test_2', 2, 4) == 6

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-22 09:09:14.819748
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = r'''
      function test0(a,b,c){
        return a+b+","+c
      }
      test0(1,2,"3")
    '''
    jsinterpreter = JSInterpreter(js_code)
    test0 = jsinterpreter.extract_function("test0")
    assert test0(["a","b","c"]) == "a,b,c", "build_function() failed: test0(['a','b','c']) is not equal"

    js_code = r'''
      var test1 = function(a,b,c){
        return a+b+","+c
      }
      test1(1,2,"3")
    '''
    jsinterpreter = JSInterpreter(js_code)
    test1 = js

# Generated at 2022-06-22 09:09:26.855557
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interp = JSInterpreter('')

    # Assign operator
    v, _ = interp.interpret_statement('var a = b', {'b': 5})
    assert v == 5
    # Comma operator
    v, _ = interp.interpret_statement('return 1, 2', {})
    assert v == 2

    # Simple binary expressions
    v, _ = interp.interpret_statement('var a = 1 + 2', {})
    assert v == 3
    v, _ = interp.interpret_statement('var a = 3 - 2', {})
    assert v == 1
    v, _ = interp.interpret_statement('var a = 2 * 3', {})
    assert v == 6
    v, _ = interp.interpret_statement('var a = 8 / 4', {})
    assert v == 2
   

# Generated at 2022-06-22 09:09:31.448498
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
    function myFunc(a, b) {
        return a + b;
    }
    """
    interpreter = JSInterpreter(code)
    assert 7 == interpreter.call_function('myFunc', 3, 4)


# Generated at 2022-06-22 09:09:40.630805
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-22 09:09:51.863282
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:10:03.420349
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    from unittest import TestCase
    from .utils import _SearchResult, _regex_search
    tc = TestCase()
    js_interpreter = JSInterpreter('')
    tc.assertEqual(
        js_interpreter.interpret_statement('a = 123', {'a': 0}),
        (_SearchResult(123), False))
    tc.assertEqual(
        js_interpreter.interpret_statement('a[0] = "abc"', {'a': [1, 2, 3]}),
        (_SearchResult('abc'), False))
    tc.assertEqual(
        js_interpreter.interpret_statement('a = []', {'a': None}),
        (_SearchResult([1,2,3]), False))

# Generated at 2022-06-22 09:10:11.895633
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''function a(){}var b={
        c:function(d){return d},
        e:function(f,g){return f+g},
        h:function(i,j){return i+j-f}
    };'''
    js_interp = JSInterpreter(js_code)
    obj = js_interp.extract_object('b')

    assert obj['c']('d') == 'd'
    assert obj['e']('f', 'g') == 'fg'
    assert obj['h']('i', 'j') == 'ij'
