

# Generated at 2022-06-22 09:01:11.751061
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter


# Generated at 2022-06-22 09:01:22.138255
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = r'''function aaabbbcccddd(p, a, c, k, e, d) {
    e = function(c) {
        return c
    };
    if (!''[c]) {
        k = e(c)
    }
    ;
    if (!''[c]) {
        return p
    }
    ;
    while (--d) {
        if (!''[c](k, e)(f)) {
            break
        }
    }
    ;
    return a
}'''
    interpreter = JSInterpreter(code, {})
    function = interpreter.extract_function('aaabbbcccddd')
    assert function(('a', 'b', 'c', 'd', 'e', 'f')) == 'a'

# Generated at 2022-06-22 09:01:33.873305
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_interpreter = JSInterpreter('''function foo() {
        var bar = { funcA: function(){},
                    funcB: function(param){}
                  }
    }''')
    obj = js_interpreter.extract_object('bar')
    assert callable(obj['funcA'])
    assert callable(obj['funcB'])

    js_interpreter = JSInterpreter('''function foo() {
        var bar = {
                funcA: function(){},
                funcB: function(param){},

                prop: true
                }
    }''')
    obj = js_interpreter.extract_object('bar')
    assert callable(obj['funcA'])
    assert callable(obj['funcB'])
    assert obj['prop'] is True

    js_

# Generated at 2022-06-22 09:01:40.312328
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
  test_code = """
        function test1(a, b)
        {
            return "ab"[a] * b;
        }
    """
  js_interpreter = JSInterpreter(test_code)
  res1 = js_interpreter.call_function("test1", 1, 2)
  if res1 != "bb":
    print ("test_JSInterpreter_call_function failed")


# Generated at 2022-06-22 09:01:48.656545
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
       {
          "a": "b",
          "c": "d"
       }
       var objName = {
          "func1": function(a,b) { return a + b },
          "func2": function(a,b) { return a - b }
       }
    '''
    interpreter = JSInterpreter(code)

    obj = interpreter.extract_object('objName')

    assert isinstance(obj, dict)
    assert 'func1' in obj
    assert 'func2' in obj

    assert obj['func1'](3, 5) == 8
    assert obj['func2'](3, 5) == -2

# Generated at 2022-06-22 09:02:01.257759
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    test_str = "var a = 'a1'; function a() { var b, c = 'c1'; var d = {'d1':1, 'd2':2, 'd3':3, 'd4':4}; return a; }"
    interpreter = JSInterpreter(test_str)
    assert (interpreter.interpret_statement("var a = 'a1';", {})[0] == "'a1'") 
    # test function call
    assert (interpreter.interpret_statement("a()", {})[0] == "'a1'")
    # test value of variable
    assert (interpreter.interpret_statement("a", {})[0] == "'a1'")
    # test value of variable with array key

# Generated at 2022-06-22 09:02:11.954443
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:02:17.495148
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # TODO: Add more tests
    js_interpreter = JSInterpreter('var a = 5;')
    assert js_interpreter.interpret_expression('a', {}) == 5
    assert js_interpreter.interpret_expression('(a)', {}) == 5
    assert js_interpreter.interpret_expression('{a:5}', {}) == {'a': 5}
    assert js_interpreter.interpret_expression('a.b', {}) == {'a': 5}['b']

# Generated at 2022-06-22 09:02:22.573549
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    text = '''
    var f1 = {
       "a": function(p){}
    };
    var f2 = {
       "b": function(p){}
    };
    '''

    js = JSInterpreter(text)
    obj = js.extract_object('f1')
    assert obj == {'a': js._functions['a']}

# Generated at 2022-06-22 09:02:34.311334
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def _test_expr(expr, expected_result, obj):
        assert JSInterpreter('', obj).interpret_expression(expr, {}) == expected_result
    _test_expr('(4 + 4)', 8, {})
    _test_expr('(4 + x)', 8, {})
    _test_expr(
        '"a".split("").reverse().join("")', 'a',
        {'a': 'a'.split('').reverse()})
    _test_expr('"a".indexOf("a")', 0, {})
    _test_expr('"a".indexOf("b")', -1, {})
    _test_expr('"a"[0]', 'a', {})
    _test_expr('"a".length', 1, {})

# Generated at 2022-06-22 09:02:56.642193
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:03:06.358616
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''function abc(a, b, c) {
        return (a + b) * c;
    }

    var $ = {
        decode: function(e) {
            e = e.split("");
            for (var t = a.length - 1; t >= 0; t--) {
                var n = a[t];
                i = o[n],
                i && (e = e.join(i).split(n))
            }
            return e.join("")
        },
        x: function(e) {
            return e.split("").reverse().join("")
        },
        splice: function(e) {
            return e.splice(1)
        },
        slice: function(e) {
            return e.slice(1)
        }
    };'''

   

# Generated at 2022-06-22 09:03:13.775696
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
    var a = {
        "b": function(n) {return n},
        "c": function(n) {return n+1},
        "d": "e",
    };"""
    objs = JSInterpreter(code)._objects
    assert len(objs) == 1
    assert objs["a"] == {"b": lambda n : n, "c": lambda n : n + 1, "d": "e"}



# Generated at 2022-06-22 09:03:23.819545
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('')
    test_cases = [
        ('jwplayer().onTime(function() {return ""})', None),
        ('jwplayer().seek(e.position)', None),
        ('jwplayer().onTime(function() {if(i.expired==true) {return false;}})', False),
        ('jwplayer().onTime(function() {\nif (1) return true;})', True),
        ('jwplayer().onTime(function() {\nif (1) return 1;})', 1),
        ('jwplayer().onTime(function() {\nif (1) return 1+1;})', 2),
    ]
    for test_case in test_cases:
        result = interpreter.interpret_expression(test_case[0], {})
        assert result == test_

# Generated at 2022-06-22 09:03:30.125640
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_interpreter = JSInterpreter("""
    function callMe(y) {
    return y;
    }
    var a = {
    myFunc: function(arg1) {
    console.log("Hi I am a function");
    }
    }
    """)
    assert js_interpreter.call_function("callMe", "Hello") == "Hello"
    assert js_interpreter.interpret_expression("a.myFunc()", {}) is None


# Generated at 2022-06-22 09:03:38.139583
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Easy case
    code = 'function gd(b) {return b.reverse()}'
    jsi = JSInterpreter(code)
    f = jsi.extract_function('gd')
    assert f([1, 2, 3]) == [3, 2, 1]

    # Expression as parameter
    code = 'function gd(b) {return b.slice(3)}'
    jsi = JSInterpreter(code)
    f = jsi.extract_function('gd')
    assert f([1, 2, 3]) == []

    # Hoisting
    code = 'function gd(b) {var d=b.length;return b.slice(d-3)}'
    jsi = JSInterpreter(code)
    f = jsi.extract_function('gd')

# Generated at 2022-06-22 09:03:43.026184
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsinter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2}
    assert jsinter.interpret_statement('a=a*b', local_vars) == (2, False)
    assert local_vars['a'] == 2


if __name__ == '__main__':
    test_JSInterpreter_interpret_statement()

# Generated at 2022-06-22 09:03:52.645767
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter("""
    var a = {b:function(){var b='c';return '3'+b;},e:['a','b','c'],f:[1,2,3],g:[{h:40},{h:41},{h:42}]};
    """)
    assert js.interpret_expression('a.b', {}) == '3c'
    assert js.interpret_expression('a.e[1]', {}) == 'b'
    assert js.interpret_expression('a.f.slice(1)', {}) == [2, 3]
    assert js.interpret_expression('a.g[1].h', {}) == 41
    assert js.interpret_expression('a.g.slice(1)[0].h', {}) == 41

# Generated at 2022-06-22 09:04:02.898097
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = """
        b = {
            decode: function(a) {
                a = a.split("");
                a = a.reverse();
                a = a.join("");
                return a;
            }
        };
    """
    js_i = JSInterpreter(js)
    assert  js_i.call_function('b.decode', 'demo') == 'omed'
    assert  js_i.call_function('b.decode', ['1','2','3','4','5','6','7','8','9','0']) == '0123456789'

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-22 09:04:13.124153
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = r'''
    var r = function (a,b) {
        var c = arguments[0],
            d = arguments[1];
        var e = arguments;
        var f = parseInt(c, 10);
        var g, h;
        e[0] = function(a,b){return a+b+1;};
        e[1] = '2';
        g = e[0](f,d);
        h = function () {
            return f+d;
        }();
        return g+h;
    };'''
    js = JSInterpreter(js_code)
    func = js.build_function(['a','b'], js_code.split('{')[1].split('}')[0])
    print(func((1,2)))


# Generated at 2022-06-22 09:04:37.334411
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    jsi = JSInterpreter('''
        function function1(arg1) {
        }
    ''')
    assert jsi.extract_function('function1')

    jsi = JSInterpreter('''
        var function1 = function(arg1) {
        }
    ''')
    assert jsi.extract_function('function1')

    jsi = JSInterpreter('''
        obj1 = {
            function1: function(arg1) {
            }
        }
    ''')
    assert jsi.extract_function('obj1.function1')

    jsi = JSInterpreter('''
        var obj1 = {
            function1: function(arg1) {
            }
        }
    ''')

# Generated at 2022-06-22 09:04:45.746332
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    '''
    Test method extract_object of class JSInterpreter
    '''
    test_code = '''
        var a = {
            "abc":function(){
                return 1;
            },
            "bcd":function(arg){
                if (arg == 0) {
                    return 1;
                }
                return 0;
            }
        };
    '''
    js_interpreter = JSInterpreter(test_code)
    func = js_interpreter.extract_object("a")
    assert func["abc"]() == 1
    assert func["bcd"](0) == 1
    assert func["bcd"](1) == 0


# Generated at 2022-06-22 09:04:53.399430
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = """
        var a = {};
        a.b = function() {
            return 10;
        };
        a.c = function(a, b) {
            return a + b;
        };
        var d = a;
    """
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('d')
    assert obj['b']() == 10
    assert obj['c'](1, 2) == 3

# Generated at 2022-06-22 09:05:05.926316
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    def _test_for_func(funcname, expected_args, expected_body):
        actual_args, actual_body = JSInterpreter(code, {}).extract_function(funcname)
        print("actual_args = ", actual_args)
        print("actual_body = ", actual_body)
        assert actual_args == expected_args
        assert actual_body == expected_body


# Generated at 2022-06-22 09:05:17.654434
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter('')
    local_vars = {
        'k': 4,
        'b': 15,
        'a': 12,
        'f': [(0, 0)],
        'g': [[(0, 0)], [(0, 0)]],
        'l': ['A', 'B', 'C'],
    }

    res, abort = interpreter.interpret_statement('return;', local_vars)
    assert res is None and abort is True
    res, abort = interpreter.interpret_statement('a + g[0][0][0];', local_vars)
    assert res == 12 and abort is False
    res, abort = interpreter.interpret_statement('return f[0][0];', local_vars)
    assert res == 0 and abort is True
    res, abort = interpreter.interpret_

# Generated at 2022-06-22 09:05:22.985720
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter('')
    local_vars = {'a': None}

    # Test to check the return value of an expression
    res, abort = js.interpret_statement('a=5', local_vars)
    assert local_vars['a'] == 5
    assert res == 5
    assert not abort

    # Test to check the return value of a var expression
    res, abort = js.interpret_statement('var a=5', local_vars)
    assert res == 5
    assert not abort

    # Test to ensure return is aborting
    local_vars = {'a': None}
    res, abort = js.interpret_statement('return a=5', local_vars)
    assert res == 5
    assert abort


# Generated at 2022-06-22 09:05:33.338462
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    from .youtube import YoutubeIE

    js_code = YoutubeIE._FILE_SIG_FUNC
    interpreter = JSInterpreter(js_code)

    # Extract object srt
    srt = interpreter.extract_object('srt')
    assert isinstance(srt, dict)
    assert len(srt) == 4
    assert srt['signature']('abc') == 'abc'
    assert srt['split']('abcde') == ['a', 'b', 'c', 'd', 'e']
    assert srt['join']([1, 2, 3]) == '1,2,3'
    assert srt['slice']([1, 2, 3]) == [2, 3]

    # Extract object t
    t = interpreter.extract_object('t')
    assert isinstance(t, dict)


# Generated at 2022-06-22 09:05:39.946298
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = r'''
    function abc() {
        var a = {b: function(p) {
            return p - 1;
        }};
        return a.b(3);
    }'''
    expect_res = 2
    js_interpreter = JSInterpreter(code)
    act_res = js_interpreter.call_function('abc')
    assert act_res == expect_res


# Generated at 2022-06-22 09:05:50.990059
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Testing extracting functions that are declared between {}
    js_code = '''var some_code = 1;
    var f1 = function(a){
        code_without_functions = 2;
        var x = a;
        var f2 = function(b){return x + b;};
        return 3;
    };'''
    interpreter = JSInterpreter(js_code)
    f1 = interpreter.extract_function('f1')
    f2 = interpreter.extract_function('f2')

    # Testing extracting functions that are declared with var

# Generated at 2022-06-22 09:05:57.091518
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    test_js_1 = '''
        function a(a,b){var c;if((a==1)&&(b==1)){c=1}else if((a==1)&&(b==2)){c=2}else{c=3};return c};
    '''
    test_js_2 = '''
        function a(a,b){var c;if((a==1)&&(b==1)){c=1};return c};
    '''
    test_js_3 = '''
        var a=function(){return 1};
    '''
    test_js_4 = '''
        var a={c:function(a,b){var c;return a-b}};
    '''

# Generated at 2022-06-22 09:06:25.838614
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var myObj = {
            baz: function(a, b, c) {
                return a + b + c;
            },
            q: 1,
            m: function(e, f) {
                var g = "hello " + e + f;
                return g;
            },
            n: 4,
            o: function(h, i) {
                var j = h + i + this.n;
                return j;
            }
        }
    '''
    interpreter = JSInterpreter(js_code)
    obj = interpreter.extract_object('myObj')
    assert obj['q'] == 1
    assert obj['m']('world', '!') == 'hello world!'
    assert obj['o']('world', '!') == 'world!4'

# Generated at 2022-06-22 09:06:31.468826
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():

    # Test for function split_js_variables_definition
    def test_split_js_variables_definition(code, expected):
        js = JSInterpreter(code)
        args = js.split_js_variables_definition('var %s' % code)
        assert args == expected, 'Unexpected result for %r: %r != %r' % (code, args, expected)

    test_split_js_variables_definition('a', ['a'])
    test_split_js_variables_definition('a=1', ['a'])
    test_split_js_variables_definition('a=1,b', ['a', 'b'])
    test_split_js_variables_definition('a=b', ['a'])

# Generated at 2022-06-22 09:06:43.169136
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    assert None is JSInterpreter(
        '''
            var a = 3, b = 2;
            var add = function(a, b) {
                return a + b;
            };
        ''').call_function('add', a = 3, b = 2)

    assert 4 is JSInterpreter(
        '''
            var a = 3, b = 2;
            var add = function(a, b) {
                return a + b;
            };
        ''').call_function('add', a = 1, b = 3)

    assert -1 is JSInterpreter(
        '''
            var a = 3, b = 2;
            var diff = function(a, b) {
                return a - b;
            };
        ''').call_function('diff', a = 3, b = 4)



# Generated at 2022-06-22 09:06:53.054160
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:07:03.074104
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        var testfunc = function(arg1, arg2) {
            return arg1 + arg2;
        }
    '''
    assert JSInterpreter(code).call_function('testfunc', 5, 9) == 14

    code = '''
        var decryptSignature = function(sig) {
            return sig.split("").reverse().join("")
        }
    '''
    assert JSInterpreter(code).call_function('decryptSignature', 'test') == 'tset'

    code = '''
        var abc = {
            "def": function(arg1) {
                var a = arg1 + 2;
                return a;
            }
        }
    '''

# Generated at 2022-06-22 09:07:15.791582
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:07:26.454109
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    JSInterpreter_interpret_expression = JSInterpreter('').interpret_expression
    assert JSInterpreter_interpret_expression('1', {}) == 1
    assert JSInterpreter_interpret_expression('1+1', {}) == 2
    assert JSInterpreter_interpret_expression('"a" + "b"', {}) == 'ab'
    assert JSInterpreter_interpret_expression('[1,2,3]', {}) == [1, 2, 3]
    assert JSInterpreter_interpret_expression('a', {'a': 2}) == 2
    assert JSInterpreter_interpret_expression('a + 1', {'a': 2}) == 3
    assert JSInterpreter_interpret_expression('c=a+1', {'a': 2}) == 3

# Generated at 2022-06-22 09:07:37.363449
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test interpret_expression function
    js_interpreter = JSInterpreter("")
    local_vars = {"b": 5, "y": 7, "a": 1}  # local_vars

    test_expr = ("5+5*5-5&5^5<<5>>5%5/5", (5 + 5 * 5 - 5 & 5 ^ 5 << 5 >> 5 % 5 / 5))
    result = js_interpreter.interpret_expression(test_expr[0], local_vars)
    assert result == test_expr[1]


# Generated at 2022-06-22 09:07:49.092944
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_code = '''
        function test(a) {
            var b = a[2];
            return b;
        }
    '''
    assert JSInterpreter(test_code).interpret_expression('test([1, 2, 3, 4])', {}) == 3
    assert JSInterpreter(test_code).interpret_expression('test([0])', {}) == None
    assert JSInterpreter(test_code).interpret_expression('test([0, 0, "abcd", "efgh"])', {}) == "abcd"
    assert JSInterpreter(test_code).interpret_expression('test([0, 0, "abcd", "efgh"]) + "a"', {}) == "abcda"

# Generated at 2022-06-22 09:07:54.855555
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var Test = {
            "abc": function(q) { return q; },
            def: function(a, b) { return a + b; }
        };
    """
    jsi = JSInterpreter(code)
    obj = jsi.extract_object('Test')
    assert obj['abc']('cde') == 'cde'
    assert obj['def'](1, 2) == 3

if __name__ == '__main__':
    test_JSInterpreter_extract_object()

# Generated at 2022-06-22 09:08:20.994781
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test_equal(func, arg, expected):
        if func(arg) != expected:
            raise ExtractorError('Failed')
    code = r'''
        function g(a) {
            a = a.toString();
            var b = [];
            if (a) {
                var c = a.length / 2;
                b[0] = a.substr(0, c);
                b[1] = a.substr(c)
            }
            return b
        }
    '''
    JSInterpreter(code).build_function(['a'], code)
    test_equal(JSInterpreter(code).build_function(['a'], code), 'foo', ['f', 'oo'])

# Generated at 2022-06-22 09:08:28.014243
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = r'''
		function abc(num) {
			return num * num;
		}
		function def(num) {
			return abc(num) + num;
		}
		function ghi(num) {
			return abc(num) * num;
		}
	'''
    a = JSInterpreter(js_code)
    result = a.call_function('def', 5)
    assert result == 30
    result = a.call_function('ghi', 7)
    assert result == 49
    result = a.call_function('abc', 100)
    assert result == 10000

# Generated at 2022-06-22 09:08:33.616141
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    import pdb
    #pdb.set_trace()
    code = """function() {
        var xxxxx = {
            c: function(a, b) {
                return a * b;
            }
        }
    }
    """
    jsinter = JSInterpreter(code)
    assert jsinter._objects['xxxxx']['c'](5,5) == 25



# Generated at 2022-06-22 09:08:39.829218
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
    function a(b, c){
        return c;
    }
    function d(e, f){
        return e;
    }"""
    inter = JSInterpreter(code)
    assert inter.extract_function('a')(('one', 'two')) == 'two'
    assert inter.extract_function('d')(('one', 'two')) == 'one'


# Generated at 2022-06-22 09:08:49.220085
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:08:56.407534
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    JSI = JSInterpreter
    assert JSI('var foo=1').interpret_statement('foo', {}) == 1
    assert JSI('var foo=1').interpret_statement('foo', {}) == 1
    assert JSI('var foo=1').interpret_statement('return foo', {}) == 1
    assert JSI('var foo=1').interpret_statement('foo=2', {}) == 2

    assert JSI('var foo=1').interpret_statement('return', {})[1] == True


# Generated at 2022-06-22 09:09:01.277503
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        function test() {
            var a = 5;
            var b = 4;
            return c = a + b;
        }
        '''
    jsi = JSInterpreter(code)
    assert jsi.call_function('test') == 9


# Generated at 2022-06-22 09:09:12.240762
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsi = JSInterpreter("function test_function1(arg1,arg2,arg3){var arg4=arg1*arg2+arg3;return arg4*10;}var v1=1;var v2=2;var v3=3; ")
    res, abort = jsi.interpret_statement("return arg4*10;", {"arg1":1,"arg2":2,"arg3":3})
    assert res == 60
    assert abort == True
    jsi = JSInterpreter("function test_function1(arg1,arg2,arg3){var arg4=arg1*arg2+arg3;return arg4*10;}var v1=1;var v2=2;var v3=3; ")

# Generated at 2022-06-22 09:09:20.222253
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    javascript_code = """
        var Test;
        Test = (function() {
          return function() {};
        })();

        Test.prototype.test_method = function(a, b, c) {
            return a + b + c;
        };

        Test.prototype.test_method2 = function(a, b) {
            return a - b;
        };
    """

    jsint = JSInterpreter(javascript_code)
    assert jsint.call_function('Test.test_method', 1, 2, 3) == 6
    assert jsint.call_function('Test.test_method2', 8, 4) == 4

# Generated at 2022-06-22 09:09:30.341268
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    s = '''
        var obj = {
            member1: function(args) {
                return args[0] + args[1]
            },
            member2: function(a, b) {
                return a*b
            },
            member3: 'abc',
            member4: [1,2,3,4]
        };
    '''
    i = JSInterpreter(s)
    obj = i.extract_object('obj')
    assert obj['member1']([1, 2]) == 3
    assert obj['member2'](3, 4) == 12
    assert obj['member3'] == 'abc'
    assert obj['member4'][1:] == [2, 3, 4]


# Generated at 2022-06-22 09:09:57.042320
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str = """
        function test1(a,b,c) {
            b = parseInt(parseInt(a)/1000);
            c = parseInt((parseInt(a) - 1000 * parseInt(b))/10);
            return parseInt(a) - 1000 * parseInt(b) - 10 * parseInt(c);
        }
        """
    jsInterpreter = JSInterpreter(str)
    assert jsInterpreter.call_function("test1", "1230") == 0
    assert jsInterpreter.call_function("test1", "1") == 1
    assert jsInterpreter.call_function("test1", "111") == 1
    assert jsInterpreter.call_function("test1", "1111") == 1

if __name__ == '__main__':
    test_JSInterpreter

# Generated at 2022-06-22 09:10:05.305377
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_interpreter = JSInterpreter('''
        var a = function(b) {
            var c = function(d) {
                return b + d;
            }
            return c;
        }
        var e = a(1);
        var f = e(2);
        return f;
    ''')
    assert js_interpreter.interpret_statement('return f;')[0] == 3
    assert js_interpreter.interpret_statement('return e(2);')[0] == 3
    assert js_interpreter.interpret_statement('return e(3);')[0] == 4

