

# Generated at 2022-06-22 09:00:49.274299
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter('')
    function = interpreter.build_function([], '; return 1;')
    assert function(()) == 1

# Generated at 2022-06-22 09:01:01.536961
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter("""
        foo.bar(123);
        foo.bar("abc");
        var foo = {bar: function(a) {
            return "asd" + a;
        }}
        """)
    assert jsi.interpret_expression("foo.bar(123)", {}) == "asd123"
    assert jsi.interpret_expression("foo.bar(\"abc\")", {}) == "asdabc"
    assert jsi.interpret_expression("foo[\"bar\"](\"abc\")", {}) == "asdabc"
    assert jsi.interpret_expression("foo.bar(\"abc\") + foo.bar(123)", {}) == "asdabcasd123"

# Generated at 2022-06-22 09:01:08.968112
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    from .common import ExtractorError

    objects = JSInterpreter("""
        var c  = {
            d : function(a, b) { return a },
        }
        """, {})

    def f(*args):
        return objects.call_function("c.d", *args)

    assert f(5, 3) == 5
    assert f(3, 5) == 3
    assert f(5.0, 3.0) == 5.0
    assert f(3.0, 5.0) == 3.0
    assert f("5", "3") == "5"
    assert f("3", "5") == "3"
    assert f("5", 3) == "5"
    assert f("3", 5) == "3"
    assert f(5.0, "3.0") == 5.0

# Generated at 2022-06-22 09:01:19.343856
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    if 'js_interpreter' not in globals():
        js_interpreter = JSInterpreter(open('data/base.js', 'r').read())

    assert js_interpreter.interpret_expression('2 + 3 + 7', {}, 500) == 12
    assert 3 in js_interpreter.interpret_expression('[2, 3, 4]', {}, 500)
    assert js_interpreter.interpret_expression('({a: 2, b: 4})', {}, 500)['b'] == 4
    assert js_interpreter.interpret_expression('({a: 2, b: 4})["a"]', {}, 500) == 2
    assert js_interpreter.interpret_expression('[1][0]', {}, 500) == 1

# Generated at 2022-06-22 09:01:28.613507
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def build_test(code,args,result):
        jsint = JSInterpreter(code)
        func = jsint.build_function(['a','b','c'],code)
        if func(args) != result:
            import sys
            sys.stderr.write('ERROR!\n')
            sys.stderr.write('code: %s\n' % code)
            sys.stderr.write('args: %s\n' % args)
            sys.stderr.write('result: %s\n' % result)
            sys.stderr.write('\n')
            sys.exit(1)

    build_test('d=a+b+c;return d;','abc', 'abc')

# Generated at 2022-06-22 09:01:36.322600
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = r'''
        var ytplayer = {
            'config': {
                'url_encoded_fmt_stream_map': 'url=encoded%3Dfmt%3Dstream%26map'
            },
            'args': {
                'url_encoded_fmt_stream_map': 'url=encoded%3Dfmt%3Dstream%26map'
            }
        };
    '''
    interpreter = JSInterpreter(js_code)
    obj = interpreter.extract_object('ytplayer')
    if obj['config']['url_encoded_fmt_stream_map'] != 'url=encoded=fmt=stream&map':
        print('Wrong value for object ytplayer')

# Generated at 2022-06-22 09:01:46.728193
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = """var aa = function() {
            return parseInt("123456789")+"";
        }();
        var bb = function() {
            return parseInt("987654321")+"";
        }();
        var cc = function() {
            return aa.slice(3,6);
        }();
        var dd = function() {
            return bb.slice(3,6);
        }();"""

    jsinter = JSInterpreter(js)
    print('123456789')
    print(jsinter.call_function('aa'))
    print('987654321')
    print(jsinter.call_function('bb'))
    print('456')
    print(jsinter.call_function('cc'))
    print('654')

# Generated at 2022-06-22 09:01:51.034218
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    s = '''
var A = {
    B: function (C) {
        return (C + 10) ^ 4;
    }
};
var D = function (E, F) {
    return E + F;
}
'''
    jsi = JSInterpreter(s)
    assert jsi.call_function('A.B', 1) == 0
    assert jsi.call_function('D', 1, 2) == 3



# Generated at 2022-06-22 09:02:02.652830
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:02:06.139086
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    obj = {}
    obj_code = '''
    var a = {
        b: function(arg1) {
            c.d(arg1);
        }
    };
    '''
    interp = JSInterpreter(obj_code, {
        'c': {
            'd': lambda arg1, arg2: arg1 * arg2
        }
    })
    val, abort = interp.interpret_statement('a.b(3, 4)', {})
    assert val == 12 and abort is True
    return "test_JSInterpreter_interpret_statement() passed successfully"

print(test_JSInterpreter_interpret_statement())

# Generated at 2022-06-22 09:02:36.294167
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter("")
    local_vars = {'a': 46, 'b': 2}
    assert interpreter.interpret_statement("return a;", local_vars)[0] == 46
    assert interpreter.interpret_statement("return b;", local_vars)[0] == 2
    assert interpreter.interpret_statement("return a+b;", local_vars)[0] == 48
    assert interpreter.interpret_statement("a+b;", local_vars)[1] == False
    assert interpreter.interpret_statement("return a>>b;", local_vars)[0] == 11
    assert interpreter.interpret_statement("return a|b;", local_vars)[0] == 47
    assert interpreter.interpret_statement("return a&b;", local_vars)[0] == 0

# Generated at 2022-06-22 09:02:44.556793
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:02:51.494909
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': ['1', '2', '3'], 'b': ['4', '5', '6']}
    tests = [('a[0]', '1'), ('a[1]', '2')]
    for expression, result in tests:
        assert result == js_interpreter.interpret_expression(expression, local_vars)

# Generated at 2022-06-22 09:02:55.052109
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a) {
            return a + 1;
        }
    '''
    interpreter = JSInterpreter(js_code)
    assert interpreter.call_function('test', 2) == 3


# Generated at 2022-06-22 09:03:04.907253
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var obj = {
            "a": function() {
                return 5;
            },
            "b": function(x, y) {
                return x - y;
            }
        };
        var fun = function(x, y) {
            return x * y + 5;
        };
        var f = (function(x, y) {
            return x * y + 5;
        });
        var f1 = (function(x) {
            return x + 5;
        })(2);
    '''
    jsi = JSInterpreter(code)
    assert jsi.call_function('fun', 3, 2) == 11
    assert jsi.call_function('f', 3, 2) == 11

# Generated at 2022-06-22 09:03:12.989122
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:03:21.332519
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
    var obj = {
        test1: function (abc) {
            var def = abc;
        },
        test2: function () {
            var ghi = "2";
        },
    };
    obj.test2();
    """
    objname = "obj"
    expected = {
        "test1": None,
        "test2": None
    }
    i = JSInterpreter(code)
    obj = i.extract_object(objname)
    assert obj == expected, "extract_object(%s) returns %s instead of %s" % (objname, obj, expected)


# Generated at 2022-06-22 09:03:27.534583
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    var a = {
        r: function(a, b) {
            return a + b;
        },
        f: function(a, b) {
            return a / b;
        }
    }
    '''
    js = JSInterpreter(code)
    obj = js.extract_object('a')
    assert callable(obj['r'])
    assert obj['r'](10, 20) == 30
    assert obj['f'](50, 5) == 10


# Generated at 2022-06-22 09:03:37.615721
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    jsi = JSInterpreter(
        '''
        var a = 1;
        var b = 2;
        function f(x, y) {
            return a + b + x;
        }
        function g(x, y) {
            return f + x + y;
        }
        var v = {
            "func1": function(x) {return x + x;},
            "func2": function(x, y) {return x + y;},
        };
        ''')
    assert jsi.call_function('f', 3, 4) == 6
    assert jsi.call_function('g', 3, 4) == 15
    assert jsi.call_function('v["func1"]', 3) == 6
    assert jsi.call_function('v["func2"]', 3, 4) == 7

# Generated at 2022-06-22 09:03:45.406971
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    code = ';s.set("debug",function(b,d){b&&console[console.info?"info":"log"](d)});b.debug("js")'
    funname = "set"
    args = 'b,d'
    arguments = args.split(',')
    f = js_interpreter.build_function(arguments, code)
    assert f(["a", "b"]) == None


# Generated at 2022-06-22 09:04:36.735418
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    orig_code = """
    var A={
        f1:function(a){
            return a+1;
        },
        f2:function(a,b){
            return a+b;
        },
        f3:function(){
            return this.f1(1)+this.f2(2,3);
        }
    };
    """
    js_interpreter = JSInterpreter(orig_code)
    obj = js_interpreter.extract_object("A")
    assert obj["f1"]((1,)) == 2
    assert obj["f2"]((1,2)) == 3
    assert obj["f3"](()) == 7


# Generated at 2022-06-22 09:04:40.338159
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsi = JSInterpreter('ad6 = { ra6: function (a) {"use strict";var b = a;return b}};')
    obj = jsi.extract_object('ad6')
    assert obj['ra6']('hello') == 'hello'


# Generated at 2022-06-22 09:04:51.991167
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:04:57.539519
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    sample_code = '''
    Decode(a,b,c,d) {(/* Code sample */)}
    Encode(a,b,c,d) {(/* Code sample */)}
    (function(){/* Code sample */})();
    '''
    interpreter = JSInterpreter(sample_code)
    test_func = interpreter.extract_function("Decode")
    test_func_2 = interpreter.extract_function("Encode")
    assert test_func != None and test_func_2 != None

if __name__ == '__main__':
    test_JSInterpreter_extract_function()

# Generated at 2022-06-22 09:05:05.222318
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
	obj = {
		'split': lambda args: list(args[0]),
		'join': lambda args: args[0].join(['1']),
		'reverse': lambda args: ['1'],
		'slice': lambda args: ['1'][args[0]:],
		'splice': lambda args: ['1'][args[0]:args[1]]
	}

# Generated at 2022-06-22 09:05:17.349621
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    class TestInterpreter(JSInterpreter):

        def __init__(self, code, objects=None):
            JSInterpreter.__init__(self, code, objects)

        def interpret_expression(self, expr, local_vars, allow_recursion):
            return JSInterpreter.interpret_expression(self, expr, local_vars, allow_recursion)

        def interpret_statement(self, stmt, local_vars, allow_recursion):
            return JSInterpreter.interpret_statement(self, stmt, local_vars, allow_recursion)


# Generated at 2022-06-22 09:05:19.524186
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = "var function_name = function(a,b) { return a+b; }"
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('function_name', 1, 2) == 3


# Generated at 2022-06-22 09:05:32.016211
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-22 09:05:43.778027
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    import unittest

    class TestClass(unittest.TestCase):
        def setUp(self):
            self.jsinterpreter = JSInterpreter('code')

        # test the function without return
        def test_function_without_return(self):
            def func(argnames, code):
                local_vars = dict(zip(argnames, [1, 2]))
                for stmt in code.split(';'):
                    res, abort = self.jsinterpreter.interpret_statement(stmt, local_vars)
                    if abort:
                        break
                return res


# Generated at 2022-06-22 09:05:53.584981
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('var a = 1')
    # Test var a = 1
    res, abort = js_interpreter.interpret_statement('var a = 1', {})
    print(res)  # 1
    # Test return 3
    res, abort = js_interpreter.interpret_statement('return 3', {})
    print(res, abort)  # 3, True
    # Test return \"3\"
    res, abort = js_interpreter.interpret_statement('return \"3\"', {})
    print(res, abort)  # 3, True
    # Test b = c = 1 + 2
    res, abort = js_interpreter.interpret_statement('b = c = 1 + 2', {})
    print(res, abort)  # 3, False


# Generated at 2022-06-22 09:06:20.824990
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter('')
    f = jsi.build_function(["a", "b", "c", "d"], "return a + b + c + d;")
    assert f((1, 2, 3, 4)) == 10


if __name__ == '__main__':
    import sys
    jsi = JSInterpreter(sys.argv[1])
    try:
        print(jsi.call_function('a', 1, 2))
    except AssertionError as e:
        print(e)

# Generated at 2022-06-22 09:06:28.130607
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    obj = {'fx': None}
    code = '''
        var fx = function () {var a = 123;};
        var fy = function () {var b = 321;};
        fx(); fy();
        '''
    JSInterpreter(code, obj).interpret_expression('fx()', {}, 1000)
    assert obj['fx']
    JSInterpreter(code, obj).interpret_expression('fy()', {}, 1000)
    assert obj['fx']


# Generated at 2022-06-22 09:06:41.199617
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
    function func(a, b, c) {
        var abc = a + b + c;
        return abc;
    }
    """
    f = JSInterpreter(code).extract_function('func')
    assert f((0, 1, 2)) == 3
    assert f((2, 3, 0)) == 5

    code = """
    function func(a, b, c) {
        var x = a + b + c;
        var y = x + 10;
        return y;
    }
    """
    f = JSInterpreter(code).extract_function('func')
    assert f((0, 1, 2)) == 13
    assert f((2, 3, 0)) == 15


# Generated at 2022-06-22 09:06:46.856381
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test = '''
        var a = {
            f1: function(x, y) {
                return x + y;
            }
        };
    '''

    interpreter = JSInterpreter(test)
    assert interpreter.extract_object('a')['f1'](2, 3) == 5


# Generated at 2022-06-22 09:06:49.975591
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = 'function a(a){a=a.split("")};'
    test_JSInterpreter = JSInterpreter(code)
    assert test_JSInterpreter.build_function(['a'], 'a=a.split("")')(['']) == []

# Generated at 2022-06-22 09:06:50.860136
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter


# Generated at 2022-06-22 09:06:57.839225
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''var foo = true;
        bar = false;
        var baz = false;
        function boo() {
            return 'test';
        }'''
    interpreter = JSInterpreter(code)
    local_vars = {'bar': True}
    assert interpreter.interpret_expression('foo', local_vars) is True
    assert interpreter.interpret_expression('foo || bar', local_vars) is True
    assert interpreter.interpret_expression('foo && bar', local_vars) is False
    assert interpreter.interpret_expression('!foo', local_vars) is False
    assert interpreter.interpret_expression('foo ^ bar', local_vars) is True
    assert interpreter.interpret_expression('foo ^ !bar', local_vars) is False

# Generated at 2022-06-22 09:07:03.312083
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = """
        function hello(a, b) {
            return a + b;
        }
        hello_01 = hello;
        hello(1, 2);
    """
    jsi = JSInterpreter(code)
    assert jsi.call_function('hello_01', 1, 2) == 3



# Generated at 2022-06-22 09:07:14.019226
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    testCases = [
        ("""function func1(a,b){return 'res'}""", lambda a,b: 'res'),
        ("""function func2(a,b){return a.length}""", lambda a,b: len(a)),
        ("""function func3(a,b){return a.reverse()}""", lambda a,b: a.reverse()),
    ]

    for code, expectedResult in testCases:
        actualResult = JSInterpreter(code).build_function(['a','b'], code.split('{')[1].split('}')[0])([1,2])
        assert(actualResult == expectedResult([1,2]))

# Generated at 2022-06-22 09:07:18.316865
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = "var abcdefg = {'hijk': function() {},};"
    js = JSInterpreter(code)
    assert js.call_function('abcdefg.hijk', ('a',)) is None


# Generated at 2022-06-22 09:09:09.002195
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:09:12.975244
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter(
        '''a={};a.b={c:function(){return 10;}};''')
    assert js_interpreter.call_function('a.b.c') == 10
    assert js_interpreter('a.b.c') == 10


# Generated at 2022-06-22 09:09:21.353816
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:09:31.817644
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('', {})
    # Expressions
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('-1 + 0', {}) == -1
    assert js_interpreter.interpret_expression('-1 + (-2)', {}) == -3
    assert js_interpreter.interpret_expression('-1.2', {}) == -1.2
    assert js_interpreter.interpret_expression('true', {}) is True
    assert js_interpreter.interpret_expression('false', {}) is False
    assert js_interpreter.interpret_expression('"hello"', {}) == 'hello'

# Generated at 2022-06-22 09:09:43.092866
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    import os
    path = os.path.join(os.path.dirname(__file__), 'jsinterpreter.js')
    with open(path, 'r') as f:
        js_code = f.read()
    jsi = JSInterpreter(js_code, {'null': None})

    # Simple functions with arithmetic operations
    jsi.build_function(['a', 'b'], 'return a + b')([3, 4])
    jsi.build_function(['a', 'b'], 'return a - b')([3, 4])
    jsi.build_function(['a', 'b'], 'return a * b')([3, 4])
    jsi.build_function(['a', 'b'], 'return a / b')([3, 4])
    jsi

# Generated at 2022-06-22 09:09:49.963046
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    test_code = '''
        function foo(a, b) {
            var c = a + b - 1;
            return 10 * c / a;
        }
        var bar = function(a, b) {
            var c = a + b - 1;
            return 10 * c / a;
        }
        '''
    jsi = JSInterpreter(test_code)
    assert jsi.call_function('foo', 2, 4) == 16
    assert jsi.call_function('bar', 2, 4) == 16

# Generated at 2022-06-22 09:09:56.522861
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:10:05.904620
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test 1: Test empty expression
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('', {}, 10) == None

    # Test 2: Test expression of a string
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('""', {}, 10) == ''

    # Test 3: Test expression of a variable
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('a', {'a': 10}, 10) == 10

    # Test 4: Test expression of a integer
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('10', {}, 10) == 10
    assert js_interpreter.interpret_