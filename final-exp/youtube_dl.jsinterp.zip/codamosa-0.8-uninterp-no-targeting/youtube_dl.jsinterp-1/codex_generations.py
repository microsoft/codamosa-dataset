

# Generated at 2022-06-22 09:00:37.137638
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter('test') is not None
# End unit test


# Generated at 2022-06-22 09:00:42.811869
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    JS_PROGRAM = """
        function test(arg1, arg2){
            locate = arg1 + arg2
            return locate
        }
    """
    jsinterpreter = JSInterpreter(JS_PROGRAM)
    result = jsinterpreter.build_function(["arg1", "arg2"], "locate = arg1 + arg2; return locate")
    assert result([2, 1]) == 3



# Generated at 2022-06-22 09:00:47.780185
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:00:54.005079
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Simple test:
    js_code_1 = 'function foo (a) {return a + 1;}'
    f = JSInterpreter(js_code_1).build_function(['a'], 'return a + 1')
    assert f([1]) == 2

    # More sophisticated test:
    js_code_2 = '''function baz(a,b,c){
        var d = a;
        var e = b;
        d += (c & e);
        return d;
    }'''
    g = JSInterpreter(js_code_2).build_function(['a', 'b', 'c'],
        'var d = a; var e = b; d += (c & e); return d;')
    assert g([1, 2, 3]) == 3 # 1 + (3 & 2)


# Generated at 2022-06-22 09:01:04.371728
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:01:05.569774
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    JSInterpreter('var a = "hello world";')


# Generated at 2022-06-22 09:01:14.133869
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Test with simple js code
    js_code = """
        function func(arg) {
            return arg;
        }"""
    interpreter = JSInterpreter(js_code)
    assert interpreter.call_function('func', 'xxx') == 'xxx'

    # Test with more complex js code
    js_code = """
        function func(arg1, arg2) {
            return arg2 + arg1;
        }"""
    interpreter = JSInterpreter(js_code)
    assert interpreter.call_function('func', 'xxx', 'yyy') == 'yyyxxx'

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-22 09:01:22.249271
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = r'''function a(a) {
        function c() {
            var d = 0;
            return e[f];
        }
        var b = 1;
    }'''
    interpreter = JSInterpreter(code)
    assert interpreter._functions == {}
    assert interpreter._objects == {}

    code = r'''function a(a) {
        function c() {
            var d = 0;
            return e[f];
        }
        var b = 1;
    }
    window.n = {
        b: function(a) {
            var a = a || {};
            return a.a;
        }
    }'''
    interpreter = JSInterpreter(code)
    assert interpreter._functions == {'a': None}

# Generated at 2022-06-22 09:01:31.131187
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    x = JSInterpreter("""
    b=function(a,c){while(--c){a++;if(c>3){}}return a};
    a=function(a,c){var f=b(a,c);return f};
    a(1,3);""")
    assert x.extract_function('b')([1,3]) == 4
    assert x.extract_function('a')([1,3]) == 4

if __name__ == "__main__":
    test_JSInterpreter()

# Generated at 2022-06-22 09:01:41.593813
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:02:43.840314
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    JSI = JSInterpreter('')
    v = JSI.interpret_expression('x.join("")',
                                 { 'x': [1, 2, 3]})
    assert v == '123'

# Generated at 2022-06-22 09:02:50.639143
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = r'''var s="hello";
        function foo(args) {
            return args[0] + s + args[1];
        }
        var bar = function() {
            return 42;
        }'''

    js = JSInterpreter(code)
    assert js.call_function('foo', 'World') == 'Worldhello'
    assert js.call_function('foo', 'foo', 'bar') == 'foobarhello'
    assert js.call_function('bar') == 42



# Generated at 2022-06-22 09:03:00.375000
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:03:09.848381
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsInterpreter = JSInterpreter(None)
    assert jsInterpreter.interpret_statement('a = b', {'a': [], 'b': [1, 2]}) == ([1, 2], False)
    assert jsInterpreter.interpret_statement('a', {'a': 1}) == (1, False)
    assert jsInterpreter.interpret_statement('a.b', {'a': {'b': 1}}) == (1, False)
    assert jsInterpreter.interpret_statement('a.b(c + d)', {'a': {'b': lambda x: x}, 'd': 1, 'c': 1}) == (2, False)

# Generated at 2022-06-22 09:03:21.331854
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = '''function b(b, d, c) {
    d = d || [];
    c = c || 0;
    var a = b[c];
    if (null == a)
        return [];
    null == d[c] && (d[c] = 0);
    d[c]++;
    return b.length - 1 > c ? bb(b, d, c + 1) : d
}'''

    for test, result in [
            (['a', 'a', 'b', 'c'], [2, 1, 1]),
            (['a', 'b', 'b', 'c', 'c', 'd'], [1, 2, 2, 1]),
    ]:
        res = JSInterpreter(
            js_code
        ).call_function('b', test)

# Generated at 2022-06-22 09:03:31.616276
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        var test = 1;
        var a = {
            x: function(a) {
                return a
            },
            y: function(a, b) {
                return a * b
            }
        };
    '''
    i = JSInterpreter(code)
    f = i.extract_function('a.x')
    assert f((1,)) == 1
    f = i.extract_function('a.y')
    assert f((2, 3)) == 6
    # Test if local variables are not overwritten
    assert i._objects['a']['y'](2, 3) == 6
    assert i._objects['a']['x'](3) == 3


# Generated at 2022-06-22 09:03:36.023171
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    # Simple function to test function construction
    simple_function_code = 'function simpleFunc(a, b, c) { var d = a + b * c; return d; }'
    js_interpreter = JSInterpreter(simple_function_code)
    simple_func = js_interpreter.extract_function('simpleFunc')
    return simple_func((1,2,3)) == 7


# Generated at 2022-06-22 09:03:42.822352
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = 'function test(a) { return a+10; }'
    interpreter = JSInterpreter(js)
    assert interpreter.build_function(['a'], 'return a+10')([3]) == 13


if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-22 09:03:48.162874
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
        var f = function a(b, x) {
        	var c = b;
        	return x[0] + x[1] + x[2] + c
        }"""
    interpreter = JSInterpreter(code)
    result = interpreter.build_function("b, x".split(","), "var c = b; return x[0] + x[1] + x[2] + c")
    assert result([1, [2, 3, 4]]) == 10


# Generated at 2022-06-22 09:03:59.605770
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-22 09:04:22.853864
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():

    js1 = '''
        function a(arg) {
            return arg + 5;
        }
        '''
    js2 = '''
        var b = a(1);
        b;
        '''
    #test if one can call function a
    a = JSInterpreter(js1)
    assert a.call_function('a', 1) == 6

    #test if variable b can use function a
    b = JSInterpreter(js2)
    assert b.call_function('b') == 6

if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-22 09:04:23.838801
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # write code here
    pass


# Generated at 2022-06-22 09:04:36.262721
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter.build_function(['a'], 'return 3')([5]) == 3
    assert JSInterpreter.build_function(['a'], 'return a+3')([5]) == 8
    assert JSInterpreter.build_function(['a'], 'return a[3]')([[5]]) == 5
    assert JSInterpreter.build_function(['a'], 'return a[a[0]]')([(3,)]) == 3
    assert JSInterpreter.build_function(['a'], 'return a.a')([{'a': 5}]) == 5
    assert JSInterpreter.build_function(['a'], 'return a.a[1]')([{'a': [3, 5, 6]}]) == 5
    assert JSInterpreter.build_function

# Generated at 2022-06-22 09:04:44.255775
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_JSInterpreter_interpret_expression.__test__ = False
    # basic tests

# Generated at 2022-06-22 09:04:54.505973
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    function test_func(arg1, arg2) {
        var a = arg1 + arg2;
        var b = {
            key1: 'value1',
            key2: 'value2',
            key3: 'value3',
            key4: {
                subkey1: 'subvalue1',
                subkey2: 'subvalue2'
            }
        };
        var c = [1, 2, 3];
        return a + b.key1 + b.key2 + b.key4.subkey1 + c[0] + c[1];
    }
    '''


# Generated at 2022-06-22 09:05:03.840583
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = "function f(arg1, arg2, arg3, arg4){return arg4+arg3+arg2+arg1;}"
    argnames = "arg1,arg2,arg3,arg4".split(",")
    code = code.split("{")[1].split("}")[0]
    js_intepreter = JSInterpreter("")
    func = js_intepreter.build_function(argnames, code)
    assert func([13, 47, 117, 213]) == 13+47+117+213

# Generated at 2022-06-22 09:05:14.547916
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = """
        function func(a, b, c){
            var d = a + b + c; 
            return function(e, f){
                var g = d + e + f;
                return g;
            }
        }
    """
    js = JSInterpreter(js_code)
    f = js.extract_function('func')
    assert f((1, 2, 3))((4, 5)) == 1 + 2 + 3 + 4 + 5

    js_code = """
        function func(a, b, c){
            var d = a + b + c; 
            return function(e, f){
                var g = d + e + f;
                return function(h){
                    var i = g + h;
                    return i;
                }
            }
        }
    """


# Generated at 2022-06-22 09:05:24.464149
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        function test(a, b) {
            return a + b;
        }
    ''')
    assert js_interpreter.call_function('test', 1, 2) == 3

    js_interpreter = JSInterpreter('''
        function add(a, b) {
            if (a < b) {
                return a + b;
            }
            return a - b;
        }
    ''')
    assert js_interpreter.call_function('add', 1, 2) == 3
    assert js_interpreter.call_function('add', 2, 1) == 1


# Generated at 2022-06-22 09:05:34.051066
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-22 09:05:45.487283
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    assert JSInterpreter('x=1').interpret_statement('x', {}) == (1, False)
    assert JSInterpreter('var x=1').interpret_statement('x', {}) == (1, False)
    # Test that return works
    assert JSInterpreter('var x=1').interpret_statement('return x', {}) == (1, True)
    assert JSInterpreter('x=1').interpret_statement('return x', {}) == (1, True)
    # Test that we can write variables
    assert JSInterpreter('x=1').interpret_statement('x=2', {}) == (2, False)
    assert JSInterpreter('x=1').interpret_statement('x=x+1', {}) == (2, False)
    # Test multiline

# Generated at 2022-06-22 09:06:02.428354
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter(
        """var a, b, c;
        (function () {
            c = function (a, b) {
                return a + b
            };
            b = function (a) {
                return a * a * a
            };
            a = function (b) {
                return b * b
            }
        })()
        """)
    interpreter.interpret_statement('var a; a = 8;', {})
    assert interpreter.interpret_statement('return a;', {})[0] == 8
    assert interpreter.interpret_statement('a++;', {})[0] == 9
    assert interpreter.interpret_statement('return a;', {})[0] == 9
    assert interpreter.interpret_statement('a = a + 5;', {})[0] == 14

# Generated at 2022-06-22 09:06:07.549582
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():

    interpreter = JSInterpreter("var a = 'aaaaa'; var b = {'1':'bbbbb'}; var len = 5;")
    # Test simple variable
    assert interpreter.interpret_expression("a", {}) == "aaaaa"

    # Test variable with member
    assert interpreter.interpret_expression("b['1']", {}) == "bbbbb"

    # Test variable with attribute
    assert interpreter.interpret_expression("len", {}) == 5

    # Test function call
    assert interpreter.interpret_expression("b['1'].length", {}) == 5


# Generated at 2022-06-22 09:06:18.364929
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = r'''var abc = function () {
        // This is a test function to check if
        // JSInterpreter.build_function works properly
        var a = [1, 2, 3, 4, 5];
        var b = "";
        var c = 0;
        var d = 5;
        var e = 6;
        b = d + e;
        var f = [];
        if (a[0] > d) {
            c = 6;
        }
        f[0] = 0;
        for (var i = 0; i < 5; i++) {
            f[i] = a[i];
        }
        f.push(5);
        return b;
    };'''
    obj = None
    interpreter = JSInterpreter(js_code)

# Generated at 2022-06-22 09:06:24.346425
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:06:30.971561
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-22 09:06:35.625301
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '(function() {var a={"foo":{z:{"bar":function(x){return x}}}}; this.test=a;})()'
    jsi = JSInterpreter(code)
    assert jsi.call_function('test.foo.z.bar', 1) == 1

# Generated at 2022-06-22 09:06:41.338085
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
    var ytplayer = yt.player.Application.create("player", {
        "handleError": function (a) {
            if (a.data == 150) {
                drawError(a.data);
                return false
            }
            if (a.data == 100) {
                drawError(a.data);
                return false
            }
            return true
        }
    });
    '''
    js = JSInterpreter(code)
    func = js.extract_function('handleError')
    # TODO: Test function with parameters
    # func = js.extract_function('yt.player.Application.create')
    print(func)



# Generated at 2022-06-22 09:06:52.425584
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    from .utils import js_to_json

    def test(exp, expected, objects=None):
        result = JSInterpreter(None, objects).interpret_expression(exp, {})
        assert result == expected

    test('(false)', False)
    test('(!true)', False)
    test('(!0)', True)
    test('(0)', 0)
    test('(true)', True)
    test('(!false)', True)
    test('("0")', '0')
    test('("0"+1)', '01')
    test('("a"+"b")', 'ab')
    test('("0"+1+"2")', '012')
    test("([[]][0]+[])", [])

# Generated at 2022-06-22 09:07:02.579910
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-22 09:07:09.316784
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
    function f(a,b) {
        var x = a;
        var y = b;
        return x+y;
    }
    '''
    i = JSInterpreter(js_code)
    f = i.extract_function('f')
    assert f((3, 6)) == 9


# Generated at 2022-06-22 09:07:24.068659
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter("var a = b = 1; a = 2; b = 3; return [a, b];")
    a, b = interpreter.interpret_statement("var a = b = 1; a = 2; b = 3; return [a, b];")
    assert(a == 2)
    assert(b == 3)

# Generated at 2022-06-22 09:07:36.226160
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code_1 = """
    var a = 1, b = 'hello', c = 3;
    """

    code_2 = """
    var d = a + c;
    """

    code_3 = """
    var multi_d = d * d;
    """

    code_4 = """
    var multi_d_2 = multi_d * multi_d;
    """

    code_5 = """
    var quotient = a / c;
    """

    code_6 = """
    var quotient_2 = a / 0;
    """

    code_7 = """
    var quotient_3 = d / 0;
    """

    code_8 = """
    var quotient_4 = a / d;
    """


# Generated at 2022-06-22 09:07:42.661706
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = """
        ytplayer = ytplayer || {};ytplayer.config = {
            "assets": {
                "js": "\/\/s.ytimg.com\/yts\/jsbin\/html5player-vflpqEtYu\/html5player.js"
            }
        };"""
    assert JSInterpreter(code).call_function('ytplayer')['config']['assets']['js'] == '//s.ytimg.com/yts/jsbin/html5player-vflpqEtYu/html5player.js'

# Generated at 2022-06-22 09:07:51.065231
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    objects = {
        'a': [1, 2, 3],
        'b': [1, 2, 3],
    }

# Generated at 2022-06-22 09:07:54.977465
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    s = '(function(){var a={b:function(a,b){return a+b}};return a.b})();'
    interpreter = JSInterpreter(s)
    assert interpreter.extract_object('a')['b'](2, 3) == 5
    assert interpreter.extract_object('a')['b']('2', '3') == '23'


# Generated at 2022-06-22 09:08:00.456222
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():

    # Test case 1
    def test_1(self):
        fn_name = 'be'

# Generated at 2022-06-22 09:08:08.145869
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = (
        '''
        var window={};
        ytplayer={};
        ytplayer.config=null;
        function window.ytplayer.config{
            return this.player_response.streamingData.adaptiveFormats[1].cipher;
        }
        '''
    )
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('ytplayer')
    assert obj['config']() == 'someUnexpectedCipher'


# Generated at 2022-06-22 09:08:15.957121
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    var test1 = {
       a : function() {
          alert();
          return "a";
       }
    }
    '''
    js = JSInterpreter(code)
    assert 'a' in js._objects['test1'].keys()
    assert 'a' == js._objects['test1']['a']()

    code = '''
    var a = {
       b : function() {
          return "b";
       }
       g : function(a,b) {
          return a + b;
       }
    }
    '''
    js = JSInterpreter(code)
    assert 'b' in js._objects['a'].keys()
    assert 'g' in js._objects['a'].keys()

# Generated at 2022-06-22 09:08:21.259156
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Test case with a single level object
    code = '''
        d = {
            "a":2,
            "b": function(){
                return 1;
            },
            "c": function(a){
                return a;
            },
            "f": function(a,b){
                return a + b;
            }
        };
    '''
    obj = JSInterpreter(code).extract_object('d')
    assert obj['a'] == 2
    assert obj['b']() == 1
    assert obj['c'](4) == 4
    assert obj['f'](2, 3) == 5

    # Test case with a nested object

# Generated at 2022-06-22 09:08:28.873229
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def _e(expr, expected_output, **kwargs):
        actual_output = JSInterpreter(
            'var %s;' % varname, **kwargs).interpret_expression(
            expr, {varname: varval})
        # print type(expected_output)
        # print type(actual_output)
        assert expected_output == actual_output, '%r != %r for %r' % (
            expected_output, actual_output, expr)

    varname = 'x'
    varval = 0
    _e('1 + 2', 3)
    _e('2 - 1', 1)
    _e('3 * 2', 6)
    _e('6 / 2', 3)
    _e('2 & 3', 2)
    _e('2 ^ 3', 1)

# Generated at 2022-06-22 09:08:44.103258
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    a = JSInterpreter('var a = true; var obj = {x: function(y){return a;}};')
    assert a._objects['obj']['x'](1)



# Generated at 2022-06-22 09:08:52.319842
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter("var a = 'a' + 'b';", {})
    assert interpreter.interpret_expression('a', {}, 100) == 'ab'

    interpreter = JSInterpreter("var a = 'a' + b;", {})
    assert interpreter.interpret_expression('a', {'b': 'b'}, 100) == 'ab'

    interpreter = JSInterpreter("var a = 'a' + (b + c);", {})
    assert interpreter.interpret_expression('a', {'b': 'b', 'c': 'c'}, 100) == 'abc'

    interpreter = JSInterpreter("var a = b[0] + c;", {})
    assert interpreter.interpret_expression('a', {'b': ['1'], 'c': 'c'}, 100) == '1c'

    interpreter

# Generated at 2022-06-22 09:08:59.981537
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-22 09:09:12.099343
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    '''
    test_JSInterpreter_extract_function
    Args:
        None
    Returns:
        None
    '''
    # TODO(dimsum): Fix it
    return

    code = '''
    foo = function(a, b) {
        return a+b;
    };
    '''
    interp = JSInterpreter(code)
    assert interp.extract_function('foo')((23, 42)) == 23 + 42

    code = '''
    function foo(a, b) {
        return a+b;
    }
    '''
    interp = JSInterpreter(code)
    assert interp.extract_function('foo')((23, 42)) == 23 + 42


# Generated at 2022-06-22 09:09:21.305297
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('').interpret_expression('1 + 1',{}) == 2
    assert JSInterpreter('').interpret_expression('1 + a',{'a':1}) == 2
    assert JSInterpreter('').interpret_expression('(a)',{'a':1}) == 1
    assert JSInterpreter('').interpret_expression('{}',{}) == {}
    assert JSInterpreter('').interpret_expression('[]',{}) == []
    assert JSInterpreter('').interpret_expression('"cde"',{}) == 'cde'
    assert JSInterpreter('').interpret_expression('1 + []',{}) == 1
    assert JSInterpreter('').interpret_expression('{}[1]',{}) == None
    assert JSInterpreter('').interpret_expression

# Generated at 2022-06-22 09:09:30.297899
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = "function(a){var b=a.split(\"\");a=b.length;for(--a;0<=a;a--)if(38==b[a])b[a]=\"&\",a--;return b.join(\"\")};"
    argnames = ['a']
    code = 'var b=a.split("");a=b.length;for(--a;0<=a;a--)if(38==b[a])b[a]="&",a--;return b.join("")'
    f = JSInterpreter(code).build_function(argnames, code)
    assert f('a&b') == 'a&b'

# Generated at 2022-06-22 09:09:41.701224
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Test for jscode 1
    jscode = """a='a';
b={
    a:function(c){
        var d=function(){
            var d={};
            return d;
        };
        d.d=function(e){
            b.a=function(){};
        };
        return d;
    }
}"""
    jsInterpreter = JSInterpreter(jscode)
    obj1 = jsInterpreter.extract_object("b")
    jsInterpreter.interpret_expression("b.d.d",{"b":obj1})
    obj1_a = obj1["a"]
    obj1_a("1")
    assert isinstance(obj1_a, type(lambda :None))

    # Test for jscode 2

# Generated at 2022-06-22 09:09:46.946655
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_interpreter = JSInterpreter('''
        function func(args) {
            var a = args[0];
            var b = args[1]['c'];
            return a + b;
        }
        ''')
    assert js_interpreter.call_function('func', 'a', {'c': 'b'}) == 'ab'


# Generated at 2022-06-22 09:09:56.232974
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-22 09:09:59.853360
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
        function func(arg1, arg2, arg3) {
            var a1 = arg1;
            var a2 = arg2;
            var a3 = arg3;
            var res1 = a1 + a2 + a3;
            var res2 = "res2";
            return res2;
        }
    '''
    jsi = JSInterpreter(js_code)
    assert jsi.call_function('func', 1, 2, 3) == 'res2'
