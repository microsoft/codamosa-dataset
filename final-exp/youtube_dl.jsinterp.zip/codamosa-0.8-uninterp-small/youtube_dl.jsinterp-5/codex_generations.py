

# Generated at 2022-06-26 13:23:42.891508
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    obj = JSInterpreter("""
        this.myFunc = function(a) {
            return a*a;
        }
        var f = function(b) {
            return b*b;
        }
    """)
    assert obj.build_function(['a'], 'return a*a;')(3) == 9
    assert obj.call_function('f', 3) == 9
    assert obj.call_function('myFunc', 3) == 9



# Generated at 2022-06-26 13:23:46.170168
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_class_0 = JSInterpreter(None)
    test_variable_0 = test_class_0.interpret_expression(None,None)


# Generated at 2022-06-26 13:23:56.397623
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:24:06.087189
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = """var a, b;
            a = 1;
            b = 2;
            return a + b;"""
    jsinter = JSInterpreter(code)
    assert(jsinter.interpret_statement(code, {}) == (3, True))
    code = """var a, b;
            a = 1;
            b = 2;
            a + b"""
    jsinter = JSInterpreter(code)
    assert(jsinter.interpret_statement(code, {}) == (3, False))
    code = """var a, b, c;
            a = 1;
             return b = 2;"""
    jsinter = JSInterpreter(code)
    assert(jsinter.interpret_statement(code, {}) == (2, True))

# Generated at 2022-06-26 13:24:11.916286
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    j_s_interpreter_2 = None
    j_s_interpreter_3 = JSInterpreter(j_s_interpreter_2)
    j_s_interpreter_4 = 'var a = (function(){return "foo";})();'
    j_s_interpreter_5 = j_s_interpreter_3.interpret_statement(j_s_interpreter_4, {}, 50)
    assert j_s_interpreter_5 == "foo"


# Generated at 2022-06-26 13:24:18.588739
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code_0 = None
    argnames_0 = None
    j_s_interpreter_0 = JSInterpreter(code_0)
    res_0 = j_s_interpreter_0.build_function(argnames_0, code_0)

    # check the type of res_0
    assert isinstance(res_0, type(lambda: None))


# Generated at 2022-06-26 13:24:25.307175
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_1 = JSInterpreter(None)

    local_vars = {}
    expr = None
    allow_recursion_2 = None
    retval_3 = j_s_interpreter_1.interpret_expression(local_vars, expr, allow_recursion_2)
    assert(retval_3)


# Generated at 2022-06-26 13:24:35.956322
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    func_code_0 = json.dumps(['function', 'f', 'name', 'x'])
    func_code_1 = 'function f(name) {}'
    func_code_2 = 'function f(name) {return name;};'
    j_s_interpreter_2 = JSInterpreter(func_code_1)
    assert j_s_interpreter_2.build_function(('name',), func_code_1) == j_s_interpreter_2.build_function(('name',), func_code_2)
    j_s_interpreter_0 = JSInterpreter(func_code_2)
    assert j_s_interpreter_0.build_function(('name',), func_code_1) == j_s_interpreter_0.build_

# Generated at 2022-06-26 13:24:37.516676
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    j_s_interpreter_0 = JSInterpreter("var a = 1;")
    j_s_interpreter_1 = j_s_interpreter_0.interpret_statement("a = 1;")


# Generated at 2022-06-26 13:24:41.970406
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:25:03.272149
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = None
    j_s_interpreter_1 = JSInterpreter(j_s_interpreter_0)
    j_s_interpreter_2 = JSInterpreter(j_s_interpreter_0, {})
    j_s_interpreter_2.interpret_expression


# Generated at 2022-06-26 13:25:14.115536
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test case 0
    j_s_interpreter_0 = '''
        var a = 5;
        var b = 3;
        if (a === 5) {
            b = 4;
        }
        c = a + b;
    '''
    j_s_interpreter_1 = JSInterpreter(j_s_interpreter_0)
    j_s_interpreter_2 = ''
    j_s_interpreter_3 = j_s_interpreter_1.interpret_statement(j_s_interpreter_2, {'a': 0, 'b': 0, 'c': 0})
    assert j_s_interpreter_3 == (None, False)

    # Test case 1

# Generated at 2022-06-26 13:25:16.496419
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    j_s_interpreter_4 = None
    j_s_interpreter_5 = JSInterpreter(j_s_interpreter_4)


# Generated at 2022-06-26 13:25:22.154547
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''\
var a = 5;
var q = function(x) { var vh = 1; return a; }
q(3);
var b = function(y) { return y + a + 5; }
b(3);
'''
    assert JSInterpreter(code).call_function('q', 0) == 5
    assert JSInterpreter(code).call_function('b', 5) == 15

# Generated at 2022-06-26 13:25:28.680198
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert j_s_interpreter_1.interpret_expression("""["a", "b"][index]""", {"index": 0}) == "a"

    assert j_s_interpreter_1.interpret_expression("""function a() {return true}""") is True

    assert j_s_interpreter_1.interpret_expression("""function b() {return false}""") is False

    assert j_s_interpreter_1.interpret_expression("""["a", "b"][a()].split("")[b()].charCodeAt(0)""") == 98

    assert j_s_interpreter_1.interpret_expression("""2 << 3""") == 16

    assert j_s_interpreter_1.interpret_expression("""var foo = [42]; foo[0]""") == 42

   

# Generated at 2022-06-26 13:25:32.978433
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    import nose
    j_s_interpreter = JSInterpreter("var test = {function1:function(arg1){return arg1;}}")
    nose.tools.assert_equal(j_s_interpreter.extract_object("test"), {"function1": lambda arg1:arg1})


# Generated at 2022-06-26 13:25:43.679566
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:25:50.685371
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_cases = [
        {"input_arguments": [["arg0"], "return arg0 * 2;"], "assert_value": ({"input_arguments": [123], "assert_value": 246}), "assert_return": True},
    ]
    passed_count = 0
    failed_count = 0

# Generated at 2022-06-26 13:26:01.467250
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = '''function reverse(a) {
    var b = a.length;
    var c = [];
    for (var i = 0; i < b; i++) {
        c[i] = a[b - i - 1];
    }
    return c;
}'''
    j_s_interpreter_1 = JSInterpreter(j_s_interpreter_0)
    j_s_interpreter_2 = j_s_interpreter_1.build_function(['i'], 'return i + 10;')
    assert j_s_interpreter_2([0]) == 10



# Generated at 2022-06-26 13:26:08.187102
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:27:09.448700
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    j_s_interpreter_0 = u'function abc(a, b, c) { return a + b + c };'
    j_s_interpreter = JSInterpreter(j_s_interpreter_0)
    test_0_res = j_s_interpreter.extract_function(u"abc")(1,2,3)
    assert test_0_res == 6, "Test Case for func 'extract_function' of class 'JSInterpreter' contained errors"


# Generated at 2022-06-26 13:27:15.959794
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = None
    j_s_interpreter_1 = JSInterpreter(j_s_interpreter_0)
    j_s_interpreter_2 = j_s_interpreter_1.interpret_expression("for (;;);", set([]))
    assert j_s_interpreter_2 == None


# Generated at 2022-06-26 13:27:22.634584
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    json_library = re.search(r'JSON\s*=\s*({.*})\s*;', JSInterpreter.code).group(1)
    JSON_interp = JSInterpreter(json_library)
    # The assert is here just as an example.
    # It should assert that the parsed function is equivalent
    # to the one defined in JSON.parse
    assert JSON_interp.extract_function('parse') == JSON_interp.call_function('parse')

# Generated at 2022-06-26 13:27:32.376471
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Define input parameters
    j_s_interpreter_0 = None
    j_s_interpreter_1 = JSInterpreter(j_s_interpreter_0)

    j_s_interpreter_2 = ( 6, )
    j_s_interpreter_3 = "this.i"
    j_s_interpreter_4 = ";"
    j_s_interpreter_5 = "return this.i * 3;"

    # Evaluate operation
    j_s_interpreter_6 = j_s_interpreter_1.build_function(j_s_interpreter_2, j_s_interpreter_3+j_s_interpreter_4+j_s_interpreter_5)

    # Check for positive test case
    assert j_s

# Generated at 2022-06-26 13:27:38.336035
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:27:40.433355
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = None
    j_s_interpreter_1 = JSInterpreter(j_s_interpreter_0)


# Generated at 2022-06-26 13:27:44.159241
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    j_s_interpreter_2 = JSInterpreter('')
    assert j_s_interpreter_2.call_function('functionname', 1, 2, 3) == None
    assert j_s_interpreter_2.call_function('functionname', 'a', 'b', 'c') == None


# Generated at 2022-06-26 13:27:52.949883
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    global j_s_interpreter_1
    t_e_1 = None
    t_e_2 = None
    v_1 = j_s_interpreter_1.interpret_expression(t_e_1, t_e_2)
    t_e_3 = None
    t_e_4 = None
    t_e_5 = None
    t_e_6 = None
    v_2 = j_s_interpreter_1.interpret_expression(t_e_3, t_e_4, t_e_5)
    v_3 = j_s_interpreter_1.interpret_expression(t_e_6, t_e_4)
    return v_1, v_2, v_3


# Generated at 2022-06-26 13:27:54.614969
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 13:28:02.393638
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('var a = 123;')
    result_0 = interpreter.interpret_expression('a', {})
    assert result_0 == 123
    interpreter = JSInterpreter('var a = "abc";')
    result_1 = interpreter.interpret_expression('a', {})
    assert result_1 == "abc"
    interpreter = JSInterpreter('var a = ["b", "c"];')
    result_2 = interpreter.interpret_expression('a[0]', {})
    assert result_2 == "b"
    interpreter = JSInterpreter('var a = 123;')
    result_3 = interpreter.interpret_expression('a * 2', {})
    assert result_3 == 246
    interpreter = JSInterpreter('var a = "a";')

# Generated at 2022-06-26 13:28:48.226275
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter = JSInterpreter("""function f() {}""")
    s = JSInterpreter.extract_object(j_s_interpreter, "")
    assert s == ""

    args = [""]
    expected = ""
    j_s_interpreter = JSInterpreter("""function f() {}""")
    try:
        JSInterpreter.extract_object(j_s_interpreter, *args)
    except Exception as e:
        s = str(e)
    assert s == expected


# Generated at 2022-06-26 13:28:56.707213
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    j_s_interpreter_0 = None
    j_s_interpreter_1 = JSInterpreter(j_s_interpreter_0)
    j_s_interpreter_2 = None
    assert j_s_interpreter_1.call_function(j_s_interpreter_2) == None

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', '--tb=line', 'test_jsinterpreter.py'])

# Generated at 2022-06-26 13:29:02.424165
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = None
    j_s_interpreter_1 = JSInterpreter(j_s_interpreter_0)
    j_s_interpreter_2 = None
    j_s_interpreter_3 = None
    j_s_interpreter_1.interpret_expression(j_s_interpreter_2, j_s_interpreter_3)


# Generated at 2022-06-26 13:29:04.504592
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
   assert JSInterpreter.interpret_statement(None, None, allow_recursion=100)


# Generated at 2022-06-26 13:29:05.573247
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    pass # TODO


# Generated at 2022-06-26 13:29:11.541010
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    a_s_interpreter_0 = None
    a_s_interpreter_1 = JSInterpreter(a_s_interpreter_0)
    a_s_interpreter_2 = a_s_interpreter_1.extract_object("")


# Generated at 2022-06-26 13:29:12.927072
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 13:29:16.176446
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    try:
        assert ('', False) == j_s_interpreter_1.interpret_statement(None, None)
    except AssertionError as e:
        e.__context__ = None
        raise


# Generated at 2022-06-26 13:29:24.342456
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = None
    # Calling the method
    j_s_interpreter_build_function_result_1 = JSInterpreter.build_function(
        j_s_interpreter_0,
        # (Type: list) Argument 1
        [
            # (Type: str) item 1
            'h',
            # (Type: str) item 2
            'k',
        ],
        # (Type: str) Argument 2
        'return h + k;')
    # Verifying the output type of the method
    assert isinstance(j_s_interpreter_build_function_result_1, (type(lambda: None), type(lambda x, y: None)))

    # Verifying the output value of the method
    assert j_s_interpreter_build_function_result_

# Generated at 2022-06-26 13:29:28.004075
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Test case JSInterpreter_extract_object_0
    js_interpreter_0 = None
    js_interpreter_1 = JSInterpreter(js_interpreter_0)
    js_interpreter_2 = js_interpreter_1.extract_object('D')


# Generated at 2022-06-26 13:31:26.422902
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_2 = (
        'var a = {b: function(x) {return x + 1;}, c: function(x, y) {return x + y;}};')
    j_s_interpreter_3 = JSInterpreter(j_s_interpreter_2)
    j_s_interpreter_4 = j_s_interpreter_3.extract_object('a')
    j_s_interpreter_5 = j_s_interpreter_4['b'](3)
    if (j_s_interpreter_5 != 4):
        raise AssertionError('extract_object:b:0')
    j_s_interpreter_6 = j_s_interpreter_4['c'](3, 2)

# Generated at 2022-06-26 13:31:30.502039
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_2 = JSInterpreter('function foo(a, b) {\n  return 1;\n}\n')
    j_s_interpreter_3 = j_s_interpreter_2.build_function([
        'a',
        'b',
    ], '\n  return 1;\n')
    assert j_s_interpreter_3(None) == 1


# Generated at 2022-06-26 13:31:40.748859
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test basic function definition and calling
    j_s_interpreter_0 = '''
        function test(arg1, arg2) {
            return arg1 + arg2;
        }
    '''
    j_s_interpreter_1 = JSInterpreter(j_s_interpreter_0)
    assert j_s_interpreter_1.call_function(j_s_interpreter_0, 5, 2) == 7

    # Test various variable operations

# Generated at 2022-06-26 13:31:42.832705
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_case_0()

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-26 13:31:53.418644
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    obj = {"a": 3, "b": 4}
    obj["add"] = lambda values: values[0] + values[1]
    obj["sub"] = lambda values: values[0] - values[1]
    j_s_interpreter_4 = JSInterpreter(None, {"obj": obj})
    assert j_s_interpreter_4.call_function("obj.add", 2, 3) == 5
    assert j_s_interpreter_4.call_function("obj.sub", 4, 1) == 3

# Generated at 2022-06-26 13:32:04.575170
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_0 = '''var test_a={"a":function(p){return 2*p;},"b":function(p){return 2/p;}}'''
    j_s_interpreter_1 = JSInterpreter(j_s_interpreter_0)
    j_s_interpreter_2 = j_s_interpreter_1.extract_object('test_a')
    assert isinstance(j_s_interpreter_2, dict)


# Generated at 2022-06-26 13:32:05.283857
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_case_0()


# Generated at 2022-06-26 13:32:17.253170
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_1 = JSInterpreter('', {})
    j_s_interpreter_2 = JSInterpreter('', {})
    j_s_interpreter_1._code = {"foo":"bar"}
    hashmap_1 = {"foo", {}}
    j_s_interpreter_2._objects = hashmap_1
    j_s_interpreter_0 = JSInterpreter('', {})
    j_s_interpreter_0._objects = hashmap_1
    hashmap_2 = {"foo", {"bar" : 1}}
    j_s_interpreter_0._objects = hashmap_2



# Generated at 2022-06-26 13:32:29.134370
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Init
    extractor = JSInterpreter('')
    code = '''var test_obj = {
        var_0: 'a',
        var_1: 'b',
        var_3: function(a, b) {
            return a*b
        }
    }
    '''

    # Run the tested method
    res = extractor.extract_object('test_obj', code)

    # Check the values
    assert res['var_0'] == 'a'
    assert res['var_1'] == 'b'
    assert res['var_3'](2, 3) == 6

# Generated at 2022-06-26 13:32:36.426869
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Create a new JSInterpreter
    j_s_interpreter_0 = JSInterpreter('')

    # Call method interpret_expression
    result = j_s_interpreter_0.interpret_expression('[]', dict(), 100)

    # Assert the return type
    assert isinstance(result, list)
