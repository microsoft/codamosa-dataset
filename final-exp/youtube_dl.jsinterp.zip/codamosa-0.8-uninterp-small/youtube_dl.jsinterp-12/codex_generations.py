

# Generated at 2022-06-26 13:24:24.621366
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_code = '''
        var obj_name = {
            a: function(x,y) { return x+y; },
            b: function(x,y) { return x-y; }
        }
    '''

    j_s_interpreter_0 = JSInterpreter(test_code)

    try:
        j_s_interpreter_0.extract_object('obj_name')
    except ExtractorError as e:
        raise AssertionError(e)


# Generated at 2022-06-26 13:24:29.826571
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    j_s_interpreter_0 = JSInterpreter()
    assert j_s_interpreter_0.interpret_statement('var x = 1') == 1
    assert j_s_interpreter_0.interpret_statement('return 1') == 1
    assert j_s_interpreter_0.interpret_statement('return !!0') == False


# Generated at 2022-06-26 13:24:37.508518
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_list = []
    var_0 = test_list
    var_1 = remove_quotes(var_0)

    # Call method interpret_expression of class JSInterpreter
    JSInterpreter.interpret_expression(var_1)


if __name__ == '__main__':
    argc = len(sys.argv)
    argv = sys.argv
    if argc == 2:
        # Unit test for method interpret_expression of class JSInterpreter
        test_JSInterpreter_interpret_expression()
    else:
        main()

# Generated at 2022-06-26 13:24:40.511103
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    list_0 = []
    j_s_interpreter_0 = JSInterpreter(list_0)
    j_s_interpreter_0.extract_object("abc")


# Generated at 2022-06-26 13:24:44.444479
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    list_0 = ["a = {c: function(){},b: function(){},};","this.a={b:function(){}};",
    "this.a={b:function(){}};"]
    j_s_interpreter_0 = JSInterpreter(list_0)
    assert list_0 == j_s_interpreter_0._objects["a"]


# Generated at 2022-06-26 13:24:46.171240
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert(JSInterpreter.interpret_expression(1,1,1) == 1)



# Generated at 2022-06-26 13:24:53.103236
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    list_0 = []
    j_s_interpreter_0 = JSInterpreter(list_0)
    argnames_0 = list_0
    argnames_0 = ["x"]
    argnames_0.append(0)
    code_0 = ('(_e,_0,_1,_2,_3)=>{const _={">":(_e,_0)=>_e>_0,1:1,"+":(_e,_0)=>_e+_0,2:2};return _1(_0)}')
    code_0.strip()
    code_0 = '_0=_1[_2];'
    code_0 = 'return _0'
    code_0 = 'console.log(_0);'
    code_0 = ';'

# Generated at 2022-06-26 13:25:00.410592
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = 'function abc(a, b){return a + b;}'
    j_s_interpreter_0 = JSInterpreter(code)
    test_args = 'a,b'
    test_code = 'return a + b;'
    resf = j_s_interpreter_0.build_function(test_args, test_code)
    if (('a' in resf) == False):
        raise ValueError('Property a not in resf')
    if (resf.get('a') == None):
        raise ValueError('Property a contains None')
    if (('b' in resf) == False):
        raise ValueError('Property b not in resf')
    if (resf.get('b') == None):
        raise ValueError('Property b contains None')

# Generated at 2022-06-26 13:25:02.510781
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # $this->assertEquals(33, $this->js->call_function('foo', 5));
    assert 33 == JSInterpreter.call_function('foo', 5)



# Generated at 2022-06-26 13:25:05.086218
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    list_0 = []
    j_s_interpreter_0 = JSInterpreter(list_0)
    j_s_interpreter_0.interpret_expression()


# Generated at 2022-06-26 13:25:21.169621
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Test case 0
    js_interpreter_0 = JSInterpreter("var a=1;function b(){return a + 1;}b()")
    int_0 = js_interpreter_0.call_function("b")
    assert int_0 == 2


# Generated at 2022-06-26 13:25:29.157748
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
(function() {
    function parse_tk(e) {
        var o = {},
            i = 0;
        return o.tk = e.split("_")[0], o.ts = e.split("_")[1], o.vl = e.split("_")[2], o.pos = i, o.vl || "", o
    }
    console.log(parse_tk.toString());
    console.log(parse_tk.test.toString());
})();
"""
    interpreter = JSInterpreter(code)
    result = interpreter.extract_object('parse_tk');
    print(result)
    print(result['test']('this is a test'))

# Generated at 2022-06-26 13:25:40.082101
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = '''
        var some_var = 123;
        var some_object = {
            "one": 1,
            "two": 2,
            "three": function (arg1, arg2) {
                var local_var = "local_val";
                return local_var + arg1 + arg2;
            },
            "four": function (arg1) {
                int_0 += arg1;
                return int_0;
            }
        }
    '''
    interpreter = JSInterpreter(js)
    obj = interpreter.extract_object('some_object')

    assert(obj["one"] == 1)
    assert(obj["two"] == 2)
    assert(obj["three"]('a', 'b') == 'local_valab')
    assert(obj["four"](1) == 4)


# Generated at 2022-06-26 13:25:46.327792
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
                    <script type="text/javascript">
                    var jwplayer = jwplayer || {};jwplayer.key='h8TvRyMPrqz3D2PZoDn8uV7lBtmr/uN7srnE1U9ds6U=';
                    </script>
        
        """
    interpreter = JSInterpreter(code)
    result = interpreter.extract_function('jwplayer')
    assert result is not None


# Generated at 2022-06-26 13:25:55.612195
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = (
        """
        function myFunction(arg0) {
            var arg1 = 10;
            var arg2 = 15;
            return arg1 * arg0 + arg2;
        }
        """)
    interpreter = JSInterpreter(code)
    args = ('arg0',)
    code = 'var arg1 = 10; var arg2 = 15; return arg1 * arg0 + arg2;'
    result = interpreter.build_function(args, code)
    value = result(2)
    assert_equals(value, 35)



# Generated at 2022-06-26 13:25:57.547222
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    JSInterpreter(test_case_0)



# Generated at 2022-06-26 13:26:03.317268
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = """
        var int_0 = 0; int_1 ^= int_0; int_0 &= int_1; return int_1;
        """
    objects = {
        "int_0": None,
        "int_1": None
    }
    interpreter = JSInterpreter(code, objects)
    local_vars = interpreter._objects
    interpreter.interpret_statement(code, local_vars)


# Generated at 2022-06-26 13:26:09.366485
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:26:21.864887
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        function function1 (arg1, arg2, arg3) {
            var result = arg1.function2(arg3, arg2.function3(arg3));
            return result;
        }
        
        object1 = {
            method1: function () {
                return "method1";
            },
            method2: function (arg1, arg2) {
                return arg1 + "method2" + arg2;
            }
        };
        
        object2 = {
            method1: function (arg1) {
                return arg1.substring(0, 2);
            }
        };
    '''
    interpreter = JSInterpreter(code)
    object1 = interpreter.extract_object("object1")
    object2 = interpreter.extract_object("object2")

    assert object

# Generated at 2022-06-26 13:26:30.655789
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # 1
    interpreter = JSInterpreter('test', {'test': 0})
    assert interpreter.interpret_expression('test', {}, 1) == 0
    # 2
    interpreter = JSInterpreter('test', {'test': 0})
    assert interpreter.interpret_expression('"test"', {}, 1) == 'test'
    # 3
    interpreter = JSInterpreter('test', {'test': 0})
    assert interpreter.interpret_expression('"test"[0]', {}, 1) == 't'
    # 4
    interpreter = JSInterpreter('test', {'test': 0})
    assert interpreter.interpret_expression('test+1', {}, 1) == 1
    # 5
    interpreter = JSInterpreter('test', {'test': 0})

# Generated at 2022-06-26 13:26:53.399078
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    JSInterpreter._validate_args = lambda *args, **kwargs: True
    ji = JSInterpreter('')

# Generated at 2022-06-26 13:27:05.124401
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:27:11.708844
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter("function ytplayer_0(args){var v;var ytplayer = ytplayer_0.ytplayer;var config = ytplayer.config;var args = ytplayer.config.args;var args = ytplayer.config.args;var args = ytplayer.config.args;var args = ytplayer.config.args;var args = ytplayer.config.args;var args = ytplayer.config.args;int_0 = 1;return int_0}")

# Generated at 2022-06-26 13:27:19.476335
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')

    func = js_interpreter.build_function(['int_0'], 'int_0 += 1;')
    assert func([1]) == 2
    assert func([2]) == 3

    func = js_interpreter.build_function(['int_0', 'int_1'], 'int_0 += int_1;')
    assert func([1, 2]) == 3
    assert func([2, 3]) == 5


# Generated at 2022-06-26 13:27:22.804136
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert test_case_0() == js_interpreter.build_function(
        ["int_0"], "var int_1 = int_0")(1)


# Generated at 2022-06-26 13:27:26.286299
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter("")
    args = ["int_0"]
    code = "int_0 = 1"
    res = js.build_function(args,code)
    return (res([]),test_case_0())


# Generated at 2022-06-26 13:27:28.017852
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    target = JSInterpreter("")
    target.interpret_expression("1", {}, 1)


# Generated at 2022-06-26 13:27:31.024518
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    sample_JSInterpreter = JSInterpreter(
            self.code,
            self._functions,
            self._objects
    )

    assert sample_JSInterpreter.build_function() == 0

# Generated at 2022-06-26 13:27:32.202808
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    input = test_case_0()

    js = JSInterpreter(input)
    actual_output = js.interpret_expression()

    print(actual_output)



# Generated at 2022-06-26 13:27:35.714017
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_interpreter = JSInterpreter("var a = {\"b\": function (c){ d = c; }};")
    result = js_interpreter.extract_object("a")

# Generated at 2022-06-26 13:28:09.860952
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    expr = "var int_0 = 1"
    int_0 = 2
    argnames = ()
    code = 'int_0=1'
    JSInterpreter(expr, argnames, code)
    assert int_0 == 1, "Test failed"


# Generated at 2022-06-26 13:28:18.696826
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():

    # Splits a given string into a list of words
    def split(stmt, local_vars):
        stmt = input("Statement : ")
        if stmt.startswith('('):
            sub_expr = stmt[1:m.start()]
            sub_result = self.interpret_expression(sub_expr, local_vars, allow_recursion)
            remaining_expr = stmt[m.end():].strip()
            if not remaining_expr:
                return sub_result
            else:
                stmt = json.dumps(sub_result) + remaining_expr

        return stmt

    # Test 1, checks the function split
    print(split("(((('a', 'b', 'c'), '_')), _)", {}))
    # Test 2, checks the function split

# Generated at 2022-06-26 13:28:27.914713
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter("function test(arg1, arg2) {var res = arg1 + arg2; return res;}", {})
    res = interpreter.extract_function("test")

    # Expected result:
    # def resf(args):
    #     local_vars = dict(zip(["arg1", "arg2"], args))
    #     for stmt in "var res = arg1 + arg2; return res;".split(';'):
    #         res, abort = self.interpret_statement(stmt, local_vars)
    #         if abort:
    #             break
    #     return res
    ans = res((1,2))
    assert ans == 3


# Generated at 2022-06-26 13:28:32.999839
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = "var a = 'string'; var b = a;"
    objs = {
        'a': 'string',
        'b': None
    }
    js = JSInterpreter(code, objs)
    int_0 = js.interpret_expression('a', {})
    int_1 = js.interpret_expression('b', {})
    assert int_1 == 'string'


# Generated at 2022-06-26 13:28:36.052787
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test case 0
    print('Test case 0')
    print('  Expected: 1')
    print('  Actual  : %d' % int_0)
    assert int_0 == 1
    print('Test OK')


# Generated at 2022-06-26 13:28:38.734933
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
  assert JSInterpreter("").interpret_expression("1 + 2", {}, 100) == 3
  assert JSInterpreter("").interpret_expression("2 + 3 * 4", {}, 100) == 14

# Generated at 2022-06-26 13:28:50.029386
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:29:00.134474
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
        var int_0 = 1;
        var test = function(){
            return int_0;
        }
        test();
    """
    js_interpreter = JSInterpreter(code)
    func = js_interpreter.build_function(['int_0'], """
        return int_0;
    """)
    assert func([1]) == 1

    code = """
        var int_0 = 1;
        var test = function(){
            var int_1 = int_0 + 1;
            return int_1;
        }
        test();
    """
    js_interpreter = JSInterpreter(code)

# Generated at 2022-06-26 13:29:04.406124
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter(
        code='(function() { var int_0 = 1; return int_0; })()'
    )
    assert js_interpreter.interpret_expression(
        'int_0', local_vars={'int_0': 1}) == 1


# Generated at 2022-06-26 13:29:16.179140
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:29:34.734242
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_program = """
        function test() {
            var unit_test_var = 1;
            var unit_test_var_with_array = [1, 2, 3];
            return unit_test_var;
            return unit_test_var_with_array[0];
        }
    """
    test_js = JSInterpreter(test_program)
    assert test_js.interpret_expression("unit_test_var", {}) == 1
    assert test_js.interpret_expression("unit_test_var_with_array[0]", {}) == 1


# Generated at 2022-06-26 13:29:37.892223
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinterpreter = JSInterpreter("")
    func = jsinterpreter.build_function([], "int_0=1")
    assert func(tuple()) == 1


# Generated at 2022-06-26 13:29:43.638786
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    int_0 = 1
    jsi = JSInterpreter(code='''
        function int_0(arg_0, arg_1) {
            return Math.pow(arg_0, arg_1);
        };
    ''')
    func = jsi.build_function(["arg_0", "arg_1"], "return Math.pow(arg_0, arg_1);")
    assert func(3, 2) == 9

# Generated at 2022-06-26 13:29:51.874312
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:30:02.059729
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # test case 0
    code = """
        var int_0 = 1;
        int_0 = int_0 + 1;
        int_0 = int_0 - 1;
        int_0 = int_0 * 1;
        int_0 = int_0 / 1;
        int_0 = int_0 % 1;
        int_0 = int_0 << 1;
        int_0 = int_0 >> 1;
        int_0 = int_0 ^ 1;
        int_0 = int_0 & 1;
        int_0 = int_0 | 1;
        def test_case_0():
            int_0 = 1
    """
    funcname = test_case_0.__name__
    it = JSInterpreter(code)
    int_0 = it.extract_function(funcname)

# Generated at 2022-06-26 13:30:09.146799
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():

    s_0 = JSInterpreter('int_0 = 1;')
    assert s_0.interpret_expression('int_0', {}) == 1
    assert s_0.interpret_expression('int_0 + 2', {}) == 3
    assert s_0.interpret_expression('2 + 3 * 4 + int_0', {}) == 15
    assert s_0.interpret_expression('6 + (3 - 1)', {}) == 8

    s_0 = JSInterpreter('var int_0 = 1;')
    assert s_0.interpret_expression('int_0', {}) == 1
    assert s_0.interpret_expression('int_0 + 2', {}) == 3
    assert s_0.interpret_expression('2 + 3 * 4 + int_0', {}) == 15
    assert s_0.interpret_expression

# Generated at 2022-06-26 13:30:16.598534
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('', {}).interpret_expression('1 + 2 + 3', {}, 100) == 1 + 2 + 3
    assert JSInterpreter('', {}).interpret_expression('1 * 2 * 3 * 4 * 5', {}, 100) == 1 * 2 * 3 * 4 * 5
    assert JSInterpreter('', {'int_0': 1}).interpret_expression('int_0', {}, 100) == test_case_0()
    assert JSInterpreter('var int_0 = 1;', {}).interpret_expression('int_0', {}, 100) == 1
    assert JSInterpreter('var a = 1;\nvar b = a;', {}).interpret_expression('b', {}, 100) == 1


# Generated at 2022-06-26 13:30:20.030770
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = 'int_0=1; int_1=int_0;'
    interpreter = JSInterpreter(code)
    interpreter.interpret_expression('int_1',
                                     {'int_0': 1})


# Generated at 2022-06-26 13:30:30.020670
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:30:39.428211
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    _FUNC_NAME_RE = r'''(?:[a-zA-Z$0-9]+|"[a-zA-Z$0-9]+"|'[a-zA-Z$0-9]+')'''
    code = '''
        function int_0(arg){
            return arg + 1;
        }
        var int_1 = function(arg){
            return arg + 1;
        }
        '''
    jsinter = JSInterpreter(code)

# Generated at 2022-06-26 13:31:26.989108
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        var sig = function(a){return a}
        var func = function(a,b,c){return a+b+c}
        var ob = {a:1,b:function(){return this.a},c:[1,2,3],d:{e:'foo'}}
        var ob2 = {a:1,d:{e:'bar'}}
    '''

    jsi = JSInterpreter(code)
    assert jsi.call_function('sig', 5) == 5
    assert jsi.call_function('func', 5,6,7) == 18
    assert jsi.interpret_expression('ob.b()', {}) == 1
    assert jsi.interpret_expression('ob.c[2]', {}) == 3

# Generated at 2022-06-26 13:31:32.818611
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:31:42.363675
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('')
    def f(argnames, code):
        return js.build_function(argnames, code)
    f(['x'], 'x=1;return x + 5')([10]) == 16
    f(['x'], 'x=1;return x + 5')([15]) == 20

    f(['x'], 'x=1;return x = 5')([10]) == 5
    f(['x'], 'x=1;return x = 5')([15]) == 5

    f(['x'], 'x=1;y=x+1;return y')([10]) == 2

    f(['x'], 'return x + 5')([10]) == 15
    f(['x'], 'return x + 5')([15]) == 20



# Generated at 2022-06-26 13:31:49.117193
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsInterpreter = JSInterpreter("")
    funcname = "unitTest"
    code = "int_0=1;int_0"
    argnames = []
    func = jsInterpreter.build_function(argnames, code)
    assert func([]) == 1

# Generated at 2022-06-26 13:31:55.599342
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    class_name = 'JSInterpreter'
    method_name = 'interpret_expression'

    try:
        class_method = getattr(JSInterpreter, method_name)
        js_interpreter = JSInterpreter(test_case_0)
        int_0 = js_interpreter.interpret_expression('int_0', {})
        assert int_0 == 1
    except Exception as e:
        print("Error in %s.%s: %s" % (class_name, method_name, e))
        raise


# Generated at 2022-06-26 13:32:02.835370
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinterpreter = JSInterpreter("var int_0 = 1;")
    assert jsinterpreter.build_function(["args"], "int_0=1")() == 1, "Unexpected result"
    print('OK')

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-26 13:32:05.330584
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_case_0_inst = JSInterpreter('', {'int_0': 1})
    assert test_JSInterpreter_interpret_expression_res_0 == test_case_0_inst.interpret_expression('int_0', {'int_0': 1}, 100)


# Generated at 2022-06-26 13:32:18.456925
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter("var int_0 = 1; var int_1 = 2; var int_3 = int_0 + int_1;")
    assert js.interpret_expression("int_3", {}) == 3
    assert js.interpret_expression("int_3 + 4", {}) == 7
    assert js.interpret_expression("int_0", {}) == 1
    assert js.interpret_expression("int_0 + int_1", {}) == 3
    assert js.interpret_expression("int_1 / (int_0 + int_1)", {}) == 1 / 3
    assert js.interpret_expression("(int_0 + int_1)", {}) == 2
    assert js.interpret_expression("int_0 + int_1 + int_0", {}) == 3

# Generated at 2022-06-26 13:32:31.216053
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    """
    An example of valid javascript function expression
    """
    # test_case_0
    a = JSInterpreter("var int_0 = 0;")
    b = a.build_function(['int_0'], "var int_0 = 0;")
    assert b() == 0
    c = JSInterpreter("var int_0 = 0;", {'int_0': 1})
    d = c.build_function(['int_0'], "int_0 += 1;")
    assert d() == 2

    # test_case_1
    a = JSInterpreter("var int_0 = 0;")
    try:
        b = a.build_function(['int_0'], "var int_0 = 0;")
    except:
        assert True
    else:
        assert False



# Generated at 2022-06-26 13:32:41.975577
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('var a=1; var b=4;')
    assert jsi.interpret_expression('1', {'a':1, 'b':4}) == 1
    assert jsi.interpret_expression('a', {'a':1, 'b':4}) == 1
    assert jsi.interpret_expression('b', {'a':1, 'b':4}) == 4
    assert jsi.interpret_expression('3 + 2', {'a':1, 'b':4}) == 5
    assert jsi.interpret_expression('a + 2', {'a':1, 'b':4}) == 3
    assert jsi.interpret_expression('a + a', {'a':1, 'b':4}) == 2