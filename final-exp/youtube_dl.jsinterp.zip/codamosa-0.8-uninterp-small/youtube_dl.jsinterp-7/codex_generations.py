

# Generated at 2022-06-26 13:24:28.885493
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    obj = {'foo': 'bar'}
    def fnc(x, y):
        return x + y
    fnc.__name__ = 'foo'
    obj['foo'] = fnc
    jsint = JSInterpreter(None, objects={'obj': obj})
    assert(jsint.interpret_expression('obj.foo', {}, 100) == 'bar')
    assert(jsint.interpret_expression('obj["foo"]', {}, 100) == 'bar')
    assert(jsint.interpret_expression('obj.foo(10, 20)', {}, 100) == 30)
    assert(jsint.interpret_expression('obj.foo(10, 50.4)', {}, 100) == 60.4)

# Generated at 2022-06-26 13:24:31.976945
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert str_0 == JSInterpreter._code


# Generated at 2022-06-26 13:24:38.342143
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'function hello(strArgs) {return "hello" + strArgs}'
    response = j_s_interpreter_0.call_function(str_1, str_0)
    assert(response == 'hello<header id="page_header"\\')


# Generated at 2022-06-26 13:24:42.781832
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    args_0 = ['c', 'd']
    code_0 = 'var a = c;'
    j_s_interpreter_0.build_function(args_0, code_0)


# Generated at 2022-06-26 13:24:49.427143
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = '<header id="page_header"\\\\'
    if 'x' in globals():
        str_1 = x
    if 'y' in globals():
        str_1 = y
    str_2 = '<header id="page_header"\\\\'
    if not str_2 in globals():
        str_2 = y
    res = j_s_interpreter_0.extract_object(str_1)
    assert res == j_s_interpreter_0._objects[str_2]



# Generated at 2022-06-26 13:24:56.580660
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Input and expected result
    str_1 = '<header id="page_header"\\\\'
    str_2 = '<header id="page_header"\\\\'
    str_3 = '<header id="page_header"\\\\'
    str_4 = '<header id="page_header"\\\\'
    str_5 = '<header id="page_header"\\\\'
    str_6 = '<header id="page_header"\\\\'
    str_7 = '<header id="page_header"\\\\'
    str_8 = '<header id="page_header"\\\\'
    str_9 = '<header id="page_header"\\\\'
    str_10 = '<header id="page_header"\\\\'
    str_11 = '<header id="page_header"\\\\'

# Generated at 2022-06-26 13:25:03.188893
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():

    code = '''
        function encode_func(str) {
            var out = [];
            for (var i = 0; i < str.length; i++) {
                out.push(str.charCodeAt(i));
            }
            return out;
        }
    '''
    interpreter = JSInterpreter(code)
    encode_func = interpreter.build_function(('str',), 'for (var i = 0; i < str.length; i++) { out.push(str.charCodeAt(i)); }')
    assert encode_func('hello, world') == [104, 101, 108, 108, 111, 44, 32, 119, 111, 114, 108, 100]


# Generated at 2022-06-26 13:25:13.967088
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:25:24.256548
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-26 13:25:31.492407
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = '<header id="page_header"\\\\'
    # 
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = '"\\"", "\\\\", "&", "<", ">"'
    # 
    j_s_interpreter_0 = JSInterpreter(str_1)
    str_2 = '"\\"", "\\\\", "&", "<", ">"'
    # 
    j_s_interpreter_0 = JSInterpreter(str_2)
    str_3 = '"\\"", "\\\\", "&", "<", ">"'
    # 
    j_s_interpreter_0 = JSInterpreter(str_3)

# Generated at 2022-06-26 13:25:53.033430
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = '<header id="page_header"\\\\'
    str_1 = 'fnord'
    j_s_interpreter_0 = JSInterpreter(str_0)
    obj_0 = j_s_interpreter_0.extract_object(str_1)


# Generated at 2022-06-26 13:25:57.957474
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    obj_array_0 = j_s_interpreter_0.extract_object('page_header')


# Generated at 2022-06-26 13:26:06.264913
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = "var foo = {}; foo.bar = 5; foo['abc'] = 7; foo.def(1,2,3);"
    j_s_interpreter_0 = JSInterpreter(str_0)
    # Testcase 1: Simple object with string and int members
    obj_dict_0 = {}
    obj_dict_0['bar'] = 5
    obj_dict_0['abc'] = 7
    assert isinstance(j_s_interpreter_0.extract_object('foo'), dict)
    assert obj_dict_0 == j_s_interpreter_0.extract_object('foo')
    # Testcase 2: Simple object with string, int, and function members

# Generated at 2022-06-26 13:26:09.181405
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    obj_name_0 = 'pl'
    obj_0 = {'x': 1}
    assert obj_0 == j_s_interpreter_0.extract_object(obj_name_0)



# Generated at 2022-06-26 13:26:18.884807
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    local_vars = ['arg_0', 'arg_1', 'return']
    with pytest.raises(ExtractorError) as excinfo:
        JSInterpreter.build_function(argnames=local_vars, code='arg_0; arg_1; return')
    assert 'Premature left-side return of ' in str(excinfo.value)
    with pytest.raises(ExtractorError) as excinfo:
        JSInterpreter.build_function(argnames=local_vars, code='arg_0; arg_1; arg_0; return')
    assert 'Premature right-side return of ' in str(excinfo.value)


# Generated at 2022-06-26 13:26:24.388870
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    f = lambda x: x*2
    j_s_interpreter_0 = JSInterpreter('function foo(x){return(x*2)}')
    assert(j_s_interpreter_0.extract_function('foo') == f)


# Generated at 2022-06-26 13:26:29.297759
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:26:34.401143
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    print("# Unit test for method extract_object of class JSInterpreter")
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    j_s_interpreter_1 = JSInterpreter("")
    with pytest.raises(ExtractorError):
        j_s_interpreter_1.extract_object("page_header")


# Generated at 2022-06-26 13:26:36.700826
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert j_s_interpreter_0.build_function(["args", "code"], "") is not None


# Generated at 2022-06-26 13:26:42.135756
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    result = j_s_interpreter.build_function()
    assert result == None, (result, None)


# Generated at 2022-06-26 13:27:05.456814
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)

# Generated at 2022-06-26 13:27:10.543570
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        a = 1;
        b = 'abc';
        f = function(x) {
            return x * a;
        };
        g = function() {
            return 'b' + 'x' + b;
        };
        h = function() {
            return a;
        };
        i = {split: function() {return ['a', 'b', 'c'];}};
    '''
    interpreter = JSInterpreter(code)
    local_vars = {'a': 1}
    assert interpreter.interpret_expression('a', local_vars) == 1
    assert interpreter.interpret_expression('f(10)', local_vars) == 10
    assert interpreter.interpret_expression('f(a)', local_vars) == 1

# Generated at 2022-06-26 13:27:22.256799
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    local_vars_0 = dict()
    x_0 = j_s_interpreter_0.interpret_expression('-3^5', local_vars_0, 100)
    assert x_0 == -6
    str_1 = '<header id="page_header"\\\\'
    j_s_interpreter_1 = JSInterpreter(str_1)
    local_vars_0 = dict()
    x_1 = j_s_interpreter_1.interpret_expression('1+1', local_vars_0, 100)
    assert x_1 == 2
    str_2 = '<header id="page_header"\\\\'


# Generated at 2022-06-26 13:27:32.064942
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    def func0(args):
        var0 = args
        return var0[0]
    str0 = 'var a = 0; var b = 1;'
    j_s_interpreter0 = JSInterpreter(str0)
    var0 = dict()
    j_s_interpreter0.interpret_statement(str0, var0, 10)
    a = var0['a']
    b = var0['b']
    assert a == __builtin__.int(0)
    assert b == __builtin__.int(1)
    str1 = 'return a;'
    var1 = j_s_interpreter0.interpret_statement(str1, var0, 10)
    assert var1[0] == __builtin__.int(0)
    assert var1[1] == True
   

# Generated at 2022-06-26 13:27:34.680971
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Arrange
    # Act
    func = JSInterpreter.build_function(['local_vars'], 'return local_vars;')
    # Assert
    assert func(['value']) == 'value'



# Generated at 2022-06-26 13:27:38.187973
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    test_0 = 'j.s.i.call_function($ javascript $ , { } , [ ] , ( ) , "t est" , \'t e st\' , _ )'



# Generated at 2022-06-26 13:27:45.883680
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = '\\u003Cheader id=\\"page_header\\"\\u003E'
    j_s_interpreter_0.interpret_expression(str_0, j_s_interpreter_0._objects, -1)
    str_2 = '<header id="page_header"\\\\'
    j_s_interpreter_0.interpret_expression(str_1, j_s_interpreter_0._objects, -1)
    j_s_interpreter_0.interpret_expression(str_2, j_s_interpreter_0._objects, -1)


# Generated at 2022-06-26 13:27:55.603119
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = '<header id="page_header"\\\\'
    l_0 = list()
    l_0.append(str_0)
    l_0.append(str_0)
    l_1 = list()
    l_1.append(str_0)
    l_1.append(str_0)
    l_2 = list()
    l_2.append(str_0)
    l_2.append(str_0)
    l_2.append(str_0)
    l_0[0] = l_2
    l_0[1] = l_1
    l_1[0] = l_1
    l_1[1] = l_2
    l_2[0] = l_0
    l_2[1] = l_1
    l

# Generated at 2022-06-26 13:28:03.618880
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:28:06.989221
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    dict_1 = j_s_interpreter_0.extract_object('live_streaming_player_obj')


# Generated at 2022-06-26 13:28:34.558423
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = '<header id="page_header"\\\\'
    str_1 = 'x'
    str_2 = 'y'
    str_3 = 'z'
    str_4 = '"'
    str_5 = '\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)

    for i in range(100000):
        list_1 = function_0(j_s_interpreter_0, str_1, str_2, str_3, str_4, str_5)


# Generated at 2022-06-26 13:28:42.124766
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Below snippet is taken and modified from an existing codebase
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)

    str_0 = 'return h.join("")'
    str = j_s_interpreter_0.interpret_expression(str_0, {})

    assert (str == '<header id="page_header"\\\\')
    print('Test passed')

if __name__ == "__main__":
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:28:53.681061
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-26 13:29:00.602948
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = '<header id="page_header"\\\\'
    str_2 = '<header id="page_header"\\\\'
    str_3 = '<header id="page_header"\\\\'
    str_4 = '<header id="page_header"\\\\'
    j_s_interpreter_0.call_function(str_1, str_2, str_3, str_4)


# Generated at 2022-06-26 13:29:03.421219
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)


# Generated at 2022-06-26 13:29:15.195272
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():

    # Test case 0
    # Keep this comment
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)

    # Test case 1
    # Keep this comment
    str_1 = '<header id="page_header"\\\\'
    j_s_interpreter_1 = JSInterpreter(str_1)

    # Test case 2
    # Keep this comment
    str_2 = '<header id="page_header"\\\\'
    j_s_interpreter_2 = JSInterpreter(str_2)

    # Test case 3
    # Keep this comment
    str_3 = '<header id="page_header"\\\\'
    j_s_interpreter_3 = JSInterpreter(str_3)

# Generated at 2022-06-26 13:29:23.080207
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_function = JSInterpreter.build_function
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = '<header id="page_header"\\\\'
    j_s_interpreter_1 = JSInterpreter(str_1)
    str_2 = '<header id="page_header"\\\\'
    j_s_interpreter_2 = JSInterpreter(str_2)
    str_3 = '<header id="page_header"\\\\'
    j_s_interpreter_3 = JSInterpreter(str_3)
    str_4 = '<header id="page_header"\\\\'

# Generated at 2022-06-26 13:29:30.409593
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:29:40.531116
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_interpreter = JSInterpreter('var A = { f: function(){}, b: {g: function() {}}};')
    assert len(js_interpreter._objects) == 0
    assert js_interpreter._objects.get('A') is None
    js_interpreter.extract_object('A')
    assert 'f' in js_interpreter._objects['A']
    assert 'b' in js_interpreter._objects['A']
    assert isinstance(js_interpreter._objects['A']['f'], type(lambda x:x))
    assert 'g' in js_interpreter._objects['A']['b']
    assert isinstance(js_interpreter._objects['A']['b']['g'], type(lambda x:x))

# Unit test

# Generated at 2022-06-26 13:29:46.582794
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = (
        'function a(b) {\n'
        '    b = b - 1;\n'
        '    return b;\n'
        '}')
    str_1 = (
        'function a(b) {\n'
        '    b = b - 1;\n'
        '    return b;\n'
        '}')
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert j_s_interpreter_0.build_function([], str_1)() == 0

# Generated at 2022-06-26 13:30:09.345067
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    def func_0(str_0):
        j_s_interpreter_0 = JSInterpreter(str_0)
        str_1 = 'var p = {};'
        str_2 = 'p.x = 1;'
        str_5 = 'p.y = 2;'
        str_6 = 'p.y = p.x + 1;'
        str_7 = 'p.y = p.x-- + 1;'
        str_8 = 'p.y = p.x + (1);'
        str_9 = 'p.y = p.x + p.y;'
        str_10 = 'p.y = (p.x + p.y);'
        str_11 = 'p.y = p.x ^ p.y;'

# Generated at 2022-06-26 13:30:17.310308
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('')

    var_map = {'a': 1, 'b': 2}
    assert 1 == interpreter.interpret_expression('a', var_map)
    assert 2 == interpreter.interpret_expression('b', var_map)
    assert 1 == interpreter.interpret_expression('+a', var_map)
    assert -1 == interpreter.interpret_expression('-a', var_map)
    assert 3 == interpreter.interpret_expression('a+b', var_map)
    assert -1 == interpreter.interpret_expression('a-b', var_map)
    assert 2 == interpreter.interpret_expression('a*b', var_map)
    assert 0.5 == interpreter.interpret_expression('a/b', var_map)
    assert 0 == interpreter.interpret_expression('a%b', var_map)

# Generated at 2022-06-26 13:30:27.475499
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter(
        '''var a = {};
a.b = function(c){return c;};
a["d"] = function(e){return e;};
''')
    assert interpreter.interpret_expression('a.b(1)', {}) == 1
    assert interpreter.interpret_expression('a["b"](2)', {}) == 2
    assert interpreter.interpret_expression('a.d(3)', {}) == 3
    assert interpreter.interpret_expression('a["d"](4)', {}) == 4

    interpreter = JSInterpreter(
        '''var a = [1,2];
a[3] = 42;
''')
    assert interpreter.interpret_expression('a[0]', {}) == 1
    assert interpreter.interpret_expression('a[1]', {}) == 2
   

# Generated at 2022-06-26 13:30:30.030406
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """function ${functionName}(${variableNames}) {
    ${body}
}
"""
    argnames = ["functionName", "variableNames", "body"]
    resf = JSInterpreter.build_function(argnames, code)
    expected = "function test(a, b, c) {\n    a\n}"
    output = resf(["test", "a, b, c", "a"])
    assert(output == expected)


# Generated at 2022-06-26 13:30:32.986617
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = '<header id="page_header"\\\\'
    str_1 = 'ghj'
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert j_s_interpreter_0 is not None
    j_s_interpreter_0.call_function(str_1)


# Generated at 2022-06-26 13:30:36.720649
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    j_s_interpreter_0.call_function('jwplayer', '0')


# Generated at 2022-06-26 13:30:46.045216
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    expr = 'a'
    local_vars = {'a': 'hello'}
    JSInterpreter(expr).interpret_statement(expr, local_vars)
    expr = 'var a = "hello"; var b = "world"; return a + b'
    local_vars = {'a': 'hello'}
    JSInterpreter(expr).interpret_statement(expr, local_vars)
    expr = 'a + " world"'
    local_vars = {'a': 'hello'}
    JSInterpreter(expr).interpret_statement(expr, local_vars)
    expr = 'var f = function() { return "foo"; }'
    local_vars = {'a': 'hello'}
    JSInterpreter(expr).interpret_statement(expr, local_vars)

# Generated at 2022-06-26 13:30:54.948216
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    objects = {}
    j_s_interpreter_0 = JSInterpreter("", objects)
    j_s_interpreter_1 = JSInterpreter("", objects)
    j_s_interpreter_2 = JSInterpreter("", objects)
    j_s_interpreter_3 = JSInterpreter("", objects)
    j_s_interpreter_4 = JSInterpreter("", objects)
    j_s_interpreter_5 = JSInterpreter("", objects)
    j_s_interpreter_6 = JSInterpreter("", objects)
    j_s_interpreter_7 = JSInterpreter("", objects)
    j_s_interpreter_8 = JSInterpreter("", objects)
    local_vars_0 = {}
    input_0

# Generated at 2022-06-26 13:30:58.051271
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = '<header id="page_header"\\\\'
    f_0 = j_s_interpreter_0.build_function([str_1], [str_1, str_1])


# Generated at 2022-06-26 13:31:05.071815
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = ";function Hello1(a, b){};"
    j_s_interpreter_0 = JSInterpreter(str_0)

    str_1 = "Hello1(a, b);"
    argnames = str_1.split('(')[0].split()[1]
    args = str_1.split('(')[1].split(')')[0].split(',')
    code = str_1.split('{')[1].split('}')[0]

    result = j_s_interpreter_0.build_function(argnames, code)
    assert result == None


# Generated at 2022-06-26 13:31:31.008154
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'function test_JSInterpreter_build_function(arg) {return arg + \'test\';}'
    j_s_interpreter_0 = JSInterpreter(str_0)
    stmt = 'test_JSInterpreter_build_function(\'test\')'
    l_vars = []
    result = j_s_interpreter_0.interpret_expression(stmt, l_vars, 100)
    assert result == 'testtest'

# Generated at 2022-06-26 13:31:41.262789
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    _int_0 = 0
    _str_0 = ''
    _str_1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    _str_2 = '='
    _dict_0 = {}
    _list_0 = []
    _bool_0 = False
    _int_1 = 1
    _str_3 = 'i'
    _dict_1 = {'q': 16384, 'r': 2048, 's': 128}
    _dict_2 = {'c': 262144, 'b': 4096, 'a': 2048}

    _str_4 = '<header id="page_header"\\\\'
    j_s_interpreter_0 = JSInterpreter(_str_4)



# Generated at 2022-06-26 13:31:44.775698
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    print('test_JSInterpreter_extract_object...')
    str_0 = '<header id="page_header"\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    j_s_interpreter_0.extract_object('page_header')
    assert True


# Generated at 2022-06-26 13:31:54.170121
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    _FUNC_NAME_RE = r'''(?:[a-zA-Z$0-9]+|"[a-zA-Z$0-9]+"|'[a-zA-Z$0-9]+')'''
    str_0 = '<header id="page_header"\\\\'
    str_1 = 'header'
    j_s_interpreter_0 = JSInterpreter(str_0)
    result_0 = j_s_interpreter_0.extract_object(str_1)
    assert result_0 == {}


# Generated at 2022-06-26 13:32:04.417599
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    t_1 = '<header id="page_header"\
class="bg-dark-grey-1 fixed ws-nowrap"\
role="banner"\
data-ember-action="4"\
style="background-color: #414141;">'
    js_interpreter_1 = JSInterpreter(t_1)
    assert js_interpreter_1.extract_object(t_1) == eval(t_1)


# Generated at 2022-06-26 13:32:08.081229
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = 'function strToLong(str) {var hash = 0;var i = 0;for (i = 0; i < str.length; i++) {hash |= ((str.charCodeAt(i) & 0xff) << ((i & 3) << 3));}return hash;}'
    funcname = 'strToLong'
    j_s_interpreter_1 = JSInterpreter(str_0)
    assert j_s_interpreter_1.call_function(funcname, 'my').bit_length() == 64


# Generated at 2022-06-26 13:32:19.428249
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:32:31.515092
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Initialize a variable
    str_0 = '+3.2e+2+e'
    j_s_interpreter_0 = JSInterpreter(str_0)
    # Verify method call
    str_1 = '+3.2e+2+e'
    float_0 = j_s_interpreter_0.interpret_expression(str_1, {'e': 2.0})
    assert math.isclose(float_0, 322.0)

    # Initialize a variable
    str_2 = ' + 3.2e+2 + e'
    j_s_interpreter_1 = JSInterpreter(str_2)
    # Verify method call
    str_3 = ' + 3.2e+2 + e'

# Generated at 2022-06-26 13:32:38.863222
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = "function f(a,b) { return a; }"
    j_s_interpreter_0 = JSInterpreter(str_0)
    f = j_s_interpreter_0.build_function(['a', 'b'], "return a;")
    with open('../logs/test_JSInterpreter_build_function.log', 'w') as fout:
        fout.write(str(f([1,2])))


# Generated at 2022-06-26 13:32:45.093915
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_0 = JSInterpreter(';')
    j_s_interpreter_0.code = ';var a = j.length = 2;'
    j_s_interpreter_0.extract_object('j')

