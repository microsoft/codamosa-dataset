

# Generated at 2022-06-26 13:24:12.943304
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    expr_0 = 'k[a]'
    expr_1 = '2^4'
    expr_2 = '8**4'
    expr_3 = '1|4'
    expr_4 = '1<<42'
    expr_5 = 'a[b][c]'
    expr_6 = 'a[b.c]'
    expr_7 = 'a[b().c]'
    expr_8 = 'a[b(c).c]'
    expr_9 = 'a(0x29,0x0)'
    expr_10 = 'b.length'
    expr_11 = 'b.split("")'
    expr_12 = 'b.join("")'
    expr_13 = 'b.reverse()'
    expr_14 = 'b.slice(0)'

# Generated at 2022-06-26 13:24:26.440263
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test 1
    int_0 = -4740
    j_s_interpreter_0 = JSInterpreter(int_0)
    argnames_0 = []
    argnames_0.append("WT2")
    argnames_0.append("<%s>")
    argnames_0.append("'")
    argnames_0.append("\\")
    code_0 = "var a=parseInt(this,10);if(!arguments[0])return a;"
    code_0 += "if(!this.slice)return a;a=a-1;if(!a)return 1;"
    code_0 += "var b=(a&a-1)>>>0;a=a^b;a=a<<1;a=a|(a<<1)>>>0;"

# Generated at 2022-06-26 13:24:29.049483
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    '''
    expr = 'var a = 5; return a + 7;'
    expected = 12
    local_vars = {}
    res = JSInterpreter(expr).interpret_expression('a', local_vars)
    if res != expected:
        print 'Expected: %s, but got: %s' % (expected, res)
    assert res == expected
    '''


# Generated at 2022-06-26 13:24:39.592935
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    int_0 = -4740
    j_s_interpreter_0 = JSInterpreter(int_0)
    j_s_interpreter_0.code = 's,s,s'
    j_s_interpreter_0.extract_function('s')
    j_s_interpreter_0.extract_object('s')
    j_s_interpreter_0.call_function('s', 's', 's', 's')
    j_s_interpreter_0.extract_function('object')
    j_s_interpreter_0.extract_function('self')
    j_s_interpreter_0.extract_function('var')
    j_s_interpreter_0.extract_function('return')
    j_s_interpre

# Generated at 2022-06-26 13:24:43.791432
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    JSInterpreter_obj_0 = JSInterpreter()
    JSInterpreter_obj_1 = JSInterpreter()
    JSInterpreter_obj_2 = JSInterpreter()
    JSInterpreter_obj_3 = JSInterpreter()
    JSInterpreter_obj_4 = JSInterpreter()
    JSInterpreter_obj_5 = JSInterpreter()

    result = JSInterpreter_obj_0.extract_object(JSInterpreter_obj_1)
    result = JSInterpreter_obj_2.extract_object(JSInterpreter_obj_3)
    result = JSInterpreter_obj_4.extract_object(JSInterpreter_obj_5)


# Generated at 2022-06-26 13:24:45.578173
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    assert False, "Not implemented"


# Generated at 2022-06-26 13:24:46.836956
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # No example for this test case
    assert False

# unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-26 13:24:50.418251
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():

    assert j_s_interpreter_0.interpret_statement('a = b - c',null,True)[0] == int_0
    assert j_s_interpreter_0.interpret_statement('var e = 4',null,True)[0] == int_0
    assert j_s_interpreter_0.interpret_statement('return 42',null,True)[0] == int_0



# Generated at 2022-06-26 13:24:54.322555
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_2 = ""
    dictionary_0 = {}
    str_3 = ""
    object_0 = j_s_interpreter_0.interpret_statement(str_2, dictionary_0)
    object_1 = j_s_interpreter_0.interpret_statement(str_3, dictionary_0)


# Generated at 2022-06-26 13:25:02.045836
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    vars_0 = {}
    j_s_interpreter_0 = JSInterpreter(vars_0)
    j_s_interpreter_0.interpret_expression('var var1', vars_0, 100)
    j_s_interpreter_0.interpret_expression('var1 = 5', vars_0, 100)
    j_s_interpreter_0.interpret_expression('var1', vars_0, 100)
    j_s_interpreter_0.interpret_expression('var1', vars_0, 100)
    j_s_interpreter_0.interpret_expression('var1', vars_0, 100)
    j_s_interpreter_0.interpret_expression('var1', vars_0, 100)
    j_s_interpreter_0

# Generated at 2022-06-26 13:25:49.339209
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    C = ''
    j_s_interpreter_1 = JSInterpreter(C)
    str_0 = ''
    function_0 = j_s_interpreter_1.extract_function(str_0)
    C = ''
    j_s_interpreter_2 = JSInterpreter(C)
    str_1 = ''
    function_1 = j_s_interpreter_2.extract_function(str_1)
    C = ''
    j_s_interpreter_3 = JSInterpreter(C)
    str_2 = ''
    function_2 = j_s_interpreter_3.extract_function(str_2)
    C = ''
    j_s_interpreter_4 = JSInterpreter(C)
    str_3 = ''


# Generated at 2022-06-26 13:25:57.752606
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:26:03.173292
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
        function a(p, q) {
            return p + q;
        }

        function b(x) {
            return x * 2;
        }
    """
    jsi = JSInterpreter(code)
    assert jsi.call_function('a', 1, 2) == 3
    assert jsi.call_function('b', 21) == 42


# Generated at 2022-06-26 13:26:05.391041
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # input values
    objname='foo_obj'
    j_s_interpreter_0 = JSInterpreter(code)
    j_s_interpreter_0.extract_object(objname)


# Generated at 2022-06-26 13:26:08.394442
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    int_0 = -4740
    j_s_interpreter_0 = JSInterpreter(int_0)

    str_0 = j_s_interpreter_0.build_function(["arg0", "arg1"], "a = arg0 * arg1; return a;")(2, 3)
    assert str_0 == 6


# Generated at 2022-06-26 13:26:19.576694
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_0 = JSInterpreter('d={"a":function(b){return"a"+b;}, "b":"c"};e={"a":function(b){return"e"+b;}};')
    extract_object_0 = 'a'
    extract_object_1 = j_s_interpreter_0.extract_object(extract_object_0)

# Generated at 2022-06-26 13:26:29.546661
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter({})
    js_interpreter.interpret_statement('var a = 10', {})
    assert js_interpreter.interpret_statement('''
        var c = b = a = 10; c;
    ''', {})[0] == 10
    assert js_interpreter.interpret_statement('''
        var c = b = a = 10; b;
    ''', {})[0] == 10
    assert js_interpreter.interpret_statement('''
        var c = b = a = 10; a;
    ''', {})[0] == 10
    assert js_interpreter.interpret_statement('''
        var a, c = b = a = 10; c;
    ''', {})[0] == 10

# Generated at 2022-06-26 13:26:30.624326
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Test cases
    test_case_0()


# Generated at 2022-06-26 13:26:35.818026
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_0 = JSInterpreter(None)
    j_s_interpreter_extract_object_0 = j_s_interpreter_0.extract_object('A')
    assert len(j_s_interpreter_extract_object_0) == 1
    assert j_s_interpreter_extract_object_0['B'].__name__ == 'resf'


# Generated at 2022-06-26 13:26:36.760555
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_case_0()

test_case_id = 0

# Generated at 2022-06-26 13:26:57.245143
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = (
        'function func_0(a) { return a; };\n'
        'function func_1(a, b) { return a + b; };\n'
    )
    j_s_interpreter_0 = JSInterpreter(code)
    j_s_interpreter_1 = JSInterpreter(code)
    assert j_s_interpreter_0.extract_function('func_0')((4,)) == 4
    assert j_s_interpreter_1.extract_function('func_1')((4, 2)) == 6



# Generated at 2022-06-26 13:27:07.859302
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    int_0 = 14
    j_s_interpreter_0 = JSInterpreter(int_0)
    str_0 = "f0:a}"
    j_s_interpreter_0.extract_object(str_0)
    int_1 = 0
    str_1 = "undefined"
    str_2 = "a"
    int_2 = 0
    dict_0 = dict()
    dict_0[int_2] = int_1
    dict_0[str_2] = int_1
    str_3 = "b"
    dict_0[str_3] = int_1
    str_4 = "c"
    dict_0[str_4] = int_1
    str_5 = "d"
    dict_0[str_5] = int_1


# Generated at 2022-06-26 13:27:13.106135
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test for JS expression int_0
    interpreter = JSInterpreter('var a = 1 + 2 + 3', objects={"a": 1})
    assert interpreter.interpret_expression('a', {}) == 6
    interpreter = JSInterpreter('var a = (1)', objects={"a": 1})
    assert interpreter.interpret_expression('a', {}) == 1
    interpreter = JSInterpreter('var a = (1 + 2)', objects={"a": 1})
    assert interpreter.interpret_expression('a', {}) == 3
    interpreter = JSInterpreter('var a = 1 + 2 + 3', objects={"a": 1})
    assert interpreter.interpret_expression('a', {}) == 6
    interpreter = JSInterpreter('var a = 1 + 2 * 3', objects={"a": 1})
    assert interpreter.interpret_

# Generated at 2022-06-26 13:27:18.375467
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test initializes and executes code snippet
    # Test 1
    int_0 = -7234
    j_s_interpreter_0 = JSInterpreter(int_0)
    str_0 = 'var"var" = ; var 3;'
    dict_0 = {
        ";": -7234,
        '3': -7234
    }
    j_s_interpreter_0.interpret_statement(str_0, dict_0)
    # Test 2
    int_1 = -2717
    j_s_interpreter_1 = JSInterpreter(int_1)
    str_1 = 'return 6; var l}]; obj[2];'
    dict_1 = {
        'l}]': -2717,
        'obj[2]': -2717
    }


# Generated at 2022-06-26 13:27:23.249544
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    func_name = "a"
    code = "function a() { return 2 + 2; }"
    j_s_interpreter_0 = JSInterpreter(code)
    f = j_s_interpreter_0.extract_function(func_name)
    assert (f() == 4)


# Generated at 2022-06-26 13:27:32.812426
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        function f(a, b) {
            return a + b;
        }
        var abc = 10;
        var arr = ['abc', 'bcd', 'efg'];
    '''
    jsi = JSInterpreter(code)
    assert jsi.interpret_expression('f', {}) is jsi._functions['f']
    assert jsi.interpret_expression('abc', {}) == 10
    assert jsi.interpret_expression('arr', {}) is jsi._objects['arr']
    assert jsi.interpret_expression('arr[0]', {}) == 'abc'
    assert jsi.interpret_expression('f(1, 2)', {}) == 3
    assert jsi.interpret_expression('f(1, 2) + abc', {}) == 13

# Generated at 2022-06-26 13:27:38.563925
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:27:41.657075
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code_0 = '[1,2,3,4]'
    argnames_0 = ['a', 'b', 'c']
    func_0 = JSInterpreter.build_function(code_0, argnames_0)
    assert func_0 is not None



# Generated at 2022-06-26 13:27:44.386987
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    int_0 = -4740
    j_s_interpreter_0 = JSInterpreter(int_0)
    # test_case_0
    j_s_interpreter_0.extract_object('lk')


# Generated at 2022-06-26 13:27:54.233962
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    func = 'this.oNB = function(a, b) {\n' \
           '  var c = b || 0;\n' \
           '  return this.SB[a] << c | this.SB[a + 1] >> 8 - c\n' \
           '};'
    argnames = ['a', 'b']

    func_code = '  var c = b || 0;\n' \
                '  return this.SB[a] << c | this.SB[a + 1] >> 8 - c\n'

    interpreter = JSInterpreter(func)
    res = interpreter.build_function(argnames, func_code)
    assert res('a', 'b') is None
    return res

test_result = test_JSInterpreter_build_function()

#print(test_result)

# Generated at 2022-06-26 13:28:20.124308
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    j_s_interpreter_0 = JSInterpreter(int_0)
    # method call_function of class JSInterpreter
    int_0 = -4740
    assert(j_s_interpreter_0.call_function("int_0") == -4740)


if __name__ == "__main__":
    test_case_0()
    test_JSInterpreter_call_function()

# Generated at 2022-06-26 13:28:29.546999
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Input parameters
    argnames = ['arg1', 'arg2', 'arg3', 'arg4', 'arg5', 'arg6', 'arg7', 'arg8', 'arg9', 'arg10']
    code = '''a = 3;
	b = 5;
	return a;'''

    # Expected result
    expected_result = {'resf': 'resf'}

    # Process
    j_s_interpreter_0 = JSInterpreter(2)  # TODO: Check parameters in instantiation
    resf = j_s_interpreter_0.build_function(argnames, code)

    # Verification
    assert expected_result == resf



# Generated at 2022-06-26 13:28:36.265247
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    var_1 = 'var a = "b";'
    var_2 = 'a = b'
    var_3 = 'a'
    var_4 = 'd = "Hello, world!";'

    j_s_interpreter_1 = JSInterpreter(var_1)
    j_s_interpreter_1.build_function(var_2, var_3)
    j_s_interpreter_1.build_function(var_4, 4)

test_case_0()
test_JSInterpreter_build_function()

# Generated at 2022-06-26 13:28:46.564406
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    int_0 = -4740
    int_1 = -6290
    int_2 = -2154
    # Function call: build_function
    int_3 = ((((int_1 * (int_1 + int_0)) * int_0) % int_2) + (int_1 + int_0))
    int_4 = ((((int_0 / int_2) * int_2) + (int_2 - int_2)) + (int_0 * int_0))
    expected_1 = (int_3 % int_4)
    int_5 = 880
    int_6 = ((((int_0 - int_0) - int_5) - int_0) * int_2)

# Generated at 2022-06-26 13:28:55.570508
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    int_0 = 3
    j_s_interpreter_0 = JSInterpreter(int_0)
    string_0 = 'function(b,a){var c=a.length;while(b<c){var d=b+c>>1,e=a[d];if(e>=360){c=d}else{b=d+1}}return a.length-b}'
    tuple_0 = j_s_interpreter_0.call_function('function', int_0, string_0)
    assert tuple_0 == (1,)


# Generated at 2022-06-26 13:28:57.980869
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter_interpret_expression(1, 2, 3) == 3
    assert JSInterpreter_interpret_expression(1, 2, 4) == 5



# Generated at 2022-06-26 13:29:05.435425
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    s = '''
    var a = {
        "b": function(p) { return p; },
        "c": function(p) { return p+1; },
    }
    '''
    jsi = JSInterpreter(s)
    obj = jsi.extract_object('a')
    assert obj['b'](4) == 4
    assert obj['c'](4) == 5

    obj = jsi.extract_object('a')
    assert obj['b'](4) == 4
    assert obj['c'](4) == 5


# Generated at 2022-06-26 13:29:09.594289
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Arrange
    int_0 = -4740
    j_s_interpreter_0 = JSInterpreter(int_0)

# Generated at 2022-06-26 13:29:18.998850
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    objname = "a_a"
    funcname = "funcname"
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3

    j_s_interpreter_0 = JSInterpreter(int_0)
    j_s_interpreter_0.extract_function(objname)
    # Get the function code
    j_s_interpreter_0.build_function(int_1, int_2)
    # Call function
    j_s_interpreter_0.call_function(funcname)
    # Get the object
    j_s_interpreter_0.extract_object(objname)
    # Get the member of object

# Generated at 2022-06-26 13:29:22.398564
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    argnames = ['test']
    code = 'a=5*5;b=5+5;'
    j_s_interpreter_0 = JSInterpreter(code)
    j_s_interpreter_0.build_function(argnames,code)


# Generated at 2022-06-26 13:29:51.362698
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    int_0 = -4740
    j_s_interpreter_0 = JSInterpreter(int_0)
    j_s_interpreter_0.extract_object('n')


# Generated at 2022-06-26 13:29:58.830694
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    j_s_interpreter_0 = JSInterpreter
    # TypeError: Expected str, not NoneType
    try:
        j_s_interpreter_0.call_function()
    except Exception as e:
        assert type(e) == TypeError

    j_s_interpreter_0 = JSInterpreter
    # TypeError: Expected str, not float
    try:
        j_s_interpreter_0.call_function(3.14159)
    except Exception as e:
        assert type(e) == TypeError

# Generated at 2022-06-26 13:30:01.594595
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    int_0 = -4740

    obj = j_s_interpreter_0.extract_object(int_0)
    print(obj)


# Generated at 2022-06-26 13:30:07.498521
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    JSInterpreter_instance_0 = JSInterpreter(str_0)
    JSInterpreter_instance_1 = JSInterpreter(str_0)
    JSInterpreter_instance_2 = JSInterpreter(str_0)
    dict_1 = JSInterpreter_instance_1.extract_object(str_0)
    dict_4 = JSInterpreter_instance_0.extract_object(str_0)
    dict_3 = JSInterpreter_instance_2.extract_object(str_0)
    dict_2 = JSInterpreter_instance_0.extract_object(str_0)


# Generated at 2022-06-26 13:30:10.156599
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    int_0 = 4
    j_s_interpreter_0 = JSInterpreter(int_0)
    int_1 = 4
    int_2 = 4
    j_s_interpreter_0.interpret_expression(int_1, int_2)


# Generated at 2022-06-26 13:30:18.953794
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    int_0 = -4740
    j_s_interpreter_0 = JSInterpreter(int_0)

    assert j_s_interpreter_0.build_function([], "function r(e,n){return e<n?-1:e>n?1:0}")({}) == None
    assert j_s_interpreter_0.build_function(["e", "n"], "function r(e,n){return e<n?-1:e>n?1:0}")(["e", "n"]) == 0
    assert j_s_interpreter_0.build_function(["e", "n"], "function r(e,n){return e<n?-1:e>n?1:0};")(["e", "n"]) == None
    assert j_s_

# Generated at 2022-06-26 13:30:29.035475
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code_0 = """
        function function_0(p_0, p_1, p_2, p_3, p_4)
        {
            var v_0 = p_0;
            var v_1 = p_1;
            var v_2 = p_2;
            var v_3 = p_3;
            var v_4 = p_4;
            return v_0;
        }"""
    argnames_0 = ["p_0", "p_1", "p_2", "p_3", "p_4"]
    int_0 = -4740
    int_1 = -4740
    int_2 = -4740
    int_3 = -4740
    int_4 = -4740

# Generated at 2022-06-26 13:30:36.452794
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Tests are randomly generated, so we have to import them dynamically
    global test_cases
    import test.js_interpreter_test_cases as test_cases
    try:
        for i, (funcname, argnames, code, expected_result) in enumerate(test_cases.test_cases_0):
            func = test_cases.j_s_interpreter_0.build_function(argnames, code)
            assert func(expected_result[0]) == expected_result[1]
    except AssertionError as e:
        print("Error in test case number %s" % i)
        raise e


# Generated at 2022-06-26 13:30:45.587821
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    int_0 = -4740
    j_s_interpreter_0 = JSInterpreter(int_0)


# Generated at 2022-06-26 13:30:49.265304
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    actual = JSInterpreter('f={a:function(b){return b+1}}').extract_object('f')
    expected = {'a': lambda b: b + 1}
    assert actual == expected


# Generated at 2022-06-26 13:32:00.515784
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Basic
    JSInterpreter.interpret_expression(None, None, None)

    # Invalid
    with pytest.raises(ExtractorError):
        JSInterpreter.interpret_expression(None, None, None, None)


# Generated at 2022-06-26 13:32:07.174964
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter("""
    a = {};
    a.b = function() {
        return 3;
    };
    """)
    value = js_interpreter.interpret_expression('a.b()', {})
    assert value == 3

    js_interpreter = JSInterpreter("""
    a = {};
    a.b = function(x, y) {
        return x + y;
    };
    """)
    value = js_interpreter.interpret_expression('a.b(1, 2)', {})
    assert value == 3



# Generated at 2022-06-26 13:32:12.182726
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = JSInterpreter(None)
    int_2 = 3
    int_1 = j_s_interpreter_0.interpret_expression('(1+2)', int_2)



# Generated at 2022-06-26 13:32:21.297099
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('', {'hello': 'world'})
    assert js_interpreter.interpret_expression('hello', {}, 1) == 'world'
    assert js_interpreter.interpret_expression('"hello"', {}, 1) == 'hello'
    assert js_interpreter.interpret_expression('hello.indexOf("e")', {}, 1) == 1
    assert js_interpreter.interpret_expression(
        'k = "abcd"; k.length', {'k': None}, 1) == 4
    assert js_interpreter.interpret_expression(
        'l = [1, 2, 3]; l.length', {'l': None}, 1) == 3

# Generated at 2022-06-26 13:32:25.566263
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    assert JSInterpreter('encodeURIComponent', {}).extract_object == 'encodeURIComponent'


# Generated at 2022-06-26 13:32:31.185644
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    print('Testing call_function of class JSInterpreter')
    code = '''function add(x, y) { return x + y; }'''
    jsinterpreter = JSInterpreter(code)
    result = jsinterpreter.call_function('add', 3, 5)
    expected_result = 8
    assert result == expected_result, 'Result of call_function function call not as expected'
    print('test_JSInterpreter_call_function passed')


# Generated at 2022-06-26 13:32:41.977862
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    int_0 = 15
    j_s_interpreter_0 = JSInterpreter(int_0)
    j_s_interpreter_0.interpret_expression(None, None, None)
    j_s_interpreter_1 = JSInterpreter(-19)
    j_s_interpreter_1.interpret_expression(None, None, None)
    j_s_interpreter_2 = JSInterpreter(-19)
    j_s_interpreter_2.interpret_expression(127, None, None)
    j_s_interpreter_3 = JSInterpreter(-16)
    j_s_interpreter_3.interpret_expression(-16, None, None)
    j_s_interpreter_4 = JSInterpreter(-16)
    j_s_interpre

# Generated at 2022-06-26 13:32:49.065679
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_1 = JSInterpreter("$('#abc').xyz(123)")
    j_s_interpreter_1.extract_object("$")
    j_s_interpreter_1.extract_object("$('#abc')")


# Generated at 2022-06-26 13:32:53.291064
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter("foo")
    js_interpreter.interpret_expression("12", {'foo':1}) == 12


# Generated at 2022-06-26 13:32:58.630187
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code_0 = """
        function foo(){
            var x = 'x';
            var z = {};
            z[x] = function(c){
                return "y" + c;
            }
        }
    """
    j_s_interpreter_0 = JSInterpreter(code_0)
    rc = j_s_interpreter_0.extract_object('z')
