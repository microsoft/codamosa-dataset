

# Generated at 2022-06-26 13:24:15.049732
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_1 = '''
    function a(b, c) {
        return (b * c)
    }
    a.b = {
        'a': function(b) {
            return (b * a.c)
        },
        'c': function(b) {
            return (b - a.c)
        }
    }
    a.c = {
        'a': function(b) {
            return (b - a.c)
        },
        'c': function(b) {
            return (b - a.c)
        }
    }
    a.c = (a.c - a.c)
    '''

# Generated at 2022-06-26 13:24:17.473917
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    str_0 = '\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'abc'
    dict_0 = {}
    j_s_interpreter_0.interpret_statement(str_1, dict_0)
    pass



# Generated at 2022-06-26 13:24:19.668837
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    j_s_interpreter_0 = JSInterpreter(str_0)


# Generated at 2022-06-26 13:24:31.418400
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Input
    input_str_0 = '''return a + b;'''

    # Output
    output_str_0 = '''function f(a, b){
        return a + b;
    }'''

    # Expected result
    expected_result_0 = lambda x, y: x + y

    # Unit test for method extract_function of class JSInterpreter
    input_str_1 = '''return (a + b) * c'''

    output_str_1 = '''function f(a, b, c){
        return (a + b) * c
    }'''

    expected_result_1 = lambda x, y, z: (x + y) * z

    input_str_2 = '''return a.b'''


# Generated at 2022-06-26 13:24:41.752350
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'function f(a, b) { return (function(x) { return x.split(y); }(a + b).join(a)); }'
    str_1 = 'function g(a, b) { (function(b) { return a[b]; }(1)); }'

    j_s_interpreter_0 = JSInterpreter(str_0)
    j_s_interpreter_1 = JSInterpreter(str_1)

    assert j_s_interpreter_0.build_function(['a', 'b'], 'return (function(x) { return x.split(y); }(a + b).join(a));')(['ba', 'c']) == 'bacba'

# Generated at 2022-06-26 13:24:48.543040
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = '\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'var vq3={\'hb\':function(jj){while(jj)if(jj[0]>=\'A\'&&jj[0]<=\'Z\')return false;else jj=jj[1];return true},\'B\':function(jj){var k=0;while(jj&&jj.length>0){k+=jj[0];jj=jj[1];}return k},\'K\':function(jj){var k=0;while(jj){k++;jj=jj[1];}return k}};function vq9(){return 3+2;}function vq10(){return 5+2;}function vq11(){return 8;}'
    j_s_interpreter_

# Generated at 2022-06-26 13:24:50.726756
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    j_s_interpreter_0 = JSInterpreter('function abc(){};')
    assert(j_s_interpreter_0.extract_function('abc') is not None)



# Generated at 2022-06-26 13:24:55.160518
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var c = {\
        b: function(p) { return -p; },\
        a: function(p) { return p * p * p; }}\
        '''
    j_s_interpreter = JSInterpreter(code)
    obj = j_s_interpreter.extract_object('c')
    assert obj['a'](3) == 27
    assert obj['b'](4) == -4



# Generated at 2022-06-26 13:25:02.786603
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():

    #
    objname = 'sa'

# Generated at 2022-06-26 13:25:13.391927
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'var $ = function(a){return function(b){return a.split(b)}};'
    #str_0 = 'var $ = function(a){return a.split("")};'
    j_s_interpreter_0 = JSInterpreter(str_0)
    code = 'var ka=this.n.location.hostname;var D=$.split(ka,".");var Z=D.length;var X=-1;for(var W=0;W<Z;W++){var c=D[W];var Q=c.length;if(Q>X&&f.$(c)){X=Q}};var P=D[Z-2]+"."+D[Z-1];return P'
    res = j_s_interpreter_0.interpret_expression(code, {})

# Generated at 2022-06-26 13:25:47.126815
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = "\n    function a(b, c) {\n        return (b * c)\n    }\n    a.b = {\n        'a': function(b) {\n            return (b * a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = {\n        'a': function(b) {\n            return (b - a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = (a.c - a.c)\n    "

    return JSInterpreter(str_0, None).call_function("a",1,1)


# Generated at 2022-06-26 13:25:51.995746
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter(str_0)
    assert js_interpreter.extract_function('a') == js_interpreter.build_function(['b', 'c'], 'return (b * c)')

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 13:26:03.642259
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    int_0 = 5
    int_1 = 10
    str_0 = "\n    function a(b, c) {\n        return (b * c)\n    }\n    a.b = {\n        'a': function(b) {\n            return (b * a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = {\n        'a': function(b) {\n            return (b - a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = (a.c - a.c)\n    "
    int_2 = 50
    interpreter = JSInterpreter(str_0)


# Generated at 2022-06-26 13:26:08.080271
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = "var a=1,b=2,c=a+b,d=c+1;return d;"
    local_vars = {}
    obj = JSInterpreter(code)
    result = obj.interpret_statement(code, local_vars)
    assert result == (4, True)
    assert local_vars['a'] == 1
    assert local_vars['b'] == 2
    assert local_vars['c'] == 3
    assert local_vars['d'] == 4


# Generated at 2022-06-26 13:26:09.545141
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    global str_0
    interpreter = JSInterpreter(str_0)
    assert interpreter.interpret_expression("b", {}) is None


# Generated at 2022-06-26 13:26:15.542404
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    int_0 = 6
    int_1 = 9
    js_interpreter_0 = JSInterpreter("var a = 6;")
    js_interpreter_0.interpret_statement("return a+9;");
    int_2 = js_interpreter_1.interpret_statement("b = 15;", js_interpreter_0.interpret_statement("var c = 7; return a*c;"));


# Generated at 2022-06-26 13:26:27.900756
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_1 = "\n    function a(b, c) {\n        return (b * c)\n    }\n    a.b = {\n        'a': function(b) {\n            return (b * a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = {\n        'a': function(b) {\n            return (b - a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = (a.c - a.c)\n    "
    jsi = JSInterpreter(str_1)
    assert jsi.call_function("a", 2, 5) == 10

# Generated at 2022-06-26 13:26:28.507263
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    JSInterpreter(str_0)

# Generated at 2022-06-26 13:26:29.803611
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    jsinterpreter = JSInterpreter(test_case_0.str_0)

    assert jsinterpreter.call_function('a', 3, 4) == 12


# Generated at 2022-06-26 13:26:41.226431
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = "\n    function a(b, c) {\n        return (b * c)\n    }\n    a.b = {\n        'a': function(b) {\n            return (b * a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = {\n        'a': function(b) {\n            return (b - a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = (a.c - a.c)\n    "
    obj_0 = JSInterpreter(str_0)
    res_0 = obj_0.extract_object('a.b')


# Generated at 2022-06-26 13:26:56.337440
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    result = test_case_0()


# Generated at 2022-06-26 13:27:00.010141
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    global str_0
    str_1 = 'a'

    v = JSInterpreter(str_0).extract_function(str_1)

    x = [int, None]

    assert v in x


# Generated at 2022-06-26 13:27:05.414219
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = "function f1(a, b) {var a; return a + b}"
    interpreter = JSInterpreter(js_code)
    func = interpreter.build_function(['a', 'b'], "return a + b")
    res = func([2, 3])
    assert res == 5


# Generated at 2022-06-26 13:27:09.312924
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter.JSInterpreter(str_0)
    argnames = ['b', 'c']
    code = 'return (b * c)'
    resf = js_interpreter.build_function(argnames, code)
    assert resf([2, 3]) == 6

_TEST_CASES = [
    test_case_0,
]


# Generated at 2022-06-26 13:27:15.137451
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-26 13:27:21.183496
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsint = JSInterpreter('')
    resf = jsint.build_function(['a', 'b'], 'return (a + b);')
    assert resf((1, 2)) == 3
    resf = jsint.build_function(['a', 'b'], 'return a.b(b);')
    assert resf(('foo', 'bar')) == 'foobar'


# Generated at 2022-06-26 13:27:24.516732
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    inter = JSInterpreter(str_0)
    res = inter.build_function(['b', 'c'], "\n        return (b * c)\n    ")
    assert res([1, 2]) == 2


# Generated at 2022-06-26 13:27:29.216350
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter(test_case_0())
    stmt = "a(1, 2)"
    local_vars = {'a': 2}
    try:
        js_interpreter.interpret_statement(stmt, local_vars)
        test_success()
    except ExtractorError as e:
        print(e)


# Generated at 2022-06-26 13:27:35.231462
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_2 = 'function(b, d) {\n       if((a.b.c((a.c * b)) == d)) {\n               return (d + a.b.c(b))\n       }\n       return (a.b.c(b) - b)\n    }'
    js_interpreter = JSInterpreter(str_0)
    js_interpreter.build_function(('b', 'd'), str_2)
    # AssertionError: assert (a.b.c(b) - b) == 4


# Generated at 2022-06-26 13:27:37.088619
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    interpreter = JSInterpreter(test_case_0())

    func_res = interpreter.extract_function("a")
    assert func_res((3, 4)) == 12

# Generated at 2022-06-26 13:28:26.888849
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    interpreter = JSInterpreter(str_0)

    actual = interpreter.call_function("a.b.a", 4)
    expected = 16

    assert actual == expected


# Generated at 2022-06-26 13:28:36.182600
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter("\n    function a(b, c) {\n        return (b * c)\n    }\n    a.b = {\n        'a': function(b) {\n            return (b * a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = {\n        'a': function(b) {\n            return (b - a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = (a.c - a.c)\n    ")
    argnames = ['b', 'c']
    code = "return (b * c)"
    res = interpreter.build_function

# Generated at 2022-06-26 13:28:46.472009
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_interpreter = JSInterpreter(test_case_0())

    # Extract object a.b

# Generated at 2022-06-26 13:28:51.743858
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter(test_case_0())
    assert js_interpreter.build_function(['b', 'c'], 'return (b * c)')([2, 3]) == 6

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-26 13:28:56.088603
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    interp = JSInterpreter(test_case_0())
    obj = interp.extract_object('a')
    assert obj == dict(b=dict(a=None, c=None), c=dict(a=None, c=None))


# Generated at 2022-06-26 13:28:58.206682
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsinterp = JSInterpreter(str_0)
    assert jsinterp.call_function('a', 1, 2) == 2


# Generated at 2022-06-26 13:29:00.451814
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    val = JSInterpreter(str_0).call_function('a', 1, 2)
    assert val == 2


# Generated at 2022-06-26 13:29:02.519790
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
  js_interpreter = JSInterpreter(str_0)
  assert js_interpreter.call_function("a", 3, 2) == 6

# Generated at 2022-06-26 13:29:14.641175
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = "\n    function a(b, c) {\n        return (b * c)\n    }\n    a.b = {\n        'a': function(b) {\n            return (b * a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = {\n        'a': function(b) {\n            return (b - a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = (a.c - a.c)\n    "
    j = JSInterpreter(str_0)
    obj = j.extract_object('a')
    assert 'a' in obj


# Generated at 2022-06-26 13:29:21.406653
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter(test_case_0())
    f = js.build_function(['b', 'c'], ';\n    return (b * c)\n    ;')
    assert f((2, 3)) == 6
    f = js.build_function(['b'], ";\n            return (b * a.c)\n            ;")
    assert f((2,)) == 2
    f = js.build_function(['b'], ";\n            return (b - a.c)\n            ;")
    assert f((2,)) == 2
    f = js.build_function(['b'], ";\n            return (b - a.c)\n            ;")
    assert f((2,)) == 2

# Generated at 2022-06-26 13:30:52.839218
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Initialize the JSInterpreter instance
    obj = JSInterpreter(str_0)
    # Extract the target function
    a = obj.extract_function('a')
    # Call the target function
    a((7, 9))
    assert a((7, 9)) == 63


# Generated at 2022-06-26 13:30:54.847806
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print(JSInterpreter(str_0).interpret_expression('(a.c.a + a.c.c)(a.b.a + a.b.c)', {'a': JSInterpreter(str_0).interpret_expression('a', {'a': JSInterpreter(str_0).interpret_expression('a', {})})}))


# Generated at 2022-06-26 13:31:01.123253
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    obj_0 = str_0
    obj_0_out = {
        'a': lambda b, c: (b * c),
        'b': {
            'a': lambda b: (b * a.c),
            'c': lambda b: (b - a.c)
            },
        'c': {
            'a': lambda b: (b - a.c),
            'c': lambda b: (b - a.c)
            }
        }
    i = JSInterpreter(str_0)
    obj_0_out = i.extract_object('a')
    assert obj_0_out == obj_0_out


# Generated at 2022-06-26 13:31:09.567406
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:31:16.026318
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Check if the object contains all sub-objects as expected
    obj_0 = JSInterpreter(str_0).extract_object("a")
    assert obj_0["a"](3,4) == 12
    assert obj_0["b"]["a"](7) == 49
    assert obj_0["c"]["a"](7) == -1
    assert obj_0["b"]["c"](7) == -1
    assert obj_0["c"]["c"](7) == -1
    assert obj_0["c"] == -1


# Generated at 2022-06-26 13:31:20.221981
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:31:29.244824
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Local variables:
    str_literal_0 = 'x'
    i_0 = 0
    i_1 = 0
    # Method body

# Generated at 2022-06-26 13:31:34.231486
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsi = JSInterpreter(test_case_0())

    # Call method call_function of class JSInterpreter
    assert jsi.call_function('a', 2, 3) == 6

    # Call method call_function of class JSInterpreter
    assert jsi.call_function('a.b.a', 2) == 4

# Generated at 2022-06-26 13:31:43.773433
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = "\n    function a(b, c) {\n        return (b * c)\n    }\n    a.b = {\n        'a': function(b) {\n            return (b * a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = {\n        'a': function(b) {\n            return (b - a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = (a.c - a.c)\n    "
    js_interp = JSInterpreter(str_0)

# Generated at 2022-06-26 13:31:49.550436
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    i = JSInterpreter(str_0)
    obj = i.extract_object('a')

    assert repr(obj) == "{'b': {'a': <function>, 'c': <function>}, 'c': <function>}"



# Generated at 2022-06-26 13:32:39.104827
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    ji = JSInterpreter(str_0)
    func = ji.build_function(['b', 'c'], "return (b * c)")
    assert func((5, 7)) == 35, "invalid function result, expected 35"


# Generated at 2022-06-26 13:32:45.874153
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Call function
    str_1 = "1 + 1"
    obj_1 = JSInterpreter(str_1)
    res_1 = obj_1.call_function("", "")
    assert res_1 == 2, "Expected value is 2, but got %s" % res_1


# Generated at 2022-06-26 13:32:50.522073
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinterpreter = JSInterpreter(str_0)
    assert jsinterpreter.build_function(['b', 'c'], 'return (b + c)')([10, 2]) == 12
    assert jsinterpreter.call_function('a', 10, 2) == 20


# Generated at 2022-06-26 13:32:56.172621
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter(str_0)
    assert js._objects['a']['b']['a'](2) == js._objects['a']['b']['a'](2)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:33:04.285986
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = "\n    function a(b, c) {\n        return (b * c)\n    }\n    a.b = {\n        'a': function(b) {\n            return (b * a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = {\n        'a': function(b) {\n            return (b - a.c)\n        },\n        'c': function(b) {\n            return (b - a.c)\n        }\n    }\n    a.c = (a.c - a.c)\n    "
    int_0 = 0
    jsinterpreter_0 = JSInterpreter(str_0)