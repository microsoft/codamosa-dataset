

# Generated at 2022-06-26 13:24:24.890185
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    expr = 'var d=a.split(""),i="r.swf?video_id="+c[0];return g+d[0]+i+d[1]}'
    local_vars = {'a': 'r.swf?video_id=', 'c': [4, 5, 6]}
    j_s_interpreter_1 = JSInterpreter(expr)
    if (j_s_interpreter_1.interpret_expression(expr, local_vars) != 
        'r.swf?video_id=4,5,6}'):
        return (False, 'Failed interpret_expression of class JSInterpreter')
    return (True, 'Passed interpret_expression of class JSInterpreter')


# Generated at 2022-06-26 13:24:26.963566
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter(1)
    assert isinstance(j_s_interpreter_0, JSInterpreter)
    # No need to test a specific method of an object
    # We just want to check that the interpreter can be instantiated


# Generated at 2022-06-26 13:24:37.648858
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    quote_0 = 'abc'
    str_1 = quote_0 + 'def'
    assert str_1 == 'abcdef'
    str_2 = 'def' + quote_0
    assert str_2 == 'defabc'

    num_3 = 1
    num_4 = 2
    num_5 = 3
    num_6 = num_3 + num_4
    assert num_6 == 5
    num_7 = num_3 + num_5
    assert num_7 == 4
    num_8 = num_4 + num_5
    assert num_8 == 6

    num_9 = 4
    num_10 = 5
    num_11 = num_9 + num_10
    assert num_11 == 9
    num_12 = num_9 - num_10
    assert num_12 == -1
   

# Generated at 2022-06-26 13:24:42.613218
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    local_vars = {'a': 0, 'b': 2, 'c': 3, 'd': 4}
    code = 'a = b + c; d'
    j_s_interpreter_0 = JSInterpreter(code)
    result = j_s_interpreter_0.interpret_expression(code, local_vars)
    assert result == 4


# Generated at 2022-06-26 13:24:49.169817
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    list_0 = []
    j_s_interpreter_0 = JSInterpreter(list_0)

# Generated at 2022-06-26 13:24:56.333706
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:25:03.777300
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = JSInterpreter('')
    print(js.extract_function('decrypt'))
    print(js.call_function('decrypt', 'test'))
    print(js.call_function('decrypt', 'p,5,{=fot,iuuq;04<>').decode('rot13'))
#    print(js.call_function('decrypt', 'QUNDLUoCKAbALAcwAjAEMAbwB6AJcAbwBXAEIARAA='))

if __name__ == "__main__":
    test_case_0()
    test_JSInterpreter_extract_function()
#    js = JSInterpreter('')
#    print(js.call_function('decrypt', 'QUNDLUoCKAbALAcw

# Generated at 2022-06-26 13:25:05.209087
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    JSInterpreter.extract_function('./files/jsinterpreter.py')

# Generated at 2022-06-26 13:25:16.043896
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    list_0 = []
    j_s_interpreter_0 = JSInterpreter(list_0)
    float_0 = float()
    float_1 = float()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()
    dict_18 = dict()
    dict_

# Generated at 2022-06-26 13:25:20.449358
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter()
    function_name_list_0 = [None]
    # Uncomment the next lines to manually set the parameters values
    #j_s_interpreter_0.build_function(func_name_list_0)


# Generated at 2022-06-26 13:25:47.000458
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test case 1
    inputArgs_1 = 'var a = b.c;'
    assert str(JSInterpreter.interpret_statement(inputArgs_1)) == 'var a = b.c;'
    # Test case 2
    inputArgs_2 = 'a.c = d.c | d.e'
    assert str(JSInterpreter.interpret_statement(inputArgs_2)) == 'a.c = d.c | d.e'
    # Test case 3
    inputArgs_3 = 'a = (b | d.c) - d.e'
    assert str(JSInterpreter.interpret_statement(inputArgs_3)) == 'a = (b | d.c) - d.e'
    # Test case 4
    inputArgs_4 = 'return a;'

# Generated at 2022-06-26 13:25:49.883477
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('var a = 1;')
    js.build_function([], 'return a;')


# Generated at 2022-06-26 13:26:02.146858
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    with open(str_0, 'r') as a:
        data = a.read()
    inter = JSInterpreter(data)
    assert inter.interpret_expression('undefined', {}) is None
    assert inter.interpret_expression('NaN', {}) is None
    assert inter.interpret_expression('null', {}) is None
    assert inter.interpret_expression('true', {})
    assert inter.interpret_expression('false', {}) == 0
    assert inter.interpret_expression('1', {}) == 1
    assert inter.interpret_expression('1+1', {}) == 2
    assert inter.interpret_expression('2**3', {}) == 8
    assert inter.interpret_expression('4-1', {}) == 3
    assert inter.interpret_expression('4*3', {}) == 12
    assert inter.interpret_expression

# Generated at 2022-06-26 13:26:08.561945
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:26:12.393004
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = './files/jsinterpreter.py'
    str_1 = 'b'
    str_2 = 'a'

    # Call method interpret_expression of class JSInterpreter
    interpreter = JSInterpreter(str_0)
    interpreter.interpret_expression(str_1, str_2)


# Generated at 2022-06-26 13:26:20.587323
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    str_0 = './files/jsinterpreter.py'
    obj_0 = open(str_0, 'r')
    str_1 = obj_0.read()
    obj_0.close()
    obj_1 = JSInterpreter(str_1)
    assert obj_1.extract_function('jo') is not None
    assert obj_1.extract_function('jo')(['a','b','c']) == 'abc'

# Generated at 2022-06-26 13:26:27.466060
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = './files/jsinterpreter.py'
    with open(str_0) as file_0:
        jsinterpreter = JSInterpreter(file_0.read())
    hasattr(jsinterpreter, '_objects')
    hasattr(jsinterpreter, '_functions')
    jsinterpreter.extract_object('ter')
    jsinterpreter.extract_object('obj')
    jsinterpreter.extract_object('obj')




# Generated at 2022-06-26 13:26:29.165188
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    obj = {'a': 'b'}
    code = 'var a = {};a["a"]="b";'
    interpreter = JSInterpreter(code)
    assert interpreter.extract_object('a') == obj


# Generated at 2022-06-26 13:26:30.623535
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = './files/jsinterpreter.py'
    obj_0 = JSInterpreter(str_0)


# Generated at 2022-06-26 13:26:37.665591
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = './files/jsinterpreter.py'
    jsi = JSInterpreter(open(str_0).read())
    obj = jsi.extract_object('foo')
    assert obj['bar']('foobar') == 'foobar'
    assert obj['baz'](['foo', 'bar', 'baz'], 'baz') == 'foobarbaz'
    assert obj['foobar']('foo', 'bar', 'baz') == 'foobarbaz'


# Generated at 2022-06-26 13:27:08.067728
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        var obj = {
            "func": function(a, b, c){
                var d = a + b + c;
                return (d - 1);
            }
        };
        """
    obj = JSInterpreter(code)
    assert obj.call_function("obj.func", 2, 3, 4) == 8


# Generated at 2022-06-26 13:27:21.401665
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:27:25.554673
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    with open('./files/jsinterpreter.py', 'r') as f:
        code = f.read()
    JSInterpreter(code)

if __name__ == '__main__':
    test_case_0()
    test_JSInterpreter_build_function()
    print('Done!')

# Generated at 2022-06-26 13:27:33.700237
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'z = x + y;'
    str_1 = 'x+y'
    dict_0 = dict()
    dict_0['x'] = 2
    dict_0['y'] = 3
    dict_1 = dict()
    dict_1['x'] = 'abc'
    dict_1['y'] = 'def'
    jsinterpreter_0 = JSInterpreter(str_0)
    jsinterpreter_0.build_function(None, str_1)
    jsinterpreter_0.interpret_statement(str_0, dict_0)
    jsinterpreter_0.interpret_statement(str_0, dict_1)


# Generated at 2022-06-26 13:27:36.529162
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter(str_0)
    stmt = str_1
    local_vars = dict()
    allow_recursion = int()
    interpreter.interpret_statement(stmt, local_vars, allow_recursion)


# Generated at 2022-06-26 13:27:40.396366
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code_0 = '''
        function abc(a,b,c){
            var d=c,e=b;return a.split("").reverse().join("")}
        '''

    inst = JSInterpreter(code_0)
    return_value = inst.call_function('abc', 'rpm', 0, False)
    assert return_value == 'prm'

# Generated at 2022-06-26 13:27:42.813543
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = 'function f(a, b) {return a + b;}'
    jsinterpreter = JSInterpreter(code)
    jsinterpreter.extract_function('f')


# Generated at 2022-06-26 13:27:44.352981
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter(str_0)
    interpreter.interpret_statement(str_0)



# Generated at 2022-06-26 13:27:54.197842
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:27:57.081908
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    y = "fname = 'foo';"

    f = 'function ' + y + str_0 + '(){}'
    j = JSInterpreter(f)
    j._objects['_js_pop'] = test_case_0()
    print(j.build_function(fname, y))



# Generated at 2022-06-26 13:28:30.470719
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    with open('./files/jsinterpreter.py') as f:
        code = f.read()

    interpreter = JSInterpreter(code)
    var_0 = interpreter.extract_object('_A')

    assert var_0['slice']() == ''
    assert var_0['slice'](1) == 'a'
    assert var_0['slice'](3) == 'abc'
    assert var_0['slice'](-3) == 'c'
    assert var_0['slice'](1, 3) == 'ab'
    assert var_0['slice'](-3, -1) == 'c'
    assert var_0['slice'](1, 10) == 'abcdefghi'
    assert var_0['slice'](1, 1) == ''

# Generated at 2022-06-26 13:28:33.590665
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('', {})
    result = js.build_function(['a', 'b'], 'c = a*b; d = c*c; return d;')
    result = result((3.0, 4.0))
    assert result == 144.0


# Generated at 2022-06-26 13:28:37.663575
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test that the interpreter can interpret a simple expression
    simple_statement = '4+4'
    result = JSInterpreter.interpret_expression(simple_statement)
    # Assert that the result was as expected
    assert result == 8, "Test 0: Result of simple statement was not as expected"


# Generated at 2022-06-26 13:28:48.133344
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = r'''
        var s="abcdef";
        var a=s.split("")
        var b=a.slice(3)
        var c=a.reverse()
        b.splice(1,1)
        '''
    jsinter = JSInterpreter(code)
    assert jsinter.interpret_expression('1+2*3', {}) == 7
    assert jsinter.interpret_expression('1+2*3', {'a': 2}) == 7
    assert jsinter.interpret_expression('a+2*3', {'a': 2}) == 8
    assert jsinter.interpret_expression('a+2', {'a': []}) == 2
    assert jsinter.interpret_expression('a+2', {'a': True}) == 3

# Generated at 2022-06-26 13:28:59.333695
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = './files/jsinterpreter.py'
    str_1 = './files/jsinterpreter_test.py'
    str_2 = './files/pytube_test.py'

    with open(str_0, 'r') as _f:
        str_3 = _f.read()
    str_4 = './files/jsinterpreter_test.py'
    str_5 = './files/jsinterpreter_test.py'
    str_6 = './files/pytube_test.py'

    with open(str_5, 'r') as _f:
        str_7 = _f.read()
    str_8 = './files/pytube_test.py'
    str_9 = './files/pytube_test.py'


# Generated at 2022-06-26 13:29:11.353445
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = '''
        var a = b[c]
        '''
    #
    # Unique line number code
    #
    str_1 = '''
        var d = e(f)
        '''
    #
    # Unique line number code
    #
    str_2 = '''
        var g = h.i[j]
        '''
    #
    # Unique line number code
    #
    str_3 = '''
        var k = l
        '''
    #
    # Unique line number code
    #
    start = 0
    len_0 = 0
    len_1 = 0
    len_2 = 0
    len_3 = 0
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_

# Generated at 2022-06-26 13:29:16.131132
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''function x(a, b, c){
                return (a + b) * c;
            }'''
    parser = JSInterpreter(code)
    resf = parser.build_function(['a', 'b', 'c'], 'return (a + b) * c;')

# Generated at 2022-06-26 13:29:21.435878
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    from .jsinterpreter import JSInterpreter
    from .shell_streaming import ShellStream
    shell_stream = ShellStream("./files/jsinterpreter.py")
    js_interpreter = JSInterpreter(shell_stream.read())
    test_case_0()
    assert 'None' == str(js_interpreter.build_function([], ""))
    assert 'None' == str(js_interpreter.build_function([], "return"))


# Generated at 2022-06-26 13:29:27.296608
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter('function test(a,b){return a + b;};')
    f = jsi.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3

    jsi = JSInterpreter('function test(a,b){return a + b;};')
    f = jsi.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3


# Generated at 2022-06-26 13:29:32.112078
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print('test JSInterpreter.interpret_expression()')
    func = JSInterpreter(test_case_0()).call_function
    assert func('function(a){return a.split("")}', 'test') == ['t', 'e', 's', 't']
    assert func('function(a){return a.split("").reverse()}', 'test') == ['t', 's', 'e', 't']


# Generated at 2022-06-26 13:29:58.494106
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    if not hasattr(JSInterpreter, "build_function"):
        fail(str_0)

    # Simple function definition
    str_1 = 'function foo(a){ return a*2; }'
    str_0 = 'foo(4)'
    int_0 = 8
    obj_0 = JSInterpreter(str_1)
    assert obj_0._functions[str_0]() == int_0

    # Function with two arguments
    str_1 = 'function bar(a, b){ return a - b; }'
    str_0 = 'bar'
    str_2 = 'test'
    int_0 = 4
    int_1 = 2
    int_2 = 2
    obj_0 = JSInterpreter(str_1)

# Generated at 2022-06-26 13:30:04.318286
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterpreter = JSInterpreter()
    local_vars = {
        'a': 77,
        'b': 2,
        'c': [3, 4, 2],
        'd': {
            'e': 10
        }
    }
    jsinterpreter.interpret_expression('a + b', local_vars)
    jsinterpreter.interpret_expression('a + b', local_vars)
    jsinterpreter.interpret_expression('a + b', local_vars)


# Generated at 2022-06-26 13:30:11.908353
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test case 0
    line_arr_0 = ''.splitlines()
    str_0 = ''.join(line_arr_0)
    str_1 = './files/jsinterpreter.py'
    fobj_0 = open(str_1, 'rt')
    str_arr_0 = fobj_0.readlines()
    fobj_0.close()
    jsvar_0 = JSInterpreter(str_arr_0)

# Generated at 2022-06-26 13:30:18.733865
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    print('Testing method build_function')
    funcname = 'build_function'
    code = 'var e = 3;'
    argnames = 'e'
    jsInterpreter = JSInterpreter()
    res = jsInterpreter.build_function(argnames, code)
    res(33)
    if type(res) != 'function':
        print('test_JSInterpreter_build_function() failed:')
        print('\tExpected: <type \'function\'>')
        print('\tbut got: %s' % type(res))
    print('test_JSInterpreter_build_function() passed.')


# Generated at 2022-06-26 13:30:23.940279
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('function test(a,b){return a+b;}')
    assert callable(js_interpreter.build_function(['a', 'b'], 'return a+b;'))
    assert 3 == js_interpreter.build_function(['a', 'b'], 'return a+b;')((1, 2))



# Generated at 2022-06-26 13:30:28.090595
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    with open(test_case_0(), 'r') as f:
        js_code = f.read()
    interpreter = JSInterpreter(js_code)
    f = interpreter.build_function(['x', 'y'], 'x+y')
    assert f((10, 20)) == 30


# Generated at 2022-06-26 13:30:33.673370
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''function f(a,b,c) {
    var d = 'test';
    return d + a + b + c;
}'''
    args = [1,2,3]
    obj = JSInterpreter(code)
    func = obj.build_function(['a','b','c'], code)
    expected_output = 'test123'
    assert(func(args) == expected_output)
    return True


# Generated at 2022-06-26 13:30:36.918427
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print("interpret_expression")
    str_0 = './files/jsinterpreter.py'
    jsint_0 = JSInterpreter(str_0)
    jsint_0.interpret_expression(str_0)


# Generated at 2022-06-26 13:30:43.572648
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    int_0 = -1
    str_0 = './files/jsinterpreter.py'
    str_1 = './files/jsinterpreter.py'
    int_1 = -1
    jsinterpreter_0 = JSInterpreter(str_1)
    func_0 = jsinterpreter_0.build_function([], str_0)
    func_1 = lambda x: int_1 * (x / x) if not x else int_0
    assert func_0 == func_1


# Generated at 2022-06-26 13:30:52.910845
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print('Test interpret_expression() ...', end='')
    assert JSInterpreter('1').interpret_expression('1') == 1
    assert JSInterpreter('1').interpret_expression('2') == 2
    assert JSInterpreter('1').interpret_expression('1;') == 1
    assert JSInterpreter('1').interpret_expression('2;') == 2

    assert JSInterpreter('1').interpret_expression('1 + 2') == 3
    assert JSInterpreter('1').interpret_expression('3 - 2') == 1
    assert JSInterpreter('1').interpret_expression('2 / 2') == 1
    assert JSInterpreter('1').interpret_expression('1 * 2') == 2
    assert JSInterpreter('1').interpret_expression('1 | 2') == 3
    assert JSInterpreter('1').interpret

# Generated at 2022-06-26 13:31:34.229663
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = "var a=function(c){this.b=c};new a(15);"
    obj = JSInterpreter(code, {'a': {'prototype': {'b': 0}}})
    res = obj._objects
    assert 'a' in res
    assert res['a']['prototype']['b'] == 15
    return res['a']['prototype']['b']


# Generated at 2022-06-26 13:31:43.773457
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('')
    assert interpreter.interpret_expression('2', {}) == 2
    assert interpreter.interpret_expression('2.5', {}) == 2.5
    assert interpreter.interpret_expression('"a"', {}) == 'a'
    assert interpreter.interpret_expression('true', {}) == True
    assert interpreter.interpret_expression('false', {}) == False
    assert interpreter.interpret_expression('null', {}) == None
    assert interpreter.interpret_expression('2.5+3.5', {}) == 2.5 + 3.5
    assert interpreter.interpret_expression('2.5-3.5', {}) == 2.5 - 3.5
    assert interpreter.interpret_expression('2.5*3.5', {}) == 2.5 * 3.5

# Generated at 2022-06-26 13:31:54.994703
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter("""
    var gtable = {
        c: function(a, b) {
            for (var c = 0; c < b.length - 2; c += 3) {
                var d = b.charAt(c + 2);
                d = "a" <= d ? d.charCodeAt(0) - 87 : Number(d);
                d = "+" == b.charAt(c + 1) ? a >>> d : a << d;
                a = "+" == b.charAt(c) ? a + d & 4294967295 : a ^ d;
            }
            return a;
        }
    }
    """)
    assert js._objects["gtable"]["c"](100, "+-a") == 96

# Generated at 2022-06-26 13:31:57.671366
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    assert None == JSInterpreter.call_function()


# Generated at 2022-06-26 13:32:06.036505
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = './files/jsinterpreter.py'
    str_1 = './files/jsinterpreter.py'
    str_2 = './files/jsinterpreter.py'
    str_3 = './files/jsinterpreter.py'
    str_4 = './files/jsinterpreter.py'
    str_5 = './files/jsinterpreter.py'
    str_6 = './files/jsinterpreter.py'
    str_7 = './files/jsinterpreter.py'


# Generated at 2022-06-26 13:32:14.821010
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = r'''
f1 = function(a,b) {
  return a+b;
};
f2 = function() { return 42; };
'''
    jsi = JSInterpreter(code)
    f1 = jsi.extract_function('f1')
    assert f1([2, 3]) == 5
    f2 = jsi.extract_function('f2')
    assert f2([]) == 42



# Generated at 2022-06-26 13:32:20.607666
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
function foo() {
    bar(Math.random());
}'''
    jsi = JSInterpreter(code)
    n_args = len(''.join(re.findall(r'\(.*\)', code)).strip('()').split(', '))
    f = jsi.build_function([], code)
    assert f() is None
    f = jsi.build_function(list(range(n_args)), code)
    assert f() is None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:32:31.873155
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter(str_0)
    # Testing the case when funcname is 'test_case_0'

# Generated at 2022-06-26 13:32:33.271810
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Not yet implemented.
    pass


# Generated at 2022-06-26 13:32:42.852842
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    func = 'function(a,b){while(!a[b]){b++}return b}'
    v = JSInterpreter(func)
    assert v.call_function('asdf', 'abcrd', 'cb') == 1
    assert v.call_function('asdf', 'abcrd', 'dd') == 1
    assert v.call_function('asdf', 'abcrd', 'cb') == 1
    assert v.call_function('asdf', 'abcrd', 'c') == 1
    assert v.call_function('asdf', 'abcrd', 'h') == 1
    assert v.call_function('asdf', 'a[b]', '2') == 2
    assert v.call_function('asdf', 'a[b]', '3') == 3