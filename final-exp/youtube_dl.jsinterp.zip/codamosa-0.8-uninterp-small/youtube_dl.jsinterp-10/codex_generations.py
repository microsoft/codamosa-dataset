

# Generated at 2022-06-26 13:24:05.643615
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    obj = j_s_interpreter_0.extract_object('a')
    assert len(obj) == 4
    assert obj['substring']((0,)) == '39'
    assert obj['substring']((4,)) == ''
    assert obj['substring']((100,)) == ''


# Generated at 2022-06-26 13:24:12.127952
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    stmt_0 = 'function x(a,b) {a=a^b; b=a^b; a=a^b; return a}'
    interp_0 = JSInterpreter(stmt_0, stmt_0)
    f_0 = interp_0.build_function(['a', 'b'], 'a=a^b; b=a^b; a=a^b; return a')
    assert f_0(1, 2) == 3

if __name__ == '__main__':
    test_case_0()
    test_JSInterpreter_build_function()

# Generated at 2022-06-26 13:24:25.716268
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'voDzTm394!7`kz'
    str_1 = 'voDzTm394!7`kz'
    j_s_interpreter_0 = JSInterpreter(str_0, str_1)

    str_0 = '9^rW5p8Pvn5P,n5P'
    str_1 = '!cZ\\x06_XC_\\x1f'
    str_2 = '!cZ\\x06_XC_\\x1f'
    j_s_interpreter_1 = JSInterpreter(str_0, str_1, str_2)

    str_0 = '9^rW5p8Pvn5P,n5P'

# Generated at 2022-06-26 13:24:34.858050
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_object_code = '''\
    x = {
        func1: function(arg1) {
            return arg1 * this.prop1;
        },
        prop1: 2
    }
    '''
    jsi = JSInterpreter(test_object_code)
    obj = jsi.extract_object('x')
    x1 = obj['func1'](3)
    x2 = obj['func1']('x')
    x3 = obj['prop1']
    x4 = obj['prop1'] = 3
    assert x1 == 6
    assert x2 == 'xx'
    assert x3 == 2
    assert x4 == 3



# Generated at 2022-06-26 13:24:44.047828
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'voDzTm394!7`kz'
    str_1 = str_0
    j_s_interpreter_0 = JSInterpreter(str_0, str_1)
    str_2 = 'voDzTm394!7`kz'
    str_3 = str_2
    str_4 = str_3
    str_5 = str_4
    str_6 = str_5
    str_7 = str_6
    str_8 = str_7
    str_9 = str_8
    str_10 = str_9
    str_11 = str_10
    str_12 = str_11
    str_13 = str_12
    str_14 = str_13
    str_15 = str_14
    str_16 = str_15
   

# Generated at 2022-06-26 13:24:51.664628
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('var a = 3; var b;')
    assert interpreter.interpret_expression('a', {'a': 3}) == 3
    assert interpreter.interpret_expression('a+b', {'a': 3, 'b': 2}) == 5
    assert interpreter.interpret_expression('pow(a,b)', {'a': 3, 'b': 2}) == 9
    assert interpreter.interpret_expression('a=1;b=2;a+b', {}) == 3

    interpreter = JSInterpreter(
        'var a = [3, [4, 5]]; var b;',
        {'pow': lambda x, y: x ** y, 'alert': lambda x: None})
    assert interpreter.interpret_expression('a[0]', {'a': [3, [4, 5]]}) == 3


# Generated at 2022-06-26 13:24:58.502064
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:25:05.324466
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_code = '''var a = 1,
    b = 2,
    c = 3,
    d = 4,
    e = 5,
    f = 6,
    g = 7,
    h = 8,
    i = 9,
    j = 10,
    k = 11,
    l = 12,
    m = 13,
    n = 14,
    o = 15,
    p = 16,
    q = 17,
    r = 18,
    s = 19;'''

    # Init JSInterpreter and JSInterpreter_0
    JSInterpreter = JSInterpreter(test_code)
    JSInterpreter_0 = JSInterpreter(test_code)

    # Invoke method interpret_expression of JSInterpreter

# Generated at 2022-06-26 13:25:16.164123
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
            function test() {
                var a = [1, 2, 3, 4, 5];
                a.pop();
                a.join('-');
            }
            """
    js_interpreter = JSInterpreter(code, {})
    assert js_interpreter.interpret_expression('a', {'a': [1, 2, 3, 4, 5]}) == [1, 2, 3, 4, 5]
    assert js_interpreter.interpret_expression('a[0]', {'a': [1, 2, 3, 4, 5]}) == 1


# Generated at 2022-06-26 13:25:22.850054
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = 'voDzTm394!7`kz'
    str_1 = 'ot3z@a7Xu'
    str_2 = 'w_pR67'
    str_3 = 'FBVvPC'

    j_s_interpreter_0 = JSInterpreter(str_0, str_0)
    j_s_interpreter_0.call_function(str_1, str_2, str_3)


# Generated at 2022-06-26 13:26:46.707198
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:26:53.228478
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_7 = 'I\'m_sad_that_you\'re_quitting_the_site'
    j_s_interpreter_7 = JSInterpreter(str_7)
    str_4 = 'voDzTm394!7`kz'
    j_s_interpreter_4 = JSInterpreter(str_4, str_4)
    j_s_interpreter_4.call_function(str_7)


# Generated at 2022-06-26 13:27:04.828648
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-26 13:27:11.559792
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''   
    <div class="video-embed">
    <iframe id="embed-video" width="480" height="270" 
    src="https://www.youtube.com/embed/BKorP55Aqvg?autoplay=1" frameborder="0" allowfullscreen></iframe>
    </div>
    ''' 
    j_s_interpreter_0 = JSInterpreter(code)
    argnames = []

# Generated at 2022-06-26 13:27:15.958225
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'voDzTm394!7`kz'
    j_s_interpreter_0 = JSInterpreter(str_0, str_0)
    j_s_interpreter_0.extract_object(str_0)


# Generated at 2022-06-26 13:27:26.647346
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    j_s_interpreter_0 = JSInterpreter('var a, b; a + b;')
    code = j_s_interpreter_0.interpret_statement('var a, b; a + b;')
    assert code == ('', False)
    j_s_interpreter_1 = JSInterpreter('return a;')
    code = j_s_interpreter_1.interpret_statement('return a;')
    assert code == ('a', True)
    j_s_interpreter_2 = JSInterpreter('a + b;')
    code = j_s_interpreter_2.interpret_statement('a + b;')
    assert code == (None, False)
    j_s_interpreter_3 = JSInterpreter('return a + b;')
    code = j

# Generated at 2022-06-26 13:27:28.339041
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'voDzTm394!7`kz'
    j_s_interpreter_0 = JSInterpreter(str_0, str_0)
    j_s_interpreter_0.extract_object("35=D")


# Generated at 2022-06-26 13:27:36.264293
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    str_0 = 'n/HPLS2?XCVd_7LVLKT0B'

# Generated at 2022-06-26 13:27:44.195520
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    s = 'function aaa(arg1, arg2) {var obj = {"a": function(a,b) {return a+b}}; return obj["a"]}'

# Generated at 2022-06-26 13:27:54.012860
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    assert str_0 == JSInterpreter.extract_object(j_s_interpreter_0, str_0, str_0)
    assert str_1 == JSInterpreter.extract_object(j_s_interpreter_0, str_0, str_1)
    assert str_2 == JSInterpreter.extract_object(j_s_interpreter_0, str_0, str_2)
    assert str_3 == JSInterpreter.extract_object(j_s_interpreter_0, str_0, str_3)
    assert str_4 == JSInterpreter.extract_object(j_s_interpreter_0, str_0, str_4)

# Generated at 2022-06-26 13:28:47.642136
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    storage = {}
    func = JSInterpreter('').build_function(['args'], 'a = args[0];')
    assert func(['b']) == 'b'


# Generated at 2022-06-26 13:28:58.939688
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    import string
    import random

# Generated at 2022-06-26 13:29:11.127195
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    int_1 = 0
    str_0 = 'var '
    int_0 = -16
    str_1 = 'lop'

# Generated at 2022-06-26 13:29:20.243014
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'n/HPLS2?XCVd_7LVLKT0B'
    str_1 = ''
    str_2 = 'this.videoId = null;'
    str_3 = 'this.Xh = function(b) {if (b.videoData && b.videoData.video_id) {this.videoId = b.videoData.video_id;this.Bj = b.videoData.video_id;this.init();return !0} return !1};'
    str_4 = ''
    
    obj = JSInterpreter(str_2 + str_0 + str_3 + str_1 + str_4)
    result = obj.extract_object(str_0)
    assert('Xh' in result)
    assert(len(result.keys()) == 1)
#

# Generated at 2022-06-26 13:29:28.748273
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter(r'''
        var x = "abcd"
        var y = "1234"
        var z = {"a": "first", "b": "second"}
    ''')
    snippet = jsi.interpret_expression('x+y', locals())
    assert snippet == "abcd1234"
    snippet = jsi.interpret_expression('z["a"]+z["b"]', locals())
    assert snippet == "firstsecond"
    snippet = jsi.interpret_expression('x.length+y.length', locals())
    assert snippet == 8
    snippet = jsi.interpret_expression('x.slice("9")', locals())
    assert snippet == "abcd"
    snippet = jsi.interpret_expression('x.split("")', locals())

# Generated at 2022-06-26 13:29:29.726219
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_case_0()


# Generated at 2022-06-26 13:29:39.768814
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:29:47.792843
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'n/HPLS2?XCVd_7LVLKT0B'
    assert JSInterpreter.extract_object(str_0) == '2d9b23a9c2a1f79f09b13f077d02f44c'
    str_0 = 'n/HPLS2?XCVd_7LVLKT0B'
    assert JSInterpreter.extract_object(str_0) == '2d9b23a9c2a1f79f09b13f077d02f44c'
    str_0 = 'n/HPLS2?XCVd_7LVLKT0B'

# Generated at 2022-06-26 13:29:58.054521
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'n/HPLS2?XCVd_7LVLKT0B'
    str_1 = 'bP55g(a)'
    str_2 = 'ee'
    str_3 = 'function'
    str_4 = ')'
    str_5 = '('
    str_6 = '+'
    str_7 = 'g'
    str_8 = 'd'
    str_9 = 'f'
    str_10 = 'c'
    str_11 = 'e'
    str_12 = 'F'
    str_13 = 'JJJ'
    str_14 = 'a'
    str_15 = '1'
    str_16 = '0'
    str_17 = 'z'
    str_18 = 'y'

# Generated at 2022-06-26 13:30:03.100260
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:30:46.495944
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'voDzTm394!7`kz'
    j_s_interpreter_0 = JSInterpreter(str_0, str_0)
    args_0 = ['s',]
    code_0 = 'return s'
    function_0 = j_s_interpreter_0.build_function(args_0, code_0)
    str_1 = 'voDzTm394!7`kz'
    v_0 = j_s_interpreter_0.extract_function('s',)
    args_1 = ['s',]
    v_1 = function_0(args_1)
    args_2 = ['s',]
    v_2 = function_0(args_2)

# Generated at 2022-06-26 13:30:48.618962
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    x = JSInterpreter({})
    x.extract_object('foo')

# Generated at 2022-06-26 13:30:56.279668
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # test default values for arguments
    j_s_interpreter_2 = JSInterpreter('', '')
    str_2 = 'var i=0; return i'
    dict_2 = {}
    assert j_s_interpreter_2.interpret_statement(str_2, dict_2, 0)[0] == 0

    j_s_interpreter_3 = JSInterpreter('', '')
    str_3 = 'return i'
    dict_3 = {'i': 7}
    assert j_s_interpreter_3.interpret_statement(str_3, dict_3, 0)[0] == 7

    j_s_interpreter_4 = JSInterpreter('', '')
    str_4 = 'i=0'
    dict_4 = {'i': 7}

# Generated at 2022-06-26 13:31:01.596560
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    print('test_JSInterpreter_extract_object')
    str_0 = 'var abcde = {defg:function(a,b){return a+b;},hijkl:function(c,d){return c*d;}}'
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert 'defg' in j_s_interpreter_0._objects['abcde']
    assert 'hijkl' in j_s_interpreter_0._objects['abcde']


# Generated at 2022-06-26 13:31:06.910270
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = '{get:function(a){return this[a]},reverse:function(){return this.reverse()},slice:function(a){return this.slice(a)}};'
    j_s_interpreter_0 = JSInterpreter(str_0, str_0)
    objs = j_s_interpreter_0.extract_object('a')
    print(objs)


# Generated at 2022-06-26 13:31:14.570413
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-26 13:31:25.014973
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:31:31.911334
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'k(0,0,0,0,0,0,0,0)'
    str_1 = 'arr[a+b]'
    str_2 = '2*(10+2)'
    str_3 = 'k(1,2)'
    str_4 = 'a+b*c'
    str_5 = 'a+(b*c)'
    str_6 = '{var key = "key_123"; return key}'
    str_7 = 'k(1,1,1)'
    str_8 = 'a=b'
    str_9 = 'a=b[1]'
    str_10 = 'k(a,c)'
    str_11 = 'a+b*c/d'
    str_12 = 'k[a+b]'

# Generated at 2022-06-26 13:31:35.936856
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'voDzTm394!7`kz'
    j_s_interpreter_0 = JSInterpreter(str_0, str_0)
    j_s_interpreter_0.build_function(str_0, str_0)


# Generated at 2022-06-26 13:31:45.202646
# Unit test for method extract_function of class JSInterpreter