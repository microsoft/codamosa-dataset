

# Generated at 2022-06-26 13:23:52.240697
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter('var W;')
    j_s_interpreter_0.build_function(['W', j_s_interpreter_0], 'return;', ['W', j_s_interpreter_0])


# Generated at 2022-06-26 13:24:02.596299
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'function vC(){return a(D(6))}function qE(a,b,c){c=c||ub;var d=a+"="+b;if(c&1){var e=c&2,f=(c&4)?'
    str_1 = '"secure"';
    str_2 = ':null';
    str_3 = ';document.cookie=d+(f?'

# Generated at 2022-06-26 13:24:11.588807
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)

    # Test for the default input
    assert j_s_interpreter_0.interpret_expression(
        'A', {'B': 1}, 100) == 'C\t\\fGqi>0^BsFF\\'

    # Test for edge cases

    # Positive infinity
    j_s_interpreter_0 = JSInterpreter('infinity')
    assert j_s_interpreter_0.interpret_expression('infinity', {}, 100) == float('inf')

    # Negative infinity
    j_s_interpreter_0 = JSInterpreter('-infinity')
    assert j_s_interpreter_0.interpret_

# Generated at 2022-06-26 13:24:24.886710
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
    com.comscore.analytics.comScore = function(var1, var2) {
        this.version = "3.3.0"
        this.pixelURL = "http://b.scorecardresearch.com/p?c1=2&c2="
        this.version = var1
        this.pixelURL = var2
    }
    '''
    j_s_interpreter_0 = JSInterpreter(code)
    argnames_0 = ['var1', 'var2']
    code_0 = 'this.version=var1\nthis.pixelURL=var2'
    assert j_s_interpreter_0.build_function(argnames_0, code_0)(['a', 'b']) == None


# Generated at 2022-06-26 13:24:35.586685
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():

    o = {'a':1,'b':2,'c':3}
    code = 'x=a+b*c;return x;'
    func = JSInterpreter(o).build_function(['a','b','c'],code)
    assert func(2,3,4) == 14
    # test with the arguments in a list
    assert func([2,3,4]) == 14
    # raise exception if we pass an array with too many arguments
    # since the function does not expect that
    try:
        assert func([2,3,4,5])
    except ExtractorError as e:
        pass
    # raise exception if we pass an array with too few arguments
    # since the function does not expect that
    try:
        assert func([2,3])
    except ExtractorError as e:
        pass

   

# Generated at 2022-06-26 13:24:40.219542
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    global str_0
    global __expected
    global objects
    global j_s_interpreter_0

    #Call the method
    res = j_s_interpreter_0.interpret_expression(str_0, objects)

    #Check the result
    assert res == __expected

    #Check the function was called


# Generated at 2022-06-26 13:24:43.652431
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'function sM(a){return a.reverse()}'
    argnames_0 = ['a']
    code_0 = 'return a.reverse()'
    res_0 = JSInterpreter.build_function(str_0, argnames_0, code_0)

# Generated at 2022-06-26 13:24:46.869916
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)


# Generated at 2022-06-26 13:24:53.880517
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-26 13:25:01.569324
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    funcname = 'function_name'
    code = 'function_code'
    func_m = re.search(
        r'''(?x)
            (?:function\s+%s|[{;,]\s*%s\s*=\s*function|var\s+%s\s*=\s*function)\s*
            \((?P<args>[^)]*)\)\s*
            \{(?P<code>[^}]+)\}''' % (
        re.escape(funcname), re.escape(funcname), re.escape(funcname)),
        code
    )
    if func_m is None:
        raise ExtractorError('Could not find JS function %r' % funcname)
    argnames = func_m.group('args').split(',')

    # Testing with good

# Generated at 2022-06-26 13:25:25.327504
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Initialization
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    # Invocation of method interpret_statement of class JSInterpreter
    local_vars = {str_0:str_0}
    j_s_interpreter_0.interpret_statement(str_0,local_vars)


# Generated at 2022-06-26 13:25:32.170001
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:25:37.700364
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Build a function that returns the sum of its arguments
    args = ['a', 'b']
    code = 'return a + b'
    j_s_interpreter_0 = JSInterpreter('')
    func_0 = j_s_interpreter_0.build_function(args, code)
    # Test calling the function
    func_0((1, 2))


# Generated at 2022-06-26 13:25:47.433243
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'LpfZ$.join(""),Oa=+((!+[]+!![]+!![]+!![]+[])+(!+[]+!![]+!![]));'
    str_1 = 'function qu(a){a=a.split("");'
    str_2 = 'R=R.concat(W(a,t));'
    str_3 = 'return a.join("")};'
    str_4 = 'var K="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";'

# Generated at 2022-06-26 13:25:58.586665
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    arg_0 = ['A', 'B']
    arg_1 = 'G<2H;D=0;C=D;while(G>0){if(E[C]==B){C=C+1;D=D+1}G=G-1}G=D;E=C'
    res_0 = j_s_interpreter_0.build_function(arg_0, arg_1)

# Generated at 2022-06-26 13:26:04.149211
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Test cases
    j_s_interpreter = JSInterpreter('foo={bar: function(){}}')
    j_s_interpreter_0 = j_s_interpreter
    j_s_interpreter_0.extract_object('foo')
    j_s_interpreter_1 = j_s_interpreter
    j_s_interpreter_1.extract_object('foo')
    j_s_interpreter_2 = j_s_interpreter
    j_s_interpreter_2.extract_object('foo')
    j_s_interpreter_3 = j_s_interpreter
    j_s_interpreter_3.extract_object('foo')
    j_s_interpreter_4 = j_s_interpreter


# Generated at 2022-06-26 13:26:07.631509
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    expr_0 = 'a';
    var_0 = dict();
    var_0[expr_0] = 10;
    j_s_interpreter_0 = JSInterpreter(expr_0);
    var_1 = j_s_interpreter_0.interpret_expression(expr_0, var_0);
    assert_equals(var_1, 10);



# Generated at 2022-06-26 13:26:11.087509
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'C>A'
    j_s_interpreter_0.call_function('G', str_1)


# Generated at 2022-06-26 13:26:15.890509
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'iCHf6/0/0'
    j_s_interpreter_0.extract_object(str_1)


# Generated at 2022-06-26 13:26:28.189967
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    j_s_interpreter_0.interpret_expression('F', {'F': 10})
    j_s_interpreter_0.interpret_expression('4', {'F': 10})
    j_s_interpreter_0.interpret_expression('F+1', {'F': 10})
    j_s_interpreter_0.interpret_expression('F+1', {'F': 10}).is_int()
    j_s_interpreter_0.interpret_expression('F+1', {'F': 10}).get_int()

# Generated at 2022-06-26 13:26:52.236105
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    # Test 1: Checking if an expression str is evaluated correctly
    # when it does not include any operation
    str_1 = '"a"+"b"'
    p_expected_res_1 = 'ab'
    p_res_1 = j_s_interpreter_0.interpret_expression(str_1, {})
    assert p_res_1 == p_expected_res_1, 'Wrong evaluation result'

    # Test 2: Checking if an expression is evaluated correctly
    # when it includes just basic arithmetic operations
    str_2 = '1+2'
    p_expected_res_2 = 3
    p_res_2 = j

# Generated at 2022-06-26 13:27:03.162770
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:27:06.675513
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def test_case_0():
        str_0 = 'C=s.replace(d,0x26);\t'
        j_s_interpreter_0 = JSInterpreter(str_0)


# Generated at 2022-06-26 13:27:13.225847
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    j_s_interpreter_0 = JSInterpreter('A=C\t\\fGqi>0^BsFF\\')
    j_s_interpreter_0.interpret_statement('var a = 0', {})
    j_s_interpreter_0.interpret_statement('var b = 1', {'a': 0})
    j_s_interpreter_0.interpret_statement('a=a+1', {'a': 1})
    j_s_interpreter_0.interpret_statement('a=a+1', {'b': 1, 'a': 1})
    j_s_interpreter_0.interpret_statement('a=b&3', {'b': 1, 'a': 1})

# Generated at 2022-06-26 13:27:17.894336
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test case 1
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    res = j_s_interpreter_0.build_function(["x", "y", "z"], "if(y){return x;};if(z){return x;};if(1){return x;};")
    # Expected :
    # 1. [FAILURE] JSInterpreter:1: Expected 'if' statement to execute
    # 2. [FAILURE] JSInterpreter:2: Expected 'if' statement to execute


# Generated at 2022-06-26 13:27:19.560094
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    pass



# Generated at 2022-06-26 13:27:29.533815
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():

    # Case 1
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    func_0 = j_s_interpreter_0.extract_function('QJFU')
    list_0 = [ 7, 15 ]
    try:
        func_0(list_0)
    except ExtractorError as e:
        pass

    # Case 2
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    func_0 = j_s_interpreter_0.extract_function('QJFU')
    list_0 = [ 1, 4 ]

# Generated at 2022-06-26 13:27:34.431422
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter_0 = JSInterpreter('$=0;')
    js_interpreter_0.objects['a'] = {'$': '0'}
    js_interpreter_0.call_function('$', 'a')
    js_interpreter_0.objects['a'] = {'$': '0'}
    js_interpreter_0.call_function('$', 'a')



# Generated at 2022-06-26 13:27:42.410396
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)

# Generated at 2022-06-26 13:27:51.649648
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    print("extract_object")
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = '''
             var a = {
                 "a": function(){
                     return "ab";
                 },
                 "b": function(){
                     return "bc";
                 },
                 "c": function(){
                     return "cd";
                 }
             }
             '''
    obj_0 = j_s_interpreter_0.extract_object('a')
    obj_1 = {'a': lambda: 'ab', 'b': lambda: 'bc', 'c': lambda: 'cd'}
    assert obj_0 == obj_1, 'Line 20'

# Generated at 2022-06-26 13:28:23.294949
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:28:30.470089
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    my_str = 'var b=a.split(\'\');a=b.reverse();b=a.join(\'\');$("#c").html(b);'
    my_obj = {'split': str.split, 'reverse': list.reverse, 'join': str.join}
    my_interpreter = JSInterpreter(my_str, {'a': 'test_string'})

    my_obj_extracted = my_interpreter.extract_object('b')
    if my_obj_extracted != my_obj:
        return -1
    return 0


# Generated at 2022-06-26 13:28:39.362451
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_0 = JSInterpreter('')

# Generated at 2022-06-26 13:28:50.509987
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert j_s_interpreter_0.interpret_statement('return !0') == (False, True)
    assert j_s_interpreter_0.interpret_statement('q.splice(0,C.length)') == (None, False)
    assert j_s_interpreter_0.interpret_statement('var B=C.split("")') == (None, False)
    assert j_s_interpreter_0.interpret_statement('return var B=C.split("")') == (None, True)

# Generated at 2022-06-26 13:28:55.854114
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Test 1
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)


if __name__ == '__main__':
    test_case_0()
    test_JSInterpreter_call_function()

# Generated at 2022-06-26 13:29:01.802490
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'B=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    argname_0 = ['A']
    code_0 = 'A=A'
    res_f_0 = j_s_interpreter_0.build_function(argname_0, code_0)
    assert res_f_0('A') == 'A'


# Generated at 2022-06-26 13:29:08.561058
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter__0 = JSInterpreter(str_0)
    str_1 = 'a'
    obj_0 = j_s_interpreter__0.extract_object(str_1)


# Generated at 2022-06-26 13:29:15.284284
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    argnames_0 = []
    code_0 = '0KzBhP"R9zoM{5;5(%c,%a,%o,%t,%i){}'
    j_s_interpreter_0.build_function(argnames_0, code_0)

test_JSInterpreter_build_function()

# Generated at 2022-06-26 13:29:19.785526
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():

    print("\nUnit test for method extract_object of class JSInterpreter")

    js_str = """
    a={
    "a":function(){return 0},
    "b":function(){return 1},
    "c":function(){return 2},
    }
    """
    jsi = JSInterpreter(js_str)
    obj = jsi.extract_object('a')
    assert obj['a']() == 0
    assert obj['b']() == 1
    assert obj['c']() == 2


# Generated at 2022-06-26 13:29:25.107734
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    str_0 = 'a = b;'
    list_0 = []
    i_0 = 0
    j_s_interpreter_0 = JSInterpreter(str_0)
    j_s_interpreter_0.interpret_statement(str_0, list_0)
    i_1 = len(list_0)
    i_2 = 1
    assert(i_1 == i_2)


# Generated at 2022-06-26 13:30:07.527759
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_str = 'var A=C\t\\fGqi>0^BsFF\\'
    test_JSInterpreter_obj = JSInterpreter(test_str)

    out = test_JSInterpreter_obj.interpret_expression('A', None, 100)
    assert out == None


# Generated at 2022-06-26 13:30:13.333943
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'a={d:function(0,1),e:function(2,3),f:function(4,5)}'
    j_s_interpreter_0 = JSInterpreter(str_0)
    obj_0 = j_s_interpreter_0.extract_object('a')
    assert obj_0['d'](0, 1) == 0
    assert obj_0['e'](2, 3) == 2
    assert obj_0['f'](4, 5) == 4


# Generated at 2022-06-26 13:30:21.942586
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    i_0 = str('"aWFuYm91cw==".split("").reverse().join("")')
    j_s_interpreter_0 = JSInterpreter(i_0)

# Generated at 2022-06-26 13:30:22.825431
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert True


# Generated at 2022-06-26 13:30:29.164785
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'C=A\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'A=C\t\\fGqi>0^BsFF\\'
    # Invoke method build_function with the appropriate parameters
    j_s_interpreter_0.build_function(str_1, str_1)


# Generated at 2022-06-26 13:30:38.335926
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:30:41.438846
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    j_s_interpreter_0 = JSInterpreter('1{}')
    str_0 = 'f'
    bln_0 = j_s_interpreter_0.extract_function(str_0)
    return

# Generated at 2022-06-26 13:30:51.333336
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_1 = JSInterpreter(
        'var {a,b} = obj, c = obj.a, d = obj.b;',
        {'obj': {'a': 1, 'b': 2}}
    )
    assert j_s_interpreter_1._objects == {'obj': {'a': 1, 'b': 2}}
    assert j_s_interpreter_1._functions == {}
    j_s_interpreter_1.extract_object('test')
    assert j_s_interpreter_1._objects == {'obj': {'a': 1, 'b': 2}, 'test': {}}
    assert j_s_interpreter_1._functions == {}
    test = j_s_interpreter_1._objects['test']
   

# Generated at 2022-06-26 13:30:58.051573
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    str_0 = 'var D;\nvar D=8;\nvar D=D.split("");\nvar D=D.reverse();\nvar D=D.slice(2);\nvar D=D.join("");\nfunction D(D){return D.split("")}\nfunction D(D,D){return D.slice(D)}\nfunction D(D,D){return D.splice(D,1)}\nfunction D(D){return D.join("")}\nfunction D(D,D){return D.split(D)}\nfunction D(D,D,D){var D=prompt(D,D);return D};'
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert j_s_interpreter_0.extract_function('D')

# Generated at 2022-06-26 13:31:03.831261
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    str_0 = '1!=1,g=function(){var KEKA={"f":"E",g:function(a){}}};function g(a){}function h(){}}}'
    j_s_interpreter_0 = JSInterpreter(str_0)

# Generated at 2022-06-26 13:31:48.268091
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print()


# Generated at 2022-06-26 13:31:56.634812
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = "{split:{}}_{split:{}}"
    str_1 = "{split:function(){}}"
    j_s_interpreter_0 = JSInterpreter(str_1)
    str_2 = "a"
    str_3 = "b"
    str_4 = "split"
    str_5 = "split"
    str_6 = "var a={split:{}},b={split:{}}"
    str_7 = "{split:function(a,b){}}"
    j_s_interpreter_1 = JSInterpreter(str_7)
    str_8 = "split"
    str_9 = "a"
    str_10 = "b"

# Generated at 2022-06-26 13:32:02.560750
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    funcname = ""
    argnames = []
    code = ""
    j_s_interpreter_0 = JSInterpreter(code)
    #     j_s_interpreter_0.build_function(argnames, funcname)


# Generated at 2022-06-26 13:32:04.879130
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    obj_str = '$={"i":function(){}};'
    object_interpreter = JSInterpreter(obj_str)
    extracted = object_interpreter.extract_object('$')
    assert extracted['i']() is None


# Generated at 2022-06-26 13:32:18.420402
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'a(1)'
    j_s_interpreter_0 = JSInterpreter(str_0)
    res = j_s_interpreter_0.interpret_expression('a(1)', {'a': lambda x: x * 2}, 1)
    str_1 = 'a.b.c'
    j_s_interpreter_1 = JSInterpreter(str_1)
    res = j_s_interpreter_1.interpret_expression('a.b.c', {'a': {'b': {'c': 2}}}, 1)
    str_2 = 'a.slice(0)'
    j_s_interpreter_2 = JSInterpreter(str_2)

# Generated at 2022-06-26 13:32:31.216727
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'function(a){return""}'
    str_2 = 'function(a){return a.length}'
    str_3 = 'function(a,b){return a[b]}'
    str_4 = 'function(a){return a.toString()}'
    str_5 = 'function(a){return a.split("")}'
    str_6 = 'function(a){return a.slice(0)}'
    str_7 = 'function(a){return a.length}'
    str_8 = 'function(a,b){return b}'

# Generated at 2022-06-26 13:32:35.983141
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Unit test for method call_function of class JSInterpreter
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0)
    funcname_str_0 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='

# Generated at 2022-06-26 13:32:39.820857
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = '{"a":4}'
    j_s_interpreter_0 = JSInterpreter(str_0)
    result_3 = j_s_interpreter_0.extract_object(str_0)
    assert result_3 == {'a': 4}


# Generated at 2022-06-26 13:32:51.849658
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'var a = {'
    str_1 = ', function(){}'
    str_2 = '};'
    j_s_interpreter_0 = JSInterpreter(str_0+str_1+str_2)
    str_3 = 'b'
    # Should be a non-zero length dictionary
    assert j_s_interpreter_0.extract_object(str_3)
    str_4 = '"c"'
    # Should be a non-zero length dictionary
    assert j_s_interpreter_0.extract_object(str_4)
    str_5 = "'d'"
    # Should be a non-zero length dictionary
    assert j_s_interpreter_0.extract_object(str_5)


# Generated at 2022-06-26 13:32:57.083638
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'A=C\t\\fGqi>0^BsFF\\'
    j_s_interpreter_0 = JSInterpreter(str_0, str_0)
    str_1 = 'A=C\t\\fGqi>0^BsFF\\'
