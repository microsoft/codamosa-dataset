

# Generated at 2022-06-26 13:23:54.173208
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter('', dict())
    assert not (j_s_interpreter_0.build_function(list(), str()))


# Generated at 2022-06-26 13:23:59.508490
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    import re
    from .utils import ExtractorError
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)

    # Test for re.search exception
    for i in range(10):
        try:
            funcname_0 = 'fn'
            j_s_interpreter_0.extract_function(funcname_0)
        except ExtractorError:
            pass



# Generated at 2022-06-26 13:24:09.338063
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    set_1 = {}
    j_s_interpreter_1 = JSInterpreter(set_1)
    test_code_1 = '''var c = function(b) {
            var a = '';
            for (var e = 0; e < b.length; e++) a += String.fromCharCode(b[e]);
            return a;
        };'''
    arguments_1 = ("b",)
    resf_1 = j_s_interpreter_1.build_function(arguments_1, test_code_1)

# Generated at 2022-06-26 13:24:14.091258
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0, {'fake': {'oo': 'boo'}})
    j_s_interpreter_0.call_function('fake', 0)

    j_s_interpreter_1 = JSInterpreter('', {'fake': {'oo': 'boo'}})
    j_s_interpreter_1.call_function('fake', 0)



# Generated at 2022-06-26 13:24:15.825728
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert True


# Generated at 2022-06-26 13:24:26.870171
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    local_vars_0 = {}
    local_vars_0['aV4'] = None
    local_vars_0['ar6'] = None

    # Call method with arguments set_0
    # No exception expected
    j_s_interpreter_0.interpret_expression('aV4[ar6]', local_vars_0, 100)
    # Call method with arguments
    # No exception expected
    j_s_interpreter_0.interpret_expression('[ar6]', local_vars_0, 100)




# Generated at 2022-06-26 13:24:31.544826
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    local_vars = set()
    # interpret_statement is not a static method
    assertRaises(TypeError, JSInterpreter.interpret_statement, j_s_interpreter_0)


# Generated at 2022-06-26 13:24:35.136284
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:24:38.067222
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    assert j_s_interpreter_0.extract_object(set_0) == {}

# Generated at 2022-06-26 13:24:39.626404
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 13:25:27.893681
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    set_0 = set()
    set_1 = {'a': 1, 'b': 2}
    j_s_interpreter_0 = JSInterpreter(set_0)
    a_func_0 = j_s_interpreter_0.build_function(['a', 'b'], 'return a + b;')
    a_func_1 = j_s_interpreter_0.build_function(['a', 'b'], 'assert false')
    a_func_2 = j_s_interpreter_0.build_function(['a', 'b'], 'var res = a + b; return res;')
    j_s_interpreter_1 = JSInterpreter(set_1)

# Generated at 2022-06-26 13:25:36.854888
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = ('''
    var _ = {
    'escape': function(s) {
      if (typeof s !== 'string')
        return s;
      return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
    };
    ''')
    expected = {
        'escape': lambda s: s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'),
    }
    js_interpreter = JSInterpreter(code)
    actual = js_interpreter.extract_object('_')
    assert actual == expected



# Generated at 2022-06-26 13:25:47.064680
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter("""var function_0 = function(arg0, arg1) {
var var_0 = arg1;
var var_1 = arg0;
if (var_0 === var_1) {
var_1 = arg0;
var_0 = arg1;
}
var_1 = var_1 ^ var_0;
return var_1;
};""")
    argnames_0 = []
    code_0 = """arg0 ^ arg1;"""
    func_0 = j_s_interpreter_0.build_function(argnames_0, code_0)
    arg0_0 = func_0((-16, 8))
    arg0_1 = func_0((-1, ))
    arg0_2 = func_0((-1, ))

# Generated at 2022-06-26 13:25:59.812968
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    _FUNC_NAME_RE = r'''(?:[a-zA-Z$0-9]+|"[a-zA-Z$0-9]+"|'[a-zA-Z$0-9]+')'''
    j_s_interpreter_0 = JSInterpreter(set())
    j_s_interpreter_0.build_function(set(), set())

# Generated at 2022-06-26 13:26:04.434995
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    set_0 = set()
    set_1 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    def resf(args):
        local_vars = dict(zip(argnames, args))
        for stmt in code.split(';'):
            res, abort = j_s_interpreter_0.interpret_statement(stmt, local_vars)
            if abort:
                break
        return res
    assert len(set_1) == 0
    assert len(set_0) == 0

# Generated at 2022-06-26 13:26:11.474297
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    from .common import json_loads

# Generated at 2022-06-26 13:26:18.069850
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    argnames_0 = ["A"]
    code_0 = "a"
    resf_0 = j_s_interpreter_0.build_function(argnames_0, code_0)
    assert resf_0(["A"]) == "a"


# Generated at 2022-06-26 13:26:19.877617
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # TODO
    return


# Generated at 2022-06-26 13:26:29.645979
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    #Exception thrown: Exception: Could not find JS function 'g'
    try:
        j_s_interpreter_0.build_function(('{', '<', '$', '}', 'y', 'd'), ',', 'r', 'n', 'w', 'j', 't', '\\', 's', 'c', 'b', 'i', ';', '.', '+', '=', 'u')
    except Exception as e:
        assert 'Exception' in str(e)
    #Exception thrown: Exception: Could not find JS function 'g'

# Generated at 2022-06-26 13:26:40.952045
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test case 1
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    local_vars_0 = {
        'b': 3,
        'c': 4,
        'a': 5,
    }
    expr_0 = 'a + b'
    val_0 = 8.0
    val_1 = j_s_interpreter_0.interpret_expression(expr_0, local_vars_0)
    eq_(val_0, val_1)

    # Test case 2
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    expr_0 = '"hello";'
    val_0 = 'hello'
    val_1 = j_s_interpreter

# Generated at 2022-06-26 13:27:21.443035
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    argnames_0 = {'gd9zg', 'yp5if6', 'd6csbr', 'm4', 'm5', 'm2', 'm3', 'm0', 'm1', 'a', 'c', 'b'}
    args_0 = {'hcy1wqb3q', '71', 't7sxqxlu8', 'q', 'n', 'm', 'l', 'o', 'c', 'r', 'b', 'a', 'f', 'i', 'e', 'h', 'k', 'd', 'g', 'p', 's', 'j'}

# Generated at 2022-06-26 13:27:24.419837
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    set_0 = '';
    j_s_interpreter_0 = JSInterpreter(set_0)
    j_s_interpreter_0.extract_object(set_0)


# Generated at 2022-06-26 13:27:29.887290
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    argnames_0 = list()
    code_0 = str()
    # Function call
    try:
        assert j_s_interpreter_0.build_function(argnames_0, code_0) == None
    except AssertionError as e:
        print('AssertionError: ', e)


# Generated at 2022-06-26 13:27:35.380330
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = '''
    var d, e = 5, f = "abc", g;
    b = 10;
    c = b;
    d = c + b;
    function g(a,b) { return b; }
    '''
    interp = JSInterpreter(js)
    assert interp.interpret_expression('d', {}) == 20
    assert interp.interpret_expression('e', {}) == 5
    assert interp.interpret_expression('f', {}) == 'abc'
    assert interp.interpret_expression('g', {}) == 'function g(a,b) { return b; }'
    assert interp.interpret_expression('(g)', {}) == 'function g(a,b) { return b; }'

# Generated at 2022-06-26 13:27:43.112275
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    j_s_interpreter = JSInterpreter('function abc(a,b,c){var d = 0;d = a + b;}')
    f = j_s_interpreter.extract_function('abc')
    assert f((1, 2, 3)) == 3
    assert f((2, 3, 4)) == 5

    j_s_interpreter = JSInterpreter('function abc(a,b,c){return a + b;}')
    f = j_s_interpreter.extract_function('abc')
    assert f((1, 2, 3)) == 3
    assert f((2, 3, 4)) == 5


# Generated at 2022-06-26 13:27:47.579527
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = JSInterpreter("")
    j_s_interpreter_0.interpret_expression("", {}, 100)
    j_s_interpreter_0.interpret_expression("", dict(), 100)
    j_s_interpreter_0.interpret_expression("", { "a": 1 }, 100)


# Generated at 2022-06-26 13:27:50.828386
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    objname_0 = unique()
    j_s_interpreter_0.extract_object(objname_0)


# Generated at 2022-06-26 13:27:59.104912
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    assert('TS #1')
    # global var
    set_0 = 'var a = 0; return a;'
    j_s_interpreter_0 = JSInterpreter(set_0)
    assert(0 == j_s_interpreter_0.interpret_statement(set_0, {})[0])

    # local var
    set_1 = 'var a = 0; var b = a; return b;'
    j_s_interpreter_1 = JSInterpreter(set_1)
    assert(0 == j_s_interpreter_1.interpret_statement(set_1, {})[0])

    # array
    set_2 = 'var a = []; var b = a; return b;'
    j_s_interpreter_2 = JSInterpreter(set_2)
   

# Generated at 2022-06-26 13:28:01.198936
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # TODO: Implement your test here
    raise NotImplementedError("Test not implemented for JSInterpreter.build_function")


# Generated at 2022-06-26 13:28:04.053471
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter(set())
    set_1 = set()
    j_s_interpreter_0.build_function(set_1, set_1)


# Generated at 2022-06-26 13:28:56.088680
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
                function run() {
                  var a = 1;
                  var b = 2;
                  var c = a + b;
                  if (c > 2) {
                    return 3;
                  } else {
                    return 4;
                  }
                }
                '''
    j_s_interpreter_0 = JSInterpreter(code)
    assert j_s_interpreter_0.call_function('run', ) == 4

# Generated at 2022-06-26 13:28:56.933525
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_case_0()


# Generated at 2022-06-26 13:28:59.683512
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    s = JSInterpreter("var abc = 'def';", {'def':123})
    s.interpret_statement("abc = 'def';", {})


# Generated at 2022-06-26 13:29:05.086952
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Local variables
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    # Method
    # AssertionError: Could not find JS function 'test'
    try:
        j_s_interpreter_0.call_function('test')
    except AssertionError:
        pass
    # Cleanup
    pass


# Generated at 2022-06-26 13:29:12.646426
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    my_list = []
    # Test invalid arguments
    try:
        JSInterpreter(my_list).build_function()
        assert False
    except TypeError:
        pass
    try:
        JSInterpreter(my_list).build_function(None, None)
        assert False
    except TypeError:
        pass
    assert JSInterpreter(my_list).build_function([], '') is not None


# Generated at 2022-06-26 13:29:19.995053
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_0 = JSInterpreter(None)
    object_1 = {}
    assert object_1 == j_s_interpreter_0.extract_object("object_1")
    object_2 = {0: 1, 1: 2, 2: 3}
    assert object_2 == j_s_interpreter_0.extract_object("object_2")
    object_3 = {"type": 20, "test_1": 6, "2": 7, "test_2": 8}
    assert object_3 == j_s_interpreter_0.extract_object("object_3")


# Generated at 2022-06-26 13:29:23.653314
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = 'function test(a, b) {var c = a + b; return c; }'
    jsi = JSInterpreter(code)
    f = jsi.extract_function('test')
    assert f((1, 2)) == 3



# Generated at 2022-06-26 13:29:29.211591
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    expr1 = '  var  w,  d  ,  e  =  return  +  typeof(1)  ;'
    expr2 = 'for(var a=0;a<5;a++)window.alert(a);return a;'
    expr3 = 'return true;'
    expr4 = 'return;'

    lvars = {}

    jsi = JSInterpreter('')
    for expr in (expr1, expr2, expr3, expr4):
        print(jsi.interpret_statement(expr, lvars))


# Generated at 2022-06-26 13:29:39.131854
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print("Testing JSInterpreter.interpret_expression")

# Generated at 2022-06-26 13:29:42.007233
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    cases = [
        'asr.cache[asr.cache.length] = "test"'
    ]
    for case in cases:
        result = JSInterpreter(case).extract_object('asr')
        assert len(result) > 0

# Generated at 2022-06-26 13:30:23.791763
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter()
    # Test case with 0 iterations
    test_JSInterpreter_build_function_0(j_s_interpreter_0)
    # Test case with 1 iterations
    test_JSInterpreter_build_function_1(j_s_interpreter_0)


# Generated at 2022-06-26 13:30:31.225327
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    v = None
    should_abort = None
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)
    local_vars = None
    allow_recursion = 0
    stmt = "t<c.length&&(y=c[t],!(y in D))&&(D[y]=!0,l.push(y))"
    v, should_abort = j_s_interpreter_0.interpret_statement(stmt, local_vars, allow_recursion)
    assert should_abort == None


# Generated at 2022-06-26 13:30:36.918786
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    args_0 = (3, 5, 6)
    def closure_0():
        return j_s_interpreter_1

    j_s_interpreter_0 = JSInterpreter(args_0)
    j_s_interpreter_1 = closure_0()
    j_s_interpreter_0.build_function(args_0, j_s_interpreter_1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:30:45.054332
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    A = {
      func_a: function(b, c) {
        x = b+c;
        return x;
      },
      func_b: function(d) {
        y = d;
        return y;
      },
    };
    '''
    js_interpreter = JSInterpreter(code)
    A = js_interpreter.extract_object('A')
    assert isinstance(A, dict)
    assert callable(A['func_a'])
    assert A['func_a'](1, 2) == 3
    assert callable(A['func_b'])
    assert A['func_b'](2) == 2


# Generated at 2022-06-26 13:30:50.505519
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Arrange
    set_0 = set()
    j_s_interpreter_0 = JSInterpreter(set_0)

    # Act
    argnames_0 = []
    code_0 = ''
    result_0 = j_s_interpreter_0.build_function(argnames_0, code_0)

    # Assert
    assert result_0 is not None


# Generated at 2022-06-26 13:30:54.157602
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    global set_1
    set_1 = set()
    j_s_interpreter_1 = JSInterpreter(set_1)
    obj_name_0 = "a"
    assert_equals(j_s_interpreter_1.extract_object(obj_name_0), {})


# Generated at 2022-06-26 13:30:59.883299
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code_0 = "var A=1,x=A+2,B=x*A,y=B+A; alert(y);"
    assert {'A': 1, 'x': 3, 'B': 3, 'y': 4} == JSInterpreter(code_0).extract_object('y')
    code_1 = "var a='0',b=a+'1',c=a+b,d=b+c;"
    assert {'a': '0', 'b': '01', 'c': '001', 'd': '01001'} == JSInterpreter(code_1).extract_object('d')


# Generated at 2022-06-26 13:31:04.312642
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Create a JS Interpreter object
    j_s_interpreter = JSInterpreter('var foo = {a:123, b:{c: [1,2,3], d:"hello"}};')
    assert j_s_interpreter.extract_object('foo') == {'a':123, 'b':{'c': [1,2,3], 'd':'hello'}}



# Generated at 2022-06-26 13:31:06.921447
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    j_s_interpreter_0 = JSInterpreter(None)
    j_s_interpreter_0.interpret_statement(None, None, 0)


# Generated at 2022-06-26 13:31:08.477407
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    assert not JSInterpreter('var obj_0 = {key_1: function() {}};').extract_object('obj_0')


# Generated at 2022-06-26 13:32:28.198359
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    j_s_interpreter_0 = JSInterpreter("")
    str_0 = "abcabcabcabc"
    str_1 = str_0[4:]
    str_2 = str_0[-4:]
    str_3 = str_0[:4]
    str_4 = str_0[2:8]
    assert str_0 == "abcabcabcabc"
    assert str_1 == "cabcabcabc"
    assert str_2 == "bcabc"
    assert str_3 == "abca"
    assert str_4 == "cabcab"


# Generated at 2022-06-26 13:32:40.666276
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    e = JSInterpreter('var x = 1')
    assert e.interpret_expression('x', {}) == 1
    e = JSInterpreter('var x = 1')
    assert e.interpret_expression('x + 1', {}) == 2
    e = JSInterpreter('var x = 1')
    assert e.interpret_expression('"x" + x', {}) == 'x1'
    e = JSInterpreter('var x = 1')
    assert e.interpret_expression('x + "1"', {}) == '11'
    e = JSInterpreter('var x = 1')
    assert e.interpret_expression('x + "1" + "2"', {}) == '112'
    e = JSInterpreter('var x = 1')

# Generated at 2022-06-26 13:32:52.143377
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = r'''function foo(a,b) { return a + b; }
        var bar = {
            a: 1,
            b: 2,
            c: foo(a, b),
            d: {
                e: 3,
                f: 4,
                g: foo(e, f),
            },
            h: function () {
                return "this is a test";
            },
            i: function (x, y) { return x + y; },
            j: function (x, y) {
                return {
                    k: x + y,
                    l: this.i(x, y)
                }
            },
        };
        bar.m = function (x, y, z) { return x + y + z; }
    '''

# Generated at 2022-06-26 13:33:01.813562
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    _local_vars = {}
    _local_vars['objname'] = 'objname'
    _local_vars['fields'] = "a: function(){return 'a';},b: function(){return 'b';},c: function(){return 'c';}"
    _local_vars['fields_m'] = re.finditer(r'''(?x)
                (?P<key>%s)\s*:\s*function\s*\((?P<args>[a-z,]+)\){(?P<code>[^}]+)}''' % _NAME_RE, _local_vars['fields'])
    _local_vars['obj'] = {'a': lambda args: 'a', 'b': lambda args: 'b', 'c': lambda args: 'c'}

# Generated at 2022-06-26 13:33:10.433223
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    with open('fragment.js') as f:
        code = f.read()
    jsi = JSInterpreter(code)

    assert jsi.call_function('c', 'abc', 'def') == 'abcdef'

    assert jsi.call_function(
        'v',
        'https://pbs.twimg.com/profile_images/543960363161673728/Nplwlau_normal.jpeg') == 'https://pbs.twimg.com/profile_images/543960363161673728/Nplwlau_normal.jpeg'

    # Date.now() is a bit flaky in Python 2
    # assert jsi.call_function('r') == 1444360455
    d = jsi.call_function('r')
    assert d >= 1444360455 and d