

# Generated at 2022-06-26 13:24:00.678479
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:24:10.608725
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = JSInterpreter(r'return a + b * c')
    assert j_s_interpreter_0.interpret_expression('a', {'a': 2, 'b':3, 'c':4}) == 2
    assert j_s_interpreter_0.interpret_expression('b', {'a': 2, 'b':3, 'c':4}) == 3
    assert j_s_interpreter_0.interpret_expression('c', {'a': 2, 'b':3, 'c':4}) == 4

    assert j_s_interpreter_0.interpret_expression('-b', {'a': 2, 'b':3, 'c':4}) == -3


# Generated at 2022-06-26 13:24:18.484028
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = 'function transpose(a){return Object.keys(a[0]).map(function(c){return a.map(function(r){return r[c];})})}'
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('transpose')
    assert f([[1, 2], [3, 4]]) == [[1, 3], [2, 4]]

# Generated at 2022-06-26 13:24:30.501091
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    _FUNC_NAME_RE = r'''(?:[a-zA-Z$0-9]+|"[a-zA-Z$0-9]+"|'[a-zA-Z$0-9]+')'''
    funcname = 'a'
    argnames = ['b']
    code = 'function ab(b){}'

# Generated at 2022-06-26 13:24:40.305563
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    float_0 = 2352.415058
    j_s_interpreter_0 = JSInterpreter(float_0)
    str_0 = '"hello"'
    str_1 = "var return_0 = 'hello'"
    assert j_s_interpreter_0.interpret_expression(str_0, {}, 100) == "hello"
    assert j_s_interpreter_0.interpret_expression(str_1, {}, 100) == "hello"
    str_2 = '''return 'hello' '''
    assert j_s_interpreter_0.interpret_expression(str_2, {}, 100) == "hello"

test_case_0()
test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:24:43.803004
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    obj_0 = { }
    j_s_interpreter_0 = JSInterpreter("var a=5; alert(a);", obj_0)
    result = j_s_interpreter_0.interpret_statement("a=3;",obj_0)
    print(result)


# Generated at 2022-06-26 13:24:47.613387
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    from .youtube_js import _DASH_JS_FUNCTIONS
    j_s_interpreter_0 = JSInterpreter(_DASH_JS_FUNCTIONS['dh'])
    assert j_s_interpreter_0.extract_function('dh')([4, 1]) == 86



# Generated at 2022-06-26 13:24:54.753222
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    from __main__ import (
        JSInterpreter,
        ExtractorError,
    )
    float_0 = 2352.415058
    j_s_interpreter_0 = JSInterpreter(float_0)
    local_vars = {}
    j_s_interpreter_0.interpret_statement('return 0;', local_vars)
    try:
        j_s_interpreter_0.interpret_statement('return', local_vars)
    except ExtractorError as e:
        assert str(e) == 'Premature right-side return of = in \'return\''

# Generated at 2022-06-26 13:24:58.849725
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    _FUNC_NAME_RE = r'''(?:[a-zA-Z$0-9]+|"[a-zA-Z$0-9]+"|'[a-zA-Z$0-9]+')'''
    argnames = ['js_url']
    code = '''var js_url='';var arr=''.split(',');var obj={};js_url=obj.join(arr);return js_url'''
    obj = {}
    resf = JSInterpreter(obj).build_function(argnames, code)
    assert resf(tuple()) == ""


# Generated at 2022-06-26 13:25:03.578289
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    expected = 2352
    code = '(((2546.021+89.1)<<1)>>1)+0.0001'
    j_s_interpreter_0 = JSInterpreter(code)
    value = j_s_interpreter_0.interpret_expression(code, {})
    assert value == expected, 'Expected ' + str(expected) + ' and got ' + str(value)


# Generated at 2022-06-26 13:25:20.153052
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter("""
        function f() {
            a = {
                b: function() {
                    return function() {
                        return function() {
                            return 'lol';
                        }
                    }()
                }()
            }
        }
        """)
    assert interpreter.call_function('f') == {'b': 'lol'}



# Generated at 2022-06-26 13:25:26.367462
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_object_0 = JSInterpreter(float_0)
    objname = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    obj = j_s_interpreter_object_0.extract_object(objname)

# Generated at 2022-06-26 13:25:30.732867
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    j_s_interpreter_0 = JSInterpreter("('%s'.split('').reverse().join(''))")
    res = j_s_interpreter_0.call_function("(%s'.split('').reverse().join(''))")
    assert res is None


# Generated at 2022-06-26 13:25:32.870915
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    j_s_interpreter_0 = JSInterpreter("")
    j_s_interpreter_0.call_function("testMethod", "test")

# Generated at 2022-06-26 13:25:37.330816
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    extractor = JSInterpreter('''
        "abc": function() {
            return 123;
        }
    ''')
    obj = extractor.extract_object('abc')
    assert callable(obj['abc'])
    assert obj['abc']() == 123


# Generated at 2022-06-26 13:25:42.605719
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter()
    str_0 = "var a = {x: function(a) {return a}}; a['x']"
    j_s_interpreter_0.build_function(str_0)
    # Call to method build_function of class JSInterpreter with arguments str_0
    # ended in exception


# Generated at 2022-06-26 13:25:50.089731
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def resf1(args):
        local_vars = dict(zip(argnames1, args))
        for stmt in code1.split(';'):
            res, abort = j_s_interpreter_1.interpret_statement(stmt, local_vars)
            if abort:
                break
        return res

    argnames1 = ['a', 'b']
    code1 = '''
        int a = 0;
        int b = 1;
        a + b
    '''
    j_s_interpreter_1 = JSInterpreter(code1)
    assert resf1([0, 1]) == 1

    def resf2(args):
        local_vars = dict(zip(argnames2, args))
        for stmt in code2.split(';'):
            res, abort

# Generated at 2022-06-26 13:25:55.715324
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''function test() { a = {b : function(args) { return 42;}}; }'''
    jsinterpreter = JSInterpreter(code)
    res = jsinterpreter.extract_object('a')
    assert res == {'b': lambda args: 42}


# Generated at 2022-06-26 13:26:04.764852
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Local variables initialization
    code = None
    objects = []
    j_s_interpreter_0 = None
    local_vars = []

    # Test case preparation

    # Test case execution
    code = (u'var b=b+1;')
    # 1
    objects = {u'b': [u'b+1']}
    j_s_interpreter_0 = JSInterpreter(code, objects)
    # 2
    local_vars = {u'b': [u'b+1']}
    result = j_s_interpreter_0.interpret_expression(objects[u'b'], local_vars, 100)

    assert result == [u'b+1']


# Generated at 2022-06-26 13:26:08.027631
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    float_0 = 4
    j_s_interpreter_0 = JSInterpreter(float_0)    
    argnames_0 = ['a', 'b']
    code_0 = 'return a * b'
    resf_0 = j_s_interpreter_0.build_function(argnames_0, code_0)


# Generated at 2022-06-26 13:26:28.009653
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    test_js = JSInterpreter(str_0)
    assert test_js.interpret_expression('a.value', dict(), 10), "xyz"
    assert test_js.interpret_expression('a.join()', dict(), 10), "abcxyz"


# Generated at 2022-06-26 13:26:35.242296
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = '''
    var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;
    var b = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;
    '''
    inter = JSInterpreter(js)
    
    # TEST CASE 0 - check the method build_function with arguments: argnames, code
    # Expected Result: the argnames is empty, the code is the javascript string str_0 
    # Actual Result: the result is equal to the expected result
    assert (inter.build_function([], str_0)() == 'abcxyz')
    assert (inter.build_function(['a'], str_0)(1) == 'abcxyz')
    

# Generated at 2022-06-26 13:26:48.526024
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_var = "var x = { 'x': "
    str_0 = "'w',"
    str_1 = "'y',"
    str_2 = "'z',"
    str_3 = "'a',"
    str_4 = "'b',"
    str_5 = "'c',"
    str_6 = "'d',"
    str_7 = "'e',"
    str_8 = "'f' };"
    str_9 = 'x.x();x.y();'
    str_10 = 'function abc(a, b, c, d, e, f)'
    str_11 = '{'
    str_12 = 'if(a == b) return c;'
    str_13 = 'else return f;'
    str_14 = '}'

# Generated at 2022-06-26 13:26:53.174676
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    int_0 = 1
    obj_0 = JSInterpreter(str_0)
    if(int_0 == obj_0.extract_object("a").get("value")):
        print("Test 1: Passed")
    else:
        print("Test 1: Failed")


# Generated at 2022-06-26 13:27:04.766487
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    str_1 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    str_2 = 'ABC'
    str_3 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    str_4 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    str_5 = 'xyz'

# Generated at 2022-06-26 13:27:08.129582
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_obj = JSInterpreter(str_0).extract_object("a")
    assert (js_obj["name"] == "abc")
    assert (js_obj["value"] == "xyz")
    assert (js_obj["join"]("") == "abcxyz")


# Generated at 2022-06-26 13:27:17.388638
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    js_interpreter = JSInterpreter(str_0)
    js_interpreter.interpret_expression('var', {'var': 100})
    js_interpreter.interpret_expression('a', {'a': 100})
    js_interpreter.interpret_expression('a.name', {'a': {'name': 100}})



# Generated at 2022-06-26 13:27:24.795357
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    js_interpreter = JSInterpreter(str_0)
    # Line 4
    argnames = []
    code = 'return a.name+a.value;'
    obj_0 = js_interpreter.build_function(argnames, code)
    assert obj_0() == "abcxyz"


# Generated at 2022-06-26 13:27:26.505037
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    assert(str(JSInterpreter.extract_object(str_0, "a")) == str_0)


# Generated at 2022-06-26 13:27:35.171198
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'var a = { "name": "abc",' \
            '"value": "xyz",' \
            '"join": function(v){return a.name+a.value;} } ;'
    jsi = JSInterpreter(str_0, {})
    bool_0 = jsi.interpret_expression('a.name', {})
    assert bool_0 == 'abc'
    str_1 = jsi.interpret_expression('a.value', {})
    assert str_1 == 'xyz'
    str_2 = jsi.interpret_expression('a.join', {})
    assert str_2 == 'abcxyz'
    str_3 = jsi.interpret_expression('a.join("|")', {})
    assert str_3 == 'abc|xyz'


# Generated at 2022-06-26 13:27:55.895770
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter("""var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;""", None).interpret_expression("a.join(\"\")","v") == "abcxyz"
    assert JSInterpreter("""var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;""", None).interpret_expression("a.join(\"\")","v") == "abcxyz"
    assert JSInterpreter("""var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;""", None).interpret_expression("a.name","v") == "abc"

# Generated at 2022-06-26 13:27:58.031963
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    expr = "b.join('').split('').reverse()[0]"
    js_interpreter = JSInterpreter("")
    js_interpreter.interpret_expression(expr, {})


# Generated at 2022-06-26 13:28:06.442738
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    interp = JSInterpreter(str_0)
    print(interp.interpret_expression('a["name"]+" "+a["value"]', {}, 100)) #expected abc xyz
    print(interp.interpret_expression('a.join()', {}, 100)) #expected abcxyz
    str_0 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value+v;} } ;'
    interp = JSInterpreter(str_0)
    print(interp.interpret_expression('a.join("-")', {}, 100)) #expected abcxyz-

# Generated at 2022-06-26 13:28:12.644804
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    var = dict()
    var['a'] = 3
    var['b'] = 5
    var['c'] = 1
    var['d'] = 4
    var['e'] = 99

    str0 = 'a'
    s = JSInterpreter('', var)
    assert (s.interpret_expression(str0, var) == 3)

    str0 = 'b'
    s = JSInterpreter('', var)
    assert (s.interpret_expression(str0, var) == 5)

    str0 = 'c'
    s = JSInterpreter('', var)
    assert (s.interpret_expression(str0, var) == 1)

    str0 = 'd'
    s = JSInterpreter('', var)
    assert (s.interpret_expression(str0, var) == 4)

   

# Generated at 2022-06-26 13:28:22.894311
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Create an instance of JSInterpreter
    str_0 = ('var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;')
    js_interpreter_0 = JSInterpreter(str_0)
    # Call method interpret_expression of class JSInterpreter
    res_0 = js_interpreter_0.interpret_expression('a.value', {}, 0)
    # Assertion of method interpret_expression of class JSInterpreter with local variable equal to {'a': {'join': <function _make_function.<locals>.resf at 0x7f79f66fba60>, 'name': 'abc', 'value': 'xyz'}}
    if res_0 != 'xyz':
        print('Error in script')
       

# Generated at 2022-06-26 13:28:25.030550
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    extractor = JSInterpreter()
    extractor.interpret_expression(str_1, local_vars, recursion_limit)

# Generated at 2022-06-26 13:28:30.656548
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    jsi = JSInterpreter(str_0)
    assert jsi.build_function(["a","b","c"],"return a+b+c;")("1","2","4") == "124"
    assert jsi.call_function("a.join")("","") == "abcxyz"


# Generated at 2022-06-26 13:28:39.363038
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interp = JSInterpreter('function test(name, value) { return "name:"+name+" value:"+value; }')
    assert interp.extract_function('test')(('name', 'value')) == 'name:name value:value'


# Generated at 2022-06-26 13:28:42.169377
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter(str_0)
    assert jsi.build_function(['v'], "return a.name+a.value;")([""]) == "abcxyz"


# Generated at 2022-06-26 13:28:51.743625
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        var a = {
            "name": "abc",
            "value": "xyz",
            "join": function(v){
                return a.name+a.value;
            }
        }
    '''
    assert JSInterpreter(code).interpret_expression('a.name',{}) == 'abc'
    assert JSInterpreter(code).interpret_expression('a.value',{}) == 'xyz'
    assert JSInterpreter(code).interpret_expression('a.join()',{}) == 'abcxyz'
    print('test_JSInterpreter_interpret_expression passed')



# Generated at 2022-06-26 13:29:13.577785
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_1 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    str_2 = 'var a = { "name": "abc","value": "xyz","join": function(v,w){return a.name+a.value+v+w;} } ;'
    interpreter = JSInterpreter(str_1)
    interpreter.build_function(str_1)

# Generated at 2022-06-26 13:29:14.558106
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    pass


# Generated at 2022-06-26 13:29:22.198624
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    a = JSInterpreter(str_0)

# Generated at 2022-06-26 13:29:28.135143
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('', objects={"a": {"name":"abc","value":"xyz","join":lambda *args: args}})
    assert js.interpret_expression('a["join"]("")', {}) == ('', )
    assert js.interpret_expression('a["join"](1)', {}) == (1, )
    assert js.interpret_expression('a["join"](1, 2, 3)', {}) == (1, 2, 3)
    assert js.interpret_expression('a["value"]', {}) == 'xyz'
    assert js.interpret_expression('a["value"][0]', {}) == 'x'
    assert js.interpret_expression('a["value"][2]', {}) == 'z'
    assert js.interpret_expression('a["value"]["length"]', {}) == 3

# Generated at 2022-06-26 13:29:34.856782
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    js_interpreter_0 = JSInterpreter(str_0)
    str_1 = '"abc"+"xyz"'
    try:
        print(js_interpreter_0.interpret_expression(str_1, {'a':{}}, 100))
    except Exception as e:
        print('Caught exception: ' + e.__class__.__name__)


# Generated at 2022-06-26 13:29:44.070410
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_str = 'function sf_func(param){var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;var b = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;var c = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;return a;}'
    interperter = JSInterpreter(js_str)
    func = interperter.extract_function('sf_func')
    func((1,2,3))
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 13:29:50.727885
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:29:56.922377
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'var a = { "name": "abc","value": "xyz","join": function(v){return a.name+a.value;} } ;'
    jsint = JSInterpreter(code=str_0)
    obj = jsint.extract_object(objname="a")
    assert obj["name"]=="abc"
    assert obj["join"]("-")=="abc-xyz"


# Generated at 2022-06-26 13:30:02.685706
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_interpreter = JSInterpreter(str_0)
    obj = js_interpreter.extract_object("a")

# Generated at 2022-06-26 13:30:03.632731
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    pass


# Generated at 2022-06-26 13:30:28.804786
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:30:38.020472
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    extractorError_0 = ExtractorError('Recursion limit reached')
    func_0 = object()
    float_0 = 2352.415058
    string_0 = 'B4F1J4I4N4G4B4F1J4I4N4G4'
    string_1 = '%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c'
    j_s_interpreter_0 = JSInterpreter(string_0)
    # msg is an str
    msg

# Generated at 2022-06-26 13:30:47.003212
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = JSInterpreter(None)
    float_0 = 2352.415058
    float_1 = 3.21021728515625
    float_2 = 3.21021728515625
    float_3 = 3.21021728515625
    float_4 = 3.21021728515625
    float_5 = 3.21021728515625
    float_6 = 3.21021728515625
    float_7 = 3.21021728515625
    float_8 = 3.21021728515625
    float_9 = 3.21021728515625
    float_10 = 3.21021728515625
    float_11 = 3.21021728515625
    float_12 = 3.21021728515625


# Generated at 2022-06-26 13:30:51.331809
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('var a = [1, 2]; a;')
    assert js.interpret_expression('(a)', {}) == [1, 2]
    assert js.interpret_expression('a[0]', {}) == 1


# Generated at 2022-06-26 13:30:51.847706
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert(True)


# Generated at 2022-06-26 13:30:52.667880
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert True


# Generated at 2022-06-26 13:30:59.703337
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    int_8 = 8
    int_15 = 15
    int_2352 = 2352
    int_235220 = 235220
    int_2352415058 = 2352415058
    int_23524150582352 = 23524150582352
    float_0 = 2352.415058
    string_ytd = 'ytd'
    string_abc = 'abc'
    string_def = 'def'
    string_x = 'x'
    string_qr = 'qr'
    string_pqr = 'pqr'
    string_ytd_1 = 'ytd'
    string_bc = 'bc'
    string_cd = 'cd'
    string_x_1 = 'x'
    string_qr_1 = 'qr'

# Generated at 2022-06-26 13:31:08.123101
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
            var a, v, s;
            v=function(b){c=5};
            var w=function(){};
            var x={a:function(b){c=5},2:function(){}};
            a=[1,2,3];
            a.length;
            a[1];
            a.slice(0);
            a.splice(1,1);
            a.join("");
            a.reverse();
            s="";
            s.slice(0);
            s.split("");
            v(3);
            w();
            x[2]();
            x.a(3);
            z=20;
            z/=2;
            z*=10;
            z-=14;
            z=z-1;
            z+=2;
            """
   

# Generated at 2022-06-26 13:31:16.375937
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:31:26.655553
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_case = {
        # test_case[0]
        'code': '''
            var a = 10;
            var b = 20;
            ''',
        'local_vars': {
            'a': 10,
            'b': 20
        },
        'expressions': {
            'a': 10,
            'b': 20,
            'a + b': 30,
            'a - b': -10,
            'a * b': 200,
            'a / b': 0.5,
            'a & b': 0,
            'a | b': 30,
            'a ^ b': 30,
            'a << b': 2**20,
            'a >> b': 0,
            'a % b': 10,
        }
    }


# Generated at 2022-06-26 13:31:57.535363
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_0 = JSInterpreter()
    dictionary_0 = j_s_interpreter_0.extract_object('vS')
    dictionary_1 = j_s_interpreter_0.extract_object('Xo')
    dictionary_2 = j_s_interpreter_0.extract_object('Dp')
    dictionary_3 = j_s_interpreter_0.extract_object('Rh')
    dictionary_4 = j_s_interpreter_0.extract_object('tD')
    dictionary_5 = j_s_interpreter_0.extract_object('uD')
    dictionary_6 = j_s_interpreter_0.extract_object('oD')

# Generated at 2022-06-26 13:32:07.370959
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = JSInterpreter("""
      var a = "";
      a += "YT";
      a += "player.config = ";
      var b;
      if (ytplayer && ytplayer.config) {
        b = ytplayer.config;
      }
      a += JSON.stringify(b || {});
      a += ";ytplayer.web_player_context_config = ";
      a += JSON.stringify(ytplayer.web_player_context_config || {});
      a += "";
      a;
      """)


# Generated at 2022-06-26 13:32:13.544526
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    playerInstance_0 = 'playerInstance_0'
    j_s_interpreter_0 = JSInterpreter(playerInstance_0)
    return_0 = j_s_interpreter_0.extract_object('playerInstance_0')
    assert return_0 == 0


# Generated at 2022-06-26 13:32:15.539396
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Case 0
    test_case_0()


# Generated at 2022-06-26 13:32:29.886982
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test case 1
    float_0 = 2352.415058
    j_s_interpreter_0 = JSInterpreter(float_0)

# Generated at 2022-06-26 13:32:41.421812
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    print("Testing function extract_object of class JSInterpreter...")
    j_s_interpreter_0 = JSInterpreter(
        "var a={b:function(c){return d;},e:function(c,d){f=c;g=d;}};")
    j_s_interpreter_1 = JSInterpreter("var a={b:function(){},e:function(a,c){}};")

    assert (j_s_interpreter_0.extract_object("a") == {
        "b": j_s_interpreter_0.extract_function("a.b"),
        "e": j_s_interpreter_0.extract_function("a.e"),
    })


# Generated at 2022-06-26 13:32:49.860652
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi_build_function = JSInterpreter("""
        function() {
            return c(4, 1, 7);
        }
        """)

    def f(res):
        assert res == '4177'
    c = lambda x, y, z: str(x) + str(y) + str(z)
    jsi_build_function.build_function([], f)([c])




# Generated at 2022-06-26 13:32:54.786229
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    float_1 = 2352.415058
    j_s_interpreter_1 = JSInterpreter(float_1)
    assert j_s_interpreter_1.interpret_expression(float_1)

# Generated at 2022-06-26 13:33:03.239493
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:33:08.459280
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsin = JSInterpreter(
'''
        function func(arg1, arg2) {
            var local_var = arg2;
            local_var = local_var + 1;
            return arg1 * local_var;
        }
'''
    )
    func = jsin.extract_function('func')
    assert func((2, 3)) == 5
