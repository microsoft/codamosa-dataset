

# Generated at 2022-06-26 13:23:49.609037
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = ''
    j_s_interpreter_0 = JSInterpreter(code)
    stmt = '{}()'
    local_vars = {}
    allow_recursion = 0
    # self.assertRaises(ExtractorError, j_s_interpreter_0.interpret_expression, stmt, local_vars, allow_recursion)


# Generated at 2022-06-26 13:24:00.256880
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    expr = "a + b"
    code = "return a+b;"
    assert JSInterpreter.build_function(None, expr, code)((1,2)) == 3
    expr = "obj.func(a, b)"
    code = "return a+b;"
    assert JSInterpreter.build_function(None, expr, code)((1,2)) == 3
    expr = "this.a + this.b"
    code = "return a+b;"
    assert JSInterpreter.build_function(None, expr, code)((1,2)) == 3
    expr = "this.a + this.b"
    code = "return a + b;"
    assert JSInterpreter.build_function(None, expr, code)((1,2)) == 3

# Generated at 2022-06-26 13:24:07.077926
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
    var o = {
        a: 3,
        b: 'foo',
        c: function(arg1, arg2) {return arg1 + arg2}
    };
    '''
    jsi = JSInterpreter(js_code)
    assert jsi.extract_object('o') == {
        'a': 3,
        'b': 'foo',
        'c': jsi._functions['o.c']
    }


# Generated at 2022-06-26 13:24:14.688746
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:24:27.902546
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Note: the following source code is derived from https://github.com/ytdl-org/youtube-dl/blob/master/youtube_dl/extractor/common.py
    # under MIT License and modified to fit the test case
    # Please refer to the original code for license information
    from .utils import unescapeHTML

    def js_to_json(code):
        jsi = JSInterpreter(code, {
            'a': '\\u0026',
            'b': '<',
            'c': '>',
            'd': '\\"',
        })

# Generated at 2022-06-26 13:24:31.584387
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    j_s_interpreter_0 = JSInterpreter("var q = function (a) { return a; }")
    assert j_s_interpreter_0.call_function("q", 0) == 0


# Generated at 2022-06-26 13:24:41.913362
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    float_0 = float(0)
    float_1 = float(1)
    float_2 = float(2)
    float_3 = float(3)
    float_4 = float(4)
    float_5 = float(5)
    float_6 = float(6)
    float_7 = float(7)
    float_8 = float(8)
    float_9 = float(9)
    float_10 = float(10)
    float_11 = float(11)
    float_12 = float(12)
    float_13 = float(13)
    float_14 = float(14)
    float_15 = float(15)
    float_16 = float(16)
    float_17 = float(17)
    float_18 = float(18)
    float_19 = float(19)

# Generated at 2022-06-26 13:24:48.659564
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    float_0 = -297.1
    j_s_interpreter_0 = JSInterpreter(float_0)

    # (String, String, String[]) -> int
    res_f = j_s_interpreter_0.build_function(["a", "b", "c"], "abcc.join(a)")
    assert res_f(["x", "y", "z"]) == "xyzxyz"

    # ([int], String) -> int
    res_f = j_s_interpreter_0.build_function(["x", "y"], "return x * y;")
    assert res_f([2, 3]) == 6

    # ([int], String) -> int

# Generated at 2022-06-26 13:24:55.856961
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    float_0 = 2.0
    js_interpreter_0 = JSInterpreter(float_0)
    float_1 = 2.0
    str_0 = 'undefined'
    str_1 = 'float_1'
    str_2 = 'float_1 = 2.0'
    str_3 = 'float_1'
    str_4 = '2.0'
    str_5 = 'float_1 = 2.0;'
    str_6 = 'float_1;'
    float_2 = js_interpreter_0.build_function(str_0, str_2)
    float_3 = float_2()
    assert float_3 == float_1
    float_4 = js_interpreter_0.build_function(str_1, str_5)
    float_5

# Generated at 2022-06-26 13:25:03.402209
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    float_0 = -297.1
    float_1 = float_0

# Generated at 2022-06-26 13:25:22.105718
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_0 = "var obj = {somekey: 'somevalue', somekey2: 'somevalue2'}"
    js_1 = "var obj = {somekey: 'somevalue', somekey2: 'somevalue2', somekey3: 'somevalue3'}"
    js_2 = "var obj = {somekey: 'somevalue', somekey2: 'somevalue2', somekey3: 'somevalue3', somekey4: 'somevalue4'}"

    # Initialize instances
    j_s_interpreter_0 = JSInterpreter(js_0)
    j_s_interpreter_1 = JSInterpreter(js_1)
    j_s_interpreter_2 = JSInterpreter(js_2)

    # Function to test
    objects_0 = {}
    objects_1 = {}

# Generated at 2022-06-26 13:25:30.125126
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'e6a'
    str_1 = 'Z'
    int_0 = -65
    str_2 = '\x00'
    int_1 = -15826
    str_3 = 'b9a'
    str_4 = '\x00'
    int_2 = -5708
    str_5 = '\x00'
    int_3 = -5708
    str_6 = '\x00'
    int_4 = -5708
    str_7 = '\x00'
    str_8 = '\x00'
    str_9 = '\x00'
    int_5 = -5708
    str_10 = '\x00'
    int_6 = -5708
    str_11 = '\x00'

# Generated at 2022-06-26 13:25:33.482271
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_str = '''$fmt.unique_sorted_values_of_property($metadata, "artist")'''
    js_int = JSInterpreter(test_str)
    js_int.interpret_expression(test_str, {})



# Generated at 2022-06-26 13:25:44.871553
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:25:50.972727
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    print('test_interpret_statement:')
    assert JSInterpreter('return undefined;').interpret_statement(
        'return undefined', {}
    ) == (None, True)
    assert JSInterpreter('var a = 1;').interpret_statement(
        'var a', {}
    ) == (1, False)
    assert JSInterpreter('var a = 1;').interpret_statement(
        '', {}
    ) == (None, False)
    assert JSInterpreter('return Math.round(1.1);').interpret_statement(
        'return Math.round(1.1)', {}
    ) == (1, True)
    assert JSInterpreter('var a = 1; return a;').interpret_statement(
        'return a', {'a': 1}
    ) == (1, True)
    assert JS

# Generated at 2022-06-26 13:26:03.136179
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    int_0 = 1
    int_1 = -1
    int_2 = 4
    int_3 = -4
    float_0 = -299.1
    float_1 = -27.5
    float_2 = 3.2e+5
    float_3 = 1.4e-5
    float_4 = 2.3e+5
    float_5 = 2.3e-5
    float_6 = 2.3e-5
    float_7 = 2.3e-5
    float_8 = 3.2e+5
    float_9 = 3.2e+5
    float_10 = 3.2e+5
    float_11 = 3.2e+5
    float_12 = 3.2e+5
    float_13 = 1.4e-5

# Generated at 2022-06-26 13:26:08.481192
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    t0 = "tRk"
    j0 = JSInterpreter("var tRk = {\"c\": function(p) {return p.s;}, \"s\": function(p) {return p.l;}, \"l\": function(p) {return p.c;}};")

    assert str(j0._objects["tRk"]) == "{'c': <function <lambda> at 0x0373C7D0>, 's': <function <lambda> at 0x0373C850>, 'l': <function <lambda> at 0x0373C8D0>}"
    assert str(j0._objects.keys()) == "['tRk']"

# Generated at 2022-06-26 13:26:13.030183
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    print("Test call_function")
    float_0 = -297.1;
    j_s_interpreter_0 = JSInterpreter(float_0);
    j_s_interpreter_0.call_function(float_0);
    if (j_s_interpreter_0 == float_0):
        print("PASSED")
    else:
        print("FAILED")

# Generated at 2022-06-26 13:26:26.149996
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsi_0 = JSInterpreter('a: {}')
    ob = jsi_0.extract_object('a')
    jsi_0.extract_object('a')
    ob = jsi_0.extract_object('a')
    jsi_0.extract_object('d')

    jsi_1 = JSInterpreter('a: {b: 1}')
    ob = jsi_1.extract_object('a')

    jsi_2 = JSInterpreter('a: {b: "hello"}')
    ob = jsi_2.extract_object('a')
    jsi_2.extract_object('b')

    jsi_3 = JSInterpreter('a: {b: 1, c: 2}')
    ob = jsi_3.extract_object

# Generated at 2022-06-26 13:26:28.330199
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Arrange
    j_s_interpreter_0 = JSInterpreter(None)
    objname = 'var'

    # Act
    d= j_s_interpreter_0.extract_object(objname)

    # Assert
    assert d == {}, 'empty dict expected'


# Generated at 2022-06-26 13:26:48.303300
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    float_0 = -297.1
    j_s_interpreter_0 = JSInterpreter(float_0)
    argnames = array('C')
    code = j_s_interpreter_0.build_function(argnames, code)

# Generated at 2022-06-26 13:26:51.102668
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert(test_case_0() == 0)
    print("Unit test for method build_function of class JSInterpreter PASSED")

# Tests compiled together

# Generated at 2022-06-26 13:26:55.726383
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    float_0 = -297.1
    j_s_interpreter_0 = JSInterpreter(float_0)
    j_s_interpreter_0.extract_function(None)
    j_s_interpreter_0.call_function("", "", "", "")


# Generated at 2022-06-26 13:27:06.675884
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test case 0
    float_0 = -297.1
    j_s_interpreter_0 = JSInterpreter(float_0)

    # Test case 1
    r_2_code = 'var a = function(p, a, c, k, e, r) { }'
    j_s_interpreter_1 = JSInterpreter(r_2_code, objects={'a': lambda p, a, c, k, e, r: None})
    j_s_interpreter_1.interpret_expression(None, {'a': lambda p, a, c, k, e, r: None}, 6)

    # Test case 2
    float_0 = 176993.0
    float_1 = float_0

# Generated at 2022-06-26 13:27:09.077649
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    float_0 = -297.1

    j_s_interpreter_0 = JSInterpreter(float_0)

    j_s_interpreter_0.extract_object(float_0)



# Generated at 2022-06-26 13:27:14.306151
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter('test')
    local_vars = {}
    j_s_interpreter_0.build_function(['foo', 'bar'], 'foo == bar;')


# Generated at 2022-06-26 13:27:21.743755
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    float_0 = '''
        function r(a) {
            a = a.split("");
            a = a.reverse();
            a = a.join("");
            return a;
        }
    '''
    j_s_interpreter_0 = JSInterpreter(float_0)
    string_0 = 'abc';
    string_1 = j_s_interpreter_0.extract_function(string_0)(string_1);
    assert (string_1 == "cba");


# Generated at 2022-06-26 13:27:31.239589
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        var q = function(a) {
            return a * a;
        };
        var w = {
            e: q(1),
            r: q(2)
        };
    '''
    j = JSInterpreter(code)
    assert j.interpret_expression('1 + 2', {}) == 3
    assert j.interpret_expression('2 - 10', {}) == -8
    assert j.interpret_expression(
        '"abc" + "def"', {}) == 'abcdef'
    assert j.interpret_expression('"abc".length', {}) == 3
    assert j.interpret_expression('w.e', {}) == 1
    assert j.interpret_expression('q(3)', {}) == 9


# Generated at 2022-06-26 13:27:37.681822
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test case 0
    try:
        j_s_interpreter_0 = JSInterpreter('', {})
    except Exception as exc:
        assert type(exc) == TypeError

    # Test case 1
    try:
        j_s_interpreter_1 = JSInterpreter(None, {})
    except Exception as exc:
        assert type(exc) == TypeError

    # Test case 2
    try:
        j_s_interpreter_2 = JSInterpreter('', None)
    except Exception as exc:
        assert type(exc) == TypeError

    # Test case 3
    try:
        j_s_interpreter_3 = JSInterpreter(None, None)
    except Exception as exc:
        assert type(exc) == TypeError

    # Test case 4

# Generated at 2022-06-26 13:27:45.386174
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    a = 1
    b = 2
    c = 3
    d = 4
    j_s_interpreter_0 = JSInterpreter()

    stmt = 'a = a + b - d'
    local_vars = locals()
    j_s_interpreter_0.interpret_statement(stmt, local_vars)
    assert a == 4

    stmt = 'c'
    local_vars = locals()
    j_s_interpreter_0.interpret_statement(stmt, local_vars)
    assert c == 3

    stmt = 'd = b'
    local_vars = locals()
    j_s_interpreter_0.interpret_statement(stmt, local_vars)
    assert d == 2



# Generated at 2022-06-26 13:28:38.562194
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test case 0
    float_0 = -297.1
    j_s_interpreter_0 = JSInterpreter(float_0)


# Generated at 2022-06-26 13:28:40.993777
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    float_0 = -297.1
    j_s_interpreter_0 = JSInterpreter(float_0)


# Generated at 2022-06-26 13:28:43.613251
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    JSInterpreter_obj = JSInterpreter()
    JSInterpreter_obj.interpret_expression(['1', '2', '3', '4'])


# Generated at 2022-06-26 13:28:48.417749
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    funcname = 'pow'
    js_interpreter = JSInterpreter('function pow(a,b){return a**b;}')
    f = js_interpreter.extract_function(funcname)
    # Insert test code here
    expected = 3
    actual = f((2, 3))
    assert actual == expected


# Generated at 2022-06-26 13:28:59.491138
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = JSInterpreter(1.0)
    assert j_s_interpreter_0.interpret_expression('1', {}, 100) == 1.0

    j_s_interpreter_1 = JSInterpreter(1.0)
    assert j_s_interpreter_1.interpret_expression('a', {'a': 2.0}, 100) == 2.0

    j_s_interpreter_2 = JSInterpreter(1.0)
    assert j_s_interpreter_2.interpret_expression('a + 5', {'a': 2.0}, 1) == 7.0

    j_s_interpreter_3 = JSInterpreter(1.0)

# Generated at 2022-06-26 13:29:09.226682
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        var a = function () {
            return 0;
        };
        var b = function (x) {
            return x * 3;
        };
        var c = function (x, y) {
            return x * y;
        };
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.extract_function('a')() == 0
    assert js_interpreter.extract_function('b')(2) == 6
    assert js_interpreter.extract_function('c')(2, 3) == 6



# Generated at 2022-06-26 13:29:18.654803
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code_0 = '''
        var a = {
            foo: function(v0) {
                if (a.bar(1, 2, 3)) {
                    return 'bar';
                } else if (v0) {
                    if (a.foobar(1)) {
                        return 'foobar';
                    }
                    return 'baz';
                } else {
                    return 'none';
                }
            },
            bar: function(v0, v1, v2) {
                return v0 + v1 + v2 == 6;
            },
            foobar: function(v0) {
                return v0 == 0;
            },
        };
        return a.foo(2);
    '''
    float_0 = -297.1

# Generated at 2022-06-26 13:29:23.002527
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = JSInterpreter({})
    j_s_interpreter_0.interpret_expression('0.45;', {}, 300)
    j_s_interpreter_0.interpret_expression('gdjsgd;', {}, 300)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:29:24.427429
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert test_case_0() == 'function_0'


# Generated at 2022-06-26 13:29:31.061641
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    print('Testing JSInterpreter.extract_function')
    float_0 = -297.1
    j_s_interpreter_0 = JSInterpreter(float_0)
    result = j_s_interpreter_0.extract_function('wa')
    assert result == 150122972000000000.0, 'JSInterpreter.extract_function returned ' + repr(result)
    result = j_s_interpreter_0.extract_function('hb')
    assert result == 2592000000.0, 'JSInterpreter.extract_function returned ' + repr(result)
    result = j_s_interpreter_0.extract_function('ib')
    assert result == 150122972000000000.0, 'JSInterpreter.extract_function returned ' + repr(result)

# Generated at 2022-06-26 13:30:25.212008
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_1 = JSInterpreter(None).build_function(['x'], 'return 2*x')
    assert test_1(10) == 20
    test_2 = JSInterpreter(None).build_function(
        ['x', 'y'], 'return x*y + 1')
    assert test_2(10, 20) == 1 + 200
    test_3 = JSInterpreter(None).build_function(
        ['x', 'y'], 'return x*y + 1;return 2*x+y')
    assert test_3(10, 20) == 20

    

# Generated at 2022-06-26 13:30:35.343548
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinter = JSInterpreter('')

    def test_func(f, args, expected):
        func = jsinter.build_function(f[0], f[1])
        assert func(args) == expected

    test_func((['a'], 'return a'), (42,), 42)
    test_func((['a'], 'return a + 2'), (42,), 44)
    test_func((['a'], 'a + 2'), (42,), 44)
    test_func((['a', 'b'], 'return a * b'), (3, 5), 15)
    test_func((['a', 'b'], 'a - b'), (2, 3), -1)
    test_func((['a', 'b'], 'a - (b + 1)'), (5, 3), 1)

    test

# Generated at 2022-06-26 13:30:44.627626
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    float_0 = -297.1
    j_s_interpreter_0 = JSInterpreter(float_0)
    assert type(j_s_interpreter_0.build_function([""], "")) == types.FunctionType
    assert type(j_s_interpreter_0.build_function(["hello"], "hello.split('\\?').join('\\\\n')")) == types.FunctionType
    assert type(j_s_interpreter_0.build_function(["hello"], "hello.split('\\n').join('\\n')")) == types.FunctionType
    assert type(j_s_interpreter_0.build_function(["hello"], "hello.split('\\n').join('\\n')")) == types.FunctionType

# Generated at 2022-06-26 13:30:52.803683
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_code = '''
                this.ytplayer = {
                    "config": {
                        "url": "url_to_api",
                        "args": {
                            "title": "title",
                            "url_encoded_fmt_stream_map": "url_encoded_fmt_stream_map"
                        }
                    }
                };
                '''
    j_s_interpreter_0 = JSInterpreter(test_code)
    obj_name = 'ytplayer'
    res = j_s_interpreter_0.extract_object(obj_name)
    print(res)

test_JSInterpreter_extract_object()

# Generated at 2022-06-26 13:30:59.883665
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:31:08.345054
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter_0 = JSInterpreter(str_0_0)
    array_0 = [-0.01, -0.06, -0.002, -0.01, 0.0, -0.01]
    int_0 = -2
    func_0_0 = js_interpreter_0.build_function(array_0, int_0)
    dict_0 = {}
    dict_0['_'] = '0.9'
    dict_0['a'] = '0.01'
    dict_0['b'] = '0.001'
    dict_0['c'] = '0.1'
    dict_0['d'] = '0.002'
    dict_0['e'] = '0.1'
    dict_0['f'] = '0.1'
    dict

# Generated at 2022-06-26 13:31:10.259554
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter_0 = JSInterpreter("a=1;")
    js_interpreter_0.interpret_expression("a", {})


# Generated at 2022-06-26 13:31:19.309069
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    obj = '{video_id:"eUc0vU9o6sM",list:"PL_BpOwv1m3qrAvrBwmO97FmRojOg9YTZs",el:"detailpage",player:"https://www.youtube.com/watch?v=eUc0vU9o6sM"}'
    obj = {
        'video_id': "eUc0vU9o6sM",
        'list': "PL_BpOwv1m3qrAvrBwmO97FmRojOg9YTZs",
        'el': "detailpage",
        'player': "https://www.youtube.com/watch?v=eUc0vU9o6sM",
    }
    result = JSInterpreter.extract

# Generated at 2022-06-26 13:31:24.780877
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter = JSInterpreter("sample_text")
    code = "var a = 5;"
    argnames = []
    assert j_s_interpreter.build_function(argnames, code) == None
    code = "return 1 + 1;"
    argnames = []
    assert j_s_interpreter.build_function(argnames, code) == 2



# Generated at 2022-06-26 13:31:31.791035
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    function_name = r'function_name'
    function_code = r'function function_name(a, b) {return a+b;}'
    js_interpreter = JSInterpreter(function_code)
    assert js_interpreter.call_function(function_name, 1, 2) == 3

    function_name = r'function_name'
    function_code = r'function function_name(a, b) {return a+b;}'
    js_interpreter = JSInterpreter(function_code)
    assert js_interpreter.call_function(function_name, 1, 2) == 3

    function_name = r'function_name'
    function_code = r'function function_name(a, b) {return a+b;}'
    js_interpreter = JSInterpreter

# Generated at 2022-06-26 13:32:17.093455
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert JSInterpreter.build_function(['a', 'b'], 'return a + b')([1, 2]) == 3


# Generated at 2022-06-26 13:32:24.525637
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    funcname = 'test'
    args = tuple()

    float_0 = -297.1
    j_s_interpreter_0 = JSInterpreter(float_0)
    j_s_interpreter_0.call_function(funcname, *args)


# Generated at 2022-06-26 13:32:30.532194
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    float_0 = -297.1
    j_s_interpreter_0 = JSInterpreter(float_0)
    argnames_0 = "8 >='W`}y'\"*1lLQ"
    code_0 = 'Ai0h'
    resf_0 = j_s_interpreter_0.build_function(argnames_0, code_0)

# Generated at 2022-06-26 13:32:41.750771
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-26 13:32:43.866279
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code_0 = ''
    argnames_0 = []
    js_interpreter = JSInterpreter(code_0)
    js_interpreter.build_function(argnames_0, code_0)


# Generated at 2022-06-26 13:32:52.978497
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:33:02.507544
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    obj = {
        'foo': 1,
        'bar': 2,
        'baz': 3
    }

    interpreter = JSInterpreter('{foo:1,bar:2,baz:3}', objects={'obj': obj})
    assert interpreter.extract_object('obj') == obj


if __name__ == '__main__':
    import sys
    for c in (test_case_0, test_JSInterpreter_extract_object):
        print('Running %s...' % c.__name__)
        try:
            c()
        except AssertionError as ex:
            print('    Expected %r, got %r' % ex.args)
        except:
            import traceback
            traceback.print_exc()
            sys.exit(1)

# Generated at 2022-06-26 13:33:07.187661
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function getIntValue(value) {
            return value;
        }
        function getFloatValue(value) {
            return value;
        }
        '''
    j_s_interpreter_0 = JSInterpreter(code)
    j_s_interpreter_0.call_function("getIntValue", 1)
    j_s_interpreter_0.call_function("getFloatValue", 1.0)