

# Generated at 2022-06-26 13:23:57.079864
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = ';Dl)w8,gT+'
    str_1 = '<D9(\"Z.1\"+\"G\")'
    j_s_interpreter_0 = JSInterpreter(str_0)
    obj_0 = j_s_interpreter_0.extract_object('Sg')
    obj_1 = j_s_interpreter_0.extract_object('Sg')


# Generated at 2022-06-26 13:24:06.682960
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-26 13:24:14.425556
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    objects = dict()
    objects["XjhxC"] = list()
    print(objects)
    interp = JSInterpreter('', objects)
    local_vars = {
        'null': None,
        'i': 0,
    }
    assert interp.interpret_expression('"" + "")', local_vars, 100) == 'null'
    assert interp.interpret_expression('(false)', local_vars, 100) is False
    assert interp.interpret_expression('i', local_vars, 100) == 0
    assert interp.interpret_expression('XjhxC[1]', local_vars, 100) is None
    assert interp.interpret_expression('XjhxC.length', local_vars, 100) == 0

# Generated at 2022-06-26 13:24:25.047583
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter = JSInterpreter('abc')
    resf = j_s_interpreter.build_function(['a'], 'a[0]=1;return a')
    res = resf(['c'])
    assert res == ['1']
    resf = j_s_interpreter.build_function(['a'], 'a[0]=1;return a[0]')
    res = resf(['c'])
    assert res == 1

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:24:29.817503
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:24:35.912690
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    expr_0 = "['https', 'http'][1]"
    str_0 = ';Dl)w8,gT+'
    local_vars_0 = {'Array': Array}
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert j_s_interpreter_0.interpret_expression(expr_0, local_vars_0, 100) == 'http'


# Generated at 2022-06-26 13:24:36.600443
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert True

# Generated at 2022-06-26 13:24:42.372653
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'hello'
    j_s_interpreter_0 = JSInterpreter(str_0)
    try:
        assert j_s_interpreter_0.interpret_expression('h', {}) == 'hello'
    except Exception:
        raise AssertionError('Failed interpret expression test.')


if __name__ == '__main__':
    test_case_0()
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:24:49.006753
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-26 13:24:56.179557
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Private method, testing general functionality
    str_0 = 'var this.f=function(){};var a,b,c;return a;'
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert j_s_interpreter_0.interpret_statement(str_0, {})[0] == None

    str_0 = 'var a,b,c;return a;'
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert j_s_interpreter_0.interpret_statement(str_0, {})[0] == None

    str_0 = 'var a,b,c;return a;'
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert j_s_interpreter_0

# Generated at 2022-06-26 13:25:28.326352
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    j_s_interpreter_0 = JSInterpreter('var f1 = function(){var f2 = function(){return 2;}; return typeof f2; return 1;}')
    res = j_s_interpreter_0.interpret_statement('f1()', {})
    assert res[0] == 'function'


# Generated at 2022-06-26 13:25:33.980892
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'ux6yLK}/vq3'
    j_s_interpreter_0.extract_function(str_1)
    str_2 = 'g,'

    assert str_0 is not None
    assert str_1 is not None
    assert str_2 is not None



# Generated at 2022-06-26 13:25:45.423397
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:25:49.549403
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    str_0 = ';Dl)w8,gT+'
    str_1 = 'g.length'
    str_2 = 'g'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_3, bool_0 = j_s_interpreter_0.interpret_statement(str_1, {str_2: {'length': 0}})
    assert (str_3 == 0)
    assert (bool_0 == False)


# Generated at 2022-06-26 13:26:01.780882
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-26 13:26:04.599931
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    str_0 = ';Dl)w8,gT+'
    value_0 = 'w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    j_s_interpreter_0.extract_function(value_0)



# Generated at 2022-06-26 13:26:11.764697
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)

    obj = j_s_interpreter_0.extract_object('str_0')

    function_1_args = (0, 'Dl)w8,gT+')
    function_1_expect = '2a'
    function_1_actual = obj['function_1'](function_1_args)
    assert function_1_actual == function_1_expect

    function_2_args = (1, 'Dl)w8,gT+')
    function_2_expect = '51'
    function_2_actual = obj['function_2'](function_2_args)
    assert function_2_actual == function_2

# Generated at 2022-06-26 13:26:15.497333
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    expr = '6^4'
    objects = {'e4': '4'}
    interpreter = JSInterpreter(expr, objects)
    res = interpreter.interpret_expression(expr, {})
    assert res == 6^4


# Generated at 2022-06-26 13:26:25.138856
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    fname = 'test_function'
    argnames = ['arg1', 'arg2']
    code = 'arg1 = arg1 * 2'
    j_s_interpreter_0 = JSInterpreter('')
    resf = j_s_interpreter_0.build_function(argnames, code)
    assert 'resf' not in locals()
    assert resf(1, 2) == 2
    assert resf(5, 2) == 10
    assert resf(5, 3) == 10


# Generated at 2022-06-26 13:26:32.383000
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_string = '''(function(a){
        var b=a.split(""),
            f=b.length-1;
        return function(c){
            var d=f,
                e="";
            for(c=c||0;d>=0;d--){
                e+=b[d];
                if(0===d%c&&d!=f)
                    e+=" "
            }
            return e
        }
    })("ebgthjrvdvhgf");'''
    
    interpreter = JSInterpreter(test_string)
    result = interpreter.verbose_eval(test_string)
    assert result == "ucvitgfr hdvhjrvteb"

if __name__ == '__main__':
    test_JSInterpreter_interpret

# Generated at 2022-06-26 13:26:56.213773
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_code = '''
var test_code={
    "test_0": function(t){
        return t.split("")
    },
    "test_1": function(t){
        return t.join("+")
    },
    "test_2": function(t){
        return t.slice(0,1)
    },
    "test_3": function(t){
        return t.splice(0,1)
    }
};
    '''
    test_string = 'hello world'
    jsi = JSInterpreter(test_code)
    result = jsi.extract_object("test_code")["test_0"](test_string)
    assert result == ['h','e','l','l','o',' ','w','o','r','l','d']
    result = jsi

# Generated at 2022-06-26 13:27:01.433882
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinterpreter = JSInterpreter(
        'function foo(a,b){return a*b;}'
    )
    func = jsinterpreter.build_function(['a', 'b'], 'return a*b;')
    assert func == jsinterpreter.call_function
    assert func(['a', 'b'], (4, 2)) == 8


# Generated at 2022-06-26 13:27:10.169500
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:27:21.826938
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # The following code is wrapped inside a function to prevent the
    # interpreter from exiting (and deleting globals) before asserts are
    # executed.
    code = r'''
var i = {
    ac: function(a, b) {
        return a[b]
    },
    jh: function(a, b) {
        return a[b]
    },
    yb: function(a, b) {
        return a.he(b)
    },
    he: function(a) {
        return a
    }
};
i.ac([1, 2, 3], 2);
'''
    f = JSInterpreter(code).extract_function('i.ac')
    assert f([1, 2, 3], 2) == 3


# Generated at 2022-06-26 13:27:25.230658
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'o(!p){var p={};'
    # test for method extract_object of class JSInterpreter
    assert JSInterpreter(str_0).extract_object('n') is not None



# Generated at 2022-06-26 13:27:33.428516
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    s = '''
var str_0 = ';Dl)w8,gT+';
var j_s_interpreter_0 = new JsInterpreter(str_0);
'''
    js_interpreter = JSInterpreter(s)
    local_vars = {'str_0': ';Dl)w8,gT+', 'j_s_interpreter_0' : js_interpreter}
    exp = '''str_0.split('').reverse().join('')'''
    result = js_interpreter.interpret_expression(exp, local_vars)
    print('result: ', result)


test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:27:35.409368
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsinterp = JSInterpreter('')
    assert jsinterp.interpret_statement('var a = 1', {}) == (1, False)


# Generated at 2022-06-26 13:27:41.381384
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str0 = 'var _0xdc56=["split","length","join","slice","reverse","splice"];'
    str1 = """function(b,c){b=b-0x0;var a=_0xdc56[b];return a;};"""
    str2 = str0 + str1
    j_s_interpreter_0 = JSInterpreter(str2)
    res0 = j_s_interpreter_0.extract_object('_0xdc56')
    for i in range(0,len(res0)):
        assert res0[i] != None


# Generated at 2022-06-26 13:27:50.276187
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():

    assert JSInterpreter('1 + 1').interpret_expression('1 + 1', {}) == 2
    assert JSInterpreter('1 + 1').interpret_expression('(1 + 1)', {}) == 2
    assert JSInterpreter('1 + 1').interpret_expression('(1 + 1', {}) == None

    assert JSInterpreter('a + b').interpret_expression('a + b', {'a': 1, 'b': 2}) == 3
    assert JSInterpreter('a + b').interpret_expression('(a + b)', {'a': 1, 'b': 2}) == 3

    assert JSInterpreter('a + b').interpret_expression('"a" + "b"', {'a': 1, 'b': 2}) == 'ab'

# Generated at 2022-06-26 13:27:58.506868
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:28:27.342197
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert j_s_interpreter_0.extract_object(';Dl)w8,gT+') == {}
    str_1 = ';Dl)w8,gT+'
    j_s_interpreter_1 = JSInterpreter(str_1)
    assert j_s_interpreter_1.extract_object(';Dl)w8,gT+') == {}
    str_2 = ';Dl)w8,gT+'
    j_s_interpreter_2 = JSInterpreter(str_2)

# Generated at 2022-06-26 13:28:32.426137
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'dDQe'
    j_s_interpreter_0 = JSInterpreter(str_1)
    obj_0 = j_s_interpreter_0.extract_object("Ba")


# Generated at 2022-06-26 13:28:39.916149
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # code referenced in JS:
    # var l_0 = function(a_0, a_1, a_2)
    # {
    #     var out_0 = a_0[a_1] << a_2;
    #     return out_0;
    # }

    j_s_interpreter_0 = JSInterpreter('var l_0 = function(a_0, a_1, a_2){var out_0 = a_0[a_1] << a_2;return out_0;}')
    res_0 = j_s_interpreter_0.build_function(['a_0', 'a_1', 'a_2'], 'var out_0 = a_0[a_1] << a_2;return out_0;')

# Generated at 2022-06-26 13:28:51.175540
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'var ew=function(a){var b=a.split("");return b.reverse().join("")};'
    str_2 = '~vhh!%%@!Z(t)', 'lqt!%%@!Z(t)', '~vhh!%%@!Z(t)'
    str_3 = ''
    j_s_interpreter_0.code = (str_1 + str_2[0])
    j_s_interpreter_0.extract_function('ew')

# Generated at 2022-06-26 13:29:00.805970
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = 'function foo(a, b) {return a + b;}'
    str_1 = ';Dl)w8,gT+'
    str_2 = 'function foo(a, b) {return a + b;}'
    str_3 = 'function foo(a, b) {var x = a + b;}'
    str_4 = 'function foo(a, b) {var x = a + b;return x;}'
    str_5 = 'function foo(c, d) {var e = c + d;return e;}'
    j_s_interpreter_0 = JSInterpreter(str_0)
    j_s_interpreter_1 = JSInterpreter(str_1)
    j_s_interpreter_2 = JSInterpreter(str_2)
   

# Generated at 2022-06-26 13:29:02.113406
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    assert callable(JSInterpreter.call_function)


# Generated at 2022-06-26 13:29:14.267919
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-26 13:29:19.747597
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = {
            b: function(x, y) {
                return x + y
            },
            c: function(x, y) {
                return x - y
            }
        };
    """

    jsi = JSInterpreter(code)

    assert jsi.call_function('a.b', 1, 2) == 3
    assert jsi.call_function('a.c', 1, 2) == -1



# Generated at 2022-06-26 13:29:21.367977
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    j_s_interpreter = JSInterpreter('abcde')
    j_s_interpreter.call_function('dfdf')

# Generated at 2022-06-26 13:29:27.255159
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    local_vars = dict()
    str_1 = ';Dl)w8,gT+'
    str_2 = ';Dl)w8,gT+'
    allow_recursion = 0
    # test case for method interpret_statement of class JSInterpreter
    assert_equals(j_s_interpreter_0.interpret_statement(';Dl)w8,gT+', local_vars, allow_recursion=0),
                  (j_s_interpreter_0.interpret_statement(';Dl)w8,gT+', local_vars, allow_recursion=0), False))



# Generated at 2022-06-26 13:30:19.197016
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    argnames_0 = []
    code_0 = ';Dl)w8,gT+'
    f_0 = j_s_interpreter_0.build_function(argnames_0, code_0)
    args_0 = []
    f_0(args_0)


# Generated at 2022-06-26 13:30:24.013570
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    try:
        j_s_interpreter_0.call_function('_verify_token')
    except ExtractorError:
        pass
    else:
        assert False


# Generated at 2022-06-26 13:30:26.977537
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_0 = JSInterpreter(';Dl)w8,gT+')
    j_s_interpreter_0.extract_object('')


# Generated at 2022-06-26 13:30:36.452978
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)

    str_1 = ';Dl)w8,gT+'
    str_2 = ';Dl)w8,gT+'
    str_3 = ';Dl)w8,gT+'
    str_4 = ';Dl)w8,gT+'
    str_5 = ';Dl)w8,gT+'
    str_6 = ';Dl)w8,gT+'
    str_7 = ';Dl)w8,gT+'
    str_8 = ';Dl)w8,gT+'

# Generated at 2022-06-26 13:30:39.708794
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = ''
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert(j_s_interpreter_0.call_function(str_0,None,None) == None)


# Generated at 2022-06-26 13:30:44.949670
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var LT = {};
        LT["LT"] = {"1": "l56", "2": "l56"};'''

    js_interpreter_0 = JSInterpreter(code)
    obj = js_interpreter_0.extract_object('LT')

    assert obj['LT']['1'] == 'l56'
    assert obj['LT']['2'] == 'l56'


# Generated at 2022-06-26 13:30:52.221736
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = '5[(![]+"")[+[]]+([![]]+"")[[+!+[]]*[+[]]]+([][[]]+"")[[+!+[]]*[+[]]]](![]+"")[+!+[]]+(!![]+"")[!+[]+!+[]]+(!![]+"")[+[]]'
    j_s_interpreter_0 = JSInterpreter(str_0)


if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:30:59.316427
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = ';Dl)w8,gT+'
    list_0 = []
    j_s_interpreter_0 = JSInterpreter(str_0)
    list_0.append(j_s_interpreter_0.interpret_expression('function', {'function': 'string'}, 20))
    assert_equal(list_0[0], 'string')

    str_0 = ';Dl)w8,gT+'
    list_0 = []
    j_s_interpreter_0 = JSInterpreter(str_0)
    list_0.append(j_s_interpreter_0.interpret_expression('function', {'function': 'string'}, 20))
    assert_equal(list_0[0], 'string')


# Generated at 2022-06-26 13:31:03.406825
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    argnames = ['---']
    code = '$=a*y'
    assert j_s_interpreter_0.build_function(argnames, code)([2]) == 2


# Generated at 2022-06-26 13:31:06.305286
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_0 = JSInterpreter('return a() + b(c);')
    j_s_interpreter_0.extract_object('return a() + b(c);')


# Generated at 2022-06-26 13:31:46.554141
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    dict_0 = {}
    
    assert j_s_interpreter_0.interpret_expression('strng', dict_0, 99) == 'strng'
    str_1 = 'j.t(p+\'\',{id:i,e:e,mp:mp,mv:mv,h:h})'
    assert j_s_interpreter_0.interpret_expression(str_1, dict_0, 99) == 'j.t(p+\'\',{id:i,e:e,mp:mp,mv:mv,h:h})'

# Generated at 2022-06-26 13:31:54.082595
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = ';Dl)w8,gT+ var y1qk4 = {"4":function(a,b){return a*b}}'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'y1qk4'
    # Calling method extract_object of class JSInterpreter
    j_s_interpreter_0.extract_object(str_1)
    

# Generated at 2022-06-26 13:32:01.629815
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    funcname_0 = 'kq'
    j_s_interpreter_0.call_function(funcname_0)
    

# Generated at 2022-06-26 13:32:08.484815
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    args_0 = [
        'var a1=\'et\';',
        'var el2=\'rt/\';',
        'var d3="c";',
        "E('a2',d3+'o', 'a0'+el2+'b');",
        "a1+='n';",
        'a1+="i";',
        'd3+="s";',
        'a1+="a";',
        "E('a1',d3+'p:', 'c0'+el2+'b');"]

# Generated at 2022-06-26 13:32:19.639982
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # test 1
    str_0 = ';Dl)w8,gT+'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'var abc=new Array(17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34);'

# Generated at 2022-06-26 13:32:31.580972
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'var a;b=[1,2,0,3];d=5;a=b[d-5];'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'a'
    str_2 = 'b'
    str_3 = 'd'
    j_s_interpreter_0._objects[str_1] = None
    _list_0 = [1, 2, 0, 3]
    j_s_interpreter_0._objects[str_2] = _list_0
    j_s_interpreter_0._objects[str_3] = 5
    local_vars_0 = {}
    local_vars_0[str_1] = None
    local_vars_0[str_2] = _

# Generated at 2022-06-26 13:32:42.056928
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'iZpz0b.dKM(iZpz0b.Fc6 + iZpz0b.dQT);};'
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = 'iZpz0b.Fc6 + iZpz0b.dQT'
    dict_0 = dict()
    dict_0["iZpz0b.Fc6"] = [1, 2, 3]
    dict_0["iZpz0b.dQT"] = [4, 5, 6]

# Generated at 2022-06-26 13:32:52.583063
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    local_vars = {
        'a': 2,
        'b': 5,
        'c': [1, 2, 3],
        'd': 'abcde',
        'e': {'a': 1, 'b': 2},
    }
    j_s_interpreter_0 = JSInterpreter(';')
    j_s_interpreter_1 = JSInterpreter('function fe() { return 7; }')
    res = j_s_interpreter_1.interpret_expression('fe()', local_vars, 100)
    j_s_interpreter_2 = JSInterpreter('function fe() { return 8; }')
    j_s_interpreter_3 = JSInterpreter('function fe() { return 9; }')
    res = j_s_interpreter_3

# Generated at 2022-06-26 13:32:57.691166
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = 'function w(y){this.z=y};w(4);'
    j_s_interpreter_0 = JSInterpreter(str_0)
    out_0 = j_s_interpreter_0.call_function('w', (2, ))
    assert(out_0 == 2)


# Generated at 2022-06-26 13:33:11.044758
# Unit test for method build_function of class JSInterpreter