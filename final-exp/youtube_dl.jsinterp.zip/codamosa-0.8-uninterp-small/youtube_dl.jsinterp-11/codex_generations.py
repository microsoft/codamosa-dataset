

# Generated at 2022-06-26 13:23:57.964253
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    assert len(extract_object(dict_0, str_0)) == len(dict_0)
    assert not len(extract_object(dict_0, str_1))



# Generated at 2022-06-26 13:24:07.578949
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    dict_1 = None
    str_1 = None
    dict_2 = None
    # Creation of the local_vars dictionary
    dict_3 = {}
    dict_3["w"] = 16
    dict_3["cur"] = dict_2
    dict_2 = None
    dict_3["y"] = 12
    dict_3["x"] = 11
    dict_3["z"] = 13
    dict_3["arguments"] = None
    dict_3["return"] = None
    dict_3["a"] = dict_1
    dict_3["b"] = dict_0
    dict_3["c"] = 8
    dict_3["d"] = dict_1

# Generated at 2022-06-26 13:24:11.132196
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter(';')
    local_vars = {}
    res = j_s_interpreter_0.build_function(["x", "y"], "x + y")([1, 2])
    assert res == 3



# Generated at 2022-06-26 13:24:25.045334
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    dict_1 = 'print(a);'
    list_0 = ['a']
    str_0 = 'print'
    int_0 = 0
    str_1 = 'b'
    int_1 = 1
    list_1 = '1'
    list_2 = ['a', 'b', 'c']
    int_2 = 2
    str_2 = 'c'
    int_3 = 3
    dict_2 = 'a = b + c;'
    dict_3 = 'b = c - a;'
    dict_4 = 'c = 6;'
    dict_5 = 'a = 1;'
    dict_6 = 'b = 2;'
    dict_7 = 'c = 3;'
    dict_8 = 'a = b + 1;'

# Generated at 2022-06-26 13:24:27.231127
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)


# Generated at 2022-06-26 13:24:29.051139
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_case_0()

test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:24:39.538857
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    dict_1 = None
    j_s_interpreter_1 = JSInterpreter(dict_0, dict_1)
    
    local_vars = { 
        'a': 1, 
        'b': 2,
        'c': 3,
        'f': lambda x: x * 2,
    }

    for a in [j_s_interpreter_0, j_s_interpreter_1]:
        res, _ = a.interpret_statement('a', local_vars)
        assert res == 1
        res, _ = a.interpret_statement('b', local_vars)
        assert res == 2

# Generated at 2022-06-26 13:24:45.036723
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter("}")
    assert j_s_interpreter_0.build_function("}") == "}"
    j_s_interpreter_1 = JSInterpreter("}")
    assert j_s_interpreter_1.build_function("}") == "}"
    j_s_interpreter_2 = JSInterpreter("}")
    assert j_s_interpreter_2.build_function("}") == "}"


# Generated at 2022-06-26 13:24:48.281564
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    j_s_interpreter_0.extract_object("foo.bar")
    j_s_interpreter_0.extract_object("a.b.c")
    j_s_interpreter_0.extract_object("a.b")

# Generated at 2022-06-26 13:24:55.490962
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    int_0 = j_s_interpreter_0.interpret_expression("return (2 + 3) * 4;", dict_0, dict_0)
    assert 20 == int_0
    int_1 = j_s_interpreter_0.interpret_expression("return 2 + 3 * 4;", dict_0, dict_0)
    assert 14 == int_1
    int_2 = j_s_interpreter_0.interpret_expression("return 2 + 12 / 2 + 5;", dict_0, dict_0)
    assert 13 == int_2

# Generated at 2022-06-26 13:25:22.484740
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-26 13:25:30.361473
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    dict_0 = None
    dict_1 = {}; dict_1['a'] = 1; dict_1['b'] = 2; dict_1['c'] = 3; dict_1['d'] = 4; dict_1['e'] = 5; dict_1['f'] = 6
    dict_2 = {}; dict_2['a'] = 1; dict_2['b'] = 2; dict_2['c'] = 3; dict_2['d'] = 4; dict_2['e'] = 5; dict_2['f'] = 6
    dict_3 = {}; dict_3['a'] = 1; dict_3['b'] = 2; dict_3['c'] = 3; dict_3['d'] = 4; dict_3['e'] = 5; dict_3['f'] = 6
    dict_4 = {}; dict_

# Generated at 2022-06-26 13:25:33.804705
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter(None)
    j_s_interpreter_0.build_function([], 'abc = abc')
    j_s_interpreter_0.build_function([], 'abc = def; def = ghi')


# Generated at 2022-06-26 13:25:40.991740
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    expr_0 = "var a = 5; return a;"
    local_vars_0 = {}
    allow_recursion_0 = 100
    res_0 = j_s_interpreter_0.interpret_expression(expr_0, local_vars_0, allow_recursion_0)
    assert res_0 == 5


# Generated at 2022-06-26 13:25:44.952091
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = JSInterpreter("{p: 1};")

# Generated at 2022-06-26 13:25:56.536292
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_code_0 = """
                    var c;
                    c = '\\x' + 10;
                    function b(b) {
                    var c;
                    c = '\\x' + b;
                    a = c;
                    }
                    b(17);
                    return a;
                 """
    j_s_interpreter_0 = JSInterpreter(j_s_code_0)
    local_vars_0 = {'a': '', 'b': '', 'c': '' }
    #Called method: interpret_expression
    res_0 = j_s_interpreter_0.interpret_expression('a', local_vars_0,100)
    assert res_0 == '\x11', 'Wrong answer: expected: \x11, got: %r' % res_0
    return

# Generated at 2022-06-26 13:25:58.572256
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    print('Test: extract_object')

# Generated at 2022-06-26 13:26:02.530602
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    argnames = ['']
    code = ''
    d_t_a_t_e_0 = JSInterpreter(code)
    func_0 = d_t_a_t_e_0.build_function(argnames, code)


# Generated at 2022-06-26 13:26:08.801024
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():

    dict_0 = "var WMP = {};WMP.width = null;WMP.height = null;"
    j_s_interpreter_0 = JSInterpreter(dict_0)
    dict_1 = {"width": None, "height": None}
    assert j_s_interpreter_0.extract_object("WMP") == dict_1

    dict_0 = "var WMP = {};WMP.width = null;WMP.height = null;"
    j_s_interpreter_0 = JSInterpreter(dict_0)
    dict_1 = {"width": None, "height": None}
    assert j_s_interpreter_0.extract_object("WMP") == dict_1


# Generated at 2022-06-26 13:26:12.352370
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Test case 0
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    res_0 = j_s_interpreter_0.extract_object(objname='g_str_0')
    assert res_0 == dict()


# Generated at 2022-06-26 13:26:26.953668
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_case_0()


# Generated at 2022-06-26 13:26:33.487015
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-26 13:26:35.583431
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    assert JSInterpreter(dict_0).interpret_statement(str_1, dict_1) == (None, False)


# Generated at 2022-06-26 13:26:41.696256
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-26 13:26:53.062623
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:27:04.574189
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    l_0 = "var a = [1, 2, 3];"
    l_1 = "var b = a[0];"
    l_2 = "var c = a[1];"
    l_3 = "var d = a[2];"
    l_4 = "var e = a[3];"
    j_s_interpreter_0 = JSInterpreter(l_0)
    print(j_s_interpreter_0.interpret_expression(l_1, {}))
    print(j_s_interpreter_0.interpret_expression(l_2, {}))
    print(j_s_interpreter_0.interpret_expression(l_3, {}))
    print(j_s_interpreter_0.interpret_expression(l_4, {}))

# Unit test

# Generated at 2022-06-26 13:27:05.260895
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    assert JSInterpreter.call_function(None, None) is None


# Generated at 2022-06-26 13:27:05.766756
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    pass


# Generated at 2022-06-26 13:27:10.861665
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # 1st test case
    str_0 = "var v=document.getElementById(\"gc_captcha_token\").value;"
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(str_0, dict_0)
    str_1 = "v"
    dict_1 = {}
    str_2 = ""
    int_0 = 100
    tuple_0 = (str_1, dict_1, int_0)
    str_3 = j_s_interpreter_0.interpret_expression(*tuple_0)
    #print(str_3)
    #assert str_3 == ""
    # 2nd test case
    str_4 = "var  x = document.querySelector('div[class=\"large-thumb\"]')['style'].width;"


# Generated at 2022-06-26 13:27:18.043859
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    dict_0 = "var a=10, b=20; d=function(){return a;} e=function(){return b;}";
    j_s_interpreter_0 = JSInterpreter(dict_0)
    function_extracted = j_s_interpreter_0.extract_function("a");
    assert str(function_extracted).startswith('<function JSInterpreter.build_function.<locals>.resf')


# Generated at 2022-06-26 13:27:38.545847
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    function_0_code = "var a = (function() { try { return b.c } catch(e) { return 'd' } })()"
    test_func_0_args = []
    test_func_0 = JSInterpreter(function_0_code).build_function(test_func_0_args, function_0_code)
    assert test_func_0(None) == 'd'

    function_1_code = "var a = function() { try { return b.c } catch(e) { return 'd' } }"
    test_func_1_args = []
    test_func_1 = JSInterpreter(function_1_code).build_function(test_func_1_args, function_1_code)
    assert test_func_1(None) == 'd'

# Unit

# Generated at 2022-06-26 13:27:46.520264
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test case 1
    dict_0 = 'var c = function(a,b){return a+b};a = [1,2,3];return a[0]+c(1,2);'
    j_s_interpreter_0 = JSInterpreter(dict_0)
    res_0 = j_s_interpreter_0.interpret_statement(dict_0, {})
    assert res_0[0] == 4
    # Test case 2
    dict_1 = 'var a=b.foobar;return a(2)'
    j_s_interpreter_1 = JSInterpreter(dict_1, {b: {foobar(a): a * 2}})
    res_1 = j_s_interpreter_1.interpret_statement(dict_1, {})

# Generated at 2022-06-26 13:27:50.575480
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    dict_1 = None
    j_s_interpreter_1 = JSInterpreter(dict_1)
    assert j_s_interpreter_1.extract_function('test_extract_function') == 'test_extract_function'


# Generated at 2022-06-26 13:27:55.838939
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():

    # Create a sample JS code with a function
    code = r'''function f(a, b) {return a+b;};'''

    # Create a JSInterpreter to parse and execute the code
    interpreter = JSInterpreter(code)

    # Call function f with the given arguments
    result = interpreter.call_function('f', 3, 4)

    # Assert the result
    assert(result == 7)



# Generated at 2022-06-26 13:28:03.891668
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    dict_0 = "{\"1\":true, \"0\":false, \"true\":true, \"false\":false, \"null\":null}"
    j_s_interpreter_0 = JSInterpreter(dict_0)
    dict_1 = "{\"1\":true, \"0\":false, \"true\":true, \"false\":false}"
    j_s_interpreter_1 = JSInterpreter(dict_1)
    dict_2 = "{\"1\":true, \"0\":false, \"true\":true, \"false\":false, \"null\":1}"
    j_s_interpreter_2 = JSInterpreter(dict_2)
    dict_3 = "{\"1\":true, \"0\":false, \"true\":true, \"false\":false, \"null\":null,\"n\":null}"
    j_s_interpreter

# Generated at 2022-06-26 13:28:11.186233
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:28:20.575210
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print("Testing function: interpret_expression")
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    dict_1 = None
    j_s_interpreter_1 = JSInterpreter(dict_1)
    dict_2 = None
    j_s_interpreter_2 = JSInterpreter(dict_2)
    dict_3 = None
    j_s_interpreter_3 = JSInterpreter(dict_3)
    str_0 = "var var_0=1;var var_1=2;var_2=var_0+var_1"
    local_vars_1 = None
    local_vars_2 = None
    local_vars_3 = None
    local_vars_4 = None
    local_

# Generated at 2022-06-26 13:28:26.307689
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objname_0 = "test"
    code_0 = "test = {m: function(){return 1;}}"
    j_s_interpreter_0 = JSInterpreter(code_0)
    obj = j_s_interpreter_0.extract_object(objname_0)
    assert obj['m']() == 1


# Generated at 2022-06-26 13:28:33.161348
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:28:41.256776
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    j_s_interpreter_0 = JSInterpreter('')
    method_0 = j_s_interpreter_0.extract_function('func_0')
    method_0()
    j_s_interpreter_1 = JSInterpreter('')
    method_1 = j_s_interpreter_1.extract_function('func_1')
    method_1(None)
    j_s_interpreter_2 = JSInterpreter('')
    method_2 = j_s_interpreter_2.extract_function('func_2')
    method_2(None, None)


# Generated at 2022-06-26 13:29:00.405813
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:29:12.418121
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    class_str = '''
    var obj = {
        func_0: function(arg_0) {
            var_0 = arg_0;
            return var_0
        },
        func_1: function(arg_1, arg_2) {
            var_1 = arg_1;
            var var_2 = arg_2;
            var_2 += var_1;
            return var_2
        },
    };'''
    obj_name = 'obj'
    j_s_interpreter = JSInterpreter(class_str)
    obj = j_s_interpreter.extract_object(obj_name)
    assert obj['func_0'](10) == 10
    assert obj['func_1'](100, 50) == 150


# Generated at 2022-06-26 13:29:18.874583
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    dict_0 = '''abc.def = {ghi: function(a) { return a + 1; }, jkl: function() { return 1 + 2; }}'''
    j_s_interpreter_0 = JSInterpreter(dict_0)
    assert callable(j_s_interpreter_0.extract_object('abc')['def']['ghi'])
    assert isinstance(j_s_interpreter_0.extract_object('abc')['def']['jkl'], int)


# Generated at 2022-06-26 13:29:23.824591
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():

    # Test for function call signature: call_function ( funcname, ) ->
    #     Dict[str, Any]

    # Local variable assignments:
    dict_0 = None
    str_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    func_0 = j_s_interpreter_0.call_function(str_0)


# Generated at 2022-06-26 13:29:27.374371
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = "a = 10"
    js_interpreter = JSInterpreter(code)
    local_vars = {}
    allow_recursion = 100
    statement = js_interpreter.interpret_expression(code, local_vars, allow_recursion)
    assert statement == 10


# Generated at 2022-06-26 13:29:36.569342
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    # arg1: expression to be evaluated
    # arg2: local variables to be used in expression
    # arg3: allow recursion of the method
    # output: value of evaluated expression
    out = j_s_interpreter_0.interpret_expression('var a = 3',{},100) 
    assert out == None
    out = j_s_interpreter_0.interpret_expression('6',{'a':3},100) 
    assert out == 6
    out = j_s_interpreter_0.interpret_expression('a',{'a':3},100)
    assert out == 3

# Generated at 2022-06-26 13:29:41.697406
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    local_vars_0 = None
    var_0 = None
    should_abort_0 = None
    var_1 = j_s_interpreter_0.interpret_statement(
        var_0, local_vars_0, should_abort_0)


# Generated at 2022-06-26 13:29:49.311444
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    dict_0 = "var a;\na = 1;\nvar b;\nb = 2;\na + b;"
    dict_1 = {}
    dict_2 = {}
    dict_2['a'] = 1
    dict_1['a'] = dict_2
    dict_2 = {}
    dict_2['b'] = 2
    dict_1['b'] = dict_2
    dict_1['a'] = 1
    dict_1['b'] = 2
    j_s_interpreter_1 = JSInterpreter(dict_0, dict_1)
    dict_0 = "a + b"
    dict_1 = {}
    dict_2 = {}
    dict_2['a'] = 1
    dict_1['a'] = dict_2
    dict_2 = {}

# Generated at 2022-06-26 13:29:59.155565
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    dict_0 = 'function c(a)\r\n{\r\nvar b=a.substr(1);\r\na=a[0]+b;\r\nb=parseInt(a.substr(0,2),16);\r\na=a.substr(2);\r\nfor (e=2;e<a.length;e+=2)\r\n{\r\n\td=parseInt(a.substr(e,2),16)^b;\r\n\tc+=String.fromCharCode(d);\r\n}\r\nreturn c;\r\n}'
    j_s_interpreter_0 = JSInterpreter(dict_0)

# Generated at 2022-06-26 13:30:06.988693
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test_expression(self, expr_str, expected):
        result = self.interpret_expression(expr_str)
        assert result == expected

    def test_statement(self, stmt_str, expected):
        result, _ = self.interpret_statement(stmt_str)
        assert result == expected

    jsi = JSInterpreter(
        '\n'.join([
            'var b = function (c) {\n      return a[1] + c;\n    };',
            'var a = [2, 3];\n    ',
            'var thisIsAFunction = function (argie) { return argie; }',
            'function foo(argie) { return argie; }',
        ]),
        {'a': [1, 2, 3]})


# Generated at 2022-06-26 13:30:32.173969
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    dict_0 = 'var s="";for(i=0;i<this.length;i+=2){s+=String.fromCharCode(parseInt(this.substr(i,2),16))}return s;'
    j_s_interpreter_0 = JSInterpreter(dict_0)
    s = '612064206e646f6d207374796c652e636f6d2047656e657261746f722e636f6d2057696e646f77732066726f6d205061636b61726420537065636966696320546f74616c537570706f72742046524f4d205368617265686f6c6465727320312e302e302d30312d6775616e677a'

# Generated at 2022-06-26 13:30:41.479327
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)

# Generated at 2022-06-26 13:30:46.110232
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():

    # Setup
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)

    # Test
    test_function_0 = j_s_interpreter_0.build_function(['x'], 'x = 99; return x;')

    # Verify
    assert 99 == test_function_0(['99'])



# Generated at 2022-06-26 13:30:53.749938
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    dict_0 = "{'var2': 3, 'var1': 1, 'var3': 1 + 2, 'var4': var1 + var2, 'var5': var1, 'var6': var4}"
    j_s_interpreter_0 = JSInterpreter(dict_0)
    dict_1 = "{'var1': 1, 'var2': 3}"
    list_0 = [dict_0, dict_1]
    list_1 = [1, 3]
    for i in range(2):
        j_s_interpreter_0.build_function(list_0[i], list_1[i])


# Generated at 2022-06-26 13:30:54.978428
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    JSInterpreter(dict_0).build_function(None, None)


# Generated at 2022-06-26 13:30:58.962339
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    dict_0 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    j_s_interpreter_0 = JSInterpreter(dict_0)
    assert j_s_interpreter_0.code == dict_0
    # Test case 0
    try:
        j_s_interpreter_0.build_function(None, None)
    except ExtractorError as e:
        assert True
    else:
        assert False
    # Test case 1
    try:
        j_s_interpreter_0.build_function([], [])
    except ExtractorError as e:
        assert True
    else:
        assert False
    # Test case 2

# Generated at 2022-06-26 13:31:02.682681
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert(JSInterpreter.interpret_expression("a") == "a")
    assert(JSInterpreter.interpret_expression("a[3]") == "a[3]")
    assert(JSInterpreter.interpret_expression("var a") == "var a")
    assert(JSInterpreter.interpret_expression("var [a]") == "var [a]")

# Generated at 2022-06-26 13:31:06.076848
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    result = j_s_interpreter_0.interpret_expression(dict_0, dict_0)
    assert result == None


# Generated at 2022-06-26 13:31:14.120979
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    str0 = '''var a1 = function(){};'''
    str1 = '''function a1(){};'''
    str2 = '''a1 = function(){};'''
    f = j_s_interpreter_0.build_function(['a'], 'a=a+b;')
    f(['1'])
    try:
        f(['1 2'])
    except:
        pass
    else:
        raise RuntimeError('AssertionError')
    f = j_s_interpreter_0.build_function(['a'], 'a=a+b; b=2;')
    f(['1'])
    f = j_s_interpreter_

# Generated at 2022-06-26 13:31:20.956775
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    for x in range(20):
        try:
            # Verify behavior for inputs of 10 and 20
            if x == 10:
                test = 10
            elif x == 20:
                test = 10
            else:
                test = 10
            # Verify that the interpreter returns the correct result
            result = test_JSInterpreter_interpret_expression_helper(x)
            assert result == test
        except:
            raise Exception("Test case failed for 'test_JSInterpreter_interpret_expression'")



# Generated at 2022-06-26 13:31:56.288283
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    dictionary_compile = None
    j_s_interpreter_0 = JSInterpreter(dictionary_compile)
    list_0 = ['fc']

# Generated at 2022-06-26 13:32:04.739321
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    c = {'': {'a': 'b', 'c': 'd'},
         'a': 'b',
         'c': 'd',
         }
    for code, objname, e_obj in c.items():
        j_s_interpreter_0 = JSInterpreter(code)
        assert j_s_interpreter_0.extract_object(objname) == e_obj


# Generated at 2022-06-26 13:32:08.873808
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    _input = "var a = { a: function() { return 5; } }; function(a){ return a*11; }"
    dict_0 = _input
    j_s_interpreter_0 = JSInterpreter(dict_0)


# Generated at 2022-06-26 13:32:12.183576
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)



# Generated at 2022-06-26 13:32:13.410613
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    j_s_interpreter_0 = JSInterpreter(None)
    j_s_interpreter_0.call_function(None)


# Generated at 2022-06-26 13:32:14.911087
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    dict_0 = None
    j_s_interpreter_0 = JSInterpreter(dict_0)
    j_s_interpreter_0.extract_object('foobar')


# Generated at 2022-06-26 13:32:17.783661
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j = JSInterpreter('function f(a,b){return a+b}')
    f = j.build_function(['a', 'b'], 'return a+b')
    assert f([1, 2]) == 3


# Generated at 2022-06-26 13:32:31.002848
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''var a = 'test';
            var b = false;
            var c = 'testa';
            var d = true;
        ''';
    local_vars = {};

    # testing that the method throws an error when passed an invalid expression
    try:
        j_s_interpreter_2 = JSInterpreter(code);
        j_s_interpreter_2.interpret_expression('var a = "test"', local_vars, 1000);
    except ExtractorError:
        return;

    code = '''var a = 'test';
            var b = false;
            var c = 'testa';
            var d = true;
        ''';
    local_vars = {};

    # testing that the method throws an error when passed an invalid expression

# Generated at 2022-06-26 13:32:39.452813
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_code = 'var x = 32;'
    test_dict = None
    test_interpreter = JSInterpreter(test_code, test_dict)
    test_local_vars = {}
    test_expression = 'x << 2'
    test_allow_recursion = 0
    expected_interpretation = 128
    actual_interpretation = test_interpreter.interpret_expression(test_expression, test_local_vars, test_allow_recursion)
    assert expected_interpretation == actual_interpretation


# Generated at 2022-06-26 13:32:48.068168
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    dict_0 = None
    source = "var c = function(a,b) { {var b=b;return a?b:c} };c();"
    j_s_interpreter_0 = JSInterpreter(source)
    func_0 = j_s_interpreter_0.interpret_expression(dict_0, dict_0)
