

# Generated at 2022-06-26 13:24:13.967106
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test case 0
    str_0 = "\td +'"
    j_s_interpreter_0 = JSInterpreter(str_0)
    assert(len(j_s_interpreter_0._functions) == 0)
    # Test case 1
    str_1 = "var WjQ=function(a,b){return a<b?-1:a>b?1:0};var d;"
    j_s_interpreter_1 = JSInterpreter(str_1)
    assert(len(j_s_interpreter_1._functions) == 1)


# Generated at 2022-06-26 13:24:20.532249
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    try:
        test_case_0()
    
    except AssertionError as e:
        raise AssertionError(str(e))
    except:
        import traceback
        raise Exception(traceback.format_exc())

# Run unit tests
if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-26 13:24:31.934127
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    print("Testing JSInterpreter.interpret_statement")
    str_0 = "\ts.split("
    str_1 = "\t})"

# Generated at 2022-06-26 13:24:37.071817
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = "\td +'"
    j_s_interpreter_0 = JSInterpreter(str_0)
    resf = j_s_interpreter_0.build_function(["a", "b", "c"], "var d = a + b; d + c")
    assert resf([1, 2, 3]) is 6

# Generated at 2022-06-26 13:24:45.527414
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter("\td +'")
    j_s_interpreter_1 = JSInterpreter("\td +'")
    j_s_interpreter_2 = JSInterpreter("\td +'")
    j_s_interpreter_3 = JSInterpreter("\td +'")
    j_s_interpreter_4 = JSInterpreter("\td +'")
    j_s_interpreter_5 = JSInterpreter("\td +'")
    j_s_interpreter_6 = JSInterpreter("\td +'")
    j_s_interpreter_7 = JSInterpreter("\td +'")
    j_s_interpreter_8 = JSInterpreter("\td +'")
   

# Generated at 2022-06-26 13:24:48.689480
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    str_1 = 'function foobar(a,b){return a + b};'
    j_s_interpreter_1 = JSInterpreter(str_1)
    foobar = j_s_interpreter_1.extract_function('foobar')
    assert foobar([1,2]) == 3
    assert foobar([2,2]) == 4


# Generated at 2022-06-26 13:24:50.344898
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = "\td +'"
    j_s_interpreter_0 = JSInterpreter(str_0)


# Generated at 2022-06-26 13:24:52.003777
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    for test_case in [test_case_0]:
        j_s_interpreter = test_case()


# Generated at 2022-06-26 13:24:58.814287
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-26 13:25:05.521828
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = "var Na=NaN;var err=Error;var name2=NameError;var char2=TypeError;var namez=name;var __not_in_base__=Error;var obj=Object;"
    j_s_interpreter_0 = JSInterpreter(str_0)
    try:
        j_s_interpreter_0.extract_object(j_s_interpreter_0, str_0)
    except Exception as e:
        print(str(e))
    try:
        j_s_interpreter_0.extract_object(j_s_interpreter_0, str_0)
    except Exception as e:
        print(str(e))

# Generated at 2022-06-26 13:25:29.701807
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:25:36.789274
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = "var example= {\n\t\"1\":function(abc){\n\t\treturn 1+abc;\n\t},\n\t\"2\":function(abc){\n\t\treturn abc;\n\t}\n}"
    j_s_interpreter_0 = JSInterpreter(str_0)
    try:
        j_s_interpreter_0.extract_object("example")
    except ExtractorError as e:
        print(e)



# Generated at 2022-06-26 13:25:42.000207
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = "\td +'"
    funcname_0 = 'x_0'
    j_s_interpreter_0 = JSInterpreter(str_0)
    argnames_0 = [0, 1]
    code_0 = ',"'
    j_s_interpreter_0.build_function(argnames_0, code_0)


# Generated at 2022-06-26 13:25:45.567920
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    try:
        test_case_0()
    except ExtractorError as e:
        print("ExtractorError: " + str(e))
        assert(False)
    assert(True)


# Generated at 2022-06-26 13:25:51.314680
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:26:03.382285
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = "var f = function(){};"
    j_s_interpreter_0 = JSInterpreter(str_0)
    j_s_interpreter_0.call_function("f");
    str_1 = "var f = function(a){return a;};"
    j_s_interpreter_1 = JSInterpreter(str_1)
    assert j_s_interpreter_1.call_function(
        "f", "v") == "v", 'assert value == "v"'
    str_2 = "var f = function(a,b){return a+b;};"
    j_s_interpreter_2 = JSInterpreter(str_2)

# Generated at 2022-06-26 13:26:07.766054
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    func_code = "var x=window.navigator.appVersion.match(/Chrome\\/.(\\d+)\\.(\\d+)\\.(\\d+)\\.(\\d+)/);return parseInt(x[1],10);"
    argnames = "window".split(',')
    j_s_interpreter_0 = JSInterpreter(func_code)
    f = j_s_interpreter_0.build_function(argnames, func_code)
    assert f(["dummy"]) == 65


# Generated at 2022-06-26 13:26:13.078815
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    obj_0 = {}
    int_0 = JSInterpreter.interpret_expression('d +"', obj_0)
    str_1 = "var d='\\';"
    obj_0 = {}
    int_1 = JSInterpreter.interpret_expression(str_1, obj_0)
    str_2 = "var d='\\\"';"
    obj_0 = {}
    int_2 = JSInterpreter.interpret_expression(str_2, obj_0)


# Generated at 2022-06-26 13:26:26.192978
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:26:28.158546
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter("")

# Generated at 2022-06-26 13:26:45.691368
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = "\td +'"
    j_s_interpreter_0 = JSInterpreter(str_0)


# Generated at 2022-06-26 13:26:47.902270
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = "\td +'"
    j_s_interpreter_0 = JSInterpreter(str_0)


# Generated at 2022-06-26 13:26:55.908811
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'd=function(a){a=a.split("");a.reverse();return a.join("");};'
    obj_name_0 = 'd'
    j_s_interpreter_0 = JSInterpreter(str_0)
    method_0 = j_s_interpreter_0.extract_object
    args = (obj_name_0)
    try:
        if method_0(*args) is None:
            raise Exception("Object not extracted")
    except Exception as e:
        print(e)


# Generated at 2022-06-26 13:27:06.749733
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = "{'a':-1330268906,'b':-1151765292,'c':-761453585,'d':1727385850,'e':-1274388848};"
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = "{'a':-786759037,'b':-1466371051,'c':-1419773245,'d':-1333188681,'e':-1047337496};"
    j_s_interpreter_1 = JSInterpreter(str_1)
    str_2 = "{'a':1539687905,'b':-1622270062,'c':-2028308510,'d':-1611912097,'e':-1196235182};"
    j_s

# Generated at 2022-06-26 13:27:07.895198
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert hasattr(JSInterpreter, "build_function")


# Generated at 2022-06-26 13:27:10.882394
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter.interpret_expression(1, 2, 3) == 3
    assert JSInterpreter.interpret_expression('str', 2, 3) == 2
    assert JSInterpreter.interpret_expression('str', 'str2', 3) == 3
    assert JSInterpreter.interpret_expression('str', 'str2', 'str3') == 'str3'


# Generated at 2022-06-26 13:27:16.788523
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def some_function(argnames, code):
        return 'some_function'

    j_s_interpreter_0 = JSInterpreter("")
    j_s_interpreter_0.build_function = some_function

    assert j_s_interpreter_0.call_function('some_function', 'a', 'b') == 'some_function'


# Generated at 2022-06-26 13:27:20.039290
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'function a(b){var c=d;}'
    j_s_interpreter_0 = JSInterpreter(str_0)


# Generated at 2022-06-26 13:27:23.983421
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    execfile("test_case_0.py")
    try:
        # Test case where result is a int
        assert(j_s_interpreter_0.call_function("d") == 0)
    except Exception:
        print("AssertionError")


# Generated at 2022-06-26 13:27:33.349382
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = "var c, a = c.length, d = '';\n}}}}}}}}}return d"
    j_s_interpreter_0 = JSInterpreter(str_0)
    str_1 = "var b, c, d = '', e;\nfor (b = c.length;b > 0;b--)"
    args_1 = ["abc", "def"]
    result_1 = j_s_interpreter_0.build_function(args_1, str_1)
    assert result_1(args_1) == "defcba"
    args_2 = ["abc", "def"]
    result_2 = j_s_interpreter_0.build_function(args_2, str_0)
    assert result_2(args_2) == "cba"
   

# Generated at 2022-06-26 13:28:05.075477
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'Object'
    str_1 = 'Object'
    str_2 = 'Object'
    str_3 = 'hello'
    str_4 = 'Object'
    str_5 = 'Object'
    str_6 = 'Object'
    str_7 = 'str_7'
    str_8 = 'str_8'
    str_9 = 'str_9'
    str_10 = 'str_10'
    str_11 = 'str_11'
    str_12 = 'Object'
    str_13 = 'Object'
    str_14 = 'Object'
    str_15 = 'Object'
    str_16 = 'Object'
    str_17 = 'Object'
    str_18 = 'Object'
    str_19 = 'Object'
    str_20 = 'Object'


# Generated at 2022-06-26 13:28:10.551345
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Declare the global variables
    global str_0
    # Initialize global variables
    str_0 = 'build_function'
    # Declare test input parameters
    argnames = []
    code = ''
    # Declare the expected outputs
    expected_0 = None
    # Get the actual output
    actual_0 = test_case_0()
    # Verify the output
    assert expected_0 == actual_0
    # Print test result
    print('test case 0: ok')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:28:11.797258
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter(str_0)
    jsi.interpret_expression()

    return


# Generated at 2022-06-26 13:28:22.736389
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    str_0 = 'build_function'
    str_1 = 'var a=true;'
    str_2 = 'a = false;'
    str_3 = 'return;'
    str_4 = 'return 5;'
    str_5 = 'return a;'
    str_6 = 'a = b = true;'
    str_7 = 'c = a = b = true;'
    str_8 = 'a = (5 + 4) * 10;'
    str_9 = 'a = 5 * 4 * 10;'
    str_10 = 'a = 5 * (4 * 10);'
    str_11 = 'a = b = c = 5;'
    str_12 = 'a = b = c + 5;'
    str_13 = '(a = b) = c = 5;'
   

# Generated at 2022-06-26 13:28:27.915415
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    global str_0
    try:
        str_0 = 'build_function'
        func_name = 'a'
        js_interpreter_obj = JSInterpreter(str_0)
        res = js_interpreter_obj.extract_object(func_name)
    except Exception as e:
        print(e)
        assert False
    else:
        print(res)
        assert True



# Generated at 2022-06-26 13:28:31.052580
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter(code=str_0)
    
    expr = test_case_0() #
    local_vars = dict() #
    
    js_interpreter.interpret_expression(expr=expr, local_vars=local_vars)

# Generated at 2022-06-26 13:28:39.828727
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert test_JSInterpreter_interpret_expression.__doc__ != None
    assert __name__ != "__main__"  # Used for unit testing
    js = JSInterpreter('var a1 = {a: function() {return 1}}')
    assert js.interpret_expression('a1[a]', {}) == 1
    assert js.interpret_expression('a1.a', {}) == 1
    assert js.interpret_expression('a1["a"]', {}) == 1
    js = JSInterpreter('var a2 = {a: function(a) {return a + 1}}')
    assert js.interpret_expression('a2[a](5)', {}) == 6
    assert js.interpret_expression('a2["a"](5)', {}) == 6

# Generated at 2022-06-26 13:28:51.124769
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        function f(a, b) {
            return a + b;
        }
    '''
    jsi = JSInterpreter(code)
    assert jsi.interpret_expression('f(1, 2)', {}) == 3

    code = '''
        function f(a, b) {
            return a + b + globalVar;
        }
        var globalVar = 3;
    '''
    jsi = JSInterpreter(code)
    assert jsi.interpret_expression('f(1, 2)', {}) == 6
    assert jsi.interpret_expression('globalVar', {}) == 3

    code = '''
        function f(a, b) {
            var res = a + b;
            return res;
        }
        var globalVar = 3;
    '''


# Generated at 2022-06-26 13:28:56.621175
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'build_function'
    str_1 = 'code'
    ji_0 = JSInterpreter(str_0)
    def fn_0(arg_0):
        str_2 = 'result'
        str_3 = 'arg_0'
        ji_0.build_function({str_2}, {str_3})


# Generated at 2022-06-26 13:29:02.282459
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    #Input params
    funcname = 'abc'
    argnames = ['name', 'phone']
    code = '\n        return name + phone;\n    '
    interpreter = JSInterpreter('')
    result = interpreter.build_function(argnames, code)
    print(result)

if __name__ == '__main__':
    #test_case_0()
    test_JSInterpreter_build_function()

# Generated at 2022-06-26 13:29:17.882075
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'build_function'


# Generated at 2022-06-26 13:29:19.958148
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('')
    res = js.build_function(str_0,str_0)
    assert 'function' == res


# Generated at 2022-06-26 13:29:20.839633
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_case_0()


# Generated at 2022-06-26 13:29:23.481861
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    print('Test case 0')
    str_0 = 'build_function'
    print('\tCalled _function', 'build_function')

    print('\n')

# Generated at 2022-06-26 13:29:30.589639
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    str_0 = 'build_function'
    str_1 = 'interpret_statement'
    str_2 = 'interpret_expression'
    str_3 = 'function'
    str_4 = 'interpret_expression'
    str_5 = 'interpret_expression'
    str_6 = 'interpret_expression'
    str_7 = 'interpret_expression'
    str_8 = 'interpret_expression'
    str_9 = 'interpret_expression'
    str_10 = 'interpret_expression'
    str_11 = 'interpret_expression'
    str_12 = 'interpret_expression'
    str_13 = 'interpret_expression'
    str_14 = 'interpret_expression'
    str_15 = 'interpret_expression'
    str_16 = 'interpret_expression'
    str_17 = 'interpret_expression'
    str_

# Generated at 2022-06-26 13:29:36.332491
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    src = '''
        a1 = {
            "a": function(p){},
            "b": function(p, q){return p + q;},
            "c": function(p){return p + 1;}
        };
    '''

    obj = JSInterpreter(src).extract_object('a1')
    assert obj['b'](3, 5) == 8
    assert obj['c'](9) == 10


# Generated at 2022-06-26 13:29:45.488714
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    str_0 = 'build_function'
    str_1 = 'str_0'
    local_vars = {str_0 : 'build_function'}
    assert local_vars[str_0] == 'build_function'

    str_2 = 'local_vars'
    assert local_vars[str_2] == 'build_function'

    str_3 = 'args'
    local_vars[str_3] = 'args'
    assert local_vars[str_3] == 'args'

    str_4 = 'local_vars'
    assert local_vars[str_4] == 'args'

    str_5 = 'code'
    local_vars[str_5] = 'code'
    assert local_vars[str_2] == 'code'


# Generated at 2022-06-26 13:29:50.477311
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    def test_func(args):
        return args[0] + args[1]
    je = JSInterpreter(None, {'test_func': test_func})
    assert je.call_function('test_func', 4, 5) == 9
    assert je.call_function('test_func', 'a', 'b') == 'ab'
    assert je.call_function('test_func', 'a', 3) == 'a3'
    assert je.call_function('test_func', [], [3]) == [3]


# Test cases for JSInterpreter from decrypt-youtube-signature.js

# Generated at 2022-06-26 13:29:56.294839
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r'''
var _kve = {
    decode: function(t) {
        t = t.split("");
        for (var e, n = 0, o = t.length; o > n; ++n) o > n + 1 && 55296 == (64512 & (e = 65536 + (t[n].charCodeAt(0) - 55296 << 10) + (t[++n].charCodeAt(0) - 56320))) && (t[n] = e, t[n - 1] = e >> 16), t[n] = t[n].charCodeAt(0);
        return t
    }
}
'''
    obj = JSInterpreter(code).extract_object('_kve')
    assert obj['decode']('abc') == [97, 98, 99]

# Unit

# Generated at 2022-06-26 13:29:57.683236
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinterpreter = JSInterpreter()
    jsinterpreter.build_function()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:30:46.147425
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Test case for method extract_object of class JSInterpreter

    obj1 = {
        'val1': {
            'val2': 'test_value'
        }
    }
    obj2 = {
        'func1': lambda arg: arg
    }
    obj3 = {
        'val1': 1,
        'func2': lambda a, b: a * b
    }

    # There is a function inside an object and the function calls another function inside another object.

# Generated at 2022-06-26 13:30:50.267888
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('function ' + str_0)
    assert (
        js_interpreter.call_function('build_function') == build_function()
    ), 'test_JSInterpreter_call_function failed'



# Generated at 2022-06-26 13:30:57.405982
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = 'call_function'
    str_1 = '''
    function call_function(a, b) {
        return a(b);
    }
    '''
    js = JSInterpreter('')
    js._functions['call_function'] = js.build_function(['a', 'b'], str_1)
    str_2 = '''
    function sum_2(a, b) {
        return a + b;
    }
    '''
    js._functions['sum_2'] = js.build_function(['a', 'b'], str_2)
    str_3 = '''
    function sum_3(a, b, c) {
        return a + b + c;
    }
    '''

# Generated at 2022-06-26 13:30:59.438484
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    interpreter = JSInterpreter(str_0)
    assert interpreter.call_function('build_function') == None
    return 0


# Generated at 2022-06-26 13:31:00.995627
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'interpreting JS expression'
    str_1 = 'hello world'


# Generated at 2022-06-26 13:31:09.422433
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Test 0
    #
    str_0 = 'call_function'
    str_1 = 'code'
    str_2 = 'funcname'
    str_3 = 'args'
    str_4 = 'resf'
    #
    str_5 = 'build_function'
    #
    str_6 = 'code'
    str_7 = 'argnames'
    str_8 = 'resf'
    #
    str_9 = 'local_vars'
    str_10 = 'stmt'
    str_11 = 'res'
    str_12 = 'abort'
    #
    str_13 = 'python'
    str_14 = 'python'
    str_15 = 'python'
    str_16 = 'python'
    str_17 = 'python'
    str_18

# Generated at 2022-06-26 13:31:17.564790
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'reverse'
    str_1 = 'splice'
    str_2 = 'split'
    str_3 = 'join'
    str_4 = 'slice'
    str_5 = 'return'
    str_6 = 'return'
    str_7 = 'return'
    str_8 = 'return'
    str_9 = 'return'
    str_10 = 'return'
    str_11 = 'return'
    str_12 = 'return'
    str_13 = 'return'
    str_14 = 'return'
    str_15 = 'return'
    str_16 = 'return'
    str_17 = 'return'
    str_18 = 'return'
    str_19 = 'return'
    str_20 = 'return'
    str_21 = 'return'


# Generated at 2022-06-26 13:31:24.743838
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    from .common import JS_EXAMPLE
    from .utils import js_to_json
    def test(objname):
        interpreter = JSInterpreter(JS_EXAMPLE)
        obj = interpreter.extract_object(objname)
        assert obj == js_to_json('%s = {%s}' % (objname, JS_EXAMPLE.split(objname, 1)[1].split('}', 1)[0] + '}'))
    test('swfArgs')


# Generated at 2022-06-26 13:31:26.995152
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    c = JSInterpreter("""
        function f()
        {
            var base64_alphabet = [];
        }
    """)
    assert c.interpret_statement("""
        var base64_alphabet = [];
    """, {}) == ([], False)
    assert c.interpret_statement("""
        return base64_alphabet;
    """, {}) == ([], True)


# Generated at 2022-06-26 13:31:29.544078
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # test_case_0
    str_0 = 'build_function'
    js_interpreter = JSInterpreter(str_0)


# Generated at 2022-06-26 13:31:53.068812
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    _local_vars =  { 'str_0': 'str$0' }
    _exp = 'build_function'
    _interpret_expression = JSInterpreter('').interpret_expression(
        _exp, _local_vars, 100)
    _expected = test_case_0()
    assert _interpret_expression == _expected


# Generated at 2022-06-26 13:32:02.970715
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Initialize a object
    js = JSInterpreter(str_0)
    stmt = test_case_0()
    local_vars = {}
    allow_recursion = 100
    result = js.interpret_statement(stmt, local_vars, allow_recursion)
    assert result[0] == 'build_function'
    assert result[1] == False


# Generated at 2022-06-26 13:32:04.893639
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    interpreter = JSInterpreter('build_function')
    interpreter.call_function('build_function')


# Generated at 2022-06-26 13:32:08.497403
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    s = JSInterpreter('')
    s.interpret_expression('(function() { 0; })()', {})

# Generated at 2022-06-26 13:32:10.021595
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''build_function(){}'''
    argnames = []
    obj = JSInterpreter(code)
    assert obj.build_function(argnames, code)


# Generated at 2022-06-26 13:32:16.219136
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter(test_case_0(), {})
    assert js_interpreter.interpret_statement({'name': 'build_function', 'args': [{'name': 'argnames', 'args': []}, {'name': 'code', 'args': []}]}, {}) == {}


# Generated at 2022-06-26 13:32:20.780935
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    expr = None
    local_vars = None
    allow_recursion = None
    JSInterpreter.interpret_expression(expr, local_vars, allow_recursion)


# Generated at 2022-06-26 13:32:31.940908
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Input params for the test
    objname = 'str_0'
    
    # Expected output from the tested function

# Generated at 2022-06-26 13:32:37.311590
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = r'''
        var obj = {func: function(arg1, arg2){
            return arg1 + arg2;
        }};
    '''
    jsi = JSInterpreter(code)
    jsi.interpret_expression('obj.func(1, 2)')


# Generated at 2022-06-26 13:32:41.869224
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_case_0()

# Unit test entry
if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-26 13:33:11.660126
# Unit test for method interpret_expression of class JSInterpreter