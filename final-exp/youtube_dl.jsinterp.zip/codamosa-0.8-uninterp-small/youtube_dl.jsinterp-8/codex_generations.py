

# Generated at 2022-06-26 13:24:04.695798
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    j_s_interpreter_0 = JSInterpreter('')
    str_0 = j_s_interpreter_0.interpret_statement('    var a = []', {})
    assert str_0 is None


# Generated at 2022-06-26 13:24:12.227093
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    bool_0 = False
    j_s_interpreter_0 = JSInterpreter(bool_0)
    argname_list = [
        "arg0","arg1"
    ]
    code_0 = "var {};"
    code_1 = "var {};"
    j_s_interpreter_0.build_function(argname_list, code_0)
    j_s_interpreter_0.build_function(argname_list, code_0)
    j_s_interpreter_0.build_function(argname_list, code_1)
    j_s_interpreter_0.build_function(argname_list, code_1)


# Generated at 2022-06-26 13:24:17.080682
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    object_0 = {}
    bool_0 = False
    object_1 = {}
    # Method call test
    JSInterpreter(object_0, object_1).extract_object(bool_0)


# Generated at 2022-06-26 13:24:29.441471
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Perform some setup
    bool_0 = False
    j_s_interpreter_0 = JSInterpreter(bool_0)

    # Call method on object j_s_interpreter_0
    output = j_s_interpreter_0.call_function()
    assert output is None

    # Perform some setup
    str_1 = "ABC"
    j_s_interpreter_1 = JSInterpreter(str_1)

    # Call method on object j_s_interpreter_1
    output = j_s_interpreter_1.call_function()
    assert output is None

    # Perform some setup
    str_2 = "ABC"
    j_s_interpreter_2 = JSInterpreter(str_2)

    # Call method on object j_s_interpreter

# Generated at 2022-06-26 13:24:39.582650
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    global j_s_interpreter_1, bool_0
    j_s_interpreter_1 = JSInterpreter('window["ytInitialPlayerResponse"] = {"captions": {"playerCaptionsTracklistRenderer": {"captionTracks": []}}, "responseContext": {"webResponseContextExtensionData": {"ytConfigData": {"csn": "5VgQ6_uU7V8", "visitorData": "Cgt6bUVfVVlBUFZ3X3ZaNXNXWXZOUUQyN2RjaWFobWJ0NzhrVE1ZV0s4ZmI2YWt4YWN4TlE=", "rootVisualElementType": 10004}}}}')
    bool_0 = True


# Generated at 2022-06-26 13:24:45.446098
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    func_m = re.search(
        r'''(?x)
            (?:function\s+%s|[{;,]\s*%s\s*=\s*function|var\s+%s\s*=\s*function)\s*
            \((?P<args>[^)]*)\)\s*
            \{(?P<code>[^}]+)\}''' % (
        re.escape(funcname), re.escape(funcname), re.escape(funcname)),
        self.code)
    if func_m is None:
        raise ExtractorError('Could not find JS function %r' % funcname)
    argnames = func_m.group('args').split(',')

    return self.build_function(argnames, func_m.group('code'))

# Unit

# Generated at 2022-06-26 13:24:52.004751
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test = JSInterpreter("{'a': 3, 'b': 4}")
    result=test.interpret_expression("{'a': 3, 'b': 4}", {}, 0)
    assert result == {'a': 3, 'b': 4}
    result=test.interpret_expression("var a = {'a': 3, 'b': 4}", {}, 0)
    assert result == {'a': 3, 'b': 4}
    test = JSInterpreter("a>>b")
    result=test.interpret_expression("a>>b", {'a': 2, 'b': 1}, 0)
    assert result == 1

if __name__ == '__main__':
    test_case_0()
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:24:54.214137
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    j_s_interpreter_0 = JSInterpreter("var el;el=this.a(b,c);return el;")
    j_s_interpreter_0.extract_object("this.a")

# Generated at 2022-06-26 13:25:01.872916
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Initialization of test variables
    bool_0 = True
    str_0 = '=CATEGORY_ID'
    str_1 = '=CATEGORY_ID'
    str_2 = '%3D'
    str_3 = '%3D'
    list_0 = []
    # Test method
    assert j_s_interpreter_0.build_function(bool_0, str_0, list_0) == str_1
    assert j_s_interpreter_0.build_function(bool_0, str_2, list_0) == str_3
    # Cleanup test variables
    del bool_0, str_0, str_1, str_2, str_3, list_0

test_JSInterpreter_build_function()


# Generated at 2022-06-26 13:25:06.073508
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    func_0 = 'foo'
    # Code for the definition of method interpret_expression in class JSInterpreter
    # Set attributes
    code = func_0
    objects = {'a': 1}
    j_s_interpreter_0 = JSInterpreter(code, objects)

    # Generate value for local variables
    expr = 'a'
    local_vars = {'a':1}
    allow_recursion = 100

    # Expected value
    res = 1

    # Call method under test
    r = j_s_interpreter_0.interpret_expression(local_vars, allow_recursion)
    assert r == res


# Generated at 2022-06-26 13:25:31.549228
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    import math
    j_s_interpreter_0 = JSInterpreter('''function f(x, y) { return x + y; }''')
    result_0 = j_s_interpreter_0.call_function('''f''', 5, 10)
    assert result_0 == 15
    j_s_interpreter_1 = JSInterpreter('''function f(x, y) { return x - y; }''')
    result_1 = j_s_interpreter_1.call_function('''f''', 5, 10)
    assert result_1 == -5
    j_s_interpreter_2 = JSInterpreter('''function f(x, y) { return x * y; }''')

# Generated at 2022-06-26 13:25:41.620953
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:25:44.910651
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    f = JSInterpreter.build_function(['a'], 'return a')
    assert f(4) == 4
    assert f('asf') == 'asf'



# Generated at 2022-06-26 13:25:45.747827
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_case_0()


# Generated at 2022-06-26 13:25:50.802005
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    """
    Test that the method JSInterpreter.interpret_expression functions as expected
    """
    exp = 'var a=b.join("");'
    bool_0 = False
    j_s_interpreter_0 = JSInterpreter(exp)
    j_s_interpreter_0.interpret_expression('a', {"a":list(), "b":list() })


# Generated at 2022-06-26 13:26:01.196665
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_test_interpreter = JSInterpreter("""
        function test(a, e) {
            return a === e
        }
    """)
    test_func = js_test_interpreter.build_function(["a", "e"], "return a === e")
    assert test_func([2, 2])
    assert not test_func([2, 1])

    test_func = js_test_interpreter.build_function(["a", "e"], "var x = 10; return a === x + e")
    assert test_func([20, 10])
    assert not test_func([21, 10])

# Generated at 2022-06-26 13:26:07.825622
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    import logging
    import sys
    import unittest


# Generated at 2022-06-26 13:26:18.143919
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Test case 0
    function_2_args = ['a', 'b']
    code_2_args = 'a.a(b, c); var e = d; a.b(b);'
    test_case_0_args = (function_2_args, code_2_args)
    test_case_0_expected = JSInterpreter.build_function(function_2_args, code_2_args)
    test_case_0_actual = test_case_0_args[0].extract_function(test_case_0_args[1])
    test_case_0_result = test_case_0_expected == test_case_0_actual
    print('Method extract_function of class JSInterpreter, test case 0: %s' % test_case_0_result)


# Generated at 2022-06-26 13:26:22.549801
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    i_0 = JSInterpreter('abc')
    f_0 = i_0.build_function(['a', 'b'], 'return a + b')
    assert f_0([1, 2]) == 3

# Generated at 2022-06-26 13:26:30.965641
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = 'var a, b, c; a = b?1:c=3; return c;'
    j_s_interpreter_1 = JSInterpreter(code)
    local_vars = {'b': True}
    res, abort = j_s_interpreter_1.interpret_statement(code, local_vars)
    assert res == 3
    assert abort
    local_vars = {'b': False}
    res, abort = j_s_interpreter_1.interpret_statement(code, local_vars)
    assert res == 3
    assert abort
    code = 'var a, b, c; a = b?c=3:1; return a;'
    local_vars = {'b': True}

# Generated at 2022-06-26 13:27:00.430646
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function A(a, b) {
            return a + b;
        }
    '''
    jsi = JSInterpreter(code)
    f = jsi.extract_function('A')
    assert f((1, 2)) == 3

    jsi = JSInterpreter(code)
    f = jsi.extract_function('B')
    assert f((1, 2)) == 3


# Generated at 2022-06-26 13:27:03.891544
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    bool_0 = False
    j_s_interpreter_1 = JSInterpreter(bool_0)
    j_s_interpreter_1.interpret_expression("", None, None)


# Generated at 2022-06-26 13:27:10.800409
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    bool_0 = False
    j_s_interpreter_0 = JSInterpreter(bool_0)
    bool_1 = bool_0
    statement_0 = 'var a = b'
    int_0 = j_s_interpreter_0.interpret_statement(statement_0)
    assert int_0 == None, "return value: %s, expected: %s" % (int_0, None)

    bool_1 = bool_0
    statement_0 = 'return b'
    int_0 = j_s_interpreter_0.interpret_statement(statement_0)
    assert int_0 == None, "return value: %s, expected: %s" % (int_0, None)



# Generated at 2022-06-26 13:27:22.504795
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    global bool_0
    bool_0 = False
    j_s_interpreter_0 = JSInterpreter(bool_0)
    bool_1 = False
    j_s_interpreter_1 = JSInterpreter(bool_1)
    bool_2 = False
    j_s_interpreter_2 = JSInterpreter(bool_2)
    bool_3 = False
    j_s_interpreter_3 = JSInterpreter(bool_3)
    bool_4 = False
    j_s_interpreter_4 = JSInterpreter(bool_4)
    bool_5 = False
    j_s_interpreter_5 = JSInterpreter(bool_5)
    bool_6 = False

# Generated at 2022-06-26 13:27:31.987593
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = "function a(b){return(a=function(){return b.concat(a.a)}).a=[].slice.call(arguments),a}function c(d,e,f){return(c=a.bind(b,d)).apply(b,e.concat(f))}function g(d){return(g=c(d,f,f)).apply(b,f.slice.call(arguments,1))}"
    argnames = ['f']
    code = 'return(a=function(){return b.concat(a.a)}).a=[].slice.call(arguments),a'
    j_s_interpreter_0 = JSInterpreter(code)
    j_s_interpreter_0.build_function('f', code)


# Generated at 2022-06-26 13:27:32.850696
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert True



# Generated at 2022-06-26 13:27:35.292608
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = 'function f(a, b){var c = a + b; return c;}'
    jsi = JSInterpreter(code)
    f = jsi.extract_function('f')
    assert f((3, 4)) == 7



# Generated at 2022-06-26 13:27:43.014742
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    '''Test interpret_expression()'''


# Generated at 2022-06-26 13:27:50.095133
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def resf(args):
        local_vars = dict(zip(argnames, args))
        for stmt in code.split(';'):
            res, abort = JSInterpreter.interpret_statement(stmt, local_vars)
            if abort:
                break
        return res
    funcname = 'return_2'
    code = 'var a=4; return function(a){ return a*10;}(a);'
    argnames = 'a'
    resf1 = JSInterpreter.build_function(argnames, code)
    assert resf1(2) == 40



# Generated at 2022-06-26 13:27:58.334596
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    global_vars = {}
    j_s_interpreter_0 = JSInterpreter(global_vars)
    func_0 = j_s_interpreter_0.interpret_expression('"asd".split("")', global_vars, 100)
    func_1 = j_s_interpreter_0.interpret_expression('[]', global_vars, 100)
    func_2 = j_s_interpreter_0.interpret_expression('a.reverse()', global_vars, 100)
    func_3 = j_s_interpreter_0.interpret_expression('1', global_vars, 100)
    func_4 = j_s_interpreter_0.interpret_expression('a.join("")', global_vars, 100)


# Generated at 2022-06-26 13:28:34.931124
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    bool_0 = False
    j_s_interpreter_0 = JSInterpreter(bool_0)
    argnames_0 = [
        'f',
        'o',
        'o',
        'bar']
    code_0 = '''f(o.o('0x' + bar.baz));'''
    j_s_interpreter_0.build_function(argnames_0, code_0)



# Generated at 2022-06-26 13:28:45.408497
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:28:49.639914
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    bool_0 = False
    j_s_interpreter_0 = JSInterpreter(bool_0)
    bool_0 = False
    j_s_interpreter_0.extract_object(bool_0)


# Generated at 2022-06-26 13:28:53.250468
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    funcname = None
    argnames = None
    code = None
    j_s_interpreter_0 = JSInterpreter(code)
    j_s_interpreter_0.build_function(argnames, code)


# Generated at 2022-06-26 13:29:02.119311
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objects = {}
    code = '''
        var obj = {
            'a_func': function(a, b) {
                return a + b;
            },
            'b_func': function(x) {
                return x * 2;
            }
        };
        '''
    interpreter = JSInterpreter(code, objects)
    interpreter.extract_object('obj')
    assert len(objects) == 1

# Generated at 2022-06-26 13:29:14.267209
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    bool_0 = False
    str_0 = "function(a){this[a]};"
    str_1 = "var a=\"%s\";var b=a.split(\"\").reverse();var c=b.join(\"\");c" % bool_0
    str_2 = "var a=\"function()\\\\x7breturn true\\\\x7d\";eval(a)()"
    str_3 = "var a=\"function()\\\\x7breturn false\\\\x7d\";eval(a)()"
    j_s_interpreter_0 = JSInterpreter(str_0)
    j_s_interpreter_1 = JSInterpreter(str_1)
    j_s_interpreter_2 = JSInterpreter(str_2)
    j_s_interpreter_3

# Generated at 2022-06-26 13:29:20.600306
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    bool_test_var_0 = False
    str_test_var_0 = ""
    str_test_var_1 = ""
    str_test_var_2 = ""
    str_test_var_3 = ""
    str_test_var_4 = ""
    str_test_var_5 = ""
    str_test_var_6 = ""
    float_test_var_0 = float()
    float_test_var_1 = float()
    float_test_var_2 = float()
    float_test_var_3 = float()
    float_test_var_4 = float()
    float_test_var_5 = float()
    float_test_var_6 = float()
    float_test_var_7 = float()
    float_test_var_8 = float()
    float_

# Generated at 2022-06-26 13:29:24.979814
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
            function a(x, y) {
                return x + y;
            }
            '''
    js_interpreter = JSInterpreter(js_code)
    args = (1, 2)
    result = js_interpreter.call_function('a', *args)
    assert result == 3



# Generated at 2022-06-26 13:29:26.383503
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test case 0
    test_case_0()

if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:29:35.083268
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    s = '''
        var $ = function(a){return a.split("").reverse().join("")};
        var a="abcdeabc";
        var ss="edcbaedcba";
        var b=a[5]+a[1]+a[4]+a[0]+a[2];
        var c=$(b)[1]+$(b)[2]+$(b)[3]+$(b)[4]+$(b)[0];
        var d="a"+"b"+"c"+"d"+"e";
        var e=d.split("").reverse().join("");
        var f=b+c;
        var key = b+c+d+e+ss+ss[4]+ss[1]+ss[4];
    '''
    inter = JSInterpreter(s)

# Generated at 2022-06-26 13:29:47.920810
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    assert isinstance(JSInterpreter("true").extract_object(""), object)



# Generated at 2022-06-26 13:29:58.122631
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = 'var obj = (function() {\n        var f = function() {\n            var abc = function(a, b, c) {\n                return a + b + c;\n            };\n\n            var def = function(d, e, f) {\n                return d + e + f;\n            };\n\n            return {\n                abc: abc,\n                def: def,\n                ghi: function(g, h, i) {\n                    return g + h + i;\n                }\n            }\n        };\n\n        return f;\n    })();\n'
    f = JSInterpreter(code)
    res = f.interpret_expression('obj().abc(1, 2, 3)', {})
    if res != 6:
        return False
   

# Generated at 2022-06-26 13:30:06.008345
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Case 0
    bool_0 = False
    str_0 = 'a=_0xf841[0];a=a[_0xf841[2]](a[_0xf841[1]])}'
    j_s_interpreter_0 = JSInterpreter(str_0)
    int_0 = j_s_interpreter_0.interpret_expression('1+1', {'_0xf841': []})
    assert int_0 == 2

    # Case 1
    str_0 = 'return'
    j_s_interpreter_0 = JSInterpreter(str_0)
    int_0 = j_s_interpreter_0.interpret_expression('1+1', {'_0xf841': []})
    assert int_0 == 2

    # Case 2
    str

# Generated at 2022-06-26 13:30:13.769996
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:30:15.857387
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter("")
    j_s_interpreter_0.build_function([""], "")


# Generated at 2022-06-26 13:30:25.083739
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:30:35.133893
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_0 = JSInterpreter("ab")
    function_0 = j_s_interpreter_0.build_function(["b"], "var c = (a + b);")
    function_0(["5"])
    function_1 = j_s_interpreter_0.build_function(["c"], "var d = (a + c);")
    function_1(["6"])
    function_2 = j_s_interpreter_0.build_function(["d"], "var e = (b + d);")
    function_2(["7"])
    function_3 = j_s_interpreter_0.build_function(["a"], "var b = (a + c);")

    function_3(["8"])


# Generated at 2022-06-26 13:30:39.417848
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    var_0 = False
    var_1 = True
    var_2 = False
    j_s_interpreter_0 = JSInterpreter(var_0)
    var_3 = j_s_interpreter_0.interpret_expression(var_1, var_0, var_2)
    assert var_3 is True


# Generated at 2022-06-26 13:30:49.051053
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    try:
        test_case_0()
    except AssertionError:
        raise AssertionError("Test 0 failed")
    try:
        test_case_1()
    except AssertionError:
        raise AssertionError("Test 1 failed")
    try:
        test_case_2()
    except AssertionError:
        raise AssertionError("Test 2 failed")
    try:
        test_case_3()
    except AssertionError:
        raise AssertionError("Test 3 failed")
    try:
        test_case_4()
    except AssertionError:
        raise AssertionError("Test 4 failed")
    try:
        test_case_5()
    except AssertionError:
        raise AssertionError("Test 5 failed")

# Generated at 2022-06-26 13:30:56.576240
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    bool_0 = False
    j_s_interpreter_0 = JSInterpreter(bool_0)
    bool_1 = True
    int_0 = 1
    int_1 = 2
    int_2 = 3
    str_0 = "e"
    str_1 = "Abcdef"
    str_2 = "var cct,t,n,k=this;return n=a[b%a.length],n^=k.charCodeAt(t=(t+1)%k.length),a[b%a.length]=n,n^k.charCodeAt(t=t%k.length),a[b%a.length]>(cct=c.charCodeAt(b%c.length))?a[b%a.length]=cct:0;"
    str_3 = "function()"

# Generated at 2022-06-26 13:31:28.114737
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # No code (no object to be extracted)
    j_s_interpreter_0 = JSInterpreter("")
    res0 = j_s_interpreter_0.extract_object("jwplayer")
    assert res0 is None

    # Code w/ no object
    j_s_interpreter_1 = JSInterpreter(
        "var H = '00:00:00', G = '00:00:00';")
    res1 = j_s_interpreter_1.extract_object("jwplayer")
    assert res1 is None

    # Object extracted successfully

# Generated at 2022-06-26 13:31:37.747162
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-26 13:31:46.017810
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('', {
        'a': {
            'test': lambda arg1: (arg1, 'a_test'),
            'test2': lambda: 'a_test2',
        },
    })
    assert jsi.interpret_expression('5', {}) == 5
    assert jsi.interpret_expression('5.01', {}) == 5.01
    assert jsi.interpret_expression('true', {}) is True
    assert jsi.interpret_expression('"test"', {}) == 'test'
    assert jsi.interpret_expression('a.test2()', {}) == 'a_test2'

# Generated at 2022-06-26 13:31:56.154778
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print("\nThis is a test for method interpret_expression of class JSInterpreter\n")
    code = (
        r"""
        var U1TG = function() {};
        U1TG.prototype = {};
        U1TG.length = {};
        U1TG.length = {
            _0: function(_0x2b2c97, _0x1b928f) {
                return _0x2b2c97 + _0x1b928f;
            },
            _1: function(_0x1bbc51, _0x33b6f2) {
                return _0x1bbc51 - _0x33b6f2;
            },
        };
        """
    )

# Generated at 2022-06-26 13:32:01.640695
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    try:
        res = test_JSInterpreter_extract_object()
    except:
        print('Test failed')
    else:
        print('Test passed')
    finally:
        # Cleanup code here
        pass


# Generated at 2022-06-26 13:32:07.319168
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:32:19.036809
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    string_0 = '0123456789abcdef'
    list_0 = []
    bool_0 = False
    bool_1 = True
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int_6 = 6
    int_7 = 7
    int_8 = 8
    var_0 = -1
    long_0 = long(0)
    float_0 = 0.0
    float_1 = 1.0
    float_2 = 2.0
    float_3 = 3.0
    float_4 = 4.0
    float_5 = 5.0

# Generated at 2022-06-26 13:32:31.385130
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    j_s_interpreter_2 = JSInterpreter(test_data_2)
    j_s_interpreter_1 = JSInterpreter(test_data_1)
    j_s_interpreter_0 = JSInterpreter(test_data_0)

    f_0 = j_s_interpreter_0.build_function(["a", "b", "c"], test_data_0)
    f_1 = j_s_interpreter_1.build_function(["a", "b", "c"], test_data_1)
    f_2 = j_s_interpreter_2.build_function(["a", "b", "c"], test_data_2)

    assert f_0(("a1","a2","a3")) == "a3a3a3"

# Generated at 2022-06-26 13:32:36.132933
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    bool_0 = False
    s_0 = 'aa'
    s_1 = 'ab'
    i_0 = 0
    j_s_interpreter_0 = JSInterpreter(bool_0)
    d = {'a': {0: 0, 1: 1, 2: 2}, 'b': {'b': 2, 'a': 0}}
    str_1 = 'a'
    str_2 = 'ab'
    str_3 = 'abc'
    str_4 = 'abd'
    str_5 = 'abe'
    str_6 = 'abf'
    str_7 = 'abg'
    str_8 = 'abh'

    str_9 = 'b'
    str_10 = 'ba'
    str_11 = 'bb'
    str_12 = 'bc'

# Generated at 2022-06-26 13:32:43.891577
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = r'''
            var a = 10;
            var b = 20;
            var c = 20;
            var d = 20;
            var e = 20;
            var f = 20;
            var g = 20;
            var h = 20;
            var i = 20;
            var j = "10";
            var k = "10";
            var l = 10;
            var m = 20;
            '''
    interpreter = JSInterpreter(code)
    x, y = interpreter.interpret_expression('a+b', {})
    assert x == 30

    # Test Binary operation
    x, y = interpreter.interpret_expression('a-b', {})
    assert x == -10

    x, y = interpreter.interpret_expression('a*b', {})
    assert x == 200
