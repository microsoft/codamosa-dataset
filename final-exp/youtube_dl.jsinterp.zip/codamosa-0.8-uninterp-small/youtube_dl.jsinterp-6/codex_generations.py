

# Generated at 2022-06-26 13:23:56.631630
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    j_s_interpreter_0 = JSInterpreter(None)

    test_var = 13
    test_dict = {'test_var':test_var}
    test_expression_1 = '"test_var"'
    test_result_1 = 'test_var'

    test_expression_2 = 'test_var'
    test_result_2 = test_var

    test_expression_3 = 'test_dict["test_var"]'
    test_result_3 = test_var

    test_expression_4 = 'test_dict.test_var'
    test_result_4 = test_var

    test_expression_5 = 'test_dict.test_var + 12'
    test_result_5 = test_var + 12

    test_expression_6 = '3.141592653589793'

# Generated at 2022-06-26 13:23:59.811687
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = None
    objects = None
    parser = JSInterpreter(code, objects)
    stmt = None
    local_vars = None
    allow_recursion = None
    parser.interpret_statement(stmt, local_vars, allow_recursion)


# Generated at 2022-06-26 13:24:07.937474
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    float_0 = 74.73
    set_0 = {float_0, float_0, float_0, float_0}
    j_s_interpreter_0 = JSInterpreter(set_0)
    #Test with arguments
    str_0 = "function v7(a,b,c) { return a*b*c; }"
    argnames_0 = ["a", "b", "c"]
    resf_0 = j_s_interpreter_0.build_function(argnames_0, str_0)
    assert(resf_0(argnames_0)==0)


# Generated at 2022-06-26 13:24:15.219320
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test_func() {
            var array0 = [1, 2, 3, 4];
            var array1 = [5, 6, 7, 8];
            var i = array1[0];
            if (i != 5) {
                print('i is 5.');
            }
            while (i < array1.length) {
                array0[i] = 9;
                i++;
            }
        }
    '''
    j_s_interpreter_0 = JSInterpreter(code)
    local_vars = dict()
    argnames = tuple()

# Generated at 2022-06-26 13:24:23.863722
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    float_0 = 74.73
    list_0 = []
    def function_0(args):
        res = 0
        for i in range(args[0]):
            res += float_0
        return res
    j_s_interpreter_0 = JSInterpreter(list_0)
    j_s_interpreter_0._functions["f"] = function_0
    j_s_interpreter_0.call_function("f", 2)


# Generated at 2022-06-26 13:24:25.254173
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_case_0()

# Generated at 2022-06-26 13:24:32.553201
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-26 13:24:42.820945
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # test case 3
    funcname = 'b_a'

# Generated at 2022-06-26 13:24:49.298652
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter({})
    js_interpreter.interpret_expression("o.sM('video/mp4')", {'o': {'sM': lambda x: x}})
    js_interpreter.interpret_expression("a.length", {'a': ['1']})
    js_interpreter.interpret_expression("a.reverse()", {'a': ['1']})
    js_interpreter.interpret_expression("c.sM('video/mp4')", {'c': {'sM': '1'}})
    js_interpreter.interpret_expression("o.sM('video/mp4')", {'o': {'sM': lambda x: x}})
    js_interpreter.interpret_expression("a.length", {'a': ['1']})

# Generated at 2022-06-26 13:24:56.495119
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def fake_function(args):
        return "fake function"

    def test_function_1(args):
        return "test function 1"

    def test_function_2(args):
        return "test function 2"

    test_case_1 = JSInterpreter("function abc() { return 'abc';}")
    assert test_case_1.build_function([], "return 'abc';")() == "abc"
    test_case_2 = JSInterpreter("var abc=function() { return 'abc';}")
    assert test_case_2.build_function([], "return 'abc';")() == "abc"
    test_case_3 = JSInterpreter("function abc(x, y, z) { return x+y+z;}")

# Generated at 2022-06-26 13:25:57.120646
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter(str_0)


# Generated at 2022-06-26 13:26:04.346737
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""function test_function(argnames, code){
        def resf(args):
            local_vars = dict(zip(argnames, args))
            for stmt in code.split(';'):
                res, abort = js_interpreter.interpret_statement(stmt, local_vars)
                if abort:
                    break
            return res
        return resf
    }""", {'js_interpreter': JSInterpreter("")})
    assert js_interpreter.build_function([], "") == test_case_0


# Generated at 2022-06-26 13:26:07.862844
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    try:
        #Case 0
        str_0 = 'b_a'
        assert isinstance(str_0, str)
        if str_0 != eval(str_0):
            raise AssertionError('Something bad happened.')
    except Exception as e:
        raise
        print('Something bad happened.')
    else:
        print('Case 0, something good happened.')

test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:26:18.232254
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    """
    Test for method interpret_expression of class JSInterpreter
    """
    # Testing with function call (intrinsic function)
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()

    # Test with object call
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20

# Generated at 2022-06-26 13:26:21.187855
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'b_a'
    interpreter_0 = JSInterpreter(str_0)


# Generated at 2022-06-26 13:26:24.700891
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    str_0 = 'function t(a){};'
    inter_0 = JSInterpreter(str_0)
    inter_0.call_function('t', [])


# Generated at 2022-06-26 13:26:32.105880
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:26:44.269730
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objname = 'b_a'
    fields = r'''(?P<key>%s)\s*:\s*function\s*\((?P<args>[a-z,]+)\){(?P<code>[^}]+)}'''
    fields_m = re.finditer(
        r'''(?x)
            (?P<key>%s)\s*:\s*function\s*\((?P<args>[a-z,]+)\){(?P<code>[^}]+)}
        ''' % _FUNC_NAME_RE,
        fields)
    for f in fields_m:
        argnames = f.group('args').split(',')

# Generated at 2022-06-26 13:26:55.425431
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    import sys, os
    sys.path.append(os.path.join('/home', 'brad', 'Git', 'ytdl_ext', 'youtube-dl'))
    from youtube_dl.extractor import common as test_common
    test_common.register_module()
    sys.path.append(os.path.join('/home', 'brad', 'Git', 'ytdl_ext', 'youtube-dl', 'extractor'))
    import test_common as test_common
    sys.path.append(os.path.join('/home', 'brad', 'Git', 'ytdl_ext', 'youtube-dl', 'extractor', 'common'))
    from test_common import *
    from .youtube import YoutubeIE
    from youtube_dl.extractor.youtube import YoutubeIE

# Generated at 2022-06-26 13:27:04.572626
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    print('test_JSInterpreter_extract_object ...')
    code = '''o = {
        a: 3,
        b: function(arg1) {
            return arg1 + 1;
        },
        c: function(arg1, arg2) {
            return [arg1, arg2];
        }
    };'''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('o')
    assert obj['a'] == 3
    assert obj['b'](4) == 5
    assert obj['c'](1, 2) == [1, 2]


# Generated at 2022-06-26 13:27:29.080255
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    str_0 = 'b_a'
    res = JSInterpreter._extract_object(str_0)
    assert 'b_a' == res

test_case_0()

# Generated at 2022-06-26 13:27:36.635128
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('')
    assert interpreter.interpret_expression('/**/', {}) is None

    interpreter = JSInterpreter('')
    assert interpreter.interpret_expression('hello()', {'hello': 42}) == 42

    interpreter = JSInterpreter('')
    assert interpreter.interpret_expression('"hello" + "world"', {}) == 'helloworld'

    interpreter = JSInterpreter('')
    assert interpreter.interpret_expression('hello', {'hello': 42}) == 42

    interpreter = JSInterpreter('')
    assert interpreter.interpret_expression('({})', {}) == {}

    interpreter = JSInterpreter('')
    assert interpreter.interpret_expression('[1]', {}) == [1]

    interpreter = JSInterpreter('')
    assert interpreter.interpret_expression

# Generated at 2022-06-26 13:27:44.544011
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('var a = "b"')

    # Call method interpret_expression 
    assert(jsi.interpret_expression('a', {}, 1000) == 'b')
    assert(jsi.interpret_expression('a.slice(0)', {}, 1000) == 'b')
    assert('c' == jsi.interpret_expression('a.split("")[1]', {}, 1000))
    assert(str_0 == jsi.interpret_expression('a.split("").reverse().join("")', {}, 1000))
    assert(str_0 == jsi.interpret_expression('a.reverse', {}, 1000))
    assert(str_0 == jsi.interpret_expression('a.join("")', {}, 1000))

# Generated at 2022-06-26 13:27:46.754638
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsi = JSInterpreter('var f = function(){return 42;}')
    assert(jsi.call_function('f') == 42)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:27:51.866441
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    interpreter = JSInterpreter(
        '{ a: function(arg1){var b = arg1+"c"; return b;},  d: function(){return "e";}}')
    obj = interpreter.extract_object(None)
    assert obj['a']('f') == 'fc'
    assert obj['d']() == 'e'


# Generated at 2022-06-26 13:27:54.819023
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('')
    interpreter.interpret_expression('a+2', {'a': 1})


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:27:58.750452
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = str_0
    interpreter = JSInterpreter(code)
    expr = 'b_a'
    local_vars = {}
    allow_recursion = 100
    result = interpreter.interpret_expression(expr, local_vars, allow_recursion)
    expected_result = None
    assert result == expected_result, 'Expected %s, got %s' % (expected_result, result)



# Generated at 2022-06-26 13:28:03.775189
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter("")
    result = js_interpreter.interpret_expression("5", {}, 100)
    assert(result == 5)

    result = js_interpreter.interpret_expression("var", {}, 100)
    assert(result == None)

    result = js_interpreter.interpret_expression("var", {"var": 7}, 100)
    assert(result == 7)


# Generated at 2022-06-26 13:28:05.892676
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = JSInterpreter('function b_a(a){}')
    code = js.extract_function('b_a')
    print(code)


# Generated at 2022-06-26 13:28:12.348249
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    print("Test JSInterpreter extract_function")
    js = JSInterpreter("""
        var b_a = function(e) {
            var e = e.split("");
            e = e.reverse();
            e = e.join("");
            return e;
        };""")
    f_a = js.extract_function("b_a")
    assert f_a("abcd") == "dcba"

    js = JSInterpreter("""
        var a = {b:function(c){return c+1;}};
        """)

    assert js.extract_object("a") == {"b": lambda c: c+1}

    js = JSInterpreter("""
        var a = [1,2,3];
        a.slice(1);
        """)
    assert js.interpret

# Generated at 2022-06-26 13:28:44.281192
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    assert JSInterpreter('var b_a;').interpret_statement('var b_a', {'a' : 0})


# Generated at 2022-06-26 13:28:56.226465
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_1 = '0'
    str_2 = '3'
    str_3 = '4'
    str_4 = '2'
    str_5 = '1'
    str_6 = '0'
    list_1 = ['b', 'a', '1', '2']
    list_2 = ['a', 'b', '1', '2']
    list_3 = []
    str_7 = 'function()'
    str_8 = 'function()'
    str_9 = 'function()'
    str_10 = 'function()'
    str_11 = 'function()'
    str_12 = 'function()'
    str_13 = 'function()'
    str_14 = 'function()'
    str_15 = 'function()'
    str_16 = 'function()'
    str

# Generated at 2022-06-26 13:29:00.407996
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter_instance = JSInterpreter(test_case_0)
    result = js_interpreter_instance.interpret_expression(test_case_0)
    expected_result = "b_a"

    if result == expected_result:
        return True
    else:
        return False

# Generated at 2022-06-26 13:29:03.570697
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter()
    # Check interpret_expression is returning string
    str_0 = interpreter.interpret_expression('b_a', {"b_a": "1"})
    test_case_0()


# Generated at 2022-06-26 13:29:10.425300
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'b_a'
    JSInterpreter_0 = JSInterpreter(str_0)
    str_1 = 'b_a'
    JSInterpreter_1 = JSInterpreter(str_1)
    int_0 = JSInterpreter_1.interpret_expression(str_0)
    assert int_0 == 97


# Generated at 2022-06-26 13:29:13.688254
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Case 0
    str_0 = 'a'
    js_interpreter_0 = JSInterpreter(str_0)
    assert js_interpreter_0.interpret_expression(str_0, {}) == 'a'


# Generated at 2022-06-26 13:29:17.224810
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    s = JSInterpreter('', {})

    # Test: boundary value analysis
    s.build_function(['abc'], 'abc')
    # Test: boundary value analysis
    s.build_function(['abc', 'def'], 'abc+def')


# Generated at 2022-06-26 13:29:19.785083
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Initialization
    intp = JSInterpreter()

    # Test case: str_0 = 'b_a'
    assert intp._interpret_expression(str_0) == 'b_a'


# Generated at 2022-06-26 13:29:25.946449
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = r'''
        var a, b, c;
        a = 5;
        b = a + 6;
        c = a + b;
        a = b - c;
        return c;
    '''
    js_int = JSInterpreter(code)
    res1 = js_int.interpret_expression('b', {})
    res2 = js_int.interpret_expression('a', {})
    res3 = js_int.interpret_expression('a', {})
    if res1 == 11:
        if res2 == -6:
            if res3 == -6:
                print("Test case 0 passed")
            else:
                print("Test case 0 failed")
        else:
            print("Test case 0 failed")
    else:
        print("Test case 0 failed")


# Generated at 2022-06-26 13:29:34.242846
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Create an instance of JSInterpreter
    code = '''
        function t(a) {
            if (anttube !== undefined || at != 0) {
                return a
            }
            var b = '';
            var c = '';
            var d;
            var e = a.split('');
            var f = e.length;
            var g = Math.floor(f / 2);
            for (d = 0; d < f; d++) {
                if (d % 2 == 0) {
                    c += e[d]
                } else {
                    b = e[d] + b
                }
            }
            return c + b
        };
    '''
    js = JSInterpreter(code)
    # Call method interpret_expression with arguments: a_0
    actual = js.interpret_

# Generated at 2022-06-26 13:29:50.139757
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    JS_0 = JSInterpreter(str_0, {'a': 1})
    JS_1 = JSInterpreter(str_0, {'a': 2})
    str_1 = 'c_a'


# Generated at 2022-06-26 13:29:52.104360
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    print('Test case 0:')
    js_interpreter = JSInterpreter(str_0)
    js_interpreter.build_function(['b'], 'return b+1')
    print('Test case 0 passed successfully')



# Generated at 2022-06-26 13:29:54.445405
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test case 0
    str_0 = 'b_a'
    js_interpreter_0 = JSInterpreter(str_0)
    assert(str_0 == js_interpreter_0.interpret_expression(str_0))



# Generated at 2022-06-26 13:30:02.782921
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = test_case_0.__doc__.strip()
    js_interpreter = JSInterpreter(code, {'a' : 'c', 'b_a' : 'hello world'})
    expression = 'a'
    local_vars = {}
    allow_recursion = 10

    expected = 'hello world'
    actual = js_interpreter.interpret_expression(expression, local_vars, allow_recursion)
    print('Expression: ', expression)
    print('Actual: ', actual)
    print('Expected: ', expected)
    assert actual == expected

if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:30:06.057671
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    comment = 'Tests interpret_expression method of class JSInterpreter with code = test_case_0 and obj = test_case_0'
    interpreter = JSInterpreter(test_case_0)
    assert interpreter.interpret_expression('b_a', test_case_0) == str_0, comment

test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:30:13.770019
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('var b=5;')
    assert jsi.interpret_expression("b", {"b":5}) == 5
    assert jsi.interpret_expression("b+1", {"b":5}) == 6
    assert jsi.interpret_expression("a=b+1", {"b":5}) == 6
    assert jsi.interpret_expression("a=b+1;a+=1;a", {"b":5}) == 7
    assert jsi.interpret_expression("a=b+1;a+=1;a-1", {"b":5}) == 6
    assert jsi.interpret_expression("b_a", {"b_a":"test"}) == "test"
    assert jsi.interpret_expression("b_a", {"b_a":"test"}) == "test"
    assert jsi.interpret_expression

# Generated at 2022-06-26 13:30:15.426391
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # TEST_NO_JS
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 13:30:17.922826
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    import logging

    logging.basicConfig(filename='autotest.log', level=logging.INFO)

    jsi = JSInterpreter(str_0)
    jsi.interpret_expression(str_0, None)


# Generated at 2022-06-26 13:30:21.606815
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
#    jsi = JSInterpreter(str_0, {})
    jsi = JSInterpreter(None, {})
    test_case_0()

#if __name__ == "__main__":
#    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:30:25.550756
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interp = JSInterpreter(test_case_0.__doc__)
    result = interp.interpret_expression(str_0, interp._objects, 100)
    print(result)

if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-26 13:30:55.533841
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_0 = 'b_a'
    str_1 = '1'
    str_2 = 'a_b'
    str_3 = '1'
    str_4 = 'b_a'
    str_5 = '0'
    str_6 = '1'
    str_7 = 'c_b.length'
    str_8 = 'b_a'
    str_9 = '0'
    str_10 = 'c_b'
    str_11 = 'b_a'
    str_12 = '0'
    str_13 = 'c_b'
    str_14 = 'b_a'
    str_15 = '1'
    str_16 = 'c_b'
    str_17 = 'c_b.length'
    str_18 = 'b_a'


# Generated at 2022-06-26 13:31:03.260214
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    """Test case for method build_function of class JSInterpreter

        Ensure that JSInterpreter class will correctly build function from
        provided code and arguments.
    """
    def _jsxor(a, b):
        return a ^ b

    js = JSInterpreter("""
var s = 'test';

var d = function (a, b) {
    var c = function (c, d) {
        c = a;
        d = b;
        return _0x8d30[0];
    };

    while (c < 10) {
        c++;
    }

    return c;
};

function b_a(a, b) {
    var c = d(a, b);
    return a + b + c;
}
""")

# Generated at 2022-06-26 13:31:11.723537
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:31:21.186477
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:31:29.909627
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('', {}).interpret_expression('1234', {}, 5) == 1234
    assert JSInterpreter('', {}).interpret_expression('\'1234\'', {}, 5) == '1234'
    assert JSInterpreter('', {}).interpret_expression('"1234"', {}, 5) == '1234'
    assert JSInterpreter('', {}).interpret_expression('["1234", "5678"]', {}, 5) == ['1234', '5678']
    assert JSInterpreter('', {}).interpret_expression('"1234".length', {}, 5) == 4
    assert JSInterpreter('', {}).interpret_expression('"1234"["length"]', {}, 5) == 4

# Generated at 2022-06-26 13:31:39.931242
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    expr = 'a[0]'
    local_vars = {'a':['not ','a', 'b']}
    assert JSInterpreter('').interpret_expression(expr, local_vars, 10) == 'not '
    local_vars = {'a':['not ','a', 'b'], 'b': "b"}
    expr = 'a[b]'
    assert JSInterpreter('').interpret_expression(expr, local_vars, 10) == 'b'
    expr = 'a.length'
    assert JSInterpreter('').interpret_expression(expr, local_vars, 10) == 3
    expr = 'b+1'
    assert JSInterpreter('').interpret_expression(expr, local_vars, 10) == 1

# Generated at 2022-06-26 13:31:42.349698
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print('Testing method JSInterpreter.interpret_expression')
    print('#Passed:0')
    print('#Failed:0')


# Generated at 2022-06-26 13:31:45.587673
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_i = JSInterpreter(test_case_0)
    js_i.build_function()



# Generated at 2022-06-26 13:31:56.007634
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-26 13:32:07.018480
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    str_1 = '1,2'
    str_2 = 'a'
    str_3 = 'a,b'
    str_4 = 'a,b,c'
    str_5 = 'a,b,c,d'
    str_6 = 'a,b,c,d,e'
    str_7 = '1,2,3'
    str_8 = '1,2,3,4'
    str_9 = '1,2,3,4,5'
    str_10 = '1,2,3,4,5,6'
    str_11 = '"0"'
    str_12 = '""'
    str_13 = '0'
    str_14 = '0,1'
    str_15 = '0,1,2'

# Generated at 2022-06-26 13:32:26.783269
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter("code")
    assert jsi.interpret_expression("'abc'", {}, 100) == 'abc'
    assert jsi.interpret_expression("'abc' + str_0", {'str_0': 'def'}, 100) == 'abcdef'


# Generated at 2022-06-26 13:32:32.326342
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_int = JSInterpreter("""
        var b = {
            c: function (a) {}
        };
    """)

    if (
        type(js_int.build_function(('a',), "c(a)")) != types.FunctionType or
        type(js_int.build_function(('a', 'b'), "a+b")) != types.FunctionType
    ):
        raise Exception("JSInterpreter unit test no. 0 failed!")

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-26 13:32:42.421364
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():

    # Testing string constant
    str_0 = 'b_a'
    # Testing number constant
    num_0 = 8
    # Testing object creation
    obj_0 = {"a": 1, "b": "s"}
    # Testing length
    obj_1 = ["a", "b", "c"]
    # Testing object lookup
    obj_2 = {"a": 1, "b": "s"}
    # Testing indexing
    obj_3 = [0, 1, 2, 3]
    # Testing function lookup
    obj_4 = {"a": lambda x: x + 1, "b": lambda y: y - 1}
    # Testing function call
    obj_5 = {"a": lambda x: x + 1, "b": lambda y: y - 1}
    # Testing function call of split

# Generated at 2022-06-26 13:32:52.699037
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    c = '''
        var a = 5;
        var b = 5;
        a;
        b;
        a + b;
        a - b;
        a / b;
        a * b;
        a % b;
        a << b;
        a >> b;
        a & b;
        a ^ b;
        a | b;
        a + b + c;
    '''
    i = JSInterpreter(c)
    res = i.interpret_expression('a', {})
    assert res == 5
    res = i.interpret_expression('a + b', {})
    assert res == 10
    res = i.interpret_expression('a - b', {})
    assert res == 0
    res = i.interpret_expression('a / b', {})
    assert res == 1.0


# Generated at 2022-06-26 13:33:02.107855
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    _locals = locals()
    _locals['self'] = JSInterpreter('')
    assert operator.eq(_locals['self'].interpret_expression('-1', {}, 100), -1)
    assert operator.eq(_locals['self'].interpret_expression('+1', {}, 100), 1)
    assert operator.eq(_locals['self'].interpret_expression('10%3', {}, 100), 1)
    assert operator.eq(_locals['self'].interpret_expression('3*3', {}, 100), 9)
    assert operator.eq(_locals['self'].interpret_expression('3/3', {}, 100), 1)
    assert operator.eq(_locals['self'].interpret_expression('1-1', {}, 100), 0)

# Generated at 2022-06-26 13:33:04.026773
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter(str_0)
    assert interpreter.build_function(interpreter, argnames, code) == 'Test passed'

# Generated at 2022-06-26 13:33:13.113664
# Unit test for method interpret_expression of class JSInterpreter