

# Generated at 2022-06-12 19:00:11.039949
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:00:23.028444
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test for simple function: add(arg1, arg2)
    code = (
        "function add(arg1, arg2) {"
        "    return arg1 + arg2;"
        "}")
    jsinter = JSInterpreter(code)

    f = jsinter.build_function(['arg1', 'arg2'], "    return arg1 + arg2;")
    assert f((1, 2)) == 3
    f = jsinter.build_function(['arg1', 'arg2'], "    return arg1 + arg2;")

    # Test for function with function call: add_squares(a, b)
    code = (
        "function add_squares(a, b) {"
        "    return a*a + b*b;"
        "}")

# Generated at 2022-06-12 19:00:30.302456
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''function test1(a){return 1+2;}'''
    tester = JSInterpreter(code, {})
    assert tester.interpret_expression("1+2", {}) == 3
    assert tester.interpret_expression("test1(1)", {}) == 3


# Generated at 2022-06-12 19:00:36.670709
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test data
    js_code = r'''function(a){ a="a";return a+"b";}'''
    arg_names = ['a']
    # Test code
    js_interpreter = JSInterpreter(js_code)
    f = js_interpreter.build_function(arg_names, js_code)
    r = f([])
    assert r == 'ab'
    r = f(['c'])
    assert r == 'ab'

# Generated at 2022-06-12 19:00:49.382398
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    class TestJSInterpreter(object):
        def test_call_function(self, code, funcname, args, expected):
            js_interpreter = JSInterpreter(code)
            result = js_interpreter.call_function(funcname, *args)
            assert result == expected


# Generated at 2022-06-12 19:00:58.382625
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_string = """bc: function(a){a.c};bc.d=function(a){a.e};bc.f=function(a){a.g};"""
    js_interpreter = JSInterpreter(test_string)
    obj = js_interpreter.extract_object('bc')

# Generated at 2022-06-12 19:01:11.577734
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_code = '''
        function a() {};
        var b = function {};
        c.d = function() {};
        e['f'] = function() {};
    '''
    test_obj = JSInterpreter(test_code)
    assert test_obj._functions == {}
    test_obj.build_function((), '')
    test_obj.build_function((), 'return 1;')
    test_obj.build_function(('va', 'vb'), 'return va + vb;')
    assert test_obj._functions == {}
    test_obj.build_function(('va', 'vb'), 'return va + vb + c;')
    test_obj._objects['c'] = {'d': 1}

# Generated at 2022-06-12 19:01:24.559188
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsInterpreter = JSInterpreter("")
    func = jsInterpreter.build_function(
        ["a", "b"], "a=1; return a+b")
    assert callable(func), "built function is callable"
    assert func(("foo", "bar")) == "foobar", "function works as expected"



# Generated at 2022-06-12 19:01:36.050951
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = '''
        function escape(str) {
            return encodeURIComponent(str);
        }

        var obj = {
            "obj.f": function(a, b) {
                return a.split("").reverse().join("");
            },
            "obj.length": function(x) {
                return x.length;
            }
        };
    '''
    js = JSInterpreter(js_code)
    obj = js.extract_object("obj")
    assert obj['obj.length']("test string") == 11
    assert obj['obj.f']('test string') == 'gnirts tset'

    assert js.call_function('escape', "abd'c\nde") == 'abd%27c%0Ae'

# Generated at 2022-06-12 19:01:39.849983
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    test_code = '''var obj = {
        "example_function": function(info) {
            return "hello " + info;
        }
    };'''
    interpreter = JSInterpreter(test_code)
    res = interpreter.call_function('obj.example_function', 'world')
    assert res == "hello world"

# Generated at 2022-06-12 19:02:04.941961
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    from .utils import js_to_json

    js_code = '''
    a={"forEach":function(b,c){b&&(this.Yd[b]=this.Yd[b]||[]).push(c)},
    Fc:function(b){b&&(b=this.Yd[b]||[])&&(b.forEach(function(b){b()}),delete this.Yd[b])}};
    '''
    js_code = js_to_json(js_code)

    js_interpreter = JSInterpreter(js_code)
    js_interpreter._objects = {}
    js_interpreter._functions = {}


# Generated at 2022-06-12 19:02:13.231786
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        wb = {
            c : function(a,b){
                return a.split(b);
            },
            d : function(a,b){
                return a.join(b);
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    wb = js_interpreter.extract_object('wb')
    assert wb == {
        "c" : js_interpreter.build_function(["a","b"],
            '''
            return a.split(b);
            '''
        ),
        "d" : js_interpreter.build_function(["a","b"],
            '''
            return a.join(b);
            '''
        ),
    }


# Generated at 2022-06-12 19:02:24.605416
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def test_expression(js, obj, expected):
        js_interpreter = JSInterpreter('')
        assert js_interpreter.interpret_expression(js, obj) == expected

    obj = {'a': 1, 'b': 2, 'c': [3, 4, 5]}

    test_expression('1 + 2 ', {}, 3)
    test_expression('a + 2', obj, 3)
    test_expression('1 + b', obj, 3)
    test_expression('a + b', obj, 3)
    test_expression('1 + 0x12', obj, 18)
    test_expression('1 + 0x1A', obj, 26)
    test_expression('0x1A + 26', obj, 42)
    test_expression('0x1A + 0x1A', obj, 42)
   

# Generated at 2022-06-12 19:02:31.469198
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
function abc(a, b) {
    return a + b;
}"""
    interpreter = JSInterpreter(code)

# Generated at 2022-06-12 19:02:42.924171
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    from pytube import YouTube
    js_code = YouTube('http://www.youtube.com/watch?v=BaW_jenozKc').watch_html
    js_code += '''
        function flashvars(){
            return vars;
        }'''
    interpreter = JSInterpreter(js_code)
    res = interpreter.call_function('flashvars')

# Generated at 2022-06-12 19:02:56.357694
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:03:08.493707
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test_build_function(funcname, code, args, expected_result):
        args_str = ''
        if args:
            args_str = ','.join(args)
        code = 'function %s(%s){%s}' % (funcname, args_str, code)
        js_interp = JSInterpreter(code)
        f = js_interp.build_function(args, code)
        res = f(args)
        assert res == expected_result

    test_build_function('f1', 'f1', [], 'f1')

    test_build_function('f2', 'f2;f2;f2', [], 'f2')

    test_build_function('f3', 'a=3', ['a'], 3)


# Generated at 2022-06-12 19:03:11.280857
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:03:19.972974
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
        function f() {}
        function g(a,b,c) {}
        var a = {
            b: function(arg) {
                return 3;
            },
            c: function() {
                return 'd';
            }
        };
        var e = a.c();
        var f = a[e]();
        var g = 'hello';
        var h = g.length;
        var i = 'split,me'.split(',');
        var j = i.join('');
        var k = [1,2,3,4,5];
        var l = k.slice(2);
        var m = k.splice(1,2);
        var n = [].reverse()[0];
        """
    jsinterpreter = JSInterpreter(code)
    assert js

# Generated at 2022-06-12 19:03:27.254787
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
	code = '''
		var a= {
			"first": function(arg1, arg2){var a = arg1-arg2;return a;},
			"second": function(arg){return arg+2;}
		}
	'''
	interpreter = JSInterpreter(code)
	obj_a = interpreter.extract_object("a")
	assert(obj_a['first'](3,2) == 1)
	assert(obj_a['second'](1) == 3)


# Generated at 2022-06-12 19:03:47.827432
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:03:55.920940
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = r'''
        var a = function() {
            var b = function() {
                return 2;
            };
            var c = function() {
                return 3;
            };
            return b();
        };

        var d = function() {
            return 2;
        };
    '''
    i = JSInterpreter(code)

    func_m = re.search(r'var\sa\s*=\s*function\(\)', code)
    func = code[func_m.end():]
    func_m2 = re.search(r'{\s*(.*?)\s*}\s*;$', func, flags=re.DOTALL)
    func = func[func_m2.start() + 1:func_m2.end() - 2]

    local_vars = {}

# Generated at 2022-06-12 19:04:08.389996
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:04:20.635667
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter(
        'var a = function(b) {return b};'
        'var c = {e: function() {return (function(k) {return k})}};'
        'var d = [0, 1];'
        'var f = [2, 3];'
        'var g = [4, 5];'
        'var h = {};'
        'var i = 0;'
        'var j = "j";')
    interpreter.interpret_expression('a(1)', {}, 1)
    interpreter.interpret_expression('c.e()(1)', {}, 1)
    interpreter.interpret_expression('c["e"]()(1)', {}, 1)
    interpreter.interpret_expression('d[0]', {}, 1)

# Generated at 2022-06-12 19:04:33.531667
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
        function test(){
            var a, b, c;
            a = 1;
            b = a + 2;
            c = c | a;
            c = c & 1;
            c = c ^ 1;
            a = c + 3;
            return a;
        }
    """
    js = JSInterpreter(code)
    result = js.interpret_expression("a + 2", {'a': 0, 'c': 4})
    assert result == 2
    result = js.interpret_expression("c | a", {'a': 1, 'c': 4})
    assert result == 5
    result = js.interpret_expression("c & 1", {'a': 2, 'c': 4})
    assert result == 0

# Generated at 2022-06-12 19:04:44.782017
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('')

    # Test for simple expressions
    assert js.interpret_expression('"abc"', {}) == 'abc'
    assert js.interpret_expression('1', {}) == 1
    assert js.interpret_expression('x', {'x': 1}) == 1
    assert js.interpret_expression('x', {'x': 'abc'}) == 'abc'
    assert js.interpret_expression('x["y"]', {'x': {'y': 0}}) == 0
    assert js.interpret_expression('x[0]', {'x': [0]}) == 0
    assert js.interpret_expression('a + b', {'a': 0, 'b': 1}) == 1
    assert js.interpret_expression('a * b', {'a': 0, 'b': 1}) == 0

# Generated at 2022-06-12 19:04:46.686075
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    assert JSInterpreter('').call_function('', '') == None



# Generated at 2022-06-12 19:04:53.345567
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter('')
    local_vars = {'a': 0}
    res, abort = interpreter.interpret_statement('var b = a + 1; a = b', local_vars)
    assert res == 1
    assert abort == False
    assert local_vars['a'] == 1
    assert 'b' not in local_vars.keys()
    print('test_JSInterpreter_interpret_statement done ...')
    return 'OK'


# Generated at 2022-06-12 19:05:02.140544
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    def _func_y2x_y3x(args):
        assert len(args) == 1
        a = args[0]
        return a * 2, a * 3

    jsi = JSInterpreter('var p = { a: function(x) { return x * 2; } };',
                        {
                            'y2x_y3x': _func_y2x_y3x
                        })
    assert jsi.call_function('p.a', 5) == 10

# vim:et:sw=4:ts=4

# Generated at 2022-06-12 19:05:12.458758
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = r'''
        var a = "0";
        var b = {
            "c": function(d) {
                var e = 1, f = 2;
                var g = "h";
                return 3;
            },
            "i": function() {
                return 4;
            }
        };
        var j = function() {
            return 5;
        };
        var k = d(6);
    '''
    i = JSInterpreter(code)
    assert i.interpret_statement('var a = b.c(3)', {})[0] == 3
    assert i.interpret_statement('var a = b["c"](3)', {})[0] == 3
    assert i.interpret_statement('return b.i()', {})[0] == 4


# Generated at 2022-06-12 19:05:53.651056
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    """Test for the method JSInterpreter.extract_object in class JSInterpreter
    """
    code = """
    var a = {
        b: function() {
            return 1;
        },
        c: function() {
            return 2;
        }
    };
    """
    actual = JSInterpreter(code).extract_object('a')
    expected = {
        'b': lambda: 1,
        'c': lambda: 2
    }
    assert actual == expected


# Generated at 2022-06-12 19:05:59.466420
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = """
var obj = {
    method1: function(x) {
        return x
    },
    method2: function(x, y) {
        return x + y
    }
}
"""
    jsi = JSInterpreter(js)
    assert jsi.extract_object("obj")["method1"] == jsi.extract_function("method1")
    assert jsi.extract_object("obj")["method2"] == jsi.extract_function("method2")


# Generated at 2022-06-12 19:06:04.942071
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
    foobar = function () {
        var a = [1,2,3];
        return a;
    }
    '''
    jsi = JSInterpreter(code)
    assert jsi.call_function('foobar') == [1,2,3]


# Generated at 2022-06-12 19:06:09.889945
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var DqI={
            JeY:function(s) {...}
        };
    '''
    objects = {
        "DqI" : {
            'JeY': lambda s: 'test_result'
        }
    }
    interpreter = JSInterpreter(code, objects)
    assert interpreter.extract_object('DqI') == {
        'JeY': lambda s: 'test_result'
    }


# Generated at 2022-06-12 19:06:22.051337
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('', {'str': 'abcdefghij'})
    obj = {}
    assert interpreter.interpret_expression('({})', {}, 0) == obj
    assert interpreter.interpret_expression('({})', {}, 0) == obj
    assert interpreter.interpret_expression('([1,2,3])', {}, 0) == [1, 2, 3]
    assert interpreter.interpret_expression('[1,2,3]', {}, 0) == [1, 2, 3]
    assert interpreter.interpret_expression('true', {}, 0) is True
    assert interpreter.interpret_expression('false', {}, 0) is False
    assert interpreter.interpret_expression('null', {}, 0) is None
    assert interpreter.interpret_expression('(true)', {}, 0) is True

# Generated at 2022-06-12 19:06:26.701822
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''function test(aa, bb) {
        return bb;
    }'''
    jsinterpreter = JSInterpreter(js_code)
    ok_(jsinterpreter.call_function('test', 'str', 1) == 1)

if __name__ == '__main__':
    from nose.tools import *

    test_JSInterpreter_call_function()

# Generated at 2022-06-12 19:06:39.107054
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    func_code = '{"a":1}[e](b);return{c:2}[e](b);'
    js_interp = JSInterpreter(func_code)
    func = js_interp.build_function(['e', 'b'], func_code)

# Generated at 2022-06-12 19:06:43.609202
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:06:52.059994
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    function abc() {
        var x = {
            'a': function(){},
            'b': function(){},
        }
    }'''

    interpreter = JSInterpreter(code)
    assert len(interpreter.extract_object('x')) == 2
    assert interpreter.extract_object('x')['a'] is not None
    assert interpreter.extract_object('x')['b'] is not None


# Generated at 2022-06-12 19:07:00.695430
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var obj1 = {
          a: function(arg1, arg2) {
            var c = arg2;
            return arg1 + test;
          },
          b: function() {
            return this.a(4, 5);
          },
          "d": function(arg1) {
            return arg1;
          }
        };
    """
    i = JSInterpreter(code)
    obj1 = i.extract_object('obj1')
    assert obj1 == {
        'a': lambda arg1, arg2: arg1 + i.call_function('test',),
        'b': lambda: obj1['a'](4, 5),
        'd': lambda arg1: arg1,
    }


# Generated at 2022-06-12 19:07:47.489273
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        var a = 
        {
            "b": function (c) {
                return c + d;
            },
            "e": function (c) {
                return c + f;
            }
        };
        function d(c) {
            return c + 3;
        }
        function f(c) {
            return c + g;
        }
        var g = 1;
        var h = 
        {
            "i": function (c) {
                return c + j;
            }
        };
        var j = 2;
    ''')
    assert js_interpreter.call_function('a.b', 0) == 3
    assert js_interpreter.call_function('a.e', 0) == 1
    assert js

# Generated at 2022-06-12 19:07:53.858869
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = 'function test(a, b, c){d = a; e = b; f = c}'
    jsi = JSInterpreter(js)
    func = jsi.build_function(['a', 'b', 'c'], 'd = a; e = b; f = c')
    expected = 6
    res = func((1, 2, 3))
    assert res == expected



# Generated at 2022-06-12 19:08:04.218536
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    inter = JSInterpreter('')
    f = inter.build_function(['x'], 'var z=x+1;return z;')
    assert f([3]) == 4

    f = inter.build_function(['z'], 'return z')
    assert f([0]) == 0
    assert f([1]) == 1
    assert f([0.5]) == 0.5

    f = inter.build_function(['w', 'x', 'y', 'z'], 'return x%y+z')
    assert f([1, 2, 3.5, 2.5]) == 4.0
    assert f([1, 2, 3.3, 2.5]) == 3.3

    f = inter.build_function(['x'], 'return Math.ceil(x)')

# Generated at 2022-06-12 19:08:09.946790
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    X("Y", {
        "asd": function(a, b) {return a + b;},
        "eqc": function(a, b) {return a == b;}
    });
    '''
    js = JSInterpreter(code)
    obj = js.extract_object("Y")
    assert obj["asd"]((1, 2)) == 3
    assert obj["eqc"]((1, 1)) is True


# Generated at 2022-06-12 19:08:12.503802
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        var a1234 = 4;
        var b56 = 12;
        var sumab = function(a, b) {return a + b;};
        sumab(a1234, b56);
    '''
    assert JSInterpreter(code).extract_function('sumab')((4, 12)) == 16



# Generated at 2022-06-12 19:08:23.239494
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    objects = {
        'b': [1, 2, 3, 4, 5],
        'a': {
            'c': 3,
            'b': [1, 2, 3, 4, 5],
            'splice': list.pop,
            'slice': list.__getslice__,
            'reverse': list.reverse,
            'join': str.join,
            'd': 4,
            'e': 5,
            'f': 6,
            'g': 7,
        },
    }


# Generated at 2022-06-12 19:08:35.490562
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js1 = r'''function v(a){a=a.split("");a=a.reverse();a=a.join("");return a}'''

# Generated at 2022-06-12 19:08:43.752462
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Test to extract a object from Js code
    code = r'''function someFunction(){
                someThing = {a: function(){},
                             b: function(){},
                             c: function(){},
                             d: function(){}};
            };
            '''
    js = JSInterpreter(code)
    obj = js.extract_object('someThing')
    a_func = obj['a']
    assert(a_func() == None)

# Generated at 2022-06-12 19:08:54.504806
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = '"Hello, world!"'
    for i in range(10000):
        js += '+"!"'
        
    js = 'var x=1,y=2;return x*(y+1);'

# Generated at 2022-06-12 19:09:01.695074
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r'''
        var obj = {
            "a" : function(arg){
                return arg * 2
            },
            "b" : function(arg){
                return arg + 2
            }
        };
        var output = obj.a(obj.b(2));
    '''
    objects = JSInterpreter(code)._objects
    assert objects['obj']['a'](objects['obj']['b'](2)) == 6


# Generated at 2022-06-12 19:09:19.004993
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
            var a = function(x,y){
                return x*Math.pow(y,2);
            }
        """
    jsi = JSInterpreter(code)
    assert jsi.call_function("a",9,3) == 243


# Generated at 2022-06-12 19:09:25.456815
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function test(a,b){
            var c = a+b;
            return c;
        }
    '''
    interpreter = JSInterpreter(code)
    assert(interpreter.call_function('test', 5, 6) == 11)
    