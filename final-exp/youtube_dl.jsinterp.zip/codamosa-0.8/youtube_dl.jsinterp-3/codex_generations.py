

# Generated at 2022-06-12 19:00:07.727923
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
    function m(a) {
        return a;
    }
    '''
    obj = JSInterpreter(code)
    f = obj.extract_function('m')
    assert f((1,)) == 1
    assert f((5,)) == 5


if __name__ == '__main__':
    import sys
    test_JSInterpreter_extract_function()
    sys.exit(0)

# Generated at 2022-06-12 19:00:18.129260
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    a = ['4']
    b = ['4']
    c = ['1']
    d = ['2']

    js1 = '''
        var a=4,b=10,c=function(){return 17;}
        function d(p,a,c,d,b){return p;}
        function e(a,b){var c=a[0];return c+b;}
        d(e(a,b)-c()[2]+1)/a[0]
    '''

# Generated at 2022-06-12 19:00:27.056032
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        vug1 = 'b';
        vug2 = 'a';
        vt = ' ';
        vv = vug1 + vug2;
        function functionB(vug3, vug4, vt) {
            var vv = vug3 + vug4 + vt;
            return vv;
        }
        function functionA(vug1, vug2, vt) {
            var vv = vug1 + vug2 + vt;
            var vv = functionB(vug1, vug2, vt);
            return vv;
        }
    '''
    js_interpreter = JSInterpreter(js_code)

# Generated at 2022-06-12 19:00:38.159791
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
    function ytplayer() {
        return ytplayer;
    }

    var ytplayer = {
        "config": {
            "args" :
            {
                "status" : "ok"
            }
        },
        "x": function(a,b){
            return a + b;
        },
        "y": function(a,b){
            return a * b;
        },
        "z": function(a){
            return a;
        }
    };
    """

    interpreter = JSInterpreter(code)
    interpreter.call_function('ytplayer')

    extracted = interpreter.extract_object('ytplayer')

    assert extracted['x'](2, 3) == 5
    assert extracted['y'](2, 3) == 6
    assert extracted['z']('4')

# Generated at 2022-06-12 19:00:45.572322
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
        a = function () {
            var b = function () {
                return 4;
            }
            if (3 == 4) {
                b = function () {
                    return 7;
                }
            }
            return b();
        }
        '''
    js_interpreter = JSInterpreter(js_code)
    f = js_interpreter.extract_function("a")
    assert f() == 4


# Generated at 2022-06-12 19:00:53.115893
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    objects = {
        'window': {
            'decodeURIComponent': lambda x: x[0].replace('\\x', '%'),
        }
    }
    interpreter = JSInterpreter(objects=objects)
    expr = 'window["decodeURIComponent"]("abc%20def")'
    assert interpreter.interpret_expression(expr, {}) == 'abc def'


if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-12 19:01:06.224847
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
    var f = function(){};
    f.foo = {
        bar: function(a){
            return a;
        },
        baz: function(){
            return "hello";
        },
        quux: function(a, b, c){
            return a + b + c;
        },
    };
    f.other = {
        thing: function(a, b){
            return a + b;
        }
    }
    """
    jsint = JSInterpreter(code)
    obj = jsint.extract_object('f.foo')
    assert obj['bar'](4) == 4
    assert obj['quux'](1, 2, 3) == 6
    assert obj['quux'](-1, 0, 1) == 0

# Generated at 2022-06-12 19:01:10.877477
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('')
    assert callable(js.build_function(['a', 'b'], 'return a+b;'))
    assert callable(js.build_function([], 'return 2;'))

# Generated at 2022-06-12 19:01:18.889475
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinterpreter = JSInterpreter('')
    func = jsinterpreter.build_function(['a', 'b'], 'c=a+b;d=a-1;return d')
    assert func((10, 2)) == 9

    func = jsinterpreter.build_function(['a', 'b'], 'c=a+b;d=c+b;return d')
    assert func((1, 2)) == 5



# Generated at 2022-06-12 19:01:27.883671
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsi = JSInterpreter("""
    var obj = {
        a: "A",
        funcA: function(){
            return "func A result";
        },
        funcB: function(a){
            return "func B result " + a;
        }
    };
    """)
    obj = jsi.extract_object("obj")

# Generated at 2022-06-12 19:01:44.665190
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter(
        '''
        from __future__ import unicode_literals
        a = 3;
        b = "s"
        b += a;
        c = b + "a";
        ab = function () { return a + b; }
        d = {a: 1, b: 2}
        d.a += 3
        e = [1, 2, 3, "ab", d]
        e.push('3')
        e.reverse()
        e.slice(1)
        f = function (x, y) {
            console.log(a, b, c, x, y)
            return a + b + c + x + y;
        }
        ''')

    f = js_interpreter.extract_function('f')

# Generated at 2022-06-12 19:01:54.909251
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-12 19:02:01.942794
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-12 19:02:06.813900
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    import copy

    # Test case 1: Testing for a simple object
    code = """
        var obj1={
            "a": function(p,q){
                var r=p+q;
                return r;
            },
            "b": function(p,q){
                var r=p-q;
                return r;
            }
        }
    """
    obj1 = JSInterpreter(code).extract_object('obj1')
    assert obj1 != None
    assert obj1['a'] == None
    assert obj1['b'] == None
    assert obj1['a'](1,2) == 3
    assert obj1['b'](1,2) == -1

    # Test case 2: Testing for a deeply nested object

# Generated at 2022-06-12 19:02:11.515522
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    objects = {'vb': [0, 1, 2]}
    code = '''function(a){
                    a.splice(0, 1, 3);
                    return a.slice(1);
                }'''
    interpreter = JSInterpreter(code, objects)
    assert interpreter.interpret_expression('a.splice(0, 1, 3)', {}) == [3]


# Generated at 2022-06-12 19:02:23.266994
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('1').interpret_expression('1', None) == 1
    assert JSInterpreter('1').interpret_expression('1+1', None) == 2
    assert JSInterpreter('1').interpret_expression('-1', None) == -1
    assert JSInterpreter('1').interpret_expression('a', {'a': 2}) == 2
    assert JSInterpreter('1').interpret_expression('a', {'a': 2, 'b': 1}) == 2
    assert JSInterpreter('1').interpret_expression('a+b', {'a': 2, 'b': 1}) == 3
    assert JSInterpreter('1').interpret_expression('a+b;return a', {'a': 2, 'b': 1}) == 2

# Generated at 2022-06-12 19:02:36.390075
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    interpreter = JSInterpreter('''
        var name = {'a': 'apple', 'b': 'banana', 'c': 'coconut'};
        var js_functions = {'concat': function(x, y) {return x.concat(y);}, 'join_with_dashes': function(l) {return l.join('-');}};
        var js_arrays = {'nums': [0, 1, 2], 'fruits': ['a', 'b', 'c']};
        var js_empty_array = {'empty': []};
    ''')

    assert interpreter.extract_object('name') == {'a': 'apple', 'b': 'banana', 'c': 'coconut'}

# Generated at 2022-06-12 19:02:46.185202
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    obj_1 = {"slice": list.__getitem__, "splice": list.__getitem__}
    obj_2 = {"method": lambda x: 'method(%s)' % x[0]}
    obj_3 = {"a": 1, "b": 2, "c": 3, "d": 4}
    res_1 = JSInterpreter('obj_1', {"obj_1": obj_1}).interpret_expression("obj_1.slice(0, 3)", {})
    res_2 = JSInterpreter('obj_2', {"obj_2": obj_2}).interpret_expression("obj_2.method(ab)", {"ab": "ab"})

# Generated at 2022-06-12 19:02:55.551907
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    assert JSInterpreter('', {}).interpret_statement('a=a', {'a': 5}) == (5, False)
    assert JSInterpreter('', {}).interpret_statement('a=3', {'a': 1}) == (3, False)
    assert JSInterpreter('', {}).interpret_statement('a=a+1', {'a': 2}) == (3, False)
    assert JSInterpreter('', {}).interpret_statement('a=a*a', {'a': 2}) == (4, False)



# Generated at 2022-06-12 19:03:07.698942
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():

    # define test vars
    strType = type('a')
    intType = type(1)
    listType = type([])
    dictType = type({})


# Generated at 2022-06-12 19:03:32.223697
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def test_one(code, obj):
        js_interpreter = JSInterpreter("var a = " + code)
        assert js_interpreter.interpret_expression("a", {"a": None}) == obj

    test_one("123", 123)
    test_one("-123", -123)
    test_one("123.456", 123.456)
    test_one("-123.456", -123.456)
    test_one("[1, 2, 3]", [1, 2, 3])
    test_one("[1, [2, [3, [4, [5, 6]]]]]", [1, [2, [3, [4, [5, 6]]]]])

# Generated at 2022-06-12 19:03:39.969560
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('''function test(a, b, c) {
        var d = a + b;
        var e = d + c;
        return e;
    }''')
    res = js_interpreter.build_function(['a', 'b', 'c'], '''
        var d = a + b;
        var e = d + c;
        return e;
    ''')
    assert res(range(3)) == 5


# Generated at 2022-06-12 19:03:49.674248
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter('').build_function([], 'return')() is None
    assert JSInterpreter('').build_function(['foo'], 'return foo;')() is None
    assert JSInterpreter('').build_function(['foo'], 'return foo')(['bar']) == 'bar'
    # Test for the signature:  build_function(self, argnames, code):
    assert JSInterpreter('').build_function(['a', 'b'], 'return a + b')([1, 2]) == 3
    assert JSInterpreter('').build_function(['a'], 'return [a];')([1, 2]) == [1, 2]

if __name__ == '__main__':
    # test_JSInterpreter_build_function()
    pass

# Generated at 2022-06-12 19:03:57.200016
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Example of string concatenation
    def test_1():
        js_code = "var aaa = 'a';\nvar bbb = 'b';\nvar ccc = aaa + bbb;"
        interpreter = JSInterpreter(js_code)
        assert 'ab' == interpreter.interpret_expression('aaa + bbb', locals())

    # Example of function call
    def test_2():
        js_code = """
                var bbb = function(a, b) { return a + b; };
                var ccc = bbb(1, 2);
            """
        interpreter = JSInterpreter(js_code)
        assert 3 == interpreter.interpret_expression('bbb(1, 2)', locals())

    # Example of array

# Generated at 2022-06-12 19:04:01.089155
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test simple function
    js_interpreter = JSInterpreter('')
    function = js_interpreter.build_function(['a', 'b'], 'return (a + b) / 2')
    assert function([4, 6]) == 5


# Generated at 2022-06-12 19:04:12.565343
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''var a = {
    b: function() {
        return 5;
    },
    c: function(arg) {
        return arg;
    }
}'''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter._objects.get('a') is None
    obj = js_interpreter.extract_object('a')

# Generated at 2022-06-12 19:04:25.343700
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsi = JSInterpreter(
        'var a=1; a; var c = "" + "ab" + "cd"; var d = a + c + "123"; d;')
    assert jsi.interpret_statement('return a;', {}) == (1, True)
    assert jsi.interpret_statement('a;', {}) == (1, False)
    assert jsi.interpret_statement('c;', {}) == ('abcd', False)
    assert jsi.interpret_statement('d;', {}) == ('1abcd123', False)
    assert jsi.interpret_statement('return a + c;', {}) == ('1abcd', True)
    assert jsi.interpret_statement('return d;', {}) == ('1abcd123', True)


# Generated at 2022-06-12 19:04:39.062235
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('')

# Generated at 2022-06-12 19:04:44.874708
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var A = {
            f: function(b) {
                return (function(c) {
                    return b + c;
                })(b * 2)
            }
        };
    '''
    jsi = JSInterpreter(code)
    obj = jsi.extract_object("A")
    assert obj["f"]((5,)) == 15

if __name__ == '__main__':
    test_JSInterpreter_extract_object()

# Generated at 2022-06-12 19:04:55.088721
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Operation test
    def assert_operation(code, var_dict, expected_value):
        jsi = JSInterpreter(code, var_dict)
        result = jsi.interpret_expression(code, var_dict)
        assert result == expected_value


# Generated at 2022-06-12 19:05:14.706984
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter("""
    var o = {
        f: function(){}
    }
    """)
    assert interpreter.interpret_statement("var a = 10", {})[0][0] == 10
    assert interpreter.interpret_statement("return a", {'a': 3})[0] == 3
    assert interpreter.interpret_statement("o.f()", {}) == (None, False)


# Generated at 2022-06-12 19:05:22.218801
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        var a = '';
        var b = 'abc';
        var c = [0,1,2];
        var d = [[0,0], [0,1], [1,0]];
        var e = {
            a: function(x) { return x; },
            b: function(x, y) { return x + y; },
            c: function(x) { return x * x; }
        }
    '''
    interp = JSInterpreter(code)

    assert interp.interpret_expression('a', {}) == ''
    assert interp.interpret_expression('b', {}) == 'abc'
    assert interp.interpret_expression('c', {}) == [0, 1, 2]
    assert interp.interpret_expression('c.length', {}) == 3
   

# Generated at 2022-06-12 19:05:29.212530
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    obj = '''
    o = {
        "a":1,
        "b": [1, 2, 3],
        "c": function() {
            return 4;
        },
        "d": function(a, b) {
            return a + b;
        }
    }
    '''
    obj2 = '''
    o = {
        "a": [
            [
                [1, 2],
                [3, 4]
            ],
            [
                [5, 6],
                [7, 8]
            ]
        ],
        "b": function() {
            return 4;
        }
    };
    '''
    objects = {
        'o': None,
        'p': None,
    }
    jsi = JSInterpreter(obj, objects)
    assert jsi

# Generated at 2022-06-12 19:05:32.552841
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Function to test
    func_code = 'return'
    func_args = []

    # Code of the class JSInterpreter
    code = ''
    interpreter = JSInterpreter(code)

    assert interpreter.build_function(func_args, func_code)

# Generated at 2022-06-12 19:05:37.143932
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})
    result = js_interpreter.build_function(['a'], 'a = 0; return 1;')
    assert result([1]) == 1
    result = js_interpreter.build_function(['a'], 'return a;')
    assert result([1, 2]) == [1, 2]


# Generated at 2022-06-12 19:05:40.108375
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('alert("hi")').interpret_expression('1+1', {}, 100) == 2


if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-12 19:05:43.490308
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    var obj = {
        "func1": function(a, b) { return a + b; },
        "func2": function(a) { return a + 2; },
    };
    '''
    js_interpreter = JSInterpreter(code, {})
    obj = js_interpreter.extract_object("obj")

    # Test the method func1 of the object obj
    assert obj["func1"]((1, 2)) == 3
    # Test the method func2 of the object obj
    assert obj["func2"]((3,)) == 5


# Generated at 2022-06-12 19:05:56.021369
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('').interpret_expression('"Hello"', {}) == 'Hello'
    assert JSInterpreter('').interpret_expression('(function () {"Hello"})()', {}) == 'Hello'
    assert JSInterpreter('').interpret_expression('1+1', {}) == 2
    assert JSInterpreter('').interpret_expression('3 - 1', {}) == 2
    assert JSInterpreter('').interpret_expression('8 * 1.25', {}) == 10.0
    assert JSInterpreter('').interpret_expression('6 / 2', {}) == 3.0
    assert JSInterpreter('').interpret_expression('10 % 5', {}) == 0
    assert JSInterpreter('').interpret_expression('10 & 5', {}) == 0

# Generated at 2022-06-12 19:06:06.349874
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    print("\n---JSInterpreter---\n")
    interpreter = JSInterpreter('')
    result = interpreter.interpret_statement('var a=5; var b=6', {})
    print(result)
    result = interpreter.interpret_statement('a+b', {})
    print(result)
    result = interpreter.interpret_statement('a>>1', {})
    print(result)
    result = interpreter.interpret_statement('var a="a"; var b="b"; a+b', {})
    print(result)
    result = interpreter.interpret_statement('a*b', {'a':5,'b':6})
    print(result)
    result = interpreter.interpret_statement('a+b', {'a':5,'b':6})
    print(result)

# Generated at 2022-06-12 19:06:12.689465
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsi = JSInterpreter('')
    assert jsi.interpret_statement('var a=5', {}) == (5, False)
    assert jsi.interpret_statement('var a=3', {'a': 5}) == (3, False)
    assert jsi.interpret_statement('var a=["foo","bar"]', {}) == (['foo', 'bar'], False)
    assert jsi.interpret_statement('a.length', {'a': [1, 2, 3]}) == (3, False)
    assert jsi.interpret_statement('return a.length', {'a': [1, 2, 3]}) == (3, True)
    assert jsi.interpret_statement('return a.length; a=5', {'a': [1, 2, 3]}) == (3, True)
    assert j

# Generated at 2022-06-12 19:06:39.013590
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = "function test(a,b,c) { var d=a+b-c; return d; }"
    js = JSInterpreter(code)
    argnames = ['a', 'b', 'c']
    code = "var d=a+b-c; return d;"
    f = js.build_function(argnames, code)
    assert f([1,2,3]) == 0
    code = "if(a==0) { b=5; return b; }"
    f = js.build_function(argnames, code)
    assert f([0,2,3]) == 5
    assert f([1,2,3]) is None
    code = "a=b;"
    f = js.build_function(argnames, code)
    assert f([1,2,3]) == 2



# Generated at 2022-06-12 19:06:51.400894
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('var a = 1;')
    print(jsi.interpret_expression('a', {}, 100))
    jsi = JSInterpreter('var a = [1, 2, 3]')
    print(jsi.interpret_expression('a', {}, 100))
    jsi = JSInterpreter('var a = [1, 2, 3]')
    print(jsi.interpret_expression('a[2]', {}, 100))
    jsi = JSInterpreter('var a = "abcd"')
    print(jsi.interpret_expression('a[1]', {}, 100))
    jsi = JSInterpreter('var a = "abcd"')
    print(jsi.interpret_expression('a.length', {}, 100))

# Generated at 2022-06-12 19:06:56.571871
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_interpreter = JSInterpreter(
        code = '''
            a = {
                "b": function(p) {
                    return p;
                }
            };
        '''
    )
    obj = js_interpreter.extract_object('a')

    assert obj['b']('c') == 'c'


# Generated at 2022-06-12 19:07:08.153643
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    inter = JSInterpreter(None)
    assert inter.build_function(['abc'], 'abc=abc*10;')(100) == 1000
    assert inter.build_function(['abc', 'def'], 'abc=abc*def;')(50,2) == 100
    assert inter.build_function(['abc', 'def'], 'abc=abc*def;def=def*10;')(50,2) == 100
    assert inter.build_function(['abc', 'def'], 'abc=abc*def;return def;')(50,2) == 2
    assert inter.build_function(['abc', 'def'], 'abc=abc*def;return def*10;')(50,2) == 20

# Generated at 2022-06-12 19:07:13.974617
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-12 19:07:25.340316
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():

    # Assign operator
    assert JSInterpreter("test='test';return test;").interpret_expression("test='test';return test;",
                                                                          {"test":"test"}) == "test"
    # Plus operator
    assert JSInterpreter("test='test';return test;").interpret_expression("test='test';return test;",
                                                                          {"test":"test"}) == "test"
    # Minus operator
    assert JSInterpreter("test=-test;return test;").interpret_expression("test=-test;return test;",
                                                                          {"test":5}) == -5
    # Multiple operator
    assert JSInterpreter("test=test*5;return test;").interpret_expression("test=test*5;return test;",
                                                                          {"test":5}) == 25
    #

# Generated at 2022-06-12 19:07:30.398130
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = "function func(arg0, arg1) { return arg1+arg0}"
    js_interpreter = JSInterpreter(js_code)
    func = js_interpreter.build_function(["arg0", "arg1"], "return arg1+arg0")
    assert func((0, 1)) == 1


# Generated at 2022-06-12 19:07:33.524063
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = "function f(x, y) {return x+1;}"
    argnames = ["x","y"]
    code_str = 'return x+1;'
    assert JSInterpreter("").build_function(argnames, code_str)([1,2]) == 2


# Generated at 2022-06-12 19:07:45.474150
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('''
        function ytplayer_ES3(a, b) {
            var c = [a[0] ^ b[0], a[1] ^ b[1], a[2] ^ b[2], a[3] ^ b[3]];
            return c;
        }
        function ytplayer_ES5(a, b, c, d, e) {
            a = a[0] ^ b, c = c[0] ^ d, e = e[0] ^ b;
            var f = [a, c, e];
            return f;
        }
    ''')


# Generated at 2022-06-12 19:07:56.080369
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    import unittest