

# Generated at 2022-06-12 19:00:18.177114
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test simple expressions
    assert JSInterpreter('').interpret_expression('1', {}) == 1
    assert JSInterpreter('').interpret_expression('1.0', {}) == 1.0
    assert JSInterpreter('').interpret_expression('1.5', {}) == 1.5
    assert JSInterpreter('').interpret_expression('1e3', {}) == 1e3
    assert JSInterpreter('').interpret_expression('2e-2', {}) == 2e-2
    assert JSInterpreter('').interpret_expression('0x3', {}) == 0x3
    assert JSInterpreter('').interpret_expression('true', {}) is True
    assert JSInterpreter('').interpret_expression('false', {}) is False
    assert JSInterpreter('').interpret_

# Generated at 2022-06-12 19:00:27.082809
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Case 1: Example 1 of http://www.w3schools.com/js/js_operators.asp
    assert 3 == JSInterpreter('3').interpret_expression('3', {})
    assert 4 == JSInterpreter('3 + 1').interpret_expression('3 + 1', {})
    assert 2 == JSInterpreter('3 - 1').interpret_expression('3 - 1', {})
    assert 2 == JSInterpreter('3 * 1').interpret_expression('3 * 1', {})
    assert 3 == JSInterpreter('3 / 1').interpret_expression('3 / 1', {})
    assert 2 == JSInterpreter('9 % 7').interpret_expression('9 % 7', {})

    # Case 2: Example 2 of http://www.w3schools.com/js/js_operators.asp
    local_

# Generated at 2022-06-12 19:00:38.163290
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    class TestJSInterpreter(JSInterpreter):
        def __init__(self, code):
            self.code = code
    
    code = '''
        function func() { 
            return 1;
        }
    '''
    js = TestJSInterpreter(code)
    f = js.build_function([], 'return 1;')
    ret = f(())
    if ret != 1:
        print('TestJSInterpreter_build_function return %d fail' % ret)
        return False
    
    code = '''
        function func(a, b) { 
            return a + b;
        }
    '''
    js = TestJSInterpreter(code)
    f = js.build_function(['a', 'b'], 'return a + b;')
    ret = f

# Generated at 2022-06-12 19:00:51.080508
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    ji = JSInterpreter('var a = b;')
    assert ji.interpret_statement('a = b', {'a': 'a', 'b': 'b'}) == (
        'b', False)
    assert ji.interpret_statement('a = b + 1', {'a': 'a', 'b': 'b'}) == (
        'b1', False)
    assert ji.interpret_statement(
        'a = b + 1; c = a + 1;', {'a': 'a', 'b': 'b'}) == ('a1', False)
    assert ji.interpret_statement('a = "1";', {'a': 'a'}) == ('1', False)
    assert ji.interpret_statement('return a', {'a': 'a'}) == ('a', True)

# Generated at 2022-06-12 19:00:57.104100
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinterp = JSInterpreter('')
    func = jsinterp.build_function(['a','b','c','d','e','f','g'], "e*d+f*g;")
    assert func((1,2,3,4,5,6,7)) == 26
    assert func((7,6,5,4,3,2,1)) == 18

# Generated at 2022-06-12 19:01:09.982399
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-12 19:01:23.134421
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''a = 0
    function bt(a,b,c){
        var d=a.length,e=[],g=0,h=0;
                    h=e[c]^=d;
        for(g=0;g<d;g++)e.push(b[g%b.length]);
        return e}
    function escape(a){
        return a.split("").reverse().join("")}'''
    def test_case(func_name, args, answer):
        print ("func_name = ",func_name)
        print ("args = ",args)
        print ("answer = ",answer)
        print ("--------------------")
        js_interpreter = JSInterpreter(code)
        resf = js_interpreter.build_function(args, code)

# Generated at 2022-06-12 19:01:34.795932
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-12 19:01:39.207087
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test_swap(a, b) {
            var c = a;
            a = b;
            b = c;
        }
    '''
    interpreter = JSInterpreter(code)
    interpreter.build_function(['a', 'b'], 'var c = a; a = b; b = c')


# Generated at 2022-06-12 19:01:48.266842
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_code = '''
    var a = 5;
    var b = 6;
    var c = 7;
    var d = "asdf";
    var e = a + b;
    var f = d + e;
    '''
    jsinterpreter = JSInterpreter(js_code)
    local_vars = jsinterpreter.interpret_statement('var a = 5', {})
    local_vars = jsinterpreter.interpret_statement('var b = 6', local_vars)
    local_vars = jsinterpreter.interpret_statement('var c = 7', local_vars)
    local_vars = jsinterpreter.interpret_statement('var d = "asdf"', local_vars)

# Generated at 2022-06-12 19:02:14.727688
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:02:19.445946
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test for method interpret_expression of class JSInterpreter
    # Case 1: verify the result of statement like "a=b+c"
    test_code_1 = '''var a=b+c;'''
    ji_1 = JSInterpreter(test_code_1)
    ji_1.interpret_expression("a=b+c", {"b":1, "c":2})
    assert ji_1.interpret_expression("a==b+c", {"b":1, "c":2})==True

    # Case 2: verify the result of statement like "a++"
    test_code_2 = '''var a=2; a++'''
    ji_2 = JSInterpreter(test_code_2)
    ji_2.interpret_expression("a++", {"a":1})

# Generated at 2022-06-12 19:02:27.436751
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})

    def testcase(funcname, args, code, expected):
        v = js_interpreter.build_function(args.split(','), code)
        actual = v(args.split(','))
        if actual != expected:
            print('Error on JSInterpreter.build_function case for "%s":' % (funcname))
            print(' - expected: %s' % expected)
            print(' - actual  : %s' % actual)
        assert actual == expected

    testcase('f1', 'a,b', 'a+b;', 3)
    testcase('f2', 'a,b', 'a+b;a-b;', 1)

# Generated at 2022-06-12 19:02:41.368945
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = 'var obj1 = {"foo": function(a, b) {var c; c = a; if (b) {c = c + b;} return c;}};'
    e = JSInterpreter(code)
    f = e.build_function(['a', 'b'], 'var c; c = a; if (b) {c = c + b;} return c;')
    assert f((1, 2)) == 3
    assert f((1, None)) == 1
    assert f((1, 'bar')) == '1bar'

    code = 'var obj2 = {"hi, my name is": function(a) {return a}};'
    e = JSInterpreter(code)
    f = e.build_function(['a'], 'return a;')

# Generated at 2022-06-12 19:02:54.281984
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interp = JSInterpreter("""x=5;
    y=5;
    var z=6;
    function abc(a,b,c) {
        a=b*c;
        return x
        }
    var xxx=0;
    xxx=function(a,b,c){
        return x;
        }
    var jkl=xxx;
    var foo=function(a,b,c){
        return x;
        }
    foo(1,2,3)
    function foo2(a,b,c){
        return x;
        }
    foo2(1,2,3)
    var foo3=function foo(a,b,c){
        return x;
        }
    """)

# Generated at 2022-06-12 19:03:03.661569
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # _extract_signature() in youtube_dl/extractor/youtube.py, line ~515
    code = '''\
    function nZ(a, b) {
        b.push(a[0] << 24 | a[1] << 16 | a[2] << 8 | a[3]);
        return b
    };
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('nZ', [0, 1, 0, 0], [0]) == [16777216]

# Generated at 2022-06-12 19:03:12.465328
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:03:20.515732
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_js_code = """
    (function () {
        var b = function (a) {
            return a ? [a[0], a[1], a[2]] : [];
        };
        var c = function (a) {
            var d = b(a);
            d[0] = 'c';
            return d;
        };
        var e = function (a) {
            var d = c(a);
            d[0] = 'e';
            return d;
        };
        console.log(e(['a', 'b', 'c']));
    })();\n
    """
    ji = JSInterpreter(test_js_code, objects={})
    ji.extract_function('b')
    ji.extract_function('c')
    e = ji

# Generated at 2022-06-12 19:03:26.662788
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        f("Hi!");
        var f = function(alert_txt) {
            alert(alert_txt);
            return "foo";
        };
    '''
    interp = JSInterpreter(code)
    f1 = interp.extract_function('f')
    f2 = lambda x: ('foo',)
    assert f1 == f2, 'extract_function not working'


# Generated at 2022-06-12 19:03:29.483822
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    assert JSInterpreter('var func = function(a,b){return a+b;}').call_function('func',1,2) == 3


# Generated at 2022-06-12 19:03:52.102541
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
    var swf = "some.swf";
    var swfParams = {
        algo: function(arg1, arg2) {
            return arg1 * arg2;
        },
        foo: "bar",
        baz: {
          a: "A",
          b: "B",
          c: "C"
        }
    };
    '''

    interpreter = JSInterpreter(code)
    local_vars = {
        'swf': 'some.swf',
        'swfParams': {
          'algo': lambda x, y: x * y,
          'foo': 'bar',
          'baz': {
            'a': 'A',
            'b': 'B',
            'c': 'C'
          }
        }
    }

# Generated at 2022-06-12 19:04:02.989271
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # test code
    code = r'''
        function raw_cc(){
            var A = {
                a: function(a) {
                    return 'a'
                },
                b: function(a, b) {
                    return a+b
                },
                c: function(a) {
                    return a
                }
            };
            return A
        }
    '''
    # expected result
    expected = {
        'a': lambda a:'a',
        'b': lambda a,b: a+b,
        'c': lambda a: a
    }
    # extract object
    obj = JSInterpreter(code).extract_object('A')
    # test if result equals expected
    assert obj == expected, '%s != %s' % (obj, expected)


# Generated at 2022-06-12 19:04:14.707622
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Simple example
    JSInterpreter("").interpret_expression("a+b*c", {"a": 1, "b": 2, "c": 3}) == 7
    # Complex example
    JSInterpreter("").interpret_expression("a+b*c[d]", {"a": 1, "b": 2, "c": (1, 2, 3), "d": 2}) == 7
    # Use the function split.
    JSInterpreter("").interpret_expression("a.split('')", {"a": 'abc'}) == ["a", "b", "c"]
    # Use the function join.
    JSInterpreter("").interpret_expression("a.join('.')", {"a": ["a", "b", "c"]}) == "a.b.c"
    # Use the function reverse.
    JSInterpreter("").interpret

# Generated at 2022-06-12 19:04:27.475033
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:04:40.681967
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:04:52.742308
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter("")
    # 1, '1'
    print("1, '1':\t\t" + str(js_interpreter.interpret_expression("1", None)))
    print("1, '1':\t\t" + str(js_interpreter.interpret_expression("'1'", None)))
    # 1 + 1
    print("1 + 1:\t\t" + str(js_interpreter.interpret_expression("1+1", None)))
    # '1' + '1'
    print("'1' + '1':\t\t" + str(js_interpreter.interpret_expression("'1' + '1'", None)))
    # '1' + 1

# Generated at 2022-06-12 19:05:04.597439
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:05:10.382730
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:05:17.204344
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    c = r'''
    var _0x5e38=[];
    function _0x3bdb(_0x3f6f) {
        return _0x3f6f*_0x3f6f;
    }
    '''

    args = [5, -10, 100]
    js_interpreter = JSInterpreter(c)
    for arg in args:
        ans = js_interpreter.call_function('_0x3bdb', arg)
        assert arg*arg == ans


# Generated at 2022-06-12 19:05:21.165740
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():

    # Define local variables
    interp = JSInterpreter("")
    stmt = "(case_1) { var x ; var y = 1 ; }"
    local_vars = {"x": 1, "y": 1}
    allow_recursion = 10

    # Call the method
    v, should_abort = interp.interpret_statement(stmt, local_vars, allow_recursion)

    # Check the results
    assert v is None
    assert should_abort is False

# Generated at 2022-06-12 19:06:09.708883
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter("""
        a = {};
        b = {};
        c = {};
        d = {};
        e = {};
        f = {};
        g = {};
        a.b = function(c) {
            d.e = function(f) {
                g.h = function(i, j) {
                    return i + j + f;
                };
                return 'foo' + f;
            };
            return 'boo' + c;
        };
        """)
    a = interpreter.extract_object('a')
    assert a.get('b')('b') == 'boob'
    assert a['b']('b') == 'boob'
    assert a['b']('c') == 'booc'

# Generated at 2022-06-12 19:06:21.883276
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # simple test
    interpreter = JSInterpreter('a')
    assert interpreter.interpret_statement('a', {}) == (None, False)
    assert interpreter.interpret_statement('return a', {}) == (None, True)
    assert interpreter.interpret_statement('var a', {}) == (None, False)

    # test for operator '+'
    interpreter = JSInterpreter('1 + a')
    assert interpreter.interpret_statement('1 + a', {'a': 2}) == (3, False)
    assert interpreter.interpret_statement('1+a', {'a': 2}) == (3, False)
    assert interpreter.interpret_statement('1 +a', {'a': 2}) == (3, False)
    assert interpreter.interpret_statement('1+ a', {'a': 2}) == (3, False)

    #

# Generated at 2022-06-12 19:06:32.305270
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    """
    To test JSInterpreter.interpret_expression
    """

# Generated at 2022-06-12 19:06:43.924976
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('', {})
    res = jsi.interpret_expression('false && true', {}, 100)
    assert res == False
    jsi = JSInterpreter('', {})
    res = jsi.interpret_expression('true && false', {}, 100)
    assert res == False
    jsi = JSInterpreter('', {})
    res = jsi.interpret_expression('true || false', {}, 100)
    assert res == True
    jsi = JSInterpreter('', {})
    res = jsi.interpret_expression('1 ^ 0', {}, 100)
    assert res == 1
    jsi = JSInterpreter('', {})
    res = jsi.interpret_expression('1 >> 2', {}, 100)
    assert res == 0

# Generated at 2022-06-12 19:06:56.528428
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = '''
        var o = {
            a: function(arg1, arg2) {
                var t;
                t=arg1+arg2;
                return arg1/t;
            },
            b: function(arg1) {
                return 5-arg1;
            }
        };

        function f(arg1, arg2) {
            return o.a(arg1, arg2) + o.b(arg1);
        }
    '''

    jsi = JSInterpreter(js)
    f = jsi.extract_function('f')
    assert f((2, 2)) == 6
    f = jsi.extract_function('f')
    assert f((5, 5)) == 0
    oa = jsi.extract_object('o')['a']
    assert oa

# Generated at 2022-06-12 19:07:08.058320
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def test_interpret_expression_should_fail(self, expr):
        self.assertRaises(ExtractorError, self.interpreter.interpret_expression, expr, {})

    def test_interpret_expression_should_pass(self, expr, expected, values_dict):
        self.assertEqual(expected, self.interpreter.interpret_expression(expr, values_dict))

    jsi = JSInterpreter('')

# Generated at 2022-06-12 19:07:14.113026
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    assert JSInterpreter('''
        var obj1 = {
            aa: function(){},
            bb: function(){},
            cc: {d: 0, e: 1},
            dd: 0
        }''').extract_object('obj1') == {'aa': {}, 'bb': {}, 'cc': {'d': 0, 'e': 1}, 'dd': 0}
    assert JSInterpreter('''
        var obj2 = {
            aa: function(){},
            bb: function(){},
            cc: {d: 0, e: 1},
            dd: 0
        }''').extract_object('obj2') == {'aa': {}, 'bb': {}, 'cc': {'d': 0, 'e': 1}, 'dd': 0}

# Generated at 2022-06-12 19:07:18.724541
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''var cube = { test: function(x,y){return x*x*x;} };'''
    interpreter = JSInterpreter(code)
    result = interpreter.extract_object('cube')
    assert result['test'](3,1) == 27

# Generated at 2022-06-12 19:07:23.110706
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """var Ad = {
  wl: function(c) {
    window.alert(c)
  },
  get_obj: function(b, a) {
    return b[a]
  }
};
var C = {
  f: function(b, a) {
    return b * a
  },
  y: true,
  x: false
};
"""
    interpreter = JSInterpreter(code)
    assert set(interpreter._objects.keys()) == set(['Ad', 'C'])
    ad = interpreter._objects['Ad']
    c = interpreter._objects['C']
    assert ad['wl']('hello') is None
    assert ad['get_obj'](c, 'f') == c['f']
    assert ad['get_obj'](c, 'y') is True
   

# Generated at 2022-06-12 19:07:32.705873
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsInter = JSInterpreter('')
    assert jsInter.interpret_expression('a', {'a' : 23}) == 23
    assert jsInter.interpret_expression('a+3', {'a' : 23}) == 26
    assert jsInter.interpret_expression('a+a', {'a' : 23}) == 46
    assert jsInter.interpret_expression(
        'a+a',
        {'a' : 23, 'b' : 'c'}) == 46
    assert jsInter.interpret_expression(
        'a+b',
        {'a' : 23, 'b' : 'c'}) == '23c'
    assert jsInter.interpret_expression(
        'a+b',
        {'a' : 23, 'b' : ['c']}) == ['23', 'c']
    assert jsInter

# Generated at 2022-06-12 19:08:21.551399
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def _test_function(js_function, expected_result, *args):
        interpreter = JSInterpreter(code=js_function)
        interpreter.build_function(argnames=[], code=js_function)
        result = interpreter.call_function(funcname='func', *args)
        assert result == expected_result

    _test_function(
        js_function='''function func() { return 42; }''',
        expected_result=42
    )
    _test_function(
        js_function='''function func() { return [1, 2]; }''',
        expected_result=[1, 2]
    )

# Generated at 2022-06-12 19:08:27.979891
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code='function func(a, b) {return a+b;}'
    argnames=['a', 'b']
    code='return a+b;'

# Generated at 2022-06-12 19:08:40.324391
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:08:48.267361
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = r'''
        function f(a) {return a + x;}
        var x = y;
        var y = 3;

        function g(a) {return a + y;}
        var y = 5;
        '''
    obj = JSInterpreter(js)
    assert obj.call_function('f', 4) == 7
    assert obj.call_function('g', 4) == 9



# Generated at 2022-06-12 19:08:57.760943
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    class JSInterpreter_test_class(JSInterpreter):
        def __init__(self, code, objects=None):
            super().__init__(code, objects)
            if isinstance(self.code, str):
                self.code = self.code.decode('ascii')

        def test_extract_function(self, funcname):
            return self.extract_function(funcname)


# Generated at 2022-06-12 19:09:05.834898
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsinter = JSInterpreter('''
        function f(){
            var i = 1;
            var z = this.a(i, 2);
            return z;
        }
        b = {
            'c': function(u){
                return this.d(u);
            },
            'd': function(e){
                var f = 1;
                return e * f;
            }
        };''')
    assert jsinter.interpret_expression('b.c(2)') == 2
    assert jsinter.interpret_expression('b.d(3)') == 3

# Generated at 2022-06-12 19:09:14.461787
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:09:25.678656
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsi = JSInterpreter('')
    local_vars_1 = {'a': 5, 'b': 10}
    local_vars_2 = {'result': 1}
    assert (1, False) == jsi.interpret_statement("a = 5; b = 10; result = result ^ a + b", local_vars_2, 100)
    assert 16 == local_vars_2['result']
    assert (None, False) == jsi.interpret_statement("a = b + 5;", local_vars_1, 100)
    assert 15 == local_vars_1['a']
    assert (None, True) == jsi.interpret_statement("return b + 5;", local_vars_1, 100)