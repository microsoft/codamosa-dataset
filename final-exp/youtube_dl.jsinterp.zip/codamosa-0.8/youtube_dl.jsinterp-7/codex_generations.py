

# Generated at 2022-06-12 19:00:08.613280
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js1 = '''
        foo = {
            bar: function(a, b) {
                return a + b;
            }
        };
    '''
    obj = JSInterpreter(js1).extract_object('foo')
    assert obj['bar'](1, 2) == 3
    assert obj['bar'](4, 5) == 9

    js2 = '''
        foo = function(a) {
            return a;
        }
    '''
    foo = JSInterpreter(js2).extract_function('foo')
    assert foo([1, 2, 3]) == [1, 2, 3]
    assert foo(['a', 'b', 'c']) == ['a', 'b', 'c']


# Generated at 2022-06-12 19:00:14.487327
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    try:
        JSInterpreter('var x; var y; return x;').interpret_statement('y=5', {})
    except ExtractorError as e:
        if str(e) != 'Premature right-side return of = in \'y=5\'':
            raise Exception("test_JSInterpreter_interpret_statement failed")

test_JSInterpreter_interpret_statement()


# Generated at 2022-06-12 19:00:24.786122
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:00:37.047750
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    import os
    import urllib
    from echonest_text_to_speech.tools.js_interpreter import JSInterpreter
    js_file_path = os.path.join(os.path.dirname(__file__), 'js_files/xxxx.js')
    print("js_file_path:" + js_file_path)
    with open(js_file_path, 'rb') as js_file:
        code = urllib.unquote(js_file.read())
        js_interpreter = JSInterpreter(code)
        build_func_dict = {}

# Generated at 2022-06-12 19:00:48.936738
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var some_var = -1;
        var some_other_var = {
            "some_meth": function(a,b,c) { return a + b + c; },
            "some_other_meth": function(a,b) { return a - b; }
        };
        function some_func(a,b,c) {
            return a * b * c;
        };
    '''
    jsi = JSInterpreter(code)

    obj = jsi.extract_object('some_other_var')
    assert obj['some_meth'](1, 2, 3) == 6
    assert obj['some_other_meth'](3, 2) == 1



# Generated at 2022-06-12 19:01:00.664622
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        var obj = {
            func: function(var1) {
                var localvar = var1 + 10;
                return localvar*2;
            }
        };
        """
    interp = JSInterpreter(code)
    func = interp.extract_function('obj.func')
    assert func((5,)) == 30

    code = """
        var func = function(var1, var2, var3) {
            return var3*3;
        };
        """
    interp = JSInterpreter(code)
    func = interp.extract_function('func')
    assert func((1, 2, 3)) == 9
    func = interp.call_function('func', 1, 2, 3)
    assert func == 9


# Generated at 2022-06-12 19:01:13.539667
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        v=function(){};
        v.a=function(){};
        s={"bjp":function(){},
           "fqt":function(){}
          };
    '''
    obj = JSInterpreter(code).extract_object('s')
    assert len(obj) == 2

    # Unit test for method extract_function of class JSInterpreter
    code = '''
        function v("a","b"){};
        s=function("a","b"){};
    '''
    v = JSInterpreter(code).extract_function('v')
    assert v

    # Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:01:26.870208
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_inputs = ['var a = function(){};',
                   'function(a){var b = function(){};return a+1;};',
                   'function(a){var b = function(){};return a+1;};',
                   'function(a){return a+1;};',
                   'function(a, b){return a+b;};']
    expected_outputs = [{'a': []},
                        {'b': [1]},
                        {'b': [1]},
                        {'a': [2]},
                        {'a': [2], 'b': [3]}]
    cnt = 0
    for text in test_inputs:
        interpreter = JSInterpreter(text)
        code = interpreter.build_function(['a', 'b'], text)

# Generated at 2022-06-12 19:01:37.668553
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:01:44.910669
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    objects = {
        'a': [1, 2, 3],
        'b': {
            'c': {
                'e': ['a', 'b', 'c']
            }
        },
        'd': {
            'f': [1, 2, 3],
            'g': 'abc'
        }
    }
    interpreter = JSInterpreter('', objects)

    # test case 1: expr as a value
    expr = '{}'
    expected_result = {}
    assert interpreter.interpret_expression(expr, objects) == expected_result

    # test case 2: expr as a variable
    expr = 'a'
    expected_result = [1, 2, 3]
    assert interpreter.interpret_expression(expr, objects) == expected_result

    # test case 3: expr as an object

# Generated at 2022-06-12 19:02:25.906253
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter('obj={}')
    jsi.extract_object('obj')
    jsi._objects['obj']['a'] = 'a'
    jsi._objects['obj']['c'] = 'c'

    build_function = JSInterpreter.build_function
    jsi_b = build_function(jsi, ['a', 'b', 'c'], 'a=b; return c;')
    assert jsi_b('a', 'b', 'c') == 'c'
    assert jsi_b('a', 'b', 'd') == 'd'
    assert jsi_b('a', 'd', 'c') == 'c'

    jsi_b = build_function(jsi, ['a'], "return -a;")

# Generated at 2022-06-12 19:02:39.618260
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # TODO: remove this function once the unit test for JSInterpreter
    # is added in test_extractor_common.py
    # The test for this function is based on the test for JSInterpreter
    # in test_utils.py, but the test for JSInterpreter in
    # test_utils.py is not compatible with the new refactored
    # class JSInterpreter.
    code = r'''
        function f1(a,b,c) {
            function f2(d,e,f) {
                function f3(g,h,i,j) {
                    return g+h+i+j;
                }
            }
        }
    '''
    js_interpreter = JSInterpreter(code)

# Generated at 2022-06-12 19:02:45.443072
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = """
        var a = {
            "b": function() {},
            "c": function(d) {},
            "e": {
                "f": function() {}
            }
        };
        """

    obj = JSInterpreter(js_code).extract_object("a")
    assert "b" in obj
    assert "c" in obj
    assert "e" in obj

if __name__ == '__main__':
    test_JSInterpreter_extract_object()

# Generated at 2022-06-12 19:02:58.702959
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        var func_1 = function (arg1, arg2) {
            var arg3 = arg1 + arg2;
            var arg4 = arg1 * arg2;
            return arg4 - arg3;
        }
    """)

    # Test 1: simple statement
    func = js_interpreter.extract_function("func_1")
    assert func((2, 3)) == 3

    # Test 2: function with a simple object member

# Generated at 2022-06-12 19:03:06.618405
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    JSI = JSInterpreter(code = """
        function testFunction(arg1, arg2) {
            var localVar1 = 10;
            var localVar2 = arg2;
            var result = arg1 + localVar1 + localVar2 + math.sin(math.PI / 6);
            return result;
        }
    """, objects = { 'math' : {'sin': lambda x: 0.5 } })

    print(JSI.call_function("testFunction", 2, 3))


# Generated at 2022-06-12 19:03:16.438367
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test(code, funcname, args, expected):
        print(code, funcname, args, expected)
        interpreter = JSInterpreter(code)
        f = interpreter.build_function([], code)
        assert f(None) == expected
        f_extracted = interpreter.extract_function(funcname)
        assert f_extracted(tuple(args)) == expected

    test(
        "parseInt('00110111',2)",
        'parseInt',
        ['00110111', 2],
        55
    )

    test(
        "parseInt('00110111',2)",
        'parseInt',
        ['00110111', 2],
        55
    )


# Generated at 2022-06-12 19:03:21.453078
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = '''\
        var obj = {
            c: function(a, b) {
                return a + b;
            },
        }'''
    interp = JSInterpreter(js)
    obj = interp.extract_object('obj')
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-12 19:03:31.710265
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = ('''
        var $ = function(a, b) {
            return function(c) {
                return a + b + c;
            };
        };

        var ab = {
            "a": 1,
            "b": [2, 3],
            "c": {"d": 4},
            "f": function(a, b) {
                return a + b;
            }
        }
    ''')

    js = JSInterpreter(js_code)
    assert js.interpret_expression('1', {}) == 1
    assert js.interpret_expression('1+1', {}) == 2
    assert js.interpret_expression('1+1+1', {}) == 3
    assert js.interpret_expression('1+1+1+1', {}) == 4


# Generated at 2022-06-12 19:03:33.857456
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    assert JSInterpreter('').call_function('f', 'a', 'b') == None
    

# Generated at 2022-06-12 19:03:44.752082
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test function1
    function1 = '''
        function f(arg1, arg2, arg3){
            var a = arg1,
                b = [1, 2, 3],
                c = arg3;
            a = a ^ b[1];
            return a;
        }
    '''
    interpreter = JSInterpreter(function1)
    function = interpreter.build_function(['arg1', 'arg2', 'arg3'], function1.split('{')[1].rsplit('}')[0].strip())
    assert function([1, 2, 3]) == 0, 'Error test for method build_function of class JSInterpreter'

    # Test function2

# Generated at 2022-06-12 19:04:03.043701
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        this.a = {
            hello: function (k,t,f){console.log(k)},
            test: "test"
        };
    '''
    interp = JSInterpreter(code)
    obj = interp.extract_object("a")
    assert isinstance(obj, dict)
    assert obj["test"] == "test"
    assert isinstance(obj["hello"], FunctionType)
    obj["hello"]("value", "value", "value")


# Generated at 2022-06-12 19:04:14.763802
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code='''
        function foo(a, b){
            var c=a+b;
            var d=b-a;
            return c/d;
        }

        function bar(a, b){
            var c=a-b;
            var d=b+a;
            return c/d;
        }
    '''
    js_interpreter=JSInterpreter(js_code)
    assert 'foo' in js_interpreter._functions
    f_foo=js_interpreter._functions['foo']
    assert 'bar' in js_interpreter._functions
    f_bar=js_interpreter._functions['bar']
    assert f_foo(1, 2) == 0.5
    assert f_bar(2, 1) == 0.5

#

# Generated at 2022-06-12 19:04:19.278071
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
        function abc(a, b, c) {
            var e = a;
            var f = b;
            var g = c;
            if (a == b) {
                e = c;
            };
            return d + g;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    func = js_interpreter.build_function(['a', 'b', 'c'], '''
            var e = a;
            var f = b;
            var g = c;
            if (a == b) {
                e = c;
            };
            return d + g;
        ''')
    assert func([1, 1, 2]) == 3
    assert func([2, 1, 2]) == 4

# Generated at 2022-06-12 19:04:25.286604
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_code = """
        var test_me_1 = {
            "me": function(a, b) {
                return a + b;
            }
        };
    """
    jsi = JSInterpreter(test_code)
    assert jsi.call_function('test_me_1.me', 2, 3) == 5


# Generated at 2022-06-12 19:04:35.814621
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    snippet = '''var aa = {
  "s1": "v1",
  "s2": "v2",
  "s3": function(p1, p2) {return p1 + p2;},
  "s4": function(p1, p2) {return p1 * p2;}
};
var bb = aa.s3("aa", "bb");
var cc = aa.s4(2, 3);
'''
    bb = JSInterpreter(snippet).interpret_expression('bb')
    assert bb == 'aabb'
    cc = JSInterpreter(snippet).interpret_expression('cc')
    assert cc == 6

# Generated at 2022-06-12 19:04:46.165399
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_JSInterpreter_interpret_expression.__test__ = False

    def assert_expr_equals(expr, expect):
        assert interpreter.interpret_expression(expr, {}) == expect

    interpreter = JSInterpreter(None)
    assert_expr_equals('12', 12)
    assert_expr_equals('(12)', 12)
    assert_expr_equals('(1+2)', 3)
    assert_expr_equals('(1+2)*3', 9)
    assert_expr_equals('(1+2+3)*3', 18)
    assert_expr_equals('(1 + 2 + 3) * 3', 18)
    assert_expr_equals('1+2*3', 7)

# Generated at 2022-06-12 19:04:52.960584
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test1 = """
    a="b";
    c={
        d:"e"
    }
    """
    js_i = JSInterpreter(test1)
    assert js_i._objects == {}
    c = js_i.extract_object("c")
    assert c["d"] == "e"
    assert js_i._objects == {"c": c}
    assert js_i.extract_object("c") is c


# Generated at 2022-06-12 19:05:04.773476
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''var evaluate = function (s){eval(s);}
        var x = function (s){return eval(s);}
        var y = function (s){return x(s);}
        var z = function (s){return y(s);}
        var add1 = function(x){return(x+1);}
        var add2 = function(x){return(x+2);}
        var mul1 = function(x,y){return(x*y);}
        var mul2 = function(x,y){return(y*x);}
        var mul3 = function(x,y,z){return(x*y*z);}
        ''' 
    # Create a JSInterpreter
    jsinter = JSInterpreter(js_code)

# Generated at 2022-06-12 19:05:15.155764
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:05:20.024622
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test JS code using eval or toSource (Mozilla and Rhino specific)

    # eval
    interpreter = JSInterpreter('function f(a, b) { return eval(a); }')
    f = interpreter.build_function(['a', 'b'], 'return eval(a);')
    assert f(['2+2', 'a']) == 4

    # toSource
    interpreter = JSInterpreter('function f(a, b) { return a.toSource(); }')
    f = interpreter.build_function(['a', 'b'], 'return a.toSource();')
    assert f([[1, 2], 'a']) == '[1, 2]'


# Generated at 2022-06-12 19:05:37.609173
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
            var A = {
                "b": function (a, b) { return a + b; },
                "c": function (a, b) { return a - b; }
            }
            '''

    interp = JSInterpreter(code)

    obj = interp.extract_object('A')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == -1

# Generated at 2022-06-12 19:05:46.050598
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test method build_function.
    # Test 1, function only with one argument.
    code="""
    function func1(a) {
        return a+1;
    }
    """
    f=JSInterpreter(code)
    assert f.extract_function('func1')((2,))==3
    # Test 2, function only with two arguments.
    code="""
    function func2(a,b) {
        return a+b;
    }
    """
    f=JSInterpreter(code)
    assert f.extract_function('func2')((2,3))==5
    # Test 3, function with two arguments and one extra argument
    # to test if the extra argument is ignored

# Generated at 2022-06-12 19:05:57.349248
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    #First, we have to instantiate the JsInterpreter
    interpreter = JSInterpreter("")
    #We have a bug: when an expression is finished with a dot, we don't eat it
    #and test fails
    assert interpreter.interpret_expression("window.location.href", {}) == None
    #This assertion passed
    assert interpreter.interpret_expression("window.location.href.new_name", {}) == None
    #We modify the code to eat the dot
    interpreter = JSInterpreter("")
    assert interpreter.interpret_expression("window.location.href", {}) == None
    #This assertion passed
    assert interpreter.interpret_expression("window.location.href.new_name", {}) == None
    #We have a bug: in the line 1195, we don't use the member 'pop' when it is
    #

# Generated at 2022-06-12 19:06:04.180922
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("function test(a){var b,c,d;b=1;c=a+b;return c;};")
    args = list()
    args.append("a")
    function = js_interpreter.build_function(args, "var b,c,d;b=1;c=a+b;return c;")
    result = function([3])


# Generated at 2022-06-12 19:06:11.680144
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    # Test for a simple expression
    assert js_interpreter.interpret_expression('1', {}) == 1
    # Test for a simple expression with whitespace
    assert js_interpreter.interpret_expression('1', {}) == 1
    # Test for multiple expressions with whitespace
    assert js_interpreter.interpret_expression('1 + 1', {}) == 2
    # Test for multiple expressions with whitespace and parentheses
    assert js_interpreter.interpret_expression('(1 + 1)', {}) == 2
    # Test for multiple expressions with whitespace and parentheses
    assert js_interpreter.interpret_expression('((1 + 1))', {}) == 2
    # Test for multiple expressions with whitespace, parentheses, and variables

# Generated at 2022-06-12 19:06:23.161565
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # pylint: disable=no-self-use
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('', {})[0] is None
    assert js_interpreter.interpret_statement('abc', {})[0] == 'abc'
    assert js_interpreter.interpret_statement('"abc"', {})[0] == 'abc'
    assert js_interpreter.interpret_statement('return abc', {})[0] == 'abc'
    assert js_interpreter.interpret_statement('return', {})[0] is None
    assert js_interpreter.interpret_statement('var abc = "hello"', {})[0] == 'hello'
    assert js_interpreter.interpret_statement('abc', {})[0] == 'hello'
    assert js_

# Generated at 2022-06-12 19:06:33.381457
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    assert JSInterpreter('').interpret_statement('3', {})[0] == 3
    assert JSInterpreter('').interpret_statement('"a"', {})[0] == 'a'
    assert JSInterpreter('').interpret_statement('{}', {})[0] == {}
    assert JSInterpreter('').interpret_statement('[]', {})[0] == []
    assert JSInterpreter('').interpret_statement('true', {})[0] == True
    assert JSInterpreter('').interpret_statement('false', {})[0] == False
    assert JSInterpreter('').interpret_statement('undefined', {})[0] == None

    assert JSInterpreter('').interpret_statement('f', {'f': 'g'})[0] == 'g'


# Generated at 2022-06-12 19:06:45.763290
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:06:57.378519
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_in = """{
      var a = [1, 2, 3];
      var b = a.map(function(x) {
        return x+1;
      });
      var c = a.reduce(
          function(x, y) {
              return x+y;
          },
          0);
      var d = a.filter(
          function(x) {
              return (x % 2) == 0;
          });
    }"""
    js_exp = {
        'a' : [1, 2, 3],
        'b' : [2, 3, 4],
        'c' : 6,
        'd' : [2]
    }

    jsi = JSInterpreter(js_in)
    v = jsi.call_function('test', js_in)


# Generated at 2022-06-12 19:07:08.772035
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''\
      function test1(args) {
        var a = args[0];
        var b = args[1];
        return a + b;
      }''')
    assert js_interpreter.call_function('test1', 1, 2) == 3

    js_interpreter = JSInterpreter('''\
      function test2(args) {
        var a = args[0];
        var b = args[1];
        return a + a * b + b;
      }''')
    assert js_interpreter.call_function('test2', 1, 2) == 5


# Generated at 2022-06-12 19:07:45.968452
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:07:49.928344
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter("var b=3;var a='3';")
    assert js_interpreter.interpret_expression('b', {}) == 3
    assert js_interpreter.interpret_expression('a', {}) == '3'

# Generated at 2022-06-12 19:08:01.060248
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:08:03.950894
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(['a', 'b'], 'a+b')(2, 3) == 5



# Generated at 2022-06-12 19:08:09.752579
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        obj1 = {
            obj1_1: function(a, b) { return a + b; },
            obj2_2: function(a, b) { return a * b; },
        };

        obj2 = {
            obj2_1: function(a, b) { return a - b; },
            obj2_2: function(a, b) { return a / b; },
        };
    '''
    o = JSInterpreter(code)
    obj1 = o.extract_object('obj1')
    obj2 = o.extract_object('obj2')

    assert len(obj1) == 2
    assert obj1['obj1_1'](1, 2) == 3
    assert obj1['obj2_2'](5, 6) == 30


# Generated at 2022-06-12 19:08:21.594715
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
            c = {
                ba: function() {},
                b: function(c) {},
                a: function(a, b) {},
                d: function() {return 1;}
            };
            '''
    jsi = JSInterpreter(code)
    obj = jsi.extract_object('c')
    assert callable(obj['a'])
    assert callable(obj['b'])
    assert callable(obj['d'])
    assert obj['d']() == 1
    assert obj['a'](1, 2) is None

if __name__ == '__main__':
    import sys
    test_JSInterpreter_extract_object()
    # js_code = open(sys.argv[1]).read()
    # js_interpreter = JSInter

# Generated at 2022-06-12 19:08:33.853118
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_code = '''
        function test_func(a, b, c){
            var __valid_fn = function(){
                return b.join(a.reverse().slice(c));
            }

            var __combine_fn = function(){
                var __ary = Array(b);
                var __result = Array();

                for (var i = 0; i < c; i++) {
                    __result[i] = __ary[i] >>> a[__valid_fn()];
                }

                return __result;
            }

            return __combine_fn();
        }
    '''

    # test __valid_fn()
    interpreter = JSInterpreter(test_code)
    a = ['a', 'b']
    b = [1, 2, 3, 4]
    c = 1

# Generated at 2022-06-12 19:08:41.761558
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var obj = {
            func1: function(arg1) { return arg1 },
            func2: function(arg1, arg2) { return arg1 + arg2 }
        }
    '''
    js = JSInterpreter(js_code)
    obj = js.extract_object('obj')
    assert obj['func1']('a') == 'a'
    assert obj['func2']('a', 'b') == 'ab'


# Generated at 2022-06-12 19:08:47.821761
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = r'''
    function p(a,b) {
        return a+b;
    }
    '''

    jsi = JSInterpreter(code)

    assert jsi.call_function('p', 1, 2) == 3

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-12 19:08:57.458974
# Unit test for method interpret_expression of class JSInterpreter