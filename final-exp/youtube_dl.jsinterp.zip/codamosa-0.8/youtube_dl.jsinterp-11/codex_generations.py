

# Generated at 2022-06-12 19:00:23.571186
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:00:36.863337
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Tests extract_object with the following JS code:
    #
    # yt.playerConfig = {
    #   "args": {
    #     'a_key': 'a_val',
    #     'another_key': 'another_val',
    #   },
    #   'player': {
    #     'key1': 'val1',
    #     'key2': 'val2',
    #   }
    # }
    if __name__ == '__main__':
        code = """
        yt.playerConfig = {
            "args": {
                'a_key': 'a_val',
                'another_key': 'another_val',
            },
            'player': {
                'key1': 'val1',
                'key2': 'val2',
            }
        }"""

# Generated at 2022-06-12 19:00:44.534672
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        a = {'aa': 10, 'bb': 20};
        b = {
            func1: function() {return 10;},
            func2: function(a, b) {return a+b;}
        };"""
    jsint = JSInterpreter(code)
    obj = jsint.extract_object('b')

    assert obj == {
        'func1': lambda args: 10,
        'func2': lambda args: args[0] + args[1]
    }


# Generated at 2022-06-12 19:00:57.325730
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        var this = {};
        this.encodeURIComponent = function(a)
        {
            return encodeURIComponent(a).replace(/%([0-9A-F]{2})/g, function()
            {
                return String.fromCharCode('0x' + arguments[1]);
            });
        };
        """)
    f = js_interpreter.build_function(['a'], """
        var a = encodeURIComponent(a);
        var b = a.replace(/%([0-9A-F]{2})/g, function()
        {
            return String.fromCharCode('0x' + arguments[1]);
        });
        return b;
        """)

# Generated at 2022-06-12 19:01:10.218065
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterpreter = JSInterpreter('')
    print(jsinterpreter.interpret_expression('["abc", "def"]', {}))
    print(jsinterpreter.interpret_expression('8', {}))
    print(jsinterpreter.interpret_expression('8+3', {}))
    print(jsinterpreter.interpret_expression('8*3+1', {}))
    print(jsinterpreter.interpret_expression('"ab" + "cd"', {}))
    print(jsinterpreter.interpret_expression('"a"+c', {'c': 'd'}))
    print(jsinterpreter.interpret_expression('"a"+"b"+c', {'c': 'd'}))

# Generated at 2022-06-12 19:01:20.642778
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_str = '''
    var obj1 = {
        "a": function(a, b) {
            var c = a + b;
            return c;
        },
        "b": function(a, b) {
            var c = a - b;
            return c;
        }
    };
    '''
    js_interpreter = JSInterpreter(js_str)
    obj = js_interpreter.extract_object('obj1')
    assert callable(obj['a'])
    assert obj['a'](1, 2) == 3
    assert obj['b'](3, 2) == 1


# Generated at 2022-06-12 19:01:33.031943
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    local_vars = {'a': 'test', 'b': 1}
    jsinterpreter = JSInterpreter('')
    assert jsinterpreter.interpret_expression('a', local_vars) == 'test'
    assert jsinterpreter.interpret_expression('a + b', local_vars) == 'test1'
    local_vars['b'] = 'b'
    assert jsinterpreter.interpret_expression('a + b', local_vars) == 'testb'
    assert jsinterpreter.interpret_expression('a.length', local_vars) == 4
    local_vars['a'] = ''
    assert jsinterpreter.interpret_expression('a.length', local_vars) == 0

# Generated at 2022-06-12 19:01:38.178645
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    objects = {}
    interpreter = JSInterpreter('', objects)
    # method interpret_expression must return "12"
    assert interpreter.interpret_expression('10 + 2', {}, 10) == 12
    # method interpret_expression must return "abcd"
    assert interpreter.interpret_expression('"a" + "b" + "c" + "d"', {}, 10) == 'abcd'


# Generated at 2022-06-12 19:01:45.246316
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    JS_TEST_CASE_1 = r'''
        var a = 1;
        var b = '2';
        var c = [3, "4", '5'];
        var d = {
            e: [6,
                {
                    f: 7,
                    "g": 'h'
                },
                ['i', [j]]
            ],
            k: {
                l: 8
            }
        };
    '''
    js = JSInterpreter(JS_TEST_CASE_1)
    assert js.interpret_expression('a', {}) == 1
    assert js.interpret_expression('b', {}) == '2'
    assert js.interpret_expression('c', {}) == [3, '4', '5']

# Generated at 2022-06-12 19:01:47.282145
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interp = JSInterpreter(code=None)

    arg_names = ['a', 'b']
    code = 'a+b'
    resf = js_interp.build_function(arg_names=arg_names, code=code)

    assert resf((1, 2)) == 3



# Generated at 2022-06-12 19:02:09.428414
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    from .testcases import JS_TESTCASES

    def check_statement_result(statement, expected_result):
        interpreter = JSInterpreter(statement)
        result = interpreter.interpret_statement(statement, {})
        assert result == expected_result

    for testcase in JS_TESTCASES:
        yieldcheck_statement_result, testcase.statement, testcase.value

if __name__ == '__main__':
    import pytest
    pytest.main('-q')

# Generated at 2022-06-12 19:02:20.728376
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Basic regular expression
    js_interpreter = JSInterpreter('var a=5;var b=\'6\';return a+b;')
    res = js_interpreter.interpret_expression('a+b', locals())
    assert res == '56'
    # Basic regular expression with split, join, reverse and slice
    js_interpreter = JSInterpreter('var a=b.split(\'\');return a.reverse().join(\'\');')
    res = js_interpreter.interpret_expression('a.reverse().join(\'\')', locals())
    assert res == 'abcdef'
    js_interpreter = JSInterpreter('var a=b.split(\'\');return a.slice(1);')

# Generated at 2022-06-12 19:02:28.181809
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter(None)

    # test function with empty args and code
    func_obj = js_interpreter.build_function([], "")
    assert func_obj is not None

    # test function with 'null' code
    func_obj = js_interpreter.build_function(["a"], "null")
    assert func_obj is not None

    # test function with 'return' code
    func_obj = js_interpreter.build_function(["a"], "return 2")
    assert func_obj is not None

    # test function with 'return' code and assignment
    func_obj = js_interpreter.build_function(["a"], "return 2; a = 3")
    assert func_obj is not None

    # test function with two arguments, one return statement and one assignement

# Generated at 2022-06-12 19:02:34.695180
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    local_vars = { 'a': 2, 'b': 3 }
    res = js_interpreter.interpret_expression('a + b', local_vars)
    assert (res == 5)


# Generated at 2022-06-12 19:02:41.599071
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
    var kareem = {
        count: function() {
            var cnt = 0;
            for (var a = 0; a < 123; a++) {
                cnt += a;
            }
            return cnt;
        }
    };
    """
    kareem_obj = JSInterpreter.extract_object(code, 'kareem')
    count_func = kareem_obj['count']
    assert count_func() == 7626

# Generated at 2022-06-12 19:02:48.849049
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter(
        code='''function test_function(arg1, arg2) {
            var out = function(s) {
                return s.split('').reverse().join('');
            }(arg2).slice(2);
            return arg1.join('');
        }

        var test_object = {
            foo: function(x) {
                return x.join('');
            },
            bar: function(x) {
                return x.split('').reverse().join('');
            }
        }''')
    assert jsi.extract_function('test_function')(('abc', 'defg')) == 'abc'
    assert jsi.call_function('test_function', 'abc', 'defg') == 'abc'
    assert jsi.interpret_expression

# Generated at 2022-06-12 19:02:55.329671
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = '''var foo = {
        bar: {
            baz: function(a, b) {
                return a + b;
            }
        }
    };'''
    js = JSInterpreter(js_code)
    assert js.interpret_expression('foo["bar"].baz(3, 4)', {}, 100) == 7

# Generated at 2022-06-12 19:03:07.470995
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test 1
    js_interpreter = JSInterpreter("")
    argnames = ["a", "b", "c", "d", "e", "f", "g", "h"]
    code = '''
         r = a + b;
         r = r + c;
         r = r + d;
         r = r + e;
         r = r + f;
         r = r + g;
         r = r + h;
         return r;
     '''
    resf = js_interpreter.build_function(argnames, code)
    assert resf([1,2,3,4,5,6,7,8]) == 36

    # Test 2
    js_interpreter = JSInterpreter("")

# Generated at 2022-06-12 19:03:17.173934
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test case 1
    code = 'function   foo  (  x , y, z  )  { var a = x + y + z; }'
    argnames = ['x', 'y', 'z']
    jsinte = JSInterpreter(code, None)
    f = jsinte.build_function(argnames, code)
    assert f([1, 2, 3]) == 6

    # Test case 2
    code = '''function   foo  ( x , y, z  )  {
        var a = x + y + z;
        var b = a + 2;
        var c = b * 5;
        return c;
    }'''
    argnames = ['x', 'y', 'z']
    jsinte = JSInterpreter(code, None)
    f = jsinte.build_

# Generated at 2022-06-12 19:03:20.306977
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = "function foo(a, b) { return a * b; }"

    assert JSInterpreter(code).call_function('foo', 3, 7) == 21

# Generated at 2022-06-12 19:03:47.086092
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter("""
        function arr(a, b) {};
        var c = 1;
        var d = 'd';
        var e = {
            e_f: function(a, b) {}
        };
        var g = [1, 2, 3];
    """)

    def test(expr, result):
        assert js.interpret_expression(expr, {}) == result

    test('1', 1)
    test('1+1', 2)
    test('1+1+1', 3)
    test('c', 1)
    test('d', 'd')
    test('d.length', 1)
    test('g[1]', 2)
    test('g.length', 3)
    test('g.slice(1)', [2, 3])

# Generated at 2022-06-12 19:03:55.543686
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
    var h = function (a, b) {
        if (a) {
            return 1;
        } else {
            return b;
        }
    }'''
    interpreter = JSInterpreter(code)
    func = interpreter.build_function(['a', 'b'], '''
        if (a) {
            return 1;
        } else {
            return b;
        }''')
    assert func(['a', 'b']) == 'b'
    assert func([False, 'b']) == 'b'
    assert func([True, 'b']) == 1
    assert func([1, 'b']) == 1

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-12 19:04:08.252334
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:04:20.478655
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:04:33.301336
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test method with a simple function that adds 2 numbers
    def test_function_1():
        js_interpreter = JSInterpreter('x=0')
        argnames = ['a', 'b']
        code = 'x = a + b'
        f = js_interpreter.build_function(argnames, code)
        assert f((2, 3)) == 5
        assert f((5, 5)) == 10

    # Test method with a simple function that subtracts 2 numbers
    def test_function_2():
        js_interpreter = JSInterpreter('x=0')
        argnames = ['a', 'b']
        code = 'x = a - b'
        f = js_interpreter.build_function(argnames, code)
        assert f((2, 3)) == -1

# Generated at 2022-06-12 19:04:36.699098
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    JS_DATA = """
        function func1() {
            return "hello";
        }
        function func2(p1, p2) {
            return p1 + " " + p2;
        }
    """
    I = JSInterpreter(JS_DATA)
    assert I.call_function("func1") == "hello"
    assert I.call_function("func2", "hello", "world") == "hello world"

# Generated at 2022-06-12 19:04:42.360722
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = 'srt.download("https://example.com/file.srt")'
    js_interpreter = JSInterpreter(code)

    srt_expect = {
        'download': lambda args: 'download sub'
    }

    assert js_interpreter._objects['srt'] == srt_expect

# Generated at 2022-06-12 19:04:47.057635
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = "function test_function(arg1, arg2) {var arg2 = arg2; arg2 += 'a'; return arg2 + arg1;}"
    argnames = ['arg1', 'arg2']
    code = code[code.find('{')+1:-1]
    js = JSInterpreter('')
    f = js.build_function(argnames, code)
    assert f(['1', '2']) == '2a1'
    return True


# Generated at 2022-06-12 19:04:52.786459
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objects = JSInterpreter(js_player_code)._objects
    assert objects['some_object']['some_method']([objects['some_object'], 'some_other_argument']) == \
        objects['some_object'] * 'some_other_argument' * 3 * int(objects['some_object']['num'])


# Generated at 2022-06-12 19:04:58.034697
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter("function foo(x){ var a = x + 5; var b = a * 2; return b; }")
    func = interpreter.build_function(['x'], "var a = x + 5; var b = a * 2; return b;")
    assert func(params=[10]) == 30


# Generated at 2022-06-12 19:05:20.152967
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:05:27.630209
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objects = {'jwplayer': {'key': 'test'}}
    js_interpreter = JSInterpreter(
        '''
        jwplayer = {
          test: function() {
            return testVar;
          },
          length: function(arg) {
            return arg.length;
          }
        };
        ''', objects)
    extracted_objects = js_interpreter.extract_object('jwplayer')
    assert extracted_objects['test']() == 'testVar'
    assert extracted_objects['length']('7d3_') == 4

    # Test global variables

# Generated at 2022-06-12 19:05:36.083340
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:05:39.878309
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_interpreter = JSInterpreter("""
    var a = { b: function (x) { return x + 1; } }
    """)
    assert js_interpreter.extract_object('a') == {'b': lambda x: x + 1}



# Generated at 2022-06-12 19:05:47.570810
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        function g(a) {
            var foo = [];
            function h(z) {
                return z + z;
            }
            for (var i = 0; i < 10; i++) {
                foo.push(h(i));
            }
            return foo;
        }
        var bar = "abc";
        var baz = 42.3;
    '''
    interp = JSInterpreter(code)
    assert interp.interpret_expression('1 + 1', {}) == 2
    assert interp.interpret_expression('g(1)', {}) == list(range(2, 20, 2))
    assert interp.interpret_expression('"foo" + "bar"', {}) == 'foobar'
    assert interp.interpret_expression('g(1).length', {}) == 5

# Generated at 2022-06-12 19:05:52.962481
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = JSInterpreter('''
        function f() {
            foobar = {
                foo: function() {},
                bar: function() {}
            }
        }
    ''')

    assert js.extract_object('foobar') == {'foo': None, 'bar': None}

# Generated at 2022-06-12 19:06:01.830072
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:06:07.277873
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:06:19.360039
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test literal expression parsing
    js = JSInterpreter('')
    assert js.interpret_expression('true', {})
    assert not js.interpret_expression('false', {})
    assert js.interpret_expression('null', {}) is None
    assert js.interpret_expression('3', {}) == 3
    assert js.interpret_expression('{a: 1, "b": "c"}', {}) == {'a': 1, 'b': 'c'}
    assert js.interpret_expression('[1,2,3,4,5]', {}) == [1, 2, 3, 4, 5]
    assert js.interpret_expression('["a", "b", "c"]', {}) == ['a', 'b', 'c']
    assert js.interpret_expression('"foo"', {}) == "foo"

# Generated at 2022-06-12 19:06:27.936289
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterpreter = JSInterpreter('')
    assert jsinterpreter.interpret_expression('8', {}) == 8
    assert jsinterpreter.interpret_expression('8 + 3', {}) == 11
    assert jsinterpreter.interpret_expression('8 - 3', {}) == 5
    assert jsinterpreter.interpret_expression('8 / 3', {}) == 8 / 3.
    assert jsinterpreter.interpret_expression('8 * 3', {}) == 24
    assert jsinterpreter.interpret_expression('8 % 3', {}) == 2
    assert jsinterpreter.interpret_expression('8 & 3', {}) == 0
    assert jsinterpreter.interpret_expression('8 ^ 3', {}) == 11
    assert jsinterpreter.interpret_expression('8 >> 3', {}) == 1
    assert jsinter

# Generated at 2022-06-12 19:07:01.813315
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    interpreter = JSInterpreter('''
        a = {
            b: function(arg1, arg2) {},
            c: function(arg3) {},
            d: function(arg4, arg5, arg6) {},
            e: function(arg7, arg8, arg9, arg10) {},
            f: function(arg11, arg12, arg13, arg14, arg15) {}
        }
    ''')

    obj = interpreter.extract_object('a')

    assert len(obj.keys()) == 5
    assert callable(obj['b'])
    assert callable(obj['c'])
    assert callable(obj['d'])
    assert callable(obj['e'])
    assert callable(obj['f'])


# Generated at 2022-06-12 19:07:11.413686
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    extractor = JSInterpreter('''var a = {
        va:"va",
        vb: 0,
        vc: function(args){
            return "vc";
        }
    }
    var b = {
        a: 1,
        
        "b": function(a,b){
            c = (a > b) ? 1:2;
        },
        
        'c': function(a){
            return a;
        }
    }
    var c = {
        x: 0,
        
        "y": function(a, b){
            this.x += a;
            return this.x;
        }
    }
    ''', eval(open("../../include/objects.json", 'r').read()))
    object_A = extractor._objects["a"]
    object_B

# Generated at 2022-06-12 19:07:23.785476
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    local_vars = {"a": 22,"b": 12,"x": "abcd"}
    jsint = JSInterpreter(None)
    assert jsint.interpret_statement("a", local_vars) == (22, False)
    assert jsint.interpret_statement("b", local_vars) == (12, False)
    assert jsint.interpret_statement("x", local_vars) == ("abcd", False)
    local_vars["x"] = 10
    assert jsint.interpret_statement("a=x", local_vars) == (10, False)
    local_vars["j"] = 2
    assert jsint.interpret_statement("a=b*j", local_vars) == (24, False)

# Generated at 2022-06-12 19:07:28.947483
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        v = {
            "a": function(a){return a * 4;}
        };
    '''
    js = JSInterpreter(code)
    obj = js.extract_object('v')
    # Result
    assert obj == {'a': lambda x: x * 4}
    # Test
    assert obj['a'](2) == 8


# Generated at 2022-06-12 19:07:32.834543
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        (function(x){
          return (x + 5) & 3;
        })("+-&")
    '''
    intp = JSInterpreter(code)
    assert intp.interpret_expression('("+-&" + 5) & 3', {}) == 0


# Generated at 2022-06-12 19:07:38.635520
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
	a = JSInterpreter("function aaa(a,b) {return a + b;};");
	b = a.extract_function("aaa")
	c = b((1,1))
	print(c)

# Generated at 2022-06-12 19:07:47.396919
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:07:58.919195
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        var a = {
            reverse:function(){},
            slice: function(){},
            splice: function() {},
            foo: function(arg) {
                return arg;
            },
            bar: function() {},
            baz: function() {}
        };
        function func(arg1, arg2) {
            var b = a.foo(arg1);
            var c = a.foo(arg2);
            var d = a.bar(b, c);
            var e = a.baz(b, c, d);
            return e;
        }
    '''

# Generated at 2022-06-12 19:08:08.801497
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = """
        var obj = {
            fn1: function(x, y){
                return x+y;
            },
            fn2: function(x){
                return x-1;
            }
        };
        var otherObj = {
            fn: function(x) {
                return x-1;
            }
        }
        var a = 2;
        function testFn1() {
            var a = 1;
            return obj.fn1(a, 2);
        }
        function testFn2() {
            return obj.fn2(a);
        }
    """
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('obj')

    assert 'fn1' in obj and 'fn2' in obj
   

# Generated at 2022-06-12 19:08:14.266414
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsi = JSInterpreter(
        'sr_map={"123":function(a,b){return a+b}, "456":function(){return "789"}};')
    obj = jsi.extract_object('sr_map')
    key = "123"
    function_123 = obj[key]
    result = function_123(1,2)
    assert result == 3
    key = "456"
    function_456 = obj[key]
    result = function_456()
    assert result == "789"


# Generated at 2022-06-12 19:09:08.088070
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test case 1
    js_interpreter = JSInterpreter('')
    argnames = ['a', 'b']
    code = 'a + b'
    resf = js_interpreter.build_function(argnames, code)
    res = resf((3, 4))
    assert res == 7

    # Test case 2
    js_interpreter = JSInterpreter('')
    argnames = ['a']
    code = 'ab = a; return encodeURIComponent(b);'
    resf = js_interpreter.build_function(argnames, code)
    res = resf(('rattlesnake',))
    assert res == 'rattlesnake'

    # Test case 3
    js_interpreter = JSInterpreter('')

# Generated at 2022-06-12 19:09:16.142551
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter("a = {'1': 3, '2': 5};")
    obj = interpreter.interpret_expression("a", {})
    assert obj['1'] == 3 and obj['2'] == 5
    interpreter = JSInterpreter("b = [2, 3, 5, 7];")
    obj = interpreter.interpret_expression("b", {})
    assert obj[1] == 3 and obj[2] == 5
    interpreter = JSInterpreter("c = a['1'] + b[3];")
    res = interpreter.interpret_expression("c", {})
    assert res == 10
    interpreter = JSInterpreter("d = 'a1';")
    obj = interpreter.interpret_expression("d", {})
    assert obj == 'a1'

# Generated at 2022-06-12 19:09:28.119344
# Unit test for method interpret_expression of class JSInterpreter