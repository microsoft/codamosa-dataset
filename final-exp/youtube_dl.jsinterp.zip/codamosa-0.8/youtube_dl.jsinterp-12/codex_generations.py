

# Generated at 2022-06-12 19:00:19.400844
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        function func(arg1, arg2) {
            var a = arg1;
            var b = arg2;
            var c = a + b;
            return a + c;
        }
    """)
    func = js_interpreter.build_function(['arg1', 'arg2'], ";\n".join([
        "var a = arg1",
        "var b = arg2",
        "var c = a + b",
        "return a + c",
    ]))
    assert(func([1, 2]) == 4)
    assert(func([2, 3]) == 9)

# Generated at 2022-06-12 19:00:25.838705
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    func = JSInterpreter.build_function(argnames=[], code="""
    test = [];
    for (var i = 0; i < 10; i++) {
        test.push(i);
    }
    return test;
    """)
    assert func() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    func = JSInterpreter.build_function(argnames=['a', 'b'], code="""
    return a + b;
    """)
    assert func(1, 2) == 3


# Generated at 2022-06-12 19:00:35.353629
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('''
        e.reverse = function() {
            var b = this.length;
            var c = Math.floor(b / 2);
            var a = 0;
            for (; a < c;) {
                var d = this[a];
                this[a++] = this[--b];
                this[b] = d;
            }
            return this;
        }''')
    e = 'bdcae'.split('')
    f = js.build_function(['e'], js.code)
    print('f(e) is', f(e))


# Generated at 2022-06-12 19:00:47.622855
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    src = '''
    var a = function() {
        var na = [1,2,3];
        var nb = ["a","b"];
        var nc = [1,"a"];
        var nd = [1,"a",["b","c"]];
        var ne = [2,"a",["b","c"]];
        var f = function(a,b){return a+b};

        return {
            "a": na,
            "b": nb,
            "c": nc,
            "d": nd,
            "e": ne,
            "f": f
        };
    }();
    '''
    js = JSInterpreter(src)

    # Test for array
    assert js.interpret_expression('a[2]', {}) == 3
    assert js.interpret_

# Generated at 2022-06-12 19:00:58.839699
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    """ Test of method call_function in JSInterpreter """
    assert JSInterpreter(r'''
        function func1(a,b){
            return a+b;
        }
        var func2 = function(a,b){
            return a*b;
        }
    ''').call_function('func1', 1, 2) == 3
    assert JSInterpreter(r'''
        function func1(a,b){
            return a+b;
        }
        var func2 = function(a,b){
            return a*b;
        }
    ''').call_function('func2', 1, 2) == 2



if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-12 19:01:11.989060
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('var a = b = 100')
    assert js.interpret_expression('a', {}) == 100

    js = JSInterpreter('var a = [1, 2, 3].splice(1, 1)')
    assert js.interpret_expression('a', {}) == [2]

    js = JSInterpreter('var a = "abcd".split("")')
    assert js.interpret_expression('a', {}) == ['a', 'b', 'c', 'd']

    js = JSInterpreter('var a = "abc".indexOf("c")')
    assert js.interpret_expression('a', {}) == 2

    js = JSInterpreter('var a = "abc".indexOf("d")')
    assert js.interpret_expression('a', {}) == -1

    js = JSInter

# Generated at 2022-06-12 19:01:24.967097
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    var obj = {
        a: function() {},
        b: function() {},
        c: function() {},
        d: function() {},
        e: function() {},
        get: function() {},
        abc: function() {},
        hello_world: function() {},
    };
    '''
    assert code == JSInterpreter(code).code
    obj = JSInterpreter(code).extract_object("obj")
    assert obj == {
        "a": None,
        "b": None,
        "c": None,
        "d": None,
        "e": None,
        "get": None,
        "abc": None,
        "hello_world": None
    }
# end of test_JSInterpreter_extract_object



# Generated at 2022-06-12 19:01:32.145664
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """var obj = {
            a: function(p, q) { return p + q; },
            b: function(p, q) { return p * q; }
    };"""
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](5,3) == 8
    assert obj['b'](5,3) == 15



# Generated at 2022-06-12 19:01:36.689501
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("abc = function(a, b, c){return a + b * c;}")
    f = js_interpreter.build_function(['a', 'b', 'c'], 'return a + b * c;')
    assert f(['1', '2', '3']) == '7'

# Generated at 2022-06-12 19:01:42.986126
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # test case 1:
    # test_code define a variable test_string and initial value "123"
    test_code = r'''
        var test_string = "123";
    '''
    interpreter = JSInterpreter(test_code)
    assert interpreter.interpret_expression("test_string", {}) == "123"
    assert interpreter.interpret_expression("test_string", {}) == "123"

    # test case 2:
    # test_code define a variable test_int and initial value 123
    test_code = r'''
        var test_int = 123;
    '''
    interpreter = JSInterpreter(test_code)
    assert interpreter.interpret_expression("test_int", {}) == 123
    assert interpreter.interpret_expression("test_int", {}) == 123

    # test case 3:
   

# Generated at 2022-06-12 19:02:05.802712
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    obj_re = r'^Object\s*\((?P<name>.+?)\)\s*{\s*' \
             r'(?P<fields>(?:[a-zA-Z$0-9]+\s*:\s*function\s*\(.*?\)\s*' \
             r'{.*?}(?:,\s*)?)*)\s*}$'

# Generated at 2022-06-12 19:02:09.909384
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = '''
        var c = function(a) {
            var b = a + 3;
            return b;
        }
        '''
    obj = JSInterpreter(js_code)
    result = obj.interpret_expression('c(1)', {}, 10)
    assert result == 4


# Generated at 2022-06-12 19:02:13.955359
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function foo(a, b, c) { return a + b + c; };
        function bar(a, b, c) { return a * b * c; };
    '''
    jsi = JSInterpreter(js_code)
    assert jsi.call_function('foo', 1, 2, 3) == 6
    assert jsi.call_function('bar', 1, 2, 3) == 6


# Generated at 2022-06-12 19:02:22.517082
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinterpreter = JSInterpreter("function f(a,b,c) { d=b+c; e=a.trim(); f=a.trim(); return d; }")
    func_res=jsinterpreter.build_function(['a','b','c']," d=b+c; e=a.trim(); f=a.trim(); return d")
    assert func_res([1,2,3]) == 5
    assert func_res(['a','b','c']) == 'bc'


# Generated at 2022-06-12 19:02:35.360237
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:02:41.234594
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test 1
    code ='''
        function abc(a, b, c) {
            var e, f, g, h;
            e = d + c;
            if (a == 0) {
                f = 3;
            } else {
                g = 2;
            }
            h = f + g;
            return h + 1;
        }
    '''
    js = JSInterpreter(code)
    f = js.build_function(['a', 'b', 'c'], 'var e, f, g, h;\n            e = d + c;\n            if (a == 0) {\n                f = 3;\n            } else {\n                g = 2;\n            }\n            h = f + g;\n            return h + 1;\n        ')
   

# Generated at 2022-06-12 19:02:49.369853
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code_template = r'''
                var %s = {
                    "func1": function(a, b) {
                        return a + b;
                    },
                    "func2": function(a, b) {
                        return a - b;
                    }
                };'''

    obj = JSInterpreter(code_template % "obj").extract_object("obj")
    assert obj['func1'](1, 2) == 3
    assert obj['func2'](1, 2) == -1


# Generated at 2022-06-12 19:02:55.383192
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # TODO: Add more tests
    js_interpreter = JSInterpreter("")
    js_interpreter.interpret_expression(
        "split('a','')",
        {"split":'split'}
        )
    

if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-12 19:03:03.952703
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter(None)
    args = ('a','b','c','d')
    code = '''
        a=b+c;
        d=a+c;
        return d
    '''
    resf = interpreter.build_function(args, code)
    res = interpreter.call_function(None, *(2,3,5,None))
    assert res==15
    res = interpreter.call_function(None, *(7,3,5,None))
    assert res==20

# Generated at 2022-06-12 19:03:14.286901
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
  code = r'''
    a = {
      b: function(p1, p2) {
        c = p1;
        return p2;
      }
    };
  '''

  js = JSInterpreter(code)
  obj = js.extract_object('a')
  assert obj['b']('1', '2') == '2'

  code = r'''
    a = {
      b: function(p1, p2) {
        c = p1;
        return {
          d: function() {
            return p1;
          }
        };
      }
    };
  '''

  js = JSInterpreter(code)
  obj = js.extract_object('a')
  assert obj['b']('1', '2')['d']() == '1'



# Generated at 2022-06-12 19:04:19.611967
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterpreter = JSInterpreter('')
    assert jsinterpreter.interpret_expression('x', {'x': 5}) == 5
    assert jsinterpreter.interpret_expression('x + y', {'x': 5, 'y': 2}) == 7



# Generated at 2022-06-12 19:04:31.854918
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r'''
    var s = {
        em: function(a) {
            return String.fromCharCode(a);
        },
        bm: function(a, b) {
            return a.replace(RegExp(b, "g"), "");
        }
    };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('s')
    return obj['em'](65) == 'A' and obj['bm']("abcabc", "b") == 'acac'

if __name__ == '__main__':
    if not test_JSInterpreter_extract_object():
        print("Error in JSInterpreter.extract_object() unit test")
        exit(1)

# Generated at 2022-06-12 19:04:39.922204
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        var n = function(a) {
            return a * a
        }
        var pc = function(a) {
            return n(a) + 1
        }
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function("n", 4) == 16
    assert js_interpreter.call_function("pc", 3) == 10



# Generated at 2022-06-12 19:04:51.974139
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter(
        # Test function extraction
        '''var name = "signature";
        function myfunc(arg1, arg2) {
            return arg2 + arg1;
        }
        ''',
        # Test object extraction
        {'myobj': {
            'sub': {'subsub': 'value'},
            'subfunc': lambda y: y * y * y
        }})

    assert js.interpret_expression('myfunc(5, 3)', {}) == 8
    assert js.interpret_expression('myobj.sub.subsub', {}) == 'value'
    assert js.interpret_expression('myobj[sub][subsub]', {}) == 'value'
    assert js.interpret_expression('myobj.subfunc(2)', {}) == 8

# Generated at 2022-06-12 19:05:02.519025
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code="""var a=0;
    var b={
        m:function(a){
            return a
        },

        n:function(a,b){
            return a+b
        },

        o:function(a,b,c){
            return a+b-c
        }
    };"""

    obj_name='b'
    js_interpreter=JSInterpreter(code)
    obj=js_interpreter.extract_object(obj_name)
    assert obj['m']([10])==10
    assert obj['n']([3,1])==4
    assert obj['o']([3,1,2])==2


# Generated at 2022-06-12 19:05:12.783741
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def test(expr, vars, res):
        jsi = JSInterpreter('')
        v = jsi.interpret_expression(expr, vars)
        assert v == res, '%r == %r != %r %r' % (expr, v, res, vars)
    test('1', {}, 1)
    test(' abcd - 1', {'abcd': 2}, 1)
    test('1 + 2', {}, 3)
    test('1 + abcd', {'abcd': 2}, 3)
    test('abcd + 1', {'abcd': 2}, 3)
    test('abcd', {'abcd': 2}, 2)
    test('abcd + efgh', {'abcd': 2, 'efgh': 3}, 5)

# Generated at 2022-06-12 19:05:21.041680
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = """
        window.ytplayer = {
            "config": {
                "assets": {
                    "js": "https://s.ytimg.com/yts/jsbin/player-en_US-vflSbSd0G.js"
                },
                "args": {
                    "ptk": "vevo",
                    "autoplay": 1
                }
            }
        };
    """
    
    obj = {
        'config': {
            'assets': {
                'js': 'https://s.ytimg.com/yts/jsbin/player-en_US-vflSbSd0G.js'
            },
            'args': {
                'ptk': 'vevo',
                'autoplay': 1
            }
        }
    }
    


# Generated at 2022-06-12 19:05:28.212482
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
    function foo(a,b) {
        var c=2, d=3, f=6, g=6;
        return {'e': a*b};
    }"""

    interpreter = JSInterpreter(code)

    # Check expression without parentheses
    #expr = "a * b * c + d * f"
    #res = interpreter.interpret_expression(expr, {})
    #assert res == a * b * c + d * f
    assert interpreter.interpret_expression("2 * 3 + 4 * 5", {}) == 26
    assert interpreter.interpret_expression("2 + 3 * 4 * 5", {}) == 62
    assert interpreter.interpret_expression("2 + 3 * (4 * 5)", {}) == 62
    assert interpreter.interpret_expression("2 + 3 * (4 * 5) + 8", {})

# Generated at 2022-06-12 19:05:35.691859
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    extract_object_test_inputs = (
        (
            "function test() {}\n test.func = {\n hello: function(arg1, arg2) {}\n};",
            "test.func",
            {"hello": lambda args: None}
        ),
        (
            "var test = function() {}\n test.func = {\n hello: function(arg1, arg2) {}\n};",
            "test.func",
            {"hello": lambda args: None}
        )
    )

    for input_code, objname, expected in extract_object_test_inputs:
        actual = JSInterpreter(input_code).extract_object(objname)
        assert expected == actual


# Generated at 2022-06-12 19:05:41.717254
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    s = '''
    q = {
        d: function(a, b) {
            return a + b
        },
        c: function(a) {
            return a - 1
        }
    }
    '''
    js = JSInterpreter(s)
    o = js.extract_object('q')
    assert o == {'d': lambda a, b: a + b, 'c': lambda a: a - 1}


# Generated at 2022-06-12 19:06:11.653664
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        var xxx; 
        xxx = {
            "a": function(p) {
                return function(q) {
                    return q;
                }
            }
        }
        function s(x) {
            return xxx.a(x);
        }
    '''

    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('s', 123) == 123

# Generated at 2022-06-12 19:06:23.161276
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    expected_result_1 = "Hello people!"
    expected_result_2 = "Hello, world!"
    expected_result_3 = 42
    expected_result_4 = 11
    expected_result_5 = "helloworld"

    func_1 = JSInterpreter.build_function(["a"], "return a;")
    result_1 = func_1("Hello people!")

    func_2 = JSInterpreter.build_function(["a", "b"], "return a + b;")
    result_2 = func_2("Hello", ", world!")

    func_3 = JSInterpreter.build_function(["a"], "return a * 2;")
    result_3 = func_3(21)


# Generated at 2022-06-12 19:06:28.837198
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    f = open("test.js", "r")
    data = f.read()
    f.close()
    extractor = JSInterpreter(data)
    a = []
    a.extend(extractor.extract_object("Foo").values())
    func1 = JSInterpreter.build_function(a[0], ["b", "c"], "d=b+c;return d")
    res = func1([2, 3])
    print(res)



# Generated at 2022-06-12 19:06:37.917687
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    from inspect import signature
    from .utils import (
        compact_bytes,
        compact_str
    )
    codes = {
        'compact_bytes': compact_bytes,
        'compact_str': compact_str
    }
    jsi = JSInterpreter('')
    for code_name, code in codes.items():
        parameter_number = len(signature(code).parameters)
        assert code_name == jsi.call_function(code_name, *range(parameter_number))


# Generated at 2022-06-12 19:06:49.389569
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    import sys
    import unittest


# Generated at 2022-06-12 19:06:58.591888
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsi = JSInterpreter('''
        some_object = {
            "some_value": 42,
            "some_function": function(arg1, arg2) { return arg1 + arg2; },
            "another_function": function(x) {
                if (x === true) return 42;
                else return x;
            }
        };
    ''')
    obj = jsi.extract_object('some_object')
    assert obj['some_value'] == 42
    assert obj['some_function'](10, 32) == 42
    assert obj['another_function'](True) == 42
    assert obj['another_function'](False) is False


# Generated at 2022-06-12 19:07:09.533367
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:07:11.855248
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = """
    function foo(a, b) {
        var c = a + b;
        return c;
    }
    """
    jsi = JSInterpreter(js)
    assert jsi.call_function('foo', 1, 2) == 3


# Generated at 2022-06-12 19:07:21.847329
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = '''
        var obj = {
            "a": function(a){
                return a;
            },
            b: function(a, b){
                return [a, b];
            }
        };
    '''
    i = JSInterpreter(js)
    obj = i.extract_object('obj')
    assert callable(obj['a'])
    assert callable(obj['b'])
    assert obj['a'](3) == 3
    assert obj['b'](3, 4) == [3, 4]


# Generated at 2022-06-12 19:07:30.222264
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code_str = '''
        function f(args) {
            print('>>' + args);
            return "inner " + args;
        }
        function g(args) {
            return f("outer " + args);
        }
        function h(args) {
            return g("another " + args);
        }
    '''
    code = JSInterpreter(code_str)
    assert code.call_function('f', 'args') == 'inner args'
    assert code.call_function('g', 'args') == 'inner outer args'
    assert code.call_function('h', 'args') == 'inner outer another args'


# Generated at 2022-06-12 19:08:02.382641
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''function b(a,b){return a+b;}
              function c(a,b){return a*b;}'''
    js = JSInterpreter(code)
    assert js.call_function('b', 1, 2) == 3
    assert js.call_function('c', 5, 4) == 20


# Generated at 2022-06-12 19:08:06.444202
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = 'var y={a:function(p){return p}};'
    interp = JSInterpreter(code)
    obj = interp.extract_object('y')
    assert isinstance(obj, dict)
    assert obj.get('a') is not None


# Generated at 2022-06-12 19:08:14.613687
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:08:17.497698
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
	code = '''
		var download_retry = {
						0:"bA==",
						1:"bA==",
						2:"bQ=="
					};
	'''
	interpreter = JSInterpreter(code)
	obj = interpreter.extract_object('download_retry')
	assert obj == {0: 'a', 1: 'a', 2: 'b'}


# Generated at 2022-06-12 19:08:22.840955
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = {
            b1: function() {
                return 1;
            },
            b2: function() {
                return 2;
            }
        }
    """
    obj = JSInterpreter(code).extract_object('a')
    assert len(obj) == 2
    assert obj['b1']() == 1
    assert obj['b2']() == 2


# Generated at 2022-06-12 19:08:28.657178
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:08:34.926939
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    s = """
    P = {
        a: function(b){},
        c: function(d) {
            e = f;
        }
    };
    """
    jsi = JSInterpreter(s)
    obj = jsi.extract_object("P")
    assert isinstance(obj, dict)


# Generated at 2022-06-12 19:08:47.541214
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    def test_extract_object(js_code, object_name, expected_object):
        js_interpreter = JSInterpreter(js_code)
        actual_object = js_interpreter.extract_object(object_name)
        if expected_object != actual_object:
            raise Exception("Test failed.\nExpected: %s\nActual: %s" % (expected_object, actual_object))
    test_extract_object("a={};", "a", {})
    test_extract_object("window.a.b={};", "window.a.b", {})
    test_extract_object("var a = function(){}; a={};", "a", {})
    test_extract_object("a={b:'c'};", "a", {"b":"c"})
   

# Generated at 2022-06-12 19:08:51.735726
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter(
        '''
            foo = function(a, b) {
            var c = a - b;
            return c;
            }''')
    assert js_interpreter.call_function('foo', 7, 5) == 2

# Generated at 2022-06-12 19:08:59.653586
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter("")
