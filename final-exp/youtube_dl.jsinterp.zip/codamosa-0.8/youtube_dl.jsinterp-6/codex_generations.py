

# Generated at 2022-06-12 19:00:20.596888
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
	objects = {'a':'a'}
	code = 'var c = a.split("")'
	interpreter = JSInterpreter(code, objects)
	local_vars = {'a':'a'}
	assert interpreter.interpret_expression('a.split("")', local_vars) == ['a']
	local_vars = {'a':['a']}
	assert interpreter.interpret_expression('a.join("")', local_vars) == 'a'
	local_vars = {'a':'a'}
	assert interpreter.interpret_expression('a.slice(1)', local_vars) == []
	local_vars = {'a':['a', 'b']}

# Generated at 2022-06-12 19:00:26.456244
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code_01 = '''
        c = {
            a: function() {
                return 10;
            },
            b: function(){
                return 20;
            }
        };
    '''
    interprer = JSInterpreter(code_01)
    obj = interprer.extract_object('c')
    assert obj['a']() == 10
    assert obj['b']() == 20

    code_02 = '''
        a = function(arg_a, arg_b){
            return arg_a + arg_b;
        };
        b = {
            a: function(arg_b) {
                return a(arg_b, 10);
            },
        };
    '''
    interprer = JSInterpreter(code_02)
    obj = interprer.extract_object('b')
   

# Generated at 2022-06-12 19:00:35.173283
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = """
        var A = {
            decode: function(input) {
                return input[0];
            },
            extract: function(input) {
                return input[1];
            }
        }
    """
    j = JSInterpreter(js_code)
    A = j.extract_object('A')
    assert A['decode']('abc') == 'a'
    assert A['extract']('abc') == 'b'
    assert A['decode']('123') == '1'
    assert A['extract']('123') == '2'



# Generated at 2022-06-12 19:00:47.414751
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():

    # Test variable
    def test_variable(expr, var_array, wants):
        local_vars = {'a': var_array[0], 'b': var_array[1]}
        interpreter = JSInterpreter('', {})
        assert interpreter.interpret_expression(expr, local_vars, 100) == wants

    test_variable('a', [1,2], 1)
    test_variable('b', [1,2], 2)

    # Test array
    def test_array(expr, var_array, index_array, wants):
        local_vars = {'a': var_array[0], 'b': var_array[1]}
        interpreter = JSInterpreter('', {})
        assert interpreter.interpret_expression(expr, local_vars, 100) == wants


# Generated at 2022-06-12 19:00:52.941365
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        function foo(a,b) {
            return a + b;
        }
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('foo', 1, 2) == 3


if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-12 19:01:06.106333
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:01:19.552187
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    class Test(JSInterpreter):
        def __init__(self, code):
            super(Test, self).__init__(code)

    assert Test('a + b').interpret_expression('1 + 1', {'a': 1, 'b': 1}) == 2
    assert Test('a + b').interpret_expression('a + b', {'a': 1, 'b': 1}) == 2
    assert Test('a + b').interpret_expression('a', {'a': 1, 'b': 1}) == 1
    assert Test('a + b').interpret_expression('a - b', {'a': 3, 'b': 1}) == 2
    assert Test('a + b').interpret_expression('a * b', {'a': 3, 'b': 2}) == 6

# Generated at 2022-06-12 19:01:32.006984
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Case 1: Test variable assignment
    js = '''var a = 0, b = 1;'''
    js_interpreter = JSInterpreter(js)
    v, _ = js_interpreter.interpret_statement(js, {})
    assert v == 1
    # Case 2: Test arithmetic operations
    js = 'var c = a + b * 3;'
    v, _ = js_interpreter.interpret_statement(js, {})
    assert v == 3
    # Case 3: Test logical operations
    js = 'var d = c >= 3 && c <= 5;'
    v, _ = js_interpreter.interpret_statement(js, {})
    assert v is True
    # Case 4: Test array operations
    js = 'var e = d.split("");'
    v, _ = js_

# Generated at 2022-06-12 19:01:40.768852
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter("")
    obj = {"key1": "value1", "key2": "value2"}
    local_vars = {"var1": obj, "var2": ["a", "b", "c", "d"], "var3": {"key3": "value3", "key4": "value4"}}
    assert "value1" == js.interpret_expression("var1.key1", local_vars)
    assert "value2" == js.interpret_expression("var1['key2']", local_vars)
    assert ["a", "b", "c", "d"] == js.interpret_expression("var2", local_vars)
    assert "b" == js.interpret_expression("var2[1]", local_vars)

# Generated at 2022-06-12 19:01:45.414795
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        rb = {
            d: function(a){},
            a: function(a){},
            c: function(a){},
            b: function(a){}
        };
    '''
    obj = JSInterpreter(code).extract_object('rb')

    assert len(obj) == 4
    assert 'd' in obj
    assert callable(obj['d'])
    assert obj['d'](1, 2) == None


# Generated at 2022-06-12 19:02:40.949594
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('var a = b[c];')
    assert js_interpreter.interpret_statement('var a = b[c];', {'b': [1, 2, 3], 'c' : 0})[0] == 1
    js_interpreter = JSInterpreter('var a = b;')
    assert js_interpreter.interpret_statement('var a = b;', {'b': 2})[0] == 2
    js_interpreter = JSInterpreter('var a = 0b10;')
    assert js_interpreter.interpret_statement('var a = 0b10;', {})[0] == 2
    js_interpreter = JSInterpreter('var a = "0b10";')

# Generated at 2022-06-12 19:02:48.565789
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:03:02.100715
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Case 1: Script with only one object
    js_code = '''
        vd = {
            "sub" : function(a, b) {
                return a - b;
            },
            "add" : function(a, b) {
                return a + b;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    assert(js_interpreter.extract_object('vd') == {
        "sub" : lambda *args: args[0] - args[1],
        "add" : lambda *args: args[0] + args[1]
    })

    # Case 2: Script with multiple objects

# Generated at 2022-06-12 19:03:11.607749
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Simple arithmetics.
    assert JSInterpreter("").interpret_expression("1+2", {}) == 3
    assert JSInterpreter("").interpret_expression("1+2+3", {}) == 6
    assert JSInterpreter("").interpret_expression("(1+2)*4", {}) == 12
    assert JSInterpreter("").interpret_expression("2*4+3", {}) == 11
    assert JSInterpreter("").interpret_expression("6/3+8/2", {}) == 10
    assert JSInterpreter("").interpret_expression("6/3/2+8/1", {}) == 5
    assert JSInterpreter("").interpret_expression("6+8/2/1-2*2", {}) == 8

# Generated at 2022-06-12 19:03:17.751884
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        function g(a, b) {
            return a % b;
        }

        function f(a, b) {
            return a + b;
        }
    """
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('f')
    assert f((1, 2)) == 3
    g = js_interpreter.extract_function('g')
    assert g((7, 3)) == 1



# Generated at 2022-06-12 19:03:29.131274
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    
    sample_code = '''
        for (; i < a.length; i++) {
            a[i] = str.charCodeAt(i);
        }
    '''
    js_intepreter = JSInterpreter(sample_code)
    # setup the local variables for the testing
    local_varibles = {
        "a": [97, 98, 99],
        "i": 0
    }
    
    
    # test the regular expression
    regular_expression_test_cases = [
        ("a[i]", 97),
        ("a[i+1]", 98),
        ("a.length", 3),
        ("str.charCodeAt(i)", 97),
        ("str.charCodeAt(i + 1)", 98)
    ]

# Generated at 2022-06-12 19:03:36.466811
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
    for (var i = 0; i < a.length; i++) {
        var from = a[i];
        var to = b[i] || a[0];
        if (from !== to) {
            args.push(["", from, to]);
        }
    }"""
    expected_result = [["", "a0", "b0"], ["", "a1", "b1"], ["", "a2", "b2"], ["", "a3", "b3"]]
    local_vars = {
        "args": [], "a": ["a0", "a1", "a2", "a3"], "b": ["b0", "b1", "b2", "b3"]
    }
    js_interpreter = JSInterpreter(code)
    js_interpre

# Generated at 2022-06-12 19:03:42.192803
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    interpreter = JSInterpreter("""
        var p = function(a,b) {
            if(a < b) {
               a = a+b;
            }
            else {
               a = b+a;
            }
            return a;
        }
    """)
    a,b = 5, 10
    assert interpreter.call_function("p", a, b) == a+b


# Generated at 2022-06-12 19:03:43.230711
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    pass


# Generated at 2022-06-12 19:03:49.971822
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Parameter of method call_function
    funcname = "reverse"
    args = (2, 3)
    # Code of the function reverse
    code = """var arr = [1, 2, 3];
        var x = arr[a];
        var y = arr[b];
        arr[a] = y;
        arr[b] = x """
    # Result of the call of the function reverse
    res = [1, 3, 2]
    # Initialization of the class
    obj = JSInterpreter(code)
    f = obj.call_function(funcname, args)
    print(f)
    # Assertion
    assert f == res


# Generated at 2022-06-12 19:04:26.182056
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:04:40.081325
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:04:52.067983
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('''
        ''')
    # Test cases
    assert interpreter.interpret_expression("'test string'", {'test': "test string"}) == 'test string'
    assert interpreter.interpret_expression("true", {'test': "test string"}) == True
    assert interpreter.interpret_expression("false", {'test': "test string"}) == False
    assert interpreter.interpret_expression("{}", {'test': "test string"}) == {}
    assert interpreter.interpret_expression("[]", {'test': "test string"}) == []
    assert interpreter.interpret_expression("null", {'test': "test string"}) == None
    assert interpreter.interpret_expression("undefined", {'test': "test string"}) == None

# Generated at 2022-06-12 19:05:03.767627
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:05:13.973086
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('').interpret_expression('1 + 2', {}) == 3
    assert JSInterpreter('').interpret_expression('3 - 2', {}) == 1
    assert JSInterpreter('').interpret_expression('3 * 2', {}) == 6
    assert JSInterpreter('').interpret_expression('3 / 2', {}) == 1.5
    assert JSInterpreter('').interpret_expression('3 & 2', {}) == 2
    assert JSInterpreter('').interpret_expression('3 | 2', {}) == 3
    assert JSInterpreter('').interpret_expression('3 ^ 2', {}) == 1
    assert JSInterpreter('').interpret_expression('3 << 2', {}) == 12
    assert JSInterpreter('').interpret_expression('3 >> 2', {}) == 0

# Generated at 2022-06-12 19:05:21.791875
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
            a = {
                b: function(p){return function(q){return function(r){
                        return p+q+r;}}},
                c: function(p){return function(q){
                        return p+q;}}
                };
            """
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    # Unit test for method build_fuction of class JSInterpreter
    def add(a, b):
        return a + b
    # Unit tests for method interpret_expression of class JSInterpreter
    def test_plus_operator():
        assert js_interpreter.interpret_expression("1+1", {}) == 2
    def test_pass_object():
        assert obj['c'](1)(2) == 3


# Generated at 2022-06-12 19:05:28.939119
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test extraction of JS objects
    objects = {
        'c': {
            'd': {  # We need to reference this deeper object to detect the parsing bug (see below)
                'e': 'ge'
            }
        }
    }
    jsi = JSInterpreter('var a={b:1};', objects)
    assert {'b': 1} == jsi.interpret_expression('a', {})
    assert 1 == jsi.interpret_expression('a.b', {})
    assert 1 == jsi.interpret_expression('a["b"]', {})

    # Test extraction of JS functions
    jsi = JSInterpreter('var b=function(){return 3};')
    assert 3 == jsi.interpret_expression('b()', {})

    # Test extraction of JS function with arguments
    jsi = JSInterpre

# Generated at 2022-06-12 19:05:34.144727
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:05:36.376947
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsi = JSInterpreter('function a(x){return x*x}')
    assert jsi.call_function('a',6)==36

# Generated at 2022-06-12 19:05:45.504636
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_interpreter = JSInterpreter('''
        mr_result={"length":1,"0":19,"ciphertext":"fraaaV7uxuCOSlZVpJCu8LkPV7dDzYb1V7uM8LkPP7uxuuxuCOSlZVu84N8aN7VuQYQN7VVkQQQN7V","getContentLength":"z_dZW","h":16,"l":14,"m":19,"s":6,"abort":17};
        mrr('mr_result["length"]');
    ''')

# Generated at 2022-06-12 19:07:33.501762
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
            function func(abc, def) {
                var x = abc;
                var y = x;
                var z = x + 1;
                x = 3;
                x = y + 1;
                return x + y;
            }
        """
    js = JSInterpreter(code)
    func = js.build_function(["abc", "def"], code.split('{')[1].split('}')[0])
    ret = func([1, 2])
    assert ret == 2



# Generated at 2022-06-12 19:07:45.434743
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    class TestArgs(object):
        """
        Mock class for sys.args in the unit test
        """
        args = None
    test_args = TestArgs()
    import sys
    sys.args = test_args
    from .jsinterp import JSInterpreter

# Generated at 2022-06-12 19:07:56.035373
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter('')

    # Return statement
    (res, abort) = interpreter.interpret_statement('return "wow"')
    assert (res == "wow") and (abort == True)

    # New variable declaration
    local_vars = {}
    (res, abort) = interpreter.interpret_statement('var t = 7', local_vars)
    assert (local_vars["t"] == 7) and (res == None) and (abort == False)

    # Variable assignment
    (res, abort) = interpreter.interpret_statement('t = 9', local_vars)
    assert (local_vars["t"] == 9) and (res == 9) and (abort == False)

    # Arithmetic expression

# Generated at 2022-06-12 19:08:06.356257
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def _test_interpret_expression(expr, expected):
        local_vars = {}
        js = JSInterpreter('')
        actual = js.interpret_expression(expr, local_vars)
        assert expected == actual

    _test_interpret_expression('1 + 2', 3)
    _test_interpret_expression('1 + 2 * 3', 7)
    _test_interpret_expression('(1 + 2) * 3', 9)
    _test_interpret_expression('x = 1 + 2', 3)
    _test_interpret_expression('x + 2', 5)
    _test_interpret_expression('x - y / 2', 3)
    _test_interpret_expression('x - 2', -1)
    _test_interpret_expression('x = 2', 2)

# Generated at 2022-06-12 19:08:14.551969
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter(code='')
    def resf(args):
        assert(len(args) == 2)
        if args[0]:
            return args[1]
        else:
            return ''
    assert(interpreter.build_function([None, None], 'return a || b') == resf)
    assert(interpreter.build_function([None, None], 'a && return b') == resf)
    assert(interpreter.build_function([None, None], 'c && return d') == resf)

    def resf(args):
        assert(len(args) == 2)
        if args[0]:
            return args[1]
        else:
            return 0

# Generated at 2022-06-12 19:08:24.613883
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        el9 = {"B3qhZi": function(n, e) {
            return n + e
        },
        "ox4cv9": function(n, e, t) {
            return n(e, t)
        }}

        function test1() {
            return el9["B3qhZi"]("#", "rgb");
        }

        function test2() {
            return el9["ox4cv9"](test1, "#", "rgb");
        }

        function test3() {
            return el9["ox4cv9"](test1, "#", "rgb");
        }
    """
    js = JSInterpreter(code)
    obj = js.extract_object("el9")

    assert len(obj) == 2

# Generated at 2022-06-12 19:08:37.505827
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Check if the interpreter can interpret a statement
    code = 'a = a + 1; b = a + 2; a; b;'
    interpreter = JSInterpreter(code)
    interpreter.interpret_statement('a = a + 1;', {'a': 1, 'b': 2})
    interpreter.interpret_statement('b = a + 2;', {'a': 2, 'b': 2})

    # Check if the interpreter can interpret a statement and return a value
    assert interpreter.interpret_statement('a;', {'a': 3, 'b': 4}) == (3, False)
    assert interpreter.interpret_statement('b;', {'a': 3, 'b': 4}) == (5, False)

    # Check if the interpreter can interpret a statement and return a value, if it is not the last statement

# Generated at 2022-06-12 19:08:49.990598
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = 'var a = [5, 2, 3]; var b = a.length; var c = a.slice(0); var d = a.splice(1, 1); var x = 3; var e = [1, x, a[1]];'
    interpreter = JSInterpreter(code)
    a = interpreter.call_function('a')
    assert a == [5, 2, 3]
    b = interpreter.call_function('b')
    assert b == 3
    c = interpreter.call_function('c')
    assert c == [5, 2, 3]
    d = interpreter.call_function('d')
    assert d == [2]
    e = interpreter.call_function('e')
    assert e == [1, 3, 2]

# Generated at 2022-06-12 19:08:58.744125
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    error = None
    try:
        jsint = JSInterpreter('var v;v = "test";')
        jsint.interpret_statement('v = "test";', {})
    except Exception as e:
        error= e
    assert(error is None)

    error = None
    try:
        jsint = JSInterpreter('var v;v = "test";return v;')
        jsint.interpret_statement('v = "test";', {})
    except Exception as e:
        error= e
    assert(error is None)

    error = None
    try:
        jsint = JSInterpreter('var v;v = "test";return v;')
        jsint.interpret_statement('return v;', {})
    except Exception as e:
        error= e
    assert(error is None)



# Generated at 2022-06-12 19:09:09.590556
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Unit test for method build_function of class JSInterpreter
    code = """function test(a,b,c){
        var d=a+b+c;
        return a;
    }"""
    interpreter = JSInterpreter(code)
    func = interpreter.build_function(["a", "b", "c"], "var d=a+b+c;return a;")
    assert func([1, 1, 1]) == 1

    code = """function test(a,b,c){
        var d=a+b+c;
        return a;
    }"""
    interpreter = JSInterpreter(code)
    func = interpreter.build_function(["a", "b", "c"], "var d=a+b+c;return a;")
    assert func([1, 1, 1]) == 1

   