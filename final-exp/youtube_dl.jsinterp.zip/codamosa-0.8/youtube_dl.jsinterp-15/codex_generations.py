

# Generated at 2022-06-12 19:00:24.355304
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
    function f(arg1, arg2) {
        return 1 + arg1 + arg2;
    }

    var a1 = f(1, 2);
    var a2 = f(3, 4);
    '''

    assert JSInterpreter(code).call_function('f', 1, 2) == 4
    assert JSInterpreter(code).call_function('f', 3, 4) == 8

# Generated at 2022-06-12 19:00:37.007685
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('')
    assert interpreter.interpret_expression('1', {}) == 1
    assert interpreter.interpret_expression('true', {}) == True
    assert interpreter.interpret_expression('false', {}) == False
    assert interpreter.interpret_expression('"foobar"', {}) == 'foobar'
    assert interpreter.interpret_expression('a', {'a': 3}) == 3
    assert interpreter.interpret_expression('a', {'a': 3}) == 3
    assert interpreter.interpret_expression('a.b', {'a': {'b': 'foo'}}) == 'foo'
    assert interpreter.interpret_expression('a.b', {'a': ['c', 'd', 'foo']}) == 'foo'

# Generated at 2022-06-12 19:00:49.382744
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    src = '''
      function abc() {
        var a = {
            cde: function(data) {
                sth();
            }
        };
      }'''
    interpreter = JSInterpreter(src)
    obj = interpreter.extract_object('a')
    assert obj == {'cde': None}

    src = '''
      function abc() {
        var a = {
            cde: function(data) {
                sth();
            },
            fgh: function(data) {
                sth();
            }
        };
      }'''
    interpreter = JSInterpreter(src)
    obj = interpreter.extract_object('a')
    assert obj == {'cde': None, 'fgh': None}


# Generated at 2022-06-12 19:00:57.038147
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        a = {
            foo: function(a, b) {
                return a + b;
            },
            bar: function(a, b) {
                return a - b;
            },
            baz: function(a, b) {
                return a * b;
            }
        }'''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert len(obj) == 3
    assert obj['foo'](1, 2) == 3
    assert obj['bar'](10, 2) == 8
    assert obj['baz'](4, 5) == 20


# Generated at 2022-06-12 19:01:09.926579
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('var x = 0;')
    # Test a line: var x = 0;
    res = interpreter.interpret_expression('x', {})
    assert res == 0

    # Test a line: x = 2; return x;
    interpreter = JSInterpreter('x = 2; return x;')
    res = interpreter.interpret_expression('x = 2; return x;', {})
    assert res == 2

    # Test a line: x = "hello world"; return x;
    interpreter = JSInterpreter('x = "hello world"; return x;')
    res = interpreter.interpret_expression('x = "hello world"; return x;', {})
    assert res == "hello world"

    # Test a line: return x;
    interpreter = JSInterpreter('return x;')
    res = interpreter.interpret

# Generated at 2022-06-12 19:01:22.889527
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Test functions from https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/common.py#L1699

    test_js = '''
        test = {
            "a":function(x){return 1+x},
            "b":function(x,y){return y-x},
            "c":"this is string",
            "d":"this is also string"
        }
        var t={"e":function(){ return 3 }};
        var func1 = function(args','){
            var a = 5;
            return a + ' ' + args;
        }
        function func2(args,m){
            var b = "text";
            return a+b+" "+args+" "+m;
        }
    '''


# Generated at 2022-06-12 19:01:34.703952
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objname = 'e12964d4'
    code = _e12964d4_code
    js_interpreter = JSInterpreter(code)
    object_dict = js_interpreter.extract_object(objname)
    obj_str = str(object_dict)

# Generated at 2022-06-12 19:01:42.132459
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:01:52.086733
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = r'''var a = {};
        function f(a, b) {
            return a + b;
        }
        function g(a, b) {return a + b;};
        var h = function(a, b) {return a + b;}
        a.i = function (a, b) {
            return a + b;
        }
        var j = function () { return function(a, b) {return a + b;}};
        '''
    obj = JSInterpreter(code)
    f = obj.extract_function('f')
    assert f((3, 4)) == 7
    g = obj.extract_function('g')
    assert g((3, 4)) == 7
    h = obj.extract_function('h')
    assert h((3, 4)) == 7
   

# Generated at 2022-06-12 19:02:00.184416
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:02:34.695289
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    for _ in range(100):
        argnames = tuple(str(i) for i in range(random.randint(1, 5)))
        code = ";".join("%s=%d" % (random.choice(argnames), random.randint(-100, 100)) for _ in range(random.randint(1, 5)))
        f = js_interpreter.build_function(argnames, code)
        args = tuple(random.randint(-20, 20) for _ in argnames)
        assert f(args) == args[-1]

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-12 19:02:39.078301
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    from .common import random_user_agent
    # Case 1: construct function from function name, function name is 'parseInt'
    jsInterpreter = JSInterpreter("parseInt('0xc63c9a', 16)")
    func = jsInterpreter.build_function(['x'], "x.split('').reverse().join('')")
    assert func(['123']) == '321'

    # Case 2: construct function from function name, function name is 'reverseArray'
    jsInterpreter = JSInterpreter("reverseArray([1, 2, 3, 4])")
    func = jsInterpreter.build_function(['x'], "x.reverse()")
    assert func([[1, 2, 3, 4]]) == [4, 3, 2, 1]

    # Case 3: construct funtion from

# Generated at 2022-06-12 19:02:47.609762
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:03:01.145898
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    local_vars = {}
    js_interpreter = JSInterpreter('', local_vars)

    code = '''
        var obj = {
            f: function(a, b) {
                return a + b;
            }
        };
        '''
    js_interpreter.code = code
    obj = js_interpreter.extract_object('obj')
    assert obj['f'](1, 2) == 3

    code = '''
        var obj = {
            f: function(a, b) {
                return a + b;
            }
        };
        '''
    js_interpreter.code = code
    obj = js_interpreter.extract_object('obj')
    assert obj['f'](1, 2) == 3
    obj = js_interpreter

# Generated at 2022-06-12 19:03:11.179242
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
    var a = [1, 2, 3, 4];
    var b = function(x, y){return x + y};
    var c = "abc";
    var d = {
      'a': 1,
      'b': function(x, y){ return x * y; },
      'c': ['a', 'b', 'c']
    };
    var e = 42;
    """
    interpreter = JSInterpreter(code)
    local_vars = {}
    interpreter.interpret_statement(code, local_vars)

    assert local_vars["a"] == [1, 2, 3, 4]
    assert local_vars["b"](1, 2) == 3
    assert local_vars["c"] == "abc"

# Generated at 2022-06-12 19:03:19.914537
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    from .utils import get_testdata_file
    with open(get_testdata_file('js_test.js')) as f:
        jsi = JSInterpreter(f.read())
    local_vars = {
        'a': 2,
        'b': -23.5,
        'c': 0.09,
        'd': 'apple',
    }

    assert jsi.interpret_expression('a', local_vars) == 2
    assert jsi.interpret_expression('a+b', local_vars) == -21.5
    assert jsi.interpret_expression('(a+b)-2', local_vars) == -23.5
    assert jsi.interpret_expression('a*b+b/c-1', local_vars) == -44.16666666666667
    assert j

# Generated at 2022-06-12 19:03:30.484486
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Note: The code of method build_function had been modified. This unit test might fail in the future.
    js_interpreter = JSInterpreter("")
    build_function = js_interpreter.build_function
    func = build_function(["a","b","c"], "a;b;c;return 0")
    assert func([1, 2, 3]) == 0
    func = build_function(["a","b","c"], "a;b;c;return a")
    assert func([1, 2, 3]) == 1
    func = build_function(["a","b","c"], "a;b;c;return b")
    assert func([1, 2, 3]) == 2
    func = build_function(["a","b","c"], "a;b;c;return c")

# Generated at 2022-06-12 19:03:41.577221
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    """
    js_interpreter = JSInterpreter(code)
    js_interpreter.call_function(funcname, *args)
    """

    # Test 1
    code = """
        a = function() {
            var func = function(arg1, arg2) {
                return arg1 + arg2;
            }
            return func;
        }
        result = a();
    """
    js_interpreter = JSInterpreter(code)
    result = js_interpreter.call_function('a')
    assert result(4, 5) == 9

    # Test 2

# Generated at 2022-06-12 19:03:44.109465
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter('')
    f = jsi.build_function(['a'], ';return a;')
    assert f([1]) == 1



# Generated at 2022-06-12 19:03:53.276294
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def assert_equal(expression, expected_output):
        local_vars = {}
        interpreter = JSInterpreter("")
        output = interpreter.interpret_expression(expression, local_vars, 100)
        assert output == expected_output
    assert_equal('1', 1)
    assert_equal('-3.5', -3.5)
    assert_equal('"abc"', "abc")
    assert_equal('(2-(2+2)*(1+1))', -8)
    assert_equal('!true', False)

if __name__ == '__main__':
    import sys
    import json

    if len(sys.argv) == 1:
        import doctest
        doctest.testmod()

# Generated at 2022-06-12 19:04:21.007593
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    objects = {'window': {'location': {'href': 'http://example.com/'}}}
    js_interpreter = JSInterpreter('', objects)
    fct = js_interpreter.build_function(
        ['arg1', 'arg2'], 'return arg1.join(arg2);')
    assert fct(['a', 'b', 'c', 'd'], ';') == 'a;b;c;d'
    fct = js_interpreter.build_function(['fn'], 'return fn(2);')
    assert fct([lambda x: x * x]) == 4


if __name__ == '__main__':
    import sys
    test_JSInterpreter_build_function()
    sys.exit(0)

# Generated at 2022-06-12 19:04:33.848242
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsin = JSInterpreter("var a=[0,1,2,3,4,5,6,7,8,9];var b=[9,8,7,6,5,4,3,2,1,0]; var c='abcdefghij'; var d=12345;")
    assert jsin.interpret_expression("a", {}) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert jsin.interpret_expression("a[2]+d", {}) == 12345+2
    assert jsin.interpret_expression("a[d%10]", {}) == 5
    assert jsin.interpret_expression("c.length", {}) == 10
    assert jsin.interpret_expression("c[0]+c[1]", {}) == "ab"

# Generated at 2022-06-12 19:04:42.066184
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter("""
        function foo(a,b,c){
            c = [a,b,c];
            b = a = 0;
            return c;
        }
        """)
    assert interpreter.call_function('foo', 1,2,3) == [1,2,3]
    assert interpreter.call_function('foo', 4,5,6) == [4,5,6]
    assert interpreter.call_function('foo', 7,8,9) == [7,8,9]

# Generated at 2022-06-12 19:04:53.474040
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:05:01.452291
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsinter = JSInterpreter(code=(
        'var a = 5;'))
    assert jsinter.interpret_statement('a - 14', {})[0] == -9
    assert jsinter.interpret_statement('return a', {})[0] == 5
    assert jsinter.interpret_statement('return a - 13', {})[0] == -8
    assert jsinter.interpret_statement('a + 13; return a * 3', {})[0] == 15



# Generated at 2022-06-12 19:05:11.801904
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    obj = {
        'a': 1,
        'b': 'two',
        'c': [3, 4],
        'd': ('three', 'four'),
        'e': {6: 'six'},
        'f': ['seven'],
        'g': {'eight': 9},
        'substr': lambda args: args[0][args[1]:],
        'substring': lambda args: args[0][args[1]:args[2]],
    }

    interp = JSInterpreter(None)

    print(interp.interpret_expression('1 + 2', {}, 1000))  # 3
    print(interp.interpret_expression('1 + 2 - 1', {}, 1000))  # 2
    print(interp.interpret_expression('1 + -2', {}, 1000))  # -1
   

# Generated at 2022-06-12 19:05:17.120462
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    l = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    jsi = JSInterpreter(None, {'a': l})
    print(jsi.interpret_expression('a[1+1]', {}, 100))
    print(jsi.interpret_expression('a[0]', {}, 100))
    print(jsi.interpret_expression('a[7]', {}, 100))


# Generated at 2022-06-12 19:05:21.497749
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter=JSInterpreter("")
    argnames = ['a', 'b']
    code = """
    tmp=a+b;
    tmp-=10;
    return tmp;
    """
    resf = js_interpreter.build_function(argnames, code)
    assert(resf([2, 3]) == -5)
    assert(resf([0, 0]) == -10)
    assert(resf([100, 100]) == 180)

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-12 19:05:23.563555
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter(code=None, objects=None)
    assert js_interpreter.interpret_expression('a', {'a': 1}, 100) == 1

# Generated at 2022-06-12 19:05:34.971378
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    print("[+] Testing JSInterpreter.extract_object")

    code1 = """
        var a = {
            b: function(a){
                return "c"
            }
        };
    """

    code2 = """
        var g = {};
        g.a = {
            b: function(a){
                return "c"
            }
        };
    """

    code3 = """
        var g = {
            a: {
                b: function(a){
                    c = 123
                    return 0
                }
            }
        };
    """

    interpreter = JSInterpreter(code1)
    obj1 = interpreter.extract_object("a")
    assert(obj1 == {"b": lambda a: "c"})

    interpreter = JSInterpreter(code2)
    obj

# Generated at 2022-06-12 19:06:00.920136
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-12 19:06:08.632464
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    resolve_obj = JSInterpreter.build_function(
        ['a', 'b'],
        '''
            var d = a[0];
            var e = a[1];
            var f = a[2];
            var g = b;
            var h = 0;
            do {
                h = d(f, g)
            } while (f > 0 && h == 0);
            return h;
        ''')
    def d(f, g):
        return f + g

    test_value = resolve_obj([[d, 0, 1], 2])
    assert test_value == 3

# Generated at 2022-06-12 19:06:20.719238
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
        var D = function(b) {
            var a = b.match(/^\D+(\d+)/);
            if (!a)
                return !1;
            a = parseInt(a[1], 10);
            return 0 === a % 100 ? 0 === a % 400 ? !0 : !1 : 0 === a % 4 ? !0 : !1
        };
        var E = function(b) {
            var a = b.match(/^\D+(\d+)/);
            if (!a)
                return !1;
            a = parseInt(a[1], 10);
            return 0 === a % 100 ? 0 === a % 400 ? !0 : !1 : 0 === a % 4 ? !0 : !1
        };
    '''

# Generated at 2022-06-12 19:06:27.513768
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:06:39.724983
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:06:43.606160
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''var a = function(b, c, d){
        var e = b + c - d
        return e
    }'''
    assert JSInterpreter(code).call_function('a', 1, 2, 3) == 0


# Generated at 2022-06-12 19:06:56.043179
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:07:01.324544
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # muxer is a name of the class
    # h is a name of variable
    # b is a name of variable
    code = '''
        var muxer = function() {
            var h = [], b = 0;
            h[0] = function() {
                return b;
            }
        }
    '''
    js_interpreter = JSInterpreter(code)
    muxer = js_interpreter.build_function([], code)
    h = muxer()[0]

    assert h() == 0


# Generated at 2022-06-12 19:07:11.148066
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def safe_interpret(js_code):
        JSInterpreter(js_code).interpret_expression(js_code, {})

    # Test all operators
    for op, opfunc in _OPERATORS:
        safe_interpret('4{0}4'.format(op))

    # Test function call
    safe_interpret('x(4,4)')
    safe_interpret('x(4,4).y(4,4)')
    safe_interpret('x(4,4)[y(4,4)]')

    # Test array access
    safe_interpret('x[y]')
    safe_interpret('x.y')
    safe_interpret('x().y')
    safe_interpret('x()[y]')

    # Test object access
    safe_interpret('x[y]')

# Generated at 2022-06-12 19:07:23.532710
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def _resv(code, *args):
        interp = JSInterpreter(code)
        return interp.build_function([], code)(args)

    code = '''function(a, b) {return [a, b]}'''
    assert _resv(code, 1, 3) == [1, 3]

    code = '''function(a, b) {return a + b}'''
    assert _resv(code, 1, 3) == 4

    code = '''function(a, b) {return a[0]}'''
    assert _resv(code, [1, 2], [1, 3]) == 1

    code = '''function(a, b) {return a.b}'''
    assert _resv(code, {'b' : 1}, {'b' : 2}) == 1

# Generated at 2022-06-12 19:07:47.730324
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:07:56.901079
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objects = {
        'map': {'abc': '123', 'def': '456'},
    }
    translator = JSInterpreter('var foo = {}; foo.bar = function(args) { return "Hello" };', objects)

    foo = translator.extract_object('foo')
    assert('bar' in foo)
    assert('Hello' == foo['bar']())

    with pytest.raises(ExtractorError) as excinfo:
        translator.extract_object('bar')
    assert('Could not find JS function' in str(excinfo.value))

    assert(objects == translator._objects)



# Generated at 2022-06-12 19:08:07.092162
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_input_dict = {
        'mep_obj': {'mep_f': None},
        'mec_obj': {'mec_f': None},
        'mux': {'x': None},
        'muy': {'y': None},
        'muz': {'z': None}
    }

# Generated at 2022-06-12 19:08:15.001741
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Test case 1.
    code = '''
        test = {
            name: '',
            type: 'even more',
            more: function(arg1, arg2){
                var toReturn = arg1 + ' ' + arg2;
                return toReturn;
            },
            more2: function(arg1,arg2){
                var toReturn = arg1 + ' ' + arg2;
                return toReturn;
            }
        };
    '''
    js = JSInterpreter(code)
    exp_obj = {
        'name': '',
        'more': lambda args: args[0] + ' ' + args[1],
        'more2': lambda args: args[0] + ' ' + args[1],
        'type': 'even more'
    }
    obj = js.extract_object

# Generated at 2022-06-12 19:08:19.530150
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = r'''var obj = {'a': function(arg) {
                     return arg;
                 }};
                 '''
    inter = JSInterpreter(code)
    func = inter.build_function(['arg'], r'return arg;')
    assert func([42]) == 42

# Generated at 2022-06-12 19:08:30.340832
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    """
    >>> test_JSInterpreter_interpret_statement()
    """
    interpreter = JSInterpreter('')
    local_vars = {}

# Generated at 2022-06-12 19:08:40.411964
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var aa = {
            bb: function(cc) {
                uu = "u=" + cc;
                return uu;
            },
            dd: function() {
                return 1;
            },
            ee: 5
        };
        var ff = aa.bb("v");
        var gg = aa.dd();
    '''
    js_interpreter = JSInterpreter(js_code)
    aa = js_interpreter.extract_object("aa")
    bb = aa["bb"]
    ff = bb((('c',),))
    assert ff == "u=c"

# Generated at 2022-06-12 19:08:47.959297
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter('A=B')
    func_a = interpreter.build_function(['A'], 'return A+1')
    func_b = interpreter.build_function(['B'], 'return B+1')
    result_a = func_a([2])
    result_b = func_b([2])
    assert result_a == 3
    assert result_b == 3

# Generated at 2022-06-12 19:08:57.035671
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Arrange
    code = '''var re = {
            escape: function (s) {
                return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
            }
        };'''
    interpreter = JSInterpreter(code)
    expected = '\\[-\\/\\\\\\^\\$\\*\\+\\?\\.\\(\\)\\|\\[\\]\\{\\}\\]'
    # Act
    stmt = 'escape("[-/\\^$*+?.()|[\\]{}]");'
    res, abort = interpreter.interpret_statement(stmt, {})
    # Assert
    assert (res == expected)

# Generated at 2022-06-12 19:09:07.837518
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test STRING type
    code = ';var abc="12345";'
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.interpret_expression('abc', {}) == '12345'
    assert js_interpreter.interpret_expression('abc.length', {}) == 5

    # Test NUMBER type
    code = ';var cd=12345;'
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.interpret_expression('cd', {}) == 12345
    assert js_interpreter.interpret_expression('cd.toString()', {}) == '12345'

    # Test LIST type
    code = ';var ef=[1,2,3,4,5];'