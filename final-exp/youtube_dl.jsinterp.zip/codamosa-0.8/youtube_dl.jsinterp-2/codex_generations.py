

# Generated at 2022-06-12 18:59:58.919658
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    JSInterpreter('', {}).interpret_statement('document.length', {})

# Generated at 2022-06-12 19:00:05.099398
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:00:08.054643
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
        function func_1() {
            var input = '12345';
            return func_2(input);
        }
        function func_2(input) {
            return String.fromCharCode(input);
        }
    '''
    interpreter = JSInterpreter(js_code)
    assert interpreter.call_function('func_1') == '12345'


# Generated at 2022-06-12 19:00:18.550181
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    return
    # Test 1
    js_code = """
        var a = b;
        var d;
        function testJsInterpreter(arg1, arg2){
            var c;
            c = arg1;
            a = arg2;
            d = c + a;
            return d;
        }
    """
    interpreter = JSInterpreter(js_code)
    res = interpreter.call_function('testJsInterpreter', 4, 5)
    assert res == 9

    # Test 2

# Generated at 2022-06-12 19:00:25.867586
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    a = JSInterpreter('''
        function hello(a) {
            var b = a;
            for (var i=0;i<4;i++){
                b += a[i]+",";
            };
            return(b)
        };
    ''')
    assert '11,12,13,14,' == a.call_function('hello', [11, 12, 13, 14])
    assert '11,12,13,14,11,12,13,14,' == a.call_function('hello', [[11, 12, 13, 14], [11, 12, 13, 14]])

# Generated at 2022-06-12 19:00:37.393067
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:00:50.352665
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code_test = '''
        var i = 0;
        var c = {
            "name": "c",
            "a": 5,
            "b": 6,
            "c": function (arg) {
                return i + arg;
            }
        };
        var d = function (arg) {
            return i - arg
        };
    '''
    js_interpreter_test = JSInterpreter(js_code_test)
    object_test = {'a': 5, 'b': 6, 'c': js_interpreter_test.build_function([], 'return i + arg'), 'name': 'c'}
    assert(js_interpreter_test.interpret_expression('3*a | (1<<2) & -2', {'a': 5}) == 13)

# Generated at 2022-06-12 19:00:59.340145
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Simple code
    func = JSInterpreter.build_function(['x', 'y'], 'return x + y;')
    assert func((1, 2)) == 3
    assert func((5, 6)) == 11

    # Code with operator '+='
    func = JSInterpreter.build_function(
        ['x'], 'x += 10;return x;')
    assert func((1,)) == 11

    # Code with operator '*='
    func = JSInterpreter.build_function(
        ['x'], 'x *= 10;return x;')
    assert func((1,)) == 10

    # Code with operator '*='
    func = JSInterpreter.build_function(
        ['x'], 'x /= 10;return x;')
    assert func((10,)) == 1

    #

# Generated at 2022-06-12 19:01:12.380987
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('var test = "test";')
    assert interpreter.interpret_expression('test', {'test': 'test result'}) == 'test result'

    interpreter = JSInterpreter('var test = ["test","test2"];', {'test': ['test result', 'test2 result']})
    assert interpreter.interpret_expression('test[0]', {'test': ['test result', 'test2 result']}) == 'test result'
    assert interpreter.interpret_expression('test[1]', {'test': ['test result', 'test2 result']}) == 'test2 result'
    assert interpreter.interpret_expression('test.length', {'test': ['test result', 'test2 result']}) == 2
    assert interpreter.interpret_expression('test.length', {}) == 2


# Generated at 2022-06-12 19:01:19.650062
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = r'''
        function parse(a) {
            function f(a, b) {
                return a + b;
            }
            return f(1, 2);
        }
    '''
    js_interpreter = JSInterpreter(code)

    output = js_interpreter.call_function('parse', 3)
    print(output)
    assert output == 3



# Generated at 2022-06-12 19:02:01.213860
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:02:06.028354
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test for operator assignments
    jsInterpreter = JSInterpreter('', {'a': []})
    assert jsInterpreter.interpret_expression('a=0', {}, 100) == 0
    assert jsInterpreter.interpret_expression('a+=0', {'a':0}, 100) == 0
    assert jsInterpreter.interpret_expression('a-=0', {'a':0}, 100) == 0
    assert jsInterpreter.interpret_expression('a*=0', {'a':0}, 100) == 0
    assert jsInterpreter.interpret_expression('a/=0', {'a':0}, 100) == 0
    assert jsInterpreter.interpret_expression('a%=0', {'a':0}, 100) == 0

# Generated at 2022-06-12 19:02:13.754404
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_js = '''
    foo = function(a,b) {
        x = a.split("");
        y = b.split("");
        while (x.length > 0 && y.length > 0) {
            if (x[0] == y[0]) {
                x.splice(0, 1);
                y.splice(0, 1);
            } else {
                break;
            }
        }
        return x.join("") + y.join("");
    }

    bar = "fgh";
    '''

    res = JSInterpreter(test_js).extract_function('foo')(
        "abcdefgh", "abcdefghi")
    assert res == 'efghi', 'Unable to parse JS function'

# Generated at 2022-06-12 19:02:21.978876
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # we create a js string that defines an object with name 'a'
    # and a method f with a single parameter x
    # the method f returns x*2
    code = """
        a = {
            f: function(x) {
                return x*2;
            }
        };
    """
    interpreter = JSInterpreter(code)
    assert('f' in interpreter._objects['a'])
    assert(interpreter._objects['a']['f'](2)==4)


# Generated at 2022-06-12 19:02:26.061069
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        a = {
            "b": function(p){return p},
            "c": function(p){return -p}
        };'''
    interpreter = JSInterpreter(code)
    a = interpreter.extract_object('a')
    assert a['b'](2) == 2
    assert a['c'](2) == -2

# Generated at 2022-06-12 19:02:39.760164
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # quick hack to test the method extract_object
    expected = {'u': {'split': "<method 'split' of 'str' objects>"},
                'reverse': "<method 'reverse' of 'list' objects>",
                'slice': "<method 'slice' of 'list' objects>",
                'splice': "<method 'splice' of 'list' objects>",
                'join': "<method 'join' of 'str' objects>"}

# Generated at 2022-06-12 19:02:48.001694
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def test_case(js, expected):
        interpreter = JSInterpreter('')
        local_vars = {'a': [1, 2, 3], 'b': 'foo', 'c': {'x': 'y'}}
        assert interpreter.interpret_expression(js, local_vars) == expected

    test_case('a', [1, 2, 3])
    test_case('a[1]', 2)
    test_case('a[1 + 1]', 3)
    test_case('a[1 + 1] + 2', 5)
    test_case('a[b[c.x]] + 2', 5)
    test_case('2 + 3', 5)
    test_case('2 + 3 - 4', 1)

# Generated at 2022-06-12 19:03:01.490172
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def eq(i, o):
        if o == JSInterpreter(i).interpret_expression(i):
            print("o OK")
        else:
            print("x FAIL")
    eq("<<5", 5*(2**5))
    eq("1*-5", 1*-5)
    eq("(0+5)*(2-3)", (0+5)*(2-3))
    eq("a.length", "abcd")
    eq("a.length/2", 2)
    eq("a.length+1", 5)
    eq("a.length-5", 2)
    eq("a.length+5", 6)
    eq("a.slice(0)", "ab")
    eq("a.slice(1)", "b")
    eq("a.length%2", 0)

# Generated at 2022-06-12 19:03:11.386670
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:03:19.046470
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = (
        'var obj = {'
        '   "func_a": function() { return 1 + 2; },'
        '   "func_b": function(a, b) { return a - b; },'
        '   "func_c": function(a, b) { return a * b; }'
        '};'
    )
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('obj')
    assert obj['func_a']() == 3
    assert obj['func_b'](5, 2) == 3
    assert obj['func_c'](5, 5) == 25


# Generated at 2022-06-12 19:03:40.365006
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'c=a;d=b;c+d;')
    assert(func((1, 2)) == 3)
    func = js_interpreter.build_function(['a', 'b'], 'c=a;d=b;var e=c+d;e;')
    assert(func((1, 2)) == 3)
    func = js_interpreter.build_function(['a', 'b'], 'c=a;d=b;return c+d;')
    assert(func((1, 2)) == 3)

# Generated at 2022-06-12 19:03:44.797656
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jseval = JSInterpreter("""
        function test(a,b) {
            c = a + b;
            return c;
        }
    """)
    res = jseval.build_function(['a', 'b'], "c = a + b; return c;")
    assert res([1, 2]) == 3

# Generated at 2022-06-12 19:03:53.809694
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = "['u2FsdGVkX1+YbZ5xO7q3E1yC+/yHM5I/Nw7Q2N/N+VzZuOJg8a1X9f6UETD6UyQ6']"
    objname = 'test'
    funcname = 'testFunc'
    interpreter = JSInterpreter(code)

# Generated at 2022-06-12 19:04:04.712192
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = '''var obj = {
        name: "Obi Wan",
        planet: "Tatooine",
    }
    var other_obj = {
        func: function() {return "Hi";}
    }'''
    objs = JSInterpreter(js)._objects
    assert 'obj' in objs
    obj = objs['obj']
    assert 'name' in obj
    assert obj['name'] == 'Obi Wan'
    assert 'planet' in obj
    assert obj['planet'] == 'Tatooine'
    assert 'other_obj' in objs
    other_obj = objs['other_obj']
    assert other_obj['func']() == 'Hi'


# Generated at 2022-06-12 19:04:16.514848
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    #test1
    code1 = 'abc;'
    local_vars1 = dict({'abc':'abc_value'})
    res1 = JSInterpreter(code1).interpret_expression(code1,local_vars1,100)
    assert res1=='abc_value', 'test1 failed'

    #test2
    code2 = '"abc";'
    local_vars2 = dict({'abc':'abc_value'})
    res2 = JSInterpreter(code2).interpret_expression(code2,local_vars2,100)
    assert res2=='abc', 'test2 failed'

    #test3
    code3 = 'abc=2;'
    local_vars3 = dict({'abc':'abc_value'})

# Generated at 2022-06-12 19:04:23.348560
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
var a = 1;
var b = 2;
var c = {
  d: function(a,b) { console.log(a-b); }
}
c.d(a,b);
'''
    i = JSInterpreter(code)
    assert i.extract_object('c') == {'d': lambda a,b: console.log(a-b)}


# Generated at 2022-06-12 19:04:31.569617
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = (
        'function abc(a){var b=a.join("")}function def(c){var a=c.split("");abc(a)}'
    )
    interpreter = JSInterpreter(code)
    function = interpreter.build_function(['a'], 'var b=a.join("");')
    assert function(['1','2','3']) == '123'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 19:04:43.554696
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code_str = "var A=function(a){this.a=a};"
    code_str += "var B=function(b){this.b=b};"
    code_str += "var C=function(c){this.c=c};"
    code_str += "var D={};"
    code_str += "D.a=function(aa){this.aa=aa};"
    code_str += "D.b=function(bb){this.bb=bb};"
    code_str += "D.c=function(cc){this.cc=cc};"
    code_str += "D.d=[0,1,2];"
    code_str += "D.e=\"hello\";"
    code_str += "D.f=[3,4,5];"

# Generated at 2022-06-12 19:04:54.318266
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:05:00.516575
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        abc = {
            xxx: function(a) { return a; },
            yyy: function(a) { return a; }
        }
    '''

    res = JSInterpreter(code).extract_object('abc')
    assert res['xxx'](5) == 5
    assert res['yyy'](6) == 6

# Generated at 2022-06-12 19:05:27.270941
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:05:30.163460
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var A = {
            x: function(a) {
                return a.join()
            },
        }
    """

    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('A')
    assert obj['x'](['a']) == 'a'



# Generated at 2022-06-12 19:05:36.946725
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:05:39.177669
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_code = '''
      e = {
        b: function(a) {
          return a
        }
      }
    '''
    js_interpreter = JSInterpreter(test_code)
    obj = js_interpreter.extract_object('e')
    assert obj['b'](['a']) == 'a'



# Generated at 2022-06-12 19:05:41.503967
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    JSInterpreter_inst = JSInterpreter('test')
    assert JSInterpreter_inst.build_function(['a'],'return a') == 'a'


# Generated at 2022-06-12 19:05:47.224545
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    local_vars = {
        'a': 1,
        'b': 3,
        'c': 7,
        'd': 0,
        'e': [1, 2, 3],
        'f': 5,
        'g': 7,
        'h': 9,
        'i': ['a', 'b', 'c', 'd', 'e'],
    }
    def test_interpret_statement(stmt, expected_result):
        interpreter = JSInterpreter('')
        actual_result, should_abort = interpreter.interpret_statement(stmt, local_vars)
        assert actual_result == expected_result, \
            '%s -> %s != %s' % (stmt, actual_result, expected_result)
    test_interpret_statement('a', 1)
    test_interpret_

# Generated at 2022-06-12 19:05:58.388427
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    import pytest

    code = '''
        function test_func(a, b){
            var c = a + b;
            var d = c + b;
            var e = c + d;
            return e
        }
        '''
    js_interpreter = JSInterpreter(code)
    try:
        assert js_interpreter.extract_function('test_func')([1, 2]) == 6
    except ExtractorError as error:
        pytest.fail('Error: ' + (error.msg))


# Generated at 2022-06-12 19:06:06.725577
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinterpreter = JSInterpreter("""
            function w(a) {
                    if (a == 0) {
                            return "1";
                    }
                    else {
                            if (a == 1) {

                                    return "a";
                            }
                            else {
                                    return a[1] + w(a.slice(1));
                            }
                    }
            }""")
    result = jsinterpreter.extract_function("w")
    assert result(["01"]) == "11"


# Generated at 2022-06-12 19:06:12.691095
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r'''
        function big_function() {
            this.a = {
                b: "abc",
                c: function() { return 42; }
            };
        }
    '''
    js = JSInterpreter(code)

    assert js.extract_object('a')['b'] == 'abc'
    assert js.extract_object('a')['c']() == 42


# Generated at 2022-06-12 19:06:23.585598
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter(None)
    local_vars = {'test':'test_val', 'test2':'test2_val', 'test3':'test3_val', 'test4':'test4_val'}
    expr = '"test"'
    assert js_interpreter.interpret_expression(expr, local_vars) == 'test'
    expr = 'test'
    assert js_interpreter.interpret_expression(expr, local_vars) == 'test_val'
    expr = 'test2'
    assert js_interpreter.interpret_expression(expr, local_vars) == 'test2_val'
    expr = '{test : test2, test3 : test4}'
    assert js_interpreter.interpret_expression(expr, local_vars)

# Generated at 2022-06-12 19:06:50.291904
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = '''
        function test_func(arg1, arg2) {
            var a, b, c;
            a = arg1;
            b = arg2;
            c = a + b;
            return c;
        }
    '''
    assert JSInterpreter(js_code).call_function('test_func', 3, 4) == 7

# Generated at 2022-06-12 19:06:59.547681
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinterpreter = JSInterpreter(None)
    argnames = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    code = 'a + b / c * d + e - f % g ^ h & i | j << k >> l >>> m ;'
    def resf(*args):
        assert len(argnames) == len(args)
        local_vars = dict(zip(argnames, args))
        for stmt in code.split(';'):
            res, abort = jsinterpreter.interpret_statement(stmt, local_vars)
        return res
    f = jsinterpreter.build_function(argnames, code)


# Generated at 2022-06-12 19:07:10.076143
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:07:12.995138
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsInterpreter = JSInterpreter('var a={x:function(){return 0;},a1:function(){return 1;}};')
    assert jsInterpreter.extract_object('a') == {'x': lambda: 0, 'a1': lambda: 1}
    assert jsInterpreter.extract_object('b') == {}


# Generated at 2022-06-12 19:07:24.934313
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        function f() {}
        var g = function g() {};
        var a = 1;
        var b = 2;
        var c = ["one", "two", "three"];
        var d = "four";
        var e = {"a": 1, "b": {"c": 2}};
        var f = [1, 2, 3];
        var o = {
            "a": 1,
            "b": function(x) { return x + 5; },
            "c": [1, 2, 3],
            "d": function(x, y) { return x + y; }
        };
        var p = [9, 8, 7];
        '''
    jsint = JSInterpreter(code)
    assert jsint.interpret_expression('a + b', {}) == 3
   

# Generated at 2022-06-12 19:07:31.914175
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    from .common import InAdvancePagedList

    objects = {}
    objects["a"] = InAdvancePagedList(1, 10, lambda cur, size: range(cur, cur + size))

    intp = JSInterpreter("""
        var b = {
            d: function() {
                var f = function(h) {
                    return h;
                };
                return g;
            }
        };
    """, objects)

    assert intp.extract_object("b")["d"](1) == 1


# Generated at 2022-06-12 19:07:44.005306
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:07:53.161117
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('').interpret_expression('3', {}) == 3
    assert JSInterpreter('').interpret_expression('3 + 3', {}) == 6
    assert JSInterpreter('').interpret_expression('3 - 3', {}) == 0
    assert JSInterpreter('').interpret_expression('3 * 3', {}) == 9
    assert JSInterpreter('').interpret_expression('3 / 3', {}) == 1
    assert JSInterpreter('').interpret_expression('3 % 2', {}) == 1
    assert JSInterpreter('').interpret_expression('3 << 2', {}) == 12
    assert JSInterpreter('').interpret_expression('3 >> 2', {}) == 0
    assert JSInterpreter('').interpret_expression('3 | 2', {}) == 3
    assert JS

# Generated at 2022-06-12 19:08:04.041955
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:08:08.951150
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = """
        function c(a) {
          return 0
        }
        var b={a:function(){},c:function(a){return 1},b:function(a,b,c){return b}};
        a.k=b"""

    jsi = JSInterpreter(js)
    obj = jsi.extract_object('a.k')
    assert callable(obj['a'])
    assert callable(obj['c'])
    assert callable(obj['b'])
    assert obj['c'](3) == 1
    assert obj['b'](1, 2, 3) == 2



# Generated at 2022-06-12 19:08:37.321983
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('''\
        function func_1(arg1){
            var var_1 = 10;
            var var_2 = true;
            var_1 += 100;
            return var_2;
        }
    ''')
    result = js_interpreter.build_function(['arg1'], '''\
        var var_1 = 10;
        var var_2 = true;
        var_1 += 100;
        return var_2;
    ''')([])
    assert result, 'The result should be true'


# Generated at 2022-06-12 19:08:48.004434
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter('', {}).build_function([], '')() == None
    assert JSInterpreter('', {}).build_function([], '1')() == 1
    assert JSInterpreter('', {}).build_function([], 'x').__name__ == 'resf'
    assert JSInterpreter('', {}).build_function(['x'], 'x').__name__ == 'resf'
    assert JSInterpreter('', {}).build_function(['x'], 'x')(1) == 1
    assert JSInterpreter('', {}).build_function(['x', 'y'], 'x + y')(1, 2) == 3


# Generated at 2022-06-12 19:08:53.699152
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter(none)
    # Test the method interpret_expression of class JSInterpreter
    # Test case 1:

# Generated at 2022-06-12 19:09:00.806912
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = '''
        var v1 = "abcd1234";
        var v2 = [0x100, 0x200];
        var v3 = "B1B2B3B4";
        var v4 = [4, 5, 6, 7];
        var v5 = "abcd1234";
        function f1(a, b, c, d) {
            var v6 = v1[c] + v2[2] + v3[d] + v4[c] + v5[d];
            return v6;
        }
    '''
    interpreter = JSInterpreter(js)

# Generated at 2022-06-12 19:09:10.995486
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:09:17.946593
# Unit test for method interpret_expression of class JSInterpreter