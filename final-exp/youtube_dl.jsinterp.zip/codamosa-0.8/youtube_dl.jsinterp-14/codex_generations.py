

# Generated at 2022-06-12 19:00:37.204844
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():

    def validate(func):
        try:
            func()
            return True
        except:
            return False

    js = JSInterpreter('', {})

    assert js.interpret_expression('', {}, 100) == None

    assert js.interpret_expression('1', {}, 100) == 1

    # Empty parens
    assert js.interpret_expression('( )', {}, 100) == None

    # parens
    assert js.interpret_expression('( 1 + 2)', {}, 100) == 3

    # parens with asignment
    assert js.interpret_expression('var a = 1+2 ; ( a )', {}, 100) == 3

    # parens with asignment 2
    assert js.interpret_expression('var a = 1 + 2 ; ( a ) + 10', {}, 100) == 13

    #

# Generated at 2022-06-12 19:00:50.026387
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test = '''
        ytplayer.config = {
            args: {
                hlsvp: "http://blabla.com/hls/hls_720p.m3u8",
                uri: "/watch?v=iKHgzTjdK7I",
                "dashmpd": "http://blabla.com/dash/dash_720p.mpd",
            },
            assets: {
                js: "http://www.youtube.com/yts/jsbin/player-vflrGXrq3/en_US/base.js",
            },
            attrs: {},
        };'''

    jsinter = JSInterpreter(test)
    res = jsinter.extract_object('ytplayer')

# Generated at 2022-06-12 19:00:56.463818
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsi = JSInterpreter(r'''
        var a = {
            b: function(c) {
                return c * 2
            }
        };

        var d = {
            e: function(f) {
                return f + 2
            }
        };
        ''')
    a = jsi.extract_object('a')
    assert a['b'](7) == 14
    d = jsi.extract_object('d')
    assert d['e'](4) == 6


# Generated at 2022-06-12 19:01:09.592633
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:01:22.210236
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    obj = '''
        function a() {}
        function b() {}
        var c = a;
        var d = {
            e: function(){},
            f: function(){},
        }
        var g = {
            h: function(){},
            i: function(){},
        }
    '''
    js_interpreter = JSInterpreter(obj)

    assert js_interpreter.extract_object('g') == {
        'h': js_interpreter.build_function([], ''),
        'i': js_interpreter.build_function([], ''),
    }

# Generated at 2022-06-12 19:01:28.115902
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = """
function some_func(foo, bar) {
    var baz = foo + bar;
    return foo * bar * baz;
}
"""
    inter = JSInterpreter(js)
    f = inter.extract_function('some_func')
    assert f((1, 2)) == 12



# Generated at 2022-06-12 19:01:38.821840
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():

    def functionA(*args):
        return args

    jsinterpreter = JSInterpreter('', {'a': functionA})
    assert jsinterpreter.interpret_expression('a(1,2,3)', {}) == (1,2,3)
    assert jsinterpreter.interpret_expression('a', {}) == functionA

    jsinterpreter = JSInterpreter('', {'a': [1, 2, 3]})
    assert jsinterpreter.interpret_expression('a.0', {}) == 1
    assert jsinterpreter.interpret_expression('a[0]', {}) == 1
    assert jsinterpreter.interpret_expression('a.1', {}) == 2
    assert jsinterpreter.interpret_expression('a[1]', {}) == 2
    assert jsinterpreter.interpret_expression

# Generated at 2022-06-12 19:01:47.782257
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function funcA(a) {
            return a;
        }
        function funcB(a, b) {
            return a + b;
        }
        function funcC(a, b) {
            return [a, b, a + b];
        }
    '''
    interp = JSInterpreter(js_code)
    class A(object):
        def funcD(self, a, b):
            return a * b
    interp._objects['a'] = A()

    assert interp.call_function('funcA', 3) == 3
    assert interp.call_function('funcB', 3, 5) == 8
    assert interp.call_function('funcC', 3, 5) == [3, 5, 8]

# Generated at 2022-06-12 19:01:52.351578
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter("""
        function foo(a,b,c) {
            return a.bar(b, [c.d, e.slice(0,c.f), +g.h, [i[0]]]);
        }
    """)
    assert jsi.interpret_expression("a.bar(b, [c.d, e.slice(0,c.f), +g.h, [i[0]]])", {"a": {"bar": lambda args: args}, "b": 1, "c": {"d": 2, "f": 3}, "e": [4, 5, 6], "g": {"h": 4}, "i": [5]}) == (1, [2, [4, 5], 4, [5]])

# Generated at 2022-06-12 19:01:58.807608
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
    var test_var = "hey dude";
    var test_func = function(your_name, my_name) {
        var hello = "hello ";
        var salutation = hello + your_name;
        var greeting = hello + salutation;
        return "hello " + salutation + " " + greeting;
    };
    '''
    js = JSInterpreter(code)
    assert js.extract_function('test_func')(
        ['voldemort', 'harry']) == 'hello hello voldemort hello hello voldemort hello voldemort'



# Generated at 2022-06-12 19:02:33.781192
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('return "&#39;"', dict()) == ('&#39;', True)
    assert js_interpreter.interpret_statement('var x = "&#39;"', dict()) == ('&#39;', False)
    assert js_interpreter.interpret_statement('return x', dict(x=123)) == (123, True)

# Generated at 2022-06-12 19:02:44.337988
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():

    # Define some functions

    # Function to test method build_function
    def func(args):
        local_vars = dict(zip(argnames, args))
        for stmt in code.split(';'):
            res, abort = js.interpret_statement(stmt, local_vars)
            if abort:
                break
        return res

    # Functions used for unit testing
    def id(x):
        return x
    def fac(x):
        return x * fac(x-1) if x > 1 else 1
    def add(x, y):
        return x + y

    # Now we start with unit testing

    funcname = 'func'
    code = 'x = 123; res = x;'
    argnames = ['res', 'x']
    js = JSInterpreter(code)
    assert func

# Generated at 2022-06-12 19:02:56.997921
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsInterpreter = JSInterpreter('')
    assert jsInterpreter.interpret_expression('1', {}) == 1
    assert jsInterpreter.interpret_expression('(1)', {}) == 1
    with pytest.raises(ExtractorError):
        jsInterpreter.interpret_expression('(1', {})
    assert jsInterpreter.interpret_expression('"foo"', {}) == 'foo'
    assert jsInterpreter.interpret_expression('("foo")', {}) == 'foo'
    assert jsInterpreter.interpret_expression("('foo')", {}) == 'foo'
    assert jsInterpreter.interpret_expression("['foo']", {}) == ['foo']
    assert jsInterpreter.interpret_expression("['foo', 'bar']", {}) == ['foo', 'bar']

# Generated at 2022-06-12 19:03:08.615462
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter("""var obj = {
                a: function(arg1, arg2) {
                    return arg1 * arg2;
                },
                b: function() {
                    return 1;
                }
            };""")
    assert callable(js.build_function(('arg1', 'arg2'), """return arg1 * arg2;"""))
    assert js.build_function(('arg1', 'arg2'), """return arg1 * arg2;""")(2, 3) == 6
    assert callable(js.build_function((), """return 1;"""))
    assert js.build_function((), """return 1;""")() == 1

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-12 19:03:18.333851
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = """

        function b(a) {
          return function(b) {
            for (var c = 0; c < b.length; c++) {
              var d = b.charCodeAt(c);
              a = (a << 5) - a + d;
              a = a & a
            }
            return a
          }
        }

        window.MSW8cf3c3f0d = {
          a: b('8XCMp0rL')
        };

    """

# Generated at 2022-06-12 19:03:25.372068
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_parser = JSInterpreter("function hello(arg1, arg2){ return arg1 + arg2;}")
    fct = js_parser.build_function(['arg1', 'arg2'], "return arg1 + arg2;")
    assert fct((1, 2)) == 3
    fct = js_parser.build_function(['arg1', 'arg2'], "var sum = arg1 + arg2; r = sum;")
    assert fct((1, 2)) == 3


# Generated at 2022-06-12 19:03:30.049138
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_obj = JSInterpreter('''a1 = 0; // test comment
    b1 = {
        "cc": function(p1){
            return p1;
        }
    }''', {})
    assert test_obj.extract_object('b1') == {'cc': lambda x: x[0]}

# Generated at 2022-06-12 19:03:37.009020
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:03:47.215756
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():

    js_str = '''
        var a = {};
        a.s = 1;
        a['s'] = 2;
        a.length = 4;

        var b = {
            c: function(d) {
                return d;
            },
            f: function(g, h) {
                return g + h;
            },
            i: function(j, k) {
                return j * k;
            }
        };

        var l = {
            m: function(n, o) {
                return n + o;
            },
            p: function() {
                return this;
            }
        };'''

    js_interpreter = JSInterpreter(js_str)
    a = js_interpreter.extract_object('a')
    b = js_interpreter.ext

# Generated at 2022-06-12 19:03:52.184712
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    CODE = """
        var youtube = {
            "fn": function() {
                return 1;
            },
            "obj": {"a": 1},
        };
    """
    jsi = JSInterpreter(CODE)
    assert jsi.extract_object("youtube") == {
        'fn': lambda args: 1,
        'obj': {'a': 1},
    }


# Generated at 2022-06-12 19:04:16.893323
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js1 = r'''
    a = 1;
    var b = function() {
        return a * 2;
    }
    var c = function() {
        return a * 3;
    }
    b();
    c();
    '''
    js2 = r'''
    d = 'abcdef';
    f = function() {
        return d.length;
    }
    h = function() {
        return d.substr(1, 3);
    }
    j = function() {
        return d.substring(1, 3);
    }
    f();
    h();
    j();
    '''
    js3 = r'''
    "abc" + "def"
    '''

# Generated at 2022-06-12 19:04:25.879750
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objects = {}
    code = '''
        A = {
            abc: function(a, b, c) { return [a, b, c]; },
            def: function(a, b, c) { return a + b + c; }
        };
    '''
    j = JSInterpreter(code, objects)
    j.extract_object('A')
    assert objects['A']['def'](1, 2, 3) == 6
    assert objects['A']['abc'](1, 2, 3) == [1, 2, 3]


# Generated at 2022-06-12 19:04:39.810166
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def jsfunc(argnames, code):
        return JSInterpreter('', {}).build_function(argnames, code)

    assert jsfunc(('x',), 'x ++ ; return x')([4]) == 5
    assert jsfunc(('x',), 'return x > 1 ? x + 3 : x + 5')([4]) == 7
    assert jsfunc(('y', 'x'), 'return x > y ? x + 3 : x + 5')([3, 4]) == 7
    assert jsfunc(('x',), 'return x == 0 ? 1 : x * x')([0]) == 1
    assert jsfunc(('x',), 'return x == 0 ? 1 : x * x')([5]) == 25


# Generated at 2022-06-12 19:04:45.987366
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
    var A = function(a){this.a = a}
    var a = new A("hello");
    """
    jsi = JSInterpreter(code)
    assert jsi.call_function("A", "hello").a == "hello"
    assert jsi.call_function("A", "world").a == "world"


# Generated at 2022-06-12 19:04:52.566376
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    var1 = 4
    def f(y):
        return y * var1
    assert f(5) == 20
    # Because var1 is declared in the outer scope, we need to pass it to JSInterpreter
    f = JSInterpreter(f.__code__.co_consts[0],{"var1":4}).build_function(["y"])
    assert f(5) == 20

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-12 19:04:58.125235
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter('')
    code = '''
        function f(a, b){
            res = a + b
            return res
        };
    '''
    f = interpreter.build_function(['a', 'b'], code)
    assert f((2, 3)) == 5
    assert f((0, 0)) == 0


# Generated at 2022-06-12 19:05:07.624145
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(arg){
            var a=arg,b=5,c=8,d=0,e=1,f=2,g=3,h=4;
            a=5;
            b=a;
            c=1;
            d=f;
            e=g;
            f=h;
            g=6;
            h=b;
            return a+b+c+d+e+f+g+h;
    }
    '''

    js_interpreter = JSInterpreter(code)
    res = js_interpreter.build_function(['arg'], code)
    assert res(['arg']) == 30



# Generated at 2022-06-12 19:05:10.275948
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter("var a = 5;var b = 10;")
    print("pass unit test")
    


# Generated at 2022-06-12 19:05:19.626119
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_cases = [
        {'code': """
    qwe = {
        x: function(zz, qqq) {
            return 4;
        },
        y: function() {
            return 3;
        },
        z: 2,
        t: 'test'
    };
""",
         'objname': 'qwe',
         'expected_result': {'x': lambda zz, qqq: 4, 'y': lambda: 3, 'z': 2, 't': 'test'}},
    ]
    for test_case in test_cases:
        code = test_case['code']
        objname = test_case['objname']
        expected_result = test_case['expected_result']
        result = JSInterpreter(code).extract_object(objname)
        assert result == expected_

# Generated at 2022-06-12 19:05:27.271915
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function funcName(arguments) {
            var v = 1234;
            var v2 = arguments[0]
            if (v2 == 0) {
                return 1;
            } else {
                var v3 = v2;
                v3--;
                return arguments[1](v3) * v2;
            }
        }
    '''

    js = JSInterpreter(code)
    assert js.build_function(['arguments'], code)([0]) == 1
    assert js.build_function(['arguments'], code)([1, js.build_function(['arguments'], code)]) == 1
    assert js.build_function(['arguments'], code)([2, js.build_function(['arguments'], code)]) == 2

# Generated at 2022-06-12 19:06:00.663277
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_JSInterpreter_build_function_js = """function f(a,b,c){var d=a,e=b,f=c;return(e^f)+((a&b)<<c)}"""
    def f(args):
        local_vars = dict(zip(['a', 'b', 'c'], args))
        for stmt in test_JSInterpreter_build_function_js.split(';'):
            res, abort = JSInterpreter('').interpret_statement(stmt, local_vars)
            if abort:
                break
        return res
    assert JSInterpreter('').build_function(['a', 'b', 'c'], test_JSInterpreter_build_function_js) == f

# Generated at 2022-06-12 19:06:05.965899
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('function a(b,c){d=b+c;e=b-c;return b;}')
    assert js_interpreter.build_function(['b','c'],'d=b+c;e=b-c;return b;') == js_interpreter.call_function('a')


# Generated at 2022-06-12 19:06:12.515043
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = r'''
        var rt = {
            "a": function(p) {
                return p.split("")
            },
            "b": function(p) {
                var n = [];
                for (var i = 0; i < p.length; i++) {
                    n.push(p[i])
                }
                return n
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object("rt")
    assert obj['a']("asd") == ['a', 's', 'd']
    assert obj['b']("asd") == ['a', 's', 'd']

if __name__ == "__main__":
    test_JSInterpreter_build_function()

# Generated at 2022-06-12 19:06:23.477610
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:06:33.761585
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test simple arithmetic
    assert JSInterpreter('', '').build_function([], '0')([]) == 0
    assert JSInterpreter('', '').build_function(['a'], 'a+b')([4, 5]) == 9

    # Test assignments
    assert JSInterpreter('', '').build_function(['a'], 'a=1+2')([0]) == 3

    # Test if-else
    assert JSInterpreter(
        '', '').build_function(['a'], 'if(a){a=a+1}else{a=a-1};a')([5]) == 6

# Generated at 2022-06-12 19:06:42.222091
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test case
    str_c = 'function test(a,b){var c,d;c=a+b;d=a*b;return d;}'
    test_JSInterpreter = JSInterpreter(str_c)
    argnames = ['a','b']
    code = 'var c,d;c=a+b;d=a*b;return d;'
    res = test_JSInterpreter.build_function(argnames, code)
    assert res([5,6])==30


# Generated at 2022-06-12 19:06:53.830046
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # function rotation(a) {
    #   a = a % 360;
    #   return a > 180 ? a - 360 : a < -180 ? a + 360 : a;
    # }
    interpreter = JSInterpreter('',{})
    f = interpreter.build_function(['a'],
                                   'a = a % 360; return a > 180 ? a - 360 : a < -180 ? a + 360 : a;')
    assert f([0]) == 0
    assert f([180]) == 180
    assert f([181]) == -179
    assert f([270]) == -90
    assert f([360]) == 0
    assert f([361]) == 1
    assert f([720]) == 0
    assert f([721]) == 1

# Generated at 2022-06-12 19:07:00.586932
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = JSInterpreter(r'''
        function hello(message) {
            window.alert(message);
        }

        window.world = function (param1, param2) {
            return param1 + param2;
        }

        function abc () {
            var a = 123;
            var b = 'def';
            var c = 456;

            return a + c;
        }
    ''')

    assert js.call_function('hello', 'world') is None
    assert js.call_function('world', 'hello ', 'world') == 'hello world'
    assert js.call_function('abc') == 579

# Generated at 2022-06-12 19:07:07.546604
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b, c) {
            a = [b, c];
            return a[0];
        }
    '''
    jsi = JSInterpreter(code)
    f = jsi.build_function(['a', 'b', 'c'], 'a=[[b,c]];return a[0]')
    assert f([4, 5, 6]) == 5


# Generated at 2022-06-12 19:07:13.366968
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('')
    code = '''
        if (jwplayer.utils.isIOS() || jwplayer.utils.isAndroid(2.3)) {
          _type = "mp4";
        } else {
          if (jwplayer.utils.isIE() && this.getConfig().type == "hls") {
            _type = "m3u8";
          } else {
            _type = this.getConfig().type;
          }
        }
        '''
    f = js.build_function(['jwplayer', 'this'], code)

# Generated at 2022-06-12 19:07:46.604288
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    json_string = '''{
            "id": "Youtube",
            "title": "YouTube",
            "description": "YouTube does not provide this info.",
            "version": "1.0",
            "thumbnail": "",
            "author": "Marcos E. Molina",
            "repo": "https://github.com/juanfra/superseriousstuff-webscripts/",
            "homepage": "https://github.com/juanfra/superseriousstuff-webscripts/",
            "domains": [
                "youtube.com",
                "youtu.be"
            ],
            "categories": [
                "video",
                "social"
            ],
            "create_instance": "function(config) { return new Youtube(config); }"
        }'''

    # Initial

# Generated at 2022-06-12 19:07:57.769441
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:08:06.700086
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test function:
    # function f(a, b, c) {
    #     var e = 0;
    #     for (var d = 0; d <= c; d++)
    #         e += a % b * d;
    #     return e;
    # }

    js_code = 'function f(a, b, c) {var e = 0;for (var d=0; d<=c; d++) e += a%b*d;return e;}'
    js_interpreter = JSInterpreter(js_code)
    js_function = js_interpreter.extract_function('f')
    assert js_function((1, 2, 4)) == 15



# Generated at 2022-06-12 19:08:14.785979
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    from .utils import int_or_none

    jsinterpreter = JSInterpreter('')

    def f(a, b):
        return a + b

    def f1(a):
        return a

    def f2(a):
        s = 0
        for x in a:
            s += x**2
        return s

    def f3(a, n):
        assert isinstance(a, list)
        return a[n:]

    def f4(a):
        return a[::-1]

    def f5(a, n):
        assert isinstance(a, list)
        return a[n::-1]

    def f6(a, n):
        assert isinstance(a, list)
        return a[:n]

    def f7(a, n):
        assert isinstance

# Generated at 2022-06-12 19:08:24.735341
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    import re
    import unittest
    from yt8m_extract import JSInterpreter

    jsi = JSInterpreter(code='', objects={})

    #########|> Test 1 - Operators: &, |, >>, <<, *, /, +, -, %, ^
    operators = [('&', operator.and_), ('|', operator.or_),
                 ('>>', operator.rshift), ('<<', operator.lshift),
                 ('*', operator.mul), ('/', operator.truediv),
                 ('+', operator.add), ('-', operator.sub),
                 ('%', operator.mod), ('^', operator.xor)]
    for i in range(5):
        for op, opfunc in operators:
            lhs, rhs = i, i + 1
            expression = str

# Generated at 2022-06-12 19:08:34.125062
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Example taken from http://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_substring
    js = """
    function myFunction(p1, p2) {
        return p1.substring(p2);
    }
    """
    interpreter = JSInterpreter(js)
    my_func = interpreter.build_function(('p1', 'p2'),
        """
        return p1.substring(p2)
        """
    )
    assert my_func('Hello world', 6) == 'world'



# Generated at 2022-06-12 19:08:46.803963
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:08:54.909339
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {'_': {}})
    assert js_interpreter.build_function(['abc'], 'abc=7;return "what";')((7,)) == 'what'
    assert js_interpreter.interpret_expression('_.sortedIndex(abc,4)', {'abc': [1, 2, 3]}) == 1
    assert js_interpreter.interpret_expression('_.unescape("%5C")', {}) == '\\'


if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-12 19:09:06.048038
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('')
    assert jsi.interpret_expression('[99, 88, 77][0]', {}) is 99
    assert jsi.interpret_expression('[99, 88, 77][3 - 1]', {}) is 88
    assert jsi.interpret_expression('[99, 88, 77].slice(1)', {}) is [88, 77]
    assert jsi.interpret_expression('[99, 88, 77].reverse()[2]', {}) is 99
    assert jsi.interpret_expression('-~(1 - 2)', {}) is 1
    assert jsi.interpret_expression('1', {}) is 1
    assert jsi.interpret_expression('+1', {}) is 1
    assert jsi.interpret_expression('1.5', {}) is 1.5

# Generated at 2022-06-12 19:09:14.625350
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
          "abc": function(b, c) {
            return b.a;
          },
          "def": function(b, c) {
            return c;
          },
          "ghi": function(b, c) {
            return b;
          },
          "jkl": function(b, c) {
            return 1;
          }
        }
        '''
    jsi = JSInterpreter(code)
    obj = jsi.extract_object('obj')
    assert obj['abc']( {'a': 'abc'}, 'abc' ) == 'abc'
    assert obj['def']( 'abc', 'abc' ) == 'abc'
    assert obj['ghi']( 'abc', 'abc' ) == 'abc'