

# Generated at 2022-06-12 19:00:04.818657
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # code for testing the unit test
    code = '''
	function foo(a,b,c,d){
		var e = a + b;
		var f = b - 1;
		var g = e(b);
		return e + f + g;
	}
	function bar(a,b,c,d){
		var e = a + b;
		var f = b - 1;
		var g = e(b);
		return e + f + g;
	}
	'''
    # preparing the arguments
    funcname = 'foo'
    args = (1,2,3,4)
    # instantiating the tested class
    jsi = JSInterpreter(code)
    # calling the tested method

# Generated at 2022-06-12 19:00:11.107090
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:00:23.117426
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = """
        var a = 3;
        var b = 'abc';
        var c;
        var d,e,f;
        var g,h,i=1,j=function(k,l){return k+l;};
        var m = function(n,o){return n+o;};
        function test(p,q,r){
            var s = 4;
            return p+q+r+s;
        }
        var t = {toString:function(){return 'hi';}};
        var u = test(a,b,c)+s;
        function v(w){
            var x = w*w;
            return x+y;
        }
    """
    interpreter = JSInterpreter(code)
    assert interpreter.interpret_statement("var a = 20; a", {}) == 20

# Generated at 2022-06-12 19:00:29.899804
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    print(js_interpreter.build_function(['a'], 'a')('hello'))

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-12 19:00:40.358751
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsi = JSInterpreter("")
    # Test interpret empty statement
    res, abort = jsi.interpret_statement("", {'a':2})
    assert res == None
    assert abort == False
    # Test interpret statement with only var
    res, abort = jsi.interpret_statement("var a = 2", {})
    assert res == 2
    assert abort == False
    # Test interpret statement with return statement
    res, abort = jsi.interpret_statement("return a", {'a':2})
    assert res == 2
    assert abort == True
    # Test interpret statement with return of a function
    res, abort = jsi.interpret_statement("return a(b)", {'a':lambda x:x, 'b':1})
    assert res == 1
    assert abort == True
    # Test interpret statement with return of a statement

# Generated at 2022-06-12 19:00:52.985532
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:01:05.921583
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:01:13.643447
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        var a='5',b='0',c='9',d='b';
        function A(a){var b,c,d;d=function(){return a};c=function(){return d()};b=function(b,c){a=b;d=c};return{b:b,c:c}}
    """
    v = JSInterpreter(code).extract_function('btoa')([])
    assert v == 'NDk='

# Generated at 2022-06-12 19:01:26.870016
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test #1: Compute a simple mathematical expression
    code = 'var a=1+1;'
    expr  = 'a'
    jsInterpreter = JSInterpreter(code)
    assert jsInterpreter.interpret_expression(expr, {}) == 2

    # Test #2: Compute a mathematical expression with parentheses
    code = 'var a=1+1;'
    expr = '(a)'
    jsInterpreter = JSInterpreter(code)
    assert jsInterpreter.interpret_expression(expr, {}) == 2

    # Test #3: Compute a mathematical expression with assignment
    code = 'var a=1+1;'
    expr = 'a += 1'
    jsInterpreter = JSInterpreter(code)
    assert jsInterpreter.interpret_expression(expr, {}) == 3

# Generated at 2022-06-12 19:01:34.842951
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''
    this.aaa = {
        'var1': 5,
        'var2': 0,
        'alert': function(x) {
            return x;
        },
        'str': 'str',
        'str_quote': 'str"',
        'str2': 'str2',
        'str2_quote': 'str2"',
        'func1': function(x) {
            if(x) {
                return x * 2;
            }
            return x;
        },
        'func2': function(x, y) {
            return y;
        },
        'func3': function(x, y) {
            return x;
        },
        'concat': function(x) {
            return this.str + x;
        },
    };
    '''
    objects

# Generated at 2022-06-12 19:02:07.089555
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:02:14.625609
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter(
        'var a = 1;',
        objects={'b': [1, 2, 3]})
    assert jsi.interpret_expression('a', locals(), 100) == 1
    assert jsi.interpret_expression('(a)', locals(), 100) == 1
    assert jsi.interpret_expression(
        '1 + 1', locals(), 100) == 1 + 1
    assert jsi.interpret_expression(
        '1 + (1 + 1)', locals(), 100) == 1 + (1 + 1)
    assert jsi.interpret_expression(
        '(1 + 1) + 1', locals(), 100) == (1 + 1) + 1
    assert jsi.interpret_expression(
        '[] + []', locals(), 100) == "[]" + "[]"

# Generated at 2022-06-12 19:02:16.695034
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    JSInterpreter = JSInterpreter
    argnames = ['a', 'b']
    code = "var x = a + b; x * x;"
    resf = JSInterpreter.build_function(JSInterpreter, argnames, code)
    assert resf((1, 2)) == 9

# Generated at 2022-06-12 19:02:25.937499
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:02:39.617925
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    import unittest

    _TEST_OBJECTS = {
        'object1': {
            'nestedObj2': {
                'key': 'value'
            },
            'nestedFunc1': lambda: 'nestedFunc1',
            'nestedFunc2': lambda a, b: a + b
        },
        'nestedObj1': {
            'key': 'value'
        },
        'nestedFunc1': lambda: 'nestedFunc1',
        'nestedFunc2': lambda a, b: a + b,
    }


# Generated at 2022-06-12 19:02:47.921742
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Function to extract the stream URL from a Youtube video URL
    jsi = JSInterpreter('function test(a){return a.length}')
    f = jsi.build_function(['a'], 'return a.length')
    assert f(['Hello']) == 5
    jsi = JSInterpreter('function test(a,b){return a+b}')
    f = jsi.build_function(['a', 'b'], 'return a+b;')
    assert f([1, 2]) == 3
    jsi = JSInterpreter('function test(a,b){return a+b}')
    f = jsi.build_function(['a', 'b'], 'return a+b')
    assert f([1, 2]) == 3

# Generated at 2022-06-12 19:02:56.303709
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter.build_function([], '5;')([]) == 5
    assert JSInterpreter.build_function(['a'], 'return a;')([42]) == 42
    assert JSInterpreter.build_function(['a', 'b'], 'return a + b;')([40, 2]) == 42
    assert JSInterpreter.build_function(['a', 'b'], 'return [a, b];')([40, 2]) == [40, 2]


# Generated at 2022-06-12 19:03:08.436992
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', None)
    func1 = '[a, b, c] = some_code_here; return d;'
    argnames1 = ['a', 'b', 'c']
    resf1 = js_interpreter.build_function(argnames1, func1)
    assert resf1([1, 2, 3]) == None
    assert resf1(['a', 'b', 'c']) == None
    assert resf1(['a', 1, 'c']) == None
    func2 = 'return a;'
    argnames2 = ['a']
    resf2 = js_interpreter.build_function(argnames2, func2)
    assert resf2([1]) == 1
    assert resf2(['a']) == 'a'

# Generated at 2022-06-12 19:03:13.729629
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter(r'decipher=function(a,b){return a*b}')
    assert(callable(jsi.build_function(['a', 'b'], r'return a*b')))
    assert(jsi.build_function(['a', 'b'], r'return a*b')([4, 6]) == 24)

# Generated at 2022-06-12 19:03:16.464675
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('')
    if jsi.interpret_expression('1', {}) != 1:
        raise Exception('JSInterpreter interpret_expression failed')



# Generated at 2022-06-12 19:03:51.395998
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def assert_interpret(expr, expected, locals):
        js_interpreter = JSInterpreter('')
        actual = js_interpreter.interpret_expression(expr, locals)
        assert actual == expected

    assert_interpret('x', "ABC", {'x':"ABC"})
    assert_interpret('function(x) {return x}("DEF")', "DEF", {})
    assert_interpret('join("")', '', {'join': lambda l: ''.join(l), 'x': "ABC"})
    assert_interpret('join(",")', '1,2,3', {'join': lambda l: ''.join(l), 'x': [1,2,3]})
    assert_interpret('x.split("A")', ['', 'BC'], {'x':"ABC"})
    assert_interpret

# Generated at 2022-06-12 19:03:54.354306
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = 'var obj = {"f": function() {var a = ["1", "2"]; return a.join("")}};'
    interpreter = JSInterpreter(js)
    assert interpreter.extract_object("obj")["f"] == "12"


# Generated at 2022-06-12 19:04:00.100696
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:04:11.533806
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_interpreter = JSInterpreter('''
        var a = 123;
        var b = 345;
        var t = {};
        t["foo"] = function(a, b) {
            return a + b;
        };
        t["bar"] = function(b) {
            return a + b;
        };''')

    assert js_interpreter.call_function('t["foo"]', 1, 2) == 3
    assert js_interpreter.call_function('t["bar"]', -1) == 122

    with pytest.raises(ExtractorError):
        js_interpreter.call_function('t["bar"]', 1, 2)

    with pytest.raises(ExtractorError):
        js_interpreter.call_function('t["baz"]', -1)

# Generated at 2022-06-12 19:04:24.361898
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterpreter = JSInterpreter(None)
    local_vars = {
        'x': 1,
        'y': 2,
        's': 'a',
        'lst': [1, 2, 3],
        'funA': lambda x,y: x+y,
        'funB': lambda x: x*2,
        'funC': lambda: 0,
    }

    def test(expression, result):
        computed = jsinterpreter.interpret_expression(expression, local_vars)
        assert result == computed
        print('Passes', expression, 'with result', computed)

    test('1+2', 3)
    test('x+y', 3)
    test('x-y', -1)
    test('x<<2', 4)
    test('x^y', 3)


# Generated at 2022-06-12 19:04:37.500446
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = 'function my_function(a, b){var c = a.foo(b); return a.fuu(c); }'
    jsi = JSInterpreter(js_code)
    res1 = jsi.build_function(['a','b'], 'var c = a.foo(b); return a.fuu(c);')
    def res2(args):
        kwargs = dict(zip(['a','b'],args))
        c = kwargs['a'].foo(kwargs['b'])
        return kwargs['a'].fuu(c)
    assert res1.__name__ == 'resf'
    assert res1((1,2)) == res2((1,2))
    assert res1((2,3)) == res2((2,3))

# Unit

# Generated at 2022-06-12 19:04:47.121123
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # test object
    js_interpreter = JSInterpreter('a = { b: function (c, d) { e = c + d; }, "f": function (g) { h = g; } }')
    assert js_interpreter.extract_object('a') == { 'b':
                lambda c, d: c + d, 'f': lambda g: g }
    # test function
    js_interpreter = JSInterpreter('function test(a, b) { return a+b; }')
    assert js_interpreter.extract_function('test')((3, 4)) == 7
    js_interpreter = JSInterpreter('function test2(a, b) { return a-b; }')

# Generated at 2022-06-12 19:04:56.343674
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    null = None

# Generated at 2022-06-12 19:05:06.422512
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # when used of JSInterpreter.build_function,
    # the 'resf' function will refer to variables in the surrounding context
    # 'global_var' and 'global_func'

    global_var = 'global_var'
    global_func = lambda: 'global_func'

    js_interpreter = JSInterpreter('', {})
    resf = js_interpreter.build_function(['arg1'], '''
        var v1 = 'v1';
        var v2 = arg1;
        return v1 + ' ' + v2 + ' ' + global_var + ' ' + global_func();
    ''')

    assert resf(['arg1']) == 'v1 arg1 global_var global_func'

# Generated at 2022-06-12 19:05:16.695381
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:05:45.638213
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
    var a = {
        b: function (c, d) {
            var e = f;
            return g;
        },
        "h": function (i, j) {
            var k = l;
            return m;
        }
    };
    """
    assert JSInterpreter(code).extract_object("a") == {
        'b': lambda args: 'g',
        'h': lambda args: 'm'
    }


# Generated at 2022-06-12 19:05:57.228007
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    from .utils import js_to_json
    js_code = '''
        function test(a, b) {
            if (a == 'a') {
                return 5;
            } else if (a == 'b') {
                return b;
            } else {
                return null;
            }
        }
    '''
    js_code_json = js_to_json(js_code)
    objs = json.loads(js_code_json)
    js_interpreter = JSInterpreter(js_code, objs)
    assert js_interpreter.interpret_expression('test("a", null)') == 5
    assert js_interpreter.interpret_expression('test("b", 6)') == 6
    assert js_interpreter.interpret_expression('test("c", null)') is None

# Generated at 2022-06-12 19:06:08.090119
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:06:20.045930
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = (
        'function abc(a,b,c,d){'
        'if(a==1&&b==1){'
        'a=b;'
        'c=3;'
        '}else{'
        'a=c;'
        '}'
        'if(a==c){'
        'a=a+b+c;'
        'c=3;'
        '}'
        'return a;'
        '}')
    assert JSInterpreter(js).build_function(['a','b','c','d'],'if(a==1&&b==1){a=b;c=3;}else{a=c;}if(a==c){a=a+b+c;c=3;}return a;')([1,1,3,4]) == 3

# Generated at 2022-06-12 19:06:27.049455
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
        function decode_signature_func(s, sig_enc) {
            var t = 1,
                a = [],
                c = sig_enc.split(""),
                i;
            for (i = 0; i < c.length; i++) {
                var k = t + c[i].charCodeAt(0),
                    b = k ^ 56,
                    j = String.fromCharCode(b);
                t = k;
                a.push(j);
            }
            return a.join("");
        }
        """
    js = JSInterpreter(code)
    res = js.interpret_expression("decode_signature_func('foobar', '3az')", {})
    assert res == '734'


# Generated at 2022-06-12 19:06:39.280758
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = r'''var D=function(f){while(f.length>0){var e=f.shift();console.log(e);if(typeof e==='string'){var d=document.createElement('div');d.innerHTML=e;document.body.appendChild(d)}else{if(e.length==2){document.body.appendChild(e[0].cloneNode(true),e[1])}else{document.body.appendChild(e[0].cloneNode(true))}}}},F={"0":"local_storage_support_test","1":"pl_exists_test"};D([F[0],F[1]]);'''
    jsint = JSInterpreter(js_code)

# Generated at 2022-06-12 19:06:44.996275
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
           var obj = {
               x: function() {return 1},
               y: function() {return 2}
           };
           '''
    inter = JSInterpreter(code)
    obj = inter.extract_object('obj')
    assert obj['x']() == 1
    assert obj['y']() == 2


# Generated at 2022-06-12 19:06:49.944455
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:06:56.897057
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        var abc = {
            "def": true,
            "ghi": function(p1, p2) {
                return 3;
            }
        };
        var jkl = function(p1, p2) {
            return p1;
        };'''
    jsi = JSInterpreter(code)
    assert jsi.call_function('jkl', 1, 2) == 1
    assert jsi.call_function('abc.ghi', 1, 2) == 3

# Generated at 2022-06-12 19:07:08.428312
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test case 1: example 1
    js_code = """\
    function test(){
        var d="abc",e=d.length,f=d.charCodeAt(0),g=d.charCodeAt(1),h=d.charCodeAt(2),m=e,t=0;t|=(f-("a".charCodeAt(0))+(g-("b".charCodeAt(0))+(h-("c".charCodeAt(0))))<<24>>>0)<<("a".charCodeAt(0));
    }
    """
    interpret = JSInterpreter(js_code).interpret_expression

    # Test case 2: example 2

# Generated at 2022-06-12 19:07:40.725441
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_input = """
    var b = { a: function(p){return p}, c: 1};
    var a = b.a;
    """
    test_result = {"a": lambda p: p, "c": 1}
    i = JSInterpreter(test_input)
    assert i._objects == {}
    assert i.extract_object("b") == test_result
    assert i._objects == {"b": test_result}



# Generated at 2022-06-12 19:07:46.636481
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
        function someFunc(arg1, arg2) {
            var x = 1;
            var y = x + 2;
            var z = arg1 + arg2;
        }
    """
    js_interpreter = JSInterpreter(code)
    assert(js_interpreter.interpret_expression('x', {}) == 1)
    assert(js_interpreter.interpret_expression('y', {}) == 3)
    assert(js_interpreter.interpret_expression('z', {}) == 3)

# Generated at 2022-06-12 19:07:57.855607
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-12 19:08:07.872373
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Test 1: simple function
    func_code = b'''
        function a(b) {
            return b+2;
        }
        var a = function(b) {
            return b+2;
        }
        var a = function(b) {
            return b+2;
        }
        var al = function(b,d) {
            return b+d+2;
        }
        var aal = function(b,d) {
            return a(b,d) + 2;
        }
    '''

    interpreter = JSInterpreter(func_code)
    f = interpreter.extract_function(b'a')
    assert f((1,)) == 3
    assert f((2,)) == 4
    f = interpreter.extract_function(b'al')

# Generated at 2022-06-12 19:08:19.559396
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code1 = '''
            var a = {
                b: function(p) {
                    return p;
                },
                c: function(p) {
                    return p+1;
                }
            };
            '''
    code2 = '''
            var a = {
                b: function(p) {
                    return p;
                },
                c: function(p, q) {
                    return p+q;
                }
            };
            '''
    code3 = '''
            var a = {
                b: function(p) {
                    return p;
                },
                c: function(p, q) {
                    if (p > 10) {
                        return p-q;
                    }
                    return p+q;
                }
            };
            '''

# Generated at 2022-06-12 19:08:30.432491
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj1 = {
            aaa: function () {},
            bbb: function () {},
            ccc: function () {},
        }
    '''
    obj1 = JSInterpreter(code).extract_object('obj1')
    assert obj1 == {'aaa': None, 'bbb': None, 'ccc': None}

    code = '''
        var obj1 = {
            aa: function () {},
            bb: function () {},
            cc: function () {},
            "dd": function () {}
        }
    '''
    obj1 = JSInterpreter(code).extract_object('obj1')
    assert obj1 == {'aa': None, 'bb': None, 'cc': None, 'dd': None}


# Generated at 2022-06-12 19:08:36.680481
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    def test_function():
        js = """
        function a(a){
          if(!a)return 1;
          return a*this.a(a-1)
        }
        """
        jsi = JSInterpreter(js)
        return jsi.call_function('a', 3)

    assert test_function() == 6

# Generated at 2022-06-12 19:08:43.304935
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Example from https://github.com/rg3/youtube-dl/pull/6903
    # Testing code
    code = '''
        #comment
        function test(arg1, arg2, arg3, arg4) {
            var x = arg2;
            var r = x.split('').reverse().join('');
            var y = r.slice(1);
            var z = y.slice(2);
            var a = "ab";
            var b = a + c;
            return z;
        }
    '''
    interpreter = JSInterpreter(code)
    func = interpreter.build_function(['arg1', 'arg2', 'arg3', 'arg4'], code)
    assert func(['A', 'B', 'C', 'D']) == 'b'

    # Example from https://

# Generated at 2022-06-12 19:08:54.323813
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:09:05.938538
# Unit test for method interpret_statement of class JSInterpreter