

# Generated at 2022-06-12 19:00:15.045624
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_str = '''
        var c = function(a){
            return a*a;
        };
        var b = function(a,b){
            return a/b;
        };
        var a = c(b(9,3));'''
    assert JSInterpreter(test_str).interpret_expression('a', {}) == 3



# Generated at 2022-06-12 19:00:25.094767
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        var d = function (a, b, c) {
            var e = a + b + c;
            var f = b * c;
            var g = f % a;
            var h = [1, 2, 3];
            var i = h.join('');
            var j = f.toString(16);
            return j;
        }
    '''
    jsi = JSInterpreter(code)
    d = jsi.build_function(['a', 'b', 'c'], 'var e=a+b+c;var f=b*c;var g=f%a;var h=[1,2,3];var i=h.join(\'\');var j=f.toString(16);return j;')

# Generated at 2022-06-12 19:00:28.090952
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interp = JSInterpreter("""
        function a(b, c) {
            return b - c
        }
        function x(b) {
            return b * b
        }
    """)
    assert js_interp.call_function("a", 13, 10) == 3
    assert js_interp.call_function("x", 13) == 169

# Generated at 2022-06-12 19:00:39.058861
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        var s12345 = 'D20be407bcb6fb4.52731856';
        var o0 = value.split("");
        var r6789 = o0["reverse"]();
        var b = o0["splice"](s12345["length"], r6789[0]);
        var rt = b[0] + b[3] + b[2] + b[1];
        return rt;
    '''
    expected = '07de.b8c43b64fb60'
    actual = JSInterpreter(js_code).call_function('s0', '2.D407bcb6fb4e0b')
    assert actual == expected


if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-12 19:00:52.007024
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-12 19:01:04.426702
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
        var b = function(oq) {
            oq.le(0, 0);
            oq.le(1, 2);
            oq.le(2, 3, 4);
        };
        var q = "afaf";
        var a = [1, 2, 3, 4];
        var c = q.split(',');
        var m = a.length;
        var n = c.length;
        var l = b.length;
        var x = 5;
        var y = 6;
        var u = x + y;
        var v = x - y;
        var w = x * y;
        var p = x << y;
        var d = {
            m: 10,
            n: 11,
            a: a
        };
    """

# Generated at 2022-06-12 19:01:18.208580
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # test 1
    expr = 'parseInt("10")'
    code = 'function x(a){a=a.split("");a=a.reverse();a=a.join("");a=parseInt(a,10);return a+1}'
    js = JSInterpreter(code)
    assert js.interpret_expression(expr, {}) == 10

    # test 2
    expr = 'x'
    code = 'function x(a, b, c){return a+b-c;}'
    js = JSInterpreter(code)
    assert js.interpret_expression(expr, {'x': [1, 2, 3]}) == [1, 2, 3]
    assert js.interpret_expression(expr, {'x': 1}) == 1

    # test 3

# Generated at 2022-06-12 19:01:21.936159
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():

    code = """
        a = 1;
        a;
    """

    interpreter = JSInterpreter(code)
    result = interpreter.interpret_statement("a = 1;", {})
    assert result[0] == 1


# Generated at 2022-06-12 19:01:34.297786
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function add(a,b) {
            var c = 20;
            d = a+b;
            return d;
        }
    '''

    jsi = JSInterpreter(code)
    f = jsi.build_function(['a', 'b'], 'var c = 10; d = a+b; return d;')
    assert f((3, 4)) == 7
    assert f((3, 10)) == 13

    code = '''
        function add2(a) {
            var c = 20;
            c = a+c;
            return c;
        }
    '''
    jsi = JSInterpreter(code)
    f = jsi.build_function(['a'], 'c = a+c; return c;')

# Generated at 2022-06-12 19:01:41.925028
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('var a = 0; var b = 1; var c = 2;')
    jsi.interpret_expression('a', {'a': 0, 'b': 1, 'c': 2})
    jsi.interpret_expression('(a)', {'a': 0, 'b': 1, 'c': 2})
    jsi.interpret_expression('a = a + 1', {'a': 0, 'b': 1, 'c': 2})
    jsi.interpret_expression('a = a + 1; a = a + 1', {'a': 0, 'b': 1, 'c': 2})
    jsi.interpret_expression('a >> 0', {'a': 0, 'b': 1, 'c': 2})

# Generated at 2022-06-12 19:02:25.551336
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = """
        var a = [1, 2, 3, 4];
        var b = 2;
        var c = 3;
        a[0] + b;
        b - a[1];
        c * a[2];
        b / 5;
        a[1] - (a[2] + 1);
        a[0] + b - c * a[2] / 5 + a[1] - (a[2] + 1);
        a[a[3] - 4]
    """
    exp = [3, -1, 6, 0.4, 0, -6, -4, 1]
    i = JSInterpreter(code)
    for ind, stmt in enumerate(code.split(';')):
        res, abort = i.interpret_statement(stmt, {})
        assert res

# Generated at 2022-06-12 19:02:37.158522
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    func_code = """
    function decode(test){
      var res = test.reverse();
      var ret = res.slice(7, res.length - 4).reverse();
      return ret.join('');
    }
    """

    _jsi = JSInterpreter(func_code, dict())
    _f = _jsi.build_function(['test'], re.search(r'{(.*)}', func_code).group(1))
    _ret = _f([list("ABCDEFG")])

    assert _ret == "BCDE"

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-12 19:02:45.869779
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
    function func1(a,b){
        return foo.length + a*b;
    }
    """

    js_code2 = """
    function func1(a,b){
        var c = a + b;
        return c;
    }
    """

    foo = [1, 2, 3, 4]
    interp = JSInterpreter(js_code, {'foo': foo})
    res = interp.call_function('func1', 3, 4)
    assert res == 11
    interp = JSInterpreter(js_code2)
    res = interp.call_function('func1', 2, 3)
    assert res == 5


# Generated at 2022-06-12 19:02:53.187788
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = r'''
        xxx = {
            "a": function(p, a, c, k, e, d) {
                return c;
            }
        };
        '''
    f = JSInterpreter(js).extract_function('xxx.a')
    assert f(["1", "2", "3", "4", "5", "6"]) == '3'

# Generated at 2022-06-12 19:03:02.101472
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = '''
        var A = {
            B: function(a, b) {
                return a + b;
            },
            C: function(a, b) {
                return a - b;
            }
        };'''

    js_interpreter = JSInterpreter(js)
    A = js_interpreter.extract_object('A')
    assert A['B'](5, 4) == 9
    assert A['C'](5, 4) == 1



# Generated at 2022-06-12 19:03:11.956994
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789$_(){
            return 1+2;
        }
    '''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789$_')
    assert f() == 3

    code = '''
    abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789$_ = function(){
        return 1+2;
    }
    '''
    js

# Generated at 2022-06-12 19:03:19.710431
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function call4js(arg1, arg2) {
            return arg1 + arg2;
        }
    '''
    ji = JSInterpreter(code)
    ret = ji.call_function('call4js', 1, 2)
    assert ret == 3

    code = '''
        function call4js(arg1, arg2) {
            return arg1 - arg2;
        }
    '''
    ji = JSInterpreter(code)
    ret = ji.call_function('call4js', 1, 2)
    assert ret == -1


if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-12 19:03:30.260849
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    JSInterpreter_test0 = JSInterpreter('testmodule_test2=function(a,b){a=a+1;b=b+1;a=a+b;return a}')
    # Unit test for function testmodule_test2 in file testmodule.js
    assert 6 == JSInterpreter_test0.call_function('testmodule_test2',2,2)
    # Unit test for function testmodule_test2 in file testmodule.js
    assert 1 == JSInterpreter_test0.call_function('testmodule_test2',-1,2)
    # Unit test for function testmodule_test2 in file testmodule.js
    assert 6 == JSInterpreter_test0.call_function('testmodule_test2',3,3)
    # Unit test for function testmodule_test2 in file test

# Generated at 2022-06-12 19:03:34.777618
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = "function abc(a){ return(a); }"
    interp = JSInterpreter(code)
    assert interp.call_function("abc", [1,2,3]) == [1,2,3]
    return True

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-12 19:03:45.620969
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('''
        window.yt.timing = {};
        window.yt.timing.tick = function(n, b) {
            if (window.yt.timing.pt)
                return;
            window.yt.timing.pt = n;
            window.yt.timing.ts = b;
        };
    ''')
    func_name = 'window.yt.timing.tick'
    var_names = ['n', 'b']
    code = '''
        if (window.yt.timing.pt);
            return;
        window.yt.timing.pt = n;
        window.yt.timing.ts = b;
    '''
    func = js.build_function(var_names, code)
    assert func(['n', 'b'])

# Generated at 2022-06-12 19:04:14.012904
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){ return p; },
            c: function(p){ return p; }
        };
    '''
    res = JSInterpreter(code).extract_object('a')
    assert res['b']('test') == 'test'
    assert res['c']('test') == 'test'


# Generated at 2022-06-12 19:04:25.504451
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    testcode = '''
        Object.create = function() {};
        var a = {
            b: function(p) {
                return function(p) {};
            },
            'c': function() {},
            d: 3
        };
        '''
    jsinter = JSInterpreter(testcode)
    obj = jsinter.extract_object('a')
    assert isinstance(obj, dict)
    assert set(obj.keys()) == set(['b', 'c', 'd'])
    assert callable(obj['b'])
    assert obj['b']('p1')('p2') is None
    assert callable(obj['c'])
    assert obj['c']() is None
    assert obj['d'] == 3

# Generated at 2022-06-12 19:04:39.295450
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test with no argument
    code = '''
        (function() {
            var $ = function(a) {
                return new $.fn.init(a);
            };
            $.fn = $.prototype = {
                init: function(a) {
                    this.e = a;
                    return this;
                },
                find: function(a) {
                    this.e = a;
                    return this;
                },
                attr: function(a) {
                    this.e = a;
                    return this;
                },
                text: function() {
                    return "abc";
                }
            }
            window.jQuery = $;
        })();
        '''
    jsi = JSInterpreter(code)
    f = jsi.build_function((), code)
    f(())


# Generated at 2022-06-12 19:04:44.998804
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''var x=12, y='hoho';
        function kk(a,b) {return a+b;}
        '''
    i = JSInterpreter(code)
    f = i.build_function(['a', 'b'], '''var c=a+b;return c+10;var d=kk(c,x);return d+y;''')
    assert f((1, 2)) == 35
    assert f((10, 20)) == 62


# Generated at 2022-06-12 19:04:54.317451
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_content = r'''
function kkk() {
    a = {
        f1: function(a, b) {
            return a * b * b;
        },
        a: 1,
        b: function(){return 1;}
    };
}
var a = 1;
    '''
    js_interpreter = JSInterpreter(js_content)
    extracted_object = js_interpreter.extract_object('a')
    assert len(extracted_object) == 3
    assert extracted_object[r'a'] == 1
    assert extracted_object[r'b']() == 1
    assert extracted_object[r'f1'](2, 3) == 18


# Generated at 2022-06-12 19:04:59.402249
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = "{m: function(a) { function b(c) { return function() {return c}} return b(a)}, s: function() {}}"
    interpreter = JSInterpreter(code)

# Generated at 2022-06-12 19:05:06.664151
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinter = JSInterpreter('var a = 1; var b = "c"')
    a = jsinter.interpret_expression('a', {})
    b = jsinter.interpret_expression('b', {})
    c = jsinter.interpret_expression('a + 2', {})
    d = jsinter.interpret_expression('d', {})
    assert a == 1
    assert b == 'c'
    assert c == 3
    assert d == None

if __name__ == "__main__":
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-12 19:05:16.953802
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter('''
        function test(a) {
            return a;
        }
        var a = 5;
        var b = 10, c = 20;
        var d = function() {
            var e = 30;
            var f = function() {
                return e+c;
            }
            return f();
        }
        var g = d();''')
    def _test(js, stmt, expected_val, expected_abort=False):
        val, abort = js.interpret_statement(stmt, {})
        assert val == expected_val
        assert abort == expected_abort

    _test(js, 'return 20', 20, True)
    _test(js, 'return {a: 10}', {'a': 10}, True)

# Generated at 2022-06-12 19:05:19.223425
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsi = JSInterpreter('''
        a = {
            x: function(a){return a + 1;}
        }
        ''')
    
    assert jsi.extract_object('a') == {'x': lambda a: a + 1}


# Generated at 2022-06-12 19:05:27.240850
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:06:51.349075
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
        function p(a,b){
            return a+b;
        }
        var c=2;
        var d=3;
        var e=4;
        var f=5;
        var g=6;
        var h=7;
        var i=8;
        var j=9;
        var k=10;
        var l=[11,12];
        var m={n:"13",o:"14"};
        var s="abc";
        var t="def";
        var u="ghi"
    """
    interpreter = JSInterpreter(code)

# Generated at 2022-06-12 19:07:00.225834
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    def _recursive_test(stmt, expected, local_vars):
        jsi = JSInterpreter("", local_vars)
        res, abort = jsi.interpret_statement(stmt, local_vars)
        assert abort == (expected is None)
        if not abort:
            assert res == expected
    # case 1: simple arithmetic
    _recursive_test('return 5+a', 8, {'a':3})
    _recursive_test('return a/4', 0.75, {'a':3})
    _recursive_test('return a//4', 0, {'a':3})
    _recursive_test('return a-b', -1, {'a':1, 'b':2})
    # case 2: array access

# Generated at 2022-06-12 19:07:06.931860
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    func_code = 'var test = function (a, b) {return (a + b);}'
    js_int = JSInterpreter(func_code)
    js_func = js_int.build_function(['a', 'b'], 'return (a + b);')
    assert js_func((1, 4)) == 5


if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-12 19:07:12.677245
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('').interpret_expression('1') == 1
    assert JSInterpreter('').interpret_expression('1 + 1') == 2
    assert JSInterpreter('').interpret_expression('(1)') == 1
    assert JSInterpreter('').interpret_expression('(1 + 1)') == 2
    assert JSInterpreter('').interpret_expression('0.1') == 0.1
    assert JSInterpreter('').interpret_expression('0.1 + 0.2') == 0.3
    assert JSInterpreter('').interpret_expression('"a"') == 'a'
    assert JSInterpreter('').interpret_expression('"a" + "b"') == 'ab'
    assert JSInterpreter('').interpret_expression('("a")') == 'a'
   

# Generated at 2022-06-12 19:07:24.591850
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Expected results
    expected_dict = {'a': 1, 'b': 1, 'c': 2}
    expected_list = [1,2,3,4,5]
    expected_int = 4
    expected_str = 'test'
    expected_bool = False

    # Test with a dict
    code_dict = ('var a; var b = 1;'
                 'if (a == undefined) a = 1;'
                 'if (a == b) c = a + b;')
    interpreter_dict = JSInterpreter(code_dict)
    interpreter_dict.interpret_statement(code_dict, {})
    assert interpreter_dict._objects['a'] == expected_dict['a']
    assert interpreter_dict._objects['b'] == expected_dict['b']

# Generated at 2022-06-12 19:07:33.798059
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-12 19:07:45.745893
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''\
            var b = true;
            var c = false;
            var d = 9;
            var e = d;
            var f = "abc";
            var g = [f];
            var h = 5;
            var i = 10;
            var j = [h,i];
            var k = d | 3;
            var l = (k ^ 2);
            var m = (d + "abcd");
            var n = (d == 9);
            '''
    interpreter_test = JSInterpreter(code)
    case_stmt = ("var b = true",{})
    case_stmt_2 = ("var a = {'a': b};",{})

# Generated at 2022-06-12 19:07:52.446261
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        function function_name() {
            var obj = {
                "a": function() {},
                "b": function() {},
                "c": function() {},
            };
            return obj;
        }
        '''
    jsi = JSInterpreter(js_code)
    obj = jsi.extract_object('obj')
    assert obj['a'] != None
    assert obj['b'] != None
    assert obj['c'] != None

# Generated at 2022-06-12 19:08:03.420939
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    obj1 = {
        'a': 'test',
        'b': {
            'c': 'test2'
        },
        'd': [1, 2, 3]
    }
    obj2 = {
        'a': 'test'
    }
    obj3 = {
        'a': 'test',
        'e': {
            'b': 'test2'
        }
    }
    obj4 = {
        'a': 'test',
        'c': [1, 2, 3]
    }
    obj5 = {
        'a': 'test'
    }
    obj6 = {
        'a': 'test',
        'b': [1, 2, 3]
    }
    obj7 = {
        'a': 'test'
    }

# Generated at 2022-06-12 19:08:09.530966
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    var qq_fmt = {
        "218": "%(aqq_url)s",
        "219": "%(aqq_vid)s"
    }
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object("qq_fmt")
    assert isinstance(obj, dict)
    assert obj["218"] == '%(aqq_url)s'
    assert obj["219"] == '%(aqq_vid)s'

# Generated at 2022-06-12 19:08:40.499009
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter("")
    # Test, if the method interpret_expression returns the right value of a function call
    # Test for function call of function 'f'
    assert(js_interpreter.interpret_expression("f(1)", {}) == 1)
    # Test for function call of function 'g'
    assert(js_interpreter.interpret_expression("g(a, b)", {'a': 2, 'b': 3}) == 2)
    # Test for function call of function 'g'
    assert(js_interpreter.interpret_expression("g(1, 2)", {}) == 1)


# Generated at 2022-06-12 19:08:51.967097
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js1 = JSInterpreter(
        'function func(a,b,c){with(c){return b/a;}}')
    assert js1.build_function(
        ('a','b','c'),'with(c){return b/a;}')(['b','c','a']) == 'c/b'
    js2 = JSInterpreter(
        'function func(a,b){c=Math.ceil(a/b);return c+1;}')
    assert js2.build_function(
        ('a','b'),'c=Math.ceil(a/b);return c+1;')(['2','2']) == 3

test_JSInterpreter_build_function()

# Generated at 2022-06-12 19:08:52.947429
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    pass


# Generated at 2022-06-12 19:09:00.385323
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_js = '''
    var testobj = {
        some_name : 'foo',
        some_method: function(para, para2) {
            return para + this.some_name + para2;
        }
    };

    function some_function(arg) {
        return arg;
    }

    var some_other_function = function(arg1, arg2) {
        return arg1 * arg2;
    }
    '''
    jsi = JSInterpreter(test_js)
    assert jsi.interpret_expression('testobj.some_name', {}) == 'foo'

    with pytest.raises(ExtractorError):
        jsi.interpret_expression(
            'some_method(some_other_function(123))', {})


# Generated at 2022-06-12 19:09:10.682055
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Function with 'return'
    # Input js code:
    #   return f(a,b);
    js_code_1 = 'return f(a,b);'
    # Expected output result:
    #   [function resf]
    expected_result_1 = '[function resf]'
    # Actual output result:
    actual_result_1 = JSInterpreter.build_function(
        None, 'f', js_code_1)
    # Print the result for unit test
    print("test_JSInterpreter_build_function - 1: ",
          actual_result_1)
    # Check the result
    assert str(actual_result_1) == expected_result_1
    # Function with 'return'
    # Input js code:
    #   var a = 1;
    #   var b = 1

# Generated at 2022-06-12 19:09:17.731718
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:09:28.403252
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter(
        r'''
        a = 2;
        b = 3;
        bleh = 5;
        function foo(x, y) {
            return (x + y) * bleh;
        }
        function bar(n) {
            return foo(n, a);
        }
        var get_a = function(x) {
            return x + a;
        }
        ''')
    assert js_interpreter.call_function('foo', 1, 2) == 15
    assert js_interpreter.call_function('bar', 1) == 8
    assert js_interpreter.call_function('get_a', 10) == 12
