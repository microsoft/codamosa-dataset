

# Generated at 2022-06-12 19:00:16.701898
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = '''
        var a = "abcdef";
        function f(arg1) {
            var arg2 = "uvwxy";
            var r = a.charAt(arg1) + arg2[1];
            var arr = [1, 2.0, 3, 0.5];
            return arg2[0] + arg2[2] + arg2[4] + r + arr[2];
        }
    '''
    js_intp = JSInterpreter(js_code)
    assert js_intp.extract_function('f')([1]) == 'uvwxbc'
    assert js_intp.extract_function('f')([0]) == 'auvwxdef'


# Generated at 2022-06-12 19:00:23.250783
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(x) {
            var y = x + x;
            var z = 'abc' + x + 'def' + y;
            var w = 'abc';
            return w + z;
        }
    '''
    interp = JSInterpreter(code)
    func = interp.build_function(['x'], code)
    assert func(('xyz',)) == 'abcxyzxyzdefxyzxyz'



# Generated at 2022-06-12 19:00:31.993475
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("function test(arg1, arg2){var a = 1; var b = arg2 * 3; return arg1 * b;}")
    js_function = js_interpreter.build_function(["arg1", "arg2"],  "var a = 1; var b = arg2 * 3; return arg1 * b;")
    assert js_function([1, 2]) == 6


# Generated at 2022-06-12 19:00:43.224074
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:00:55.843548
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = """
    var $ = function(a) {return a};
    var a = function() {
        var b = function(c) {
            return c + 1;
        };
        return b;
    };
    """
    interpreter = JSInterpreter(js_code)
    assert interpreter.interpret_expression("1 + 2", {}) == 3
    assert interpreter.interpret_expression("b(2)", {"b": a}) == 3
    assert interpreter.interpret_expression("b.length", {"b": [1, 2, 3]}) == 3
    assert interpreter.interpret_expression("b.slice(1)", {"b": [1, 2, 3]}) == [2, 3]
    assert interpreter.interpret_expression("b.splice(1, 1)", {"b": [1, 2, 3]}) == [2]

# Generated at 2022-06-12 19:01:06.962675
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    def func(x, y, z):
        return z(y(x))

    def callf(f, x, y, z):
        return f(x)(y)(z)

    # JSInterpreter instance
    js = JSInterpreter('function f(x, y, z){return z(y(x))};')
    # Extract function with name 'f'
    f = js.extract_function('f')
    # assert f is a function
    assert callable(f)
    # assert the function extracted by JSInterpreter is the same
    # as the function has name 'func' above
    assert func(1, 2, 3) == callf(f, 1, 2, 3)


# Generated at 2022-06-12 19:01:20.359658
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Create object that can handle function add, sub and xor
    interpreter = JSInterpreter(code='function add(a, b){return a+b;};function sub(a, b){return a-b;};function xor(a,b){return (a||b)&&!(a&&b);}')

    # Test function add, function sub and function xor
    assert interpreter.call_function('add', 1, 1) == 2
    assert interpreter.call_function('sub', 5, 2) == 3
    assert interpreter.call_function('xor', 1, 0) == 1

    # Test function that uses more built in functions
    interpreter = JSInterpreter(code='function reverse(a){a.reverse();};function shift(a){a.shift();};function join(a, b){return a.join(b);};')

   

# Generated at 2022-06-12 19:01:32.804314
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsi = JSInterpreter('''
        this.extract_object = {
            "key1": 'value1',
            "key2": "value2",
            "key3": function(arg1, arg2){
                return {
                    "key11": arg1,
                    "key12": arg2,
                    "key13": this.key2
                }
            },
            "key4": function(arg1, arg2){
                return this.key1 + " of " + arg2
            }
        };
    ''')
    obj = jsi.extract_object('extract_object')
    assert obj['key1'] == 'value1'
    assert obj['key2'] == 'value2'

# Generated at 2022-06-12 19:01:37.966898
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        c = {
            "a": 20,
            "b": function (b) {
                var c = b;
                return c;
            }
        }
    '''
    js = JSInterpreter(code)
    c = js.extract_object("c")
    assert c["a"] == 20
    assert c["b"]("test") == "test"


# Generated at 2022-06-12 19:01:45.095800
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_string = '''
        var obj = {
            number_val: 42,
            string_val: "String",
            func: function(a, b) {
                return a + b;
            },
            func2: function(a, b, c) {
                return a + b + c;
            }
        };
        '''
    jsinterp = JSInterpreter(test_string)
    obj = jsinterp.extract_object('obj')
    # test obj
    assert obj['number_val'] == 42, 'number_val extract error'
    assert obj['string_val'] == 'String', 'string_val extract error'
    assert obj['func'](1, 2) == 3, 'func extract error'

# Generated at 2022-06-12 19:02:14.014939
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    SCRIPT_1 = '''
        var a = 100;
        var b = a + 10;
        var c = a * b + "%s" + _0xb9f1[3];
        function d(e, f) {
            return 3;
        }
        return d(a, b);
    '''

    intpreter = JSInterpreter(SCRIPT_1)
    result = intpreter.interpret_expression("a * b + '%s' + _0xb9f1[3]", {'a': 100, 'b': 110, '_0xb9f1[3]': 'xyz'})
    assert result == '100110%sxyz'


# Generated at 2022-06-12 19:02:25.275071
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter('')
    local_vars = {
        'a': 1,
        'b': 2
    }
    exprs = [
        ('a + b', 3),
        ('a + 3', 4),
        ('return a', 1),
        ('var a = b', None, 0),
        ('var b = a + 1', None, -1),
        ('return a + b + var_to_be_ignored', 3)
    ]
    for expr, expected, abort_expected in exprs:
        print(expr, expected, abort_expected)
        ret, abort = interpreter.interpret_statement(expr, local_vars)
        assert (ret, abort) == (expected, abort_expected)

if __name__ == '__main__':
    test_JSInterpreter_interpret_

# Generated at 2022-06-12 19:02:34.696284
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter.build_function(
        ['x', 'y'], 'return x + y')((1, 2)) == 3
    assert JSInterpreter.build_function(
        ['X'], 'return X.map(function(x){return x*2})')(([1, 2, 5],)) == [2, 4, 10]


if __name__ == '__main__':
    import script_tests
    script_tests.run_unittest(__name__)

# Generated at 2022-06-12 19:02:41.000775
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test to restore the original youtube.sig.decipher_signature function
    funcname='yt.sig.decipher_signature'
    argnames=['ciphertext', 'signature_fragments']

# Generated at 2022-06-12 19:02:53.513218
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:03:06.170407
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsi = JSInterpreter('''
        var func1 = function(p1, p2){
            return p1 + p2
        }
        ''')
    assert jsi.call_function('func1', 1, 3) == 4

    jsi = JSInterpreter('''
        var func1 = function(p1, p2){
            return p1 + p2
        }
        var func2 = function(p1, p2){
            return func1(p1, p2)
        }
        ''')
    assert jsi.call_function('func2', 1, 3) == 4


# Generated at 2022-06-12 19:03:12.320622
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('var a=0;function b(c,d){a=c+d;};b(2,3);')
    res = js_interpreter.build_function(['c','d'], 'a=c+d;')
    assert res((1,2)) == None
    assert res((2,3)) == None
    assert js_interpreter.call_function('b',2,3) == None
    assert js_interpreter.call_function('b',2,4) == None


# Generated at 2022-06-12 19:03:16.294308
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter('function test(arg1, arg2) {return arg1 + arg2;}')
    f = interpreter.build_function(('arg1', 'arg2'), 'return arg1 + arg2; ')
    assert f((3, 7)) == 10
    assert f((10, 4)) == 14

# Generated at 2022-06-12 19:03:22.533986
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var foo = {
            bar: function(a,b) {return a+b},
            baz: function(a) {return -a}
        }'''
    res = JSInterpreter(code).extract_object('foo')
    assert len(res) == 2
    assert res['bar'](1,2) == 3
    assert res['baz'](3) == -3


# Generated at 2022-06-12 19:03:32.462079
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    #TODO: add test coverage
    #TODO: add logging
    def interpret_expr(expr):
        inst = JSInterpreter('', {'window': {'navigator': {'userAgent': 'Mozilla'}}})
        return inst.interpret_expression(expr, {})

    assert interpret_expr('5') == 5
    assert interpret_expr('window') == {'navigator': {'userAgent': 'Mozilla'}}
    assert interpret_expr('window.navigator') == {'userAgent': 'Mozilla'}
    assert interpret_expr('window["navigator"]') == {'userAgent': 'Mozilla'}
    assert interpret_expr('window.navigator.userAgent') == 'Mozilla'

# Generated at 2022-06-12 19:04:18.897322
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """var kc = function(a){return a};
              var f = function() { return kc('test') };"""
    js = JSInterpreter(code)
    assert (js.call_function('f') == 'test')


# Generated at 2022-06-12 19:04:25.395140
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    import textwrap
    script = textwrap.dedent("""
        function my_function(arg1, arg2) {
            return arg1 + arg2;
        }""")

    js_interpreter = JSInterpreter(script)
    func = js_interpreter.build_function(["arg1", "arg2"], "return arg1+arg2;")
    assert func((1, 2)) == 3

# Generated at 2022-06-12 19:04:39.143247
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = """
    var obj = {
        a: function(args) {},
        b: 2
    }
    """
    js_obj = JSInterpreter(js_code)
    assert js_obj._objects['obj'] == {'a': None, 'b': 2}
    obj = js_obj._objects['obj']
    obj['a']((1,))
    obj['a']((1, 2, 3))
    # obj['c']()  # Raises KeyError
    # obj['b']()  # Raises TypeError

    js_code = """
    function a(x, y) {
        var z;
        z = x + y;
        return z;
    }
    """
    js_function = JSInterpreter(js_code)

# Generated at 2022-06-12 19:04:50.030181
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:04:57.746112
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:05:08.270515
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:05:18.576599
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_cases = [
        ['''
            var obj1 = {
                func: function () {},
            };
        ''', {'func': None}],
        ['''
            var obj1 = {
                func: function(a, b) {},
            };
        ''', {'func': None}],
        ['''
            var obj1 = {
                func: function(a, b) {},
                var1: 33,
                func2: function() {},
                func3: function(a,b,c) {},
            };
        ''', {'func': None, 'var1': 33, 'func2': None, 'func3': None}],
    ]
    for code, obj in test_cases:
        interp = JSInterpreter(code)
        obj_c = interp

# Generated at 2022-06-12 19:05:27.209759
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    def tjs(code):
        js = JSInterpreter('''
            function test() {
                %s
            }
        ''' % code)
        res, _ = js.interpret_statement(code, {})
        return res

    def tjss(code, local_vars=None):
        if local_vars is None:
            local_vars = {}
        js = JSInterpreter('''
            function test() {
                %s
            }
        ''' % code)
        return js.interpret_statement(code, local_vars)

    def test_equal(left, right, local_vars=None):
        if local_vars is None:
            local_vars = {}
        left_v, _ = tjss(left, local_vars)
        right_v

# Generated at 2022-06-12 19:05:34.713899
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
        function f(a, b) {
            var myvar = -1;
            myvar = 1 + 2;
            c = myvar + b;
            return {'hello': 'world', 'burger': ['a', 'b', 'c']};
        }
    """
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('f', 3, 'a') == {'hello': 'world', 'burger': ['a', 'b', 'c']}

if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-12 19:05:44.470326
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    #obj = {}

    #for f in fields_m:
    #    argnames = f.group('args').split(',')
    #    obj[f.group('key')] = self.build_function(argnames, f.group('code'))

    code = """
    var $ = function(arg1, arg2) {
        var abc = arg1 + arg2;
        return abc;
    };
    """
    js = JSInterpreter(code)
    code_m = re.search(
            r'''var\s*\$\s*=\s*function\s*\((?P<args>[^)]*)\)\s*\{(?P<code>[^}]+)\}''',
            code)
    argnames = code_m.group('args').split(',')


# Generated at 2022-06-12 19:06:37.783032
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter("")
    assert interpreter.interpret_expression("hello", {}) == "hello"
    assert interpreter.interpret_expression("1 + 1 == 2", {}) == 1 + 1 == 2
    assert interpreter.interpret_expression("1+1", {}) == 1 + 1
    assert interpreter.interpret_expression("1==1", {}) == 1 == 1
    assert interpreter.interpret_expression("true", {}) == True
    assert interpreter.interpret_expression("false", {}) == False
    assert interpreter.interpret_expression("1 < 2", {}) == 1 < 2
    assert interpreter.interpret_expression("1 > 2", {}) == 1 > 2

# Generated at 2022-06-12 19:06:40.992834
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = { a : "hello" };
        var func = function(myVar) {
            return myVar;
        };
        var b = {
            c : function(v) {
                return func(v);
            }
        };
    """
    i = JSInterpreter(code)
    r = i.extract_object("b")
    assert callable(r['c'])
    assert "hello" == r['c']("hello")
    return True


# Generated at 2022-06-12 19:06:52.213725
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var A = {
            b: function(c) {
                return c;
            },
            d: function(e) {
                return e;
            }
        };
        var f = function() {
            return 1;
        };
        var g = {};
        g = {
            h: function(i) {
                return i;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('A')
    assert obj['b'](3) == 3
    obj = js_interpreter.extract_object('g')
    assert obj['h'](5) == 5

# Generated at 2022-06-12 19:07:01.721510
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:07:11.414167
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:07:22.094589
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        A={a: function() { return 1 + 1; }, b: function() { return 1 + 2; }};
        B={c: function() { return 1 + 3; }};
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('A')

    assert(len(obj) == 2)
    assert(obj['a']() == 2)
    assert(obj['b']() == 3)

    obj = interpreter.extract_object('B')
    assert(len(obj) == 1)
    assert(obj['c']() == 4)


# Generated at 2022-06-12 19:07:31.806184
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """
        var B;
        var a = [2, 4, 8];
        var b = a[1] + a[0];
        B = b + 2;
        var c = 1 + 4;
        var obj = {
            'x': function(arg, arg2, arg3) {
                var obj2 = {'y': B};
                return obj2['y'];
            }
        };
        var b = obj['x']();
    """

    js = JSInterpreter(code)
    assert js.interpret_expression('1 << 3', {}) == 8
    assert js.interpret_expression('a[1]', {}) == 4
    assert js.interpret_expression('2 + 3', {}) == 5
    assert js.interpret_expression('1 + a[1]', {}) == 5
   

# Generated at 2022-06-12 19:07:43.814614
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # case 1
    js_code = '''var d = function() {
        stmt_res = ""
    }
    stmt_res = "";
    for (var b = 0; b < a.length; b++) {
        var c = a.charAt(b);
        stmt_res += d(c)
    }'''
    objects = {
        'a': 'foo',
        'd': lambda val: val + '1',
    }
    interpreter = JSInterpreter(js_code, objects)
    res = interpreter.interpret_expression('stmt_res', dict())
    assert res == 'f1o1o1'

    # case 2

# Generated at 2022-06-12 19:07:50.239485
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test1(a, b) {
            return a + b;
        }
    '''
    jsi = JSInterpreter(code)
    f = jsi.build_function(['a', 'b'], ';'.join([
        'return a + b']))
    assert f((3, 4)) == 7

    code = '''
        function test2(a, b) {
            var c = a + b;
            return a + b;
        }
    '''
    jsi = JSInterpreter(code)
    f = jsi.build_function(['a', 'b'], ';'.join([
        'var c = a + b',
        'return a + b',
    ]))
    assert f((3, 4)) == 7


# Generated at 2022-06-12 19:07:59.239489
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_inter = JSInterpreter("""var sym = function() {}""")
    sym = js_inter.build_function([], """
        var a_plus_b = a + b;
        var a_plus_b_times_c = a_plus_b * c;
        var sum = a_plus_b_times_c + d;
        var ans = [sum, a_plus_b_times_c, a_plus_b, a, b];
        return ans;
    """)
    assert sym([1, 2, 3, 4]) == [13, 12, 3, 1, 2]


# Generated at 2022-06-12 19:08:25.815525
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('')
    assert js.interpret_expression('1 + 2', {'a': 5}) == 3
    assert js.interpret_expression('1.5 - 2.5', {'a': 5}) == -1.0
    assert js.interpret_expression('2 * 3', {'a': 5}) == 6
    assert js.interpret_expression('8 / 2', {'a': 5}) == 4.0
    assert js.interpret_expression('3 % 2', {'a': 5}) == 1
    assert js.interpret_expression('1 | 4', {'a': 5}) == 5
    assert js.interpret_expression('2 & 4', {'a': 5}) == 0
    assert js.interpret_expression('5 ^ 6', {'a': 5}) == 3

# Generated at 2022-06-12 19:08:38.177150
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('', {
        'a': [5, 6, 7, 8, 9],
        'b': [1, 2, 3, 4, 5],
        'c': 'abcdefghijklmnopqrstuvwxyz',
        'd': ['a', 'b', 'c']
    })

    def check(v):
        def t(expr, expected):
            assert v(expr) == expected
        return t
    test = check(lambda expr: js.interpret_expression(expr, {}))
    test('""', '')
    test('"abc"', 'abc')
    test('"abc".length', 3)
    test('"abc".slice(1)', 'bc')
    test('"abc".slice(1).length', 2)

# Generated at 2022-06-12 19:08:48.643143
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objname = 'a'
    test_string = '''a={"b":function(x, y) {c=x+y} }'''

    class JSInterpreter_test(JSInterpreter):
        def __init__(self, code, objects=None):
            JSInterpreter.__init__(self, code, objects=objects)
            
    jsi = JSInterpreter_test(test_string)
    obj = jsi.extract_object(objname)
    assert obj == {'b': jsi.build_function(['x', 'y'], 'c=x+y')}


# Generated at 2022-06-12 19:08:57.890275
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    objects = {
        'testobj': {
            'b': ['a', 'b', 'c'],
            'c': ['d', 'e'],
        }
    }


# Generated at 2022-06-12 19:09:01.696409
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("code")
    assert js_interpreter.build_function(["arg1", "arg2"], "function(arg1, arg2){return arg1 + arg2;}")((4, 6)) == 10



# Generated at 2022-06-12 19:09:11.688114
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Given a js code
    js_code = '''
    q = '\\x77\\x69\\x6B\\x69'
    e = 0
    for (i = 0; i < q.length; i++)
        e += q.charCodeAt(i)
    e + '';
    '''
    # There should be no exception when processing expression
    js_expr = 'q.split(x)',
    js_expr = 'q.join(x)',
    js_expr = 'q.reverse()',
    # Testing q.charCodeAt()
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.interpret_expression('q.charCodeAt(0)') == 119


test_JSInterpreter_interpret_expression()

# Generated at 2022-06-12 19:09:13.625942
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter("function testfunction(a,b){}")
    assert("function" == str(type(jsi.build_function(["a", "b"], ""))))


# Generated at 2022-06-12 19:09:24.835126
# Unit test for method interpret_expression of class JSInterpreter