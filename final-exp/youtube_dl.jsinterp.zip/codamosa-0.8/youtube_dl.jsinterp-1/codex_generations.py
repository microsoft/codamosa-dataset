

# Generated at 2022-06-12 19:00:59.282498
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test a function without parameter and without return statement
    code = 'function funcname() { code }'
    argnames = ()
    codeStr = ' code '
    result = JSInterpreter(code).build_function(argnames, codeStr)(argnames)
    assert result is None
    # Test a function with parameter and without return statement
    code = 'function funcname(arg1, arg2) { code }'
    argnames = ('arg1', 'arg2')
    codeStr = ' code '
    argvals = ('this is arg1', 'this is arg2')
    result = JSInterpreter(code).build_function(argnames, codeStr)(argvals)
    assert result is None
    # Test a function without parameter and with return statement
    code = 'function funcname() { return string; }'

# Generated at 2022-06-12 19:01:05.146810
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter("""
        function ytplayer_1(a){
            return a;
        }
        """)
    f = js.build_function(["a"], "return a;")
    if f(1) != 1:
        raise AssertionError('JSInterpreter build_function test failed')



# Generated at 2022-06-12 19:01:18.629274
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code1 = '''\n    function poo(){    var obj = {
    key1: function(a,b){return a+b;},
    key2: function(a){return a-5;}
    };return obj.key2(obj.key1(5,5));}'''.replace('    ', '')

    jsinterpreter1 = JSInterpreter(code1)
    obj1 = jsinterpreter1.build_function([], code1)

    obj_return1 = obj1(())
    assert obj_return1 == 5

    code2 = '''\nfunction poo(){   var local_var = {};
    local_var.a = 5;
    local_var.b = 6;
    return local_var.a*local_var.b;}'''.replace('    ', '')

    jsinter

# Generated at 2022-06-12 19:01:31.097697
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('a', {'a': 6, 'b': 7}) == 6
    assert js_interpreter.interpret_expression('[1, 2, 3]', {}) == [1, 2, 3]
    assert js_interpreter.interpret_expression('a', {'a': [1, 2, 3]}) == [1, 2, 3]
    assert js_interpreter.interpret_expression('a[1]', {'a': [1, 2, 3]}) == 2
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('a>0?a:b', {'a': 1, 'b': -1}) == 1

# Generated at 2022-06-12 19:01:40.272375
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = JSInterpreter('''\
var a = [0, 1, 2];
a[0] = 11;
''', {'a': [0, 1, 2]})

    assert code.interpret_expression('11', {}) == 11
    assert code.interpret_expression('a[0]', {}) == 11
    assert code.interpret_expression('a[1]', {}) == 1
    assert code.interpret_expression('a[2]', {}) == 2
    assert code.interpret_expression('a[1]+1', {}) == 2
    assert code.interpret_expression('a.slice(1)', {}) == [1, 2]
    assert code.interpret_expression('a.join("")', {}) == '112'


# Generated at 2022-06-12 19:01:49.628803
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = '''\
    function func1(name) {
    return 'Hello ' + name
    }
    foo = func1('world')
    '''
    inter = JSInterpreter(js)
    assert inter.interpret_expression('func1("world")', {}) == 'Hello world'
    assert inter.interpret_expression('foo', {}) == 'Hello world'
    assert inter.interpret_expression('"Hello "+"world"', {}) == 'Hello world'
    assert inter.interpret_expression('1+2', {}) == 3
    assert inter.interpret_expression('1+3*5', {}) == 16
    assert inter.interpret_expression('1*2+3*5', {}) == 13
    assert inter.interpret_expression('(1+2)*(3+5)', {}) == 36

# Generated at 2022-06-12 19:01:59.171263
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    '''
    Test the method build_function of class JSInterpreter
    '''
    jsi = JSInterpreter("var x = function (args) {var y = 1 + args[0]; return y;}")
    f = jsi.build_function(['args'], "var y = 1 + args[0]; return y;")
    assert f([2]) == 3, "Error with function 'x'"
    jsi2 = JSInterpreter("function y(args) {var x = 0; for (var i = 0; i < args.length; i++) {x = x + args[i];} return x;}")

# Generated at 2022-06-12 19:02:04.341984
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        console.log(true);
        var f = function(a) { 
            var x = a * 2;
            var y = x + 1;
            return y;
        };
        console.log(f(2));
        '''
    jsi = JSInterpreter(code, {})
    f = jsi.build_function(['a'], 'var x = a * 2; var y = x + 1; return y;')
    assert f((2,)) == 5
    f = jsi.build_function(['a'], 'var x = a * -2; var y = x + 1; return y;')
    assert f((2,)) == -3



# Generated at 2022-06-12 19:02:08.767746
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r"""
        var A = {
            reverse: function(){
                this.reverse();
            }
        }
    """
    js = JSInterpreter(code)
    a = js.extract_object("A")
    a = [1, 2, 3]
    a.reverse()
    assert a == [3, 2, 1]


# Generated at 2022-06-12 19:02:15.555685
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def test(s, expected):
        print('Evaluating: ' + s)
        v = JSInterpreter('', {}).interpret_expression(s, {})
        assert v == expected, 'eval(%r)==%r!=%r' % (s, v, expected)
        print('Evaluated to: ' + str(v))

    # test(expression, expected_result)
    test('0', 0)
    test('1', 1)
    test('-1', -1)
    test('1 + 1', 2)
    test('-1+-2', -3)
    test('1-1', 0)
    test('1*1', 1)
    test('1/2', 0.5)
    test('2**2', 4)
    test('1 % 2', 1)
    test

# Generated at 2022-06-12 19:02:46.806109
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter('var a="A"; b="B"; c=[]; x=5; y=5.5;')
    assert js.interpret_statement('a', {}) == ('A', False)
    assert js.interpret_statement('x', {}) == (5, False)
    assert js.interpret_statement('y', {}) == (5.5, False)
    assert js.interpret_statement('c', {}) == ([], False)
    assert js.interpret_statement('return a', {}) == ('A', True)
    assert js.interpret_statement('var a = "B"', {}) == ('B', False)
    assert js.interpret_statement('var a = "B"; return a', {}) == ('B', True)

# Generated at 2022-06-12 19:02:59.672553
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterpreter = JSInterpreter("var a = 100; var b = a + 1; b;")
    assert jsinterpreter.interpret_expression("a", {}) == 100
    assert jsinterpreter.interpret_expression("b", {}) == 101
    jsinterpreter = JSInterpreter("var a = 100; var b = a + 1; var c = b + 1; c;")
    assert jsinterpreter.interpret_expression("c", {}) == 102
    jsinterpreter = JSInterpreter("var a = 100; var b = a * 1; var c = b * 1; c;")
    assert jsinterpreter.interpret_expression("c", {}) == 100

# Generated at 2022-06-12 19:03:10.590679
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_object_code = '''
    var test_object = {
        "a": function(){return 'this is a function'},
        "b": function(arg){return arg + ' is a function'},
        "hello": 'world'
    }
    '''

# Generated at 2022-06-12 19:03:19.557832
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:03:30.134236
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:03:41.109552
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:03:50.754355
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:04:00.508275
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var Outstreamblackbird = {
            "adx.jwpsrv.com" : function(n, t) {
                return n
            },
            "d.jwpcdn.com" : function(n, t) {
                return n
            },
            "pb.jwpcdn.com" : function(n, t) {
                return n
            },
            "google_adx_domain" : function(n) {
                return n
            },
            "google_adx_direct" : function(n) {
                return n
            }
        };
    '''
    outstreamblackbird = JSInterpreter(code).extract_object('Outstreamblackbird')
    assert isinstance(outstreamblackbird, dict)

# Generated at 2022-06-12 19:04:10.412382
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    test_code = '''
    function func(a, b) {
        return a + b;
    }
    '''
    js_interpreter = JSInterpreter(test_code)
    f = js_interpreter.extract_function('func')
    assert f((1, 2)) == 3
    
    test_code = '''
    function func(a, b) {
        return a * b;
    }
    '''
    js_interpreter = JSInterpreter(test_code)
    f = js_interpreter.extract_function('func')
    assert f((1, 2)) == 2


# Generated at 2022-06-12 19:04:16.945397
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
    function f(x) {
        return x + 1;
    }
    var g = function(y, z) {
        return y + z;
    }
    '''
    jsi = JSInterpreter(code)
    assert jsi.call_function('f', 7) == 8
    assert jsi.call_function('g', 3, 7) == 10



# Generated at 2022-06-12 19:04:51.656123
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsint = JSInterpreter('''
    f1 = function(a){
        return a;
    }
    ''')
    assert jsint.call_function('f1', 'x') == 'x'
    jsint = JSInterpreter(u'''
    f1 = function(a){
        return "a" + a;
    }
    ''')
    assert jsint.call_function(u'f1', u'x') == u'ax'
    jsint = JSInterpreter(u'''
    f1 = function(a, b){
        return a + b;
    }
    ''')
    assert jsint.call_function(u'f1', 1, 2) == 3

# Generated at 2022-06-12 19:04:54.889703
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        var a = {
            b: function(p,q){
                return p+q;
            }
        }
    '''
    
    assert 5 == JSInterpreter(code).call_function('a.b', 2, 3)

# Generated at 2022-06-12 19:05:05.987432
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_data = [
        ("function f(w,h,s){document.getElementById('v').width=w;document.getElementById('v').height=h;document.getElementById('v').src=s;}",
         704, 576, 'https://my-video-url.com/stream.mp4')
    ]

    for js_code, w, h, s in test_data:
        jsInterpreter = JSInterpreter(js_code)
        args = ["v", "v", "v"]

# Generated at 2022-06-12 19:05:08.039936
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('function func(a, b){ return a + b; }')
    assert js_interpreter.call_function('func', 3, 5) == 8

# Generated at 2022-06-12 19:05:18.378212
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # This function returns a function as a result of call_function
    # If a function is to be returned, the second argument of call_function
    # must be (), otherwise an error will occur
    js_igm_fun1 = '''
    function ig(a) {
        if (a) {
            return a;
        } else {
            return "";
        }
    }'''
    js_igm_fun2 = '''
    function ig2 (a) {
        if (a) {
            return a;
        } else {
            return "";
        }
    }'''
    js_igm_fun3 = '''
    function ig3 (a) {
        if (a) {
            return a;
        } else {
            return "";
        }
    }'''
    js_igm_fun

# Generated at 2022-06-12 19:05:24.347109
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:05:35.144894
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:05:44.728427
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''
        a = 5;
        var b = 6;
        return a + b;
        ''';
    assert JSInterpreter(code).interpret_statement(code)[0] == 11
    code = '''
        var a = [1,2,3,4,5];
        return a[2];
        ''';
    assert JSInterpreter(code).interpret_statement(code)[0] == 3
    code = '''
        var a = [1,2,3,4,5];
        var b = 2;
        return a[b];
        ''';
    assert JSInterpreter(code).interpret_statement(code)[0] == 3

# Generated at 2022-06-12 19:05:52.774032
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
    var a=0;
    var b=1;
    var f=function(x,y){
        return x*y;
    }
    var g=function(x){
        return Math.pow(x,2);
    }
    """
    test1 = JSInterpreter(code)
    assert test1.call_function('f',2,3) == 6
    assert test1.call_function('g',3) == 9


# Generated at 2022-06-12 19:05:57.348396
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = "function test(a, b) { c = a + b; return c; }"
    ji = JSInterpreter(code)
    f = ji.build_function(["a", "b"], "c = a + b; return c;")
    assert f((1,1)) == 2



# Generated at 2022-06-12 19:08:01.616567
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:08:10.941676
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter(None).interpret_expression('{}', {}) == {}
    assert JSInterpreter(None).interpret_expression('[]', {}) == []
    assert JSInterpreter(None).interpret_expression('""', {}) == ''
    assert JSInterpreter(None).interpret_expression('99', {}) == 99
    assert JSInterpreter(None).interpret_expression('true', {}) == True
    assert JSInterpreter(None).interpret_expression('false', {}) == False
    assert JSInterpreter(None).interpret_expression('null', {}) is None
    assert JSInterpreter(None).interpret_expression('1+2', {}) == 3
    assert JSInterpreter(None).interpret_expression('1*2', {}) == 2

# Generated at 2022-06-12 19:08:21.676131
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:08:34.018354
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinter = JSInterpreter('')

    def check(code, expected):
        # Ignoring optional arguments for now
        code = re.sub(r'(?<=[^=])=\s*\[.*?\](?=;)', '= 0', code)
        f = jsinter.build_function(['x', 'y'], code)
        res = f(expected)
        if res != expected:
            raise AssertionError('%r != %r for %r' % (res, expected, code))

    check('x', 0)
    check('y', 1)
    check('x + y', 1)
    check('x + y + 1', 2)
    check('x + y + "a"', '1a')
    check('x + y - 1', 0)

# Generated at 2022-06-12 19:08:39.467669
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter(None)
    # Test interpret number
    assert interpreter.interpret_expression('0', locals()) == 0
    # Test interpret boolean
    assert interpreter.interpret_expression('true', locals()) is True
    assert interpreter.interpret_expression('false', locals()) is False
    # Test interpret string
    assert interpreter.interpret_expression('""', locals()) == ''


# Generated at 2022-06-12 19:08:44.541801
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter('foo=bar;')
    local_vars = {}
    js.interpret_statement('foo=1', local_vars)
    assert local_vars['foo'] == 1

# Generated at 2022-06-12 19:08:50.346371
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    JS = '''
var a = {
    b: function() {},
    c: function() {},
    d: function() {}
}
'''.strip()
    jsi = JSInterpreter(JS)
    o = jsi.extract_object('a')
    assert o['b'] is not None
    assert o['c'] is not None
    assert o['d'] is not None



# Generated at 2022-06-12 19:08:58.774195
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    v = JSInterpreter('')
    local_vars = {'return': True}

# Generated at 2022-06-12 19:09:02.607540
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    result = js_interpreter.build_function(['arg1', 'arg2'], 'return arg1 + arg2')
    assert result([2, 3]) == 5


# Generated at 2022-06-12 19:09:12.438313
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():

    def test(input, output):
        code = "var foo = { a: function(){}.toString(), b: function(){}.toString() }; var bar = {};"
        bar = JSInterpreter(code).interpret_statement(input, dict(foo=["a", "b"]))
        assert bar == output, bar

    test("return foo[1]", "b")
    test("return foo[0]", "a")
    test("return foo[1].length", 8)
    test("return foo[0][2]", "n")

    test("bar = foo[1]", "b")
    test("bar = foo[1]; return bar", "b")
    test("bar[0] = foo[0][2]; return bar", ["n"])