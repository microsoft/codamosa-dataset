

# Generated at 2022-06-12 19:00:25.360041
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_interpreter = JSInterpreter(
        '''
        atob = {
            utf8Decode: function(strUtf) {
                return decodeURIComponent(escape(strUtf));
            }
        };
        ''',
        {
            'strUtf': 'aHR0cHM6Ly95b3V0dS5iZS9nck9hcUhfbWS=',
            'strBase64': 'Z3JPYXFIX21k',
            'strRaw': 'grOaqH_md'
        }
    )

    atob = js_interpreter.extract_object('atob')

    result = atob['utf8Decode'](('strUtf',))
    assert result == 'https://youtu.be/grOaqH_md'

   

# Generated at 2022-06-12 19:00:30.558371
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = 'var c=a+b; return c;'
    jsi = JSInterpreter(code)
    res, abort = jsi.interpret_statement(code, {'a': 1, 'b': 2})
    assert res == 3
    assert abort

# Generated at 2022-06-12 19:00:38.017316
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = r'''
        bar "foo" . a = {
            b : function (a) {
                c = a + 1;
                return c;
            },

            d : function () {
                return foo;
            }
        }
    '''

    js = JSInterpreter(js_code)
    f1 = js.extract_function('a.b')
    f2 = js.extract_function('a.d')

    assert f1([1]) == 2
    assert f2([]) == 'foo'


# Generated at 2022-06-12 19:00:44.145946
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code_to_test = r'{a: function(b) {return b;}}'
    argnames_to_test = ['b']
    js_interpreter = JSInterpreter(code_to_test)
    f = js_interpreter.build_function(argnames_to_test, code_to_test)
    assert f([1]) == 1



# Generated at 2022-06-12 19:00:56.703538
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:01:09.760294
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    global jsi

# Generated at 2022-06-12 19:01:20.987632
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    var a = {
        x: function(a,b) {
            return a + b;
        },
        y: function(a) {
            return a * a;
        }
    };

    a.z = function(a) {
        return a - 1;
    };
'''
    i = JSInterpreter(code)
    res = i.extract_object('a')
    assert callable(res['x'])
    assert callable(res['y'])
    assert callable(res['z'])
    assert res['x'](2, 3) == 5
    assert res['y'](5) == 25
    assert res['z'](5) == 4

# Generated at 2022-06-12 19:01:33.351146
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = """
        var test = {
            get_number: function() {
                return 3;
            },
            get_array: function() {
                return [5, 6, 7, 8];
            }
        };

        var myfunc = function(a, b) {
            var c = a + b;
            var d = a + b + c;
            var test_array = [3, 4, 5, 6];
            return test.get_array().reverse().slice(test_array.reverse().pop());
        };
    """
    interpreter = JSInterpreter(code)
    res, abort = interpreter.interpret_statement('var a = 1', {})
    assert res == 1
    res, abort = interpreter.interpret_statement('return a + 2 + test.get_number()', {})
    assert res == 6


# Generated at 2022-06-12 19:01:40.142028
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    var a = {
        test: function() {
            var myVar = 10;
            return myVar;
        },
        test2: function() {
            var someVar = {
                test: function() {
                    return "Hello World"
                }
            }
            return someVar.test();
        }
    }
    '''

    js_interpreter = JSInterpreter(code)
    a = js_interpreter.extract_object("a")
    assert a["test"]() == 10
    assert a["test2"]() == "Hello World"


# Generated at 2022-06-12 19:01:49.474709
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        var a = 0;
        var b = 1;
        var c = 2;
    '''

    interpreter = JSInterpreter(code, objects={})

    res = interpreter.interpret_expression('a', {})
    assert res == 0

    res = interpreter.interpret_expression('b', {})
    assert res == 1

    res = interpreter.interpret_expression('a + b', {})
    assert res == 1

    res = interpreter.interpret_expression('a + b + c', {})
    assert res == 3

    res = interpreter.interpret_expression('(a + b) + c', {})
    assert res == 3

    res = interpreter.interpret_expression('a + (b + c)', {})
    assert res == 3


# Generated at 2022-06-12 19:02:19.409326
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        function f(arg1, arg2) {
            if (arg1 == 'foo') {
                return arg2;
            }
            var a, b, c;

            a = 4
            b = 1
            c = a + b
            b = arg1

            if (arg2) {
                a = b;
            }
            a += c;
            return a;
        }'''

    assert JSInterpreter(code).interpret_expression('a', {}) is None
    assert JSInterpreter(code).interpret_expression('a', {'a': 5, 'b': 3}) == 5

    assert JSInterpreter(code).interpret_expression('a + 3', {'a': 5, 'b': 3}) == 8

# Generated at 2022-06-12 19:02:27.409447
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter("""\
    ;function z(a,b) { return a+b; }
    ;var test1 = {
    ;    "a": "5",
    ;    "b": "6",
    ;    "reduce": function(a,b) {return a-b;}
    ;    }
    ;var test2 = {
    ;    "a": "5",
    ;    "b": "6" }
    ;var a = [1,2,3,4,5];
    ;function v(a,b) {
    ;    if (b == 0)
    ;        return 0;
    ;    else
    ;        return a;
    ;    }
    ;function z(a,b) {
    ;    return a+b; }
    """)

# Generated at 2022-06-12 19:02:41.368535
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('', {})
    assert js.interpret_expression('1', {}) == 1
    assert js.interpret_expression('-1', {}) == -1
    assert js.interpret_expression('3 + 4', {}) == 7
    assert js.interpret_expression('3 + 4 + 5', {}) == 12
    assert js.interpret_expression('3 * 4 + 5', {}) == 17
    assert js.interpret_expression('3 + 4 * 5', {}) == 23
    assert js.interpret_expression('9 / 3', {}) == 3
    assert js.interpret_expression('8 - 5', {}) == 3
    assert js.interpret_expression('8 % 5', {}) == 3
    assert js.interpret_expression('8 + 5', {}) == 13

# Generated at 2022-06-12 19:02:47.651699
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = "function(arg1,arg2){var a = arg1;var b = arg2;var c = a[0]}"
    argnames = ['arg1','arg2']
    jsi = JSInterpreter(code)
    f = jsi.build_function(argnames, code)

    args= [1,2]

    assert(f(args) == 1)

# Generated at 2022-06-12 19:03:01.151114
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = """var d = function (a, b, c) {return b};"""
    jsi = JSInterpreter(js)
    # Test function defined in variable
    f = jsi.build_function(['a', 'b', 'c'], 'return b')
    assert f(['d', 'e', 'f']) == 'e'
    # Test function defined in variable followed by another variable
    js = """var d = function (a, b, c) {return b};var e = 2;"""
    jsi = JSInterpreter(js)
    f = jsi.build_function(['a', 'b', 'c'], 'return b')
    assert f(['d', 'e', 'f']) == 'e'
    # Test function defined in variable followed by a function

# Generated at 2022-06-12 19:03:10.907580
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    def check_JSInterpreter_interpret_statement(statement, expect_abort, expect_res):
        res, abort = JSInterpreter('').interpret_statement(statement, {})
        if (expect_abort != abort) or (expect_res != res):
            return False
        return True

    assert True == \
        check_JSInterpreter_interpret_statement('return 1', True, 1)
    assert True == \
        check_JSInterpreter_interpret_statement('1 + 2', False, 3)
    assert True == \
        check_JSInterpreter_interpret_statement('x += 1', False, 1)
    assert True == \
        check_JSInterpreter_interpret_statement('x = 1', False, 1)



# Generated at 2022-06-12 19:03:19.771947
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('')
    x = {
        'x': 1,
        'y': 0,
        'z': [3, 1, 5, 0, 2],
        'v': [1, 2, 3]
    }
    # Test 1: x + y
    assert js.interpret_expression('x + y', x) == x['x'] + x['y']
    # Test 2: x - y
    assert js.interpret_expression('x - y', x) == x['x'] - x['y']
    # Test 3: x * y
    assert js.interpret_expression('x * y', x) == x['x'] * x['y']
    # Test 4: x / y
    assert js.interpret_expression('x / y', x) == x['x'] / x['y']
    #

# Generated at 2022-06-12 19:03:27.939892
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():

    def assert_build_function(funcname, code, argnames, args, expected):
        f = JSInterpreter('').build_function(argnames, code)
        assert f.__name__ == funcname
        assert f(args) == expected

    assert_build_function(
        'swapNumbers', 'var temp = a; a = b; b = temp;',
        ['a', 'b'], (1, 2), None)

    assert_build_function(
        'computeProduct', 'return a * b;',
        ['a', 'b'], (2, 3), 6)

# Generated at 2022-06-12 19:03:35.867179
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:03:41.955266
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    f = JSInterpreter("""function test(a, b, c) {
                var e=a+b;
                var d=e+1;
                return c+d;
            }""").build_function(['a', 'b', 'c'], """var e=a+b;
                var d=e+1;
                return c+d;""")
    assert f((2, 5, 0)) == 8


# Generated at 2022-06-12 19:04:33.145109
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Function definition with no parameters
    code = "function f () { return 3+2; }"
    argnames = []
    interpreter = JSInterpreter(code)
    resf = interpreter.build_function(argnames, 'return 3+2;')
    result = resf([])
    if result != 5:
        raise AssertionError('The result of function call is wrong: ' + result)

    # Function definition with one parameter
    code = "function f (a) { return a+1; }"
    argnames = ['a']
    interpreter = JSInterpreter(code)
    resf = interpreter.build_function(argnames, 'return a+1;')
    result = resf([1])
    if result != 2:
        raise AssertionError('The result of function call is wrong: ' + result)



# Generated at 2022-06-12 19:04:44.549403
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test(argnames, code, args, result):
        f = JSInterpreter('').build_function(argnames, code)
        messages = [
            '\tExpected value:',
            '\t\t%s\n' % result,
            '\tReturned value:',
            '\t\t%s' % f(args)
        ]
        if f(args) == result:
            print('[OK] ', end='')
        else:
            print('[FAIL] ', end='')
            exit(1)
        print(', '.join(map(lambda x: '%s' % x, [argnames, code, args])))

    print('Testing JSInterpreter', end='')
    print('.')


# Generated at 2022-06-12 19:04:54.889205
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:05:05.944698
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test_function(argnames, code, args, result):
        jsi = JSInterpreter('')
        f = jsi.build_function(argnames, code)
        if f(args) != result:
            raise AssertionError('%r != %r' % (f(args), result))

    test_function(['a', 'b'], 'a + b', [1, 2], 3)
    test_function(['a', 'b'], 'a - b', [5, 2], 3)
    test_function(['a', 'b'], 'a * b', [3, 2], 6)
    test_function(['a', 'b'], 'a / b', [10, 2], 5)

# Generated at 2022-06-12 19:05:09.338604
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsinter = JSInterpreter(r'''
        b = function() {return 3};
        a = function (x){
            var c = function(a, b){
                return a + b + x
            };
            var e = 2, d = 2;
            a = c(e, d);
            return b();
        };''')
    test_a = jsinter.build_function(['x'], r'''
            var c = function(a, b){
                return a + b + x
            };
            var e = 2, d = 2;
            a = c(e, d);
            return b();''')

    assert test_a((3,)) == 3

# Generated at 2022-06-12 19:05:18.961251
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    global code
    global _objects
    global _functions

# Generated at 2022-06-12 19:05:27.240213
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:05:32.994739
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test_routine(function_name, args, expected_result):
        code = '''
            %s = function() {
                %s
            };
        ''' % (function_name, expected_result)
        js_interpreter = JSInterpreter(code)
        actual_result = js_interpreter.call_function(
            function_name, *args)
        assert actual_result == expected_result
        return True

    # test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:05:40.921700
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:05:46.868787
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:08:04.746801
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
    function testFunction(a,b,c) {
      var x = a + b + c;
      return x;
    }
    '''
    resf = JSInterpreter(code).build_function(['a', 'b', 'c'], 'a + b + c;')
    assert resf((5, 3, 9)) == 17

# Generated at 2022-06-12 19:08:10.418913
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('', {}).interpret_expression(
        '"abc".slice(1)', {}, 100) == 'bc'
    assert JSInterpreter('', {}).interpret_expression('abcdefg', {}, 100) == 'abcdefg'
    assert JSInterpreter('', {}).interpret_expression('1+1', {}, 100) == 2
    assert JSInterpreter('', {}).interpret_expression('2+2', {}, 100) == 4
    assert JSInterpreter('', {}).interpret_expression('4+4', {}, 100) == 8
    assert JSInterpreter('', {}).interpret_expression('2+2+2*2', {}, 100) == 6
    assert JSInterpreter('', {}).interpret_expression('2*2+2', {}, 100) == 6
    assert JSInterpre

# Generated at 2022-06-12 19:08:21.595451
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # test function with 1 argument
    js = JSInterpreter('function func1(arg1) { return arg1 * 5; }')
    f = ['func1', 'function (arg1) { return arg1 * 5; }']
    f = js.build_function(f[0], f[1])
    assert f([5]) == 25

    # test function with 1 argument and 1 local variable
    js = JSInterpreter('function func2(arg1) { var var1 = arg1 + 5; return var1 * 5; }')
    f = ['func2', 'function (arg1) { var var1 = arg1 + 5; return var1 * 5; }']
    f = js.build_function(f[0], f[1])
    assert f([5]) == 50

    # test function with two arguments and one local variable

# Generated at 2022-06-12 19:08:25.814121
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # test a function
    js1 = r'var a,b,c;a=b=c=d;return d;'
    interpreter = JSInterpreter(js1)
    result = interpreter.interpret_statement(js1, {})
    if (result != ('', True)):
        raise Exception('JSInterpreter_interpret_statement unit test failed')
    print('JSInterpreter_interpret_statement unit test passed')


# Generated at 2022-06-12 19:08:38.238739
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('', {'window': {'navigator': {'userAgent': 'foobar'}}})
    assert js.interpret_expression('42', {}) == 42
    assert js.interpret_expression('42.3', {}) == 42.3
    assert js.interpret_expression('"a"', {}) == 'a'
    assert js.interpret_expression('true', {}) is True
    assert js.interpret_expression('false', {}) is False
    assert js.interpret_expression('null', {}) is None
    assert js.interpret_expression('x', {'x': 42}) == 42
    assert js.interpret_expression('x["a"]', {'x': {'a': 5}}) == 5

# Generated at 2022-06-12 19:08:50.761513
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = r'''
        (function(w, d){
            var a = {
                b: function(p, f, c, k, h, e, b) {
                    return h(p, f, c, k, h, e, b);
                },
                c: function(p, f, c, k, h, e, b) {
                    return h(p, f, c, k, h, e, b);
                }
            };
            w.ya = {
                w: a
            };
        })(window, document);
    '''
    js_interpreter = JSInterpreter(js_code)
    f = js_interpreter.extract_function('a.c')
    assert f(range(7)) == 6

    # Test for calling an internal function
    js_

# Generated at 2022-06-12 19:08:59.185837
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    objects = {}
    jsinterpreter = JSInterpreter('', objects)
    local_vars = {'a': 2, 'b': 3}
    allow_recursion = 10
    expr = 'a+b'
    assert jsinterpreter.interpret_expression(expr, local_vars, allow_recursion) == 5, 'Normal operator'
    expr = 'a-b'
    assert jsinterpreter.interpret_expression(expr, local_vars, allow_recursion) == -1, 'Normal operator'
    expr = 'a*b'
    assert jsinterpreter.interpret_expression(expr, local_vars, allow_recursion) == 6, 'Normal operator'
    expr = 'a**b'
    assert jsinterpreter.interpret_expression(expr, local_vars, allow_recursion)

# Generated at 2022-06-12 19:09:05.072172
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter(code = "")
    res = js_interpreter.build_function(['a'], "b=a;return b")
    assert res(1) == 1
    res = js_interpreter.build_function(['a'], "b=a;return b")
    assert res(2) == 2
    assert callable(res)


# Generated at 2022-06-12 19:09:10.361771
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = (
        "var t={};t.sig||(t.sig=function(t){var n={a:t};"
        "return n.b}); var b = t.sig('hello world')['b'];")
    assert JSInterpreter(js).call_function('t.sig', 'hello world') == {'a': 'hello world'}


# Generated at 2022-06-12 19:09:14.527360
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    var aa = function() {};
    aa.prototype = {
        bar: function() {},
        baz: function() {}
    };
    '''
    interpreter = JSInterpreter(code)
    aa = interpreter.extract_object('aa')
    assert aa['bar']
    assert aa['baz']
    return
