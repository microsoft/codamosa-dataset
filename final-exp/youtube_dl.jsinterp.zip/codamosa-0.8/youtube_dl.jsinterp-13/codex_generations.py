

# Generated at 2022-06-12 19:00:22.756810
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:00:36.425679
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:00:49.103819
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    inf = "r=function(a,b){for(var c=0;c<b.length-2;c+=3){var d=b.charAt(c+2),d=d>=t?d.charCodeAt(0)-87:Number(d),d=b.charAt(c+1)==Rb?a>>>d:a<<d;a=b.charAt(c)==Rb?a+d&4294967295:a^d}return a};"
    jsi = JSInterpreter(inf)
    assert(jsi.call_function('r','fghijk','abcdefghijklmnopqrstuvwxyz0123456789-_<?>|12312') == 3650728496)

if __name__ == '__main__':
    test_JSInterpre

# Generated at 2022-06-12 19:01:01.018242
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    '''Unit test for method build_function of class JSInterpreter'''
    from .utils import url_basename

    code = 'function(){return 3;};'
    js_int = JSInterpreter(code)
    resf = js_int.build_function([], code)
    assert resf() == 3

    code = 'function(a,b){return a+b;};'
    js_int = JSInterpreter(code)
    resf = js_int.build_function(['a', 'b'], code)
    assert resf(1, 2) == 3

    code = 'function(a,b){return arguments[0]+b;};'
    js_int = JSInterpreter(code)
    resf = js_int.build_function(['a', 'b'], code)
   

# Generated at 2022-06-12 19:01:10.778243
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_interpreter = JSInterpreter(
        '''
        klass = {
            el: function(str) {
                if (str == 'parentNode') {
                    return {attributes: [], nodeName: 'DIV'};
                }
            }
        };
        '''
    )
    assert js_interpreter._objects['klass'] == {
        'el': lambda *args: {
            'attributes': [],
            'nodeName': 'DIV',
            } if args[0] == 'parentNode' else [],
    }


# Generated at 2022-06-12 19:01:23.788963
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})
    def testfunc(argnames, code, exp_value):
        f = js_interpreter.build_function(argnames, code)
        act_value = f(args)
        assert act_value == exp_value,\
                "Value returned by function '%s' is %s, expected %s" % (
                code, act_value, exp_value)
    args = [1, 'a', 10]
    testfunc(('a', 'b', 'c'), 'a;b=c;return c', 10)
    testfunc(('a', 'b', 'c'), 'a;b=c;return a', 1)
    testfunc(('a', 'b', 'c'), 'a;b=c;return b', 10)

# Generated at 2022-06-12 19:01:30.541957
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter("var a = 'abc'; var dt = {'dd': 'abd'}; var h4 = ('abc'+'def').split('').reverse().join(''); var f = function (a, b) { return a+b; }")
    assert js_interpreter.interpret_expression("a", {}) == 'abc'
    assert js_interpreter.interpret_expression("dt.dd", {}) == 'abd'
    assert js_interpreter.interpret_expression("h4", {}) == 'fedcba'
    assert js_interpreter.interpret_expression("f('def', a)", {}) == 'defabc'

# Generated at 2022-06-12 19:01:35.746200
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    sample_code = """var a = 10;var b = 20;var c = a + b;c;"""
    js_interpreter = JSInterpreter(sample_code)
    for stmt in sample_code.split(';'):
        res, abort = js_interpreter.interpret_statement(stmt, {})
    assert res == 30


# Generated at 2022-06-12 19:01:42.589568
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    test = JSInterpreter('')

    # Test case 1
    stmt = ' var k = 0;'
    local_vars = {}
    test.interpret_statement(stmt, local_vars, allow_recursion=10)
    assert local_vars['k'] == 0

    stmt = ' var k = 0;'
    local_vars = {}
    test.interpret_statement(stmt, local_vars, allow_recursion=10)
    assert local_vars['k'] == 0

    stmt = ' var k = 0;'
    local_vars = {}
    test.interpret_statement(stmt, local_vars, allow_recursion=10)
    assert local_vars['k'] == 0

    stmt = ' var k = 0;'
    local_vars

# Generated at 2022-06-12 19:01:52.561682
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    local_vars = dict(
        a=[1, 2, 3, 4, 5],
        b='abcde',
        c=dict(d='abcde', f='fghij')
    )
    interpreter = JSInterpreter(None, dict(c=local_vars['c']))
    assert interpreter.interpret_expression('a', local_vars, 0) == local_vars['a']
    assert interpreter.interpret_expression('b', local_vars, 0) == local_vars['b']

    assert interpreter.interpret_expression('a[0]', local_vars, 0) == local_vars['a'][0]
    assert interpreter.interpret_expression('a[1]', local_vars, 0) == local_vars['a'][1]


# Generated at 2022-06-12 19:02:40.341678
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():

    js = JSInterpreter(None)

    # Some test cases are copied from https://ru.wikibooks.org/wiki/JavaScript/%D0%9A%D0%B0%D1%82%D0%B5%D0%B3%D0%BE%D1%80%D0%B8%D0%B8

    # Test case 1
    #   Input: '3.1415926'
    #  Output: 3.1415926
    res = js.interpret_expression('3.1415926', {})
    assert res == 3.1415926

    # Test case 2
    #   Input: 'a = "Hello, world!";'
    #  Output: 'Hello, world!'
    res = js.interpret_expression('a = "Hello, world!";', {})
   

# Generated at 2022-06-12 19:02:45.133674
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
    function someFunc(a, b, c) {
        return a * b * c;
    }
    '''

    js = JSInterpreter(code)
    func_result = js.call_function('someFunc', 2, 3, 4)
    assert func_result == 24

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-12 19:02:50.904214
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objname = "debuggify"
    code = """
    ta = {
        fa: function(a) {
            return a.length
        },
    }
    """

    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object(objname)
    assert obj.get("fa") != None


# Generated at 2022-06-12 19:03:04.280448
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('var hello = "world";').interpret_expression('hello', {}, 100) == 'world'
    assert JSInterpreter('var hello = "world";').interpret_expression('hello.split("")', {}, 100) == ["w", "o", "r", "l", "d"]
    assert JSInterpreter('var hello = "world";').interpret_expression('hello.length', {}, 100) == 5
    assert JSInterpreter('var hello = "world";var foobar = "bar";').interpret_expression('hello.concat(foobar)', {}, 100) == 'worldbar'
    assert JSInterpreter('var hello = "world";var foobar = "bar";').interpret_expression('hello.concat(foobar).length', {}, 100) == 10

# Generated at 2022-06-12 19:03:14.478352
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-12 19:03:17.049677
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter("")
    jsi.build_function(["a", "b", "c"], "a(b);return c;")(["A", "B", "C"])

# Generated at 2022-06-12 19:03:28.113792
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
    var a = 10;
    var b = function(){
      var c = 20;
      return c;
    };
    b();
    '''
    interpreter = JSInterpreter(code)
    assert interpreter.interpret_expression('10', {}) == 10
    assert interpreter.interpret_expression('a', {}) == 10
    assert interpreter.interpret_expression('a+3', {}) == 13
    assert interpreter.interpret_expression('b()', {}) == 20
    assert interpreter.interpret_expression('a+b()', {}) == 30


if __name__ == '__main__':
    import sys
    import doctest
    if len(sys.argv) == 1:
        sys.exit(doctest.testmod().failed)
    else:
        test_JSInterpreter_interpret_statement

# Generated at 2022-06-12 19:03:35.991147
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print('JSInterpreter test: interpret_expression')
    interpreter = JSInterpreter('')

    # Test for method interpret_expression of class JSInterpreter
    # Test case 1
    expr = 'test'
    local_vars = {'test': 'test'}
    value = interpreter.interpret_expression(expr, local_vars)
    print('JSInterpreter test: interpret_expression')
    if str(value) != 'test':
        print('test case 1 fail')
    else:
        print('test case 1 pass')
    print

    # Test for method interpret_expression of class JSInterpreter
    # Test case 2
    expr = 'test[0]'
    local_vars = {'test': ['te', 'st']}
    value = interpreter.interpret_expression(expr, local_vars)

# Generated at 2022-06-12 19:03:46.214052
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:03:50.557570
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    #test for calling a function
    code = '''var obj = {
    "a":function(){return 0;}
    }'''
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('obj.a') == 0

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-12 19:04:18.499012
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    def test_obj(objname):
        js = JSInterpreter('''function test(obj, key, farg) {
        obj[key](farg);
    }
    test(''' + objname + ''', "test", 1)''')
        obj = js.extract_object(objname)
        assert obj["test"](1) == 2
    test_obj('{"test": function(arg){return arg * 2}}')
    test_obj('{"test" : function(arg){return arg * 2}}')
    test_obj('{ "test" : function(arg){return arg * 2}}')
    test_obj('{ "test" : function(arg){return arg * 2} }')


# Generated at 2022-06-12 19:04:31.266093
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_code = """
        var a = [];
        var b = {'a': [1, 2, 3]};
        function f() {};
        var c = {
            'reverse': function() { a.reverse() },
            'split': function() { return a.join('').split('') },
            'slice': function() { return a.slice(0) },
            'splice': function() { return a.splice(0, 1) },
            'swap': function(x, y) {
                var tmp = a[x];
                a[x] = a[y];
                a[y] = tmp;
            }
        }
    """

# Generated at 2022-06-12 19:04:43.310807
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objname = 'swfArgs'

# Generated at 2022-06-12 19:04:48.337521
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter('function myFunction (a,b,c) { var d = a + b; return c - d;}')
    buildFunction = interpreter.build_function('a,b,c'.split(','), 'var d = a + b; return c - d;')
    assert buildFunction([10, 20, 30]) == 0



# Generated at 2022-06-12 19:04:56.949751
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-12 19:05:01.419904
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_interpreter = JSInterpreter("function test(a, b){return a+b}")
    func = js_interpreter.extract_function("test")
    assert func((1,2)) == 3


# Generated at 2022-06-12 19:05:11.753158
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-12 19:05:18.102884
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = r'''
    function test(abc) {
        return abc;
    }
    function test2(abc) {
        return abc*2;
    }
    '''
    js_interpreter = JSInterpreter(code)
    f1 = js_interpreter.extract_function('test')
    f2 = js_interpreter.extract_function('test2')
    assert f1([123]) == 123
    assert f2(['abc']) == 'abcabc'


# Generated at 2022-06-12 19:05:23.740148
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function() { c = 1; },
            d: function() { c = 2; },
            e: function() { c = 3; },
            f: function() { c = 4; },
            g: function() { c = 5; }
        };
    '''
    js_interpreter = JSInterpreter(code)

    obj = {'b': None, 'd': None, 'e': None, 'f': None, 'g': None}
    result = js_interpreter.extract_object('a')
    assert(result == obj)


# Generated at 2022-06-12 19:05:35.061609
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-12 19:06:00.574298
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter(
        'var swfArgs1 = function(a, b) { return a + b.length; }')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b.length')
    assert func(['a', 'bc']) == 4
    assert func(['a', 'bcde']) == 6
    assert func([1, [1, 2, 3]]) == 4



import unittest


# Generated at 2022-06-12 19:06:10.219826
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('''
        var a = 2; var b = 1; return a + 3;
        var c = a + b;
        var d = a + b; return a + 2;
        var e = a + b;
        var f = a + b; return a + 1;
        return a;
    ''')
    assert js_interpreter.interpret_statement('return a + 3;', {'a': 1, 'b': 1}) == (4, True)
    assert js_interpreter.interpret_statement('return a + 2;', {'a': 1, 'b': 1}) == (3, True)
    assert js_interpreter.interpret_statement('return a + 1;', {'a': 1, 'b': 1}) == (2, True)
    assert js

# Generated at 2022-06-12 19:06:20.294942
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function() {return 1},
            "b": function(x) {return x + 2;},
            "c": function(x, y) {return [x, y];},
        };
    '''
    jsinterpreter = JSInterpreter(code)
    obj = jsinterpreter.extract_object('obj')
    assert obj == {
        'a': lambda: 1,
        'b': lambda x: x + 2,
        'c': lambda x, y: [x, y],
    }


# Generated at 2022-06-12 19:06:27.324062
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('var x = 10;')
    local_vars = {'x': None}
    assert js_interpreter.interpret_expression('x', local_vars, 10) == 10
    assert js_interpreter.interpret_expression('x', local_vars, 10) == 10
    assert js_interpreter.interpret_expression('x + 10', local_vars, 10) == 20
    assert js_interpreter.interpret_expression('x**2', local_vars, 10) == 100
    assert js_interpreter.interpret_expression('x / 2', local_vars, 10) == 5
    assert js_interpreter.interpret_expression('x > 1', local_vars, 10) == True

# Generated at 2022-06-12 19:06:39.557229
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    s = '''
    function foo(){
        return 10;
    }
    var bar = {
        "a":1,
        b:[1,2],
        c:function(){
            return 3;
        },
        d:function(x){
            return x;
        },
        e:function(x){
            return x*x;
        },
        f:function(x,y){
            return x*y;
        }
    };
    '''
    it = JSInterpreter(s)
    bar = it.extract_object('bar')
    assert bar['a'] == 1
    assert bar['b'][0] == 1 and bar['b'][1] == 2
    assert bar['c']() == 3
    assert bar['d'](4) == 4

# Generated at 2022-06-12 19:06:52.059157
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r'''var dg=function(a,b,c){this.f=a;this.c=b;this.g=c};dg.prototype.l=function(a){var b=a.c;if(!b.length)return null;var c=this.w();a.c=a.c.substr(c.length);return c};dg.prototype.w=function(){return this.g.length?this.g[0]:this.c.length?this.c[0]:null};dg.prototype.toString=function(){return"tokenizer"};
    '''
    jsinterpreter = JSInterpreter(code)
    obj = jsinterpreter.extract_object('dg')
    assert obj.get('l') is not None


# Generated at 2022-06-12 19:07:00.646341
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Test 1
    jsInterpreter = JSInterpreter(
        r'''
        var $=function(a){return void 0!==a?document.getElementById(a):null};
        var window={};
        function ytcenter() {
        var ytcenter= {};
        ytcenter.page={};
        ytcenter.page.Type=null;
        ytcenter.page.subpage=null;
        ytcenter.page.subpageName=null;
        ytcenter.page.subpageGroup=null;
        return ytcenter;
        ''')
    extracted_object = jsInterpreter.extract_object('ytcenter')
    assert extracted_object == {}, 'test1 fail'
    # Test 2

# Generated at 2022-06-12 19:07:10.869296
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def test_interpret(expr, vars, expected):
        js = JSInterpreter('')
        result = js.interpret_expression(expr, vars)
        assert result == expected
    # evaluate a simple expression
    test_interpret('1 + 1', dict(), 2)
    # evaluate a more complex expression
    test_interpret('a + 1', dict(a=1), 2)
    # evaluate a string
    test_interpret('"1 + 1"', dict(), '1 + 1')
    # evaluate a string
    test_interpret('"1 < 1"', dict(), '1 < 1')
    # evaluate a None value
    test_interpret('', dict(), None)
    # evaluate a function call as an expression

# Generated at 2022-06-12 19:07:18.638086
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    argnames = ["a", "b", "c"]
    code = ';'.join([
        "return a+b+c",
    ])
    resf = js_interpreter.build_function(argnames, code)
    assert resf([1,2,3]) == 6
    resf = js_interpreter.build_function(argnames, code)
    assert resf([2,3,1]) == 6

# Generated at 2022-06-12 19:07:24.475858
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Data
    js = """
        var d = function(x) { return b[x] };
        var b = [3, 4];
    """
    objects = {
        'b': [3, 4],
    }
    expected = 4
    # Test
    actual = JSInterpreter(js, objects).interpret_expression('d(1)', {})
    # Result
    assert actual == expected

# Generated at 2022-06-12 19:07:45.468904
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert 'var' in JSInterpreter("var a;a=5;").build_function(
        None, 'a=5')(None)


if __name__ == '__main__':
    from .common import main
    main(JSInterpreter)

# Generated at 2022-06-12 19:07:56.079814
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    import sys
    assert sys.version_info >= (3, 0)
    js_code = '''
        var o = {
            a: function(x){
                return x * 2;
            },
            b: function(f, x){
                return f(x);
            },
            c: function(){
                return 3;
            },
            d: function(x, y){
                return x + y;
            },
            e: 5
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('o.a', 2) == 4
    assert js_interpreter.call_function('o.b', lambda x: x * 3, 2) == 6

# Generated at 2022-06-12 19:08:06.400291
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    objname = 'test_objname'
    funcname = 'test_funcname'
    code = '''{
        function test_objname(){
        }
        test_objname = function(){
        }
        var test_objname = function(){
        }
    }'''
    ji = JSInterpreter(code)
    assert ji.extract_function(objname) is not None
    # Now test 3 different variants of the same function
    # First one uses the standard syntax
    func_m = re.match(r'''(?x)
                function\s+%s\s*\((?P<args>[^)]*)\)\s*
                \{(?P<code>[^}]+)\}''' % re.escape(funcname), code)

# Generated at 2022-06-12 19:08:14.581678
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter(None)

    local_vars = {
        'a': 2,
        'x': [
            {'foo': 'bar'},
            {'baz': 'qux'}
        ],
        'b': {
            'c': 'd'
        },
        'z': 'foobar',
    }


# Generated at 2022-06-12 19:08:18.851362
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert not JSInterpreter('').interpret_expression('', {})

    assert JSInterpreter('').interpret_expression('1', {}) == 1

    assert JSInterpreter('').interpret_expression(
        '1+2', {}) == 3

    assert JSInterpreter('').interpret_expression(
        '1+2*(3+4)', {}) == 15

    assert JSInterpreter('').interpret_expression(
        'v', {'v': 'a'}) == 'a'

    assert JSInterpreter('').interpret_expression(
        'v[1]', {'v': 'abc'}) == 'b'

    assert JSInterpreter('').interpret_expression(
        'v.lengt', {'v': 'abc'}) == 3


# Generated at 2022-06-12 19:08:26.886747
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    global_vars = {
        'url': "http://www.cntv.cn/2017/08/31/VIDEaG7ByLJjHMRnm7VX8P9J170831.shtml"
    }

# Generated at 2022-06-12 19:08:39.118437
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    function_code = (
        'function w(a){'
        'var b=2;'
        'a*=(b+3)'
        'return a'
        '};'
        'var y=(n=5);'
        'y+=(n-3);'
        'function ww(a){'
        'var b=2;'
        'a*=(b+3)'
        'return a'
        '};'
    )
    local_vars = {'b' : 2}
    interpreter = JSInterpreter(function_code)
    for i in range(0, 100):
        res = interpreter.interpret_expression('y', local_vars)
        assert res == 2, 'JSInterpreter test 1 failed'
        res = interpreter.interpret_expression('y++', local_vars)

# Generated at 2022-06-12 19:08:50.558672
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter(None)
    # Test the method without recursion
    assert js.interpret_expression('f()', {'f': lambda: 1}) == 1
    assert js.interpret_expression(
        '!f()', {'f': lambda: False}) == True

    # Test the method with recursion
    assert js.interpret_expression(
        '"" + f()', {'f': lambda: 'f()'}) == 'f()'

    assert js.interpret_expression(
        '"" + f()', {'f': lambda: 'a'}) == 'a'

    assert js.interpret_expression('f()', {'f': lambda: '"" + f()'}) == '"" + f()'

# Generated at 2022-06-12 19:08:55.385631
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
        var aa = function (a,b,c) {
            return a+b+c;
        }
    """
    js = JSInterpreter(code)
    f = js.extract_function("aa")
    assert f((1, 2, 3)) == 6

    f = js.extract_function("unexist")



# Generated at 2022-06-12 19:09:06.095321
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = """
        a = {};
        a.b = function(){};
        a.b.c = [];
        a.b.c[1] = 1;
        a.b.c[2] = 2;
        a.b.c[3] = 3;
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.interpret_expression('b.c[2]', {'b': js_interpreter._objects['a']['b']}) == 2
    assert js_interpreter.interpret_expression('("a[\\\\]".split("\\\\")[0] + "a[]")', {}) == 'a[]'
    assert js_interpreter.interpret_expression("a['toString'](2)", {'a': 1}) == 1
