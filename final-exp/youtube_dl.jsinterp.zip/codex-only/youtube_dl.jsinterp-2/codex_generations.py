

# Generated at 2022-06-24 13:50:06.700924
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Function that reverses a string
    js = r"""
            reverse:function(a){a=a.split("");a=a.reverse();a=a.join("");return a}
    """
    obj = {}
    js_interpreter = JSInterpreter(js, obj)
    reverse_func = js_interpreter.extract_function("reverse")
    assert reverse_func(("Hello",)) == "olleH"

    # Function that encodes a string

# Generated at 2022-06-24 13:50:12.139407
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def check(funcname, argnames, code, expected):
        try:
            f = JSInterpreter('', {}).build_function(argnames, code)
            res = f(expected[:-1])
            assert res == expected[-1]
        except Exception as e:
            print(funcname, argnames, code, expected)
            raise e

    check('a', ['x'], 'x=x>>0;return x', [1, 1])
    check('a', ['x'], 'x=x>>0;return x + 3', [1, 4])
    check('a', ['x'], 'x=x>>0;return x;x=3;return "nope"', [1, 1])
    check('a', ['x', 'y'], 'return x&y', [1, 2, 0])


# Generated at 2022-06-24 13:50:20.346904
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Test function calls with multiple arguments
    jsinterpreter = JSInterpreter('''
        function testFunction(arg1, arg2) {
            return arg1 + "," + arg2;
        }
    ''')
    assert(jsinterpreter.call_function('testFunction', 'a', 'b') == 'a,b')
    # Test function calls with no arguments
    jsinterpreter = JSInterpreter('''
        function testFunction() {
            return "empty";
        }
    ''')
    assert(jsinterpreter.call_function('testFunction') == 'empty')

# Generated at 2022-06-24 13:50:29.312015
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterpreter = JSInterpreter('')
    assert jsinterpreter.interpret_expression('', None) == None
    assert jsinterpreter.interpret_expression('0', None) == 0
    assert jsinterpreter.interpret_expression('0;', None) == 0
    assert jsinterpreter.interpret_expression('abc', {'abc':'abc'}) == 'abc'
    assert jsinterpreter.interpret_expression('abc[0]', {'abc':'abc'}) == 'a'
    assert jsinterpreter.interpret_expression('\r\n0', None) == 0
    assert jsinterpreter.interpret_expression('0\r\n', None) == 0
    assert jsinterpreter.interpret_expression('\r\n0\r\n', None) == 0
    assert jsinterpreter

# Generated at 2022-06-24 13:50:33.324051
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
    var w = {};
    w.xt = function(a) {
        return 123;
    };
    '''
    interpreter = JSInterpreter(js_code)
    f = interpreter.extract_function('w.xt')
    assert f((1,)) == 123

# Generated at 2022-06-24 13:50:42.128534
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    for name, jsinterp in test_JSInterpreter_extract_function.jsinterps.items():
        print(name, ": ", jsinterp.interpret_statement('var a = 7;', {}))
        print(name, ": ", jsinterp.interpret_statement('var a = b;', {'b': 7}))
        print(name, ": ", jsinterp.interpret_statement('var a = 7 + b;', {'b': 7}))
        print(name, ": ", jsinterp.interpret_statement('var a = 7 + b + 3;', {'b': 7}))
        print(name, ": ", jsinterp.interpret_statement('var a = b + 3;', {'b': 7}))

# Generated at 2022-06-24 13:50:49.856092
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter("""function test1(a,b) {
        return a + b;
    }""")
    function = interpreter.build_function(["a", "b"], "return a + b;")
    assert function([1,2]) == 3

    interpreter = JSInterpreter("""function test2(a,b) {
        return a - b;
    }""")
    function = interpreter.build_function(["a", "b"], "return a - b;")
    assert function([1,2]) == -1

# Generated at 2022-06-24 13:50:57.556840
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:51:02.166163
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    local_vars = { 'a':2, 'b':3 }
    method_resf = js_interpreter.build_function(
        argnames=['a', 'b'],
        code='var c = a + b; c;')
    res = method_resf([2, 3])
    assert(res == 5)


# Generated at 2022-06-24 13:51:12.884896
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    obj = {}
    obj_m = re.search(
        r'''(?x)
            Test\s*=\s*{\s*
                (?P<fields>(%s\s*:\s*function\s*\(.*?\)\s*{.*?}(?:,\s*)?)*)
            }\s*;
        ''',
        "Test = {\r\nfunction1:function(a,b){return a-b},\r\nfunction2:function(){return 10}\r\n}",
        )
    fields = obj_m.group('fields')

# Generated at 2022-06-24 13:51:25.475375
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    obj = JSInterpreter('')

    # Test and, or and not
    assert obj.interpret_statement('(a || b)', {'a': 0, 'b': 2}) == (0, False)
    assert obj.interpret_statement('(a || b)', {'a': '3', 'b': 2}) == ('3', False)
    assert obj.interpret_statement('(a && 3)', {'a': 0}) == (0, False)
    assert obj.interpret_statement('!a', {'a': 0}) == (1, False)
    assert obj.interpret_statement('!a', {'a': ''}) == (1, False)
    assert obj.interpret_statement('!a', {'a': '0'}) == (0, False)

# Generated at 2022-06-24 13:51:34.279527
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = """
    function f(a,b,c){
			var e=a[0];
			var f=a[1];
			var g=3;
			var h=f;
			var d=h+1;
			var k=d+6;
			return function(p,q){
				return d+g+h;
			};
		}
		f(7,8,9);
    """
    objects = {}
    js_interpreter = JSInterpreter(code, objects)
    # Test statement with assignment
    v, abort = js_interpreter.interpret_statement("var e=a[0];", {"a":[4,4],"b":4,"c":4})
    assert(v == 4)

# Generated at 2022-06-24 13:51:43.576120
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
        var obj = {
            x: function(a, b) {
                return a + b;
            },
            y: function(a) {
                return a;
            }
        }"""
    interp = JSInterpreter(code)
    x = interp.build_function(['a', 'b'], 'return a + b')
    assert x([1, 2]) == 3
    y = interp.build_function(['a'], 'return a')
    assert y([1]) == 1


# Generated at 2022-06-24 13:51:49.495746
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = JSInterpreter('''
        var myObj = {
            bar: function(x, y) {
                return x + y;
            },
            baz: 'hoge'
        }
    ''')
    myObj = js.extract_object('myObj')
    assert myObj['bar'](2, 3) == 5
    assert myObj['baz'] == 'hoge'


# Generated at 2022-06-24 13:51:57.417675
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
    function a(abc){
        var def = "abc";
        var lmn = "def";
        var opq = {
            rst: function(uvw) {
                console.log("rst",uvw);
                return def + def;
            }
        };
        if (opq.rst("xyz") == lmn + lmn) {
            return def;
        } else {
            return lmn;
        }
    }
    '''

    js_interpreter = JSInterpreter(code)
    func = js_interpreter.extract_function("a")
    assert func(("xyz",)) == "abc"
    assert func(("xyz",)) == "abc"
    assert func(("aaa",)) == "def"


# Generated at 2022-06-24 13:52:00.761040
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        a = {}
        a.b = 1
        a.c = function () {}
        d = {
            foo: function (x) { return x + 1; },
            bar: function (y) { return y - 1; }
        }
        '''
    i = JSInterpreter(code)
    obj = i.extract_object('d')
    assert obj['foo'](1) == 2
    assert obj['bar'](2) == 1


# Generated at 2022-06-24 13:52:12.366838
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function f1(a){
            return a + 1;
        }
        f2 = function(a){
            return a + 1;
        }
        var f3 = function(a){
            return a + 1;
        }
        '''
    for f in ['f1', 'f2', 'f3']:
        f = JSInterpreter(code).extract_function(f)
        assert f([1]) == 2

    code = '''
        function f1(a, b){
            return a + b;
        }
        f2 = function(a, b){
            return a + b;
        }
        var f3 = function(a, b){
            return a + b;
        }
        '''

# Generated at 2022-06-24 13:52:20.092390
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    stmt = '''
        function b(a) {
            a = a.slice(2);
            a = a.reverse();
            a = a.slice(3);
            a = a.reverse();
            return a.join("")
        }
    '''
    args = ['abcde', 'abcd']
    for arg in args:
        jsi = JSInterpreter(stmt)
        res = jsi.call_function('b', arg)
        assert res == arg[::-1]

        stmt = '''
            function b(a) {
                a = a.split("");
                a = a.reverse();
                a = a.slice(3);
                a = a.reverse();
                return a.join("")
            }
        '''

# Generated at 2022-06-24 13:52:31.720901
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:52:38.528999
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    f("a");
    e.b = {
        c: function(a) {
            f("c");
            return function() {
                f("d")
            }
        },
        d: function() {
            f("e")
        }
    }
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('e.b')
    assert obj['c']('a')() == 'd'
    assert obj['d']() == 'e'


# Generated at 2022-06-24 13:52:45.398409
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    expr = '''
        var v2 = new Array(0x100);
        var enkripsi = "";
        for (var i = 0; i < v1.length; i++) {
            v2[i] = v1.charCodeAt(i);
            v2[i] = (v2[i] + 14) % 0x100;
            enkripsi = enkripsi + String.fromCharCode(v2[i]);
        }
        return enkripsi;
    '''
    local_vars = {'v1': "i'm a string"}
    jsi = JSInterpreter(expr)
    v, ab = jsi.interpret_statement(expr, local_vars)
    print(v, ab)


# Generated at 2022-06-24 13:52:55.087916
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('function test_function(){return "test";}')
    assert not jsi.code
    assert jsi.extract_function('test_function')() == 'test'
    assert jsi.interpret_expression('test_function()', {}) == 'test'
    assert jsi.interpret_expression(' "test_string" ', {}) == 'test_string'
    assert jsi.interpret_expression('(function () {return "test";})()', {}) == 'test'
    assert jsi.interpret_expression('12', {}) == 12
    assert jsi.interpret_expression('[1,2,3,4][2]', {}) == 3
    assert jsi.interpret_expression('[1,2,3,4]["length"]', {}) == 4

# Generated at 2022-06-24 13:53:05.765990
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
        function func(foo, bar, baz) {
            var a = foo + bar;
            var b = bar * bar + baz;
            return a + b;
        }'''
    interpreter = JSInterpreter(js_code)
    func = interpreter.build_function(
        ['foo', 'bar', 'baz'],
        '''
            var a = foo + bar;
            var b = bar * bar + baz;
            return a + b;
        ''')
    assert func((1, 2, 3)) == 9
    assert func((4, 5, 6)) == 42

# Generated at 2022-06-24 13:53:15.539456
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Primitive value test
    def _interpret_expr(expr):
        return JSInterpreter('', {}).interpret_expression(expr, {})
    assert _interpret_expr('1') == 1
    assert _interpret_expr('1 + 2') == 1 + 2
    assert _interpret_expr('2 - 1') == 2 - 1
    assert _interpret_expr('2 * 3') == 2 * 3
    assert _interpret_expr('10 / 5') == 10 / 5
    assert _interpret_expr('10 % 5') == 10 % 5
    assert _interpret_expr('-2') == -2
    assert _interpret_expr('-10 + 5') == -10 + 5
    assert _interpret_expr('"a string"') == 'a string'

# Generated at 2022-06-24 13:53:22.582910
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test: get stmt, expected and args from file
    f = open("test_data.txt", "r")
    stmt = f.readline()
    expected = f.readline()
    arg1 = f.readline()
    arg2 = f.readline()
    arg3 = f.readline()
    f.close()
    
    # Convert args to objects
    obj1 = json.loads(arg1)
    obj2 = json.loads(arg2)
    obj3 = json.loads(arg3)
    
    # Set up a JSInterpreter and pass in test args
    js_interpreter = JSInterpreter("", {arg1:obj1, arg2:obj2, arg3:obj3})
    
    # Convert expected to expected object
    expected = json.loads(expected)


# Generated at 2022-06-24 13:53:31.119989
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var obj1={
            a:function(x,y){
                return x+y;
            },
            b:function(x,y){
                return x-y;
            },
            c:function(x,y){
                return x*y;
            },
            d:function(x,y){
                return x/y;
            },
            e:function(x,y){
                return y-x;
            }
        }
    '''
    js = JSInterpreter(code)
    assert js.interpret_expression('obj1.a(1,2)', {}) == 3
    assert js.interpret_expression('obj1.e(1,2)', {}) == 1


# Generated at 2022-06-24 13:53:40.030323
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter("""var a = 0;
    ;;;;var b = 1;
    var c = 6;var d = 10;
    function test(b, c) {
        a = 7;
        var e = b + c;
        return e;
    }
    """)
    args = ('b', 'c')
    code = """a = 7;
    var e = b + c;
    return e;"""
    f = jsi.build_function(args, code)
    assert f((1, 2)) == 3

# Generated at 2022-06-24 13:53:52.412931
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:53:59.515523
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test_func(name, args, code, *argv):
        js_interpreter = JSInterpreter('')
        f = js_interpreter.build_function(args, code)
        assert f(argv) == None

    test_func('test_name', ['a'], 'a=a+2', 3)
    test_func('test_name', ['a', 'b', 'c'], 'a=b+c', 1, 2, 3)
    test_func('test_name', ['a', 'b', 'c'], 'a=b+c', 1, '2', 3)
    test_func('test_name', ['this', 'a'], 'this.a = a', {}, '1')

# Generated at 2022-06-24 13:54:09.900690
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:54:15.286838
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''foo = function(a,b) {
        var c = a + b;
        while (true) {
            c = c + 2;
            var d = c - b;
            if (d > b) {
                break;
            }
        }
        return c + d;
    }'''
    ret = JSInterpreter(code).call_function('foo', 2, 3)
    print("ret")
    print(ret)


# Generated at 2022-06-24 13:54:27.025622
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:54:36.169385
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = """
        var obj123 = {
            "foo1": function(){
                return 1;
            },
            "foo2": function(){
                return 2;
            }
        }
        var obj321 = {
            "foo1": function(){
                return 3;
            },
            "foo2": function(){
                return 4;
            }
        }

        var obj = {
            "a": 1,
            "b": {
                "c": "str",
                "d": [1, 2, 3]
            },
            "e": function(a, b, c) {
                var foo = [a, b, c];
                return foo;
            }
        }
    """
    jsinter = JSInterpreter(js_code)

# Generated at 2022-06-24 13:54:42.241353
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter('', {}).build_function([], 'return 1;')() == 1
    assert JSInterpreter('', {}).build_function(['a'], 'return 1;')(1) == 1
    assert JSInterpreter('', {}).build_function(['a'], 'return a;')(1) == 1
    assert JSInterpreter('', {}).build_function(['a'], 'return a + 1;')(1) == 2
    assert JSInterpreter('', {}).build_function(['a'], 'return a + a;')(1) == 2

# Generated at 2022-06-24 13:54:51.925888
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # source code of function
    code = (
        r'function test(a, b) {'
        r' var c;'
        r' a = "abcd";'
        r' b = [1, [2, 3]];'
        r' c = {e: 4, f: b};'
        r' b[0] = a.split("");'
        r' b[1][1] = b[1][0] ^ 0x1f;'
        r' return b[0].join("") + String.fromCharCode(b[1][1]);'
        r'}'
    )
    # string to test
    s = 'test("arg1", ["arg2", [3, 5]]);'
    # expected result
    expected = 'abcd2'
    # initialize interpreter

# Generated at 2022-06-24 13:55:01.309213
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:55:08.381929
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function function_js(a, b){
            var c = a + b
            return c
        }'''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('function_js')
    assert f((1, 2)) == 3

    code = '''
        var function_js2 = function(a, b){
            var c = a + b
            return c
        }'''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('function_js2')
    assert f((1, 2)) == 3


# Generated at 2022-06-24 13:55:19.016803
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:55:31.234197
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    def do_test(js, expected):
        assert JSInterpreter('function f(){%s}' % js).interpret_statement(js, {}) == expected
    do_test('a=1;b=2;c=a+b;return c', (3, True))
    do_test('a=1;var b=2;c=a+b;return c', (3, True))
    do_test('return a', (None, True))
    do_test('return a+3', (3, True))
    do_test('a=3', (3, False))
    do_test('a=3;b=4', (4, False))
    do_test('a=1;b=2;c=a+b;a+b', (3, False))

# Generated at 2022-06-24 13:55:42.940651
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:55:52.980804
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    func = JSInterpreter('').build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = JSInterpreter('').build_function(['a'], 'return [1, a];')
    assert func((2,)) == [1, 2]

    func = JSInterpreter('').build_function(
        ['a', 'b'],
        '''
        var c = a + b;
        return c * c;
        '''
    )
    assert func((1, 2)) == 9


# Generated at 2022-06-24 13:56:03.692295
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_interp = JSInterpreter('''
        function func1(a,b,c) {d=3; return c}
        var func2 = function(a,b,c) {d=3; return c}
        other_code();
        var func3 = function(a,b,c) {d=3; return c}
        function func4(a,b,c) {d=3; return c}
    ''')
    assert js_interp.extract_function("func1")("a", "b", "c") == "c"
    assert js_interp.extract_function("func2")("a", "b", "c") == "c"
    assert js_interp.extract_function("func3")("a", "b", "c") == "c"
    assert js

# Generated at 2022-06-24 13:56:11.239419
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
	
	# Test 1
	argnames = ['x', 'y']
	code = 'return x * y;'
	
	test_function = JSInterpreter('').build_function(argnames, code)
	
	assert test_function((2, 2)) == 4
	assert test_function((2, 3)) == 6
	
	# Test 2
	argnames = ['x']
	code = 'return typeof(x);'
	
	test_function = JSInterpreter('').build_function(argnames, code)
	
	assert test_function(('string',)) == 'string'
	assert test_function(([],)) == 'object'



# Generated at 2022-06-24 13:56:22.403670
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:56:34.378805
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
	# test case 1: var a = 5;
	s = 'var a = 5;'
	x = JSInterpreter(s)
	y = x.interpret_statement(s, {'a': 5}, 100)
	assert y == (5, False)
	# test case 2: return a;
	s = 'return a;'
	y = x.interpret_statement(s, {'a': 5}, 100)
	assert y == (5, True)
	# test case 3: var b = a + 10; return b - 5;
	s = 'var b = a + 10; return b - 5;'
	y = x.interpret_statement(s, {'a': 5}, 100)
	assert y == (10, True)


# Generated at 2022-06-24 13:56:44.084366
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = """
        e("a", "b", "c")
        f("a", 2, "c")
    """
    objects = {'e': 0, 'f': 1}
    i = JSInterpreter(code, objects)
    assert i.interpret_expression("e(\"a\", \"b\", \"c\")", {}) == 0
    assert i.interpret_expression("f(\"a\", 2, \"c\")", {}) == 1
    assert i.interpret_statement("return e(\"a\", \"b\", \"c\");", {})[0] == 0

if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-24 13:56:48.885821
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_interpreter = JSInterpreter('''
        function f(a, b) {
            return a + b;
        }
    ''')
    def f(a, b):
        return a + b
    assert js_interpreter.extract_function('f') == f


# Generated at 2022-06-24 13:56:52.983448
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('''
    var a = 1;
    var b = 2;
    var f1 = function(x, y) {
        a = x;
        return a + y;
    }
    ''')
    f1 = js.build_function(['x', 'y'], '''
    a = x;
    return a + y;
    ''')
    assert f1(5,6) == 11
    assert js._objects['a'] == 5



# Generated at 2022-06-24 13:57:03.653198
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = (
        "function func1(a, b) {"
        "var c = 1, d = 'string', e = (1 + 2), f = a.split(''), g = f.slice(1);"
        "return c + d + e + f + g + a + b;"
        "}"
    )
    test_jsi = JSInterpreter(js_code)
    func1 = test_jsi.build_function(['a', 'b'], "var c = 1, d = 'string', e = (1 + 2), f = a.split(''), g = f.slice(1); return c + d + e + f + g + a + b;")

# Generated at 2022-06-24 13:57:10.045748
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('')
    assert interpreter.interpret_expression('1') == 1
    assert interpreter.interpret_expression('1+2') == 3
    assert interpreter.interpret_expression('1+2*3') == 7
    assert interpreter.interpret_expression('1+2*(3+4)') == 15
    assert interpreter.interpret_expression('1+2*3+4') == 11
    assert interpreter.interpret_expression('(1+2)*3+4') == 13
    assert interpreter.interpret_expression('"a"+"b"') == "ab"
    assert interpreter.interpret_expression('["a"]+["b"]') == ["ab"]
    assert interpreter.interpret_expression('["ab"]') == ["ab"]
    assert interpreter.interpret_expression('1/-1') == -1

# Generated at 2022-06-24 13:57:15.446177
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''var a = {b: function(p){
        return p + 1;
    }};
    var c = {d: function(p){return p - 1;}};'''
    jsi = JSInterpreter(code)
    assert jsi.extract_object('a')['b'](5) == 6
    assert jsi.extract_object('c')['d'](5) == 4


# Generated at 2022-06-24 13:57:22.170710
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:57:32.884002
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:57:44.277871
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        a = {
            b: function (arg1) {
                return arg1 * 2
            },
            "c": function (arg1, arg2) {
                return arg1 + arg2
            }
        }
        obj = {
            "func1": function(arg1, arg2) {
                return arg1 + arg2
            },
            "func2": function(arg1, arg2) {
                return arg1 * arg2
            },
            "func3": function(arg1, arg2) {
                return arg1 - arg2
            }
        }
        '''

    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object("obj")
    assert obj["func1"]((1, 2)) == 3

# Generated at 2022-06-24 13:57:49.650596
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = r'''var obj = {
        'func': function(a, b) {
            return a + b;
        }
    };
    function func(a, b, c) {
        return obj.func(a, b) * c;
    }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('func', 1, 2, 3) == 9

    js_code = r'''var obj = {
        'func': function(a, b) {
            return a + b;
        }
    };
    function func(a, b, c) {
        return obj.func(a, b) * c;
    }
    '''
    js_interpreter = JSInterpreter(js_code)


# Generated at 2022-06-24 13:57:54.016543
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(['a', 'b', 'c'], 'return a+b+c')([1, 2, 3]) == 6


if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-24 13:58:03.415584
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('''var obj = {
        "a": 42,
        "b": 3,
        "c": function(args) {
            return "c was called with " + args.join();
        },
        "d": function(args) {
            return args[0] + args[1];
        },
        "e": function(args) {
            return {
                "e": "e"
            };
        },
        "f": function(args) {
            return "f";
        },
        "g": function(args) {
            return 7;
        }
    };''')
    assert jsi.interpret_expression('obj.a', {}) == 42
    assert jsi.interpret_expression('obj["a"]', {}) == 42

# Generated at 2022-06-24 13:58:09.585502
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        this.fn = function(arg1, arg2){
            return arg1 + arg2;
        };

        this.obj = {
            prop1: 1,
            func: function(arg1, arg2){
                return arg1 + arg2;
            }
        };
    """

    obj = JSInterpreter(code).extract_object('obj')
    assert obj['prop1'] == 1
    assert obj['func'](4, 5) == 9


# Generated at 2022-06-24 13:58:20.790311
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        var calculateSignature = function(s, sigParts, t) {
            if (sigParts != null) {
                for (var x = 0; x < sigParts.length; x++) {
                    s = s.split(sigParts[x]).join(t[x])
                }
            }
            return s;
        };
    '''
    js_interpreter = JSInterpreter(code)
    sig = js_interpreter.call_function(
        'calculateSignature',
        'abc',
        ['c', 'a'],
        ['1', '2'])
    assert sig == '2bc'
# End unit test

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-24 13:58:29.889291
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
        var a = 0,
            b = function() {
                return 1;
            },
            c = function(a, b) {
                return a + b;
            };
    '''
    js_interpreter = JSInterpreter(js_code)
    assert callable(js_interpreter.extract_function('a'))
    assert js_interpreter.call_function('a') == 0
    assert callable(js_interpreter.extract_function('b'))
    assert js_interpreter.call_function('b') == 1
    assert callable(js_interpreter.extract_function('c'))
    assert js_interpreter.call_function('c', 2, 3) == 5

# Generated at 2022-06-24 13:58:34.666786
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objects = JSInterpreter('''
        a={};a.b={c:function(d){return d+1}};
    ''').extract_object('a')
    assert objects == {'b': {'c': lambda d: d + 1}}, objects


# Generated at 2022-06-24 13:58:38.652146
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsi = JSInterpreter(code='var x = 3; function f(a) { return a + x; }; var g = f(x); var y = 4;')
    assert jsi.call_function('f', 0) == 3


# Generated at 2022-06-24 13:58:44.510467
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
    function add(a,b){
        return a+b
    }
    """
    js = JSInterpreter(js_code)
    assert js.call_function('add', 2, 3) == 5
    assert js.call_function('add', [2, 3]) == 5
    assert js.call_function('add', 12, 18) == 30


# Generated at 2022-06-24 13:58:49.585935
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:59:01.361591
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = r'''
        var a = {
            b: function(c) {
                return c;
            },
            d: function(b, c) {
                return b + c;
            },
            f: function(a, b, c) {
                d = a;
                e = b;
                return f;
            }
        }
    '''
    objects = {}
    js = JSInterpreter(code, objects)
    assert js.call_function('a.b', 5) == 5
    assert js.call_function('a.d', 3,2) == 5
    test_a = [1,2,3]
    test_b = [2,3,4]
    assert js.call_function(r"a.f", test_a, test_b) == objects['f']



# Generated at 2022-06-24 13:59:11.146074
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():

    def compare_extracted_func(func_str, func_name, arg_num, func_content):
        interpreter = JSInterpreter(func_str)
        extracted_func = interpreter.extract_function(func_name)

        # build the original function from the original javascript code
        code = 'def func(' + 'arg, ' * arg_num
        code += ')' + ':' + '\t' + func_content
        local_namespace = {}
        exec(code, {}, local_namespace)
        original_func = local_namespace['func']

        # test the extracted function
        assert extracted_func(*[i for i in range(arg_num)]) == original_func(*[i for i in range(arg_num)])

    # test a one-line function

# Generated at 2022-06-24 13:59:21.390288
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test method interpret_expression with sample
    # Sample 1: simple expression
    js_interpreter = JSInterpreter(
        code="""var a = 10;""")
    local_vars = {'a': 9}
    allow_recursion = 100
    expr = "a + 2"
    assert 11 == js_interpreter.interpret_expression(expr, local_vars, allow_recursion)

    # Sample 2: complex expression
    local_vars = {'a': 1, 'b': 1}
    allow_recursion = 100
    expr = "((a+b)*3/2) % 4"
    assert 2 == js_interpreter.interpret_expression(expr, local_vars, allow_recursion)



# Generated at 2022-06-24 13:59:30.829095
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    """test method call_function of class JSInterpreter"""
    class JSInterpreterTest(JSInterpreter):
        def __init__(self, code, objects=None):
            if objects is None:
                objects = {}
            super(JSInterpreterTest, self).__init__(code, objects)

        def build_function(self, argnames, code):
            def resf(args):
                local_vars = dict(zip(argnames, args))
                for stmt in code.split(';'):
                    res, abort = self.interpret_statement(stmt, local_vars)
                    if abort:
                        break
                return res
            return resf

    code = '''
        function test(a) {
            return a * 100;
        }
    '''

    result = JSInterpreter

# Generated at 2022-06-24 13:59:42.286266
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    js_interpreter.extract_function = lambda name : lambda args: name+'func'
    js_interpreter.extract_object = lambda name : {'prop':'objprop'}
    assert js_interpreter.interpret_statement('return;', locals())[0] is None
    assert js_interpreter.interpret_statement('return;', locals())[1] is True
    assert js_interpreter.interpret_statement('v = "test";', locals())[0] == 'test'
    assert js_interpreter.interpret_statement('return "test";', locals())[0] == 'test'
    assert js_interpreter.interpret_statement('return "test";', locals())[1] is True
    assert js_interpreter.interpret

# Generated at 2022-06-24 13:59:53.649894
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test for expressions
    js_interpreter = JSInterpreter('', {})
    assert js_interpreter.interpret_expression('var', {}) == None
    assert js_interpreter.interpret_expression('a', {'a': 1}) == 1
    assert js_interpreter.interpret_expression('a + b', {'a': 1, 'b': 1}) == 2
    assert js_interpreter.interpret_expression('a + 1', {'a': 1}) == 2
    assert js_interpreter.interpret_expression('a + b', {'a': 1, 'b': 1}) == 2
    assert js_interpreter.interpret_expression('a + b', {'a': 1, 'b': 1}) == 2

# Generated at 2022-06-24 14:00:00.415025
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    class Extractor(object):
        def __init__(self, url):
            self._url = url

        def extract(self):
            from .youtube import YoutubeIE
            from .youtube_dl.utils import ExtractorError
            # Youtube:
            # {
            #   "__sc": "null",
            #   "__wts": "true",
            #   "__wrg": "null",
            #   "__wga": "null",
            #   "__wga_token": "null",
            #   "__wgl": "null",
            #   "__wgl_token": "null"
            # };

            # Bilibili
            # {
            #   "__cmt": "null",
            #   "__cmt_token": "null",
            #   "__playinfo_expr