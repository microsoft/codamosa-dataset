

# Generated at 2022-06-24 13:50:11.160564
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    test_extracted_function_name = 'test_function'
    test_extracted_function_args = ['test_arg']
    test_extracted_function_code = 'test_code'

    test_code = (
        'function '+test_extracted_function_name+'('+
            ''.join(e+', ' for e in test_extracted_function_args)[:-2]+
        ') {'+test_extracted_function_code+'}')

    test_jsinterpreter = JSInterpreter(test_code)
    test_extracted_function = test_jsinterpreter.extract_function(test_extracted_function_name)

    assert test_extracted_function
    assert test_extracted_function_name in test_code
    assert test_extracted_function_name

# Generated at 2022-06-24 13:50:17.593640
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''
        var a = []; a.push(1);
        var b = {}; b['a'] = a;
        var c = "abc";
        return b.a.splice(0, 1).join('') + c.substring(1, 2);
    '''
    jsi = JSInterpreter(code)
    assert jsi.interpret_statement(code, {}) == ('ba', True)



# Generated at 2022-06-24 13:50:22.717653
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = """
    function test() {
        var a;
        switch(a) {
            case b:
                return 1;
        }
        return 0;
    }
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function("test") == 0



# Generated at 2022-06-24 13:50:28.193019
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = r'''
    function func(arg1, arg2) {
        var a = [arg1, arg2];
        var b = [a, [0]];
        return b;
    }
    '''
    i = JSInterpreter(js_code)
    f = i.extract_function('func')
    result = f(('a', 'b'))
    assert result == [['a', 'b'], [0]]

# Generated at 2022-06-24 13:50:37.850097
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var obj1 = {
            "member1": function(p1,p2){
                return p1+p2;
            },
            "member2": 3
        };
        var obj2 = {
            "member1": function(p1,p2){
                return p1+p2;
            },
            "member2": function(p3){
                return p3;
            }
        };
    """
    objects = {}
    interpreter = JSInterpreter(code, objects)
    assert interpreter.extract_object("obj1") == {"member1": lambda p1, p2: p1 + p2, "member2": 3}

# Generated at 2022-06-24 13:50:48.377754
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:50:57.377987
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter("""
    if (x.a) {
        return x.b;
    }
    """)
    assert interpreter.interpret_expression("x", {"x": 1}) == 1
    assert interpreter.interpret_expression("x.b", {"x": {"b": 1}}) == 1
    assert interpreter.interpret_expression("(x.a ? x.b : x.c)",
                                            {"x": {"a": 1, "b": 1, "c": 0}}) == 1
    assert interpreter.interpret_expression("x.c",
                                            {"x": {"a": 1, "b": 1, "c": 0}}) == 0
    assert interpreter.interpret_expression("a = c = b = 1", {}) == 1

# Generated at 2022-06-24 13:51:09.051959
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Test 1. Call a function with no argument.
    #-------------------------------------------------------------------------#
    # This test calls a function called noArgs_func, which has no argument
    #-------------------------------------------------------------------------#
    code = '''
        function noArgs_func() {
            var result = "Alice";
            return result;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('noArgs_func') == 'Alice'

    # Test 2. Call a function that takes a string argument.
    #-------------------------------------------------------------------------#
    # This test calls a function called stringArg_func, which takes a string
    # argument
    #-------------------------------------------------------------------------#
    code = '''
        function stringArg_func(arg) {
            var result = arg;
            return result;
        }
    '''

# Generated at 2022-06-24 13:51:20.670828
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    assert JSInterpreter('').interpret_statement('abc.abc', {'abc': {'abc': '123'}})[0] == '123'
    assert JSInterpreter('').interpret_statement('abc.split("")', {'abc': '123'})[0] == ['1', '2', '3']
    assert JSInterpreter('').interpret_statement('return abc.split("")', {'abc': '123'})[0] == ['1', '2', '3']
    assert JSInterpreter('').interpret_statement('return abc.abc', {'abc': {'abc': '123'}})[0] == '123'
    assert JSInterpreter('').interpret_statement('abc.abc.abc', {'abc': {'abc': {'abc': '123'}}})[0]

# Generated at 2022-06-24 13:51:25.224279
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    z = JSInterpreter('''
        function odkaz(kde,y){var z="";var x=["","k","l","m","n","o","p","q","r","s","t"];
        for(i=3;i<y.length-1;i+=3)z+=x[y.charAt(i)];
        return kde+z}
    ''')
    expected = "https://www.example.com/myvideo.mp4"
    actual = z.call_function("odkaz", "https://www.example.com/", "wqoqwlotqlw")
    assert expected == actual, "Real world example"

# vim:set shiftwidth=4 softtabstop=4 expandtab textwidth=79:

# Generated at 2022-06-24 13:51:30.014411
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = """
        function hello(a, b) {
            var myvar = a + b;
            var e = 3;
            return myvar;
        }
    """
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('hello', 1, 2) == 3



# Generated at 2022-06-24 13:51:44.160927
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = JSInterpreter("")
    assert js.interpret_statement("1+1", {}) == (2, False)
    assert js.interpret_expression("2+2", {}) == 4
    assert js.interpret_expression("2-2", {}) == 0
    assert js.interpret_expression("2*2", {}) == 4
    assert js.interpret_expression("2/2", {}) == 1
    assert js.interpret_expression("8%3", {}) == 2
    assert js.interpret_expression("2<<2", {}) == 8
    assert js.interpret_expression("2>>2", {}) == 0
    assert js.interpret_expression("2|2", {}) == 2
    assert js.interpret_expression("2^2", {}) == 0

# Generated at 2022-06-24 13:51:53.962381
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    exp_abort = '''
        var a, b, c;
        a = 5;
        b = 6;
        return a + b;
        '''
    exp_ret = '''
        var a, b, c;
        a = 5;
        b = 6;
        return a;
        '''
    exp_var_define = '''
        var a, b;
        var c, d;
        '''
    exp_var_define2 = '''
        var a, b;
        c = 5;
        d = 6;
        '''
    exp_var_define3 = '''
        a = 5;
        b = 6;
        '''

# Generated at 2022-06-24 13:52:00.251175
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    l = []
    class MockExtractor(object):
        def __init__(self, video_id):
            self.video_id = video_id

        def _download_webpage(self, url, *args, **kwargs):
            return url

        def _download_json(self, url, video_id, transform_source=None, fatal=True):
            l.append(url)
            return {'url': url}

        def _download_webpage_handle(self, request, *args, **kwargs):
            return request

    from .extractor import common
    from .extractor import (
        GenericIE,
        YoutubeIE,
    )
    ies = [v for v in vars(common).values() if isinstance(v, type) and issubclass(v, GenericIE)]


# Generated at 2022-06-24 13:52:11.965805
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:52:19.252443
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = '''
        foo = {
            bar: function(arg1, arg2) { return arg1 + arg2; },
            baz: function(arg1, arg2, arg3) { return arg1 * arg2 + arg3; }
        }
    '''
    interpreter = JSInterpreter(js)
    obj = interpreter.extract_object('foo')
    assert obj['bar'](1, 2) == 3
    assert obj['baz'](2, 3, 4) == 10


# Generated at 2022-06-24 13:52:30.971134
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    obj_code = '''var obj = {
    "a": 1,
    "b": "test",
    "c": function(a) { return a + 1; },
    "0": function(a) { return a + 2; },
    "d": function(a) { return a + 3; },
    "e": function(a) { return a + 4; },
    "length": 5
};'''

    f_code = '''function test(a, b) { return a + b; }'''

    jsi = JSInterpreter(obj_code)

    assert jsi.interpret_expression('"test"', {}) == "test"
    assert jsi.interpret_expression('0', {}) == 0
    assert jsi.interpret_expression('1', {}) == 1
    assert jsi.interpret_expression

# Generated at 2022-06-24 13:52:33.324459
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsi = JSInterpreter("function abc(a,b) {return a+b;}")
    assert (jsi.call_function("abc", 2, 3) == 5)


# Generated at 2022-06-24 13:52:41.041004
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objects = {}
    js_interpreter = JSInterpreter(
        code='''
        function function1(a, b) {
            return a+b;
        }
        var object1 = {
            "a": 1,
            "b": "some string",
            "c": function(a, b) {
                return a-b;
            }
        }
        ''',
        objects=objects)
    actual = js_interpreter.extract_object('object1')
    expected = {
        "a": 1,
        "b": "some string",
        "c": lambda a, b: a-b,
    }
    assert expected == actual

# Generated at 2022-06-24 13:52:52.863005
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:53:04.955208
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:53:09.964686
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    function func(id, callee) {
        function() {
            return 4
        }
    }
    var obj = {
        var: 'myvar',
        vardef: 5,
        myfunc: function(arg1) {
            return arg1;
        },
        sum: function(arg1, arg2) {
            return arg1 + arg2;
        },
    }
    '''
    inter = JSInterpreter(code)
    print(inter.call_function('func', 4, 5))
    print(inter.call_function('obj.myfunc', 3))
    print(inter.call_function('obj.sum', 3, 5))
    print(inter.call_function('obj.sum', '3', '5'))

# Generated at 2022-06-24 13:53:15.909722
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
    var a = 4;
    var f = function(b) { return a + b; };'''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('f', 4) == 8

# Generated at 2022-06-24 13:53:22.925933
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Test with a simple function
    code = 'function f1(){return 1 + 1;}'
    f = JSInterpreter(code).extract_function('f1')
    assert f() == 2

    # Test with a function with arguments
    code = 'function f12(a,b){return a+b;}'
    f = JSInterpreter(code).extract_function('f12')
    assert f(2, 3) == 5

    # Test with a function with statements
    code = 'function f123(a,b){return a + b + 3;}'
    f = JSInterpreter(code).extract_function('f123')
    assert f(2, 3) == 8

    # Test with a function that does some logic

# Generated at 2022-06-24 13:53:27.543084
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        function b(a) {return a};
        var c = function (d) {return b(d)};
    """
    js_i = JSInterpreter(js_code)
    assert js_i.call_function('b', 2) == 2
    assert js_i.call_function('c', 3) == 3


# Generated at 2022-06-24 13:53:41.128500
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = """
var a = 'abc';
var b = [1, 2, 3];
var c = b.reverse();
var d = b[1];
"""
    jsi = JSInterpreter(code)
    local_vars = {}
    jsi.interpret_statement('var a = \'abc\'', local_vars)
    assert local_vars['a'] == 'abc'
    jsi.interpret_statement('var b = [1, 2, 3]', local_vars)
    assert local_vars['b'] == [1, 2, 3]
    jsi.interpret_statement('var c = b.reverse()', local_vars)
    jsi.interpret_statement('var d = b[1]', local_vars)
    assert local_vars['d'] == 2


# Generated at 2022-06-24 13:53:53.419152
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsinterpreter = JSInterpreter('var swfHTML = swfHTML.replace(/\\/\\//g, "/");')
    jsinterpreter.interpret_statement('var iframeHTML =', {})
    try:
        jsinterpreter.interpret_statement('var iframeHTML =', {})
    except ExtractorError as e:
        assert str(e) in ("'iframeHTML'", 'Recursion limit reached')

# Generated at 2022-06-24 13:54:05.566895
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_interpreter = JSInterpreter("""
        a = {
            x: 1,
            y: 2,
            z: function(a) {return a * 10;}
        };
        var b = function (a) { return a * 2;};
    """, {'c': 1})
    assert(js_interpreter.extract_object('a') == {
        'x': 1, 'y': 2, 'z': lambda a: a * 10
    })
    assert(js_interpreter.extract_function('b')(1) == 2)
    assert(js_interpreter.extract_function('b')(2) == 4)
    assert(js_interpreter.call_function('b', 3) == 6)


# Generated at 2022-06-24 13:54:07.210892
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = r'''var _x = function (a, b) {
    return a + b
}'''
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('_x', 3, 4) == 7



# Generated at 2022-06-24 13:54:11.198230
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    s = '''var obj = {
    'a': function(x){ return x + 1},
    'b': function(x,y){ return x + y}
    };
    an_int = 4;
    some_arr = [2, 3, 4];
    some_str = 'hello world';
    '''
    interpreter = JSInterpreter(s)
    assert interpreter._objects['obj']['a'](5) == 6
    assert interpreter._objects['obj']['b'](5, 6) == 11


# Generated at 2022-06-24 13:54:22.173067
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = '''
    test_function = function (foo, bar) {
        var a = foo + bar;
        var c = a*a;
        var b = a - c;
        var d = c << b;
        var e = d >> b;
        var f = a / e;
        var g = a ^ f;
        var h = a | g;
        var i = a & f;
        var j = a || g;
        var k = e || g;
        var l = b || f;
        var m = a && g;
        var n = e && g;
        var o = b && f;
        return a + b + c + d + e + f + g + h + i + j + k + l + m + n + o;
    };
    '''
    interp

# Generated at 2022-06-24 13:54:30.656316
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    test_var = [
        ['window["ytInitialPlayerResponse"]', 'ytInitialPlayerResponse'],
        ['window.ytInitialPlayerResponse', 'ytInitialPlayerResponse']
    ]
    for var, expected_func_name in test_var:
        js_interpreter = JSInterpreter("")
        func_name = js_interpreter.call_function('function(a){return a}', var)
        assert func_name == expected_func_name, 'Found %s instead of %s' % (func_name, expected_func_name)

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-24 13:54:39.212170
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = r'''var a = 5; b = "some string"; a = b.substr(2);'''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('random') == 0.18156458557557883
    assert js_interpreter.call_function('test', 2) == 1.0368462927878942
    assert js_interpreter.call_function('run', "substr") == "me string"
    assert js_interpreter.call_function(
        'split', "substr") == ['sub', '', 'tring']

if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-24 13:54:40.286836
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    JSInterpreter('var fun = function() { alert("Hello World!"); }')

# Generated at 2022-06-24 13:54:49.377039
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('var a = [1, 2, 3];')
    local_vars = {}
    js_interpreter.interpret_statement('var a = [1, 2, 3];', local_vars)
    assert local_vars['a'] == [1, 2, 3]
    js_interpreter.interpret_statement('var b = [a[1], a[0]];', local_vars)
    assert local_vars['b'] == [2, 1]
    js_interpreter.interpret_statement('var c = a[1]+b[1];', local_vars)
    assert local_vars['c'] == 3
    js_interpreter.interpret_statement('var d = a[3];', local_vars)

# Generated at 2022-06-24 13:54:58.704732
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsinterpreter = JSInterpreter("return Math.round(val);")
    assert jsinterpreter.interpret_statement("var c = Math.random();", {}) == (0, False), \
    "Result of interpreting var c = Math.random(); without local vars \
    should be 0, False."
    assert jsinterpreter.interpret_statement("return Math.round(val);", {}) == (None, True), \
    "Result of interpreting return Math.round(val); without local vars \
    should be None, True."
    assert jsinterpreter.interpret_statement("var c = Math.random();", {'val': 0}) == (1, False), \
    "Result of interpreting var c = Math.random(); with local vars {'val': 0} \
    should be 1, False."
    assert jsinter

# Generated at 2022-06-24 13:55:02.799818
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
    function test(a, b, c){
        var d = a + b;
        var e = a - c;
        return d + e;
    }'''
    f = JSInterpreter(code).extract_function('test')
    assert f((1, 2, 3)) == 0


# Generated at 2022-06-24 13:55:13.372047
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    
    # 1. Test assignment statement
    # Example 1: result, should_abort = js.interpret_statement('var a = 1', local_vars, allow_recursion)
    js = JSInterpreter('var a = 1')
    output = js.interpret_statement('var a = 1', {}, 0)
    assert output == (1, False)
    # Example 2: result, should_abort = js.interpret_statement('var a = a + 1', local_vars, allow_recursion)
    output = js.interpret_statement('var a = a + 1', {'a': 1}, 0)
    assert output == (2, False)
    # Example 3: result, should_abort = js.interpret_statement('a = a + 1', local_vars, allow_recursion)
    output = js.interpret

# Generated at 2022-06-24 13:55:17.398909
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsinterp = JSInterpreter("function extractFunction(a){var b=12,c=a.split('');return b}function extractFunction2(q){var b=14,c=q.split('');return b}")
    assert jsinterp.interpret_statement("return extractFunction(1)", {})[0] == 12
    assert jsinterp.interpret_statement("return extractFunction2(1)", {})[0] == 14


# Generated at 2022-06-24 13:55:21.443620
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_interpreter = JSInterpreter('function test(a, b, c){return "a" + "b" + "c"}')
    result = js_interpreter.extract_function('test')
    assert result((1,2,3)) == 'abc'


# Generated at 2022-06-24 13:55:33.352596
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    def test_call(js_code, func_name, func_args, expected):
        js_interpreter = JSInterpreter(js_code)
        actual = js_interpreter.call_function(func_name, *func_args)
        assert actual == expected

    test_call(
        '''
            function someFunc(x, y){
                return x + y;
            }
        ''',
        'someFunc',
        [2, 3],
        5)
    test_call(
        '''
            var someFunc = function(x, y){
                return x + y;
            };
            ''',
        'someFunc',
        [2, 3],
        5)

# Generated at 2022-06-24 13:55:44.921050
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    a = JSInterpreter("""
        var obj1 = {
            foo: function (a, b) {
                return a + b
            },
            bar: function (args) {
                return args[0]
            }
        }
    """)
    assert a.call_function("obj1.foo",1,2) == 3
    assert a.call_function("obj1.bar",[1,2]) == 1

    b = JSInterpreter("""
        var obj2 = {
            a: "a",
            b: ["1", "2"],
            c: {
                a: "a",
                b: "3"
            }
        }
    """)
    assert b.interpret_expression("obj2.a",{}) == 'a'

# Generated at 2022-06-24 13:55:50.600604
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    JSInterpreter_inst = JSInterpreter("""
        function testFunction(arg1, arg2) {
            arg1 = arg1.split(" ");
            var a = arg1[0];
            var b = arg1[1];
            return a + " " + b + " " + arg2;
        }
    """)
    expected_result = lambda args: args[0].split(' ')[0] + ' ' + args[0].split(' ')[1] + ' ' + args[1]
    actual_result = JSInterpreter_inst.extract_function("testFunction")
    assert actual_result("arg1 val1", "val2") == expected_result("arg1 val1", "val2")


# Generated at 2022-06-24 13:55:53.019219
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    c = JSInterpreter("")
    f = c.build_function(["x", "y"], "a = x + y")
    assert(f([1, 2]) == 3)


# Generated at 2022-06-24 13:55:59.315853
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsinterpreter = JSInterpreter(open('test_jsm.js').read())
    assert jsinterpreter.call_function('parse_digit', 'L') == 50
    assert jsinterpreter.call_function('parse_digit', '1') == 1
    assert jsinterpreter.call_function('parse_digit', 'O') == 15


if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-24 13:56:05.399278
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter(code='''
        function func(a, b, d) {
            var c = a + b;
            return b + d;
        }''')
    f = js.build_function(argnames=('a', 'b', 'd'), code="""
            var c = a + b;
            return b + d;
        """)
    res = f((1, 2, 3))
    assert (res == 5)


# Generated at 2022-06-24 13:56:13.473606
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:56:24.114875
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = JSInterpreter('var a = 1; return a;')
    assert code.interpret_statement('var a = 1;', {}) == (None, False)
    assert code.interpret_statement('return a', {}) == (1, True)
    assert code.interpret_statement('a', {}) == (1, False)
    assert code.interpret_statement('var a2 = a;', {}) == (None, False)
    assert code.interpret_statement('return a2', {}) == (1, True)
    assert code.interpret_statement('a2', {}) == (1, False)
    assert code.interpret_statement('a2 = 2; return a2', {}) == (2, False)
    assert code.interpret_statement('a2', {}) == (2, False)

# Generated at 2022-06-24 13:56:36.038332
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:56:48.057821
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    variables = {
        'k': {'h': 1, 'i': 2},
        'z': [3, 4, 5],
        'n': 'abc',
        'q': 12,
        'x': -5,
    }
    jsInterpreter = JSInterpreter('', variables)

# Generated at 2022-06-24 13:56:57.862994
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('if (1) x = y; return 3;')
    assert(js_interpreter.interpret_statement('x') == None)
    assert(js_interpreter.interpret_statement('1') == 1)
    assert(js_interpreter.interpret_statement('1;2') == 1)
    assert(js_interpreter.interpret_statement('str = "abc"') == "abc")
    assert(js_interpreter.interpret_statement('str') == "abc")
    assert(js_interpreter.interpret_statement('a = 1') == 1)
    assert(js_interpreter.interpret_statement('a') == 1)
    assert(js_interpreter.interpret_statement('b = a') == 1)

# Generated at 2022-06-24 13:57:10.162638
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsInterpretor = JSInterpreter('')

    test_strings = ['var a=1', 'return 1', 'alert(2)']
    test_expected_results = [True, True, False]
    test_abort_results = [False, True, True]

    for test_string, test_expected_result, test_abort_result in zip(test_strings, test_expected_results, test_abort_results):
        test_rst_result, test_rst_abort_result = jsInterpretor.interpret_statement(test_string, {'a': 1})
        assert test_rst_result == test_expected_result, 'Expected result %s, but got %s instead' % (test_expected_result, test_rst_result)
        assert test_rst_abort_result

# Generated at 2022-06-24 13:57:14.600333
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function asdf(a,b) {
            a = a + 1;
            b = b + 2;
            return a*b;
        }
    '''
    jsi = JSInterpreter(js_code)
    assert jsi.call_function('asdf', 1, 2) == 9


# Generated at 2022-06-24 13:57:24.570720
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('').interpret_expression('5') == 5
    assert JSInterpreter('').interpret_expression('5+5') == 10
    assert JSInterpreter('').interpret_expression('5-5') == 0
    assert JSInterpreter('').interpret_expression('5*5') == 25
    assert JSInterpreter('').interpret_expression('5/5') == 1
    assert JSInterpreter('').interpret_expression('5%5') == 0
    assert JSInterpreter('').interpret_expression('2+2*2') == 6
    assert JSInterpreter('').interpret_expression('(2+2)*2') == 8
    assert JSInterpreter('').interpret_expression('5^5') == 0

# Generated at 2022-06-24 13:57:34.462477
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    codes = []
    codes.append('''
        var $ = function(a) {
            return {
                0: 100,
                1: a[1],
                length: 2,
                push: function(b) {
                    this[this.length] = b;
                    this.length++;
                }
            };
        };
        ''')

# Generated at 2022-06-24 13:57:45.318963
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:57:55.381433
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def test (code, expected_result):
        # create interpreter object
        obj = JSInterpreter(code)
        # call interpret_expression
        actual_result = obj.interpret_expression('a', {})
        # check for equality
        assert expected_result == actual_result
    
    # test two cases -> one is an integer and one is a string
    # integer test
    test('var a = 12345;', 12345)
    # string test
    test('var a = "hello world";', 'hello world')
    # the interpreter is able to convert strings with numbers in them
    test('var a = "hello world 567";', 'hello world 567')
    # the interpreter is able to parse out numbers from strings
    test('var a = "hello world 567 foo";', 'hello world 567 foo')
    # test concat

# Generated at 2022-06-24 13:58:01.445365
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    src_code = '''
        function func_0(){
            return true;
        }        
        function func_1( a ){
            return a;
        }
'''
    js_interpreter = JSInterpreter(src_code)
    func0 = js_interpreter.extract_function('func_0')
    assert func0() == True
    func1 = js_interpreter.extract_function('func_1')
    assert func1('abcd') == 'abcd'


# Generated at 2022-06-24 13:58:04.858234
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objname = 'a'
    code = 'var a = {};'
    m = JSInterpreter(code)
    a = m.extract_object(objname)
    assert a == {}
    return True


# Generated at 2022-06-24 13:58:16.655589
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    obj = JSInterpreter('')
    f = obj.build_function([], 'return 42;')
    assert f(()) == 42


if __name__ == '__main__':
    import sys
    test_JSInterpreter_build_function()
    if len(sys.argv) == 1:
        sys.exit(0)
    fname = sys.argv.pop(1)
    code = open(fname, 'rb').read().decode('utf-8')
    if len(sys.argv) == 1:
        sys.exit(0)

    obj = JSInterpreter(code)
    res = obj.call_function(sys.argv[1], *sys.argv[2:])
    print(repr(res))

# Generated at 2022-06-24 13:58:25.310635
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = r'''function p(a) {
    var d, c, e, b, f;
    c = function (a, b) {
        var c = arguments,
            d = c[0] + "";
        return d + c[1]
    };
    d = function (a, b) {
        var c = a || b;
        return c
    };
    b = function (a, b) {
        return a + b
    };
    e = function (a, b) {
        return a / b
    };
    f = function (a, b) {
        return a * b
    };
    return f(e(b(d(c(a[0], a[1]), a[2]), a[3]), a[4]), a[5])
}'''

   

# Generated at 2022-06-24 13:58:33.488672
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    """
    You can use it to check the result of the method extract_object
    """
    code = '''
    var a = {
        "b": 5,
        "c": function() {
            return 3 + 4
        }
    }
    '''
    jsi = JSInterpreter(code)
    a = jsi.extract_object('a')
    assert a['c']() == 7
    assert a['b'] == 5


if __name__ == '__main__':
    test_JSInterpreter_extract_object()

# Generated at 2022-06-24 13:58:39.876523
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
    decodeURIComponent(arguments[0])
    """
    js_interpreter = JSInterpreter(js_code)
    ret = js_interpreter.call_function('decodeURIComponent', 'abc')
    assert ret == 'abc'
    ret = js_interpreter.call_function('decodeURIComponent', '%20')
    assert ret == ' '



# Generated at 2022-06-24 13:58:52.571201
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:59:01.890071
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # In actual use, the method call_function always receives string arguments
    # Function name is the first argument.
    # Other arguments are string representations of integers,
    # and they are passed to the function as integers.
    # The function will return the result of the last statement.

    # This is a very simple version of the function st.set(t, t + e),
    # where st and t are integer variables and e is an integer argument.
    func_str = "st=t+e;t=st>>" + str(5) + ";return st"
    # In actual use, the function always receive 3 arguments, the last 2 arguments
    # are usually values of integer variables st and t, and the first argument is
    # an integer expression.
    # In this simple example, the function only requires 1 argument.

# Generated at 2022-06-24 13:59:11.463185
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Function with only one statement
    js_interpreter = JSInterpreter('')
    resf = js_interpreter.build_function((), 'return 1')
    assert resf(()) == 1

    # Function with multiple statements
    js_interpreter = JSInterpreter('')
    local_vars = {}
    code = '''
        var a = 1;
        var b = 2;
        var c = a + "-" + b;
        return c;
    '''
    js_interpreter.build_function((), code)(()) == '1-2'
    assert local_vars['c'] == '1-2'

    # Function with operations
    js_interpreter = JSInterpreter('')

# Generated at 2022-06-24 13:59:22.268593
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter("")
    # test interpret_statement: empty statement
    expr = ""
    local_vars = {}
    res, abort = js.interpret_statement(expr, local_vars)
    assert res is None and abort == False
    # test interpret_statement: simple expression statement
    expr = "var var_name = 123"
    local_vars = {}
    res, abort = js.interpret_statement(expr, local_vars)
    assert res == 123 and abort == False and local_vars['var_name'] == 123
    # test interpret_statement: assignment expression statement
    local_vars['var_name'] = 100
    expr = "var_name = 345"
    res, abort = js.interpret_statement(expr, local_vars)
    assert res == 345 and abort == False and local

# Generated at 2022-06-24 13:59:27.991851
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    test_func = """
        function test_func(arg_a, arg_b) {
            var variable_c=arg_a+arg_b;
            var variable_d=2;
            variable_c=variable_d*variable_c;
            return variable_c;
        }
    """
    # Test JSInterpreter initialization
    test_interpreter = JSInterpreter(test_func)
    # Test extract_function
    test_func_extracted = test_interpreter.extract_function('test_func')
    # Test function extraction
    assert test_func_extracted((1,2)) == 4
    assert test_func_extracted((3,4)) == 18


# Generated at 2022-06-24 13:59:32.412796
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter('function test(v){return 1+v}')
    f = jsi.build_function(['v'], 'return 1+v')
    assert f([2]) == 3


# Generated at 2022-06-24 13:59:36.572120
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        a = {'b': function(){;}, 'c': function(){;}};
    '''
    interpreter = JSInterpreter(code)
    obj_a = interpreter.extract_object('a')
    assert obj_a == {'b': None, 'c': None}



# Generated at 2022-06-24 13:59:41.283603
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter(code='', objects=None)
    res = js_interpreter.build_function(argnames=['a'], code='var b = 3;return b;')
    assert res == 3


# Generated at 2022-06-24 13:59:52.724124
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test for method interpret_statement.
    # This test is for a case where the method returns a tuple of (value, should_abort)
    code = '''
        function test() {
            var a = "test1";
            var b = a + "test2" + \"test3\" + 'test4';
            return b;
        }
    '''

    interpreter = JSInterpreter(code)
    local_vars = {}
    res, abort = interpreter.interpret_statement('var a = "test1";', local_vars)
    assert res == 'test1'
    assert abort == False
    res, abort = interpreter.interpret_statement('return b;', local_vars)
    assert res == "test1test2test3test4"
    assert abort == True



# Generated at 2022-06-24 13:59:56.398958
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''    function test(arg1, arg2) {
        return arg1 + arg2;
    }'''
    jsi = JSInterpreter(code)
    test = jsi.extract_function('test')
    assert test([2, 3]) == 5

# Generated at 2022-06-24 14:00:03.393921
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    example_code_1 = r'''
    function f112(a, b) {
        var c = a + b;
        var d = a * b;
        var e = c + d;
        return e;
    }
    '''
    js_interpreter = JSInterpreter(example_code_1)
    func1 = js_interpreter.extract_function('f112')
    assert func1([1, 2]) == 5
    assert func1([2, 3]) == 13
    assert func1([-1, 2]) == 3

    example_code_2 = r'''
    function f112(a, b) {
        var c = a + b;
        var d = a * b;
        var e = c + d;
        return c;
    }
    '''
    js