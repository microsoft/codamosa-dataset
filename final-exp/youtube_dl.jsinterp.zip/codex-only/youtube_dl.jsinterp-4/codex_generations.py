

# Generated at 2022-06-24 13:50:04.388498
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # input data
    test_code = '''
        var a = {
            "b": function(p) {
                return p;
            },
            "c": function(p) {
                return !p;
            },
            "d": function(p) {
                return p === 1;
            },
            "e": function(p) {
                return p == 1;
            },
            "f": function(p) {
                return typeof p;
            },
            "g": function(p) {
                return typeof p === "undefined";
            },
            "h": function(p) {
                return typeof p == "undefined";
            }
        }
        function x(p) {
            return !p;
        }
    '''
    # expected result

# Generated at 2022-06-24 13:50:15.300423
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # build_function takes a list of variable names and code, 
    # and it returns a callable that evaluates code with a dictionary of variables
    # code is not a single-line code
    # code includes a call of a defined function
    js_code = (
        'function obj(a, b) {' +
        '    if (a == 0) {' +
        '        function add(a, b) {' +
        '            return a + b' +
        '        };' +
        '        return add(a, b);' +
        '    }' +
        '};' +
        'function main() {' +
        '    return obj();' +
        '};')
    js_interpreter = JSInterpreter(js_code)
    js_interpreter.extract_function('obj')

# Generated at 2022-06-24 13:50:24.533299
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:50:31.501473
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
    function function_a(a,b,c)
    {
        var x =  a * a * b * c * a * a * b * c;
        var y = x + 100;
        return y - x;
    }
    """
    js_interpreter = JSInterpreter(code)

    assert js_interpreter.call_function("function_a",1,2,3) == 200


# Generated at 2022-06-24 13:50:40.770942
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:50:51.315480
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement(
        'return x + 5;', {'x': 1})[0] == 6
    # Test output variable
    assert js_interpreter.interpret_statement(
        'y = x + 5;', {'x': 1})[0] == 6
    assert 'y' in js_interpreter._objects
    # Test variable in function
    assert js_interpreter.interpret_statement(
        'function(x) { return x + 5; };', {'x': 1})[0] == 6
    assert 'x' not in js_interpreter._objects
    assert js_interpreter.interpret_statement(
        'var y = 0; y = x + y;', {'x': 1})[0]

# Generated at 2022-06-24 13:50:56.746317
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''var some_object;
                some_object = {
                    'function_name': function(param_1, param_2) {
                        return param_1 + param_2;
                    }
                };'''
    assert JSInterpreter(js_code).call_function('some_object.function_name', 4, 5) == 9


# Generated at 2022-06-24 13:51:08.954598
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:51:20.399691
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('l = "";')
    assert interpreter.interpret_expression('l', {}) == ''
    interpreter = JSInterpreter('l = "abc";')
    assert interpreter.interpret_expression('l', {}) == 'abc'
    interpreter = JSInterpreter('l = ["a", "b", "c"];')
    assert interpreter.interpret_expression('l', {}) == ['a', 'b', 'c']
    assert interpreter.interpret_expression('l[0]', {}) == 'a'
    assert interpreter.interpret_expression('l[1]', {}) == 'b'
    assert interpreter.interpret_expression('l[2]', {}) == 'c'
    interpreter = JSInterpreter('l = ["a", "b", ["c", "d", "e"]];')
    assert interpreter.interpret

# Generated at 2022-06-24 13:51:30.086453
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    def _test(js, expectedStmt, expectedReturn):
        js_interpreter = JSInterpreter('')
        stmt, should_abort = js_interpreter.interpret_statement(js, {})
        assert stmt == expectedStmt
        assert should_abort == expectedReturn
    _test('var a = b;', None, False)
    _test('return;', None, True)
    _test('return x;', 'x', True)
    _test('''
        var a;
        if (a) {
            var b;
            return 5;
        } ''', 5, True)
    _test('return a.split("");', ['a'], True)
    _test('return a.reverse();', ['a'], True)

# Generated at 2022-06-24 13:51:44.162966
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:51:51.200852
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = '''
        od = {
            a: 1,
            b: '2',
            c: {
                a: 3
            },
            d: function (a, b) {
                return a * b + 4;
            }
        } 
    '''

    js_interpreter = JSInterpreter(js_code)
    assert(js_interpreter._objects['od'] == {
        'a': 1, 
        'b': '2', 
        'c': {
            'a': 3
        }, 
        'd': js_interpreter._objects['od']['d']
    })
    assert(js_interpreter.interpret_expression('od.a', {}) == 1)

# Generated at 2022-06-24 13:51:56.875111
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    var myarr = [1, 2, 3];
    var mystr = 'abcde';
    var myobj = {
            "function": function(a, b, c) {
                return a + b + c;
            }
    };
    var myfunc = function(a, b, c) {
        return a + b + c;
    }
    var myfunc2 = function(a, b) {
        return a * b;
    }
    '''
    j = JSInterpreter(code, {'myarr': [1, 2, 3]})
    assert j.call_function('myfunc2', 3, 0) == 0
    assert j.call_function('myobj.function', 1, 2, 3) == 6

# Generated at 2022-06-24 13:52:09.831500
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        function test(u){
            var o=[];
            for(i=0;i<u.length;i++)o.push(u.charCodeAt(i)^(1+(u.length-i)%32));
            for(;i<32;i++)o.push(u.charCodeAt(i)^(1+i));
            return o;
        }
        """
    global_vars = {'u': 'test'}
    expected_result = [116, 101, 115, 116, 80, 81, 16, 17, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
    js = JSInterpreter(code)
   

# Generated at 2022-06-24 13:52:18.604232
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsIn = JSInterpreter("")
    assert jsIn.interpret_statement("", {"var":9}) == (None, False)
    assert jsIn.interpret_statement("   ", {"var":9}) == (None, False)
    assert jsIn.interpret_statement("var ", {"var":9}) == (None, False)
    assert jsIn.interpret_statement("var", {"var":9}) == (None, False)
    assert jsIn.interpret_statement("var var2", {"var":9}) == (None, False)
    assert jsIn.interpret_statement("return", {"var":9}) == (None, False)
    assert jsIn.interpret_statement("return var2", {"var":9}) == (None, False)
    assert jsIn.interpret_statement("return;", {"var":9}) == (None, True)


# Generated at 2022-06-24 13:52:30.609586
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        function func1(a,b,c) { a; var x = 1, y = c, z = c[0]; b[0]++; return x; }
        var func2 = function(e,d) { d + 1; return e[0]; };
    """
    intpr = JSInterpreter(code)
    func1 = intpr.extract_function("func1")
    # func1(a,b,c) returns 1
    assert func1((1,[2],[[3]])) == 1
    # Calling func1(a,b,c) increments b[0]
    assert func1((1,[2],[[3]])) == 1
    assert func1((1,[2],[[3]])) == 1

    func2 = intpr.extract_function("func2")
    # func2(

# Generated at 2022-06-24 13:52:36.344612
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        foo = {
            e: function(a){},
            f: function(a, b){}
        }
        '''
    jsi = JSInterpreter(js_code)
    obj = jsi.extract_object('foo')
    assert len(obj) == 2
    assert obj['e']('value') is None
    assert obj['f']('value', 'other value') is None


# Generated at 2022-06-24 13:52:39.672610
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    tcode = 'var obj3 = {}; obj3.var1 = obj1;'
    try:
        JSInterpreter(tcode)
        assert True
    except ExtractorError as e:
        print(e.args)
        assert False


# Generated at 2022-06-24 13:52:51.436628
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter("")
    # Test 1: Test empty statement
    result, abort = interpreter.interpret_statement("",{})
    if abort != False or result != None:
        raise Exception("fail")
    # Test 2: Test statement 'var x = y;'
    x = "x"
    y = "y"
    result, abort = interpreter.interpret_statement('var ' + x + " = " + y + ";", {x:1, y:2})
    if abort != False or result != 2:
        raise Exception("fail")
    # Test 3: Test statement 'return x + 1;'
    x = "x"
    result, abort = interpreter.interpret_statement('return ' + x + " + 1;", {x:2})

# Generated at 2022-06-24 13:52:54.140173
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = JSInterpreter(
'''
function a(b, c, d) {
    return b + ' ' + c + ' ' + d + '!!!';
}
''')
    assert js.call_function('a', 1, 2, 3) == '1 2 3!!!'

# Generated at 2022-06-24 13:53:06.586760
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:53:16.064714
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('')

    assert interpreter.interpret_expression('2', {}, 100) == 2
    assert interpreter.interpret_expression('(2)', {}, 100) == 2
    assert interpreter.interpret_expression('(2 + 3)', {}, 100) == 5
    assert interpreter.interpret_expression('(3) + (4)', {}, 100) == 7
    assert interpreter.interpret_expression('"a"', {}, 100) == 'a'
    assert interpreter.interpret_expression('("a")', {}, 100) == 'a'
    assert interpreter.interpret_expression('"a" + "b"', {}, 100) == 'ab'
    assert interpreter.interpret_expression('("a") + "b"', {}, 100) == 'ab'

# Generated at 2022-06-24 13:53:23.081750
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    text = '''
var myObject={a:1,b:2,c:function(x,y){return this.a+this.b+x+y;}};

function myFunction(arg1,arg2){
if(arg1=="foo"){
return myObject.c(arg2,4);}
else{
return myObject.c(arg2,5);
}
}

function myFunction2(arg1,arg2){
if(arg1=="foo"){
return myObject.c(arg2,4);}
else{
return myObject.c(arg2,5);
}
}

myFunction2(myFunction("foo",1),1);
'''

    ji = JSInterpreter(text)

# Generated at 2022-06-24 13:53:32.268223
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = r'''
function dec(a, b) {
    return a + b;
}
function abc() {
    return 123;
}
function bar() {
    return 321;
}
function foo(par) {
    var obj = {
        "a": function() {
            return 999;
        },
        "b": function() {
            return 42;
        }
    }
    return obj[par]();
}
'''
    js_interpreter = JSInterpreter(code)

    assert js_interpreter.call_function("dec", 3, 4) == 3 + 4
    assert js_interpreter.call_function("abc") == 123
    assert js_interpreter.call_function("bar") == 321

# Generated at 2022-06-24 13:53:43.518547
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''
        a = 4; b = 5;
        a = a + 4;
        return a;
    '''
    interpreter = JSInterpreter(code)
    result = interpreter.interpret_statement(code, {})
    assert result[0] == 8
    assert result[1]

    code = '''
        a = 4; b = 5;
        a = a + 4;
    '''
    interpreter = JSInterpreter(code)
    result = interpreter.interpret_statement(code, {})
    assert result[0] == 8
    assert not result[1]

    code = '''
        a = "a";
        a += "b";
        return a;
    '''
    interpreter = JSInterpreter(code)
    result = interpreter.interpret_statement(code, {})
   

# Generated at 2022-06-24 13:53:55.378693
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    import subprocess
    import os
    import tempfile
    import time
    # Test for code without any expressions
    code_empty = """function test {
        }"""
    # Test for code with a single expression
    code_single = """function test(a, b) {
        return a+b;
        }"""
    # Test for code with multiple expressions
    code_multiple = """function test(a,b,c) {
        return (a+b)*c;
        }"""
    # Test for code with an expression that returns a value
    code_return = """function test(a) {
        return (a);
        }"""
    # Test for code with an expression that does not return a value
    code_no_return = """function test(a) {
        a=a+4;
        }"""
    # Test for

# Generated at 2022-06-24 13:54:07.748281
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:54:18.224814
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:54:30.105596
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = 'function a(o, t){while(o%=t)t^=o;return t;};'
    js = JSInterpreter(code)


# Generated at 2022-06-24 13:54:36.160699
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    test_code = ("""
        function test_func(arg1, arg2) {
            var field1 = arg1 + arg2;
            var field2 = field1 + 1;
            return field2;
        }
        """)
    js_interpreter = JSInterpreter(test_code)

    assert js_interpreter.call_function("test_func", 10, 15) == 26

# Generated at 2022-06-24 13:54:43.149131
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    test_cases = [
        {'file': 'function test(a){return a;}', 'function': 'test', 'args': (1,), 'expected_result': 1},
        {'file': 'function test(a){var b=a;return b+1;}', 'function': 'test', 'args': (1,), 'expected_result': 2},
    ]
    for test in test_cases:
        interpreter = JSInterpreter(test['file'])
        res = interpreter.call_function(test['function'],*test['args'])
        assert res == test['expected_result'], '%s != %s, args: %s, file: %s' % (res, test['expected_result'], test['args'], test['file'])


# Generated at 2022-06-24 13:54:49.834174
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():

    js_code = '''
        function test_JSInterpreter_extract_function() {
            return test_1(arg1, arg2) + arg1 * arg2;
        }
    '''

    js_interpreter = JSInterpreter(js_code)
    f = js_interpreter.extract_function('test_JSInterpreter_extract_function')
    test_1 = lambda arg1, arg2: 4
    assert f((1, 2)) == 8


# Generated at 2022-06-24 13:54:52.979788
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
    function foo(a,b) {
        return a + b;
    }
    """
    js = JSInterpreter(code)
    assert callable(js.extract_function("foo"))


# Generated at 2022-06-24 13:55:02.297755
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter("var obj = {ab:1, abc:3, abd:5, abcd:7, abcde:9};")
    assert js.interpret_expression("obj['ab']", {}) == 1
    assert js.interpret_expression("obj.abc", {}) == 3
    assert js.interpret_expression("obj['abcd']", {}) == 7
    assert js.interpret_expression("obj.abcde", {}) == 9
    js = JSInterpreter("var obj = {b:1, abc:3, abd:5, abcd:7, abcde:9};")
    assert js.interpret_expression("obj['ab']", {}) == None
    assert js.interpret_expression("obj['abc']", {}) == 3

# Generated at 2022-06-24 13:55:13.372494
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test for method interpret_statement of class JSInterpreter
    # The 1st arg of function build_function is the argnames of function,
    # the 2nd arg of it is the code of function.
    code = """some_function(some, args);"""
    f = JSInterpreter(code).build_function(['some', 'args'], """some_function(some, args);""")

    # The test is succeed if the 1st arg of f is the correct vars.
    resf = f(['a', 'b'])
    if resf == None:
        print('test_JSInterpreter_interpret_statement: Succeed')
    else:
        print('test_JSInterpreter_interpret_statement: Fail')

if __name__ == "__main__":
    test_JSInterpreter_interpret_

# Generated at 2022-06-24 13:55:21.668373
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Unit test for method extract_object of class JSInterpreter
    code = '''
        function test(a){return a*a};
        var a = (function() {
            var b = {
              c: function(d) {
                return d * 1000;
              },
              e: function(f) {
                return f / 1000;
              }
            };
            return {
              d: function(e) {
                return e * 1000;
              },
              f: function(g) {
                return g / 1000;
              },
              b: b
            };
        })();
        '''
    obj = JSInterpreter(code).extract_object('a')
    assert len(obj.keys()) == 3
    assert 'd' in obj
    assert callable(obj['d'])

# Generated at 2022-06-24 13:55:33.522177
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:55:40.288876
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''
    var a = 0;
    return a;'''
    js = JSInterpreter(code)
    assert js.interpret_statement(code, {}) == (0, True)
    code = '''
    var a = 7;
    var b = a + 3;
    var c = a | b;
    return c;'''
    js = JSInterpreter(code)
    assert js.interpret_statement(code, {}) == (0b111, True)
    # Test for function call
    code = '''
    var a = hls() + 3;
    return a;
    '''
    js = JSInterpreter(code)
    js._functions['hls'] = lambda x: 3
    assert js.interpret_statement(code, {}) == (6, True)
   

# Generated at 2022-06-24 13:55:48.292790
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:55:53.156823
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objname = 'w'
    code = '''
        function x(y,z) {
            var y = y
            for (var i = 0; i < 5; ++i) {
                var h = true
                var g = false
                function b(a){
                    if (a == true){
                        return a
                    }
                    if (a == false){
                        return a
                    }
                    return h
                }
                function c(d, e){
                    return d + e
                }
                function f(){
                    return h
                }
                w = {
                    "isReady": b,
                    "add": c,
                    "getTrue": f
                }
            }
        }
    '''
    obj = JSInterpreter(code).extract_object(objname)

# Generated at 2022-06-24 13:56:03.875109
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    test_code = 'test_code'
    test_funcname = 'test_funcname'
    func_m = re.search(r'(?:function\s+%s|[{;,]\s*%s\s*=\s*function|var\s+%s\s*=\s*function)\s*'
                       r'\((?P<args>[^)]*)\)\s*'
                       r'\{(?P<code>[^}]+)\}' % (re.escape(test_funcname), re.escape(test_funcname),
                                                 re.escape(test_funcname)), test_code)
    JSInterpreter(test_code).build_function(func_m.group('args').split(','), func_m.group('code'))

# Generated at 2022-06-24 13:56:13.576053
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    jsinter = JSInterpreter("var a = 1; var b = 2; return a + b;")
    assert jsinter.interpret_expression("a", {}, 100) == 1
    assert jsinter.interpret_expression("b", {}, 100) == 2
    assert jsinter.interpret_expression("a + b;", {}, 100) == 3
    assert jsinter.interpret_expression("1 + 2;", {}, 100) == 3
    assert jsinter.interpret_expression("(1) + (2);", {}, 100) == 3
    assert jsinter.interpret_expression("(1 + 1) + 2;", {}, 100) == 4
    assert jsinter.interpret_expression("1 + (1 + 2);", {}, 100) == 4

# Generated at 2022-06-24 13:56:24.200784
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:56:36.117542
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:56:45.963410
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter("""
            var a = [1, 2, 3];
            a[1] = 10;
            var b = a[0] + a[1] - 2 + a[2];
            """)
    assert(js.interpret_statement("var a = [1, 2, 3];")[0] == [1, 2, 3])
    assert(js.interpret_statement("a[1] = 10;")[0] == 10)
    assert(js.interpret_statement("var b = a[0] + a[1] - 2 + a[2];")[0] == 11)


# Generated at 2022-06-24 13:56:56.449188
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter(
        """var a=0;var b=0;
        function my_func(arg1, arg2){a=arg1;b=arg2;return a+b;};
        """)
    assert js_interpreter.call_function('my_func', 3, 8) == 11

    js_interpreter = JSInterpreter(
        """
            function my_func(arg1, arg2){
                return arg1 + arg2;
            };
            """)
    assert js_interpreter.call_function('my_func', 3, 8) == 11


# Generated at 2022-06-24 13:57:08.422063
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    expr = """function(p,a,c,k,e,d){while(c--)if(k[c])p=p.replace(new RegExp('\\b'+c.toString(a)+'\\b','g'),k[c]);return p}"""
    func = JSInterpreter(expr).extract_function('0')
    params = (
        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
        62,
        lambda x:x
    )

    assert func(params) == 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'

# Generated at 2022-06-24 13:57:15.992766
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Case 1: single statement, return expression
    js_code = 'function f(a, b, c) { return a + b * c; }'
    f = JSInterpreter(js_code).build_function(['a', 'b', 'c'], 'return a + b * c')
    assert f((3, 4, 5)) == 3 + 4 * 5
    assert f((1, 2, 3)) == 1 + 2 * 3

    # Case 2: multi-statement, return expression
    js_code = 'function f(a, b, c) { a = a + 1; b = b - 1; return a + b * c; }'

# Generated at 2022-06-24 13:57:19.724546
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert callable(js_interpreter.build_function(('x', 'y'), 'this.x+this.y')), 'build_function returns a function'
    assert js_interpreter.build_function(('x', 'y'), 'this.x+this.y')((1, 2)) == 3, 'build_function returns the right function'

# Generated at 2022-06-24 13:57:30.871882
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    f = '''  function foo(a,b,c) { 
                var x = a*a+b*b+c*c;
                return x;
            }
            var bar = function(a,b,c) { 
                var x = a*a+b*b+c*c;
                return x;
            }
            var another_func = function(a,b,c) { 
                var x = a*a+b*b+c*c;
                return x;
            }
            foo(1,2,3);
            bar(4,5,6);
            another_func(7,8,9);
        '''
    jsi = JSInterpreter(f)
    foo = jsi.extract_function('foo')

# Generated at 2022-06-24 13:57:42.943339
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    func_def = '''
            function s(str, key) {
                str = str.split('');
                for (var i = str.length - 1; i > -1; i--) {
                    var j = i;
                    var c = str[i];
                    for (var k = key.length - 1; k > -1; k--) {
                        c = String.fromCharCode(c.charCodeAt(0) ^ key[k].charCodeAt(0));
                    }
                    str[j] = c;
                }
                return str.join('');
            }
    '''

# Generated at 2022-06-24 13:57:54.017188
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:58:03.417297
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objname = "_0x8a36"
    obj = {}

    o = JSInterpreter('''
        _0x8a36 = {
            _0x29c654: function(_0x1c3e1d, _0x3f994e, _0x5a8f0c) {
                return _0x1c3e1d(_0x3f994e, _0x5a8f0c);
            },
            _0x5d00fa: function(_0x1eb773, _0x48d5aa, _0x5a5d5a) {
                return _0x1eb773(_0x48d5aa, _0x5a5d5a);
            },
        }
    ''')
    obj = o.extract_object(objname)


# Generated at 2022-06-24 13:58:11.894674
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:58:22.807268
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    JSInterpreter_instance = JSInterpreter(code='code')
    assert JSInterpreter_instance.interpret_statement('a=1', {'a':0}) == (1, False)
    assert JSInterpreter_instance.interpret_statement('return a', {'a':1}) == (1, True)
    assert JSInterpreter_instance.interpret_statement('return', {}) == (None, True)
    assert JSInterpreter_instance.interpret_statement('var a = 1', {}) == (1, False)
    assert JSInterpreter_instance.interpret_statement('var b=1;a=b', {'b':1}) == (1, False)
    assert JSInterpreter_instance.interpret_statement('var a = 1; b = a', {'a':1}) == (1, False)
   

# Generated at 2022-06-24 13:58:31.017083
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = r'''
    a = 3;
    b = 4;
    c = a + b;
    c;
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.interpret_expression(code, {'a': 3, 'b': 4}) == 7
    assert JSInterpreter('''
        function hello(a) {
            a(5);
        }
    ''').call_function('hello', lambda x: x * 3) == 15
    assert JSInterpreter('''
        function reverseTwice(a) {
            a.reverse();
            a.reverse();
        }
    ''').call_function('reverseTwice', [1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-24 13:58:38.945032
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test = '''
    ns = {aFunc: function(arg1, arg2) {if (arg1 == arg2) return true; return false;},
           aNumber: 5};
    '''

    js = JSInterpreter(test)
    ns = js.extract_object('ns')

    assert ns['aFunc'](6, 5) == False
    assert ns['aFunc'](5, 5) == True

    assert ns['aNumber'] == 5


# Generated at 2022-06-24 13:58:42.918064
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    interpreter = JSInterpreter("""
        function func(a, b, c) {
            return (a + b) / c;
        }
    """)
    assert interpreter.call_function('func', 2, 5, 2) == 3.5


# Generated at 2022-06-24 13:58:51.221281
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = r'''
    function f(arg1, arg2) {
        return arg1 + arg2;
    }
    '''
    js_interpreter = JSInterpreter(js_code)
    result = js_interpreter.interpret_expression('f(2, 3)', {}, allow_recursion=100)
    assert result == 5

if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-24 13:59:01.700883
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    a = js_interpreter.interpret_statement('var e = [];', {})
    assert a == (None, False)
    b = js_interpreter.interpret_statement('2;', {})
    assert b == (2, False)
    c = js_interpreter.interpret_statement('var e=2;', {})
    assert c == (None, False)
    d = js_interpreter.interpret_statement('e=2;', {})
    assert d == (None, False)
    e = js_interpreter.interpret_statement('if (1) e=2;', {})
    assert e == (None, False)
    f = js_interpreter.interpret_statement('return e;', {})

# Generated at 2022-06-24 13:59:11.345541
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''var a,b,c;b=[{u:function(x,y){return x - y}},{y:function(a){return a + a}},{z:function(a,b){return a * b}}]; c = a.y(2);'''
    i = JSInterpreter(code)
    v = i.interpret_expression('b[1].y(2)', {'a': {'y': lambda x: x + x}})
    assert v == 4

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print('Usage: %s <file.js>' % sys.argv[0])
        sys.exit(1)

# Generated at 2022-06-24 13:59:19.049873
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    import unittest
    class JSInterpreterTest(unittest.TestCase):
        def test_call_function(self):
            code = """
                function abc(a, b) { return a + b; }
            """
            js = JSInterpreter(code)
            self.assertEqual(js.call_function('abc', [1, 2]), 3)
    unittest.main()

if __name__ == "__main__":
    test_JSInterpreter_call_function()

# Generated at 2022-06-24 13:59:27.925199
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter('var x = 3;')
    result, abort = interpreter.interpret_statement('x', {})
    assert result == 3
    assert abort == False
    try:
        interpreter.interpret_statement('y', {})
        assert False
    except ExtractorError:
        pass

    interpreter = JSInterpreter('var x = 3; var y;')
    result, abort = interpreter.interpret_statement('x', {})
    assert result == 3
    assert abort == False
    result, abort = interpreter.interpret_statement('y', {})
    assert result == None
    assert abort == False

    interpreter = JSInterpreter('var x = 3; var y;')
    result, abort = interpreter.interpret_statement('x', {'x': 5})
    assert result == 3
    assert abort == False

    interpreter

# Generated at 2022-06-24 13:59:36.616542
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:59:44.472612
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():

    def build_function(code):
        js_interpreter = JSInterpreter(code)
        return js_interpreter.build_function(['a', 'b'], code)

    code1 = 'a + b'
    f = build_function(code1)
    assert f((1, 2)) == 3

    code2 = 'return a * b;'
    f = build_function(code2)
    assert f((3, 4)) == 12



# Generated at 2022-06-24 13:59:55.587532
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    class FakeObject(object):
        def __init__(self):
            self.__members = {'value': 'value'}

        def __getitem__(self, key):
            return self.__members[key]

    local_vars = {
        'a': 2,
        'b': 3,
        'c': [1, 2, 3],
        'd': 'd',
        'e': FakeObject()
    }
    js_interpreter = JSInterpreter('')

    # Test simple assignment
    assert js_interpreter.interpret_statement('a=4', local_vars)[0] == 4
    assert js_interpreter.interpret_statement('var b=5', local_vars)[0] == 5

# Generated at 2022-06-24 13:59:56.717863
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
        assert JSInterpreter('var test = 2').interpret_statement('var test = 2', {}) == (2, False)

# Generated at 2022-06-24 14:00:04.294959
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var a = {
            foo: function() {},
            bar: function(baz) {}
        };

        var b = {
            baz: function() {}
        };
        '''
    interp = JSInterpreter(code)
    assert 'a' in interp._objects
    assert 'b' in interp._objects
    a = interp._objects['a']
    assert 'foo' in a
    assert 'bar' in a
    b = interp._objects['b']
    assert 'baz' in b
    # print(a)
    # print(b)
