

# Generated at 2022-06-24 13:50:00.354759
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = ''
    jsi = JSInterpreter(js)
    jsi.call_function('func', 'a')


# Generated at 2022-06-24 13:50:07.792647
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    interpreter = JSInterpreter('''
        var obj = {
            "func1": function(a, b){
                return a + b;
            },
            "func2": function(a, b, c){
                return [a, b, c];
            }
        };
    ''')
    obj = interpreter.extract_object('obj')

    # Test obj['func1']
    assert obj['func1'](1, 2) == 3

    # Test obj['func2']
    assert obj['func2'](1, 2, 3) == [1, 2, 3]

    # Test a non-existent function
    try:
        obj['func3']()
        assert False
    except KeyError:
        pass

    # Test obj['length']
    assert len(obj) == 2


# Generated at 2022-06-24 13:50:17.277753
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    raw_js = """function o(a) {
        a.reverse();
    }"""
    js = JSInterpreter(raw_js)
    func = js.extract_function('o')
    l = [1, 2, 3]
    func([l])
    assert l == [3, 2, 1]

    raw_js = """function l(a) {
        a = a.split("");
        h(a, 1);
        return a.join("")
    }"""

    js = JSInterpreter(raw_js)
    func = js.extract_function('l')
    assert func(['abc']) == 'bac'



# Generated at 2022-06-24 13:50:21.173783
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        function test(){
            return "test";
        }
    """
    jsi = JSInterpreter(code, objects={})
    f = jsi.extract_function("test")
    assert f() == "test"


# Generated at 2022-06-24 13:50:28.781123
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = [];
        a[0] = [1, 2];
        a[1] = [3, 4];
        myObj = {
            func1: function(a, b) {
                return a + b;
            },
            func2: function(c, d) {
                return c - d;
            }
        };
    """
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('myObj')
    assert len(obj) == 2
    assert obj['func1'](3, 5) == 8
    assert obj['func2'](5, 3) == 2


# Generated at 2022-06-24 13:50:38.215145
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_code = """
    var a = 1;
    var b = 'string'
    var c = function(){};
    var d = '\\\\x3c';
    var e = [1, 2, 3, 4];
    var f = {'a': 1};
    """
    js_interpreter = JSInterpreter(js_code)

    test_code = [
        ('a', 1),
        ('b', 'string'),
        ('c', 'function(){}'),
        ('d', '\\x3c'),
        ('e', [1, 2, 3, 4]),
        ('f', {'a': 1})
    ]
    for code, expect in test_code:
        result, should_abort = js_interpreter.interpret_statement(code, {})

# Generated at 2022-06-24 13:50:48.835318
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterp = JSInterpreter("")

    # simple cases
    result = jsinterp.interpret_expression("\"a\"+\"b\"", {})
    assert result == "ab"

    result = jsinterp.interpret_expression("\"a\"+\"b\"+\"c\"", {})
    assert result == "abc"

    # nested parentheses
    result = jsinterp.interpret_expression("(\"a\"+\"b\")", {})
    assert result == "ab"

    result = jsinterp.interpret_expression("(\"a\"+\"b\")+(\"c\"+\"d\")", {})
    assert result == "abcd"

    # nested expressions
    result = jsinterp.interpret_expression("\"a\"+(\"b\"+\"c\")", {})
    assert result == "abc"

# Generated at 2022-06-24 13:50:58.898884
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:51:08.348389
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
	code = """
		var b = {
			'c': function(a) {
				return (a + 1) * 3;
			}
		};
		var d = function (e) {
			var f = e.split('');
			f = f.reverse();
			return f.join('')
		};
	"""
	jsi = JSInterpreter(code)
	assert jsi.call_function('d','123') == '321'
	assert jsi._objects['b']['c'](40) == 123

# Generated at 2022-06-24 13:51:10.317154
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    any_instance = JSInterpreter('')
    any_argnames = []
    any_code = ''
    assert callable(any_instance.build_function(any_argnames, any_code))


# Generated at 2022-06-24 13:51:17.789816
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    objects = {}

# Generated at 2022-06-24 13:51:25.033287
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = """
        var obj = {
            "f": function(a,b) { return a+b; },
            "g": function(a,b) { return a-b; }
        };
        """
    jsi = JSInterpreter(js_code)
    obj = jsi.extract_object('obj')
    assert obj['f'](2, 3) == 5
    assert obj['g'](2, 3) == -1

# Generated at 2022-06-24 13:51:32.454379
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:51:38.781732
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:51:47.099332
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    from pprint import pprint
    code = '''
        var f = function(a, b) {
            return a + b;
        };
        var g = {
            'foo': function() {},
            'bar': function() { return 1; }
        };
        var h = function() {
            var a = 1, b = 2;
            return a + b;
        };
    '''
    js = JSInterpreter(code)
    assert js.extract_function('f')((3, 4)) == 7
    assert js.call_function('g.bar') == 1
    assert js.call_function('h') == 3

if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-24 13:51:56.282663
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:52:09.091614
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    print("Running JSInterpreter unit tests")
    jsi = JSInterpreter(
"""
function foo(a, b) {
    return a + b + 1;
}
function bar(a, b, c) {
    var _0x8ddcx2 = function (a, b) {
        return a + b;
    }
    return _0x8ddcx2(a, b) + c;
}
""")
    print("Passed unit test: foo")
    assert jsi.call_function('foo', 10, 20) == 31
    print("Passed unit test: bar")
    assert jsi.call_function('bar', 10, 20, 1) == 31

if __name__ == "__main__":
    test_JSInterpreter_call_function()

# Generated at 2022-06-24 13:52:18.013319
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code1 = '''
        function foo(a, b) { return function(c) { return a + b + c; } }
        function bar(a, b) { return a * b; }
    '''
    js_interpreter1 = JSInterpreter(js_code1)
    assert js_interpreter1.call_function('foo', 1, 2)(3) == 6
    assert js_interpreter1.call_function('bar', 3, 5) == 15

    js_code2 = '''
        function dec(x){
            function mul(a, b, c) {
                return a * b * c;
            }
            return mul(x, 2, 4);
        }
    '''
    js_interpreter2 = JSInterpreter(js_code2)
    assert js

# Generated at 2022-06-24 13:52:26.579114
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Instanciate the class
    interpreter = JSInterpreter('')
    # Define the code
    code = '''
    function helper() {
        var a = 'some';
        var c = a + ' string';
        return c;
    }
    '''
    # Define the expected output
    expected = "some string"
    # Call the tested method
    result = interpreter.extract_function("helper")()
    # Check that result and expected are equals
    assert(result == expected)

# Generated at 2022-06-24 13:52:32.360496
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = '''
    var obj = {
        "a": function(x) { return x; },
        "b": function(x) { return x + 1; }
    }
    '''
    jsi = JSInterpreter(js)
    assert jsi.interpret_expression("obj.a(5)", {}, 100) == 5
    assert jsi.interpret_expression("obj.b(5)", {}, 100) == 6



# Generated at 2022-06-24 13:52:37.195100
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var obj = {
            foo: 12,
            bar: function(){
                console.log("hello")
            }
        }
        '''
    js = JSInterpreter(code)
    assert js.code == code
    assert js._functions == {}
    assert js._objects == {}

test_JSInterpreter()


# Generated at 2022-06-24 13:52:44.578555
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        my_obj = {
            split: function(str) {
                return str.split("_");
            },
            join: function(array) {
                return array.join("_");
            },
            reverse: function(array) {
                var that = array.slice(0).reverse();
                return that;
            },
            slice: function(array, start) {
                return array.slice(start);
            },
            splice: function(array, start, deleteCount, item) {
                return array.splice(start, deleteCount, item);
            }
        }
        funct = function(a,b,c) {
            var e = (a + b - c);    
            return e;
        }
    '''
    interpreter = JSInterpreter(code)
    assert interpreter

# Generated at 2022-06-24 13:52:50.063788
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    # Test 1
    code = '''\
        function foo(abc) {
            var pqr = 'lol';
            return abc + pqr;
        }
    '''
    interpreter = JSInterpreter(code)
    results = interpreter.call_function('foo', 'abc')
    assert results == 'abclol'


# Generated at 2022-06-24 13:52:56.191150
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var obj = {
            a: function(p1, p2) {
                return p1 + p2;
            },
            b: function(p1, p2) {
                return p1 - p2;
            }
        };
    '''
    jsi = JSInterpreter(js_code)
    obj = jsi.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1
    assert 'c' not in obj


# Generated at 2022-06-24 13:53:05.009798
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function name1() {
            function func1(){
                func2()
            }
        }
        function func2() {
            var val1 = 123
            return val1
        }
        name1();
    '''
    js_interpreter = JSInterpreter(code)
    func2 = js_interpreter.extract_function('func2')
    val1 = func2()
    assert(val1 == 123)



# Generated at 2022-06-24 13:53:15.268170
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    assert JSInterpreter('''(function (a) { var b = a.split('_'); return b[0];})("foo_bar")''').call_function('', 'foo_bar') == 'foo'
    assert JSInterpreter('''(function(a,b){while(a!=b){if(a>b)a=a-b;else b=b-a;}return a;})(99,88)''').call_function('', 99, 88) == 11
    assert JSInterpreter('''(function(a,b){while(a!=b){if(a>b)a=a-b;else b=b-a;}return a;})(99,88)''').call_function('', 99, 88) == 11

# Generated at 2022-06-24 13:53:24.948015
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
	code = '''
		var s = {
			abc: function(a,b,c) {
				return a+b+c;
			},
			def: function(a,b,c) {
				return a*b*c;
			},
			ghi: function(a,b,c) {
				return a-b-c;
			},
		}
	'''
	j = JSInterpreter(code)
	obj = j.extract_object('s')
	for key in obj.keys():
		assert obj[key](*range(1,4)) == eval('1' + key + '2' + key + '3')

test_JSInterpreter_extract_object()

# Generated at 2022-06-24 13:53:33.932031
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    import unittest

    class TestJSInterpreter(unittest.TestCase):
        def setUp(self):
            self.interpreter = JSInterpreter('', {
                'id': '5c5d5e5f',
                'privkey': [1, 2, 3, 4, 5, 6, 7, 8, 9, 0],
                'String': {
                    'fromCharCode': lambda args: ''.join(map(chr, args)),
                    'split': lambda args: list(args[0]),
                    'join': lambda args: args[0].join(args[1]),
                }
            })

        def test_string(self):
            self.assertEqual(self.interpreter.interpret_expression('"foo"'), 'foo')

# Generated at 2022-06-24 13:53:39.712284
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():

    assert JSInterpreter('function test(a,b) {if (a > b){a=b}return a}').extract_function('test')([4, 5]) == 4
    assert JSInterpreter('function test(a,b) {if (a < b){a=b}return a}').extract_function('test')([4, 5]) == 5
    assert JSInterpreter('function test(a,b) {return a+b}').extract_function('test')([4, 5]) == 9
    assert JSInterpreter('function test(a,b) {return a-b}').extract_function('test')([4, 5]) == -1
    assert JSInterpreter('function test(a,b) {return a*b}').extract_function('test')([4, 5])

# Generated at 2022-06-24 13:53:48.166791
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
    var obj = {
        obj_func_1: function () {return 1;}
    };
    function func_1() {
        return obj.obj_func_1();
    }
    function func_2(arg1) {
        return arg1;
    }
    '''
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('func_1') == 1
    assert interpreter.call_function('func_2', 2) == 2


# Generated at 2022-06-24 13:53:57.767783
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var A;
        A = {
            a:function(a){a.reverse()},
            b:function(a,b){},
        };
        var B = {
            c:function(a){a.join('')},
            d:function(a,b){},
        }
    '''
    interpreter = JSInterpreter(js_code)
    assert len(interpreter._objects) == 0
    # Extract A
    obj = interpreter.extract_object('A')
    assert isinstance(obj, dict)
    assert obj['a']
    assert callable(obj['a'])
    assert obj['b']
    assert callable(obj['b'])
    # Extract B
    obj = interpreter.extract_object('B')

# Generated at 2022-06-24 13:54:07.968147
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter('')
    local_vars = {}
    assert js.interpret_statement('var xy = "abc";', local_vars) == ('abc', False)
    assert js.interpret_statement('var x = 123;', local_vars) == (123, False)
    assert local_vars['xy'] == 'abc'
    assert local_vars['x'] == 123
    assert js.interpret_statement('x = 756;', local_vars) == (756, False)
    assert local_vars['x'] == 756
    assert js.interpret_statement('return 756;', local_vars) == (756, True)
    assert local_vars['x'] == 756


# Generated at 2022-06-24 13:54:11.594797
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = {b:function(){return 1;},c:function(){return "2";}};
        """
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj == {'b': {'returnValue': 1}, 'c': {'returnValue': '2'}}


# Generated at 2022-06-24 13:54:19.510538
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    import sys
    if sys.version_info < (3, 0):
        from io import BytesIO as DataIO
    else:
        from io import StringIO as DataIO
    code = '''
    var a;
    function b(x,y) {
        return x + 1,
        a = x + y + 1;
    }
    var c = b;
    var d = {
        e: function(f, g) {
            return f + g;
        },
        'h': function(i) {
            return i * i;
        }
    };
    var j = d.e;
    var k = d['h'];
    '''

    js_interpreter = JSInterpreter(code)
    js_interpreter.call_function('b', 3, 5)

# Generated at 2022-06-24 13:54:26.595477
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    inst = JSInterpreter('')
    argnames = ['a', 'b']
    code = '''
        var c;
        c = a + b;
        return c;
    '''
    resf = inst.build_function(argnames, code)
    assert resf([3, 4]) == 7

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-24 13:54:34.792929
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
        var a = function () {
            return 'a';
        };
        var b = function (arg1, arg2) {
            return [arg1, arg2];
        };
        var c = function (arg1, arg2) {
            return arg1 + arg2;
        };
    """
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('a') == 'a'
    assert js_interpreter.call_function('b', 1, 2) == [1, 2]
    assert js_interpreter.call_function('c', 1, 2) == 3



# Generated at 2022-06-24 13:54:40.846936
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function testfunction(arg1,arg2,arg3,arg4,arg5,arg6,arg7) {
            var outvar = "start";
            var $=function(a){return a};
            var a={"c":function(a){outvar+=a;}, "b":function(a){outvar+=a;}};
            a.b(arg1);
            a.c(arg2);
            a.c(arg3);
            outvar = 0 + outvar;
            a.c(arg4);
            a.c(arg5);
            a.c(arg6);
            outvar = outvar + arg7;
            return outvar;
        }'''
    jsinterpreter = JSInterpreter(code)

# Generated at 2022-06-24 13:54:50.904094
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:55:00.318969
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test(funcname, code, expected, *args):
        qargs = [json.dumps(v) for v in args]
        qexpr = code.format(*[json.dumps(v) for v in args])
        interpreter = JSInterpreter('')
        interpreter._objects = {'a': args[0]}
        f = interpreter.build_function([str(i) for i in range(len(qargs))], qexpr)
        res = f(args)
        assert res == expected, '%s(%s) = %r != %r for %r' % (funcname, ','.join(qargs), res, expected, code)

    # Basic arithmetic from http://www.w3schools.com/js/js_operators.asp

# Generated at 2022-06-24 13:55:04.269006
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''var a = 10; var b = 20; var c = 30;'''
    objects = {}
    interpreter = JSInterpreter(code, objects)
    local_vars = {}
    interpreter.interpret_statement(code, local_vars)
    assert local_vars['a'] == 10
    assert local_vars['b'] == 20
    assert local_vars['c'] == 30


# Generated at 2022-06-24 13:55:13.683730
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:55:16.058295
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''function hi() {return hola;} var hola = "hello";'''
    JSInterpreter(code).call_function('hi')
    return True



# Generated at 2022-06-24 13:55:28.240885
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = '''
        function q(a) {
            var d = a.split(""),
                e = d.length,
                f = z.charAt(64);
            if (64 < e) {
                for (var g = 0, h = ""; g < e; g++) h += d[g] ^ f;
                d = h
            }
            a = "";
            e = d.length;
            for (f = 0; f < e; f++) g = d.charCodeAt(f),
            a += String.fromCharCode(g >>> 7 ^ g);
            return a
        }'''

# Generated at 2022-06-24 13:55:39.649783
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = "var cfg = {'TOKEN': 'test'};"
    interp = JSInterpreter(code)
    stmt = "var a = 1;"
    (res, abort) = interp.interpret_statement(stmt, {'cfg': {'TOKEN': 'test'}})
    assert not abort
    assert res == 1
    stmt = "var b = a+1;"
    (res, abort) = interp.interpret_statement(stmt, {'a': 1, 'cfg': {'TOKEN': 'test'}})
    assert not abort
    assert res == 2
    stmt = "var c = a + cfg.TOKEN;"
    (res, abort) = interp.interpret_statement(stmt, {'a': 1, 'cfg': {'TOKEN': 'test'}})

# Generated at 2022-06-24 13:55:47.792750
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test 1
    code = '''var c=b.length;var d=a[0];var e=a[c%d];var f=c+d;var g=f+e*(c-e);'''
    interp = JSInterpreter(code)
    a, b, c, d, e, f, g = range(7)
    local_vars = {
        'a': a,
        'b': b,
        'c': c,
        'd': d,
        'e': e,
        'f': f,
        'g': g,
    }
    for stmt in code.split(';'):
        res, abort = interp.interpret_statement(stmt, local_vars)
        if abort:
            break
    assert res == 15
    assert local_

# Generated at 2022-06-24 13:55:55.746675
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # "f" calls function "g" once and quits.
    # When "g" is called, it returns "10".
    f_code = """
        var f = function(){return g()};
        var g = function(){return 10};
    """
    f = JSInterpreter(f_code)
    assert f.call_function("f") == 10

    # "f" calls function "g" twice and returns the sum of both results.
    # When "g" is called, it returns "10".
    f_code = """
        var f = function(){return g() + g()};
        var g = function(){return 10};
    """
    f = JSInterpreter(f_code)
    assert f.call_function("f") == 20

    # "f" calls function "g" with "10" as parameter

# Generated at 2022-06-24 13:56:04.669860
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = (
        'var abc = function(x, y, z) {'
        '    a = x + y;'
        '    b = x + z;'
        '    c = y + z;'
        '    return (a, b, c);'
        '};')
    func = JSInterpreter(js_code).build_function(['x', 'y', 'z'], js_code[js_code.index('{') + 1:len(js_code) - 2])
    assert func((1, 2, 3)) == (3, 4, 5)

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 13:56:12.897502
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code ='''
    function a() {return func2(0);}
    function b() {return a();}
    function c() {return b();}
    function d() {return func1("1234");}
    function e() {return func1("1234");}
    function f() {return func2(2);}
    function func1(a) {return a;}
    function func2(a) {return a;}
    '''
    js_interpreter =JSInterpreter(js_code)

    assert js_interpreter.call_function("a") == 0
    assert js_interpreter.call_function("b") == 0
    assert js_interpreter.call_function("c") == 0
    assert js_interpreter.call_function("d") == "1234"
   

# Generated at 2022-06-24 13:56:23.677578
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter('')
    assert interpreter.interpret_expression('2+2', {}) == 4
    assert interpreter.interpret_expression('7*3', {}) == 21
    assert interpreter.interpret_expression('7*3+3', {}) == 24
    assert interpreter.interpret_expression('5/2', {}) == 2.5
    assert interpreter.interpret_expression('2+2', {'a': 11}) == 4
    assert interpreter.interpret_expression('a+1', {'a': 11}) == 12
    assert interpreter.interpret_expression('a+1', {}) == 1
    assert interpreter.interpret_expression('1+2+3', {}) == 6
    assert interpreter.interpret_expression('1+2*3', {}) == 7
    assert interpreter.interpret_expression('1*2+3', {}) == 5


# Generated at 2022-06-24 13:56:35.803516
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    """ JSInterpreter - extract_function test """

# Generated at 2022-06-24 13:56:40.901932
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function test_function(id) {
            return "test_function_" + id;
        }
    '''

    js = JSInterpreter(code)
    assert js.call_function('test_function', 'test_id') == 'test_function_test_id'



# Generated at 2022-06-24 13:56:47.175197
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test for method interpret_expression of class JSInterpreter.
    # Test for operator precedence.
    operators = re.escape('+-*/%|^&<<>>') + '='
    operators_lst = []
    for i in range(len(operators)):
        operators_lst.append(operators[i:i + 1])
    operators_lst = '|'.join(operators_lst)
    operators_lst = operators_lst.replace('=', '=\s*[^;]*;')
    operators_lst = operators_lst.replace('<<', '<<\s*[^;]*;')
    operators_lst = operators_lst.replace('>>', '>>\s*[^;]*;')

# Generated at 2022-06-24 13:56:53.388069
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:57:04.457343
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    import unittest
    class Test(unittest.TestCase):
        def test_build_function(self):
            self.assertEqual(
                JSInterpreter('').\
                build_function([], 'return a+b')((1, 2)),
                3)
            self.assertEqual(
                JSInterpreter('').\
                build_function(['a'], 'return a+1')((2,)),
                3)
            self.assertEqual(
                JSInterpreter('').\
                build_function(['a', 'b'], 'return a+b')((1, 2)),
                3)

# Generated at 2022-06-24 13:57:15.129405
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    def assert_interpret_expression(expr, expectation):
        interpreter = JSInterpreter(black_hole)
        interpreter.interpret_expression(expr, {})
        assert interpreter.interpret_expression(expr, {}) == expectation

    # Testing simple operations
    black_hole = '''
        var a = 5;
        var b = 6;
    '''
    assert_interpret_expression('a', 5)
    assert_interpret_expression('a+b', 11)
    assert_interpret_expression('a-b', -1)
    assert_interpret_expression('a*b', 30)
    assert_interpret_expression('a/b', 5/6.)
    assert_interpret_expression('a%b', 5)
    assert_interpret_expression('a<<b', 160)
    assert_interpret_expression('a>>b', 0)
   

# Generated at 2022-06-24 13:57:23.083346
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''var abcdef = 543;
var test_func = function (arg1, arg2) {
    var out = "arg3";
    var inner_func = function (inner_arg1, inner_arg2) {
        var inner_func_out = inner_arg1 + inner_arg2;
        return inner_func_out;
    }
    out = inner_func(arg1, arg2);
    return out;
}'''

    # Test for valid case
    result = JSInterpreter(code).extract_function("test_func")
    assert result("2", "3") == "5", "extract_function with valid" \
        " function name is incorrect"

    # Test for case of invalid function name

# Generated at 2022-06-24 13:57:33.610779
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Arrange
    expr = 'strencode("abc")'

# Generated at 2022-06-24 13:57:44.674905
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = r'''
    var a = "abc";
    var b = [];
    b[0] = function(){ return "def"; }
    b[1] = 3;
    b[2] = {'foo': 'bar'};
    var c = "ghi";
    var d = 10;
    var e = {'foo': {'bar': 'foobar'}}
    '''
    js = JSInterpreter(js_code)

    # String simple evaluation
    assert 'abc' == js.interpret_expression("a", js._functions)

    # String function call
    assert 'ghi' == js.interpret_expression("c.slice(1)", js._functions)

    # Array access
    assert 'def' == js.interpret_expression("b[0]()", js._functions)

   

# Generated at 2022-06-24 13:57:54.673684
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
    var z = function(a,b){
        return a+b;
    }'''
    interpreter = JSInterpreter(code)
    res = interpreter.extract_function('z')([3, 5])
    assert res == 8

    code = "var z = function(a,b){a+b}"
    interpreter = JSInterpreter(code)
    res = interpreter.extract_function('z')([3, 5])
    assert res == 8

    code = "function z(a,b){a+b}"
    interpreter = JSInterpreter(code)
    res = interpreter.extract_function('z')([3, 5])
    assert res == 8

    code = '''
    var log = function(str){
        print(str);
    }'''
    interpreter

# Generated at 2022-06-24 13:57:57.804127
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsInterpreter = JSInterpreter("""function test(a, b) {
        return a + b;
    }""")
    assert jsInterpreter.call_function("test", 201, 10) == 211
    assert jsInterpreter.call_function("test", "201", 10) == "20110"

# Generated at 2022-06-24 13:58:08.054554
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    test_str_01 = 'var a=1,b=2;'
    test_str_02 = 'var a = 1, b = 2;'
    jsint_01 = JSInterpreter(test_str_01)
    jsint_02 = JSInterpreter(test_str_01)
    jsint_03 = JSInterpreter(test_str_02)
    assert jsint_01.code == test_str_01
    assert jsint_02.code == test_str_01
    assert jsint_03.code == test_str_02
    assert jsint_01._functions == {}
    assert jsint_01._functions is jsint_02._functions
    assert jsint_01._objects == {}
    assert jsint_01._functions is jsint_02._functions
    assert js

# Generated at 2022-06-24 13:58:20.393276
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objname = "peer"
    code = '''
            var peer = {
                mv: function(a) {
                    a.reverse()
                },
                mv2: function(a) {
                    a.splice(0, 1)
                },
                sz: function(a) {
                    return a.length
                },
                u: function(a) {
                    a.splice(0, a.length)
                }
            };
            '''
    js = JSInterpreter(code, {})
    obj = js.extract_object(objname)

    # Test object method mv
    test = list(range(20))
    obj['mv'](test)
    assert test == list(reversed(range(20)))

    # Test object method mv2

# Generated at 2022-06-24 13:58:29.888229
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test(func_str, func_arg, expected):
        resf = JSInterpreter(func_str, {}).build_function([], func_str)
        result = resf(func_arg)
        assert result == expected
    jsinter = JSInterpreter('', {})
    test('function retval(a,b) {return a+b;}', (1, 2), 3)
    test('function retval(a,b) {var c=a+b;return c;}', (1, 2), 3)
    test('function retval(a,b) {var c=a+b;var d=c+1;return d;}', (1, 2), 4)

# Generated at 2022-06-24 13:58:37.410218
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    var foo = {
        bar: function() {
            return "bar";
        },
        baz: function(b) {
            return "baz";
        },
    };
    '''
    objects = {}
    JSInterpreter(code, objects)
    assert len(objects) == 1
    assert objects['foo']['bar']() == "bar"
    assert objects['foo']['baz']() == "baz"


# Generated at 2022-06-24 13:58:45.256961
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:58:52.525315
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # For example: function z(a){a=a.split("");a=a.reverse();a=a.join("");return a};
    func_str = '''function z(a){a=a.split("");a=a.reverse();a=a.join("");return a};'''
    obj = JSInterpreter(func_str)
    assert obj.call_function('z', 'abc') == 'cba'



# Generated at 2022-06-24 13:59:00.912536
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    obj={"iNqxqo": "uV7Gn", "yzq": "kFtp"}
    js_interpreter=JSInterpreter(None,obj)
    stmt=["var a=12", "var y=1", "var c=a+y", "return c", "var b=a+y", "return b", "return a", "var a=12","return a"]
    final_result={}
    for st in stmt:
        res,abort=js_interpreter.interpret_statement(st,final_result)
        print(st, res, abort)

if __name__=="__main__":
    test_JSInterpreter_interpret_statement()

# Generated at 2022-06-24 13:59:10.761643
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:59:21.728630
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Testing the JSInterpreter object
    js_interp = JSInterpreter('''function f1(arg1, arg2) { return arg1 + arg2; }''')
    assert js_interp.call_function('f1', 2, 3) == 5

    # Testing re.search()
    js_interp = JSInterpreter('''function f1(a, b) { return a + b; }''')
    assert js_interp.call_function('f1', 2, 3) == 5

    # Testing re.search()
    js_interp = JSInterpreter('''function f1(a, b) { return a + b; }''')
    assert js_interp.call_function('f1', 2, 3) == 5

    # Testing extract_function()
    js_interp

# Generated at 2022-06-24 13:59:29.895014
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:59:37.223533
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsinterp = JSInterpreter('''
        el = {
            tab: function(a, b) {
                return a + b;
            }
        }''')

    assert jsinterp.extract_object('el') == {'tab': lambda x, y : x + y}

    jsinterp = JSInterpreter('''
        el = {
            tab: function(a, b) {
                var c = 2;
                return a + b + c;
            },
            truc: function(d) {
                return d*2;
            }
        }''')

    assert jsinterp.extract_object('el') == {
        'tab': lambda x, y : x + y + 2,
        'truc': lambda x : x*2
    }

# Generated at 2022-06-24 13:59:42.465483
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = """
    function abc(a, c) {
        var b = a;
        return a + b + c;
    }
    """
    assert JSInterpreter(js).call_function("abc", 1, 2) == 4


# Generated at 2022-06-24 13:59:53.793729
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:59:58.634391
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = r'''
    var a = {
        "b": function () {
        return 10;
        },
        "c": 20
    };
    var foo = function(p, q, r) {
        return p + q + r + this.d + a.c;
    };
    var d = 30;
    '''
    jsi = JSInterpreter(code)
    assert jsi.call_function('foo', 5, 10, 15) == 70


# Generated at 2022-06-24 14:00:08.501345
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    assert JSInterpreter('').interpret_statement('x=1+3', {'x':0}) == (4, False)
    assert JSInterpreter('').interpret_statement('x=1+3;', {'x':0}) == (4, False)
    assert JSInterpreter('').interpret_statement('1+3', {'x':0}) == (4, False)
    assert JSInterpreter('').interpret_statement('x=1+3', {'x':0}) == (4, False)
    assert JSInterpreter('').interpret_statement('return x', {'x':4}) == (4, True)
    assert JSInterpreter('').interpret_statement('return (1+3)', {'x':4}) == (4, True)
    assert JSInterpreter('').interpret