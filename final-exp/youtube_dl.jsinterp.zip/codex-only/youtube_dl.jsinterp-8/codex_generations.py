

# Generated at 2022-06-24 13:50:10.826059
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    assert JSInterpreter('').interpret_statement('x = 5', {}) == (5, False)
    assert JSInterpreter('').interpret_statement('return x', {'x': 5}) == (5, True)
    assert JSInterpreter('').interpret_statement('return x + 5', {'x': 5}) == (10, True)
    assert JSInterpreter('').interpret_statement('return x + 5', {}) == (None, True)
    assert JSInterpreter('').interpret_statement('x = y + 5', {'y': 5}) == (10, False)
    assert JSInterpreter('').interpret_statement('x = y + 5', {}) == (None, False)

# Generated at 2022-06-24 13:50:17.283496
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Test for function "b"
    js_code = r"""
        (function(a,b,c){
            function f(a){
                c=a;
                return;
            }
            f(b);
        })(1,2,3);
    """
    interpreter = JSInterpreter(js_code)
    fb = interpreter.extract_function('b')
    assert fb(5) == 2


# Generated at 2022-06-24 13:50:20.437663
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter.build_function(['a'], ';')(['foo']) is None


if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-24 13:50:29.386143
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function cet(a, b) {
            return a + b;
        }

        function set(a, b) {
            return a * b;
        }

        function getValue() {
            return 5;
        }

        var test_arr = new Array(1, 2, 3, 4, 5);
    '''
    interpreter = JSInterpreter(js_code)
    assert interpreter.call_function('cet', 4, 5) == 9
    assert interpreter.call_function('set', 2, 4) == 8
    assert interpreter.call_function('getValue') == 5
    test_arr = JSInterpreter(js_code).call_function('test_arr')
    assert test_arr == list(range(1, 6))



# Generated at 2022-06-24 13:50:38.566493
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:50:47.681650
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    s = '''
    ytplayer = {
        "config": {
            "url": "blabla"
        },
        "fpData": {
            "running": false,
            "sid": null,
            }
        }
    function blah(a,b,c)
    {
        return a + b - c;
    }
    '''
    jsi = JSInterpreter(s)
    jsi._objects = {'ytplayer': {'config': {'url': ''}, 'fpData': {}}}
    f = jsi.extract_function('blah')
    assert f((10, 10, 2)) == 18



# Generated at 2022-06-24 13:50:56.791621
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Step 1: check for arithmetic operation
    obj = {"a": {"b": 5}}
    i = JSInterpreter(code='a.b = (1 + 1)', objects=obj)
    assert i.interpret_expression('(1 + 1)', obj) == 2
    assert i.interpret_expression('(1 & 1)', obj) == 1

    # Step 2: check for member access
    obj = {"a": {"b": 5}}
    i = JSInterpreter(code='a.b = (1 + 1)', objects=obj)
    assert i.interpret_expression('a.b', obj) == 5
    assert i.interpret_expression('a[b]', obj) == 5
    assert i.interpret_expression('a["b"]', obj) == 5

    # Step 3: check for recursive call

# Generated at 2022-06-24 13:51:01.328600
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:51:05.407368
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        xxx.yyy = {
            decode: function(a) {
                return a.reverse();
            },
            encode: function(a) {
                return a.reverse();
            }
        }
        function tritanomaly(a) {
            return xxx.yyy.decode(a);
        }
    '''
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('tritanomaly', list('abc')) == list('cba')


# Generated at 2022-06-24 13:51:10.861725
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:51:23.378563
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():

    # Test function signature
    test_code = '''
    function func1(arg1, arg2) {
        ...
    }
    '''

    interp = JSInterpreter(test_code)
    f = interp.extract_function("func1")
    assert callable(f)
    assert f("a", "b") == None

    # Test functions with same name
    # The interpreter will only extract the first function with the same name
    test_code = '''
    function func1(arg1, arg2) {
        ...
    }

    function func1(arg1, arg2) {
        ...
    }
    '''

    interp = JSInterpreter(test_code)
    f = interp.extract_function("func1")
    assert callable(f)
    assert f

# Generated at 2022-06-24 13:51:33.312638
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r'''var obj1 = {"a": function(p){return p;}};'''
    interpreter = JSInterpreter(code)
    assert {"a": lambda x: x} == interpreter.extract_object("obj1")

    code = r'''var obj2 = {"a": function(p){return p;}, "b": function(p){return p.join("");}};'''
    interpreter = JSInterpreter(code)
    assert {"a": lambda x: x, "b": lambda x: "".join(x)} == interpreter.extract_object("obj2")

    code = r'''var obj3 = {"a": function(p){return p;}, "b": function(p){return "".join(p);}};'''
    interpreter = JSInterpreter(code)

# Generated at 2022-06-24 13:51:45.538326
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:51:54.574141
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
            var obj1 = {
                "one": function(a, b) {
                    return a + b;
                },
                "two": function(a, b) {
                    return a * b;
                }
            }
            obj2 = {
                "len": function(a) {
                    return a.length;
                }
            }
            '''

    obj1 = JSInterpreter(code).extract_object('obj1')
    obj2 = JSInterpreter(code).extract_object('obj2')

    assert obj1['one'](2, 3) == 5
    assert obj1['two'](2, 3) == 6
    assert obj2['len']('abc') == 3

# Generated at 2022-06-24 13:52:07.758143
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var aa = 123;
        var bb = {};
        aa.reverse = function(){};
        bb.aa = function(){};
        bb.reverse = function(){};
        var cc = {
            "aa": function(){},
            reverse: function(){}
        };
        var dd = {
            aa: function(){},
            reverse: function(){},
            length: function(){}
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('bb')
    assert len(obj) == 2
    assert obj['aa']() is None
    assert obj['reverse']() is None
    obj = interpreter.extract_object('dd')
    assert len(obj) == 3

# Generated at 2022-06-24 13:52:13.448373
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
    (function(a){
        if(a)
            return a
        return a+'='
    })
    '''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('anonymous')
    assert f(('abc',)) == 'abc'
    assert f(('',)) == '='
    

# Generated at 2022-06-24 13:52:20.604489
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    from .utils import js_to_json


# Generated at 2022-06-24 13:52:24.611208
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    assert JSInterpreter(r'''
(function (a) {
  return a;
})(y);
''').call_function('a', y='hello') == 'hello'


# Generated at 2022-06-24 13:52:35.151259
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter('').call_function('hello', 'world') == 'world'
    assert JSInterpreter('').call_function('hello2', 'world') == 'drow'
    assert JSInterpreter('').call_function('hello3', 'world', '!') == 'world!'
    assert JSInterpreter('').call_function('hello4', 'world') == 'dlrow'
    assert JSInterpreter('').call_function('hello5', 'world') == ['d', 'r', 'o', 'w']
    assert JSInterpreter('').call_function('hello6', 'world') == ['d', 'r', 'o', 'w']
    assert JSInterpreter('').call_function('hello7', 'A world') == ['world', 'A']
    assert JSInterpre

# Generated at 2022-06-24 13:52:42.543775
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = JSInterpreter("""
        var a = 'hi there';
        var b = {
            c: 'i am an object',
            d: function(n) {
                return 'number: ' + n;
            }
        };
        var f = function(m) {
            return 'hello ' + m;
        };
    """)
    assert js.extract_function('f')(('world',)) == 'hello world'
    assert js.extract_object('b')['c'] == 'i am an object'
    assert js.extract_object('b')['d']((42,)) == 'number: 42'


# Unit tests for the test_JSInterpreter method

# Generated at 2022-06-24 13:52:53.341088
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():

    code = """
var a = function(x, y) {
    return x === "0" ? 0 : y;
}
"""
    js_interpreter = JSInterpreter(code)
    expr = "var d=a('0',1)"
    local_vars = {}
    js_interpreter.interpret_statement(expr, local_vars)
    assert local_vars['d'] == 0
    expr = "var e=a('1',1)"
    local_vars = {}
    js_interpreter.interpret_statement(expr, local_vars)
    assert local_vars['e'] == 1


# Generated at 2022-06-24 13:53:05.621297
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # for method interpret_statement
    code = '''
    function ytplayer_0() {
        var ret = {"a": 1}
        ret.length = 1 << 0
        ret.reverse();
        return ret;
    }
    '''
    jsi = JSInterpreter(code)
    assert jsi.call_function('ytplayer_0') == {"a": 1, "length": 1}

    # for method interpret_expression
    code = '''
    function ytplayer_1() {
        var a = function(a) {
            return a * a
        }
        var b = function(a) {
            return a + a
        }
        return a(b(1))
    }
    '''
    jsi = JSInterpreter(code)

# Generated at 2022-06-24 13:53:15.447707
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = """
        var a = {}
        var b = 4
        var c = "example"
        var d = [1,2,3]
        d.length
        d.slice(0)
        d.splice(1,d.length-5)
        d.reverse()
        function e(f){ return f; };
        e(b)
        var g = 1
        var h = 2
        g + h
        var i = [1,2,3]
        i[1] + 1
        var j = 4
        j + 1
        var k = "a"
        var l = "b"
        var m = k + l
    """
    interpreter = JSInterpreter(code)
    m = interpreter.extract_function("e")

# Generated at 2022-06-24 13:53:25.127269
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = """
    var A = A || {};
    A.B = function(b, c) {
        this.v = b;
        this.w = c;
    };
    A.B.prototype.x = function(d, e) {};
    A.B.prototype.y = function(f) {};
    A.B.prototype.z = function(g) {};

    function x() {}
    function y() {}
    function z() {}

    var someOtherCode = "dummy";
    """

    obj = JSInterpreter(js_code).extract_object("A.B.prototype")

    assert obj["x"].__name__ == "resf"
    assert obj["y"].__name__ == "resf"

# Generated at 2022-06-24 13:53:29.281672
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = """
        var a = 10;
        var b = "20";
        var c = [1, 2, 3];
        var d = {a: "b", c: "d"};
        var e = function(x, y) { return x * y; };
        """
    interpreter = JSInterpreter(code)
    result = interpreter.interpret_statement("var a = (c[1] + b[0])", {})[0]
    assert result == 12
    result = interpreter.interpret_statement("var a = 20", {})[0]
    assert result == 20

# Generated at 2022-06-24 13:53:39.520835
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''var a = "";
              function b(c, d){
                  a = c + d;
              };
              b(1, 2);
    '''
    i = JSInterpreter(code)
    assert i.call_function('b', 1, 2)
    assert i.call_function('b', 3, 4) == None
    assert i._objects['a']['j']() == '34'

if __name__ == '__main__':
    test_JSInterpreter_call_function()
    print('Test finished')

# Generated at 2022-06-24 13:53:45.953977
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js = '''
    var a = {
        b: function(c, d) {
            return c + d
        },
        e: function(f) {
            return f * 2;
        }
    };
    '''
    obj = JSInterpreter(js).extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['e'](3) == 6

# Generated at 2022-06-24 13:53:55.303233
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
    var obj = {
        "a": function(x) {
            return x * 17;
        },

        "b": function(x, y) {
            return x * y;
        }
    };

    var fun = {};
    fun.c = function(x, y) {
        return obj["a"](x) + obj["b"](x, y);
    }
    '''
    js = JSInterpreter(code)
    f = js.build_function(('x', ), code)
    assert f((1)) == 17
    f = js.build_function(('x', 'y'), code)
    assert f((1, 2)) == 2

# Generated at 2022-06-24 13:54:07.658428
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def compare(funcname, code, args, result):
        jsi = JSInterpreter('')
        f = jsi.build_function(['a', 'b', 'c'], code)
        res = f(args)
        print(res)
        assert res == result
    compare('test', 'return a+b+c;', [1, 2, 3], 6)
    compare('test', 'return a*b+c;', [2, 5, 3], 13)
    compare('test', 'return (a+b)*c;', [2, 6, 3], 24)
    compare('test', 'return a+b*c;', [2, 6, 3], 20)
    compare('test', 'return a*b-c;', [2, 6, 3], 3)

# Generated at 2022-06-24 13:54:18.110788
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r'''
    var b;
    var e = {
        a: function() {
            a = 6
        },
        b: function(c) {
            c = a
        },
        c: function(c,b) {
            b.push(c)
        },
        d: function(a,b) {
            return a + b
        }
    }
    '''
    jsinterpreter = JSInterpreter(code)
    objects = jsinterpreter._objects

    assert 'b' not in objects
    assert 'e' in object

    assert len(objects['e']) == 4
    assert 'a' in objects['e']
    assert callable(objects['e']['a'])

# Generated at 2022-06-24 13:54:29.960617
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function func_add(arg1, arg2) {
            return arg1 + arg2;
        }
    '''
    jsinterpreter = JSInterpreter(code)
    res = jsinterpreter.call_function('func_add', 1, 2)
    assert res == 3, "test case 'func_add' failed. res=%r" % res

    code = '''
        function func_dec(arg1) {
            return --arg1;
        }
    '''
    jsinterpreter = JSInterpreter(code)
    res = jsinterpreter.call_function('func_dec', 1)
    assert res == 0, "test case 'func_dec' failed. res=%r" % res


# Generated at 2022-06-24 13:54:39.987955
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:54:43.941671
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        a = 1 + 3
        var b = a
        c = function(){return a+4}()
    '''
    assert JSInterpreter(code).interpret_expression('a', {'a': 5}) == 5
    assert JSInterpreter(code).interpret_expression('b', {'a': 5}) == 4
    assert JSInterpreter(code).interpret_expression('c', {'a': 5}) == 9

# Generated at 2022-06-24 13:54:54.215674
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():

    def equal(func_name, func_args_string, result):
        argnames = func_args_string.split(',')
        body = 'return ' + result
        js_interpreter = JSInterpreter('')
        f = js_interpreter.build_function(argnames, body)
        ans = js_interpreter.call_function(func_name, *args)
        assert ans == int(result)

    def unequal(func_name, func_args_string, result):
        argnames = func_args_string.split(',')
        body = 'return ' + result
        js_interpreter = JSInterpreter('')
        f = js_interpreter.build_function(argnames, body)

# Generated at 2022-06-24 13:54:59.060942
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''var a = {
        "b": function(arg1, arg2) {
            return 5;
        }
    };
    a["b"](1, 2);

    '''
    interpreter = JSInterpreter(code)
    print(interpreter.interpret_expression('(a["b"])(1, 2)', {}))

# Generated at 2022-06-24 13:55:07.127613
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:55:11.701256
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = '''
    function func(a, b) {
        return a + b;
    }
    '''
    inter = JSInterpreter(js)
    res = inter.call_function('func', 1, 2)
    assert res == 3


# Generated at 2022-06-24 13:55:17.138643
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        a = {
            "b": function(p) {
                return p;
            },
            "c": function(p) {
                return -p;
            }
        };
        """
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object("a")
    assert obj["b"]((1,)) == (1,)
    assert obj["c"]((1,)) == (-1,)


# Generated at 2022-06-24 13:55:23.742901
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objects = {
        'player_quality': {
            'medium': 1,
            'large': 2
        }
    }

# Generated at 2022-06-24 13:55:28.717153
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    def extract_result(js_code, funcname, args):
        print('js_code: ' + js_code)
        print('funcname: ' + funcname)
        print('args: ' + str(args))
        jsInt = JSInterpreter(js_code)
        t = jsInt.call_function(funcname, *args)
        print('result: ' + str(t))
        return t
    js_code = "function test(){return '123';}"
    funcname = 'test'
    args = []
    extract_result(js_code, funcname, args)
    js_code = "function test(a,b){return a+b;}"
    funcname = 'test'
    args = [2, 3]
    extract_result(js_code, funcname, args)
    js_

# Generated at 2022-06-24 13:55:33.087943
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    test_object = {
        'foo': {'bar': 'hello world'},
        'baz': [1, 2, 3],
        'qux': None,
    }
    jsi = JSInterpreter(code=None, objects=test_object)
    assert jsi._objects == test_object
    assert jsi.code is None


# Generated at 2022-06-24 13:55:44.685707
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # test1
    arg_list = ["a", "b", "c"]
    code = "var d = c+a; return b;";
    jsi = JSInterpreter("nothing", {})
    fun = jsi.build_function(arg_list, code)
    assert fun((1,2,3)) == 2

    # test2
    arg_list = ["a", "b"]
    code = "var c = b;"
    jsi = JSInterpreter("nothing", {})
    fun = jsi.build_function(arg_list, code)
    assert fun((1,2)) is None

    # test3
    arg_list = ["a", "b"]
    code = "var c = a+b; return c;"
    jsi = JSInterpreter("nothing", {})
    fun = j

# Generated at 2022-06-24 13:55:50.236536
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    objectname = "k"
    js = "var k={_0xf1c9:function(_0x779a,_0x7cee){return _0xf1c9(_0x779a);}};"
    interpreter = JSInterpreter(js)
    obj = interpreter.extract_object(objectname)
    assert '_0xf1c9' in obj


# Generated at 2022-06-24 13:55:52.582026
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter


# Generated at 2022-06-24 13:56:03.553190
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    import unittest
    import json

    class JSInterpreterTest(unittest.TestCase):
        def test_extract_function(self):
            js_interp = JSInterpreter(code=r"""
                function hello() {
                    return 'hello world';
                }
            """)
            assert js_interp.extract_function('hello')() == 'hello world'

            js_interp = JSInterpreter(code=r"""
                var hello2 = function () {
                    return 'hello world 2';
                }
            """)
            assert js_interp.extract_function('hello2')() == 'hello world 2'

            js_interp = JSInterpreter(code=r"""
                hello3 = function () {
                    return 'hello world 3';
                }
            """)

# Generated at 2022-06-24 13:56:12.018871
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('', {})
    f = js.build_function(['a', 'b'], 'a = a + b;')
    assert f((1, 2)) == 3
    assert f(('[', ']')) == '[]'
    f = js.build_function(['a'], 'a.split("")')
    assert f(('word',)) == ['w', 'o', 'r', 'd']
    f = js.build_function(['a', 'b'], 'a.join(b)')
    assert f(({'a': '1', 'b': '2'}, '|')) == '1|2'

    f = js.build_function([], 'return 1;')
    assert f(()) == 1
    f = js.build_function([], 'return;')


# Generated at 2022-06-24 13:56:15.951821
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    import sys
    local_vars = {}
    interpreter = JSInterpreter(sys.argv[1], local_vars)
    res = interpreter.interpret_expression(sys.argv[2], local_vars, int(sys.argv[3]))
    print(res)

if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-24 13:56:26.223594
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsinterpreter = JSInterpreter('var b;var a=b+c;return a;')
    result = jsinterpreter.interpret_statement('a=b+c', {'b': 3, 'c': 5})
    assert result[0] == 8

    jsinterpreter = JSInterpreter('var b;var a=b+c;return a;')
    result = jsinterpreter.interpret_statement('a=b+c', {'b': 3, 'c': 5}, allow_recursion=0)
    assert result[0] is None


# Generated at 2022-06-24 13:56:28.582872
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    interpreter = JSInterpreter('''
    function f(a, b) {
        return a * b;
    };
    ''')
    assert interpreter.call_function('f', 2, 3) == 6


# Generated at 2022-06-24 13:56:34.904868
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        function foo(a, b, c) {
            return a + b + c;
        }
    """
    expected = 6
    jsi = JSInterpreter(js_code)
    assert jsi.call_function("foo", 1, 2, 3) == expected
    # If a function does not exist, an exception is raised
    try:
        jsi.call_function("baz")
        assert False
    except ExtractionError:
        pass

# Generated at 2022-06-24 13:56:39.813119
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    obj = JSInterpreter("""
        function abc(a, b, c) {
            var d = a + b - c;
            return a * b * c + d;
        }
    """)
    assert obj.interpret_expression("abc(3,4,6)") == 3



# Generated at 2022-06-24 13:56:45.018634
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter(
        r"""
        var foo = {
            'a': 'z',
            'b': function (p) {
                return p.a + p.b;
            },
            'c': function (p) {
                return p.a + p.b;
            }
        };"""
    )
    assert 'ab' == js_interpreter.call_function(
        'foo.b', {'a': 'a', 'b': 'b'})
    assert 'abc' == js_interpreter.call_function(
        'foo.c', {'a': 'a', 'b': 'bc'})

# Generated at 2022-06-24 13:56:55.752209
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r'''
    (function(g, b) {
        var a = {
            f: function(c) {
                return c.split('').reverse().join('')
            },
            g: function(c, d) {
                c = a.f(c);
                return c.substr(c.length - d, d)
            }
        };
        return a
    })(window, document);
    '''

    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['f']('123456') == '654321'
    assert obj['g']('123456', 3) == '456'


# Generated at 2022-06-24 13:57:08.368116
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:57:17.561423
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    import pytest
    # Test Example 1.
    assert JSInterpreter('function a(b, c){b.bb = bb; c.cc = cc}').call_function('a', {'bb': 'x', 'cc': 'y'}, {'bb': 'x', 'cc': 'y'}) == None
    # Test Example 2.
    assert JSInterpreter('function a(b, c){a.bb = bb; c.cc = cc}').call_function('a', {'bb': 'x', 'cc': 'y'}, {'bb': 'x', 'cc': 'y'}) == None
    # Test Example 3.

# Generated at 2022-06-24 13:57:26.914611
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
    var abc = {
        f1: function() {},
        f2: function(a,b,c) {},
        f3: function() {},
        d1: {},
        d2: {}
    }"""

# Generated at 2022-06-24 13:57:31.839778
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsinterpreter = JSInterpreter('a = 3; return a + 5;')
    assert jsinterpreter.interpret_statement('a = 3;',{}) == (3, False)
    assert jsinterpreter.interpret_statement('return a + 5;',{}) == (8, True)
# test_JSInterpreter_interpret_statement()


# Generated at 2022-06-24 13:57:43.414507
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert (JSInterpreter('', {'a': [1, 2, 3]}).interpret_expression('a[1]', {}, 1)
            == 2)
    assert (JSInterpreter('', {'str': 'test'}).interpret_expression('str.length', {}, 1)
            == 4)
    assert (JSInterpreter('', {'str': ['t', 'e', 's', 't']}).interpret_expression('str.join()', {}, 1)
            == 'test')
    assert (JSInterpreter('', {'a': [1, 2, 3]}).interpret_expression('a.splice(1,2)', {}, 1)
            == [2, 3])

# Generated at 2022-06-24 13:57:52.213873
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''var foo = function(a){var b=0; return a;};
           function bar(c){var a=c,b=[1,2,3];return function(j){return a;};};
           function qux(a,b){return function(c){return a;};};'''

    res = JSInterpreter(code).call_function('foo', 10)
    assert res == 10
    res = JSInterpreter(code).call_function('bar', 20)
    assert res == 20
    res = JSInterpreter(code).call_function('qux', 20, 30)
    assert res == 20



# Generated at 2022-06-24 13:57:56.590494
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    class Dummy:
        def f(self, x):
            return x*x

    js = JSInterpreter(code='''
        function g(x) {
            return f(x);
        }
    ''', objects={'f': Dummy().f})
    print(js)
    print(js.call_function('g', 2)) # should be 4


# Generated at 2022-06-24 13:58:03.916581
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = r"""
    var c = function(){};
    c.sig = function(pt){};
    c.sig.signature="l0oHiozjh1/B0CqhdOME1jVuYMk=";
    """
    js = JSInterpreter(code)
    assert js.extract_object('c')['sig']['signature'] == 'l0oHiozjh1/B0CqhdOME1jVuYMk='


# Generated at 2022-06-24 13:58:12.191920
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Test case 1
    js_code = '''a={c:function(){alert(1);},d:function(){window.open();}}'''
    js_objects = JSInterpreter(js_code)
    result = js_objects.extract_object('a')

# Generated at 2022-06-24 13:58:17.887816
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:58:28.561451
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    data = {'s': 'z4PhNX7vuL3xVChQ1m2AB9Yg5AULVxXcg/SpIdNs6c5H0NE8XYXysP+DGNKHfuwvY7kxvUdBeoGlODJ6+SfaPg==',
            'in_order': '',
            'out_order': 'dmi_all_vendor',
    }


# Generated at 2022-06-24 13:58:40.363919
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:58:44.449226
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = JSInterpreter("""
        function eval_test(args) {
            return substr(args, 0, 2);
        }
        
        function substr(args, start, end) {
            return args[0] + args[1] + args[2] + start + end;
        }
    """)
    assert js.call_function("eval_test", 1, 2, 3) == "123021"


# Generated at 2022-06-24 13:58:56.301768
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:59:07.939715
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:59:19.675421
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-24 13:59:28.550122
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Test 1
    # Example code:
    # function foo(a,b) { a=a^b+(a|b); b=a^b+(a&b); return a|b; }
    code = r'''function foo(a,b) { a=a^b+(a|b); b=a^b+(a&b); return a|b; }'''
    jsInterpreter = JSInterpreter(code)
    foo_function = jsInterpreter.extract_function('foo')
    result = foo_function((1,2))
    assert result == 5

    # Test 2
    # Example code:
    # function bar(a,b) { a=a+b; b=a-b; return a-b+1; }

# Generated at 2022-06-24 13:59:39.877346
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test functions of "JSInterpreter.interpret_expression"
    jsi = JSInterpreter('')
    local_vars = {}
    # 1. test expr is number
    expr = '123'
    v = jsi.interpret_expression(expr, local_vars, 100)
    assert v == 123
    # 2. test expr is boolean
    expr = 'true'
    v = jsi.interpret_expression(expr, local_vars, 100)
    assert v == True
    # 3. test expr is an assignment operation
    expr = 'a=1'
    v = jsi.interpret_expression(expr, local_vars, 100)
    assert v == 1
    # 4. test expr is an array element
    expr = 'a[1]'
    a = [0, 1, 2]
    local

# Generated at 2022-06-24 13:59:51.403812
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Getter of signature

    # Initial
    signature_js = '''var  signature=function(a){a=a.split("");sig.sig.reverse();a=a.slice(32);a=a.slice(2);sig.sig=a.slice(3);return a.join("")};'''
    js_interpreter = JSInterpreter(signature_js)
    signature = js_interpreter.call_function('signature', '2411A1C01BEF0655FDFCB7F02E23F9EA9B25F6A4.6FE2B6FC02B6E1844CEC1A48A93AA79E9BC929BA')

    # Print the result
    print("signature=%s" % signature)

    # If the result is correct,

# Generated at 2022-06-24 14:00:00.599783
# Unit test for method extract_function of class JSInterpreter