

# Generated at 2022-06-24 13:50:05.488952
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    expected_result_of_function_decrypt_signature_function_with_args_signature_and_decrypt_function_name = 'afdgghjkljhgfdafghjklloiuytrewq'

    code = '''
        function decryptSignature(signature){
            return signature;
        }
    '''
    interpreter = JSInterpreter(code)
    signature = 'afdgghjkljhgfdafghjklloiuytrewq'
    result = interpreter.call_function('decryptSignature', signature)

    assert result == expected_result_of_function_decrypt_signature_function_with_args_signature_and_decrypt_function_name


# Generated at 2022-06-24 13:50:16.328733
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:50:25.822882
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('', {})

# Generated at 2022-06-24 13:50:32.468632
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    interpreter = JSInterpreter("foo = {bar: function(a) {return a+1;}, baz: function(b,c) {return b*c;}};", {'foo': {'toString': lambda args: 'bar'}})
    assert interpreter.extract_object('foo') == {'bar': lambda args: args[0] + 1, 'baz': lambda args: args[0] * args[1]}


# Generated at 2022-06-24 13:50:38.480192
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
        function test_add(a, b) {
            var c = a + b;
            return c;
        }
    '''
    assert JSInterpreter(js_code).build_function(['a', 'b'], 'var c = a + b; return c;')([1, 2]) == 3

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-24 13:50:49.057123
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    a = [1, 2, 3]
    f = {'join': lambda args: ''.join(a)}

    expr = 'join("")'
    expr2 = 'join(",")'

    # Test 1
    obj = JSInterpreter("", {'a': a, 'f': f})
    assert obj.interpret_expression(expr, {'a': a, 'f': f}) == '123'
    assert obj.interpret_expression(expr2, {'a': a, 'f': f}) == '1,2,3'
    # Test 2
    obj = JSInterpreter("", {'a': a, 'f': f})
    assert obj.interpret_expression('f.join("")', {'a': a, 'f': f}) == '123'

# Generated at 2022-06-24 13:50:57.495661
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsinterpreter = JSInterpreter("""
                                var a1 = {
                                    "a2": {
                                        "a3": {
                                            "a4": "a5"
                                        }
                                    }
                                };
                                function b1(a,b){
                                    return ""+a+b;
                                }
                                function c1(){
                                    return "c2";
                                }
                            """)
    assert jsinterpreter.call_function("b1", "1","2") == "12"
    assert jsinterpreter.call_function("c1") == "c2"
    assert jsinterpreter.interpret_expression("a1.a2.a3.a4",dict()) == "a5"

if __name__ == '__main__':
    test

# Generated at 2022-06-24 13:51:02.373777
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # 1. Test on result of an empty expression
    obj = JSInterpreter('var abcd;')
    args, abort = obj.interpret_statement('', {'abcd': ''})
    assert args is None
    assert not abort

    # 2. Test on result of a non-empty expression
    obj = JSInterpreter('var abcd;')
    args, abort = obj.interpret_statement('1', {'abcd': ''})
    assert args == 1
    assert not abort

    # 3. Test on result of a return expression
    obj = JSInterpreter('var abcd;')
    args, abort = obj.interpret_statement('return 1', {'abcd': ''})
    assert args == 1
    assert abort

    # 4. Test on result of a basic expression with operators

# Generated at 2022-06-24 13:51:13.034179
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = """
        var a = {
            x: function(arg1, arg2) { 
                var output = arg1 + arg2; 
                return output;
            },
            y: function(arg1, arg2) {
                var output = arg1 * arg2;
                return output;
            }
        };
        var b = 5;
        var c = 7;
    """
    jsi = JSInterpreter(js)
    assert(jsi.interpret_expression('a.x(b, c)',{}) == 12)
    assert(jsi.interpret_expression('a.y(b, c)',{}) == 35)

# Generated at 2022-06-24 13:51:20.174999
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_interp = JSInterpreter('''function foo(a, b) {return a + b}''')
    assert js_interp.extract_function('foo')((1, 2)) == 3
    try:
        js_interp.extract_function('bar')
        assert False
    except ExtractorError:
        assert True


# Generated at 2022-06-24 13:51:29.953312
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Case 1: simple string
    stmt1 = "var a='hello'"
    jsInterpreter = JSInterpreter(stmt1)
    assert jsInterpreter.interpret_expression('a', {})=="hello"
    # Case 2: function call
    stmt2 = "function a(x){return x+1}"
    jsInterpreter = JSInterpreter(stmt2)
    assert jsInterpreter.interpret_expression('a(12)', {})==13
    # Case 3: multi-level object access
    stmt3 = "var a = {'b': {'c': 'd'}};"
    jsInterpreter = JSInterpreter(stmt3)
    assert jsInterpreter.interpret_expression('a["b"]["c"]', {})=="d"
    # Case 4

# Generated at 2022-06-24 13:51:44.160685
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    stmt = '''
        var a, c, d;
        var e = 0;
        var b = function() {
            a = '"' + "%3B" + '"';
            c = '"' + ";" + '"';
            d = '"' + "%3b" + '"';
            e = "\\x3b" ? 1 : 0;
        }
    '''
    vars = {}
    JSInterpreter(stmt).interpret_statement(stmt + '; b();', vars)
    assert vars['a'] == '"%3B"'
    assert vars['c'] == '";"'
    assert vars['d'] == '"%3b"'
    assert vars['e'] == 0


if __name__ == '__main__':
    test_JSInterpreter_

# Generated at 2022-06-24 13:51:50.795310
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        function test_func (args) {
            var result = [];
            for (var i = 0; i < args.length; i++) {
                result.push(i);
            }
            return result;
        }
    ''')
    print(js_interpreter.call_function('test_func', [1, 2, 3]))

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-24 13:51:57.393232
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Test data
    # JavaScript code that contains the function to be tested
    js_code = '''
        function hexToR(h) {
            return parseInt(cutHex(h).substring(0, 2), 16)
        }
        function hexToG(h) {
            return parseInt(cutHex(h).substring(2, 4), 16)
        }
        function hexToB(h) {
            return parseInt(cutHex(h).substring(4, 6), 16)
        }
        function cutHex(h) {
            return (h.charAt(0) === "#") ? h.substring(1, 7) : h
        }
    '''
    func_name = 'hexToR'
    func_parameter = '#0000FF'
    expected_return_value

# Generated at 2022-06-24 13:52:10.438989
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:52:18.923492
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = JSInterpreter(code='''
        function some_function(a, b) {
            return a + b;
        }
    ''')
    assert js.call_function('some_function', 10, 20) == 30
    js = JSInterpreter(code='''
        function concat(a, b) {
            return a.concat(b);
        }
    ''')
    assert js.call_function('concat', [10, 20], [30, 40]) == [10, 20, 30, 40]
    js = JSInterpreter(code='''
        function concat(a, b) {
            return a.splice(0, 0, b);
        }
    ''')

# Generated at 2022-06-24 13:52:23.412674
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = '''
        var a=1;
        var b=2;
        var c=a+b;
    '''
    inp = JSInterpreter(js_code)
    assert(inp is not None)

    return


# Generated at 2022-06-24 13:52:32.183041
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    var a = [1,2,3];
    var c = a.length;
    var f1 = function() {
        var d = a.length;
        return d;
    }
    '''
    interpreter = JSInterpreter(code)
    assert 'a' in interpreter._objects
    assert 'c' in interpreter.call_function(
        'f1', interpreter._objects['a']).__closure__[0].cell_contents
    assert 'd' not in interpreter._objects

if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-24 13:52:37.461083
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = JSInterpreter('''
        var a = {b: 'hello'};
        var c = function() {
            return 'test';
        };
        var d = {
            e:function(x) {
                return a.b + c() + x;
            }
        };
    ''')
    assert js.call_function('d.e', '!') == 'hello!test!'

# Generated at 2022-06-24 13:52:38.709658
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    assert JSInterpreter("").interpret_expression('1 + 1', {}, 100) == 2


# Generated at 2022-06-24 13:52:46.808804
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = r'''
        var A = 5;
        var B = 6;
        var C = 7;
        var f = function(a) {
            return a * A * B * C;
        };
    '''
    interp = JSInterpreter(code)
    res1 = interp.call_function('f', 2)
    assert res1 == 2*5*6*7
    res2 = interp.call_function('f', 3)
    assert res2 == 3*5*6*7



# Generated at 2022-06-24 13:52:51.391453
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = """
        var c = {
            "b": function(p) {
                p.a(0, 4);
            },
            "a": function(b, e) {
            }
        }
    """
    interpreter = JSInterpreter(js_code)
    interpreter.extract_object('c')


# Generated at 2022-06-24 13:52:57.910110
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    obj_code = '''
    {
        foo: function(x) { return x * x - 4; },
        bar: function(x, y) { return x + y + this.foo(y); }
    }
    '''

    func_code = '''
    function func(a, b, c) {
        return a + b + c + this.foo(b);
    }
    '''
    code = obj_code + func_code
    interpreter = JSInterpreter(code)
    args = (1, 2, 3)
    func = interpreter.extract_function('func')
    assert func(args) == 11

# Generated at 2022-06-24 13:53:06.690555
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('''
        function x(a, b) {
            if (!a) {
                return false;
            }
            var c = a.y + a.z;
            var d = -1;
            do {
                var e = c;
                var f = '' + b.length;
                var g = b[f];
                var h = g.v;
                var i = h.join('');
                var j = i.split(' ');
                if (j.length > 6) {
                    d = j.length;
                } else {
                    d = -1;
                }
            } while (e != d);
            return d;
        }
    ''')
    a = {'y': 1, 'z': 2}

# Generated at 2022-06-24 13:53:16.119447
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterpreter = JSInterpreter("", {})
    assert jsinterpreter.interpret_expression("1", {}) == 1
    assert jsinterpreter.interpret_expression("1 + 1", {}) == 2
    assert jsinterpreter.interpret_expression("1 - 1", {}) == 0
    assert jsinterpreter.interpret_expression("2 * 3", {}) == 6
    assert jsinterpreter.interpret_expression("2 / 3", {}) == 2/3
    assert jsinterpreter.interpret_expression("2 ** 3", {}) == 8
    assert jsinterpreter.interpret_expression("8 % 3", {}) == 2
    assert jsinterpreter.interpret_expression("8 << 3", {}) == 64
    assert jsinterpreter.interpret_expression("8 >> 3", {}) == 1
    assert jsinter

# Generated at 2022-06-24 13:53:20.620868
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsinterpreter = JSInterpreter('var vars_1 = {a: 1, b: 2}', {'a': 1, 'b': 2})
    print(jsinterpreter.extract_object('vars_1')['a'])
    assert jsinterpreter.extract_object('vars_1')['a'] == 1
    assert jsinterpreter.extract_object('vars_1')['b'] == 2


# Generated at 2022-06-24 13:53:28.594263
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
  test_obj = JSInterpreter('var a = {}; a.b = function() {}, a.c = function(d,e) {}, a.f = function(g) {};')
  extracted_obj = test_obj.extract_object('a')
  assert callable(extracted_obj['b'])
  assert callable(extracted_obj['c'])
  assert callable(extracted_obj['f'])
  assert extracted_obj['b']() == None
  assert extracted_obj['c'](1, 2) == None
  assert extracted_obj['f'](1) == None

## Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:53:31.338284
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a + b')
    assert func([1, 2]) == 3

# Generated at 2022-06-24 13:53:38.515582
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter(None)
    assert js_interpreter.build_function(['x', 'y'], 'var z; z = x + y;')([1, 2]) == 3
    assert js_interpreter.build_function(['x', 'y'], 'var z; z = x - y;')([1, 2]) == -1



# Generated at 2022-06-24 13:53:45.270778
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # build a JSInterpreter
    code = """var f = function(arg1, arg2) {
            return arg1 * arg2;
        }
    """

    interpreter = JSInterpreter(code)

    # call the function f with arg1 = 5 and arg2 = 3
    res = interpreter.call_function('f', 5, 3)

    # test the result
    assert(res == 15)


# Generated at 2022-06-24 13:53:54.269542
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = """
      var a = function(){
        var b = 10;
        return function(arg1){
          var c = arg1;
          return c;
        }
      }
      var d = a();
      var e = d(20);
    """
    js_func_name = "a"
    js_arg = "20"

    interpreter = JSInterpreter(js_code)
    res = interpreter.call_function(js_func_name, js_arg)
    print ("The result is: %s" % res)

if __name__ == "__main__":
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-24 13:54:02.555826
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    obj = JSInterpreter('')
    expr = 'function(a){a=a.split("");a=a.reverse();a=a.join("");return a}'
    code = expr[8: -1]

    argnames = expr[8: expr.find(')')].split(',')
    f = obj.build_function(argnames, code)
    assert f(['abc']) == 'cba'



# Generated at 2022-06-24 13:54:08.542911
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('''
        function foo(a) {
            return a;
        }
    ''')
    print(js_interpreter.build_function(['a'], 'return a')(['b']))



# Generated at 2022-06-24 13:54:13.225696
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsinterp = JSInterpreter(
        r'''function f(a, b) {
                 return a - b;
               }
               function g(a, b) {
                 return a + f(a, b);
               }''')
    assert jsinterp.call_function('f', 4, 2) == 2
    assert jsinterp.call_function('g', 4, 2) == 6


# Generated at 2022-06-24 13:54:16.081336
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    jsinterpreter = JSInterpreter("""
        var obj = {
            a : function() {},
            b : function() {},
            c : function() {},
            d : function() {},
            e : function() {}
        }
        ;
    """)
    obj = jsinterpreter.extract_object("obj")
    assert len(obj) == 5


# Generated at 2022-06-24 13:54:28.114323
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:54:35.115168
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test(code):
        def f(args):
            return args
        def test_args(args):
            js_interpreter = JSInterpreter('', {})
            js_interpreter_f = js_interpreter.build_function([], code)
            f_res = f(args)
            js_interpreter_f_res = js_interpreter_f(args)
            assert f_res == js_interpreter_f_res
        yield test_args
    test_args = test("1 + 1")
    test_args(1)


# Generated at 2022-06-24 13:54:41.069710
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = (
        'function f() {var x;x=1;x+1;x=x+1;return(x);};'
        'function g() {var x,y;x=1,y=2;return(x>y);};'
        'var h=function(){return(1);}'
    )
    parser = JSInterpreter(code)
    assert parser.interpret_expression('1', {}) == 1
    assert parser.interpret_expression('1+1', {}) == 2
    assert parser.interpret_expression('(1)', {}) == 1
    assert parser.interpret_expression('(1)+(1)', {}) == 2
    assert parser.interpret_expression('1+(1)', {}) == 2
    assert parser.interpret_expression('(1+1)', {}) == 2

# Generated at 2022-06-24 13:54:47.567692
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var $ = {}
        $.x = {
            a: function() {
                return 1;
            },
            b: function() {
                return 2;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('$.x')

    for method in ['a', 'b']:
        assert obj[method]() == globals()['test_' + method]()


# Generated at 2022-06-24 13:54:57.353625
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Set up test case
    code = """
        var noop = function(a, b){
        };

        var f1 = function(a, b){
            return a + b;
        }

        var f2 = function(a, b){
            var c = a + b;
            return function(d){
                return c + d;
            }
        }
    """
    js = JSInterpreter(code)

    # Run tests
    assert js.extract_function('noop')([1, 2]) is None
    assert js.extract_function('f1')([3, 5]) == 8
    assert js.extract_function('f1')([-1, -2]) == -3
    assert js.extract_function('f2')([1, 2]) == 3
    assert js

# Generated at 2022-06-24 13:55:03.097466
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = JSInterpreter('''
        var a = 10;
        var b = 20;
        var c = 30;
        function test_func(x, y) {
            return ((x + y) * b + c) / a;
        }
    ''')
    # Test case 1, call_function should return 8
    assert js.call_function('test_func', 1, 2) == 8
    # Test case 2, call_function should return 31
    assert js.call_function('test_func', 10, 20) == 31


# Generated at 2022-06-24 13:55:09.376629
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    JSI = JSInterpreter('function abc(x,y,z){ return x+y*z; }')

# Generated at 2022-06-24 13:55:19.653106
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter('var a = 1;')
    stmt = 'a=3'
    local_vars = {'a':2}
    v, should_abort = js.interpret_statement(stmt, local_vars)
    assert v == 3 and should_abort == False and local_vars == {'a':3}
    stmt = 'a=a+1'
    local_vars = {'a':2}
    v, should_abort = js.interpret_statement(stmt, local_vars)
    assert v == 3 and should_abort == False and local_vars == {'a':3}
    stmt = 'return a+1'
    local_vars = {'a':2}

# Generated at 2022-06-24 13:55:31.750403
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    JSInterpreter_instance = JSInterpreter('a = b - 1', {'b': 1})
    assert JSInterpreter_instance.interpret_expression('a', {'b': 1}) == 0
    assert JSInterpreter_instance.interpret_expression('a + 1', {'b': 10}) == 9
    JSInterpreter_instance = JSInterpreter('a = b + 1', {'b': 1})
    assert JSInterpreter_instance.interpret_expression('a', {'b': 1}) == 2
    assert JSInterpreter_instance.interpret_expression('a + 1', {'b': 1}) == 3
    JSInterpreter_instance = JSInterpreter('a = b / 1', {'b': 1})
    assert JSInterpreter_instance.interpret_expression('a', {'b': 1})

# Generated at 2022-06-24 13:55:43.422091
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = JSInterpreter('''
        function f(arg1, arg2) {
            return arg1 * arg2;
        }''')
    assert js.extract_function('f')((3, 2)) == 6

    js = JSInterpreter('''
        a = {
            f: function() {
                return 3;
            }
        };''')
    assert js.extract_function('a.f')() == 3

    js = JSInterpreter('''
        a = {
            f: function(arg1, arg2) {
                return arg1 * arg2;
            }
        };''')
    assert js.extract_function('a.f')((3, 2)) == 6


# Generated at 2022-06-24 13:55:53.288574
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():

    code = '''
        var v1 = 1;
        var v2 = 2;
        var v3 = 3;
        var v4 = 4;

        var f1 = function (v1) { return v1 + 1; }
        function f2(v1, v2) { return v1 + v2; }
        var f3 = function (v1, v2, v3, v4) { return v1 + v2 + v3 + v4; };
    '''

    interpreter = JSInterpreter(code)

    assert interpreter.call_function('f1', 1) == 2
    assert interpreter.call_function('f2', 1, 2) == 3
    assert interpreter.call_function('f3', 1, 2, 3, 4) == 10


# Generated at 2022-06-24 13:55:59.210903
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    CODE = r'''
        var a = {
            "b": function(c){return c;}
        };
    '''
    interpreter = JSInterpreter(CODE)
    obj = interpreter.extract_object('a')
    assert obj['b']('foo') == 'foo'
    try:
        obj['c']
        assert False
    except KeyError:
        pass


# Generated at 2022-06-24 13:56:08.696933
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:56:16.310239
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = """
    var e = function (a) {
        return a.reverse()
    };
    var f = function (a, b) {
        b = e(b);
        var c = b[a];
        var d = 0;
        while (d < c) {
            c -= a.charCodeAt(d % a.length);
            c = c < 0 ? c + 26 : c;
            d++
        }
        return c
    }
    """
    interpreter = JSInterpreter(code)
    stmt = "var c = b[a];"
    local_vars = {'b': 'abc', 'a': 2}
    print(interpreter.interpret_statement(stmt, local_vars))

    stmt = "var d = 0;"

# Generated at 2022-06-24 13:56:22.214122
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = r'''window.ytplayer = {
        "args": function(a) {return a;},
        "videoData": function(a) {return a;}
    }'''
    parser = JSInterpreter(code)
    assert parser.extract_object("window.ytplayer") == {
        "args": lambda a: a,
        "videoData": lambda a: a
    }


# Generated at 2022-06-24 13:56:33.080054
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    """
    src/downloader/external.py:JSInterpreter.extract_function
    """

    code = """
        function func1(a1, b) {
            return a1 + b;
        }

        var a = {
            func2: function(a2, b2) {
                return a2 + b2;
            }
        };
    """

    interpreter = JSInterpreter(code)
    func1 = interpreter.extract_function('func1')
    func2 = interpreter.extract_function('a.func2')

    assert func1((1, 2)) == 3
    assert func2((1, 2)) == 3


# Generated at 2022-06-24 13:56:38.244103
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    var e=function(a){
        var b;
        b=function(){
            return a
        };
        a+=1;
        return b
    };
    var f=function(a){
        return function(){
            return a
        }
    };
    function g(a){
        return function(){
            return a
        }
    }
    var h=e(3);
    var i=f(4);
    var j=g(5);

    var a={
        foo:function(x){return x+1},
        bar:function(x){return x*2},
        baz:function(x){return x*x}
    }
    '''
    js = JSInterpreter(code)
    assert js.call_function('e', 3) == 4

# Generated at 2022-06-24 13:56:50.201432
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter(code = "")
    js_interpreter.build_function(argnames = ["a", "b", "c"], code = "return d;")
    js_interpreter.build_function(argnames = [], code = "return f({a:b,c:d});")
    js_interpreter.build_function(argnames = ["a"], code = "return a.f({b:c,d:e});")
    js_interpreter.build_function(argnames = ["a", "b"], code = "return a.f(b);")
    js_interpreter.build_function(argnames = ["a", "b"], code = "return a[b];")

# Generated at 2022-06-24 13:56:56.413480
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter('')

    # empty statement
    assert interpreter.interpret_statement('', {}) == (None, False)

    # global statement
    assert interpreter.interpret_statement('var a', {}) == (None, False)
    assert interpreter.interpret_statement('var a=1+5^5%5', {}) == (1, False)

    # global statement
    assert interpreter.interpret_statement('return a', {}) == (None, True)
    assert interpreter.interpret_statement('return a=1+5^5%5', {}) == (1, True)

    # local statement
    assert interpreter.interpret_statement('a', {}) == (1, False)
    assert interpreter.interpret_statement('a=1+5^5%5', {'a': 10}) == (16, False)

# Unit test

# Generated at 2022-06-24 13:57:01.271962
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsinterpreter = JSInterpreter('''function f(arg1,arg2) { return arg1 + arg2; }''')
    assert jsinterpreter.call_function('f', 'a', 5) == 'a5'

# Generated at 2022-06-24 13:57:07.730927
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code1 = '''
    function a(a){
        return a;
    }
    '''

    assert JSInterpreter(js_code1).extract_object('a').__name__ == "a"
    assert JSInterpreter(js_code1, {'a': 'b'}).extract_object('a').__name__ == "b"


# Generated at 2022-06-24 13:57:17.181860
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    print('Testing JSInterpreter.interpret_statement:')
    print('test_JSInterpreter_interpret_statement')

# Generated at 2022-06-24 13:57:24.260929
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        a = {
            foo : function(a,b){
                var a;
                return a;
            },

            bar : function(c,d){
                return c+d;
            },
            baz : {
                a:1,
                b:2
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert isinstance(obj, dict)
    assert obj.keys() == ['foo','bar','baz']
    assert isinstance(obj['baz'], dict) and obj['baz'].keys() == ['a','b'] and obj['baz']['a']==1 and obj['baz']['b']==2

# Generated at 2022-06-24 13:57:34.274774
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        function test1(arg1, arg2) {
            var op = "";
            if (arg1 > arg2) {
                op = ">";
            } else if (arg1 == arg2) {
                op = "==";
            } else {
                op = "<";
            }
            return arg1 + op + arg2;
        }

        function test2(arg1, arg2) {
            return arg1 + arg2;
        }
    """

    js_interpreter = JSInterpreter(code, {})
    assert js_interpreter.extract_function("test1")("2", "3") == "2<3"
    assert js_interpreter.extract_function("test1")("3", "3") == "3==3"
    assert js_inter

# Generated at 2022-06-24 13:57:45.182890
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:57:51.916515
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter(
        code='''var f = function(a,b,c){a=b+1;b=a+2;c=b+3;return c}''')
    f = js_interpreter.build_function(
        argnames=['a', 'b', 'c'], code='''a=b+1;b=a+2;c=b+3;return c''')
    assert f((0, 1, 2)) == 5



# Generated at 2022-06-24 13:57:55.754632
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter("""
        function abc(a, b) {
            return a * b;
        }""")
    assert jsi.call_function("abc", 3, 4) == 12

if __name__ == "__main__":
    test_JSInterpreter_build_function()

# Generated at 2022-06-24 13:58:03.643488
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsinterpreter = JSInterpreter('')

    assert jsinterpreter.interpret_statement('undefined') == (None, False)
    assert jsinterpreter.interpret_statement('var a = 3') == (3, False)
    assert jsinterpreter.interpret_statement('var a = 3 + 3') == (6, False)
    assert jsinterpreter.interpret_statement('var s = "test"') == ('test', False)
    assert jsinterpreter.interpret_statement('var a = 3 + 3;') == (6, False)
    assert jsinterpreter.interpret_statement('var a = 3 + 3; return a') == (6, True)
    assert jsinterpreter.interpret_statement('var a = 3, b = 3 + a; return b') == (6, True)
    assert jsinterpre

# Generated at 2022-06-24 13:58:15.700981
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    local_interpreter = JSInterpreter('''
    function test(a, b, c, d){
        a = b + c - d;
        return a;
    }
    ''')
    assert local_interpreter.call_function('test', 1, 2, 3, 4) == 1
    assert local_interpreter.call_function('test', 1, 2, 3, -4) == 5
    assert local_interpreter.call_function('test', 'a', 'b', 'c', 'd') == 'bc'
    assert local_interpreter.call_function('test', 'a', 'b', 'cd', 'd') == 'bcd'
    assert local_interpreter.call_function('test', 'a', 'b', '', 'd') == 'bd'
    assert local_

# Generated at 2022-06-24 13:58:22.028074
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    local_vars = {}
    code = """
        function test() {
            var a = []
            a[0] = 1
            a[1] = 2
            a[2] = a[0] + a[1]
            return a[2]
        }
        test();
    """
    interpreter = JSInterpreter(code)
    assert interpreter.interpret_statement(code, local_vars)[0] == 3
    return 0

# Unit test of member methods of class JSInterpreter

# Generated at 2022-06-24 13:58:30.810477
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:58:39.664448
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_interpreter = JSInterpreter('')
    fun = js_interpreter.extract_function('fromCharCode')
    assert fun(list(range(65, 75))) == 'ABCDEFGHIJ'
    fun = js_interpreter.extract_function('fromCharCode')
    assert fun(list(range(0x30,0x3A))) == '0123456789'
    fun = js_interpreter.extract_function('RegExp')
    assert fun(('[b]', 'g')) == 'b'


# Generated at 2022-06-24 13:58:51.119630
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def f(var1=None, var2 = None):
        '''
        var v = new Array(var1, var2);
        v.reverse();
        return v
        '''

    from inspect import getsource
    code = getsource(f)
    argnames = ['var1', 'var2']
    JS = JSInterpreter(code)
    func = JS.build_function(argnames, code)
    assert func([1, 2]) == [2, 1]

    f1 = JS.extract_function('f')
    assert f1([1, 2]) == [2, 1]
    assert f1([3, 4]) == [4, 3]


# Generated at 2022-06-24 13:59:02.533899
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter(None)
    # test simple assignment
    local_vars = {'a':None}
    res, abort = interpreter.interpret_statement(" a = 1", local_vars)
    assert local_vars['a'] == 1
    assert res == 1
    # test simple assignment with var
    res, abort = interpreter.interpret_statement("    var b = 1", local_vars)
    assert local_vars['b'] == 1
    assert res == 1
    # test simple statement
    local_vars = {'a':None}
    res, abort = interpreter.interpret_statement(" a + 1", local_vars)
    assert abort == False
    # test return
    local_vars = {'a':1}

# Generated at 2022-06-24 13:59:10.210090
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code1 = """
    var a = "string";
    var b = a.split("");
    function hello(word) {
        if (word == "") {
            return "";
        } else {
            return "Hello " + word + "!";
        }
    }
    var x = hello("world");
    """
    test_inst = JSInterpreter(code1)
    assert test_inst._functions == {}
    assert test_inst._objects == {}

# Unit test of JSInterpreter().interpret_expression(expr, local_vars, allow_recursion)

# Generated at 2022-06-24 13:59:16.418910
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:59:25.491859
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    a = {}
    a['test2'] = "function(a,b){return a+b;}"
    a['test3'] = "function(a,b){return a-b;}"
    a['test4'] = "function(a){return a*a;}"
    a['test5'] = "function(a){return a/2;}"
    a['test6'] = "function(a,b){return a**b;}"
    a['test7'] = "function(a,b){return a%b;}"
    a['test8'] = "function(a,b){return a%b*a/b+a;}"

# Generated at 2022-06-24 13:59:36.141739
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:59:46.363375
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var object = {
            "a": "b",
            "c": function(arg1, arg2) {
                return [arg1, arg2];
            }
        };
    '''
    
    # Test the constructor
    interp = JSInterpreter(code)
    assert interp.code == code
    assert interp._functions == {}
    assert interp._objects == {}

    # Test extract_object
    obj = interp.extract_object('object')
    assert obj['a'] == 'b'
    assert obj['c']('d', 'e') == ['d', 'e']


# Generated at 2022-06-24 13:59:56.530452
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    cases = (
        ('"a"', 'a'),
        ('a', 'a'),
        ('2 + b', 2 + 'b'),
        ('function(){return a}()', 'a'),
        ('function(b){return a}("b")', 'a'),
        ('function(a){return b}("a")', 'b'),
        ("""var c="abc";function(b){return a+b+c}("b")""", 'abcbabc'),
        ("""var c="abc";function(b){return a+b+c}("b") + 3""", 'abcbabc3'),
    )
    for expr, expected in cases:
        assert JSInterpreter(expr).interpret_expression({'a':'a', 'b':'b'}) == expected


# Generated at 2022-06-24 14:00:00.138861
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    function a(b, c){
        return b + c;
    }
    function d(e){
        return e;
    }
    var f = function(g){
        return g;
    }
    var h = {
        i: function(j, k){
            return j + k;
        }
    };
    '''
    jsinterpreter = JSInterpreter(code)

