

# Generated at 2022-06-24 13:50:08.469945
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})
    # Test function
    f = js_interpreter.build_function([], "var b = 'a'; return b;")
    assert f(()) == 'a'
    # Test another function
    f = js_interpreter.build_function(["a"], "return a;")
    assert f(("b",)) == "b"
    # Test another function
    f = js_interpreter.build_function(["a"], "var b = 'c'; return a+b;")
    assert f(("b",)) == "bc"


# Generated at 2022-06-24 13:50:19.333250
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def assertion(args, expected_value):
        jsi = JSInterpreter(code)
        assert jsi.build_function(argnames, code)(args) == expected_value


    code = '''
    function func1(arg1, arg2){
        if(arg1 == 5){
            return arg2;
        }
        return 0;
    }
    '''
    argnames = ['arg1', 'arg2']

    assertion((1, 'a'), 0)
    assertion((5, 'a'), 'a')
    assertion((5, None), None)

    code = '''
    function func1(arg1, arg2){
        var a = arg1, b = arg2;
        return a;
    }
    '''
    argnames = ['arg1', 'arg2']


# Generated at 2022-06-24 13:50:30.024575
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    global _OPERATORS
    import unittest
    import random

    class JSTest(unittest.TestCase):
        def test_basic(self):
            interpreter = JSInterpreter('''
                s = {sign: function(n) {
                    if (n == 0) {
                        return 0;
                    } else if (n > 0) {
                        return 1;
                    } else {
                        return -1;
                    }
                }};
            ''')
            self.assertEqual(interpreter.interpret_expression('1 + 2', {}), 3)
            self.assertEqual(interpreter.interpret_expression('1 - 2', {}), -1)
            self.assertEqual(interpreter.interpret_expression('1 * 2', {}), 2)

# Generated at 2022-06-24 13:50:39.380317
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:50:50.105728
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterpreter = JSInterpreter('', {'swfArgs': {'url_encoded_fmt_stream_map': 'url=test&bad'}})
    assert jsinterpreter.interpret_expression(
        'url_encoded_fmt_stream_map.split(",")', {}, 1000) == ['url=test&bad']

    jsinterpreter = JSInterpreter('', {'swfArgs': {'url_encoded_fmt_stream_map': 'url=test'}})
    assert jsinterpreter.interpret_expression(
        'url_encoded_fmt_stream_map.split(",").length', {}, 1000) == 1


# Generated at 2022-06-24 13:50:54.228108
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    interpreter = JSInterpreter('function abc(a, b) {a + b;}')
    assert interpreter.call_function('abc', 1, 2) == 3
    func = interpreter.build_function(['a', 'b'], 'a + b')
    assert func((1, 2)) == 3

# Generated at 2022-06-24 13:51:03.270474
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var A = a + 1;
        var B = b
        function aaa(c, d, e) {
            var D = a + b + c
            var E = 5
            var F = g
            if (true) {
                var G = 12
            }
            var H = I
            var I = 13
        }
        var J = {
            bbb: function(c, d) {
                var E = a + b + c + d
                var F = g
                return [E, F, arg]
            },
            ccc: function(d) {
                var E = a + b + d
                return E
            }
        }
        var eee = function(e) {
            var E = a + b + e
            return E
        }
    '''
   

# Generated at 2022-06-24 13:51:13.742065
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    strTestCode = """function d(a) {
            a.reverse()
        }
        var e = {
            f: function (a) {
                return a.join('')
            },
            g: function (a, b) {
                return a + b
            }
        }"""
    print("code is: ", strTestCode)
    js = JSInterpreter(strTestCode)
    d = js.extract_function('d')
    print(d)
    assert d is not None
    e = js.extract_object('e')
    print(e)
    assert e is not None
    assert e['f'](['1', '2', '3']) == '123'
    assert e['g']('1', '2') == '12'



# Generated at 2022-06-24 13:51:26.056787
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('var b = a + 1;')
    assert js.interpret_expression('b', {'a': 1}) == 2
    assert js.interpret_expression('b += 2', {'a': 1}) == 3

    js = JSInterpreter('function swap(x){var a = x[0];x[0] = x[1];x[1] = a;}')
    x = [1, 2]
    js.interpret_expression('swap(x)', {'x': x})
    assert x[0] == 2

    js = JSInterpreter('var c = b;')
    assert js.interpret_expression('c', {'b': 2}) == 2
    assert js.interpret_expression('b', {'b': 2}) == 2


# Generated at 2022-06-24 13:51:32.968802
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        var a = "abcdef";
        var b = 3;
        var c = [1, 2, 3];
        var d = {
            "one": 1,
            "two": 2,
            "three": 3,
            "get": function(idx) {return this[idx]},
            "set": function(idx, val) {this[idx] = val; return val;},
            "split": function(s) {return s.split("")},
            "join": function(s) {return s.join("")},
            "reverse": function() {return this.reverse()}
        };
        var e = d;
    '''
    jsi = JSInterpreter(code)
    # Tests for built-in object

# Generated at 2022-06-24 13:51:39.181836
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = '''var name = {}; var name2 = {}; name.foo = function(a1, a2){}; name2.foo = function(a1, a2){var name3 = {}; var name4 = {}; name3.foo = function(a1, a2){}; name4.foo = function(a1, a2){}};'''
    jsInt = JSInterpreter(js)
    assert jsInt.extract_object('name2') is not None
    assert jsInt.extract_object('name2').get('foo') is not None
    assert jsInt.extract_object('name2')['foo'] is not None
    assert jsInt.extract_function('name.foo') is not None
    assert jsInt.extract_function('name.foo')(4, 5) is None



# Generated at 2022-06-24 13:51:50.458915
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter("""
    var a = "ok";
    var ab = "ok";
    var bbo = {};
    bbo.split = function(a,b) {return [a,b];}
    bbo.join = function(a) {return a;}
    bbo.c = function() {return "c";}
    """)
    #print('test', js.interpret_statement("var a = 'ok'", {}))
    assert js.interpret_statement("var a = 'ok'", {}) == ("ok", False)
    assert js.interpret_statement("ab = 'ok'", {'ab': 'not ok'}) == ('ok', False)
    assert js.interpret_statement("(function(){return 'ok';})()", {}) == ('ok', True)
    assert js.interpret_statement

# Generated at 2022-06-24 13:51:57.938119
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:52:04.218123
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter('var a = 1;')
    assert JSInterpreter('var a = 1;', {'a': 2})
    assert JSInterpreter('var a = 1;', objects={'a': 2})
    assert JSInterpreter('var a = 1;', objects={'a': 2})



# Generated at 2022-06-24 13:52:14.786240
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = u'''
        var a = b[c];
        var a,b=1;
        var c = "abc", d = { "abc": 
    var a,
        b;
    for (c in d) {
        e(c);
    }
    function e() {}
    function f() {}
    f();
    '''

# Generated at 2022-06-24 13:52:27.420609
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:52:37.251638
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:52:44.413456
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        someFunc = function(arg1, arg2) {
            if (arg1 != "test") {
                return func2(arg1, arg2);
            }
            return arg1;
        }
        """
    js_interpreter = JSInterpreter(code)
    expected_result = "test"
    assert js_interpreter.call_function("someFunc", "test", "arg2") == expected_result

code = """
var a = function() {};
a.b = function() {};
a.b.c = function(d,e) {};
a.b.prototype.d = function() {};
var f = function(g) {};
f.prototype.h = function(i) {};
"""

# Generated at 2022-06-24 13:52:48.352062
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = 'function a(a, b){return a + b}'
    interpreted_code = JSInterpreter(js_code).extract_function('a')
    assert interpreted_code([1, 1]) == 2


# Generated at 2022-06-24 13:52:56.791639
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = """{
        var a = "2";
        var b = function(c, d) {
            var e = 0;
            var f = 1;
            return f;
        };
        var g = [ [1, 2], [3, 4], [5, 6] ];
        var h = "";
        var i = function(c, d) {
            var e = 0;
            var f = 1;
        };
        var j = function(c, d) {
            var e = 0;
            var f = 1;
        };
        var k = function(c, d) {
            var e = 0;
            var f = 1;
        };
        var l = function(c, d) {
            var e = 0;
            var f = 1;
        };
    }"""
    j

# Generated at 2022-06-24 13:53:09.523466
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        var test123 = function() {};
        var test456 = function(arg1, arg2) { var x = arg1; var y = arg2; };
        var g = function() {}

        test = function(arg1, arg2) { var x = arg1; var y = arg2; var z = arg1 + y; return z; };
        f = function() { test(g, g); };
    '''

    # Test function test
    extracted_function_test = JSInterpreter(code).extract_function('test')
    assert extracted_function_test(('arg1', 'arg2')) == 'arg1arg2'

    # Test function f
    extracted_function_f = JSInterpreter(code).extract_function('f')
    assert extracted_function_f([]) == None

# Generated at 2022-06-24 13:53:21.480795
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:53:30.723080
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = """
        function test_function(){
        }
    """
    f = JSInterpreter(js_code).extract_function("test_function")
    assert f() is None

    js_code = """
        test_function = function () {
        }
    """
    f = JSInterpreter(js_code).extract_function("test_function")
    assert f() is None

    js_code = """
        var test_function = function () {
        }
    """
    f = JSInterpreter(js_code).extract_function("test_function")
    assert f() is None

    js_code = """
        var test_function = function (a) {
            return a;
        }
    """

# Generated at 2022-06-24 13:53:38.035067
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js = '''
    ;; Hey I'm a comment
    function tok(a) {
        var b = a;
        var c = b + 3;
        return c;
    }
    '''
    jsi = JSInterpreter(js)
    f = jsi.extract_function('tok')
    assert f((1,)) == 4

# Generated at 2022-06-24 13:53:40.982905
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = JSInterpreter('var foo = { bar: function(a) { return 1; } };', {})
    assert js.call_function('foo.bar') == 1



# Generated at 2022-06-24 13:53:53.283378
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
    qq = {
        f1: function(a,b) { return a + b;},
        f2: function(a,b) { return a - b;},
        subf: {
            f3: function(a,b) { return a * b;},
            f4: function(a,b) { return a / b;}
        }
    }
    '''
    obj = JSInterpreter(js_code).extract_object('qq')

    assert(len(obj) is 4)
    assert(obj['f1'](3, 4) is 7)
    assert(obj['f2'](3, 4) is -1)
    assert(obj['subf']['f3'](3, 4) is 12)

# Generated at 2022-06-24 13:54:05.897992
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():

    def test_case(code, argnames, args, expected_res):
        res_f = JSInterpreter(code).build_function(argnames, code)
        res = res_f(args)
        if res != expected_res:
            raise AssertionError('%r != %r (Expected: %r)' % (res, res_f, expected_res))

    # Function definition
    test_case('function test_f(a,b){return a-b;}', ['a','b'], [4,2], 2)

    # Function definition with inner variable
    test_case('function test_f(a,b){var z = a+b; return z;}', ['a','b'], [4,2], 6)

    # Function definition with inner function

# Generated at 2022-06-24 13:54:10.025018
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    interp = JSInterpreter('''
        var obj = {
            a: function(b){
                return c;
            },
            d: function(a){
                return a;
            },
            e: function(a){
                return a;
            }
        };
    ''')
    assert interp.extract_object('obj') == {
        'a': lambda b: 'c',
        'd': lambda a: a,
        'e': lambda a: a,
    }


# Generated at 2022-06-24 13:54:18.425246
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsinterp = JSInterpreter('')
    assert jsinterp.interpret_expression('"a"', {}) == 'a'
    assert jsinterp.interpret_expression('{"a":"b"}', {}) == {'a': 'b'}
    assert jsinterp.interpret_expression('''["a", "b"]''', {}) == ['a', 'b']
    assert jsinterp.interpret_expression('''["a", "b"][0]''', {}) == 'a'
    assert jsinterp.interpret_expression('''["a", "b"][1]''', {}) == 'b'
    assert jsinterp.interpret_expression('''["a", "b"].join''', {}) == ''.join
    local_vars = {'a': ['a', 'b']}


# Generated at 2022-06-24 13:54:27.707875
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    print('------- Unit test for method build_function of class JSInterpreter ---------')

    s = """
    function test(a, b) {
        var c = a + b;
        var d = a * b;
        return c - d;
    }
    """

    js_interpreter = JSInterpreter(s)
    f = js_interpreter.build_function(['a', 'b'], s[s.find('{') + 1:s.rfind('}')])
    print(f(['a', 'b']))


# Generated at 2022-06-24 13:54:36.647278
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj1 = {
            method1: function(a, b) { return a + b; },
            method2: function(a) { return a + 'str'; },
            method3: function(a, b) { return a[b]; },
            method4: function(a, b) { return a.b; }
        };
    '''
    obj = JSInterpreter(code).extract_object('obj1')
    assert obj['method1'](1, 2) == 3
    assert obj['method2'](1) == '1str'
    assert obj['method3']([1, 2], 1) == 2
    assert obj['method4']({'b': 'c'}, '') == 'c'


# Generated at 2022-06-24 13:54:47.801144
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test_case(function_name,expected_result,*args):
        jsinterpreter = JSInterpreter('''function %s(){return %s;}''' % (function_name, expected_result))
        assert jsinterpreter.call_function(function_name,*args) == expected_result
        pass

    # Test case with number
    test_case('fun','1',1,2)
    test_case('fun','11',1,2)
    test_case('fun','1+2',1,2)
    test_case('fun','11+22',11,22)
    test_case('fun','1+2+3',1,2,3)
    test_case('fun','1+2+3+4',1,2,3,4)

# Generated at 2022-06-24 13:54:51.391981
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
    function func1(a, b, c) {
        return a + b + c;
    }
    """
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('func1', 1, 2, 3) == 6


# Generated at 2022-06-24 13:55:01.254279
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:55:13.335314
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsi = JSInterpreter('var p = 1;')
    assert jsi.interpret_statement('var p = 1;', {})[0] == 1
    assert jsi.interpret_statement('p = 2;', {})[0] == 2
    assert jsi.interpret_statement('p', {})[0] == 2
    assert jsi.interpret_statement('2', {})[0] == 2

    assert jsi.interpret_statement('(p)', {})[0] == 2
    assert jsi.interpret_statement('(p+1)', {})[0] == 3

    assert jsi.interpret_statement('p==2', {})[0] == True
    assert jsi.interpret_statement('p!=2', {})[0] == False
    assert jsi.interpret_statement('p>2', {})[0] == False
   

# Generated at 2022-06-24 13:55:18.092065
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = """
var test1 = {
    "a": 2,
    "b": function(x) {
        return x + 1;
    }
}
var test2 = {
    "c": function(x, y) {
        return x + y;
    }
}
function test3(x, y) {
    return x + y;
}
function test4() {
    var abc = 1;
    return abc;
}
"""
    interpreter = JSInterpreter(code)
    func = interpreter.extract_function("test3")
    assert func([1, 2]) == 3
    func = interpreter.extract_function("test4")
    assert func([]) == 1
    obj = interpreter.extract_object("test1")
    assert obj["a"] == 2

# Generated at 2022-06-24 13:55:30.245850
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:55:38.853544
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''
    a = 1 + 2
    b = a * 3
    return b
    '''
    for local_vars, should_abort, res in [
        ({'a': 1, 'b': 2}, False, 7),
    ]:
        assert JSInterpreter(code).interpret_statement(
            code, local_vars)[1] == should_abort
        assert JSInterpreter(code).interpret_statement(
            code, local_vars)[0] == res

# Generated at 2022-06-24 13:55:50.371851
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test case 1
    interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    v, abort = interpreter.interpret_statement('var c=a+b;', local_vars)
    assert (not abort) and v == 3
    v, abort = interpreter.interpret_statement('var d=a*b;', local_vars)
    assert (not abort) and v == 2
    v, abort = interpreter.interpret_statement('var e=c*d;', local_vars)
    assert (not abort) and v == 6
    v, abort = interpreter.interpret_statement('return e;', local_vars)
    asse

# Generated at 2022-06-24 13:55:59.631318
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    print('JSInterpreter_interpret_expression')
    js_code ='''
        z = '+';
        zz = z.split('+').join(z);
        zzz = zz.split(z);
        zz23 = z.split('+234235').join(z);
        zzz234 = zz23.split(z);
        d = (1,2,3);
        d[0] = 4;
        d;
        c;
        c = 10;
        a = 10;
        b = 10;
        b = a + b;
        b + c;
    '''
    i = JSInterpreter(js_code)
    res = i.interpret_expression('zzz.length', {})
    assert res == 2

# Generated at 2022-06-24 13:56:02.606550
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = r'''
    a = function(x){
        return x * x
    }
    '''
    assert JSInterpreter(code).call_function('a', 2) == 4


# Generated at 2022-06-24 13:56:09.087845
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Construct a new JSInterpreter
    code_snippet = '''
        x = 10;
        function get_x(){
            return x;
        }
    '''
    js_interpreter = JSInterpreter(code_snippet)
    # Call method interpret_statement on object js_interpreter
    local_vars = {'x': 5, 'y': 7}
    result = js_interpreter.interpret_statement('return x', local_vars)
    assert result[0] == 5
    assert result[1] == True


# Generated at 2022-06-24 13:56:14.387345
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = open("js_codes/function_code.js").read()
    interp = JSInterpreter(code)
    res = interp.extract_function('number_to_letter')
    assert res((1,)) == 'a'
    assert res((2,)) == 'b'
    assert res((0,)) == 'm'



# Generated at 2022-06-24 13:56:24.805513
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:56:26.481989
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert(1 == 1)
    # assert(1 == 2)
    # assert(2 == 1)


# Generated at 2022-06-24 13:56:33.278218
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    """
    Test case for method interpret_statement of class JSInterpreter

    """
    # initialize the class object with dummy code
    js_intrpreter = JSInterpreter(code='example code')
    # test with an empty string
    assert js_intrpreter.interpret_statement(stmt='',local_vars=dict()) == (None, False)
    # test with an empty string that starts with a space
    assert js_intrpreter.interpret_statement(stmt=' ',local_vars=dict()) == (None, False)
    # test with an assignment expression
    assert js_intrpreter.interpret_statement(stmt='var x=1',local_vars=dict()) == (1, False)
    # test with a return statement

# Generated at 2022-06-24 13:56:39.693545
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:56:50.145528
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    function myfunc(a,b,c) {
        return a + b + c;
    }
    function myfunc2(d,e) {
        return d * e;
    }
    function myfunc3(f) {
        return f;
    }
    '''
    jsinterpreter = JSInterpreter(code)
    assert jsinterpreter.call_function('myfunc', 1, 2, 3) == 6
    assert jsinterpreter.call_function('myfunc2', 2, 3) == 6
    assert jsinterpreter.call_function('myfunc3', 5) == 5


if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-24 13:56:59.033974
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    jsi = JSInterpreter('var a = 10;')
    assert jsi.interpret_expression('a', dict(a='1')) == '1'

    jsi = JSInterpreter('var a; a = 1;')
    assert jsi.interpret_expression('a = a + 1', dict(a=1)) == 2

    jsi = JSInterpreter('var b; b = {"a": 10};')
    assert jsi.interpret_expression('b.a', dict(b=dict(a=10))) == 10

    jsi = JSInterpreter('var c; c = [10, 20, 30];')
    assert jsi.interpret_expression('c[0]', dict(c=[10, 20, 30])) == 10

# Generated at 2022-06-24 13:57:05.931091
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = """
    function test(){
        function obj(a, b, c){
            return a*b+c;
        }
        return obj;
    }
    """
    interpreter = JSInterpreter(js)
    # Specify the function name you want to run and the parameters
    # return the value of calling the function
    assert interpreter.call_function('test', 2, 3, 9) == 15


# Generated at 2022-06-24 13:57:11.591718
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        var a = {
            b: function() {
                return 1;
            }
        }

        var t = function(v) {
            return a.b() + v;
        }
        """
    jsi = JSInterpreter(js_code)
    assert jsi.call_function('t', 1) == 2


# Generated at 2022-06-24 13:57:20.258239
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter('')
    f = jsi.build_function((), '')
    assert f(()) is None
    f = jsi.build_function(('a'), 'a=0;')
    assert f((1,)) is None
    assert f((0,)) == 0
    f = jsi.build_function(('a', 'b'), 'a=a-b;')
    assert f((1, 1)) == 0
    assert f((1, 2)) == -1
    f = jsi.build_function(('a', 'b'), 'a=a>>b; return a;')
    assert f((1, 1)) == 0
    assert f((8, 1)) == 4



# Generated at 2022-06-24 13:57:31.375069
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:57:43.164128
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        var swf = function(arg1, arg2) {
            WfU5D6X = arg1;
            YNpH6iC = arg2;
        };
    """)
    func = js_interpreter.build_function(['arg1', 'arg2'], """
        WfU5D6X = arg1;
        YNpH6iC = arg2;
    """)

    # Python doesn't allow reassignment to arguments, so we use a global variable to simulate
    global WfU5D6X
    global YNpH6iC
    WfU5D6X = 0
    YNpH6iC = 0

    func([1, 2])
    assert WfU5D6X == 1
   

# Generated at 2022-06-24 13:57:50.156497
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test(func_code, argnames, args, expected):
        resf = JSInterpreter('var test = function(%s) { %s } ' % (','.join(argnames), func_code)).build_function(argnames, func_code)
        res = resf(args)
        assert res == expected, '%r != %r' % (res, expected)

    # test(func_code, argnames, args, expected)
    test('return 1;', ['a', 'b'], (1, 2), 1)
    test('return 1; var x = 2;', ['a', 'b'], (1, 2), 1)
    test('return a;', ['a', 'b'], (1, 2), 1)

# Generated at 2022-06-24 13:58:00.589335
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code =(
        '''\
        var ytplayer = {
            "args":{
                "t": "oXb_9jKdJCM"
            },
            "media": {
                "ftoken": "asd"
            },
            "html5": true,
            "thumbnailUrl":"asd",
            "id": "test"
        };'''
    )
    interp = JSInterpreter(code)
    obj = interp.extract_object('ytplayer')
    assert obj['args']['t'] == 'oXb_9jKdJCM'
    assert obj['media']['ftoken'] == 'asd'
    assert obj['html5'] == True
    assert obj['thumbnailUrl'] == 'asd'
    assert obj['id'] == 'test'

# Generated at 2022-06-24 13:58:08.478060
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    # nop
    assert js_interpreter.build_function([], "")(args=[]) is None
    # identity
    assert js_interpreter.build_function(["a"], "a")(args=[1]) == 1
    # addition
    assert js_interpreter.build_function(["a"], "a + a")(args=[1]) == 2
    # function call
    assert js_interpreter.build_function(["a"], "a(1)")(args=[lambda a: a + 1]) == 2

# Generated at 2022-06-24 13:58:20.481483
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter('')
    assert interpreter.interpret_expression('this.length', {'this': 'foobar'}) == 6
    assert interpreter.interpret_statement('return 3', {})[0] == 3
    assert interpreter.interpret_statement('var a', {})[0] == None
    assert interpreter.interpret_statement('var a = 3 + 4', {})[0] == 7
    assert interpreter.interpret_statement('var a = this.length', {'this': 'foobar'})[0] == 6
    assert interpreter.interpret_statement('var a = (3 + 4)', {})[0] == 7
    assert interpreter.interpret_statement('var a = 3 + (4)', {})[0] == 7

# Generated at 2022-06-24 13:58:26.449840
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsi = JSInterpreter('''\
var a = 5;
var b = {
    "c": function(arg) {
        return arg + 2;
    },
    "d": function() {
        return 3;
    }
};
var e = b.c(a) + b.d();''')
    assert jsi.interpret_statement('e', {}, allow_recursion=100) == (10, True)


# Generated at 2022-06-24 13:58:38.605282
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_interpreter = JSInterpreter("""
        JW = {
            "decrypt": function(t, e) {
                for (var r = new Uint8Array(t.length), n = 0; n < t.length; n++) r[n] = t.charCodeAt(n) - e;
                return function(t) {
                    for (var e = t.length - 1; e > 0; e--) {
                        var r, n = t[e],
                            o = n >> 4,
                            i = 15 & n;
                        r = o + (15 & t[e - 1]) << 4, t[e] = r ^ i
                    }
                    return t
                }(r).buffer
            }
        }""")

# Generated at 2022-06-24 13:58:45.691614
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:58:57.967687
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:59:03.105672
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    jsint = JSInterpreter('')
    assert jsint.interpret_statement('var xyz = 1', {})[0] == 1
    assert jsint.interpret_statement('var xyz = 10+2', {})[0] == 12
    assert jsint.interpret_statement(
        'var xy9 = 20 + a + 2', {'a': 1})[0] == 23
    assert jsint.interpret_statement(
        'xy9 += 10 + a', {'a': 1, 'xy9': 20})[0] == 32
    assert jsint.interpret_statement(
        'xy9 -= 5', {'xy9': 20})[0] == 15
    assert jsint.interpret_statement(
        'xy9 *= 5', {'xy9': 15})[0] == 75
    assert jsint.interpret_statement

# Generated at 2022-06-24 13:59:09.429626
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''
        function func(arg1, arg2) {
            return arg1.member1.member2(arg2);
        }
        '''
    objects = {
        'arg1': {
            'member1': {
                'member2': lambda arg2: arg2
            }
        }
    }
    assert JSInterpreter(code, objects=objects).call_function('func', 'arg1', 'arg2') == 'arg2'


# Generated at 2022-06-24 13:59:17.861219
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    extractor = {
        'extract_object': JSInterpreter.extract_object.__func__
    }
    code = """
            yt.playerConfig = {
              "args": {
                "id": "video-id"
              }
            };
            """
    expected = {
        "args": {
            "id": "video-id"
        }
    }
    actual = JSInterpreter.extract_object(extractor, code, "yt.playerConfig")
    assert actual == expected


# Generated at 2022-06-24 13:59:26.284139
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:59:36.667342
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-24 13:59:47.412872
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    text = '''var a=10,b=20,c=30,d=40;
        function add(x,y) {
                return x+y;
        }
        function sub(x,y) {
                return x-y;
        }
        function mul(x,y) {
                return x*y;
        }'''

    jsinterp = JSInterpreter(text)
    assert(jsinterp.call_function('add',10,20) == 30)
    assert(jsinterp.call_function('sub',20,10) == 10)
    assert(jsinterp.call_function('mul',10,20) == 200)


# Generated at 2022-06-24 13:59:53.091749
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:59:58.840333
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    test_js_code = """
    foo = {
        bar1: function(baz) {
            return 'aaa' + baz;
        },
        bar2: function(baz) {
            return 'bbb' + baz;
        }
    }
    """
    interpreter = JSInterpreter(test_js_code)
    assert interpreter._objects['foo']['bar1']('qqq') == 'aaaqqq'
    assert interpreter._objects['foo']['bar2']('qqq') == 'bbbqqq'

if __name__ == '__main__':
    test_JSInterpreter()