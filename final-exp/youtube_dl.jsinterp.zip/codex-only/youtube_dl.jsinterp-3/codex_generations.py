

# Generated at 2022-06-24 13:50:04.825583
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-24 13:50:11.021958
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test = '''
    var a = {
        b: function(c, d) {
            return c + d;
        },
        e: function(f) {
            return f * f;
        }
    };
    '''
    jsi = JSInterpreter(test)
    b = jsi.extract_object('a')
    assert b['b'](5, 6) == 11
    assert b['e'](5) == 25


# Generated at 2022-06-24 13:50:17.509121
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = '''
        function foo(a, b){
            c = b;
            return a + c;
        }
    '''
    interpreter = JSInterpreter(js)
    foo = interpreter.build_function(['a', 'b'], 'c = b; return a + c')
    assert foo([2, 3]) == 5

if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-24 13:50:27.411746
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''var a, b, c;
    function b(x) {
        return x * x;
    }
    function d(x, y) {
        return x * y;
    }
    d(b(3), c = 4 + 5);
    '''
    interpreter = JSInterpreter(js_code)
    r = interpreter.call_function('b', (3,))
    assert r == 9

    r = interpreter.call_function('d', (9,))
    assert r == 9 * 9

    r = interpreter.call_function('d', (9, 9))
    assert r == 9 * 9

    interpreter.interpret_statement('c = 10', {})
    r = interpreter.call_function('d', (9,))
    assert r == 9 * 10

    r = interpreter.call

# Generated at 2022-06-24 13:50:37.302622
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    var_x = (1, False)
    var_y = ('y', True)
    var_z = ('z', True)
    var_a = ('a', False)
    var_b = ('b', False)

    local_vars = {
        'x': var_x[0],
        'y': var_y[0],
        'z': var_z[0],
        'a': var_a[0],
        'b': var_b[0]
    }

    interpreter = JSInterpreter("")

# Generated at 2022-06-24 13:50:47.681598
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_in_str = '''
        var a = {b: "hello"}
        var c = {d: "hello"}
        d.e = f.g
        c.e = f.h
        i.e = f.g
        a.e = j.g
        function k(l, m, n){
            o[l.b] = 1;
            o[m.b] = 2;
            o[n.b] = 3;
        }
    '''
    js_in_str2 = '''
        var p = {q: "world"}
    '''
    js_in_itr = JSInterpreter(js_in_str)

# Generated at 2022-06-24 13:50:56.790324
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:51:02.604029
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var m = {
            "a": function(p) { return p; },
            "b": function(p) { return p * 2; }
        };
    '''
    js = JSInterpreter(code)
    m = js.extract_object('m')
    assert m['a']('hello') == 'hello'
    assert m['a'](123) == 123
    assert m['b']('hello') == 'hellohello'
    assert m['b'](123) == 246


# Generated at 2022-06-24 13:51:10.152040
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # test case 1
    js_interpreter = JSInterpreter(' {;}')
    args = ('a','b','c')
    code = '{}'
    def f(args):
        local_vars = dict(zip(argnames, args))
        return local_vars
    res_f = js_interpreter.build_function(args, code)
    assert res_f(('1', '2', '3')) == f(('1', '2', '3'))

# Generated at 2022-06-24 13:51:17.654091
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:51:25.648608
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function obj_func(name){
            if(name == null){
                name = "Unknown";
            }
            return name;
        }
    '''
    funcname = 'obj_func'
    args = ['name']
    code = 'if(name == null){ name = "Unknown"; } return name;'

    j = JSInterpreter(code)
    f = j.build_function(args, code)
    assert f(['Peter']) == 'Peter'
    assert f([None]) == 'Unknown'

# Generated at 2022-06-24 13:51:31.972026
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    obj = {'a': 'abcdef'}
    jsi = JSInterpreter(None, objects=obj)
    obj['reverse'] = jsi.build_function([], 'a.split("").reverse();')

    assert jsi.interpret_statement("""
        var b = a.reverse();
        b[0] + b[2];
        """, {}) == ('bca', False)


if __name__ == '__main__':
    import sys
    test_JSInterpreter_interpret_statement()

# Generated at 2022-06-24 13:51:43.066046
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    test_jsi = JSInterpreter(None)
    assert test_jsi.interpret_expression('30', {}, 0)  == 30
    assert test_jsi.interpret_expression('a + b', {'a': 11, 'b': 24}, 0)  == 35
    assert test_jsi.interpret_expression('{1:2}', {}, 0)  == {1:2}
    assert test_jsi.interpret_expression('[1, 2, 3]', {}, 0)  == [1, 2, 3]

if __name__ == '__main__':
    test_JSInterpreter_interpret_expression()

# Generated at 2022-06-24 13:51:50.689877
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = JSInterpreter('''
    "use strict";
    var a = {
        "b": 123,
        "c": 456
    };
    var $ = function(ctx, func, args) {
        return func.apply(ctx, args);
    };
    function initializeEmbed(o) {
        var b = {
            "d": a.b,
            "f": function() {
                return a.c;
            },
            "g": function() {
                return o.h;
            }
        };
        o.i = $.bind(b, b.g);
    };
    ''')
    res = js.call_function('initializeEmbed', {'h': 789})
    assert res is None

# Generated at 2022-06-24 13:51:58.042039
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():

    code_android = """
        var a = {
            "a" : function(p) {
                return p;
            },
            "b" : function(a, b) {
                return a + b;
            }
        };
    """

    code_ios = """
        a = {
            "a" : function(p) {
                return p;
            },
            "b" : function(a, b) {
                return a + b;
            }
        }
    """

    js = JSInterpreter(code_android)
    js_obj = js.extract_object("a")
    assert js_obj["a"]("c") == "c"
    assert js_obj["b"]("c", "d") == "cd"

    js = JSInterpreter(code_ios)
    js

# Generated at 2022-06-24 13:52:07.858424
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_interpreter = JSInterpreter("""
            var b = function (c) {
                return function (d) {
                    return d
                }
            };
            var e = function (f) {
                return f + 1;
            };
            var g = 3, h = b(4), i = function (j) {
                return h(j + g);
            };
            """)
    assert (js_interpreter.interpret_expression('i(e(5))', {}, 100)) == 6

if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-24 13:52:13.849270
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
    function function1() {
        var v = 1
        t1 = {
            funcA: function(arg) {
                var t = arg + v;
                return t;
            },
            funcB: function(arg) {
                var t = arg + v;
                return t;
            }
        }
        return t1;
    }
    """

    js = JSInterpreter(code)
    obj = js.extract_object('t1')
    assert 2 == obj['funcA'](1)
    assert 2 == obj['funcB'](1)

# Generated at 2022-06-24 13:52:20.276511
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_interpreter = JSInterpreter("var obj1 = {}; obj1.a = 1; obj1.b = [1, 2, 3]; obj1.c = {'d': 'd'}")
    assert js_interpreter._objects['obj1'] == {'a': 1, 'b': [1, 2, 3], 'c': {'d': 'd'}}, 'Cannot build js object as expected'


# Generated at 2022-06-24 13:52:23.129335
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = """function x(a){return a;}"""
    assert JSInterpreter(js).call_function('x', 123) == 123


# Generated at 2022-06-24 13:52:34.163628
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def assert_js_interpreter(js, funcname, argnames, code, expected_result):
        js_interpreter = JSInterpreter(js)
        actual_f = js_interpreter.build_function(argnames, code)
        actual_result = actual_f(expected_result)
        assert actual_result == expected_result,'failure on js=%r, funcname=%r, argnames=%r, code=%r, expected_result=%r, actual_result=%r' % (js, funcname, argnames, code, expected_result, actual_result)


# Generated at 2022-06-24 13:52:38.264119
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
    function abc(v) {
        return v + 5;
    }
    function def(v) {
        return v + 6;
    }
    function xyz(a, b) {
        return abc(a) + def(b);
    }
    """
    interp = JSInterpreter(code)

    assert interp.call_function('abc', 10) == 15
    assert interp.call_function('def', 10) == 16
    assert interp.call_function('xyz', 1, 2) == 15

# Generated at 2022-06-24 13:52:49.445990
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = """
    var a = function(b,c) {this.b = b; this.c = c};
    var x = function(a,b) {return a+b;};
    var y = function(a,b) {return a-b;};
    var z = function(a,b,c) {return a+b+c;};
    var k = function(a,b,c,d) {return a+b+c+d;};
    """
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('x',1,2) == 3
    assert interpreter.call_function('y',3,2) == 1
    assert interpreter.call_function('z',3,2,4) == 9

# Generated at 2022-06-24 13:52:58.641157
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Test case 1
    code = """
function test1(x, y) {
    return x + y;
}
"""
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('test1', 40, 2) == 42
    
    # Test case 2
    code = """
function test2(x, y, z) {
    return x + y + z;
}
"""
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('test2', 40, 1, 1) == 42
    
    # Test case 3
    code = """
function test3(x, y, z, w) {
    return x + y + z + w;
}
"""
    interpreter = JSInterpreter(code)

# Generated at 2022-06-24 13:53:10.559445
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = """
        var a = {};
        a.b = 1;
        a.c = 2;
    """

    jsi = JSInterpreter(code)

    stmt = 'var a={};'
    jsi.interpret_statement(stmt, {})

    stmt = 'a.b=1;'
    jsi.interpret_statement(stmt, {})

    stmt = 'a.c=2;'
    jsi.interpret_statement(stmt, {})

    # the variable a should now have 2 fields
    obj = jsi._objects['a']

    assert 'b' in obj
    assert obj['b'] == 1

    assert 'c' in obj
    assert obj['c'] == 2


# Generated at 2022-06-24 13:53:19.121599
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interp = JSInterpreter("h = {a:function(){return y},b:function(a,b,c){return a+b+c},c:function(){return x+1}};")
    res = interp.interpret_statement("h.a()",{'y':1})
    assert res[0] == 1
    res = interp.interpret_statement("h.b(1,2,3)",{'x':0})
    assert res[0] == 6
    res = interp.interpret_statement("h.c()",{'x':0})
    assert res[0] == 1
    res = interp.interpret_statement("var xy = h.a();return xy",{'y':4})
    assert res[0] == 4


# Generated at 2022-06-24 13:53:24.223207
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('var argument1;')
    argnames = ['argument1']
    code = '''
        var variable1 = argument1.toString(16);
        var variable2 = variable1;
        return variable2;
    '''
    function = js_interpreter.build_function(argnames, code)
    assert function(['abc']) == 'abc'

# Generated at 2022-06-24 13:53:33.249300
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    test_func_names = ['Aa', 'bb', 'CC', 'dd_', '_$dd', 'ee77', 'foob$r']
    test_func_codes = []
    for func_name in test_func_names:
        test_func_code = '''
var {func_name}=function(a,b){return a+b};

'''.format(func_name = func_name)
        test_func_codes.append(test_func_code)
    
    for i in range(len(test_func_names)):
        js_interpreter = JSInterpreter(test_func_codes[i])
        func = js_interpreter.extract_function(test_func_names[i])
        assert func([1, 2]) == 3
    
    test_func_codes

# Generated at 2022-06-24 13:53:45.379513
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter("""
        var a = b;
        var c = function() { var d = e; };
        return a;
    """)
    assert interpreter.interpret_statement("var a = b;") == (None, False)
    assert interpreter.interpret_statement("var c = function() { var d = e; }") == (None, False)
    assert interpreter.interpret_statement("return a;") == (None, True)
    # test for evaluate expression
    assert interpreter.interpret_statement("a", {'a':123}) == (123, False)
    assert interpreter.interpret_statement("a[0]", {'a':[123]}) == (123, False)
    assert interpreter.interpret_statement("a.length", {'a':[123]}) == (1, False)
    assert interpreter.interpret_

# Generated at 2022-06-24 13:53:55.860162
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    var a = 42;
    var b = true;
    var c = "hello";
    var d = ['\\'', '"'];
    var e = {'a': 1, 'b': 'c'};
    function f(g) {
        return e[g];
    }
    function h() {
        return 'foobar';
    }
    function i(x) {
        return x;
    }
    var j = [12, 13, 14];
    var k = {'a': 1, 'b': 'c', 'f': f, 'h': h};
    var l = {'l1': {'l2': {'l3': 13, 'f': i}}, 'f': f, 'h': h};
    '''

# Generated at 2022-06-24 13:54:08.227517
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:54:14.486882
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:54:25.437836
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():

    js_code = 'var test=function(){};'
    js_code += 'var test1=function(arg1){var b;};'
    js_code += 'var test2=function(arg2,arg3,arg4){var c;var d;};'

    oJSInterpreter = JSInterpreter(js_code)
    assert oJSInterpreter.build_function([], js_code)([]) == None
    assert oJSInterpreter.build_function(['arg1'], 'var b;')(['a']) == None
    assert oJSInterpreter.build_function(['arg2', 'arg3', 'arg4'],
                                         'var c;var d;')(['a', 'b', 'c']) == None



# Generated at 2022-06-24 13:54:35.218252
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    obj = """
{
  xxx: "abc",
  yyy: [1,2,3],
  zzz: [{
    aaa: "def",
    bbb: 123,
    ccc: {
      ddd: "ghi",
    },
    eee: "jkl",
  }],
  func_1: function(a, b, c) {
    return a+b+c
  },
  func_2: function(a) {
    return a
  },
}
"""
    f = """
function func(a, b, c) {
  var d = a+b-c
  return func_1(a, b, c) * d * func_2(1)
}
"""
    interp = JSInterpreter(obj + f)

# Generated at 2022-06-24 13:54:41.137790
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # f("abc")
    code = '"abc"'
    result = JSInterpreter(None).build_function([], code)('')
    assert result == 'abc'
    # f("abc", "def")
    code = '"abc"'
    result = JSInterpreter(None).build_function(['a'], code)('def')
    assert result == 'abc'
    # f("abc", "def", "ghi")
    code = '"abc" + arguments[1] + arguments[2]'
    result = JSInterpreter(None).build_function(['a', 'b'], code)('def', 'ghi')
    assert result == 'abcdefghi'
    # f("abc", "def", "ghi")

# Generated at 2022-06-24 13:54:51.134642
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    jsinterpreter = JSInterpreter('''
        var a = {
            "reverse": function() { [native code] },
            "join": function() { [native code] }
        };
        abcd.efg = {
            "hij": function() { [native code] }
        };
        function f() {
            return a;
        }
        function g(str) {
            return str;
        }
        var h = function(obj) {
            return obj;
        }
        function test() {
            var a = "abcdefghijklm".split("");
            a = a.reverse();
            var b = a.join("");
            return b;
        }
    ''')
    assert jsinterpreter.call_function('test') == 'mlkjihgfedcba'

# Generated at 2022-06-24 13:55:01.015181
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:55:10.161101
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = """
    var a = 0;
    function f1(x, y) {
        z = x + y;
        return z;
    }

"""
    obj = JSInterpreter(js)
    assert obj.call_function('f1', 3, 5) == 8
    obj.code += """
function f2(n, m) {
    var p = n + m;
    var q = n * m;
    return p*q;
}
    """
    assert obj.call_function('f2', 1, 4) == 20



# Generated at 2022-06-24 13:55:20.066558
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    TEST_CODE_1 = '''
  function test_func(arg1, arg2) {
    var obj = {
      key1: 'val1',
      key2: 'val2',
      key3: function(arg1, arg2) {
          return arg1 + arg2;
      },
      key4: function(arg1, arg2) {
          return arg1 - arg2;
      }
    };
  }
    '''
    test_obj = JSInterpreter(TEST_CODE_1)
    result = test_obj.extract_object('obj')
    assert len(result) == 4
    assert result['key1'] == 'val1'
    assert result['key2'] == 'val2'
    assert result['key3'](1, 2) == 3

# Generated at 2022-06-24 13:55:28.422385
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
        function f(a){return a*a};
        function g(arr){arr.reverse();};
        function h(a,b){return f(a)+f(b);};
        """
    i = JSInterpreter(code)
    assert i.call_function('f', 3) == 9
    assert i.call_function('h', 3, 6) == 45

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-24 13:55:34.171761
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    jsi = JSInterpreter('''\
        function foo(a,b) {
            var c = a + b;
            var d = c - b;
            return d;
        }

        var bar = {
            add: function (a, b) {
                return a + b;
            }
        };
        ''')
    assert jsi.call_function('foo', 5, 6) == 11
    assert jsi.call_function('bar.add', 5, 6) == 11

# Generated at 2022-06-24 13:55:45.559583
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    functions = {'f': lambda x: x}
    interp = JSInterpreter('foo=1;', {'f': functions['f']})

    # Test all combinations of operators
    for op, opfunc in _OPERATORS:
        for i in range(1, 11):
            for j in range(1, 11):
                expr = '{0}{2}{1}'.format(i, j, op)
                res = opfunc(i, j)
                assert interp.interpret_expression(expr, {'foo': 0}) == res

    # Test all combinations of assignments
    for op, opfunc in _ASSIGN_OPERATORS:
        for i in range(1, 11):
            for j in range(1, 11):
                expr = 'foo{0}{1}'.format(op, j)

# Generated at 2022-06-24 13:55:54.733991
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:56:05.264952
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    assert JSInterpreter('').interpret_statement('a = 1;') == (1, False)
    assert JSInterpreter('').interpret_statement('return 1;') == (1, True)
    assert JSInterpreter('').interpret_statement('a = b;') == (None, False)
    assert JSInterpreter('').interpret_statement('return b;') == (None, True)
    assert JSInterpreter('').interpret_statement('a = "1";') == ('1', False)
    assert JSInterpreter('').interpret_statement('return "1";') == ('1', True)
    assert JSInterpreter('').interpret_statement('a = b + 1;') == (None, False)

# Generated at 2022-06-24 13:56:12.713372
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:56:23.677480
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:56:29.438728
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter(
        r'''function foo(a, b) {
               return a+b;
           }''')
    assert js_interpreter.call_function('foo', 1, 4) == 5


# Generated at 2022-06-24 13:56:35.292839
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter(code='')
    var_m = re.match(r'var\s+', 'var x = 2')
    if var_m:
        var_name = var_m.group().strip()
        expr = 'var x = 2'[len(var_m.group(0)):]
        v = js_interpreter.interpret_statement(expr=expr, local_vars={})
    return

# Generated at 2022-06-24 13:56:43.427362
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        OO = {
            B: function () {
                return ('a' + 'b'.toUpperCase())
            },
            A: function () {
                return OO.B() + 'c'
    }
    '''
    jsi = JSInterpreter(js_code)
    obj = jsi.extract_object('OO')
    assert len(obj) == 2
    assert obj['A']() == 'aBc'
    assert obj['B']() == 'ab'


# Generated at 2022-06-24 13:56:53.882428
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    f = JSInterpreter("function g(a,c) { var d = a + c; return d; }").build_function(["a", "c"], "var d = a + c; return d;")
    assert f((1, 2)) == 3
    f = JSInterpreter("function g(a,c) { var d = a + c; if (d > 20) return 2; return d; }").build_function(["a", "c"], "var d = a + c; if (d > 20) return 2; return d;")
    assert f((1, 2)) == 3
    assert f((10, 10)) == 2


if __name__ == '__main__':
    test_JSInterpreter_build_function()

# Generated at 2022-06-24 13:57:03.096965
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        function func(arg0, arg1, arg2) {
            if (arg0 == 1) {
                return arg1;
            } else {
                return arg2;
            }
        }
    """)
    func = js_interpreter.build_function(('arg0', 'arg1', 'arg2'), """
        if (arg0 == 1) {
            return arg1;
        } else {
            return arg2;
        }
    """)
    assert func((1, 2, 3)) == 2
    assert func((2, 2, 3)) == 3


# Generated at 2022-06-24 13:57:14.202858
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter('')
    f = jsi.build_function
    assert f(['a', 'b', 'c'], 'e=a+b+c;f=d;return d;')(['1', '2', 3, '4']) == '4'
    assert f(['a', 'b', 'c'], 'e=a+b+c;return e;')(['1', '2', 3]) == 6
    assert f(['a', 'b', 'c'], 'return a+b+c;')(['1', '2', 3]) == 6
    assert f(['a', 'b', 'c'], 'return d();')(['1', '2', 3, lambda: 4]) == 4

# Generated at 2022-06-24 13:57:17.377473
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    print('start test.')
    import pytest
    assert(pytest.main(['-s', '-k JSInterpreter:test', 'ytb_extractor/js_interpreter.py']) == 0)
    print('end test.')


# Generated at 2022-06-24 13:57:22.884206
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        a = {
            "b": function(p) {return p},
            "c": function(p) {return -p}
        }
        '''
    jsi = JSInterpreter(code, {})
    obj = jsi.extract_object('a')
    assert obj['b'](5) == 5
    assert obj['c'](5) == -5


# Generated at 2022-06-24 13:57:33.444756
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_int = JSInterpreter(None)
    assert js_int.interpret_statement("var a = 1", {}, 1000) == (1, False)
    assert js_int.interpret_statement("var a = b", {}, 1000) == (None, False)
    assert js_int.interpret_statement("var a = 1", {"b": 2}, 1000) == (1, False)
    assert js_int.interpret_statement("return a", {"a": 1}, 1000) == (1, True)
    assert js_int.interpret_statement("return", {"a": 1}, 1000) == (None, True)
    assert js_int.interpret_statement("return;", {}, 1000) == (None, True)
    assert js_int.interpret_statement("a = 1", {"a": 0}, 1000) == (1, False)


# Generated at 2022-06-24 13:57:44.511276
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    test_object_string = \
'''
var Object_1 = {
    Object_1_Function_A: function(arg_string, arg_int) {
        return arg_string + arg_int;
    },
    Object_1_Function_B: function(arg_string) {
        return arg_string;
    },
    Object_1_Function_C: function(arg_int) {
        return arg_int;
    },
    Object_1_Function_D: function(arg_string_1, arg_string_2) {
        return arg_string_1 + arg_string_2;
    }
};
'''

    js_interpreter = JSInterpreter(test_object_string)
    obj = js_interpreter.extract_object("Object_1")

# Generated at 2022-06-24 13:57:52.691301
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_code = r'''
        var a = "test";
        var result = "test";
        var obj = {
            "func": function(arg1){
                var a = "test2";
            }
        };
        function main(){
            var b = "test3";
        }
        main();
        var result2 = obj.func(1);
    '''
    jsi = JSInterpreter(js_code)
    assert jsi._functions == {}
    assert jsi._objects == {
        "obj": {
            "func": lambda args: None
        }
    }



# Generated at 2022-06-24 13:58:00.974002
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
    function func1(arg1) {
        return arg1 + 5;
    }
    function func2(arg2) {
        return arg2 * 2;
    }
    function func3(arg1, arg2) {
        return func1(arg1) + func2(arg2);
    }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('func3', 5, 4) == 23

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-24 13:58:07.201271
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    interpreter = JSInterpreter("""
        var sM = {
        Qe: function(a) {
            return a.toString()
        },
        H7: function(a, b) {
            this.xe = a;
            this.j5 = b
        }
    };
        """)
    obj = interpreter.extract_object("sM")
    assert obj["Qe"]("abcd") == "abcd"



# Generated at 2022-06-24 13:58:14.818404
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''var str="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";var pos=0;'''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.code == code
    assert js_interpreter._functions == {}
    assert js_interpreter._objects == {}


# Generated at 2022-06-24 13:58:24.286051
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # A javascript code string
    code = '''function test_function(){var a = 100; b = 200; return a; a = 300; return a;}'''
    test_interpreter = JSInterpreter(code)
    #Test case 1: a string without assignment
    test_1 = "var a = 100; b = 200; return a; a = 300; return a;"
    test_res, abort = test_interpreter.interpret_statement(test_1, {'b': None})
    #Abort should be False
    assert abort == False
    #Should return 300
    assert test_res == 300

    #Test case 2: a string with assignment with return
    test_2 = "a = 300; return a;"

# Generated at 2022-06-24 13:58:28.854542
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    assert JSInterpreter('').build_function([], 'return 1')() == 1
    assert JSInterpreter('').build_function(['a'], 'return a')('a') == 'a'
    assert JSInterpreter('').build_function(['a', 'b'], 'return a + b')([1, 2]) == 3

# Generated at 2022-06-24 13:58:40.770978
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('''
        var obj1 = {
            "a": 1,
            "b": function(x) { return x * 2; },
            "c": function() { return this["a"] + this["b"]("5"); }
        };
        var obj2 = {
            "a": 2,
            "b": function(x) { return x * 3; },
            "c": function() { return this["a"] + this["b"]("5"); }
        };
        var obj3 = {
            "a": 3,
            "b": function(x) { return x * 4; },
            "c": function() { return this["a"] + this["b"]("5"); }
        };
    ''')
    assert js_interpreter.interpret_expression('1')

# Generated at 2022-06-24 13:58:44.493097
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():

    js = '''
        function test_one(a, b) {
            return a + b;
        }

        function test_two(a, b, c) {
            return (a + b) * c;
        }
    '''
    js_c = JSInterpreter(js)
    
    assert 1 == js_c.call_function('test_one', -1, 2)
    assert 4 == js_c.call_function('test_two', 1, 2, 2)

# Generated at 2022-06-24 13:58:56.472403
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    test_code = '''
    var obj = {
        "func1": function(x) { return x * 2; },
        "func2": function(x, y) { return x + y; },
        "func3": function(x) { return this.func1(this.func2(x, 1)); },
        "prop1": 5
    };

    var func1 = function(x) { return x * 2; };

    var func2 = function(x, y) { return x + y; };
    '''
    with JSInterpreter(test_code) as js:
        obj = js.extract_object('obj')
        func1 = js.extract_function('func1')
        func2 = js.extract_function('func2')

        assert obj['prop1'] == 5
        assert func1

# Generated at 2022-06-24 13:58:59.283535
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    extractor = None  # type: JSInterpreter
    assert (extractor.call_function(
        "function_name", "arg1", "arg2") == "expected_result")

# Generated at 2022-06-24 13:59:10.172825
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_code = '''
        function hello(w){
            return "hello"+w;
        }
        function world(){
            return "world";
        }
        function add(x, y){
            return x+y;
        }
        function add2(x, y){
            var self = this;
            return self.add(x, y);
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.interpret_statement('hello("")', {}) == 'hello'
    assert js_interpreter.interpret_statement('hello(world())', {}) == 'helloworld'
    assert js_interpreter.interpret_statement('add(1, "2")', {}) == '12'
    assert js_interpreter.interpret_statement

# Generated at 2022-06-24 13:59:21.346588
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var testobj = {
            first: function(a) {return a+10;},
            second: function(a,b) {return a*b;},
            third: function(a,b,c) {return a-b-c;}
        };
        var otherobj = {
            first: 'this_is_a_string',
            second: 20,
        };
    '''
    jsi = JSInterpreter(code)
    assert(jsi.extract_object('testobj') == {'first': lambda a: a+10,
                                             'second': lambda a,b: a*b,
                                             'third': lambda a,b,c: a-b-c})

# Generated at 2022-06-24 13:59:27.185691
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        function f(n, m) {
            return g(n+m, 123);
        }
        g = function (s, t) {
            return s+t;
        }"""
    interpreter = JSInterpreter(code)
    for func_name in ('f', 'g'):
        assert interpreter.extract_function(func_name)((3, 4)) == 130
        assert interpreter.call_function(func_name, 3, 4) == 130


# Generated at 2022-06-24 13:59:36.372943
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        var obj = {
            a: function(b, c) {return d + e * f * g * h;}
        };
        var baz = function(t, x) {
            return t * x * t * x * t * x * t * x;
        };
        function f(a, b, c, g) {
            return a * b * c * g;
        }
        var g = function(a, b) {
            return a + b;
        };
    '''
    i = JSInterpreter(code)
    f = i.extract_function('f')
    assert f((1, 2, 3, 4)) == 24
    g = i.call_function('g', 1, 2)
    assert g == 3

# Generated at 2022-06-24 13:59:42.390863
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Unit test code
    funcname = 'TEST'
    argnames = ['arg1', 'arg2']
    code = 'return arg1 + arg2;'
    jsi = JSInterpreter('')
    f = jsi.build_function(argnames, code)
    assert f([10, 5]) == 15


# Generated at 2022-06-24 13:59:43.100284
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    pass

# Generated at 2022-06-24 13:59:47.134857
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
	assert JSInterpreter('').call_function('toString', 1) == '1'
	assert JSInterpreter('').call_function('charAt', '1234', 2) == '3'

##############################################################################################################################

# Generated at 2022-06-24 13:59:57.492158
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('', None)
    f = js.build_function([], 'if (true) return 1; return 0;')
    assert f(()) == 1
    f = js.build_function(['x'], 'return x * x;')
    assert f([2]) == 4
    f = js.build_function(['x', 'y'], 'return x + y;')
    assert f([2, 3]) == 5

    f = js.build_function(['s'], 'return s[2];')
    assert f(['abc']) == 'c'
    f = js.build_function(['s'], 'return s[2:];')
    assert f(['abc']) == 'c'


# Generated at 2022-06-24 14:00:03.636124
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        var c = 36;
        var d = 6;
        var a = c + d;
    	function myfunction(x) {
    	  return x * a;
    	}
    '''
    js = JSInterpreter(code=code)
    argnames = ['x']
    code = 'return x * a;'
    function = js.build_function(argnames=argnames, code=code)
    assert function == resf
