

# Generated at 2022-06-24 13:50:04.171341
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsi = JSInterpreter('''
    f1 = function(x,y){
        return x+y;
    };
    f2 = function(z){
        return z*2;
    };''')

    assert jsi.call_function('f1', 1, 2) == 3
    assert jsi.call_function('f1', y=1, x=2) == 3
    assert jsi.call_function('f2', z=4) == 8
    assert jsi.call_function('f2', 2) == 4


# Generated at 2022-06-24 13:50:08.469520
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    jsinterpreter = JSInterpreter('function b(a) { return a*a }')
    f = jsinterpreter.extract_function('b')
    assert f((1,)) == 1
    assert f((2,)) == 4
    assert f((3,)) == 9
    assert f((4,)) == 16

# Generated at 2022-06-24 13:50:16.834142
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    extractor = JSInterpreter("""
        var a = {
            b:{
                c:'str',d:4
            },
            e:function(a,b){
                return a+b;
            },
            f:function(a){
                return a*a;
            }
        };
        """)
    obj = extractor.extract_object('a')
    assert 'b' in obj
    assert obj['b'] == {'c': 'str', 'd': 4}
    assert obj['f'](5) == 25



# Generated at 2022-06-24 13:50:26.447789
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter({})

# Generated at 2022-06-24 13:50:36.681742
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = r'''
    function test(arg1, arg2) {
        return arg1 + arg2;
    }

    function test2() {
        return function(arg3) {
            return arg3;
        }
    }
    '''
    jsi = JSInterpreter(code)
    ##print (jsi.interpret_statement('return "hello";', {'a':'b'}))
    assert jsi.interpret_expression('1 + 2', {'a': 'b'}) == 3
    assert jsi.interpret_expression('a', {'a': 'b'}) == 'b'
    assert jsi.interpret_expression('test2()("c")', {'a': 'b'}) == 'c'

# Generated at 2022-06-24 13:50:47.254615
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Example 1
    interpreter = JSInterpreter(
        '''
        function testfunc(testarg) {
            if (testarg == 0)
                return 123;
            return 456;
        }
        ''')
    f = interpreter.extract_function('testfunc')
    assert f((0,)) == 123
    assert f((1,)) == 456

    # Example 2
    interpreter = JSInterpreter(
        '''
        var testfunc2 = function(testarg) {
            if (testarg == 0)
                return 123;
            return 456;
        }
        ''')
    f = interpreter.extract_function('testfunc2')
    assert f((0,)) == 123
    assert f((1,)) == 456

    # Example 3

# Generated at 2022-06-24 13:50:51.785070
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function func(param1, param2) {
            return param1 * param2;
        }
    '''
    interpreter = JSInterpreter(code)
    func = interpreter.build_function(['param1', 'param2'], 'return param1*param2;')
    assert func((2, 3)) == 6


# Generated at 2022-06-24 13:51:01.752727
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:51:12.534699
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    # Test 1: function with no name
    code = """
          function(a){return a}
          """
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('', 1) == 1

    # Test 2: function with name
    code = """
          function f(a){return a}
          """
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('f', 1) == 1

    # Test 3: function with name and arguments
    code = """
          function f(a, b){return a+b}
          """
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('f', (1, 2)) == 3

    # Test 4: function with name

# Generated at 2022-06-24 13:51:25.074276
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:51:32.478627
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var aa = {
            bb: function() {
                var cc = function() {
                    var dd = function() {
                        return 1;
                    }
                    return dd(2);
                }
            }
        }
        '''

    class Obj(object):
        def __init__(self):
            self.bb = Obj()
            self.bb.cc = Obj()
            self.bb.cc.dd = Obj()
            self.bb.cc.dd.ee = lambda x: x

    expected_obj = {
        'bb': Obj.bb,
        'cc': Obj.bb.cc,
        'dd': Obj.bb.cc.dd,
        'ee': Obj.bb.cc.dd.ee,
    }


# Generated at 2022-06-24 13:51:35.621266
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = JSInterpreter('var test = 1;')
    assert js.interpret_statement('test;', {})[0] == 1


# Generated at 2022-06-24 13:51:41.511197
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:51:43.414221
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js_interpreter = JSInterpreter('var a = 1; var b = 2;')
    assert isinstance(js_interpreter, JSInterpreter)


# Generated at 2022-06-24 13:51:48.405078
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = '''
    function abc() {
        if (a == 3) {
            return 10;
        }
        return 20;
    }
    '''
    _jsi = JSInterpreter(js)
    assert _jsi.call_function('abc') == 20
    assert _jsi.call_function('abc', 3) == 10


# Generated at 2022-06-24 13:51:55.647869
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    code = '''
    var obj = {
        getString: function(){ return 'abc'; },
        getNumber: function(){ return 2; }
    };
    function vodig(num, str1, str2){
        return str1[num] + str2;
    }
    function f(n){
        return n + 1;
    }
    var e, b, c;
    e = 1, b = 2, c = 3;'''
    interpreter = JSInterpreter(code)
    # Test case 1
    assert interpreter.interpret_statement('var a, b, c', {}) == (None, False)
    # Test case 2
    assert interpreter.interpret_statement('a = b = c = 1', {}) == (1, False)
    # Test case 3

# Generated at 2022-06-24 13:52:08.487700
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        $dew = {
            encode: function(str) {
                var result = "";
                var i;
                for (i = 0; i < str.length; i++) {
                    var value = str.charCodeAt(i);
                    var character = String.fromCharCode(value + i);
                    result = result + character;
                }
                return result;
            },
            decode: function(str) {
                var result = "";
                var i;
                for (i = 0; i < str.length; i++) {
                    var value = str.charCodeAt(i);
                    var character = String.fromCharCode(value - i);
                    result = result + character;
                }
                return result;
            }
        }
    """
    js = JSInterpreter(code)


# Generated at 2022-06-24 13:52:17.882428
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter('var x = 1;\nvar y = 2;\nreturn x;\n')
    result, abort = js.interpret_statement('x=x+x*x;', {'y':2})
    assert result == 9
    assert not abort

    result, abort = js.interpret_statement('y=y+y*y;', {'x':2})
    assert result == 6
    assert not abort

    result, abort = js.interpret_statement('return y;', {'x':2})
    assert result == 6
    assert abort

    js = JSInterpreter('var x = 1;\nvar y = 2;\n')
    result, abort = js.interpret_statement('x=x+x*x;', {'y':2})
    assert result == 3
    assert not abort



# Generated at 2022-06-24 13:52:30.090630
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # Test code 1:
    code1 = '''
        function a(){
            return 2;
        }
        '''
    js_interpreter1 = JSInterpreter(code1)
    assert js_interpreter1.call_function('a') == 2

    # Test code 2:
    code2 = '''
        function b(arg1){
            return arg1 + 2;
        }
        '''
    js_interpreter2 = JSInterpreter(code2)
    assert js_interpreter2.call_function('b', 0) == 2

    # Test code 3:
    code3 = '''
        var c = function(arg1, arg2){
            return arg1 + arg2;
        }
        '''
    js_interpreter3 = JSInterpreter(code3)

# Generated at 2022-06-24 13:52:38.657439
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function abc(a, b) {
            var c;
            c = a + b;
            return c;
        }
        var def = function (a, b) {
            var c;
            c = a * b;
            c = c + a;
            c = c + b;
            return c;
        }
    '''
    i = JSInterpreter(code)
    for func in ['abc', 'def']:
        for a in range(5):
            for b in range(5):
                f = i.extract_function(func)
                assert i.call_function(func, a, b) == f((a, b))


# Generated at 2022-06-24 13:52:50.017333
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:52:58.682140
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:53:11.585439
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter(
        "var obj = {n: Math.random(), f: function(a, b){return true;}};var var_n = obj['n'];return var_n*10;")
    print(interpreter.interpret_statement("return var_n * 10;", {}))
    print(interpreter.interpret_statement("obj.f(1,2);", {}))
    print(interpreter.interpret_statement("obj['n'];", {}))
    print(interpreter.interpret_statement("var_n;", {}))
    print(interpreter.interpret_statement("obj['f'](1,2);", {}))
    print(interpreter.interpret_statement("return obj[\"f\"](1,2);", {}))

# Generated at 2022-06-24 13:53:12.947214
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    JSInterpreter('var myfunc = function(args) {return args}')

# Generated at 2022-06-24 13:53:22.594589
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        function foo() {}
        var bar = {
            a: function(x,y) {
                return x+y;
            },
            b: function(x,y) {
                return x-y;
            }
        };
        var foobar = bar.a(2, 3);
        var res = bar.b(4, foobar);
        return res;
    '''

    jsi = JSInterpreter(code)
    bar = jsi.extract_object('bar')
    assert bar == {'a': bar['a'], 'b': bar['b']}
    assert jsi.call_function('foo') is None
    assert jsi.call_function('res') == -5
    assert bar['a'](10, 20) == 30

# Generated at 2022-06-24 13:53:23.124541
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    pass


# Generated at 2022-06-24 13:53:26.993158
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
var foo = function(bar) {
    return bar * 2;
}
'''
    interpreter = JSInterpreter(js_code)
    foo = interpreter.extract_function('foo')
    assert(foo((10,)) == 20)


# Generated at 2022-06-24 13:53:35.282173
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    jsi = JSInterpreter(
        '''
        var xxx = { a: function() {return 1},
                   b: function(y) {return 2 * y},
                   c: function(x, y) {return x + y}
        };
        var fff = function() {return 1};
        ''')

    assert jsi.build_function([], 'a=1;')([]) == 1
    assert jsi.build_function(['y'], 'return ++y')([-1]) == 0
    assert jsi.build_function(['x', 'y'], 'return x * y + 2')([1, 2]) == 4
    assert jsi.build_function(['x', 'y'], 'y=1+1;return x + y + 1')([1, 2]) == 5


# Generated at 2022-06-24 13:53:47.307952
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
    a = "abcd";
    b = "1234";
    c = a.split("");
    """
    jsi = JSInterpreter(js_code)
    print(jsi.call_function('a.split', ''))  # ['a', 'b', 'c', 'd']
    print(jsi.call_function('c.join', ''))  # abcd
    print(jsi.call_function('b.split', ''))  # ['1', '2', '3', '4']
    
    js_code = """
    d = "a,b,c,d,e,f";
    e = d.split(",");
    """
    jsi = JSInterpreter(js_code)

# Generated at 2022-06-24 13:53:52.723136
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
function func(a, b, c) {
    return a[0] + b[1] + c[2]
}
"""
    x = JSInterpreter(js_code)
    args = ['abc', 'abcd', 'abcde']
    assert x.call_function('func', *args) == 'abcdbcdecde'


# Generated at 2022-06-24 13:53:59.791389
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:54:10.095731
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:54:18.489766
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:54:30.401514
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    # Test with data from test/test_urls.txt
    code1 = '''
    x="1";
    y=2;
    z=x+y;
    k=x+y*2-3;
    l=z+k/(4%5);
    v=["a","b"];
    w=[5,6];
    u=[v,w];
    abc={"foo":1,"bar":2};
    if (x==1) {
        t=123;
    }
    else {
        t=456;
    }
    f=function(a,b){
        r=a+b*3;
        return r;
    };
    '''
    js = JSInterpreter(code1)
    assert js.interpret_expression('z', js._objects) == 3
   

# Generated at 2022-06-24 13:54:40.055565
# Unit test for constructor of class JSInterpreter

# Generated at 2022-06-24 13:54:49.092983
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:54:51.631155
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    test_str = "local_vars"
    try:
        JSInterpreter().build_function(test_str, "")
        assert False
    except TypeError:
        pass



# Generated at 2022-06-24 13:55:01.474395
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    objname = 'test'
    funcname = 'testFunction'
    code = 'var %s = { %s: function(arg1,arg2){ return arg1*arg2; }}' % (objname, funcname)
    interpreter = JSInterpreter(code)
    argnames = ['arg1', 'arg2']
    func_code = 'return arg1*arg2;'
    func = interpreter.build_function(argnames, func_code)
    assert func([3, 4]) == 12
    assert objname not in interpreter._functions

    code = code.replace(objname, funcname)
    interpreter = JSInterpreter(code)
    func = interpreter.build_function(argnames, func_code)
    assert func([3, 4]) == 12
    assert funcname in interpreter._functions
    assert func

# Generated at 2022-06-24 13:55:12.709000
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    # Example code taken from youtube
    code = '''
        var s = {
            g: function(a, b) {
                var c = a.length,
                    d = window.sjcl.bitArray;
                b = d.bitSlice(f(a), 0, 8 * b);
                a = [];
                for (d = 0; d < c; d += 4) a.push(String.fromCharCode(b[d >> 2] >> 8 * (d & 3) & 255));
                return a.join("")
            }
        };
    '''
    interpreter = JSInterpreter(code)
    s = interpreter.extract_object('s')
    assert s['g']([1, 2, 3, 4], 8) == '????'


# Generated at 2022-06-24 13:55:17.077269
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    jsinter = JSInterpreter("function swap(arr, first_Index, second_Index){\
        \nvar temp = arr[first_Index];\
        \narr[first_Index] = arr[second_Index];\
        \narr[second_Index] = temp;\
    };")
    assert jsinter.call_function("swap", ["A", "B", "C", "D", "E"], 0, 2) == None

# Generated at 2022-06-24 13:55:27.138023
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test JSInterpreter.build_function method
    assert JSInterpreter.build_function((), '')() is None # Test empty code
    assert JSInterpreter.build_function(('a',), 'a')((1,)) == 1 # Test one argument
    assert JSInterpreter.build_function(('a', 'b'), 'a+b')((1,2)) == 3 # Test two arguments
    assert JSInterpreter.build_function(('a', 'b', 'c'), 'a+b+c')((1,2,3)) == 6 # Test three arguments


# Generated at 2022-06-24 13:55:38.271124
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    class MockedInterpreter(JSInterpreter):
        def __init__(self, code, objects = None):
            super(MockedInterpreter, self).__init__(code, objects)
            self._functions = {"a": lambda args: 1, "b": lambda args: 2}

        def extract_function(self, funcname):
            return self._functions[funcname]

    code = """
        var v = {
            "a": function(a) {
                return a;
            },
            "b": function(b) {
                return b;
            }
        };
        var w = v.a();
        var x = v.b();
    """

    interpreter = MockedInterpreter(code)
    assert interpreter.interpret_expression("v.a()", locals()) == 1
    assert interpreter

# Generated at 2022-06-24 13:55:50.601937
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:55:59.961278
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        function abc(arg1, arg2) {
            return abcdef(arg1, arg2, "arg3");
        }

        testVar = {
            testMethod: function(arg) {
                return abc(arg, "something");
            }
        }

        function abcdef(arg1, arg2, arg3) {
            return arg1 + arg2 + arg3;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('abc', 'arg1', 'arg2') == 'arg1arg2arg3'
    assert js_interpreter.call_function('abcdef', 'arg1', 'arg2', 'arg3') == 'arg1arg2arg3'
    assert js_interpreter

# Generated at 2022-06-24 13:56:09.217855
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-24 13:56:20.348069
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js = JSInterpreter('', objects={'a': {'b': {'c': 3}}})

    assert js.interpret_statement('var x = [1,2,3]', {})[0] == [1,2,3]
    assert js.interpret_statement('var x = [1,2,3][1]', {})[0] == 2
    assert js.interpret_statement('var x = [1,2,3][1]', {})[0] == 2
    assert js.interpret_statement('x[1] = 13', {'x': [1,2,3]})[0] == 13
    assert js.interpret_statement('x[1] = x[2]', {'x': [1,2,3]})[0] == 3

# Generated at 2022-06-24 13:56:27.018024
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = r'''
        var a = {
            c: function() {
                return 3;
            },
            d: function() {
                return this.c();
            }
        };
        b = {
            e: function() {
                return 4;
            }
        };
    '''
    obj = JSInterpreter(js_code).extract_object('a')
    assert(obj == {'c': lambda: 3, 'd': lambda: obj['c']()})

#Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:56:36.825487
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    videos_metadata_filename = os.path.join(os.path.dirname(__file__), 'yt_videos_metadata.json')
    videos_metadata = json.loads(open(videos_metadata_filename).read())
    for video_id in videos_metadata:
        if 'signatureCipher' in videos_metadata[video_id]:
            signatureCipher = videos_metadata[video_id]['signatureCipher']
            signatureCipher_JSInterpreter = JSInterpreter(signatureCipher)
            signatureCipher_url_encoded_fmt_stream_map = urllib.unquote(signatureCipher.split('&')[0].split('=')[1])
            signatureCipher_url_encoded_fmt_stream_map_list = signatureCipher_url_encoded_fmt_

# Generated at 2022-06-24 13:56:45.515190
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    assert JSInterpreter('var a1=1;')
    assert JSInterpreter('var a2=1;var a2=2;')
    assert JSInterpreter('var a3=1;var a3=2;var a3=3;')
    assert JSInterpreter('var a4=1;var a4=2;var a4=3;var a4=4;')
    assert JSInterpreter('var a5=1;var a5=2;var a5=3;var a5=4;var a5=5;')


# Generated at 2022-06-24 13:56:56.129499
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    jsinterpreter = JSInterpreter()
    def test_cases():
        test_case('''
            function func() {
            }''', 'func')
        test_case('''
            f1 = function() {
                var f2 = function() {
                }
            }''', 'f2')
        test_case('''
            var f3 = function() {
            }''', 'f3')
        test_case('''
            var f4 = function() {
                var f5 = function() {
                }
            }''', 'f5')
        test_case('''
            var f6 = {
                f7: function() {
                }
            };''', 'f6.f7')

# Generated at 2022-06-24 13:57:02.780213
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
        var d = {
            "test": function(a,b){
                return a+b;
            }
        }
        '''
    interpreter = JSInterpreter(code)
    assert interpreter.extract_object('d') == {
        "test": lambda args: args[0] + args[1]
    }


# Generated at 2022-06-24 13:57:13.936698
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var myVariable = 'myVariableValue';
        var myObject = {
            foo: 'bar',
            func1: function(a) {
                return 'func1Result';
            },
            func2: function(x, y) {
            var func2Variable = 'func2VariableValue';
                return x + y;
            },
            func3: function(x, y) {
                return x * y;
            }
        };
        """
    myObject = {
        'foo': 'bar',
        'func1': lambda x: 'func1Result',
        'func2': lambda x, y: x + y,
        'func3': lambda x, y: x * y
        }
    extractedObject = JSInterpreter(code).extract_object('myObject')

# Generated at 2022-06-24 13:57:23.771937
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    # first unit test
    code='''function abc(a){
                return a;
                }'''
    obj = '''var a = {b: function(c) { return c;
                                }
                };'''
    function = '''function a(b) {
                        return b;
                    }'''

    interprete = JSInterpreter(code)
    interprete1 = JSInterpreter(obj)
    interprete2 = JSInterpreter(function)

    assert interprete.call_function('abc', 5) == 5
    assert interprete1.call_function('a', 'abc') == 'abc'
    assert interprete2.call_function('a', 10) == 10

    # second unit test

# Generated at 2022-06-24 13:57:34.162622
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter_obj = JSInterpreter("a=5; abc=7;")
    test_obj1 = js_interpreter_obj.interpret_expression("a+2;", {})
    assert test_obj1 == 7
    test_obj2 = js_interpreter_obj.interpret_expression("a+2; abc+1;", {})
    assert test_obj2 == 8
    test_obj3 = js_interpreter_obj.interpret_expression("abc*2; a+2; abc+1;", {})
    assert test_obj3 == 9
    test_obj4 = js_interpreter_obj.interpret_expression("a += 1", {})
    assert test_obj4 == 6

# Generated at 2022-06-24 13:57:39.456412
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''var AABB=function(a,b,d,c){this.x=a;this.y=b;this.width=d;this.height=c;};function FFF() {}'''

    f = JSInterpreter(code).extract_function('FFF')
    f((1, 2))



# Generated at 2022-06-24 13:57:46.837291
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter("""
    var a = 0;

    function test1(param1) {
        var b = param1;
        return a + b;
    }

    function test2(param1, param2) {
        var b = param1;
        var c = param2;
        return test1(b + c);
    }
    """)
    assert js_interpreter.call_function('test1', 1) == 1
    assert js_interpreter.call_function('test2', 1, 1) == 2


# Generated at 2022-06-24 13:57:55.901801
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''  function t(a){return a*2} var n=4; t(n);'''
    JSI=JSInterpreter(code)
    assert JSI.interpret_expression(str(n), {str(n): 2}) == 4
    assert JSI.interpret_expression('t(n)', {str(n): 2}) == 4
    assert JSI.interpret_expression('n', {str(n): 2}) == 2
    assert JSI.interpret_expression('n', {str(n): 3}) == 3
    assert JSI.interpret_expression('t(n)', {str(n): 3}) == 6
    assert JSI.interpret_expression(r't(\'n\')',{r'\'n\'': 3}) == 6

# Generated at 2022-06-24 13:58:03.684903
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    test_code_1 = """
function test(a,b){
    var c = a + b + 1;
    return c;
}
    """
    test_code_2 = """
function test(a,b){
    var c = a + b;
    c = c + 1;
    return c;
}
    """
    test_code_3 = """
function test(a,b){
    var c = a;
    if (b > 1) c = c + 1;
    return c;
}
    """
    test_code_4 = """
function test(a,b){
    var c = a;
    if (b > 1) c = c + 1;
    else c = c + 0;
    return c;
}
    """

# Generated at 2022-06-24 13:58:12.077024
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:58:22.955032
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test 1
    interpreter = JSInterpreter('var args = {};')
    local_vars = {}
    interpreter.interpret_statement('var args = {};', local_vars)
    assert local_vars['args'] == {}

    # Test 2
    interpreter = JSInterpreter('var args = {};')
    local_vars = {}
    interpreter.interpret_statement('var args = [];', local_vars)
    assert local_vars['args'] == []

    # Test 3
    interpreter = JSInterpreter('var args = [];')
    local_vars = {'args': [1, 2], 'a': [1, 2, 3]}
    interpreter.interpret_statement('args = a;', local_vars)
    assert local_vars['args'] == [1, 2, 3]

   

# Generated at 2022-06-24 13:58:25.524390
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    js = JSInterpreter('function abc(){return 1+2;}')
    result = js.call_function('abc')
    assert result == 3

# Generated at 2022-06-24 13:58:37.058054
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:58:42.255865
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    code = '''
    var ytplayer = {
                "config": {
                    "url_encoded_fmt_stream_map": "#1#2#3"
                }
            };
        '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter


if __name__ == '__main__':
    test_JSInterpreter()

# Generated at 2022-06-24 13:58:54.414393
# Unit test for constructor of class JSInterpreter
def test_JSInterpreter():
    test_code_1 = '''
        function abc(a,b,c) {
            return a + b - c;
        }
        '''
    test_code_2 = '''
        var abc = function (a, b, c) {
            return a + b - c;
        }
        '''
    test_code_3 = '''
        var abc = {
            def: function (a, b, c) {
                return a + b - c;
            }
            , ghi: function (a, b, c) {
                return a + b - c;
            }
            , jkl: function (a, b, c) {
                return a + b - c;
            }
        };
        '''

# Generated at 2022-06-24 13:59:03.090531
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-24 13:59:12.179097
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = '''
    var a = 5;
    var b = 4;
    var c = 3;
    var d = 2;
    var e = 1;
    var f = 0;
    var g = -1;
    function o(n) { return n + 1; }
    function p(n) { return n - 1; }
    function q(n) { return n + g; }
    '''
    interpreter = JSInterpreter(js_code)

    assert interpreter.interpret_expression('5', {}) == 5
    assert interpreter.interpret_expression('a', {}) == 5
    assert interpreter.interpret_expression('a-b', {}) == 1
    assert interpreter.interpret_expression('a-b*c', {}) == -2

# Generated at 2022-06-24 13:59:18.042365
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 13:59:26.370257
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = """
      function test1() {
        return 'test';
      }
      function test2(a) {
        return a * 2;
      }
      function test3(a, b) {
        return a * 2 + b * 2;
      }
      function test4(a, b) {
        return test2(a) + test2(b);
      }"""
    js_interp = JSInterpreter(js_code)
    assert js_interp.call_function('test1') == 'test'
    assert js_interp.call_function('test2', 1) == 2
    assert js_interp.call_function('test3', 1, 2) == 6
    assert js_interp.call_function('test4', 2, 3) == 10


# Generated at 2022-06-24 13:59:35.950949
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    interpreter = JSInterpreter("")
    print('Test JSInterpreter.interpret_expression')
    expression = '1 + 2'
    result = interpreter.interpret_expression(expression, {})
    assert result  == 3
    expression = '12 + 13'
    result = interpreter.interpret_expression(expression, {})
    assert result  == 25
    expression = '14 - 13'
    result = interpreter.interpret_expression(expression, {})
    assert result  == 1
    expression = '14 * 13'
    result = interpreter.interpret_expression(expression, {})
    assert result  == 182
    expression = '15 / 13'
    result = interpreter.interpret_expression(expression, {})
    assert result  == 1.1538461538461537
    expression = '15 % 13'
    result = interpreter.interpret_

# Generated at 2022-06-24 13:59:48.267637
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-24 13:59:58.431371
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-24 14:00:08.355239
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    interpreter = JSInterpreter("var a = 'abc';")
    assert(interpreter.interpret_statement("a", {}) == ('abc', False))
    try:
        result = interpreter.interpret_statement("return", {})
    except ExtractorError as e:
        assert "Premature end of parens in 'return'" == str(e)
    try:
        result = interpreter.interpret_statement("return a", {})
    except ExtractorError as e:
        assert "Premature right-side return of  in 'return a'" == str(e)
    assert(interpreter.interpret_expression("a", {}) == 'abc')
    assert(interpreter.interpret_expression("123", {}) == 123)
    interpreter = JSInterpreter("var b = {'c': 'def'}")