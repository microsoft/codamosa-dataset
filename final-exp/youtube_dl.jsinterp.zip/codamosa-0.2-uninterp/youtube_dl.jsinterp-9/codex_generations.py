

# Generated at 2022-06-18 15:27:31.385816
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        function test(a, b) {
            return a + b;
        }
    """
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('test')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:27:38.018851
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:27:49.020314
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    # Test for method interpret_expression
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7


# Generated at 2022-06-18 15:27:54.752997
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    f = js_interpreter.extract_function('test')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:27:59.949360
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('1+2*3+4*5', {}) == 26
    assert js_interpreter.interpret_expression('(1+2)*3+4*5', {}) == 35

# Generated at 2022-06-18 15:28:03.191988
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:28:15.291137
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:28:24.570974
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:30.594444
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-18 15:28:41.855267
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:29:00.449273
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-18 15:29:12.319542
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:29:18.474355
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    var A = {
        b: function(p1, p2) {
            return p1 + p2;
        },
        c: function(p1, p2) {
            return p1 - p2;
        }
    };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('A')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == -1


# Generated at 2022-06-18 15:29:28.874012
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a+b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a-b;')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'return a*b;')
    assert func((1, 2)) == 2
    func = js_interpreter.build_function(['a', 'b'], 'return a/b;')
    assert func((1, 2)) == 0.5

# Generated at 2022-06-18 15:29:34.160008
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    argnames = ['a', 'b']
    code = '''
        var c = a + b;
        return c;
    '''
    f = js_interpreter.build_function(argnames, code)
    assert f((1, 2)) == 3
    assert f((3, 4)) == 7


# Generated at 2022-06-18 15:29:41.369629
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + (2 * 3)', {}) == 7
    assert js_interpreter.interpret_expression('1 + (2 * 3) + 4', {}) == 11
    assert js_interpreter.interpret_expression('1 + (2 * 3) + 4 * 5', {}) == 26

# Generated at 2022-06-18 15:29:54.553064
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; var b = 2; a + b', {})[0] == 3
    assert js_interpreter.interpret_statement('var a = 1; var b = 2; a + b; a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; var b = 2; return a + b', {})[0] == 3

# Generated at 2022-06-18 15:30:04.651098
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return a * b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return a * b;')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return a * b; return a + b')([1, 2]) == 2

# Generated at 2022-06-18 15:30:06.824024
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
    var a = function(x, y) {
        return x + y;
    };
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('a', 1, 2) == 3


# Generated at 2022-06-18 15:30:10.386113
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p, q) {
                return p + q;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:30:34.107429
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function f(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('f', 1, 2) == 3


# Generated at 2022-06-18 15:30:40.698772
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')

# Generated at 2022-06-18 15:30:53.236470
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, '2']) == '12'
    assert js_interpreter.build_function(['a', 'b'], 'a+b')(['1', 2]) == '12'
    assert js_interpreter.build_function(['a', 'b'], 'a+b')(['1', '2']) == '12'
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2, 3]) == 3
    assert js_interpreter

# Generated at 2022-06-18 15:31:02.191028
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('')
    assert js.interpret_expression('1', {}) == 1
    assert js.interpret_expression('1+1', {}) == 2
    assert js.interpret_expression('1+1+1', {}) == 3
    assert js.interpret_expression('1+1+1+1', {}) == 4
    assert js.interpret_expression('1+1+1+1+1', {}) == 5
    assert js.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js.interpret_expression('1+1+1+1+1+1+1+1', {}) == 8

# Generated at 2022-06-18 15:31:13.742622
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-18 15:31:24.393468
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:31:31.936862
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:31:43.036546
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b')
    assert func([1, 2]) == 3
    func

# Generated at 2022-06-18 15:31:48.199859
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var obj = {
            "a": function(x, y) {
                return x + y;
            },
            "b": function(x, y) {
                return x - y;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:32:01.656649
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:32:46.045908
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        function test(a, b) {
            return a + b;
        }
    ''')
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:32:55.848167
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test 1
    js_code = '''
        var a = {
            b: function(p) {
                return p;
            }
        };
        var c = a.b("hello");
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.interpret_expression('c', {}) == 'hello'

    # Test 2
    js_code = '''
        var a = {
            b: function(p) {
                return p;
            }
        };
        var c = a["b"]("hello");
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.interpret_expression('c', {}) == 'hello'

    # Test 3

# Generated at 2022-06-18 15:33:02.295154
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            a: function() {
                return 1;
            },
            b: function() {
                return 2;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a']() == 1
    assert obj['b']() == 2


# Generated at 2022-06-18 15:33:13.745028
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:33:18.710493
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p){
                return p;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:33:30.216830
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"


# Generated at 2022-06-18 15:33:39.788798
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = '''
        var a = {
            "b": function(p) {
                return p;
            }
        };
        var c = function(p) {
            return p;
        };
        var d = "abcdef";
        var e = [1, 2, 3];
        var f = [
            [4, 5, 6],
            [7, 8, 9]
        ];
        var g = [
            {"h": 10},
            {"i": 11},
            {"j": 12}
        ];
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.interpret_expression('a.b(1)', {}) == 1
    assert js_interpreter.interpret_expression('c(2)', {}) == 2
   

# Generated at 2022-06-18 15:33:45.714675
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:33:56.572908
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars) == (1, False)
    assert js_interpreter.interpret_statement('a + b', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('a + b + c', local_vars) == (6, False)
    assert js_interpreter.interpret_statement('a + b + c + 1', local_vars) == (7, False)
    assert js_interpreter.interpret_statement('a + b + c + 1 + 2', local_vars) == (9, False)
    assert js_interpreter.interpret_statement

# Generated at 2022-06-18 15:34:02.612157
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p - q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == -1


# Generated at 2022-06-18 15:34:43.917981
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function foo(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('foo', 1, 2) == 3


# Generated at 2022-06-18 15:34:50.335706
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    def test_func(argnames, code, args, expected):
        js_interpreter = JSInterpreter('')
        f = js_interpreter.build_function(argnames, code)
        assert f(args) == expected

    test_func(['a', 'b'], 'a + b', (1, 2), 3)
    test_func(['a', 'b'], 'a + b; a + b', (1, 2), 3)
    test_func(['a', 'b'], 'a + b; return a + b', (1, 2), 3)
    test_func(['a', 'b'], 'return a + b', (1, 2), 3)
    test_func(['a', 'b'], 'return a + b; a + b', (1, 2), 3)


# Generated at 2022-06-18 15:35:01.433305
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('')
    assert js.interpret_expression('1', {}) == 1
    assert js.interpret_expression('1+1', {}) == 2
    assert js.interpret_expression('1+1+1', {}) == 3
    assert js.interpret_expression('1+1+1+1', {}) == 4
    assert js.interpret_expression('1+1+1+1+1', {}) == 5
    assert js.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js.interpret_expression('1+1+1+1+1+1+1+1', {}) == 8

# Generated at 2022-06-18 15:35:08.432903
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(c) {
                return c;
            },
            d: function(e, f) {
                return e + f;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['d'](1, 2) == 3


# Generated at 2022-06-18 15:35:11.899466
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        function test(a, b) {
            return a + b;
        }
    ''')
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:35:18.686978
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        function test(a, b) {
            var c = a + b;
            return c;
        }
    """)
    f = js_interpreter.build_function(['a', 'b'], """
        var c = a + b;
        return c;
    """)
    assert f((1, 2)) == 3



# Generated at 2022-06-18 15:35:28.925306
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func((1, 2)) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func((1, 2)) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:35:36.111208
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:35:49.444234
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    def test_func(argnames, code, expected_result):
        f = js_interpreter.build_function(argnames, code)
        assert f(tuple()) == expected_result
    test_func(["a"], "a=1;", 1)
    test_func(["a"], "a=1;return a;", 1)
    test_func(["a"], "a=1;return a+1;", 2)
    test_func(["a"], "a=1;return a+1;return a;", 2)
    test_func(["a"], "a=1;return a+1;return a+2;", 3)

# Generated at 2022-06-18 15:35:54.775745
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret