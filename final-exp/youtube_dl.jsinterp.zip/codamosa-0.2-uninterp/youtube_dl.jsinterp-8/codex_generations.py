

# Generated at 2022-06-18 15:27:45.916092
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:27:57.318804
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func([1, 2]) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func([1, 2]) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func([1, 2]) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:28:02.119005
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function abc(a, b, c) {
            return a + b + c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('abc', 1, 2, 3) == 6


# Generated at 2022-06-18 15:28:13.899714
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + (2 * 3)', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * (3 + 4)', {}) == 21
    assert js_interpreter.interpret_expression('1 + 2 * 3 + 4', {}) == 11

# Generated at 2022-06-18 15:28:19.815266
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    interpreter = JSInterpreter(js_code)
    func = interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert func((1, 2)) == 3


# Generated at 2022-06-18 15:28:25.879995
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')

# Generated at 2022-06-18 15:28:31.447810
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:33.803090
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function func(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('func', 1, 2) == 3


# Generated at 2022-06-18 15:28:43.704949
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((1, 2)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((1, 2)) == 0.5
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:28:50.796042
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:29:12.932151
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test_func(a, b, c) {
            return a + b + c;
        }
    '''
    interpreter = JSInterpreter(js_code)
    assert interpreter.call_function('test_func', 1, 2, 3) == 6


# Generated at 2022-06-18 15:29:20.999956
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:29:30.875525
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    def resf(args):
        local_vars = dict(zip(argnames, args))
        for stmt in code.split(';'):
            res, abort = js_interpreter.interpret_statement(stmt, local_vars)
            if abort:
                break
        return res
    argnames = ["a", "b"]
    code = "var c = a + b; return c"
    assert js_interpreter.build_function(argnames, code)([1, 2]) == 3
    code = "var c = a + b; return c"
    assert js_interpreter.build_function(argnames, code)([2, 3]) == 5
    code = "var c = a + b; return c"
    assert js_interpre

# Generated at 2022-06-18 15:29:36.277813
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:29:50.569951
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; return a', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; return a; var b = 2', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; return a; var b = 2; return b', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; return a; var b = 2; return b; var c = 3', {}) == (1, True)

# Generated at 2022-06-18 15:30:02.240184
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:30:09.263584
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build

# Generated at 2022-06-18 15:30:14.180042
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('var a = 1; var b = 2; var c = a + b;')
    assert js_interpreter.interpret_statement('var a = 1;', {}) == (1, False)
    assert js_interpreter.interpret_statement('var b = 2;', {}) == (2, False)
    assert js_interpreter.interpret_statement('var c = a + b;', {}) == (3, False)
    assert js_interpreter.interpret_statement('return a + b;', {}) == (3, True)


# Generated at 2022-06-18 15:30:26.266055
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:30:36.695053
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a + 1', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1; a + 1; a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a + 1; a + 1', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1; a + 1; a + 1; a', {})[0] == 1
    assert js_interpreter.interpret_

# Generated at 2022-06-18 15:30:57.095837
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function abc(a, b) {
            return a + b;
        }
        function def(a, b) {
            return a - b;
        }
    '''
    interpreter = JSInterpreter(code)
    assert interpreter.extract_function('abc')((1, 2)) == 3
    assert interpreter.extract_function('def')((1, 2)) == -1


# Generated at 2022-06-18 15:31:04.747276
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:31:16.286588
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;return a*b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a*b')([1, 2]) == 3

# Generated at 2022-06-18 15:31:26.307896
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:31:39.255119
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:31:43.518776
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(b, c) {
                return b + c;
            },
            "b": function(c) {
                return c;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](4) == 4


# Generated at 2022-06-18 15:31:48.495446
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(arg1, arg2) {
                return arg1 + arg2;
            },
            "b": function(arg1, arg2) {
                return arg1 - arg2;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:31:57.519099
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p + 1;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1) == 2


# Generated at 2022-06-18 15:32:00.548863
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        var a = function(b, c) {
            var d = b + c;
            return d;
        }
    '''
    js_interpreter = JSInterpreter(code)
    func = js_interpreter.build_function(['b', 'c'], 'var d = b + c; return d;')
    assert func([1, 2]) == 3


# Generated at 2022-06-18 15:32:05.001041
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        function test(arg1, arg2) {
            var a = arg1;
            var b = arg2;
            var c = a + b;
            return c;
        }
    """)
    func = js_interpreter.build_function(['arg1', 'arg2'], """
        var a = arg1;
        var b = arg2;
        var c = a + b;
        return c;
    """)
    assert func([1, 2]) == 3


# Generated at 2022-06-18 15:32:27.820009
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a, b, c) {
            return a + b + c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2, 3) == 6


# Generated at 2022-06-18 15:32:38.615014
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a+b;return a-b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a+b;return a-b;')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a+b;return a-b;return a*b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function

# Generated at 2022-06-18 15:32:42.765043
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:32:53.270669
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((1, 2)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((1, 2)) == 0.5
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:32:58.133623
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:33:10.539452
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2+3', {}) == 6
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {}) == 21
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {'a': 2}) == 21

# Generated at 2022-06-18 15:33:16.547352
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p, q) {
                return p + q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:33:22.529202
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(c) {
                return c;
            },
            d: function(e) {
                return e;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('c') == 'c'
    assert obj['d']('e') == 'e'


# Generated at 2022-06-18 15:33:30.342351
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p1, p2){
                return p1 + p2;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('hello') == 'hello'
    assert obj['c']('hello', ' world') == 'hello world'


# Generated at 2022-06-18 15:33:36.811674
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    """
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:34:13.455511
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p, q) {
                return p + q;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:34:22.816717
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:34:27.917871
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('hello') == 'hello'
    assert obj['c']('world') == 'world'


# Generated at 2022-06-18 15:34:38.950509
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:34:47.332378
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((1, 2)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((1, 2)) == 0.5
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:34:58.233441
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:35:04.026012
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')

# Generated at 2022-06-18 15:35:13.614936
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
        function test(a, b, c) {
            var d = a + b;
            return d + c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    f = js_interpreter.build_function(['a', 'b', 'c'], 'var d = a + b; return d + c;')
    assert f((1, 2, 3)) == 6
    assert f((1, 2, '3')) == '33'
    assert f((1, '2', 3)) == '13'
    assert f(('1', 2, 3)) == '123'
    assert f(('1', '2', '3')) == '123'


# Generated at 2022-06-18 15:35:26.243875
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:35:36.910876
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:36:21.283258
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 + 3', {}) == 6
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + (2 * 3)', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * (3 + 4)', {}) == 21

# Generated at 2022-06-18 15:36:24.859671
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p + 1;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1) == 2


# Generated at 2022-06-18 15:36:27.828889
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3

# Generated at 2022-06-18 15:36:34.027193
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:36:42.002241
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;return a*b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a*b')([1, 2]) == 3

# Generated at 2022-06-18 15:36:52.001227
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret