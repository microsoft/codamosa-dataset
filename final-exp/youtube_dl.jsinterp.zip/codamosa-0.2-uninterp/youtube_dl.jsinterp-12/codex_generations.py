

# Generated at 2022-06-18 15:27:50.636628
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:01.460710
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function([], "")() is None
    assert js_interpreter.build_function(["a"], "a=1")() == 1
    assert js_interpreter.build_function(["a"], "a=1;return a")() == 1
    assert js_interpreter.build_function(["a"], "a=1;return a+1")() == 2
    assert js_interpreter.build_function(["a"], "a=1;return a+1;")() == 2
    assert js_interpreter.build_function(["a"], "a=1;return a+1;a=2")() == 2

# Generated at 2022-06-18 15:28:06.333798
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:19.428404
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')

# Generated at 2022-06-18 15:28:26.867281
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:39.857941
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('1+2*3+4*5', {}) == 26
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {}) == 21

# Generated at 2022-06-18 15:28:45.742153
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p1, p2) {
                return p1 + p2;
            }
        };
    '''
    js = JSInterpreter(code)
    obj = js.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:28:49.148814
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function abc(a, b, c) {
            return a + b + c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('abc', 1, 2, 3) == 6


# Generated at 2022-06-18 15:28:54.498398
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:29:02.931380
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:29:30.227438
# Unit test for method build_function of class JSInterpreter

# Generated at 2022-06-18 15:29:34.999357
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
        function foo(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    f = js_interpreter.extract_function('foo')
    assert f((1, 2)) == 3
    assert f((2, 3)) == 5


# Generated at 2022-06-18 15:29:43.963284
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:29:51.978181
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:30:03.455458
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func([1, 2]) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func([1, 2]) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func([1, 2]) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:30:06.559909
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:30:12.042137
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:30:21.388686
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:30:27.097971
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
    function test(a, b) {
        return a + b;
    }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:30:34.212487
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:30:54.201579
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})
    argnames = ['a', 'b']
    code = '''
        var c = a + b;
        return c;
    '''
    f = js_interpreter.build_function(argnames, code)
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:31:02.889561
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;return a - b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;return a - b;return a * b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;return a - b;return a * b;return a / b;')

# Generated at 2022-06-18 15:31:14.176019
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('var a = 1; var b = 2; var c = 3;')
    assert js_interpreter.build_function(['a', 'b'], 'a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a + b; c + b')([1, 2]) == 5
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return c + b')([1, 2]) == 5
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return c + b;')([1, 2]) == 5

# Generated at 2022-06-18 15:31:18.539724
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:31:25.024720
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(a, b) {
                return a + b;
            },
            "b": function(a, b) {
                return a - b;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:31:37.831156
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:31:46.943059
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:31:54.635683
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    f = js_interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:31:59.349217
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3


# Generated at 2022-06-18 15:32:05.380332
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){return p},
            c: function(p){return p+1}
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1) == 2


# Generated at 2022-06-18 15:32:34.628775
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:32:46.206634
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build

# Generated at 2022-06-18 15:32:56.010789
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func((1, 2)) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func((1, 2)) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:33:08.327290
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 + 3', {}) == 6
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + (2 * 3)', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * (3 + 4)', {}) == 21

# Generated at 2022-06-18 15:33:17.750023
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:33:29.130582
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:33:38.861724
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:33:45.152869
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p - q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == -1


# Generated at 2022-06-18 15:33:55.974728
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars) == (1, False)
    assert js_interpreter.interpret_statement('b', local_vars) == (2, False)
    assert js_interpreter.interpret_statement('c', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('a + b', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('a + b + c', local_vars) == (6, False)

# Generated at 2022-06-18 15:34:01.260744
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = {
            b: function(p){return p},
            c: function(p){return p+1}
        };
    """
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1) == 2


# Generated at 2022-06-18 15:34:46.203198
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.interpret_expression("1", {}) == 1
    assert js_interpreter.interpret_expression("1 + 1", {}) == 2
    assert js_interpreter.interpret_expression("1 + 1 + 1", {}) == 3
    assert js_interpreter.interpret_expression("1 + 1 + 1 + 1", {}) == 4
    assert js_interpreter.interpret_expression("1 + 1 + 1 + 1 + 1", {}) == 5
    assert js_interpreter.interpret_expression("1 + 1 + 1 + 1 + 1 + 1", {}) == 6
    assert js_interpreter.interpret_expression("1 + 1 + 1 + 1 + 1 + 1 + 1", {}) == 7
    assert js_interpreter.interpret_

# Generated at 2022-06-18 15:34:57.191093
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.interpret_statement("var a = 1", {}) == (1, False)
    assert js_interpreter.interpret_statement("var a = 1;", {}) == (1, False)
    assert js_interpreter.interpret_statement("var a = 1; var b = 2", {}) == (2, False)
    assert js_interpreter.interpret_statement("var a = 1; return a", {}) == (1, True)
    assert js_interpreter.interpret_statement("var a = 1; return a;", {}) == (1, True)
    assert js_interpreter.interpret_statement("return 1", {}) == (1, True)
    assert js_interpreter.interpret_statement("return 1;", {})

# Generated at 2022-06-18 15:35:01.542431
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p + 1;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    a = js_interpreter.extract_object('a')
    assert a['b'](1) == 1
    assert a['c'](1) == 2


# Generated at 2022-06-18 15:35:12.158543
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:35:24.052262
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:35:30.365123
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p - q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == -1


# Generated at 2022-06-18 15:35:43.013843
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.interpret_expression("1", {}) == 1
    assert js_interpreter.interpret_expression("1+1", {}) == 2
    assert js_interpreter.interpret_expression("1+1+1", {}) == 3
    assert js_interpreter.interpret_expression("1+1+1+1", {}) == 4
    assert js_interpreter.interpret_expression("1+1+1+1+1", {}) == 5
    assert js_interpreter.interpret_expression("1+1+1+1+1+1", {}) == 6
    assert js_interpreter.interpret_expression("1+1+1+1+1+1+1", {}) == 7
    assert js_interpreter.interpret_

# Generated at 2022-06-18 15:35:54.506319
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var obj1 = {
            "a": function(x) { return x + 1; },
            "b": function(x, y) { return x + y; }
        };
        var obj2 = {
            "a": function(x) { return x + 1; },
            "b": function(x, y) { return x + y; }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj1 = js_interpreter.extract_object('obj1')
    obj2 = js_interpreter.extract_object('obj2')
    assert obj1['a'](1) == 2
    assert obj1['b'](1, 2) == 3
    assert obj2['a'](1) == 2
    assert obj

# Generated at 2022-06-18 15:36:03.620897
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars) == (1, False)
    assert js_interpreter.interpret_statement('a + b', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('a + b * c', local_vars) == (7, False)
    assert js_interpreter.interpret_statement('a + b * c - 1', local_vars) == (6, False)
    assert js_interpreter.interpret_statement('return a + b * c - 1', local_vars) == (6, True)

# Generated at 2022-06-18 15:36:15.085688
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 1', {}) == 2
    assert js_interpreter.interpret_expression('1 + 1 + 1', {}) == 3
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1', {}) == 4
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1', {}) == 5
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1 + 1', {}) == 6
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1 + 1 + 1', {}) == 7
    assert js_interpreter.interpret