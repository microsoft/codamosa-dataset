

# Generated at 2022-06-18 15:27:36.091879
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:27:42.714939
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p,q) {
                return p + q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:27:54.752156
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:27:59.058734
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
    function a(a, b) {
        return a + b;
    }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('a', 1, 2) == 3


# Generated at 2022-06-18 15:28:02.062242
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function test_func(arg1, arg2) {
            var a = arg1 + arg2;
            return a;
        }
    '''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('test_func')
    assert f((1, 2)) == 3
    assert f((2, 3)) == 5


# Generated at 2022-06-18 15:28:13.841464
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:23.689171
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b, c) {
            var d = a + b;
            var e = c;
            e += d;
            return e;
        }
    '''
    js_interpreter = JSInterpreter(code)
    func = js_interpreter.build_function(['a', 'b', 'c'], 'var d=a+b;var e=c;e+=d;return e;')
    assert func((1, 2, 3)) == 6
    assert func((1, 2, '3')) == '33'
    assert func(('1', '2', '3')) == '123'
    assert func(('1', '2', 3)) == '123'
    assert func((1, '2', '3')) == '123'
    assert func

# Generated at 2022-06-18 15:28:30.043859
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('1+2*3+4*5', {}) == 26
    assert js_interpreter.interpret_expression('1+2*3+4*5+6', {}) == 32

# Generated at 2022-06-18 15:28:41.388799
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 + 3', {}) == 6
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + (2 * 3)', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * (3 + 4)', {}) == 21

# Generated at 2022-06-18 15:28:46.388416
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        function test(a, b) {
            var c = a + b;
            return c;
        }
    """)
    f = js_interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:29:07.539002
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3

# Generated at 2022-06-18 15:29:18.735046
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:29:29.189959
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((1, 2)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((1, 2)) == 0.5
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:29:35.428705
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p1, p2){
                return p1 + p2;
            }
        };
    '''
    jsi = JSInterpreter(code)
    obj = jsi.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test', 'test') == 'testtest'


# Generated at 2022-06-18 15:29:42.083577
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func((1, 2)) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func((1, 2)) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:29:50.670866
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(a, b) {
                return a + b;
            },
            "b": function(a, b) {
                return a - b;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:30:02.335809
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a*b')([1, 2]) == 3

# Generated at 2022-06-18 15:30:08.267522
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a + 1', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1; a + 1; a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a + 1; return a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a + 1; return a + 1', {})[0] == 2

# Generated at 2022-06-18 15:30:14.600650
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2+3', {}) == 6
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {}) == 21

# Generated at 2022-06-18 15:30:26.931336
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('a = 1', {'a': 2}) == (1, False)
    assert js_interpreter.interpret_statement('a = 1', {'a': 2}) == (1, False)
    assert js_interpreter.interpret_statement('a = b', {'a': 2, 'b': 3}) == (3, False)
    assert js_interpreter.interpret_statement('a = b', {'b': 3}) == (3, False)
    assert js_interpreter.interpret_statement('a = b', {'a': 2, 'b': 3}) == (3, False)
    assert js_

# Generated at 2022-06-18 15:30:54.985469
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:31:00.500957
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:31:11.872816
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:31:15.733897
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test_function(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test_function', 1, 2) == 3


# Generated at 2022-06-18 15:31:26.131367
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:31:39.254450
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:31:41.087307
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function abc(a,b,c) {
            return a+b+c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('abc', 1, 2, 3) == 6


# Generated at 2022-06-18 15:31:48.792736
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:31:59.494266
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b, c) {
            var d = a + b;
            var e = c;
            return d + e;
        }
    '''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.build_function(['a', 'b', 'c'], 'var d = a + b; var e = c; return d + e;')
    assert f((1, 2, 3)) == 6
    assert f((2, 3, 4)) == 9
    assert f((3, 4, 5)) == 12


# Generated at 2022-06-18 15:32:09.158879
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + 2 * 3 + 4', {}) == 11
    assert js_interpreter.interpret_expression('(1 + 2) * (3 + 4)', {}) == 21
    assert js_interpreter.interpret_expression('1 + 2 * (3 + 4)', {}) == 15

# Generated at 2022-06-18 15:33:08.648836
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a - b;')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'return a * b;')
    assert func((1, 2)) == 2
    func = js_interpreter.build_function(['a', 'b'], 'return a / b;')
    assert func((1, 2)) == 0.5

# Generated at 2022-06-18 15:33:14.787287
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p, q){
                return p + q;
            }
        };
    '''
    interp = JSInterpreter(code)
    obj = interp.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:33:21.591949
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1;', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2', {}) == (2, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2;', {}) == (2, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2; return 3', {}) == (3, True)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2; return 3;', {}) == (3, True)

# Generated at 2022-06-18 15:33:33.414811
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p, q) {
                return p + q;
            }
        };
        var d = {
            e: function(p) {
                return p;
            },
            f: function(p, q) {
                return p + q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3
    obj = js_interpreter.extract_object('d')
    assert obj['e'](1) == 1

# Generated at 2022-06-18 15:33:41.452640
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test for function build_function
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func([1, 2]) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func([1, 2]) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func([1, 2]) == 0.5

# Generated at 2022-06-18 15:33:52.309583
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a + b')

# Generated at 2022-06-18 15:33:59.203531
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:34:05.839117
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a-b')([1, 2]) == -1
    assert js_interpreter.build_function(['a', 'b'], 'a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a/b')([1, 2]) == 0.5
    assert js_interpreter.build_function(['a', 'b'], 'a%b')([1, 2]) == 1

# Generated at 2022-06-18 15:34:11.658934
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('''
        function test(a, b, c) {
            var d = a + b;
            return d + c;
        }
    ''')
    f = js.build_function(['a', 'b', 'c'], 'var d = a + b; return d + c;')
    assert f((1, 2, 3)) == 6
    assert f((1, 2, 'c')) == '1c2c'


# Generated at 2022-06-18 15:34:16.443847
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function a(b, c) {
            return b + c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('a', 1, 2) == 3


# Generated at 2022-06-18 15:34:55.216419
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1 + 2', {})[0] == 3
    assert js_interpreter.interpret_statement('var a = 1 + 2; a', {})[0] == 3
    assert js_interpreter.interpret_statement('var a = 1 + 2; a + 3', {})[0] == 6
    assert js_interpreter.interpret_statement('var a = 1 + 2; a + 3; a', {})[0] == 3
    assert js_interpreter.interpret_statement('var a = 1 + 2; return a + 3', {})[0] == 6

# Generated at 2022-06-18 15:35:06.129005
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
        var d = {
            e: function(p) {
                return p;
            }
        };
        var f = function(p) {
            return p;
        };
        var g = {
            h: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'
    obj = js_interpreter.extract_object('d')

# Generated at 2022-06-18 15:35:14.816956
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a+b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build

# Generated at 2022-06-18 15:35:27.111377
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:35:38.311097
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')

# Generated at 2022-06-18 15:35:45.345910
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    jsi = JSInterpreter(code)
    obj = jsi.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:35:52.200579
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            a: function() {
                return 1;
            },
            b: function(a, b) {
                return a + b;
            }
        };
    '''
    obj = JSInterpreter(code).extract_object('obj')
    assert obj['a']() == 1
    assert obj['b'](2, 3) == 5


# Generated at 2022-06-18 15:35:59.274387
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2+3', {}) == 6
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {}) == 21

# Generated at 2022-06-18 15:36:06.380827
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'return a+b;')
    assert f((1,2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a+b;return a-b;')
    assert f((1,2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a+b;return a-b;return a*b;')
    assert f((1,2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a+b;return a-b;return a*b;return a/b;')

# Generated at 2022-06-18 15:36:12.055879
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:36:51.814563
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')