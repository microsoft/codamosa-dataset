

# Generated at 2022-06-18 15:28:06.919197
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:20.105225
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:22.247522
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function func(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('func', 1, 2) == 3


# Generated at 2022-06-18 15:28:28.332574
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:28:40.285398
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func((1, 2)) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func((1, 2)) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:28:49.121314
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2', {}) == (2, False)
    assert js_interpreter.interpret_statement('var a = 1; return a', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; return a; var b = 2', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; return a; var b = 2; return b', {}) == (1, True)

# Generated at 2022-06-18 15:28:54.478305
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((1, 2)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((1, 2)) == 0.5
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:29:02.931716
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:29:14.763059
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b', 'c'], 'a + b + c')
    assert func([1, 2, 3]) == 6
    func = js_interpreter.build_function(['a', 'b', 'c'], 'a + b + c; return a + b + c')
    assert func([1, 2, 3]) == 6
    func = js_interpreter.build_function(['a', 'b', 'c'], 'a + b + c; return a + b + c; return a + b + c')
    assert func([1, 2, 3]) == 6

# Generated at 2022-06-18 15:29:22.202921
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func((1, 2)) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func((1, 2)) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:29:41.773327
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:29:55.165828
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;return a*b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a*b')([1, 2]) == 3

# Generated at 2022-06-18 15:30:01.251089
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    jsi = JSInterpreter(code)
    obj = jsi.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:30:08.678609
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b;')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b;')([1, 2]) == 2

# Generated at 2022-06-18 15:30:15.206339
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:30:27.782600
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:30:37.525408
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a+b;a+b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a+b;return a+b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b;')
    assert func((1, 2)) == 3

# Generated at 2022-06-18 15:30:45.758859
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:30:56.969981
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2+3', {}) == 6
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {}) == 21

# Generated at 2022-06-18 15:31:02.264120
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:32:03.051050
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:32:09.095819
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            a: function(x, y) {
                return x + y;
            },
            b: function(x, y) {
                return x - y;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:32:20.611156
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p){
                return p;
            }
        };
        var d = {
            e: function(p){
                return p;
            },
            f: function(p){
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'
    obj = js_interpreter.extract_object('d')
    assert obj['e']('test') == 'test'
    assert obj['f']('test') == 'test'

#

# Generated at 2022-06-18 15:32:31.526502
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-18 15:32:42.849103
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-18 15:32:48.659263
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function func1(a, b) {
            return a + b;
        }
        function func2(a, b) {
            return func1(a, b);
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('func2', 1, 2) == 3


# Generated at 2022-06-18 15:32:57.669370
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:33:10.120876
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js = JSInterpreter(code)
    f = js.extract_function('test')
    assert f((1, 2)) == 3

    code = '''
        var test = function(a, b) {
            return a + b;
        }
    '''
    js = JSInterpreter(code)
    f = js.extract_function('test')
    assert f((1, 2)) == 3

    code = '''
        var test = function(a, b) {
            return a + b;
        };
    '''
    js = JSInterpreter(code)
    f = js.extract_function('test')
    assert f((1, 2)) == 3



# Generated at 2022-06-18 15:33:14.143212
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter(
        '''
        function test_function(a, b) {
            return a + b;
        }
        '''
    )
    assert js_interpreter.call_function('test_function', 1, 2) == 3


# Generated at 2022-06-18 15:33:21.259517
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b;var c=a+b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b;var c=a+b;return c;')
    assert func([1, 2]) == 3

# Generated at 2022-06-18 15:33:55.888870
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        function test(arg1, arg2) {
            var a = arg1;
            var b = arg2;
            var c = a + b;
            return c;
        }
    """)
    f = js_interpreter.build_function(['arg1', 'arg2'], """
        var a = arg1;
        var b = arg2;
        var c = a + b;
        return c;
    """)
    assert f((1, 2)) == 3

# Generated at 2022-06-18 15:34:04.278560
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    # Test 1
    js_code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    f = js_interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3

    # Test 2
    js_code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    f = js_interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')


# Generated at 2022-06-18 15:34:13.526317
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b;')
    assert f((1, 2)) == 3
    assert f((3, 4)) == 7
    f = js_interpreter.build_function(['a', 'b'], 'return a+b;')
    assert f((1, 2)) == 3
    assert f((3, 4)) == 7
    f = js_interpreter.build_function(['a', 'b'], 'return a+b; a+b;')
    assert f((1, 2)) == 3
    assert f((3, 4)) == 7

# Generated at 2022-06-18 15:34:22.848806
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2+3', {}) == 6
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('(1+2)*3+4', {}) == 13
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {}) == 21

# Generated at 2022-06-18 15:34:26.927500
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    """
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:34:29.670619
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:34:40.585599
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-18 15:34:51.060917
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1 + 2', {})[0] == 3
    assert js_interpreter.interpret_statement('var a = 1 + 2 + 3', {})[0] == 6
    assert js_interpreter.interpret_statement('var a = 1 + 2 * 3', {})[0] == 7
    assert js_interpreter.interpret_statement('var a = 1 + 2 * 3 + 4', {})[0] == 11
    assert js_interpreter.interpret_statement('var a = 1 + 2 * 3 + 4 * 5', {})[0] == 26

# Generated at 2022-06-18 15:35:02.244567
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')

# Generated at 2022-06-18 15:35:09.489055
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p * q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](2, 3) == 5
    assert obj['c'](2, 3) == 6


# Generated at 2022-06-18 15:35:37.270358
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = JSInterpreter('''
        function test(a, b) {
            return a + b;
        }
    ''')
    assert js.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:35:50.339172
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2', {}) == (2, False)
    assert js_interpreter.interpret_statement('return 1', {}) == (1, True)
    assert js_interpreter.interpret_statement('return 1; var b = 2', {}) == (1, True)
    assert js_interpreter.interpret_statement('return 1; return 2', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; return a', {}) == (1, True)

# Generated at 2022-06-18 15:35:55.670653
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b; return a-b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b; a-b')
    assert func([1, 2]) == 3

# Generated at 2022-06-18 15:36:04.656086
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func([1, 2]) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func([1, 2]) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func([1, 2]) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:36:12.979394
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function func(a, b, c) {
            var d = a + b;
            var e = d + c;
            return e;
        }
    '''
    interpreter = JSInterpreter(code)
    func = interpreter.build_function(['a', 'b', 'c'], 'var d = a + b; var e = d + c; return e;')
    assert func((1, 2, 3)) == 6
    assert func((2, 3, 4)) == 9
    assert func((3, 4, 5)) == 12


# Generated at 2022-06-18 15:36:22.017441
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((1, 2)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((1, 2)) == 0.5
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:36:31.503248
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1 + 2', {})[0] == 3
    assert js_interpreter.interpret_statement('var a = 1 + 2 + 3', {})[0] == 6
    assert js_interpreter.interpret_statement('var a = 1 + 2 * 3', {})[0] == 7
    assert js_interpreter.interpret_statement('var a = (1 + 2) * 3', {})[0] == 9
    assert js_interpreter.interpret_statement('var a = 1 + (2 * 3)', {})[0] == 7

# Generated at 2022-06-18 15:36:38.160571
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        function test(a, b, c) {
            var d = a + b;
            var e = c;
            return d + e;
        }
    """)
    func = js_interpreter.build_function(['a', 'b', 'c'], """
        var d = a + b;
        var e = c;
        return d + e;
    """)
    assert func([1, 2, 3]) == 6


# Generated at 2022-06-18 15:36:44.024188
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    """
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b']('hello') == 'hello'
    assert obj['c']('world') == 'world'


# Generated at 2022-06-18 15:36:50.293867
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p){
                return p;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'
