

# Generated at 2022-06-18 15:27:55.026623
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars) == (1, False)
    assert js_interpreter.interpret_statement('a + b', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('a + b * c', local_vars) == (7, False)
    assert js_interpreter.interpret_statement('a + b * c - 1', local_vars) == (6, False)
    assert js_interpreter.interpret_statement('a + b * c - 1 == 6', local_vars) == (True, False)
    assert js_interpreter.interpret_statement

# Generated at 2022-06-18 15:28:04.925774
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:28:17.680641
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('var a = "hello";')
    assert js_interpreter.interpret_expression('a', {}) == 'hello'

    js_interpreter = JSInterpreter('var a = "hello";')
    assert js_interpreter.interpret_expression('a[1]', {}) == 'e'

    js_interpreter = JSInterpreter('var a = "hello";')
    assert js_interpreter.interpret_expression('a.length', {}) == 5

    js_interpreter = JSInterpreter('var a = "hello";')
    assert js_interpreter.interpret_expression('a.split("")', {}) == ['h', 'e', 'l', 'l', 'o']


# Generated at 2022-06-18 15:28:21.685501
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:28:28.194891
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
        function func1(arg1, arg2) {
            var a = arg1 + arg2;
            return a;
        }
        var func2 = function(arg1, arg2) {
            var a = arg1 + arg2;
            return a;
        }
        var func3 = function func3(arg1, arg2) {
            var a = arg1 + arg2;
            return a;
        }
        var func4 = {
            func4: function(arg1, arg2) {
                var a = arg1 + arg2;
                return a;
            }
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    func1 = js_interpreter.extract_function('func1')

# Generated at 2022-06-18 15:28:40.202237
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:28:49.064217
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; return a', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; return a; var b = 2', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; return a; var b = 2; return b', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2; return b', {}) == (2, True)

# Generated at 2022-06-18 15:28:54.433284
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('var a = "abc"; var b = "def";')
    assert js_interpreter.interpret_expression('a', {}) == 'abc'
    assert js_interpreter.interpret_expression('b', {}) == 'def'
    assert js_interpreter.interpret_expression('a+b', {}) == 'abcdef'
    assert js_interpreter.interpret_expression('a.length', {}) == 3
    assert js_interpreter.interpret_expression('a.split("")', {}) == ['a', 'b', 'c']
    assert js_interpreter.interpret_expression('a.split("").reverse()', {}) == ['c', 'b', 'a']

# Generated at 2022-06-18 15:29:01.874743
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; a', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; a + 1', {}) == (2, False)
    assert js_interpreter.interpret_statement('var a = 1; a + 1; a', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; return a', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; return a; a', {}) == (1, True)

# Generated at 2022-06-18 15:29:12.804715
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js = JSInterpreter('''
        function foo(a, b) {
            return a + b;
        }
        function bar(a, b) {
            return a * b;
        }
        function baz(a, b) {
            return a / b;
        }
        function qux(a, b) {
            return a - b;
        }
    ''')
    assert js.call_function('foo', 1, 2) == 3
    assert js.call_function('bar', 2, 3) == 6
    assert js.call_function('baz', 6, 3) == 2
    assert js.call_function('qux', 6, 3) == 3


# Generated at 2022-06-18 15:29:43.379133
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:29:56.653046
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; var b = a; b', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; var b = a; b + 1', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1; var b = a; b + 1; b', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; var b = a; b + 1; return b', {})[0] == 1

# Generated at 2022-06-18 15:30:02.982583
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:30:06.680931
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        }
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:30:08.843793
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function a(b, c) {
            return b + c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('a', 1, 2) == 3


# Generated at 2022-06-18 15:30:15.439090
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1;', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2', {}) == (2, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2;', {}) == (2, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2; return a', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2; return a;', {}) == (1, True)

# Generated at 2022-06-18 15:30:22.443668
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:30:28.469450
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
    function test_function(a, b) {
        return a + b;
    }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test_function', 1, 2) == 3


# Generated at 2022-06-18 15:30:35.193443
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:30:40.296596
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:31:20.951025
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:31:28.750435
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + 2 * 3 + 4', {}) == 11
    assert js_interpreter.interpret_expression('(1 + 2) * (3 + 4)', {}) == 21
    assert js_interpreter.interpret_expression('(1 + 2) * (3 + 4) + 5', {}) == 26
    assert js_interpreter.interpret_expression

# Generated at 2022-06-18 15:31:36.908794
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(c) {
                return c;
            },
            d: function(e) {
                return e;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['d'](2) == 2


# Generated at 2022-06-18 15:31:43.080018
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func([1, 2], {'c': 3}) == 6
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func([1, 2], {'c': 3, 'd': 4}) == 6
    func = js_

# Generated at 2022-06-18 15:31:55.001196
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return a - b')([1, 2]) == -1
    assert js_interpreter.build_function(['a', 'b'], 'var c = a + b; return c')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'var c = a + b; c += 1; return c')([1, 2]) == 4

# Generated at 2022-06-18 15:32:06.560762
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a; a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a + 1', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1; a + 1; a + 2', {})[0] == 3
    assert js_interpreter.interpret_statement('var a = 1; a + 1; a + 2; a + 3', {})[0] == 4
    assert js_interpreter.interpret_

# Generated at 2022-06-18 15:32:17.970409
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a-b')([1, 2]) == -1
    assert js_interpreter.build_function(['a', 'b'], 'a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a/b')([1, 2]) == 0.5
    assert js_interpreter.build_function(['a', 'b'], 'a%b')([1, 2]) == 1

# Generated at 2022-06-18 15:32:22.870598
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            a: function() { return 1; },
            b: function() { return 2; },
            c: function() { return 3; }
        };
    '''
    obj = JSInterpreter(code).extract_object('obj')
    assert obj['a']() == 1
    assert obj['b']() == 2
    assert obj['c']() == 3


# Generated at 2022-06-18 15:32:34.628856
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars) == (1, False)
    assert js_interpreter.interpret_statement('a + b', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('a + b + c', local_vars) == (6, False)
    assert js_interpreter.interpret_statement('return a + b + c', local_vars) == (6, True)
    assert js_interpreter.interpret_statement('return a + b', local_vars) == (3, True)

# Generated at 2022-06-18 15:32:37.145274
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js = JSInterpreter(code)
    obj = js.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:34:27.602848
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p * q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](2, 3) == 6


# Generated at 2022-06-18 15:34:38.478540
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;return a - b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;return a - b;return a * b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;return a - b;return a * b;return a / b;')

# Generated at 2022-06-18 15:34:47.001490
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-18 15:34:50.597036
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test_func(a, b) {
            return a + b;
        }
    '''
    interpreter = JSInterpreter(js_code)
    assert interpreter.call_function('test_func', 1, 2) == 3


# Generated at 2022-06-18 15:34:54.631634
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(["a", "b"], "return a + b;")(["1", "2"]) == "12"

# Generated at 2022-06-18 15:35:05.528283
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3

# Generated at 2022-06-18 15:35:14.426559
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:35:26.967176
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:35:38.034828
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:35:51.053754
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b;')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function