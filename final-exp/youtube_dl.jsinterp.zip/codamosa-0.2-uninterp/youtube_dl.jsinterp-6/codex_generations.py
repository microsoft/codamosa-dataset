

# Generated at 2022-06-18 15:27:44.666689
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;a-b')([1, 2]) == -1
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a-b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;return a-b')([1, 2]) == 3
    assert js_interpreter

# Generated at 2022-06-18 15:27:56.075443
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;a-b')([1, 2]) == -1
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a-b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;return a-b')([1, 2]) == 3
    assert js_interpreter

# Generated at 2022-06-18 15:28:05.783113
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
        function func1(a, b) {
            return a + b;
        }
        var func2 = function(a, b) {
            return a + b;
        }
        var func3 = function func3(a, b) {
            return a + b;
        }
        var func4 = {
            "func4": function(a, b) {
                return a + b;
            }
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('func1', 1, 2) == 3
    assert js_interpreter.call_function('func2', 1, 2) == 3
    assert js_interpreter.call_function('func3', 1, 2) == 3

# Generated at 2022-06-18 15:28:18.777079
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:26.475156
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a * b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a * b; return a - b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a * b; return a - b; return a / b;')

# Generated at 2022-06-18 15:28:39.810983
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars)[0] == 1
    assert js_interpreter.interpret_statement('a + b', local_vars)[0] == 3
    assert js_interpreter.interpret_statement('a + b - c', local_vars)[0] == 0
    assert js_interpreter.interpret_statement('a + b - c * 2', local_vars)[0] == -3
    assert js_interpreter.interpret_statement('a + b - c * 2 / 2', local_vars)[0] == -1.5

# Generated at 2022-06-18 15:28:44.033089
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3



# Generated at 2022-06-18 15:28:56.303067
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; a', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; return a', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2; a + b', {}) == (3, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2; return a + b', {}) == (3, True)

# Generated at 2022-06-18 15:29:06.459383
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function func1(arg1, arg2) {
            return arg1 + arg2;
        }
        var func2 = function(arg1, arg2) {
            return arg1 - arg2;
        }
        var func3 = function func3(arg1, arg2) {
            return arg1 * arg2;
        }
        var func4 = {
            a: function(arg1, arg2) {
                return arg1 / arg2;
            }
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.extract_function('func1')((1, 2)) == 3
    assert js_interpreter.extract_function('func2')((1, 2)) == -1
    assert js_interpreter

# Generated at 2022-06-18 15:29:17.846018
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + 2 * 3 + 4', {}) == 11
    assert js_interpreter.interpret_expression('1 + 2 * 3 + 4 * 5', {}) == 26
    assert js_interpreter.interpret_expression('1 + 2 * 3 + 4 * 5 + 6', {}) == 32

# Generated at 2022-06-18 15:29:52.087844
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-18 15:30:03.497781
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 1', {}) == 2
    assert js_interpreter.interpret_expression('1 + 1 + 1', {}) == 3
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1', {}) == 4
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1', {}) == 5
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1 + 1', {}) == 6
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1 + 1 + 1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:30:08.563777
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a+b;return a-b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a+b;return a-b;a*b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a+b;return a-b;a*b;return a+b')
    assert func((1, 2)) == 3


# Generated at 2022-06-18 15:30:11.056447
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        function test(a, b) {
            return a + b;
        }
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:30:19.772501
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:30:32.855109
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('(1+2)*3+4', {}) == 13
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {}) == 21
    assert js_interpreter.interpret_expression('(1+2)*(3+4)+5', {}) == 26

# Generated at 2022-06-18 15:30:40.006850
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:30:51.989978
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function([], "")() == None
    assert js_interpreter.build_function(["a"], "a")(1) == 1
    assert js_interpreter.build_function(["a"], "a = 1")(1) == 1
    assert js_interpreter.build_function(["a"], "a = 1; return a")(1) == 1
    assert js_interpreter.build_function(["a"], "a = 1; return a + 1")(1) == 2
    assert js_interpreter.build_function(["a"], "a = 1; return a + 1;")(1) == 2

# Generated at 2022-06-18 15:31:00.121800
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function func1(a, b) {
            return a + b;
        }
        function func2(a, b) {
            return a - b;
        }
        function func3(a, b) {
            return func1(a, b) + func2(a, b);
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('func1', 1, 2) == 3
    assert js_interpreter.call_function('func2', 1, 2) == -1
    assert js_interpreter.call_function('func3', 1, 2) == 2


# Generated at 2022-06-18 15:31:11.405771
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"


# Generated at 2022-06-18 15:32:37.986740
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        function test(a, b) {
            return a + b;
        }
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:32:40.767583
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p - q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == -1


# Generated at 2022-06-18 15:32:46.304885
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter(
        '''
        function test_func(arg1, arg2) {
            return arg1 + arg2;
        }
        ''')
    assert js_interpreter.call_function('test_func', 1, 2) == 3


# Generated at 2022-06-18 15:32:52.422724
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:32:59.931855
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:33:08.510340
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:33:17.875336
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([3, 4]) == 7
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([5, 6]) == 11
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([7, 8]) == 15
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([9, 10]) == 19

# Generated at 2022-06-18 15:33:29.309582
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:33:35.837197
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:33:44.513735
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:34:45.643503
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p, q) {
                return p + q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:34:56.788121
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a + b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; a - b')
    assert func([1, 2]) == 3

# Generated at 2022-06-18 15:35:00.760945
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3
    assert f((3, 4)) == 7


# Generated at 2022-06-18 15:35:07.377637
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:35:15.521156
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:35:25.990093
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
        var d = {
            e: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'
    obj = js_interpreter.extract_object('d')
    assert obj['e']('test') == 'test'


# Generated at 2022-06-18 15:35:32.099829
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(x, y) {
                return x + y;
            },
            "b": function(x, y) {
                return x - y;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:35:35.735209
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var A = {
            b: function(c) {
                return c;
            },
            d: function(e) {
                return e;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('A')
    assert obj['b']('c') == 'c'
    assert obj['d']('e') == 'e'


# Generated at 2022-06-18 15:35:49.349956
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = '''
        var a = 5;
        var b = {'c': 3};
        var d = function(x) {
            return x * x;
        };
        var e = [1, 2, 3];
        var f = 'abc';
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.interpret_expression('a', {}) == 5
    assert js_interpreter.interpret_expression('b.c', {}) == 3
    assert js_interpreter.interpret_expression('d(4)', {}) == 16
    assert js_interpreter.interpret_expression('e[1]', {}) == 2
    assert js_interpreter.interpret_expression('f.length', {}) == 3
    assert js_interpreter

# Generated at 2022-06-18 15:35:54.447760
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a+b;a-b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'return a+b;a-b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b;return a-b')
    assert func((1, 2)) == 3
