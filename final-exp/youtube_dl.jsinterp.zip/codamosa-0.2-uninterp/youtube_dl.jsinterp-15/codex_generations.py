

# Generated at 2022-06-18 15:27:50.929734
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('')
    assert js.interpret_expression('1', {}) == 1
    assert js.interpret_expression('1 + 1', {}) == 2
    assert js.interpret_expression('1 + 1 + 1', {}) == 3
    assert js.interpret_expression('1 + 1 + 1 + 1', {}) == 4
    assert js.interpret_expression('1 + 1 + 1 + 1 + 1', {}) == 5
    assert js.interpret_expression('1 + 1 + 1 + 1 + 1 + 1', {}) == 6
    assert js.interpret_expression('1 + 1 + 1 + 1 + 1 + 1 + 1', {}) == 7
    assert js.interpret_expression('1 + 1 + 1 + 1 + 1 + 1 + 1 + 1', {}) == 8

# Generated at 2022-06-18 15:27:57.559286
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:28:07.040952
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3

# Generated at 2022-06-18 15:28:20.259712
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b")(["1", "2"]) == "12"


# Generated at 2022-06-18 15:28:26.489490
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a-b')([1, 2]) == -1
    assert js_interpreter.build_function(['a', 'b'], 'a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a/b')([1, 2]) == 0.5
    assert js_interpreter.build_function(['a', 'b'], 'a%b')([1, 2]) == 1

# Generated at 2022-06-18 15:28:39.857519
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a*b;')([1, 2]) == 2
    assert js_interpreter.build_

# Generated at 2022-06-18 15:28:48.749728
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:54.052109
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:29:01.599450
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-18 15:29:13.547932
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {}) == 21
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {'a': 1}) == 21

# Generated at 2022-06-18 15:29:47.329899
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = {
            b: function(p){
                return p;
            },
            c: function(p, q){
                return p + q;
            }
        };
    """
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:29:52.352418
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:30:00.282840
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p - q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == -1


# Generated at 2022-06-18 15:30:05.782977
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var obj = {
            "a": function(b) {
                return b;
            },
            "b": function(c) {
                return c;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object("obj")
    assert obj["a"]("a") == "a"
    assert obj["b"]("b") == "b"


# Generated at 2022-06-18 15:30:11.238409
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:30:20.110474
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:30:33.175896
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a'], 'return a + 1;')
    assert func((1,)) == 2
    func = js_interpreter.build_function(['a'], 'return a + 1; return a + 2;')
    assert func((1,)) == 2
    func = js_interpreter.build_function(['a'], 'return a + 1; return a + 2; return a + 3;')
    assert func((1,)) == 2

# Generated at 2022-06-18 15:30:37.621990
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2+3', {}) == 6
    assert js_interpreter.interpret_expression('1+2-3', {}) == 0
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('1*2+3', {}) == 5
    assert js_interpreter.interpret_expression('1*2*3', {}) == 6
    assert js_interpreter.interpret_expression('1*2/3', {}) == 2/3
    assert js_

# Generated at 2022-06-18 15:30:40.985777
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b, c) {
            var d = a + b;
            var e = d * c;
            return e;
        }
    '''
    interpreter = JSInterpreter(code)
    f = interpreter.build_function(['a', 'b', 'c'], 'var d = a + b; var e = d * c; return e;')
    assert f((1, 2, 3)) == 9


# Generated at 2022-06-18 15:30:45.806669
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    interpreter = JSInterpreter(code)
    f = interpreter.extract_function('test')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:32:01.647874
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p
            },
            c: function(p,q){
                return p+q
            }
        }
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1,2) == 3


# Generated at 2022-06-18 15:32:10.264628
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars) == (1, False)
    assert js_interpreter.interpret_statement('a + b', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('a + b + c', local_vars) == (6, False)
    assert js_interpreter.interpret_statement('a + b + c + d', local_vars) == (6, False)
    assert js_interpreter.interpret_statement('return a + b + c + d', local_vars) == (6, True)

# Generated at 2022-06-18 15:32:18.485945
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(x, y) {
                return x + y;
            },
            "b": function(x, y) {
                return x - y;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:32:25.911192
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:32:36.813787
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7

# Generated at 2022-06-18 15:32:48.374490
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:32:57.479433
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1 + 2', {})[0] == 3
    assert js_interpreter.interpret_statement('var a = 1 + 2 + 3', {})[0] == 6
    assert js_interpreter.interpret_statement('var a = 1 + 2 * 3', {})[0] == 7
    assert js_interpreter.interpret_statement('var a = (1 + 2) * 3', {})[0] == 9
    assert js_interpreter.interpret_statement('var a = 1 + (2 * 3)', {})[0] == 7

# Generated at 2022-06-18 15:33:02.597626
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:33:09.405545
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){return p},
            c: function(p){return p+1}
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1) == 2


# Generated at 2022-06-18 15:33:18.476754
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:33:55.151044
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function func(a, b) {
            var c = a + b;
            return c;
        }
    '''
    js_interpreter = JSInterpreter(code)
    func = js_interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert func((1, 2)) == 3


# Generated at 2022-06-18 15:34:03.813084
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:34:13.185814
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')
    assert f((1, 2))

# Generated at 2022-06-18 15:34:17.310705
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function f(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('f', 1, 2) == 3


# Generated at 2022-06-18 15:34:22.464029
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            a: function(x) {
                return x + 1;
            },
            b: function(x, y) {
                return x + y;
            }
        };
    '''
    js = JSInterpreter(code)
    obj = js.extract_object('obj')
    assert obj['a'](1) == 2
    assert obj['b'](1, 2) == 3


# Generated at 2022-06-18 15:34:25.708512
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("function test(a, b) { return a + b; }")
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    assert f((2, 3)) == 5
    assert f((3, 4)) == 7


# Generated at 2022-06-18 15:34:32.014190
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert js_interpreter.interpret_statement('a', local_vars) == (1, False)
    assert js_interpreter.interpret_statement('return a', local_vars) == (1, True)
    assert js_interpreter.interpret_statement('return a; b', local_vars) == (1, True)
    assert js_interpreter.interpret_statement('return a; b; c', local_vars) == (1, True)
    assert js_interpreter.interpret_statement('return a; b; c; d', local_vars) == (1, True)
    assert js_interpreter.interpret_

# Generated at 2022-06-18 15:34:42.562515
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func([1, 2]) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func([1, 2]) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func([1, 2]) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:34:54.206702
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('')
    assert js.interpret_expression('1', {}) == 1
    assert js.interpret_expression('1+1', {}) == 2
    assert js.interpret_expression('1+1+1', {}) == 3
    assert js.interpret_expression('1+1+1+1', {}) == 4
    assert js.interpret_expression('1+1+1+1+1', {}) == 5
    assert js.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js.interpret_expression('1+1+1+1+1+1+1+1', {}) == 8

# Generated at 2022-06-18 15:35:04.713175
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a + 1', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1; a + 1; a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a + 1; a + 1', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1; a + 1; a + 1; a', {})[0] == 1
    assert js_interpreter.interpret_

# Generated at 2022-06-18 15:36:01.874846
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function abc(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('abc', 1, 2) == 3


# Generated at 2022-06-18 15:36:05.182230
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        function test(a, b) {
            return a + b;
        }
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:36:16.781948
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:36:21.503751
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('1') == '1'
    assert obj['c']('2') == '2'


# Generated at 2022-06-18 15:36:26.818603
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(x) { return x + 1; },
            "b": function(x) { return x + 2; }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('obj')
    assert obj['a'](1) == 2
    assert obj['b'](1) == 3


# Generated at 2022-06-18 15:36:32.793773
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('hello') == 'hello'
    assert obj['c']('world') == 'world'


# Generated at 2022-06-18 15:36:38.472101
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p + 1;
            }
        };
    '''
    obj = JSInterpreter(code).extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1) == 2


# Generated at 2022-06-18 15:36:49.632704
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1.1', {}) == 1.1
    assert js_interpreter.interpret_expression('"1"', {}) == '1'
    assert js_interpreter.interpret_expression('true', {}) == True
    assert js_interpreter.interpret_expression('false', {}) == False
    assert js_interpreter.interpret_expression('null', {}) == None
    assert js_interpreter.interpret_expression('[1,2,3]', {}) == [1,2,3]
    assert js_interpreter.interpret_expression('{"a":1}', {}) == {'a':1}
    assert js

# Generated at 2022-06-18 15:36:58.401864
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
        var d = {
            e: function(p) {
                return p;
            },
            f: function(p) {
                return p;
            }
        };
    '''
    jsi = JSInterpreter(code)
    obj = jsi.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'
    obj = jsi.extract_object('d')
    assert obj['e']('test') == 'test'
    assert obj['f']('test') == 'test'
