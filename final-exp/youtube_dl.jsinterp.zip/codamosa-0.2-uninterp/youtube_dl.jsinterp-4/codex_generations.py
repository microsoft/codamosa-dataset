

# Generated at 2022-06-18 15:27:55.619444
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-18 15:28:05.380430
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-18 15:28:08.491172
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
        function test(a, b) {
            var c = a + b;
            var d = c * c;
            return d;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    func = js_interpreter.build_function(['a', 'b'], 'var c = a + b; var d = c * c; return d;')
    assert func((1, 2)) == 9


# Generated at 2022-06-18 15:28:14.448467
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function test(a, b) {
            return a + b;
        }
        '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:28:21.002038
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p * q;
            }
        };
    '''
    js = JSInterpreter(code)
    obj = js.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == 2


# Generated at 2022-06-18 15:28:27.350282
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('(1+2)*3+4', {}) == 13
    assert js_interpreter.interpret_expression('1+2*(3+4)', {}) == 15

# Generated at 2022-06-18 15:28:40.030949
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 1', {}) == 2
    assert js_interpreter.interpret_expression('1 + 1 + 1', {}) == 3
    assert js_interpreter.interpret_expression('1 + 1 * 2', {}) == 3
    assert js_interpreter.interpret_expression('(1 + 1) * 2', {}) == 4
    assert js_interpreter.interpret_expression('(1 + 1) * (2 + 3)', {}) == 10
    assert js_interpreter.interpret_expression('1 + 1 * 2 + 3', {}) == 6

# Generated at 2022-06-18 15:28:48.909534
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:54.256708
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7

# Generated at 2022-06-18 15:28:58.525813
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    js = JSInterpreter(code)
    f = js.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:29:22.718592
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8, 'i': 9, 'j': 10, 'k': 11, 'l': 12, 'm': 13, 'n': 14, 'o': 15, 'p': 16, 'q': 17, 'r': 18, 's': 19, 't': 20, 'u': 21, 'v': 22, 'w': 23, 'x': 24, 'y': 25, 'z': 26}
    assert js_interpreter.interpret_expression('a', local_vars, 100) == 1

# Generated at 2022-06-18 15:29:32.885518
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((1, 2)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((1, 2)) == 0.5
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:29:38.422844
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b) {
            var c = a + b;
            var d = c * a;
            return d;
        }
    '''
    js = JSInterpreter(code)
    f = js.build_function(['a', 'b'], 'var c = a + b; var d = c * a; return d;')
    assert f((1, 2)) == 3
    assert f((2, 3)) == 10


# Generated at 2022-06-18 15:29:43.153363
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
    function test(a, b) {
        return a + b;
    }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3

# Generated at 2022-06-18 15:29:56.449112
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:30:05.692246
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {}) == 21
    assert js_interpreter.interpret_expression('(1+2)*3+4', {}) == 13

# Generated at 2022-06-18 15:30:11.458654
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = """
        function func1(a, b) {
            return a + b;
        }
        var func2 = function(a, b) {
            return a + b;
        }
        var func3 = function func3(a, b) {
            return a + b;
        }
        var func4 = {
            func4: function(a, b) {
                return a + b;
            }
        }
        var func5 = {
            func5: function func5(a, b) {
                return a + b;
            }
        }
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('func1', 1, 2) == 3

# Generated at 2022-06-18 15:30:13.993848
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        function test(a, b) {
            return a + b;
        }
    ''')
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:30:25.994371
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
        var a = function(b, c) {
            return b + c;
        };
        var d = function(e, f) {
            return e - f;
        };
        var g = function(h, i) {
            return h * i;
        };
        var j = function(k, l) {
            return k / l;
        };
        var m = function(n, o) {
            return n % o;
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('a', 1, 2) == 3
    assert js_interpreter.call_function('d', 1, 2) == -1

# Generated at 2022-06-18 15:30:33.312397
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('hello') == 'hello'
    assert obj['c']('world') == 'world'


# Generated at 2022-06-18 15:30:59.476878
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    code = '''
        function f(a, b) {
            var c = a + b;
            return c;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.interpret_expression('f(1, 2)', {}) == 3
    assert js_interpreter.interpret_expression('f(1, 2) + 1', {}) == 4
    assert js_interpreter.interpret_expression('f(1, 2) + f(2, 3)', {}) == 6
    assert js_interpreter.interpret_expression('f(1, 2) + f(2, 3) + 1', {}) == 7

# Generated at 2022-06-18 15:31:05.068375
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p, q){
                return p + q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:31:16.587241
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3', {'a': 2}) == 7
    assert js_interpreter.interpret_expression('a', {'a': 2}) == 2
    assert js_interpreter.interpret_expression('a+1', {'a': 2}) == 3

# Generated at 2022-06-18 15:31:26.509237
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func([1, 2]) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func([1, 2]) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func([1, 2]) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:31:32.148130
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a'], 'a=1;return a')() == 1
    assert js_interpreter.build_function(['a'], 'a=1;return a+1')() == 2
    assert js_interpreter.build_function(['a'], 'a=1;return a+1;')() == 2
    assert js_interpreter.build_function(['a'], 'a=1;return a+1')() == 2
    assert js_interpreter.build_function(['a'], 'a=1;return a+1;')() == 2
    assert js_interpreter.build_function(['a'], 'a=1;return a+1;')() == 2
    assert js

# Generated at 2022-06-18 15:31:36.908532
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:31:46.292725
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    interpreter = JSInterpreter(code)
    f = interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3
    assert f((2, 3)) == 5

    code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    interpreter = JSInterpreter(code)
    f = interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3
    assert f((2, 3)) == 5

   

# Generated at 2022-06-18 15:31:58.473247
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        var a = function(x, y) {
            return x + y;
        };
        var b = function(x, y) {
            return x * y;
        };
        var c = function(x, y) {
            return a(x, y) + b(x, y);
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('a', 1, 2) == 3
    assert js_interpreter.call_function('b', 3, 4) == 12
    assert js_interpreter.call_function('c', 5, 6) == 33


# Generated at 2022-06-18 15:32:08.466734
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:32:20.209588
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('function test(a, b) { return a + b; }')
    assert js_interpreter.build_function(['a', 'b'], 'return a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b')(['a', 'b']) == 'ab'
    assert js_interpreter.build_function(['a', 'b'], 'return a + b')([1, 'b']) == '1b'
    assert js_interpreter.build_function(['a', 'b'], 'return a + b')(['a', 2]) == 'a2'

# Generated at 2022-06-18 15:32:56.507753
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)

# Generated at 2022-06-18 15:33:03.476305
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function() {
                return 1;
            },
            "b": function(a, b) {
                return a + b;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a']() == 1
    assert obj['b'](2, 3) == 5


# Generated at 2022-06-18 15:33:10.688055
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p - q;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == -1


# Generated at 2022-06-18 15:33:15.358970
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
        function func(a, b, c) {
            var d = a + b + c;
            return d;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    func = js_interpreter.extract_function('func')
    assert func((1, 2, 3)) == 6


# Generated at 2022-06-18 15:33:27.077957
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-18 15:33:33.913558
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        }
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:33:41.683285
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    func = js_interpreter.build_function(["a", "b"], "return a + b")
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(["a", "b"], "return a + b; return a - b")
    assert func([1, 2]) == -1
    func = js_interpreter.build_function(["a", "b"], "return a + b; return a - b; return a * b")
    assert func([1, 2]) == -1
    func = js_interpreter.build_function(["a", "b"], "return a + b; return a - b; return a * b; return a / b")
    assert func([1, 2]) == -1
    func = js

# Generated at 2022-06-18 15:33:52.659492
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.interpret_expression("1", {}) == 1
    assert js_interpreter.interpret_expression("1+2", {}) == 3
    assert js_interpreter.interpret_expression("1+2+3", {}) == 6
    assert js_interpreter.interpret_expression("1+2*3", {}) == 7
    assert js_interpreter.interpret_expression("(1+2)*3", {}) == 9
    assert js_interpreter.interpret_expression("1+2*3+4", {}) == 11
    assert js_interpreter.interpret_expression("(1+2)*(3+4)", {}) == 21

# Generated at 2022-06-18 15:34:02.611435
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:34:07.028920
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function foo(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('foo', 1, 2) == 3


# Generated at 2022-06-18 15:35:06.876209
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2+3', {}) == 6
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('1*2+3', {}) == 5
    assert js_interpreter.interpret_expression('1*2*3', {}) == 6
    assert js_interpreter.interpret_expression('1*2+3*4', {}) == 14
    assert js_interpreter.interpret_expression('1*2*3+4', {}) == 10

# Generated at 2022-06-18 15:35:15.233922
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1 + 1', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1 + 1; return a', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1 + 1; return a', {})[1] == True
    assert js_interpreter.interpret_statement('var a = 1 + 1; return a; var b = 2', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1 + 1; return a; var b = 2', {})[1] == True

# Generated at 2022-06-18 15:35:20.506206
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + (2 * 3)', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * (3 + 4)', {}) == 21
    assert js_interpreter.interpret_expression('1 + (2 * (3 + 4))', {}) == 15

# Generated at 2022-06-18 15:35:30.396201
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3

# Generated at 2022-06-18 15:35:37.428824
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var obj = {
            "a": function(x) { return x + 1; },
            "b": function(x, y) { return x + y; }
        };
    """
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](2) == 3
    assert obj['b'](2, 3) == 5


# Generated at 2022-06-18 15:35:50.479261
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(["a", "b"], "return a+b")([1, 2]) == 3
    assert js_interpreter.build_function(["a", "b"], "return a+b")([3, 4]) == 7
    assert js_interpreter.build_function(["a", "b"], "return a+b")([5, 6]) == 11
    assert js_interpreter.build_function(["a", "b"], "return a+b")([7, 8]) == 15
    assert js_interpreter.build_function(["a", "b"], "return a+b")([9, 10]) == 19

# Generated at 2022-06-18 15:35:55.799566
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 1', {}) == 2
    assert js_interpreter.interpret_expression('1 + 1 + 1', {}) == 3
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1', {}) == 4
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1', {}) == 5
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1 + 1', {}) == 6
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1 + 1 + 1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:36:04.657434
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:36:16.435612
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; var b = a', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; var b = a; b', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; var b = a; var c = b; c', {})[0] == 1

# Generated at 2022-06-18 15:36:19.830620
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('function test(a, b) { return a + b; }')
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
