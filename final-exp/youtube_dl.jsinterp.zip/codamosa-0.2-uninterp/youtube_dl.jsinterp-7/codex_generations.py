

# Generated at 2022-06-18 15:27:53.263688
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:00.427048
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(b, c) {
                return b + c;
            },
            "b": function(b, c) {
                return b - c;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:28:05.170443
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 + 3', {}) == 6
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + (2 * 3)', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * (3 + 4)', {}) == 21

# Generated at 2022-06-18 15:28:09.710050
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1; var b = 2', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1; var b = a + 1', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1; var b = a + 1; return b', {})[0] == 2
    assert js_interpreter.interpret_statement('var a = 1; var b = a + 1; return b; var c = 3', {})[0] == 2

# Generated at 2022-06-18 15:28:22.302057
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:28.801147
# Unit test for method extract_function of class JSInterpreter

# Generated at 2022-06-18 15:28:34.271152
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test_func(a, b, c) {
            return a + b + c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test_func', 1, 2, 3) == 6


# Generated at 2022-06-18 15:28:43.860937
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('3', {}) == 3
    assert js_interpreter.interpret_expression('3 + 4', {}) == 7
    assert js_interpreter.interpret_expression('3 + 4 * 5', {}) == 23
    assert js_interpreter.interpret_expression('(3 + 4) * 5', {}) == 35
    assert js_interpreter.interpret_expression('3 + 4 * 5 + 6', {}) == 29
    assert js_interpreter.interpret_expression('3 + 4 * 5 + 6 * 7', {}) == 57
    assert js_interpreter.interpret_expression('3 + 4 * 5 + 6 * 7 / 8', {}) == 56.875

# Generated at 2022-06-18 15:28:50.859684
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build

# Generated at 2022-06-18 15:28:55.642854
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a+b;a+b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a+b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a+b;return a+b;')
    assert f((1, 2)) == 3

# Generated at 2022-06-18 15:30:27.043817
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var obj = {
            "a": function(b) {
                return b;
            },
            "b": function(a) {
                return a;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('obj')
    assert obj['a']('b') == 'b'
    assert obj['b']('a') == 'a'


# Generated at 2022-06-18 15:30:37.109988
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:30:42.728785
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:30:51.615199
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:30:59.476245
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function func1(a, b) {
            return a + b;
        }
        function func2(a, b) {
            return func1(a, b);
        }
        function func3(a, b) {
            return func2(a, b);
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('func1', 1, 2) == 3
    assert js_interpreter.call_function('func2', 1, 2) == 3
    assert js_interpreter.call_function('func3', 1, 2) == 3


# Generated at 2022-06-18 15:31:02.569453
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        function test(a, b) {
            return a + b;
        }
    """
    interpreter = JSInterpreter(code)
    f = interpreter.extract_function('test')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:31:14.133789
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    interpreter = JSInterpreter(code)
    f = interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3
    assert f((2, 3)) == 5
    assert f((3, 4)) == 7
    assert f((4, 5)) == 9
    assert f((5, 6)) == 11
    assert f((6, 7)) == 13
    assert f((7, 8)) == 15
    assert f((8, 9)) == 17
    assert f((9, 10)) == 19
    assert f((10, 11)) == 21
    assert f((11, 12)) == 23
   

# Generated at 2022-06-18 15:31:18.485343
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars) == (1, False)
    assert js_interpreter.interpret_statement('a + b', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('a + b - c', local_vars) == (0, False)
    assert js_interpreter.interpret_statement('a + b - c * 2', local_vars) == (-3, False)
    assert js_interpreter.interpret_statement('a + b - c * 2 + 1', local_vars) == (-2, False)
    assert js_interpreter.interpret_statement

# Generated at 2022-06-18 15:31:27.507275
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    func = js_interpreter.build_function(["a", "b"], "return a + b;")
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(["a", "b"], "return a + b; return a - b;")
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(["a", "b"], "return a + b; return a - b; return a * b;")
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(["a", "b"], "return a + b; return a - b; return a * b; return a / b;")
    assert func([1, 2]) == 3

# Generated at 2022-06-18 15:31:36.353409
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(arg1, arg2) {
                return arg1 + arg2;
            },
            "b": function(arg1, arg2) {
                return arg1 - arg2;
            }
        };
        '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:32:19.808521
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function func(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('func', 1, 2) == 3


# Generated at 2022-06-18 15:32:31.340139
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-18 15:32:42.632224
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:32:53.133357
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1;', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; return a;', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; return a; var b = 2;', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; return a; var b = 2; return b;', {}) == (1, True)

# Generated at 2022-06-18 15:33:00.373682
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:33:12.585064
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(["a", "b"], "return a + b")([1, 2]) == 3
    assert js_interpreter.build_function(["a", "b"], "return a + b")([2, 3]) == 5
    assert js_interpreter.build_function(["a", "b"], "return a + b")([3, 4]) == 7
    assert js_interpreter.build_function(["a", "b"], "return a + b")([4, 5]) == 9
    assert js_interpreter.build_function(["a", "b"], "return a + b")([5, 6]) == 11

# Generated at 2022-06-18 15:33:20.357163
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    js_interpreter.build_function(['a', 'b'], 'a+b')
    js_interpreter.build_function(['a', 'b'], 'return a+b')
    js_interpreter.build_function(['a', 'b'], 'var c=a+b; return c')
    js_interpreter.build_function(['a', 'b'], 'var c=a+b; return c;')
    js_interpreter.build_function(['a', 'b'], 'var c=a+b; return c; var d=c+1; return d')

# Generated at 2022-06-18 15:33:32.268648
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func([1, 2], c=3) == 6
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func([1, 2], c=3) == 6

# Generated at 2022-06-18 15:33:40.833759
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:33:51.459618
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-18 15:34:43.640188
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            a: function(x) {
                return x + 1;
            },
            b: function(x, y) {
                return x * y;
            }
        };
    '''
    obj = JSInterpreter(code).extract_object('obj')
    assert obj['a'](1) == 2
    assert obj['b'](2, 3) == 6


# Generated at 2022-06-18 15:34:55.782125
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:34:59.508779
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function abc(a, b, c) {
            return a + b + c;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('abc', 1, 2, 3) == 6


# Generated at 2022-06-18 15:35:10.611546
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:35:22.034196
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a+b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build

# Generated at 2022-06-18 15:35:24.893862
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a,b) {
            return a+b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:35:31.075815
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p - q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == -1


# Generated at 2022-06-18 15:35:35.201041
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p,q){
                return p+q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1,2) == 3


# Generated at 2022-06-18 15:35:43.712150
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p, q) {
                return p + q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:35:55.019023
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(["a", "b"], "return a + b")([1, 2]) == 3
    assert js_interpreter.build_function(["a", "b"], "return a + b")([2, 3]) == 5
    assert js_interpreter.build_function(["a", "b"], "return a + b")([3, 4]) == 7
    assert js_interpreter.build_function(["a", "b"], "return a + b")([4, 5]) == 9
    assert js_interpreter.build_function(["a", "b"], "return a + b")([5, 6]) == 11