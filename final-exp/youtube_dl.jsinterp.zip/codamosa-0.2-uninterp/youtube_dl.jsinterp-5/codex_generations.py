

# Generated at 2022-06-18 15:28:06.961046
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('1+2*3+4*5', {}) == 26
    assert js_interpreter.interpret_expression('1+2*3+4*5+6', {}) == 32

# Generated at 2022-06-18 15:28:20.164945
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:26.371108
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + (2 * 3)', {}) == 7
    assert js_interpreter.interpret_expression('1 + 2 * 3 + 4', {}) == 11
    assert js_interpreter.interpret_expression('1 + 2 * (3 + 4)', {}) == 15

# Generated at 2022-06-18 15:28:29.864408
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p + 1;
            }
        };
    '''
    interp = JSInterpreter(code)
    obj = interp.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1) == 2


# Generated at 2022-06-18 15:28:33.307309
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:28:41.020999
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p1, p2) {
                return p1 + p2;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:28:47.274488
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function func1(a, b) {
            return a + b;
        }
        function func2(a, b) {
            return a * b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('func1', 1, 2) == 3
    assert js_interpreter.call_function('func2', 3, 4) == 12


# Generated at 2022-06-18 15:28:50.013502
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function func(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(code)
    func = js_interpreter.extract_function('func')
    assert func((1, 2)) == 3


# Generated at 2022-06-18 15:28:54.323432
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('test')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:29:01.796719
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a*b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'var c=a+b;return c')([1, 2]) == 3
    assert js

# Generated at 2022-06-18 15:29:21.908636
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a + b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a + b; return a - b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a.length')
    assert f(([1, 2, 3], 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a.join(b)')
    assert f(('ab', 'c')) == 'acb'

# Generated at 2022-06-18 15:29:31.907996
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:29:37.060619
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js = JSInterpreter(code)
    obj = js.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:29:45.973542
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('foo') == 'foo'
    assert obj['c']('bar') == 'bar'


# Generated at 2022-06-18 15:29:53.244575
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p - q;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](2, 3) == 5
    assert obj['c'](2, 3) == -1


# Generated at 2022-06-18 15:30:04.266356
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:30:09.459532
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        var a = {
            "b": function(p) {
                return p;
            }
        };
        var c = function(p) {
            return p;
        };
        var d = function(p) {
            return a.b(p);
        };
        var e = function(p) {
            return c(p);
        };
        var f = function(p) {
            return p + 1;
        };
        var g = function(p) {
            return f(p);
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('a.b', 1) == 1
    assert js_interpreter.call_function('c', 2) == 2
    assert js

# Generated at 2022-06-18 15:30:13.247975
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('hello') == 'hello'
    assert obj['c']('world') == 'world'


# Generated at 2022-06-18 15:30:24.631387
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'return a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b')([1, 2]) == 3

# Generated at 2022-06-18 15:30:31.886404
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    obj = JSInterpreter(code).extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:31:01.931515
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:31:13.439079
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars) == (1, False)
    assert js_interpreter.interpret_statement('a + b', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('a + b - c', local_vars) == (0, False)
    assert js_interpreter.interpret_statement('a + b * c', local_vars) == (7, False)
    assert js_interpreter.interpret_statement('a + b * c - 1', local_vars) == (6, False)

# Generated at 2022-06-18 15:31:24.135125
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2+3', {}) == 6
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('1+2*3+4*5', {}) == 26

# Generated at 2022-06-18 15:31:32.309334
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var obj = {
            "a": function(x, y) {
                return x + y;
            },
            "b": function(x, y) {
                return x - y;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:31:43.276666
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; return a', {}) == (1, True)
    assert js_interpreter.interpret_statement('var a = 1; var b = a + 1; return b', {}) == (2, True)
    assert js_interpreter.interpret_statement('var a = 1; var b = a + 1; return a', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = a + 1; return b', {'a': 2}) == (3, True)

# Generated at 2022-06-18 15:31:49.798495
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    # Test 1
    code = '''
        var a = function() {
            var b = function() {
                return 3;
            }
            return b();
        }
        a();
    '''
    interpreter = JSInterpreter(code)
    assert interpreter.interpret_statement('return 3;', {})[0] == 3

    # Test 2
    code = '''
        var a = function() {
            var b = function() {
                return 3;
            }
            return b();
        }
        a();
    '''
    interpreter = JSInterpreter(code)
    assert interpreter.interpret_statement('var b = function() { return 3; }', {})[0] == None

    # Test 3

# Generated at 2022-06-18 15:32:02.915819
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-18 15:32:07.082778
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        function foo(a, b) {
            return a + b;
        }
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('foo', 1, 2) == 3


# Generated at 2022-06-18 15:32:14.334264
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p, q){
                return p + q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:32:17.788419
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'return a + b')
    assert f((1, 2)) == 3

# Generated at 2022-06-18 15:32:46.354243
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        function test_function(arg1, arg2) {
            return arg1 + arg2;
        }
    ''')
    assert js_interpreter.call_function('test_function', 1, 2) == 3


# Generated at 2022-06-18 15:32:56.078328
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-18 15:33:03.876513
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    func = js_interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert func((1, 2)) == 3
    assert func((2, 3)) == 5
    assert func((4, 5)) == 9


# Generated at 2022-06-18 15:33:12.214767
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func_name = 'test_func'
    arg_names = ['a', 'b']
    code = '''
        var c = a + b;
        return c;
    '''
    f = js_interpreter.build_function(arg_names, code)
    assert f(['1', '2']) == '3'
    assert f(['1', '2', '3']) == '3'
    assert f(['1']) == '1'
    assert f([]) == None


# Generated at 2022-06-18 15:33:20.124318
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:33:32.206284
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:33:40.800382
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test for interpret_expression
    js_interpreter = JSInterpreter('')
    local_vars = {'a': [1, 2, 3], 'b': 'abc', 'c': 'def', 'd': 'ghi'}
    assert js_interpreter.interpret_expression('a[0]', local_vars, 100) == 1
    assert js_interpreter.interpret_expression('a[1]', local_vars, 100) == 2
    assert js_interpreter.interpret_expression('a[2]', local_vars, 100) == 3
    assert js_interpreter.interpret_expression('b.length', local_vars, 100) == 3

# Generated at 2022-06-18 15:33:51.346535
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a + b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a + b; return a - b;')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a + b; return a - b; a + 3;')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a + b; return a - b; a + 3; return a;')
    assert f((1, 2)) == 1
    f = js

# Generated at 2022-06-18 15:34:01.735040
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        function test(a, b) {
            var c = a + b;
            return c;
        }
    """)
    func = js_interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert func((1, 2)) == 3
    assert func((2, 3)) == 5
    assert func((3, 4)) == 7
    assert func((4, 5)) == 9
    assert func((5, 6)) == 11
    assert func((6, 7)) == 13
    assert func((7, 8)) == 15
    assert func((8, 9)) == 17
    assert func((9, 10)) == 19
    assert func((10, 11)) == 21
    assert func((11, 12)) == 23


# Generated at 2022-06-18 15:34:11.439410
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 1', {}) == 2
    assert js_interpreter.interpret_expression('1 + 1 + 1', {}) == 3
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1', {}) == 4
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1', {}) == 5
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1 + 1', {}) == 6
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1 + 1 + 1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:35:07.951873
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function func1(a, b, c) {
            return a + b + c;
        }
        function func2(a, b, c) {
            return func1(a, b, c);
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('func2', 1, 2, 3) == 6


# Generated at 2022-06-18 15:35:15.833657
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:35:22.032092
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    '''
    interpreter = JSInterpreter(code)
    f = interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3

# Generated at 2022-06-18 15:35:31.584020
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a'], 'a')(['b']) == 'b'
    assert js_interpreter.build_function(['a'], 'a+1')(['1']) == 2
    assert js_interpreter.build_function(['a'], 'a+1')(['1']) == 2
    assert js_interpreter.build_function(['a'], 'a+1')(['1']) == 2
    assert js_interpreter.build_function(['a'], 'a+1')(['1']) == 2
    assert js_interpreter.build_function(['a'], 'a+1')(['1']) == 2
    assert js_interpreter.build_

# Generated at 2022-06-18 15:35:44.199009
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3

# Generated at 2022-06-18 15:35:50.009714
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test_func(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test_func', 1, 2) == 3


# Generated at 2022-06-18 15:35:52.317779
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        function test(a, b) {
            return a + b;
        }
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:36:01.292755
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-18 15:36:11.122151
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:36:18.184539
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p1, p2) {
                return p1 + p2;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2, 3) == 5
