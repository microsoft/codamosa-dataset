

# Generated at 2022-06-18 15:28:00.202278
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})
    func = js_interpreter.build_function(['a', 'b'], 'a+b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b; return a-b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b; a-b;')
    assert func([1, 2]) == 3

# Generated at 2022-06-18 15:28:02.360964
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:28:07.581882
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:28:20.830485
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:28:24.669668
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:28:27.319008
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:28:40.034548
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = '''
        var a = 5;
        var b = {'c': {'d': [1, 2, 3]}};
        var f = function(x) {
            return x * x;
        };
        var g = function(y) {
            return y + 1;
        };
        var h = function(z) {
            return z + 2;
        };
        var i = function(w) {
            return w + 3;
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.interpret_expression('a', {}) == 5
    assert js_interpreter.interpret_expression('b.c.d[0]', {}) == 1

# Generated at 2022-06-18 15:28:45.944553
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    jsi = JSInterpreter(code)
    obj = jsi.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:28:50.846593
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function func1(a, b) {
            return a + b;
        }
        var func2 = function(a, b) {
            return a + b;
        }
        var func3 = function func3(a, b) {
            return a + b;
        }
        var func4 = {
            func4: function(a, b) {
                return a + b;
            }
        }
        var func5 = {
            func5: function func5(a, b) {
                return a + b;
            }
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('func1', 1, 2) == 3

# Generated at 2022-06-18 15:28:59.620801
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:29:28.667384
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        function test(a, b) {
            var c = a + b;
            return c;
        }
    """)
    f = js_interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:29:37.971979
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:29:51.149372
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.interpret_statement("var a = 1", {}) == (1, False)
    assert js_interpreter.interpret_statement("var a = 1; a", {}) == (1, False)
    assert js_interpreter.interpret_statement("var a = 1; return a", {}) == (1, True)
    assert js_interpreter.interpret_statement("var a = 1; return a; a", {}) == (1, True)
    assert js_interpreter.interpret_statement("var a = 1; return a; var b = 2; return b", {}) == (2, True)

# Generated at 2022-06-18 15:30:00.430198
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        var a = function(x, y) {
            return x + y;
        };
        var b = function(x, y) {
            return a(x, y);
        };
        var c = function(x, y) {
            return b(x, y);
        };
        var d = function(x, y) {
            return c(x, y);
        };
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('d', 1, 2) == 3


# Generated at 2022-06-18 15:30:08.156599
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-18 15:30:12.972757
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func((1, 2)) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func((1, 2)) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:30:23.248863
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func([1, 2], {'c': 3}) == 6
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func([1, 2], {'c': 3}) == 6
    func = js_interpreter.build

# Generated at 2022-06-18 15:30:35.487586
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + 2 * 3 + 4', {}) == 11
    assert js_interpreter.interpret_expression('(1 + 2) * (3 + 4)', {}) == 21
    assert js_interpreter.interpret_expression('(1 + 2) * 3 + 4', {}) == 13

# Generated at 2022-06-18 15:30:40.629619
# Unit test for method interpret_statement of class JSInterpreter

# Generated at 2022-06-18 15:30:50.781805
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    def f(args):
        local_vars = dict(zip(["a", "b"], args))
        for stmt in "a=b+1;return a*a".split(';'):
            res, abort = js_interpreter.interpret_statement(stmt, local_vars)
            if abort:
                break
        return res
    assert js_interpreter.build_function(["a", "b"], "a=b+1;return a*a")(1, 2) == f(1, 2)


# Generated at 2022-06-18 15:31:09.143272
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(c) {
                return c;
            },
            d: function(e) {
                return e;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['d'](2) == 2


# Generated at 2022-06-18 15:31:13.350362
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    jsinterpreter = JSInterpreter(code)
    func = jsinterpreter.extract_function('test')
    assert func((1, 2)) == 3


# Generated at 2022-06-18 15:31:23.982481
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([2, 3]) == 5
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([3, 4]) == 7
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([4, 5]) == 9
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([5, 6]) == 11

# Generated at 2022-06-18 15:31:30.567215
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:31:42.210198
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + (2 * 3)', {}) == 7
    assert js_interpreter.interpret_expression('1 + 2 * 3 + 4', {}) == 11
    assert js_interpreter.interpret_expression('(1 + 2) * (3 + 4)', {}) == 21

# Generated at 2022-06-18 15:31:49.289811
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((1, 2)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((1, 2)) == 0.5
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:32:02.507757
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('')
    f = js.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert f((1, 2)) == 3
    f = js.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert f((1, 2)) == 3
    f = js.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')
    assert f((1, 2)) == 3

# Generated at 2022-06-18 15:32:08.386310
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p1, p2) {
                return p1 + p2;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:32:20.166704
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')

# Generated at 2022-06-18 15:32:26.968857
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((1, 2)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((1, 2)) == 0.5
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:32:48.943855
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:32:57.858185
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a+b;return a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a+b;return a-b;')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a+b;return a-b;return a*b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function

# Generated at 2022-06-18 15:33:05.551230
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p, q) {
                return p + q;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:33:16.017052
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:33:21.796427
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(p) {
                return p;
            },
            "b": function(p) {
                return p + 1;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](1) == 1
    assert obj['b'](1) == 2


# Generated at 2022-06-18 15:33:33.563520
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((1, 2)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((1, 2)) == 0.5
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:33:41.541225
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b;')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b;a=b')([1, 2]) == 2

# Generated at 2022-06-18 15:33:52.460039
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:33:58.640659
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        var a = function(b, c) {
            return b + c;
        };
        var d = function(e, f) {
            return a(e, f);
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('d', 1, 2) == 3


# Generated at 2022-06-18 15:34:03.631075
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(arg1, arg2) {
                return arg1 + arg2;
            },
            "b": function(arg1, arg2) {
                return arg1 - arg2;
            }
        };
    '''
    obj = JSInterpreter(code).extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:34:41.575916
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:34:51.557370
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 1', {}) == 2
    assert js_interpreter.interpret_expression('1 + 1 + 1', {}) == 3
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1', {}) == 4
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1', {}) == 5
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1 + 1', {}) == 6
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1 + 1 + 1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:35:02.717411
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-18 15:35:13.091583
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:35:19.692834
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("function test(a,b){var c=a+b;return c;}")
    test_function = js_interpreter.build_function(["a","b"],"var c=a+b;return c;")
    assert test_function([1,2]) == 3


# Generated at 2022-06-18 15:35:24.003402
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a,b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:35:28.566104
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function abc(a, b, c) {
            return a + b + c;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('abc', 1, 2, 3) == 6


# Generated at 2022-06-18 15:35:35.791720
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func((1, 2)) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func((1, 2)) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:35:49.348825
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:35:57.611220
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars) == (1, False)
    assert js_interpreter.interpret_statement('a + b', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('a + b + c', local_vars) == (6, False)
    assert js_interpreter.interpret_statement('a + b + c + 1', local_vars) == (7, False)
    assert js_interpreter.interpret_statement('a + b + c + 1 + 1', local_vars) == (8, False)
    assert js_interpreter.interpret_statement

# Generated at 2022-06-18 15:36:27.858531
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a*b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;return a*b')([1, 2]) == 3
    assert js

# Generated at 2022-06-18 15:36:38.438078
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:36:43.937385
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    ''')
    f = js.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:36:54.651340
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a + b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a + b; a + b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; a + b')
    assert func((1, 2)) == 3