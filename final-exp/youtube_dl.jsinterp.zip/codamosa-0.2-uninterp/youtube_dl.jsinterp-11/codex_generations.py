

# Generated at 2022-06-18 15:27:40.585039
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('')
    assert js.interpret_expression('1', {}) == 1
    assert js.interpret_expression('1+1', {}) == 2
    assert js.interpret_expression('1+1+1', {}) == 3
    assert js.interpret_expression('1+1+1+1', {}) == 4
    assert js.interpret_expression('1+1+1+1+1', {}) == 5
    assert js.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js.interpret_expression('1+1+1+1+1+1+1+1', {}) == 8

# Generated at 2022-06-18 15:27:48.480084
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_code = '''
    function test(a, b) {
        var c = a + b;
        var d = a - b;
        return c + d;
    }
    '''
    js_interpreter = JSInterpreter(js_code)
    func = js_interpreter.build_function(['a', 'b'], 'var c = a + b; var d = a - b; return c + d;')
    assert func((1, 2)) == 2
    assert func((2, 1)) == 4


# Generated at 2022-06-18 15:27:53.705666
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
    function test(a, b) {
        return a + b;
    }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:28:03.932745
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func((1, 2)) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func((1, 2)) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:28:06.999052
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    jsi = JSInterpreter(code)
    obj = jsi.extract_object('a')
    assert obj['b']('hello') == 'hello'
    assert obj['c']('world') == 'world'


# Generated at 2022-06-18 15:28:20.260299
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a * b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a * b; return a - b; return a / b;')

# Generated at 2022-06-18 15:28:26.519452
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars)[0] == 1
    assert js_interpreter.interpret_statement('b', local_vars)[0] == 2
    assert js_interpreter.interpret_statement('c', local_vars)[0] == 3
    assert js_interpreter.interpret_statement('a + b', local_vars)[0] == 3
    assert js_interpreter.interpret_statement('a + b + c', local_vars)[0] == 6
    assert js_interpreter.interpret_statement('a + b - c', local_vars)[0] == 0
    assert js_interpreter

# Generated at 2022-06-18 15:28:32.439493
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:28:35.767389
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        function test(a, b) {
            var c = a + b;
            return c;
        }
    """)
    f = js_interpreter.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3
    assert f((3, 4)) == 7


# Generated at 2022-06-18 15:28:44.576341
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-18 15:29:07.096117
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = b', {'b': 1}) == (1, False)
    assert js_interpreter.interpret_statement('var a = b + c', {'b': 1, 'c': 2}) == (3, False)
    assert js_interpreter.interpret_statement('var a = b + c', {'b': 1, 'c': 2}) == (3, False)
    assert js_interpreter.interpret_statement('var a = b + c', {'b': 1, 'c': 2}) == (3, False)
    assert js_interpreter.interpret_statement('var a = b + c', {'b': 1, 'c': 2}) == (3, False)
    assert js_interpre

# Generated at 2022-06-18 15:29:18.438207
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    stmt = 'a + b * c'
    res, abort = js_interpreter.interpret_statement(stmt, local_vars)
    assert res == 7
    assert abort == False
    stmt = 'a = b + c'
    res, abort = js_interpreter.interpret_statement(stmt, local_vars)
    assert res == 5
    assert abort == False
    stmt = 'return a + b'
    res, abort = js_interpreter.interpret_statement(stmt, local_vars)
    assert res == 7
    assert abort == True
    stmt = 'return'

# Generated at 2022-06-18 15:29:22.856466
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:29:33.023804
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b, c) {
            var d = a + b;
            var e = c;
            return d + e;
        }
    '''
    jsi = JSInterpreter(code)
    f = jsi.build_function(['a', 'b', 'c'], 'var d = a + b; var e = c; return d + e;')
    assert f((1, 2, 3)) == 6
    assert f((1, 2, 4)) == 7
    assert f((1, 2, 5)) == 8
    assert f((1, 2, 6)) == 9
    assert f((1, 2, 7)) == 10
    assert f((1, 2, 8)) == 11
    assert f((1, 2, 9)) == 12

# Generated at 2022-06-18 15:29:38.257426
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        var a = function(b, c) {
            var d = b + c;
            return d;
        }
    '''
    js_interpreter = JSInterpreter(code)
    func = js_interpreter.build_function(['b', 'c'], 'var d = b + c; return d;')
    assert func((1, 2)) == 3
    assert func((2, 3)) == 5


# Generated at 2022-06-18 15:29:51.299028
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3

# Generated at 2022-06-18 15:30:02.929456
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a + b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; a + b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a + b')
    assert func([1, 2]) == 3

# Generated at 2022-06-18 15:30:08.788469
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:30:15.362452
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3

# Generated at 2022-06-18 15:30:28.057475
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a*b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;return a*b')([1, 2]) == 3
    assert js

# Generated at 2022-06-18 15:31:22.460658
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((1, 2)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((1, 2)) == 0.5
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:31:27.863978
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var A = {
            a: function(p) {
                return p;
            },
            b: function(p, q) {
                return p + q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('A')
    assert obj['a'](1) == 1
    assert obj['b'](1, 2) == 3


# Generated at 2022-06-18 15:31:37.247699
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        function test(arg1, arg2) {
            var a = arg1;
            var b = arg2;
            var c = a + b;
            return c;
        }
    """)
    func = js_interpreter.build_function(['arg1', 'arg2'], """
        var a = arg1;
        var b = arg2;
        var c = a + b;
        return c;
    """)
    assert func([1, 2]) == 3


# Generated at 2022-06-18 15:31:46.548776
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func((1, 2)) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func((1, 2)) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:31:54.690641
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p){
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:32:06.297546
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:32:13.273776
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p){
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:32:22.902954
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function foo(a, b, c) {
            return a + b + c;
        }
    '''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('foo')
    assert f((1, 2, 3)) == 6
    assert f((1, 2, 4)) == 7

    code = '''
        var foo = function(a, b, c) {
            return a + b + c;
        }
    '''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('foo')
    assert f((1, 2, 3)) == 6
    assert f((1, 2, 4)) == 7


# Generated at 2022-06-18 15:32:34.681582
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:32:46.257866
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:33:07.212398
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('hello') == 'hello'
    assert obj['c']('world') == 'world'


# Generated at 2022-06-18 15:33:13.413013
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p, q) {
                return p + q;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:33:22.685957
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:33:34.497602
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = """
        var a = 'abc';
        var b = [1, 2, 3];
        var c = {
            'd': 'def',
            'e': [4, 5, 6],
            'f': function(g) {
                return g * 2;
            }
        };
        var h = function(i, j) {
            return i + j;
        };
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.interpret_expression('a', {}) == 'abc'
    assert js_interpreter.interpret_expression('b', {}) == [1, 2, 3]

# Generated at 2022-06-18 15:33:42.038051
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.interpret_expression("1", {}) == 1
    assert js_interpreter.interpret_expression("1+1", {}) == 2
    assert js_interpreter.interpret_expression("1+1+1", {}) == 3
    assert js_interpreter.interpret_expression("1+1+1+1", {}) == 4
    assert js_interpreter.interpret_expression("1+1+1+1+1", {}) == 5
    assert js_interpreter.interpret_expression("1+1+1+1+1+1", {}) == 6
    assert js_interpreter.interpret_expression("1+1+1+1+1+1+1", {}) == 7
    assert js_interpreter.interpret_

# Generated at 2022-06-18 15:33:48.835092
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = {
            b: function(p){
                return p;
            },
            c: function(p){
                return p;
            }
        };
    """
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:33:55.845596
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p1, p2) {
                return p1 + p2;
            }
        };
    '''
    js = JSInterpreter(code)
    obj = js.extract_object('a')
    assert obj['b']('foo') == 'foo'
    assert obj['c']('foo', 'bar') == 'foobar'


# Generated at 2022-06-18 15:34:01.806990
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = """
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    """
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:34:08.191840
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        }
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:34:12.999262
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('''
        function test(a, b) {
            var c = a + b;
            return c;
        }
    ''')
    f = js.build_function(['a', 'b'], 'var c = a + b; return c;')
    assert f((1, 2)) == 3
    assert f((3, 4)) == 7


# Generated at 2022-06-18 15:35:03.174501
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return a * b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return a * b; return a + b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return a * b; return a + b; return a * b')([1, 2]) == 2

# Generated at 2022-06-18 15:35:13.337478
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:35:21.834223
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:35:24.787926
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3

# Generated at 2022-06-18 15:35:33.544097
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(["a", "b"], "return a + b;")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b;")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b;")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b;")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b;")(["1", "2"])

# Generated at 2022-06-18 15:35:47.319090
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    def test_func(argnames, code, expected):
        resf = js_interpreter.build_function(argnames, code)
        assert resf(expected[0]) == expected[1]
    test_func(["a", "b"], "return a + b;", [[1, 2], 3])
    test_func(["a", "b"], "return a + b;", [[1, 2], 3])
    test_func(["a", "b"], "return a + b;", [[1, 2], 3])
    test_func(["a", "b"], "return a + b;", [[1, 2], 3])
    test_func(["a", "b"], "return a + b;", [[1, 2], 3])

# Generated at 2022-06-18 15:35:56.806920
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:36:01.036804
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function f(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('f', 1, 2) == 3


# Generated at 2022-06-18 15:36:07.869602
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(x) { return x + 1; },
            "b": function(x, y) { return x + y; },
            "c": function(x, y) { return x * y; }
        };
    '''
    interp = JSInterpreter(code)
    obj = interp.extract_object('obj')
    assert obj['a'](1) == 2
    assert obj['b'](1, 2) == 3
    assert obj['c'](2, 3) == 6


# Generated at 2022-06-18 15:36:18.452348
# Unit test for method interpret_expression of class JSInterpreter