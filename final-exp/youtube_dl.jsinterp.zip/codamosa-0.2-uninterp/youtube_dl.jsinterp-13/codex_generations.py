

# Generated at 2022-06-18 15:27:57.458229
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
        '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:28:06.960835
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 * 3', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js_interpreter.interpret_expression('1 + (2 * 3)', {}) == 7
    assert js_interpreter.interpret_expression('(1 + 2) * (3 + 4)', {}) == 21
    assert js_interpreter.interpret_expression('1 + 2 * 3 + 4', {}) == 11

# Generated at 2022-06-18 15:28:20.164297
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a + b', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('a + b; c', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('return a + b', local_vars) == (3, True)
    assert js_interpreter.interpret_statement('return a + b; c', local_vars) == (3, True)
    assert js_interpreter.interpret_statement('var d = a + b', local_vars) == (3, False)

# Generated at 2022-06-18 15:28:26.401526
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:31.774350
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:28:42.697988
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a + b; a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a + b;')
    assert func((1, 2)) == 3

# Generated at 2022-06-18 15:28:50.269998
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            a: function(x, y) {
                return x + y;
            },
            b: function(x, y) {
                return x - y;
            }
        };
        '''
    obj = JSInterpreter(code).extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:28:59.103275
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a*b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;return a*b')([1, 2]) == 3
    assert js_interpreter

# Generated at 2022-06-18 15:29:02.370061
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:29:06.362160
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        function test(a, b) {
            return a + b;
        }
    ''')
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:29:48.377650
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 1', {}) == 2
    assert js_interpreter.interpret_expression('1 + 1 + 1', {}) == 3
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1', {}) == 4
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1', {}) == 5
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1 + 1', {}) == 6
    assert js_interpreter.interpret_expression('1 + 1 + 1 + 1 + 1 + 1 + 1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:30:00.703497
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('1+2*3+4*5', {}) == 26
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {}) == 21

# Generated at 2022-06-18 15:30:08.341701
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:30:12.707892
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var obj = {
            "a": function(arg1, arg2) {
                return arg1 + arg2;
            },
            "b": function(arg1, arg2) {
                return arg1 - arg2;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:30:22.731254
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    def test_func(argnames, code, args, expected_result):
        f = js_interpreter.build_function(argnames, code)
        assert f(args) == expected_result
    test_func(['a', 'b'], 'a + b', (1, 2), 3)
    test_func(['a', 'b'], 'a + b; a + b', (1, 2), 3)
    test_func(['a', 'b'], 'a + b; return a + b', (1, 2), 3)
    test_func(['a', 'b'], 'return a + b', (1, 2), 3)

# Generated at 2022-06-18 15:30:35.233374
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;')([2, 3]) == 5
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;')([3, 4]) == 7
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;')([4, 5]) == 9
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;')([5, 6]) == 11
    assert js_interpreter.build

# Generated at 2022-06-18 15:30:38.037570
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js = JSInterpreter(code)
    obj = js.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:30:40.348057
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function abc(a, b, c) {
            return a + b + c;
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('abc', 1, 2, 3) == 6


# Generated at 2022-06-18 15:30:52.597071
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1 + 2', {}) == 3
    assert js_interpreter.interpret_expression('1 + 2 + 3', {}) == 6
    assert js_interpreter.interpret_expression('1 + 2 + 3 + 4', {}) == 10
    assert js_interpreter.interpret_expression('1 + 2 + 3 + 4 + 5', {}) == 15
    assert js_interpreter.interpret_expression('1 + 2 + 3 + 4 + 5 + 6', {}) == 21
    assert js_interpreter.interpret_expression('1 + 2 + 3 + 4 + 5 + 6 + 7', {}) == 28
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:31:01.655040
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:31:42.209437
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test for method interpret_expression of class JSInterpreter
    # Test for basic arithmetic operations
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1-2', {}) == -1
    assert js_interpreter.interpret_expression('1*2', {}) == 2
    assert js_interpreter.interpret_expression('1/2', {}) == 0.5
    assert js_interpreter.interpret_expression('1%2', {}) == 1
    assert js_interpreter.interpret_expression('1<<2', {}) == 4
    assert js_interpreter.interpret_expression('1>>2', {}) == 0
    assert js_interpreter.interpret_expression

# Generated at 2022-06-18 15:31:47.928119
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:31:56.257841
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:32:01.552561
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('test')
    assert f((1, 2)) == 3

# Generated at 2022-06-18 15:32:07.512836
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:32:14.830860
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            "b": function(p) {
                return p;
            },
            "c": function() {
                return "c";
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('b') == 'b'
    assert obj['c']() == 'c'


# Generated at 2022-06-18 15:32:21.226983
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p + 1;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1) == 2


# Generated at 2022-06-18 15:32:32.333572
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:32:43.668819
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
        var d = {
            e: function(p) {
                return p;
            },
            f: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'
    obj = js_interpreter.extract_object('d')
    assert obj['e']('test') == 'test'

# Generated at 2022-06-18 15:32:47.844265
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        function test(a, b) {
            return a + b;
        }
    ''')
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:33:26.241001
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    func = js_interpreter.build_function(["a", "b"], "return a + b;")
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(["a", "b"], "return a + b; return a - b;")
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(["a", "b"], "return a + b; return a - b; return a * b;")
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(["a", "b"], "return a + b; return a - b; return a * b; return a / b;")
    assert func([1, 2]) == 3

# Generated at 2022-06-18 15:33:32.452830
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func_name = 'test_func'
    arg_names = ['a', 'b']
    code = '''
        var c = a + b;
        return c;
    '''
    func = js_interpreter.build_function(arg_names, code)
    assert func(['1', '2']) == '12'


# Generated at 2022-06-18 15:33:40.938744
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1-1', {}) == 0
    assert js_interpreter.interpret_expression('1*1', {}) == 1
    assert js_interpreter.interpret_expression('1/1', {}) == 1
    assert js_interpreter.interpret_expression('1%1', {}) == 0
    assert js_interpreter.interpret_expression('1<<1', {}) == 2
    assert js_interpreter.interpret_expression('1>>1', {}) == 0
    assert js_interpreter.interpret_expression('1&1', {})

# Generated at 2022-06-18 15:33:51.552064
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})
    assert js_interpreter.build_function(['a', 'b'], 'a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return a')([1, 2]) == 1
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return a; a + b')([1, 2]) == 1
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return a; a + b; return a + b')([1, 2]) == 3

# Generated at 2022-06-18 15:33:58.885175
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p * q;
            }
        };
    '''
    jsi = JSInterpreter(code)
    obj = jsi.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](2, 3) == 6


# Generated at 2022-06-18 15:34:05.657820
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-18 15:34:15.963591
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:34:24.093047
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')

# Generated at 2022-06-18 15:34:32.712435
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_code = """
        var a = 'abc';
        var b = [1, 2, 3];
        var c = {
            'd': 'def',
            'e': [4, 5, 6],
            'f': function(g) {
                return g.join(',');
            }
        };
        var h = function(i) {
            return i.reverse();
        };
        var j = function() {
            return 'x';
        };
        var k = function(l, m) {
            return l + m;
        };
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.interpret_expression('a', {}) == 'abc'

# Generated at 2022-06-18 15:34:42.958710
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a;')([1, 2]) == 1
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a;return b;')([1, 2]) == 1
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a;return b;')([1, 2]) == 1


# Generated at 2022-06-18 15:35:22.082124
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            "b": function(p) {
                return p;
            },
            "c": function(p) {
                return -p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1) == -1


# Generated at 2022-06-18 15:35:31.635322
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:35:44.312063
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:35:55.370856
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:36:04.442150
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b;')
    assert func((1, 2)) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b;')
    assert func((1, 2)) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b;')
    assert func((1, 2)) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b;')

# Generated at 2022-06-18 15:36:16.210819
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-18 15:36:23.689629
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a + b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a + b; return a - b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'return a + b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; a - b')
    assert f((1, 2)) == 3

# Generated at 2022-06-18 15:36:28.219635
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a + b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a + b; return a - b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'return a + b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'return a + b; a - b')
    assert f((1, 2)) == 3

# Generated at 2022-06-18 15:36:38.700141
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b + c;')
    assert func((1, 2)) == 3

# Generated at 2022-06-18 15:36:49.905346
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b')
    assert func([1, 2]) == 3
    func