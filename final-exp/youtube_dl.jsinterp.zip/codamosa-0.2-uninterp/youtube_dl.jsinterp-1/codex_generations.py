

# Generated at 2022-06-18 15:28:01.057312
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:28:06.712262
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p, q) {
                return p + q;
            }
        }
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:28:19.864661
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a+b;return a-b;')
    assert func([1, 2]) == -1
    func = js_interpreter.build_function(['a', 'b'], 'return a+b;')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b;return a-b;')
    assert func([1, 2]) == 3

# Generated at 2022-06-18 15:28:25.971204
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:28:29.943419
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:28:35.563693
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b;')([1, 2]) == 3
    assert js_interpreter.build

# Generated at 2022-06-18 15:28:40.201232
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function f(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('f', 1, 2) == 3


# Generated at 2022-06-18 15:28:49.064237
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a + b; return a - b')([1, 2]) == -1
    assert js_interpreter.build_function(['a', 'b'], 'return a + b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b; a - b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b')([1, 2]) == 3
    assert js_interpre

# Generated at 2022-06-18 15:28:54.433437
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a*b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;return a*b')([1, 2]) == 3
    assert js_interpreter

# Generated at 2022-06-18 15:29:02.796997
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:29:33.113968
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {})[0] == 1
    assert js_interpreter.interpret_statement('var a = 1 + 2', {})[0] == 3
    assert js_interpreter.interpret_statement('var a = 1 + 2 + 3', {})[0] == 6
    assert js_interpreter.interpret_statement('var a = 1 + 2 + 3 + 4', {})[0] == 10
    assert js_interpreter.interpret_statement('var a = 1 + 2 + 3 + 4 + 5', {})[0] == 15
    assert js_interpreter.interpret_statement('var a = 1 + 2 + 3 + 4 + 5 + 6', {})[0] == 21
    assert js_interpreter.interpret_

# Generated at 2022-06-18 15:29:40.772375
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars) == (1, False)
    assert js_interpreter.interpret_statement('return a', local_vars) == (1, True)
    assert js_interpreter.interpret_statement('a + b', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('return a + b', local_vars) == (3, True)
    assert js_interpreter.interpret_statement('a + b + c', local_vars) == (6, False)

# Generated at 2022-06-18 15:29:53.438917
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    local_vars = {'a': 1, 'b': 2, 'c': 3}
    assert js_interpreter.interpret_statement('a', local_vars) == (1, False)
    assert js_interpreter.interpret_statement('a + b', local_vars) == (3, False)
    assert js_interpreter.interpret_statement('a + b - c', local_vars) == (0, False)
    assert js_interpreter.interpret_statement('a + b - c * 2', local_vars) == (-3, False)
    assert js_interpreter.interpret_statement('a + b - c * 2 + 1', local_vars) == (-2, False)
    assert js_interpreter.interpret_statement

# Generated at 2022-06-18 15:30:00.753492
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p){
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:30:03.389328
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(b, c) {
                return b + c;
            },
            "b": function(b, c) {
                return b - c;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:30:05.661483
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1


# Generated at 2022-06-18 15:30:11.436686
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:30:20.446528
# Unit test for method extract_object of class JSInterpreter

# Generated at 2022-06-18 15:30:29.219139
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p - q;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == -1


# Generated at 2022-06-18 15:30:38.032769
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    # Test 1
    code = '''
        var a = {
            "b": function(p) {
                return p;
            }
        };
        var c = a.b("d");
    '''
    interpreter = JSInterpreter(code)
    assert interpreter.interpret_expression('c', {}) == 'd'

    # Test 2
    code = '''
        var a = {
            "b": function(p) {
                return p;
            }
        };
        var c = a["b"]("d");
    '''
    interpreter = JSInterpreter(code)
    assert interpreter.interpret_expression('c', {}) == 'd'

    # Test 3

# Generated at 2022-06-18 15:31:01.086392
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = """
        function test(a, b) {
            return a + b;
        }
    """
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('test')
    assert f((1, 2)) == 3
    assert f((3, 4)) == 7


# Generated at 2022-06-18 15:31:08.192813
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p + 1;
            }
        };
    '''
    js = JSInterpreter(code)
    obj = js.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1) == 2


# Generated at 2022-06-18 15:31:14.262050
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:31:24.907096
# Unit test for method call_function of class JSInterpreter

# Generated at 2022-06-18 15:31:30.933085
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = """
    function test(a, b) {
        return a + b;
    }
    """
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function("test", 1, 2) == 3

if __name__ == '__main__':
    test_JSInterpreter_call_function()

# Generated at 2022-06-18 15:31:36.668615
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(code)
    f = js_interpreter.extract_function('test')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:31:46.098521
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:31:59.398396
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:32:03.937760
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        function test_function(a, b) {
            return a + b;
        }
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test_function', 1, 2) == 3


# Generated at 2022-06-18 15:32:11.311380
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js = JSInterpreter('')
    assert js.interpret_expression('1', {}) == 1
    assert js.interpret_expression('1 + 2', {}) == 3
    assert js.interpret_expression('1 + 2 * 3', {}) == 7
    assert js.interpret_expression('(1 + 2) * 3', {}) == 9
    assert js.interpret_expression('1 + (2 * 3)', {}) == 7
    assert js.interpret_expression('1 + 2 * 3 + 4', {}) == 11
    assert js.interpret_expression('1 + 2 * (3 + 4)', {}) == 15
    assert js.interpret_expression('(1 + 2) * (3 + 4)', {}) == 21
    assert js.interpret_expression('1 + 2 * 3 + 4 * 5', {}) == 26
    assert js

# Generated at 2022-06-18 15:32:33.575671
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    interpreter = JSInterpreter(code)
    assert interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:32:44.935012
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js = JSInterpreter('')
    f = js.build_function(['a', 'b'], 'return a + b;')
    assert f((1, 2)) == 3
    f = js.build_function(['a'], 'return a + 1;')
    assert f((1,)) == 2
    f = js.build_function(['a'], 'return a + 1;')
    assert f((1,)) == 2
    f = js.build_function(['a'], 'return a + 1;')
    assert f((1,)) == 2
    f = js.build_function(['a'], 'return a + 1;')
    assert f((1,)) == 2
    f = js.build_function(['a'], 'return a + 1;')

# Generated at 2022-06-18 15:32:55.150006
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a*b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;return a*b')([1, 2]) == 2
    assert js

# Generated at 2022-06-18 15:33:03.198254
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var obj = {
            "a": function(x) { return x + 1; },
            "b": function(x) { return x + 2; }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('obj')
    assert obj['a'](1) == 2
    assert obj['b'](1) == 3


# Generated at 2022-06-18 15:33:14.192387
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:33:19.411664
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        }
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:33:27.186435
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        function f(a, b) {
            return a + b;
        }
        function g(a, b) {
            return f(a, b);
        }
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('f', 1, 2) == 3
    assert js_interpreter.call_function('g', 1, 2) == 3


# Generated at 2022-06-18 15:33:33.575958
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p){
                return p;
            }
        };
    '''
    jsi = JSInterpreter(code)
    obj = jsi.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:33:40.780739
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:33:51.345396
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:35:32.853233
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('1+2*3+4', {}) == 11
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {}) == 21
    assert js_interpreter.interpret_expression('(1+2)*3+4', {}) == 13

# Generated at 2022-06-18 15:35:40.749324
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p, q) {
                return p + q;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1, 2) == 3


# Generated at 2022-06-18 15:35:49.823586
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
    var a = {
        b: function(c) {
            return c;
        },
        d: function(e, f) {
            return e + f;
        }
    };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['d'](1, 2) == 3


# Generated at 2022-06-18 15:35:55.044188
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p){
                return p;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:36:04.131200
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a+b;return a*b')
    assert func([1, 2]) == 2
    func = js_interpreter.build_function(['a', 'b'], 'return a+b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a+b;return a*b')
    assert func([1, 2]) == 3

# Generated at 2022-06-18 15:36:11.802077
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(arg1, arg2) {
                return arg1 + arg2;
            },
            "b": function(arg1, arg2) {
                return arg1 - arg2;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:36:18.336803
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p + 1;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](1) == 2


# Generated at 2022-06-18 15:36:24.996398
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'return a + b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b;')
    assert func((1, 2)) == 3
    func = js_interpreter.build_function(['a', 'b'], 'return a + b; return a - b; return a * b; return a / b;')

# Generated at 2022-06-18 15:36:28.525678
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        function test(a, b) {
            return a + b;
        }
    ''')
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:36:34.873414
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2
