

# Generated at 2022-06-18 15:27:47.540154
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    f = js_interpreter.extract_function('test')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:27:59.354038
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}, 100) == 1
    assert js_interpreter.interpret_expression('1+1', {}, 100) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}, 100) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}, 100) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}, 100) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}, 100) == 6

# Generated at 2022-06-18 15:28:02.501737
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = """
        function f(a, b) {
            return a + b;
        }
        function g(a, b) {
            return a * b;
        }
    """
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('f', 1, 2) == 3
    assert js_interpreter.call_function('g', 2, 3) == 6


# Generated at 2022-06-18 15:28:14.391862
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((2, 3)) == 6
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((2, 3)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((6, 3)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:28:22.610187
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        function a(x, y) {
            return x + y;
        }
        function b(x, y) {
            return x * y;
        }
        function c(x, y) {
            return a(x, y) + b(x, y);
        }
    ''')

    assert js_interpreter.call_function('a', 1, 2) == 3
    assert js_interpreter.call_function('b', 3, 4) == 12
    assert js_interpreter.call_function('c', 5, 6) == 33


# Generated at 2022-06-18 15:28:24.633943
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func((1, 2)) == 3

# Generated at 2022-06-18 15:28:30.635624
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(["a", "b"], "a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "a + b")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "a + b")(["1", "2"]) == "12"
    assert js_inter

# Generated at 2022-06-18 15:28:41.893158
# Unit test for method interpret_statement of class JSInterpreter
def test_JSInterpreter_interpret_statement():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_statement('var a = 1', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1;', {}) == (1, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2', {}) == (2, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2;', {}) == (2, False)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2; return', {}) == (None, True)
    assert js_interpreter.interpret_statement('var a = 1; var b = 2; return 3', {}) == (3, True)
   

# Generated at 2022-06-18 15:28:49.929754
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    jsi = JSInterpreter(code)
    obj = jsi.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:28:58.836267
# Unit test for method extract_function of class JSInterpreter
def test_JSInterpreter_extract_function():
    code = '''
        function func1(a, b) {
            return a + b;
        }
        var func2 = function(a, b) {
            return a + b;
        }
        var func3 = function func3(a, b) {
            return a + b;
        }
        var func4 = {
            "func4": function(a, b) {
                return a + b;
            }
        }
    '''
    js_interpreter = JSInterpreter(code)
    assert js_interpreter.call_function('func1', 1, 2) == 3
    assert js_interpreter.call_function('func2', 1, 2) == 3
    assert js_interpreter.call_function('func3', 1, 2) == 3
    assert js_interpre

# Generated at 2022-06-18 15:29:24.145577
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:29:34.294264
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3

    js_code = '''
        function test(a, b) {
            return a + b;
        }
        function test2(a, b) {
            return a * b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3
    assert js_interpreter.call_function('test2', 1, 2) == 2


# Generated at 2022-06-18 15:29:43.700391
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    code = '''
        function test(a, b, c) {
            var d = a + b;
            var e = c;
            var f = d + e;
            return f;
        }
    '''
    js_interpreter = JSInterpreter(code)
    func = js_interpreter.build_function(['a', 'b', 'c'], 'var d = a + b; var e = c; var f = d + e; return f;')
    assert func([1, 2, 3]) == 6


# Generated at 2022-06-18 15:29:57.005423
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+2', {}) == 3
    assert js_interpreter.interpret_expression('1+2+3', {}) == 6
    assert js_interpreter.interpret_expression('1+2*3', {}) == 7
    assert js_interpreter.interpret_expression('(1+2)*3', {}) == 9
    assert js_interpreter.interpret_expression('(1+2)*3+4', {}) == 13
    assert js_interpreter.interpret_expression('(1+2)*(3+4)', {}) == 21

# Generated at 2022-06-18 15:30:03.625098
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:30:05.783674
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test_function(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test_function', 1, 2) == 3


# Generated at 2022-06-18 15:30:09.637469
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        }
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1) == 1
    assert obj['c'](2) == 2


# Generated at 2022-06-18 15:30:16.905897
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:30:24.509297
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p){
                return p;
            },
            c: function(p){
                return p;
            }
        };
    '''
    js = JSInterpreter(code)
    obj = js.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:30:32.670302
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(arg1, arg2) {
                return arg1 + arg2;
            },
            "b": function(arg1, arg2) {
                return arg1 - arg2;
            }
        };
    '''
    obj = JSInterpreter(code).extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:31:07.811497
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p) { return p; },
            c: function(p) { return p; }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:31:18.416286
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter.interpret

# Generated at 2022-06-18 15:31:22.459200
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_interpreter = JSInterpreter('''
        function test(a, b) {
            return a + b;
        }
    ''')
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:31:26.585957
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("""
        function test(a, b) {
            var c = a + b;
            return c;
        }
    """)
    f = js_interpreter.build_function(["a", "b"], "var c = a + b; return c;")
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:31:35.156236
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    js_code = '''
        var a = {
            b: function(p) {
                return p;
            },
            c: function(p) {
                return p;
            }
        };
    '''
    js_interpreter = JSInterpreter(js_code)
    obj = js_interpreter.extract_object('a')
    assert obj['b']('test') == 'test'
    assert obj['c']('test') == 'test'


# Generated at 2022-06-18 15:31:43.065333
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    def resf(args):
        local_vars = dict(zip(['a', 'b'], args))
        for stmt in "a=b;return a+1;".split(';'):
            res, abort = js_interpreter.interpret_statement(stmt, local_vars)
            if abort:
                break
        return res
    assert js_interpreter.build_function(['a', 'b'], "a=b;return a+1;") == resf


# Generated at 2022-06-18 15:31:48.003145
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(x, y) {
                return x + y;
            },
            "b": function(x, y) {
                return x - y;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:31:57.520445
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p - q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == -1


# Generated at 2022-06-18 15:32:07.680641
# Unit test for method interpret_expression of class JSInterpreter
def test_JSInterpreter_interpret_expression():
    js_interpreter = JSInterpreter(code='')
    assert js_interpreter.interpret_expression('1', {}) == 1
    assert js_interpreter.interpret_expression('1+1', {}) == 2
    assert js_interpreter.interpret_expression('1+1+1', {}) == 3
    assert js_interpreter.interpret_expression('1+1+1+1', {}) == 4
    assert js_interpreter.interpret_expression('1+1+1+1+1', {}) == 5
    assert js_interpreter.interpret_expression('1+1+1+1+1+1', {}) == 6
    assert js_interpreter.interpret_expression('1+1+1+1+1+1+1', {}) == 7
    assert js_interpreter

# Generated at 2022-06-18 15:32:13.186571
# Unit test for method call_function of class JSInterpreter
def test_JSInterpreter_call_function():
    js_code = '''
        function test(a, b) {
            return a + b;
        }
    '''
    js_interpreter = JSInterpreter(js_code)
    assert js_interpreter.call_function('test', 1, 2) == 3


# Generated at 2022-06-18 15:34:42.077326
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    assert js_interpreter.build_function(['a', 'b'], 'a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'a+b;a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'a+b;return a*b')([1, 2]) == 2
    assert js_interpreter.build_function(['a', 'b'], 'return a+b')([1, 2]) == 3
    assert js_interpreter.build_function(['a', 'b'], 'return a+b;a*b')([1, 2]) == 3
    assert js_

# Generated at 2022-06-18 15:34:47.393666
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(arg1, arg2) {
                return arg1 + arg2;
            },
            "b": function(arg1, arg2) {
                return arg1 - arg2;
            }
        };
    '''
    interpreter = JSInterpreter(code)
    obj = interpreter.extract_object('obj')
    assert obj['a'](1, 2) == 3
    assert obj['b'](1, 2) == -1


# Generated at 2022-06-18 15:34:58.317371
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter("")
    assert js_interpreter.build_function(["a", "b"], "return a + b;")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b;")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b;")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b;")(["1", "2"]) == "12"
    assert js_interpreter.build_function(["a", "b"], "return a + b;")(["1", "2"])

# Generated at 2022-06-18 15:35:07.470701
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var obj = {
            "a": function(x) { return x + 1; },
            "b": function(x, y) { return x + y; },
            "c": function(x, y, z) { return x + y + z; }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('obj')
    assert obj['a'](1) == 2
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2, 3) == 6


# Generated at 2022-06-18 15:35:10.611280
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3


# Generated at 2022-06-18 15:35:17.323106
# Unit test for method interpret_expression of class JSInterpreter

# Generated at 2022-06-18 15:35:27.801463
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    f = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert f((1, 2)) == 3
    f = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert f((1, 2)) == -1
    f = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert f((1, 2)) == 2
    f = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert f((1, 2)) == 0.5
    f = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:35:39.558320
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('')
    func = js_interpreter.build_function(['a', 'b'], 'a+b')
    assert func([1, 2]) == 3
    func = js_interpreter.build_function(['a', 'b'], 'a-b')
    assert func([1, 2]) == -1
    func = js_interpreter.build_function(['a', 'b'], 'a*b')
    assert func([1, 2]) == 2
    func = js_interpreter.build_function(['a', 'b'], 'a/b')
    assert func([1, 2]) == 0.5
    func = js_interpreter.build_function(['a', 'b'], 'a%b')

# Generated at 2022-06-18 15:35:52.365705
# Unit test for method build_function of class JSInterpreter
def test_JSInterpreter_build_function():
    js_interpreter = JSInterpreter('', {})
    def test_func(argnames, code, expected_result):
        f = js_interpreter.build_function(argnames, code)
        result = f([])
        assert result == expected_result, '%s != %s' % (result, expected_result)
    test_func(['a'], 'a=1', 1)
    test_func(['a'], 'a=1;return a', 1)
    test_func(['a', 'b'], 'a=1;b=2;return a+b', 3)
    test_func(['a', 'b'], 'a=1;b=2;return a+b;return a', 3)

# Generated at 2022-06-18 15:35:57.685238
# Unit test for method extract_object of class JSInterpreter
def test_JSInterpreter_extract_object():
    code = '''
        var a = {
            b: function(p, q) {
                return p + q;
            },
            c: function(p, q) {
                return p - q;
            }
        };
    '''
    js_interpreter = JSInterpreter(code)
    obj = js_interpreter.extract_object('a')
    assert obj['b'](1, 2) == 3
    assert obj['c'](1, 2) == -1
