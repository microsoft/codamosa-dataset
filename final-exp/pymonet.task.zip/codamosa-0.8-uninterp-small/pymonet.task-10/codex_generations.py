

# Generated at 2022-06-26 00:05:52.003555
# Unit test for method map of class Task
def test_Task_map():
    def test_method_map_0(value):
        assert value == 1
        return 2

    task_0 = Task.of(1)
    actual_0 = task_0.map(test_method_map_0)

# Generated at 2022-06-26 00:06:00.899511
# Unit test for method bind of class Task
def test_Task_bind():
    sentinel = object()
    result = sentinel
    some_int = 10
    # check that bind map on resolved Task
    Task.of(some_int)\
        .map(lambda arg: arg + 1)\
        .map(lambda arg: arg - 1)\
        .bind(lambda arg: Task.of(arg))\
        .fork(
            lambda reject: None,
            lambda resolve: result if result == resolve else None
        )
    assert result == some_int

    # check that bind resolve
    Task.of(some_int)\
        .bind(lambda arg: Task.of(arg + 1))\
        .bind(lambda arg: Task.of(arg - 1))\
        .fork(
            lambda reject: None,
            lambda resolve: result if result == resolve else None
        )
    assert result == some_int

# Generated at 2022-06-26 00:06:02.489798
# Unit test for method map of class Task
def test_Task_map():
    assert(
        Task.of(0).map(lambda v: v + 1).fork(lambda e: e, lambda i: i)
        == 1
    )


# Generated at 2022-06-26 00:06:11.811735
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\x0e\x12;\x01\xf8\x0c\x87\xda\xf1\x9d\x1bF\xbf\x11\x83'

# Generated at 2022-06-26 00:06:17.777422
# Unit test for method bind of class Task
def test_Task_bind():
    def task(reject, resolve):
        resolve(2)

    def bind(value):
        assert value == 2
        return Task.of(4)

    task_0 = Task(task)
    # Task[resolve = 4]
    task_0 = task_0.bind(bind)
    assert task_0.fork(lambda arg: arg, lambda arg: arg) == 4



# Generated at 2022-06-26 00:06:22.998050
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xa4\xc9,'
    task_0 = Task(bytes_0)
    def fn_0():
        task_0.map(lambda x: print(x))
    bytes_1 = b'\xa4\xc9,'
    task_1 = Task(bytes_1)
    def fn_1():
        task_1.map(lambda x: print(x))

    assert task_0.map == task_1.map
    assert task_0.fork != task_1.fork
    assert fn_0 != fn_1


# Generated at 2022-06-26 00:06:31.906742
# Unit test for method bind of class Task
def test_Task_bind():
    def decorator_0(value):
        return (value + 1).to_bytes(1, 'big')

    bytes_0 = b'\xa4\xc9,'
    task_0 = Task.of(bytes_0)
    task_1 = task_0.bind(decorator_0)
    bytes_1 = b'\xa4\xc9,'
    assert (bytes_1 == task_0.fork(lambda arg: arg, lambda arg: arg)) is True
    assert (bytes_0 == task_1.fork(lambda arg: arg, lambda arg: arg)) is True
    assert (b'\xa5' == task_1.fork(lambda arg: arg, lambda arg: arg)) is True


# Generated at 2022-06-26 00:06:37.001412
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(b'\xa4')
    task_1 = task_0.bind(lambda x: Task.of(x + b'\xc9'))
    assert b'\xa4\xc9' == task_1.fork(None, None)
    assert task_1.fork(None, None) == task_0.fork(None, None) + b'\xc9'


# Generated at 2022-06-26 00:06:45.800774
# Unit test for method map of class Task
def test_Task_map():
    def fn_0(value):
        return value + 1

    def fn_1(value):
        return value * 2

    def fn_2(value):
        return value - 10

    expected_0 = 2
    expected_1 = 4
    expected_2 = 0

    task_0 = Task.of(1)

    assert task_0.map(fn_0).fork(lambda value: -1, lambda value: value) == expected_0
    assert task_0.map(fn_1).fork(lambda value: -1, lambda value: value) == expected_1
    assert task_0.map(fn_2).fork(lambda value: -1, lambda value: value) == expected_2


# Generated at 2022-06-26 00:06:50.248217
# Unit test for method bind of class Task
def test_Task_bind():
    import numpy as np
    np.random.seed(2233)
    bytes_0 = b'\xa4\xc9,'
    task_0 = Task.of(bytes_0)
    def fn_0(arg):
        return Task.of(arg.decode('utf-8'))
    def fn_1(arg):
        return Task.of(arg.encode('ascii'))
    task_1 = task_0.bind(fn_0)
    task_2 = task_1.bind(fn_1)
    def fork_0():
        def reject_0(arg):
            return Task.reject(arg)
        def resolve_0(arg):
            return Task.of(arg)
        return task_2.fork(reject_0, resolve_0)
    task_3 = fork

# Generated at 2022-06-26 00:06:58.848564
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2
    assert Task.reject(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 1
    assert Task.reject(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x + 1) == 1


# Generated at 2022-06-26 00:07:08.085029
# Unit test for method bind of class Task
def test_Task_bind():
    def print_resolve_reject(resolve, reject):
        print('resolve: %s' % str(resolve))
        print('reject: %s' % str(reject))

    def map_resolve_reject(resolve, reject):
        print('resolve: %s' % str(resolve))
        print('reject: %s' % str(reject))
        return resolve(resolve)

    def bind_resolve_reject(resolve, reject):
        print('resolve: %s' % str(resolve))
        print('reject: %s' % str(reject))
        return reject(resolve)

    test_Task_0 = Task(map_resolve_reject)


# Generated at 2022-06-26 00:07:18.010118
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_0(resolve, reject):
        def bind_0(resolve_0, reject_0):
            def bind_1(resolve_1, reject_1):
                resolve_0(resolve_1(reject_1(reject(0))))

            return Task(bind_1).map(lambda value_1: value_1 + 1).bind(lambda value_1: Task.of(value_1 + 2))

        resolve(Task(bind_0))

    def reject_0(resolve, reject):
        def bind_0(resolve_0, reject_0):
            def bind_1(resolve_1, reject_1):
                resolve_0(reject_1(resolve_1(reject(0))))


# Generated at 2022-06-26 00:07:28.121906
# Unit test for method bind of class Task
def test_Task_bind():
    class Test:
        def __init__(self):
            self.counter = 0

        def test(self):
            self.counter += 1
            return self.counter

    test = Test()
    def wrapper(value):
        test.test()
        return Task.of(value)

    task = Task.of(1).bind(wrapper).bind(wrapper)
    task.fork(lambda _: None, lambda _: None)

    assert test.counter == 2

if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-26 00:07:34.377832
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:07:41.040044
# Unit test for method bind of class Task
def test_Task_bind():
    """
    def bind(self, fn):
        """

# Generated at 2022-06-26 00:07:44.315736
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(0).map(lambda _: 0).fork(
        lambda _: False,
        lambda _: True
    )()
    assert Task.reject(1).map(lambda _: 0).fork(
        lambda _: True,
        lambda _: False
    )()


# Generated at 2022-06-26 00:07:48.494063
# Unit test for method map of class Task
def test_Task_map():
    def handle_error(error):
        return error
    assert Task.of(1).map(lambda x: x + 1).fork(handle_error, lambda x: x) == 2
    assert Task.reject(1).map(lambda x: x + 1).fork(lambda x: x, handle_error) == 1


# Generated at 2022-06-26 00:07:52.874034
# Unit test for method map of class Task
def test_Task_map():
    def test(a):
        return a ** 2

    assert Task.of(2).map(test).fork(None, lambda a: a) == 4


# Generated at 2022-06-26 00:08:00.850830
# Unit test for method bind of class Task
def test_Task_bind():

    # test_Task_bind_0: Task.of -> Task.map -> Task.bind
    def test_Task_bind_0():
        task_0 = Task.of(42)
        def add_one(n):
            return n + 1

        task_1 = task_0.map(add_one)
        def nothing(n):
            return n
        task_2 = task_0.bind(nothing)
        assert task_1.fork == task_2.fork

    test_Task_bind_0()

    # test_Task_bind_1: Task.of -> Task.bind -> Task.map
    def test_Task_bind_1():
        def nothing(n):
            return n
        task_0 = Task.of(42).bind(nothing)
        def add_one(n):
            return n + 1

# Generated at 2022-06-26 00:08:07.416164
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(42).bind(lambda arg: Task.of(arg + 1)).fork(lambda _: 'error', lambda arg: arg) == 43
    assert Task.of(42).bind(lambda arg: Task.reject(arg + 1)).fork(lambda arg: arg, lambda _: 'error') == 43
    assert Task.reject(42).bind(lambda _: Task.of(1)).fork(lambda arg: arg, lambda _: 'error') == 42



# Generated at 2022-06-26 00:08:13.892692
# Unit test for method map of class Task
def test_Task_map():
    def add_1(x): return x + 1

    task_0 = Task(None)
    task_1 = Task(None)

    # Skipping calling fork args due to not defined
    result = task_0.map(add_1).map(add_1)
    assert result is task_1


# Generated at 2022-06-26 00:08:21.219010
# Unit test for method map of class Task
def test_Task_map():
    def check_task_map(task_0, value_0):
        task_0 = task_0
        if (value_0 == task_0.map(lambda arg_0: str(arg_0)).fork(lambda arg_0: str(arg_0))):
            return True
        else:
            return False

    assert check_task_map(Task.of('\xa4\xc9,'), '\xa4\xc9,') == True
    assert check_task_map(Task.reject('\xa4\xc9,'), '\xa4\xc9,') == True


# Generated at 2022-06-26 00:08:25.571103
# Unit test for method bind of class Task
def test_Task_bind():
    from test_case_data import case_0, case_0_output
    task = Task.of(case_0[0])
    for transformation in case_0[1:]:
        task = task.bind(transformation)
    output = task.fork(
        lambda _: None,
        lambda arg: arg
    )
    assert case_0_output == output


# Generated at 2022-06-26 00:08:26.804194
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(0)

    task_0 = Task(fork)
    task_0.bind(lambda x: x)


# Generated at 2022-06-26 00:08:29.761280
# Unit test for method bind of class Task
def test_Task_bind(): 
    """
    Call bind for Task
    """
    def fn(arg):
        def result(reject, resolve):
            return resolve(arg)
        return Task(result)
    task = Task.of('aa') 
    assert task.bind(fn).fork(lambda x: None, lambda x: x) == 'aa'

# Generated at 2022-06-26 00:08:35.203351
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(b'\xa4\xc9,')
    print(task_0.fork)

    def fn(arg):
        print(arg)
        return Task.of(b'test')

    task_1 = task_0.bind(fn)
    print(task_1.fork)
    print(task_1.fork(None, None))



# Generated at 2022-06-26 00:08:41.508136
# Unit test for method map of class Task
def test_Task_map():
    # test call with None value
    assert_raises(TypeError, Task.of(1).map, None)

    # test error with wrong type of argument
    assert_raises(TypeError, Task.of(1).map, 1)

    # test error with wrong function signature
    assert_raises(TypeError, Task.of(1).map, lambda x: x)

    # test error with wrong function signature
    assert_raises(TypeError, Task.of(1).map, lambda x, y: x)


# Generated at 2022-06-26 00:08:50.483344
# Unit test for method bind of class Task
def test_Task_bind():
    import json
    bytes_0 = b'\xa4\xc9,'

    # test case 0
    print('test case 0')
    task_0 = Task.of(bytes_0)
    task_1 = task_0.bind(lambda bytes_0: Task.of(json.loads(bytes_0)))

    assert task_1 == {
        'fork': lambda reject, resolve: resolve(json.loads(bytes_0))
    }

    # test case 1
    print('test case 1')
    bytes_1 = b'{}'

    task_2 = Task.of(bytes_1)
    task_3 = task_2.bind(lambda bytes_1: Task.of(json.loads(bytes_1)))


# Generated at 2022-06-26 00:08:51.766174
# Unit test for method bind of class Task
def test_Task_bind():
    with pytest.raises(AttributeError):
        Task.bind(1, 2)



# Generated at 2022-06-26 00:09:00.557800
# Unit test for method map of class Task
def test_Task_map():
    base_0 = Task.of(1)
    def double_1(arg):
        return arg * 2
    double_0 = base_0.map(double_1)
    assert double_0.fork(
        lambda arg: 0,
        lambda arg: arg
    ) == 2



# Generated at 2022-06-26 00:09:07.418458
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case(expected, result_reject, result_resolve, arg_value):
        assert expected == \
               Task.of(arg_value).bind(lambda value:
                                       Task(lambda reject, resolve:
                                            result_reject(reject(value)) if value else
                                            result_resolve(resolve(value)))).fork(
                   lambda value: value,
                   lambda value: value
               )

    test_case(0, lambda arg: arg, lambda arg: arg, 0)
    test_case(1, lambda arg: arg, lambda arg: arg, 1)



# Generated at 2022-06-26 00:09:15.609751
# Unit test for method map of class Task
def test_Task_map():
    """
    map(self, fn):
        Take function, store it and call with Task value during calling fork function.
        Return new Task with result of called.

        :param fn: mapper function
        :type fn: Function(value) -> B
        :returns: new Task with mapped resolve attribute
        :rtype: Task[Function(resolve, reject) -> A | B]
    """

    # Create first mock
    def mock_fn_0(value):
        return None

    # Create second mock
    def mock_fn_1(resolve, reject):
        return None

    # Create task with the mock
    task_0 = Task(mock_fn_1)

    # Add the mock to the task
    task_0.map(mock_fn_0)

# Generated at 2022-06-26 00:09:18.596168
# Unit test for method map of class Task
def test_Task_map():
    def fn_0(value):
        return 0

    task_0 = Task.of(0)
    assert task_0.map(fn_0).fork(lambda x: 0, lambda x: 1) == 1


# Generated at 2022-06-26 00:09:26.552141
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task(lambda reject, resolve: resolve(14))
    task_1 = Task.of(14)

    assert task_0.bind(lambda v: v + 1) == task_1.bind(lambda v: str(v + 1))
    assert task_0.bind(lambda v: v * 2) == task_1.bind(lambda v: Task.of(v * 2))

    task_2 = Task(lambda reject, resolve: resolve(1))
    task_3 = Task(lambda reject, resolve: resolve(14))

    assert task_2.bind(lambda v: task_3.map(lambda v_new: v + v_new)) == task_3.bind(lambda v: Task.of(v * 1))

# Generated at 2022-06-26 00:09:35.920767
# Unit test for method bind of class Task
def test_Task_bind():
    # returned value is new Task with mapper resolve attribute
    bytes_0 = b'\xa4\xc9,'
    task_0 = Task(bytes_0)
    str_0 = str(task_0)
    task_1 = task_0.bind(lambda arg: arg)
    str_1 = str(task_1)

    # returned value is new Task with mapper resolve attribute
    bytes_1 = b'\xfb\xec\xa8\x87\xd1\xaa\xda\xcd \x87\xb0'
    task_2 = Task(bytes_1)
    str_2 = str(task_2)
    task_3 = task_2.bind(lambda arg: arg)
    str_3 = str(task_3)

    # returned value is new Task with mapper resolve attribute


# Generated at 2022-06-26 00:09:43.774339
# Unit test for method bind of class Task
def test_Task_bind():
    def dummy_fn(x):
        """
        Dummy function for testing, take only one argument,
        don't use it, return task, witch resolved null.
        """
        return Task.of(None)

    value_0 = 10
    task_0 = Task.of(value_0)
    task_1 = task_0.bind(dummy_fn)


# Generated at 2022-06-26 00:09:52.275722
# Unit test for method bind of class Task
def test_Task_bind():
    # test for valid call
    def fn_0(value: object) -> Task:
        def inner_fn(reject: object, resolve: object) -> object:
            return resolve(value)

        return Task(inner_fn)

    task_1 = Task.of(1)
    task_2 = Task.bind(task_1, fn_0)

    def resolve_0(value: object) -> object:
        return value

    def reject_0(value: object) -> object:
        return value

    task_2.fork(reject_0, resolve_0)
    # test for exception inside task during execution
    def fn_1(value: object) -> Task:
        def inner_fn(reject: object, resolve: object) -> object:
            return resolve(value)

        return Task(inner_fn)

   

# Generated at 2022-06-26 00:10:00.820995
# Unit test for method map of class Task
def test_Task_map():
    # Testing class Task method map with arguments {Function(*args) -> int}
    tuple_1 = (4, 5, 6)
    task_1 = Task.of(tuple_1)
    task_2 = task_1.map(sum)
    assert (task_2.fork(lambda arg_1: arg_1, lambda arg_2: arg_2)) == 15
    # Testing class Task method map with arguments {Function(value) -> B}
    # Testing class Task method map with argument {Function(reject, resolve) -> reject}
    tuple_3 = (4, 5, 6)
    task_3 = Task.reject(tuple_3)
    task_4 = task_3.map(sum)
    assert (task_4.fork(lambda arg_4: arg_4, lambda arg_5: arg_5))

# Generated at 2022-06-26 00:10:06.985149
# Unit test for method map of class Task
def test_Task_map():
    mock_fn = mock.MagicMock()
    mock_fork = mock.MagicMock()
    task_0 = Task(mock_fork)
    task_1 = task_0.map(mock_fn)
    assert task_0.fork == mock_fork
    assert task_1.fork != mock_fork
    assert task_1.fork(lambda arg: arg + 1, lambda arg: arg) == mock_fork()
    mock_fn.assert_called_once_with(mock_fork()[1])



# Generated at 2022-06-26 00:10:22.005207
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xcb\xc5\xc8\xb5\xd9\xb1\xcb\xc5\xc8\xb5\xd9\xb1\xd8\xf5\xd8\xbc\xc4\xbc'
    task_0: Task[bytes] = Task((lambda _, resolve: resolve(bytes_0)))
    def fn_0(arg_0: bytes) -> None:
        pass

    task_1 = task_0.map(fn_0)


# Generated at 2022-06-26 00:10:32.043746
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test of method bind of class Task
    """
    def id(x):
        return x

    def bind_f(x):
        return Task.of(id(id(x)))

    def bind_g(x):
        return Task.of(x)

    x_0 = 0


# Generated at 2022-06-26 00:10:40.042193
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        return Task.of(value)

    def reject(value):
        return Task.reject(value)

    def mapper(value):
        return value

    def resolved_with(value):
        t = Task.of(value)
        assert t.fork(reject, resolve) == Task.of(value)

    def rejected_with(value):
        t = Task.reject(value)
        assert t.fork(mapper, reject) == Task.reject(value)

    resolved_with(5)
    rejected_with(5)
    resolved_with('five')
    rejected_with('five')



# Generated at 2022-06-26 00:10:48.667378
# Unit test for method map of class Task
def test_Task_map():
    """
    This unit tests check if after calling map with function,
    Task return same value as function.
    """
    def check_result(result, value):
        if result == value:
            return True

        return False

    def add_one(value):
        return value + 1

    task_0 = Task.of(3)
    result_0 = task_0.map(add_one).fork(None, lambda a: a)
    assert check_result(result_0, 4)
    result_1 = task_0.map(lambda a: a + 1).fork(None, lambda a: a)
    assert check_result(result_1, 4)


# Generated at 2022-06-26 00:11:00.277026
# Unit test for method map of class Task
def test_Task_map():
    def double(x):
        return x * 2

    def is_odd(x):
        return x % 2 == 1

    res_of_is_odd = Task.of(2).map(is_odd).fork(
        print,
        print
    )
    res_of_double_is_odd = Task.of(2).map(double).map(is_odd).fork(
        print,
        print
    )

    def double_if_odd(x):
        if not is_odd(x):
            return Task.reject(x)

        return Task.of(x * 2)

    double_if_odd_task_result = Task.of(2).bind(double_if_odd).fork(
        print,
        print
    )


# Generated at 2022-06-26 00:11:04.830889
# Unit test for method map of class Task
def test_Task_map():
    # Create Task
    task_0 = Task.of(0)
    # Test method map
    assert task_0.map(lambda x: x+2).fork(
        lambda x: None,
        lambda x: x) == 2
    # Test method reject
    # assert Task.reject(0).map(lambda x: x+2).fork(
    #     lambda x: x,
    #     lambda x: x) == 0


# Generated at 2022-06-26 00:11:10.010568
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_0():
        str_0 = 'foo'
        task_0 = Task.of(str_0)
        def fn_0(str_1):
            str_2 = 'bar'
            str_3 = str_1 + str_2
            task_1 = Task.of(str_3)
            return task_1
        task_1 = task_0.bind(fn_0)


# Generated at 2022-06-26 00:11:12.094587
# Unit test for method map of class Task
def test_Task_map():

    def function_0(value):
        return 0

    task_0 = Task.of(0)
    task_1 = task_0.map(function_0)


# Generated at 2022-06-26 00:11:22.932587
# Unit test for method bind of class Task
def test_Task_bind():
    def should_return_reject_Task_0():
        error_0 = Exception(message='Error')

        def resolve(value):
            assert False

        def reject(value):
            assert value is error_0

        task_0 = Task(lambda reject, resolve: reject(error_0))

        return task_0.bind(lambda a: a)

    def should_raise_TypeError_0():
        def resolve(value):
            assert False

        def reject(value):
            assert False

        task_0 = Task(lambda reject, resolve: resolve(None))

        try:
            task_0.bind()
        except TypeError as error_0:
            assert isinstance(error_0.__str__(), str)
        else:
            assert False


# Generated at 2022-06-26 00:11:26.054448
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(1)
    task_1 = task_0.bind(lambda n: Task.of(n + 1))
    expected = Task.of(2)

    assert(task_1.fork(
        lambda reject: False,
        lambda value: value == expected.fork(
            lambda reject: False,
            lambda value: value
        )
    ))


# Generated at 2022-06-26 00:11:54.317057
# Unit test for method bind of class Task
def test_Task_bind():

    # Test method bind which returns Task with value.
    def fn_0(*args):
        return Task.of(None)

    task_0 = Task.reject(None)
    task_1 = task_0.bind(fn_0)

    # Test method bind which returns rejected Task.
    def fn_1(*args):
        return Task.reject(None)

    task_2 = Task.of(None)
    task_3 = task_2.bind(fn_1)

    # Test method bind which returns resolved Task.
    def fn_2(*args):
        return Task.of(None)

    task_4 = Task.of(None)
    task_5 = task_4.bind(fn_2)


# Generated at 2022-06-26 00:12:05.542534
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xa4\xc9,'
    task_0 = Task(bytes_0)
    float_0 = float()

    class MatchError0(Exception):
        def __init__(self):
            pass

    def test_case_0(reject):
        def test_case_1():
            class TestCase0():
                def __init__(self):
                    pass
            def test_case_0(arg_0):
                nonlocal float_0
                if (arg_0 == 4.6):
                    float_0 = arg_0
                else:
                    raise MatchError0()
            temp_0 = (
                (
                    task_0.bind(
                        test_case_0
                    )
                ).bind(
                    test_case_0
                )
            )

# Generated at 2022-06-26 00:12:06.325631
# Unit test for method map of class Task
def test_Task_map():
    pass


# Generated at 2022-06-26 00:12:12.956529
# Unit test for method bind of class Task
def test_Task_bind():
    def encode0(arg):
        def encode1(arg):
            def encode2(arg):
                return Task.of(arg + b'2')

            return Task.of(arg + b'1').bind(encode2)

        return Task.of(arg + b'0').bind(encode1)

    assert Task.of(b'.').bind(encode0).fork(lambda reject: False, lambda resolve: resolve) == b'.012'


# Generated at 2022-06-26 00:12:21.977061
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xa4\xc9,'
    task_0 = Task.of(bytes_0)
    def fn(a):
        return a * 3

    task_1 = task_0.map(fn)

    def mock_fork_0(reject, resolve):
        return resolve(bytes_0)
    task_0.fork = mock_fork_0

    def mock_fork_1(reject, resolve):
        return resolve(bytes_0 * 3)
    task_1.fork = mock_fork_1

    def fn_test():
        return task_1.fork(lambda a: a, lambda a: a)

    assert fn_test() == fn(bytes_0)

    mock_fork_0.assert_called_once_with(lambda a: a, lambda a: a)
    mock_

# Generated at 2022-06-26 00:12:30.000368
# Unit test for method map of class Task
def test_Task_map():
    """
    Check map(fn) method.
    """
    print("\nTesting Task.map()")
    # argument value
    bytes_0 = b'\xa4\xc9,'
    
    # mapper function
    def fn_0(value):
        print(value)
    # create Task and use map method
    task_0 = Task.of(bytes_0)
    task_1 = task_0.map(fn_0)
    # check result
    assert task_1.fork(
        lambda arg: None,
        lambda arg: None
    ) == task_0.fork(
        lambda arg: None,
        lambda arg: None
    )



# Generated at 2022-06-26 00:12:38.715884
# Unit test for method bind of class Task
def test_Task_bind():
    assert_equal(Task.of(1).bind(lambda x: Task.of(x)).fork(None, None), 1)

    assert_equal(
        Task.of(1).bind(lambda x: Task.of(x + 1)).fork(None, None),
        2
    )

    assert_equal(
        Task.of(1).bind(lambda x: Task.of(x + 2).bind(lambda y: Task.of(x + y))).fork(None, None),
        4
    )

    assert_equal(
        Task.of(1).bind(lambda x: Task.of(x + 2)).bind(lambda y: Task.of(y + 3)).fork(None, None),
        6
    )


# Generated at 2022-06-26 00:12:48.775263
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\x80\x03}q\x00U\x08unsignedq\x01K\x00U\x06signedq\x02K\x01u.'

    fn_0 = lambda bytes_0: Task.of(bytes_0)

    task_0 = Task.of(bytes_0)

    task_1 = task_0.bind(fn_0)

    value_0 = task_1.bind(lambda bytes_0: Task.of(bytes_0))

    result = (task_0, task_1, value_0)
    assert_true(bytes_0 is value_0.fork(lambda _, resolve: resolve(None), lambda _, resolve: resolve(None)).value)


# Generated at 2022-06-26 00:12:54.424448
# Unit test for method map of class Task
def test_Task_map():
    def check_mapper(mapper):
        print('mapper: ', mapper)
        assert mapper.__name__ == 'add_one'

    task_0 = Task.of(0).map(add_one)
    task_0.fork(
        lambda arg: check_mapper(arg),
        lambda arg: None
    )
    task_0.fork(
        lambda arg: None,
        lambda arg: check_mapper(arg)
    )


# Generated at 2022-06-26 00:12:56.910914
# Unit test for method map of class Task
def test_Task_map():
    task_of_1 = Task.of(1)
    assert task_of_1.map(lambda x: x + 1).fork(lambda x: 'rejected', lambda x: x) == 2



# Generated at 2022-06-26 00:13:53.420621
# Unit test for method bind of class Task
def test_Task_bind():

    def bytes_repr(bytes_):
        def _(reject, resolve):
            if isinstance(bytes_, bytes):
                resolve(repr(bytes_))
            else:
                reject(str(bytes_))

        return Task(_)

    def bytes_to_str(bytes_):
        def _(reject, resolve):
            if isinstance(bytes_, bytes):
                resolve(bytes_.decode())
            else:
                reject(str(bytes_))

        return Task(_)

    result_0 = Task(b'foo').bind(bytes_to_str).map(str.upper) \
        .bind(lambda s: Task.of(s + '!')).map(str.lower)
    result_1 = Task(b'foo').bind(bytes_repr)

# Generated at 2022-06-26 00:14:01.529927
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    task_0 = Task.of(None)
    task_1 = (
        task_0
        .bind(lambda _: Task.reject(None))
        .bind(lambda _: Task.of(None))
        .bind(lambda _: Task.reject(None))
    )

    task_2 = (
        task_0
        .bind(lambda _: Task.of(None))
        .bind(lambda _: Task.reject(None))
    )

    task_3 = (
        task_0
        .bind(lambda _: Task.of(None))
        .bind(lambda _: Task.of(None))
    )

    assert task_1.fork(lambda _: None, lambda _: None) == None
    assert task_

# Generated at 2022-06-26 00:14:06.820102
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xa4\xc9,'
    task_0 = Task(bytes_0)

    task_1 = task_0.map(lambda arg: arg.decode("utf-8"))

    bytes_1 = b'\xa4\xc9,'
    task_2 = Task.of(bytes_1)
    task_3 = task_2.map(lambda arg: arg.decode("utf-8"))

    assert task_1.fork == task_3.fork



# Generated at 2022-06-26 00:14:13.566334
# Unit test for method bind of class Task
def test_Task_bind():
    assert (
        Task.of('string')
        .bind(lambda x: Task.of(x + '_bind'))
        .fork(lambda x: x, lambda y: y)
    ) == 'string_bind'
    assert (
        Task.of(1)
        .bind(lambda x: Task.of(x + 1))
        .bind(lambda x: Task.of(x + 1))
        .fork(lambda x: x, lambda y: y)
    ) == 3
    assert (
        Task.reject(1)
        .bind(lambda x: Task.of(x + 1))
        .bind(lambda x: Task.of(x + 1))
        .fork(lambda x: x, lambda y: y)
    ) == 1



# Generated at 2022-06-26 00:14:17.963299
# Unit test for method bind of class Task
def test_Task_bind():
    def bytes_0(reject, resolve):
        resolve(b'\xa4\xc9,')
    task_0 = Task(bytes_0)
    assert isinstance(task_0.bind(len), Task)


# Generated at 2022-06-26 00:14:26.024474
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xa4\xc9,'
    task_0 = Task.of(bytes_0)
    task_1 = task_0.map(lambda arg: [arg])
    assert isinstance(task_1, Task)
    assert isinstance(task_1.fork, FunctionType)
    assert isinstance(task_1.fork(
        lambda arg: [arg],
        lambda arg: [arg]
    ), List)


# Generated at 2022-06-26 00:14:28.906410
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return 2 * value

    task_0 = Task.of(1)
    assert task_0.map(fn).fork(lambda x: None, lambda x: x) == 2

# Generated at 2022-06-26 00:14:36.227730
# Unit test for method map of class Task
def test_Task_map():
    # Test positive scenario
    def mock_reject(_):
        assert False

    def mock_resolve(arg):
        assert '42' == arg

    def mock_fork(reject, resolve):
        resolve(42)

    task_0 = Task(mock_fork)
    task_0.map(lambda value: str(value)).fork(mock_reject, mock_resolve)

    # Test negative scenario
    def mock_reject(reason):
        assert '42' == reason

    task_0 = Task(mock_fork)
    task_0.map(lambda value: raise_exception()).fork(mock_reject, mock_resolve)


# Generated at 2022-06-26 00:14:41.960747
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\x86\xc8\xed\xa2'
    bytes_1 = b'\x91F\xc9\xa6%\x93\x81m\xba\xeak\xdb\x93\x8b\x9d'
    def fn_0(value):
        return value / 2
    def fn_1(value):
        return Task.of(value + 2)
    def fn_2(value):
        return Task.reject(value - 1)

    task_0 = Task.of(bytes_0)
    task_1 = task_0.map(fn_0)
    assert task_1.fork(None, None) == b'\xc8\xed\xa2'

    task_2 = task_0.map(fn_1)
    assert task

# Generated at 2022-06-26 00:14:51.790902
# Unit test for method map of class Task
def test_Task_map():
  task_0 = Task.of(5)