

# Generated at 2022-06-26 00:05:48.531763
# Unit test for method map of class Task
def test_Task_map():
    pass


# Generated at 2022-06-26 00:05:57.923672
# Unit test for method bind of class Task
def test_Task_bind():
    # prepare
    def fn_0(arg):
        return Task.of(-float(arg))

    def fn_1(arg):
        return Task.reject(-float(arg))

    def fn_2(arg):
        return Task.of(arg)

    def fn_3(arg):
        return Task.reject(arg)

    # begin test
    task_0 = Task.of(float(0)).bind(fn_0)
    assert task_0.fork(lambda reject: reject, lambda resolve: resolve) == 0.0

    task_1 = Task.of(float(1)).bind(fn_1)
    assert task_1.fork(lambda reject: reject, lambda resolve: resolve) == -1.0

    task_2 = Task.of(float(-2)).bind(fn_2)
    assert task_2

# Generated at 2022-06-26 00:06:05.232346
# Unit test for method map of class Task
def test_Task_map():
    float_0 = -2004.7
    float_1 = 0.0
    float_2 = -1.0
    float_3 = -1.0
    float_4 = -2147483648.0
    float_5 = 1859165569.0
    float_6 = -2004.7
    float_7 = 0.0
    float_8 = -1.0
    float_9 = -1.0
    float_10 = -2147483648.0
    float_11 = 1859165569.0
    float_12 = -2004.7
    float_13 = 0.0
    float_14 = -1.0
    float_15 = -1.0
    float_16 = -2147483648.0
    float_17 = 1859165569.0
   

# Generated at 2022-06-26 00:06:15.990715
# Unit test for method map of class Task
def test_Task_map():
    float_0 = -2004.7
    float_1 = 2004.7
    float_2 = -2004.7
    float_3 = 2004.7
    float_4 = -2004.7
    float_5 = 2004.7
    float_6 = 2004.7
    float_7 = -2004.7
    float_8 = -2004.7
    float_9 = -2004.7
    float_10 = -2004.7
    float_11 = 2004.7
    float_12 = -2004.7
    float_13 = 2004.7
    float_14 = -2004.7
    float_15 = 2004.7
    float_16 = 2004.7

    def fn_0(arg_0):
        return float_0 - arg_0

    def fn_1(arg_0):
        return float_1

# Generated at 2022-06-26 00:06:19.646038
# Unit test for method bind of class Task
def test_Task_bind():
    def func_0(float_0):
        return Task(float_0)

    float_0 = -2004.7
    task_0 = Task(float_0)
    task_0_0 = task_0.bind(func_0)
test_Task_bind()


# Generated at 2022-06-26 00:06:24.599358
# Unit test for method bind of class Task
def test_Task_bind():
    init_task = Task.of(1)
    return_task = init_task.bind(lambda x: Task.of(x * 2))

# Generated at 2022-06-26 00:06:27.875164
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind(fn) should return Task
    """
    def wrapper(arg):
        def fn(value):
            return Task.of(value)
        return Task.bind(fn)
    wrapper(1)


# Generated at 2022-06-26 00:06:31.573054
# Unit test for method map of class Task
def test_Task_map():
    float_0 = -2004.7
    task_0 = Task.of(float_0)
    float_1 = float_0
    task_1 = task_0.map(lambda float_2: float_2)
    float_3 = float_1


# Generated at 2022-06-26 00:06:41.484157
# Unit test for method map of class Task
def test_Task_map():
    def test_case_0():
        float_0 = -2004.7
        task_0 = Task.of(float_0)
        task_1 = task_0.map(lambda num: num + 2001.1)
        task_1.fork(
            lambda arg: print('test_case_0: Rejected =>', arg),
            lambda arg: print('test_case_0: Resolved =>', arg)
        )

    def test_case_1():
        list_0 = [-1.9, -1.7, -0.4, 0.4, 1.4, 1.7, 1.8]
        task_0 = Task.of(list_0)
        task_1 = task_0.map(lambda nums: list(map(lambda num: num + 2.1, nums)))
        task_1

# Generated at 2022-06-26 00:06:44.484945
# Unit test for method map of class Task
def test_Task_map():
    float_0 = -2004.7
    task_0 = Task(lambda _, resolve: resolve(float_0))
    new_task_0 = task_0.map(lambda arg: arg / float_0)
    new_task_0.fork(
        lambda arg: None,
        lambda arg: arg * float_0
    )
    float_1 = float_0 / float_0
    float_1 = float_1 * float_0
    float_1 = float_1


# Generated at 2022-06-26 00:06:48.824874
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(1)
    task_1 = task_0.map(lambda v_0: 2 * v_0)
    assert task_1.fork(
        lambda error: error,
        lambda result: result + 0) == 2


# Generated at 2022-06-26 00:06:56.847600
# Unit test for method map of class Task
def test_Task_map():
    for i in range(0, 100):
        # Generate random value
        float_0 = -2004.7
        if type(float_0) != float:
            continue
        # Generate random function
        def fn_0(arg_0):
            return float(arg_0)
        if type(fn_0) != FunctionType:
            continue
        task_0 = Task.of(float_0)
        result_0 = task_0.map(fn_0)
        assert result_0.fork(lambda arg: None, lambda arg: None) == None


# Generated at 2022-06-26 00:07:06.600795
# Unit test for method map of class Task
def test_Task_map():
    float_0 = 0.0
    float_1 = -1.0
    float_2 = 2.0
    
    # Test 0
    def f_0(_, resolve):
        return resolve(float_0)

    task_0 = Task(f_0)
    task_1 = task_0.map((lambda value: Task(float_1)))
    assert isinstance(task_1, Task)
    assert task_1.fork((lambda value: True), (lambda value: not (value < Task(float_2))))

    # Test 1
    def f_1(_, resolve):
        return resolve(float_1)

    task_2 = Task(f_1)
    task_3 = task_2.map(lambda value: float_1)
    assert isinstance(task_3, Task)
    assert task_3

# Generated at 2022-06-26 00:07:08.730505
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(10) \
        .bind(lambda item: Task.of(item + 1)) \
        .fork(None, None)
    assert result == 11

# Generated at 2022-06-26 00:07:14.137195
# Unit test for method map of class Task
def test_Task_map():
    def task_reject(reject, resolve):
        return reject(0)

    def task_resolve(reject, resolve):
        return resolve(5)

    def double(value):
        return 2 * value

    def double_reject(reject, resolve):
        return reject(2 * reject)

    def double_resolve(reject, resolve):
        return resolve(2 * resolve)

    task_reject = Task(task_reject)
    task_resolve = Task(task_resolve)

    assert task_reject.map(double).fork(lambda arg: arg, lambda arg: arg) == 0
    assert task_resolve.map(double).fork(lambda arg: arg, lambda arg: arg) == 10



# Generated at 2022-06-26 00:07:25.123169
# Unit test for method bind of class Task
def test_Task_bind():
    float_0 = -2004.7
    float_1 = -2004.7
    float_2 = 381.41
    float_3 = -2004.7
    float_4 = -2004.7
    float_5 = -2004.7
    float_6 = -2004.7
    float_7 = -2004.7
    float_8 = -2004.7
    float_9 = -2004.7
    task_0 = Task.of(float_0)
    task_1 = Task.of(float_1)
    task_2 = Task.of(float_2)
    task_3 = Task.of(float_3)
    task_4 = Task.of(float_4)
    task_5 = Task.of(float_5)
    task_6 = Task.of(float_6)
   

# Generated at 2022-06-26 00:07:34.588641
# Unit test for method map of class Task
def test_Task_map():
    def test_0():
        float_0 = 23.8
        Task_0 = Task.of(float_0)
        Task_1 = Task_0.map(lambda value_0: value_0 > 1.0)
        exception_0 = None

# Generated at 2022-06-26 00:07:39.042997
# Unit test for method map of class Task
def test_Task_map():
    float_0 = 2.0
    def float_1(arg_1):
        float_2 = float(arg_1)
        float_3 = float_2 + float_2
        return float_3

    task_0 = Task.of(float_0)
    task_1 = task_0.map(float_1)
    assert task_1.fork(lambda arg: arg, lambda arg: None) == float_0 + float_0



# Generated at 2022-06-26 00:07:48.289839
# Unit test for method map of class Task
def test_Task_map():
    float_0 = 2.0
    float_1 = 3.0
    float_2 = (float_0 * float_0)
    def func_pt_0(value):
        return (value - float_1)
    def func_pt_1(value):
        return (value + float_1)
    task_0 = Task.of(float_0)
    task_1 = task_0.map(func_pt_0)
    task_2 = task_1.map(func_pt_1)
    func_2 = task_2.fork
    func_1 = func_2(lambda value_0: print('reject'), lambda value_0: print(value_0))
    func_0 = func_1(('Value: ', float_2))

    task_3 = Task.reject(float_0)

# Generated at 2022-06-26 00:07:56.752012
# Unit test for method bind of class Task
def test_Task_bind():

    # Case 0
    float_0 = -2004.7

    def func_0(arg_0):
        return arg_0

    task_0 = Task(func_0)

    task_0 = task_0.bind(lambda arg_0: Task(func_0))

    # Case 1
    float_0 = -2004.7

    def func_0(arg_0):
        return arg_0

    task_0 = Task(func_0)

    task_0 = task_0.bind(lambda arg_0: Task(func_0))

    # Case 2



# Generated at 2022-06-26 00:08:02.140486
# Unit test for method bind of class Task
def test_Task_bind():
    pass

# Generated at 2022-06-26 00:08:11.381550
# Unit test for method map of class Task
def test_Task_map():
    def test_map_0():
        def test_fn(arg):
            return arg + 1

        task = Task(lambda _, fn: fn(2004.7))
        task_0 = task.map(test_fn)
        value = task_0.fork(lambda arg: arg, lambda arg: arg)
        assert value == 2005.7

    def test_map_1():
        def test_fn(arg):
            return '{}'.format(arg)

        class Class:
            def __init__(self, a, b, c):
                self.a = a
                self.b = b
                self.c = c

        task = Task(lambda _, fn: fn(Class(1, 2, 3)))
        task_0 = task.map(test_fn)

# Generated at 2022-06-26 00:08:21.385505
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:08:29.322150
# Unit test for method bind of class Task
def test_Task_bind():
    float_1 = 0.
    float_2 = 3.3
    float_3 = 6.6
    float_4 = -1.
    task_1 = Task(lambda reject, resolve: resolve(float_2))
    task_2 = Task(lambda reject, resolve: resolve(float_4))
    task_3 = task_1.bind(lambda float_5: task_2.map(lambda float_6: float_6 / float_5))
    task_4 = task_1.bind(lambda float_7: task_3)
    task_3.fork(lambda float_8: 0., lambda float_9: float_9)
    task_4.fork(lambda float_10: 0., lambda float_11: float_11)
    #assert

# Generated at 2022-06-26 00:08:39.649243
# Unit test for method map of class Task
def test_Task_map():
    def mapper_0(arg):
        return abs(arg)

    def mapper_1(arg):
        return arg * 2

    def mapper_2(arg):
        return 42

    def mapper_3(arg):
        return arg * 0

    def mapper_4(arg):
        return 42 * 42

    def mapper_5(arg):
        return arg * 0 + 0

    def mapper_6(arg):
        return 42 * 0

    def mapper_7(arg):
        return 42 * 2 + 0

    def mapper_8(arg):
        return 42 * 0 + 2

    def mapper_9(arg):
        return (arg + 0) * 0

    float_0 = -2004.7
    float_1 = float('nan')
    float_2 = float('inf')


# Generated at 2022-06-26 00:08:41.792149
# Unit test for method map of class Task
def test_Task_map():
    def fn(arg):
        return arg ** 2

    assert Task.of(4).map(fn).fork(lambda arg: arg, lambda arg: arg) == 16


# Generated at 2022-06-26 00:08:47.879290
# Unit test for method map of class Task
def test_Task_map():
    """
    Test check, if method map function properly.

    If method map properly, then number of called fork function equal 0.
    """
    def my_map(value):
        return value + 1

    call_counter = 0
    def fork(reject, resolve):
        nonlocal call_counter
        call_counter += 1

        return reject(0)

    task = Task(fork)
    task.map(my_map)
    eq_(call_counter, 0, "method map did not work properly")


# Generated at 2022-06-26 00:08:51.955017
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task(lambda reject, resolve: resolve("number"))
    task_1 = task_0.bind(lambda arg: Task(lambda reject, resolve: resolve(int(arg))))
    task_2 = task_1.bind(lambda arg: Task(lambda reject, resolve: resolve(arg + 2008)))

    assert task_2.fork(lambda arg: arg, lambda arg: arg) == 2008


# Generated at 2022-06-26 00:09:02.736756
# Unit test for method map of class Task
def test_Task_map():
    def multiply_by_two(value):
        return value * 2

    def square(value):
        return value ** 2

    def add_values(accumulator, value):
        return accumulator + value

    def print_value(value):
        print(value)

    def print_error(error):
        print(error)

    float_0 = 0.0
    float_1 = -104.0
    float_12 = 12.0
    float_13 = 13.0
    float_24 = 24.0

    task_0 = Task.of(float_0)
    task_mapped_13 = task_0.map(multiply_by_two)
    task_mapped_24 = task_mapped_13.map(add_values).map(square)


# Generated at 2022-06-26 00:09:06.642522
# Unit test for method map of class Task
def test_Task_map():
    float_0 = -2004.7
    task_1 = Task(float_0)
    def callback_0(arg_0):
        return arg_0
    task_2 = task_1.map(callback_0)
    t = task_2.fork(lambda x: False, lambda x: True)


# Generated at 2022-06-26 00:09:23.710061
# Unit test for method map of class Task
def test_Task_map():
    float_0 = -115.83
    float_1 = -39.215
    float_2 = -115.83
    float_3 = -39.215

    def fn(float_3):
        return float_3 * float_0

    task_0 = Task(float_0)
    task_1 = task_0.map(fn)
    assert math.isclose(float_1, task_1.fork(None, None), abs_tol=0.0001)
    assert math.isclose(float_2, task_0.fork(None, None), abs_tol=0.0001)


# Generated at 2022-06-26 00:09:25.188404
# Unit test for method bind of class Task
def test_Task_bind():
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-26 00:09:31.170465
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind in class Task
    """
    float_0 = -2004.7
    task_0 = Task.of(float_0)
    def func_0(task_0):
        return task_0.map(lambda val_0: val_0 * 0.06)
    task_1 = task_0.bind(func_0)
    assert task_1.fork(lambda val_1: None, assertAlmostEqual(-120.282, val_1))


# Generated at 2022-06-26 00:09:40.196132
# Unit test for method map of class Task
def test_Task_map():
    def divide_by_two(x):
        return x / 2

    def multiply_by_two(x):
        return x*2

    def plus_three(x):
        return x + 3

    def plus_five(x):
        return x + 5

    def plus_six(x):
        return x + 6

    t0 = Task.of(1)
    t1 = t0.map(divide_by_two).map(multiply_by_two)
    t2 = t0.map(divide_by_two).map(multiply_by_two)
    t3 = t0.map(divide_by_two).map(multiply_by_two).map(plus_three)

# Generated at 2022-06-26 00:09:49.601557
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value**2.

    def assert_func(value):
        required_result = mapper(value)
        task_0 = Task.of(value)
        task_1 = task_0.map(mapper)
        fork_result = task_1.fork(lambda arg: arg, lambda arg: arg)
        assert fork_result == required_result

    value_arr = [
        float_0, float_1, float_2, float_3, float_4, float_5, float_6,
        float_7, float_8, float_9, float_10, float_11, float_12, float_13,
        float_14, float_15, float_16, float_17, float_18, float_19
    ]


# Generated at 2022-06-26 00:09:55.025854
# Unit test for method bind of class Task
def test_Task_bind():
    def hello(name):
        return Task.of('Hello, ' + name + '!')

    def get_name():
        return Task.of('World')

    _helloworld = Task.of('').bind(lambda name: hello(name))

    return _helloworld.fork(
        lambda a: False,
        lambda b: b == 'Hello, World!'
    )


# Generated at 2022-06-26 00:10:01.950004
# Unit test for method bind of class Task
def test_Task_bind():
    def float_0(a1, a2):
        return a1 / a2

    def task_0(reject, resolve):
        return resolve(float_0(-2004.7, 12.0))

    def task_1(reject, resolve):
        return resolve(float_0(-2004.7, 6.0))

    def task_0_0(reject, resolve):
        return resolve(float_0(float_0(-2004.7, 12.0), 1.0))

    def task_0_1(reject, resolve):
        return resolve(float_0(float_0(-2004.7, 12.0), 0.5))

    def task_2(reject, resolve):
        return resolve(float_0(-2004.7, 1.0))


# Generated at 2022-06-26 00:10:11.975303
# Unit test for method bind of class Task
def test_Task_bind():
    # Testing when input value is a negative number
    neg_float = -2004.7
    def increment_neg_float(neg_float):
        return Task(lambda _, resolve: resolve(neg_float + 1))
    task_neg_float = Task(lambda _, resolve: resolve(neg_float))
    new_task_neg_float = task_neg_float.bind(increment_neg_float)
    resolved_neg_float = new_task_neg_float.fork(lambda x: x, lambda x: x)
    assert resolved_neg_float == -2003.7
    
    # Testing when input value is a positive number
    pos_float = 2004.7
    def increment_pos_float(pos_float):
        return Task(lambda _, resolve: resolve(pos_float + 1))

# Generated at 2022-06-26 00:10:15.060313
# Unit test for method bind of class Task
def test_Task_bind():
    def get_number(number):
        return Task(number)

    assert Task.of(99).bind(get_number).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 99



# Generated at 2022-06-26 00:10:21.444206
# Unit test for method bind of class Task
def test_Task_bind():
    # bind with not callable argument
    assert Task(lambda _, resolve: resolve(-23.5)).bind("not callable")
    # bind with not instance of Task class
    assert Task(lambda _, resolve: resolve(-23.5)).bind(lambda arg: arg)

    # bind with callable argument, who return new Task
    def mapper(arg):
        return Task(lambda _, resolve: resolve(arg))

    assert Task(lambda _, resolve: resolve(-23.5)).bind(mapper).fork(
        lambda arg: isinstance(arg, float),
        lambda arg: isinstance(arg, float)
    )

# Generated at 2022-06-26 00:10:42.790007
# Unit test for method bind of class Task
def test_Task_bind():
    def mock_fork(reject, resolve):
        return None

    def mock_fn(value):
        return None

    task_0 = Task(mock_fork)
    task_0.bind(mock_fn)


# Generated at 2022-06-26 00:10:48.260270
# Unit test for method bind of class Task
def test_Task_bind():
    # Case 0:
    int_0 = 6
    task_0 = Task.of(int_0)
    def mapper_0(arg_0):
        return Task.of(arg_0 + 1)

    task_1 = task_0.bind(mapper_0)
    assert type(task_1) == Task
    assert type(task_1.fork) == FunctionType


# Generated at 2022-06-26 00:10:56.749822
# Unit test for method map of class Task
def test_Task_map():
    # Example from docs
    # map :: (a -> b) -> Task[a] -> Task[b]
    def double(x):
        return x * 2

    task_double = Task.of(2).map(double)
    assert task_double.fork(lambda reject_: reject_, lambda resolve_: resolve_) == 4

    # Additional test
    def triple(y):
        return y * 3

    task_triple = Task.of(5).map(triple)
    assert task_triple.fork(lambda reject_: reject_, lambda resolve_: resolve_) == 15


# Generated at 2022-06-26 00:11:02.756837
# Unit test for method map of class Task
def test_Task_map():
    print("Unit test for method map of class Task")

    # Test case 0
    print("Test case 0")
    fork_0 = lambda _, resolve: resolve(1)
    task_0 = Task(fork_0)
    fn_0 = lambda arg: arg + arg
    task_0_map_0 = task_0.map(fn_0)
    assert task_0_map_0 is not None


# Generated at 2022-06-26 00:11:05.251907
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of("Hello")
    def fn_0(value):
        def result(reject, resolve):
            return resolve("World")
        return Task(result)

    task_0 = task.bind(fn_0)


# Generated at 2022-06-26 00:11:09.708256
# Unit test for method map of class Task
def test_Task_map():
    # Creating object Task
    object_Task = Task.bind(lambda: 44)
    object_Task_res = object_Task.map(lambda _: _ + 1)
    assert object_Task_res == Task.bind(lambda: 44 + 1)

if __name__ == '__main__':
    test_case_0()
    test_Task_map()

# Generated at 2022-06-26 00:11:20.204009
# Unit test for method map of class Task
def test_Task_map():
    is_passed = True
    # test lambda float value
    float_0 = -2004.7
    task_0 = Task.of(float_0)
    test_0 = task_0.map(lambda x: x + 1.3)
    is_passed = is_passed and (test_0.fork(lambda x: x, lambda x: x) == task_0.fork(lambda x: x, lambda x: x) + 1.3)

    # test lambda string value
    string_0 = "test"
    task_1 = Task.of(string_0)
    test_1 = task_1.map(lambda x: x.replace("s", "c"))

# Generated at 2022-06-26 00:11:27.787093
# Unit test for method map of class Task
def test_Task_map():
    float_0 = 5.4739561729
    float_1 = 0.45
    float_2 = -60.923
    float_3 = 5.30
    float_4 = -1.0
    float_5 = -1450.8
    float_6 = -1539.1087
    float_7 = 0.0
    task_0 = Task.of(float_1)
    task_1 = Task.of(float_2)
    task_2 = task_1.map(
        lambda x_0: Task.of(
            ((float(x_0) + float(-2.5585)) * float(float_4))))
    task_3 = Task.of(float_3)

# Generated at 2022-06-26 00:11:32.440427
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_0(value_0):
        """
        :param value_0:
        :type value_0: Any
        :returns: Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(2)

    Task.of(1).bind(fn_0)


# Generated at 2022-06-26 00:11:41.933160
# Unit test for method map of class Task
def test_Task_map():

    def add_5(x):
        return x + 5

    def div_5(x):
        return x / 5

    def mul_5(x):
        return x * 5

    def sub_5(x):
        return x - 5

    # test case 0
    int_0 = 42
    task_0 = Task.of(int_0)
    task_1 = task_0.map(add_5).map(div_5).map(mul_5).map(sub_5)

# Generated at 2022-06-26 00:12:28.401233
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    task_0 = Task(lambda reject, resolve: resolve(5))
    task_1 = task_0.map(add_one)
    assert task_1.fork(lambda value: value, lambda value: value) == 6

    task_2 = Task(lambda reject, resolve: reject(5))
    task_3 = task_2.map(add_one)
    assert task_3.fork(lambda value: value, lambda value: value) == 5


# Generated at 2022-06-26 00:12:34.984530
# Unit test for method bind of class Task
def test_Task_bind():
    assert_repr_equal(
        Task.of(1).bind(lambda arg: Task.of(arg + 2)).fork(lambda _: _, lambda _: _),
        3
    )

    assert_repr_equal(
        Task.reject(1).bind(lambda _: Task.of(2)).fork(lambda arg: arg, lambda _: _),
        1
    )

    assert_repr_equal(
        Task.reject(1).bind(lambda _: Task.reject(2)).fork(lambda arg: arg, lambda _: _),
        1
    )

# Generated at 2022-06-26 00:12:38.317509
# Unit test for method bind of class Task
def test_Task_bind():
    # Test case 0
    float_0 = -2004.7
    def lambda_arg_0(arg_0):
        return Task(arg_0)
    task_0 = Task(float_0)
    task_1 = task_0.bind(lambda_arg_0)


# Generated at 2022-06-26 00:12:44.314407
# Unit test for method map of class Task
def test_Task_map():
    number = 5
    str_number = str(number)
    task_0 = Task.of(number)
    task_1 = task_0.map(str)
    result = task_1.fork(lambda _: None, lambda arg: str(arg))
    assert result == str_number, "test_case_1"


# Generated at 2022-06-26 00:12:47.923594
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.reject(0)
    task_1 = task_0.bind(lambda value: Task.of(value + 1))
    result_0 = task_1.fork(lambda value: False, lambda value: True)
    assert result_0


# Generated at 2022-06-26 00:12:52.457427
# Unit test for method bind of class Task
def test_Task_bind():
    for float_0 in [1.526156986, 0.539134494, -0.21003958, -0.37669024, -0.53190914]:
        assert Task(float_0).bind(lambda float_1: Task(float_1)).fork(float_0, float_0) == (float_0, float_0)


# Generated at 2022-06-26 00:13:00.675927
# Unit test for method map of class Task
def test_Task_map():

    def test_0():
        float_0 = -965.34
        float_1 = -40.48
        float_2 = 939.73
        float_3 = -9669.35
        float_4 = -8359.21
        float_5 = -6514.95
        float_6 = 80.92
        float_7 = -8626.88
        float_8 = -6776.79
        float_9 = -5927.5

        def func_74(arg_0):
            float_16 = 2.3
            float_17 = 3.2
            float_18 = 4.5
            float_19 = 5.6
            float_20 = 5.6
            float_21 = 7.9
            float_22 = 9.8
            float_23 = 13.2
            float_

# Generated at 2022-06-26 00:13:09.718018
# Unit test for method map of class Task
def test_Task_map():
    def test_0():
        # Task.of(1) => Map(lambda arg: arg+1) => 2
        task_0 = Task.of(1.0)
        task_1 = task_0.map(lambda arg: arg + 1)
        assert type(task_1) == Task
        assert task_1.fork(None, lambda arg: arg) == 2.0

    def test_1():
        # Task.of(1) => Map(lambda arg: arg+1) => 2
        task_0 = Task.reject("error")
        task_1 = task_0.map(lambda arg: arg + 1)
        assert type(task_1) == Task
        assert task_1.fork(
            lambda arg: arg,
            lambda arg: None
        ) == "error"

    test_0()
   

# Generated at 2022-06-26 00:13:18.642632
# Unit test for method map of class Task
def test_Task_map():
    # data from task context
    float_0 = -2004.7
    task_0 = Task.reject(float_0)
    # data for check result
    float_1 = 1904.7
    expected_value_0 = Task.reject(float_1)

    # call method map
    actual_value_0 = task_0.map(lambda arg: -arg)

    # check result
    assert actual_value_0 == expected_value_0

    # data from task context
    int_0 = 1993987
    task_1 = Task.of(int_0)
    # data for check result
    str_0 = '1993987'
    expected_value_1 = Task.of(str_0)

    # call method map
    actual_value_1 = task_1.map(str)

    # check

# Generated at 2022-06-26 00:13:24.916770
# Unit test for method bind of class Task
def test_Task_bind():

    # Test 1
    # Task as map function
    float_0 = -2004.7
    task_0 = Task.reject(float_0)
    task_1 = task_0.bind(Task.of)
    assert task_1.fork(
        lambda arg_0: isinstance(arg_0, float) and arg_0 == float_0,
        lambda arg_0: False
    )

    # Test 2
    # Task as reject function
    float_0 = -2004.7
    task_0 = Task.of(float_0)
    task_1 = task_0.bind(Task.reject)
    assert task_1.fork(
        lambda arg_0: isinstance(arg_0, float) and arg_0 == float_0,
        lambda arg_0: False
    )

    # Test

# Generated at 2022-06-26 00:15:07.208096
# Unit test for method map of class Task
def test_Task_map():
    def round(value):
        return int(float(value))
    assert Task.of(123.5).map(round).fork(None, lambda x: x) == 123


# Generated at 2022-06-26 00:15:15.474142
# Unit test for method map of class Task
def test_Task_map():
    is_float_0 = 0.2
    float_0 = -2004.7
    float_mapper = lambda float_0: float_0 * float_0
    task_0 = Task(float_0)
    task_1 = Task.of(is_float_0)
    task_0_mapped = task_0.map(float_mapper)
    task_1_mapped = task_1.map(float_mapper)
    return (task_0_mapped.fork(lambda is_float_0: is_float_0, lambda is_float_0: is_float_0)==float_mapper(float_0))

task_0_mapped = Task(test_case_0).map(test_Task_map)

# Generated at 2022-06-26 00:15:18.022837
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:15:25.281334
# Unit test for method map of class Task
def test_Task_map():
    float_0 = -2004.7
    float_1 = 0.0
    float_2 = 1009.0
    float_3 = 2.0
    float_4 = 5.0
    float_5 = 0.0
    float_6 = -15.0
    float_7 = -2.0
    float_8 = 1e-06
    float_9 = -5.0

    def inner_0(value):
        return value * float_3

    def inner_1(value):
        return value - float_2

    def inner_2(value):
        return value * float_4

    task_0 = Task(float_0)
    task_1 = task_0.map(lambda x: x * float_1)

# Generated at 2022-06-26 00:15:28.786797
# Unit test for method bind of class Task
def test_Task_bind():
    task_of_zero = Task.of(0)
    assert task_of_zero.bind(lambda x: Task.of(x + 1)).fork(None, None) == 1
    assert task_of_zero.bind(Task.reject).fork(None, None) == None
    task_of_zero.bind(lambda x: x + Task.of(2))


# Generated at 2022-06-26 00:15:32.118395
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task(lambda reject, resolve: resolve(2))
    task_1 = task_0.bind(lambda x: Task.of(x + 5))
    assert 7 == task_1.fork(lambda err: 0, lambda val: val)


# Generated at 2022-06-26 00:15:39.132527
# Unit test for method map of class Task
def test_Task_map():
    mapper = lambda value: value * 100

    float_0 = -2004.7
    task_0 = Task(lambda reject, resolve: resolve(float_0))

    task_0_mapped = task_0.map(mapper)
    assert task_0_mapped.fork(None, None) == float_0 * 100

    task_0_mapped = task_0.map(mapper).map(mapper)
    assert task_0_mapped.fork(None, None) == (float_0 * 100) * 100

    float_1 = -2004.3
    task_1 = Task(lambda reject, resolve: resolve(float_1))

    task_1_mapped = task_1.map(mapper)
    assert task_1_mapped.fork(None, None) == float_1 * 100

   

# Generated at 2022-06-26 00:15:45.684153
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map function of class Task
    """
    def assert_equal(got, expected):
        assert got == expected, "Got {0}, expected {1}".format(str(got), str(expected))

    def assert_not_equal(got, expected):
        assert got != expected, "Got {0}, expected not {0}".format(str(got))

    def assert_error(tag, fn, *args):
        try:
            fn(*args)
        except Exception as e:
            return
        assert False, "{0}: no error generated".format(tag)

    class Dummy_A:
        def __init__(self, v):
            self.value = v

        def __repr__(self):
            return "Dummy_A({0})".format(self.value)
