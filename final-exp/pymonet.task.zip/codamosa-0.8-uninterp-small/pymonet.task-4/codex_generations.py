

# Generated at 2022-06-26 00:05:49.874444
# Unit test for method map of class Task
def test_Task_map():
    def f():
        pass

    def g():
        pass

    def h():
        pass

    result = Task(f)
    result = result.map(g)
    result = result.map(h)


# Generated at 2022-06-26 00:05:56.837546
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test case for Task.bind method
    """

    t1 = Task(lambda reject, _: reject('failure'))

    assert_that(
        t1.bind(lambda arg: Task.of(arg + '!!!')).fork(lambda arg: arg, lambda arg: arg),
        equal_to('failure')
    )

    assert_that(
        t1.bind(lambda arg: Task.of(arg + '!!!')).fork(lambda arg: arg, lambda arg: arg),
        not_(equal_to('failure!!!'))
    )



# Generated at 2022-06-26 00:06:04.534251
# Unit test for method map of class Task
def test_Task_map():
    def test_0():
        """
        :param fn:
        :type fn: Function(value) -> B
        :returns:
        :rtype:
        """
        task_0 = Task.of(2)

        def fn_0(value):
            return value * 2

        task_0 = task_0.map(fn_0)

        def fork_0(reject, resolve):
            def resolve_0(value):
                assert value == 4
                return
            return resolve(task_0.fork(reject, resolve_0))

# Generated at 2022-06-26 00:06:13.391477
# Unit test for method map of class Task
def test_Task_map():
    from_string = 'foo'
    to_string = 'bar'

    from_string_to_string_Task = Task.of(from_string).map(
        lambda _: to_string
    )

    assert from_string_to_string_Task.fork(lambda _: None, lambda result: result) is to_string

    task_string = 'foo'
    mapped_string = 'bar'
    String_to_String_Task = Task.of(task_string).map(lambda _: mapped_string)

    assert String_to_String_Task.fork(lambda _: None, lambda result: result) is mapped_string


# Generated at 2022-06-26 00:06:20.390943
# Unit test for method bind of class Task
def test_Task_bind():
    def valid(value):
        return Task.of(value * 2)
    def invalid(value):
        return Task.reject(value * 2)

    task_0 = Task.of(2)
    task_1 = task_0.bind(valid)
    assert isinstance(task_1, Task)
    assert task_1.fork(lambda x: None, lambda x: x) == 4
    task_2 = task_0.bind(invalid)
    assert isinstance(task_2, Task)
    assert task_2.fork(lambda x: x, lambda x: None) == 4



# Generated at 2022-06-26 00:06:26.312906
# Unit test for method map of class Task
def test_Task_map():
    def id(arg):
        return arg

    assert Task.of(1).map(id).fork(lambda _: False, lambda value: value == 1)
    assert Task.reject(1).map(id).fork(lambda value: value == 1, lambda _: False)


# Generated at 2022-06-26 00:06:31.817832
# Unit test for method map of class Task
def test_Task_map():
    """
    Test mapping of tasks with resolved and rejected results.
    """
    assert Task(lambda _, resolve: resolve(1)).map(lambda i: i + 1).fork(
        lambda _: False,
        lambda i: i == 2
    )

    assert Task(lambda reject, _: reject(1)).map(lambda i: i + 1).fork(
        lambda i: i == 1,
        lambda _: False
    )


# Generated at 2022-06-26 00:06:41.767740
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    bytes_1 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    bytes_2 = b'\x1c\x05\x19\xe7\x17\x00\x0e\x13\x9e\xfc\xe8\x16\x18\xec\x16'
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = 0

    # Testing method bind of class Task

# Generated at 2022-06-26 00:06:51.228891
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_0 = Task(bytes_0)
    task_1 = Task.of(bytes_0)
    def fn_0(arg_0):
        return arg_0
    def fn_1(arg_0):
        return fn_0(arg_0)
    def fn_2(arg_0):
        def fn_3(arg_0):
            return arg_0
        return fn_3(arg_0)
    task_2 = task_0.map(fn_2)
    task_3 = task_1.map(fn_1)


# Generated at 2022-06-26 00:06:59.880680
# Unit test for method map of class Task
def test_Task_map():
    """
    Call str() on value wrapped by Task.
    """
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    bytes_1 = bytes_0
    function_0 = Task.of(bytes_1).map(str)
    bytes_2 = function_0.fork(None, None)
    assert bytes_2 == b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'


# Generated at 2022-06-26 00:07:05.411392
# Unit test for method bind of class Task
def test_Task_bind():
    a = Task.of(1)
    b = a.bind(lambda x: Task.of(x + 1))
    assert b.fork(None, lambda r: r) == 2

## Unit test for method map of class Task

# Generated at 2022-06-26 00:07:10.992027
# Unit test for method map of class Task
def test_Task_map():
    def assert_0(task_0, expected_0):
        def _fn_0(reject, _):
            return reject('error')

        def _fn_1(reject, resolve):
            return resolve('Task.fork')

        task_0.fork = _fn_0
        task_1.fork = _fn_1
        assert_1(task_0.map(lambda arg: reject(arg)), expected_0)
        assert_1(task_1.map(lambda arg: resolve(arg)), expected_0)



# Generated at 2022-06-26 00:07:21.570601
# Unit test for method map of class Task
def test_Task_map():
    def add_num(num):
        return num + 10

    def sub_num(num):
        return num - 10

    # Case 0 - check result of map func with add_num
    task_0 = Task.of(100)
    task_0_1 = task_0.map(add_num)

    assert 110 == task_0_1.fork(lambda x: x, lambda x: x)

    # Case 1 - check result of mapper func with sub_num
    task_1 = Task.of(100)
    task_1_1 = task_1.map(sub_num)

    assert 90 == task_1_1.fork(lambda x: x, lambda x: x)


# Generated at 2022-06-26 00:07:28.728522
# Unit test for method bind of class Task
def test_Task_bind():

    # Create instance of class Task
    value = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task = Task.of(value)

    # Get result of method
    actual_task = task.bind(lambda value1: Task.of(value1))

    def fork(reject, resolve):
        reject(actual_task)

    expected_task = Task(fork)

    assert actual_task is not expected_task


# Generated at 2022-06-26 00:07:34.319531
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task(lambda _, resolve: resolve(23))
    task_1 = task_0.map(lambda x: x + 10)

    def print_resolve(resolve):
        def fn(value):
            print(value)
            resolve()

        return fn

    def reject_unexpected_values(_):
        print("Unexpected reject value")

    task_1.fork(reject_unexpected_values, print_resolve(lambda: print("done")))

# Generated at 2022-06-26 00:07:41.027313
# Unit test for method bind of class Task
def test_Task_bind():
    def assert_equal(x, y):
        if x != y:
            raise Exception('Assert failed')

    Task.of(1).bind(lambda _: Task.reject(2)).fork(
        lambda error: assert_equal(error, 2),
        lambda result: assert_equal(result, None)
    )
    assert_equal(
        Task.of(1).bind(lambda _: Task.of(2)).fork(
            lambda error: None,
            lambda result: result
        ),
        2
    )
    Task.reject(1).bind(lambda _: Task.of(2)).fork(
        lambda error: assert_equal(error, 1),
        lambda result: assert_equal(result, None)
    )

# Generated at 2022-06-26 00:07:47.802238
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'

    def fn_0(arg):
        return Task.reject(arg)

    def fn_1(arg):
        return Task.of(arg)

    task_0 = Task.of(bytes_0)
    assert task_0.bind(fn_0).bind(fn_1).fork(lambda arg: None, lambda arg: arg == bytes_0)


# Generated at 2022-06-26 00:07:57.773816
# Unit test for method map of class Task
def test_Task_map():
    def resolver(value):
        return value

    def rejecter(value):
        raise Exception("Invalid value")

    def test_case_0():
        task_0 = Task(lambda _, resolve: resolve(1))
        task_1 = task_0.map(lambda value: value)
        assert task_1.fork(rejecter, resolver) == 1

    def test_case_1():
        task_0 = Task(lambda _, resolve: resolve(3))
        task_1 = task_0.map(lambda value: value + 1)
        assert task_1.fork(rejecter, resolver) == 4

    def test_case_2():
        task_0 = Task.of(2)
        task_1 = task_0.map(lambda value: value * 3)
        assert task_1.fork

# Generated at 2022-06-26 00:08:05.635379
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    """

    def fn_0(value):
        return Task.reject(value)

    def fn_1(value):
        return Task.of(value)

    value = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_0 = Task.reject(value)
    task_1 = task_0.bind(fn_0)
    assert task_1.fork(lambda x : x, lambda x : x) == value

    task_2 = task_0.bind(fn_1)
    assert task_2.fork(lambda x : x, lambda x : x) == value


test_Task_bind()

# Generated at 2022-06-26 00:08:09.417632
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(arg):
        return Task.of(arg*2)

    assert Task.of(2).bind(mapper).fork(None, None) == 4
    assert Task.reject(2).bind(mapper).fork(None, None) == 2


# Generated at 2022-06-26 00:08:15.661917
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of('test string').bind(len).fork('error', lambda x: x) == 11
    assert Task.reject('test string').bind(len).fork('error', lambda x: x) == 'test string'



# Generated at 2022-06-26 00:08:24.943630
# Unit test for method bind of class Task
def test_Task_bind():
    # Test case 1
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_0 = Task(bytes_0)
    def fn_0():
        bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
        task_0 = Task(bytes_0)
        return task_0.bind(__lambda_0.__code__.co_code)

    def __lambda_0(value_0):
        return Task.of(value_0)

    task_1 = fn_0()
    # Test case 2

# Generated at 2022-06-26 00:08:31.304895
# Unit test for method bind of class Task
def test_Task_bind():
    class A:
        def __init__(self, value):
            self.value = value

        def transform(self, v):
            return self.value * v

    class B:
        def __init__(self, value):
            self.value = value

        def transform(self, x):
            return Task.of(self.value * x.value)


    # test case of int type
    value_0 = 5
    task_0 = Task.of(A(value_0))
    task_1 = task_0.bind(lambda x: x.transform(2))
    assert isinstance(task_1, Task)
    assert task_1.fork(lambda _: _, lambda x: x) == 10

    # test case of int type
    value_1 = 10

# Generated at 2022-06-26 00:08:37.397888
# Unit test for method map of class Task
def test_Task_map():
    def test_0_0():
        bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
        task_0 = Task(bytes_0)
        task_1 = task_0.map(lambda x: x[0])
        assert type(task_1) == Task


# Generated at 2022-06-26 00:08:39.316030
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of('TEST').map(str.lower).fork(None, lambda arg: arg) == 'test'


# Generated at 2022-06-26 00:08:43.956321
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(identity, identity) == 2
    assert Task.of(1) \
        .bind(lambda x: Task.of(x + 1)) \
        .bind(lambda x: Task.of(x + 1)) \
        .fork(identity, identity) == 3


# Generated at 2022-06-26 00:08:50.120277
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(1)
    result_0 = task_0.bind(
        lambda x: Task.of(x + 1)
    ).fork(
        lambda x: 1,
        lambda x: x
    )
    assert(result_0 == 2)

    task_1 = Task.reject(1)
    result_1 = task_1.bind(
        lambda x: Task.of(x + 1)
    ).fork(
        lambda x: x,
        lambda x: 1
    )
    assert(result_1 == 1)


# Generated at 2022-06-26 00:08:50.858136
# Unit test for method bind of class Task
def test_Task_bind():
    pass


# Generated at 2022-06-26 00:09:01.428833
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_0 = Task(bytes_0)
    task_0.map(bytes)
    bytes_1 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_1 = Task(bytes_1)
    task_1.map(bytes)
    bytes_2 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_2 = Task(bytes_2)
    task

# Generated at 2022-06-26 00:09:05.016363
# Unit test for method bind of class Task
def test_Task_bind():
    def fail(_):
        raise AssertionError('Should not be called')

    def ok(x):
        assert x == 'OK'

    res = Task.of('OK').bind(lambda _: Task.of(None)).fork(fail, ok)

# Unit tests for method fork of class Task

# Generated at 2022-06-26 00:09:15.534290
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(_):
        pass

    def reject(_):
        raise AssertionError

    def assert_task(task):
        task.fork(reject, resolve)

    def assert_mapper(value):
        return Task.of(value)

    value = 1
    assert_task(Task.of(value).bind(assert_mapper))

    value = 'hello'
    assert_task(Task.of(value).bind(assert_mapper))



# Generated at 2022-06-26 00:09:16.965159
# Unit test for method bind of class Task
def test_Task_bind():
    def test(a):
        return Task.of(a * 2)

    assert Task.of(2).bind(test).fork(Task.reject, Task.of) == 4


# Generated at 2022-06-26 00:09:24.519915
# Unit test for method map of class Task
def test_Task_map():
    def f(v):
        return v

    def f_result(e, r):
        return r

    def f_reject(e, r):
        return e

    task_0 = Task(lambda e, r: r(f(0)))
    task_1 = Task(lambda e, r: r(f(1)))
    task_2 = Task(lambda e, r: e(f_reject(2, r)))

    assert f_result(0, task_0.map(f)) is f_result(0, task_1)
    assert f_result(0, task_0.map(f)) is f_result(0, task_2)


# Generated at 2022-06-26 00:09:30.070184
# Unit test for method bind of class Task
def test_Task_bind():
    def task_int_add(a):
        def task_int_add_inner(b):
            return Task.of(a + b)
        return task_int_add_inner

    task_one_plus_two = Task.of(1).bind(lambda one: Task.of(2).bind(task_int_add(one)))
    print(task_one_plus_two.fork(lambda r: r, lambda r: r))

test_Task_bind()

# Generated at 2022-06-26 00:09:39.224940
# Unit test for method bind of class Task
def test_Task_bind():

    class F0:
        bytes = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'

        def v0(self, v1):
            # type: (F0, b'') -> F0
            return self

        def v1(self, v1):
            # type: (F0, b'') -> F0
            return self

    class F1:
        def v0(self, v1):
            # type: (F1, b'') -> b''
            return self.v1(self, v1)

        def v1(self, v1):
            # type: (F1, b'') -> b''
            return Task.of(self.v0(self, v1))



# Generated at 2022-06-26 00:09:45.184008
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    bytes_1 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    result = bytes_0 is bytes_1
    assert result is False

test_Task_map()

# Generated at 2022-06-26 00:09:46.337767
# Unit test for method bind of class Task
def test_Task_bind():
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 00:09:55.839468
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_0 = Task.of(bytes_0)
    assert isinstance(task_0, Task)
    fn_0 = lambda arg: str(arg)
    task_1 = task_0.map(fn_0)
    assert isinstance(task_1, Task)
    def result(reject, resolve):
        return task_1.fork(
            lambda arg: reject(arg),
            lambda arg: resolve(arg)
        )

# Generated at 2022-06-26 00:10:00.350828
# Unit test for method map of class Task
def test_Task_map():
    def to_int(value):
        return int(value, 2)

    def to_list_of_char(value):
        return list(str(value))


# Generated at 2022-06-26 00:10:09.066375
# Unit test for method bind of class Task
def test_Task_bind():
    def test_Task_bind_0():
        task_0 = Task.of(b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0')
        task_1 = task_0.bind(lambda arg: Task.reject(arg))
        bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
        task_2 = task_0.map(lambda arg: bytes_0)
        bytes_1 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
        task

# Generated at 2022-06-26 00:10:29.661081
# Unit test for method map of class Task
def test_Task_map():
    def fn_0():
        def fn_1(arg_0):
            return arg_0 * 10

        bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
        task_0 = Task.of(bytes_0)
        task_0 = task_0.map(fn_1)
        assert task_0.fork(None, None).__class__ is float

    fn_0()

    def fn_1():
        def fn_1(arg_0):
            return math.ceil(arg_0)


# Generated at 2022-06-26 00:10:36.019816
# Unit test for method bind of class Task
def test_Task_bind():
    print("Test of method bind of class Task")
    def foo(a, b): return a + b
    def bar(x): return Task.of(foo(x, 10))
    def baz(x): return Task.of(foo(x, 10)).map(lambda x: foo(x, 10))
    task_0 = Task.of(2).bind(bar).bind(baz)
    assert task_0.fork(lambda x: x, lambda x: x) == 42
    print('Test passed')



# Generated at 2022-06-26 00:10:43.503452
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_1():
        class Applicative:
            def __init__(self):
                self.value = None
            def __eq__(self, other):
                return self.value == other.value
            def __call__(self, fn):
                if self.value is not None:
                    return fn(self.value)
                else:
                    return self
            @classmethod
            def of(cls, value):
                instance = cls()
                instance.value = value
                return instance

        def add_1(x):
            return x + 1

        def mapper(x):
            return Task.reject(x)

        instance_0 = Applicative.of(1)
        result = Task.of(instance_0).bind(mapper)

# Generated at 2022-06-26 00:10:54.733364
# Unit test for method bind of class Task
def test_Task_bind():
    # Test case 1
    def test_case_1():
        bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
        task_0 = Task(bytes_0)
        # Test case 1.1
        def test_case_1_1():
            def f_0(task_1):
                def f_1(bytes_1):
                    return Task(bytes_1)
                return task_1.map(f_1)
            task_1 = task_0.bind(f_0)

        test_case_1_1()

        # Test case 1.2

# Generated at 2022-06-26 00:11:00.994155
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_0 = Task.of(bytes_0)
    task_1 = task_0.map(lambda array: array.decode())
    assert type(task_1) is Task
    assert task_1.fork is None


# Generated at 2022-06-26 00:11:07.834076
# Unit test for method bind of class Task
def test_Task_bind():
    """Test Task.bind."""
    def inc(num):
        return num + 1

    def inc_task(num):
        return Task.of(num + 1)

    def add(a, b):
        return a + b

    def add_task(a, b):
        return Task.of(a + b)

    assert Task.of(2).bind(inc_task).fork(None, inc) == 3
    assert Task.of(2).bind(inc_task).bind(inc_task).fork(None, inc) == 4
    assert Task.of(2).bind(inc_task).bind(inc_task).bind(lambda x: Task.of(x + 2)).fork(None, inc) == 5

# Generated at 2022-06-26 00:11:18.462012
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """
    import random
    random.seed()

    uuid_0 = uuid.UUID(int=random.randint(0, 2 ** 128 - 1))
    uuid_str = uuid_0.hex
    task_0 = Task.of(uuid_str)

    def mapper_0(arg):
        return arg.upper()

    task_1 = task_0.map(mapper_0)

    assert isinstance(task_0, Task)
    assert isinstance(task_1, Task)
    assert task_0.fork is not task_1.fork
    assert task_0 is not task_1

    result_0 = task_0.fork(
        lambda x: "error",
        lambda x: x
    )
    result_1

# Generated at 2022-06-26 00:11:23.656208
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0')
    result_0 = task_0.map(lambda _0: type(_0).__name__)
    assert result_0.fork(lambda _0: _0, lambda _0: _0) == 'bytes'


# Generated at 2022-06-26 00:11:29.565372
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_1 = b'd\x11\x10\x00\xa5\x00\x13Q\x00\xa6\x00\x15Q\x00\xa7\x00\x17Q\x00\xa8\x00\x19Q\x00\r\x00\t\x00\x0b'


# Generated at 2022-06-26 00:11:39.416903
# Unit test for method bind of class Task
def test_Task_bind():
    byte_0 = b'\x07\xd6R\x1b\x1f\xf6[\xeb\x857\xa1\x81\xdd\xac\xb9'
    byte_1 = b'\x95\x80\xa1'
    byte_2 = b'\xf2\xd2\x05\xae\x1d\xab\r$\xbc\x89\xf3'

    def fn_0(val):
        return Task(val)

    def fn_1(val):
        return Task(val)

    assert Task(byte_0).bind(fn_0).fork(lambda _: byte_1, lambda _: byte_2) == byte_0

# Generated at 2022-06-26 00:12:12.640533
# Unit test for method bind of class Task
def test_Task_bind():
    # TEST_CASE_0
    def test_bind_0(i):
        return i + 1

    def test_bind_1(i):
        return i - 1

    def test_bind_2(result):
        if result == 5:
            return Task.of('test_0_pass')
        else:
            return Task.reject('test_0_fail')

    test_bind_0_task = Task.of(4)
    test_bind_0_task_1 = test_bind_0_task.bind(test_bind_0).bind(test_bind_0).bind(test_bind_1)
    test_bind_0_task_2 = test_bind_0_task_1.bind(test_bind_2)


# Generated at 2022-06-26 00:12:20.360540
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_0 = Task.of(bytes_0)
    def func_1(_):
        return Task.of(bytes_0)
    assert task_0.bind(func_1).fork(
        lambda value: True,
        lambda value: value == bytes_0
    )
    assert task_0.bind(func_1).fork(
        lambda value: value == bytes_0,
        lambda value: True
    )



# Generated at 2022-06-26 00:12:22.654113
# Unit test for method bind of class Task
def test_Task_bind():
    val_0 = Task(list()).bind(lambda _: Task([{}]))
    val_1 = Task(list()).bind(lambda _: Task([()]))


# Generated at 2022-06-26 00:12:31.904324
# Unit test for method map of class Task
def test_Task_map():
    # Test 0
    def sub_test_0():
        def mapper_func_0(value):
            return value * 2

        task_0 = Task.of(2)
        task_1 = task_0.map(mapper_func_0)
        result = task_1.fork(
            lambda reject: f'reject: {reject}',
            lambda resolve: f'resolve: {resolve}'
        )
        return repr(result) == repr('resolve: 4')

    ret_0 = sub_test_0()

    # Test 1
    def sub_test_1():
        task_0 = Task.reject(Exception())
        task_1 = task_0.map(lambda value: value)

# Generated at 2022-06-26 00:12:40.066595
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task map method.
    """

    # Case 0
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_0 = Task.of(bytes_0)

    def fn_0(bytes_0):
        def fn_1(id_1):
            return uuid.UUID(bytes=bytes_0, version=id_1)
        return fn_1

    task_1 = task_0.map(fn_0(bytes_0))
    result = task_1.fork(lambda arg: None, lambda arg: arg.version)

    assertEqual(result, 1)


# Generated at 2022-06-26 00:12:50.279925
# Unit test for method map of class Task
def test_Task_map():
    # Test case 1:
    # when expect: return Task.of(42)
    # and data: Task.of(42)
    # and mapper: lambda x: x + 42
    # and reject: lambda x: x + 113
    task_1 = Task.of(42)
    result_1 = task_1.map(lambda x: x + 42)
    assert result_1.fork(lambda x: x + 113, lambda _: None) == 42

    # Test case 2:
    # when expect: return rejected Task with error
    # and data: Task.reject(42)
    # and mapper: lambda x: x + 42
    # and reject: lambda x: x + 113
    task_2 = Task.reject(42)
    result_2 = task_2.map(lambda x: x + 42)


# Generated at 2022-06-26 00:12:56.050727
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_0 = Task(bytes_0)
    task_1 = Task.of(0.9)

    def func_0(arg):
        assert arg == 0.9
        return Task.of(0.8)

    task_2 = task_1.bind(func_0)

# Generated at 2022-06-26 00:13:04.100663
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of class Task
    Expected behavior: method returns new Task with mapped value
    :return: None
    """
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_0 = Task(bytes_0)
    def fn_0(arg_0):
        return bin(arg_0).decode('utf-8')

    task_1 = task_0.map(fn_0)
    fn_1 = task_1.fork

# Generated at 2022-06-26 00:13:05.952518
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(2).bind(lambda x: Task.of(x + 2)).fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-26 00:13:15.925957
# Unit test for method bind of class Task
def test_Task_bind():
    import pytest

    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    bytes_1 = b'\xd5\xaf\x93\x1c\xae\xb5\xdb\x86\xc7\x88\x84\xcf'
    bytes_2 = b'\xec\xe7\x98\x9f\xbf\xb2\xde\x87\xc8\x89\x85\xd0'
    task_0 = Task(bytes_0)
    task_1 = Task(bytes_1)
    task_2 = Task(bytes_2)

    def fn_0(arg_0):
        return task_2


# Generated at 2022-06-26 00:14:21.920567
# Unit test for method map of class Task
def test_Task_map():

    # Task.map: Task[A] -> (A -> B) -> Task[B]

    # (A -> B) -> Task[A] -> Task[B]

    # Task.of: A -> Task[A]
    # Task.reject: A -> Task[A]

    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    task_0 = Task.of(bytes_0)
    bytes_1 = b'test'
    task_1 = Task.of(bytes_1)
    bytes_2 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'


# Generated at 2022-06-26 00:14:30.105680
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(1)
    task_1 = task_0.map(lambda a: a + 3)
    assert task_1.fork(lambda value: None, lambda value: value) == 4

    task_2 = task_1.map(lambda a: a % 3)
    assert task_2.fork(lambda value: None, lambda value: value) == 1



# Generated at 2022-06-26 00:14:38.189325
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'

    def fn_0(value):
        """
        Take bytes and return it
        :param value: bytes
        :type value: bytes
        :return: value
        :rtype: bytes
        """
        return value

    task_0 = Task.of(bytes_0)
    task_1 = task_0.map(fn_0)

    def fn_1(value):
        """
        Take bytes and return Task.of()
        :param value: bytes
        :type value: bytes
        :return: Task
        :rtype: bytes
        """
        return Task.of(value)

    task_2 = task_0

# Generated at 2022-06-26 00:14:43.071773
# Unit test for method map of class Task
def test_Task_map():
    def assert_equal(val_0, val_1):
        if val_0 != val_1:
            raise Exception('Value {} does not equal to {}'.format(val_0, val_1))

    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    bytes_1 = bytes([x + 1 for x in bytes_0])

    task_0 = Task.of(bytes_0)
    task_1 = task_0.map(lambda a: bytes_1)

    fork_0 = task_1.fork
    assert_equal(type(fork_0), type(lambda a, b: None))
    assert_equal(type(fork_0(0, 0)), type(None))



# Generated at 2022-06-26 00:14:46.085676
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> Task(lambda _, resolve: resolve(10)).bind(lambda x: Task.of(x + 1)).fork(lambda err: print('error:', err), lambda val: print('val:', val))
    val: 11
    """


# Generated at 2022-06-26 00:14:53.274111
# Unit test for method bind of class Task
def test_Task_bind():
    # create Task with fork function
    task_0 = Task(lambda reject, resolve: resolve(4))
    # create mapper function
    def fn(value):
        return Task(lambda reject, resolve: reject(str(value)))

    # apply bind with mapper
    result = task_0.bind(fn)

    # check fork of result

# Generated at 2022-06-26 00:14:57.047330
# Unit test for method bind of class Task
def test_Task_bind():
    # Case 0
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    func_0 = lambda arg: Task.of(arg)
    task_0 = Task.of(bytes_0)
    task_0 = task_0.bind(func_0)
    # Case 1
    bytes_1 = b"l"
    func_1 = lambda arg: Task.reject(arg)
    task_1 = Task.of(bytes_1)
    task_1 = task_1.bind(func_1)
    # Case 2

# Generated at 2022-06-26 00:14:59.736554
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(3)
    def fn(value):
        def inner():
            return value + 4
        return inner()
    task_1 = task_0.map(fn)
    assert task_1.fork(lambda x: None, lambda x: x)() == 7


# Generated at 2022-06-26 00:15:03.131969
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    bytes_1 = b'\xda~e\x91\x02\xbdb\xcf\xd1\x15\xa1wA\xdd\x1c\xf0'
    int_0 = Task.bind(Task.of(bytes_0), bytes_1)


# Generated at 2022-06-26 00:15:12.630557
# Unit test for method bind of class Task
def test_Task_bind():
    def f1(arg):
        return arg

    def f2(arg):
        return arg + arg

    def f3(arg):
        return arg + arg + arg

    def f4(arg):
        return arg + arg + arg + arg

    def f5(arg):
        return arg + arg + arg + arg + arg

    assert Task.of(1).bind(f1).fork(None, f2) == 2
    assert Task.of(1).bind(f1).bind(f1).fork(None, f3) == 3
    assert Task.of(1).bind(f1).bind(f1).bind(f1).fork(None, f4) == 4
    assert Task.of(1).bind(f1).bind(f1).bind(f1).bind(f1).fork(None, f5)