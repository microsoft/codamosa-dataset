

# Generated at 2022-06-26 00:05:56.837690
# Unit test for method map of class Task
def test_Task_map():
    string_0 = 'K0'
    string_1 = 'A0'
    string_2 = 'Q0'
    string_3 = 'I0'
    string_4 = 'P0'
    string_5 = 'C0'
    string_6 = 'W0'
    string_7 = 'X0'
    string_8 = 'S0'
    string_9 = 'C0'

    def unit_test_0(arg_1, arg_2):
        def result(arg_3, arg_4):
            return arg_4(arg_1 + arg_2 + arg_3)
        return Task(result)

    task_0 = unit_test_0(string_0, string_1)
    bool_0 = isinstance(task_0, Task)
    bool_1 = not bool_

# Generated at 2022-06-26 00:06:04.533164
# Unit test for method map of class Task
def test_Task_map():
    arg_0 = None
    def result_0(reject, resolve):
        reject(arg_0)
        resolve(arg_0)

    def result_1(reject, resolve):
        reject(arg_0)
        resolve(arg_0)

    def result_2(reject, resolve):
        reject(arg_0)
        resolve(arg_0)

    def result_3(reject, resolve):
        reject(arg_0)
        resolve(arg_0)


    task_0 = Task(result_0)
    fn_0 = None
    task_1 = task_0.map(fn_0)
    def result_4(_, resolve):
        resolve(arg_0)

    task_2 = Task(result_4)
    def result_5(reject, _):
        reject

# Generated at 2022-06-26 00:06:15.245306
# Unit test for method bind of class Task
def test_Task_bind():
    bool_0 = False
    bool_1 = True
    int_0 = 0
    int_1 = 1
    string_0 = ""
    string_1 = "1"
    def fn_0(arg_0):
        bool_1 = bool_0
        if (not bool_1):
            bool_1 = not bool_0
        bool_2 = bool_1
        bool_1 = (not bool_0)
        if ((not bool_0) and bool_1):
            bool_1 = not bool_0
        bool_0 = bool_1
        return int_1
    def fn_1(arg_0):
        int_0 = int_1
        bool_0 = bool_1
        string_0 = string_1
        return Task.of(int_0)
    int_0 = fn_

# Generated at 2022-06-26 00:06:23.365341
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(1)
    task_1 = Task.of('a')
    task_2 = Task.of(True)
    task_3 = Task.of(False)

    task_4 = task_0.map(lambda x: x + 1)
    task_5 = task_1.map(lambda x: x + 'b')
    task_6 = task_2.map(lambda x: not x)
    task_7 = task_3.map(lambda x: not x)

    assert_equal(str(task_0), 'Task of<Class of int>')
    assert_equal(str(task_1), "Task of<Class of str>")
    assert_equal(str(task_2), "Task of<Class of bool>")

# Generated at 2022-06-26 00:06:33.421724
# Unit test for method bind of class Task
def test_Task_bind():
    # Unit test for method bind of class Task
    def test_0(i):
        assert i == 3, 'bind test 0'

    def test_1(i):
        assert i == 3, 'bind test 1'

    def test_2(i):
        assert i == None, 'bind test 2'

    def test_3(i):
        assert i == 3, 'bind test 3'

    def test_4(i):
        assert i == [ 1, 2, 3 ], 'bind test 4'

    def test_5(i):
        assert i == False, 'bind test 5'

    def test_6(i):
        assert i == 3, 'bind test 6'

    def test_7(i):
        assert i == 'error', 'bind test 7'

    def test_8(i):
        assert i == 3

# Generated at 2022-06-26 00:06:39.085393
# Unit test for method map of class Task
def test_Task_map():
    def assert_fn(arg):
        assert arg == 0

    def transform_fn(arg):
        return arg + 1

    Task.of(0).map(assert_fn).fork(assert_false, assert_false)
    Task.of(0).map(transform_fn).fork(assert_false, assert_true)
    Task.of(0).map(transform_fn).map(assert_fn).fork(assert_false, assert_false)


# Generated at 2022-06-26 00:06:45.344598
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map
    """
    def map_function_0(value):
        """
        map_function_0
        """
        return str(value)
    task_0 = Task.of(1)
    exception_type = None
    try:
        task_0.map(map_function_0)
    except Exception as exception:
        exception_type = type(exception)

    assert(exception_type is None)


# Generated at 2022-06-26 00:06:51.146177
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(0).map(lambda a: a + 1).fork(lambda a: a, lambda b: b) == 1
    assert Task.reject("qwerty").map(lambda a: a + 1).fork(lambda a: a, lambda b: b) == "qwerty"
    assert Task.of(True).map(lambda a: a).fork(lambda a: a, lambda b: b) == True


# Generated at 2022-06-26 00:06:57.520882
# Unit test for method bind of class Task
def test_Task_bind():
    bool_0 = False
    task_0 = Task(bool_0)
    method_1 = task_0.bind
    float_0 = float(0)
    task_1 = Task.of(float_0)
    task_2 = method_1(task_1)
    bool_2 = task_2 == task_1
    print(bool_2)
    if bool_2:
        print('OK')
    else:
        print('FAIL')


# Generated at 2022-06-26 00:07:07.046578
# Unit test for method map of class Task
def test_Task_map():
    """
    Test case to test map method of Task class.
    """
    #True case
    task_0 = Task.of(100)
    task_1 = task_0.map(lambda val: val / 10)
    assert task_1.fork(
        lambda val: True,
        lambda val: False
    ) == task_1.fork(
        lambda val: True,
        lambda val: 10 == val
    )

    task_2 = Task.of('Hello ')
    task_3 = task_2.map(lambda val: val + 'world!')
    assert task_3.fork(
        lambda val: True,
        lambda val: False
    ) == task_3.fork(
        lambda val: True,
        lambda val: 'Hello world!' == val
    )

    # False case
    task_

# Generated at 2022-06-26 00:07:11.016374
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(2).bind(lambda x: Task.of(x + 1)).fork(None, lambda x: x) == 3

# Generated at 2022-06-26 00:07:21.610518
# Unit test for method bind of class Task
def test_Task_bind():
    def add_5(a):
        return a + 5
    def add_9(a):
        return a + 9
    def mul_2(a):
        return a * 2


    task_0 = Task.of(3).bind(
        lambda a: Task.of(a).bind(
            lambda b: Task.of(add_9(b)).map(add_5)
        )
    )
    task_0_fork_result = task_0.fork(
        lambda arg: arg,
        lambda arg: arg
    )
    task_0_expected_result = 17

    assert task_0_fork_result == task_0_expected_result, "error in test_Task_bind"

# Generated at 2022-06-26 00:07:25.143041
# Unit test for method map of class Task
def test_Task_map():
    def reject(_):
        assert False

    def resolve(value):
        assert value == 2

    task = Task.of(1)
    task.map(lambda value: value + 1).fork(reject, resolve)


# Generated at 2022-06-26 00:07:34.589087
# Unit test for method bind of class Task
def test_Task_bind():
    @functools.lru_cache(maxsize=None)
    def test_0(value):
        return Task.of(value)

    @functools.lru_cache(maxsize=None)
    def test_1(value):
        if value % 2 == 0:
            return Task.of(1)
        else:
            return Task.reject(0)

    @functools.lru_cache(maxsize=None)
    def test_2(value):
        if value % 3 == 0:
            return Task.of(1)
        else:
            return Task.reject(0)

    @functools.lru_cache(maxsize=None)
    def test_3(value):
        if value % 10 == 0:
            return Task.of(1)

# Generated at 2022-06-26 00:07:41.946552
# Unit test for method map of class Task
def test_Task_map():
    class Mapper:
        def __init__(self):
            self.call_count = 0

        def __call__(self, value):
            self.call_count += 1
            return value

    mapper = Mapper()
    task_0 = Task.of('test')

    task_1 = task_0.map(mapper)
    assert mapper.call_count == 0


# Generated at 2022-06-26 00:07:53.148181
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(3).map(lambda v: v + 1).fork(
        lambda _: False,
        lambda _: True
    ) is True

    assert Task.of(3).map(lambda v: v + 1).fork(
        lambda v: v == 4,
        lambda _: False
    ) is True

    assert Task.of(3).map(lambda v: v + 1).bind(
        lambda v: Task.of(v - 1)
    ).fork(
        lambda _: False,
        lambda _: True
    ) is True

    assert Task.of(3).map(lambda v: v + 1).bind(
        lambda v: Task.of(v - 1)
    ).fork(
        lambda v: v == 3,
        lambda _: False
    ) is True


# Generated at 2022-06-26 00:08:01.017197
# Unit test for method map of class Task
def test_Task_map():
    """
    Method test_Task_map test map method of class Task
    """
    # Test case #0:
    # Test for return result of mapper function
    def test_case_0():
        def mapper(value):
            return value * 2

        task_0 = Task.of(2)
        assert task_0.map(mapper).fork(lambda _: 0, lambda value: 2) == 4

    # Test case #1:
    # Test for raise exception

    def test_case_1():
        def mapper(value):
            raise Exception
        #
        task_0 = Task.of(2)

        def callback(exception):
            if isinstance(exception, Exception):
                return True
            return False

        assert task_0.map(mapper).fork(callback, lambda _: False)



# Generated at 2022-06-26 00:08:05.537767
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for map function
    """
    task_0 = Task.of('zero')
    multiply_by_2 = lambda x: x * 2
    task_1 = task_0.map(multiply_by_2)
    assert task_1.fork(lambda a: 'error', lambda arg: arg) == 'zerozero'



# Generated at 2022-06-26 00:08:08.932088
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(0)
    task_1 = task_0.map(lambda x: x + 2)
    assert task_1.fork(lambda x: False, lambda x: True) is True


# Generated at 2022-06-26 00:08:13.785868
# Unit test for method map of class Task
def test_Task_map():
    def fun_0(bool_0):
        return bool_0
    task_0 = Task(fun_0)
    task_1 = task_0.map(fun_0)
    assert(task_1.fork(fun_0, fun_0) == False)


# Generated at 2022-06-26 00:08:26.983460
# Unit test for method bind of class Task
def test_Task_bind():
    def bool_0(resolve):
        resolve(True)

    task_0 = Task(bool_0)

    def bool_1(resolve):
        resolve(True)

    task_1 = task_0.bind(lambda x: Task.of(x).bind(lambda y: Task.of(y)))
    task_1.fork(lambda x: True, lambda x: False)

    def bool_2(resolve):
        resolve(True)

    task_2 = Task.of(Task.of(True).bind(lambda x: Task.of(x))).bind(lambda x: x)
    task_2.fork(lambda x: True, lambda x: False)

    def bool_3(resolve):
        resolve(True)


# Generated at 2022-06-26 00:08:29.648941
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(3)
    task_1 = task_0.map(lambda x: x + 1)
    task_2 = Task.reject(0)
    task_3 = task_2.map(lambda x: x + 1)


# Generated at 2022-06-26 00:08:32.089103
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(_): Task.of(True)

    assert Task.of(True).bind(fn).fork(lambda _: False, lambda _: True)



# Generated at 2022-06-26 00:08:35.433843
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(123).map(lambda arg: arg + 456)
    assert result.fork(lambda _: "Fail", lambda arg: arg) == 579


# Generated at 2022-06-26 00:08:44.832057
# Unit test for method bind of class Task
def test_Task_bind():
    # 1. Test map with const value and identity function
    actual = Task.of(0).map(lambda value: value * 2)

# Generated at 2022-06-26 00:08:48.140698
# Unit test for method bind of class Task
def test_Task_bind():
    class A:
        pass

    class B:
        pass

    def fn_0(a):
        return a + "1"


# Generated at 2022-06-26 00:08:53.322058
# Unit test for method bind of class Task
def test_Task_bind():
    result_0 = Task.of(1)
    fork_0 = lambda reject, resolve: resolve(1)
    assert result_0.fork == fork_0

    result_1 = Task.of(1).map(lambda value: value + 1)
    fork_1 = lambda reject, resolve: resolve(2)
    assert result_1.fork == fork_1

    result_2 = Task.of(1).bind(lambda value: Task.of(value+1))
    fork_2 = lambda reject, resolve: resolve(2)
    assert result_2.fork == fork_2



# Generated at 2022-06-26 00:08:59.372694
# Unit test for method bind of class Task
def test_Task_bind():
    def callback(value):
        return value

    assert_equal(Task.of(1).map(callback).fork(print, print), 1)
    assert_equal(Task.of('string').map(callback).fork(print, print), 'string')
    assert_equal(Task.of([1, 2, 3]).map(callback).fork(print, print), [1, 2, 3])



# Generated at 2022-06-26 00:09:04.653476
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(0)
    task_1 = task_0.map(lambda value: value + 1)
    result_0 = task_0.fork(lambda err: err, lambda value: value)
    result_1 = task_1.fork(lambda err: err, lambda value: value)

    assert task_0.fork == task_1.fork
    assert result_0 == 0
    assert result_1 == 1


# Generated at 2022-06-26 00:09:08.106649
# Unit test for method map of class Task
def test_Task_map():
    Task.of(1).map(lambda x: x + 1).fork(lambda x: print("error"), lambda x: print("ok", x))
    Task.reject("error").map(lambda x: x + 1).fork(lambda x: print("error"), lambda x: print("ok", x))


# Generated at 2022-06-26 00:09:25.820656
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method map of class Task

    :returns: testing result
    :rtype: bool
    """
    # Case 1
    task_0 = Task.of(2)
    task_1 = task_0.map(lambda x: x + 2)
    task_2 = task_1.map(lambda x: x * x)
    assert task_2.fork(lambda: None, lambda x: True if x == 16 else False) # True
    # Case 2
    task_0 = Task.reject(2)
    task_1 = task_0.map(lambda x: x + 2)
    task_2 = task_1.map(lambda x: x * x)
    assert task_2.fork(lambda: True, lambda x: False if x == 16 else True) # True


# Generated at 2022-06-26 00:09:29.735192
# Unit test for method map of class Task
def test_Task_map():
    bool_0 = True
    task_0 = Task(bool_0)

    def func_0(value):
        return value

    bool_1 = True
    task_1 = Task(bool_1)
    task_2 = task_0.map(func_0)


# Generated at 2022-06-26 00:09:38.910076
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(1)
    task_1 = task_0.bind(lambda a: Task.of(a + 10))
    assert task_1.fork(error_handler, lambda res: res == 11)

    task_0 = Task.of(1)
    task_1 = task_0.bind(lambda a: Task.of(a + 10)).bind(lambda a: Task.of(a + 20))
    assert task_1.fork(error_handler, lambda res: res == 31)

    task_0 = Task.of(1)
    task_1 = task_0.bind(lambda a: Task.of(a + 10)).bind(lambda a: Task.of(a + 20))\
        .bind(lambda a: Task.of(a + 30))

# Generated at 2022-06-26 00:09:48.056177
# Unit test for method bind of class Task
def test_Task_bind():
    result = "foo"

    # Unit test for case when first argument is a function
    def first_argument_is_a_function():
        def caller(reject, resolve):
            resolve(10)

        def mapper(value):
            assert value == 10
            return Task.of(result)

        def fork(reject, resolve):
            resolve(result)

        task = Task(caller).bind(mapper)
        task.fork(lambda arg: arg, lambda arg: arg)

    first_argument_is_a_function()

    # Unit test for case when first argument is not a function
    def first_argument_is_not_a_function():
        def caller(reject, resolve):
            return reject(result)

        def mapper(value):
            assert False


# Generated at 2022-06-26 00:09:57.524892
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind() method.
    """
    # Test case 1
    # assert Task.of(1) | Task.bind(lambda x: Task.of(x + 1)) == Task.of(2)
    # assert Task.of(1) | Task.bind(lambda x: Task.reject(x)) == Task.reject(2)
    # assert Task.reject(1) | Task.bind(lambda x: Task.of(x + 1)) == Task.reject(2)
    # assert Task.reject(1) | Task.bind(lambda x: Task.reject(x)) == Task.reject(2)

# Generated at 2022-06-26 00:09:59.222305
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)).map(lambda x: x + 1).fork(
        lambda x: x * 2,
        lambda x: x * 2
    ) == 4


# Generated at 2022-06-26 00:10:07.525228
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(5)
    task_1 = task_0.bind(lambda x: Task.of(x + 1))
    assert task_1.fork(lambda x: x, lambda x: x) == 6

    task_2 = task_1.bind(lambda x: Task.of(x + 1))
    assert task_2.fork(lambda x: x, lambda x: x) == 7

    task_3 = task_2.bind(lambda x: Task.of(x + 1))
    assert task_3.fork(lambda x: x, lambda x: x) == 8

    task_4 = task_2.bind(lambda x: Task.of(x + 1))
    assert task_4.fork(lambda x: x, lambda x: x) == 8

# Generated at 2022-06-26 00:10:17.575955
# Unit test for method map of class Task
def test_Task_map():
    """ Unit test for method map of class Task
    :returns: True if all tests is ok, False otherwise
    :rtype: bool
    """
    results = []
    expected = [2, 3, 4, 5]

    task_0 = Task.of(1).map(lambda x: x + 1)
    results.append(task_0.fork(lambda x: x, lambda x: x))
    task_1 = Task.of(2).map(lambda x: x + 2)
    results.append(task_1.fork(lambda x: x, lambda x: x))
    task_2 = Task.of(3).map(lambda x: x + 3)
    results.append(task_2.fork(lambda x: x, lambda x: x))

# Generated at 2022-06-26 00:10:26.856874
# Unit test for method bind of class Task
def test_Task_bind():
    # Create random arguments for class Task and method bind of class Task
    arg = random.uniform(0, 100)
    arg_0 = random.uniform(0, 100)
    arg_1 = random.uniform(0, 100)
    arg_2 = random.uniform(0, 100)
    arg_3 = random.uniform(0, 100)
    arg_4 = random.uniform(0, 100)
    arg_5 = random.uniform(0, 100)
    arg_6 = random.uniform(0, 100)
    arg_7 = random.uniform(0, 100)
    arg_8 = random.uniform(0, 100)
    arg_9 = random.uniform(0, 100)
    arg_10 = random.uniform(0, 100)
    arg_11 = random

# Generated at 2022-06-26 00:10:36.663205
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_0():
        def fork(reject, resolve):
            resolve(1)

        task = Task(fork)
        fn = lambda x: Task.of(x * 2)
        mapped = task.map(fn)

        def fork_(reject_, resolve_):
            assert reject_ == reject
            assert resolve_ == resolve

        mapped.fork(fork_)

    def test_case_1():
        def fork(reject, resolve):
            resolve(1)

        task = Task(fork)
        fn = lambda x: Task.of(x * 2)
        mapped = task.bind(fn)

        def fork_(reject_, resolve_):
            assert reject_ == reject
            assert resolve_ == resolve

        mapped.fork(fork_)

    test_case_0()
    test_case_

# Generated at 2022-06-26 00:10:58.737925
# Unit test for method map of class Task
def test_Task_map():
    bool_0 = False
    task_0 = Task.of(bool_0)
    task_1 = task_0.map(bool)
    task_2 = task_0.map(id)


# Generated at 2022-06-26 00:11:04.510009
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(2).bind(lambda v: Task.of(v + 4))
    task_1 = Task.of(2).bind(lambda v: Task.of(v * 2))
    task_2 = Task.of(2).bind(lambda v: Task.of(v / 2))

    def callback(v):
        print(v)

    task_0.fork(None, callback)
    task_1.fork(None, callback)
    task_2.fork(None, callback)


# Generated at 2022-06-26 00:11:13.085292
# Unit test for method map of class Task
def test_Task_map():
    
    # Test with empty lambdas
    empty_lambda = lambda _ : 1
    rejected_task = Task.of(empty_lambda)
    resolved_task = Task.reject(empty_lambda)
    assert rejected_task.map(lambda x: x) == resolved_task
    assert resolved_task.map(lambda x: x) == rejected_task
    
    # Test with task of first arg
    def test_Task_map_one_arg_first(x, y):
        assert task_0.fork(lambda _: 1, lambda _: 1) == 1
        return x
    task_0 = Task(test_Task_map_one_arg_first)
    
    # Test with task of second arg

# Generated at 2022-06-26 00:11:20.768085
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task(lambda _, resolve: resolve(0))
    task_1 = task_0.map(lambda arg: arg + 1)
    task_2 = task_1.map(lambda arg: arg * 2)

    assert task_0.fork(lambda _: None, lambda arg: arg) == 0
    assert task_1.fork(lambda _: None, lambda arg: arg) == 1
    assert task_2.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-26 00:11:24.263676
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(_, resolve):
        resolve(1)

    def resolve(value):
        assert value == 1, "Test failed"

    task = Task(fork)
    task.bind(lambda value: Task.of(value)).fork(lambda _: 1, resolve)



# Generated at 2022-06-26 00:11:29.879829
# Unit test for method bind of class Task
def test_Task_bind():
    """
     +-----------------------+
     | Program | Expected    |
     +=======================+
     | Task.of(3).bind(      |
     |     lambda x:        |
     |         Task.of(x*2) |
     | )                     |
     +-----------------------+
     | Task.of(6)            |
     +-----------------------+
    """
    # +-----------------------+
    # | Program | Expected    |
    # +=======================+
    # | Task.of(3).bind(      |
    # |     lambda x:        |
    # |         Task.of(x*2) |
    # | )                     |
    # +-----------------------+

# Generated at 2022-06-26 00:11:32.554889
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(5)
    task_1 = task_0.map(lambda arg: arg * 2)
    assert task_1.fork(lambda _, __: False, lambda arg: arg == 10)


# Generated at 2022-06-26 00:11:42.013558
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda _, resolve: resolve(True)).bind(
        lambda value: Task.of(not value)
    ).fork(
        lambda reject: True,
        lambda resolve: False
    ), "bind rejected"

    assert not Task(lambda reject, _: reject(False)).bind(
        lambda value: Task.of(not value)
    ).fork(
        lambda reject: True,
        lambda resolve: False
    ), "bind resolved"

    assert Task.of(False).bind(
        lambda value: Task.of(not value)
    ).fork(
        lambda reject: True,
        lambda resolve: False
    ), "bind called map"


# Generated at 2022-06-26 00:11:52.557848
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda i: i * i) == Task.of(4)

    def map_0(i):
        if i == 1:
            return Task.of(1)
        if i == 2:
            return Task.of(2)
        if i == 3:
            return Task.of(3)

    assert Task.of([1,2,3]).map(map_0) == Task.of([1,2,3])

    def map_1(i):
        if i == 1:
            return Task.reject(1)
        if i == 2:
            return Task.reject(2)
        if i == 3:
            return Task.reject(3)


# Generated at 2022-06-26 00:12:03.191137
# Unit test for method bind of class Task
def test_Task_bind():
    # Assert Task for function lambda (value) -> Task[reject, mapped_value].
    def fork_0(reject, resolve):
        return Task(bool_0).bind(lambda value: Task(bool_1)).fork(reject, resolve)

    # Assert error for function lambda (value) -> Task[reject, mapped_resolve].
    def fork_1(reject, resolve):
        return Task(bool_2).bind(lambda value: Task(bool_3)).fork(reject, resolve)

    assert fork_0(bool_1, bool_0)
    assert fork_1(bool_3, bool_2)



# Generated at 2022-06-26 00:12:48.187983
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:12:53.843148
# Unit test for method bind of class Task
def test_Task_bind():
    # Set up
    def r(x):
        return Task.reject(x)
    def t(x):
        return Task.of(x)
    a = 1
    b = 2
    c = 3
    # Execution
    result = Task.of(a).bind(lambda x: t(x+1)).bind(lambda x: t(x+1))
    # Test
    assert result.fork(lambda _: False, lambda _: True) == True

# Generated at 2022-06-26 00:13:01.860590
# Unit test for method bind of class Task
def test_Task_bind():
    def const(value):
        def fn(_):
            return value

        return fn

    def bind(value):
        def fn(x):
            return Task.of(x + value)

        return fn

    def fork(result):
        def fn(resolve, reject):
            try:
                return resolve(result)
            except:
                return reject(result)

        return fn

    task_1 = Task(fork(1))
    task_2 = Task(fork(2))
    task_3 = Task(fork(3))
    task_4 = Task(fork(4))
    task_5 = Task(fork(5))

    task_1_map = task_1.map(const(4)).fork(fork(10), fork(100))
    task_2_map = task_2.map(bind(4)).fork

# Generated at 2022-06-26 00:13:04.606081
# Unit test for method map of class Task
def test_Task_map():
    """
    Method Task.map should transform result of Task (value of reject and resolve)
    """
    # Prepare test
    # Create test Task
    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    # Prepare method mapper
    def double_value(value):
        return value * 2

    # Run test
    task = task.map(double_value)
    # Check result
    assert task.fork(None, lambda arg: arg) == 2



# Generated at 2022-06-26 00:13:09.992879
# Unit test for method bind of class Task
def test_Task_bind():
    def match(value):
        if value > 0:
            return Task.of(value)
        return Task.reject(value)

    assert Task.of(1).bind(match) == Task.of(1)
    assert Task.of(2).bind(match) == Task.of(2)
    assert Task.of(0).bind(match) == Task.reject(0)



# Generated at 2022-06-26 00:13:18.895705
# Unit test for method map of class Task
def test_Task_map():
    def first_test():
        task_0 = Task.of(1)
        task_1 = task_0.map(lambda x: x + 1)
        if task_1.fork(lambda x: None, lambda x: None) == 2:
            print("first_test is passed")
        else:
            print("first_test is failed")

    def test_0():
        task_0 = Task.of(1)
        task_0.map(lambda x: x)
        if task_0.fork(lambda x: None, lambda x: None) == 1:
            print("test_0 is passed")
        else:
            print("test_0 is failed")

    def test_1():
        task_0 = Task.of(1)
        task_0.map(lambda x: 3)

# Generated at 2022-06-26 00:13:25.045306
# Unit test for method bind of class Task
def test_Task_bind():
    from functools import partial
    import random

    def test(n, l, r):
        a = l[n]
        b = r[n]
        return Task.of(a).bind(lambda x: Task.of(b)).map(lambda x: x.pop())

    def test_pop(x, l):
        l.pop()

    def check_dependance(n, l, r):
        x = l[n]
        y = r[n]
        return x is y

    left = [random.randint(0, 1000) for _ in range(10)]
    right = [random.randint(0, 1000) for _ in range(10)]
    for i in range(10):
        assert check_dependance(i, left, right) == True
        test(i, left, right)
       

# Generated at 2022-06-26 00:13:33.044517
# Unit test for method map of class Task
def test_Task_map():
    bool_0 = True
    task_0 = Task(bool_0)
    task_1 = task_0.map(lambda arg_0: arg_0)
    task_2 = task_1.map(lambda arg_0: arg_0)
    task_3 = task_2.map(lambda arg_0: arg_0)
    task_4 = task_3.map(lambda arg_0: arg_0)
    task_5 = task_4.map(lambda arg_0: arg_0)
    task_6 = task_5.map(lambda arg_0: arg_0)
    task_7 = task_6.map(lambda arg_0: arg_0)
    task_8 = task_7.map(lambda arg_0: arg_0)

# Generated at 2022-06-26 00:13:41.233928
# Unit test for method map of class Task
def test_Task_map():
    # Case 0
    try:
        test_case_0()
    except:
        assert True
    else:
        assert False

    # Case 1
    def task_fork_1(reject, resolve):
        return resolve(1)

    def fn_1(arg):
        return 2

    task_1 = Task(task_fork_1).map(fn_1)

    def task_fork_1_result(reject, resolve):
        return resolve(2)

    task_1_result = Task(task_fork_1_result)

    assert task_1 == task_1_result

    # Case 2
    def task_fork_2(reject, resolve):
        return resolve([1, 2, 3, 4, 5])


# Generated at 2022-06-26 00:13:43.654148
# Unit test for method map of class Task
def test_Task_map():
    test_case_0()
    task_0 = Task.of("foo")
    task_1 = task_0.map(lambda x: x.upper())
    assert task_1.fork(lambda x: "nope", lambda x: x) == "FOO"

# Generated at 2022-06-26 00:15:23.141564
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(5)
    assert task_0.map(lambda x: x * 2).fork(lambda x: 0, lambda x: x) == 10

    task_1 = Task.of(6)
    inc_task = task_1.map(lambda x: x + 1)
    assert inc_task.fork(lambda x: 0, lambda x: x) == 7

    task_2 = Task.of(-100)
    dec_task = task_2.map(lambda x: x - 1)
    assert dec_task.fork(lambda x: 0, lambda x: x) == -101

    task_3 = Task.of(1)
    null_task = task_3.map(lambda x: x * 0)
    assert null_task.fork(lambda x: 0, lambda x: x) == 0



# Generated at 2022-06-26 00:15:26.823397
# Unit test for method map of class Task
def test_Task_map():
    # Implemented unit test is incorrect, need to be improved
    a = 'a'
    b = 'b'
    def fork(reject, resolve):
        return resolve(a)

    def map_fn(arg):
        return b

    task = Task(fork)
    result = task.map(map_fn)

    assert result.fork(None, None) == b


# Generated at 2022-06-26 00:15:31.841674
# Unit test for method bind of class Task
def test_Task_bind():
    task_1_0 = Task.of(1).bind(lambda value: Task.of(value + 1))
    assert_equals(task_1_0.fork(lambda error: None, lambda value: value), 2)

    task_1_1 = Task.of(1).bind(lambda value: Task.reject("Error"))
    assert_equals(task_1_1.fork(lambda error: error, lambda value: None), "Error")


# Generated at 2022-06-26 00:15:36.905586
# Unit test for method map of class Task
def test_Task_map():
    number = 3
    bool_0 = False
    bool_1 = True
    value = True
    task_0 = Task.of(number)
    task_1 = task_0.map(lambda arg: arg + 3)

    def fn(_):
        nonlocal bool_0
        bool_0 = True

    task_1.fork(lambda _: None, fn)
    assert bool_0 == bool_1 and value == task_1.fork(
        lambda _: None,
        lambda arg: arg == number + 3
    )



# Generated at 2022-06-26 00:15:43.865109
# Unit test for method bind of class Task
def test_Task_bind():

    def task_0_func(reject_0, resolve_0):
        resolve_0(True)

    task_0 = Task(task_0_func)

    def task_1_func(reject_1, resolve_1):
        resolve_1(False)

    task_1 = Task(task_1_func)

    def task_fork(reject, resolve):
        resolve(1)

    task_2 = Task(task_fork)

    def task_2_0(value_0):
        return task_2


# Generated at 2022-06-26 00:15:46.058062
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda arg: arg + 1)

    def assert_resolve(arg):
        print(arg)
        assert arg == 2

    def assert_reject(arg):
        assert False

    task.fork(assert_reject, assert_resolve)
