

# Generated at 2022-06-26 00:05:57.764508
# Unit test for method map of class Task
def test_Task_map():
    value = 10
    str_0 = '10'
    test_0 = Task(lambda _, resolve: resolve(value))
    result_0 = test_0.map(str)

# Generated at 2022-06-26 00:06:05.134625
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    str_0 = "CTg&7}u`"
    num_0 = 0
    num_1 = 1
    num_2 = 2
    task_0 = Task.of(str_0)

    # Case 0: (A -> Map)
    def task_0__case_0(task_arg_0):
        return task_arg_0.map(lambda num_1: num_1)

    task_0__case_0 = task_0__case_0(task_0)
    # Case 1: (A -> Map)
    def task_0__case_1(task_arg_0):
        def fn_0(num_0):
            return num_0

        return task_arg_0.map(fn_0)

    task_0

# Generated at 2022-06-26 00:06:14.956627
# Unit test for method map of class Task
def test_Task_map():
    def resolve(arg):
        return arg
    def reject(arg):
        return arg

    def f(value):
        return [int(value)]

    str_0 = 'SBvxxdzE@5'
    task_0 = Task.of(str_0)
    task_1 = Task.reject(str_0)
    task_2 = task_0.map(f)

    assert str_0 == task_0.fork(reject, resolve)
    assert str_0 == task_1.fork(reject, resolve)
    assert f(str_0) == task_2.fork(reject, resolve)
    assert str_0 == task_0.fork(reject, resolve)


# Generated at 2022-06-26 00:06:23.884087
# Unit test for method map of class Task
def test_Task_map():
    def strlen(value):
        return len(value)

    def strlower(value):
        return value.lower()

    def strupper(value):
        return value.upper()

    task_1 = Task.of('abc')

    def bold(value):
        return '<bold>%s</bold>' % value

    def italic(value):
        return '<italic>%s</italic>' % value

    def underline(value):
        return '<underline>%s</underline>' % value

    def highlight(value):
        return '<highlight>%s</highlight>' % value

    task_2 = Task.of('abc')
    task_2 = task_2.map(bold).map(italic).map(underline).map(highlight)


# Generated at 2022-06-26 00:06:27.920244
# Unit test for method bind of class Task
def test_Task_bind():
    # Task.of(15).bind(lambda x: Task.of(x**2))
    assert Task.of(15).bind(lambda x: x**2) == 15**2


if __name__ == '__main__':
    test_case_0()
    test_Task_bind()

# Generated at 2022-06-26 00:06:36.521869
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(1)
    task_1 = task_0.map(lambda arg: arg + 1)
    assert task_1.fork(lambda arg: None, lambda arg: arg) == 2
    task_2 = Task.of([1, 2, 3])
    task_3 = task_2.map(lambda arg: arg[0])
    assert task_3.fork(lambda arg: None, lambda arg: arg) == 1
    task_4 = Task.of({1: 2, 3: 4})
    task_5 = task_4.map(lambda arg: arg[1])
    assert task_5.fork(lambda arg: None, lambda arg: arg) == 2


# Generated at 2022-06-26 00:06:43.918961
# Unit test for method bind of class Task
def test_Task_bind():
    assert 'SBvxxdzE@5'.bind(lambda x: 'U6F8O1').fork(
        lambda x: False,
        lambda x: True if x == 'U6F8O1' else False
    )

    print('Task.bind - passed')

    assert not 'SBvxxdzE@5'.bind(lambda x: 'U6F8O1').fork(
        lambda x: True if x == 'U6F8O1' else False,
        lambda x: False
    )

    print('Task.bind - passed')


# Generated at 2022-06-26 00:06:44.836699
# Unit test for method map of class Task
def test_Task_map():
    test_case_0()


# Generated at 2022-06-26 00:06:49.473196
# Unit test for method bind of class Task
def test_Task_bind():
    result_0 = test_case_0()
    str_0 = 'de:dzE@5'
    equal_0 = assert_equal(result_0, str_0)
    if equal_0:
        print('Test case 0: class [Task] method [bind] work correct')
    else:
        print('Test case 0: class [Task] method [bind] work in-correct')


# Generated at 2022-06-26 00:06:59.518041
# Unit test for method map of class Task
def test_Task_map():
    def task_0():
        return Task(lambda reject, resolve: resolve(2))

    def task_1():
        return Task(lambda reject, resolve: resolve(1))

    def task_2():
        return Task(lambda reject, resolve: reject('err'))


# Generated at 2022-06-26 00:07:06.759114
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'SBvxxdzE@5'

    def fn_0(str_1):
        return str_1

    task_0 = Task.of(str_0)
    task_1 = task_0.map(fn_0)
    assert type(task_1) == Task
    assert task_1.fork(lambda x: None, lambda x: None) == None


# Generated at 2022-06-26 00:07:10.332305
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task

    Test method bind of class Task.

    :return: None
    :rtype: None
    """
    def fn_0(value):
        return value
    task_0 = Task.of(fn_0)
    task_0.bind(fn_0)



# Generated at 2022-06-26 00:07:11.832976
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(5)
    assert isinstance(task_0.map(lambda arg: arg), Task)


# Generated at 2022-06-26 00:07:14.504658
# Unit test for method bind of class Task
def test_Task_bind():
    def x():
        pass

    def y():
        pass

    task = Task(x)
    assert isinstance(task.bind(y), Task), 'test_Task_bind'



# Generated at 2022-06-26 00:07:25.335272
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'SBvxxdzE@5'
    task_0 = Task.of(str_0).bind(lambda arg: Task.reject('Y9'))
    assert(task_0.fork(lambda arg: arg, lambda arg: arg) == 'Y9')

    str_1 = 'gK'
    task_1 = Task.of(str_1).bind(lambda arg: Task.of(arg))
    assert(task_1.fork(lambda arg: arg, lambda arg: arg) == str_1)

    str_2 = '_NkU'
    task_2 = Task.of(str_2).map(lambda arg: arg).bind(lambda arg: Task.reject(arg))
    assert(task_2.fork(lambda arg: arg, lambda arg: arg) == str_2)



# Generated at 2022-06-26 00:07:29.144309
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task.
    """
    fn_0 = lambda arg_0: fn_0(arg_0)
    task_0 = Task.of(fn_0)
    task_1 = task_0.map(str)


# Generated at 2022-06-26 00:07:34.843870
# Unit test for method map of class Task
def test_Task_map():
    # prepare data
    int_0 = 0
    str_0 = 'SBvxxdzE@5'
    str_1 = 'SBvxxdzE@5'

    # call function
    task_0 = Task.of(int_0)
    task_1 = task_0.map(lambda x: str_0)

    # check result
    assert task_1.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == str_1


# Generated at 2022-06-26 00:07:42.738275
# Unit test for method bind of class Task
def test_Task_bind():
    # Assign
    def task_0(reject, resolve):
        def call_0(arg):
            raise TypeError

        def call_1(arg):
            raise IndexError

        return task_1.fork(reject, call_2)
    task_1 = Task(task_0)
    def call_2(arg):
        def call_3(arg):
            pass
        return call_3(arg)

    # Action
    result = task_1.bind(call_2)

    # Assert
    assert type(result) == Task, 'Assertion error: %s not Task' % repr(result)


# Generated at 2022-06-26 00:07:45.540539
# Unit test for method bind of class Task
def test_Task_bind():
    # Test case 0
    task_0 = Task(123)
    task_1 = task_0.bind(14)
    assert task_1.fork(True, False) is False


# Generated at 2022-06-26 00:07:56.261492
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task.
    """
    # Test case 0
    #
    # str_0 = 'SBvxxdzE@5'
    # task_0 = Task(str_0)
    # task_map_0 = task_0.map(lambda arg_0: arg_0 + arg_0)
    #
    # assert task_map_0.fork(
    #     lambda arg: arg,
    #     lambda arg: arg + arg
    # ) == 'SBvxxdzE@5SBvxxdzE@5'
    #
    # Test case 1
    #
    # task_1 = Task(lambda _, resolve: resolve(lambda arg_1: arg_1))
    # task_map_1 = task_1.map(lambda arg_2: arg_

# Generated at 2022-06-26 00:08:02.595488
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda _, resolve: resolve(None))
    task_0 = task.map(lambda arg: arg)
    assert isinstance(task_0, Task)


# Generated at 2022-06-26 00:08:05.781278
# Unit test for method map of class Task
def test_Task_map():
  task_0 = Task.of(0)
  task_1 = task_0.map(lambda x: x + 1)
  return 1 is task_1.fork(
    lambda arg: 1,
    lambda arg: 0
  )


# Generated at 2022-06-26 00:08:12.040737
# Unit test for method bind of class Task
def test_Task_bind():
    # Create new task
    task_0 = Task('R_{UA;D,O')

    # Test bind with map result to str
    task_1 = task_0.bind(lambda value: Task.of(str(value) + " :)"))
    assert task_1.fork(None, None) == 'R_{UA;D,O :)'

    # Test bind with reject
    task_2 = task_0.bind(lambda value: Task.reject(str(value)))
    assert task_2.fork(None, None) == 'R_{UA;D,O'

# Generated at 2022-06-26 00:08:21.858750
# Unit test for method bind of class Task
def test_Task_bind():
    task_reject = Task.of(1)
    task_resolve = Task.of(2)

    def resolve(value):
        return value + 1

    def reject(value):
        return value + 3

    def error_reject(value):
        return value - 1

    def error_resolve(value):
        return value - 3

    task_0 = task_resolve.map(resolve).map(lambda value: value + 3).bind(lambda value: Task.of(value + 5)).map(lambda value: value - 2)
    assert task_0.fork(reject, resolve) == 12

    task_1 = task_resolve.map(error_resolve).map(lambda value: value + 3).bind(lambda value: Task.of(value + 5)).map(lambda value: value - 2)
    assert task

# Generated at 2022-06-26 00:08:29.622793
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value.lower()

    def mapper_with_error(value):
        if value == 'error':
            raise ValueError('foo')
        return value.lower()

    def call_and_resolve():
        task = Task.reject('Error message')

        def resolve_with_lower(value):
            return value.lower()


# Generated at 2022-06-26 00:08:34.211774
# Unit test for method bind of class Task
def test_Task_bind():
    def bind_0(Task):
        def fn_0(value):
            return Task.of(value)
        return Task.bind(fn_0)

    str_1 = 'rYXzhiP_$0'
    task_1 = Task(str_1)

    task_2 = bind_0(task_1)


# Generated at 2022-06-26 00:08:41.672616
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:08:49.066740
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Bind test

    Take function, store it and call with Task value during calling fork function.
    Return result of called.

    :param fn: mapper function
    :type fn: Function(value) -> Task[reject, mapped_value]
    :returns:  new Task with mapper resolve attribute
    :rtype: Task[reject, mapped_value]
    """

    def handler(arg2: str) -> Task:
        return Task(arg2)
    task_0 = Task.of('fL%c6Z')
    task_1 = task_0.bind(handler)
    return (task_1.fork)


# Generated at 2022-06-26 00:08:52.344258
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'SBvxxdzE@5'
    task_0 = Task(str_0)

    def fn_0(x):
        return x + 's'

    task_1 = task_0.map(fn_0)

    assert(task_1.fork == 'SBvxxdzE@5s')


# Generated at 2022-06-26 00:08:56.406768
# Unit test for method map of class Task
def test_Task_map():
    number = 2
    str_0 = str(number)
    task_0 = Task(str_0)
    number = task_0.map(number * number)
    assert number == 4


# Generated at 2022-06-26 00:09:09.133090
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda _, resolve: resolve(1))
    result = task.map(lambda x: x + 1).fork(lambda x: x, lambda x: x)
    assert result == 2, f"Fail: the result is equal {result} instead of 2"
    print("test_Task_map: OK")



# Generated at 2022-06-26 00:09:17.961336
# Unit test for method bind of class Task
def test_Task_bind():
    # Setup
    str_0 = '<l|0@0^D9=B'
    str_1 = '<l|0@0^D9=B'
    str_2 = '<l|0@0^D9=B'
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    #

# Generated at 2022-06-26 00:09:19.992169
# Unit test for method map of class Task

# Generated at 2022-06-26 00:09:25.798287
# Unit test for method map of class Task
def test_Task_map():
    # Case 0
    str_0 = '1Dk9bcl(E@['
    task_0 = Task(str_0)
    str_1 = 'VuPvUr8h7V'
    function_0 = lambda value: str_1 + value
    task_1 = task_0.map(function_0)
    str_2 = 'VuPvUr8h7V1Dk9bcl(E@['
    assert task_1.fork.__name__ == str_2


# Generated at 2022-06-26 00:09:35.146685
# Unit test for method map of class Task
def test_Task_map():
    def test_case_0():
        str_0 = 'SBvxxdzE@5'
        task_0 = Task(str_0)
        fn0 = lambda x: x.upper()
        fn1 = lambda x: x[::-1]
        expected = Task(fn0(str_0))
        actual = task_0.map(fn0)
        print(actual)
        assert actual.fork == expected.fork

        expected = Task(fn1(str_0))
        actual = task_0.map(fn0).map(fn1)
        print(actual)
        assert actual.fork == expected.fork

    def test_case_1():
        str_0 = 'SBvxxdzE@5'
        task_0 = Task(str_0)
        fn0 = lambda x: x.upper

# Generated at 2022-06-26 00:09:44.632360
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'SBvxxdzE@5'
    task_0 = Task.of(str_0)
    task_1 = task_0.bind(lambda str_1: Task.of(str_1[6]))
    assert task_1.fork(lambda str_0: str_0, lambda str_1: str_1) == 'z'
    task_0 = Task.of(str_0)
    task_1 = task_0.bind(lambda str_1: Task.of(str_1[9]))
    assert task_1.fork(lambda str_0: str_0, lambda str_1: str_1) == '5'
    task_0 = Task.of(str_0)

# Generated at 2022-06-26 00:09:48.740499
# Unit test for method bind of class Task
def test_Task_bind():
    # Task -> String
    def stringify_number(number):
        return Task(lambda _, resolve: resolve(str(number)))

    # Task -> Task -> Task
    def sequence(task):
        return task.bind(stringify_number)

    assert sequence(Task.of(1)) == Task(lambda _, resolve: stringify_number(1).fork(_, resolve))


# Generated at 2022-06-26 00:09:54.939249
# Unit test for method map of class Task
def test_Task_map():
    def task_fork_0(reject, resolve):
        return None

    task_0 = Task(task_fork_0)
    executor_0 = Task.of(0)
    result_0 = executor_0.map(lambda arg: arg + 1)
    result_1 = task_0.map(lambda arg: arg + 1)

    # assert isinstance(result_0, Task)
    assert isinstance(result_1, Task)


# Generated at 2022-06-26 00:09:58.787213
# Unit test for method bind of class Task
def test_Task_bind():
    int_1 = -1348482063
    res_2 = int_1 + int_1
    task_3 = Task(lambda x, y: y(res_2))
    res_5 = task_3.bind(lambda x: Task(lambda _r, _y: _y(x - 2)))
    assert res_5.fork(None, None) == 0



# Generated at 2022-06-26 00:10:03.780453
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'sbvxxdze@5'
    task_0 = Task.of(str_0)

    str_1 = 'string'
    task_1 = Task.of(str_1)

    # task_0 binding with task_1
    task_2 = task_0.bind(lambda arg: task_1)
    assert task_2.fork(lambda arg: '', lambda arg: '1') == str_1

    task_3 = task_0.bind(lambda arg: Task.reject(str_1))
    assert task_3.fork(lambda arg: '', lambda arg: '1') == str_1

    task_0 = Task.reject(str_0)
    task_4 = task_0.bind(lambda arg: task_1)

# Generated at 2022-06-26 00:10:27.025856
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'test_Task_bind'
    def def_0(arg_0):
        return Task(arg_0)

    task_0 = Task(def_0)

    assert task_0.bind(def_0).fork('', '') == 'test_Task_bind'


# Generated at 2022-06-26 00:10:32.392571
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case(b, reject, resolve):
        return Task(lambda b, reject, resolve: reject(resolve('pT9DAsvE+'))).bind(lambda reject, b, resolve: reject(b)).fork(lambda reject, resolve: reject(resolve(b)), lambda reject, b, resolve: reject(resolve(reject(b))))

    return test_case('8@cJs', 'v', 'yf')


# Generated at 2022-06-26 00:10:41.539423
# Unit test for method map of class Task
def test_Task_map():
    def assert_mapper(value, fn, expected_value, expected_code):
        task = Task(value)
        result = task.map(fn)
        assert result.fork(
            lambda arg: (arg, 0),
            lambda arg: (arg, 1)
        ) == (expected_value, expected_code)

    # Test for string
    def str_mapper(str_arg):
        return str_arg + '_mapped'

    assert_mapper('SBvxxdzE@5', str_mapper, 'SBvxxdzE@5_mapped', 1)

    # Test for function
    def function_mapper(fn):
        def result(arg):
            return fn(arg) + '_mapped'
        return result


# Generated at 2022-06-26 00:10:46.932969
# Unit test for method bind of class Task
def test_Task_bind():
    print('\n')
    str_0 = 'task of string'
    str_1 = 'other string'
    task_0 = Task.of(str_0)
    task_1 = Task.of(str_1)
    task_0.map(lambda v: print(v))
    task_1.map(lambda v: print(v))


# Generated at 2022-06-26 00:10:55.933526
# Unit test for method bind of class Task
def test_Task_bind():
    _name = Task.of('haskell')
    _age = Task.of(23)
    _user = _name.bind(lambda name: _age.map(lambda age: (name, age)))
    assert _user.fork(print, print) == ('haskell', 23)

    _friends = Task.of(['Mark', 'Dima', 'Kirill'])
    _user2 = _user.bind(
        lambda user: _friends.map(
            lambda friends: (user, friends)
        )
    )
    assert _user2.fork(print, print) == (('haskell', 23), ['Mark', 'Dima', 'Kirill'])



# Generated at 2022-06-26 00:11:01.044740
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task(lambda _, resolve: resolve(1))
    task_1 = task_0.map(lambda arg: arg + 1)

    def assert_function(reject, resolve):
        return task_1.fork(reject, resolve)

    assert assert_function(lambda x: False, lambda y: y == 2)



# Generated at 2022-06-26 00:11:04.437366
# Unit test for method map of class Task
def test_Task_map():
    def map_fn(value):
        return value + 1

    def fork_impl(reject, resolve):
        return resolve(5)

    task = Task(fork_impl)

    assert task.map(map_fn).fork(None, lambda resolved_value: resolved_value == 6)



# Generated at 2022-06-26 00:11:08.036463
# Unit test for method bind of class Task
def test_Task_bind():
    # Run this test case with debug.

    # Unit test for method bind of class Task
    task_0 = Task.of(None)
    task_0 = task_0.bind(lambda str_0: Task.reject('foo'))
    assert task_0.fork(str_0, str_0) == 'foo'

# Generated at 2022-06-26 00:11:18.720844
# Unit test for method bind of class Task
def test_Task_bind():
    def test_Task_bind_0():
        fn_0 = lambda value: Task.reject(value)
        task_0 = Task.of('').bind(fn_0)

    def test_Task_bind_1():
        fn_0 = lambda value: Task.reject(value)
        task_0 = Task.reject('').bind(fn_0)

    def test_Task_bind_2():
        fn_0 = lambda value: Task.of(value)
        task_0 = Task.of('').bind(fn_0)

    def test_Task_bind_3():
        def fn_0(value):
            return Task.of(value)

        fn_0('tr')


# Generated at 2022-06-26 00:11:23.579851
# Unit test for method map of class Task
def test_Task_map():
    # Base test
    str_0 = 'TJT]ngh%h'
    task_0 = Task.of(str_0)

    def mapper(s):
        return s + 'mapper'

    task_1 = task_0.map(mapper)
    assert task_1.fork(lambda x: x, lambda x: x) == str_0 + 'mapper'


# Generated at 2022-06-26 00:12:12.048713
# Unit test for method bind of class Task
def test_Task_bind():
    # Create an instance of class Task
    str_0 = 'V8WcX9L-E7=I_K'
    task_0 = Task.of(str_0)
    # Create another instance of class Task
    str_1 = '-h}0H?yK&6@5'
    task_1 = Task.of(str_1)
    # Function for mapping function
    def fn_0(value):
        return task_1
    # Result of method bind
    str_2 = '-h}0H?yK&6@5'
    task_2 = task_0.bind(fn_0)
    assert str_2 == task_2.fork(lambda reject, resolve: reject(reject), lambda reject, resolve: resolve(resolve))

# Generated at 2022-06-26 00:12:18.538281
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'VqN0q@2o'
    def str_1(str_2):
        def str_3(str_4):
            return str_4.upper()
        return str_3(str_2)
    task_0 = Task.of(str_0)
    task_1 = task_0.map(str_1)
    str_5 = task_1.fork(None, None)
    assert str_5 == str_0.upper()


# Generated at 2022-06-26 00:12:23.968461
# Unit test for method bind of class Task
def test_Task_bind():
    a = [1, 2, 3]

    def inc(x):
        return Task.of(x + 1)

    def dec(x):
        return Task.of(x - 1)

    map_0 = Task.of(a).map(lambda array: [lambda x: x + 1, lambda x: x - 1])
    map_1 = Task.of(a).map(lambda array: [[lambda x: x + 1, lambda x: x - 1], lambda x: x * 3])



# Generated at 2022-06-26 00:12:26.801688
# Unit test for method bind of class Task
def test_Task_bind():
    # test_case_0()
    is_pass_0 = True
    assert is_pass_0, 'Fail test_Task_bind'



# Generated at 2022-06-26 00:12:35.684925
# Unit test for method bind of class Task
def test_Task_bind():
    # str_0 = 'SBvxxdzE@5'

    def mapped_fn_0(value_0):
        return value_0 ** 2

    def mapped_fn_1(value_0):
        return value_0 ** 3

    def mapped_fn_2(value_0):
        return Task.of(mapped_fn_1(mapped_fn_0(value_0)))

    task_0 = Task.of(5)
    task_1 = task_0.bind(mapped_fn_2)
    task_2 = task_1.map(lambda value_0: value_0 ** 2)
    task_3 = task_2.map(lambda value_0: value_0 ** 3)
    task_4 = task_3.bind(lambda value_0: Task.of(value_0))#

# Generated at 2022-06-26 00:12:42.061175
# Unit test for method map of class Task
def test_Task_map():
    @asyncio.coroutine
    def test_case_1():
        pass

    @asyncio.coroutine
    def test_case_2():
        pass

    @asyncio.coroutine
    def test_case_3():
        pass

    @asyncio.coroutine
    def test_case_4():
        pass

    @asyncio.coroutine
    def test_case_5():
        pass

    @asyncio.coroutine
    def test_case_6():
        pass

    @asyncio.coroutine
    def test_case_7():
        pass

    @asyncio.coroutine
    def test_case_8():
        pass

    @asyncio.coroutine
    def test_case_9():
        pass


# Generated at 2022-06-26 00:12:45.383413
# Unit test for method bind of class Task
def test_Task_bind():
    tsk = Task.of('xx')
    result = tsk.bind(lambda x: Task.of(x + '-foo'))
    assert(result.fork(None, lambda x: x == 'xx-foo'))


# Generated at 2022-06-26 00:12:54.573512
# Unit test for method map of class Task
def test_Task_map():
    """
    test_Task_map() is a unit test for method Task.map() of class Task
    it takes no arguments and returns no values

    test_Task_map() tests are in the form of assertions.
    If any of the assertions fail, then the test case fails.

    Input:
        test_Task_map() takes no arguments
    Return:
        test_Task_map() returns no values

    """
    # Test Case 1 of Task.map()
    # inputs
    str_1 = "Some random text"
    task_1 = Task.of(str_1)
    new_task_1 = task_1.map(lambda x: str(x).upper())

    # outputs
    expected_new_task_1 = Task.of(str_1.upper())

    # assertion

# Generated at 2022-06-26 00:13:01.086041
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'Zz'
    str_1 = 'OFTq_cp2Ao'
    proc_0 = Task(str_0)
    def func_0(arg_0):
        int_0 = arg_0
        return arg_0
    proc_1 = proc_0.map(func_0)
    assert proc_1.fork == (str_0)
    str_2 = '4b'
    proc_2 = Task(str_1)
    proc_3 = proc_2.map(lambda arg_0: arg_0)
    assert proc_3.fork == (str_1)


# Generated at 2022-06-26 00:13:10.105087
# Unit test for method map of class Task
def test_Task_map():
    def test_0():
        task_0 = Task.of(1)
        task_1 = task_0.map(lambda v: v + 1)
        assert task_0.fork(lambda _: 0, lambda v: v) == 1
        assert task_1.fork(lambda _: 0, lambda v: v) == 2

    def test_1():
        task_0 = Task.reject(1)
        task_1 = task_0.map(lambda v: v + 1)
        assert task_0.fork(lambda v: v, lambda _: 0) == 1
        assert task_1.fork(lambda v: v, lambda _: 0) == 1

    def test_2():
        task_0 = Task.of(1)
        task_1 = task_0.map(lambda v: 0)

# Generated at 2022-06-26 00:14:51.124327
# Unit test for method bind of class Task
def test_Task_bind():
    def func_0(reject, resolve):
        if 0 != 0:
            reject(0)
            return
        resolve(0)

    def func_1(arg):
        if arg == 0:
            return Task(func_0)
        else:
            return Task(func_0)

    task_0 = Task(func_0)
    try:
        result = task_0.bind(func_1)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 00:14:53.678544
# Unit test for method bind of class Task
def test_Task_bind():
    def str_0(arg):
        return Task.of(arg.upper())

    output = Task.of('abc').bind(str_0)
    expect = 'ABC'
    assert output == expect


# Generated at 2022-06-26 00:15:00.470516
# Unit test for method map of class Task
def test_Task_map():
    # Task
    str_0 = 'SBvxxdzE@5'
    task_0 = Task(str_0)

    # str -> int
    def f(x):
        try:
            return int(x)
        except:
            return 0

    # Task(str)
    def g(x):
        try:
            return int(x)
        except:
            return 0

    # int -> Task[int]
    def h(x):
        return Task.of(x)

    # Task(str) -> Task[int]
    # Result of task_0.map(f).map(h)
    # deprecated
    task_1 = task_0.map(f).map(h)
    #new
    task_1 = task_0.map(h).map(f)

    # Task(

# Generated at 2022-06-26 00:15:04.825867
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'SBvxxdzE@5'
    task_0 = Task(str_0)
    str_1 = 'SBvxxdzE@5'
    task_1 = Task(str_1)
    def fn_0(value):
        return task_1
    task_2 = task_0.bind(fn_0)
    str_2 = task_2.fork()
    assert(str_0 == str_2)


# Generated at 2022-06-26 00:15:10.648427
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task(lambda _, resolve: resolve(
        'Hello ' + 'world!'
    ))
    assert task_0.map(lambda value: value + '!').fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 'Hello world!!'

    task_1 = Task(lambda reject, _: resolve('Hello world!'))
    assert task_1.map(lambda value: value + '!').fork(
        lambda arg: arg,
        lambda _: None
    ) == 'Hello world!'



# Generated at 2022-06-26 00:15:13.661882
# Unit test for method map of class Task
def test_Task_map():
    # str_0 = 'SBvxxdzE@5'
    # task_0 = Task(str_0)
    test_case_0()


# Generated at 2022-06-26 00:15:21.727863
# Unit test for method map of class Task
def test_Task_map():
    def test_case_1():
        """Test result of mapping over Task instance with resolve value"""
        str_0 = 'fA/0rEAg8e'
        task_0 = Task.of(str_0)
        str_1 = 'rI=nf47'
        assert not task_0.map(lambda x: '{0}{1}'.format(x, str_1)).fork(None, assert_equal_to_expected)

    def test_case_2():
        """Test result of mapping over Task instance with reject value"""
        str_0 = '1gixdJ'
        task_0 = Task.reject(str_0)
        str_1 = 'NcI{'

# Generated at 2022-06-26 00:15:25.996509
# Unit test for method bind of class Task
def test_Task_bind():
    t1 = Task.of(1)
    t2 = t1.bind(lambda x: Task.of(x + 1))
    assert t2.fork(lambda err: -1, lambda val: val) == 2

    try:
        t2 = t1.bind(lambda x: Task.reject(x + 1))
        assert t2.fork(lambda err: -1, lambda val: val) == -1
    except:
        pass


# Generated at 2022-06-26 00:15:32.127395
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(None)

    task_1 = task_0.bind(lambda _: Task.of(None))

    task_2 = task_1.map(lambda _: None)

    def foo(_):
        def bar(_):
            def baz(_):
                return Task.of(None)

            return Task.of(baz)

        return Task.of(bar)

    task_3 = task_2.bind(foo)

    task_4 = task_3.map(lambda _: None).bind(lambda _: Task.of(None))



# Generated at 2022-06-26 00:15:36.350233
# Unit test for method bind of class Task
def test_Task_bind():
    test_resolve_0 = Task.of(42).bind(lambda x: Task.of(x + 1))
    assert test_resolve_0.fork(None, lambda x: x) == 43
    test_reject_0 = Task.reject(42).bind(lambda x: Task.reject(x + 1))
    assert test_reject_0.fork(lambda x: x, None) == 42
