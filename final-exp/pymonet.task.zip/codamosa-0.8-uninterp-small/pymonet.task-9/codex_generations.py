

# Generated at 2022-06-26 00:05:58.264310
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:06:05.420335
# Unit test for method bind of class Task
def test_Task_bind():
    def show(arg):
        print(arg)
        return Task(None)

    def to_int(arg):
        return Task.of(int(arg))

    def on_error(error):
        print('Error')
        return Task.reject(error)

    def on_success(value):
        print('Success')
        return Task.of(value)

    class App:
        """
        Application class is a Context for Task.
        """
        def exec(self, task):
            """
            Start execution of task, call fork function and execute resolve or reject callbacks.

            :param task: Task object to execute
            :type task: Task
            """
            task.fork(
                on_error,
                on_success
            )

    # test case 1: map and bind
    # expected result: 'Success'


# Generated at 2022-06-26 00:06:11.467069
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task

    Check case with passing argument to Task constructor and call map method with
    identity function.
    """
    str_0 = 'B%5'
    task_0 = Task(lambda _, resolve: resolve(str_0))
    task_1 = task_0.map(lambda value: value)

    assert task_1.fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 'B%5'



# Generated at 2022-06-26 00:06:15.400894
# Unit test for method bind of class Task
def test_Task_bind():
    b = Task.of(1)
    a = b.bind(lambda x: Task.of(x + 10))
    c = a.fork(lambda _: None, lambda x: print(x))
    c


# Generated at 2022-06-26 00:06:19.169731
# Unit test for method map of class Task
def test_Task_map():
    def add_1(value):
        return value + 1

    def str_and_add_1(value):
        return 'a' + add_1(value)

    assert Task.of(1).map(add_1).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(str_and_add_1).fork(lambda x: x, lambda x: x) == 'a2'



# Generated at 2022-06-26 00:06:24.498895
# Unit test for method map of class Task
def test_Task_map():
    def add_a(str_x):
        return 'a' + str_x

    str_0 = 'hello'
    task_0 = Task(str_0)
    changed_task = task_0.map(add_a)

    assert(changed_task.fork(None, lambda str_x: str_x)) == 'ahello'



# Generated at 2022-06-26 00:06:34.250593
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of('Task')
    map_0 = task_0.map(lambda arg: arg.upper())

# Generated at 2022-06-26 00:06:42.303501
# Unit test for method bind of class Task
def test_Task_bind():
    def task_fork_0(reject, resolve):
        resolve('B%5')

        def fn_0(value_0):
            task_fork_0_0 = lambda _, resolve: resolve(value_0.upper())
            task_0 = Task(task_fork_0_0)
            return task_0

        task_0 = Task(task_fork_0)
        task_1 = task_0.bind(fn_0)
        return task_1.fork(reject, resolve)

    value_0 = task_fork_0(None, None)
    assert value_0 == 'B%5'



# Generated at 2022-06-26 00:06:47.790037
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'B%5'
    str_1 = 'B%5'
    str_2 = 'B%5'
    task_0 = Task.of(str_0)
    task_1 = task_0.map(lambda str_0: str_0)
    task_2 = task_1.map(lambda str_1: str_1)
    assert task_2.fork(str_1, str_2) == 'B%5'


# Generated at 2022-06-26 00:06:58.720201
# Unit test for method bind of class Task
def test_Task_bind():
    # Verify that method map in class Task is as expected
    # Create a Task instance with function str_0 as argument
    str_0 = "ab."
    str_1 = "ab%"
    str_2 = "ABC"
    task_0 = Task(lambda reject, resolve: resolve(str_0))
    task_1 = Task(lambda reject, resolve: resolve(str_1))
    task_2 = Task(lambda reject, resolve: resolve(str_2))
    # Create Task instance using of function
    task_of = Task.of(str_0)
    # Create a Task instance using method bind
    task_bind_0 = task_0.bind(lambda arg: Task.of(arg.upper()))
    # Create a Task instance using method bind

# Generated at 2022-06-26 00:07:07.212726
# Unit test for method map of class Task
def test_Task_map():
    """
    Test case:
    Task.map((str) -> int)({
        'fork': (lambda reject, resolve) -> resolve(str_0),
        'map': (lambda value) -> str_0
    })
    """

    str_0 = '1234'
    int_0 = 1234

    task_0 = Task.of(str_0)
    task_1 = task_0.map(int)

    assert task_1.fork(lambda x: x, lambda x: x) == int_0

# Generated at 2022-06-26 00:07:11.555437
# Unit test for method map of class Task
def test_Task_map():
    mock_0 = Mock()
    mock_1 = Mock()
    task_0 = Task.of(None)
    task_0.map(mock_0)
    task_0.map(mock_1)
    task_0.fork(lambda _: None, lambda _: None)
    mock_0.assert_called_with(None)
    mock_1.assert_called_with(None)

# Generated at 2022-06-26 00:07:23.450175
# Unit test for method bind of class Task
def test_Task_bind():
    def foo(x):
        return Task.of(x + 0)


# Generated at 2022-06-26 00:07:28.122205
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of('10')
    async def fn_0(x):
        return int(x)
    with pytest.raises(ValueError):
        task_0.map(fn_0)


if __name__ == '__main__':
    test_case_0()
    test_Task_map()

# Generated at 2022-06-26 00:07:32.113738
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(1)
    task_1 = task_0.map(lambda x: x + 5)
    # expect
    assert task_1.fork(
        lambda arg: None, lambda arg: arg
    ) == 6



# Generated at 2022-06-26 00:07:40.018315
# Unit test for method bind of class Task
def test_Task_bind():
    # Test data
    str_0 = 'B%5'
    str_1 = 'Привет!'
    str_2 = 'B%5Привет!B%5Привет!'
    str_3 = 'Hello, world!'
    str_4 = 'B%5Привет!B%5Привет!B%5Hello, world!'
    # Test function
    def func_0(value):
        assert value == str_0
        return Task.of(str_1)

    def func_1(value):
        assert value == str_1
        return Task.of(value + value)

    def func_2(value):
        assert value == str_2
        return Task.of(str_3)


# Generated at 2022-06-26 00:07:50.196294
# Unit test for method map of class Task
def test_Task_map():
    # Testing map with simple argument:
    # (resolve, reject) -> resolve('123')
    def argument(resolve, reject):
        return resolve('123')

    # + fn: (value) -> '456'
    # => result: (resolve, reject) -> resolve('123')
    #           => resolve('456')
    #           => resolve('456')
    #           => resolve('456')
    fn = lambda x: '456'
    result_task = Task(argument).map(fn)
    assert result_task.fork(None, None) == '456'

    # Testing map with maped argument:
    # (resolve, reject) -> resolve('123')
    # + fn: (value) -> '456'
    # => (resolve, reject) -> resolve('456')
    # => (resolve, reject)

# Generated at 2022-06-26 00:07:57.611893
# Unit test for method bind of class Task
def test_Task_bind():
    test_0 = Task(
        lambda _, resolve: resolve('foo')
    )

    test_1 = Task.of('foo')

    assert test_0.bind(lambda value: Task.of(value)) == test_1


# Generated at 2022-06-26 00:08:03.529513
# Unit test for method map of class Task
def test_Task_map():
    """
    Check map method of class Task
    """
    # WHEN
    fact_arg = 5
    arg = 10
    fact_fn = factorial(fact_arg)
    expected = fact_fn(arg)
    mapper_fn = factorial(fact_arg)

    task = Task.of(arg)
    task = task.map(mapper_fn)

    # THEN
    assert task.fork(lambda err: False, lambda value: value) == expected



# Generated at 2022-06-26 00:08:10.376547
# Unit test for method map of class Task
def test_Task_map():
    # Create task, call map function and test result
    task = Task.of(1)

    def fn_0(value):
        print('called')
        return value + 1

    mapped_task_0 = task.map(fn_0)

    def mapped_task_0_resolver(resolve, reject):
        def reject_0(value):
            raise 'error'

        def resolve_0(value):
            assert value == 2, 'resolve value of mapped task must be 2'

        mapped_task_0.fork(reject_0, resolve_0)

    mapped_task_0_resolver(None, None)



# Generated at 2022-06-26 00:08:24.695168
# Unit test for method bind of class Task
def test_Task_bind():

    def test_case_0():
        task_0 = Task.of('B%5')

# Generated at 2022-06-26 00:08:30.511222
# Unit test for method map of class Task
def test_Task_map():
    # Create string which will be used as test value
    str_0 = 'Hello, my name is Albert!'

    # Task with resolve string
    task_0 = Task.of(str_0)

    # Task with resolve length of string above
    task_1 = task_0.map(lambda arg: len(arg))

    # Check length of string in task 0 and in task 1
    assert len(str_0) == task_0.fork(lambda _: -1, lambda arg: len(arg))
    assert len(str_0) == task_1.fork(lambda _: -1, lambda arg: arg)

    print('Task.map() test successful!')


# Generated at 2022-06-26 00:08:38.611701
# Unit test for method map of class Task
def test_Task_map():
    # Initialize
    value = 5
    mapper = lambda x: x * x
    expected = 25
    # Set up
    task = Task.of(value)
    # Execute
    result = task.map(mapper)
    # Verify
    def check(fn):
        """
        Use this function in fork arguments,
        this handle result of fork and check result value
        """
        def handler_0(val):
            assert val == expected
        def handler_1(error):
            raise error
        fn(handler_0, handler_1)
    result.fork(check)


# Generated at 2022-06-26 00:08:46.342193
# Unit test for method bind of class Task
def test_Task_bind():
    # test for successful case
    str_0 = 'B%5'
    str_1 = str(str_0).replace('%', '^')
    task_0 = Task.of(str_0).bind(lambda arg: Task.of(str_1))
    assert task_0.fork(
        lambda arg: None,
        lambda arg: arg
    ) == str_1

    # test for error case
    task_1 = Task.reject(str_0).bind(lambda arg: Task.of(str_1))
    assert task_1.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == str_0


# Generated at 2022-06-26 00:08:53.456184
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'B%5'
    task_0 = Task(lambda reject, resolve: resolve(str_0))

    def mapper(x):
        return Task(lambda reject, resolve: resolve(x.lower()))

    def mapper_1(x):
        return Task(lambda reject, resolve: resolve(x.upper()))

    task_1 = task_0.bind(mapper)
    task_1.fork(
        lambda arg: assert_(arg == 'b%5'),
        lambda arg: assert_(arg == 'b%5')
    )

    task_2 = task_1.bind(mapper_1)
    task_2.fork(
        lambda arg: assert_(arg == 'B%5'),
        lambda arg: assert_(arg == 'B%5')
    )


# Generated at 2022-06-26 00:09:01.513227
# Unit test for method map of class Task
def test_Task_map():
    def test_case_1():
        str_1 = 'B%^()'
        task_1 = Task.of(str_1)
        check.equal(
            task_1.map(urllib.quote).value,
            urllib.quote(str_1)
        )

    def test_case_2():
        str_2 = 'B%^()'
        task_2 = Task.reject(str_2)
        check.equal(
            task_2.map(urllib.quote).value,
            str_2
        )


# Generated at 2022-06-26 00:09:08.931381
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of Task class.
    """
    def test_Task(task, expected):
        """
        Checking map function of Task class

        :param task: Task instance
        :type task: Task
        :param expected: expected value
        :type expected: Boolean
        :returns: pass/fails of test
        :rtype: Boolean
        """
        task = task.map(lambda arg: arg + '_')
        return task.fork(
            lambda reject: reject == expected,
            lambda resolve: resolve == expected
        )

    # Test map function of Task class
    return test_Task(Task(lambda _, resolve: resolve('foo')), 'foo_')



# Generated at 2022-06-26 00:09:16.237864
# Unit test for method map of class Task
def test_Task_map():
    """
    Check if method map is running properly
    """
    ########################
    # Test data (mock)
    ########################
    def mock_function(value):
        return value + 1

    def mock_fork(reject, resolve):
        return resolve(10)

    mock_input = Task(mock_fork)


    ########################
    # Call method map
    ########################
    task_output = mock_input.map(mock_function)


    ########################
    # Tests
    ########################
    assert task_output.fork(lambda arg: reject(arg), lambda arg: resolve(arg)) == 11



# Generated at 2022-06-26 00:09:25.028515
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(2)

    task_0 = Task(fork)
    def to_string(integer):
        return str(integer)

    task_1 = task_0.map(to_string)
    def add_1(string):
        return Task(lambda _, resolve: resolve(string + '1'))

    task_2 = task_1.bind(add_1)
    def add_2(string):
        return Task(lambda _, resolve: resolve(string + '2'))

    task_3 = task_2.bind(add_2)
    def add_3(string):
        return Task(lambda _, resolve: resolve(string + '3'))

    task_4 = task_3.bind(add_3)

    # resolve task_4

# Generated at 2022-06-26 00:09:26.205061
# Unit test for method map of class Task
def test_Task_map():
    # TODO: implement real test instead of assert True
    assert True


# Generated at 2022-06-26 00:09:45.671090
# Unit test for method map of class Task
def test_Task_map():
    # Hint: Task.of = lambda value: Task(lambda _, resolve: resolve(value))
    Task.of(42).map(lambda value: value + 37).fork(lambda reject: None, lambda resolve: print(resolve))
    Task.of(42).map(lambda value: value + 37).fork(lambda reject: print(reject), lambda resolve: None)
    Task.of(42).map(lambda value: value + 37).fork(lambda reject: print(reject), lambda resolve: None)

# Generated at 2022-06-26 00:09:53.941765
# Unit test for method bind of class Task
def test_Task_bind():
    """
        Test bind method of class Task.
        Call bind method, with value 3 for calculations.
        Test fork with resolve
        Test fork with reject
    """
    str_0 = 'B%5'
    task_0 = Task(str_0)
    task_1 = task_0.bind(lambda x: Task.of(x + 1))

    assert task_1.fork(lambda x: False, lambda x: x == 6)

    task_0 = Task(str_0)
    task_1 = task_0.bind(lambda x: Task.reject(x + 1))

    assert task_1.fork(lambda x: x == 6, lambda x: False)



# Generated at 2022-06-26 00:10:01.440446
# Unit test for method map of class Task
def test_Task_map():
    string_0 = 'A'
    string_1 = 'B'
    task = Task.of(string_0)
    def map_0(value):
        """
        :param value: value to append
        :type value: string
        :returns: appended value
        :rtype: string
        """
        return string_1 + value

    task_0 = task.map(map_0)
    def fork_0(reject, resolve):
        """
        :param reject: reject function
        :type reject: Function(value) -> Any
        :param resolve: resolve function
        :type resolve: Function(value) -> Any
        :returns: result of resolve function
        :rtype: Any
        """
        return resolve(string_1 + string_0)

    task_1 = Task(fork_0)



# Generated at 2022-06-26 00:10:04.097208
# Unit test for method map of class Task
def test_Task_map():
    def func(val):
        return val + 1

    task = Task.of(2)
    task1 = task.map(func)

    assert task1.fork(lambda e: e, lambda a: a) == 3



# Generated at 2022-06-26 00:10:07.403581
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of('B%5').map(lambda x: x + '0')
    assert result.fork(
        lambda error: False,
        lambda value: value == 'B%50'
    )


# Generated at 2022-06-26 00:10:17.459554
# Unit test for method map of class Task
def test_Task_map():
    def test_case_1():
        """
        Test case:
            call_fn 0 -> 'B'
            call_fn 1 -> '%'
            call_fn 2 -> '5'
            call_fn 3 -> 'second_str_0'
        """
        str_0 = 'B%5'
        task_0 = Task.of(str_0)
        fn_0 = lambda str_arg: str_arg[0]
        fn_1 = lambda str_arg: str_arg[1]
        fn_2 = lambda str_arg: str_arg[2]
        fn_3 = lambda str_arg: 'second_str_0'

        task_1 = task_0.map(fn_0)
        task_2 = task_0.map(fn_1)

# Generated at 2022-06-26 00:10:19.990170
# Unit test for method bind of class Task
def test_Task_bind():
    @task.bind(lambda x: Task.of(x+1))
    def test_1(arg):
        assert arg == 1
        return arg+1


# Generated at 2022-06-26 00:10:22.591139
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """

    def bind_fn(value):
        return Task.of(value * value)

    assert Task.of(2).bind(bind_fn).fork(None, lambda value: value) == 4

# Generated at 2022-06-26 00:10:26.856914
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    """

    # Case 0
    str_0 = 'B%5'
    task_0 = Task(str_0)
    assert str_0 is task_0.fork
    assert 'B%5' is task_0.fork

# Generated at 2022-06-26 00:10:32.555018
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'B%5'
    str_encoded = 'B%255'
    
    task_0 = Task.of(str_0)
    task_encoded = task_0.bind(lambda arg: Task.of(parse.quote(arg)))
        
    assert task_0.fork(lambda arg: arg, lambda arg: arg) == str_0
    assert task_encoded.fork(lambda arg: arg, lambda arg: arg) == str_encoded

# Generated at 2022-06-26 00:10:53.926203
# Unit test for method map of class Task
def test_Task_map():

    def mapper(value):
        return value + 42

    str_0 = 'B%5'
    task_0 = Task.of(str_0)
    mapped = task_0.map(mapper)
    assert mapped.fork(lambda x: "", lambda x: x) == "B%542"



# Generated at 2022-06-26 00:10:56.795665
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(42)
    fn_0 = lambda arg: arg + 1

    assert task_0.map(fn_0).fork(None, lambda arg: arg) == 43


# Generated at 2022-06-26 00:11:05.710204
# Unit test for method bind of class Task
def test_Task_bind():
    asserts = [
        {
            'description': 'return rejected task',
            'input': {
                'task': Task.reject(0),
                'fn': lambda _: Task.reject(1)
            },
            'structure': {
                'resolved': False,
                'value': 1
            }
        },
        {
            'description': 'return resolved task',
            'input': {
                'task': Task.of(1),
                'fn': lambda _: Task.of(2)
            },
            'structure': {
                'resolved': True,
                'value': 2
            }
        }
    ]


# Generated at 2022-06-26 00:11:16.113021
# Unit test for method bind of class Task
def test_Task_bind():
    @add_stack_trace
    def test(value):
        return Task.of(value + 1)

    @add_stack_trace
    def test_2(value):
        return Task.reject(value + 2)

    @add_stack_trace
    def test_3(value):
        return Task.reject(value + 3)

    @add_stack_trace
    def test_4(value):
        return Task.reject(value + 4)

    @add_stack_trace
    def test_map(value):
        return value + 1

    @add_stack_trace
    def test_map_2(value):
        return value + 2

    @add_stack_trace
    def test_map_3(value):
        return value + 3

    # unit-test

# Generated at 2022-06-26 00:11:24.264524
# Unit test for method map of class Task
def test_Task_map():
    def test_0():
        assert Task.of(1).map(lambda a: a + 1).fork(False, 0) == 2
    def test_1():
        assert Task.of(1).map(lambda a: a + 1).fork(lambda value: value, False) == 1
    def test_2():
        assert Task.reject(2).map(lambda a: a + 1).fork(False, 0) == 2
    def test_3():
        assert Task.reject(2).map(lambda a: a + 1).fork(lambda value: value , False) == 2

    test_0()
    test_1()
    test_2()
    test_3()


# Generated at 2022-06-26 00:11:27.466959
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of('pyramid')
    mapped = task_0.map(lambda string: 'PYRAMID')

    def check_resolved(resolved):
        assert resolved == 'PYRAMID'

# Generated at 2022-06-26 00:11:38.139524
# Unit test for method bind of class Task
def test_Task_bind():
    # Case 0
    str_0 = 'B%5'
    expected_result = 'B%5'
    task_0 = Task.of(str_0)
    actual_result = task_0.bind(lambda m: m)
    assert actual_result.fork(lambda s: s, lambda s: s) == expected_result

    # Case 1
    str_1 = 'B%5%5'
    expected_result = 'B%5'
    task_1 = Task.of(str_1).bind(lambda m: m.split('%')[0])
    actual_result = task_1.fork(lambda s: s, lambda s: s)
    assert actual_result == expected_result

    # Case 2
    str_2 = 'B%5%5'
    expected_result = 'B%5'


# Generated at 2022-06-26 00:11:47.493804
# Unit test for method map of class Task
def test_Task_map():
    def str_0(str_0):
        return 'B%5'

    def str_1(str_0):
        return 'B%5'

    def str_2(str_0):
        return 'B%5'

    task_0 = Task(str_0)
    task_1 = task_0.map(str_1)
    task_2 = task_1.map(str_2)


# Generated at 2022-06-26 00:11:54.716485
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(2).bind(lambda x: Task.of(x + 2)).fork(lambda err: -1, lambda y: y) == 4
    assert Task.reject(1).bind(lambda x: Task.reject(x + 1)).fork(lambda err: -1, lambda y: y) == -1
    assert Task.of(1).bind(lambda x: Task.reject(x + 1)).fork(lambda err: -1, lambda y: y) == -1
    assert Task.of(1).bind(lambda x: Task.bind(x + 1)).fork(lambda err: -1, lambda y: y) == -1


# Generated at 2022-06-26 00:12:05.615079
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'B%5'
    task_0 = Task.of(str_0)

    task_1 = task_0.bind(lambda arg: Task.of(int(arg, 16)))

    def task_2(reject, resolve):
        return task_1.fork(
            reject,
            lambda arg: resolve(arg + 1)
        )

    task_3 = Task(task_2)
    task_4 = task_3.bind(lambda arg: Task.of(arg))

    def test_0(reject, resolve):
        return task_4.fork(
            reject,
            resolve
        )

    task_5 = Task(test_0)


# Generated at 2022-06-26 00:12:53.728434
# Unit test for method map of class Task
def test_Task_map():
    # expected result
    expected = Task('%s#%s#%s#%s#' % ('A', 'B', 'C', 'D'))
    result = Task('A') \
        .map(lambda arg: arg + '#') \
        .map(lambda arg: arg + 'B') \
        .map(lambda arg: arg + '#') \
        .map(lambda arg: arg + 'C#') \
        .map(lambda arg: arg + 'D#')
    assert expected == result

if __name__ == '__main__':
    test_Task_map()

# Generated at 2022-06-26 00:13:01.744145
# Unit test for method bind of class Task
def test_Task_bind():

    def task1():
        """
        :returns: Task instance
        :rtype: Task[..., 5]
        """
        def fork(reject, resolve):
            return resolve(5)

        return Task(fork)

    def task2():
        """
        :returns: Task instance
        :rtype: Task[..., 5]
        """
        def fork(reject, resolve):
            return resolve(6)

        return Task(fork)

    def fn(value):
        """
        :param value: mapper function
        :type value: int
        :returns: Task instance
        :rtype: Task[..., value]
        """
        def fork(reject, resolve):
            return resolve(value)

        return Task(fork)

    task1_instance = task1()
    task2_

# Generated at 2022-06-26 00:13:03.609724
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'B%5'
    task_0 = Task.of(str_0)
    task_1 = task_0.map(lambda x: x.replace('%5', ' '))
    assert task_1.fork(lambda x: 0, lambda x: x) == 'B '



# Generated at 2022-06-26 00:13:07.402160
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'B%5'
    task_0 = Task.of(str_0)
    task_1 = task_0.bind(lambda x: Task.of(x.upper()))
    assert task_1.fork(lambda x: x, lambda x: x) == 'B%5'.upper()




# Generated at 2022-06-26 00:13:12.696689
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'B%5'

    def fn(str):
        return len(str)

    task_0 = Task.of(str_0)
    task_1 = task_0.map(fn)
    result_0 = task_1.fork(lambda x: None, lambda x: x)

    assert str_0 == str_0
    assert result_0 == fn(str_0)


# Generated at 2022-06-26 00:13:16.302122
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'A%5'
    str_1 = 'B%5'

    task_0 = Task.reject(str_0)
    task_1 = Task.reject(str_1)
    task_0.bind(lambda arg: task_1)

# Generated at 2022-06-26 00:13:18.378791
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x + 1).fork(
        lambda x: False,
        lambda x: x == 3
    )


# Generated at 2022-06-26 00:13:21.634223
# Unit test for method map of class Task
def test_Task_map():
    t = Task(lambda _, resolve: resolve('A'))
    print(t.map(lambda s: s.lower()).fork(
        lambda s: print('REJECT: %s' % s),
        lambda s: print('RESOLVED: %s' % s)
    ))


# Generated at 2022-06-26 00:13:24.682005
# Unit test for method map of class Task
def test_Task_map():
    from json import dumps
    from urllib.request import urlopen
    def fetch(url):
        return Task(lambda reject, resolve: urlopen(url))

    def fetch_json(url):
        return fetch(url).map(dumps)

    Task.of(fetch_json('https://www.google.com/'))



# Generated at 2022-06-26 00:13:32.170111
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(7)
    task_1 = task_0.bind(lambda x: Task.of(x + ' mno'))
    assert task_1.fork(None, 'mno') == 'mno'

    task_2 = task_0.bind(lambda x: Task.of(x + ' mno'))
    assert task_2.fork(None, 'pqr') == 'pqr'

    task_0 = Task.of('B%5')
    task_0.bind(lambda x: Task.of(x + ' mno'))
    assert task_0.fork(None, 'pqr') == 'pqr'



# Generated at 2022-06-26 00:15:14.313735
# Unit test for method bind of class Task
def test_Task_bind():
    test_case_0()  # TypeError: __init__() takes exactly 2 arguments (3 given)

if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-26 00:15:17.602228
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of('hello')\
        .map(lambda x: x.upper())\
        .map(lambda x: x + '!')\
        .fork(None, lambda x: x)

    assert result == 'HELLO!'


# Generated at 2022-06-26 00:15:19.378706
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(10).map(lambda x: x + 2).fork(None, lambda x: x == 12)


# Generated at 2022-06-26 00:15:22.649911
# Unit test for method map of class Task
def test_Task_map():
    counter = 0
    task = Task.of(1).map(lambda arg: arg + 1).map(lambda arg: arg + 1)

    def assert_result(task_value):
        nonlocal counter
        counter += 1
        assert counter == task_value

    task.fork(lambda _: None, assert_result)


# Generated at 2022-06-26 00:15:29.994114
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task map method.
    """
    from utils import Task
    
    def resolve(value):
        print('resolved task')
        print(value)

    def reject(value):
        print('rejected task')
        print(value)

    def multiply_by_2(value):
        return value * 2

    def multiply_by_3(value):
        return value * 3

    def map_fn(value):
        return value + 5
    
    def bind_fn(value):
        return Task.of('rejected value')

    task = Task(lambda reject, resolve: resolve(5))

    task_mapped_2 = task.map(multiply_by_2)
    task_mapped_2.fork(reject, resolve)


# Generated at 2022-06-26 00:15:33.332500
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(2)
    mapped = 1
    def func_0(value):
        return value + mapped

    task_1 = task_0.map(func_0)
    assert task_1.fork(None, None) == 3


# Generated at 2022-06-26 00:15:39.504914
# Unit test for method bind of class Task
def test_Task_bind():

    def fn(value):
        return Task.of(str(value) + "1")

    # Test method with a resolved Task
    task = Task.of("fizz")
    mapped_task = task.bind(fn)
    assert "fizz1" == mapped_task.fork(lambda value: None, lambda value: value)
    assert fn(1).fork(lambda value: None, lambda value: value) == "11"

    # Test method with a rejected Task
    assert Task.reject(1).bind(fn).fork(lambda value: value, lambda value: None) == 1
    assert Task.of(["foo", "bar"]).bind(fn).fork(lambda value: None, lambda value: value) == "foo"



# Generated at 2022-06-26 00:15:45.966871
# Unit test for method bind of class Task
def test_Task_bind():
    # Case 0
    task_0 = Task.of(0)
    task_1 = task_0.bind(
        lambda x0: Task.of(x0 + 1)
    )
    result = task_1.fork(
        lambda x0: x0,
        lambda x0: x0
    )
    assert result == 1

    # Case 1
    task_0 = Task.of(0)
    task_1 = task_0.bind(
        lambda x0: Task.reject(x0 - 1)
    )
    result = task_1.fork(
        lambda x0: x0,
        lambda x0: x0
    )
    assert result == -1

    # Case 3
    task_0 = Task.reject(0)