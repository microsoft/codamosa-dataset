

# Generated at 2022-06-26 00:05:49.922776
# Unit test for method bind of class Task
def test_Task_bind():
    float_0 = -1132.1563179320397
    task_0 = Task.of(float_0)
    float_1 = 0.30463936
    task_1 = task_0.bind(lambda x: Task.of(x + float_1))
    assert abs(task_1.fork(lambda x: -1, lambda x: x) - (-1101.8516785719397)) <= 1e-8


# Generated at 2022-06-26 00:05:54.809517
# Unit test for method map of class Task
def test_Task_map():

    def test_case_0():
        map_0 = None
        float_0 = -159.74726
        task_0 = Task(float_0)
        def float_1(float_2):
            nonlocal map_0
            map_0 = float_2
            return float_2
        task_1 = task_0.map(float_1)


# Generated at 2022-06-26 00:06:03.068943
# Unit test for method bind of class Task
def test_Task_bind():

    # Test case 0:
    # #############################################################################
    float_0 = -1132.1563179320397
    task_0 = Task.of(float_0)
    task_1 = task_0.bind(lambda arg_0: Task.of(arg_0.real))
    result_0 = task_1.fork(lambda reject: 0, lambda resolve: resolve)

    assert result_0 == -1132.1563179320397

    # Test case 1:
    # #############################################################################
    float_0 = -1132.1563179320397
    task_0 = Task.of(float_0)
    task_1 = task_0.bind(lambda arg_0: Task.of(abs(arg_0.imag)))

# Generated at 2022-06-26 00:06:05.981810
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:06:10.428422
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(666).bind(
        lambda arg0: Task.of(arg0 / 2).map(
            lambda arg1: arg1 / 2
        )
    )

    assert result.fork(
        lambda arg: None,
        lambda arg: arg == 83.25,
    )


# Generated at 2022-06-26 00:06:15.910854
# Unit test for method bind of class Task
def test_Task_bind():
    float_0 = -1132.1563179320397
    float_1 = float_0
    def fn_0(arg_0):
        float_2 = float_0
        return float_2
    task_0 = Task.bind(fn_0, float_1)
    float_3 = float_0


# Generated at 2022-06-26 00:06:23.209499
# Unit test for method bind of class Task
def test_Task_bind():
    # TODO: enforce for types
    float_0 = -1132.1563179320397
    task_0 = Task(float_0)

    float_1 = -1107.9092887728792
    task_1 = Task(float_1)

    def func(arg_0, arg_1):
        task_0 = Task.of(arg_0)
        return task_0.map(lambda arg_0: arg_1)

    task_2 = func(float_0, float_1)
    assert task_1.fork(
        lambda arg: True,
        lambda arg: arg == arg_1
    )
    assert task_2.fork(
        lambda arg: True,
        lambda arg: arg == arg_1
    )
test_Task_bind()

# Generated at 2022-06-26 00:06:33.378446
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:06:43.257419
# Unit test for method bind of class Task
def test_Task_bind():
    # Bind
    task_0 = Task.of(0)
    eval_0 = task_0.bind(lambda x: Task.of(x + 1))
    assert(eval_0.fork(lambda x: x, 0) == 1)

    task_1 = Task.of(0)
    eval_1 = task_1.bind(lambda x: Task.of(x + 1))
    eval_2 = eval_1.bind(lambda x: Task.of(x + 1))
    assert(eval_2.fork(lambda x: x, 0) == 2)

    task_2 = Task.of(0)
    eval_3 = task_2.bind(lambda x: Task.of(x + 1))
    eval_4 = eval_3.bind(lambda x: Task.of(x + 2))
    eval_5

# Generated at 2022-06-26 00:06:53.308029
# Unit test for method map of class Task
def test_Task_map():
    float_0 = 4126.3995150556855
    float_1 = 150.03630772439713
    def test_case_1(value):
        float_0 = value
        return float_0

    task_0 = Task.of(float_1)
    task_1 = task_0.map(test_case_1)
    assert (type(task_1) == Task)
    assert (task_1.fork(float, float) == float_1)

    float_2 = 5134.7320867320265
    float_3 = 646.8664168647459
    float_4 = float_3
    def test_case_2(value):
        float_0 = float_2 - float_3
        float_1 = value
        float_2 = float_1 - float_0
       

# Generated at 2022-06-26 00:07:03.459841
# Unit test for method bind of class Task
def test_Task_bind():
    # test case 0
    float_0 = -1132.1563179320397
    task_0 = Task(float_0)
    def float_0_f(reject, resolve):
        return resolve(float_0)
    task_1 = Task(float_0_f)
    def float_1_f(reject, resolve):
        return resolve(float_0)
    task_2 = Task(float_1_f)
    assert task_0.bind(float_1_f) == task_2
    assert task_1.bind(float_0_f) == task_2


# Generated at 2022-06-26 00:07:11.610854
# Unit test for method map of class Task
def test_Task_map():
    # Case 0:
    float_0 = -1132.1563179320397
    task_0 = Task.of(float_0)
    def fn_0(arg):
        return arg
    task_1 = task_0.map(fn_0)
    def fork_0(reject, resolve):
        return resolve(float_0)
    # Assert value
    assert task_1.fork == fork_0
    # Case 1:
    task_2 = task_1.map(fn_0)
    def fork_1(reject, resolve):
        return resolve(float_0)
    # Assert value
    assert task_2.fork == fork_1
    # Case 2:
    def fn_1(arg):
        return arg + arg

# Generated at 2022-06-26 00:07:20.885259
# Unit test for method bind of class Task
def test_Task_bind():
    import builtins
    Task_0 = Task
    float_0 = -1132.1563179320397
    def Task_of_0(arg):
        return Task_0.of(arg)
    task_0 = Task_0.of(float_0)
    task_1 = task_0.bind(Task_of_0)
    assert builtins.type(task_1) == Task
    task_1 = task_0.bind(Task_of_0)
    assert task_1.fork(None, None) == task_0.fork(None, None)


# Generated at 2022-06-26 00:07:31.725093
# Unit test for method bind of class Task
def test_Task_bind():
    float_0 = -1132.1563179320397
    task_0 = Task.of(float_0)
    float_1 = float_0 + float_0
    task_1 = task_0.map(lambda float_0: float_0 + float_0)
    float_2 = float_1 + float_1
    task_2 = task_1.map(lambda float_1: float_1 + float_1)
    float_3 = float_2 + float_2
    task_3 = task_2.map(lambda float_2: float_2 + float_2)
    task_4 = task_3.bind(lambda float_3: Task.of(float_3 + float_3))

# Generated at 2022-06-26 00:07:39.835106
# Unit test for method map of class Task
def test_Task_map():
    """
    when we apply method map(func) on Task, we get new Task with applied function func
    to resolved value.
    """
    def test_case_1():
        float_0 = -4976.686370963398
        task_0 = Task.of(float_0)

        def func(value_0):
            return value_0 + 5850.513134925254

        task_1 = task_0.map(func)
        assert task_1.fork(lambda err: None, lambda res: res) == 874.826763951856
    test_case_1()

    def test_case_2():
        int_0 = -4043
        task_0 = Task.of(int_0)

        def func(value_0):
            return value_0 * -1927.55

# Generated at 2022-06-26 00:07:48.745410
# Unit test for method bind of class Task
def test_Task_bind():
    def def_0(reject, resolve):
        return resolve(10)
    task_0 = Task(def_0)

    def def_1(reject, resolve):
        return resolve(2)
    task_1 = Task(def_1)

    def def_2(arg):
        return task_1
    actual_0 = task_0.bind(def_2)

    def def_3(reject, resolve):
        return reject(10)
    task_2 = Task(def_3)

    def def_4(reject, resolve):
        return reject(2)
    task_3 = Task(def_4)

    def def_5(arg):
        return task_3
    actual_1 = task_2.bind(def_5)


# Generated at 2022-06-26 00:07:58.685497
# Unit test for method bind of class Task
def test_Task_bind():
    # Testing for Task[int, A].bind(Function(int) -> Task[int, B])
    task_0 = Task(lambda _, resolve: resolve(1))
    task_1 = task_0.bind(lambda arg_0: Task(lambda _, resolve: resolve(arg_0 + 1)))
    assert task_1.fork(
        lambda _: False,
        lambda arg_1: arg_1 == 2
    )
    task_2 = task_1.bind(lambda _: Task.reject(0))
    assert task_2.fork(
        lambda arg_2: arg_2 == 0,
        lambda _: False
    )
    task_3 = task_2.bind(lambda _: Task.of(0))

# Generated at 2022-06-26 00:08:00.145819
# Unit test for method bind of class Task
def test_Task_bind():
    # Just simple type test
    test_case_0()


# Generated at 2022-06-26 00:08:09.717903
# Unit test for method bind of class Task
def test_Task_bind():
    def task_reject(arg):
        return Task.reject(arg)

    def task_resolve(arg):
        return Task.of(arg)

    def task_reject_mapper(_):
        return "mapped reject value"

    def task_resolve_mapper(_):
        return "mapped resolve value"

    def reject_mapper(arg):
        return task_reject_mapper(arg)

    def resolve_mapper(arg):
        return task_resolve_mapper(arg)

    def fork_rejected(reject, resolve):
        return reject("rejected value")

    def fork_resolved(reject, resolve):
        return resolve("resolved value")

    def test_task_rejected():
        return Task(fork_rejected)


# Generated at 2022-06-26 00:08:14.704639
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda v: Task.of(v + 1)).fork(None, lambda v: v) == 2
    assert Task.of(1).bind(lambda v: Task.reject(v - 1)).fork(lambda v: v, None) == 0


# Generated at 2022-06-26 00:08:24.853393
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test data:
        int: -27
        Task: Task[int]
        Task.bind(lambda int: Task.reject[int]): Task[int]
    """
    int_0 = -27
    Task_0 = Task.of(int_0)
    Task_1 = Task_0.bind(lambda int_0: Task.reject(int_0))

    assert Task_1.fork(lambda int_0: True, lambda int_0: False) == True
    assert Task_1.fork(lambda int_0: int_0, lambda int_0: -1) == int_0


# Generated at 2022-06-26 00:08:28.176024
# Unit test for method bind of class Task
def test_Task_bind():
    def func(int_0):
        int_return = int_0 + 2
        return Task.of(int_return)

    task_inst = Task.of(10)
    task_return = task_inst.bind(func)
    task_return.fork(None, test_case_0)


# Generated at 2022-06-26 00:08:36.386229
# Unit test for method bind of class Task
def test_Task_bind():
    int_0 = -4043
    Task(lambda _, resolve: resolve(42)).bind(lambda arg: Task.reject(arg)).fork(lambda arg: int_0, lambda _: None)

    int_1 = (int_0)
    int_0 = -4043
    Task(lambda _, resolve: resolve(42)).bind(lambda arg: Task(lambda _, resolve: resolve(arg))).fork(lambda _: None, lambda arg: int_0)
    int_2 = (int_0)
    assert int_1 == 42
    assert int_2 == 42



# Generated at 2022-06-26 00:08:45.420376
# Unit test for method bind of class Task
def test_Task_bind():
    count_0 = 0
    count_1 = 0
    count_2 = 0

    mapper_0 = lambda arg: arg + 1
    mapper_1 = lambda arg: arg - 1

    task = Task.of(0)
    task_0 = task.map(mapper_0)
    task_1 = task_0.bind(lambda arg: Task.of(arg + 1))
    task_2 = task_1.map(mapper_1)

    def reject(arg):
        nonlocal count_0

        count_0 = arg

    def resolve(arg):
        nonlocal count_1

        count_1 = arg

    task_2.fork(reject, resolve)
    assert count_1 == 1, 'test_Task_bind: expected 1, got ' + str(count_1) + '.'
   

# Generated at 2022-06-26 00:08:52.772871
# Unit test for method map of class Task
def test_Task_map():
    test_source = [
        {
            "name": "Case 0",
            "input": {
                "fork": lambda _, resolve: resolve(1),
                "fn": lambda arg: arg - 1
            },
            "expected": 0
        },
        {
            "name": "Case 1",
            "input": {
                "fork": lambda _, resolve: resolve(1),
                "fn": lambda arg: "Some string"
            },
            "expected": "Some string"
        }
    ]

    for test in test_source:
        input = test["input"]
        task = Task(input["fork"])
        assert task.map(input["fn"]).fork(lambda arg: arg, lambda arg: arg) == test["expected"]


# Generated at 2022-06-26 00:08:57.686876
# Unit test for method bind of class Task
def test_Task_bind():
    def _(a): return a
    def add_10(a): return a + 10

    assert Task(lambda r, k: k(0)).bind(_).bind(add_10).fork(lambda e: e, lambda a: a) == 10



# Generated at 2022-06-26 00:09:06.757858
# Unit test for method map of class Task
def test_Task_map():
    # Unit test for method map with identity function
    def test_0():
        print('Start test 0')
        # Given
        int_0 = -4043
        task_0 = Task.of(int_0)
        fn_0 = lambda arg: arg

        # When
        task_1 = task_0.map(fn_0)
        result = task_1.fork(lambda arg: arg, lambda arg: arg)

        # Then
        assert result == int_0

    # Unit test for method map with simple adding function
    def test_1():
        print('Start test 1')
        # Given
        int_0 = -4043
        task_0 = Task.of(int_0)
        fn_0 = lambda arg: arg + 15

        # When

# Generated at 2022-06-26 00:09:09.167044
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    assert Task.of(1).map(fn).fork(
        lambda reject: None,
        lambda resolve: resolve + 2
    ) == 4



# Generated at 2022-06-26 00:09:11.599960
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of("cmd").bind(lambda x: Task.of("-" + x)).fork("", echo) == "cmd", "test_Task_bind"


# Generated at 2022-06-26 00:09:16.652100
# Unit test for method map of class Task
def test_Task_map():
    int_0 = -4043
    Task_0 = Task.of(int_0)

    def fn_0(value):
        return value + 2

    Task_1 = Task_0.map(fn_0)
    int_1 = Task_1.fork(
        lambda arg: arg,
        lambda arg: arg - 2
    )

    if int_1 != (int_0 + 2):
        raise RuntimeError('Wrong map method in Task class')


# Generated at 2022-06-26 00:09:30.963366
# Unit test for method bind of class Task
def test_Task_bind():
    # Task[Function(_, resolve) -> int]
    task_0 = Task.of(3)

    # Task[Function(reject, _) -> int]
    task_1 = Task.reject(3)

    # Unit test for Task.bind(function(value)->Task.of(value))
    # Task[Function(_, resolve) -> int]
    task_2 = task_0.bind(lambda value: Task.of(value))

    # Task[Function(_, resolve) -> int]
    task_3 = task_2.bind(lambda value: Task.of(value))

    # Unit test for Task.bind(function(value)->Task.reject(value))
    # Task[Function(reject, _) -> int]

# Generated at 2022-06-26 00:09:36.505967
# Unit test for method map of class Task
def test_Task_map():
    for int_0 in range(-5, 5):
        Task_0 = Task.of(int_0)
        Task_1 = Task_0.map(lambda arg: arg + 1)

        def test_Task_map_fork(reject, resolve):
            task = Task_1.fork(reject, resolve)
            assert task == int_0 + 1

        test_Task_map_fork(lambda arg: arg, lambda arg: arg)



# Generated at 2022-06-26 00:09:39.574514
# Unit test for method bind of class Task
def test_Task_bind():
    # Case 0
    int_0 = -4043
    task_0 = Task.of(int_0).bind(lambda arg: Task.of(arg)).fork(lambda arg: None, lambda arg: arg)
    assert task_0 == int_0

# Generated at 2022-06-26 00:09:48.757412
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_0():
        def fork_0(reject, resolve):
            return resolve(8)

        def fork_1(reject, resolve):
            return resolve(8)

        def fork_2(reject, resolve):
            return resolve(12)

        def test_case_0():
            task_0 = Task(fork_0)
            task_1 = task_0.bind(lambda arg: Task(fork_1))
            assert task_1.fork(
                lambda arg: arg,
                lambda arg: arg
            ) == 8

        def test_case_1():
            task_0 = Task(fork_0)
            task_1 = task_0.bind(lambda arg: Task(fork_2))

# Generated at 2022-06-26 00:09:54.938258
# Unit test for method bind of class Task
def test_Task_bind():
    # case 0
    _result_0 = Task.of(int_0).bind(Task.reject)
    assert _result_0.fork(_return_0, _return_1) == _return_0(_result_0)

    # case 1
    _result_1 = Task.reject(int_0).bind(Task.reject)
    assert _result_1.fork(_return_0, _return_1) == _return_0(_result_1)


# Generated at 2022-06-26 00:09:58.521226
# Unit test for method map of class Task
def test_Task_map():
    int_0 = -4043
    Task.reject(int_0).map(lambda x: x + 30).fork(lambda x: int_0, lambda x: x + 30)
    Task.of(int_0).map(lambda x: x + 30).fork(lambda x: int_0, lambda x: x + 30)


# Generated at 2022-06-26 00:10:02.431186
# Unit test for method map of class Task
def test_Task_map():
    int_0 = -4043

    # Create two Task
    task_0 = Task.of(int_0)
    task_1 = task_0.map(lambda arg_1: arg_1 + arg_1)

    # Expect int_0 + int_0 in resolved Task
    assert(task_1.fork(lambda result: result == 8080, lambda _: True))
    # Expect None in rejected Task
    assert(task_1.fork(lambda _: None, lambda result: result == None))


# Generated at 2022-06-26 00:10:12.606063
# Unit test for method map of class Task
def test_Task_map():

    int_task = Task.of(10)

    int_task = int_task.map(lambda x: x + 1)
    int_task = int_task.map(lambda x: x + 1)
    int_task = int_task.map(lambda x: x + 1)
    int_task = int_task.map(lambda x: x + 1)
    int_task = int_task.map(lambda x: x + 1)
    int_task = int_task.map(lambda x: x + 1)
    int_task = int_task.map(lambda x: x + 1)
    int_task = int_task.map(lambda x: x + 1)
    int_task = int_task.map(lambda x: x + 1)

# Generated at 2022-06-26 00:10:21.254551
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_0():
        int_0 = -4043
        task_0 = Task.of(int_0).bind(lambda a0: Task.of(lambda a1, a2: a1(a0 + a2)))
        def fork(reject, resolve):
            return resolve(task_0)
        task_0.fork = fork
        assert task_0.fork(lambda a0: a0, lambda a0: a0(int_0, -4043)) == int_0
    test_case_0()
    def test_case_1():
        int_0 = -4043
        task_0 = Task.of(int_0).bind(lambda a0: Task.of(lambda a1, a2: a1(a0 + a2)))
        def fork(reject, resolve):
            return

# Generated at 2022-06-26 00:10:29.413154
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Bind method of class Task should transform value of Task and return new Task
    with transformed value for resolve attribute.
    """
    # TestCase
    int_0 = -4043
    def fn(x): return x * int_0

    task = Task.of(int_0).bind(fn)

    def fork_0(reject, resolve):
        assert x == int_0
        assert fn(x) == int_0 * int_0
        return task.fork(reject, resolve)

    x = 0
    task.fork(lambda _: print('Rejected'), lambda x: print(x))


# Generated at 2022-06-26 00:10:49.999062
# Unit test for method map of class Task
def test_Task_map():
    # Case 0
    int_0 = -4043
    int_1 = -99

    def function_0(value):
        if value != int_0:
            raise AssertionError()
        return int_1

    task_0 = Task.of(int_0)
    task_1 = task_0.map(function_0)
    assert int(task_1.fork(
        lambda arg: arg,
        lambda arg: arg,
    )) == int_1

    # Case 1
    int_2 = -6

    def function_1(value):
        if value == Exception:
            raise AssertionError()
        return int_2

    task_2 = Task.reject(Exception())
    task_3 = task_2.map(function_1)

# Generated at 2022-06-26 00:10:58.862979
# Unit test for method bind of class Task
def test_Task_bind():
    def exception_error(a):
        raise Exception('Invalid argument exception')

    def times_10(arg):
        return Task.of(arg * 10)

    # test for checked error
    assert Task.reject(
        exception_error(0)
    ).bind(times_10).fork(lambda e: e, lambda v: v) == 'Invalid argument exception'

    # test for checked value
    assert Task.of(10).bind(times_10).fork(lambda e: None, lambda v: v) == 100


# Generated at 2022-06-26 00:11:01.667174
# Unit test for method map of class Task
def test_Task_map():
    def abs(x):
        if x < 0:
            return -x
        else:
            return x

    task = Task.of(int_0)
    result_task = task.map(abs)

    assert_equals(abs(int_0), result_task.fork(lambda _, resolve: resolve))


# Generated at 2022-06-26 00:11:05.651036
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(10).map(lambda x: x + 12).fork(
        lambda x: None,
        lambda x: x
    ) == 22

    assert Task.of([10, 2.5]).map(
        lambda x: x[0] + x[1]
    ).fork(
        lambda x: None,
        lambda x: x
    ) == 12.5


# Generated at 2022-06-26 00:11:16.112491
# Unit test for method map of class Task
def test_Task_map():
    # Testing lambda expression as "map" function
    def test_map_lambda():
        def inner_map(a):
            return a + 1

        def inner_test(a, b):
            return a == b

        int_0 = -4043
        int_1 = -4042

        try:
            task_0 = Task.of(int_0).map(inner_map)
            assert task_0.fork(lambda r_0: False, lambda r_0: inner_test(r_0, int_1))
        except:
            raise Exception('Test failed in method "test_Task_map" in "Task" class test')

    # Testing function as "map" function
    def test_map_function():
        def inner_map(a):
            return a + 1


# Generated at 2022-06-26 00:11:25.133760
# Unit test for method map of class Task
def test_Task_map():
    int_0 = -4043
    task_0 = Task.of(int_0)
    def func_0():
        def func_0_0(arg_0):
            return (- arg_0)
        return func_0_0
    def func_1():
        def func_1_0(arg_0):
            return (arg_0 / arg_0)
        return func_1_0
    int_1 = -4043
    if (Task.of(int_1).bind(func_0()).fork(func_1(), func_0()) != 1):
        assert False
    else:
        if (Task.of(int_1).map(func_0()).fork(func_1(), func_0()) != (- int_1)):
            assert False
        else:
            pass

# Unit test

# Generated at 2022-06-26 00:11:27.441892
# Unit test for method map of class Task
def test_Task_map():
    def my_task():
        return Task.of(int_0).map(lambda value: value + 1)

    assert my_task().fork(lambda _: 'error', lambda x: x) == int_0 + 1


# Generated at 2022-06-26 00:11:38.092692
# Unit test for method bind of class Task
def test_Task_bind():
    def check(result, expected_result, case_number):
        if isinstance(result, Task) and isinstance(expected_result, Task):
            resolved_result = result.fork(lambda x: "rejected", lambda x: x)
            resolved_expected_result = expected_result.fork(lambda x: "rejected", lambda x: x)
            if resolved_result == resolved_expected_result:
                print("Case #{}: Pass".format(case_number))
            else:
                print("Case #{}: Fail, got {}".format(case_number, resolved_result))
        else:
            print("Sorry, master, get wrong types of result, expected_result")

    def plus_two(x):
        return Task.of(x + 2)


# Generated at 2022-06-26 00:11:43.309183
# Unit test for method bind of class Task
def test_Task_bind():
    # run test with lambda
    test_case_0()

# run unit test
test_Task_bind()

# Generated at 2022-06-26 00:11:46.625166
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(int_0)).map(lambda X: X).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == int_0


# Generated at 2022-06-26 00:12:08.877535
# Unit test for method bind of class Task
def test_Task_bind():
    global sum
    sum = 0
    # Check that task_0.resolve is a number
    def test_case_0(task_0):
        assert type(task_0.resolve) == int
    # Check that increment is working properly
    def increment(n):
        return n + 1
    def test_case_1(task_1):
        global sum
        sum += 1
        assert task_1.resolve == sum

    # Check that decrement is working properly
    def test_case_2(task_2):
        global sum
        sum -= 1
        assert task_2.resolve == sum
    def decrement(n):
        return n - 1
    # Check that incrementBy is working properly
    def incrementBy(n, m):
        return n + m

# Generated at 2022-06-26 00:12:12.956255
# Unit test for method map of class Task
def test_Task_map():
    # set up test variables
    float_0 = -1132.1563179320397
    task_0 = Task(float_0)

    # call test function
    fn_0 = Task(float_0).map()
    # check result
    assert(isinstance(fn_0, Task))
    assert(fn_0.fork == Task(float_0).map())


# Generated at 2022-06-26 00:12:15.848924
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(1)
    task_1 = task_0.bind(lambda a: Task.of(a+1))
    assert task_1.fork(lambda a: None, lambda a: a) == 2

    task_2 = task_0.bind(lambda a: Task.reject(a+1))
    assert task_2.fork(lambda a: a, lambda a: None) == 2

test_Task_bind()

# Generated at 2022-06-26 00:12:20.558691
# Unit test for method map of class Task
def test_Task_map():
    float_0 = -1132.1563179320397
    task_0 = Task(float_0)
    def fn(arg):
        return arg * arg

    task = task_0.map(fn)

    def fork(reject, resolve):
        return resolve(fn(float_0))

    task_1 = Task(fork)

    assert task == task_1


# Generated at 2022-06-26 00:12:25.522983
# Unit test for method map of class Task
def test_Task_map():
    # create Task
    task = Task.of(1)
    # create mapper function
    def mapper(value):
        return value + 1

    # mapp Task
    mapped_task = task.map(mapper)
    # call fork
    fork_value = mapped_task.fork(None, None)
    # check that value was mapped
    assert fork_value == 2


# Generated at 2022-06-26 00:12:28.651289
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task(lambda reject, resolve: 0)
    task_1 = task_0.bind(lambda arg_0: arg_0)
    assert isinstance(task_1, Task)
    return task_0


# Generated at 2022-06-26 00:12:30.773862
# Unit test for method map of class Task
def test_Task_map():
    float_0 = -1132.1563179320397
    task_0 = Task(float_0)
    task_0.map(lambda arg: arg)


# Generated at 2022-06-26 00:12:39.364407
# Unit test for method bind of class Task
def test_Task_bind():

    def value_task_0():
        """Value task_0"""
        int_0 = 1
        return Task.of(int_0)


    def value_task_1():
        """Value task_1"""
        str_0 = "lorem"
        return Task.of(str_0)


    def value_task_2():
        """Value task_2"""
        list_0 = [2, 3.0, "4"]
        return Task.of(list_0)


    def value_task_3():
        """Value task_3"""
        set_0 = {'orci', 'aliquet', 'felis'}
        return Task.of(set_0)


    def value_task_4():
        """Value task_4"""
        float_0 = 2.0
        return

# Generated at 2022-06-26 00:12:45.967927
# Unit test for method map of class Task
def test_Task_map():
    float_0 = 1.0
    task_0 = Task(float_0)
    assert task_0.map(lambda x: x).fork(lambda x: x, lambda x: x)

    float_0 = 0.0
    task_0 = Task(float_0)
    assert task_0.map(lambda x: x).fork(lambda x: x, lambda x: x)


# Generated at 2022-06-26 00:12:50.253694
# Unit test for method bind of class Task
def test_Task_bind():
    # Arrange
    float_0 = 173.56044344855302
    expected_result = 'Fail!'

    # Act
    actual_result = Task.of(float_0).bind(lambda x: Task.of(x + 1)).fork(lambda e: 'Fail!', lambda r: r)

    # Assert
    assert actual_result == expected_result


# Generated at 2022-06-26 00:13:19.877369
# Unit test for method map of class Task
def test_Task_map():
    float_0 = -1132.1563179320397
    float_1 = float_0 ** float_0 ** float_0 ** float_0 ** float_0 ** float_0 ** float_0 ** float_0 ** float_0 ** float_0 ** float_0
    task_0 = Task.of(float_1)
    task_1 = task_0.map(lambda float_2: float_2 / float_2)
    resolve_0 = task_1.fork(
        lambda float_2: float_2,
        lambda float_2: float_2
    )
    assert resolve_0 == float_1 / float_1


# Generated at 2022-06-26 00:13:20.573209
# Unit test for method map of class Task
def test_Task_map():
    with pytest.raises(NameError):
        Task().map()


# Generated at 2022-06-26 00:13:24.736998
# Unit test for method map of class Task
def test_Task_map():
    """
    Tests map method of Task
    """
    def test_case_0():
        num_0 = 10
        task_0 = Task.of(num_0)
        def fn_0(value):
            return value / 3
        task_1 = task_0.map(fn_0)
        def fork_0(reject, resolve):
            return resolve(10/3)
        assert(task_1.fork == fork_0)
    test_case_0()


# Generated at 2022-06-26 00:13:33.007303
# Unit test for method bind of class Task
def test_Task_bind():
    # Run
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_

# Generated at 2022-06-26 00:13:37.312872
# Unit test for method map of class Task
def test_Task_map():
    def float_0(reject, resolve):
        return resolve(-1132.1563179320397)

    int_0 = -1132

    task_0 = Task(float_0)

    task_1 = task_0.map(lambda arg0: int(arg0))

    assert task_0.fork == float_0

# Generated at 2022-06-26 00:13:41.172614
# Unit test for method bind of class Task
def test_Task_bind():
    def minus(x):
        return x - 15

    def plus(x):
        return x + 9

    assert Task(0).bind(minus).bind(plus).fork(lambda _: None, lambda result: result == 0 - 15 + 9)



# Generated at 2022-06-26 00:13:51.774261
# Unit test for method bind of class Task
def test_Task_bind():
    def method_1(): pass
    def method_2(): pass
    def method_3(arg): pass

    task_4 = Task(method_1)
    task_5 = Task(method_2)

    task_6 = Task(method_1)

    def method_7():
        task_8 = Task(method_2)
        return task_8

    def method_9():
        task_10 = Task(method_2)
        return task_10

    def method_11(arg):
        def method_12():
            task_13 = Task(method_2)
            return task_13
        task_14 = Task(method_12)
        return task_14

    def method_15(arg):
        def method_16():
            task_17 = Task(method_2)
            return task_17
       

# Generated at 2022-06-26 00:13:53.200723
# Unit test for method bind of class Task
def test_Task_bind():
    assert isinstance(Task.of(10).bind(lambda x: Task.of(x * 10)), Task)


# Generated at 2022-06-26 00:14:01.358509
# Unit test for method bind of class Task
def test_Task_bind():

    # assert Task.of(1).bind(lambda arg: arg + 1).fork(lambda arg: assert arg == 1, lambda arg: assert arg == 2)

    # assert Task.reject(1).bind(lambda arg: arg + 1).fork(lambda arg: assert arg == 1, lambda arg: assert arg == 2)

    task_0 = Task.of(1).bind(lambda arg: Task.of(arg + 1))

    task_1 = Task.reject(2).bind(lambda arg: Task.of(arg + 1))

    task_2 = Task.reject(2).bind(lambda arg: Task.reject(arg + 1))

    def reject(arg): assert arg == 2

    def resolve_0(arg): assert arg == 2

    def resolve_1(arg): assert arg == 3

    # task_0.fork(re

# Generated at 2022-06-26 00:14:07.194876
# Unit test for method bind of class Task
def test_Task_bind():
    class _Task_bind_mock:
        def __init__(self):
            self.result = None
        def fork(self, _, resolve):
            return resolve('')
    expected = '1'
    task_0 = _Task_bind_mock()
    task_1 = Task.of(1).bind(lambda i: task_0)
    def _resolve(arg):
        self.result = arg
    task_1.fork(lambda arg: arg, _resolve)
    actual = self.result
    assert actual == expected


# Generated at 2022-06-26 00:15:03.410248
# Unit test for method map of class Task
def test_Task_map():
    task_1 = Task(0)
    task_2 = task_1.map(lambda x: x)

    task_3 = Task(1)
    task_4 = task_3.map(lambda x: x)

    task_5 = Task.of(2)
    task_6 = task_5.map(lambda x: x)

    task_7 = Task.of(3)
    task_8 = task_7.map(lambda x: x)

    task_9 = Task.reject(4)
    task_10 = task_9.map(lambda x: x)

    task_11 = Task.reject(5)
    task_12 = task_11.map(lambda x: x)



# Generated at 2022-06-26 00:15:07.241594
# Unit test for method map of class Task
def test_Task_map():
    # input
    instance_0 = Task(float)
    function_0 = function_0 = lambda x: (x ** 2)
    # method call
    result = instance_0.map(function_0)

    # check result
    assert isinstance(result, Task) is True


# Generated at 2022-06-26 00:15:16.575102
# Unit test for method bind of class Task
def test_Task_bind():
    float_0 = -1132.1563179320397
    float_1 = float_0 / float_0
    regex_0 = re.compile('(.)')
    float_2 = float_1 * float_1
    def str(float_3):
        float_3 = float_2 * float_2
        float_3 = float_0 / float_0
        float_3 = float_0 / float_0
        float_3 = float_1 * float_1
        float_3 = float_1 * float_1
        float_3 = float_0 / float_0
        float_3 = float_1 * float_1
        float_3 = float_0 / float_0
        float_3 = float_0 / float_0
        float_3 = float_0 / float_0
        float_3

# Generated at 2022-06-26 00:15:22.649647
# Unit test for method map of class Task
def test_Task_map():
    # test case 0
    def fn(value):
        assert (type(value) is float)
        return float(value + 1)
    float_0 = -1132.1563179320397
    task_0 = Task(float_0)
    task_1 = task_0.map(fn)
    # test case 1
    def fn(value):
        assert (type(value) is float)
        return float(value + 1)
    float_0 = -26.213131568380903
    task_0 = Task(float_0)
    task_1 = task_0.map(fn)


# Generated at 2022-06-26 00:15:29.997885
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(10)
    assert task_0.bind(lambda x: Task.of(x)).fork(lambda x: x, lambda x: 1 + x) == 11

    task_1 = Task.of(10)
    assert task_1.bind(lambda x: Task.of(x)).fork(lambda x: x, lambda x: x ** 2) == 100

    task_2 = Task.of(20)
    assert task_2.bind(lambda x: Task.reject(x + 1)).fork(lambda x: x ** 2, lambda x: x) == 401

    task_2 = Task.of(10)
    assert task_2.bind(lambda x: Task.reject(x + 1)).fork(lambda x: x ** 2, lambda x: x) == 11



# Generated at 2022-06-26 00:15:37.551799
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method map for class Task.
    """

    def fail(message):
        def raise_error():
            raise Exception(message)
        return raise_error

    def true(arg):
        return True

    def is_int(arg):
        return isinstance(arg, int)

    template = 'Task(value).map(f) does not work correctly. Task(value).map(f) is {}, but Task.of(value).map(f) is {}'
    value = 10
    mult2 = lambda x: x * 2
    pow2 = lambda x: x ** 2
    is_zero = lambda x: x == 0
    check_error = lambda x: (1 / x) if x != 0 else 0
    zero_task = Task.of(0)
    int_task = Task.of(value)
   

# Generated at 2022-06-26 00:15:44.398297
# Unit test for method bind of class Task
def test_Task_bind():
    def f1(x):
        return x * 2

    def f2(x):
        return Task.of(x * 3)

    def f3(x):
        return Task.reject(x * 4)

    x = Task.of(10)
    y = x.bind(f1).bind(f2).bind(f3)

    # With no fork statement inside bind, we need to set up a callback
    # to get a value out of the task
    values = []
    errors = []

    def accept(value):
        values.append(value)

    def reject(error):
        errors.append(error)

    y.fork(reject, accept)
    assert values == [10 * 2 * 3]
    assert errors == []

    x = Task.reject(20)