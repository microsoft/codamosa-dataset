

# Generated at 2022-06-26 00:05:52.950016
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    task_0 = Task.of(bytes_0)
    # Test 1
    def test_1(value):
        return value.decode('UTF-8')
    task_1 = task_0.map(test_1)
    assert type(task_1) == Task


# Generated at 2022-06-26 00:06:01.746942
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    bytes_0 += b'\x19\xe4\xdbj\x0e\xc2\x8f\x92\xbb\xde\xd9\x1e\xa6\x96\x8f\x8e>\xad\xad'
    bytes_1 = b'\xf0.\xd2Y]\xf3\xab\x1e\xed\x94\x86#\x9a\x97\xd7\xb5\t\x8d\xf0\x1cvd\xec\xb9'

# Generated at 2022-06-26 00:06:10.644275
# Unit test for method bind of class Task
def test_Task_bind():
    import random

    def random_func():
        return bool(random.randint(0, 1))

    def random_bytes():
        return b'\xf9\xb8\xa3\xca\x15:\xee1\x8c\xf2\r\x12\xe5'

    # Test case 0
    task_0 = Task.of('\x03\xfa\x94\xf4')

    def mapper_fn_0(arg):
        return Task.of('\x8e\x0f\x93\xb7\x9c8j\x98\x93\xb1tD')

    value_0 = task_0.bind(mapper_fn_0)


# Generated at 2022-06-26 00:06:20.760923
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map()
    """
    task_0 = Task.of(0)

    @test
    def test_0():
        """
        Test for Task.map(lambda x: x + 1)
        """
        def add_1(x):
            """
            returns: x + 1
            :rtype: int
            """
            return x + 1

        assert task_0.map(add_1).fork(None, lambda x: x) == 1

    @test
    def test_1():
        """
        Test for Task.map(lambda x: x + 1).map(lambda x: x - 1)
        """
        def add_1(x):
            """
            returns: x + 1
            :rtype: int
            """
            return x + 1


# Generated at 2022-06-26 00:06:29.285033
# Unit test for method map of class Task
def test_Task_map():
    def convert_to_string(output):
        return str(output)

    task_0 = Task.of(b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3')
    assert task_0.map(convert_to_string) == Task.of(str(b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'))



# Generated at 2022-06-26 00:06:34.410689
# Unit test for method bind of class Task
def test_Task_bind():
    def some_function(resolve, reject):
        return resolve('A')

    assert Task(some_function).bind(lambda v: Task.of(v + 'B')).fork(None, lambda v: v) == 'AB'
    assert Task(some_function).bind(lambda _: Task.reject('B')).fork(lambda v: v, None) == 'B'


# Generated at 2022-06-26 00:06:37.555473
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + value
    task = Task.of(2)
    mapped_task = task.map(fn)
    assert mapped_task.fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-26 00:06:45.304239
# Unit test for method bind of class Task
def test_Task_bind():
    def _bind(task, fn):
        def result(reject, resolve):
            return task.fork(
                lambda arg: reject(arg),
                lambda arg: fn(arg).fork(reject, resolve)
            )

        return Task(result)

    def bind(task, fn):
        return task.bind(fn)

    task_map = Task(lambda reject, resolved: resolved(1))
    task_mapper = lambda arg: Task(lambda reject, resolved: resolved(arg))

    assert bind(task_map, task_mapper) == _bind(task_map, task_mapper)


# Generated at 2022-06-26 00:06:51.451688
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'

    def fn_0(arg_0):
        return Task(arg_0)

    task_0 = Task(bytes_0)
    task_1 = task_0.bind(fn_0)
    task_2 = task_1.map(lambda arg_1: arg_1)


# Generated at 2022-06-26 00:06:59.436770
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    task_0 = Task.of(bytes_0)
    task_1 = task_0.map(lambda bytes_1: ''.join(map(chr, bytes_1)))
    assert '\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3' == task_1.fork(lambda arg: arg, lambda arg: arg)


# Generated at 2022-06-26 00:07:04.925019
# Unit test for method map of class Task
def test_Task_map():
    Task.of(1) \
        .map(lambda value: value + 1) \
        .fork(
            lambda arg: arg,
            lambda arg: arg
        )


# Generated at 2022-06-26 00:07:12.551800
# Unit test for method bind of class Task
def test_Task_bind():
    # bind Task
    test_str = 'str'
    Task_str = Task.of(test_str)
    Task_str = Task_str.map(lambda arg: arg[::-1])
    result = Task_str.fork(
        lambda arg: False,
        lambda arg: arg == test_str[::-1]
    )
    assert(result)

    # bind Task
    test_str = 'str'
    Task_str = Task.of(test_str)
    Task_str = Task.of(Task_str)
    Task_str = Task_str.bind(lambda arg: arg)
    result = Task_str.fork(
        lambda arg: False,
        lambda arg: arg == test_str
    )
    assert(result)

    #reject none Task

# Generated at 2022-06-26 00:07:23.812667
# Unit test for method map of class Task
def test_Task_map():
    str_0 = '\x03ú\x94ô'
    # str_0.encode('utf-8') = '\xc3\xba\x94\xc3\xb4'
    assert Task.of(str_0).map(lambda str_0: len(str_0)).fork(None, None) == 4
    # Task.reject is wrong for assert 'error' is an error message.
    # Because Task.reject can't raise any exception.
    try:
        Task.reject('error').map(lambda str_0: len(str_0)).fork(None, None)
    except:
        raise Exception("Task.reject is wrong for assert 'error' is an error message. Because Task.reject can't raise any exception.")



# Generated at 2022-06-26 00:07:33.862732
# Unit test for method map of class Task
def test_Task_map():
    str_0 = '\x03ú\x94ô'

    # Test 0
    str_1 = '\x03ú\x94ô'
    str_2 = '\x03ú\x94ô'
    str_3 = '\x03ú\x94ô'
    str_4 = '\x03ú\x94ô'
    str_5 = '\x03ú\x94ô'
    str_6 = '\x03ú\x94ô'
    str_7 = '\x03ú\x94ô'
    str_8 = '\x03ú\x94ô'
    str_9 = '\x03ú\x94ô'

    str_10 = '\x03ú\x94ô'
    str_11 = '\x03ú\x94ô'
    str

# Generated at 2022-06-26 00:07:40.826795
# Unit test for method map of class Task
def test_Task_map():
    # Test 1
    str_0 = '\x03ú\x94ô'
    str_1 = str_0
    def fn_0(arg):
        return arg
    def fn_1(arg):
        return arg
    int_0 = 4
    def fn_2(arg):
        return arg
    def fn_3(arg):
        return arg
    def fn_4(arg):
        return arg
    def fn_5(arg):
        return arg
    Task_0 = Task.of(str_0)
    Task_1 = Task_0.map(fn_0)
    Task_2 = Task.of(str_0)
    Task_3 = Task_2.map(fn_1)
    Task_4 = Task.of(str_0)
    Task_5 = Task_4.map

# Generated at 2022-06-26 00:07:41.457048
# Unit test for method bind of class Task
def test_Task_bind():
    pass

# Generated at 2022-06-26 00:07:52.650812
# Unit test for method bind of class Task
def test_Task_bind():

    # Test for Task.bind
    def test_0():
        Task.of(str_0).bind(print)
        Task.of(str_0).bind(print)
        Task.of(str_0).bind(print)
        Task.of(str_0).bind(print)
        Task.of(str_0).bind(print)

    # Test for Task.bind
    def test_1():
        Task.of(str_0).bind(print)
        Task.of(str_0).bind(print)
        Task.of(str_0).bind(print)
        Task.of(str_0).bind(print)
        Task.of(str_0).bind(print)

    # Test for Task.bind
    def test_2():
        Task.of(str_0).bind(print)


# Generated at 2022-06-26 00:07:54.910179
# Unit test for method map of class Task
def test_Task_map():
    fork = Task(lambda _, resolve: resolve(True)).map(lambda arg: arg)
    _, result = fork(lambda _: None)
    assert result is True


# Generated at 2022-06-26 00:07:59.312028
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(str_0)
    task = task.map(lambda string: string + "1")
    return task.fork(
        lambda reject: reject,
        lambda resolve: resolve == str_0 + "1"
    )


# Generated at 2022-06-26 00:08:01.382417
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(str_0)
    return task_0.bind((lambda arg_0: task_0))


# Generated at 2022-06-26 00:08:07.333348
# Unit test for method map of class Task
def test_Task_map():
    t0 = Task.of(1).map(lambda x: x + 1).map(lambda x: x * x)
    assert(t0.fork(lambda x: x, lambda x: x) == 4)


# Generated at 2022-06-26 00:08:15.322267
# Unit test for method map of class Task
def test_Task_map():

    def test_of():
        assert Task.of(1).map(lambda x: x + 1).fork(
            lambda _: _,
            lambda a: a
        ) == 2

    def test_reject():
        assert Task.reject(1).map(lambda x: x + 1).fork(
            lambda a: a,
            lambda _: _
        ) == 1

    test_of()
    test_reject()


# Generated at 2022-06-26 00:08:20.543247
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_0() -> Task:
        return Task.reject(False)

    def fn_1() -> Task:
        return Task.of(True)

    assert Task.of(True).bind(fn_0).fork(lambda _: True, lambda _: False) == True
    assert Task.of(True).bind(fn_1).fork(lambda _: False, lambda _: True) == True


# Generated at 2022-06-26 00:08:28.753176
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        if x == 0:
            return Task.reject(0)
        else:
            return Task.of(x + 1)

    def g(y):
        return Task.of(y * y)

    task_0 = Task.of(1)
    task_1 = task_0.bind(f)
    task_2 = task_1.bind(g)
    assert task_2.fork(lambda a: None, lambda a: a) == 4
    assert task_2.fork(lambda a: a, lambda a: None) is None

    task_0 = Task.of(0)
    task_1 = task_0.bind(f)
    task_2 = task_1.bind(g)
    assert task_2.fork(lambda a: a, lambda a: None) == 0

# Generated at 2022-06-26 00:08:39.157998
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    task_0 = Task(bytes_0)
    assert task_0
    task_1 = Task.of(task_0)
    assert task_1
    bytes_1 = b"\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3"
    def func_0(arg_0):
        res = Task.of(bytes_1)
        assert len(res.fork) == 2
        assert res.fork[0] == arg_0.fork[0]
        assert res.fork[1] == arg_0.fork[1]
        return res
    res_

# Generated at 2022-06-26 00:08:48.180576
# Unit test for method map of class Task
def test_Task_map():
    def random_bytes(count):
        def fork(reject, resolve):
            import os
            reject_count = (count + 7) // 8
            reject_bytes = os.urandom(reject_count)
            reject_bytes = reject_bytes.ljust(count, b'\x00')
            resolve_count = count // 8
            resolve_bytes = os.urandom(resolve_count)
            resolve_bytes = resolve_bytes.ljust(count, b'\x00')
            return reject_bytes, resolve_bytes

        return Task(fork)

    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    task_0 = random_bytes(16)
    def hex(bytes):
        fn

# Generated at 2022-06-26 00:08:54.243997
# Unit test for method bind of class Task
def test_Task_bind():
    value_0 = 0;
    task_0 = Task.of(value_0);
    def function_0(arg):
        return 'a';
    task_1 = task_0.bind(function_0);
    assert task_0.fork(lambda arg: arg, lambda arg: arg) == 0
    assert task_1.fork(lambda arg: arg, lambda arg: arg) == 'a'

    value_1 = 0;
    task_2 = Task.reject(value_1);
    def function_1(arg):
        return 'b';
    task_3 = task_2.bind(function_1);
    assert task_3.fork(lambda arg: arg, lambda arg: arg) == 0


# Generated at 2022-06-26 00:09:04.573192
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        print(value)

    def reject(value):
        print(value)

    def fork(reject, resolve):
        resolve(value)

    def mapped_task1_fork(reject, resolve):
        resolve(value)

    def mapped_task2_fork(reject, resolve):
        resolve(value)

    value = 0
    task_0 = Task(fork)
    # Map
    mapped_task1 = task_0.map(lambda arg: arg + 1)
    mapped_task1 = Task(mapped_task1_fork)

    mapped_task2 = mapped_task1.map(lambda arg: arg + 1)
    mapped_task2 = Task(mapped_task2_fork)

    # Bind

# Generated at 2022-06-26 00:09:08.336365
# Unit test for method map of class Task
def test_Task_map():
    def f_map(x):
        return x + 1

    def f_map_fork(reject, resolve):
        return resolve(1)

    task = Task(f_map_fork)
    assert task.map(f_map_map)(reject, resolve) == f_map_fork(reject, f_map)



# Generated at 2022-06-26 00:09:14.304904
# Unit test for method bind of class Task
def test_Task_bind():
    for __index, __value in ((0, b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3')):
        # Prepare arguments for Task

        # Call method bind of Task with prepared arguments
        task_0 = Task.of(b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3').bind(lambda arg_0: Task.of(arg_0))


# Generated at 2022-06-26 00:09:28.404737
# Unit test for method bind of class Task
def test_Task_bind():
    def case0(value):
        return Task(lambda _, resolve: resolve(value))

    def case1(value):
        return Task(lambda _, resolve: resolve(value))

    result = case0(Task.of(10)).bind(lambda value: case1(value))
    assert result.fork(None, lambda value: value) == 10

    result = case0(Task.of(10)).bind(lambda value: case0(value))
    assert result.fork(None, lambda value: value) == 10

    result = case0(Task.of(20)).bind(lambda value: case1(value)) 
    assert result.fork(None, lambda value: value) == 20

    result = case0(Task.of(30)).bind(lambda value: case1('test'))
    assert result.fork(None, lambda value: value)

# Generated at 2022-06-26 00:09:38.055503
# Unit test for method map of class Task
def test_Task_map():
    input_0 = Task.of(1)
    input_1 = Task.of(2)
    input_2 = Task.of(3)
    input_3 = Task.of(4)
    test_0 = input_0.map(lambda arg: arg + 1)
    test_1 = input_1.map(lambda arg: arg + 1)
    test_2 = input_2.map(lambda arg: arg + 1)
    test_3 = input_3.map(lambda arg: arg + 1)
    assert test_0.fork(lambda arg: None, lambda arg: arg) == 2
    assert test_1.fork(lambda arg: None, lambda arg: arg) == 3
    assert test_2.fork(lambda arg: None, lambda arg: arg) == 4

# Generated at 2022-06-26 00:09:45.660358
# Unit test for method bind of class Task
def test_Task_bind():
    # Test for Task.bind
    # @type Task[int]
    task_0 = Task.of(5)

    def inc(value):
        return value + 1

    # @type Task[int]
    task_1 = task_0.bind(inc)
    # @type int
    task_1_resolve_result = task_1.fork(None, lambda value: value)
    print(f'{task_0.fork(None, lambda value: value)} + 1 = {task_1_resolve_result}')


if __name__ == '__main__':
    test_Task_bind()
    test_case_0()

# Generated at 2022-06-26 00:09:55.142604
# Unit test for method map of class Task
def test_Task_map():
    TASK_0 = Task(lambda _, resolve: resolve(5))
    TASK_1 = TASK_0.map(lambda a: a + 20)
    assert TASK_1.fork(lambda a: None, lambda a: a) == 25
    assert type(TASK_1) == Task
    TASK_2 = Task(lambda _, resolve: resolve(5))
    TASK_3 = TASK_2.map(lambda a: a + 20)
    assert TASK_3.fork(lambda a: None, lambda a: a) == 25
    assert type(TASK_3) == Task
    TASK_4 = Task(lambda _, resolve: resolve(5))
    TASK_5 = TASK_4.map(lambda a: a + 20)
   

# Generated at 2022-06-26 00:10:02.025326
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_1():
        task_0 = Task.of(0)
        task_1 = task_0.map(lambda arg_0: arg_0 + 5)
        def result_0(reject, resolve):
            resolve(5)
        assert task_1.fork == result_0
    test_case_1()

    def test_case_2():
        task_0 = Task.of('abc')
        task_1 = task_0.map(lambda arg_0: arg_0 + 'def')
        def result_0(reject, resolve):
            resolve('abcdef')
        assert task_1.fork == result_0
    test_case_2()

    def test_case_3():
        task_0 = Task.of('abc')

# Generated at 2022-06-26 00:10:05.867612
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    task_0 = Task(bytes_0)
    def fn_0(num_0):
        return num_0
    task_0.map(fn_0)


# Generated at 2022-06-26 00:10:08.726405
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task(
        lambda reject, resolve: resolve(1))
    _ = task.bind(lambda value: Task.of(value * 2))
    assert(_.fork(None, None) == 2)


# Generated at 2022-06-26 00:10:18.869457
# Unit test for method map of class Task
def test_Task_map():
    def assert_equal(value, expected):
        assert value == expected

    def test_case_0():
        def to_uppercase(value):
            return value.upper()

        task_0 = Task.of(b'!')

        task_1 = task_0.map(to_uppercase)
        assert_equal(task_1.fork, b'!')

    def test_case_1():
        def to_uppercase(value):
            return value.upper()

        task_0 = Task.of(b'!')

        task_1 = task_0.map(to_uppercase)
        assert_equal(task_1.fork, b'!')

    def test_case_2():
        def to_uppercase(value):
            return value.upper()


# Generated at 2022-06-26 00:10:28.126203
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind test
    """

    def task_fn_0(reject, resolve):
        resolve(2)

    def task_fn_1(reject, resolve):
        resolve(3)

    def task_fn_2(reject, resolve):
        resolve(4)

    def task_fn_3(reject, resolve):
        resolve(5)

    def task_fn_4(reject, resolve):
        reject(6)

    # initialization
    task_0 = Task(task_fn_0)
    task_1 = Task(task_fn_1)
    task_2 = Task(task_fn_2)
    task_3 = Task(task_fn_3)
    task_4 = Task(task_fn_4)


    # test case

# Generated at 2022-06-26 00:10:33.957776
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    task_0 = Task(bytes_0)

    bytes_1 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    task_1 = Task(bytes_1)


# Generated at 2022-06-26 00:10:55.976340
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    task_0 = Task(bytes_0)

    def func_0(_):
        return task_0

    task_1 = task_0.bind(func_0)

    def func_1(_):
        return task_0

    task_1 = task_0.bind(func_1)

    def func_2(_):
        return task_0

    task_1 = task_0.bind(func_2)

    def func_3(_):
        return task_1

    task_2 = task_0.bind(func_3)

    def func_4(_):
        return task_1


# Generated at 2022-06-26 00:11:03.064771
# Unit test for method map of class Task
def test_Task_map():
    def map_result(value):
        return str(value).encode('ascii')

    value = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    result0 = Task(value)
    result1 = result0.map(map_result)

    expected = value.decode('ascii').encode('ascii')
    assert result1.fork(lambda arg: arg, lambda arg: arg) == expected


# Generated at 2022-06-26 00:11:09.972672
# Unit test for method map of class Task
def test_Task_map():
    byte_to_int = lambda byte: byte + 1
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    bytes_1 = b'\xaf<\xfc\xe5\x19\xa7Iuc\x1e\xa4\x00+G\xc4'
    task_0 = Task(bytes_0)
    task_1 = Task(bytes_0).map(byte_to_int)
    assert task_1.fork == task_0.map(byte_to_int).fork



# Generated at 2022-06-26 00:11:13.866015
# Unit test for method map of class Task
def test_Task_map():
    def mapping(value):
        return value * 2

    def forking(reject, resolve):
        resolve(5)

    task = Task(forking)

    def fork_to_test(reject, resolve):
        resolve(mapping(5))

    assert task.map(mapping).fork == fork_to_test


# Generated at 2022-06-26 00:11:24.566929
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    task_0 = Task.of(bytes_0)
    assert isinstance(task_0, Task)
    def fn_0(arg_0):
        return Task.of(arg_0)

    assert fn_0(bytes_0) == Task(lambda _, resolve: resolve(b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'))

    def fn_1(arg_1):
        return Task(lambda reject, resolve: resolve(arg_1))


# Generated at 2022-06-26 00:11:30.023325
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task(lambda _, resolve: resolve(b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'))
    task_1 = task_0.bind(lambda _: Task(lambda _, resolve: resolve(True)))
    assert task_1.fork(lambda _: _, lambda arg: arg) == True
    task_2 = Task(lambda _, resolve: resolve(True)).bind(lambda _: Task(lambda _, resolve: resolve(bytes('hello', 'utf8'))))
    assert task_2.fork(lambda _: _, lambda arg: arg) == bytes('hello', 'utf8')

# Generated at 2022-06-26 00:11:34.313937
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_1():
        bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
        new_fn = lambda arg: Task.of(arg)
        new_task = Task(new_fn)
        new_task.bind(bytes_0)

test_Task_bind()

# Generated at 2022-06-26 00:11:40.361414
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(x):
        return x + 1
    def mapper2(x):
        return x + 1

    task_0 = Task.of(1)
    task_1 = task_0.map(mapper)
    task_2 = task_1.bind(lambda x: Task.reject(x))
    task_3 = task_1.map(mapper2)


# Generated at 2022-06-26 00:11:44.719664
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x: Task.of(2)).fork(lambda _: False, lambda x: x == 2)
    assert Task.of(1).bind(lambda x: Task.of(2)).map(lambda x: x * 2).fork(lambda _: False, lambda x: x == 4)
    assert Task.reject(1).bind(lambda x: Task.of(2)).fork(lambda x: x == 1, lambda _: False)
    assert Task.reject(1).map(lambda x: x * 2).fork(lambda x: x == 1, lambda _: False)



# Generated at 2022-06-26 00:11:49.258650
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    task_mapped_by_plus_2 = task.map(lambda x: x + 2)
    assert task is not task_mapped_by_plus_2
    assert isinstance(task_mapped_by_plus_2, Task)
    assert task_mapped_by_plus_2.fork(None, lambda x: x) == 3


# Generated at 2022-06-26 00:12:21.795055
# Unit test for method bind of class Task
def test_Task_bind():
    from Task import Task

    # Test 1
    fork = eval('lambda reject, resolve: resolve(1)')
    task_obj = Task(fork)
    fn = eval('lambda x: Task(lambda reject, resolve: resolve(x+1))')
    res = task_obj.bind(fn)
    assert res.fork(lambda x: x, lambda x: x) == 2, "Test 1 failed"

    # Test 2
    fork = eval('lambda reject, resolve: resolve(1)')
    task_obj = Task(fork)
    fn = eval('lambda x: Task(lambda reject, resolve: reject(x+1))')
    res = task_obj.bind(fn)
    assert res.fork(lambda x: x, lambda x: x) == 2, "Test 2 failed"

    # Test 3

# Generated at 2022-06-26 00:12:30.739070
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of('Hello World!')
    assert task_0.fork(lambda v: v, str.upper) == 'HELLO WORLD!'

    task_1 = Task.reject('Hello World!')
    assert task_1.fork(lambda v: v, str.upper) == 'Hello World!'

    task_2 = Task.of('Hello World!')
    task_3 = task_2.map(str.upper)
    assert task_3.fork(_, lambda v: v) == 'HELLO WORLD!'

    task_4 = Task.reject('Hello World!')
    task_5 = task_4.map(str.upper)
    assert task_5.fork(lambda v: v, _) == 'Hello World!'


# Generated at 2022-06-26 00:12:39.332193
# Unit test for method map of class Task
def test_Task_map():
    """
    Make simple test for method map of class Task.
    """
    task_0 = Task.of(1)
    assert task_0.fork(lambda arg: arg, lambda arg: arg) == 1
    task_1 = task_0.map(lambda arg: arg + 1)
    assert task_1.fork(lambda arg: arg, lambda arg: arg) == 2
    task_2 = task_1.map(lambda arg: arg + 2)
    assert task_2.fork(lambda arg: arg, lambda arg: arg) == 4

    task_3 = Task.of(1)
    task_4 = task_3.map(lambda arg: Task.of(arg + 1))
    assert task_4.fork(lambda arg: arg, lambda arg: arg) == 2

# Generated at 2022-06-26 00:12:47.581147
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'

    task_0 = Task(lambda reject, resolve: resolve(bytes_0))

    task_1 = task_0.bind(lambda value: Task(lambda reject, resolve: resolve(len(value))))

    assert task_1.fork(
        lambda arg: 'fail' + str(arg),
        lambda arg: 'success' + str(arg)
    ) == 'success20'

# Generated at 2022-06-26 00:12:52.069214
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    task_0 = Task(bytes_0)
    result_from_map = task_0.map(lambda arg_0: arg_0)
    assert result_from_map == task_0


# Generated at 2022-06-26 00:12:57.521908
# Unit test for method map of class Task
def test_Task_map():
    t1 = Task.of(2)
    t2 = Task.of(3)
    result = t1.map(lambda v: v + 1)
    assert result.fork(None, lambda v: v) == 3
    result = result.map(lambda v: v * 2)
    assert result.fork(None, lambda v: v) == 6
    result = t2.map(lambda v: v + 2)
    assert result.fork(None, lambda v: v) == 5


# Generated at 2022-06-26 00:13:03.677393
# Unit test for method bind of class Task
def test_Task_bind():
    def helper(fmt):
        return [fmt, lambda arg: arg ** 2, lambda arg: arg * 2]

    def mapper(arg):
        fmt, first_mapper, second_mapper = helper(arg)
        return Task.of(fmt).map(first_mapper).map(second_mapper)

    task = Task.of(True)
    values = [0] * 1000000
    for i, _ in enumerate(values):
        values[i] = task.bind(mapper).fork(lambda _: _, lambda _: _)

    assert True


# Generated at 2022-06-26 00:13:06.676796
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return range(x)

    value = 5
    task_0 = Task.of(value).map(fn)
    assert(task_0.fork(
        lambda err: None,
        lambda res: res
    ) == fn(value))



# Generated at 2022-06-26 00:13:15.260650
# Unit test for method bind of class Task
def test_Task_bind():
    call_counter = 0

    def fn(value):
        nonlocal call_counter
        call_counter += 1
        return Task.of('%s_%s' % (value, call_counter))

    result = Task.of(0).bind(fn).fork(None, None)

    # Call Task[A, B] with two argument lambda.
    # Lambda return value if Task resolved
    # and return reject if Task rejected.
    assert result == '0_1'
    assert call_counter == 1

    result = Task.reject(0).bind(fn).fork(None, None)
    assert result == 0
    assert call_counter == 1



# Generated at 2022-06-26 00:13:16.132742
# Unit test for method bind of class Task
def test_Task_bind():
    assert True


# Generated at 2022-06-26 00:14:21.978770
# Unit test for method bind of class Task
def test_Task_bind():
    """Unit test for method bind of class Task."""
    Task(b"123")\
        .map(lambda arg: arg.decode())\
        .map(lambda arg: int(arg))\
        .map(lambda arg: hex(arg))\
        .map(lambda arg: bytes.fromhex(arg))\
        .map(lambda arg: arg.decode())\
        .map(lambda arg: "Hello " + arg + "!")\
        .map(lambda arg: print(arg))\
        .fork(
            lambda _: None,
            lambda _: None
        )



# Generated at 2022-06-26 00:14:34.254762
# Unit test for method map of class Task
def test_Task_map():
    """
    Test case `Task.map`
    """

    # We define two functions
    def double(arg):
        return arg * 2

    def plus_one(arg):
        return arg + 1

    # We create simple Task
    task_0 = Task.of(0)
    task_1 = Task.of(1)

    # Check map result
    assert task_0.map(double).fork(None, lambda x: x) == 0
    assert task_1.map(double).fork(None, lambda x: x) == 2
    assert task_0.map(plus_one).fork(None, lambda x: x) == 1
    assert task_1.map(plus_one).fork(None, lambda x: x) == 2


# Generated at 2022-06-26 00:14:40.539474
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map

    :returns: void
    :rtype: None
    """
    bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
    task_0 = Task(bytes_0)

    assert_equals(task_0.map(len), Task(len(bytes_0)))
    assert_equals(task_0.map(chr), Task(chr(bytes_0[0])))
    task_1 = Task(chr(bytes_0[0]))
    assert_equals(task_1.map(ord), Task(ord(chr(bytes_0[0]))))



# Generated at 2022-06-26 00:14:51.959058
# Unit test for method map of class Task
def test_Task_map():
    from typing import Callable, Any
    def of(cls, value):
        def result(_, resolve):
            return resolve(value)

        return Task(result)

    def curry(cls, func):
        def result(arg_1, arg_2):
            return func(arg_1, arg_2)

        return result

    def f(_):
        def result(reject, resolve):
            return resolve("New")

        return Task(result)

    def map(self, fn):
        def result(reject, resolve):
            return self.fork(
                lambda arg: reject(arg),
                lambda arg: fn(arg).fork(reject, resolve)
            )

        return Task(result)


# Generated at 2022-06-26 00:14:59.232642
# Unit test for method bind of class Task
def test_Task_bind():
    def assert_task_bind(task_0, task_1_value, task_2_value):
        task_1 = Task.of(task_1_value)
        task_2 = Task.of(task_2_value)

        task_0.bind(lambda t: task_1).bind(lambda t: task_2)

    def bytes_0(task_0_value, task_1_value, task_2_value):
        task_0 = Task.of(task_0_value)
        task_1 = Task.of(task_1_value)
        task_2 = Task.of(task_2_value)

        task_0.bind(lambda t: task_1).bind(lambda t: task_2)


# Generated at 2022-06-26 00:15:01.242315
# Unit test for method bind of class Task
def test_Task_bind():
    task_1 = Task.of(1)
    task_2 = task_1.bind(lambda arg: Task.of(arg + 1))
    assert task_2.fork(lambda err: None, lambda val: val) == 2



# Generated at 2022-06-26 00:15:05.185143
# Unit test for method bind of class Task
def test_Task_bind():
    # Test case 0
    def test_case_0():
        bytes_0 = b'\xae;\xfb\xe4\x18\xa6Htb\x1d\xa3\xff*F\xc3'
        task_0 = Task.of(bytes_0)
        def fn_0(arg_0):
            def task_0(reject, resolve):
                data = byte = ''
                for byte in arg_0:
                    hex_code = '%02x' % byte
                    data += hex_code
                resolve(data)
            return Task(task_0)
        task_1 = task_0.bind(fn_0)
        assert(isinstance(task_1, Task))
        assert(not hasattr(task_1, 'fork'))

    # Test case 1

# Generated at 2022-06-26 00:15:10.685257
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_0():
        def fork_0(reject, resolve):
            def result_0():
                raise AssertionError
            return result_0
        task_0 = Task(fork_0)
        def fn_0(value):
            def fork_1(reject, resolve):
                def result_1():
                    raise AssertionError
                return result_1
            return Task(fork_1)
        task_1 = task_0.bind(fn_0)


# Generated at 2022-06-26 00:15:16.466948
# Unit test for method bind of class Task
def test_Task_bind():
    def main():
        # Test data
        # function to map value
        def map_square(value):
            return value * value

        def fork_result(reject, resolve):
            resolve(1)

        task_0 = Task(fork_result)

        # Call method
        result = task_0.bind(map_square)

        # Test result
        assert result.fork(lambda _, __: False, lambda value: value == 1)

# Generated at 2022-06-26 00:15:21.459589
# Unit test for method bind of class Task
def test_Task_bind():
    # Unit test for function of method bind of class Task
    def function_is_callable():
        Task.reject('nil').bind(lambda value: Task.of(value))

    # Unit test for value of method bind of class Task
    def value_is_Task_of_value():
        task = Task.of(10)

        def task_of_value(value: int) -> Task:
            return Task.of(value)

        assert isinstance(task.bind(task_of_value), Task)
