

# Generated at 2022-06-26 00:05:57.178667
# Unit test for method bind of class Task
def test_Task_bind():
    def task_0(reject, resolve):
        return resolve("foo")

    def task_1(reject, resolve):
        return resolve("bar")

    def task_2(reject, resolve):
        return resolve("baz")

    def fn_0(arg_0):
        return Task(task_1)

    def fn_1(arg_0):
        return Task(task_2)

    def assert_equal(value_0, value_1):
        if not (value_0 == value_1):
            raise AssertionError(
                "expected_0: %s expected_1: %s"
                % (str(value_0), str(value_1))
            )

    task_3 = Task(task_0)
    task_4 = Task(task_1)
    task_5 = Task

# Generated at 2022-06-26 00:06:04.767892
# Unit test for method bind of class Task
def test_Task_bind():
    def test_Task_bind_case_0():
        def bind_0(value):
            def fn_0(value):
                return bind_0(value)

            return fn_0

        tuple_0 = ()
        task_0 = Task(tuple_0)
        task_1 = task_0.bind(bind_0)
        assert task_1.fork(None, None) == None

    def test_Task_bind_case_1():
        def bind_0(value):
            def fn_0(value):
                return bind_0(value)

            return fn_0

        def fork_0(_, resolve):
            return resolve(False)

        task_0 = Task(fork_0)
        task_1 = task_0.bind(bind_0)

# Generated at 2022-06-26 00:06:09.391300
# Unit test for method map of class Task
def test_Task_map():
    def fn_0(arg_0):
        return arg_0 + 1

    def fn_1(arg_0):
        return arg_0 + 1

    task_0 = Task.of(1).map(fn_0)
    tuple_0 = task_0.fork()

    assert fn_1(tuple_0[1]) == 3


# Generated at 2022-06-26 00:06:18.188963
# Unit test for method map of class Task
def test_Task_map():
    def test_function(input_value):
        return input_value + 1

    def test_fork_function(_, resolve):
        return resolve(1)

    def test_expected_fork_function(_, resolve):
        return resolve(2)

    class TestTaskMap:
        def test_1(self):
            actual_result = Task(test_fork_function).map(test_function).fork
            expected_result = test_expected_fork_function
            assert actual_result == expected_result

    TestTaskMap.test_1(TestTaskMap())



# Generated at 2022-06-26 00:06:23.044453
# Unit test for method map of class Task
def test_Task_map():
    result_0 = Task.of(
        1
    ).map(
        lambda value_0: value_0
    ).fork(
        lambda error: False,
        lambda value_1: value_1 == 1
    )

    result_1 = Task.reject(
        'error'
    ).map(
        lambda value_2: value_2
    ).fork(
        lambda error: error == 'error',
        lambda value_3: value_3 == None
    )

    assert result_0 and result_1


# Generated at 2022-06-26 00:06:29.655595
# Unit test for method bind of class Task
def test_Task_bind():
    # Count of errors
    count_error = 0
    # Count of test
    count_test = 0

    # Call function bind with tuple as arg
    try:
        test_case_0()
    except TypeError:
        count_error += 1

    # Count of test
    count_test += 1

    # Return result
    if count_error > 0:
        return '|------------->> Test task_0 failed!!!'
    else:
        return '|------------->> Test task_0 passed!!!'

# Generated at 2022-06-26 00:06:39.207828
# Unit test for method bind of class Task
def test_Task_bind():
    def __is_equal(task, expected):
        try:
            task.fork(
                lambda rejected: print(rejected),
                lambda resolved: print(resolved)
            )
        except Exception as e:
            print(e)

    # test case 1
    print('Test case 1: bind raise exception')
    try:
        task = Task.of(1).bind(lambda arg: arg)
        __is_equal(task, False)
    except Exception as e:
        print(e)
    print('\n')

    # test case 2
    print('Test case 2: bind with string')
    task = Task.of(1).bind(lambda arg: Task.of(str(arg)))
    __is_equal(task, '1')
    print('\n')

    # test case 3

# Generated at 2022-06-26 00:06:43.746797
# Unit test for method bind of class Task
def test_Task_bind():
    expected = "task_0.fork(reject, lambda: None)"
    task_0 = Task(lambda reject, resolve: reject("result"))
    result = task_0.bind(lambda: None).fork(lambda: None, lambda: None)
    assert expected == str(result)


# Generated at 2022-06-26 00:06:49.095111
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.reject(value)

    def mapper_1(value):
        return Task.of(value)

    def reject(value):
        return 0

    def resolve(value):
        return value

    task = Task(lambda _, resolve: resolve(1))

    assert task.bind(mapper).fork(reject, resolve) == 0
    assert task.bind(mapper_1).fork(reject, resolve) == 1

# Generated at 2022-06-26 00:06:54.743026
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(1)
    task_1 = task_0.bind(lambda x: Task.of(x + 1))
    task_2 = task_1.bind(lambda y: Task.of(y + 1))
    task_3 = task_2.bind(lambda z: Task.of(z + 1))
    print(task_3)


# Generated at 2022-06-26 00:07:06.225143
# Unit test for method map of class Task
def test_Task_map():
    int_0 = Task.of(3).map(lambda x: x + 1).fork(lambda _: None, lambda value: assertEqual(value, 4))
    int_1 = Task.of(10).map(lambda x: x * 2).map(lambda x: x + 1).fork(lambda _: None, lambda value: assertEqual(value, 21))
    int_2 = Task.of("str").map(lambda x: len(x)).fork(lambda _: None, lambda value: assertEqual(value, 3))
    int_3 = Task.of([1, 2, 4]).map(lambda x: len(x)).fork(lambda _: None, lambda value: assertEqual(value, 3))
    test_case_0()


# Generated at 2022-06-26 00:07:13.194183
# Unit test for method bind of class Task
def test_Task_bind():
    '''
    Test for Task.bind method.
    '''

    # Create stub for method Task.bind
    class StubTask:
        def bind(self, fn):
            return fn(1)

    # Create stub for method Task.fork
    class StubTaskWithFork:
        def fork(self, reject, resolve):
            return resolve(1)

    # Create stub for method Task.fork with reject
    class StubTaskWithForkReject:
        def fork(self, reject, resolve):
            return reject(1)

    # stub_task = StubTask()
    # stub_task_with_fork = StubTaskWithFork()

    # Create stub for method Task.fork.
    # Cause: In this case fork method should return result of fn(1)

# Generated at 2022-06-26 00:07:24.529958
# Unit test for method map of class Task
def test_Task_map():
    # Test case 0
    task_0 = Task.of(int_0)
    # Test case 1
    task_1 = Task.of(int_1)
    # Test case 2
    task_2 = Task.reject(int_2)
    # Test case 3
    task_3 = Task.reject(int_3)

    # Call map method with callable argument
    # Test case 0
    res_map_0 = task_0.map(lambda x: x * 2)
    assert res_map_0.fork(
        lambda _: int_4,
        lambda _: int_2,
    ) == int_2
    # Test case 1
    res_map_1 = task_1.map(lambda x: x * 2)

# Generated at 2022-06-26 00:07:31.819631
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(1).map(lambda x: x + 2).bind(lambda y: Task.reject(y - 3))
    result.fork(lambda x: print(x), lambda x: print(x))
    expected_reject_value = -2
    assert result.fork(lambda x: x, lambda x: x) == expected_reject_value
    assert type(result) == Task
    assert result.fork == Task.of(1).map(lambda x: x + 2).bind(lambda y: Task.reject(y - 3)).fork

# Generated at 2022-06-26 00:07:35.785772
# Unit test for method bind of class Task
def test_Task_bind():
    int_0 = 1
    task = Task.of(int_0)
    fn = lambda a: Task.of(a + 1)
    res = task.bind(fn)
    assert res.fork(None, lambda a: int_0 + 1) == 3


# Generated at 2022-06-26 00:07:42.077350
# Unit test for method bind of class Task
def test_Task_bind():
    int_0 = 1
    int_1 = 2

    def return_int_1(arg):
        return Task.of(int_1)

    def run_chain(resolve, reject):
        return Task.of(int_0) \
                   .map(lambda value: value + 1) \
                   .bind(return_int_1) \
                   .fork(reject, resolve)

    result = Task(run_chain)
    assert result.fork(None, None) == int_1


# Generated at 2022-06-26 00:07:47.425978
# Unit test for method bind of class Task
def test_Task_bind():
    int_0 = 1
    Task_1 = Task.of(int_0)
    Task_2 = Task_1.bind(lambda int_1: Task.of(int_0 + int_1))

# Generated at 2022-06-26 00:07:57.533258
# Unit test for method map of class Task
def test_Task_map():
    def test_case_0():
        task = Task.of(int_0)
        task = task.map(lambda x: x + 1)
        assert task.fork(id, id) == int_0 + 1

    def test_case_1():
        task = Task.reject(int_0)
        task = task.map(lambda x: x + 1)
        assert task.fork(id, id) == int_0

    def test_case_2():
        def add(x):
            return Task.of(x + 1)

        task = Task.of(int_0)
        task = task.bind(add)
        assert task.fork(id, id) == int_0 + 1

    def test_case_3():
        def add(x):
            return Task.of(x + 1)

       

# Generated at 2022-06-26 00:08:02.465502
# Unit test for method map of class Task
def test_Task_map():
    def mock_fork(reject, resolve):
        return resolve(7)

    def mock_fn(value):
        return 2 * value

    int_0 = Task(mock_fork).map(mock_fn)
    assert isinstance(int_0, Task)
    assert int_0.fork(lambda _: False, lambda value: value == 14)


# Generated at 2022-06-26 00:08:05.053919
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda arg: Task.of(arg + 1)).fork(lambda arg: False, lambda arg: arg == 2)


# Generated at 2022-06-26 00:08:14.967265
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(["<value>"])
    task_1 = task_0.map(lambda arg_0: arg_0)
    tuple_0 = task_1.fork(lambda arg_0: ("reject", arg_0), lambda arg_0: ("resolve", arg_0))
    assert tuple_0 == ('resolve', ['<value>'])

test_Task_map()


# Generated at 2022-06-26 00:08:20.208978
# Unit test for method bind of class Task
def test_Task_bind():
    def _fork_mocked(reject, resolve):
        return resolve(42)

    task = Task(_fork_mocked)

    def _mapper(x):
        return x + 10

    task_resolved = task.bind(lambda x: Task.of(_mapper(x)))

    assert task_resolved.fork(lambda rejected: rejected, lambda resolved: resolved) == 52


# Generated at 2022-06-26 00:08:28.503126
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_0(arg_0):
        def fn_1(reject_0, resolve_0):
            return resolve_0(arg_0)

        def fn_2(reject_0, resolve_0):
            return resolve_0(arg_0)

        task_0 = Task(fn_1)
        return task_0.bind(fn_2)

    tuple_0 = ()
    task_0 = Task(tuple_0)
    assert task_0.bind(fn_0).fork(lambda a: a, lambda b: b) == task_0.fork(lambda a: a, lambda b: b)

    def fn_3(reject_0, resolve_0):
        raise NotImplementedError("No implementation for: fn_3")

    task_1 = Task(fn_3)

# Generated at 2022-06-26 00:08:33.715371
# Unit test for method bind of class Task
def test_Task_bind():
    def factory_0(value):
        def reject(arg): return arg + value
        def resolve(arg): return arg + value
        return Task(lambda reject, resolve: resolve(value))

    def test_0(value):
        task_0 = Task.of(value)
        task_1 = task_0.bind(factory_0)
        return task_1.fork(lambda arg: arg, lambda arg: arg)


# Generated at 2022-06-26 00:08:39.356893
# Unit test for method map of class Task
def test_Task_map():
    source_0 = Task(lambda reject, resolve: resolve('value_0'))
    source_1 = Task.of('value_0')
    source_2 = source_0.map(lambda arg: arg + '_0')
    source_3 = source_1.map(lambda arg: Task(lambda reject, resolve: resolve(arg + '_0')))


# Generated at 2022-06-26 00:08:40.218262
# Unit test for method map of class Task
def test_Task_map():
    test_case_0()


# Generated at 2022-06-26 00:08:49.225605
# Unit test for method map of class Task
def test_Task_map():
    # test for method Task.of
    def test_case_0():
        tuple_0 = ()
        task_0 = Task.of("")
        tuple_1 = (2, )
        task_1 = task_0.map(lambda x: tuple_1[0])
        task_1.fork(
            lambda value: print("error:", value),
            lambda value: print("value:", value)
        )

    def test_case_1():
        tuple_0 = ()
        task_0 = Task.of("")
        tuple_1 = (2, )
        task_1 = task_0.map(lambda x: tuple_1)
        task_1.fork(
            lambda value: print("error:", value),
            lambda value: print("value:", value)
        )


# Generated at 2022-06-26 00:08:53.391169
# Unit test for method bind of class Task
def test_Task_bind():
    def gen_func(value, fn):
        def result(resolve, reject):
            resolve(fn(value))
        return result

    def mapper(value):
        return value

    def gen_task(value, fn):
        return Task(gen_func(value, fn))

    task = gen_task(1, lambda x: x + 1)
    assert gen_task(1, mapper).bind(lambda val: gen_task(val, mapper)).fork(None, mapper) == 2

# Generated at 2022-06-26 00:09:01.428969
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1
    def minus_one(value):
        return value - 1
    def plus_one(a, b):
        return a + b
    tuple_0 = ()
    tuple_1 = (add_one, minus_one, plus_one)
    task_0 = Task(tuple_0).map(lambda value: value + 1)
    task_1 = Task(tuple_1).map(lambda value: value + 1)
    print(task_1.fork(tuple_0, tuple_0))


# Generated at 2022-06-26 00:09:04.692753
# Unit test for method map of class Task
def test_Task_map():
    def add2(value):
        return value + 2

    task = Task.of(2)

    task_1 = task.map(add2)

    assert task_1.fork(lambda err: "Error", lambda res: res) == 4



# Generated at 2022-06-26 00:09:18.397325
# Unit test for method bind of class Task
def test_Task_bind():
    tupler = (lambda arg: Task.of(arg + 1),)
    length_tupler = len(tupler) # Line 7
    index_tupler = 0
    task_0 = Task(())
    count_0 = 0
    while (count_0 <= length_tupler):
        def callback_0(arg):
            return (arg + 1)
        def callback_1(arg):
            return Task.of(arg + 1)
        try:
            task_0 = task_0.bind(tupler[index_tupler])
            count_0 += 1 # Line 13
            if (index_tupler >= length_tupler):
                index_tupler = 0
            else:
                index_tupler += 1
        except Exception as exception_0:
            print(exception_0)
    count_1 = 0

# Generated at 2022-06-26 00:09:27.008746
# Unit test for method bind of class Task
def test_Task_bind():
    # test case 0
    tuple_0 = ()
    task_0 = Task(tuple_0)
    def tuple_1():
        return Task.of(0)
    task_1 = task_0.bind(tuple_1)
    # test case 1
    tuple_2 = ()
    task_2 = Task(tuple_2)
    def tuple_3():
        return Task.of(1)
    task_3 = task_2.bind(tuple_3)
    # test case 2
    tuple_4 = ()
    task_4 = Task(tuple_4)
    def tuple_5():
        return Task.of(2)
    task_5 = task_4.bind(tuple_5)
    # test case 3
    tuple_6 = ()

# Generated at 2022-06-26 00:09:30.023931
# Unit test for method bind of class Task
def test_Task_bind():
    fn_0 = lambda a0: a0
    tuple_0 = ()
    task_0 = Task(tuple_0)
    task_1 = task_0.bind(fn_0)


# Generated at 2022-06-26 00:09:32.706407
# Unit test for method bind of class Task
def test_Task_bind():
    pass
    tuple_0 = ()
    task_0 = Task(tuple_0)
    task_0.bind(tuple_0)

# Generated at 2022-06-26 00:09:37.149191
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(1)
    task_1 = task_0.bind(lambda arg_0: Task.of(arg_0 + 1))
    task_2 = task_1.bind(lambda arg_1: Task.of(arg_1 + 1))
    task_3 = task_2.bind(lambda arg_2: Task.of(arg_2 + 1))


# Generated at 2022-06-26 00:09:46.621053
# Unit test for method bind of class Task
def test_Task_bind():
    tuple_0 = (lambda x: x + 1, 1)
    tuple_1 = (lambda x: x * 2, 2)
    tuple_2 = (lambda x: x * 3, 3)
    tuple_3 = (lambda x: x * 4, 4)
    tuple_4 = (lambda x: x * 5, 5)
    tuple_5 = (lambda x: x * 6, 6)
    tuple_6 = (lambda x: x * 7, 7)

    task_0 = Task(tuple_0[0])
    task_1 = task_0.map(tuple_1[0])
    task_2 = task_1.map(tuple_2[0])
    task_3 = task_2.map(tuple_3[0])

# Generated at 2022-06-26 00:09:47.773102
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(None).bind(None) == Task(None)


# Generated at 2022-06-26 00:09:51.435122
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of("Hello")

    def fn(value):
        return value + " World"

    task_1 = task_0.map(fn)
    print(task_1)

    task_2 = task_1.map(fn)
    print(task_2)


# Generated at 2022-06-26 00:09:55.230022
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(3)
    task = task.map(lambda x: x * x)
    assert task.fork == (
        lambda reject, resolve: resolve(9),
        None
    ), 'map in Task not works'


# Generated at 2022-06-26 00:09:58.190688
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value+1)

    input = Task.of(1)
    output = input.bind(mapper)
    assert callable(output.fork)
    assert output.fork(None, lambda value: value) == 2


# Generated at 2022-06-26 00:10:18.628688
# Unit test for method bind of class Task
def test_Task_bind():
    def is_name(name):
        return len(name) >= 4 and \
            name[0].isupper() and \
            all(character.isalpha() for character in name[1:])

    def transform_name(name):
        return name[0].lower() + name[1:]

    def get_name(resolve):
        resolve('Roman')

    def is_name_task(name):
        return Task.of(is_name(name))

    def transform_name_task(name):
        return Task.of(transform_name(name))

    task_0 = Task(get_name)
    task_1 = task_0.bind(is_name_task).bind(transform_name_task)
    assert task_0.fork(lambda _: True, lambda _: False)
    assert task_1.fork

# Generated at 2022-06-26 00:10:25.628951
# Unit test for method bind of class Task
def test_Task_bind():
    def task_0_fork(reject, resolve):
        return resolve(3)

    def task_1_fork(reject, resolve):
        return resolve(5)

    class task_0(Task):
        def __init__(self):
            super().__init__(task_0_fork)

    class task_1(Task):
        def __init__(self):
            super().__init__(task_1_fork)

    def f(x):
        return task_1()


# Generated at 2022-06-26 00:10:35.652461
# Unit test for method map of class Task
def test_Task_map():
    # annotation `A` on `task_0` is not needed here but
    # could be useful for self-documentation
    task_0: Task[A] = Task(lambda _, resolve: resolve(0))
    task_1: Task[A] = task_0.map(lambda x: x + 1)
    task_2: Task[A] = task_1.map(lambda x: x + 1)
    task_3: Task[A] = task_2.map(lambda x: x + 1)
    task_4: Task[A] = task_3.map(lambda x: x + 1)
    task_5: Task[A] = task_4.map(lambda x: x + 1)
    task_6: Task[A] = task_5.map(lambda x: x + 1)
    task_7

# Generated at 2022-06-26 00:10:40.836546
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of("test")

    def fn_0(arg):
        return str(arg)

    task_1 = task_0.map(fn_0)
    assert task_1.fork(lambda arg: False, lambda arg: True) is True

    task_2 = task_0.map(lambda arg: int(arg) + 1)
    assert task_2.fork(lambda arg: False, lambda arg: True) is True


# Generated at 2022-06-26 00:10:43.993921
# Unit test for method bind of class Task
def test_Task_bind():
    result_0 = Task.bind(
            Task.of("value_1"),
            lambda value_1: Task.of("value_2")
        )
    eq_0 = result_0.fork(
            lambda value_1: "value_1",
            lambda value_2: "value_2"
        )
    eq_1 = "value_2"
    assert eq_0 == eq_1


# Generated at 2022-06-26 00:10:47.910271
# Unit test for method map of class Task
def test_Task_map():
    # Test 0:
    try:
        tuple_0 = ()
        task_0 = Task(tuple_0)
        task_0.map(tuple_0)
        assert False
    except:
        assert True



# Generated at 2022-06-26 00:10:54.820512
# Unit test for method bind of class Task
def test_Task_bind():
    # Case: reject
    value = 'value'
    result = Task.of(value).bind(lambda _: Task.reject(None))
    assert result.fork(lambda _: 'rejected', lambda _: 'resolved') == 'rejected'
    # Case: resolve
    result = Task.of(value).bind(lambda arg: Task.of(arg + value))
    assert result.fork(lambda _: 'rejected', lambda arg: arg) == value + value


# Generated at 2022-06-26 00:11:01.745356
# Unit test for method map of class Task
def test_Task_map():
    def fn_0(arg_0):
        return arg_0

    def fn_1(arg_0):
        return arg_0

    def fn_2(arg_0):
        return arg_0

    tuple_0 = ()
    task_0 = Task(tuple_0)
    task_1 = task_0.map(fn_0)
    task_2 = task_1.map(fn_1)
    task_3 = task_2.map(fn_2)


# Generated at 2022-06-26 00:11:06.560865
# Unit test for method map of class Task
def test_Task_map():
    # task with value "value"
    dict_0 = {'reject': lambda arg: (lambda function: function(arg))}
    tuple_0 = (lambda arg0: lambda arg1: arg1(arg0))
    task_0 = Task(tuple_0)
    def function_0(arg):
        return f'value{arg}'
    task_1 = task_0.map(function_0)
    task_1.fork(**dict_0)


# Generated at 2022-06-26 00:11:12.552311
# Unit test for method map of class Task
def test_Task_map():
    def fn_0():
        tuple_0 = ()
        task_0 = Task.of(tuple_0)
        value_0 = task_0.map(lambda tuple_1: tuple_1)
        value_1 = value_0.fork()
        value_2 = value_1[0]
        value_3 = value_1[1]
        value_4 = value_3(None)
        return value_4

    value_5 = fn_0()
    value_6 = tuple()
    return value_5 == value_6



# Generated at 2022-06-26 00:11:38.189777
# Unit test for method bind of class Task
def test_Task_bind():
    tuple_0 = ()
    task_0 = Task(tuple_0)
    method_0 = task_0.bind
    tuple_1 = ()
    task_1 = Task(tuple_1)
    method_0(task_1)


# Generated at 2022-06-26 00:11:44.185163
# Unit test for method map of class Task
def test_Task_map():
    def fork_0(reject, resolve):
        return resolve(0)
    task_0 = Task(fork_0)
    def fn_0(value_0):
        return value_0
    task_1 = task_0.map(fn_0)
    def check_Task(task):
        return isinstance(task, Task)
    assert (check_Task(task_1) == True)

    def fork_1(reject, resolve):
        return resolve(0)
    task_2 = Task(fork_1)
    def fn_1(value_0):
        return value_0
    task_3 = task_2.map(fn_1)
    def check_Task(task):
        return isinstance(task, Task)
    assert (check_Task(task_3) == True)


# Generated at 2022-06-26 00:11:47.141558
# Unit test for method map of class Task
def test_Task_map():
    value = 42
    result = Task.of(value).map(lambda arg: arg + 1).fork(
        lambda arg: 'Not resolve',
        lambda arg: arg
    )

    assert result == 43


# Generated at 2022-06-26 00:11:49.087395
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of("")
    def fn_0(arg_0):
        return Task.of("")

    task_0.bind(fn_0)


# Generated at 2022-06-26 00:11:56.538677
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_0(value):
        return Task.of(value)

    def fn_1(value):
        return Task.reject(value)

    def fn_2(value):
        return Task(lambda reject, resolve: (reject(value), resolve(value)))

    tuple_0 = ()
    tuple_1 = ((),)

    tuple_0 = ()
    tuple_1 = (tuple_0,)
    tuple_2 = ((tuple_0,),)
    tuple_3 = ((tuple_0, tuple_0),)
    tuple_4 = ((tuple_0, tuple_0, tuple_0),)
    tuple_5 = ((tuple_0, tuple_0, tuple_0, tuple_0),)

# Generated at 2022-06-26 00:12:01.906119
# Unit test for method map of class Task
def test_Task_map():
    # Test case 0
    fn_0 = lambda value: value
    task_0 = Task.of(0)
    task_1 = task_0.map(fn_0)

    # Test case 1
    fn_1 = lambda value: value
    task_2 = Task.of(1)
    task_3 = task_2.map(fn_1)



# Generated at 2022-06-26 00:12:12.456324
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of Task class.
    """
    # Test case 0
    def fn_0(value):
        return value

    tuple_0 = ()
    task_0 = Task(tuple_0)
    task_1 = task_0.map(fn_0)
    # Test case 1
    def fn_1(value):
        return value

    def fn_2(value, value_2):
        return value
    tuple_1 = (fn_1, fn_2)
    task_0 = Task(tuple_1)
    task_1 = task_0.map(fn_2)
    # Test case 2
    def fn_1(value):
        return value

    def fn_2(value, value_2):
        return value

# Generated at 2022-06-26 00:12:18.174828
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x + 1

    def run(reject, resolve):
        return resolve(9)

    task = Task(run)

    def fork(reject, resolve):
        reject(0)
        return resolve(9)

    new_task = task.map(fn)

    assert new_task.fork(lambda x: None, lambda x: None) == fork(lambda x: None, lambda x: None)


# Generated at 2022-06-26 00:12:21.419536
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2
    assert Task.reject('error').map(lambda x: x + 1).fork(lambda x: x, None) == 'error'


# Generated at 2022-06-26 00:12:30.663427
# Unit test for method map of class Task
def test_Task_map():
    def test_case_0():
        def add_2(x):
            return x + 2

        def multiply_by_100(x):
            return x * 100

        def divide_by_5(x):
            return x / 5

        task_0 = Task.of(10).map(add_2).map(multiply_by_100).map(divide_by_5)

        def fork_0(reject, resolve):
            return resolve(task_0)

        tuple_0 = fork_0()

        def case_0_0(value):
            assert value == 40, "value == 40"

        assert tuple_0(case_0_0), "assert tuple_0(case_0_0)"


# Generated at 2022-06-26 00:13:20.514498
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(2).bind(lambda x: Task.of(x + 2)) == Task.of(4)
    assert Task.of(2).bind(lambda x: Task.of(x + 2)).bind(lambda y: Task.of(y + 4)) == Task.of(8)
    assert Task.reject(2).bind(lambda x: Task.of(x + 2)) == Task.reject(2)
    assert Task.reject(2).bind(lambda x: Task.of(x + 2)).bind(lambda y: Task.of(y + 4)) == Task.reject(2)

test_Task_bind()

# Generated at 2022-06-26 00:13:25.798571
# Unit test for method bind of class Task
def test_Task_bind():
    def tuplify(arg):
        if isinstance(arg, tuple) and len(arg) == 2:
            return arg
        return (arg, arg)

    def add_one(arg):
        return (arg[0] + 1, arg[1] + 1)

    def eq(arg, arg_):
        return (arg[1] == arg_[1], arg_)

    resolved = Task.of([0, 1])
    rejected = Task.reject((1, 0))

    alice = resolved.bind(add_one).bind(tuplify)
    bob = resolved.bind(add_one).bind(tuplify).bind(add_one)

    alice.fork(lambda _: print("Fail"), lambda arg: print(arg))

# Generated at 2022-06-26 00:13:31.243334
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task(
        lambda reject, resolve: resolve('Hello World!')
    )

    def concat(value):
        return value + '!'

    task_1 = task_0.map(concat)

    task_2 = task_0.map(
        lambda value: Task(lambda reject, resolve: resolve(value + '!'))
    )

    task_3 = task_0.bind(
        lambda value: Task(lambda reject, resolve: resolve(value + '!'))
    )

    tuple_0 = (task_1, task_2, task_3)



# Generated at 2022-06-26 00:13:35.968459
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for map method of class Task.
    """
    def _test_map_of_resolved_task(p):
        """
        Test for resolved task
        :param p:
        :return:
        """
        v = p.map(lambda x: x + 1)
        assert v.fork == (lambda _, resolve: resolve(2))

    _test_map_of_resolved_task(Task.of(1))


# Generated at 2022-06-26 00:13:41.584618
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(1)
    task_1 = task_0.map(lambda _: 2)
    assert isinstance(task_1, Task)
    assert task_1.fork(lambda _: None, lambda value: value) == 2

    task_1 = task_0.map(lambda _: Task.reject(2))
    assert isinstance(task_1, Task)
    assert task_1.fork(lambda value: value, lambda _: None) == 2


# Generated at 2022-06-26 00:13:47.109769
# Unit test for method map of class Task
def test_Task_map():
    def add_one(arg):
        return arg + 1

    tuple_0 = ()
    task_0 = Task(tuple_0)
    task_1 = task_0.map(add_one)

    def add_two(arg):
        return arg + 2

    task_2 = task_1.map(add_two)



# Generated at 2022-06-26 00:13:52.386315
# Unit test for method map of class Task
def test_Task_map():
    # test 0
    tuple_0 = ()
    task_0 = Task(tuple_0)
    task_1 = task_0.map(tuple_0)
    assert isinstance(task_1, Task)

    # test 1
    tuple_0 = ()
    task_0 = Task(tuple_0)
    task_1 = task_0.map(tuple_0)
    assert task_1.fork is task_0.fork


# Generated at 2022-06-26 00:13:56.852787
# Unit test for method map of class Task
def test_Task_map():
    value = 5
    mapped_value = 7
    task_0 = Task.of(value)

    task_1 = task_0.map(lambda arg: arg + mapped_value - value)

    assert isinstance(task_1, Task)


# Generated at 2022-06-26 00:14:06.912768
# Unit test for method map of class Task
def test_Task_map():
    def to_upper(string):
        return string.upper()

    def to_lower(string):
        return string.lower()

    def fork(reject, resolve):
        return resolve('test')

    task_0 = Task(fork)
    task_1 = task_0.map(to_upper)
    task_2 = task_0.map(to_lower)
    task_3 = task_1.map(to_upper)
    task_4 = task_2.map(to_lower)
    task_5 = task_3.map(to_upper)
    task_6 = task_4.map(to_lower)
    task_7 = task_5.map(to_upper)
    task_8 = task_6.map(to_lower)

# Generated at 2022-06-26 00:14:10.117781
# Unit test for method map of class Task
def test_Task_map():
    tuple_0 = ()
    task_0 = Task(tuple_0)
    str_0 = fn_0(task_0)
    # assert value of str_0 is equal to "1"
    assert str_0 == "1"

