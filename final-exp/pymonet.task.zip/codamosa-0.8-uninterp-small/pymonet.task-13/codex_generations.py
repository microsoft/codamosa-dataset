

# Generated at 2022-06-26 00:05:56.289065
# Unit test for method bind of class Task
def test_Task_bind():
    # Bool task
    bool_0 = Task.of(True)
    fn_0 = lambda arg: Task.of(not arg)
    task_0 = bool_0.bind(fn_0)
    assert task_0.fork(lambda _: 'rejected', lambda arg: arg) == False, "should be False"

    # Num task
    num_0 = Task.of(3)
    fn_0 = lambda arg: Task.of(arg + 3)
    task_0 = num_0.bind(fn_0)
    assert task_0.fork(lambda _: 'rejected', lambda arg: arg) == 6, "should be 6"

    # String task
    str_0 = Task.of('Haskell')
    fn_0 = lambda arg: Task.of(arg[:3])

# Generated at 2022-06-26 00:06:01.401474
# Unit test for method bind of class Task
def test_Task_bind():
    def result(resolve, reject):
        return Task.of(42).bind(
            lambda arg: Task.of(arg + 1)
        ).fork(reject, resolve)

    def test(reject, resolve):
        value = result(reject, resolve)

        if value == 43:
            print('Unit test for method bind of class Task finished.')
        else:
            print('Unit test for method bind of class Task failed.')

    Task(test)


# Generated at 2022-06-26 00:06:04.274872
# Unit test for method bind of class Task
def test_Task_bind():
    assert eval(repr(Task.of(1).bind(lambda x: Task.of(x + 1)))), "Expect: 'Task(<function [reject, resolve]>)' but got '{}'".format(repr(Task.of(1).bind(lambda x: Task.of(x + 1))))

# Generated at 2022-06-26 00:06:10.341408
# Unit test for method map of class Task
def test_Task_map():
    # Task[Function(resolve, reject) -> A]
    def task_0(reject, resolve):
        resolve(0)

    task_00 = Task(task_0)

    # Task[Function(_, resolve) -> A]
    my_task = task_00.map(lambda arg: arg + 1)
    assert isinstance(my_task, Task)
    assert my_task.fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-26 00:06:19.598615
# Unit test for method map of class Task
def test_Task_map():
    """
    Check if method map of class Task are worked.
    """
    for number in range(100):
        def mapper(x):
            return x + 1

        def doubler(x):
            return x * 2

        def triple(x):
            return x * 3

        source_data = [
            Task.of(number).map(mapper).map(doubler).map(triple).fork(lambda x: None, lambda x: x)
        ]

        expected = [(number + 1) * 2 * 3]

        for index, task in enumerate(source_data):
            try:
                assert task == expected[index]
            except:
                return False
        return True


# Generated at 2022-06-26 00:06:23.558007
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(20)
    task_1 = task_0.map(lambda x: x + 1)
    assert task_1.fork(
        lambda arg: arg(),
        lambda arg: arg
    ) == 21
    task_2 = Task.reject(23).map(lambda x: x + 1)
    assert task_2.fork(
        lambda arg: arg,
        lambda arg: arg()
    ) == 23


# Generated at 2022-06-26 00:06:28.324912
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind method of class Task
    """
    assert True == Task.of(True).bind(lambda value: Task.of(value)).fork(
        lambda _: False,
        lambda value: value
    )
    assert False == Task.of(False).bind(lambda value: Task.of(value)).fork(
        lambda _: True,
        lambda value: value
    )

# Generated at 2022-06-26 00:06:37.953278
# Unit test for method bind of class Task
def test_Task_bind():
    # Test 0
    bool_0 = True
    task_0 = Task.of(bool_0)
    def fn(value):
        return Task.of(value)
    result = task_0.bind(fn)
    assert result.fork(lambda arg: arg, lambda arg: arg) == bool_0
    # Test 1
    value_0 = "value"
    task_1 = Task.of(value_0)
    def fn_1(value):
        return Task.of(not value)
    result_1 = task_1.bind(fn_1)
    assert result_1.fork(lambda arg: arg, lambda arg: arg) == False

if __name__ == "__main__":
    test_case_0()
    test_Task_bind()
    print("All test cases passed")

# Generated at 2022-06-26 00:06:39.552748
# Unit test for method bind of class Task
def test_Task_bind():
    # Test when left task is resolved
    # Test when left task is resolved and right task is rejected
    # Test when left task is rejected
    # Test when left task is rejected and right task is rejected
    pass



# Generated at 2022-06-26 00:06:42.966950
# Unit test for method map of class Task
def test_Task_map():
    task_test = Task.of(2)
    task_test_2 = task_test.map(lambda x: x+x)

    assert task_test_2.fork(None, None) == 4

# Generated at 2022-06-26 00:06:50.153573
# Unit test for method map of class Task

# Generated at 2022-06-26 00:06:51.141263
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:06:54.608299
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(3)

    def substract_one(value):
        return value - 1

    task_1 = task_0.bind(substract_one)

    assert (task_1.fork(None, None) == 2)

# Generated at 2022-06-26 00:06:57.247967
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(
        lambda x: Task.reject(x)
    ).fork(lambda x: x, lambda x: None) == 1


# Generated at 2022-06-26 00:07:06.843166
# Unit test for method bind of class Task
def test_Task_bind():
    """
    this test is inspired by the following source:
    https://github.com/fantasyland/fantasy-tasks/blob/58fd07dbd228d4c4b2ef8b7f367e9f1a9d9dfb3a/test/task.spec.js
    """
    def test_bind_with_void_should_chain(should_be_instance_of_A, should_be_none):
        """
        Should chain with void and return task with the same value.
        """
        task = Task.of(2)
        
        chained = task.bind(lambda x: Task.of(None))

        value, error = chained.fork(lambda x: (None, x), lambda x: (x, None))

        expected_value, expected_error = (2, None)

        should

# Generated at 2022-06-26 00:07:10.377039
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        assert value == 'some-value'

    def reject(value):
        raise Exception(value)

    def mapper(value):
        return Task.of(value)

    result = Task.of('some-value').bind(mapper)
    result.fork(reject, resolve)


# Generated at 2022-06-26 00:07:14.578812
# Unit test for method bind of class Task
def test_Task_bind():
    bool_0 = True
    bool_1 = True
    str_0 = "abcd"
    lam_0 = lambda : str_0
    task_0 = Task(bool_0)
    task_1 = task_0.bind(lambda : bool_0)
    assert str_0


# Generated at 2022-06-26 00:07:19.318492
# Unit test for method map of class Task
def test_Task_map():
    bool_0 = True
    task_0 = Task.of(bool_0)
    func_0 = lambda val: not val
    task_1 = task_0.map(func_0)


# Generated at 2022-06-26 00:07:25.226814
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of Task class with Task.of(1).map() method in lazy way.
    """
    def adding_one(input):
        return input + 1

    assert Task.of(1).map(adding_one).fork(None, lambda v: v) == 2



# Generated at 2022-06-26 00:07:31.081464
# Unit test for method bind of class Task
def test_Task_bind():
    bool_0 = True
    task_0 = Task(bool_0)
    task_0_bind = task_0.bind(lambda bool_0: bool_0)
    assert task_0_bind.fork(lambda bool_0: bool_0, lambda bool_0: bool_0) == True, 'task_0_bind = %s' % task_0_bind

test_Task_bind()


# Generated at 2022-06-26 00:07:41.806381
# Unit test for method map of class Task
def test_Task_map():
    """
    Task:
        resolve: int
        reject: str
    """

    task_0 = Task(lambda reject, resolve: resolve(1))
    task_1 = task_0.map(lambda x: x + 1)

    assert task_1.fork(
        lambda result: 'reject' if result == 2 else 'OK',
        lambda result: 'OK' if result == 2 else 'reject'
    ) == 'OK'



# Generated at 2022-06-26 00:07:46.025764
# Unit test for method bind of class Task
def test_Task_bind():
    bool_0 = True
    task_0 = Task.of(bool_0)
    bool_1 = True
    task_1 = Task.of(bool_1)
    task_0_0 = task_0.bind(lambda arg_0: task_1)
    assert task_0_0.fork(False, True) == True


# Generated at 2022-06-26 00:07:56.652344
# Unit test for method bind of class Task
def test_Task_bind():
    bool_0 = True
    get_TaskDownEnv_0 = get_TaskDownEnv()
    get_TaskDownEnv_0.fork(None, (lambda bool_1: bool_1))
    get_TaskDownEnv_0.bind((lambda down_env_0: down_env_0-1))
    get_TaskDownEnv_0.bind((lambda down_env_0: down_env_0-1))
    get_TaskDownEnv_0.bind((lambda down_env_0: down_env_0-1))
    get_TaskDownEnv_0.bind((lambda down_env_0: down_env_0-1))
    get_TaskDownEnv_0.bind((lambda down_env_0: down_env_0-1))
    get_TaskDownEnv_0

# Generated at 2022-06-26 00:07:57.610661
# Unit test for method bind of class Task
def test_Task_bind():
    pass


# Generated at 2022-06-26 00:08:02.540802
# Unit test for method bind of class Task
def test_Task_bind():
    def f(a):
        return Task.of(a)

    def g(a):
        return Task.of(a)

    def h(a):
        return Task.of(a)

    assert Task.of(0).bind(f).bind(g).bind(h).fork(lambda _: 1, lambda x: x) == 0



# Generated at 2022-06-26 00:08:11.691399
# Unit test for method bind of class Task
def test_Task_bind():
    bool_0 = Task.of(True).bind(lambda arg: Task.of(arg))
    bool_1 = bool_0.fork(
        lambda arg: True,
        lambda arg: False
    )
    bool_2 = bool_1 == True

    bool_3 = Task.of(True).bind(lambda arg: Task.reject(arg))
    bool_4 = bool_3.fork(
        lambda arg: arg,
        lambda arg: False
    )
    bool_5 = bool_4 == True

    bool_6 = Task.reject(True).bind(lambda arg: Task.of(arg))
    bool_7 = bool_6.fork(
        lambda arg: arg,
        lambda arg: False
    )
    bool_8 = bool_7 == True


# Generated at 2022-06-26 00:08:18.912251
# Unit test for method bind of class Task
def test_Task_bind():
    def result(reject, resolve):
        return reject(Task.of(5).fork(
            lambda arg: reject(arg),
            lambda arg: resolve(arg)
        ))

    assert Task.of(5).fork(
        lambda arg: reject(arg),
        lambda arg: resolve(arg)
    ) == 5

    assert Task.of(5).bind(
        lambda arg: result(
            lambda arg: None,
            lambda arg: arg
        )
    ).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 5

# Generated at 2022-06-26 00:08:23.151534
# Unit test for method map of class Task
def test_Task_map():
    def round(x):
        return int(x)

    task_0 = Task.of(2.5)
    task_1 = task_0.map(round)

    def fork(reject, resolve):
        def equal(value):
            assert value == 2
        task_1.fork(reject, equal)

    Task(fork)



# Generated at 2022-06-26 00:08:26.430689
# Unit test for method bind of class Task
def test_Task_bind():

    # test empty function
    task_0 = Task.reject(1)
    task_0 = task_0.bind(lambda _: Task.reject(2))
    assert task_0.fork(lambda value: value == 2, lambda _: False)


# Generated at 2022-06-26 00:08:28.400685
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve('value')).map(lambda x: 'mapped_' + x).fork(
        lambda value: 'error',
        lambda value: value
    ) == 'mapped_value'



# Generated at 2022-06-26 00:08:47.829516
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_0(value):
        return Task.of(value + 1)

    def fn_1(value):
        return Task.of(value * 2)

    def fn_2(value):
        return Task.reject(value)

    task_0 = Task.of(2)
    task_1 = Task.reject(2)

    # test for resolve
    result_0 = task_0.bind(fn_0).bind(fn_1)
    assert result_0.fork(lambda _: False, lambda v: v is 4)
    result_1 = task_0.bind(fn_1).bind(fn_0)
    assert result_1.fork(lambda _: False, lambda v: v is 5)

# Generated at 2022-06-26 00:08:54.118383
# Unit test for method bind of class Task
def test_Task_bind():
    # Test case 0
    # Task.of(True).bind(lambda _: False).fork(lambda _: True, lambda _: True)
    # fork(reject, resolve) -> resolve(reject(resolve(False))
    # -> resolve(False)
    # -> False
    assert Task.of(True).bind(lambda _: False).fork(
        lambda _: True,
        lambda _: False
    ) == False

    # Test case 1
    # Task.of(True).bind(lambda _: True).fork(lambda _: True, lambda _: True)
    # fork(reject, resolve) -> resolve(resolve(True))
    # -> resolve(True)
    # -> True

# Generated at 2022-06-26 00:09:00.052908
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task(lambda resolve, reject: resolve(0))
    task_0 = task_0.map(lambda value: value + 1)
    task_0 = task_0.map(lambda value: value + 1)
    task_0 = task_0.map(lambda value: value + 1)
    task_0 = task_0.map(lambda value: value + 1)


# Generated at 2022-06-26 00:09:05.301480
# Unit test for method bind of class Task
def test_Task_bind():
    def throw_value(value):
        raise value

    def throw_nothing(value):
        return value

    task_1 = Task.of(5).bind(throw_value)
    task_2 = Task.of(5).bind(throw_nothing)

    task_3 = Task.reject(5).bind(throw_value)
    task_4 = Task.reject(5).bind(throw_nothing)


# Generated at 2022-06-26 00:09:10.279298
# Unit test for method map of class Task
def test_Task_map():
    # prepare input
    task_0 = Task.of(1)
    task_1 = Task.reject("error")
    # test with good task
    assert task_0.map(lambda x: x + 1).fork(lambda x: "error", lambda x: x) == 2
    # test with bad task
    assert task_1.map(lambda x: "a").fork(lambda x: x, lambda x: x) == "error"


# Generated at 2022-06-26 00:09:15.951902
# Unit test for method bind of class Task
def test_Task_bind():
    def func_165(arg_167):
        return Task.of(arg_167 + " world")

    def func_168(arg_170):
        return Task.of(arg_170[::-1])

    def func_172(arg_174):
        return Task.of(arg_174 + "!")

    task_174 = Task.of("hello")
    task_174.bind(func_165).bind(func_168).bind(func_172).fork(lambda err: "error",
                                                                lambda val: val)



# Generated at 2022-06-26 00:09:23.354086
# Unit test for method map of class Task
def test_Task_map():
    def task_0_map_fn(value):
        return value + 1

    def task_1_map_fn(value):
        return value + " second"

    task_0 = Task.of(10)
    task_1 = task_0.map(task_0_map_fn)

    if task_1.fork(lambda _: None, lambda value: value) != 11:
        raise Exception("test_0_map failed")

    task_2 = task_1.map(task_1_map_fn)

    if task_2.fork(lambda _: None, lambda value: value) != "11 second":
        raise Exception("test_0_map failed")


# Generated at 2022-06-26 00:09:28.126674
# Unit test for method map of class Task
def test_Task_map():
    bool_1 = True
    add_one = lambda x: x + 1
    task_1 = Task(bool_1)
    task_1_map = task_1.map(add_one)
    task_1_map_fork = task_1_map.fork(lambda x: x, lambda x: x)
    return task_1_map_fork

print("test_Task_map() = ", test_Task_map())


# Generated at 2022-06-26 00:09:37.512352
# Unit test for method bind of class Task
def test_Task_bind():
    # Check that bind handle result of called as new Task
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(None, lambda x: x) == 2

    # Check that bind handle rejection of called as rejection of current Task
    assert Task.of(1).bind(lambda x: Task.reject(x + 1)).fork(lambda x: x, None) == 2

    # Check that bind can be called several times
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).bind(lambda x: Task.of(x + 1)).fork(None, lambda x: x) == 3

    # Check that bind call function immediately with value
    def fn(value):
        return Task.of(value)
    result = Task.of(1).bind(fn)

# Generated at 2022-06-26 00:09:40.893903
# Unit test for method map of class Task
def test_Task_map():
    # Before
    bool_0 = True
    task_0 = Task(bool_0)

    def function_0():
        pass

    # Call Task.map(fn)
    task_1 = task_0.map(function_0)



# Generated at 2022-06-26 00:10:11.153650
# Unit test for method bind of class Task
def test_Task_bind():
    # Test case 0
    #  Task(bool_0), fn_0
    # Result should be
    #  Task(False)
    bool_0 = False
    fn_0 = lambda arg_0: Task(bool_0)
    task_0 = Task.of(True).bind(fn_0)
    task_1 = Task(bool_0)
    assert task_0.fork == task_1.fork
    # Test case 1
    #  Task(str_0), fn_1
    # Result should be
    #  Task(str_1)
    str_0 = '0'
    str_1 = '1'
    fn_1 = lambda arg_1: Task(str_1)
    task_2 = Task.of(str_0).bind(fn_1)

# Generated at 2022-06-26 00:10:20.105086
# Unit test for method map of class Task
def test_Task_map():
    # Test 1
    add_1 = lambda val: val + 1
    task_1 = Task.of(1).map(add_1)

    def test_case_1():
        assert task_1.fork(lambda err: None, lambda val: val) == 2

    test_case_1()

    # Test 2
    add_2 = lambda val: val + 2
    task_2 = Task.of(1)

    def test_case_2():
        assert task_2.map(add_2).fork(lambda err: None, lambda val: val) == 3

    test_case_2()

    # Test 3
    add_3 = lambda val: val + 3

# Generated at 2022-06-26 00:10:25.106945
# Unit test for method bind of class Task
def test_Task_bind():
    def f_task(_, resolve):
        resolve(4)

    def g_task(_, resolve):
        resolve(5)

    def f(arg):
        return Task(f_task)

    def g(arg):
        return Task(g_task)

    assert Task(f_task).bind(f).bind(g).fork(None, lambda x: True) == True



# Generated at 2022-06-26 00:10:26.936119
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(4).bind(lambda _: Task.of(2)).fork(None, lambda arg: arg) == 2

# Generated at 2022-06-26 00:10:33.261102
# Unit test for method bind of class Task
def test_Task_bind():
    def fork1(reject, resolve):
        resolve(True)

    class TaskForTest(Task):
        def __init__(self, fork):
            self.fork = fork

    task1 = TaskForTest(fork1)

    def fork2(reject, resolve):
        resolve(True)

    task2 = TaskForTest(fork2)

    def mapper(value):
        return task2

    binded_task = task1.bind(mapper)

    assert binded_task.fork == fork2



# Generated at 2022-06-26 00:10:42.161981
# Unit test for method bind of class Task
def test_Task_bind():
    # input data
    task_0 = Task.of(True)
    task_1 = Task.of(1)
    task_2 = Task.of(2)

    # expected results
    expected_task_0_resolve = 1
    expected_task_1_reject = 1
    expected_task_2_resolve = 4

    # tests
    def test_case_0():
        """
        Task is rejected.
        """
        bool_0 = True

        task_0 = Task(
            lambda reject, _: bool_0 and reject(expected_task_1_reject)
        )

        task_1 = task_0.map(lambda val: val)
        task_2 = task_0.bind(lambda val: val)

        assert task_1.fork(lambda val: True, lambda val: False)

# Generated at 2022-06-26 00:10:52.531911
# Unit test for method bind of class Task
def test_Task_bind():
    print('**** Unit test for method bind of class Task')
    def task_fork(reject, resolve):
        pass

    def task_fork_mapper(value):
        return value

    def task_fork_mapper_1(value):
        return Task(task_fork)

    task = Task(task_fork)

    source = task.fork(task_fork_mapper, task_fork_mapper)
    source_1 = task.fork(task_fork_mapper, task_fork_mapper_1)

    assert source == task_fork_mapper(task_fork_mapper(task))
    assert source_1 == task_fork_mapper(task_fork_mapper_1(task))



# Generated at 2022-06-26 00:10:57.553657
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    task = Task.of(1).bind(lambda a: Task.of(2))

    def resolved(value):
        return value

    def rejected(value):
        return value

    assert task.fork(rejected, resolved) == 2



# Generated at 2022-06-26 00:10:59.226045
# Unit test for method map of class Task
def test_Task_map():
    pass


# Generated at 2022-06-26 00:11:00.732117
# Unit test for method bind of class Task
def test_Task_bind():
    data = Task.of(2)
    result = data.bind(lambda val: Task.of(val * 2))
    assert result.fork(_, resolve) == 4


# Generated at 2022-06-26 00:11:52.746867
# Unit test for method map of class Task
def test_Task_map():

    def test_map_success():
        """
        Assert that when called map method of Task, it must call fork method
        with resolve function and argument of given function
        """
        def test_fork(reject, resolve):
            resolve(0)

        def test_fn(arg):
            return arg + 1

        task = Task(test_fork)
        result = task.map(test_fn)
        assert result.fork(lambda reject: reject, lambda resolve: resolve) == 1

    def test_map_failure():
        """
        Assert that when called map method of Task, it must call fork method
        with reject function and argument of given function
        """
        def test_fork(reject, resolve):
            reject(0)

        def test_fn(arg):
            return arg + 1


# Generated at 2022-06-26 00:12:00.301592
# Unit test for method bind of class Task
def test_Task_bind():
    bool_0 = Task.of(2).bind(lambda x: Task.of(x + 2))
    assert(bool_0.fork(lambda _: False, lambda _: True))

    bool_1 = Task.of(2).bind(lambda x: Task.reject(x + 2))
    assert(bool_1.fork(lambda _: True, lambda _: False))

# Generated at 2022-06-26 00:12:11.159226
# Unit test for method bind of class Task
def test_Task_bind():
    # Unit test for method bind of class Task
    class MockedTask0:
        def __init__(self):
            self.value = None
            self.resolve = None
            self.reject = None

        def fork(self, reject, resolve):
            self.resolve = resolve
            self.reject = reject
            self.value = "abcd"
            return self

        def map(self, fn):
            self.value = fn(self.value)
            return self

        def bind(self, fn):
            self.value = fn(self.value)
            return fn(self.value)

    class MockedTask1:
        def __init__(self):
            self.value = None
            self.resolve = None
            self.reject = None


# Generated at 2022-06-26 00:12:19.376627
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper_0(arg):
        return 'Hello ' + arg

    def mapper_1(arg):
        return 'Hello ' + mapper_0(arg)

    def mapper_2(arg):
        return 'Hello ' + mapper_1(arg)

    task_0 = Task(lambda reject, resolve: resolve('world'))
    task_1 = task_0.map(mapper_0)
    task_2 = task_1.map(mapper_1)
    task_3 = task_2.map(mapper_2)

    assert task_3.fork(lambda reject: False, lambda resolve: True) == True


# Generated at 2022-06-26 00:12:28.898817
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(None).bind(lambda arg0: Task.of(True)) \
        .bind(lambda arg1: Task.of(str)) \
        .bind(lambda arg2: Task.of('Hello World')) \
        .map(lambda arg3: arg3[::-1]) \
        .map(lambda arg4: arg4.capitalize())

    assert task.fork(lambda err: print(err), lambda arg: arg) == 'Dlrow olleh'

# Generated at 2022-06-26 00:12:31.645589
# Unit test for method map of class Task
def test_Task_map():
    def f(value):
        return value + 1

    a = Task(lambda resolve, reject: resolve(1))
    b = a.map(f)
    assert b.fork(lambda reject, resolve: reject(1, 2)) == 2


# Generated at 2022-06-26 00:12:40.067004
# Unit test for method bind of class Task
def test_Task_bind():

    # Test 0 - check A|B
    result_0 = Task.of(2).bind(lambda a: Task.of(a + 2))
    value_0 = result_0.fork(lambda x: print("reject", x), lambda x: x)
    assert value_0 == 4
    print("Task_bind_0:", value_0)

    # Test 1 - check A|Error
    result_1 = Task.of(2).bind(lambda a: Task.reject(a + 2))
    value_1 = result_1.fork(lambda x: x, lambda x: print("resolve", x))
    assert value_1 == 4
    print("Task_bind_1:", value_1)

    # Test 2 - check Error|B

# Generated at 2022-06-26 00:12:49.680463
# Unit test for method bind of class Task
def test_Task_bind():
    bool_0 = True
    task_0 = Task(bool_0)
    task_1 = Task.of(task_0)
    task_2 = task_1.map(lambda bool_1: bool_1)
    task_3 = task_2.bind(lambda bool_2: bool_2)
    def mapper_0(bool_3):
        return bool_3
    task_4 = task_3.map(mapper_0)
    def fork_0(reject, resolve):
        return resolve(task_4)
    task_5 = Task(fork_0)
    def fork_1(reject, resolve):
        return resolve(task_5)
    task_6 = Task(fork_1)

# Generated at 2022-06-26 00:12:57.689313
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    task_0 = Task.of(True)
    def function_0(argument_0):
        return Task.of(argument_0)
    def function_1(argument_1):
        return Task.reject(argument_1)
    def function_2(argument_2):
        return Task.of(argument_2)
    bool_0 = task_0.bind(function_0).bind(function_1).bind(function_2).fork(lambda argument_3: argument_3, lambda argument_4: argument_4)
    bool_1 = True
    bool_2 = bool_0

    assert(bool_1 == bool_2)


# Generated at 2022-06-26 00:13:02.774548
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case(arg_0, arg_1):
        return Task.of(arg_0).bind(lambda arg_2: Task.of(arg_1).map(lambda arg_3: arg_2 + arg_3)).fork(
            lambda arg_4: arg_4,
            lambda arg_5: arg_5
        )
    assert test_case(1, 2) == 3
    assert test_case(1, 1) == 2
    assert test_case(2, 2) == 4


# Generated at 2022-06-26 00:14:55.487850
# Unit test for method map of class Task
def test_Task_map():
    def f(a):
        return a - 1

    def g(a):
        return a * a

    def h(a):
        return a + 2

    def resolve(x):
        return x

    def reject(x):
        return x

    a = Task(lambda reject, resolve: resolve(2))
    b = Task(lambda reject, resolve: resolve(4))
    c = Task(lambda reject, resolve: reject(6))

    # Case 0
    def case_0():
        assert a.map(f)
        assert b.map(g)
        assert c.map(h)

    # Case 1
    def case_1():
        assert a.map(f).fork(reject, resolve) == 1
        assert b.map(g).fork(reject, resolve) == 16

# Generated at 2022-06-26 00:14:57.555592
# Unit test for method map of class Task
def test_Task_map():
    result_0 = Task.of(1).map(lambda arg_0: arg_0 + 1)

# Generated at 2022-06-26 00:15:01.060674
# Unit test for method map of class Task
def test_Task_map():
    expected = ["A", "B", "C"]
    value = ["a", "b", "c"]

    def map_function(value):
        return value.upper()

    def fork_function(_, resolve):
        resolve(value)

    task = Task(fork_function)
    mapped_task = task.map(map_function)
    result = mapped_task.fork(None, None)
    assert result == expected



# Generated at 2022-06-26 00:15:03.545329
# Unit test for method map of class Task
def test_Task_map():
    bool_0 = True

    def fn_0(reject, resolve):
        return resolve(True)

    map_0 = Task(fn_0)

    def fn_1(reject, resolve):
        return resolve(True)

    map_1 = map_0.map(lambda _: True)

    assert bool_0 == map_1.fork(lambda _: False, lambda _: True)



# Generated at 2022-06-26 00:15:10.624678
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(1)

    task_0_map_0 = task_0.map(lambda arg: arg + 1)  # Task[Function(_, resolve) -> A]
    task_0_map_1 = task_0.map(lambda arg: arg + 1)  # Task[Function(_, resolve) -> A]
    task_0_map_2 = task_0.map(lambda arg: arg + 1)  # Task[Function(_, resolve) -> A]

    assert task_0_map_0.fork is task_0_map_1.fork == task_0_map_2.fork


# Generated at 2022-06-26 00:15:17.941952
# Unit test for method bind of class Task
def test_Task_bind():
    def ff(x):
        return Task.of(2 * x)

    def gg(x):
        return Task.of(3 * x)

    def hh(n):
        return Task.of(n + 1)

    t1 = Task.of(1)
    t2 = t1.bind(ff).bind(gg).bind(gg).bind(hh)
    t3 = t1.bind(ff)

    assert t2.fork(lambda x: None, lambda x: x) == 19
    assert t3.fork(lambda x: None, lambda x: x) == 2



# Generated at 2022-06-26 00:15:25.216808
# Unit test for method map of class Task
def test_Task_map():
    @task_instance
    def test_map_instance(fn, task):
        """
        Test map function of Task instance
        """
        @task_method
        def map_method(resolve, reject, task):
            task.map(fn)

        return map_method(task, fn)

    # Test right result
    def test_right():
        result = test_map_instance.of(lambda x: 2 * x).fork(
            lambda task: task.fork(
                lambda x: 2 * x
            )
        )
        assert result == 4

    # Test wrong result
    def test_wrong():
        result = test_map_instance.of(lambda x: 2 * x).fork(
            lambda task: task.fork(
                lambda x: x
            )
        )
        assert result == 2

    test_

# Generated at 2022-06-26 00:15:29.010012
# Unit test for method bind of class Task
def test_Task_bind():

    result = Task(lambda *_: "Task")  # Task<String>
    # bind multiply by 2
    result_0 = result.bind(lambda x: Task.of(x + ":1")).bind(lambda x: Task.of(x + ":2"))  # Task<String>
    assert result_0.fork(lambda _: None, lambda x: None) == "Task:1:2"

# Generated at 2022-06-26 00:15:36.875856
# Unit test for method bind of class Task
def test_Task_bind():
    def f(value):
        return value * 2

    def g(value):
        return Task.of(value - 1)

    def h(value):
        return Task.of(value + 1)

    task_0 = Task.of(1)
    task_1 = task_0.map(f)
    task_2 = task_1.bind(g)
    task_3 = task_2.map(f)
    task_4 = task_3.bind(h)

# Generated at 2022-06-26 00:15:39.316353
# Unit test for method map of class Task
def test_Task_map():
    def test_case_0():
        task_0 = Task.of(10)
        task_1 = task_0.map(lambda x: x + 1)
        assert task_0.fork(lambda x: x, lambda x: x) == 10

