

# Generated at 2022-06-26 00:05:48.716019
# Unit test for method bind of class Task
def test_Task_bind():
    pass


# Generated at 2022-06-26 00:05:58.089221
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(1)
    task_1 = task_0.map(lambda arg: arg + 1)
    task_2 = task_1.map(lambda arg: arg + 1)
    task_3 = task_2.map(lambda arg: arg + 1)

    def fork(reject, resolve):
        resolve(task_3)

    task_4 = Task(fork)
    task_5 = task_4.map(lambda arg: arg.fork(lambda _: _, lambda _: _))
    task_6 = task_5.map(lambda arg: arg(lambda _: _, lambda _: _))

    task_7 = Task(lambda reject, resolve: resolve(task_6.fork(lambda _: _, lambda _: _)(lambda _: _, lambda _: _)))

# Generated at 2022-06-26 00:06:05.134272
# Unit test for method map of class Task
def test_Task_map():
    def task_0_fork_0(reject, resolve):
        return reject('task_0_fork_0')

    task_0 = Task(task_0_fork_0)
    def task_0_map_0(value):
        return 'task_0_map_0'

    task_1 = task_0.map(task_0_map_0)
    def task_1_fork_0(reject, resolve):
        return reject('task_0_fork_0')

    def task_1_fork_1(reject, resolve):
        return resolve('task_0_fork_1')

    assert task_1.fork(task_1_fork_0, task_1_fork_1) == 'task_0_fork_1'


# Generated at 2022-06-26 00:06:10.642377
# Unit test for method bind of class Task
def test_Task_bind():
    def test(arg):
        return Task.of(arg + 1)

    task = Task.of(1).bind(test)

    def test_func(resolve, reject):
        if 2 == task.fork(reject, resolve):
            print("Task.bind test OK")
        else:
            print("Task.bind test FAIL")

    Task.of(None).fork(None, test_func)



# Generated at 2022-06-26 00:06:18.626856
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(2).bind(lambda a: Task.of(a + 2)).fork(None, lambda a: a) == 4
    assert Task.reject(3).bind(lambda a: Task.of(a + 1)).fork(lambda a: a, None) == 3
    assert Task.of(4).bind(lambda a: Task.reject(a + 1)).fork(lambda a: a, None) == 5
    assert Task.reject(5).bind(lambda a: Task.reject(a + 1)).fork(lambda a: a, None) == 5


# Generated at 2022-06-26 00:06:23.926376
# Unit test for method bind of class Task
def test_Task_bind():
    @add_to_dict
    def _Task_bind_0():
        task_0 = Task.of(1)
        task_1 = task_0.bind(lambda arg: Task.of(arg + 1))
        assert task_1.fork(lambda arg: arg, lambda arg: arg) == 2
    print("Unit test Task_bind success")
    return _Task_bind_0


# Generated at 2022-06-26 00:06:31.819171
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(None)
    task_1 = task_0.map(lambda arg: arg)
    task_2 = task_0.map(lambda arg: None)

    class ClassA(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return '{}({!r})'.format(self.__class__.__name__, self.value)

    task_3 = task_1.map(lambda arg: ClassA(arg))
    task_4 = task_2.map(lambda arg: ClassA(arg))



# Generated at 2022-06-26 00:06:41.768461
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    # Case 0 for method bind of class Task
    def case_0():
        """
        Case 0 for method bind of class Task
        """
        task = Task.of(1).bind(lambda x: Task.reject(x + 1))
        assert task.fork(lambda x: x, lambda x: x) == 2

    # Case 1 for method bind of class Task
    def case_1():
        """
        Case 1 for method bind of class Task
        """
        task = Task.of(1).bind(lambda x: Task.of(x + 1))
        assert task.fork(lambda x: x, lambda x: x) == 2

    test_cases = [
        case_0,
        case_1
    ]


# Generated at 2022-06-26 00:06:51.579936
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method.
    """
    def task_reject(m):
        return Task.reject(m)

    def task_resolve(m):
        return Task.of(m)

    def add_1(arg):
        return arg + 1

    def mul_2(arg):
        return arg * 2

    def div_2(arg):
        return arg / 2

    def id(ar):
        return ar

    def should_be_right_rejection():
        (Task
            .reject(2)
            .bind(task_reject)
            .fork(
                lambda arg: print('Expected error: {}'.format(arg)),
                lambda arg: print('Expected result: {}'.format(arg))
            ))


# Generated at 2022-06-26 00:06:58.849748
# Unit test for method map of class Task
def test_Task_map():
    def mapper(a):
        return a + 3

    def complex_0(reject, resolve):
        resolve(1)

    task_0 = Task(complex_0)
    task_1 = task_0.map(mapper)

    def complex_1(reject, resolve):
        resolve(4)

    task_2 = Task(complex_1)


# Generated at 2022-06-26 00:07:09.981652
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Check the bind method of class Task.

    :returns: (True) if all assertions are true else (False)
    :rtype: Boolean
    """
    task_0 = Task.reject('RESULT')
    task_1 = Task.of('value_1')
    task_2 = task_0.bind(lambda _: task_1)
    def completer(fn):
        return fn()

    task_3 = Task.of(
        'value_2'
    ).map(
        lambda _: 'value_2'
    ).map(
        lambda _: 'value_3'
    ).bind(
        lambda _: Task.of('value_3')
    )

    assert completer(task_2.fork('RESULT', None)) == 'RESULT'

# Generated at 2022-06-26 00:07:12.408793
# Unit test for method map of class Task
def test_Task_map():
    value_0 = 0
    complex_0 = None
    task_0 = Task.of(value_0).map(complex_0)


# Generated at 2022-06-26 00:07:20.098262
# Unit test for method map of class Task
def test_Task_map():
    
    # create resolved Task with value
    value = 24
    task = Task.of(value)

    # create mapper
    def mapper(x): return x + 1

    # check that Task has not been changed
    assert task.fork(noop, noop) == value

    # check that calling map return new Task
    new_task = task.map(mapper)
    assert new_task.fork(noop, noop) == mapper(value)

# Generated at 2022-06-26 00:07:23.878837
# Unit test for method map of class Task
def test_Task_map():
    def test(a, b):
        return Task(lambda _, resolve: resolve(a)).map(lambda arg: arg + b)

    assert test(1, 2).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 3


# Generated at 2022-06-26 00:07:29.184462
# Unit test for method map of class Task
def test_Task_map():
    # Define and lambda value
    dummy_value = 'value'
    dummy_result = 'result'
    lam_value = lambda dummy_value: dummy_result

    # Create and call new Task
    task_0 = Task.of(dummy_value).map(lam_value)
    # Check result
    assert task_0.fork(None, None) == dummy_result



# Generated at 2022-06-26 00:07:36.661821
# Unit test for method bind of class Task
def test_Task_bind():
    # Asserts
    assert Task(lambda _, resolve: resolve(1)).bind(lambda _: Task.reject(2)).fork(
        lambda arg: arg,
        lambda _: 'Error'
    ) == 2
    assert Task(lambda _, resolve: resolve(1)).bind(lambda _: Task.reject(2)).fork(
        lambda _: 'Error',
        lambda arg: arg
    ) == 'Error'

    assert Task.reject(1).bind(lambda _: Task.of(2)).fork(
        lambda arg: arg,
        lambda _: 'Error'
    ) == 1
    assert Task.reject(1).bind(lambda _: Task.of(2)).fork(
        lambda _: 'Error',
        lambda arg: arg
    ) == 'Error'


# Generated at 2022-06-26 00:07:46.111959
# Unit test for method bind of class Task
def test_Task_bind():
    def complex_0(reject, resolve):
        reject("Argument")
        resolve("Some value")
        return True

    def complex_1(reject, resolve):
        resolve("Some value")
        return True

    def complex_2(reject, resolve):
        resolve("Some value")
        return True

    def complex_3(reject, resolve):
        reject("Value")
        return False

    def complex_4(reject, resolve):
        reject("Value")
        return False

    def complex_5(reject, resolve):
        resolve("Some value")
        return True

    def complex_6(reject, resolve):
        resolve("Some value")
        return True

    def complex_7(reject, resolve):
        reject("Value")
        return False


# Generated at 2022-06-26 00:07:54.031493
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper_0(_):
        return Task.of("mapped_0")

    assert Task.of(1).bind(mapper_0).fork(lambda _, __: None, lambda _: assert_equal("mapped_0", _))

    def mapper_1(_):
        return Task.of("mapped_1")

    assert Task.reject("value_0").bind(mapper_1).fork(lambda _, __: None, lambda _: assert_equal("value_0", _))



# Generated at 2022-06-26 00:08:04.147388
# Unit test for method map of class Task
def test_Task_map():
    def complex_0(reject, resolve):
        if (True):
            resolve(1)
        else:
            reject(2)

    task_0 = Task(complex_0)
    def fnc_0(x):
        return x + 1

    task_1 = task_0.map(fnc_0)
    def complex_1(reject, resolve):
        if (True):
            resolve(2)
        else:
            reject(2)

    task_2 = Task(complex_1)
    (task_1 == task_2)

    def fnc_1(x):
        return x + 2

    task_3 = task_1.map(fnc_1)
    def complex_2(reject, resolve):
        if (True):
            resolve(4)
        else:
            reject

# Generated at 2022-06-26 00:08:11.381898
# Unit test for method map of class Task

# Generated at 2022-06-26 00:08:19.472289
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Check bind function work as expected
    """
    # Case 0
    try:
        test_case_0()
    except Exception as error:
        pass
    else:
        assert False

# Generated at 2022-06-26 00:08:25.404773
# Unit test for method map of class Task
def test_Task_map():
    task_1 = Task.of(1)
    assert task_1.map(lambda x: x + 1).fork(lambda arg: arg, lambda arg: arg) == 2

    task_2 = Task.of(1)
    assert task_2.map(lambda x: x * 2).fork(lambda arg: arg, lambda arg: arg) == 2

    task_3 = Task.of(1)
    assert task_3.map(lambda x: x - 1).fork(lambda arg: arg, lambda arg: arg) == 0



# Generated at 2022-06-26 00:08:32.278434
# Unit test for method map of class Task
def test_Task_map():
    task_map_0 = Task(lambda _, resolve: resolve(list(range(100)))).map(lambda value: value[0:10])
    task_map_0.fork(
        lambda reject: print("test_case_0: " + str(reject)),
        lambda resolve: print("test_case_0: " + str(resolve))
    )
    assert task_map_0.fork(lambda _: None, lambda resolve: resolve) == list(range(10))
    task_map_1 = Task.of(list(range(10))).map(lambda value: value[0:5])
    task_map_1.fork(
        lambda reject: print("test_case_1: " + str(reject)),
        lambda resolve: print("test_case_1: " + str(resolve))
    )


# Generated at 2022-06-26 00:08:42.709593
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test case class Task method bind

    Test:
        * Mapping Task.reject

    Expected:
        * Task rejected with mapped value

    :return:
    """
    def complex_0(reject, resolve):
        return reject("You got exception")

    def complex_1(reject, resolve):
        return resolve("You got something")

    def mapper(value):
        return value + "!"

    task_0 = Task(complex_0)
    result_0 = task_0.bind(mapper)

# Generated at 2022-06-26 00:08:47.732146
# Unit test for method map of class Task
def test_Task_map():
    # Test for empty task
    task_1 = Task.of(1)
    task_1.map(lambda value: value + 1)

    task_2 = Task.reject(1)
    task_2.map(lambda value: value + 1)

    # Test for passed task
    task = Task(
        lambda reject, resolve: resolve(1)
    )
    task.map(lambda value: value + 1)



# Generated at 2022-06-26 00:08:54.065894
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_0(value):
        return value

    def reject_0(value):
        return value

    def complex_0(reject_0, resolve_0):
        resolve_0(1)

    def complex_1(reject_0, resolve_0):
        reject_0(2)

    def complex_2(reject_0, resolve_0):
        resolve_0(3)

    def complex_3(reject_0, resolve_0):
        reject_0(4)

    def complex_4(reject_0, resolve_0):
        resolve_0(5)

    def complex_5(reject_0, resolve_0):
        reject_0(6)

    def complex_6(reject_0, resolve_0):
        resolve_0(7)


# Generated at 2022-06-26 00:08:59.329761
# Unit test for method bind of class Task
def test_Task_bind():
    complex_1 = None
    task_1 = Task(complex_1)
    complex_2 = None
    task_2 = Task(complex_2)
    expected_1 = task_2
    actual_1 = task_1.bind(complex_2)
    assert(actual_1 == expected_1)


# Generated at 2022-06-26 00:09:06.915061
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(1)
    task_1 = task_0.bind(lambda arg: Task.of(arg + 1))
    assert task_1.fork(lambda arg: -1, lambda arg: arg) == 2
    task_2 = task_1.bind(lambda arg: Task.of(arg + 1))
    assert task_2.fork(lambda arg: -1, lambda arg: arg) == 3
    task_3 = Task.of(2)
    task_4 = task_3.bind(lambda arg: Task.of(arg + 1))
    assert task_4.fork(lambda arg: -1, lambda arg: arg) == 3


# Generated at 2022-06-26 00:09:08.967393
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of("test").map(lambda value: value + " test")

# Generated at 2022-06-26 00:09:14.085971
# Unit test for method map of class Task
def test_Task_map():
    """
    Check that method map works as expected.
    """
    def cube(x):
        return x*x*x

    task = Task.of(3)
    new_task = task.map(cube)
    def check(_, resolve):
        assert resolve(27) == new_task.fork(lambda _: 'Hi', lambda arg: arg)
    check(None, None)
    print('test_Task_map - ok')


# Generated at 2022-06-26 00:09:32.897823
# Unit test for method map of class Task
def test_Task_map():
    def test_invalid_map_function():
        assert Task(None).map("not function") == None

    def test_invalid_type_of_Task_value():
        assert Task("not safe").map(lambda: None) == None

    def test_empty_Task_map_function():
        assert Task(None).map(None) == Task(None)


# Generated at 2022-06-26 00:09:37.352714
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(90).map(lambda x: x + 2) == Task.of(92)
    assert Task.of(90).bind(lambda x: Task.of(x + 2)) == Task.of(92)

    assert Task.of(80).bind(
        lambda x: Task.of(x + 2)
    ).map(
        lambda x: x + 2
    ) == Task.of(84)

# Generated at 2022-06-26 00:09:43.408287
# Unit test for method bind of class Task
def test_Task_bind():
    def identity(x):
        return x

    def step_0(value):
        return value

    def step_1(value):
        return Task.of(identity(value))

    task_0 = Task.of(None)
    task_1 = task_0.bind(step_0)
    task_2 = task_1.bind(step_1)

    assert task_2.fork(lambda x: x, lambda x: x) == None


# Generated at 2022-06-26 00:09:46.982723
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(5).map(lambda value: 6).fork(
        lambda reject: False,
        lambda resolve: resolve == 6
    )

    assert Task.reject(5).map(lambda value: 6).fork(
        lambda reject: reject == 5,
        lambda resolve: False
    )


# Generated at 2022-06-26 00:09:56.481091
# Unit test for method map of class Task
def test_Task_map():
    def task_map_0(reject, resolve):
        def task_map_0_reject(arg):
            return reject(arg)

        def task_map_0_resolve(arg):
            return resolve(arg)

        return ((task_map_0_resolve(1)), (task_map_0_reject(2)))

    complex_task_map_0 = task_map_0
    task_0 = Task(complex_task_map_0)
    def fn_0(value):
        return ((value) + (1))

    task_1 = task_0.map(fn_0)
    int_0 = ((task_1.fork)(lambda arg: arg, (lambda arg: arg)))
    assert int_0 == 2



# Generated at 2022-06-26 00:10:02.760767
# Unit test for method map of class Task
def test_Task_map():

    def map_0(value):
        return value * 2

    def map_1(value):
        return value / 2

    def map_2(value):
        return Task.reject(value)

    def map_3(value):
        return Task.of(value / 4)

    def test_0():
        # Test case for map after resolve
        task_0 = Task.of(10)
        result_0 = task_0.map(map_0)
        result_1 = result_0.fork(lambda reject: reject, lambda resolve: resolve)
        assert result_1 == 20

    def test_1():
        # Test case for map after reject
        task_0 = Task.reject(20)
        result_0 = task_0.map(map_0)

# Generated at 2022-06-26 00:10:08.983707
# Unit test for method bind of class Task
def test_Task_bind():
    id_ = lambda arg: arg

    # 1. Unit test for correct handling of calling callback of fork method
    assert Task.of(1).bind(id_).fork(lambda arg: arg, lambda arg: arg) == 1, "Unit test #1 failed"

    # 2. Unit test for correct chain of calls
    assert Task.of(1).bind(lambda arg: Task.of(arg + 1)).bind(lambda arg: Task.of(arg + 1)).fork(lambda arg: arg, lambda arg: arg) == 3, "Unit test #2 failed"



# Generated at 2022-06-26 00:10:19.099974
# Unit test for method map of class Task
def test_Task_map():
    def test_0(resolve, reject):
        resolve(1)

    def test_1(resolve, reject):
        resolve(2)
        reject(1)

    def test_2(resolve, reject):
        reject(2)
        resolve(1)

    # Test case 0
    task_0 = Task(test_0)
    mapped_task_0 = task_0.map(lambda value: value + 1)
    assert mapped_task_0.fork(lambda value: value * 2, lambda value: value / 2) == 1

    # Test case 1
    task_1 = Task(test_1)
    mapped_task_1 = task_1.map(lambda value: value + 1)
    assert mapped_task_1.fork(lambda value: value * 2, lambda value: value / 2) == 1

   

# Generated at 2022-06-26 00:10:22.908067
# Unit test for method bind of class Task
def test_Task_bind():
    complex_0 = (lambda r, s: s(4))
    task_0 = Task(complex_0)

    complex_1 = (lambda v: Task.of(v + 2))
    new_task = task_0.bind(complex_1)
    v = new_task.fork(None, None)
    print(v)




# Generated at 2022-06-26 00:10:32.947707
# Unit test for method map of class Task
def test_Task_map():
    mapper_fn = lambda value: value * 2
    value = 10

    # Test on valid Task with valid mapper function
    resolver = lambda reject, resolve: resolve(value)
    task = Task(resolver)
    actual = task.map(mapper_fn)
    expected = Task(lambda reject, resolve: resolve(mapper_fn(value)))
    assert actual == expected

    # Test on not valid Task with valid mapper function
    resolver = None
    task = Task(resolver)
    actual = task.map(mapper_fn)
    expected = Task(resolver)
    assert actual == expected

    # Test on valid Task with not valid mapper function
    resolver = lambda reject, resolve: resolve(value)
    task = Task(resolver)
    actual = task.map(None)

# Generated at 2022-06-26 00:10:55.278994
# Unit test for method bind of class Task
def test_Task_bind():
    double_value = lambda arg: arg * 2
    multiply_by_2 = lambda arg: Task.of(double_value(arg))
    mapper = lambda arg: Task.of(arg + '#')

    def test_0():
        task = Task.of(1)

        result = task.bind(multiply_by_2).bind(mapper).fork(lambda _: 'error', lambda arg: arg)

        assert result == '2#'

    def test_1():
        task = Task.reject(1)

        result = task.bind(multiply_by_2).bind(mapper).fork(lambda _: 'error', lambda arg: arg)

        assert result == 'error'



# Generated at 2022-06-26 00:11:04.799535
# Unit test for method bind of class Task
def test_Task_bind():
    # Case:
    #  Return new Task with result of called function.
    #  Function should be called with value.
    #  Function must return Task:
    #   Which resolve should be called with value.
    #   Which reject should not be called.
    #
    # Assert:
    #   Task should be resolved with value.

    result_value = "value"
    def test_mapper(value):
        assert value == result_value
        return Task.of("mapped_value")


# Generated at 2022-06-26 00:11:13.386628
# Unit test for method bind of class Task
def test_Task_bind():
    # unit test for case where fork function return value for resolve
    case_0 = Task(lambda reject, resolve: resolve(1))
    task_0 = case_0.bind(lambda i: Task.of(i))
    assert task_0 == Task(lambda reject, resolve: resolve(2))

    # unit test for case where fork function return value for reject
    case_1 = Task(lambda reject, resolve: reject(1))
    task_1 = case_1.bind(lambda i: Task.of(i))
    assert task_1 == Task(lambda reject, resolve: reject(1))

    # unit test for case where fork function return another Task
    nested_task = Task(lambda reject, resolve: resolve(100))
    case_2 = Task(lambda reject, resolve: resolve(nested_task))

# Generated at 2022-06-26 00:11:20.446437
# Unit test for method map of class Task
def test_Task_map():
    def test_case_1():
        # Task[int, int]
        value = 1
        fn_0 = (lambda x: x + 1)
        task_0 = Task.of(value)
        mapper = task_0.map(fn_0)
        assert mapper is not task_0
        assert mapper.fork(lambda x: x, lambda x: x * 2) == 4

    test_case_1()



# Generated at 2022-06-26 00:11:27.915239
# Unit test for method map of class Task
def test_Task_map():
    Task_0 = Task(lambda reject, resolve: resolve(2))
    Task_1 = Task_0.map(lambda x: x * 2)
    Task_1_expect = Task(lambda reject, resolve: resolve(4))

    Task_2 = Task(lambda reject, resolve: resolve(2))
    Task_3 = Task_2.map(lambda x: x * x)
    Task_3_expect = Task(lambda reject, resolve: resolve(4))

    Task_4 = Task(lambda reject, resolve: resolve(2))
    Task_5 = Task_4.map(lambda x: x ** 2)
    Task_5_expect = Task(lambda reject, resolve: resolve(4))

    Task_6 = Task(lambda reject, resolve: resolve(2))

# Generated at 2022-06-26 00:11:32.895175
# Unit test for method map of class Task
def test_Task_map():
    def test(test):
        def fn(value):
            return value + 1

        task = Task.of(1)
        task = task.map(fn)
        result = task.fork(
            lambda value: value,
            lambda value: value
        )

        expected = 2
        return test == expected

    assert test(test_Task_map())


# Generated at 2022-06-26 00:11:40.809710
# Unit test for method map of class Task
def test_Task_map():
    """
    Add 1 to number and return Task with result and not raise error.

    :returns: True, if pass | False, if error
    :rtype: bool
    """
    task_0 = Task.of(1)
    task_1 = task_0.map(lambda arg: arg + 1)
    task_2 = task_1.map(lambda arg: arg * 3)
    return task_2.fork(
        lambda error: False,
        lambda arg: arg == 9
    ), task_2.fork(
        lambda error: error,
        lambda arg: arg
    )


# Generated at 2022-06-26 00:11:44.657289
# Unit test for method bind of class Task
def test_Task_bind():
    complex_0 = None
    task_0 = Task(complex_0)
    task_1 = task_0.bind(complex_0)


# Generated at 2022-06-26 00:11:48.953311
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(3)

    def map_0(_, resolve):
        resolve(3)

    assert task_0.fork == map_0

    def map_1(_, resolve):
        resolve(6)

    result_0 = task_0.map(lambda x: x * 2)
    assert result_0.fork == map_1


# Generated at 2022-06-26 00:11:53.893754
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + " new value"

    task = Task(lambda _, resolve: resolve(5))
    task_mapped = task.map(mapper)
    assert task_mapped.fork(lambda _: _, lambda arg: arg) == "5 new value", "task_mapped.fork() != '5 new value'"


# Generated at 2022-06-26 00:12:39.563732
# Unit test for method bind of class Task
def test_Task_bind():
    def task_fn_0(arg):
        return Task.of(arg)

    # call method bind of class Task with Task.of, Task.of and Task.of
    # expect: Task(lambda: Task(lambda: Task.of(arg)))
    result_0 = Task.of(123).bind(lambda _: task_fn_0(456)).bind(lambda _: Task.of(789))

    # call method fork of Task
    # expect: 789
    assert result_0.fork(lambda err: err, lambda res: res) == 789



# Generated at 2022-06-26 00:12:50.240174
# Unit test for method bind of class Task
def test_Task_bind():
    # SUT bind
    def identity(value):
        return value

    def increment(value):
        return value + 1

    def decrement(value):
        return value - 1

    def multiply_2(value):
        return value * 2


    def to_Task(fn):
        def wrap(value):
            def fork(_, resolve):
                return resolve(fn(value))
            return Task(fork)
        return wrap

    task_0 = Task.of(0)

    assert task_0.bind(to_Task(identity)).fork(identity, identity) \
        == task_0.fork(identity, identity)

    assert task_0.bind(to_Task(increment)).fork(identity, identity) \
        == task_0.fork(identity, increment)

    assert task_0.bind

# Generated at 2022-06-26 00:12:57.651689
# Unit test for method map of class Task
def test_Task_map():

    def complex_0(reject, resolve):
        resolve(1)

    task_0 = Task(complex_0)
    mapped_task_0 = task_0.map(lambda value: value + 1)

    def complex_1(reject, resolve):
        reject(2)

    task_1 = Task(complex_1)
    mapped_task_1 = task_1.map(lambda value: value + 1)

    assert mapped_task_0.fork(lambda value: value, lambda value: value) == 2
    assert mapped_task_1.fork(lambda value: value, lambda value: value) == 2


# Generated at 2022-06-26 00:13:05.443867
# Unit test for method map of class Task
def test_Task_map():
    # Check types
    # Wrong type
    try:
        res_0 = Task.of('hello')
        res_0.map(0)
    except TypeError as e:
        assert str(e) == 'type(fn) must be a function'

    # Check Calls
    def mock_0(resolve, reject):
        resolve('world')

    def mock_1(value):
        return value + '!'

    def mock_2(reject, resolve):
        resolve(mock_1('world'))

    task_0 = Task(mock_0)
    try:
        res_0 = task_0.map(mock_1)
        res_1 = mock_2(None, None)
        assert res_0.fork(None, None) == res_1
    except e:
        assert False



# Generated at 2022-06-26 00:13:09.041749
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_0(value):
        return Task.of(value)

    task_0 = Task.of(1)
    print(task_0.bind(fn_0))



# Generated at 2022-06-26 00:13:16.421738
# Unit test for method bind of class Task
def test_Task_bind():
    def complex_0():
        return True

    def complex_1(value):
        return Task.of(value)

    def complex_2(value):
        return Task.reject(value)

    task_0 = Task.of(0)
    task_1 = task_0.bind(complex_0)
    task_2 = task_0.bind(complex_1)
    task_3 = task_0.bind(complex_2)
    task_1.fork(None, lambda value: complex_0())
    task_2.fork(None, lambda value: complex_0())
    task_3.fork(lambda value: complex_0(), None)

# Generated at 2022-06-26 00:13:19.918341
# Unit test for method bind of class Task
def test_Task_bind():
    def fork_0(reject, resolve):
        return None

    task_value_0 = Task(fork_0)

    def fn_0(value_0):
        return task_value_0

    task_0 = task_value_0.bind(fn_0)



# Generated at 2022-06-26 00:13:23.553302
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind
    """

    # Test: positive
    assert Task.of(1).bind(lambda val: Task.of(val + 2)).fork(
        lambda _: False,
        lambda val: val is 3
    )

    # Test: negative
    assert Task.reject(1).bind(
        lambda val: Task.of(val + 2)
    ).fork(
        lambda val: val is 1,
        lambda _: False
    )



# Generated at 2022-06-26 00:13:27.354657
# Unit test for method map of class Task
def test_Task_map():
    def mock_fork(reject, resolve):
        return resolve(42)

    def mock_map(value):
        return value + 1

    mock_task = Task(mock_fork)

    assert mock_task.map(mock_map).fork(None, lambda x: x) == 43


# Generated at 2022-06-26 00:13:31.139033
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x:Task.of(x + 1)).fork(lambda _: None, lambda x: x) == 2, 'Should be equals'
    assert Task.of(1).bind(lambda x:Task.of(x + 1)).bind(lambda x:Task.of(x + 1)).fork(lambda _: None, lambda x: x) == 3, 'Should be equals'


# Generated at 2022-06-26 00:15:17.287963
# Unit test for method bind of class Task
def test_Task_bind():
    def complex_0(reject, resolve):
        return resolve(10)

    task_0 = Task(complex_0)

    def test_complex_0(arg):
        if arg == 10:
            return Task.of(arg + 1)
        else:
            return Task.reject("fail")

    result = task_0.bind(test_complex_0)
    if result.fork(
            lambda arg: None,
            lambda arg: arg) != 11:
        raise Exception("Task.bind failed")


# Generated at 2022-06-26 00:15:24.732025
# Unit test for method map of class Task
def test_Task_map():
    # Case 1
    # input
    value_1 = 'value'
    mapper_1 = lambda x: x * x
    task_1 = Task.of(value_1)

    # action
    task_1 = task_1.map(mapper_1)

    # result
    try:
        result_1 = task_1.fork(lambda r: None, lambda r: r)
    except Exception as e:
        print('test_Task_map. Case 1. Error: ', e)

    # Case 2
    # input
    value_2 = 'value'
    task_2 = Task.of(value_2)

    # action
    task_2 = task_2.map(None)

    # result

# Generated at 2022-06-26 00:15:32.434229
# Unit test for method map of class Task
def test_Task_map():
    complex_0 = lambda x: x + 1
    task_0 = Task.of(1)

    task_1 = task_0.map(complex_0)
    task_1 = task_1.map(complex_0)

    task_0 = task_0.map(complex_0)
    task_0 = task_0.map(complex_0)

    task_0 = task_0.map(complex_0)

    task_2 = task_0.map((lambda arg: arg + 1))
    task_2 = task_2.map((lambda arg: arg + 1))

    task_0 = task_0.map(complex_0)
    task_0 = task_0.map(complex_0)
    task_0 = task_0.map(complex_0)

# Generated at 2022-06-26 00:15:38.623157
# Unit test for method map of class Task
def test_Task_map():
    actual_0 = Task.of(1).map(lambda x: x + 1)
    assert actual_0 == Task.of(2)

    actual_1 = Task.of(1).map(lambda x: x + 1).map(lambda x: x * 2)
    assert actual_1 == Task.of(4)

    actual_2 = Task.reject(1).map(lambda x: x + 1)
    assert actual_2 == Task.reject(1)

    actual_3 = Task.reject(1).map(lambda x: x + 1).map(lambda x: x * 2)
    assert actual_3 == Task.reject(1)

    print('Method map of Task is correct')


# Generated at 2022-06-26 00:15:41.176011
# Unit test for method bind of class Task
def test_Task_bind():
    def plus_one(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(plus_one).fork(print, print)

    try:
        assert task == 2
    except AssertionError:
        print("Failed test of Task_bind")


# Generated at 2022-06-26 00:15:44.828459
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(3)
    assert task.fork(lambda a: None, lambda a: None) == 3
    def test_function_0(value):
        assert value == 3
        return Task.of(value + 1)
    new_task = task.bind(test_function_0)
    assert new_task.fork(lambda a: None, lambda a: None) == 4