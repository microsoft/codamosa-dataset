

# Generated at 2022-06-26 00:05:55.897139
# Unit test for method map of class Task
def test_Task_map():
    """
    Method map of class Task
    """

    def function_0(arg):
        return arg + 1

    def function_1(arg):
        return arg - 1

    def function_2(arg):
        return arg * 2

    def function_3(arg):
        return arg / 2

    def tester_0(value):
        return Task.of(value).map(function_0)

    def tester_1(value):
        return Task.reject(value).map(function_1)

    def tester_2(value):
        return Task.of(value).map(function_2)

    def tester_3(value):
        return Task.reject(value).map(function_3)

    counter = 0


# Generated at 2022-06-26 00:06:01.971014
# Unit test for method map of class Task
def test_Task_map():
    str_0 = '\x13\x01\x0f\\K\x16\x14\x06\x0f\x18\x0f\x1f\n\x02\x11'
    task_0 = Task(str_0)
    res = task_0.map(
        lambda arg: arg + 1)
    assert res.fork == '\x14\x02\x10\\L\x17\x15\x07\x10\x19\x10\x20\x0b\x03\x12'



# Generated at 2022-06-26 00:06:05.608122
# Unit test for method map of class Task
def test_Task_map():
    def mock_fork(reject, resolve):
        resolve('4')

    task = Task(mock_fork)

    def mock_fn(value):
        return int(value) * 2

    result = task.map(mock_fn)
    assert result.fork(
        None,
        lambda value: value == 8
    )



# Generated at 2022-06-26 00:06:13.987454
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task(lambda a, b: a(b("asdasd")))

    def f1(a):
        return a + a

    def f2(a):
        return a + "asd"

    task_1 = task_0.map(f1)
    assert task_1.fork(lambda a: a, lambda b: b) == "asdasdasdasd"

    task_2 = task_0.map(f2)
    assert task_2.fork(lambda a: a, lambda b: b) == "asdasdasd"


# Generated at 2022-06-26 00:06:17.575268
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda arg: arg + 1) == Task.of(2)


# Generated at 2022-06-26 00:06:24.154070
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    task_0 = Task(str_0)
    str_1 = '\u0017\n\x1fU6\x13'
    task_1 = Task(task_0)
    str_2 = '\u001e\x03\x1b:!\x1a'
    task_2 = Task(str_1)
    str_3 = '\u0012\x1a\u0012\x14\x1f'
    task_3 = Task(str_2)
    str_4 = '\x1c\u0014\x11\x04\x0f'
    task_4 = Task(task_2)

# Generated at 2022-06-26 00:06:33.983790
# Unit test for method map of class Task
def test_Task_map():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    func_0 = [None]
    func_1 = [None]
    func_2 = [None]
    func_3 = [None]
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    str_1 = '~9j='
    str_2 = '3i4'
    str_3 = 'jqf1\x0b;wgx2vvxoK8.\\'
    str_4 = 'w0)^1=,!f$;|7gkd\t:n7'
    str_5 = '~9j='
    str_6 = '3i4'

    def func_4(arg_0):
        func

# Generated at 2022-06-26 00:06:36.453856
# Unit test for method bind of class Task
def test_Task_bind():
    Task.of(16).bind(lambda x: Task.of(x)).fork(
        lambda err: False,
        lambda res: res is 16
    )


# Generated at 2022-06-26 00:06:42.249295
# Unit test for method bind of class Task
def test_Task_bind():
    # Setup
    str_0 = '\n'
    task_0 = Task.of(str_0)
    task_1 = Task.of(task_0)
    task_2 = Task.of(task_1)
    task_3 = Task.of(task_2)
    task_4 = Task.of(task_3)
    task_5 = Task.of(task_4)
    task_6 = Task.of(task_5)
    task_7 = Task.of(task_6)
    task_8 = Task.of(task_7)
    task_9 = Task.of(task_8)
    task_10 = Task.of(task_9)
    task_11 = Task.of(task_10)
    task_12 = Task.of(task_11)
    task_

# Generated at 2022-06-26 00:06:47.112060
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'

    task_0 = Task(str_0)

    def method_0(arg_0):
        arg_0 = arg_0.replace('\x0b', '\n')
        return arg_0

    task_1 = task_0.map(method_0)


# Generated at 2022-06-26 00:06:51.048615
# Unit test for method map of class Task
def test_Task_map():
    test_case_0()


# Generated at 2022-06-26 00:06:53.395044
# Unit test for method bind of class Task
def test_Task_bind():
    actual = Task.of(1).bind(lambda x: Task.of(x + 1))
    assert actual == Task.of(2)


# Generated at 2022-06-26 00:07:03.460679
# Unit test for method map of class Task
def test_Task_map():
    def test_Task_map_0():
        class addAsyncTask(Task):
            def __init__(self, x, y):
                self.x = x
                self.y = y
                def fork(_, resolve):
                    def add(resolve, reject, x, y):
                        return resolve(x + y)
                    add(resolve, _, x, y)
                Task.__init__(self, fork)

        assert addAsyncTask(1, 1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 3

    def test_Task_map_1():
        class addAsyncTask(Task):
            def __init__(self, x, y):
                self.x = x
                self.y = y

# Generated at 2022-06-26 00:07:07.527077
# Unit test for method bind of class Task
def test_Task_bind():
    def test_body(value):
        return Task.of(value)

    result_1 = Task.of(1).bind(test_body)
    assert result_1.fork(lambda rejected: rejected, lambda resolved: resolved) == 1
    assert result_1.fork(lambda rejected: rejected + 1, lambda resolved: resolved + 1) == 2



# Generated at 2022-06-26 00:07:17.759787
# Unit test for method bind of class Task
def test_Task_bind():

    def test_case_0():
        str_0 = '0'
        def fn(x):
            return Task.of(x + str_0)

        task_0 = Task.of(str_0)
        task_1 = task_0.bind(fn)
        assert task_1.fork(lambda _: None, lambda x: x) == '00'

    def test_case_1():
        str_0 = '0'
        def fn(x):
            return Task.of(x + str_0)

        task_0 = Task.reject(str_0)
        task_1 = task_0.bind(fn)
        assert task_1.fork(lambda x: x, lambda _: None) == '0'

    def test_case_2():
        str_0 = '0'

# Generated at 2022-06-26 00:07:31.499574
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:07:32.672059
# Unit test for method map of class Task
def test_Task_map():
    test_case_0()



# Generated at 2022-06-26 00:07:40.267637
# Unit test for method bind of class Task
def test_Task_bind():
    subject_0 = Task.of(1)
    def mapper_0(n):
        return Task.of(n + 1)

    result_0 = subject_0.bind(mapper_0)
    assert result_0.fork(lambda reject: reject, lambda resolve: resolve) == 2

    subject_1 = Task.of(2)
    def mapper_1(n):
        return Task.reject(n + 1)

    result_1 = subject_1.bind(mapper_1)
    assert result_1.fork(lambda reject: reject, lambda resolve: resolve) == 3

    subject_2 = Task.reject(2)
    def mapper_2(n):
        return Task.of(n + 1)

    result_2 = subject_2.bind(mapper_2)
    assert result_2

# Generated at 2022-06-26 00:07:51.343849
# Unit test for method map of class Task
def test_Task_map():
    print('\n')
    print('Testing map method of class Task')
    print('')


# Generated at 2022-06-26 00:08:02.045061
# Unit test for method bind of class Task
def test_Task_bind():
    class Test(TestCase):
        def runTest(self):
            # Test 0
            # test_case_0
            task_0 = Task.of(1)
            task_0_result = task_0.bind(lambda x: Task.of(x+1))

            def result_0(reject, resolve):
                return task_0_result.fork(reject, resolve)

            self.assertEqual(result_0, 2)

    test = Test()
    test.runTest()
    print(test.id(), test.shortDescription())

test_Task_bind()


# Generated at 2022-06-26 00:08:12.797483
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda a: a + 10).fork(None, lambda x: x) == 11
    assert Task.of(1).map(lambda a: a + 10).fork(lambda x: x, None) == None
    assert Task.of(10).map(lambda a: a * a).fork(None, lambda x: x) == 100
    assert Task.of(10).map(lambda a: a * a).fork(lambda x: x, None) == None
    assert Task.of(1).map(lambda a: a ** a).fork(None, lambda x: x) == 1
    assert Task.of(1).map(lambda a: a ** a).fork(lambda x: x, None) == None

# Generated at 2022-06-26 00:08:17.207307
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of('abc')
    task_1 = task_0.bind(lambda value: Task.of('123'))
    assert task_1.fork.__closure__[0].cell_contents == '123'
    assert task_0.fork.__closure__[0].cell_contents == 'abc'



# Generated at 2022-06-26 00:08:26.316098
# Unit test for method map of class Task
def test_Task_map():

    # Unit test for method map of class Task when execution is fine
    def test_Task_map_0():
        def fn_0(value):
            return value + 1

        task_0 = Task.of(2)
        task_1 = task_0.map(fn_0)
        assert task_1.fork(lambda arg: raise_error(), lambda arg: arg) == 3

    # Unit test for method map of class Task when execution raise Exception
    def test_Task_map_1():
        def fn_0(value):
            raise Exception('Test Exception')

        def fn_1(value):
            return value + 1

        task_0 = Task.of(2)
        task_1 = task_0.map(fn_0)
        task_2 = task_0.map(fn_1)

        assert task_1

# Generated at 2022-06-26 00:08:31.970490
# Unit test for method bind of class Task
def test_Task_bind():
    # Create a Task of a random string
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    task_0 = Task(lambda _, resolve: resolve(str_0))

    # Use the method bind on the Task to check if the string length is odd
    task_1 = task_0.bind(lambda str_1: Task(lambda _, resolve: resolve(len(str_1) % 2)))

    # Use the method map on the Task to increment the previous result by 1 (unless the result is already 1, which
    # will not be incremented)
    task_2 = task_1.map(lambda number_0: number_0 + 1 if number_0 != 1 else number_0)

    # Fork the Task and save the result in a global variable
    global number_1
   

# Generated at 2022-06-26 00:08:42.050000
# Unit test for method map of class Task
def test_Task_map():

    # Case 0
    task_0 = Task.of(None)
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    mapped_task_0 = task_0.map(str_0)
    assert mapped_task_0.fork(None, None) is None

    # Case 1
    task_1 = Task.of(None)
    str_1 = 'jqf1\x0b;wgx2vvxoK8.\\'
    mapped_task_1 = task_1.map(str_1)
    assert mapped_task_1.fork(None, None) is None

    # Case 2
    task_2 = Task.of(None)
    int_2 = 3

# Generated at 2022-06-26 00:08:50.938752
# Unit test for method map of class Task
def test_Task_map():
    # test case 0
    # Test case method map
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    task_0 = Task(str_0)
    str_1 = 'ghjg'
    task_1 = task_0.map(str_1)
    assert task_1.fork(
        None,
        assertEqual(str_1)
    ) is None
    
    # test case 1
    # Test case method map
    fn_0 = print
    task_0 = Task(fn_0)
    str_1 = 'ghjg'
    task_1 = task_0.map(str_1)
    assert task_1.fork(
        None,
        assertEqual(str_1)
    ) is None
    


# Generated at 2022-06-26 00:09:01.554070
# Unit test for method map of class Task
def test_Task_map():
    class DummyTask:
        def __init__(self, fork):
            self.fork = fork

    class Stub:
        def __init__(self, result):
            self.result = result

        def __call__(self, *args, **kwargs):
            return self.result

    def test_Task_map_with_true_call_mapper():
        mapper = Stub(42)
        task = DummyTask(lambda _, resolve: resolve(42))
        result = task.map(mapper)

        mapper.assert_called_once_with(42)

    def test_Task_map_with_reject_call_reject():
        mapper = Stub(42)
        task = DummyTask(lambda reject, _: reject('Rejected'))
        result = task.map(mapper)

       

# Generated at 2022-06-26 00:09:04.813730
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(10)
    task = task.map(lambda value: value + 4)
    result = task.fork(lambda reject, value: value, lambda value: 0)
    if not result == 14:
        raise Exception("Task map failed")


# Generated at 2022-06-26 00:09:07.962688
# Unit test for method map of class Task
def test_Task_map():
    # Task.map()
    task_0 = Task.of(0)
    result_0 = task_0.map(lambda x: x + 1)
    assert result_0.fork(
        lambda arg: False,
        lambda arg: arg == 1
    )


# Generated at 2022-06-26 00:09:16.507172
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:09:24.678671
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2
    assert Task.reject(1).map(lambda x: x + 1).fork(lambda x: x, None) == 1



# Generated at 2022-06-26 00:09:34.029799
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    task_0 = Task(str_0)
    task_1 = task_0.map(lambda _0: ''.join(reversed(_0)))
    task_2 = task_1.map(lambda _0: str(len(_0)))
    task_3 = task_2.map(lambda _0: ''.join(reversed(_0)))
    task_4 = task_3.map(lambda _0: len(str(_0)) == len(str(_0)))
    task_5 = task_4.map(lambda _0: (lambda _1: _0[_0.index(_1) + 1])(_0[0]))

# Generated at 2022-06-26 00:09:43.315876
# Unit test for method bind of class Task
def test_Task_bind():
    global test_counter
    test_counter += 1
    success = True

    global str_0
    str_0 = "{8</\x7f~\x00+r\t\rLn\x7f\x1d'4\x0c/-"

    task_0 = Task(str_0)

    task_1 = task_0.bind(lambda arg_0: Task(arg_0))
    task_1.fork(lambda arg_1: (lambda arg_2: arg_2(arg_1))("assertEquals")("__assertion__"),
                lambda arg_1: "assertFalse")


# Generated at 2022-06-26 00:09:49.074566
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(lambda reject, resolve: None)
    task_1 = task_0.bind(lambda arg: Task.of(lambda reject, resolve: resolve(arg)))
    task_2 = task_1.bind(lambda arg: Task.reject(lambda reject, resolve: arg))
    assert task_2.fork(
        lambda arg: arg,
        lambda arg: None
    ) == task_2.fork(
        lambda arg: arg,
        lambda arg: None
    )


# Generated at 2022-06-26 00:09:58.226356
# Unit test for method bind of class Task
def test_Task_bind():
    # Test 1
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    task_0 = Task(str_0)
    task_1 = task_0.bind(lambda arg: Task(str_0))

    assert isinstance(task_0, Task) == True
    assert isinstance(task_1, Task) == True
    assert task_1 is not None
    assert task_1._Task__is_rejected == False
    assert task_1._Task__is_resolved == False

    # Test 2
    task_0 = Task.of(2.4)
    task_1 = task_0.bind(lambda arg: Task.of(-0.619))

    assert isinstance(task_0, Task) == True

# Generated at 2022-06-26 00:10:01.310788
# Unit test for method map of class Task
def test_Task_map():
    # Create a task and apply map
    task_0 = Task.of('Hello')
    task_1 = task_0.map(lambda s: s + ' World!')

    # Test the task_1
    assert task_1.fork(lambda err: 'Error', lambda res: res) == 'Hello World!'


# Generated at 2022-06-26 00:10:02.214355
# Unit test for method bind of class Task
def test_Task_bind():
    pass


# Generated at 2022-06-26 00:10:12.313539
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Fail test for Task.bind method.
    """
    def task_1(arg_1, arg_2):
        def task_1_1(arg_1_1, arg_2_1):
            def task_1_1_1(arg_1_1_1, arg_2_1_1):
                return arg_2_1_1(arg_1_1_1)

            return task_1_1_1

        return task_1_1(arg_1, arg_2)


# Generated at 2022-06-26 00:10:20.991055
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of class Task
    """
    # test case 0
    def function_0(arg):
        return arg
    resolved = Task.of('jqf1\x0b;wgx2vvxoK8.\\').map(function_0)
    assert_equals(resolved.fork(lambda reject: reject, lambda resolve: resolve), 'jqf1\x0b;wgx2vvxoK8.\\')
    # test case 1
    def function_1(arg):
        return arg
    def function_2(arg):
        return arg
    resolved = Task.of('f{Vu|gR|T7X')\
        .map(function_1).map(function_2)

# Generated at 2022-06-26 00:10:24.757705
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2
    assert Task.reject(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-26 00:10:39.896413
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(1)
    task_1 = task_0.bind(lambda x: Task.of(x + 1))
    assert task_1.fork(lambda x: 0, lambda x: x) == 2

    task_0 = Task.of(1)
    task_1 = task_0.bind(lambda x: Task.reject(x + 1))
    assert task_1.fork(lambda x: x, lambda x: 0) == 2

# Generated at 2022-06-26 00:10:45.265315
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    task_0 = Task(str_0)

    assert task_0.fork('ff') == Task.reject(str_0).fork('ff')
    assert task_0.fork('ff') != Task.of(str_0).fork('ff')
    assert Task.reject(str_0).fork('ff') != Task.of(str_0).fork('ff')
    assert task_0.fork('ff') == Task.reject(str_0).fork('ff')
    assert task_0.fork('ff') != Task.of(str_0).fork('ff')
    assert Task.reject(str_0).fork('ff') != Task.of(str_0).fork('ff')
    assert task

# Generated at 2022-06-26 00:10:50.392827
# Unit test for method bind of class Task
def test_Task_bind():
    def case_0():
        def method_0(value):
            method_0.value = value
            return Task.of(value)

        str_0 = '\x11\x1d\x1d\x0e'
        task_0 = Task.of(str_0)
        task_1 = task_0.bind(method_0)
        assert method_0.value == str_0


# Generated at 2022-06-26 00:10:54.003469
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda reject, resolve: resolve('value')).map(lambda value: value * 2) == 'valuevalue'


# Generated at 2022-06-26 00:11:03.026606
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.reject(0).bind(
        lambda value: Task.of(value + 1)
    ).fork(lambda value: 1, lambda value: value), 1

    assert Task.of(0).bind(
        lambda value: Task.reject(value + 1)
    ).fork(lambda value: value, lambda value: 1), 1

    assert Task.of(0).bind(
        lambda value: Task.of(value + 1)
    ).fork(lambda value: 1, lambda value: value), 1

    assert Task.reject(0).bind(
        lambda value: Task.reject(value + 1)
    ).fork(lambda value: value, lambda value: 1), 1


# Generated at 2022-06-26 00:11:11.509218
# Unit test for method bind of class Task
def test_Task_bind():
    # Step0
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    task_0 = Task(str_0)
    str_2 = '>m1\x0b\xe4\x0c\xcd\x08'
    task_1 = Task(str_2)
    def wrap_0(arg_0):
        return task_1
    str_3 = 'y1\x0bC\x0cB\x08'
    task_2 = Task(str_3)
    def wrap_1(arg_0):
        return task_2
    str_4 = '>u1\x0bO\x0c\xc8\x08'
    task_3 = Task(str_4)

# Generated at 2022-06-26 00:11:13.535505
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of('test value')

    task_1 = task_0.map(lambda arg: arg)

    assert 'test value' == task_1


# Generated at 2022-06-26 00:11:24.111598
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    task_0 = Task.of(str_0)
    str_1 = 'g2cB\\_v,#\\bx+r\x0c\x0e\\'
    task_1 = task_0.map(str_1)
    str_2 = '\x07+\\,\x0e\x0c\\0\x1c\x00,8\x18\x00\x00y\x1e-8\x0cg2cB\\_v,#\\bx+r\x0c\x0e\\'
    assert task_1.fork(None, None) == str_2


# Generated at 2022-06-26 00:11:32.174558
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    task_0 = Task.of(str_0)
    str_1 = 'o\x17\x1a=\x1b\x1cq\x03ehip\x0f\x07\x0e\x06g\x18b\x14\x07\x1a\x0e\x17\x1d'

# Generated at 2022-06-26 00:11:41.493572
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    str_1 = 'jqf1\x0b;wgx2vvxoK8.\\'


    def fn_0(str_0):
        return str_0

    task_0 = Task.of(str_0)
    task_1 = task_0.map(fn_0)

# Generated at 2022-06-26 00:12:12.522397
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'yj7\x1c\u0013e\x14k'
    str_1 = '$l7\x1c\u0013e\x14k'
    str_2 = '$l7\x1c\u0013e\x14k'
    int_0 = 4
    str_3 = '4l7\x1c\u0013e\x14k'
    task_0 = Task.of(str_0)
    task_1 = task_0.map(lambda str_3: str_3)
    task_2 = task_0.map(lambda str_3: str_1 + str_3)
    task_3 = task_0.map(lambda str_3: str_2 + str_3)

# Generated at 2022-06-26 00:12:21.869036
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    task_0 = Task.of(str_0)
    fn_0 = lambda x: len(x)
    task_1 = task_0.map(
        fn_0
    )

    def task_fork(reject, resolve):
        return task_1.fork(
            reject,
            resolve
        )

    task_2 = Task(task_fork)

    def task_fork_2(reject, resolve):
        return task_2.fork(
            reject,
            resolve
        )

    task_3 = Task(task_fork_2)

    def task_fork_3(reject, resolve):
        return task_3.fork(
            reject,
            resolve
        )

   

# Generated at 2022-06-26 00:12:26.654886
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(0)
    # Check that Task.bind calls Task.fork with arguments
    def test_fork(reject, resolve):
        assert reject(0) == 0
        assert resolve(0) == 0
    task_0.fork = test_fork
    task_0.bind(Task.of)


# Generated at 2022-06-26 00:12:31.046507
# Unit test for method bind of class Task
def test_Task_bind():
    result_0 = Task.of('value_0').bind(
        lambda arg: Task.of(arg.lower())
        ).bind(
        lambda arg: Task.of(arg.upper())
        ).map(
        lambda arg: Task.of(arg.capitalize())
        )
    assert (result_0.fork(lambda arg: arg, lambda arg: arg) == 'Value_0')


# Generated at 2022-06-26 00:12:35.992662
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test case for method bind of class Task
    """
    input_val = Task(lambda _, resolve: resolve(100))
    input_fn = lambda val: Task(lambda _, resolve: resolve(val+100))
    expected_output = input_fn(input_val.fork(None, None))
    assert input_val.bind(input_fn) == expected_output


# Generated at 2022-06-26 00:12:38.679622
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'Pv#p&|/;!g9=8jY@0]B'
    task_0 = Task(str_0)
    task_0.map(lambda a: a)


# Generated at 2022-06-26 00:12:49.313393
# Unit test for method bind of class Task
def test_Task_bind():
    byte_0 = b'\x12\x1c\x1c4\x15\x18\\\x0ce\x18\x17\x16\x1a\x1c'
    str_0 = str(byte_0, 'utf-8')
    def fn_0(value_0):
        return Task.of(value_0)

    task_0 = Task.of(str_0).bind(fn_0)
    str_1 = str(b'\x12\x1c\x1c4\x15\x1c\x0ce\x18\x17\x16\x1a\x1c', 'utf-8')
    assert task_0.fork(lambda arg: arg, lambda arg: arg) == str_1


# Generated at 2022-06-26 00:12:58.193833
# Unit test for method bind of class Task
def test_Task_bind():
    test_Task_bind_0()
    test_Task_bind_1()
    test_Task_bind_2()
    test_Task_bind_3()
    test_Task_bind_4()
    test_Task_bind_5()
    test_Task_bind_6()
    test_Task_bind_7()
    test_Task_bind_8()
    test_Task_bind_9()
    test_Task_bind_10()
    test_Task_bind_11()
    test_Task_bind_12()
    test_Task_bind_13()
    test_Task_bind_14()
    test_Task_bind_15()
    test_Task_bind_16()
    test_Task_bind_17()
    test_Task_bind_18()
    test_Task_bind_19()

# Generated at 2022-06-26 00:13:01.196310
# Unit test for method map of class Task
def test_Task_map():
    expected = Task(lambda _, resolve: resolve(2))

    def test_method_map(arg_0):
        return arg_0 + 1

    task = Task.of(1)
    result = task.map(test_method_map)

    assert result == expected


# Generated at 2022-06-26 00:13:05.578216
# Unit test for method map of class Task
def test_Task_map():
    def fn_0(value):
        return value

    def fn_1(value):
        return value

    task_0 = Task.of('fn_0')
    task_0.map(fn_0)

    task_1 = Task.of('fn_0').map(fn_1)

    task_2 = Task.reject('fn_1')
    task_2.map(fn_1)


# Generated at 2022-06-26 00:14:06.820795
# Unit test for method map of class Task
def test_Task_map():
    def test_0(arg_0):
        return arg_0
    def test_1(arg_0):
        return test_0(arg_0)
    def test_2(arg_0):
        return Task(arg_0)
    def test_3(arg_0, arg_1):
        return Task(arg_0)(arg_1)
    def test_4(arg_0):
        return Task(arg_0)
    def test_5(arg_0, arg_1):
        return Task(arg_0)(arg_1)
    def test_6(arg_0, arg_1):
        return Task(arg_0)(arg_1)
    def test_7(arg_0):
        return Task(arg_0)

# Generated at 2022-06-26 00:14:08.646212
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(0).map(lambda a: a + 1).fork(lambda a: a, lambda a: a) == 1


# Generated at 2022-06-26 00:14:16.293304
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task('z' + ';j~pmgh9X')
    assert_equals(task_0.map(''.join(['c', 'u', 't', 'e'])), task_0)
    task_1 = Task('best')
    task_1.map(lambda value: value + ' ' + 'cat')


# Generated at 2022-06-26 00:14:19.161084
# Unit test for method bind of class Task
def test_Task_bind():
    def add_1(x):
        return Task.of(x+1)

    assert Task(lambda r, h: h(1)).bind(add_1).fork(lambda e: e, lambda s: s) == 2

# Generated at 2022-06-26 00:14:28.354814
# Unit test for method bind of class Task
def test_Task_bind():
    str_in = 'jqf1\x0b;wgx2vvxoK8.\\'
    task = Task.of(str_in)
    result = task.bind(lambda arg: Task.of(arg))
    assert isinstance(result, Task)
    assert result.fork is not task.fork
    assert result.fork is not None
    str_out = result.fork(
        lambda error: None,
        lambda success: success
    )
    assert str_out == str_in


# Generated at 2022-06-26 00:14:36.009868
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(None)
    task_1 = task_0.bind(lambda _: Task.of(None))
    if task_1.fork is None:
        assert False
    elif task_1.fork(None, None) is not None:
        assert False

    str_0 = 'BQ]#<\x10XD>k'
    task_0 = Task.of(str_0)
    task_1 = task_0.bind(lambda str_0: Task.reject(str_0))
    if task_1.fork is None:
        assert False
    elif task_1.fork(lambda str_0: None, None) is not str_0:
        assert False


# Generated at 2022-06-26 00:14:41.847550
# Unit test for method bind of class Task
def test_Task_bind():

    def task(_, resolve):
        resolve('value')

    # Task[Function(_, resolve) -> str]
    task_0 = Task(task)

    # Task[Function(_, resolve) -> str]
    task_1 = task_0.map(lambda arg: arg + arg)

    # Task[Function(_, resolve) -> str]
    task_2 = task_0.map(lambda arg: arg + arg)

    # Task[Function(_, resolve) -> str]
    task_3 = task_1.bind(lambda arg: Task.of(arg.upper()))

    # Task[Function(_, resolve) -> str]
    task_4 = task_3.bind(lambda arg: Task.reject(arg.upper()))

    # Task[Function(_, resolve) -> str]
    task_5 = task_2.bind

# Generated at 2022-06-26 00:14:46.661700
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task(
        lambda _, resolve: resolve(5)
    )
    task_1 = task_0.map(
        lambda v0: v0 * 2
    )

    assert task_0.fork(lambda x0: x0, lambda x0: x0) == 5
    assert task_1.fork(lambda x0: x0, lambda x0: x0) == 10


# Generated at 2022-06-26 00:14:56.812501
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of('0')
    print(task_0.fork(lambda arg: arg, lambda arg: arg))
    task_1 = task_0.map(lambda arg: '1')
    print(task_1.fork(lambda arg: arg, lambda arg: arg))
    task_2 = task_1.map(lambda arg: '2')
    print(task_2.fork(lambda arg: arg, lambda arg: arg))
    task_3 = task_2.map(lambda arg: '3')
    print(task_3.fork(lambda arg: arg, lambda arg: arg))
    task_4 = task_3.map(lambda arg: '4')
    print(task_4.fork(lambda arg: arg, lambda arg: arg))

# Generated at 2022-06-26 00:15:00.008310
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'jqf1\x0b;wgx2vvxoK8.\\'
    task_0 = Task.of(str_0)
    task_1 = task_0.map(lambda value: value.__add__('\\'))
    print(task_1.fork(lambda reject_value: None, lambda resolve_value: resolve_value))
