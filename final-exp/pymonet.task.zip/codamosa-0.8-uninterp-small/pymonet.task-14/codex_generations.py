

# Generated at 2022-06-26 00:05:52.003034
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task.of(str_0)
    assert task_0.bind(lambda s: Task.of(s.upper())).fork(
        lambda error: None,
        lambda value: value == str_0.upper()
    )



# Generated at 2022-06-26 00:06:00.899811
# Unit test for method map of class Task
def test_Task_map():
    # Task[Function(_, resolve) -> A]
    task_of = Task.of(' Task.of ')
    # Task[Function(reject, _) -> A]
    task_reject = Task.reject(' Task.reject ')

    # Test for Task[Function(resolve, _) -> A]
    assert task_reject.map(lambda x: f' \t{x}  ') == task_reject

    # Test for Task[Function(_, resolve) -> A]
    task_empty = Task(lambda _, resolve: None)
    assert task_empty.map(lambda _: None) == task_empty
    assert task_empty.map(lambda x: f' \t{x}  ') == task_empty
    assert task_empty.map(lambda x: f'{x}  ')

# Generated at 2022-06-26 00:06:04.450293
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of('Hello').map(lambda value: value + ', world!')
    assert task.fork(
        lambda reason: False,
        lambda result: result == 'Hello, world!'
    )
    assert Task.of('Hello').map(lambda value: value + ', world!').fork(
        lambda reason: False,
        lambda result: result == 'Hello, world!'
    )


# Generated at 2022-06-26 00:06:12.892593
# Unit test for method map of class Task
def test_Task_map():
    str_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task.of(str_0)

    mapped_str_0 = task_0.map(str.strip)
    mapped_str_1 = mapped_str_0.map(str.lower)
    mapped_str_2 = mapped_str_1.map(str.title)
    result_0 = mapped_str_2.fork(
        lambda value: print('This is reject: {}'.format(value)),
        lambda value: print('This is resolve: {}'.format(value))
    )


# Generated at 2022-06-26 00:06:21.693065
# Unit test for method map of class Task
def test_Task_map():
    # Create 2 Task with stored 2 str, each consist of 3 letter
    task_a = Task.of('abc')
    task_b = Task.of('def')

    # Create new Task from mapping, Task are rejectable, so use reject in argument
    task_0 = Task(_, _).map(lambda arg: arg[0])
    task_1 = Task(_, _).map(lambda arg: arg[1])
    task_2 = Task(_, _).map(lambda arg: arg[2])

    assert task_0.fork('rejected', 'resolved') == 'abc'[0]
    assert task_1.fork('rejected', 'resolved') == 'abc'[1]
    assert task_2.fork('rejected', 'resolved') == 'abc'[2]

    # Assert that resolve and reject stay the same

# Generated at 2022-06-26 00:06:30.756288
# Unit test for method bind of class Task
def test_Task_bind():
    fun_0 = lambda _: Task.reject(True)
    fun_1 = lambda _: Task.reject(True)
    fun_2 = lambda _: Task.of(True)
    assert Task.of(None).bind(fun_0).fork(lambda _: True, lambda _: False)
    assert Task.reject(None).bind(fun_1).fork(lambda _: True, lambda _: False)
    assert Task.reject(None).bind(fun_2).fork(lambda _: True, lambda _: False)
    assert Task.of(None).bind(fun_2).fork(lambda _: False, lambda _: True)



# Generated at 2022-06-26 00:06:34.838410
# Unit test for method bind of class Task
def test_Task_bind():
    try:
        test_case_0()
        test_case_1()
        test_case_2()
        test_case_3()
        test_case_4()
        test_case_5()
    except AssertionError as error:
        print(error)



# Generated at 2022-06-26 00:06:44.847393
# Unit test for method map of class Task
def test_Task_map():
    length = len(test_case_0.__code__.co_code)

    def test_return_type(y): return type(y) is Task

    def test_arg_type(x): return type(x) is function

    def test_result_return_type(x): return type(x.fork('', ''))

    def test_result_arg_type(x):
        def resolve_type(x, y): return x

        return type(x.fork(resolve_type, ''))

    assert test_return_type(test_case_0().map(''))

    assert test_arg_type(list(filter(test_arg_type, dir(test_case_0().map(''))))[0])


# Generated at 2022-06-26 00:06:46.429247
# Unit test for method bind of class Task
def test_Task_bind():
    task_bind = Task.of(0).bind(lambda x: Task.of(x + 1))
    print(isinstance(task_bind, Task))


# Generated at 2022-06-26 00:06:51.907258
# Unit test for method map of class Task
def test_Task_map():
    str_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task(str_0)

    mapped_task_0 = task_0.map(lambda str_0: str_0 + ' ')

    assert mapped_task_0.fork('reject', 'resolve') == ' G0UVzBYD.-Fd\ts1C '


# Generated at 2022-06-26 00:07:04.587603
# Unit test for method bind of class Task
def test_Task_bind():
    # Test case 0
    test = Task.of(0)
    str_0 = 'expected 0, got {}'.format(test.fork(lambda _: 'reject', lambda res: res))
    assert test.fork(lambda _: 'reject', lambda res: res) == 0, str_0
    test = test.bind(lambda value: Task.of(value + 1))
    str_1 = 'expected 1, got {}'.format(test.fork(lambda _: 'reject', lambda res: res))
    assert test.fork(lambda _: 'reject', lambda res: res) == 1, str_1

    #Test case 1
    test = Task.of(1)
    str_2 = 'expected 1, got {}'.format(test.fork(lambda _: 'reject', lambda res: res))
    assert test.fork

# Generated at 2022-06-26 00:07:09.146368
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task(lambda _, resolve: resolve(True))
    func_0 = lambda value: Task.of(value)
    task_1 = task_0.bind(func_0)
    t_0 = task_1.fork(lambda value: False, lambda value: value)
    print(t_0)
    assert t_0

    str_0 = ''


# Generated at 2022-06-26 00:07:14.564949
# Unit test for method map of class Task
def test_Task_map():
    str_0 = ''
    # call class method
    # test map method
    str_0 = 'Call Task.of([1, 2, 3]).map(lambda x: 1 if x % 2 else x)'
    assert Task.of([1, 2, 3]).map(lambda x: 1 if x % 2 else x) == Task(lambda _0, _1: _1([1 if x % 2 else x for x in [1, 2, 3]])), \
    "Bad result for " + str_0
    str_0 = 'Call Task.of([1, 2, 3]).map(lambda x: 1 + x)'

# Generated at 2022-06-26 00:07:25.361339
# Unit test for method map of class Task
def test_Task_map():
    def expect_equal(expected, actual):
        expected_value, expected_type = expected
        actual_value, actual_type = actual

        assert expected_type is type(actual_value), 'Bad return type'
        assert expected_value == actual_value, 'Bad return value'

    def add(x):
        return x + 2

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def concat(x):
        return str(x) + '!'


# Generated at 2022-06-26 00:07:27.057122
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit tests for method bind of class Task
    """
    pass


# Generated at 2022-06-26 00:07:35.688248
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = ''
    str_9 = ''
    str_10 = ''
    str_11 = ''
    str_12 = ''
    str_13 = ''
    str_14 = ''
    str_15 = ''
    str_16 = ''
    str_17 = ''
    str_18 = ''
    str_19 = ''
    str_20 = ''
    str_21 = ''
    str_22 = ''
    str_23 = ''
    str_24 = ''
    str_25 = ''
    str_26 = ''
    str_27 = ''
    str_

# Generated at 2022-06-26 00:07:38.000836
# Unit test for method map of class Task
def test_Task_map():
    assert str(Task.of(1).map(lambda x: x + 1)) == str(Task.of(2))


# Generated at 2022-06-26 00:07:47.300572
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = ''

    # Test 1 - call bind method with function as argument and check result
    str_1 = '1'
    def test_1(value): return Task.of(value + str_0)
    assert Task.of(str_1).map(test_1).fork(lambda arg: arg, lambda arg: arg) == '1'
    str_0 = '0'
    assert Task.of(str_1).map(test_1).fork(lambda arg: arg, lambda arg: arg) == '10'

    # Test 2 - call bind method with Task as argument and check result
    str_1 = '1'
    str_2 = '2'

# Generated at 2022-06-26 00:07:51.912584
# Unit test for method map of class Task
def test_Task_map():
    str_0 = ''
    test_case_0()
    assert str_0 == '', 'Test case 0 failed'

if __name__ == '__main__':
    test_Task_map()

# Generated at 2022-06-26 00:07:56.650364
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = ''
    def on_reject(arg):
        str_0 = 'on_reject'

    def on_resolve(arg):
        str_0 = 'on_resolve'

    task = Task(lambda reject, resolve: resolve(1)).bind(lambda arg: Task.of(arg + 1))
    task.fork(on_reject, on_resolve)
    assert str_0 == 'on_resolve'


# Generated at 2022-06-26 00:08:05.971123
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper_0(arg):
        def reject(value):
            return Task.reject(' X nXE,NQ/UG ' + value)

        def resolve(value):
            return Task.of(' s8Kv_5' + value + '-L@ ')

        return Task(lambda reject_0, resolve_0: reject_0(arg)).map(lambda arg_0: arg_0 + arg).map(lambda arg_0: arg_0 + 'j').bind(lambda arg_0: resolve_0(arg_0 + arg))



# Generated at 2022-06-26 00:08:11.745734
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task(lambda _, resolve: resolve(0))
    check_function('Task', 'map', 0, task_0.map(lambda x: x + 1))
    task_1 = Task(lambda _, resolve: resolve(str_0))
    check_function('Task', 'map', 1, task_1.map(lambda x: x.upper()))
    check_function('Task', 'map', 2, task_1.map(lambda x: x[::-1]))


# Generated at 2022-06-26 00:08:21.645725
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(42).bind(lambda value: Task.of(value + 3)).fork(None, lambda value: value) is 42 + 3
    assert Task.reject(42).bind(lambda value: Task.of(value + 3)).fork(lambda value: value, None) is 42

    # Pronounced "task equals task"
    def task_equals(task):
        def task_eq(actual, expect):
            def result(reject, resolve):
                return task.fork(
                    lambda actual: reject(actual == expect),
                    lambda actual: resolve(actual == expect)
                )

            return Task(result)

        return task_eq

    task_eq = task_equals(Task.of(42))
    assert task_eq(Task.of(42)).fork(None, lambda value: value) is True

# Generated at 2022-06-26 00:08:24.901121
# Unit test for method map of class Task
def test_Task_map():
    task_1 = Task(lambda reject, resolve: resolve(7))
    task_2 = task_1.map(lambda arg: arg + arg)

    def func_2(reject, resolve):
        pass

    assert func_2 == task_2.fork


# Generated at 2022-06-26 00:08:29.181788
# Unit test for method map of class Task
def test_Task_map():
    # Task.of([1,2,3]).map(lambda x: x + 1).fork(lambda r: print("Rejected:", r), lambda r: print("Resolved:", r))
    assert Task.of([1,2,3]).map(lambda x: x + 1).fork(lambda r: print("Rejected:", r), lambda r: print("Resolved:", r)) == [2, 3, 4]


# Generated at 2022-06-26 00:08:33.355504
# Unit test for method map of class Task
def test_Task_map():
    # test 2 #
    str_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task(str_0)

    # test 1 #
    str_1 = 'NiG\tGu2jz'
    task_1 = Task.of(str_1)



# Generated at 2022-06-26 00:08:37.973785
# Unit test for method map of class Task
def test_Task_map():
    """
    Test case for method map of class Task.
    """

    def add(value):
        return value + 1

    assert Task.of(1).map(add).fork(None, lambda value: assertEqual(value, 2)) is None



# Generated at 2022-06-26 00:08:44.673748
# Unit test for method bind of class Task
def test_Task_bind():
    def case_0():
        def fn_0(value):
            def reject(res):
                return value + res

            def resolve(res):
                return 'not expected'

            return Task(lambda reject, resolve: resolve(value))

        def reject(value):
            return value

        def resolve(value):
            return value

        str_0 = ' G0UVzBYD.-Fd\ts1C'
        task_0 = Task(lambda reject, resolve: resolve(fn_0(str_0)))
        task_0.fork(reject, resolve)


# Generated at 2022-06-26 00:08:51.831738
# Unit test for method map of class Task
def test_Task_map():
    def first_map_fn(str_0):
        return str_0.lstrip()

    def second_map_fn(str_0):
        return str_0.rstrip()

    def third_map_fn(str_0):
        return str_0.upper()

    first_task = Task.of(first_map_fn)
    second_task = Task.of(second_map_fn)
    third_task = Task.of(third_map_fn)

    first_result = first_task.map(first_map_fn)
    second_result = first_result.map(second_map_fn)
    third_result = second_result.map(third_map_fn)



# Generated at 2022-06-26 00:09:02.571084
# Unit test for method bind of class Task
def test_Task_bind():
    def assert_on_bind(expected, task, fn):
        def on_resolve(value):
            assert value == expected, \
                f"value {value} is not equal {expected}"

        def on_reject(value):
            assert expected[0] == value[0], \
                f"should be reject {expected[0]} but reject {value[0]}"
            assert expected[1] == value[1], \
                f"should be reject {expected[1]} but reject {value[1]}"

        task.bind(fn).fork(on_reject, on_resolve)

    assert_on_bind(('reject', 'expected result'),
                   Task.reject('reject'),
                   lambda value: Task.reject('expected result'))


# Generated at 2022-06-26 00:09:15.272468
# Unit test for method map of class Task
def test_Task_map():
    def get_task_1():
        def function_0():
            return Task.of(function_1())

        def function_1():
            return ['g', 'z', '5', 'w', '3']

        return Task.of(function_0()).bind(function_1)

    def get_task_2():
        def function_0():
            return Task.of(function_1())

        def function_1():
            return ['G', 'Z', '5', 'W', '3']

        return Task.of(function_0()).bind(function_1)

    assert get_task_1().fork(None, None) == get_task_2().fork(None, None)

# Generated at 2022-06-26 00:09:18.114280
# Unit test for method map of class Task
def test_Task_map():
    string_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task.of(string_0)

    def mapper(string):
        return string.lower()

    expected = Task.of(string_0.lower())

    assert task_0.map(mapper).fork(
        lambda x: None,
        lambda x: x
    ) == (
        None,
        string_0.lower(),
    )

    assert task_0.map(mapper) == expected



# Generated at 2022-06-26 00:09:21.756176
# Unit test for method map of class Task
def test_Task_map():
    # init
    n = 100
    i = 5

    def fn(n):
        return n

    task_0 = Task(fn(n))

    # call
    task_1 = task_0.map(fn)

    # check
    assert task_0.fork == task_1.fork



# Generated at 2022-06-26 00:09:27.877141
# Unit test for method map of class Task
def test_Task_map():
    data = {
        "1": Task.of(1).map(lambda n: n + 2),
        "2": Task.of(2).map(lambda n: n + 3),
        "3": Task.of(3).map(lambda n: n + 4),
        "4": Task.of(4).map(lambda n: n + 3),
        "5": Task.of(5).map(lambda n: n + 2),
    }
    print(data["1"].fork(lambda n: n + 2, lambda n: n + 3))


# Generated at 2022-06-26 00:09:34.028689
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'zchhfR6Yg-jKARMOs3Z'
    task_0 = Task.of(str_0)
    def map_0(arg_0):
        int_0 = -27
        str_1 = 'Qdh1uV7xJ*WO.EHYfj+'
        task_1 = Task.of(str_1)
        return task_1

    task_0.bind(map_0)


# Generated at 2022-06-26 00:09:43.315420
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:09:51.989636
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task(lambda _, resolve: resolve(42))
    task_1 = task_0.map(lambda x: x + 1)
    task_2 = task_0.map(lambda x: x + 2)
    task_3 = task_0.map(lambda x: x + 3)
    task_4 = task_0.map(lambda x: x + 4)
    task_5 = task_0.map(lambda x: x + 5)
    task_6 = task_0.map(lambda x: x + 6)
    task_7 = task_0.map(lambda x: x + 7)
    task_8 = task_0.map(lambda x: x + 8)
    task_9 = task_0.map(lambda x: x + 9)

# Generated at 2022-06-26 00:10:00.626026
# Unit test for method map of class Task
def test_Task_map():
    import copy
    import random


# Generated at 2022-06-26 00:10:04.605383
# Unit test for method map of class Task
def test_Task_map():
    str_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task.of(str_0)
    str_1 = task_0.map(str.upper)
    assert str_1.fork(lambda _: None, print) == ' G0UVZBYD.-FDTXS1C'



# Generated at 2022-06-26 00:10:15.069723
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task.of(str_0)

    str_1 = ' G0UVzBYD.-Fd\ts1C'
    task_1 = Task.of(str_1)

    str_2 = ' G0UVzBYD.-Fd\ts1C'
    task_2 = Task.of(str_2)

    # Test 0
    task_3 = task_0.bind(
        lambda str_3: task_1.bind(lambda str_4: task_2)
    )
    assert str(type(task_3)) == "<class '__main__.Task'>"

# Generated at 2022-06-26 00:10:31.421995
# Unit test for method bind of class Task
def test_Task_bind():
    # Create new Task with bind
    task_0 = Task.of(10)
    task_0 = task_0.bind(lambda arg: Task.of(arg + 1))

    # Call fork and run mapper
    value, error = task_0.fork(lambda x: x, lambda x: x)

    # Assert value
    assert value == 11

    # Assert error is None
    assert error is None


# Generated at 2022-06-26 00:10:36.060044
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(0)
    task_1 = task_0.bind(lambda x: Task.of(x + 1))
    task_1
    # TASK{ [0, of(x + 1)] }
    task_1.fork(None, None)

#Unit test for method of of class Task

# Generated at 2022-06-26 00:10:43.159336
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = ' G0UVzBYD.-Fd\ts1C'
    str_1 = '\t\tQnMkd4/nq3X9h@'
    def fn_0(value):
        def result(reject, resolve):
            resolve(value+value)

        return Task(result)

    task_0 = Task(str_0)
    task_1 = task_0.bind(fn_0)
    def fn_1(value):
        def result(reject, resolve):
            resolve(reject(value))

        return Task(result)

    task_2 = task_0.map(fn_1)
    task_3 = Task.reject(str_0)



# Generated at 2022-06-26 00:10:47.016381
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(str(11))
    task_1 = task_0.map(lambda value: value * 2)
    assert task_1.fork(lambda err: None, lambda value: value == '1111')


# Generated at 2022-06-26 00:10:53.740191
# Unit test for method map of class Task
def test_Task_map():
    # Test case 0
    str_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task.of(str_0)
    fn_0 = lambda value: value.strip().upper()
    result_0 = task_0.map(fn_0)
    assert result_0.fork(
        lambda reject: 'rejected', lambda resolve: resolve
    ) == 'G0UVZBYD.-FDS1C'


# Generated at 2022-06-26 00:11:03.695765
# Unit test for method map of class Task
def test_Task_map():
    # Test 0
    str_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task.of(str_0)
    def fn_0(value):
        return value.replace('1', '2')

    task_1 = task_0.map(fn_0)

    # Test 1
    str_1 = ' G0UVzBYD.-Fd\ts1C'
    task_2 = Task.of(str_1)
    def fn_1(value):
        return value.replace('1', '2')

    task_3 = task_2.map(fn_1)

    # Test 2
    str_2 = ' G0UVzBYD.-Fd\ts1C'
    task_4 = Task.of(str_2)

# Generated at 2022-06-26 00:11:07.555574
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fnc_0(str_0):
        return Task(str_0)

    str_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task(str_0)
    task_1 = task_0.bind(test_fnc_0)


# Generated at 2022-06-26 00:11:17.223303
# Unit test for method bind of class Task
def test_Task_bind():
    def str_list_of_task(str_task):
        return str_task.bind(lambda str_0: Task.of(str_0.split()))

    def str_list_of_task_2(str_task):
        return str_task.map(lambda str_0: str_0.split())

    task_0 = Task.of(' G0UVzBYD.-Fd\ts1C')
    expected_0 = Task.of(['G0UVzBYD.-Fd', 's1C'])

    assert str_list_of_task(task_0) == expected_0
    assert str_list_of_task_2(task_0) == expected_0



# Generated at 2022-06-26 00:11:25.202380
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(0).map(lambda x: x + 1).fork(lambda x: str(x), lambda x: x) == '1'
    assert Task.of(0).map(lambda x: 'result is ' + str(x)).fork(lambda x: x, lambda x: x) == 'result is 0'
    assert Task.of(0).map(lambda x: x + 1).map(lambda x: 'result is ' + str(x)).fork(lambda x: x, lambda x: x) == 'result is 1'
    assert Task.of(0).map(lambda x: x + 1).map(lambda x: x + 1).fork(lambda x: str(x), lambda x: x) == '2'


# Generated at 2022-06-26 00:11:30.998619
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task.
    """

    task_0 = Task.of(1)
    def fn_0(arg_0):
        return arg_0 + 1
    task_1 = task_0.map(fn_0)
    try:
        assert task_1.fork(
            lambda arg_0: None,
            lambda arg_0: list(arg_0)[0]
        ) == 2
    except AssertionError:
        raise AssertionError


# Generated at 2022-06-26 00:11:56.522747
# Unit test for method map of class Task
def test_Task_map():
    testing_object = Task.of(42)
    result = testing_object.map(lambda value: value + 1)
    expected = Task.of(43)

    message = 'Task.map() fails with case value = 42'
    assert result == expected, message

    testing_object = Task.of(42)
    result = testing_object.map(lambda value: value + 2)
    expected = Task.of(44)

    message = 'Task.map() fails with case value = 42'
    assert result == expected, message



# Generated at 2022-06-26 00:12:07.655213
# Unit test for method map of class Task
def test_Task_map():

    def resolve_0(result_0):
        return result_0

    def reject_0(result_0):
        return result_0

    def fork_0(reject_0, resolve_0):
        return resolve_0(' G0UVzBYD.-Fd\ts1C')

    def fork_1(reject_1, resolve_1):
        return resolve_1('g0uvzbyd-fd\ts1c')

    task_0 = Task(fork_0)
    expect_0 = task_0.fork(reject_0, resolve_0)

    test_0 = task_0.fork(reject_0, resolve_0)
    assert  test_0 == expect_0

    def fn_0(value_0):
        return value_0.lower()

    task_1 = task_

# Generated at 2022-06-26 00:12:19.375844
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = '=ZW8Bv+o%}'
    task_0 = Task.reject(str_0)
    str_1 = 'P%;zn+<I'
    task_1 = Task.of(str_1)
    task_0.bind(task_1).fork(str_0, str_1)
    str_0 = 'U(I6U~rFE'
    task_0 = Task.of(str_0)
    str_1 = 'y_C2.PYE'
    task_1 = Task.of(str_1)
    task_0.bind(task_1).fork(str_0, str_1)


# Generated at 2022-06-26 00:12:28.688088
# Unit test for method map of class Task
def test_Task_map():
    def eq(a, b):
        return a == b

    def str_len(str_0):
        return len(str_0)

    def last_char(str_0):
        return str_0[-1:]

    str_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task.of(str_0)
    mapped_task_0 = task_0.map(str_len)
    assert mapped_task_0.fork(None, eq)(15)

    mapped_task_1 = task_0.map(last_char)
    assert mapped_task_1.fork(None, eq)('C')

    mapped_task_2 = task_0.map(lambda x: (x, x))

# Generated at 2022-06-26 00:12:30.509748
# Unit test for method map of class Task
def test_Task_map():
    """
    Method: map
    """
    for i in range(5):
        test_case_0()

test_Task_map()

# Generated at 2022-06-26 00:12:34.159773
# Unit test for method bind of class Task
def test_Task_bind():
    # unit test
    assert Task.of('Hello') \
        .bind(lambda value: Task.of('{} World'.format(value))) \
        .fork(lambda value: 'Err: {}'.format(value), lambda value: value) == 'Hello World'


# Generated at 2022-06-26 00:12:41.288246
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(5).bind(lambda arg: Task.of(arg)).fork(
        lambda rejected: print(rejected, ' rejected'),
        lambda resolved: print(resolved, ' resolved')
    )
    assert Task.reject(5).bind(lambda arg: Task.of(arg)).fork(
        lambda rejected: print(rejected, ' rejected'),
        lambda resolved: print(resolved, ' resolved')
    )
    assert Task.of('fds').bind(lambda arg: Task.reject(arg)).fork(
        lambda rejected: print(rejected, ' rejected'),
        lambda resolved: print(resolved, ' resolved')
    )

# Generated at 2022-06-26 00:12:46.079068
# Unit test for method map of class Task
def test_Task_map():
    def str_0(arg_0):
        return arg_0 + '01'

    str_1 = '"G0UVzBYD.-Fd\ts1C'
    task_0 = Task(str_1)
    task_1 = Task.of(str_1)
    task_2 = task_0.map(str_0)


# Generated at 2022-06-26 00:12:55.240233
# Unit test for method bind of class Task
def test_Task_bind():
    class Task_bind:
        def __init__(self):
            pass
        def run(self):
            self.test_case_0()
            self.test_case_1()
            self.test_case_2()
            self.test_case_3()
            self.test_case_4()
            self.test_case_5()
            self.test_case_6()
    def test_case_0():
        str_0 = 'G0UVzBYD.-Fd\ts1C'
        task_0 = Task(str_0)
        def fn_0(arg_0):
            return Task(arg_0)
        task_1 = task_0.bind(fn_0)
        task_2 = task_1.bind(fn_0)

# Generated at 2022-06-26 00:13:03.443272
# Unit test for method bind of class Task
def test_Task_bind():
    def assert_Task_bind(task, value):
        assert isinstance(task, Task)
        assert task.fork(lambda a: 'reject', lambda a: 'resolve') == 'resolve'

    task_0 = Task.of(1)
    assert_Task_bind(task_0.bind(lambda a: Task.of('a')), 'a')

    task_1 = Task.of('a')
    assert_Task_bind(task_1.bind(lambda a: Task.of('a')), 'a')

    task_2 = Task.of(1)
    assert_Task_bind(task_2.bind(lambda a: Task.reject(a)), 1)
    assert_Task_bind(task_2.bind(lambda a: Task.of(a)), 1)



# Generated at 2022-06-26 00:14:02.146872
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(37)
    task_1 = task_0.map(lambda int_0: chr(int_0))
    task_2 = task_1.fork(lambda str_0: False, lambda str_1: '%' == str_1)

# Generated at 2022-06-26 00:14:05.034407
# Unit test for method map of class Task
def test_Task_map():
    function = lambda arg: arg + ' -> new value'
    first = Task.of('test')
    second = first.map(function)
    assert second.fork(lambda reject: reject, lambda resolve: resolve) == 'test -> new value'


# Generated at 2022-06-26 00:14:09.255211
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'DvzgQ\t-0JT'
    task_0 = Task.of(str_0)

    task_1 = task_0.bind(lambda x: Task.of(x.lower()))

    assert task_1.fork(
        lambda err: str_0,
        lambda res: res
    ) == str_0.lower()



# Generated at 2022-06-26 00:14:20.780197
# Unit test for method map of class Task
def test_Task_map():
    # Unit tesest for function (map)
    def test_Task_map_0():
        fn_0 = (lambda arg_0: arg_0 + 1)
        task_0 = Task(fn_0)

    # Unit tesest for function (map)
    def test_Task_map_1():
        fn_0 = (lambda arg_1: arg_1 + 1)
        task_0 = Task(fn_0)

    # Unit tesest for function (map)
    def test_Task_map_2():
        fn_0 = (lambda arg_2: arg_2 + 1)
        task_0 = Task(fn_0)

    # Unit tesest for function (map)
    def test_Task_map_3():
        fn_0 = (lambda arg_3: arg_3 + 1)

# Generated at 2022-06-26 00:14:33.220098
# Unit test for method map of class Task
def test_Task_map():
    def function_0():
        value_0 = b'\xff\xfc\r\r\t\r\t\r\x0e\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        task_0 = Task.of(value_0)
        def function_0(arg_0):
            return len(arg_0)

        task_1 = task_0.map(function_0)
        len_0

# Generated at 2022-06-26 00:14:39.974748
# Unit test for method map of class Task
def test_Task_map():
    def plus_one(a: int) -> int:
        return a + 1

    def task_minus_one():
        return Task.of(-1)

    assert Task.of(0).map(plus_one).fork(lambda _: "reject", lambda val: val) == 1
    assert Task.reject(0).map(plus_one).fork(lambda _: "reject", lambda _: "resolve") == "reject"
    assert Task.of(0).map(plus_one).map(plus_one).fork(lambda _: "reject", lambda val: val) == 2
    assert Task.reject(0).map(plus_one).map(plus_one).fork(lambda _: "reject", lambda _: "resolve") == "reject"

# Generated at 2022-06-26 00:14:44.133169
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(2)
    task_1 = task_0.map(add(1))
    task_2 = task_1.fork.result

    assert task_2 == 3


# Generated at 2022-06-26 00:14:50.441206
# Unit test for method map of class Task
def test_Task_map():
    str_0 = ' G0UVzBYD.-Fd\ts1C'
    str_1 = '0UVzBYD.-Fd\ts1C'
    task_0 = Task.of(str_0)
    task_1 = task_0.map(lambda s: s.strip())
    assert task_1.fork(lambda e: e, lambda s: s) == str_1


# Generated at 2022-06-26 00:14:55.253611
# Unit test for method map of class Task
def test_Task_map():
    str_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task(lambda _, resolve: resolve(str_0))
    task_1 = task_0.map(lambda str_0: str_0.upper())
    fork_0 = task_1.fork(
        lambda arg: arg,
        lambda arg: arg
    )
    assert fork_0 == str_0.upper()



# Generated at 2022-06-26 00:15:00.714129
# Unit test for method map of class Task
def test_Task_map():
    str_0 = ' G0UVzBYD.-Fd\ts1C'
    task_0 = Task.of(str_0)

    def fn_0(arg):
        return arg.upper()
    task_1 = task_0.map(fn_0)

    str_1 = ' G0UVZBYD.-FDT\tS1C'
    def fn_1(reject, resolve):
        assert reject('E0N5OZ2') == 'E0N5OZ2'
        assert resolve(' G0UVZBYD.-FDT\tS1C') == str_1
    task_1.fork(fn_1)

