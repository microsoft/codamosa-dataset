

# Generated at 2022-06-26 00:05:49.180954
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(1)
    task_1 = task_0.map(lambda x: x + 2)
    assert task_1.fork(lambda x: 1, lambda x: x) == 3


# Generated at 2022-06-26 00:05:54.153559
# Unit test for method map of class Task
def test_Task_map():
    # noinspection PyTypeChecker
    try:
        Task.of(0).map(lambda _: '').fork(lambda _: {}, lambda _: '')
        Task.of(0).map(lambda _: 0).fork(lambda _: {}, lambda _: 0)
    except Exception:
        raise AssertionError('Task.map({}) is wrong'.format(0))



# Generated at 2022-06-26 00:06:02.765542
# Unit test for method map of class Task
def test_Task_map():
    def get_string_length(string):
        return len(string)

    def get_double(number):
        return number * 2

    def add_strings(string_1, string_2):
        return string_1 + string_2

    str_0 = 'P5x?~I{HjWZ]Yk(2'
    str_1 = ':}p6f+^d%xh>7%&'
    str_3 = '=%9A&.TbT*W4V8'

    # Test for Task with different callbacks
    # Test for Task with one callback
    # Test for Task with several callbacks
    task_0 = Task(str_0)
    task_1 = Task(str_1)
    task_2 = Task(str_3)

# Generated at 2022-06-26 00:06:11.207349
# Unit test for method map of class Task
def test_Task_map():
    def fn_0(arg_0):
        return arg_0
    task_0 = Task.of(int)
    str_0 = '\t'
    task_1 = task_0.map(fn_0)
    str_1 = '%cI\x1b'
    task_2 = Task.of(str_1)
    task_3 = task_2.map(fn_0)
    str_2 = '\x1b'
    byte_0 = 255
    task_4 = Task.of(str_1)
    def fn_1(arg_0):
        return task_4

    task_5 = task_2.bind(fn_1)


# Generated at 2022-06-26 00:06:21.021344
# Unit test for method bind of class Task
def test_Task_bind():
    # Case 0
    str_0 = 'e'
    task_0 = Task.of(str_0)
    list_0 = []
    task_1 = task_0.bind(lambda arg: Task.of(arg.upper()))
    task_1.fork(lambda arg: list_0.append(arg), lambda arg: list_0.append(arg))
    assert(list_0[0] == str_0.upper())
    # Case 1
    str_0 = 'i'
    task_0 = Task.of(str_0)
    list_0 = []
    task_1 = task_0.bind(lambda arg: Task.of(arg.upper()))
    task_1.fork(lambda arg: list_0.append(arg), lambda arg: list_0.append(arg))

# Generated at 2022-06-26 00:06:25.558588
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of('test')
    task = task.map(lambda val: val + ' value')
    assert task.fork(None, lambda val: val) == 'test value'


# Generated at 2022-06-26 00:06:29.153284
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda arg: arg * 2).fork(lambda _: None, lambda arg: arg) == 4
    assert Task.reject(2).map(lambda _: None).fork(lambda arg: arg, lambda _: None) == 2



# Generated at 2022-06-26 00:06:38.750593
# Unit test for method map of class Task
def test_Task_map():
    # Task.map(fn)
    def test_0(input, expected_result):
        actual_result = Task.of(input).map(lambda arg: arg)
        print(
            'input: ', input,
            '\nexpected result: ', expected_result,
            '\nactual result: ', actual_result,
        )
        assert (actual_result == expected_result)

    args = [
        (1, Task.of(1)),
        ('str', Task.of('str')),
        ('WTlkxDp{9XS/vHG~zW', Task.of('WTlkxDp{9XS/vHG~zW'))
    ]
    for arg in args:
        test_0(*arg)

    return True


# Generated at 2022-06-26 00:06:42.607968
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x * 2).fork(
        lambda value: 'Error: {0}'.format(value),
        lambda value: 'Ok: {0}'.format(value)
    ) == 'Ok: 2'

    def test_func(x):
        return x + 2

    assert Task.of(1).map(test_func).fork(
        lambda value: 'Error: {0}'.format(value),
        lambda value: 'Ok: {0}'.format(value)
    )  == 'Ok: 3'



# Generated at 2022-06-26 00:06:52.681997
# Unit test for method bind of class Task
def test_Task_bind():
    def run():
        task_0 = Task('U_i-}Z%@$2*GYNMl')

# Generated at 2022-06-26 00:06:56.444190
# Unit test for method map of class Task
def test_Task_map():
    pass


# Generated at 2022-06-26 00:07:01.553618
# Unit test for method map of class Task
def test_Task_map():
    # Create new Task
    task = Task.of(1)
    # Create map function
    fn = lambda x: x + 1

    # Create new Task with mapped function and check result
    assert task.map(fn).fork(
        lambda reject: 'rejected' if reject else 'ok',
        lambda resolve: resolve + 1
    ) == 2



# Generated at 2022-06-26 00:07:10.162128
# Unit test for method map of class Task
def test_Task_map():
    def invoke_map(str_0):
        str_1 = 'af1d96b63a62b2e85bd848d0d94c7b0a'
        str_2_list = []
        for str_3 in str_0:
            str_2_list.append(chr(ord(str_3) ^ 6))
        str_2 = ''.join(str_2_list)
        int_4 = 1
        task_0 = Task.of(str_2)
        def func_1(str_2):
            int_0 = ord(str_2[int_4])
            int_1 = ord(str_2[len(str_2) - int_4])
            int_2 = int_0 ^ int_1
            int_3 = int_2 ^ 5
            return ch

# Generated at 2022-06-26 00:07:18.861078
# Unit test for method bind of class Task
def test_Task_bind():
    """
    WIP: Use the task to do something that can be mapped from a task. Then bind it to another task
    """
    str_0 = 'U_i-}Z%@$2*GYNMl'
    task_0 = Task.of(str_0)
    task_1 = task_0.map(str.upper)
    # task_2 = task_1.map(str.replace)
    # task_2.bind(str.replace)
    # print(task_1.fork('err', 'success'))


# Generated at 2022-06-26 00:07:24.169451
# Unit test for method bind of class Task
def test_Task_bind():
    # Test case 0
    func_0 = lambda task: task.map(lambda i: i - 1)
    task_0 = Task.of(5)
    test_0_result = task_0.bind(func_0)

    assert test_0_result.fork(
        lambda arg: arg,
        lambda arg: arg) == 4, \
        'Task_bind test case 0'


# Generated at 2022-06-26 00:07:28.388867
# Unit test for method bind of class Task
def test_Task_bind():
    obj_0 = Task.of(1)
    def fn_0(x):
        obj_1 = Task.of(2)
        def fn_1(y):
            return x + y

        return obj_1.map(fn_1)


    obj_2 = obj_0.bind(fn_0)

# Generated at 2022-06-26 00:07:36.226451
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of("Hello")
    task_1 = Task.of("World")

    result_0 = task_0.map(lambda x: x + " ").map(lambda x: x + "World")
    result_1 = result_0.map(lambda x: x + "!")

    # assert 'result_2' is not equal to 'None'
    assert result_1 is not None

    def result_2(reject, resolve):
        task_0.fork(lambda arg: reject(arg), lambda arg: task_1.fork(lambda arg_0: reject(arg_0), lambda arg_0: resolve(arg + " " + arg_0)))

    # assert 'result_3' is not equal to 'result_2'
    assert result_1.fork is not result_2


# Generated at 2022-06-26 00:07:40.992171
# Unit test for method map of class Task
def test_Task_map():
    first_task = Task.of(2)
    test_1 = first_task.map(lambda value: value ** 2)
    test_2 = first_task.map(lambda value: value + 2)
    assert test_1.fork(None, lambda value: value) == 4
    assert test_2.fork(None, lambda value: value) == 4


# Generated at 2022-06-26 00:07:44.796367
# Unit test for method bind of class Task
def test_Task_bind():
    result = 0
    def mapper(val):
        """
        :param val: value to return in Task
        :type val: String
        :returns: new Task
        :rtype: Task
        """
        return Task(val)

    assert result is 0, 'Code have not been tested'


# Generated at 2022-06-26 00:07:54.195727
# Unit test for method bind of class Task
def test_Task_bind():
    max_len_str = 'Go4g0FaCFf0JE1Hp'
    str_task = Task.of(Task.of(max_len_str))
    max_len = 12
    msg_len = 'Too long text, max length is {}'
    def valid_length(text, max_len=12, msg=msg_len):
        if len(text) > max_len:
            return Task.reject(msg.format(max_len))
        return Task.of(text)

    str_task.bind(lambda text: text.bind(lambda text: valid_length(text, max_len=max_len)))


# Generated at 2022-06-26 00:08:06.302863
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test

    :param obj: Task[A]
    :type obj: data of type Task[A]
    :returns: True if test passed and False if failed
    :rtype: bool
    """
    str_0 = 'U_i-}Z%@$2*GYNMl'
    task_0 = Task(str_0)
    def mapper(obj):
        return obj * 2
    task_1 = task_0.map(mapper)
    if task_1 == str_0 * 2:
        return True
    else:
        return False


# Generated at 2022-06-26 00:08:13.570460
# Unit test for method map of class Task
def test_Task_map():
    def test_case_1():
        str_0 = 'e|4ij4-| c4x+4()^1R-#fY]6DgU_i-}Z%@$2*GYNMl'
        tuple_0 = ()
        list_0 = [1, 2, 3]
        str_1 = '{|'
        str_2 = '0B6w|'
        def str_3(arg_0, arg_1):
            return arg_0 + arg_1

        str_4 = 'G'
        str_5 = str_3(str_4, str_0)
        int_0 = 1
        def str_6(arg_0, arg_1):
            return arg_0 + arg_1

        str_7 = str_6(str_5, str_1)


# Generated at 2022-06-26 00:08:18.912308
# Unit test for method bind of class Task
def test_Task_bind():
    for _ in range(999):
        random_integer = random.randint(0, 100)
        task = Task.of(random_integer)

        def mapper(arg):
            def result(reject, resolve):
                return resolve(arg + 1)
            return Task(result)

        assert task.bind(mapper).fork(lambda _: None, lambda x: x) == random_integer + 1


# Generated at 2022-06-26 00:08:27.441450
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_1(value):
        return Task.of(int(value) + 1)

    def fn_2(value):
        return Task.of(int(value) + 2)
    str_0 = '3'
    task_1 = Task.of(str_0)
    task_2 = task_1.bind(fn_1).bind(fn_2)
    assert task_2.fork(None, lambda data: True) == 6

    def fn_1(_):
        return Task.reject(True)

    def fn_2(_):
        return Task.reject(True)

    str_0 = '3'
    task_1 = Task.of(str_0)
    task_2 = task_1.bind(fn_1).bind(fn_2)

# Generated at 2022-06-26 00:08:34.932306
# Unit test for method bind of class Task
def test_Task_bind():
    # Stub function to return Task with passed value
    def stub_fn(value):
        return Task.of(value)

    # Test case for correct value
    res_0 = Task.of(5).bind(stub_fn).fork(lambda reject: False, lambda resolve: resolve)
    assert res_0 is 5, 'Task.bind() produces incorrect result'

    # Test case for incorrect value
    res_1 = Task.of(5).bind(stub_fn).fork(lambda reject: True, lambda resolve: False)
    assert res_1 is False, 'Task.bind() produces incorrect result'


# Generated at 2022-06-26 00:08:44.418385
# Unit test for method map of class Task
def test_Task_map():
    def str_gen():
        return ''.join([chr(random.randint(0, 255)) for i in range(random.randint(0, 255))])

    str_0 = str_gen()
    task_0 = Task(str_0)
    task_1 = task_0.map(str.upper)
    assert task_0.fork(None, None) == str_0.upper()

    def add_len(value):
        return value + len(str_0)

    task_2 = task_1.map(add_len)
    assert task_2.fork(None, None) == str_0.upper() + len(str_0)

    def add_value(value):
        return value + str_0

    task_3 = task_2.map(add_value)
    assert task_

# Generated at 2022-06-26 00:08:49.911205
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_0():
        str_0 = 'U_i-}Z%@$2*GYNMl'
        task_0 = Task.of(str_0)
        def fn(str_1):
            return str_1 + str_1
        task_1 = task_0.bind(fn)
        task_2 = task_1.bind(fn)
        str_2 = task_2.fork(lambda rejected: None, lambda resolved: resolved)
    test_case_0()



# Generated at 2022-06-26 00:08:58.595428
# Unit test for method map of class Task
def test_Task_map():
    """
    Task -> map(fn: Function) -> Task

    Task t0 = Task.of('x');
    Task t1 = t0.map(function(value) { return value + 'y'; })

    assert(t1.fork(function(value) { return 'fail'; }, function(value) { return value; }) == 'xy' )

    Task t2 = Task.reject('x');
    Task t3 = t2.map(function(value) { return 'fail'; });

    assert(t3.fork(function(value) { return value; }, function(value) { return 'fail'; }) == 'x' )
    """
    pass



# Generated at 2022-06-26 00:09:03.209628
# Unit test for method map of class Task
def test_Task_map():
    def fn_0(arg):
        return arg
    task_0 = Task.of(fn_0)
    def fn_1(arg):
        return arg
    task_1 = Task.of(fn_1)
    assert task_0.map(fn_0) == task_0
    assert task_0.map(fn_1) == task_1


# Generated at 2022-06-26 00:09:04.454714
# Unit test for method bind of class Task
def test_Task_bind():
    def test_Task_bind_0(self):
        assert False

# Generated at 2022-06-26 00:09:22.676295
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 's+s,s-s.s/s=s'
    str_1 = 'S+S,S-S.S/S=S'
    str_2 = 'S+S,S-S.S/S=S'

    task_0 = Task.of(str_0)
    task_1 = task_0.map(str.upper)

    str_3 = None
    try:
        str_3 = task_1.fork(lambda arg: arg, lambda arg: arg)
    except TypeError:
        raise Exception('You can\'t fork task after map. Need to fork before.')

    if str_2 != str_3:
        raise Exception('Not a true mapping. Try again.')



# Generated at 2022-06-26 00:09:31.743826
# Unit test for method bind of class Task

# Generated at 2022-06-26 00:09:39.689006
# Unit test for method map of class Task
def test_Task_map():
    str_0 = '@*d!h{&'
    str_1 = 'd!@{&h*'
    def func_0(arg_0):
        list_0 = []
        for i in range(len(str_0)):
            list_0.append(str_0[i])
        list_0.sort()
        str_1 = ''
        for i in range(len(list_0)):
            str_1 += list_0[i]
        return str_1

    task_0 = Task.of(str_0)
    task_1 = task_0.map(func_0)
    assert task_1.fork(None, None) == str_1

# Generated at 2022-06-26 00:09:46.308473
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(15)
    task_1 = task_0.bind(lambda value: Task.of(value + 5))
    task_2 = task_1.bind(lambda value: Task.of(value * 2))
    assert task_2.fork(lambda value: 11, lambda value: value) == 36
    task_3 = task_0.bind(lambda value: Task.reject(value + 5))
    assert task_3.fork(lambda value: value, lambda value: 11) == 20


# Generated at 2022-06-26 00:09:53.530134
# Unit test for method bind of class Task
def test_Task_bind():
    task_1 = Task.of(15)
    def func_1(arg):
        return Task.of(arg + 5)

    task_2 = task_1.bind(func_1)
    task_3 = task_2.fork(lambda arg: 'FAIL', lambda arg: arg)
    assert task_3 == 20

    def func_2(arg):
        return Task.reject(arg + 5)

    task_4 = task_1.bind(func_2)
    task_5 = task_4.fork(lambda arg: arg, lambda arg: 'FAIL')
    assert task_5 == 20


# Generated at 2022-06-26 00:10:01.334480
# Unit test for method map of class Task
def test_Task_map():
    def square(x):
        return x * x

    task_0 = Task(lambda reject, resolve: resolve(2))
    task_0 = task_0.map(square)
    assert task_0.fork(lambda a: None, lambda b: b) == 4, 'fail map test #0'
    task_0 = Task(lambda reject, resolve: resolve(3))
    task_0 = task_0.map(square)
    assert task_0.fork(lambda a: None, lambda b: b) == 9, 'fail map test #1'
    task_0 = Task(lambda reject, resolve: resolve(5))
    task_0 = task_0.map(square)
    assert task_0.fork(lambda a: None, lambda b: b) == 25, 'fail map test #2'
    task_0 = Task

# Generated at 2022-06-26 00:10:07.194958
# Unit test for method map of class Task
def test_Task_map():
    def resolver(resolve):
        def cb(value):
            resolve(value)

        return cb

    def rejecter(reject):
        def cb(value):
            reject(value)

        return cb

    def fn(value):
        return value

    S = Task(
        lambda reject, resolve: resolve('$')
    )

    S.map(fn).fork(rejecter(test_Task_map), resolver(test_Task_map))


# Generated at 2022-06-26 00:10:09.066781
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2



# Generated at 2022-06-26 00:10:17.133541
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'U_i-}Z%@$2*GYNMl'
    task_0 = Task.of(str_0)
    str_1 = '.d;4<:7p{|/yx/h|>9'
    def fn_0(arg_0):
        str_2 = '4<:7p{|/yx/h|>9'
        return Task.of(str_2)
    task_1 = task_0.bind(fn_0)
    task_2 = task_0.bind(lambda _: Task.reject(str_1))


# Generated at 2022-06-26 00:10:22.118369
# Unit test for method map of class Task
def test_Task_map():

    # Task 0
    def fn_0(value):
        return '_'

    task_0 = Task.of(fn_0)

    result_0 = task_0.map(lambda n: n + n)

    # Task 1
    def fn_1(value):
        return 'fizz'

    task_1 = Task.of(fn_1)

    result_1 = task_1.map(lambda n: n + n)



# Generated at 2022-06-26 00:10:47.502668
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task(1)
    def fn_0(input_0):
        task_1 = Task(input_0)
        return task_1
    task_1 = task_0.bind(fn_0)

    def fn_1(input_0):
        task_2 = Task(input_0)
        return task_2
    task_2 = task_0.bind(fn_1)


# Generated at 2022-06-26 00:10:58.957176
# Unit test for method map of class Task
def test_Task_map():
    def fn_0():
        def fn_1():
            def fn_2():
                def fn_3():
                    def fn_4():
                        str_0 = 'Di*G"'
                        int_0 = -1349894040
                        str_1 = 'fb^M]XaA<'
                        float_0 = -14.5960
                        str_2 = 'P=uV7'
                        float_1 = -41.6488
                        str_3 = '"B|w1r#'
                        float_2 = -43.9377
                        str_4 = '^6.c]|x'
                        float_3 = -74.632
                        list_0 = [44, -35, -50, -42]
                        list_1 = []
                        int_1 = -71

# Generated at 2022-06-26 00:11:03.868909
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'fX4YzRP^$D'
    task_0 = Task.of(str_0)
    task_1 = task_0.bind(
        lambda str_1: Task.of(
            list(str_1)
        )
    )
    task_2 = task_0.bind(
        lambda str_1: Task.of(
            list(str_1)
        )
    )


# Generated at 2022-06-26 00:11:07.749393
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test of method bind of class Task
    """
    str_0 = 'U_i-}Z%@$2*GYNMl'
    assert Task.of(str_0).bind(lambda arg: arg + arg) == Task(lambda _, resolve: resolve(str_0 + str_0))



# Generated at 2022-06-26 00:11:18.384660
# Unit test for method map of class Task
def test_Task_map():
    def test_case(case):
        value = 'asd'
        check = 'def'

        str_0 = lambda reject, resolve: resolve(check)
        task_0 = Task(str_0)

        str_1 = lambda reject, resolve: resolve(value)
        task_1 = Task(str_1)
        res_1 = task_1.map(lambda arg: arg + arg)
        res_1 = res_1.map(lambda arg: arg.upper())
        task_2 = Task(str_0)
        res_2 = task_2.map(
            lambda arg: arg + arg).map(
                lambda arg: arg.upper()
        )

        str_3 = lambda reject, resolve: reject(check)
        task_3 = Task(str_3)

# Generated at 2022-06-26 00:11:20.205851
# Unit test for method map of class Task
def test_Task_map():
    assert(Task.of(3).map(lambda v: v * 2).fork(lambda _: None, lambda x: x)) == 6


# Generated at 2022-06-26 00:11:25.500524
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_0():
        str_0 = 'U_i-}Z%@$2*GYNMl'
        task_0 = Task.of(str_0)
        task_1 = task_0.bind(lambda value: Task.of(lambda: value))
        task_2 = task_1.map(lambda fn: fn())
        assert str_0 == task_2.fork(
            lambda _: None,
            lambda arg: arg
        )



# Generated at 2022-06-26 00:11:34.200468
# Unit test for method map of class Task
def test_Task_map():
    # test case 0 with value of type str
    def str_mapper(value):
        return value + value

    assert Task.of('U_i-}Z%@$2*GYNMl').map(str_mapper) == Task.of('U_i-}Z%@$2*GYNMlU_i-}Z%@$2*GYNMl')
    # test case 1 with value of type int
    def int_mapper(value):
        return value + value

    assert Task.of(2).map(int_mapper) == Task.of(4)
    # test case 2 with value of type str
    def str_mapper(value):
        return value + value


# Generated at 2022-06-26 00:11:38.631568
# Unit test for method map of class Task
def test_Task_map():
    """
    Method map test 1.
    """
    task_0 = Task.of(0)
    assert task_0.map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 1



# Generated at 2022-06-26 00:11:48.169787
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'U_i-}Z%@$2*GYNMl'
    task_0 = Task(str_0)

    def fn_0(arg_0):
        task_1 = Task.of(arg_0 + 'd5')
        return task_1

    task_2 = task_0.bind(fn_0)
    assert task_2.fork(lambda arg: 'Rejected',
                       lambda arg: 'Resolved') == 'Resolved'


# Generated at 2022-06-26 00:12:32.115144
# Unit test for method bind of class Task
def test_Task_bind():
    s = 'U_i-}Z%@$2*GYNMl'
    t = Task(lambda _, r: r(s))
    assert t.bind(lambda x: Task(lambda _, r: r(x[0]))).fork(lambda x: None, lambda x: x) == s[0]


# Generated at 2022-06-26 00:12:36.145197
# Unit test for method map of class Task
def test_Task_map():
    task_1 = Task(lambda reject, resolve: resolve(5))
    task_2 = task_1.map(lambda value: value * 2)

    assert task_2.fork(lambda _: 'Task was rejected', lambda value: value) == 10


# Test for show difference between bind and map from class Task

# Generated at 2022-06-26 00:12:41.311233
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task(lambda _, resolve: resolve(5))
    task_1 = lambda x: Task(lambda _, resolve: resolve(x + 7))

    assert task_0.bind(task_1).fork(
        lambda e: e,
        lambda v: v == 12
    )

    task_2 = Task(lambda reject, _: reject('foo'))
    task_3 = lambda x: Task(lambda reject, _: reject(x))

    assert task_2.bind(task_3).fork(
        lambda e: e == 'foo',
        lambda _: False
    )


# Generated at 2022-06-26 00:12:46.852906
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'D#G}n/1^N_:N]t'
    Task_0 = Task.of(str_0)
    str_1 = 'L-w@Rm'
    Task_1 = Task_0.map(str_1)
    Task_1_value = Task_1.fork(None, None)
    assert Task_1_value == str_1


# Generated at 2022-06-26 00:12:47.655467
# Unit test for method bind of class Task
def test_Task_bind():
    assert True


# Generated at 2022-06-26 00:12:49.348026
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-26 00:12:52.960548
# Unit test for method bind of class Task
def test_Task_bind():
    assert_that(Task.of('1').bind(
        lambda a: Task((lambda reject, resolve: resolve(a + '2'))))) \
        .is_equal_to(Task((lambda reject, resolve: resolve('12'))))



# Generated at 2022-06-26 00:12:55.940453
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + value

    t_0 = Task.of(5)
    t_1 = t_0.map(fn)

    assert t_1.fork(lambda x: x, lambda x: x) == 10



# Generated at 2022-06-26 00:12:58.054546
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of('Hello world!').map(str.upper)
    assert result.fork(lambda error: error, lambda value: value) == 'HELLO WORLD!'



# Generated at 2022-06-26 00:13:01.385525
# Unit test for method bind of class Task
def test_Task_bind():
    task_1 = Task.of(1)
    task_2 = task_1.bind(
        lambda arg: Task.of(arg + 1)
    )

    def fork_2(reject, resolve):
        return resolve(2)

    assert task_2.fork == fork_2


# Generated at 2022-06-26 00:14:42.168622
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'Sny5!n@]{X'
    task_0 = Task.reject('Sny5!n@]{X')

    def bind_2(arg):
        def f_0(reject, resolve):
            resolve('Lp|_5M5+Dy')
        return Task(f_0)

    task_1 = task_0.bind(bind_2)

    def f_0(reject, resolve):
        reject('Lp|_5M5+Dy')

    assert task_1.fork == f_0

# Generated at 2022-06-26 00:14:51.624384
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(2).bind(lambda x: Task.of(x + 2)).fork(lambda: 'error',
                                                          lambda: 'success') == 'success'
    assert Task.of(2).bind(lambda x: Task.of(x + 2)).fork(lambda: 'error', lambda: 'success') == 'success'
    assert Task.reject(2).bind(lambda x: Task.of(x + 2)).fork(lambda x: x + 2, lambda: 'success') == 4
    assert Task.reject(2).bind(lambda x: Task.of(x + 2)).fork(lambda x: x + 2, lambda: 'success') == 4



# Generated at 2022-06-26 00:14:58.987502
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of('U_i-}Z%@$2*GYNMl')
    def fn_i1(i1):
        return Task.of('6\'2U"iY`#`o;#pw')
    task_1 = task_0.bind(fn_i1)
    def fn_i2(i2):
        def fn_i3(i3):
            return Task.of('7VXfvb')
        return Task.of(fn_i3(i2))
    task_2 = task_1.bind(fn_i2)
    def fn_i4(i4):
        def fn_i5(i5):
            return Task.of('J&-]g')
        return Task.of(fn_i5(i4))

# Generated at 2022-06-26 00:15:01.661138
# Unit test for method bind of class Task
def test_Task_bind():
    def _f(arg):
        return Task.of(arg)

    str_0 = 'NaN'
    task_0 = Task.of(str_0)
    task_1 = Task.of(task_0)

    result = task_1.bind(lambda arg: _f(arg))

    assert result == task_0


# Generated at 2022-06-26 00:15:07.555980
# Unit test for method map of class Task
def test_Task_map():
    str_0 = 'U_i-}Z%@$2*GYNMl'
    task_0 = Task.of(str_0)
    task_1 = task_0.map(lambda arg_0: arg_0[::-1])

    result_0 = task_1.fork(lambda arg_0: arg_0, lambda arg_0: arg_0)
    result_1 = 'lMNyG*2$@%Z}-i_U'

    assert result_0 == result_1


# Generated at 2022-06-26 00:15:16.910767
# Unit test for method map of class Task
def test_Task_map():
    # with non-empty str_0
    str_0 = 'y(N"^t1}|3q'
    str_1 = 'y'
    task_0 = Task.of(str_0)
    task_1 = task_0.map(str.lower)
    assert task_1.fork(lambda arg: arg, lambda arg: arg + str_1) == (
        str_0 + str_1).lower()
    # with non-empty str_0
    str_0 = '~T_}X9x_EO1%B1/!@qC^'
    str_1 = 'bz_o;P&~{'
    task_0 = Task.of(str_0)
    task_1 = task_0.map(str.upper)

# Generated at 2022-06-26 00:15:21.636761
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'G{hR8p/|0aeEs!sC^'
    task_0 = Task.reject(str_0)
    def func_0(value):
        return Task.of(f'{value}{value}')
    
    task_1 = task_0.bind(func_0)

    # task_1.fork(print, print)
    assert task_1.fork(print, print) is None


# Generated at 2022-06-26 00:15:28.722811
# Unit test for method map of class Task
def test_Task_map():
    def test_mapper(x):
        return x * 2

    def test_reject(reject, resolve):
        reject(1)

    def test_resolve(reject, resolve):
        resolve(2)

    def test_reject_with_mapper(reject, resolve):
        map_task = Task(test_reject).map(test_mapper)
        map_task.fork(lambda arg: reject(arg), lambda arg: resolve(arg))

    def test_resolve_with_mapper(reject, resolve):
        map_task = Task(test_resolve).map(test_mapper)
        map_task.fork(lambda arg: reject(arg), lambda arg: resolve(arg))


# Generated at 2022-06-26 00:15:33.680466
# Unit test for method bind of class Task
def test_Task_bind():
    str_0 = 'U_i-}Z%@$2*GYNMl'
    task_0 = Task.of(str_0)
    task_1 = task_0.bind(lambda str_: Task.of(str_))
    result_0 = task_1.fork(lambda arg_0: arg_0, lambda arg_1: arg_1)
    assert result_0 == str_0



# Generated at 2022-06-26 00:15:40.260320
# Unit test for method bind of class Task
def test_Task_bind():
    print('test_Task_bind')
    def bind_mapper(arg):
        return Task.of(arg * 3)

    def identity(arg):
        return arg

    def reject_mapper(arg):
        return Task.reject(arg + '_rejected')

    # Task -> Task
    result = Task.of(0).bind(bind_mapper)
    assert result.fork(identity, identity) == 0

    # Task -> Task -> Task
    result = Task.of(0).bind(bind_mapper).bind(identity)
    assert result.fork(identity, identity) == 0

    # Task -> Task -> Task REJECT
    result = Task.of(0).bind(reject_mapper).bind(identity)
    assert result.fork(identity, identity) == '0_rejected'