

# Generated at 2022-06-26 00:05:52.905848
# Unit test for method bind of class Task
def test_Task_bind():
    # Test case number 0
    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    task_0 = Task.of(bytes_0)

    def fn_0(arg_0):
        def fn_1(arg_1):
            def fn_2(arg_2):
                def fn_3(arg_3):
                    def fn_4(_):
                        pass
                    return Task.of(fn_4(arg_3))
                return Task.of(fn_3(arg_2))
            return Task.of(fn_2(arg_1))
        return Task.of(fn_1(arg_0))

    task_0 = task_0.bind(fn_0)



# Generated at 2022-06-26 00:05:59.820763
# Unit test for method bind of class Task
def test_Task_bind():
    # Defining function that allow to test Task.bind
    def func(value):
        return Task.of(value)

    # Testing with Task.of
    task_0 = Task.of(1)
    task_1 = task_0.bind(func)
    assert task_1.fork(lambda _: 'error', lambda value: value == 1)

    # Testing with Task.reject
    task_2 = Task.reject(1)
    task_3 = task_2.bind(func)
    assert not task_3.fork(lambda value: value == 1, lambda _: 'error')



# Generated at 2022-06-26 00:06:07.653745
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task(lambda reject, resolve: resolve(1))
    task_1 = Task(lambda reject, resolve: resolve(2))
    task_2 = Task(lambda reject, resolve: resolve(3))
    task_3 = Task(lambda reject, resolve: reject(1))
    task_4 = Task(lambda reject, resolve: resolve(1))
    task_5 = Task(lambda reject, resolve: resolve(2))
    task_6 = Task(lambda reject, resolve: resolve(3))
    task_7 = Task(lambda reject, resolve: reject(1))
    task_8 = task_0.map(lambda arg_0: arg_0)
    task_9 = task_1.map(lambda arg_0: arg_0)
    task_10 = task_2.map(lambda arg_0: arg_0)


# Generated at 2022-06-26 00:06:18.430292
# Unit test for method bind of class Task
def test_Task_bind():
    res_0 = Task.of(b'\xf5\x9c\xe3\xcf=\xd7~')
    res_1 = res_0.bind(
        lambda arg_0: Task.of(b'\x01\x07\x08\x06\x01\x03' + arg_0[3:6] + b'\x08\x06\x02\x01'))
    res_2 = res_1.bind(lambda arg_1: Task.of(b'\x02' + arg_1[3:6]))

# Generated at 2022-06-26 00:06:25.509932
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xe4\xaf\xbc\xd9\xa7\xf6\xe4\x8b\xac\xa4\x93\xc4'
    str_0 = str(bytes_0)

    def fn_0(arg):
        return arg.decode('utf-8')

    task_0 = Task(fn_0)
    task_0 = task_0.map(fn_0)
    task_0 = task_0.map(lambda arg: arg)

    assert str(task_0) == str_0


# Generated at 2022-06-26 00:06:35.139536
# Unit test for method map of class Task
def test_Task_map():
    def fn_0(arg_0: str) -> str:
        return arg_0 + "foo"

    def fn_1(arg_0: int) -> str:
        return str(arg_0)

    def fn_2(arg_0: str) -> str:
        return arg_0 + "foo"

    def fn_3(arg_0: str) -> str:
        return arg_0 + "foo"

    def resolve_0(arg_0: int) -> Task[str]:
        return Task.of(fn_1(arg_0))
    def reject_0(arg_0: str) -> Task[str]:
        return Task.reject(arg_0)

    task_0 = Task(lambda reject, resolve: resolve(5))
    task_1 = task_0.map(fn_0)


# Generated at 2022-06-26 00:06:42.146216
# Unit test for method bind of class Task
def test_Task_bind():
    def test(fn, expected):
        def decorator(value):
            return Task.of(value).bind(fn)
        return decorator, expected

    cases = [
        test(lambda x: x * 2, 16),
        test(lambda x: Task.of(x + 1), 5),
        test(lambda x: Task.reject(x - 1), 1),
    ]

    for case in cases:
        decorator, expected = case
        assert decorator(8).fork(lambda x: x, lambda x: x) == expected



# Generated at 2022-06-26 00:06:51.228406
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Case of correct bind-method from class Task
    """
    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    task_0 = Task(bytes_0)
    task_1 = task_0.bind(lambda x: Task(x.decode('utf-8')))
    task_2 = task_1.bind(lambda x: Task(x.upper()))
    task_3 = task_2.bind(lambda x: Task(x.lower()))
    task_4 = task_3.map(lambda x: Task(x.encode('utf-8')))
    assert task_4.fork(lambda err: err, lambda res: res) == bytes_0


# Generated at 2022-06-26 00:06:58.148207
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(
        'http://example.com/?arg=val'
    ).bind(lambda arg: Task.of(arg
                               .replace('http://', 'https://')
                               .replace('arg=val', 'arg=other_val')
                               .replace('example.com', 'another_example.com'))
    ).fork(
        None,
        (lambda arg: arg)
    ) == 'https://another_example.com/?arg=other_val'


# Generated at 2022-06-26 00:07:02.513751
# Unit test for method map of class Task
def test_Task_map():
    """
    Method map transform value in resolved Task.
    """
    def mapper(x) -> int:
        return int(x)
    task_0 = Task.of(b'10')
    result = task_0.map(mapper)

    assert result.fork(lambda error: None, lambda value: value) == 10



# Generated at 2022-06-26 00:07:12.073479
# Unit test for method map of class Task
def test_Task_map():
    def noop(value):
        return value

    assert Task(lambda _, resolve: resolve(2)) \
        .map(noop) \
        .fork(lambda reject: reject, lambda resolve: resolve) == 2

    assert Task(lambda _, resolve: resolve(3)) \
        .map(lambda value: value * value) \
        .fork(lambda reject: reject, lambda resolve: resolve) == 9

    assert Task(lambda _, resolve: resolve(9)) \
        .map(lambda value: Task.of(value * value)) \
        .fork(lambda reject: reject, lambda resolve: resolve) \
        .fork(lambda reject: reject, lambda resolve: resolve) == 81


# Generated at 2022-06-26 00:07:23.746800
# Unit test for method map of class Task
def test_Task_map():
    # Test case 0
    print('test case 0')
    task_0 = Task.of(b'\xf5\x9c\xe3\xcf=\xd7~')
    task_0 = task_0.map(lambda _: test_case_0())
    task_0.fork(
        lambda arg: print(arg),
        lambda arg: print(arg)
    )
    # Test case 1
    print('test case 1')
    task_0 = Task.of(b'\xf5\x9c\xe3\xcf=\xd7~')
    task_0 = task_0.map(lambda _: test_case_0())
    task_0.fork(
        lambda arg: print(arg),
        lambda arg: print(arg)
    )


# Generated at 2022-06-26 00:07:27.693688
# Unit test for method map of class Task
def test_Task_map():
    for i in range(10):
        test_case_0()

if __name__ == "__main__":
    t = timeit.Timer("test_Task_map", setup="from __main__ import test_Task_map")
    print("Time for map ", t.timeit(number=5))

# Generated at 2022-06-26 00:07:32.851947
# Unit test for method map of class Task
def test_Task_map():
    @task
    def test(reject, resolve):
        resolve(b'\xf5\x9c\xe3\xcf=\xd7~')

    assert(
        test.map(hexlify)
            .fork(lambda reject: b'fail', lambda resolve: resolve)
        ==
        b'f59ce3cf3dd77e'
    )


# Generated at 2022-06-26 00:07:40.363932
# Unit test for method bind of class Task
def test_Task_bind():
    # Prepare input
    bytes_0 = b'\x8fZ\xf7\x1a\x19\x89\xb8\x9e\x04\x9e\xe8'
    # Error cases
    # (1)
    # Run method
    t = Task.of(bytes_0)
    t = t.bind(lambda x: Task.reject(0))
    # Assertion
    assert t.fork(lambda x: x, lambda x: x) == 0, 'Error in test case: test_Task_bind. Message: incorrect result'
    # (2)
    # Run method
    t = Task.reject(bytes_0)
    t = t.bind(lambda x: Task.reject(0))
    # Assertion

# Generated at 2022-06-26 00:07:44.597257
# Unit test for method map of class Task
def test_Task_map():
    """
    Task().map(fn) -> Task[fn(value)]
    """

    # Defining test method
    def fn(value):
        return value + 1

    # Defining Task and running test
    assert Task.of(1).map(fn).fork(lambda error: 'error', lambda success: success) == 2


# Generated at 2022-06-26 00:07:47.061258
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(bytes_0).bind(lambda x: Task.of(x))

    assert result == Task.of(bytes_0), 'Task.bind not work'


# Generated at 2022-06-26 00:07:57.319869
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\x96\x8e\xb5\x82\xbf\x98\x8cH\x82\xa3\x89\xab\x8b\xae\xcc\x9d\x9e\x8a\x9c\x89'
    bytes_1 = b'\xcf\x82\xa9\x8d\x96\xec\x89\xad\x8c\xad\x8a\x9e\x99\xec\x96\x84\x89'

# Generated at 2022-06-26 00:08:06.912267
# Unit test for method bind of class Task
def test_Task_bind():
    def task_of():
        return Task.of(1)

    def task_reject():
        return Task.reject(2)

    def inc(a):
        return a + 1

    def double(a):
        return Task.of(a * 2)

    def inc_and_double(a):
        return Task.of(a + 1).bind(double)

    def double_and_inc(a):
        return Task.of(a * 2).bind(inc)

    def task_of_bind_task_of():
        return Task.of(1).bind(inc_and_double)

    def task_of_bind_task_reject():
        return Task.of(1).bind(task_reject)


# Generated at 2022-06-26 00:08:12.748497
# Unit test for method map of class Task
def test_Task_map():
    # Test case 0
    result_0 = Task.of(b'\xf5\x9c\xe3\xcf=\xd7~').map(base64.b64encode)
    assert result_0.fork(lambda _: None, lambda value: test_case_0()) == None

    # Test case 2
    result_2 = Task.reject(Exception('test_Task_map+test_case_2')).map(lambda arg: arg)

# Generated at 2022-06-26 00:08:24.692122
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\x04\xf5\x9c\xe3\xcf=\xd7~\x9e\x7f\xcc\xc8\xca'
    bytes_1 = b'\xec"\x9c\x9c\x98\xdf\xc8'
    bytes_2 = b'\xae\x8e\xb4\xcf\xd3 \x10\x1b'
    bytes_3 = b'\xf5\x9c\xe3\xcf=\xd7~'
    bytes_4 = b'\x04\xf5\x9c\xe3\xcf=\xd7~\x9e\x7f\xcc\xc8\xca'

# Generated at 2022-06-26 00:08:31.230671
# Unit test for method map of class Task
def test_Task_map():
    def bytes_to_int(bytes_):
        return int.from_bytes(bytes_, byteorder='big')

    def int_to_bytes(int_):
        return int_.to_bytes(int_.bit_length() // 8 or 1, byteorder='big')

    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    task_0 = Task.of(bytes_0)

    task_1 = task_0.map(bytes_to_int)

    task_2 = task_1.map(int_to_bytes)

    def is_eql(bytes_0, bytes_1):
        return bytes_0 == bytes_1

    assert is_eql(bytes_0, task_2.fork(id, id))



# Generated at 2022-06-26 00:08:41.302971
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Case 1:
        Init Task with value = 'value' and mapper
        create new Task with value = 'mapped_value'
        Test function bind with both Tasks,
        Test result with fork function of result Task
    Case 2:
        Init Task with reject = 'reject' and mapper
        create new Task with reject = 'mapped_reject'
        Test function bind with both Tasks,
        Test result with fork function of result Task
    """
    # Case 1
    # Init resolved Task with value = 'value'
    task_1 = Task(lambda _, resolve: resolve('value'))
    # Init resolved Task with value = 'mapped_value'
    task_mapper_1 = Task(lambda _, resolve: resolve('mapped_value'))
    # Test function bind with both Tasks,
    result

# Generated at 2022-06-26 00:08:44.337805
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task.of(1).map(fn)
    assert task.fork(lambda a: None, lambda a: a) == 2


# Generated at 2022-06-26 00:08:49.225701
# Unit test for method bind of class Task
def test_Task_bind():
    def task0_fork(reject, resolve):
        return reject(2)

    def task1_fork(reject, resolve):
        return resolve(3)

    task0 = Task(task0_fork)
    task1 = Task(task1_fork)
    task2 = task0.bind(lambda arg: task1)

    task2.fork(
        lambda reject: reject,
        lambda resolve: resolve
    )



# Generated at 2022-06-26 00:08:52.011853
# Unit test for method map of class Task
def test_Task_map():
    def fn_0(value):
        return value.decode()

    bytes_0 = b'foo'
    task_0 = Task.of(bytes_0)

    task_1 = task_0.map(fn_0)
    task_1.fork(print, print)


# Generated at 2022-06-26 00:09:02.818102
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map for Task
    """
    def test_case_1():
        task_0 = Task.of(0)
        task_1 = task_0.map(lambda x: x + 1)
        result = task_1.fork(lambda x: b'false', lambda x: b'true')
        assert result == b'true'

    def test_case_2():
        task_0 = Task.of(0)
        task_1 = task_0.map(lambda x: x + 2)
        result = task_1.fork(lambda x: b'false', lambda x: b'true')
        assert result == b'true'

    def test_case_3():
        task_0 = Task.of(1)
        task_1 = task_0.map(lambda x: x - 1)
       

# Generated at 2022-06-26 00:09:05.056823
# Unit test for method map of class Task
def test_Task_map():
    value = Task.of(1).map(lambda x: x + 1)
    expected = Task.of(2)
    assert value == expected


# Generated at 2022-06-26 00:09:12.999803
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    bytes_1 = Test.f(bytes_0)
    bytes_2 = Test1.f(bytes_1)
    bytes_3 = Test2.f(bytes_2)
    task_0 = Task.of(bytes_0)
    task_1 = task_0.bind(Test.f)
    task_2 = task_1.bind(Test1.f)
    task_3 = task_2.bind(Test2.f)
    result = task_3.fork(
        lambda value: b'fail',
        lambda value: value
        )
    check(bytes_3, result)


# Generated at 2022-06-26 00:09:21.639154
# Unit test for method map of class Task
def test_Task_map():
    # Test case 0
    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    task_0 = Task.of(bytes_0)
    def fn_0(value_0):
        def fn_0(value_1):
            return value_1 * 2
        value_0 = map(fn_0, value_0)
        return value_0
    task_1 = task_0.map(fn_0)
    assert task_1.fork(None, None) == b'\xf5\x9c\xe3\xcf=\xd7~\xf5\x9c\xe3\xcf=\xd7~'

    # Test case 1

# Generated at 2022-06-26 00:09:29.926407
# Unit test for method bind of class Task
def test_Task_bind():
    tester = Task.of(None)
    result = tester.bind(lambda _: Task.of(1)).fork(
        lambda reject: None,
        lambda resolve: resolve
    )
    assert result == 1



# Generated at 2022-06-26 00:09:34.226574
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    task_0 = Task(bytes_0)
    def func_0(arg):
        return Task(lambda reject, resolve: resolve(bytes_0))
    task_1 = task_0.bind(func_0)


# Generated at 2022-06-26 00:09:37.675038
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = '\xf1\x9c\xab\xcf=\xd7~'
    assert Task(bytes_0).bind("convert_bytes_to_unicode").bind("join_strings") == 'ű\x9c«Ï=×~'


# Generated at 2022-06-26 00:09:40.796454
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.reject(Exception())
    task_1 = task_0.bind(lambda _: 'task_0 was rejected')
    (task_1.fork(
        lambda _: pytest.fail('mapper was not called'),
        lambda _: pytest.fail('mapper was not called')))
    task_2 = Task.of(Exception()).bind(lambda x: Task.of(x))
    (task_2.fork(
        lambda _: pytest.fail('mapper was not called'),
        lambda _: pytest.fail('mapper was not called')))
    return (task_1, task_2)

(task_1, task_2) = test_Task_bind()



# Generated at 2022-06-26 00:09:50.216604
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task map function

    :returns: Nothing
    """
    def add_10(x):
        return x + 10

    def sub_10(x):
        return x - 10

    def throw_exception():
        raise Exception()

    def return_empty_task():
        return Task.of(0)


# Generated at 2022-06-26 00:09:55.955077
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    task_0 = Task(bytes_0)
    def fn(value):
        return value.decode('utf-8').upper()

    result = Task.of(bytes_0).map(fn)
    # assert result.fork(lambda err: None, lambda val: val) == 'ЪЭУЯ=Хч'

# Generated at 2022-06-26 00:10:02.501818
# Unit test for method bind of class Task
def test_Task_bind():
    def get_xml_body(url):
        def fork(reject, resolve):
            res = requests.get(url, timeout=5)
            if res.status_code != 200:
                return reject({
                    message: res.text
                })
            return resolve(res.text)
        return Task(fork)

    def parse_html(text):
        return Task(lambda _, resolve: resolve(bs(text, 'html.parser')))

    def get_title(task):
        task.bind(parse_html)
        return task.map(lambda text: text.title)

    def log(title):
        return Task(lambda _, resolve: resolve(logging.info(title)))

    url = 'http://www.google.com'

    get_title(get_xml_body(url)).bind(log)

# Generated at 2022-06-26 00:10:11.515846
# Unit test for method bind of class Task
def test_Task_bind():
    def test_data():
        yield (1, 2, 3)
        yield (1, )
        yield (1, 2)
        yield (1, 2, 3, 4)
        yield (1, 2, 3, 4, 5)
        yield tuple()

    for data in test_data():
        task = Task.of(data)
        assert task.fork is None
        result = task.bind(lambda value: Task.reject(tuple(map(operator.mul, value, value))))
        # result: Task[reject, mapped_value]
        assert result.fork(lambda v: v, lambda v: v) == tuple(map(operator.mul, data, data))



# Generated at 2022-06-26 00:10:17.808060
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    task_0 = Task.of(bytes_0)

    task_1 = task_0.map(lambda _: b'\xac\x9c\xe3\xcf=\xd7~')
    assert task_0.fork(lambda _: None, lambda x: x) == bytes_0
    assert task_1.fork(lambda _: None, lambda x: x) == bytes_0



# Generated at 2022-06-26 00:10:20.616730
# Unit test for method map of class Task

# Generated at 2022-06-26 00:10:34.458669
# Unit test for method bind of class Task
def test_Task_bind():
    result_Task = Task.of('value').bind(lambda arg: Task.of(arg))

    assert result_Task.fork is not None
    ok, result = result_Task.fork(lambda error: (False, error), lambda value: (True, value))
    assert ok
    assert result == 'value'



# Generated at 2022-06-26 00:10:42.682005
# Unit test for method map of class Task
def test_Task_map():

    # Test 0: value = None
    # Expected: AttributeError

    task_0 = Task.of(None)
    exception_0 = None
    try:
        task_0.map(None)
    except AttributeError as err:
        exception_0 = err
    assert exception_0

    # Test 1: value = [], fn = {}, reject = [], resolve = []
    # Expected: reject = [], resolve = []

    fn_1 = dict()
    resolve_1 = []
    reject_1 = []
    task_1 = Task.of([])
    exception_1 = None
    try:
        task_1.map(fn_1)
    except AttributeError as err:
        exception_1 = err
    assert exception_1

# Generated at 2022-06-26 00:10:43.542083
# Unit test for method map of class Task
def test_Task_map():
    # TODO fix this test
    pass

# Generated at 2022-06-26 00:10:48.060928
# Unit test for method bind of class Task
def test_Task_bind():
    # Testing of Task.bind in simple case
    Task.of(1).bind(lambda x: Task.of(x + 1)).map(print)

    # Testing of Task.bind in case of exception
    Task.of(0).bind(lambda x: Task.reject(x + 1)).map(print)



# Generated at 2022-06-26 00:10:58.863253
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_0(task_0):
        def result(reject, resolve):
            def reject_arg_0(task_1):
                def result_0(reject_0, resolve_0):
                    return resolve(b'\x00')

                return Task(result_0)

            return task_0.fork(reject_arg_0, resolve)

        return Task(result)


    task_0 = Task.of(b'\xf5\x9c\xe3\xcf=\xd7~')
    task_1 = task_0.bind(fn_0)
    def fork_0(reject, resolve):
        return resolve(b'\x00')
    assert task_1.fork == fork_0


# Generated at 2022-06-26 00:11:02.276598
# Unit test for method bind of class Task
def test_Task_bind():
    """
    # Unit test for method bind of class Task
    > Task.reject(None).bind(lambda _: Task.of(2))
    :return:
    """
    print(Task.reject(None).bind(lambda _: Task.of(2)))



# Generated at 2022-06-26 00:11:04.547055
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(0)
    assert task_0.map(lambda arg: arg + 1).fork(
        lambda _: False,
        lambda arg: arg == 1
    )


# Generated at 2022-06-26 00:11:09.175917
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return len(value)

    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    expected = 6
    task_0 = Task(bytes_0)
    result = task_0.map(mapper).fork(reject=lambda x: 'rejected', resolve=lambda x: x)
    assert result == expected


# Generated at 2022-06-26 00:11:17.183239
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    task_0 = Task.of(bytes_0)

# Generated at 2022-06-26 00:11:25.700093
# Unit test for method bind of class Task
def test_Task_bind():
    # Test 0
    bytes_0 = b'\xed\x90X\x9f'
    task_0 = Task(bytes_0)
    def fn_0(reject, resolve):
        def fn_1(value_1):
            def fn_2(value_2):
                return resolve(value_2)

            return task_1.fork(None, fn_2)
        return task_0.fork(None, fn_1)
    bytes_1 = b'\xbf\x13\x05\t\xc3'
    task_1 = Task(bytes_1)
    task_2 = task_0.bind(fn_0)
    assert task_2.fork(None, None) == '\xbf\x13\x05\t\xc3'

    # Test 1
    bytes_

# Generated at 2022-06-26 00:11:51.107231
# Unit test for method bind of class Task
def test_Task_bind():
    data = [1,2,3]
    task = Task.of(data)
    task_1 = task.bind(lambda x: Task.of(x[:-1]))
    assert task_1.fork(lambda x: x) == [1,2]
    task_2 = task.bind(lambda x: Task.reject(x[:-1]))
    assert task_2.fork(lambda x: x) == [1,2]


# Generated at 2022-06-26 00:11:53.603974
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.reject('error').bind(lambda x: Task.of(x)).fork(
        lambda arg: arg == 'error',
        lambda arg: arg == 'error'
    )



# Generated at 2022-06-26 00:12:00.764551
# Unit test for method bind of class Task
def test_Task_bind():
    def add_task(v):
        return Task.of(v + 1)

    def transform_task(v):
        return Task.of(v + 1)

    def fork(reject, resolve):
        resolve(Task.of(1))

    task = Task(fork)

    assert task.bind(add_task).bind(transform_task).fork(lambda v: None, lambda v: v) == 3

# Generated at 2022-06-26 00:12:04.121328
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_0(A):
        if A < 10:
            return Task.of(A)
        else:
            return Task.reject(A)

    task_0 = Task.of(8)
    task_1 = task_0.bind(fn_0)

# Generated at 2022-06-26 00:12:13.830111
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Summary line: Test for task.bind

    Description: Test call of bind method on Task class

    Test: Check the results of calling bind method on Task class.
    """
    expected = b'\xf5\x9c\xe3\xcf=\xd7~'
    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    task_0 = Task.of(bytes_0)

    def bind_0(x):
        return Task(x)

    new_task = task_0.bind(bind_0)
    result = new_task.fork(lambda x: None, lambda x: x)
    assert expected == result
    print('Test OK')
    print('Task bind test')
    print('expected:', expected)
    print('result:', result)

# Generated at 2022-06-26 00:12:18.032331
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task(lambda _, resolve: resolve(5))

    result_0 = task_0.map(lambda arg: arg % 2)
    assert isinstance(result_0, Task)

    result_1 = result_0.fork(lambda error: 'rejected', lambda value: value)
    assert result_1 == 1


# Generated at 2022-06-26 00:12:22.797548
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Check bind functionality of class Task with method object_task.
    """
    # Assign
    object_task = Task.of(object())

    def input_fn_0(in_value):
        return Task.of(type(in_value))

    # Action
    task_0 = object_task.bind(input_fn_0)

    # Assert
    assert type(task_0) is Task



# Generated at 2022-06-26 00:12:26.009576
# Unit test for method map of class Task
def test_Task_map():
  task = Task(lambda _, resolve: resolve(10))
  assert task.map(lambda a: a * 3).fork(lambda _: None, lambda a: None) == 30


# Generated at 2022-06-26 00:12:35.176062
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind(fn) returns new Task with mapped reject attribute
    """
    def fn_0(arg_0):
        """
        Task.bind(fn) returns new Task with mapped reject attribute
        """
        assert isinstance(arg_0, bytes), 'arg_0 should be bytes'
        arg_0_0 = arg_0
        task_0 = Task(bytes(b'\xf5\x9c\xe3\xcf=\xd7~'))
        return task_0

    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    task_0 = Task(bytes_0)
    mapped_task_0 = task_0.bind(fn_0)

# Generated at 2022-06-26 00:12:41.815453
# Unit test for method map of class Task
def test_Task_map():

    # Case 1: Check if Task.map(fn) returns new Task with resolve attribute mapped
    def map_fn(value):
        return value.upper()

    def fork_fn(reject, resolve):
        return resolve('Hello')

    input_task = Task(fork_fn)
    output_task = input_task.map(map_fn)
    assert output_task.fork(lambda reject: reject('algo errado'),
                            lambda resolve: resolve('algo certo')) == 'ALGO CERTO'

    # Case 2: Check if Task.map(fn) returns new Task with reject attribute mapped
    def map_fn(value):
        return value.upper()

    def fork_fn(reject, resolve):
        return reject('Hello')

    input_task = Task(fork_fn)
    output_task = input

# Generated at 2022-06-26 00:13:33.011241
# Unit test for method bind of class Task
def test_Task_bind():
    def bytes_0(reject, resolve):
        return resolve(b'\xf5\x9c\xe3\xcf=\xd7~')

    task_0 = Task(bytes_0)
    def bytes_1(reject, resolve):
        return resolve(b'\xfe\x10\x92\xbd\x81\xca*')

    task_1 = Task(bytes_1)
    def unary_0(err, value):
        return task_1

    res_0 = task_0.bind(unary_0)

    def unary_1(err, value):
        return value.decode('utf-8')

    res_1 = res_0.map(unary_1)
    assert res_1 == '⼇楷ᲁ登~'



# Generated at 2022-06-26 00:13:35.739127
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of('value of task')
    task = task.bind(lambda arg: Task.reject(arg + '-extended'))

    assert task.fork(lambda arg: arg, lambda arg: arg) == 'value of task-extended'



# Generated at 2022-06-26 00:13:43.211466
# Unit test for method bind of class Task
def test_Task_bind():
    from collections import OrderedDict
    import json


# Generated at 2022-06-26 00:13:47.839842
# Unit test for method bind of class Task
def test_Task_bind():
    def join_task(value):
        return Task.of(value)

    task_1 = Task.reject(1)
    task_2 = Task.of(1)

    assert task_1.bind(join_task) == task_1
    assert task_2.bind(join_task) == task_2

# Generated at 2022-06-26 00:13:57.759353
# Unit test for method map of class Task
def test_Task_map():
    def well_known_argument0(a, b):
        return a + b

    def well_known_argument1():
        return None

    task_0 = Task.reject(None)
    task_1 = Task.of(task_0)

    task_1_map = task_1.map(well_known_argument0)
    task_2_map = task_1_map.map(well_known_argument1)

    assert well_known_argument0(task_0, well_known_argument1()) == task_2_map

    task_3 = Task.reject(None)
    task_4 = Task.of(task_3)

    task_4_map = task_4.map(well_known_argument0)

# Generated at 2022-06-26 00:14:07.036282
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """

    # yield None

    # Test for Task.of
    # Test with Task[Function(_, resolve) -> A]
    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    task_0 = Task.of(bytes_0)

    # Test with Task[Function(reject, _) -> A]
    bytes_1 = b'k=\x14\x9e\xbf\x00\x05\xbd\xb7\xe3\x050'
    task_1 = Task.of(bytes_1)

    # Test for Task.bind
    # Test with Task[Function(_, resolve) -> A]

# Generated at 2022-06-26 00:14:10.318405
# Unit test for method map of class Task
def test_Task_map():
    bytes_0 = b'\xf5\x9c\xe3\xcf=\xd7~'
    task_0 = Task.of(bytes_0)
    body_0 = task_0.map(lambda arg: len(arg))


# Generated at 2022-06-26 00:14:21.195083
# Unit test for method map of class Task
def test_Task_map():
    def task_resolve(value):
        return Task.of(value)

    def task_reject(value):
        return Task.reject(value)

    def map_double(value):
        return value * 2

    def map_null(value):
        return None

    class Mock:
        def __init__(self):
            self.value = None

        def __call__(self, value):
            self.value = value

    # test case 0 - map from resolve
    mock = Mock()
    task0 = task_resolve(1)
    task0.map(mock)
    out0 = task0.fork(task_reject, task_resolve)
    assert mock.value == out0
    assert out0 == mock(1)

    # test case 1 - map from reject
    mock = Mock()


# Generated at 2022-06-26 00:14:33.667291
# Unit test for method bind of class Task
def test_Task_bind():
    bytes_0 = b'\xef)i\x00\xb5\x83\xa6\xee'

# Generated at 2022-06-26 00:14:37.687402
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task(lambda reject, resolve: resolve(b'\xf5\x9c\xe3\xcf=\xd7~'))
    task_1 = task_0.bind(lambda arg: Task(lambda _, resolve: resolve(arg)))
    assert(b'\xf5\x9c\xe3\xcf=\xd7~' == task_1.fork(lambda _: None, lambda arg: arg))
