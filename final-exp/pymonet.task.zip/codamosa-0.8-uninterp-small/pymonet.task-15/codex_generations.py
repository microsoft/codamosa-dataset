

# Generated at 2022-06-26 00:05:45.873239
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(5)

    def mapper(arg):
        return Task.of(arg + 5)

    result = Task(fork).bind(mapper)


# Generated at 2022-06-26 00:05:55.292356
# Unit test for method map of class Task
def test_Task_map():
    def mapper0(value):
        return value * 2

    def mapper1(value):
        return value + " string"

    def mapper2(value):
        return value * 2 + " string"

    def mapper3(value):
        return value ** 2

    task = Task.of(2)
    task2 = task.map(mapper0)
    task3 = task.map(mapper1)
    task4 = task.map(mapper2)
    task5 = task.map(mapper3)
    assert task2.fork(None, None) == 4
    assert task3.fork(None, None) == "2 string"
    assert task4.fork(None, None) == "4 string"
    assert task5.fork(None, None) == 4



# Generated at 2022-06-26 00:05:59.215174
# Unit test for method bind of class Task
def test_Task_bind():
    bool_0 = True
    task_0 = Task.of(bool_0)
    assert task_0.bind(lambda arg: Task.of(arg)) == True;
    assert task_0.bind(lambda arg: Task.reject(arg)) == True;
    assert type(task_0) == Task


# Generated at 2022-06-26 00:06:03.591290
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_0():
        bool_0 = False
        task_0 = Task(bool_0)
        def mapper_0(arg_1):
            var_0 = arg_1
            var_1 = var_0
            var_2 = var_1
            return var_2
        task_1 = task_0.bind(mapper_0)
        assert task_1 == task_0



# Generated at 2022-06-26 00:06:09.595971
# Unit test for method map of class Task
def test_Task_map():
    # Task(reject, resolve) -> Task[reject, resolve]
    def fork(reject, resolve):
        return Task(fork)

    # Function(Task[reject, resolve]) -> Task[reject, resolve]
    def fn(arg):
        return Task(fork)

    # Task[reject, resolve] -> Task[reject, resolve]
    task_0 = Task(fork)
    # Task[reject, resolve]
    task_1 = task_0.map(fn)

# Generated at 2022-06-26 00:06:20.355104
# Unit test for method map of class Task
def test_Task_map():
    """
    Simple test for Task.map method.
    """
    # Given
    def str_len(value):
        return len(value)

    def inc(value):
        return value + 1

    def compose(func_a, func_b):
        def inner(value):
            return func_a(func_b(value))
        return inner

    task_0 = Task.of("")
    task_1 = Task.of("abcd")

    # When
    map_0 = task_0.map(str_len)
    map_1 = task_1.map(str_len)
    map_2 = task_1.map(inc)
    map_3 = task_1.map(compose(inc, str_len))

    # Then

# Generated at 2022-06-26 00:06:32.355700
# Unit test for method bind of class Task
def test_Task_bind():
    def task_resolve_0(value):
        return Task.of(value)

    def task_resolve_1(value):
        assert value == 'task_resolve_0'
        return Task.of(value)

    def task_resolve_2(value):
        assert value == 'task_resolve_1'
        return Task.of(value)

    def task_reject_0(value):
        assert value == 'task_reject'
        return Task.of(value)

    task_0 = Task(lambda reject, resolve: resolve('task_resolve_0'))
    task_1 = task_0.bind(task_resolve_0)
    task_2 = task_1.bind(task_resolve_1)

# Generated at 2022-06-26 00:06:36.027000
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task(lambda reject, resolve: resolve(1))
    task_0 = task.bind(lambda x: Task.reject(x + 1))
    task_0.fork(
        lambda x: print(1),
        lambda x: print(0)
    )


# Generated at 2022-06-26 00:06:45.870551
# Unit test for method bind of class Task
def test_Task_bind():
    bool_1 = True
    bool_2 = True
    bool_3 = False
    task_1 = Task(bool_1)
    task_2 = Task(bool_2)

    def test_function_1(val):
        bool_1 = isinstance(val, Task)
        return bool_1

    def test_function_2(val):
        return task_2

    def test_function_3(val):
        def result(reject, resolve):
            if (val):
                reject(val)
            else:
                resolve(val)

        return Task(result)

    try:
        task_1.bind(test_function_1)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 00:06:47.347794
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(10).bind(lambda v: Task.of(v * 2)).fork(lambda e: e, lambda x: x) == 20


# Generated at 2022-06-26 00:06:55.052173
# Unit test for method bind of class Task
def test_Task_bind():
    value_0 = "result"
    task_0 = Task.of(value_0)

    value_1 = "new result"
    task_1 = task_0.bind(lambda arg_0: Task.of(value_1))

    assert task_1.fork(lambda arg_0: "rejected", lambda arg_1: arg_1) is value_1



# Generated at 2022-06-26 00:07:03.236723
# Unit test for method map of class Task
def test_Task_map():
    # testing example from README
    bool_1 = bool(Task.of(2).map(lambda x: x + 1))
    bool_2 = bool(Task.of(2).map(lambda x: x * 2))

    # unit testing
    bool_3 = bool(Task.of(2).map(lambda x: x + 1).bind(
        lambda x: Task.of(x + 1)
    ))
    bool_4 = bool(Task.of(2).map(lambda x: x * 2).bind(
        lambda x: Task.of(x + 1)
    ))

test_case_0()
test_Task_map()

# Generated at 2022-06-26 00:07:07.645621
# Unit test for method bind of class Task
def test_Task_bind():
    klass = Task.of
    func = Task.bind
    arg_1 = klass(None)
    arg_2 = klass(None)
    result = func(arg_1, arg_2)
    if not isinstance(result, Task):
        print('Task_bind: error')
    else:
        print('Task_bind: OK')


# Generated at 2022-06-26 00:07:17.750011
# Unit test for method map of class Task
def test_Task_map():
    bool_0 = False
    def fn_0(arg_0):
        def fn_1(arg_1):
            return arg_1 * (10 + (arg_1 + arg_0))
        return fn_1
    task_0 = Task.of(bool_0)
    task_1 = Task.of(1)
    task_2 = Task.of(2)
    task_3 = Task.of(3)
    task_4 = Task.of(4)
    task_5 = Task.of(5)
    task_6 = Task.of(6)
    task_7 = Task.of(7)
    task_8 = Task.of(8)
    task_9 = Task.of(9)
    task_10 = Task.of(10)
    task_11 = Task.of(11)

# Generated at 2022-06-26 00:07:25.868485
# Unit test for method map of class Task
def test_Task_map():
    bool_1 = False
    # multiply number by 2
    task_1 = Task(lambda _, resolve: resolve(2))
    task_2 = task_1.map(lambda value: value * 2)
    task_3 = task_2.fork(lambda *_: bool_1, lambda *_: bool_1)
    assert task_3 == bool_1


# Generated at 2022-06-26 00:07:35.035942
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(42)
    task = task.bind(lambda x: Task.of(x * x))
    assert task.fork(None, lambda x: x) == 42 * 42

    # test for the monad rules
    # left identity law
    def left_identity(x):
        assert (
            Task.of(x).bind(fn_1) ==
            fn_1(x)
        )

    def fn_1(x):
        return Task.of(x + 1)

    left_identity(1)
    left_identity(5)

    # Right identity
    def right_identity(x):
        assert (
            x.bind(Task.of) == x
        )

    right_identity(Task.of(1))
    right_identity(Task.of(5))

# Generated at 2022-06-26 00:07:44.335935
# Unit test for method bind of class Task
def test_Task_bind():
    task_0 = Task.of(1)
    task_1 = task_0.bind(lambda x: Task.of(x + 1))
    task_2 = task_0.bind(lambda x: Task.reject(x + 1))
    bool_0 = Task.reject(1).bind(lambda x: Task.of(1)) == None
    bool_1 = task_0.fork(lambda x: x, lambda x: None) == 1
    bool_2 = task_1.fork(lambda x: x, lambda x: None) == 2
    bool_3 = task_2.fork(lambda x: x, lambda x: None) == 2
    return bool_0, bool_1, bool_2, bool_3

## Unit test for method map of class Task

# Generated at 2022-06-26 00:07:47.842474
# Unit test for method map of class Task
def test_Task_map():
    bool_0 = True
    task_0 = Task.of(bool_0)

    # assert task_0.fork(lambda arg: print(arg))
    assert task_0.map(lambda arg: arg).fork(lambda arg: print(arg)) == bool_0


# Generated at 2022-06-26 00:07:51.671082
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(False).bind(lambda _: Task.of(True)).fork(lambda _: False, lambda _: True)


# Generated at 2022-06-26 00:07:57.290087
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1).map(lambda _: 2).map(lambda _: 3)
    assert task.fork(lambda _: None, lambda _: None) == 3


# Generated at 2022-06-26 00:08:04.979364
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of('value').map(lambda arg: arg).fork(
        lambda reject: reject('Test fail'),
        lambda resolve: resolve('Test passed')
    ) == 'Test passed'



# Generated at 2022-06-26 00:08:11.511959
# Unit test for method map of class Task
def test_Task_map():
    def mock_task(reject, resolve):
        resolve(0)

    Task.of(1).map(lambda arg: arg + 1).fork(lambda arg: print(arg), lambda arg: print(arg))
    # >>> 2
    Task.reject(1).map(lambda arg: arg + 1).fork(lambda arg: print(arg), lambda arg: print(arg))
    # >>> 1
    Task(mock_task).map(lambda arg: arg + 1).fork(lambda arg: print(arg), lambda arg: print(arg))
    # >>> 1


# Generated at 2022-06-26 00:08:13.640099
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(42).map(lambda n: n+1).fork(None, lambda n: n) == 43

# Generated at 2022-06-26 00:08:22.988664
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(3)
    task_1 = task_0.map(lambda x: 2 * x)
    task_2 = task_1.map(lambda x: x + 1)
    task_3 = task_1.map(lambda x: x ** 2)
    print(task_1.fork(
        lambda x: 'Error: %s' % x,
        lambda x: 'Result: %s' % x
    ))
    print(task_2.fork(
        lambda x: 'Error: %s' % x,
        lambda x: 'Result: %s' % x
    ))
    print(task_3.fork(
        lambda x: 'Error: %s' % x,
        lambda x: 'Result: %s' % x
    ))


# Generated at 2022-06-26 00:08:29.702405
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def square(arg): return arg * arg

    def add_one(_): return 1

    def identity(arg): return arg

    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3

    task_0 = Task(int_0)
    task_1 = Task(int_0).map(square).map(add_one)
    task_2 = Task.of(int_2)
    task_3 = Task.of(int_2).map(square)
    task_4 = Task.reject(int_3)
    task_5 = Task.reject(int_3).map(identity)

# Generated at 2022-06-26 00:08:32.091333
# Unit test for method map of class Task
def test_Task_map():
    assert (
        Task.of('value').map(lambda _: 'mapped_value') ==
        Task.of('mapped_value')
    )


# Generated at 2022-06-26 00:08:42.173118
# Unit test for method bind of class Task
def test_Task_bind():

    # Unit test for method bind of class Task with ForkResult = False
    def test_Task_bind_0():
        task_0 = Task.of(10)
        task_1 = task_0.bind(lambda arg_0: Task.reject(arg_0 + 20))
        task_2 = task_1.fork(lambda arg_0: arg_0, lambda arg_0: arg_0 + 1)
        assert task_2 == 30

    # Unit test for method bind of class Task with ForkResult = True
    def test_Task_bind_1():
        task_0 = Task.reject(10)
        task_1 = task_0.bind(lambda arg_0: Task.reject(arg_0 + 20))

# Generated at 2022-06-26 00:08:50.972644
# Unit test for method map of class Task
def test_Task_map():
    bool_0 = False
    bool_1 = True
    task_0 = Task.of(bool_0).map(lambda arg: bool_1)

    assert isinstance(task_0, Task), \
        "Failed to assert Task"
    assert isinstance(task_0.fork, FunctionType), \
        "Failed to assert fork is function in Task"

    result = task_0.fork(lambda arg: bool_0, lambda arg: bool_1)
    assert result is bool_1, \
        "Failed to assert map function in Task"

    task_1 = Task.reject(bool_0).map(lambda arg: bool_1)

    result = task_1.fork(lambda arg: bool_1, lambda arg: bool_0)

# Generated at 2022-06-26 00:08:55.722386
# Unit test for method bind of class Task
def test_Task_bind():
    bool_0 = True
    bool_1 = True
    result = Task.of(bool_0).bind(lambda bool_0: Task.reject(bool_1)).fork(
        lambda bool_0: print(bool_0),
        lambda bool_0: print(bool_0)
    )
    print(result)


# Generated at 2022-06-26 00:09:00.010866
# Unit test for method bind of class Task
def test_Task_bind():
    def f(_):
        return Task.of(2)
    def fork(reject, resolve):
        return Task.of(1).bind(f).fork(reject, resolve)
    task = Task(fork)
    assert task.fork(lambda x: x, lambda x: x) == 2

# Generated at 2022-06-26 00:09:16.504313
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.reject(0).bind(lambda val: Task.of(val)).fork(
        lambda _: False,
        lambda _: True
    )
    assert Task.reject(0).bind(lambda val: Task.reject(val)).fork(
        lambda _: True,
        lambda _: False
    )
    assert Task.of(0).bind(lambda val: Task.reject(val)).fork(
        lambda _: True,
        lambda _: False
    )
    assert Task.of(0).bind(lambda val: Task.of(val)).fork(
        lambda _: False,
        lambda val: val == 0
    )


# Generated at 2022-06-26 00:09:25.311011
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    def test_case_0():
        # Check that method map return Tack[value] when Task[value].map(function) called
        """
        :Test case: 
            Task[A].map(fn)
            -> Task[B]
        :returns: 
            True if result is Task[B]
            False if result is not Task[B]
        :rtype: Boolean
        """

        def fn(value):
            return value
        task = Task(fn)

        def fn_0(_, resolve):
            return resolve(5)
        task_0 = Task(fn_0)

        return (
            task.map(task_0).fork(lambda reject: False, lambda resolve: True)
            ==
            True
        )


# Generated at 2022-06-26 00:09:32.323179
# Unit test for method bind of class Task
def test_Task_bind():
    def test(value):
        bool_0 = value == 0
        task_0 = Task(bool_0)
        def fn_1(value):
            task_1 = Task.of(value)
            return task_1
        task_2 = task_0.bind(fn_1)
        return task_2
    bool_1 = test(0).fork(lambda arg: arg, lambda arg: not arg)
    bool_2 = test(1).fork(lambda arg: arg, lambda arg: not arg)
    return bool_1 and bool_2



# Generated at 2022-06-26 00:09:40.933267
# Unit test for method map of class Task
def test_Task_map():
    # Unit test 1
    task_1 = Task.of("test string")
    assert task_1.fork(lambda _, reject: reject("reject"),
                      lambda resolve, _: resolve("resolve")) == "resolve"
    # Unit test 2
    def fn_1(arg):
        return " ".join(arg.split(" ")[::2])

    task_2 = task_1.map(fn_1)
    assert task_2.fork(lambda _, reject: reject("reject"),
                       lambda resolve, _: resolve("resolve")) == "resolve"

    # Unit test 3
    task_3 = Task.reject("reject")
    assert task_3.fork(lambda reject, _: reject("reject"),
                       lambda _, resolve: resolve("resolve")) \
                       == "reject"

    #

# Generated at 2022-06-26 00:09:50.342346
# Unit test for method map of class Task
def test_Task_map():

    def f(value):
        return value

    def g(value):
        return value

    def h(value):
        return value

    def k(value):
        return value

    def task_test_1(reject, resolve):
        return resolve(f(1))

    def task_test_2(reject, resolve):
        return resolve(g(2))

    def task_test_3(reject, resolve):
        return resolve(h(3))

    def task_test_4(reject, resolve):
        return resolve(k(4))

    task_1 = Task(task_test_1)
    task_2 = Task(task_test_2)
    task_3 = Task(task_test_3)
    task_4 = Task(task_test_4)

    assert task_1.map

# Generated at 2022-06-26 00:09:57.955655
# Unit test for method bind of class Task
def test_Task_bind():
    def task_resolver(_, resolve):
        def fn(number):
            assert number == 0
            return Task.of(number)

        task_0 = Task.of(0)
        task_1 = task_0.bind(fn)

        task_1.fork(
            lambda _: resolve(False),
            lambda _: resolve(True)
        )

    task_1 = Task(task_resolver)
    task_1_result = task_1.fork(lambda _: 'ERROR !!!', lambda _: _)

    assert task_1_result == 0
    print('test_Task_bind(), pass')



# Generated at 2022-06-26 00:10:00.318616
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    task_1 = Task(lambda _, resolve: resolve(42))
    assert task_1.map(mapper).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 43



# Generated at 2022-06-26 00:10:02.096382
# Unit test for method map of class Task
def test_Task_map():
    def map_fn_0():
        return False
    task_0 = Task.of(1).map(map_fn_0)


# Generated at 2022-06-26 00:10:11.368384
# Unit test for method map of class Task
def test_Task_map():
    o_0 = Task.of(1)
    o_0_plus_5 = o_0.map(lambda arg: arg + 5)
    o_0_plus_5_eq_6 = o_0_plus_5.fork(lambda arg: False, lambda arg: arg == 6)
    o_0_plus_5_eq_6_double = o_0_plus_5_eq_6.map(lambda arg: arg * 2)
    o_0_plus_5_eq_6_double_eq_12 = o_0_plus_5_eq_6_double.fork(lambda arg: False, lambda arg: arg == 12)

    assert o_0_plus_5_eq_6_double_eq_12



# Generated at 2022-06-26 00:10:20.303259
# Unit test for method map of class Task
def test_Task_map():
    assert(Task.of(2)\
        .map(lambda arg: arg + 2)\
        .fork(lambda arg: arg, lambda arg: arg) == 4)

    assert(Task.of(1)\
        .map(lambda arg: arg + 2)\
        .fork(lambda arg: arg, lambda arg: arg) == 3)

    assert(Task.of(1)\
        .map(lambda arg: arg ** 2)\
        .fork(lambda arg: arg, lambda arg: arg) == 1)

    assert(Task.of(3)\
        .map(lambda arg: arg ** 2)\
        .fork(lambda arg: arg, lambda arg: arg) == 9)

    assert(Task.of(2)\
        .map(lambda arg: arg ** 2)\
        .fork(lambda arg: arg, lambda arg: arg) == 4)

# Generated at 2022-06-26 00:10:41.402414
# Unit test for method map of class Task
def test_Task_map():
    def mapper(x):
        return x + 1

    assert Task.of(1).map(mapper).fork(lambda x: False, lambda x: x) == 2


# Generated at 2022-06-26 00:10:52.449101
# Unit test for method bind of class Task
def test_Task_bind():
    def task_0_fork(reject, resolve):
        return True

    def task_1_fork(reject, resolve):
        return resolve(True)

    def task_2_fork(reject, resolve):
        return reject(True)

    def task_3_fork(reject, resolve):
        return resolve(False)

    def task_4_fork(reject, resolve):
        return reject(False)


# Generated at 2022-06-26 00:10:54.726094
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(42)
    task_1 = task_0.map(lambda value: value + 1)



# Generated at 2022-06-26 00:10:57.722533
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_0():
        bool_0 = False
        task_0 = Task(bool_0)
        task_1 = task_0.bind(bool_0)


# Generated at 2022-06-26 00:11:00.845955
# Unit test for method map of class Task
def test_Task_map():
    bool_0 = False
    task_0 = Task(bool_0)
    task_1 = task_0.map(lambda arg: arg)


# Generated at 2022-06-26 00:11:09.214235
# Unit test for method map of class Task
def test_Task_map():
    def map_reject(val):
        if val != 'some_string':
            raise Exception('Task is not map by reject function on map function.')

    def map_resolve(val):
        if val != 'some_string':
            raise Exception('Task is not map by resolve function on map function.')

    def map_fn(val):
        return val

    task_0 = Task.of('some_string')
    task_1 = Task.reject('some_string')

    task_0.fork(map_reject, map_resolve)
    task_1.fork(map_reject, map_resolve)

    task_0 = task_0.map(map_fn)
    task_1 = task_1.map(map_fn)


# Generated at 2022-06-26 00:11:11.199366
# Unit test for method bind of class Task
def test_Task_bind():
    def f(n):
        return Task.of(n + 1)

    print(Task.of(1).bind(f))



# Generated at 2022-06-26 00:11:16.752790
# Unit test for method map of class Task
def test_Task_map():
    first = False
    second = True
    task = Task.of(first)
    not_task = task.map(lambda value: not value)

    def fork(reject, resolve):
        return resolve(second)

    assert not_task.fork(resolve=lambda value: not value) == second



# Generated at 2022-06-26 00:11:25.371253
# Unit test for method bind of class Task
def test_Task_bind():
    # Case 0: lambda function reject
    task_0 = Task(lambda resolve, reject: reject('test reject'))

    # Case 1: lambda function resolve
    task_1 = Task(lambda resolve, reject: resolve('test resolve'))

    # Case 2: lambda function resolve with bind
    task_2 = task_1.bind(lambda value: Task.reject(value))

    result_0 = task_0.fork(
        lambda arg: arg,
        lambda arg: 'test resolve'
    )
    result_1 = task_1.fork(
        lambda arg: arg,
        lambda arg: 'test resolve'
    )
    result_2 = task_2.fork(
        lambda arg: arg,
        lambda arg: 'test resolve'
    )

    assert result_0 == 'test reject'

# Generated at 2022-06-26 00:11:34.052618
# Unit test for method map of class Task
def test_Task_map():

    assert Task.of(1).map(lambda _: 'a').fork(None, assert_result('a')) == None
    assert Task.of(1).map(_ * 2).fork(None, assert_result(2)) == None
    assert Task.of(1).map(_ + 2).map(_ * 2).fork(None, assert_result(6)) == None
    assert Task.of(1).map(_ + 2).map(_ * 2).map(_ / 2).fork(None, assert_result(3.0)) == None
    assert Task.of(1).map(_ + 2).map(_ * 2).map(_ / 2).fork(None, assert_result(3.0)) == None

# Generated at 2022-06-26 00:12:17.419967
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value * 2

    bool_0 = False
    task_0 = Task(lambda _, resolve: resolve(0))
    task_map = task_0.map(mapper)
    value = task_map.fork(lambda a: bool_0, lambda a: isinstance(a, int) and a == 0)
    assert value

    def mapper(value):
        return value * 2

    bool_1 = False
    task_1 = Task(lambda _, resolve: resolve(2))
    task_map = task_1.map(mapper)
    value = task_map.fork(lambda a: bool_1, lambda a: isinstance(a, int) and a == 4)
    assert value

    def mapper(value):
        return bool_0

    bool_2 = False


# Generated at 2022-06-26 00:12:26.730045
# Unit test for method map of class Task
def test_Task_map():

    # data to test
    empty_list = []
    empty_string = ''
    collection = [1, 2, 3, 4, 5]
    integer = 1
    float_number = 3.2
    true_boolean = True
    false_boolean = False
    string_0 = 'test string'
    string_1 = 'test string 1'
    string_2 = 'test string 2'
    none = None
    function_0 = None
    function_1 = lambda arg1: arg1
    function_2 = lambda arg1, arg2: arg1 + arg2
    function_3 = lambda arg1, arg2, arg3: arg1 + arg2 + arg3
    function_4 = lambda arg1, arg2, arg3, arg4: arg1 + arg2 + arg3 + arg4

# Generated at 2022-06-26 00:12:27.817071
# Unit test for method map of class Task
def test_Task_map():
    bool_0 = False
    task_0 = Task(bool_0)

# Generated at 2022-06-26 00:12:36.720639
# Unit test for method bind of class Task
def test_Task_bind():
    def test(result_arg_0, result_arg_1, result_error_0, result_error_1, error_0, error_1, resolve_0, resolve_1,
             reject_0, reject_1, fork_0, fork_1, bind_0, bind_1, map_0, map_1, of_0, of_1, reject_2, reject_3,
             result_arg_2, result_error_2, result_arg_3, result_error_3):

        result_0 = Task(fork_0).bind(bind_0).fork(reject_0, resolve_0)
        result_1 = Task(fork_1).bind(bind_1).fork(reject_1, resolve_1)

# Generated at 2022-06-26 00:12:41.453668
# Unit test for method bind of class Task
def test_Task_bind():
    is_called = False
    value = None
    def reject(value):
        pass

    def resolve(value):
        nonlocal is_called
        is_called = True
        nonlocal value
        value = "two"

    def fn(value):
        nonlocal is_called
        is_called = True
        nonlocal value
        value = "two"

    task = Task.of(1).bind(fn)
    task.fork(reject, resolve)

    if not(is_called and value == "two"):
        raise Exception("Task.bind")


# Generated at 2022-06-26 00:12:49.642867
# Unit test for method map of class Task
def test_Task_map():
    def test_function_0(value):
        return value + 1

    def test_function_1(value):
        return value - 1

    def test_function_2(value):
        return value + 2

    bool_0 = False
    task_0 = Task.of(bool_0)
    task_1 = task_0.map(test_function_0)

    bool_1 = bool_0
    bool_2 = bool_1 + 1

    bool_3 = bool_0
    bool_4 = bool_3 + 2

    bool_5 = bool_0
    bool_6 = bool_5 + 2

    bool_7 = bool_0
    bool_8 = bool_7 - 1


# Generated at 2022-06-26 00:12:57.946112
# Unit test for method map of class Task
def test_Task_map():
    # prepare context
    task_0 = Task.of(1)
    task_1 = Task.of(2)
    # test func map
    task_map_0 = task_0.map(lambda v: v+1)
    task_map_1 = task_1.map(lambda v: v*3)
    # execute
    task_map_0.fork(
        lambda v: print('rejected: ' + str(v)),
        lambda v: print('resolved: ' + str(v))
    )
    task_map_1.fork(
        lambda v: print('rejected: ' + str(v)),
        lambda v: print('resolved: ' + str(v))
    )


# Generated at 2022-06-26 00:13:01.272553
# Unit test for method bind of class Task
def test_Task_bind():
    def function_0(arg):
        return arg

    def function_1(arg):
        return Task.of(function_0(arg))

    # Test
    task_0 = Task(lambda reject, resolve: resolve(True))

    task_1 = task_0.bind(function_1)


# Generated at 2022-06-26 00:13:05.089517
# Unit test for method bind of class Task
def test_Task_bind():
    def result_0(reject, resolve):
        resolve(0)
    Task.of(0).bind(lambda arg: Task.of(arg)).fork(lambda arg: arg, lambda arg: arg)
    Task.of(0).bind(lambda arg: Task.of(arg)).fork(lambda arg: reject(arg), lambda arg: resolve(arg))


# Generated at 2022-06-26 00:13:15.123025
# Unit test for method map of class Task
def test_Task_map():
    # GIVEN: Task[Function(resolve | reject) -> A | B]
    bool_1 = True

    def fork_1(reject, resolve):
        if bool_1:
            return resolve("yay")
        else:
            return reject("nay")

    # GIVEN: Task[Function(resolve | reject) -> A | B]
    task_1 = Task(fork_1)

    # GIVEN: Function(value) -> B
    def map_1(value):
        return value

    # WHEN: task_2 = task_1.map(map_1)
    task_2 = task_1.map(map_1)

    # THEN: type(task_2) == Task[Function(reject | resolve) -> A | B]
    assert type(task_2) == Task

   

# Generated at 2022-06-26 00:14:57.773398
# Unit test for method map of class Task
def test_Task_map():
    task_0 = Task.of(1)
    function_0 = lambda arg: arg + 1
    task_1 = task_0.map(function_0)

# Generated at 2022-06-26 00:15:03.033082
# Unit test for method map of class Task
def test_Task_map():
    bool_0 = False
    task_0 = Task(bool_0)

    bool_1 = False
    task_1 = task_0.map(bool_1)

    assert bool_1 == bool_0

    bool_2 = True
    task_2 = task_1.map(bool_2)
    bool_3 = bool_2 == bool_1

    assert bool_3 == bool_0

    task_3 = task_2.map(lambda: 1)

    assert task_3.fork ==  task_2.fork

    class A:
        def __init__(self, val):
            self.val = val

        def __eq__(self, other):
            return self.val == other.val

        def __ne__(self, other):
            return self.val != other.val


# Generated at 2022-06-26 00:15:10.092197
# Unit test for method bind of class Task
def test_Task_bind():
    def fork_0(reject, resolve):
        return resolve(0)

    task_0 = Task(fork_0)
    def fn_0(arg_0):
        def fork_1(reject, resolve):
            return reject(arg_0)

        return Task(fork_1)

    task_1 = task_0.bind(fn_0)

    def fork_2(reject, resolve):
        try:
            task_1.fork(reject, resolve)
        except Exception as error:
            print(error)
            return reject(error)

    task_2 = Task(fork_2)


# Generated at 2022-06-26 00:15:13.694821
# Unit test for method map of class Task
def test_Task_map():
    bool_0 = True
    task_0 = Task(bool_0)
    # TODO
    # task_1 = task_0.map()
    # assert task_1 == Task.of(True)


# Generated at 2022-06-26 00:15:21.757259
# Unit test for method bind of class Task
def test_Task_bind():
    bool_0 = False
    task_0 = Task.of(bool_0)
    def resolve_fn_0(arg_0): pass
    def result_fn_0(reject, resolve):
        return task_0.fork(lambda arg: None, lambda arg: resolve_fn_0(arg))
    def fn_0(value_0):
        fn_0_a = Task.of(bool_0)
        fn_0_b = fn_0_a.map(lambda arg: None)
        return fn_0_b
    fn_0_a = task_0.bind(fn_0)
    fn_0_b = Task(result_fn_0)
    assert fn_0_a == fn_0_b

if __name__ == "__main__":
    import sys
    import doctest


# Generated at 2022-06-26 00:15:24.742424
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value if value else None

    def mapper_0(value):
        return value

    task_0 = Task(lambda _, resolve: resolve(1))

    assert task_0.map(mapper) == task_0.map(mapper_0)



# Generated at 2022-06-26 00:15:27.294431
# Unit test for method map of class Task
def test_Task_map():
    def passed_test(value):
        assert value == 1

    def fail_test(value):
        assert value != 1

    task = Task.of(1)
    task.map(passed_test)
    task.map(fail_test)


# Generated at 2022-06-26 00:15:29.452508
# Unit test for method bind of class Task
def test_Task_bind():
    def function_0(arg_0):
        return Task.of(arg_0)

    task_0 = Task.reject(False).bind(function_0)


# Generated at 2022-06-26 00:15:33.883483
# Unit test for method map of class Task
def test_Task_map():
    # Setup
    def fork(reject, resolve):
        return resolve(2)

    task_0 = Task(fork)

    def mapper(value):
        return 'a'

    # Execution
    task_1 = task_0.map(mapper)

    # Assertion
    assert 'a' == task_1.fork(lambda _: 'b', lambda _: 'a')



# Generated at 2022-06-26 00:15:40.430677
# Unit test for method map of class Task
def test_Task_map():
    """
    create Task with value = 1 then call map with func -> arg*2
    check if result of resolved task is 2
    """
    def test_map(task, func, value):
        assert task.map(func).fork(None, None) == value
        assert task.map(func).fork(None, call_func(func)) == value

    # test with value = 1
    value_0 = 1
    task_0 = Task.of(value_0)
    test_map(task_0, lambda x: x*2, value_0*2)

    # test with value = "a"
    value_1 = "a"
    task_1 = Task.of(value_1)
    test_map(task_1, lambda x: x+"b", value_1+"b")

    # test with value