

# Generated at 2022-06-18 02:06:17.248884
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task.of(1)
    assert task.map(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:25.278759
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:29.569703
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:34.458094
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:42.966644
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_map_resolve(resolve, reject):
        """
        Test for method map of class Task.
        """
        resolve(1)

    def test_map_reject(resolve, reject):
        """
        Test for method map of class Task.
        """
        reject(1)

    def test_map_map(resolve, reject):
        """
        Test for method map of class Task.
        """
        resolve(1)

    def test_map_bind(resolve, reject):
        """
        Test for method map of class Task.
        """
        resolve(1)

    def test_map_map_resolve(resolve, reject):
        """
        Test for method map of class Task.
        """

# Generated at 2022-06-18 02:06:46.209154
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.reject(1).map(add_one).fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:06:51.652841
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:58.519308
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:02.726995
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:05.867305
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:10.554531
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:13.514135
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve(1)

    def fn(value):
        return value + 1

    task = Task(fork)
    assert task.map(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:17.247400
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:21.432748
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task.of(1).map(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2

    task = Task.reject(1).map(fn)
    assert task.fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:07:31.186723
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:34.651190
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task.of(1)
    result = task.map(fn)

    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:38.754448
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.map(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:46.554622
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:50.810581
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: False, lambda arg: arg == 2)


# Generated at 2022-06-18 02:07:59.418729
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_case(value):
        """
        Test case for method map of class Task.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        def mapper(arg):
            """
            Mapper function for method map of class Task.

            :param arg: value to store in Task
            :type arg: A
            :returns: resolved Task
            :rtype: Task[Function(_, resolve) -> A]
            """
            return arg + 1

        return Task.of(value).map(mapper)

    assert test_case(1).fork(lambda _: False, lambda arg: arg == 2)
    assert test_

# Generated at 2022-06-18 02:08:09.426857
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda _: False, lambda arg: arg == 2)
    assert test_map(2).fork(lambda _: False, lambda arg: arg == 3)
    assert test_map(3).fork(lambda _: False, lambda arg: arg == 4)


# Generated at 2022-06-18 02:08:19.049563
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve(resolve, reject):
        resolve(1)

    def test_map_reject(resolve, reject):
        reject(1)

    def test_map_resolve_mapper(value):
        return value + 1

    def test_map_reject_mapper(value):
        return value + 1

    def test_map_resolve_mapper_reject(value):
        raise Exception('test_map_resolve_mapper_reject')

    def test_map_reject_mapper_reject(value):
        raise Exception('test_map_reject_mapper_reject')

    def test_map_resolve_mapper_resolve(value):
        return value + 1


# Generated at 2022-06-18 02:08:22.186447
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:28.133219
# Unit test for method bind of class Task
def test_Task_bind():
    def add(value):
        return Task.of(value + 1)

    def reject(value):
        return Task.reject(value)

    assert Task.of(1).bind(add).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).bind(reject).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-18 02:08:37.851698
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:41.377946
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:45.490542
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(value):
        return Task.of(value + 1)

    task = Task.of(1)
    task = task.bind(test_function)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:49.111042
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)


# Generated at 2022-06-18 02:08:58.593093
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x / 0)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == ZeroDivisionError


# Generated at 2022-06-18 02:09:08.334699
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def error(x):
        raise Exception(x)

    assert Task.of(1).map(add).fork(None, lambda x: x) == 2
    assert Task.of(1).map(sub).fork(None, lambda x: x) == 0
    assert Task.of(1).map(mul).fork(None, lambda x: x) == 2
    assert Task.of(1).map(div).fork(None, lambda x: x) == 0.5
    assert Task.of(1).map(error).fork(lambda x: x, None) == 1


# Generated at 2022-06-18 02:09:20.786592
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task.of(1)
    assert task.map(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:24.891935
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:30.614172
# Unit test for method map of class Task
def test_Task_map():
    def add(value):
        return value + 1

    def sub(value):
        return value - 1

    def mul(value):
        return value * 2

    def div(value):
        return value / 2

    def pow(value):
        return value ** 2

    def mod(value):
        return value % 2

    def concat(value):
        return value + ' world'

    def upper(value):
        return value.upper()

    def lower(value):
        return value.lower()

    def capitalize(value):
        return value.capitalize()

    def title(value):
        return value.title()

    def swapcase(value):
        return value.swapcase()

    def replace(value):
        return value.replace('a', 'b')

    def strip(value):
        return value.strip

# Generated at 2022-06-18 02:09:37.604471
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(
        lambda _: None,
        lambda value: value
    ) == 7


# Generated at 2022-06-18 02:09:40.727388
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:44.446967
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method.
    """
    def test_fn(value):
        """
        Test function.
        """
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(test_fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:54.901397
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:09:58.415305
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    task = Task.of(1)
    assert task.map(add_one).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:10:02.627568
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2



# Generated at 2022-06-18 02:10:06.021645
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:36.298548
# Unit test for method map of class Task
def test_Task_map():
    def add(value):
        return value + 1

    def mul(value):
        return value * 2

    def div(value):
        return value / 2

    def sub(value):
        return value - 1

    assert Task.of(1).map(add).map(mul).map(div).map(sub).fork(
        lambda err: err,
        lambda res: res
    ) == 1

    assert Task.of(1).map(add).map(mul).map(div).map(sub).map(add).fork(
        lambda err: err,
        lambda res: res
    ) == 2


# Generated at 2022-06-18 02:10:42.474948
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)

    def test_fn_reject(value):
        return Task.reject(value + 1)

    assert Task.of(1).bind(test_fn).fork(lambda x: x, lambda x: x) == 2
    assert Task.reject(1).bind(test_fn_reject).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:10:46.572364
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper).fork(lambda _: None, lambda value: value)
    assert result == 2


# Generated at 2022-06-18 02:10:49.412738
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    task_mapped = task.map(lambda x: x + 1)
    assert task_mapped.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:10:52.906411
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:57.545713
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:59.843746
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:08.359987
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12


# Generated at 2022-06-18 02:11:17.723909
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_function(value):
        return value + 1

    def test_function_2(value):
        return value + 2

    def test_function_3(value):
        return value + 3

    def test_function_4(value):
        return value + 4

    def test_function_5(value):
        return value + 5

    def test_function_6(value):
        return value + 6

    def test_function_7(value):
        return value + 7

    def test_function_8(value):
        return value + 8

    def test_function_9(value):
        return value + 9

    def test_function_10(value):
        return value + 10


# Generated at 2022-06-18 02:11:27.379341
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_map_resolve():
        """
        Test for method map of class Task with resolved Task.
        """
        def fn(value):
            return value * 2

        def fork(reject, resolve):
            resolve(2)

        task = Task(fork)
        assert task.map(fn).fork(lambda _: None, lambda value: value) == 4

    def test_map_reject():
        """
        Test for method map of class Task with rejected Task.
        """
        def fn(value):
            return value * 2

        def fork(reject, resolve):
            reject(2)

        task = Task(fork)
        assert task.map(fn).fork(lambda value: value, lambda _: None) == 2

    test_map_

# Generated at 2022-06-18 02:12:10.517203
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:12:14.598200
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:12:22.537377
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:28.879908
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(error).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:12:36.408688
# Unit test for method map of class Task
def test_Task_map():
    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_five(x):
        return x + 5

    def add_seven(x):
        return x + 7

    def add_nine(x):
        return x + 9

    def add_eleven(x):
        return x + 11

    def add_thirteen(x):
        return x + 13

    def add_fifteen(x):
        return x + 15

    def add_seventeen(x):
        return x + 17

    def add_nineteen(x):
        return x + 19

    def add_twenty_one(x):
        return x + 21

    def add_twenty_three(x):
        return x + 23


# Generated at 2022-06-18 02:12:42.049819
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-18 02:12:46.269381
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:12:54.485483
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:03.400374
# Unit test for method map of class Task
def test_Task_map():
    def add(a):
        return a + 1

    def sub(a):
        return a - 1

    def mul(a):
        return a * 2

    def div(a):
        return a / 2

    assert Task.of(1).map(add).fork(lambda _: None, lambda arg: arg) == 2
    assert Task.of(1).map(sub).fork(lambda _: None, lambda arg: arg) == 0
    assert Task.of(1).map(mul).fork(lambda _: None, lambda arg: arg) == 2
    assert Task.of(1).map(div).fork(lambda _: None, lambda arg: arg) == 0.5


# Generated at 2022-06-18 02:13:12.656463
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4

# Generated at 2022-06-18 02:14:55.532063
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def add_one(x):
            return x + 1

        task = Task.of(1)
        task = task.map(add_one)
        assert task.fork(lambda x: x, lambda x: x) == 2

    def test_map_reject():
        def add_one(x):
            return x + 1

        task = Task.reject(1)
        task = task.map(add_one)
        assert task.fork(lambda x: x, lambda x: x) == 1

    test_map_resolve()
    test_map_reject()


# Generated at 2022-06-18 02:15:02.252229
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:15:11.528656
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        return Task.of(value)

    def reject(value):
        return Task.reject(value)

    def test_resolve(value):
        return Task.of(value)

    def test_reject(value):
        return Task.reject(value)

    def test_resolve_reject(value):
        return Task.reject(value)

    def test_reject_resolve(value):
        return Task.of(value)

    def test_reject_reject(value):
        return Task.reject(value)

    def test_resolve_resolve(value):
        return Task.of(value)

    def test_resolve_resolve_resolve(value):
        return Task.of(value)


# Generated at 2022-06-18 02:15:18.461780
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_map(value):
        """
        Test for method map of class Task.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-18 02:15:21.591290
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:15:25.822171
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test_add_mul_div_sub(x):
        return Task.of(x) \
            .bind(add) \
            .bind(mul) \
            .bind(div) \
            .bind(sub)

    assert test_add_mul_div_sub(1).fork(lambda x: x, lambda x: x) == 1
    assert test_add_mul_div_sub(2).fork(lambda x: x, lambda x: x) == 2
    assert test_add_mul_

# Generated at 2022-06-18 02:15:28.554822
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(test_fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:15:38.038435
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def multiply(x):
        return Task.of(x * 2)

    def divide(x):
        return Task.of(x / 2)

    def reject(x):
        return Task.reject(x)

    assert Task.of(2).bind(add).bind(multiply).bind(divide).fork(
        lambda x: x,
        lambda x: x
    ) == 3

    assert Task.of(2).bind(add).bind(multiply).bind(divide).bind(reject).fork(
        lambda x: x,
        lambda x: x
    ) == 2


# Generated at 2022-06-18 02:15:47.305580
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:15:51.820417
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2
