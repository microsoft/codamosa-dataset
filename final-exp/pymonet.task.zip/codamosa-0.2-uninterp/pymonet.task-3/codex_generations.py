

# Generated at 2022-06-18 02:06:19.030143
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:06:22.168123
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    task = task.map(fn)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:26.019928
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:36.913620
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def pow(x):
        return x ** 2

    def mod(x):
        return x % 2

    def concat(x):
        return str(x) + '1'

    def to_int(x):
        return int(x)

    def to_float(x):
        return float(x)

    def to_str(x):
        return str(x)

    def to_bool(x):
        return bool(x)

    def to_list(x):
        return [x]

    def to_tuple(x):
        return (x, )


# Generated at 2022-06-18 02:06:43.744715
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_function(value):
        """
        Test function for map method.
        """
        return value + 1

    def test_function_with_error(value):
        """
        Test function for map method.
        """
        raise Exception('error')

    def test_function_with_error_in_fork(value):
        """
        Test function for map method.
        """
        raise Exception('error')

    def test_function_with_error_in_fork_and_map(value):
        """
        Test function for map method.
        """
        raise Exception('error')

    def test_function_with_error_in_fork_and_map_and_reject(value):
        """
        Test function for map method.
        """


# Generated at 2022-06-18 02:06:53.246217
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add(value):
        return value + 1

    def sub(value):
        return value - 1

    def mul(value):
        return value * 2

    def div(value):
        return value / 2

    assert Task.of(1).map(add).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(sub).fork(lambda _: None, lambda value: value) == 0
    assert Task.of(1).map(mul).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(div).fork(lambda _: None, lambda value: value) == 0.5


# Generated at 2022-06-18 02:06:58.518743
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: False, lambda value: value == 2)


# Generated at 2022-06-18 02:07:03.508456
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:12.489230
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test_add_mul_div_sub(x):
        return Task.of(x) \
            .bind(add) \
            .bind(mul) \
            .bind(div) \
            .bind(sub)

    assert test_add_mul_div_sub(1).fork(lambda x: x, lambda x: x) == 2
    assert test_add_mul_div_sub(2).fork(lambda x: x, lambda x: x) == 3
    assert test_add_mul_

# Generated at 2022-06-18 02:07:22.039292
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:27.317629
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    task = Task.of(1)
    assert task.map(add_one).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:07:31.459514
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:35.891156
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:44.674584
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:46.779702
# Unit test for method map of class Task
def test_Task_map():
    def add_one(arg):
        return arg + 1

    task = Task.of(1)
    assert task.map(add_one).fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-18 02:07:56.300905
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:00.587516
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2

    task = Task.reject(1)
    assert task.bind(fn).fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:08:09.985993
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fork_reject(reject, resolve):
        reject(1)

    def fork_reject_2(reject, resolve):
        reject(2)

    def fork_resolve_2(reject, resolve):
        resolve(2)

    def fork_resolve_3(reject, resolve):
        resolve(3)

    def fork_resolve_4(reject, resolve):
        resolve(4)

    def fork_resolve_5(reject, resolve):
        resolve(5)

    def fork_resolve_6(reject, resolve):
        resolve(6)

    def fork_resolve_7(reject, resolve):
        resolve(7)

    def fork_resolve_8(reject, resolve):
        resolve

# Generated at 2022-06-18 02:08:13.046355
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:21.905802
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add(value):
        return value + 1

    def sub(value):
        return value - 1

    def mul(value):
        return value * 2

    def div(value):
        return value / 2

    def identity(value):
        return value

    def test_map(value, fn):
        """
        Test for method map of class Task.

        :param value: value to store in Task
        :type value: A
        :param fn: mapper function
        :type fn: Function(value) -> B
        :returns: result of calling fork function
        :rtype: B
        """
        return Task.of(value).map(fn).fork(identity, identity)

    assert test_map(1, add) == 2
    assert test

# Generated at 2022-06-18 02:08:30.768568
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:39.765254
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:47.487165
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).bind(add).bind(mul).bind(div).bind(error).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-18 02:08:51.706370
# Unit test for method map of class Task
def test_Task_map():
    def test_mapper(value):
        return value + 1

    def test_fork(reject, resolve):
        return resolve(1)

    task = Task(test_fork)
    mapped_task = task.map(test_mapper)
    assert mapped_task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:02.054583
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a, b):
        return a + b

    def add_task(a):
        return Task.of(add(a, 1))

    def add_task_reject(a):
        return Task.reject(add(a, 1))

    def add_task_reject_reject(a):
        return Task.reject(add(a, 1)).bind(add_task_reject)

    def add_task_reject_resolve(a):
        return Task.reject(add(a, 1)).bind(add_task)

    def add_task_resolve_reject(a):
        return Task.of(add(a, 1)).bind(add_task_reject)


# Generated at 2022-06-18 02:09:10.644012
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:09:12.592901
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:18.044957
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2

    task = Task.reject(1).bind(fn)
    assert task.fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:09:25.607127
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def add_one(value):
            return value + 1

        def resolve(value):
            assert value == 2

        task = Task.of(1)
        task.map(add_one).fork(lambda _: None, resolve)

    def test_map_reject():
        def add_one(value):
            return value + 1

        def reject(value):
            assert value == 1

        task = Task.reject(1)
        task.map(add_one).fork(reject, lambda _: None)

    test_map_resolve()
    test_map_reject()


# Generated at 2022-06-18 02:09:36.401845
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:54.075769
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1



# Generated at 2022-06-18 02:10:05.705226
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def err(x):
        raise Exception(x)

    assert Task.of(1).map(add).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(sub).fork(lambda x: x, lambda x: x) == 0
    assert Task.of(1).map(mul).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(div).fork(lambda x: x, lambda x: x) == 0.5

# Generated at 2022-06-18 02:10:09.850766
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-18 02:10:16.773444
# Unit test for method map of class Task
def test_Task_map():
    def get_value(value):
        return value

    def get_value_plus_one(value):
        return value + 1

    def get_value_plus_two(value):
        return value + 2

    assert Task.of(1).map(get_value) == Task.of(1)
    assert Task.of(1).map(get_value_plus_one) == Task.of(2)
    assert Task.of(1).map(get_value_plus_one).map(get_value_plus_two) == Task.of(3)


# Generated at 2022-06-18 02:10:20.423349
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2



# Generated at 2022-06-18 02:10:24.897782
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    task_mapped = task.map(mapper)

    assert task_mapped.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:28.096255
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:37.571635
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    assert Task.of(1).bind(add_one).bind(add_two).bind(add_three).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 7

    assert Task.of(1).bind(add_one).bind(add_two).bind(add_three).bind(lambda value: Task.reject(value)).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 7


# Generated at 2022-06-18 02:10:45.711196
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def fn(value):
            return value + 1

        task = Task.of(1)
        task = task.map(fn)

        assert task.fork(lambda _: None, lambda value: value) == 2

    def test_map_reject():
        def fn(value):
            return value + 1

        task = Task.reject(1)
        task = task.map(fn)

        assert task.fork(lambda value: value, lambda _: None) == 1

    test_map_resolve()
    test_map_reject()


# Generated at 2022-06-18 02:10:48.911074
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:14.445472
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2

    task = Task.reject(1).bind(fn)
    assert task.fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:11:24.158426
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:11:26.221513
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:34.747754
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:44.797311
# Unit test for method map of class Task
def test_Task_map():
    def test_map_with_resolve():
        def mapper(value):
            return value + 1

        def fork(reject, resolve):
            return resolve(1)

        task = Task(fork)
        result = task.map(mapper)
        assert result.fork(lambda _: None, lambda value: value) == 2

    def test_map_with_reject():
        def mapper(value):
            return value + 1

        def fork(reject, resolve):
            return reject(1)

        task = Task(fork)
        result = task.map(mapper)
        assert result.fork(lambda value: value, lambda _: None) == 1

    test_map_with_resolve()
    test_map_with_reject()


# Generated at 2022-06-18 02:11:55.338154
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

   

# Generated at 2022-06-18 02:12:01.557480
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:07.680709
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    task = task.bind(lambda x: Task.of(x + 1))
    assert task.fork(lambda x: x, lambda x: x) == 2

    def fork(reject, resolve):
        return reject(1)

    task = Task(fork)
    task = task.bind(lambda x: Task.of(x + 1))
    assert task.fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-18 02:12:16.977853
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def identity(x):
        return x

    def identity_task(x):
        return Task.of(x)

    def identity_task_reject(x):
        return Task.reject(x)

    def identity_task_reject_map(x):
        return Task.reject(x).map(identity)

    def identity_task_reject_bind(x):
        return Task.reject(x).bind(identity_task)

    def identity_task_reject_bind_reject(x):
        return Task.reject(x).bind(identity_task_reject)

# Generated at 2022-06-18 02:12:21.602461
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    def sub(x):
        return x - 1

    assert Task.of(1).map(add).fork(None, lambda x: x) == 2
    assert Task.of(1).map(mul).fork(None, lambda x: x) == 2
    assert Task.of(1).map(sub).fork(None, lambda x: x) == 0


# Generated at 2022-06-18 02:13:14.304201
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:18.581002
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:22.671703
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fn(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:32.248792
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:35.065669
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:38.593952
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:13:47.076797
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:13:56.227187
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:13:59.411627
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: False, lambda arg: arg == 2)


# Generated at 2022-06-18 02:14:03.875977
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:16:11.733417
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   