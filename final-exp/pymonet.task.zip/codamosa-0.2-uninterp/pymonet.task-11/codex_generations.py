

# Generated at 2022-06-18 02:06:13.912681
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def fn(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(fn)

    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:17.829498
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.map(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:26.333722
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    def sub(x):
        return x - 1

    def div(x):
        return x / 2

    assert Task.of(1).map(add).map(mul).map(sub).map(div).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 0.5

    assert Task.of(1).map(add).map(mul).map(sub).map(div).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 0.5

    assert Task.of(1).map(add).map(mul).map(sub).map(div).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 0.5

    assert Task

# Generated at 2022-06-18 02:06:37.266759
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        return Task.of(value)

    def reject(value):
        return Task.reject(value)

    def fork(reject, resolve):
        return resolve(1)

    def fork_reject(reject, resolve):
        return reject(1)

    def fork_reject_reject(reject, resolve):
        return reject(reject(1))

    def fork_resolve_reject(reject, resolve):
        return resolve(reject(1))

    def fork_resolve_resolve(reject, resolve):
        return resolve(resolve(1))

    def fork_reject_resolve(reject, resolve):
        return reject(resolve(1))


# Generated at 2022-06-18 02:06:41.395780
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:45.257817
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)

    assert task.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:06:51.184424
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:06:57.804241
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:07:08.592211
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:10.593335
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    task = Task.of(1)
    assert task.map(add_one).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:07:17.518022
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:22.430729
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    def test_function(value):
        """
        Test function

        :param value: value to store in Task
        :type value: A
        :returns: Task with stored value
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value)

    assert Task.of(1).bind(test_function).fork(lambda arg: arg, lambda arg: arg) == 1
    assert Task.of(1).bind(lambda arg: Task.reject(arg)).fork(lambda arg: arg, lambda arg: arg) == 1
    assert Task.reject(1).bind(test_function).fork(lambda arg: arg, lambda arg: arg) == 1

# Generated at 2022-06-18 02:07:25.106069
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    assert Task.of(1).map(fn).fork(None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:35.175184
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    def test_bind(x):
        return Task.of(x) \
            .bind(add) \
            .bind(mul) \
            .bind(div) \
            .bind(sub)

    assert test_bind(1).fork(lambda x: x, lambda x: x) == 1
    assert test_bind(2).fork(lambda x: x, lambda x: x) == 2

# Generated at 2022-06-18 02:07:44.130120
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:50.131572
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:07:54.146511
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:01.709660
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:08.764980
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve(resolve, reject):
        resolve(1)

    def test_map_reject(resolve, reject):
        reject(1)

    def test_map_fn(value):
        return value + 1


# Generated at 2022-06-18 02:08:13.083120
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: False, lambda arg: arg == 2)


# Generated at 2022-06-18 02:08:21.583517
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:26.055656
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:34.429973
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:08:38.122017
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(2)

    def mapper(value):
        return Task.of(value * 2)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:08:47.449459
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:56.915377
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test_add(x):
        return Task.of(x + 1)

    def test_mul(x):
        return Task.of(x * 2)

    def test_div(x):
        return Task.of(x / 2)

    def test_sub(x):
        return Task.of(x - 1)

    def test_add_mul(x):
        return test_add(x).bind(test_mul)


# Generated at 2022-06-18 02:09:06.555145
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def mapper(value):
            return value * 2

        def fork(reject, resolve):
            resolve(2)

        task = Task(fork)
        result = task.map(mapper)
        assert result.fork(lambda _: None, lambda value: value) == 4

    def test_map_reject():
        def mapper(value):
            return value * 2

        def fork(reject, resolve):
            reject(2)

        task = Task(fork)
        result = task.map(mapper)
        assert result.fork(lambda value: value, lambda _: None) == 2

    test_map_resolve()
    test_map_reject()


# Generated at 2022-06-18 02:09:12.201922
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def add_one(value):
            return value + 1

        def fork(reject, resolve):
            resolve(1)

        task = Task(fork)
        task = task.map(add_one)
        assert task.fork(lambda _: None, lambda value: value) == 2

    def test_map_reject():
        def add_one(value):
            return value + 1

        def fork(reject, resolve):
            reject(1)

        task = Task(fork)
        task = task.map(add_one)
        assert task.fork(lambda value: value, lambda _: None) == 1

    test_map_resolve()
    test_map_reject()


# Generated at 2022-06-18 02:09:15.600552
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task.of(1).map(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:19.598904
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: False, lambda value: value == 2)


# Generated at 2022-06-18 02:09:41.543392
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(lambda x: x, lambda x: x) == 1
    assert Task.of(1).bind(add).bind(error).bind(div).bind(sub).fork(lambda x: x, lambda x: x) == 2

# Generated at 2022-06-18 02:09:44.118935
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:54.608102
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    assert Task.of(1).map(add_one).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda x: x, lambda x: x) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda x: x, lambda x: x) == 4

# Generated at 2022-06-18 02:09:59.193780
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:08.775775
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

   

# Generated at 2022-06-18 02:10:18.341681
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.
    """
    def test_map_resolve():
        """
        Test for Task.map method with resolve value.
        """
        def resolve(value):
            """
            Resolve function for Task.
            """
            assert value == 2

        def reject(_):
            """
            Reject function for Task.
            """
            assert False

        Task.of(1).map(lambda arg: arg + 1).fork(reject, resolve)

    def test_map_reject():
        """
        Test for Task.map method with reject value.
        """
        def resolve(_):
            """
            Resolve function for Task.
            """
            assert False

        def reject(value):
            """
            Reject function for Task.
            """
            assert value == 1

        Task

# Generated at 2022-06-18 02:10:27.716445
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_reject(reject, resolve):
        return reject('reject')

    def test_resolve(reject, resolve):
        return resolve('resolve')

    def test_resolve_map(value):
        return value + '_map'

    def test_resolve_bind(value):
        return Task.of(value + '_bind')

    def test_reject_map(value):
        return value + '_map'

    def test_reject_bind(value):
        return Task.of(value + '_bind')

    assert Task(test_reject).bind(test_reject_bind).fork(
        lambda value: value,
        lambda value: 'resolve'
    ) == 'reject'


# Generated at 2022-06-18 02:10:32.763556
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_function(value):
        """
        Test function for method bind of class Task.
        """
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:37.731393
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)

    def fork_mapper(reject, resolve):
        resolve(2)

    assert task.fork == fork_mapper


# Generated at 2022-06-18 02:10:47.720040
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

   

# Generated at 2022-06-18 02:11:12.067941
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    task = Task.of(1)
    assert task.map(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:16.642577
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    def reject(value):
        return Task.reject(value)

    assert Task.of(1).bind(mapper).fork(reject, lambda value: value) == 2
    assert Task.of(1).bind(reject).fork(lambda value: value, mapper) == 1


# Generated at 2022-06-18 02:11:20.256254
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2

# Generated at 2022-06-18 02:11:29.545976
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:37.025174
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    def mul(a, b):
        return a * b

    def div(a, b):
        return a / b

    def sub(a, b):
        return a - b

    def test_add(a, b):
        return Task.of(add(a, b))

    def test_mul(a, b):
        return Task.of(mul(a, b))

    def test_div(a, b):
        return Task.of(div(a, b))

    def test_sub(a, b):
        return Task.of(sub(a, b))

    def test_add_mul(a, b):
        return test_add(a, b).map(lambda c: mul(c, b))


# Generated at 2022-06-18 02:11:40.876197
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:51.394924
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2


# Generated at 2022-06-18 02:12:00.821510
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:05.787490
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    assert Task.of(1).bind(add_one).bind(add_two).bind(add_three).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 7

# Generated at 2022-06-18 02:12:13.372906
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve(resolve, reject):
        resolve(1)

    def test_map_reject(resolve, reject):
        reject(1)

    def test_map_fn(value):
        return value + 1

    task_resolve = Task(test_map_resolve)
    task_reject = Task(test_map_reject)

    assert task_resolve.map(test_map_fn).fork(lambda arg: arg, lambda arg: arg) == 2
    assert task_reject.map(test_map_fn).fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-18 02:13:13.458720
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:23.095583
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def err(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(err).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:13:27.040195
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:35.463189
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:43.236349
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of class Task.
    """
    def test_case(value):
        """
        Test case for map method.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_case(1).fork(lambda _: False, lambda arg: arg == 2)


# Generated at 2022-06-18 02:13:46.177316
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:55.461063
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:57.848640
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-18 02:14:02.488369
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def reject(x):
        return x

    def resolve(x):
        return x

    task = Task(lambda reject, resolve: resolve(1))
    assert task.map(add).fork(reject, resolve) == 2


# Generated at 2022-06-18 02:14:11.022724
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10
