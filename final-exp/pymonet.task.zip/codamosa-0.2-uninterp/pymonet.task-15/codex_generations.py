

# Generated at 2022-06-18 02:06:18.911970
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:22.328098
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:26.688678
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Task.of(1).map(add).map(add_two).map(add_three).fork(
        lambda x: x,
        lambda x: x
    ) == 7


# Generated at 2022-06-18 02:06:31.923140
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:35.354949
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:06:41.731194
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:52.226317
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:05.119418
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:09.765087
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(error).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:07:13.078158
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:19.189364
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:07:25.329294
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case(value):
        def fn(arg):
            return Task.of(arg + value)

        return Task.of(value).bind(fn)

    assert test_case(1).fork(lambda arg: arg, lambda arg: arg) == 2
    assert test_case(2).fork(lambda arg: arg, lambda arg: arg) == 4
    assert test_case(3).fork(lambda arg: arg, lambda arg: arg) == 6


# Generated at 2022-06-18 02:07:35.407698
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:07:38.513262
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:42.377385
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:46.070081
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:50.480903
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:54.438602
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: False, lambda x: x == 2)
    assert Task.reject(1).bind(fn).fork(lambda x: x == 1, lambda _: False)


# Generated at 2022-06-18 02:08:01.896538
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        return Task.of(value)

    def reject(value):
        return Task.reject(value)

    def test_resolve(value):
        return resolve(value)

    def test_reject(value):
        return reject(value)

    assert Task.of(1).bind(test_resolve).fork(lambda x: x, lambda x: x) == 1
    assert Task.of(1).bind(test_reject).fork(lambda x: x, lambda x: x) == 1
    assert Task.reject(1).bind(test_resolve).fork(lambda x: x, lambda x: x) == 1
    assert Task.reject(1).bind(test_reject).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-18 02:08:10.630038
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def sub(x):
        return x - 1

    def identity(x):
        return x

    def add_mul(x):
        return add(mul(x))

    def add_mul_div(x):
        return add(mul(div(x)))

    def add_mul_div_sub(x):
        return add(mul(div(sub(x))))

    def add_mul_div_sub_identity(x):
        return add(mul(div(sub(identity(x)))))


# Generated at 2022-06-18 02:08:17.988920
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:24.581523
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def fail(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(fail).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:08:29.502680
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:38.716342
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:08:48.030225
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fork_reject(reject, resolve):
        reject(1)

    def fork_reject_2(reject, resolve):
        reject(2)

    def fork_resolve_2(reject, resolve):
        resolve(2)

    def fork_resolve_3(reject, resolve):
        resolve(3)

    def fork_resolve_4(reject, resolve):
        resolve(4)

    def fork_resolve_5(reject, resolve):
        resolve(5)

    def fork_resolve_6(reject, resolve):
        resolve(6)

    def fork_resolve_7(reject, resolve):
        resolve(7)

    def fork_resolve_8(reject, resolve):
        resolve

# Generated at 2022-06-18 02:08:57.219018
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:09:06.511954
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add(value):
        return value + 1

    def sub(value):
        return value - 1

    def mul(value):
        return value * 2

    def div(value):
        return value / 2

    def identity(value):
        return value

    assert Task.of(1).map(add).fork(identity, identity) == 2
    assert Task.of(1).map(sub).fork(identity, identity) == 0
    assert Task.of(1).map(mul).fork(identity, identity) == 2
    assert Task.of(1).map(div).fork(identity, identity) == 0.5


# Generated at 2022-06-18 02:09:11.283014
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a, b):
        return a + b

    def add_task(a):
        return Task.of(add(a, 1))

    def add_task_with_error(a):
        if a == 1:
            return Task.reject(a)
        return Task.of(add(a, 1))

    assert Task.of(1).bind(add_task).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).bind(add_task_with_error).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-18 02:09:20.871175
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:09:28.907382
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:09:41.930003
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:45.376634
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    task = Task.of(1)
    assert task.map(add).fork(lambda _: None, lambda x: x) == 2
    assert task.map(sub).fork(lambda _: None, lambda x: x) == 0


# Generated at 2022-06-18 02:09:55.726287
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda x: x) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda x: x) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda x: x) == 4

# Generated at 2022-06-18 02:10:06.400538
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:11.341831
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    def fn(value):
        return value * 2

    def fork(reject, resolve):
        return resolve(2)

    task = Task(fork)
    assert task.map(fn).fork(lambda _: None, lambda arg: arg) == 4


# Generated at 2022-06-18 02:10:15.378556
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:19.893939
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:10:23.142760
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:27.765873
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_fn(value):
        """
        Test function for method bind of class Task.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value)

    assert Task.of(1).bind(test_fn).fork(lambda _: None, lambda value: value) == 1
    assert Task.reject(1).bind(test_fn).fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:10:32.806716
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    def test_function(value):
        return Task.of(value + 1)

    task = Task.of(1)
    new_task = task.bind(test_function)
    assert new_task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:57.550820
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:59.629601
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    task = task.bind(lambda x: Task.of(x + 1))
    assert task.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:11:08.268895
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:11.932097
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:15.087602
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    task = Task.of(1)
    assert task.map(add_one).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:11:22.899036
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return value

    def reject(value):
        return value

    def add(value):
        return value + 1

    def add_task(value):
        return Task.of(value + 1)

    assert Task.of(1).map(add)(reject, resolve) == 2
    assert Task.reject(1).map(add)(reject, resolve) == 1
    assert Task.of(1).bind(add_task)(reject, resolve) == 2
    assert Task.reject(1).bind(add_task)(reject, resolve) == 1


# Generated at 2022-06-18 02:11:32.064653
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def sub(x):
        return Task.of(x - 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(sub).bind(mul).bind(div).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(sub).bind(mul).bind(error).fork(
        lambda x: x,
        lambda x: x
    ) == 2


# Generated at 2022-06-18 02:11:41.003325
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:11:44.988868
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:55.622199
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:50.886533
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test_add(x):
        return Task.of(x + 1)

    def test_mul(x):
        return Task.of(x * 2)

    def test_div(x):
        return Task.of(x / 2)

    def test_sub(x):
        return Task.of(x - 1)

    def test_add_mul(x):
        return test_add(x).bind(test_mul)

    def test_add_mul_div(x):
        return test_

# Generated at 2022-06-18 02:12:53.596645
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:12:56.217651
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    assert Task.of(1).map(fn).fork(lambda _: False, lambda value: value == 2)


# Generated at 2022-06-18 02:13:06.617287
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:14.826023
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(error).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2


# Generated at 2022-06-18 02:13:19.110826
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(2)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 3


# Generated at 2022-06-18 02:13:24.017607
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            return resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: False, lambda value: value == 2)


# Generated at 2022-06-18 02:13:33.277034
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:44.289715
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:13:53.879022
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:16:00.775684
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:16:03.206294
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task.of(1)
    assert task.map(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:16:05.682806
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:16:08.421070
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:16:14.228629
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_function(value):
        """
        Test function for Task.bind method.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value)

    assert Task.of(1).bind(test_function).fork(lambda _: False, lambda arg: arg == 1)
    assert Task.reject(1).bind(test_function).fork(lambda arg: arg == 1, lambda _: False)
