

# Generated at 2022-06-18 02:06:21.160398
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:28.755383
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a):
        return Task.of(a + 1)

    def mul(a):
        return Task.of(a * 2)

    def div(a):
        return Task.of(a / 2)

    def sub(a):
        return Task.of(a - 1)

    def reject(a):
        return Task.reject(a)

    def test_bind_with_resolved_task():
        assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(None, lambda a: a) == 1

    def test_bind_with_rejected_task():
        assert Task.of(1).bind(add).bind(mul).bind(reject).bind(sub).fork(lambda a: a, None) == 2

    test_bind_with_

# Generated at 2022-06-18 02:06:39.822959
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(error).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:06:52.264147
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8

    def add_nine(a):
        return a + 9

    def add_ten(a):
        return a + 10

    def add_eleven(a):
        return a + 11

    def add_twelve(a):
        return a + 12


# Generated at 2022-06-18 02:07:04.058857
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    assert Task.of(1).map(add).map(mul).map(div).fork(None, lambda x: x) == 1.5
    assert Task.of(1).map(add).map(mul).map(div).map(sub).fork(None, lambda x: x) == 0.5
    assert Task.of(1).map(add).map(mul).map(div).map(sub).map(add).fork(None, lambda x: x) == 1.5


# Generated at 2022-06-18 02:07:07.877562
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    task = task.bind(lambda arg: Task.of(arg + 1))
    assert task.fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-18 02:07:11.954394
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_function(value):
        """
        Function for test.
        """
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(
        lambda _: False,
        lambda arg: arg == 2
    )


# Generated at 2022-06-18 02:07:15.715934
# Unit test for method map of class Task
def test_Task_map():
    def test_resolve(value):
        assert value == 2

    def test_reject(value):
        assert False

    Task.of(1).map(lambda x: x + 1).fork(test_reject, test_resolve)


# Generated at 2022-06-18 02:07:25.192352
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:07:34.652727
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 2

    assert Task.of(1).map(add_one).map(add_two).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 3

    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 4


# Generated at 2022-06-18 02:07:41.320709
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fn(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:51.219758
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:54.014424
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:00.394504
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda x: x, lambda x: x) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-18 02:08:09.950181
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def fail(x):
        raise Exception('fail')

    def test_map(task, fn):
        return task.map(fn).fork(lambda x: x, lambda x: x)

    assert test_map(Task.of(1), add) == 2
    assert test_map(Task.of(1), sub) == 0
    assert test_map(Task.of(1), mul) == 2
    assert test_map(Task.of(1), div) == 0.5
    assert test_map(Task.reject(1), add) == 1

# Generated at 2022-06-18 02:08:15.193310
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def fn(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    result = task.map(fn)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:17.687313
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:08:21.307726
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:32.157107
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_map_resolve(resolve, reject):
        """
        Test for method map of class Task.
        """
        resolve(1)

    def test_map_reject(resolve, reject):
        """
        Test for method map of class Task.
        """
        reject(1)

    def test_map_resolve_map(value):
        """
        Test for method map of class Task.
        """
        return value + 1

    def test_map_reject_map(value):
        """
        Test for method map of class Task.
        """
        return value + 1

    def test_map_resolve_bind(value):
        """
        Test for method map of class Task.
        """

# Generated at 2022-06-18 02:08:40.173272
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    assert Task.of(1).bind(add_one).bind(add_two).bind(add_three).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 7

    assert Task.of(1).bind(add_one).bind(add_two).bind(add_three).bind(
        lambda arg: Task.reject(arg)
    ).fork(
        lambda arg: arg,
        lambda arg: None
    ) == 7


# Generated at 2022-06-18 02:08:51.271887
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:01.582060
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12


# Generated at 2022-06-18 02:09:10.400472
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:13.735697
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    def test_function(value):
        """
        Test function for method map of class Task

        :param value: value to test
        :type value: int
        :returns: value + 1
        :rtype: int
        """
        return value + 1

    assert Task.of(1).map(test_function).fork(lambda _: False, lambda value: value == 2)


# Generated at 2022-06-18 02:09:22.290978
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:09:26.834341
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    task = Task.of(1)
    assert task.map(add_one).fork(None, lambda value: value) == 2
    assert task.map(add_two).fork(None, lambda value: value) == 3


# Generated at 2022-06-18 02:09:32.783245
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    task = Task.of(1)
    assert task.map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert task.map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3


# Generated at 2022-06-18 02:09:43.475202
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:46.996938
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:56.728461
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:16.316212
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:10:24.605951
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:35.379625
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:43.382988
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test_bind(x):
        return Task.of(x) \
            .bind(add) \
            .bind(mul) \
            .bind(div) \
            .bind(sub)

    assert test_bind(2).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:10:51.409744
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fork_reject(reject, resolve):
        reject(1)

    def fork_mapper(reject, resolve):
        resolve(2)

    def fork_mapper_reject(reject, resolve):
        reject(2)

    def mapper(value):
        return Task(fork_mapper)

    def mapper_reject(value):
        return Task(fork_mapper_reject)

    assert Task(fork).bind(mapper).fork(lambda arg: arg, lambda arg: arg) == 2
    assert Task(fork).bind(mapper_reject).fork(lambda arg: arg, lambda arg: arg) == 2
    assert Task(fork_reject).bind(mapper).fork(lambda arg: arg, lambda arg: arg)

# Generated at 2022-06-18 02:11:02.934975
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test_add_mul_div_sub(x):
        return Task.of(x) \
            .bind(add) \
            .bind(mul) \
            .bind(div) \
            .bind(sub)

    assert test_add_mul_div_sub(1).fork(lambda x: x, lambda x: x) == 1.5
    assert test_add_mul_div_sub(2).fork(lambda x: x, lambda x: x) == 2.5
    assert test_add

# Generated at 2022-06-18 02:11:07.387307
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-18 02:11:13.094212
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case(value):
        return Task.of(value).bind(lambda arg: Task.of(arg + 1))

    assert test_case(1).fork(lambda _: None, lambda arg: arg) == 2
    assert test_case(2).fork(lambda _: None, lambda arg: arg) == 3
    assert test_case(3).fork(lambda _: None, lambda arg: arg) == 4


# Generated at 2022-06-18 02:11:18.300752
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_function(value):
        """
        Test function for method bind of class Task.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value)

    assert Task.of(1).bind(test_function).fork(lambda _: None, lambda value: value) == 1


# Generated at 2022-06-18 02:11:27.680566
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:50.649914
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:11:53.812394
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:56.382405
# Unit test for method map of class Task
def test_Task_map():
    def test(value):
        return value + 1

    assert Task.of(1).map(test).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:12:02.401360
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:05.935618
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:12:15.300039
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:12:23.050212
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def err(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(err).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:12:26.210888
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:12:28.471042
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    task = task.map(mapper)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:12:35.885567
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def sub(x):
        return Task.of(x - 1)

    def div(x):
        return Task.of(x / 2)

    def test_add(x):
        return Task.of(x).bind(add).bind(add).bind(add)

    def test_mul(x):
        return Task.of(x).bind(mul).bind(mul).bind(mul)

    def test_sub(x):
        return Task.of(x).bind(sub).bind(sub).bind(sub)

    def test_div(x):
        return Task.of(x).bind(div).bind(div).bind(div)


# Generated at 2022-06-18 02:13:27.895166
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    task = Task.of(1)
    assert task.map(add_one).fork(None, lambda value: value) == 2
    assert task.map(add_two).fork(None, lambda value: value) == 3
    assert task.map(add_three).fork(None, lambda value: value) == 4


# Generated at 2022-06-18 02:13:36.024654
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:13:45.677055
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def fork_reject(reject, resolve):
        return reject(1)

    def fork_reject_2(reject, resolve):
        return reject(2)

    def fork_resolve_2(reject, resolve):
        return resolve(2)

    def fork_resolve_3(reject, resolve):
        return resolve(3)

    def fork_resolve_4(reject, resolve):
        return resolve(4)

    def fork_resolve_5(reject, resolve):
        return resolve(5)

    def fork_resolve_6(reject, resolve):
        return resolve(6)

    def fork_resolve_7(reject, resolve):
        return resolve(7)


# Generated at 2022-06-18 02:13:49.851234
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:53.605162
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: False, lambda arg: arg == 2)



# Generated at 2022-06-18 02:13:56.791368
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    result = task.bind(fn)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:59.188279
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda x: x + 1)

    assert test_map(1).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:14:04.250059
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-18 02:14:12.342967
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test_bind(x):
        return Task.of(x) \
            .bind(add) \
            .bind(mul) \
            .bind(div) \
            .bind(sub)

    assert test_bind(1).fork(lambda x: x, lambda x: x) == 1
    assert test_bind(2).fork(lambda x: x, lambda x: x) == 2
    assert test_bind(3).fork(lambda x: x, lambda x: x) == 3

# Generated at 2022-06-18 02:14:14.032424
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value * 2)

    task = Task.of(2)
    assert task.bind(fn).fork(lambda _: None, lambda arg: arg) == 4
