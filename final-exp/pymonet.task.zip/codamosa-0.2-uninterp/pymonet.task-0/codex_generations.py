

# Generated at 2022-06-18 02:06:17.095526
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def pow(x):
        return x ** 2

    def mod(x):
        return x % 2

    def concat(x):
        return x + '!'

    def upper(x):
        return x.upper()

    def lower(x):
        return x.lower()

    def reverse(x):
        return x[::-1]

    def sort(x):
        return sorted(x)

    def join(x):
        return ''.join(x)

    def split(x):
        return x.split(' ')


# Generated at 2022-06-18 02:06:20.809338
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:28.571250
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:39.679179
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4

# Generated at 2022-06-18 02:06:49.976360
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def identity(x):
        return x

    assert Task.of(1).map(add).fork(identity, identity) == 2
    assert Task.of(1).map(sub).fork(identity, identity) == 0
    assert Task.of(1).map(mul).fork(identity, identity) == 2
    assert Task.of(1).map(div).fork(identity, identity) == 0.5


# Generated at 2022-06-18 02:06:53.377637
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:57.803979
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:08.592015
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:07:10.782346
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:16.486533
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:07:28.614118
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:07:39.186349
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:46.808554
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def resolve(value):
        return Task.of(value)

    def reject(value):
        return Task.reject(value)

    def add(value):
        return value + 1

    def sub(value):
        return value - 1

    def mul(value):
        return value * 2

    def div(value):
        return value / 2

    def pow(value):
        return value ** 2

    def sqrt(value):
        return value ** 0.5

    def test_resolve(value):
        assert Task.of(value).bind(resolve).fork(reject, resolve).fork(reject, resolve).fork(reject, resolve) == Task.of(value)


# Generated at 2022-06-18 02:07:56.295109
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_value(value):
        return Task.of(value)

    def reject_value(value):
        return Task.reject(value)

    def resolve_value_with_error(value):
        return Task.of(value).bind(lambda _: reject_value(value))

    def reject_value_with_error(value):
        return Task.reject(value).bind(lambda _: resolve_value(value))

    assert Task.of(1).bind(resolve_value).fork(lambda _: False, lambda arg: arg == 1)
    assert Task.of(1).bind(reject_value).fork(lambda arg: arg == 1, lambda _: False)
    assert Task.reject(1).bind(resolve_value).fork(lambda arg: arg == 1, lambda _: False)

# Generated at 2022-06-18 02:08:05.863094
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:10.629636
# Unit test for method map of class Task
def test_Task_map():
    def test_map(fn, value, expected):
        task = Task.of(value)
        result = task.map(fn)
        assert result.fork(lambda _: None, lambda arg: arg) == expected

    test_map(lambda x: x + 1, 1, 2)
    test_map(lambda x: x * 2, 2, 4)
    test_map(lambda x: x - 1, 3, 2)


# Generated at 2022-06-18 02:08:19.793286
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:08:30.255685
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:39.329706
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    assert Task.of(1).bind(add_one).bind(add_two).bind(add_three).bind(add_four).fork(
        lambda _: None,
        lambda value: value
    ) == 11


# Generated at 2022-06-18 02:08:48.565557
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:03.519955
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:07.492960
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    mapped_task = task.map(fn)
    assert mapped_task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:09.847233
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:13.946391
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:17.127381
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:09:21.155109
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return value

    def reject(value):
        return value

    def mapper(value):
        return value + 1

    task = Task(lambda reject, resolve: resolve(1))
    assert task.fork(reject, resolve) == 1

    task = task.map(mapper)
    assert task.fork(reject, resolve) == 2


# Generated at 2022-06-18 02:09:29.135607
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).fork(lambda x: x, lambda x: x) == 1
    assert Task.of(1).bind(add).bind(error).bind(div).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).bind(add).bind(mul).bind(error).fork(lambda x: x, lambda x: x) == 3

# Generated at 2022-06-18 02:09:32.161438
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:37.741149
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:46.027690
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a):
        return Task.of(a + 1)

    def mul(a):
        return Task.of(a * 2)

    def div(a):
        return Task.of(a / 2)

    def sub(a):
        return Task.of(a - 1)

    def fail(a):
        return Task.reject(a)

    def test(a):
        return Task.of(a)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).bind(test).fork(
        lambda a: a,
        lambda a: a
    ) == 1


# Generated at 2022-06-18 02:10:06.389596
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def multiply(x):
        return x * 2

    def divide(x):
        return x / 2

    def subtract(x):
        return x - 1

    def test_map(x, y):
        return Task.of(x).map(add).map(multiply).map(divide).map(subtract).fork(
            lambda _: None,
            lambda arg: arg == y
        )

    assert test_map(1, 1)
    assert test_map(2, 2)
    assert test_map(3, 3)
    assert test_map(4, 4)
    assert test_map(5, 5)
    assert test_map(6, 6)
    assert test_map(7, 7)

# Generated at 2022-06-18 02:10:16.411951
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2


# Generated at 2022-06-18 02:10:20.458563
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fn(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:31.059059
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def double(x):
        return x * 2

    def triple(x):
        return x * 3

    def quadruple(x):
        return x * 4

    def quintuple(x):
        return x * 5

    def sextuple(x):
        return x * 6

    def septuple(x):
        return x * 7

    def octuple(x):
        return x * 8

    def nonuple(x):
        return x * 9

    def decuple(x):
        return x * 10

    def undecuple(x):
        return x * 11

    def duodecuple(x):
        return x * 12

    def tredecuple(x):
        return x * 13


# Generated at 2022-06-18 02:10:34.951246
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    def test_fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:38.702396
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def fn(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:43.465768
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:51.466187
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:02.638955
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).bind(add).bind(mul).bind(error).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).bind(add).bind(mul).bind(div).bind(error).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:11:10.116985
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def fn(value):
            return value + 1

        task = Task.of(1)
        result = task.map(fn)

        assert result.fork(None, lambda value: value) == 2

    def test_map_reject():
        def fn(value):
            return value + 1

        task = Task.reject(1)
        result = task.map(fn)

        assert result.fork(lambda value: value, None) == 1

    test_map_resolve()
    test_map_reject()


# Generated at 2022-06-18 02:11:32.478797
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:34.709559
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 1


# Generated at 2022-06-18 02:11:40.232171
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    task = Task.of(1)
    task = task.map(add_one)
    task = task.map(add_two)

    assert task.fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:11:43.448542
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:11:47.113696
# Unit test for method map of class Task
def test_Task_map():
    def add(value):
        return value + 1

    def sub(value):
        return value - 1

    def mul(value):
        return value * 2

    def div(value):
        return value / 2

    assert Task.of(1).map(add).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(2).map(sub).fork(lambda _: None, lambda value: value) == 1
    assert Task.of(2).map(mul).fork(lambda _: None, lambda value: value) == 4
    assert Task.of(4).map(div).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:55.337876
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test_add_mul_div_sub():
        return Task.of(1).bind(add).bind(mul).bind(div).bind(sub)

    assert test_add_mul_div_sub().fork(lambda x: x, lambda x: x) == 1



# Generated at 2022-06-18 02:12:01.523903
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def pow(x):
        return x ** 2

    def pow_add(x):
        return x ** 2 + 1

    def pow_sub(x):
        return x ** 2 - 1

    def pow_mul(x):
        return x ** 2 * 2

    def pow_div(x):
        return x ** 2 / 2

    def pow_pow(x):
        return x ** 2 ** 2

    def pow_pow_add(x):
        return x ** 2 ** 2 + 1

    def pow_pow_sub(x):
        return x ** 2 ** 2 - 1


# Generated at 2022-06-18 02:12:10.592621
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13


# Generated at 2022-06-18 02:12:19.425125
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:21.205932
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(test_fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:14.025446
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:23.928554
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        return Task.of(x + 1)

    def g(x):
        return Task.of(x * 2)

    def h(x):
        return Task.of(x - 1)

    def i(x):
        return Task.of(x / 2)

    def j(x):
        return Task.of(x ** 2)

    def k(x):
        return Task.of(x + 100)

    def l(x):
        return Task.of(x * 100)

    def m(x):
        return Task.of(x - 100)

    def n(x):
        return Task.of(x / 100)

    def o(x):
        return Task.of(x ** 100)

    def p(x):
        return Task.of(x + 1000)

   

# Generated at 2022-06-18 02:13:29.259413
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2

    task = Task.reject(1).bind(fn)
    assert task.fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:13:31.441608
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-18 02:13:35.109522
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    task_mapped = task.map(fn)
    assert task_mapped.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:37.595107
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    task = Task.of(1)
    assert task.map(add).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:13:43.979519
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    task = Task.of(1)
    assert task.map(add_one).fork(lambda _: None, lambda x: x) == 2
    assert task.map(add_two).fork(lambda _: None, lambda x: x) == 3


# Generated at 2022-06-18 02:13:47.509889
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    def add_one(a):
        return add(a, 1)

    task = Task.of(1)
    assert task.map(add_one).fork(None, lambda x: x) == 2


# Generated at 2022-06-18 02:13:52.171707
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    task = Task.of(1)
    assert task.map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert task.map(add_two).fork(lambda _: None, lambda value: value) == 3


# Generated at 2022-06-18 02:13:55.906500
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:16:00.241609
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def sub(x):
        return x - 1

    assert Task.of(1).map(add).map(mul).map(div).map(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).map(add).map(mul).map(div).map(sub).map(add).fork(
        lambda x: x,
        lambda x: x
    ) == 2


# Generated at 2022-06-18 02:16:03.510879
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:16:10.913032
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   