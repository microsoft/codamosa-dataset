

# Generated at 2022-06-18 02:06:22.924947
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:29.485087
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

   

# Generated at 2022-06-18 02:06:40.379701
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:06:44.885968
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task.of(1)
    assert task.map(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:49.856692
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    task = Task.of(1)
    assert task.map(add_one).fork(lambda _: None, lambda value: value) == 2

    task = Task.reject(1)
    assert task.map(add_one).fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:06:56.529750
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:07.473348
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)


# Generated at 2022-06-18 02:07:15.188403
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:24.454365
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:34.769630
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13


# Generated at 2022-06-18 02:07:40.516752
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda x: x + 1)

    assert test_map(1).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:07:43.757202
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:07:48.108968
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:52.622670
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def err(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(lambda x: x, lambda x: x) == 1
    assert Task.of(1).bind(add).bind(mul).bind(err).bind(sub).fork(lambda x: x, lambda x: x) == 2

# Generated at 2022-06-18 02:07:54.688281
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of Task class.
    """
    def test_fn(value):
        """
        Test function for map method.
        """
        return value + 1

    assert Task.of(1).map(test_fn).fork(None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:02.794562
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:08:09.841193
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:08:16.144934
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    task = Task.of(1)
    task = task.map(add_one)
    task = task.map(add_two)
    task = task.map(add_three)

    assert task.fork(lambda _: None, lambda value: value) == 7


# Generated at 2022-06-18 02:08:23.937280
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:29.147128
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:38.121879
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    def mapper(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.map(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:40.595292
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:45.490482
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    new_task = task.bind(mapper)
    assert new_task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:55.416072
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1

    assert Task.of(1).bind(add).bind(error).bind(div).bind(sub).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 2


# Generated at 2022-06-18 02:09:05.878968
# Unit test for method map of class Task
def test_Task_map():
    def test_Task_map_resolve():
        def add_one(x):
            return x + 1

        def test_Task_map_resolve_resolve(value):
            assert value == 2

        def test_Task_map_resolve_reject(value):
            assert False

        Task.of(1).map(add_one).fork(test_Task_map_resolve_reject, test_Task_map_resolve_resolve)

    def test_Task_map_reject():
        def add_one(x):
            return x + 1

        def test_Task_map_reject_resolve(value):
            assert False

        def test_Task_map_reject_reject(value):
            assert value == 1


# Generated at 2022-06-18 02:09:09.742730
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:18.719594
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_map(value):
        """
        Test for method map of class Task.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda _: False, lambda arg: arg == 2)
    assert test_map(2).fork(lambda _: False, lambda arg: arg == 3)
    assert test_map(3).fork(lambda _: False, lambda arg: arg == 4)


# Generated at 2022-06-18 02:09:27.170075
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:34.165748
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    assert Task.of(1).bind(add_one).bind(add_two).bind(add_three).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 7


# Generated at 2022-06-18 02:09:40.209508
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2

    task = Task.reject(1)
    assert task.bind(fn).fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:09:54.155424
# Unit test for method bind of class Task
def test_Task_bind():
    def test_bind(value):
        return Task.of(value)

    task = Task.of(1)
    assert task.bind(test_bind).fork(lambda _: None, lambda value: value) == 1


# Generated at 2022-06-18 02:09:58.165083
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    assert task.bind(lambda x: Task.of(x + 1)).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:10:07.614803
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = task.bind(mapper)

    def fork(reject, resolve):
        task.fork(reject, resolve)

    task = Task(fork)

    def fork(reject, resolve):
        task.fork(reject, resolve)

    task = Task(fork)

    def fork(reject, resolve):
        task.fork(reject, resolve)

    task = Task(fork)

    assert task.fork(None, lambda value: value) == 4


# Generated at 2022-06-18 02:10:12.282398
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:15.258656
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task.of(1)
    assert task.map(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:24.304481
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:35.286799
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def reject(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(reject).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2


# Generated at 2022-06-18 02:10:38.146837
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:10:43.870588
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3


# Generated at 2022-06-18 02:10:51.722270
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:19.203531
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_function(value):
        """
        Test function for Task.bind method.

        :param value: value to store in Task
        :type value: A
        :returns: new Task with stored value
        :rtype: Task[Function(resolve, reject -> A]
        """
        return Task.of(value)

    assert Task.of(1).bind(test_function).fork(lambda _: False, lambda arg: arg == 1)
    assert Task.of(1).bind(lambda arg: Task.of(arg + 1)).fork(lambda _: False, lambda arg: arg == 2)

# Generated at 2022-06-18 02:11:27.378029
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test_add_mul_div_sub(x):
        return Task.of(x) \
            .bind(add) \
            .bind(mul) \
            .bind(div) \
            .bind(sub)

    assert test_add_mul_div_sub(2).fork(lambda x: x, lambda x: x) == 2.5


# Generated at 2022-06-18 02:11:29.672431
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    task = Task.of(1)
    assert task.map(add_one).fork(None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:32.077842
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    task = Task.of(1).map(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:38.768256
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:49.392064
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def err(x):
        raise Exception(x)

    assert Task.of(1).map(add).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(sub).fork(lambda x: x, lambda x: x) == 0
    assert Task.of(1).map(mul).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(div).fork(lambda x: x, lambda x: x) == 0.5

# Generated at 2022-06-18 02:11:59.367432
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a):
        return Task.of(a + 1)

    def mul(a):
        return Task.of(a * 2)

    def div(a):
        return Task.of(a / 2)

    def sub(a):
        return Task.of(a - 1)

    def test_add_mul_div_sub(a):
        return Task.of(a) \
            .bind(add) \
            .bind(mul) \
            .bind(div) \
            .bind(sub)

    assert test_add_mul_div_sub(1).fork(lambda a: a, lambda a: a) == 1.5
    assert test_add_mul_div_sub(2).fork(lambda a: a, lambda a: a) == 2.5
    assert test_add

# Generated at 2022-06-18 02:12:08.012269
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a):
        return Task.of(a + 1)

    def add_two(a):
        return Task.of(a + 2)

    def add_three(a):
        return Task.of(a + 3)

    def add_four(a):
        return Task.of(a + 4)

    def add_five(a):
        return Task.of(a + 5)

    def add_six(a):
        return Task.of(a + 6)

    def add_seven(a):
        return Task.of(a + 7)

    def add_eight(a):
        return Task.of(a + 8)

    def add_nine(a):
        return Task.of(a + 9)

    def add_ten(a):
        return Task.of(a + 10)

   

# Generated at 2022-06-18 02:12:13.291143
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_map_function(value):
        return value * 2

    def test_fork_function(reject, resolve):
        return resolve(2)

    task = Task(test_fork_function)
    mapped_task = task.map(test_map_function)

    assert mapped_task.fork(lambda arg: arg, lambda arg: arg) == 4


# Generated at 2022-06-18 02:12:19.796786
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 7

    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(
        lambda arg: arg,
        lambda arg: None
    ) == None


# Generated at 2022-06-18 02:13:20.272069
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:30.496749
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:33.019053
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value * 2

    def fork(reject, resolve):
        return resolve(2)

    task = Task(fork)
    assert task.map(mapper).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:13:37.052213
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: False, lambda value: value == 2)


# Generated at 2022-06-18 02:13:46.310678
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:55.603704
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test_add(x):
        return Task.of(x + 1)

    def test_mul(x):
        return Task.of(x * 2)

    def test_div(x):
        return Task.of(x / 2)

    def test_sub(x):
        return Task.of(x - 1)

    def test_add_mul(x):
        return Task.of(x + 1).bind(lambda x: Task.of(x * 2))


# Generated at 2022-06-18 02:14:02.198667
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:14:05.966561
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:14:12.158928
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def add_one(value):
            return value + 1

        def resolve(value):
            assert value == 2

        Task.of(1).map(add_one).fork(lambda _: None, resolve)

    def test_map_reject():
        def add_one(value):
            return value + 1

        def reject(value):
            assert value == 1

        Task.reject(1).map(add_one).fork(reject, lambda _: None)

    test_map_resolve()
    test_map_reject()


# Generated at 2022-06-18 02:14:16.640210
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a, b):
        return a + b

    def add_one(a):
        return Task.of(add(a, 1))

    def add_two(a):
        return Task.of(add(a, 2))

    def add_three(a):
        return Task.of(add(a, 3))

    def add_four(a):
        return Task.of(add(a, 4))

    def add_five(a):
        return Task.of(add(a, 5))

    def add_six(a):
        return Task.of(add(a, 6))

    def add_seven(a):
        return Task.of(add(a, 7))

    def add_eight(a):
        return Task.of(add(a, 8))
