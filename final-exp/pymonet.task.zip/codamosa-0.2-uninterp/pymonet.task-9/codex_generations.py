

# Generated at 2022-06-18 02:06:17.248884
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task.of(1)
    assert task.map(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:21.951808
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2

    def fn(value):
        return Task.reject(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda value: value, lambda _: None) == 2


# Generated at 2022-06-18 02:06:25.839205
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:30.409491
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)

# Generated at 2022-06-18 02:06:41.094494
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:46.993422
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:51.652117
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:57.802828
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(mapper)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:00.647099
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:06.300910
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2

    task = Task.reject(1)
    assert task.bind(mapper).fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:07:11.126040
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:12.730427
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    assert Task.of(1).map(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:15.973960
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:18.953170
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-18 02:07:26.790953
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_reject(reject, resolve):
        """
        Test reject function.
        """
        reject(1)

    def test_resolve(reject, resolve):
        """
        Test resolve function.
        """
        resolve(2)

    def test_mapper(value):
        """
        Test mapper function.
        """
        return Task(test_resolve)

    task = Task(test_reject)
    result = task.bind(test_mapper)
    assert result.fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-18 02:07:37.142718
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

   

# Generated at 2022-06-18 02:07:41.507621
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:51.460894
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

   

# Generated at 2022-06-18 02:07:52.867966
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-18 02:07:59.772863
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:08:12.047694
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)

    def test_fn_reject(value):
        return Task.reject(value + 1)

    assert Task.of(1).bind(test_fn).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).bind(test_fn_reject).fork(lambda x: x, lambda x: x) == 2
    assert Task.reject(1).bind(test_fn).fork(lambda x: x, lambda x: x) == 1
    assert Task.reject(1).bind(test_fn_reject).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-18 02:08:14.841678
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:22.480900
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(
        lambda err: err,
        lambda res: res
    ) == 7

    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(
        lambda err: err,
        lambda res: res
    ) == 7

    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(
        lambda err: err,
        lambda res: res
    ) == 7


# Generated at 2022-06-18 02:08:32.002368
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test_add_mul_div_sub():
        return Task.of(1) \
            .bind(add) \
            .bind(mul) \
            .bind(div) \
            .bind(sub)

    assert test_add_mul_div_sub().fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-18 02:08:39.600990
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolved_task():
        def add_one(x):
            return x + 1

        task = Task.of(1)
        task = task.map(add_one)
        assert task.fork(lambda _: None, lambda x: x) == 2

    def test_map_rejected_task():
        def add_one(x):
            return x + 1

        task = Task.reject(1)
        task = task.map(add_one)
        assert task.fork(lambda x: x, lambda _: None) == 1

    test_map_resolved_task()
    test_map_rejected_task()


# Generated at 2022-06-18 02:08:48.791275
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(error).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:08:57.257516
# Unit test for method map of class Task
def test_Task_map():
    def test_Task_map_resolve():
        def add_one(value):
            return value + 1

        def test_resolve(value):
            assert value == 2


# Generated at 2022-06-18 02:09:07.673351
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def pow(x):
        return x ** 2

    def sqrt(x):
        return x ** 0.5

    def fact(x):
        return math.factorial(x)

    def fib(x):
        return math.fib(x)

    def sin(x):
        return math.sin(x)

    def cos(x):
        return math.cos(x)

    def tan(x):
        return math.tan(x)

    def cot(x):
        return 1 / math.tan(x)

    def sec(x):
        return 1 / math.cos(x)

# Generated at 2022-06-18 02:09:10.214016
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:19.963176
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:34.076939
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:39.071452
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    result = task.bind(fn)
    assert result.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-18 02:09:43.057193
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:45.338379
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:55.726747
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_map_resolve():
        """
        Test for method map of class Task with resolve.
        """
        def resolve(value):
            """
            Resolve function.
            """
            assert value == 2

        def reject(value):
            """
            Reject function.
            """
            assert False

        def fork(reject, resolve):
            """
            Fork function.
            """
            resolve(1)

        task = Task(fork)
        task.map(lambda value: value + 1).fork(reject, resolve)

    def test_map_reject():
        """
        Test for method map of class Task with reject.
        """
        def resolve(value):
            """
            Resolve function.
            """
            assert False

       

# Generated at 2022-06-18 02:10:06.391030
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def double(x):
        return x * 2

    def triple(x):
        return x * 3

    def add_double(x):
        return x + 2

    def add_triple(x):
        return x + 3

    def double_add(x):
        return x * 2 + 1

    def triple_add(x):
        return x * 3 + 1

    def double_triple(x):
        return x * 2 * 3

    def triple_double(x):
        return x * 3 * 2

    def double_add_triple(x):
        return x * 2 + 3

    def triple_add_double(x):
        return x * 3 + 2

    def triple_double_add(x):
        return x * 3 * 2 + 1



# Generated at 2022-06-18 02:10:10.315778
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.map(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:18.909960
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:10:22.208791
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: False, lambda value: value == 2)


# Generated at 2022-06-18 02:10:24.897956
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:52.128039
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:57.041223
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_fn).fork(lambda x: x, lambda x: x) == 2
    assert Task.reject(1).bind(test_fn).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-18 02:11:00.703097
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-18 02:11:08.690855
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test(x):
        return Task.of(x)

    def test_reject(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1


# Generated at 2022-06-18 02:11:17.950087
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:11:27.378355
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:31.748666
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    assert Task.of(1).map(add_one).map(add_two).map(add_three).map(add_four).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 10


# Generated at 2022-06-18 02:11:40.518798
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def sub(x):
        return x - 1

    def add_task(x):
        return Task.of(add(x))

    def mul_task(x):
        return Task.of(mul(x))

    def div_task(x):
        return Task.of(div(x))

    def sub_task(x):
        return Task.of(sub(x))

    def add_mul_div_sub_task(x):
        return Task.of(x) \
            .bind(add_task) \
            .bind(mul_task) \
            .bind(div_task) \
            .bind(sub_task)



# Generated at 2022-06-18 02:11:51.102392
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13


# Generated at 2022-06-18 02:12:00.561456
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:51.453801
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:12:57.590390
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda _: None, lambda arg: arg) == 2
    assert test_map(2).fork(lambda _: None, lambda arg: arg) == 3
    assert test_map(3).fork(lambda _: None, lambda arg: arg) == 4


# Generated at 2022-06-18 02:13:07.274852
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:13:15.363904
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:13:26.246536
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_map_resolve():
        """
        Test for method map of class Task with resolve.
        """
        def test_map_resolve_with_value():
            """
            Test for method map of class Task with resolve and value.
            """
            def test_map_resolve_with_value_with_mapper():
                """
                Test for method map of class Task with resolve and value and mapper.
                """
                def test_map_resolve_with_value_with_mapper_with_resolve():
                    """
                    Test for method map of class Task with resolve and value and mapper and resolve.
                    """

# Generated at 2022-06-18 02:13:30.563297
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    task = Task.of(1)
    assert task.map(mapper).fork(lambda _: None, lambda value: value) == 2

    task = Task.reject(1)
    assert task.map(mapper).fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:13:33.343441
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)

    def mapper(value):
        return Task.of(value + 1)


# Generated at 2022-06-18 02:13:44.320594
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    def add(x):
        return Task.of(x + 1)

    def add_error(x):
        return Task.reject(x + 1)

    def add_error_with_error(x):
        return Task.reject(x + 1).bind(add)

    def add_with_error(x):
        return Task.of(x + 1).bind(add_error)

    def add_with_error_with_error(x):
        return Task.of(x + 1).bind(add_error).bind(add)

    def add_with_error_with_error_with_error(x):
        return Task.of(x + 1).bind(add_error).bind(add_error).bind(add)


# Generated at 2022-06-18 02:13:53.878485
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:14:01.045966
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_map_resolve(resolve, reject):
        """
        Test for method map of class Task.
        """
        resolve(1)

    def test_map_reject(resolve, reject):
        """
        Test for method map of class Task.
        """
        reject(1)

    def test_map_fork(resolve, reject):
        """
        Test for method map of class Task.
        """
        reject(1)

    def test_map_fn(value):
        """
        Test for method map of class Task.
        """
        return value + 1

    def test_map_fn_error(value):
        """
        Test for method map of class Task.
        """
        raise Exception('error')


# Generated at 2022-06-18 02:16:11.901179
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.
    """
    def test_map(value):
        """
        Test for Task.map method.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda _: False, lambda arg: arg == 2)
    assert test_map(2).fork(lambda _: False, lambda arg: arg == 3)
    assert test_map(3).fork(lambda _: False, lambda arg: arg == 4)
    assert test_map(4).fork(lambda _: False, lambda arg: arg == 5)