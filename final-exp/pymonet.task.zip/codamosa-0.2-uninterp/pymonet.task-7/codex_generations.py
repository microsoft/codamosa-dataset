

# Generated at 2022-06-18 02:06:10.737104
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:17.430831
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:26.092701
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:29.616923
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:34.123673
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:42.788950
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def multiply(x):
        return Task.of(x * 2)

    def divide(x):
        return Task.of(x / 2)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(multiply).bind(divide).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(multiply).bind(divide).bind(error).fork(
        lambda x: x,
        lambda x: x
    ) == 2


# Generated at 2022-06-18 02:06:46.843146
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a, b):
        return a + b

    def add_task(a):
        return Task.of(add(a, 1))

    def add_task_error(a):
        return Task.reject(add(a, 1))

    def test_add_task(a):
        return Task.of(a).bind(add_task)

    def test_add_task_error(a):
        return Task.of(a).bind(add_task_error)

    assert test_add_task(1).fork(lambda x: x, lambda x: x) == 2
    assert test_add_task_error(1).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:06:49.053902
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-18 02:06:52.148038
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:06:58.912325
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fork(reject, resolve):
        resolve(1)

    def test_map(value):
        return Task.of(value + 1)

    task = Task(test_fork)
    result = task.bind(test_map).fork(lambda _: None, lambda value: value)
    assert result == 2


# Generated at 2022-06-18 02:07:04.689256
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:07:09.181513
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:11.083490
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:13.613559
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.map(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:23.551537
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:33.395610
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fork_reject(reject, resolve):
        reject(1)

    def fork_reject_2(reject, resolve):
        reject(2)

    def fork_resolve_2(reject, resolve):
        resolve(2)

    def fork_resolve_3(reject, resolve):
        resolve(3)

    def fork_resolve_4(reject, resolve):
        resolve(4)

    def fork_resolve_5(reject, resolve):
        resolve(5)

    def fork_resolve_6(reject, resolve):
        resolve(6)

    def fork_resolve_7(reject, resolve):
        resolve(7)

    def fork_resolve_8(reject, resolve):
        resolve

# Generated at 2022-06-18 02:07:36.425173
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:39.729943
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:42.640991
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:45.162324
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:53.385973
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:57.922922
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(
        lambda value: value,
        lambda value: value
    ) == 7


# Generated at 2022-06-18 02:08:08.189978
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(x):
        return Task.of(x + 1)

    def add_two(x):
        return Task.of(x + 2)

    def add_three(x):
        return Task.of(x + 3)

    def add_four(x):
        return Task.of(x + 4)

    def add_five(x):
        return Task.of(x + 5)

    def add_six(x):
        return Task.of(x + 6)

    def add_seven(x):
        return Task.of(x + 7)

    def add_eight(x):
        return Task.of(x + 8)

    def add_nine(x):
        return Task.of(x + 9)

    def add_ten(x):
        return Task.of(x + 10)

# Generated at 2022-06-18 02:08:15.247569
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return value

    def reject(value):
        return value

    def add(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value

# Generated at 2022-06-18 02:08:22.887294
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:26.881717
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    result = task.bind(fn)

    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:33.041222
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2

    def fn(value):
        return Task.reject(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda value: value, lambda _: None) == 2


# Generated at 2022-06-18 02:08:41.094342
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fork_reject(reject, resolve):
        reject(1)

    def fork_reject_2(reject, resolve):
        reject(2)

    def fork_reject_3(reject, resolve):
        reject(3)

    def fork_resolve_2(reject, resolve):
        resolve(2)

    def fork_resolve_3(reject, resolve):
        resolve(3)

    def fork_resolve_4(reject, resolve):
        resolve(4)

    def fork_resolve_5(reject, resolve):
        resolve(5)

    def fork_resolve_6(reject, resolve):
        resolve(6)

    def fork_resolve_7(reject, resolve):
        resolve

# Generated at 2022-06-18 02:08:48.530613
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda x: x, lambda x: x) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-18 02:08:58.154855
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:10.213123
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:19.964185
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12


# Generated at 2022-06-18 02:09:21.920105
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:29.609766
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:34.118502
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    task = task.bind(lambda x: Task.of(x + 1))
    assert task.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:09:44.414320
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:09:47.523727
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:57.019586
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:07.301395
# Unit test for method map of class Task
def test_Task_map():
    def test_task_map_resolve():
        def add_one(value):
            return value + 1

        def fork(reject, resolve):
            return resolve(1)

        task = Task(fork)
        mapped_task = task.map(add_one)
        assert mapped_task.fork(lambda _: None, lambda value: value) == 2

    def test_task_map_reject():
        def add_one(value):
            return value + 1

        def fork(reject, resolve):
            return reject(1)

        task = Task(fork)
        mapped_task = task.map(add_one)
        assert mapped_task.fork(lambda value: value, lambda _: None) == 1

    test_task_map_resolve()
    test_task_map_reject()

# Unit

# Generated at 2022-06-18 02:10:15.340029
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        return Task.of(value)

    def reject(value):
        return Task.reject(value)

    def mapper(value):
        return value + 1

    def test_bind_resolve():
        task = Task.of(1)
        assert task.bind(resolve).fork(reject, resolve) == 2

    def test_bind_reject():
        task = Task.of(1)
        assert task.bind(reject).fork(reject, resolve) == 1

    test_bind_resolve()
    test_bind_reject()


# Generated at 2022-06-18 02:10:40.522328
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(
        lambda value: None,
        lambda value: value
    ) == 2

    assert Task.reject(1).map(add_one).fork(
        lambda value: value,
        lambda value: None
    ) == 1


# Generated at 2022-06-18 02:10:44.877968
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:52.035331
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:56.145255
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:59.777700
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:11:08.332824
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a):
        return Task.of(a + 1)

    def mul(a):
        return Task.of(a * 2)

    def div(a):
        return Task.of(a / 2)

    def sub(a):
        return Task.of(a - 1)

    def test(a):
        return Task.of(a).bind(add).bind(mul).bind(div).bind(sub)

    assert test(1).fork(lambda x: x, lambda x: x) == 1
    assert test(2).fork(lambda x: x, lambda x: x) == 1
    assert test(3).fork(lambda x: x, lambda x: x) == 1
    assert test(4).fork(lambda x: x, lambda x: x) == 1

# Generated at 2022-06-18 02:11:17.723969
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:27.377782
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

   

# Generated at 2022-06-18 02:11:30.392084
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:32.063377
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:12:20.925095
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:27.365083
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def add_one(value):
            return value + 1

        def test_resolve(value):
            assert value == 2

        Task.of(1).map(add_one).fork(lambda _: None, test_resolve)

    def test_map_reject():
        def add_one(value):
            return value + 1

        def test_reject(value):
            assert value == 1

        Task.reject(1).map(add_one).fork(test_reject, lambda _: None)

    test_map_resolve()
    test_map_reject()


# Generated at 2022-06-18 02:12:29.974494
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2

    task = Task.reject(1)
    assert task.bind(fn).fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:12:32.162784
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value * 2

    task = Task.of(2)
    assert task.map(fn).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:12:34.062015
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:12:44.092589
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    def sub(x):
        return x - 1

    def div(x):
        return x / 2

    assert Task.of(1).map(add).fork(None, lambda x: x) == 2
    assert Task.of(1).map(mul).fork(None, lambda x: x) == 2
    assert Task.of(1).map(sub).fork(None, lambda x: x) == 0
    assert Task.of(1).map(div).fork(None, lambda x: x) == 0.5

    assert Task.reject(1).map(add).fork(lambda x: x, None) == 1
    assert Task.reject(1).map(mul).fork(lambda x: x, None)

# Generated at 2022-06-18 02:12:49.171099
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    task = Task.of(1)
    assert task.map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 7


# Generated at 2022-06-18 02:12:55.843048
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve(resolve, reject):
        resolve(1)

    def test_map_reject(resolve, reject):
        reject(1)

    def test_map_resolve_mapper(value):
        return value + 1

    def test_map_reject_mapper(value):
        return value + 1

    def test_map_resolve_mapper_reject(value):
        return Task.reject(value + 1)

    def test_map_reject_mapper_reject(value):
        return Task.reject(value + 1)

    def test_map_resolve_mapper_resolve(value):
        return Task.of(value + 1)


# Generated at 2022-06-18 02:13:00.279795
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:04.313122
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)
        return Task(fork)

    task = Task(fork)

# Generated at 2022-06-18 02:14:43.784159
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    def reject(value):
        assert False

    def resolve(value):
        assert value == 2

    task = Task(fork)
    task.bind(mapper).fork(reject, resolve)


# Generated at 2022-06-18 02:14:47.428206
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:14:51.147960
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:14:54.950518
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:15:01.589321
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:15:05.090466
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:15:13.916524
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:15:18.793033
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def fn(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(fn)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:15:21.588912
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:15:25.165180
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4
