

# Generated at 2022-06-18 02:06:10.796978
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:13.361977
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:18.099221
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(None, lambda value: value) == 4


# Generated at 2022-06-18 02:06:26.595794
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def error(x):
        raise Exception('Error')

    assert Task.of(1).map(add).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(sub).fork(lambda x: x, lambda x: x) == 0
    assert Task.of(1).map(mul).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(div).fork(lambda x: x, lambda x: x) == 0.5

# Generated at 2022-06-18 02:06:30.007737
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(lambda _: False, lambda value: value == 2)


# Generated at 2022-06-18 02:06:40.832029
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:44.840266
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:54.036100
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:05.798055
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:07:08.860100
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:07:13.578158
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:23.504302
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(error).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:07:27.697265
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task(lambda reject, resolve: resolve(value + 1))

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:30.754385
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:34.558814
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.map(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:07:39.032245
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: False, lambda value: value == 2)


# Generated at 2022-06-18 02:07:45.683732
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_fn(value):
        """
        Test function for method bind of class Task.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value)

    assert Task.of(1).bind(test_fn).fork(lambda _: False, lambda arg: arg == 1)
    assert Task.of(1).bind(lambda _: Task.reject(2)).fork(lambda arg: arg == 2, lambda _: False)


# Generated at 2022-06-18 02:07:50.024206
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:58.866854
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:04.426410
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    new_task = task.bind(mapper)

    assert new_task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:16.646166
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve(resolve, reject):
        resolve(1)

    def test_map_reject(resolve, reject):
        reject(1)

    def test_map_fn(value):
        return value + 1

    assert Task(test_map_resolve).map(test_map_fn).fork(lambda _: None, lambda value: value) == 2
    assert Task(test_map_reject).map(test_map_fn).fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:08:25.278547
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:30.215626
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value * 2

    task = Task.of(2)
    assert task.map(fn).fork(lambda x: x, lambda x: x) == 4

    task = Task.reject(2)
    assert task.map(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:08:39.293874
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:08:43.869260
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:50.741972
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:00.904857
# Unit test for method bind of class Task
def test_Task_bind():
    def test_reject(reject, resolve):
        reject('reject')

    def test_resolve(reject, resolve):
        resolve('resolve')

    def test_mapper(value):
        return Task(test_resolve)

    def test_reject_mapper(value):
        return Task(test_reject)

    assert Task(test_reject).bind(test_mapper).fork(
        lambda value: value,
        lambda value: 'resolve'
    ) == 'reject'

    assert Task(test_resolve).bind(test_reject_mapper).fork(
        lambda value: value,
        lambda value: 'resolve'
    ) == 'reject'


# Generated at 2022-06-18 02:09:10.089994
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:09:12.248634
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(None, lambda x: x) == 2


# Generated at 2022-06-18 02:09:16.972154
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    result = task.bind(fn)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:30.907176
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:40.816181
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:09:44.868795
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda x: x + 1)

    assert test_map(1).fork(lambda x: x, lambda x: x) == 2
    assert test_map(2).fork(lambda x: x, lambda x: x) == 3


# Generated at 2022-06-18 02:09:49.263382
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: False, lambda arg: arg == 2)


# Generated at 2022-06-18 02:09:53.708876
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    result = task.bind(lambda x: Task.of(x + 1))
    assert result.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:10:05.175482
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def pow(x):
        return x ** 2

    def mod(x):
        return x % 2

    def concat(x):
        return str(x) + '_'

    def to_int(x):
        return int(x)

    def to_float(x):
        return float(x)

    def to_str(x):
        return str(x)

    def to_bool(x):
        return bool(x)

    def to_list(x):
        return list(x)

    def to_tuple(x):
        return tuple(x)


# Generated at 2022-06-18 02:10:15.183177
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:22.056772
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_map(value):
        """
        Test for method map of class Task.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-18 02:10:25.995900
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:36.726932
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:02.407611
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:09.189300
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:13.433690
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:20.148612
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8

    def add_nine(a):
        return a + 9

    def add_ten(a):
        return a + 10

    def add_eleven(a):
        return a + 11

    def add_twelve(a):
        return a + 12


# Generated at 2022-06-18 02:11:23.913951
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fn(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(fn)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:26.681985
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        def fn(arg):
            return arg + value

        return Task.of(value).map(fn).fork(
            lambda arg: arg,
            lambda arg: arg
        )

    assert test_map(1) == 2
    assert test_map(2) == 4


# Generated at 2022-06-18 02:11:29.470742
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:36.969135
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:40.417487
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-18 02:11:51.062691
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:43.243229
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def test_map(value):
        """
        Test for method map of class Task.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        def mapper(value):
            """
            Mapper function.

            :param value: value to store in Task
            :type value: A
            :returns: resolved Task
            :rtype: Task[Function(_, resolve) -> A]
            """
            return value + 1

        return Task.of(value).map(mapper)

    assert test_map(1).fork(lambda _: False, lambda value: value == 2)


# Generated at 2022-06-18 02:12:46.947398
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)

    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:12:53.865898
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:12:58.507675
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:02.764606
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:07.048869
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    task_mapped = task.bind(lambda value: Task.of(value + 1))
    assert task_mapped.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:10.646435
# Unit test for method map of class Task
def test_Task_map():
    def test_fn(value):
        return value + 1

    def test_fork(reject, resolve):
        return resolve(1)

    task = Task(test_fork)
    assert task.map(test_fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:13.986106
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:23.835100
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def fail(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(fail).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2


# Generated at 2022-06-18 02:13:33.152763
# Unit test for method bind of class Task
def test_Task_bind():
    def test_mapper(value):
        return Task.of(value + 1)

    def test_mapper_reject(value):
        return Task.reject(value + 1)

    def test_mapper_reject_reject(value):
        return Task.reject(value + 1).bind(lambda _: Task.reject(value + 2))

    def test_mapper_reject_resolve(value):
        return Task.reject(value + 1).bind(lambda _: Task.of(value + 2))

    def test_mapper_resolve_reject(value):
        return Task.of(value + 1).bind(lambda _: Task.reject(value + 2))


# Generated at 2022-06-18 02:15:22.469125
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: False, lambda arg: arg == 2)


# Generated at 2022-06-18 02:15:24.731337
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:15:32.613697
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:15:35.200705
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:15:39.039612
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:15:42.751059
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task.of(1)
    result = task.map(fn)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:15:48.657030
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_function(value):
        """
        Test function for Task.bind.

        :param value: value to return
        :type value: A
        :returns: new Task with stored value
        :rtype: Task[Function(reject, resolve) -> A]
        """
        return Task.of(value)

    assert Task.of(1).bind(test_function).fork(lambda _: False, lambda arg: arg == 1)
    assert Task.of(1).bind(test_function).fork(lambda _: False, lambda arg: arg == 2) == False


# Generated at 2022-06-18 02:15:52.963108
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-18 02:15:57.578143
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2

    task = Task.reject(1)
    assert task.bind(fn).fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:16:01.712016
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    def test_function(value):
        """
        Function for testing
        """
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(test_function).fork(lambda arg: arg, lambda arg: arg) == 2
