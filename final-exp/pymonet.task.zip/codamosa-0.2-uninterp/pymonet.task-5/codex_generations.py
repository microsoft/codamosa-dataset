

# Generated at 2022-06-18 02:06:22.924831
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve(resolve, reject):
        resolve(1)

    def test_map_reject(resolve, reject):
        reject(1)

    def test_map_resolve_mapper(value):
        return value + 1

    def test_map_reject_mapper(value):
        return value + 1

    def test_map_resolve_mapper_reject(value):
        return Task.reject(value + 1)

    def test_map_reject_mapper_reject(value):
        return Task.reject(value + 1)

    def test_map_resolve_mapper_resolve(value):
        return Task.of(value + 1)


# Generated at 2022-06-18 02:06:26.879999
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:38.617410
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:06:41.062573
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:52.263825
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(error).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:07:05.119690
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:13.796364
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a):
        return Task.of(a + 1)

    def mul(a):
        return Task.of(a * 2)

    def div(a):
        return Task.of(a / 2)

    def sub(a):
        return Task.of(a - 1)

    def error(a):
        return Task.reject(a)

    def test_bind(a):
        return Task.of(a) \
            .bind(add) \
            .bind(mul) \
            .bind(div) \
            .bind(sub)


# Generated at 2022-06-18 02:07:23.603678
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:07:33.438121
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def sub(x):
        return x - 1

    def pow(x):
        return x ** 2

    def mod(x):
        return x % 2

    def concat(x):
        return str(x) + '1'

    def to_int(x):
        return int(x)

    def to_float(x):
        return float(x)

    def to_str(x):
        return str(x)

    def to_bool(x):
        return bool(x)

    def to_list(x):
        return list(x)

    def to_tuple(x):
        return tuple(x)


# Generated at 2022-06-18 02:07:37.100664
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:07:42.574936
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:45.628747
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:49.978366
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:58.831395
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:08:05.259232
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return value

    def reject(value):
        return value

    def add_one(value):
        return value + 1

    assert Task(lambda reject, resolve: resolve(1)).map(add_one).fork(reject, resolve) == 2
    assert Task(lambda reject, resolve: reject(1)).map(add_one).fork(reject, resolve) == 1


# Generated at 2022-06-18 02:08:09.236322
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: False, lambda value: value == 2)


# Generated at 2022-06-18 02:08:19.050013
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fork_reject(reject, resolve):
        reject(1)

    def fork_mapper(reject, resolve):
        resolve(2)

    def fork_mapper_reject(reject, resolve):
        reject(2)

    def mapper(value):
        return Task(fork_mapper)

    def mapper_reject(value):
        return Task(fork_mapper_reject)

    assert Task(fork).bind(mapper).fork(lambda x: x, lambda x: x) == 2
    assert Task(fork).bind(mapper_reject).fork(lambda x: x, lambda x: x) == 2
    assert Task(fork_reject).bind(mapper).fork(lambda x: x, lambda x: x)

# Generated at 2022-06-18 02:08:29.420833
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def add_four(a):
        return a + 4

    def add_five(a):
        return a + 5

    def add_six(a):
        return a + 6

    def add_seven(a):
        return a + 7

    def add_eight(a):
        return a + 8

    def add_nine(a):
        return a + 9

    def add_ten(a):
        return a + 10

    def add_eleven(a):
        return a + 11

    def add_twelve(a):
        return a + 12


# Generated at 2022-06-18 02:08:38.642343
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:41.571611
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    result = task.bind(fn)

    assert result.fork(lambda _: False, lambda value: value == 2)



# Generated at 2022-06-18 02:08:50.774710
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: False, lambda value: value == 2)


# Generated at 2022-06-18 02:08:53.639208
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:56.386845
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:06.812655
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:09:09.009768
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:19.410201
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    assert Task.of(0).map(add_one).fork(None, lambda value: value) == 1
    assert Task.of(0).map(add_two).fork(None, lambda value: value)

# Generated at 2022-06-18 02:09:27.658246
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def test_add(x):
        return Task.of(x + 1)

    def test_mul(x):
        return Task.of(x * 2)

    def test_div(x):
        return Task.of(x / 2)

    def test_sub(x):
        return Task.of(x - 1)

    def test_add_mul(x):
        return Task.of(x + 1).bind(lambda x: Task.of(x * 2))


# Generated at 2022-06-18 02:09:30.126696
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    assert Task.of(1).map(add).fork(None, lambda x: x) == 2


# Generated at 2022-06-18 02:09:34.662806
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.map(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:44.763856
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:05.705750
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        return Task.of(x + 1)

    def g(x):
        return Task.of(x * 2)

    def h(x):
        return Task.of(x - 3)

    def i(x):
        return Task.of(x / 2)

    def j(x):
        return Task.of(x ** 2)

    def k(x):
        return Task.of(x % 3)

    def l(x):
        return Task.of(x + 5)

    def m(x):
        return Task.of(x * 3)

    def n(x):
        return Task.of(x - 7)

    def o(x):
        return Task.of(x / 4)

    def p(x):
        return Task.of(x ** 3)

   

# Generated at 2022-06-18 02:10:15.799835
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def multiply(x):
        return Task.of(x * 2)

    def divide(x):
        return Task.of(x / 2)

    def reject(x):
        return Task.reject(x)

    def test_bind_with_add_multiply_divide():
        assert Task.of(1).bind(add).bind(multiply).bind(divide).fork(
            lambda x: x,
            lambda x: x
        ) == 2

    def test_bind_with_add_multiply_reject():
        assert Task.of(1).bind(add).bind(multiply).bind(reject).fork(
            lambda x: x,
            lambda x: x
        ) == 2


# Generated at 2022-06-18 02:10:24.576731
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    def test_bind(x):
        return Task.of(x).bind(add).bind(mul).bind(div).bind(sub)

    assert test_bind(1).fork(lambda x: x, lambda x: x) == 1
    assert test_bind(2).fork(lambda x: x, lambda x: x) == 1
    assert test_bind(3).fork(lambda x: x, lambda x: x) == 1

# Generated at 2022-06-18 02:10:33.291522
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def fn(value):
            return value + 1

        def fork(reject, resolve):
            return resolve(1)

        task = Task(fork)
        assert task.map(fn).fork(lambda _: None, lambda value: value) == 2

    def test_map_reject():
        def fn(value):
            return value + 1

        def fork(reject, resolve):
            return reject(1)

        task = Task(fork)
        assert task.map(fn).fork(lambda value: value, lambda _: None) == 1

    test_map_resolve()
    test_map_reject()


# Generated at 2022-06-18 02:10:41.835709
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:50.335161
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:54.228224
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def sub(x):
        return Task.of(x - 1)

    assert Task.of(1).bind(add).bind(sub).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-18 02:11:05.310549
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a):
        return Task.of(a + 1)

    def mul(a):
        return Task.of(a * 2)

    def div(a):
        return Task.of(a / 2)

    def sub(a):
        return Task.of(a - 1)

    def test_add_mul_div_sub(a):
        return Task.of(a) \
            .bind(add) \
            .bind(mul) \
            .bind(div) \
            .bind(sub)

    assert test_add_mul_div_sub(1).fork(lambda _: None, lambda arg: arg) == 2
    assert test_add_mul_div_sub(2).fork(lambda _: None, lambda arg: arg) == 4
    assert test_add_mul_

# Generated at 2022-06-18 02:11:08.579956
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:13.300202
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)

    def mapper(value):
        return value + 1

    task_mapped = task.map(mapper)

    assert task_mapped.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:34.326315
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    assert task.bind(fn).fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-18 02:11:44.721515
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:11:52.916147
# Unit test for method map of class Task
def test_Task_map():
    def test_map_of_resolved_task():
        task = Task.of(1)
        result = task.map(lambda x: x + 1)
        assert result.fork(lambda x: x, lambda x: x) == 2

    def test_map_of_rejected_task():
        task = Task.reject(1)
        result = task.map(lambda x: x + 1)
        assert result.fork(lambda x: x, lambda x: x) == 1

    test_map_of_resolved_task()
    test_map_of_rejected_task()


# Generated at 2022-06-18 02:12:02.118708
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:06.637730
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda _: False, lambda arg: arg == 2)
    assert test_map(2).fork(lambda _: False, lambda arg: arg == 3)
    assert test_map(3).fork(lambda _: False, lambda arg: arg == 4)


# Generated at 2022-06-18 02:12:16.059673
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:22.339379
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def multiply(x):
        return Task.of(x * 2)

    def reject(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(multiply).fork(lambda x: x, lambda x: x) == 4
    assert Task.of(1).bind(add).bind(reject).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).bind(reject).bind(multiply).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-18 02:12:28.770881
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda err: err,
        lambda res: res
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda err: err,
        lambda res: res
    ) == 2


# Generated at 2022-06-18 02:12:36.249858
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:12:44.668797
# Unit test for method bind of class Task
def test_Task_bind():
    def get_value(value):
        return Task.of(value)

    def get_error(value):
        return Task.reject(value)

    assert Task.of(1).bind(get_value).fork(lambda x: x, lambda x: x) == 1
    assert Task.of(1).bind(get_error).fork(lambda x: x, lambda x: x) == 1
    assert Task.reject(1).bind(get_value).fork(lambda x: x, lambda x: x) == 1
    assert Task.reject(1).bind(get_error).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-18 02:13:34.002689
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:13:36.714013
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:13:38.312248
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(test_fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:13:43.271783
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:47.596335
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:54.924181
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(None, lambda value: value) == 4


# Generated at 2022-06-18 02:14:01.128031
# Unit test for method bind of class Task
def test_Task_bind():
    def test_Task_bind_resolve():
        def mapper(value):
            return Task.of(value + 1)

        task = Task.of(1)
        result = task.bind(mapper)
        assert result.fork(lambda _: None, lambda value: value) == 2

    def test_Task_bind_reject():
        def mapper(value):
            return Task.of(value + 1)

        task = Task.reject(1)
        result = task.bind(mapper)
        assert result.fork(lambda value: value, lambda _: None) == 1

    test_Task_bind_resolve()
    test_Task_bind_reject()


# Generated at 2022-06-18 02:14:10.112504
# Unit test for method map of class Task
def test_Task_map():
    def add(value):
        return value + 1

    def sub(value):
        return value - 1

    def mul(value):
        return value * 2

    def div(value):
        return value / 2

    def error(value):
        raise Exception('error')

    def test(value):
        return Task.of(value).map(add).map(sub).map(mul).map(div).fork(lambda arg: arg, lambda arg: arg)

    assert test(1) == 0.5
    assert test(2) == 1
    assert test(3) == 1.5
    assert test(4) == 2
    assert test(5) == 2.5
    assert test(6) == 3
    assert test(7) == 3.5
    assert test(8) == 4
    assert test(9) == 4

# Generated at 2022-06-18 02:14:11.695819
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(test_function).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:14:13.135482
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:16:16.652737
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   