

# Generated at 2022-06-18 02:06:20.936816
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:28.635030
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:33.571375
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:06:42.491593
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:48.231387
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 7


# Generated at 2022-06-18 02:06:54.387247
# Unit test for method map of class Task
def test_Task_map():
    def add(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    assert Task.of(1).map(add).fork(lambda _: None, lambda a: a) == 2
    assert Task.of(1).map(add).map(add_two).fork(lambda _: None, lambda a: a) == 3
    assert Task.of(1).map(add).map(add_two).map(add_three).fork(lambda _: None, lambda a: a) == 4


# Generated at 2022-06-18 02:07:06.123125
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def multiply(x):
        return Task.of(x * 2)

    def divide(x):
        return Task.of(x / 2)

    def error(x):
        return Task.reject(x)

    def test_bind(x):
        return Task.of(x) \
            .bind(add) \
            .bind(multiply) \
            .bind(divide) \
            .bind(error)

    assert test_bind(1).fork(lambda x: x, lambda x: x) == 1
    assert test_bind(2).fork(lambda x: x, lambda x: x) == 2
    assert test_bind(3).fork(lambda x: x, lambda x: x) == 3


# Generated at 2022-06-18 02:07:14.569215
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def identity(x):
        return x

    def test_map(x):
        return Task.of(x).map(add).map(sub).map(mul).map(div).map(identity)

    assert test_map(1).fork(lambda x: x, lambda x: x) == 1
    assert test_map(2).fork(lambda x: x, lambda x: x) == 1
    assert test_map(3).fork(lambda x: x, lambda x: x) == 1
    assert test_map(4).fork(lambda x: x, lambda x: x) == 1
    assert test_

# Generated at 2022-06-18 02:07:23.843685
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:27.700028
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-18 02:07:41.169083
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:51.033083
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:54.232366
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:03.721765
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:06.701812
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:14.122532
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:22.220994
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:08:27.031684
# Unit test for method bind of class Task
def test_Task_bind():
    def add(value):
        return Task.of(value + 1)

    def mul(value):
        return Task.of(value * 2)

    assert Task.of(1).bind(add).bind(mul).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:08:37.341329
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fork_reject(reject, resolve):
        reject(1)

    def fork_reject_2(reject, resolve):
        reject(2)

    def fork_reject_3(reject, resolve):
        reject(3)

    def fork_resolve_2(reject, resolve):
        resolve(2)

    def fork_resolve_3(reject, resolve):
        resolve(3)

    def fork_resolve_4(reject, resolve):
        resolve(4)

    def fork_resolve_5(reject, resolve):
        resolve(5)

    def fork_resolve_6(reject, resolve):
        resolve(6)

    def fork_resolve_7(reject, resolve):
        resolve

# Generated at 2022-06-18 02:08:46.713999
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:09:02.424330
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:11.086597
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_value(value):
        return Task.of(value)

    def reject_value(value):
        return Task.reject(value)

    def resolve_value_with_error(value):
        return Task.of(value).map(lambda arg: arg + 1)

    def reject_value_with_error(value):
        return Task.reject(value).map(lambda arg: arg + 1)

    def resolve_value_with_error_and_reject(value):
        return Task.of(value).map(lambda arg: arg + 1).bind(reject_value)

    def reject_value_with_error_and_resolve(value):
        return Task.reject(value).map(lambda arg: arg + 1).bind(resolve_value)


# Generated at 2022-06-18 02:09:20.706311
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

   

# Generated at 2022-06-18 02:09:27.592281
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def add_one(value):
            return value + 1

        def resolve(value):
            assert value == 2

        task = Task.of(1)
        task.map(add_one).fork(lambda _: None, resolve)

    def test_map_reject():
        def add_one(value):
            return value + 1

        def reject(value):
            assert value == 1

        task = Task.reject(1)
        task.map(add_one).fork(reject, lambda _: None)

    test_map_resolve()
    test_map_reject()


# Generated at 2022-06-18 02:09:30.530661
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:09:42.180243
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:52.281739
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(error).bind(mul).bind(div).fork(
        lambda x: x,
        lambda x: x
    ) == 2


# Generated at 2022-06-18 02:09:55.658889
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)

    assert result.fork(lambda _: False, lambda value: value == 2)



# Generated at 2022-06-18 02:09:58.826491
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:02.721457
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda result: result) == 2


# Generated at 2022-06-18 02:10:22.028049
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:28.558794
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        print("resolve: " + str(value))

    def reject(value):
        print("reject: " + str(value))

    def mapper(value):
        return Task.of(value + 1)

    def mapper_reject(value):
        return Task.reject(value + 1)

    Task.of(1).bind(mapper).fork(reject, resolve)
    Task.reject(1).bind(mapper_reject).fork(reject, resolve)


# Generated at 2022-06-18 02:10:38.838065
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a, b):
        return a + b

    def add_task(a):
        return Task.of(add(a, 1))

    def add_task_reject(a):
        return Task.reject(add(a, 1))

    def add_task_reject_with_error(a):
        return Task.reject(add(a, 1))

    def add_task_reject_with_error_and_resolve(a):
        return Task.reject(add(a, 1))

    def add_task_reject_with_error_and_resolve_and_reject(a):
        return Task.reject(add(a, 1))


# Generated at 2022-06-18 02:10:43.256454
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:51.316104
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda _: False,
        lambda value: value == 1
    )

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(error).fork(
        lambda value: value == 0.5,
        lambda _: False
    )


# Generated at 2022-06-18 02:10:55.094462
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    assert Task.of(1).bind(add).bind(mul).fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-18 02:11:06.111306
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve(resolve, reject):
        resolve(1)

    def test_map_reject(resolve, reject):
        reject(1)

    def test_map_mapper(value):
        return value + 1

    def test_map_mapper_reject(value):
        return Task.reject(value + 1)

    def test_map_mapper_resolve(value):
        return Task.of(value + 1)


# Generated at 2022-06-18 02:11:16.238175
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:25.590535
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:11:29.081135
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:54.932603
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:57.917767
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-18 02:12:06.407883
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:15.817811
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12


# Generated at 2022-06-18 02:12:19.917949
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2

    task = Task.reject(1)
    assert task.bind(fn).fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-18 02:12:24.512231
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_function(value):
        """
        Test function for Task.bind.

        :param value: value to store in Task
        :type value: A
        :returns: new Task with mapped resolve attribute
        :rtype: Task[Function(resolve, reject -> A | B]
        """
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:12:27.002175
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:12:31.769947
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    def test(x):
        return Task.of(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1


# Generated at 2022-06-18 02:12:36.069969
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:12:45.956127
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:44.551998
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:48.156591
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:51.206643
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:59.186784
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def add_one(value):
            return value + 1

        def fork(reject, resolve):
            return resolve(1)

        task = Task(fork)
        result = task.map(add_one)
        assert result.fork(lambda _: False, lambda arg: arg == 2)

    def test_map_reject():
        def add_one(value):
            return value + 1

        def fork(reject, resolve):
            return reject(1)

        task = Task(fork)
        result = task.map(add_one)
        assert result.fork(lambda arg: arg == 1, lambda _: False)

    test_map_resolve()
    test_map_reject()


# Generated at 2022-06-18 02:14:03.284671
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.map(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:14:11.678986
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

   

# Generated at 2022-06-18 02:14:15.793057
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def sub(x):
        return x - 1

    assert Task.of(1).map(add).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(mul).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(div).fork(lambda x: x, lambda x: x) == 0.5
    assert Task.of(1).map(sub).fork(lambda x: x, lambda x: x) == 0


# Generated at 2022-06-18 02:14:22.267038
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve(resolve, reject):
        resolve(1)

    def test_map_reject(resolve, reject):
        reject(1)

    def test_map_fn(value):
        return value + 1

    assert Task(test_map_resolve).map(test_map_fn).fork(lambda x: x, lambda x: x) == 2
    assert Task(test_map_reject).map(test_map_fn).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-18 02:14:26.349053
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    task = task.bind(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:14:32.334219
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def add_one(value):
            return value + 1

        def resolve(value):
            assert value == 2

        Task.of(1).map(add_one).fork(lambda _: None, resolve)

    def test_map_reject():
        def add_one(value):
            return value + 1

        def reject(value):
            assert value == 1

        Task.reject(1).map(add_one).fork(reject, lambda _: None)

    test_map_resolve()
    test_map_reject()
