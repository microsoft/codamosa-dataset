

# Generated at 2022-06-18 02:06:17.052791
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3


# Generated at 2022-06-18 02:06:20.774185
# Unit test for method map of class Task
def test_Task_map():
    # Test for resolved Task
    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2

    # Test for rejected Task
    assert Task.reject(1).map(lambda x: x + 1).fork(lambda x: x, None) == 1


# Generated at 2022-06-18 02:06:28.547375
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:06:39.679893
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    def test_bind(x):
        return Task.of(x) \
            .bind(add) \
            .bind(mul) \
            .bind(div) \
            .bind(sub)


# Generated at 2022-06-18 02:06:49.013668
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_function(value):
        """
        Test function for Task.bind method.

        :param value: value to store in Task
        :type value: A
        :returns: new Task with mapped resolve attribute
        :rtype: Task[Function(resolve, reject -> A | B]
        """
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:06:56.082103
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:07.148049
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:10.012494
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(mapper)
    assert task.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:07:16.601181
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:26.033195
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:07:34.771178
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    assert Task.of(1).map(add).fork(None, lambda x: x) == 2
    assert Task.of(1).map(mul).fork(None, lambda x: x) == 2
    assert Task.of(1).map(div).fork(None, lambda x: x) == 0.5


# Generated at 2022-06-18 02:07:41.283050
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    assert Task.of(1).bind(add_one).bind(add_two).bind(add_three).fork(
        lambda value: None,
        lambda value: value
    ) == 7


# Generated at 2022-06-18 02:07:44.049591
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:48.431551
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:07:57.506434
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(error).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:08:02.918545
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def sub(x):
        return x - 1

    def error(x):
        raise Exception(x)

    def test_map(x, fn):
        return Task.of(x).map(fn).fork(lambda x: x, lambda x: x)

    assert test_map(1, add) == 2
    assert test_map(1, mul) == 2
    assert test_map(2, div) == 1
    assert test_map(2, sub) == 1
    assert test_map(1, error) == 1


# Generated at 2022-06-18 02:08:11.269937
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fork_reject(reject, resolve):
        reject(1)

    def fork_reject_2(reject, resolve):
        reject(2)

    def fork_resolve_2(reject, resolve):
        resolve(2)

    def fork_resolve_3(reject, resolve):
        resolve(3)

    def fork_resolve_4(reject, resolve):
        resolve(4)

    def fork_resolve_5(reject, resolve):
        resolve(5)

    def fork_resolve_6(reject, resolve):
        resolve(6)

    def fork_resolve_7(reject, resolve):
        resolve(7)

    def fork_resolve_8(reject, resolve):
        resolve

# Generated at 2022-06-18 02:08:20.043299
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:08:30.458928
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def multiply(x):
        return Task.of(x * 2)

    def divide(x):
        return Task.of(x / 2)

    def reject(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(multiply).bind(divide).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(add).bind(multiply).bind(divide).bind(reject).fork(
        lambda x: x,
        lambda x: x
    ) == 1


# Generated at 2022-06-18 02:08:34.210703
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fn(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:08:48.530950
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

   

# Generated at 2022-06-18 02:08:50.692517
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(1).map(add_one).fork(None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:00.858108
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:09:10.052468
# Unit test for method map of class Task
def test_Task_map():
    def test_map_with_resolve():
        def mapper(value):
            return value + 1

        def fork(reject, resolve):
            resolve(1)

        task = Task(fork)
        mapped_task = task.map(mapper)

        assert mapped_task.fork(lambda _: None, lambda value: value) == 2

    def test_map_with_reject():
        def mapper(value):
            return value + 1

        def fork(reject, resolve):
            reject(1)

        task = Task(fork)
        mapped_task = task.map(mapper)

        assert mapped_task.fork(lambda value: value, lambda _: None) == 1

    test_map_with_resolve()
    test_map_with_reject()


# Generated at 2022-06-18 02:09:12.996566
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    assert Task.of(1).map(add).map(mul).fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-18 02:09:16.873086
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:09:20.142114
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    task_result = task.bind(lambda x: Task.of(x + 1))
    assert task_result.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-18 02:09:22.492051
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:09:29.919443
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:09:41.737421
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:00.599205
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def fork_reject(reject, resolve):
        return reject(1)

    def fork_reject_2(reject, resolve):
        return reject(2)

    def fork_resolve_2(reject, resolve):
        return resolve(2)

    def fork_resolve_3(reject, resolve):
        return resolve(3)

    def fork_resolve_4(reject, resolve):
        return resolve(4)

    def fork_resolve_5(reject, resolve):
        return resolve(5)

    def fork_resolve_6(reject, resolve):
        return resolve(6)

    def fork_resolve_7(reject, resolve):
        return resolve(7)


# Generated at 2022-06-18 02:10:04.514338
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:14.617369
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).fork(lambda x: x, lambda x: x) == 1.5
    assert Task.of(1).bind(add).bind(error).bind(div).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).bind(add).bind(mul).bind(error).fork(lambda x: x, lambda x: x) == 3

# Generated at 2022-06-18 02:10:18.040236
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_function(value):
        """
        Test function for Task.bind.
        """
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(lambda _: False, lambda arg: arg == 2)


# Generated at 2022-06-18 02:10:27.297020
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:10:37.770642
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def error(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(error).bind(sub).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 2

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:10:42.063890
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    assert Task(fork).bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:10:49.126707
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(lambda _: None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(lambda _: None, lambda value: value) == 4


# Generated at 2022-06-18 02:10:51.438363
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(test_fn).fork(lambda _: False, lambda arg: arg == 2)


# Generated at 2022-06-18 02:10:56.145746
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    def fn(value):
        return Task.of(value + 1)

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    result = task.bind(fn)

    assert result.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:20.254521
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return value + 1

    task = Task(fork)
    mapped_task = task.map(mapper)

    assert mapped_task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:28.891327
# Unit test for method map of class Task
def test_Task_map():
    def test_map_resolve():
        def fn(value):
            return value + 1

        def fork(reject, resolve):
            return resolve(1)

        task = Task(fork)
        task = task.map(fn)
        assert task.fork(lambda _: None, lambda value: value) == 2

    def test_map_reject():
        def fn(value):
            return value + 1

        def fork(reject, resolve):
            return reject(1)

        task = Task(fork)
        task = task.map(fn)
        assert task.fork(lambda value: value, lambda _: None) == 1

    test_map_resolve()
    test_map_reject()


# Generated at 2022-06-18 02:11:36.491895
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    def mul(x):
        return x * 2

    def div(x):
        return x / 2

    def identity(x):
        return x

    def add_sub(x):
        return Task.of(x).map(add).map(sub)

    def add_sub_mul(x):
        return Task.of(x).map(add).map(sub).map(mul)

    def add_sub_mul_div(x):
        return Task.of(x).map(add).map(sub).map(mul).map(div)


# Generated at 2022-06-18 02:11:39.375330
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:11:42.493504
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        return Task.of(value).map(lambda arg: arg + 1)

    assert test_map(1).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-18 02:11:52.972676
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

   

# Generated at 2022-06-18 02:12:02.158451
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:12:11.129037
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    assert Task.of(1).map(add_one).map(add_two).map(add_three).map(add_four).map

# Generated at 2022-06-18 02:12:19.965622
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

   

# Generated at 2022-06-18 02:12:23.628375
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(
        lambda x: x,
        lambda x: x
    ) == 7


# Generated at 2022-06-18 02:13:18.462591
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    def add_five(value):
        return value + 5

    def add_six(value):
        return value + 6

    def add_seven(value):
        return value + 7

    def add_eight(value):
        return value + 8

    def add_nine(value):
        return value + 9

    def add_ten(value):
        return value + 10

    def add_eleven(value):
        return value + 11

    def add_twelve(value):
        return value + 12

    def add_thirteen(value):
        return value + 13

   

# Generated at 2022-06-18 02:13:22.528194
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:32.144815
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def add_three(x):
        return x + 3

    def add_four(x):
        return x + 4

    def add_five(x):
        return x + 5

    def add_six(x):
        return x + 6

    def add_seven(x):
        return x + 7

    def add_eight(x):
        return x + 8

    def add_nine(x):
        return x + 9

    def add_ten(x):
        return x + 10

    def add_eleven(x):
        return x + 11

    def add_twelve(x):
        return x + 12

    def add_thirteen(x):
        return x + 13

   

# Generated at 2022-06-18 02:13:43.306613
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def mul(x):
        return Task.of(x * 2)

    def div(x):
        return Task.of(x / 2)

    def sub(x):
        return Task.of(x - 1)

    def err(x):
        return Task.reject(x)

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(sub).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind(div).bind(err).fork(
        lambda x: x,
        lambda x: x
    ) == 1

    assert Task.of(1).bind(add).bind(mul).bind

# Generated at 2022-06-18 02:13:47.598714
# Unit test for method map of class Task
def test_Task_map():
    def task_mapper(value):
        return value + 1

    def task_fork(reject, resolve):
        return resolve(1)

    task = Task(task_fork)
    mapped_task = task.map(task_mapper)
    assert mapped_task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:13:56.631314
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:13:59.283778
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)
    assert task.bind(fn).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-18 02:14:08.783672
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)

    def add_six(value):
        return Task.of(value + 6)

    def add_seven(value):
        return Task.of(value + 7)

    def add_eight(value):
        return Task.of(value + 8)

    def add_nine(value):
        return Task.of(value + 9)

    def add_ten(value):
        return Task.of(value + 10)

# Generated at 2022-06-18 02:14:13.331345
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    assert Task.of(1).map(add_one).fork(None, lambda value: value) == 2
    assert Task.of(1).map(add_one).map(add_two).fork(None, lambda value: value) == 3
    assert Task.of(1).map(add_one).map(add_two).map(add_three).fork(None, lambda value: value) == 4


# Generated at 2022-06-18 02:14:14.974945
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    assert task.bind(lambda x: Task.of(x + 1)).fork(lambda x: x, lambda x: x) == 2
