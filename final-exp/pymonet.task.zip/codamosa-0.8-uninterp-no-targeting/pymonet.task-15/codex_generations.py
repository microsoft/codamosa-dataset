

# Generated at 2022-06-21 19:34:20.631696
# Unit test for method map of class Task
def test_Task_map():
    from nose.tools import assert_equal

    def method(x):
        return 2 * x

    def fork(reject, resolve):
        resolve(10)

    task = Task(fork)
    mappedTask = task.map(method)
    assert_equal(mappedTask.fork(None, lambda value: value), 20)


# Generated at 2022-06-21 19:34:23.232581
# Unit test for constructor of class Task
def test_Task():
    assert Task
    assert Task(lambda _, r: r(1))
    assert Task.of(1)
    assert Task.reject(1)


# Generated at 2022-06-21 19:34:24.268914
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1)



# Generated at 2022-06-21 19:34:32.273875
# Unit test for method map of class Task
def test_Task_map():
    def test_resolve():
        assert Task.of('value').map(lambda x: x + '1').fork(
            lambda x: None,
            lambda x: x
        ) == 'value1'

    def test_reject():
        assert Task.reject('value').map(lambda x: x + '1').fork(
            lambda x: x,
            lambda x: None
        ) == 'value'

    test_resolve()
    test_reject()


# Generated at 2022-06-21 19:34:38.551340
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    task = Task.of(1)
    task_resolved = task.bind(lambda val: Task.of(val * 2))
    task_rejected = task.bind(lambda val: Task.reject(val * 2))
    assert type(task_resolved) == Task
    assert task_resolved.fork(lambda _: None, lambda val: val) == 2
    assert type(task_rejected) == Task
    assert task_rejected.fork(lambda val: val, lambda _: None) == 2


# Generated at 2022-06-21 19:34:43.010385
# Unit test for method bind of class Task
def test_Task_bind():
    def return_rejected(arg):
        return Task.reject(arg)

    def call_fork(reject, resolve):
        return Task.of(1).bind(return_rejected).fork(reject, resolve)


# Generated at 2022-06-21 19:34:45.333519
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 2).fork(None, pick) == 3


# Generated at 2022-06-21 19:34:50.277952
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.reject(1).map(lambda x: x + 2).bind(
        lambda x: Task((lambda r, s: s(x + 1)) if x % 2 else (lambda r, s: r(x + 2)))
    )

    assert task.fork(lambda x: x, lambda x: x) == 4

# Generated at 2022-06-21 19:34:54.478416
# Unit test for method map of class Task
def test_Task_map():
    def f1(x):
        return x

    def f2(x):
        return x + 1

    def f3(x):
        return x + 2

    def f4(x):
        return x + 3

    def f5(x):
        return x + 4

    def f6(x):
        return x + 5

    x = Task.of(1)
    assert x.map(f1) is not None
    assert x.map(f1).fork(f1, f3)(3) == 3
    assert x.map(f1).map(f2).map(f3).map(f4).map(f5).map(f6).fork(f1, f3)(3) == 16


# Generated at 2022-06-21 19:35:02.073640
# Unit test for method map of class Task
def test_Task_map():
    """
    >>> from Taask import Task
    >>> def add(a, b): return a + b
    ...
    >>> add_task = Task(lambda _, resolve: resolve(10))
    >>> add_task.map(lambda x: add(x, 5)).fork(lambda x: x, None)
    15
    """
    pass

# Generated at 2022-06-21 19:35:07.879802
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task constructor
    """
    def fork(reject, resolve):
        return reject(10)

    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-21 19:35:14.263523
# Unit test for constructor of class Task
def test_Task():
    def fail(reject):
        return reject(Exception("REJECT"))

    def success(resolve):
        return resolve(42)

    faile = Task(fail)
    succe = Task(success)

    def fork(succ, fail):
        return succe.fork(lambda _: fail("FAIL"), lambda _: succ("SUCCES"))

    assert fork("SUCCES", "FAIL") == "FAIL"
    assert fork("SUCCES", "FAIL") == "FAIL"


# Generated at 2022-06-21 19:35:18.267667
# Unit test for method map of class Task
def test_Task_map():

    def mapper_func(value):
        return value + 1

    # Create resolved task
    task = Task.of(1)

    # Create new task with mapped resolve attribute
    new_task = task.map(mapper_func)

    # Check that new task is resolved
    assert new_task.fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-21 19:35:25.079080
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        return value + 1

    def reject(value):
        return value

    def make_task(reject_value, resolve_value):
        def some_function(reject, resolve):
            return resolve(resolve_value)

        return Task(some_function)

    task = Task.of(1)
    task2 = task.bind(lambda value: make_task(None, resolve(value)))
    assert task2.fork(reject, resolve) == 2

    task = Task.reject(1)
    task2 = task.bind(lambda value: make_task(None, resolve(value)))
    assert task2.fork(reject, resolve) == 1

    task = Task.of(None)
    task2 = task.bind(lambda value: Task.of(resolve(2)))

# Generated at 2022-06-21 19:35:29.186945
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: resolve(5)) == Task(lambda reject, resolve: resolve(5))
    assert Task(lambda reject, resolve: resolve(5)) != Task(lambda reject, resolve: resolve(4))


# Generated at 2022-06-21 19:35:33.023886
# Unit test for method map of class Task
def test_Task_map():
    def function(value):
        return value + 1

    task = Task(lambda reject, resolve: resolve(2))

    assert task.map(function).fork(lambda _: None, lambda value: value) == 3


# Generated at 2022-06-21 19:35:38.311323
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case():
        def resolve_case(): 
            task = Task.of(1).bind(lambda arg: Task.of(arg + 1))
            assert task.fork(lambda arg: arg, lambda arg: arg) == 2

        def reject_case(): 
            task = Task.of(1).bind(lambda arg: Task.reject(arg + 1))
            assert task.fork(lambda arg: arg, lambda arg: arg) == 2

        resolve_case()
        reject_case()

    test_case()

# Generated at 2022-06-21 19:35:43.805690
# Unit test for method map of class Task
def test_Task_map():
    def curry(fn, *args, **kwargs):
        return lambda *args2, **kwargs2: fn(*args, *args2, **kwargs, **kwargs2)

    assert Task(lambda reject, resolve: resolve(1)).map(
        curry(lambda x: pow(x, 2))
    ).fork(
        lambda error: False,
        lambda data: data == 1
    )



# Generated at 2022-06-21 19:35:49.005376
# Unit test for method bind of class Task
def test_Task_bind():
    """
    It should return result of called binded function with Task value.
    """
    def mapper(val):
        return val * 2

    def validator(val):
        if val % 2 == 0:
            return Task.of(val)
        return Task.reject(val)

    assert Task.of(12).bind(mapper).bind(validator).fork(id, id) == 24
    assert Task.of(11).bind(mapper).bind(validator).fork(id, id) == 11


# Generated at 2022-06-21 19:35:52.346184
# Unit test for constructor of class Task
def test_Task():
    def mock_fork(reject, resolve):
        resolve(42)
    task = Task(mock_fork)

    assert task.fork(lambda arg: arg, lambda arg: arg) == 42


# Generated at 2022-06-21 19:36:04.223437
# Unit test for method bind of class Task
def test_Task_bind():
    def identity_bind(value): return Task.of(value)

    def identity(value): return value

    task = Task.of(1)
    assert task.bind(identity_bind).bind(identity).fork(lambda x: x, identity) == 1
    assert task.map(identity).map(identity).fork(lambda x: x, identity) == 1
    assert task.map(identity).map(identity).map(identity).fork(lambda x: x, identity) == 1
    assert task.map(identity).bind(identity_bind).map(identity).fork(lambda x: x, identity) == 1
    assert task.map(identity).bind(identity_bind).bind(identity_bind).map(identity).fork(lambda x: x, identity) == 1

# Generated at 2022-06-21 19:36:06.444543
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(5).map(lambda x: x * 2).fork(None, lambda value: value) == 10


# Generated at 2022-06-21 19:36:14.113116
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task bind method.
    """
    task = Task(lambda reject, resolve: resolve(2))
    task2 = Task(lambda reject, resolve: resolve(1))

    def mapper(value):
        """
        Add 2 to value.

        :param value: value to add value
        :type value: Int
        :return: added value
        :rtype: Int
        """
        return value + 2

    def task_mapper(value):
        """
        return Task with rejected value

        :param value: value to return
        :type value: Int
        :returns: rejected Task
        :rtype: Task[reject, mapped_value]
        """
        return Task(lambda reject, _: reject(value))

    assert task.map(mapper).fork(None, Int) == 4
    assert task

# Generated at 2022-06-21 19:36:19.875394
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind method
    """
    def resolve(arg):
        assert arg == 'test'

    def reject(_):
        assert False

    def fn(arg):
        assert arg == 'test'
        return Task.of('test1')

    Task.of('test').bind(fn).fork(reject, resolve)
# End of Unit test for method bind of class Task


# Generated at 2022-06-21 19:36:24.787058
# Unit test for method map of class Task
def test_Task_map():
    def add2(x):
        return x + 2
    def add3(y):
        return y + 3
    task = Task.of(1)
    assert task.map(add2).fork(
        lambda x: error('error'),
        lambda x: x 
    ) == 3
    assert task.map(add2).map(add3).fork(
        lambda x: error('error'),
        lambda x: x 
    ) == 6


# Generated at 2022-06-21 19:36:32.115340
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)

    def adder(value):
        return Task.of(value + 1)

    assert(1 == task.fork(lambda _: None, lambda v: v))
    assert(2 == task.bind(adder).fork(lambda _: None, lambda v: v))
    assert(3 == task.bind(adder).bind(adder).fork(lambda _: None, lambda v: v))

    # check that result is Task
    assert isinstance(task.bind(adder), Task)


# Generated at 2022-06-21 19:36:36.000880
# Unit test for constructor of class Task
def test_Task():
    """
    Check correct work of constructor of Task
    """
    fn = lambda _, resolve: resolve(5)
    task = Task(fn)
    assert task.fork is fn


# Generated at 2022-06-21 19:36:40.824884
# Unit test for method map of class Task
def test_Task_map():
    def function(x):
        return x + 1

    assert Task.of(5).map(function).fork(lambda x: x + 5, lambda x: x - 7) == -1
    assert Task.reject(5).map(function).fork(lambda x: x + 5, lambda x: x - 7) == 10


# Generated at 2022-06-21 19:36:45.877761
# Unit test for constructor of class Task
def test_Task():
    def mock_fork(reject, resolve):
        reject('some_error')

    task = Task(mock_fork)

    assert task.fork == mock_fork


# Generated at 2022-06-21 19:36:51.600723
# Unit test for method map of class Task
def test_Task_map():
    succeed = Task.of(True)
    fail = Task.reject(False)

    def assert_value(arg):
        assert arg

    def assert_value_in_Task(arg):
        assert arg

    succeed.map(assert_value).fork(None, assert_value_in_Task)
    fail.map(assert_value).fork(assert_value_in_Task, None)


# Generated at 2022-06-21 19:37:04.353023
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2


# Generated at 2022-06-21 19:37:15.361880
# Unit test for method bind of class Task
def test_Task_bind():
    import unittest
    import sys
    sys.path.append('../')
    from src.utils.monad import MonadException
    import src.asyncio_tasks.task as T
    import src.utils.logger as L

    logger = L.getLogger(__name__)

    class TaskTest(unittest.TestCase):
        def setUp(self):
            pass

        def test_bind(self):
            forked = T.Task(lambda reject, resolve: setattr(resolve, '__called__', 'called'))
            forked.fork(
                lambda arg: setattr(arg, '__called__', 'called'),
                lambda _: setattr(_, '__called__', 'called')
            )

# Generated at 2022-06-21 19:37:16.646179
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task.of(None), Task)


# Generated at 2022-06-21 19:37:18.707926
# Unit test for constructor of class Task
def test_Task():
    """Unit test for constructor of class Task"""
    task = Task(lambda reject, resolve: resolve('str'))

    assert isinstance(task, Task)
    assert hasattr(task, 'fork')
    assert callable(task.fork)


# Generated at 2022-06-21 19:37:27.788940
# Unit test for method map of class Task
def test_Task_map():
    # Part 1
    x = Task.of(42).map(lambda v: v + 1)

# Generated at 2022-06-21 19:37:33.131718
# Unit test for method bind of class Task
def test_Task_bind():
    # create tasks
    task_add = Task(lambda _, resolve: resolve(1 + 1))
    task_sub = Task(lambda _, resolve: resolve(1 - 1))

    # bind tasks
    result = task_add.bind(lambda x: task_sub).fork(lambda x: None, lambda x: x)

    # check result
    assert result == 0


# Generated at 2022-06-21 19:37:35.985919
# Unit test for constructor of class Task
def test_Task():
    assert issubclass(Task, object)
    assert hasattr(Task, '__init__')
    assert hasattr(Task, 'fork')


# Generated at 2022-06-21 19:37:41.760626
# Unit test for method map of class Task
def test_Task_map():
    def _create_task(resolve, _):
        resolve(3)

    def _test_case(arg, expected):
        test = Task(_create_task)
        assert test.map(lambda value: value + arg).fork(None, lambda value: value) == expected, 'method map works incorrectly'

    _test_case(1, 4)
    _test_case(-2, 1)
    _test_case(-3, 0)


# Generated at 2022-06-21 19:37:47.662004
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Testing if method bind work in expected way.
    """
    def resolve(value):
        return Task.of(value)

    assert Task(
        lambda reject, resolve: resolve(3)
    ).bind(resolve).fork(
        lambda result: True,
        lambda result: False
    )

    assert Task(
        lambda reject, resolve: reject(4)
    ).bind(resolve).fork(
        lambda result: False,
        lambda result: True
    )


# Generated at 2022-06-21 19:37:50.553893
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    assert Task(lambda _, resolve: resolve(1)).bind(
        lambda result: Task.of(result + 2)
    ).fork(lambda _: None, lambda arg: arg) == 3


# Generated at 2022-06-21 19:38:19.163076
# Unit test for method bind of class Task
def test_Task_bind():
    """Task map method."""
    deferred1 = Task(lambda reject, resolve: resolve('foo'))
    deferred2 = Task(lambda reject, resolve: resolve('bar'))
    deferred3 = Task(lambda reject, resolve: reject('baz'))

    assert deferred1.bind(lambda _: deferred2).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 'bar'
    assert deferred3.bind(lambda _: deferred2).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 'baz'

if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-21 19:38:24.421469
# Unit test for method map of class Task
def test_Task_map():
    def f1(x):
        return x + 1
    def f2(x):
        return x + 2


# Generated at 2022-06-21 19:38:31.165844
# Unit test for constructor of class Task
def test_Task():
    """
    Just call constructor of Task and check
    for its correctness by map, fork methods.
    """
    fork = lambda reject, resolve: resolve(1)

    task = Task(fork)
    assert isinstance(task, Task)
    assert task.fork(lambda _: None, lambda arg: arg) == 1
    assert task.map(lambda arg: arg + 2).fork(lambda _: None, lambda arg: arg) == 3


# Generated at 2022-06-21 19:38:36.583023
# Unit test for method map of class Task

# Generated at 2022-06-21 19:38:40.123272
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task(lambda _, resolve: resolve(1))

    new_task = task.map(fn)

    assert 2 == new_task.fork(lambda _: None, lambda value: value)



# Generated at 2022-06-21 19:38:43.005660
# Unit test for method map of class Task
def test_Task_map():
    """
    Check that method map of class Task work properly.
    """
    assert Task.of(42).map(lambda x: x + 1).fork(identity, identity) == 43



# Generated at 2022-06-21 19:38:50.396766
# Unit test for constructor of class Task
def test_Task():
    def success_callable(reject, resolve):
        resolve('success value')

    def fail_callable(reject, resolve):
        reject('fail value')


# Generated at 2022-06-21 19:38:55.871840
# Unit test for method map of class Task
def test_Task_map():
    # good cases
    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2, "test_Task_map: method map with lambda"
    assert Task.of(2).map(lambda x: x - 2).fork(None, lambda x: x) == 0, "test_Task_map: method map with lambda"
    assert Task.of("Test").map(lambda x: x + " String").fork(None, lambda x: x) == "Test String"


# Generated at 2022-06-21 19:39:01.186450
# Unit test for method bind of class Task
def test_Task_bind():
    def foo(value):
        return Task.reject(value)

    def bar(value):
        return Task.of(value + value)


# Generated at 2022-06-21 19:39:12.822579
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    # Test if we call bind with Task that has resolve value
    def test_1():
        """
        We call bind with Task that has resolve value
        """
        got = Task.of('foo') \
            .bind(lambda value: Task.reject(value + ' bar')) \
            .fork(
                lambda reject_value: 'reject({})'.format(reject_value),
                lambda resolve_value: 'resolve({})'.format(resolve_value)
            )
        expected = 'reject(foo bar)'
        assert got == expected

    test_1()

    # Test if we call bind with Task that has reject value
    def test_2():
        """
        We call bind with Task that has reject value
        """

# Generated at 2022-06-21 19:39:58.659997
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda _, resolve: resolve(3)).bind(lambda _: Task.of(4)).fork(
        lambda x: None,
        lambda x: x
    ) == 4


# Generated at 2022-06-21 19:40:02.236497
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(1).bind(lambda x: Task.of(x ** 2)).fork(
        lambda x: None,
        lambda x: print("x ** 2 = {}".format(x))
    )
    # x ** 2 = 1


# Generated at 2022-06-21 19:40:04.324766
# Unit test for constructor of class Task
def test_Task():
    def fork(_, resolve):
        return resolve(1)

    task = Task(fork)
    assert isinstance(task, Task)


# Generated at 2022-06-21 19:40:06.320074
# Unit test for constructor of class Task
def test_Task():
    def fn(_, resolve):
        return resolve(True)

    assert Task(fn).fork(lambda _: False, lambda _: True)


# Generated at 2022-06-21 19:40:08.161375
# Unit test for method map of class Task
def test_Task_map():
    def add_1(value):
        return value + 1

    assert Task.of(0).map(add_1).fork(None, identity) == 1


# Generated at 2022-06-21 19:40:20.313697
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind(fn) with two Task one resolved, second rejected.
    Test function bind Task.bind(fn) with two Task one resolved, second rejected.
    """
    def inner_fn(value):
        return Task.of(value + ' ' + 'inner_fn')

    def inner_fn_reject(value):
        return Task.reject(value + ' ' + 'inner_fn')

    task_resolved = Task.of('resolved')
    assert task_resolved.bind(inner_fn).fork(print, print) == 'resolved inner_fn'

    task_reject = Task.reject('reject')
    assert task_reject.bind(inner_fn_reject).fork(print, print) == 'reject inner_fn'
# End test_Task_bind()


# Generated at 2022-06-21 19:40:28.004952
# Unit test for method bind of class Task
def test_Task_bind():
    def mock_Task_fn(value):
        def result(reject, resolve):
            if value > 10:
                resolve(value)
            else:
                reject(value)

        return Task(result)


# Generated at 2022-06-21 19:40:30.815023
# Unit test for method map of class Task
def test_Task_map():
    def reject(arg):
        print("reject", arg)

    def resolve(arg):
        print("resolve", arg)


    a = Task.of("Hello")
    b = a.map(lambda x: x + " World")
    b.fork(reject, resolve)

# Generated at 2022-06-21 19:40:40.080918
# Unit test for method map of class Task
def test_Task_map():
    """Test map function of Task class."""

    def mapper(v):
        return v * 2

    def fork(reject, resolve):
        return resolve(3)

    def fork_with_reject(reject, resolve):
        return reject(3)

    assert (Task(fork).map(mapper).fork(
        lambda arg: arg,
        lambda arg: arg
    )) == 6

    assert (Task(fork_with_reject).map(mapper).fork(
        lambda arg: arg,
        lambda arg: arg
    )) == 3

    assert Task.of(3).map(mapper).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 6


# Generated at 2022-06-21 19:40:47.255302
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)
        return None

    result = None

    def fork_result(reject, resolve):
        nonlocal result
        result = resolve(None)
        return None

    task = Task(fork)
    result_task = task.bind(lambda x: Task(fork_result))
    assert result_task.fork(
        lambda x: None,
        lambda x: None
    ) is None
    assert result is None


# Generated at 2022-06-21 19:42:32.655241
# Unit test for method bind of class Task
def test_Task_bind():
    def success(a, b):
        simpleTest(a, 2)
        simpleTest(b, 3)

    def fail(e):
        failTest(e)

    Task.of(1).bind(lambda x: Task.of(x + 1)).bind(
        lambda y: Task.of(y + 1)
    ).fork(fail, success)

# Generated at 2022-06-21 19:42:41.385353
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    :return: list of tuples with result and expected result
    :rtype: List[Tuple[Any, Any]]
    """
    # call bind with another Task which call fork with reject
    test_case_1 = Task(
        lambda _, resolve: resolve(23)) \
        .bind(lambda n: Task.reject('Error'))

    # call bind with another Task which call fork with resolve
    test_case_2 = Task(
        lambda _, resolve: resolve(23)) \
        .bind(lambda n: Task.of(n + 123))


# Generated at 2022-06-21 19:42:43.658588
# Unit test for constructor of class Task
def test_Task():
    # example
    fork = lambda _, resolve: resolve(1)
    assert isinstance(Task(fork), Task)


# Generated at 2022-06-21 19:42:47.442032
# Unit test for constructor of class Task
def test_Task():
    def fn(reject, resolve):
        if reject:
            return reject(1)
        else:
            return resolve(2)

    t = Task(fn)
    assert t.fork(lambda arg: arg, lambda arg: arg) == 1
    assert t.fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-21 19:42:59.786484
# Unit test for method map of class Task
def test_Task_map():
    """
    Test of method map of class Task.
    """

    def func(resolve, reject):
        resolve('test')

    def test_func(value):
        return 'test ' + value

    def test_func_2(value):
        return 'test ' + value

    test_task = Task(func)
    test_task_2 = Task(func)

    assert test_task.map(test_func).fork(lambda arg: arg,
                                         lambda arg: arg) == 'test test', \
        'method map fail with simple function and task'

    assert test_task_2.map(test_func).fork(lambda arg: arg,
                                           lambda arg: arg) == 'test test', \
        'method map fail with simple function and task'


# Generated at 2022-06-21 19:43:02.025422
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda _, resolve: resolve(10))
    task = task.map(lambda value: value * 2)
    assert task.fork(lambda _: None, lambda value: None) == 20



# Generated at 2022-06-21 19:43:03.768855
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('rejected')

    task = Task(fork)
    test.assertEquals(fork, task.fork)


# Generated at 2022-06-21 19:43:07.051519
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task
    :return:
    """

# Generated at 2022-06-21 19:43:10.632425
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        assert id(value) == id(2)

    def reject(value):
        assert False, "Must not be called"


# Generated at 2022-06-21 19:43:12.389940
# Unit test for constructor of class Task
def test_Task():
    task = Task(None)

    assert_equal(task.fork, None)
