

# Generated at 2022-06-21 19:34:22.241025
# Unit test for constructor of class Task
def test_Task():
    t = Task.of(1)

# Generated at 2022-06-21 19:34:26.790701
# Unit test for constructor of class Task
def test_Task():
    # Case: of
    assert Task.of(1) == Task(lambda _, resolve: resolve(1))

    # Case: reject
    assert Task.reject('error') == Task(lambda reject, _: reject('error'))


# Generated at 2022-06-21 19:34:32.124873
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    assert task.bind(lambda a: Task.reject(a + 1)).fork(lambda value: value, lambda _: None) == 2
    assert task.bind(lambda a: Task.of(a + 1)).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-21 19:34:35.283085
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(a):
        return Task.reject(a)

    t = Task.of(1)
    assert t.bind(test_function) == Task.of(1).reject()

# Generated at 2022-06-21 19:34:42.425839
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Case when Task is resolved with value and bind method is called
    """
    def mapper(value):
        if value == 10:
            return Task.of(value)
        else:
            return Task.reject(value)

    result = Task.of(10).bind(mapper)

    # check that result is resolved
    assert_equal(result.fork(
        lambda arg: 'fail',
        lambda arg: 'resolve()'
    ), 'resolve()')

# Generated at 2022-06-21 19:34:47.779095
# Unit test for method bind of class Task
def test_Task_bind():
    t1 = Task.of(1)
    t2 = t1.bind(lambda x: Task.of(x + 1))
    assert t2.fork(lambda x: x, lambda y: y) == 2

# Generated at 2022-06-21 19:34:52.974574
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task constructor.
    """
    # :Reject, :Resolve -> task
    def fork(reject, resolve):
        return reject(5)

    # task = Task.of(5)
    task = Task(fork)

    assert isinstance(task, Task)
    assert task.fork is fork


# Generated at 2022-06-21 19:35:00.647998
# Unit test for method bind of class Task

# Generated at 2022-06-21 19:35:07.024660
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def mul(x):
        return x * 2

    add_mul = Task.of(1).map(add).map(mul)

    def resolve(x):
        assert x == 4

    def reject(x):
        assert False

    add_mul.fork(reject, resolve)
    print('.', end='')


# Generated at 2022-06-21 19:35:11.148663
# Unit test for method map of class Task

# Generated at 2022-06-21 19:35:21.067194
# Unit test for method map of class Task
def test_Task_map():
    def foo(reject, resolve):
        resolve(5)

    task = Task(foo)
    mapped_task = task.map(lambda x: x * 2)
    assert task.fork(
        lambda x: "REJECT" + str(x),
        lambda x: "RESOLVE" + str(x)
    ) == "RESOLVE5"
    assert mapped_task.fork(
        lambda x: "REJECT" + str(x),
        lambda x: "RESOLVE" + str(x)
    ) == "RESOLVE10"


# Generated at 2022-06-21 19:35:23.463285
# Unit test for method bind of class Task
def test_Task_bind():
    def add(num):
        return Task.of(num + 1)

    task = Task.of(1)
    task = task.bind(add)
    task = task.bind(add)

    assert task.fork(None, lambda num: num) == 3


# Generated at 2022-06-21 19:35:31.171545
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        print("resolve: " + repr(value))
        assert value == 2

    def resolve_1(value):
        print("resolve_1: " + repr(value))
        return Task.of(value * 2)

    def reject(value):
        print("reject: " + repr(value))
        assert False

    task = Task.of(1) \
        .bind(lambda a: resolve_1(a)) \
        .bind(lambda a: Task.of(a))

    task.fork(reject, resolve)


# Generated at 2022-06-21 19:35:35.294239
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map method.
    """
    task = Task.of(2)
    result = task.map(lambda x: x * 2)
    assert task.fork(lambda x: x, lambda x: x) == 2
    assert result.fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-21 19:35:44.863366
# Unit test for method map of class Task
def test_Task_map():
    """
    Create Task and resolve it with value 5.
    Then call map function and check that it return Task with new resolve.

    :returns: True if method working properly
    :rtype: Bool
    """
    value = 5
    new_value = value * 2

    task = Task.of(value)

    mapped_task = task.map(lambda v: v * 2)

    def another_mapped_task(reject, resolve):
        resolve(value * 2)

    assert task.fork(reject, resolve) == value
    assert mapped_task.fork(reject, resolve) == new_value
    assert Task(another_mapped_task).fork(reject, resolve) == new_value


# Generated at 2022-06-21 19:35:47.968417
# Unit test for constructor of class Task
def test_Task():
    """
    Task __init__(fork) test function.

    :return: True if tested unit is correct.
    :rtype: Boolean
    """
    def fork(reject, resolve):
        return resolve(2)

    assert Task(fork).fork(lambda a: a, lambda a: a) == 2



# Generated at 2022-06-21 19:35:59.569319
# Unit test for constructor of class Task
def test_Task():
    # test success
    def test_of(a):
        def fork(reject, resolve):
            resolve(a)
            return a

        assert a == Task(fork).fork(None, None)

    # test fail
    def test_of_error(a):
        def fork(reject, resolve):
            reject(a)
            return a

        assert a == Task(fork).fork(None, None)

    # test (Unit test)
    def test_constructor():
        def fork(reject, resolve):
            resolve(a)

        assert isinstance(Task(fork), Task)

    # test (Unit test)
    def test_static_method_of():
        def fork(reject, resolve):
            resolve(1)

        assert isinstance(Task.of(1), Task)

    # test (Unit test

# Generated at 2022-06-21 19:36:09.352793
# Unit test for constructor of class Task
def test_Task():
    # Task of constructor
    assert get_type(Task.of(1)) == '<class \'__main__.Task\'>'
    # Task reject constructor
    assert get_type(Task.reject(1)) == '<class \'__main__.Task\'>'
    # Task constructor
    assert get_type(Task(lambda _, __: 1)) == '<class \'__main__.Task\'>'
    # Task constructor with one argument
    assert get_type(Task(1)) == '<class \'__main__.Task\'>'
    # Task constructor with two arguments
    assert get_type(Task(1, 2)) == '<class \'__main__.Task\'>'
    # Task constructor with three arguments

# Generated at 2022-06-21 19:36:15.436927
# Unit test for method map of class Task
def test_Task_map():
    def result1(reject, resolve):
        assert False

    def result2(reject, resolve):
        assert reject == Just.of
        assert resolve == Just.reject

    def result3(reject, resolve):
        assert resolve(1) == Just.of(2)

    assert Task(result1).map(lambda x: x).fork(Just.of, Just.reject) == Just.of(Just.reject(None))
    assert Task(result1).map(lambda x: x).fork(Just.reject, Just.of) == Just.of(Just.reject(None))
    assert Task(result2).map(lambda x: x).fork(Just.of, Just.reject) == Just.of(Just.reject(None))

# Generated at 2022-06-21 19:36:19.774809
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fork(reject, resolve):
        return resolve([1, 2])
    def fn(value):
        return Task.of(sum(value))

    assert Task(test_fork).bind(fn).fork(lambda a: 'error', lambda b: b) == 3



# Generated at 2022-06-21 19:36:26.775256
# Unit test for method bind of class Task
def test_Task_bind():
    def add1(arg):
        return arg + 1

    def mul2(arg):
        return arg * 2

    def resolve(arg):
        return Task.of(arg)

    def test_execution_order():
        task = Task.reject(1)
        task = task.bind(add1)
        task = task.bind(mul2)
        task = task.bind(add1)
        task.fork(lambda x: x, lambda x: x)
        return task

    assert test_execution_order() == Task.reject(6)


# Generated at 2022-06-21 19:36:34.882914
# Unit test for method bind of class Task
def test_Task_bind():
    value = 'value'
    result = Task.of(value)
    def mapper(value):
        return Task.of(value.upper())
    mapped_result = result.bind(mapper)

    def check(reject, resolve):
        assert isinstance(resolve(value), Task)
        assert mapped_result.fork(
            reject,
            lambda arg: resolve(arg)
        ) == value.upper()
    Task(check).fork(lambda _: None, lambda _: None)

# Generated at 2022-06-21 19:36:39.315972
# Unit test for method bind of class Task
def test_Task_bind():
    """
    This function test method bind of class Task
    """
    def mapper(value):
        return value + 10

    def mapper2(value):
        return Task.of(value + 10)

    task = Task.of(10)
    task_resolved = task.bind(mapper2)
    assert task_resolved.fork(None, lambda arg: arg) == 20

    task_resolved = task.bind(mapper)
    assert task_resolved.fork(None, lambda arg: arg) == 20



# Generated at 2022-06-21 19:36:43.062457
# Unit test for method map of class Task
def test_Task_map():
    def task_fork(reject, resolve):
        resolve(2)

    task = Task(task_fork)
    assert task.fork == task_fork

    double = lambda arg: arg * 2
    task_double = task.map(double)
    assert task_double.fork(None, lambda arg: arg) == 4



# Generated at 2022-06-21 19:36:49.841259
# Unit test for method map of class Task
def test_Task_map():
    def mapped(reject, resolve):
        def mapper(value):
            return value + 1

        def source(reject_source, resolve_source):
            resolve_source(1)

        return Task(source).map(mapper).fork(reject, resolve)

    assert Forkable.of(mapped).fork(
        lambda reject: reject(1),
        lambda resolve: resolve(2)
    ) == 2



# Generated at 2022-06-21 19:36:53.892237
# Unit test for method map of class Task
def test_Task_map():
    def _(value):
        return value + 1

    task = Task.of(1).map(_)
    assert task.fork(lambda a: a, lambda a: a) == 2, "Should be equal to 2"



# Generated at 2022-06-21 19:37:01.900554
# Unit test for method map of class Task
def test_Task_map():
    task_source = Task.of(1)
    assert task_source.map(lambda x: x + 1).fork(lambda a: a, lambda a: a) == 2

    task_reject = Task.reject(1)
    assert task_reject.map(lambda x: x + 1).fork(lambda a: a, lambda a: a) == 1

    # not touch original task
    assert task_source.fork(lambda a: a, lambda a: a) == 1
    assert task_reject.fork(lambda a: a, lambda a: a) == 1


# Generated at 2022-06-21 19:37:08.392257
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    Test for method of class Task
    Test for method reject of class Task
    Test for method fork of class Task
    Test for method bind of class Task
    """
    def fn(a):
        return a * 2

    def mapper(_, resolve):
        resolve(2)

    def mapper_rejected(_, reject):
        reject(2)

    assert Task.of(1).map(fn).fork(
        lambda a: a + 2,
        lambda a: a - 3
    ) == 0

    assert Task(mapper).map(fn).fork(
        lambda a: a + 2,
        lambda a: a - 3
    ) == 0


# Generated at 2022-06-21 19:37:11.269791
# Unit test for constructor of class Task
def test_Task():
    """
    >>> task = Task(lambda _, resolve: resolve(5))
    >>> task.fork(lambda arg: arg, lambda arg: arg)
    5
    """


# Generated at 2022-06-21 19:37:15.150338
# Unit test for constructor of class Task
def test_Task():
    assert Task.of('value').fork(lambda x: x + '2', lambda y: y + '2') == 'value2'
    assert Task.reject('value').fork(lambda x: x + '2', lambda y: y + '2') == 'value2'


# Generated at 2022-06-21 19:37:24.030172
# Unit test for constructor of class Task
def test_Task():
    """
    Test Task with function and arguments

    :returns: assertion for result
    :rtype: Task[reject -> A, resolve -> B]
    """

    def task_fork(reject, resolve):
        """
        Just mock function with reject and resolve argument

        :param reject: function that called with reject
        :type reject: Function(value)
        :param reject: function that called with resolve
        :type reject: Function(value)
        """
        pass

    return Task(task_fork)

# Generated at 2022-06-21 19:37:32.281810
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task bind method
    """
    assert Task.of(1).bind(
        lambda value: Task.of(value + 1)
    ) == Task.of(2)

    assert Task.of(1).bind(
        lambda value: Task.reject(value + 1)
    ) == Task.reject(2)

    assert Task.reject(1).bind(
        lambda value: Task.of(value + 1)
    ) == Task.reject(1)

    assert Task.reject(1).bind(
        lambda value: Task.reject(value + 1)
    ) == Task.reject(1)


# Generated at 2022-06-21 19:37:37.126710
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def test_function(reject, resolve):
        return resolve(4)

    assert Task(test_function).map(add_one).map(add_two).fork(None, None) == 7


# Generated at 2022-06-21 19:37:41.449390
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve("value")

    task = Task(fork)

    def empty(value):
        return Task.of("mapped value")

    assert task.bind(empty).map(bool).fork(
        lambda _: False,
        lambda arg: arg
    )


# Generated at 2022-06-21 19:37:46.719024
# Unit test for method bind of class Task
def test_Task_bind():
    def first_function(_, resolve):
        resolve(1)
    def second_function(_, resolve):
        resolve(2)

    first_task = Task(first_function)
    second_task = Task(second_function)

    assert_equal(
        first_task
        .bind(lambda _: second_task)
        .fork(None, lambda val: val),
        2
    )

# Unit test of method map of class Task

# Generated at 2022-06-21 19:37:51.845333
# Unit test for method bind of class Task
def test_Task_bind():
    def add_10(value):
        def add(val):
            return val + 10

        return Task(lambda _, resolve: resolve(add(value)))

    task = Task.of(5)

    task_reject = Task.reject('reject')

    assert task_reject.bind(add_10).fork(lambda arg: arg, lambda _: 'Not valid') == 'reject'
    assert task.bind(add_10).fork(lambda _: 'Not valid', lambda arg: arg) == 15


# Generated at 2022-06-21 19:37:54.839043
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda a: a) == 1
    assert Task.reject(1).fork(None, lambda a: a) == 1


# Generated at 2022-06-21 19:37:59.488960
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(2)

    def fn(value):
        return Task.reject(value)

    result = task.bind(fn)

    def fork(reject, _):
        return reject(1)

    assert result.fork == fork

    result = Task.reject(2).bind(fn)

    assert result.fork == fork

# Generated at 2022-06-21 19:38:04.875840
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(1) \
        .map(lambda a: a + 1) \
        .map(lambda a: a * 2) \
        .bind(lambda a: Task.reject(a))

    result.fork(
        lambda a: print('rejected, value: ' + str(a)),
        lambda a: print('resolved, value: ' + str(a))
    )

    # print rejected, value: 4

if __name__ == "__main__":
    test_Task_bind()

# Generated at 2022-06-21 19:38:10.764419
# Unit test for method bind of class Task
def test_Task_bind():
    def print_result(name):
        def result(reject, resolve):
            return resolve(name)

        return Task(result)

    def test_case():
        assert 'bind' == Task.of('bind').bind(print_result).fork(
            lambda err: None,
            lambda value: value
        )
    test_case()



# Generated at 2022-06-21 19:38:20.323842
# Unit test for method bind of class Task
def test_Task_bind():
    """
    In this tests we should see "Yes!".

    :returns: result of test
    :rtype: Boolean
    """
    value = Task.of(True)
    result = value.bind(
        lambda arg: Task.of("Yes!") if arg else Task.of("No!")
    )

    def log_error(arg):
        print(arg)

    def log_value(arg):
        print(arg)

    result.fork(log_error, log_value)
    return result.fork(
        lambda arg: False,
        lambda arg: arg == "Yes!"
    )


# Generated at 2022-06-21 19:38:22.797226
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(2)).map(lambda x: x + 1).fork(None, lambda y: y) == 3


# Generated at 2022-06-21 19:38:27.315261
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for constructor of class Task
    """
    from nose.tools import assert_true

    @test
    def _():
        def fork_function():
            pass

        task = Task(fork_function)
        assert_true(task.fork == fork_function)


# Generated at 2022-06-21 19:38:32.117446
# Unit test for method bind of class Task
def test_Task_bind():
    # Test behavior in normal case
    inter_task = Task.of(1).bind(lambda value: Task.of(value + 1))
    assert inter_task.fork(lambda arg: arg, lambda arg: arg) == 2
    # Test behavior in case of rejected Task
    inter_task = Task.reject(1).bind(lambda value: Task.of(value + 1))
    assert inter_task.fork(lambda arg: arg, lambda arg: arg) == 1



# Generated at 2022-06-21 19:38:34.166484
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda a, b: a).fork(lambda a: a) == 1



# Generated at 2022-06-21 19:38:38.139515
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(12)

    task = Task(fork).map(lambda x: x * 2)
    assert task.fork(lambda x: False, lambda x: x) == 24



# Generated at 2022-06-21 19:38:43.455728
# Unit test for constructor of class Task
def test_Task():
    """Test function for constructor of class Task"""
    is_call_reject = False
    is_call_resolve = False

    def reject():
        nonlocal is_call_reject
        is_call_reject = True

    def resolve():
        nonlocal is_call_resolve
        is_call_resolve = True

    def fork(reject, resolve):
        reject()
        resolve()

    task = Task(fork)
    assert(task.fork == fork)
    assert(not is_call_reject)
    assert(not is_call_resolve)

    task.fork(reject, resolve)
    assert(is_call_reject)
    assert(not is_call_resolve)

    task = Task.of(42)

# Generated at 2022-06-21 19:38:49.113708
# Unit test for method bind of class Task
def test_Task_bind():
    t = Task.of(2).bind(
        lambda arg: Task.of(arg + 2)
    )

    assert t == Task.of(4)

    # test error handle
    t = Task.reject(2).bind(
        lambda arg: Task.of(arg + 2)
    )

    assert t == Task.reject(2)


# Generated at 2022-06-21 19:38:53.735751
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for map method of class Task.
    """
    def inc(value):
        return value + 1

    def mul(value):
        return value * 4

    assert Task.of(2).map(inc).fork(None, inc) == 4
    assert Task.of(2).map(inc).map(mul).fork(None, mul) == 16


# Generated at 2022-06-21 19:38:56.396635
# Unit test for constructor of class Task
def test_Task():
    # Object creation
    fork_fn = lambda _, __: None
    task = Task(fork_fn)

    # Test fork
    assert task.fork is fork_fn


# Generated at 2022-06-21 19:39:03.218178
# Unit test for method map of class Task
def test_Task_map():
    def add(value):
        return value + 2

    assert Task.of(2).map(add).fork(
        lambda value: False,
        lambda value: value == 4
    )


# Generated at 2022-06-21 19:39:08.129484
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(5)).fork(lambda arg: arg, lambda arg: arg) == 5
    assert Task(
        lambda reject, _: reject('Error message')
    ).fork(lambda arg: arg, lambda arg: arg) == 'Error message'


# Generated at 2022-06-21 19:39:16.282896
# Unit test for method map of class Task
def test_Task_map():
    def add1(a):
        return a + 1

    def is_Task(arg):
        return isinstance(arg, Task)

    def is_resolved_Task(arg):
        return is_Task(arg) and isinstance(arg.fork(lambda _: None, lambda _: None), int)

    def is_rejected_Task(arg):
        return is_Task(arg) and isinstance(arg.fork(lambda _: None, lambda _: None), Exception)

    assert is_resolved_Task(Task.of(2).map(add1))
    assert Task.of(2).map(add1).fork(lambda _: None, lambda _: None) == 3
    assert is_rejected_Task(Task.reject("error").map(add1))

# Generated at 2022-06-21 19:39:21.756196
# Unit test for method map of class Task
def test_Task_map():
    def add_five(x):
        return x + 5

    task_1 = Task.of(10)
    assert task_1.map(add_five).fork(_, lambda x: x) == 15

    task_2 = Task.reject(None)
    assert task_2.map(add_five).fork(lambda _: True, lambda x: False) == True



# Generated at 2022-06-21 19:39:25.734852
# Unit test for method map of class Task
def test_Task_map():
    def test(result, expected):
        assert result == expected

    Task.of(2).map(
        lambda value: value + 3
    ).fork(
        lambda reject: test(reject, None),
        lambda resolve: test(resolve, 5)
    )


# Generated at 2022-06-21 19:39:31.306383
# Unit test for method map of class Task
def test_Task_map():
    def always_square(x):
        return x ** 2

    def always_cube(x):
        return x ** 3

    def always_pow4(x):
        return x ** 4

    task = Task.of(4)
    map_task = task.map(always_square).map(always_cube).map(always_pow4)

    assert map_task.fork() == 4096



# Generated at 2022-06-21 19:39:35.389910
# Unit test for method map of class Task
def test_Task_map():
    increment = lambda value: value + 1
    decrement = lambda value: value - 1

    assert Task(lambda reject, resolve: resolve(4)).map(increment).fork(lambda err: None, lambda res: res) == 5
    assert Task(lambda reject, resolve: resolve(4)).map(increment).map(decrement).fork(lambda err: None, lambda res: res) == 4



# Generated at 2022-06-21 19:39:40.623467
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2).map(lambda x: x ** 2)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 4

    task = Task.reject(2).map(lambda x: x ** 2)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-21 19:39:47.875109
# Unit test for method map of class Task
def test_Task_map():
    # Base data - input and output handler
    x = 1
    y = 2

    # Input and output data - they can be in any type
    input_data = x
    output_data = y

    # Prepare test data
    input_task = Task.of(input_data)
    output_task = input_task.map(lambda arg: arg + 1)

    # If we executed output_task, it should return output_data
    @fn(done, fail)
    def composed():
        data = output_task.fork(fail, done)
    composed()

    # It's clear that done function should be called with output_data
    assert done.called == 1 and done.args == (output_data, ) and done.kwargs == {}

    # Fail function should be called with 0 times
    assert fail.called == 0 and fail.args

# Generated at 2022-06-21 19:39:51.828668
# Unit test for method bind of class Task
def test_Task_bind():
    def test(resolve, reject):
        Task.of(1).bind(lambda arg: Task.of(arg + 1)).fork(reject, resolve)

    assertEqual(Task(test).fork(lambda arg: arg, lambda arg: arg), 2)


# Generated at 2022-06-21 19:39:57.509540
# Unit test for constructor of class Task
def test_Task():
    def func(value):
        def c(_, resolve):
            return resolve(value)

        return Task(c)

    assert Task.of(1) == func(1)


# Generated at 2022-06-21 19:40:02.975822
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> test_Task_bind()
    Executed!
    """
    def func(value):
        if value:
            return Task.of(value)
        else:
            return Task.reject(value)

    task = Task.of(True).bind(func)
    task.fork(
        lambda value: print('Error'),
        lambda value: print('Executed!')
    )


# Generated at 2022-06-21 19:40:06.937074
# Unit test for method map of class Task
def test_Task_map():
    # arrange
    task_of_1 = Task.of(1)
    task_of_2 = Task.of(2)
    add_one = lambda x: x + 1
    add_two = lambda x: x + 2

    # act
    result_1 = task_of_1.map(add_one)
    result_2 = task_of_2.map(add_two)

    # assert
    assert result_1.fork(None, lambda x: x) == 2
    assert result_2.fork(None, lambda x: x) == 4


# Generated at 2022-06-21 19:40:08.351298
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(5))
    assert task.fork(lambda _: None, lambda v: None) == 5


# Generated at 2022-06-21 19:40:14.088417
# Unit test for method map of class Task
def test_Task_map():
    def add_one(number):
        return number + 1

    def sub_one(number):
        return number - 1

    result = Task.of(1).map(add_one).map(sub_one)
    assert result.fork(None, None) == 1


# Generated at 2022-06-21 19:40:22.176403
# Unit test for method map of class Task
def test_Task_map():

    def add(value):
        return value + 1

    def test_add(value):
        return value[1].map(add) == Task.of(value[0] + 1)

    def fail_add(value):
        return value[1].map(add) == Task.of(value[0])

    values = [
        (1, Task.of(1)),
        (2, Task.of(2)),
        (3, Task.of(3)),
        (4, Task.of(4)),
        (100, Task.of(100)),
        (-100, Task.of(-100)),
    ]

    assert all([test_add(value) for value in values])
    assert not any([fail_add(value) for value in values])


# Generated at 2022-06-21 19:40:25.406743
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    def fork(reject, resolve):
        resolve(1)

    assert Task(fork).fork(None, lambda arg: arg) == 1


# Unit tests for class Task.of

# Generated at 2022-06-21 19:40:30.569857
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Bind function must return new Task with resolved value obtained from called function
    """
    def wrapped(resolve, reject):
        assert isinstance(resolve, Task)
        assert resolve.fork(lambda _: True, lambda _: False)
        return True

    def result(resolve, reject):
        return Task.of(True).bind(wrapped).fork(lambda _: False, lambda _: True)

    assert result(None, None)

# Generated at 2022-06-21 19:40:34.208741
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        if value >= 0:
            return Task.of(value + 1)
        else:
            return Task.reject(value)

    assert Task.of(5).bind(mapper).fork(lambda x: x, lambda x: x) == 6
    assert Task.reject(0).bind(mapper).fork(lambda x: x, lambda x: x) == 0


# Generated at 2022-06-21 19:40:36.445475
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task(lambda _, resolve: resolve().value), Task)
    assert isinstance(Task.of(1), Task)


# Generated at 2022-06-21 19:40:47.125186
# Unit test for constructor of class Task
def test_Task():
    t = Task((lambda reject, resolve: resolve(1)))

    t2 = Task.of(1)

    assert t.fork(None, None) == t2.fork(None, None)


# Generated at 2022-06-21 19:40:50.068452
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    assert callable(Task)
    assert Task is not None
    result = Task(lambda reject, resolve: None)
    assert result is not None
    assert result.fork is not None


# Generated at 2022-06-21 19:40:52.633918
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    x = Task.of(1)
    assert x.map(mapper).fork(lambda x: map, lambda x: map)(1) == 2


# Generated at 2022-06-21 19:40:57.492628
# Unit test for constructor of class Task
def test_Task():
    def fork1(*args):
        raise Exception('Task should be initialized using constructor Task.of')

    def fork2(reject, resolve):
        resolve(17)

    assert Task(fork1).fork(None, None) is None
    assert Task(fork2).fork(None, None) == 17



# Generated at 2022-06-21 19:41:06.876035
# Unit test for method bind of class Task
def test_Task_bind():
    """ Unit test for method bind of class Task """
    # pylint: disable=protected-access

    # _Task instance for test
    task = Task._Task()

    # Case:  Task with resolve attribute.
    value = task._Task.of(1).bind(lambda arg: task._Task.reject(arg + 1))
    assert isinstance(value, task._Task)
    assert value.fork((lambda arg: arg), (lambda arg: arg)) == 2

    # Case:  Task with reject attribute.
    value = task._Task.reject(1).bind(lambda arg: task._Task.of(arg + 1))
    assert isinstance(value, task._Task)
    assert value.fork((lambda arg: arg), (lambda arg: arg)) == 1

    print('Task.bind - done')


# Generated at 2022-06-21 19:41:09.764192
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        def inner(value):
            return Task.of(value + 1)

        return inner(value)

    task = Task.of(1)
    assert task.bind(fn).fork(None, lambda x: x) == 2


# Generated at 2022-06-21 19:41:11.922615
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)) \
        .map(lambda value: value + 3) \
        .fork(
            lambda reject: 'reject',
            lambda resolve: resolve
        ) == 4


# Generated at 2022-06-21 19:41:14.982763
# Unit test for method map of class Task
def test_Task_map():
    # Create promise
    def resolve_promise(resolve, reject):
        resolve(1)

    promise = Promise(resolve_promise)
    def _assert(value): assert value == 2

    # Create task
    promise.fork(lambda a: print(a), _assert)
    result = Task(resolve_promise)
    result.map(lambda v: v + 1).fork(lambda a: print(a), _assert)


# Generated at 2022-06-21 19:41:21.228598
# Unit test for constructor of class Task
def test_Task():
    def fork_with_value(reject, resolve): return resolve(1)
    fork_with_exception = lambda reject, resolve: reject(Exception)

    task = Task(fork_with_value)
    assert isinstance(task, Task)
    assert task.fork is fork_with_value

    task = Task(fork_with_exception)
    assert isinstance(task, Task)
    assert task.fork is fork_with_exception


# Generated at 2022-06-21 19:41:26.843710
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda _, resolve: resolve(1)).bind(lambda arg: Task.of(arg + 1)).fork(
        None,
        lambda result: result == 2
    )

    assert Task(lambda _, resolve: resolve(1)).bind(
        lambda arg: Task.reject(arg + 1)
    ).fork(
        lambda result: result == 2,
        None
    )



# Generated at 2022-06-21 19:41:45.359600
# Unit test for method map of class Task
def test_Task_map():
    def is_task_instance(arg):
        return isinstance(arg, Task)

    def is_not_task_instance(arg):
        return not is_task_instance(arg)

    def is_tuple_instance(arg):
        return isinstance(arg, tuple)

    def is_not_tuple_instance(arg):
        return not is_tuple_instance(arg)

    def is_sum_equal_four(arg):
        return arg == 4

    def is_not_sum_equal_four(arg):
        return not is_sum_equal_four(arg)

    def two_plue_two(reject, resolve):
        resolve(2 + 2)


# Generated at 2022-06-21 19:41:50.632881
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        assert value == 2, 'Invalid value'
        return value

    task = Task.of(1)
    task.fork(lambda _: None, resolve)

    task = Task.of(1)
    task.map(lambda value: value + 1).fork(lambda _: None, resolve)


# Generated at 2022-06-21 19:41:56.328452
# Unit test for constructor of class Task
def test_Task():
    a = Task.of(1)
    assert 1 == a.fork(lambda value: value, lambda value: value)
    b = Task.of(2)
    assert 2 == b.fork(lambda value: value, lambda value: value)
    s = Task.reject(3)
    assert 3 == s.fork(lambda value: value, lambda value: value)
    n = Task.reject(4)
    assert 4 == n.fork(lambda value: value, lambda value: value)


# Generated at 2022-06-21 19:42:05.081115
# Unit test for method bind of class Task
def test_Task_bind():
    """Unit test for method bind of class Task"""

    def fn_resolve(_):
        return Task.of(1)

    def fn_reject(_):
        return Task.reject(1)

    def run_reject(error):
        assert error == 2

    def run_resolve(result):
        assert result == 3

    rejected_task = Task.reject(2)
    resolved_task = Task.of(3)

    # test when bind to reject task
    rejected_task.bind(fn_reject).fork(
        run_reject,
        run_resolve
    )

    # test when bind to resolve task
    resolved_task.bind(fn_resolve).fork(
        run_reject,
        run_resolve
    )

# Generated at 2022-06-21 19:42:08.593374
# Unit test for constructor of class Task
def test_Task():
    """
    test_Task: Function(None) -> None
    """
    def case(resolve, reject):
        assert True

    test_case = Task(case)
    assert test_case.fork == case


# Generated at 2022-06-21 19:42:13.464189
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return reject(123)

    def fork_of(reject, resolve):
        return resolve(456)

    def fn(promise):
        return Task(fork_of)

    task = Task(fork)
    assert task.bind(fn).fork(lambda arg: arg, lambda _: None) == 456


# Generated at 2022-06-21 19:42:15.480602
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    task_mapped = task.map(lambda arg: arg + 1)

    assert task_mapped.fork(None, lambda v: v) == 2



# Generated at 2022-06-21 19:42:17.952744
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _,x: x(1)).fork(lambda r: 0, lambda x: x) == 1
    assert Task(lambda x,_: x(1)).fork(lambda x: x, lambda r: 0) == 1



# Generated at 2022-06-21 19:42:20.229102
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(1))
    assert task.fork(lambda l: l, lambda r: r) == 1


# Generated at 2022-06-21 19:42:24.750216
# Unit test for constructor of class Task
def test_Task():
    """
    Task(fork: Function(reject, resolve) -> Any)

    Task are data-type for handle execution of functions (in lazy way)
    transform results of this function and handle errors.
    """
    def fork_without_error(reject, resolve):
        """
        Function without errors.
        """
        resolve(None)

    task = Task(fork_without_error)
    assert isinstance(task, Task)


# Generated at 2022-06-21 19:42:44.523927
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for logic of Task.map

    :returns: bool
    """
    task = Task.of(2).map(lambda x: x**2)
    return task.fork(lambda x: False, lambda x: x == 4) is True


# Generated at 2022-06-21 19:42:56.445507
# Unit test for method bind of class Task
def test_Task_bind():
    def fail(reject, resolve):
        resolve(5)

    def succ(reject, resolve):
        reject('My Error')

    def not_called_function(reject, resolve):
        assert False, 'not-called function should not be called'

    def map_function(value):
        assert value == 4, 'incorrect value in map function'
        return value + 1

    def bind_function(value):
        assert value == 5, 'incorrect value in bind function'
        return Task.reject(666)

    task = Task(fail)
    assert type(task) == Task

    task = task.map(map_function)
    assert type(task) == Task

    task = task.bind(bind_function)
    assert type(task) == Task


# Generated at 2022-06-21 19:42:59.073577
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        assert type(reject) is Function
        assert type(resolve) is Function

        return Task(fork)

    task = Task(fork)

    assert type(task) is Task

# Generated at 2022-06-21 19:43:01.996095
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    def fork(_, resolve):
        return resolve(1)

    assert Task(fork).map(mapper).fork(
        lambda _: "rejected",
        lambda value: value,
    ) == 2


# Generated at 2022-06-21 19:43:05.609698
# Unit test for constructor of class Task
def test_Task():
    """
    Check constructor of Task class

    return:
        0 - if case is passed
        1 - if case fails
    """
    def func(reject, resolve):
        # return value
        return 1

    # create task
    task = Task(func)

    # test constructor
    if task.fork == func:
        return 0
    else:
        return 1


# Generated at 2022-06-21 19:43:14.839483
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map(Function(A) -> B) -> Task[resolve_a_to_b]
    """
    t = Task.of(2)

    def foo(a):
        """
        Foo mapper

        :param a: any value
        :type a: A
        :returns: (a + 1)
        :rtype: A
        """
        return a + 1

    def foo2(a):
        """
        Foo2 mapper

        :param a: any value
        :type a: A
        :returns: (a + 2)
        :rtype: A
        """
        return a + 2

    assert t.map(foo).map(foo2).fork(None, lambda x: x) == 5


# Generated at 2022-06-21 19:43:23.470444
# Unit test for method bind of class Task
def test_Task_bind():
    def bind(resolve, reject):
        return Task.of(2).bind(lambda arg: Task.of(arg + 2))
    task = Task(bind)
    assert task.fork(None, assert_equal(4))

    def bind(resolve, reject):
        return Task.of(2).bind(lambda arg: Task.reject(arg + 2))
    task = Task(bind)
    assert task.fork(assert_equal(4), None)

    def bind(resolve, reject):
        return Task.reject(2).bind(lambda arg: Task.of(arg + 2))
    task = Task(bind)
    assert task.fork(assert_equal(2), None)


# Generated at 2022-06-21 19:43:30.693202
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda arg: arg + 10)

    called = []

    def on_reject(_):
        called.append(None)

    def on_resolve(value):
        called.append(value)

    task.fork(on_reject, on_resolve)

    assert called == [11]


# Generated at 2022-06-21 19:43:33.948249
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda arg: arg, lambda arg: arg == 1) is True
    assert Task.reject(1).fork(lambda arg: arg == 1, lambda arg: arg) is True


# Generated at 2022-06-21 19:43:35.876543
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return 'result of fork'

    task = Task(fork)

    assert task.fork is fork


# Generated at 2022-06-21 19:44:07.769819
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, x: x)
    assert task.fork(lambda x: x, lambda x: x) == None



# Generated at 2022-06-21 19:44:13.405383
# Unit test for constructor of class Task
def test_Task():
    """
    Check constructor of class Task.
    It should be create object by given fork. During fork it should call
    mark in map and flatMap functions.
    """
    fork = lambda reject, resolve: resolve(True)

    mark1 = lambda _: None
    mark2 = lambda _: None

    task = Task(fork)
    task.map(mark1).map(mark2)

    assert mark1.called and mark2.called



# Generated at 2022-06-21 19:44:15.468343
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return "Some data"

    assert Task(fork).fork == fork
