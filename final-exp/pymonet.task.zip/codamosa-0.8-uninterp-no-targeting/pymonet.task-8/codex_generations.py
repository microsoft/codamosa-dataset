

# Generated at 2022-06-21 19:34:21.035591
# Unit test for method map of class Task
def test_Task_map():
    def forked(reject, resolve):
        resolve('hello')

    def add_world(value):
        return value + ' world'

    task = Task(forked)

    assert task.fork(None, None) is None
    assert task.map(add_world).fork(None, None) == 'hello world'


# Generated at 2022-06-21 19:34:22.154675
# Unit test for constructor of class Task
def test_Task():
    assert Task


# Generated at 2022-06-21 19:34:26.608375
# Unit test for constructor of class Task
def test_Task():
    """
    Task must be initialized with fork function and must have fork attribute.
    """
    def fork(_, resolve):
        resolve(True)

    task = Task(fork)
    assert isinstance(task.fork, FunctionType)


# Generated at 2022-06-21 19:34:29.677444
# Unit test for constructor of class Task
def test_Task():
    """
    >>> task = Task(lambda _, resolve: resolve('Hey'))
    >>> task.fork(print, print)
    None
    Hey
    """


# Generated at 2022-06-21 19:34:37.568351
# Unit test for method bind of class Task
def test_Task_bind():
    def inc(x):
        return Task.of(x + 1)

    def inc_error(x):
        return Task.reject(x + 1)

    result = Task.of(1) \
        .bind(inc) \
        .bind(inc) \
        .fork(
            lambda error: error,
            lambda value: value
        )

    assert result == 3

    result_error = Task.of(1) \
        .bind(inc_error) \
        .bind(inc) \
        .fork(
            lambda error: error,
            lambda value: value
        )

    assert result_error == 2



# Generated at 2022-06-21 19:34:39.700998
# Unit test for constructor of class Task
def test_Task():
    t = Task((lambda reject, resolve: reject(1)))
    assert type(t) is Task
    assert t.fork is not None


# Generated at 2022-06-21 19:34:49.182913
# Unit test for method bind of class Task
def test_Task_bind():
    from time import sleep

    def success_task(arg):
        def success(resolve):
            sleep(0.001)
            resolve(arg)

        return Task(success)

    def fail_task(arg):
        def fail(resolve):
            sleep(0.001)
            resolve({ "type": "Error", "message": arg })

        return Task(fail)

    def map_task(arg):
        return success_task(arg)

    def is_error(arg):
        return type(arg) is not int and arg["type"] == "Error"

    def map_fail_task(arg):
        if is_error(arg):
            return fail_task(arg["message"])

        return map_task(arg)

    list = []

    def add_value(value):
        list.append(value)

# Generated at 2022-06-21 19:34:55.315318
# Unit test for method map of class Task
def test_Task_map():
    def test(value):
        return value + 100

    value = 100
    task = Task.of(value)
    task = task.map(test)
    result = task.fork(
        lambda error: None,
        lambda value: value
    )

    assert result is not None
    assert result == test(value)


# Generated at 2022-06-21 19:34:58.723221
# Unit test for constructor of class Task
def test_Task():
    """
    Task(fork) -> Task[fork]
    """
    task = Task(lambda r, s: s(2))
    assert task.fork(lambda x: False, lambda x: x) == 2


# Generated at 2022-06-21 19:35:01.095695
# Unit test for constructor of class Task
def test_Task():
    fork_task = Task(lambda reject, resolve: resolve(0))
    assert fork_task.fork == fork_task.fork

# Generated at 2022-06-21 19:35:08.469284
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve(5)

    task = Task(fork)

    def _resolve(x):
        return x

    def _reject(x):
        return x

    assert task.fork(_reject, _resolve) == 5


# Generated at 2022-06-21 19:35:17.369155
# Unit test for method bind of class Task
def test_Task_bind():
    # If Task reject - bind called with reject
    # If Task resolve - bind called with resolve
    def is_reject(arg):
        return callable(arg)

    def create_task(value):
        def result(reject, resolve):
            if is_reject(value):
                return reject(value)
            return resolve(value)
        return Task(result)

    assert Task(lambda reject, _: reject(1)).bind(lambda _: create_task(2)).fork(
        lambda arg: arg,
        lambda _: None
    ) == 1

    assert Task(lambda _, resolve: resolve(1)).bind(lambda _: create_task(2)).fork(
        lambda _: None,
        lambda arg: arg
    ) == 2


# Generated at 2022-06-21 19:35:22.436184
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    task = Task.of(10)

    def sum_sqrt(value):
        return Task.of(value + math.sqrt(value))

    result = task.bind(sum_sqrt)
    assert result.fork(
        lambda value: None,
        lambda value: assert_almost_equal(value, 11.0)
    )


# Generated at 2022-06-21 19:35:29.832306
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(arg):
        assert arg == 2

# Generated at 2022-06-21 19:35:36.780603
# Unit test for constructor of class Task
def test_Task():
    """
    Resolve string from constructor, with resolve type.
    """
    result_reject = False
    result_resolve = False
    def callback(reject, resolve):
        result_reject = reject('error')
        result_resolve = resolve('response')

    task = Task(callback)
    reject = task.fork(lambda arg: arg, None)
    resolve = task.fork(None, lambda arg: arg)

    assert result_reject == 'error'
    assert result_resolve == 'response'
    assert reject == 'error'
    assert resolve == 'response'


# Generated at 2022-06-21 19:35:39.873729
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    assert Task.of(1).map(mapper).fork(None, lambda value: value) == 2


# Generated at 2022-06-21 19:35:44.939616
# Unit test for method bind of class Task

# Generated at 2022-06-21 19:35:48.368311
# Unit test for method bind of class Task
def test_Task_bind():
    # Arrange
    def rejecter(arg):
        return Task.reject(arg)

    def resolver(arg):
        return Task.of(arg)

    def mapper(arg):
        return arg

    # Act
    value = Task(resolver).bind(rejecter).map(mapper)
    # Assert
    assert value.fork(lambda arg: arg, lambda _: None) == 'rej'

# Generated at 2022-06-21 19:35:59.614295
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """

    def test_first_reject(reject, resolve):
        reject(1)
        assert False

    def test_first_resolve(reject, resolve):
        resolve(2)
        assert False

    def test_last_reject(first_value):
        assert first_value == 1
        return Task.reject(3)

    def test_last_resolve(first_value):
        assert first_value == 2
        return Task.of(4)

    task1 = Task(test_first_reject)
    task2 = Task(test_first_resolve)

    task1.bind(test_last_reject).fork(lambda arg: arg == 3, lambda _: False)
    task2.bind(test_last_resolve).fork

# Generated at 2022-06-21 19:36:03.917268
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task class for method bind
    """
    assert StrictEqual(Task(lambda reject, resolve: resolve(1)).bind(lambda x: Task(lambda reject, resolve: resolve(x + 1))).fork(lambda reject: reject(1), lambda resolve: resolve(1)), 2)


# Generated at 2022-06-21 19:36:15.727659
# Unit test for method bind of class Task
def test_Task_bind():
    def func():
        def func_1():
            return Task.of(1)
        assert Task(lambda _, resolve: resolve(0)).bind(func_1) == Task.of(1)

    def func():
        def func_1():
            return Task.of(1)
        assert Task(lambda reject, _: reject(0)).bind(func_1) == Task.of(1)

    def func():
        def func_1():
            return Task.reject(2)
        assert Task(lambda _, resolve: resolve(0)).bind(func_1) == Task.reject(2)

    def func():
        def func_1():
            return Task.reject(2)
        assert Task(lambda reject, _: reject(0)).bind(func_1) == Task.reject(2)

    func()

# Generated at 2022-06-21 19:36:16.744849
# Unit test for method map of class Task
def test_Task_map():
    assert True


# Generated at 2022-06-21 19:36:18.539598
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task(lambda reject, resolve: resolve(2)), Task)


# Generated at 2022-06-21 19:36:25.603801
# Unit test for method bind of class Task
def test_Task_bind():
    """Test for method bind of class Task."""

    def fork_success(reject, resolve):
        resolve('foo')

    def fork_fail(reject, resolve):
        reject(ValueError('error'))

    def mapper(value):
        return Task(fork_success)

    def mapper_error(value):
        return Task(fork_fail)

    def foo(value):
        assert value == 'foo'

    def success(value):
        assert value == 'foo'

    def error(value):
        assert isinstance(value, ValueError)
        assert value.args == ('error',)

    Task(fork_success).bind(mapper).fork(error, foo)
    Task(fork_fail).bind(mapper).fork(error, success)

# Generated at 2022-06-21 19:36:34.520514
# Unit test for method map of class Task
def test_Task_map():
    """
        Test for Task method map.
    """
    @pytest.mark.asyncio
    async def test_t():
        """
        Test for Task method map.
        """
        def log(m):
            print(m)

        def add(m):
            return m + 1

        def resolve(result):
            assert(result == 2)
            log(result)

        def reject(result):
            assert(result == 2)
            log(result)

        t = Task(add(1))
        await t.fork(reject, resolve)

# Generated at 2022-06-21 19:36:40.246918
# Unit test for constructor of class Task
def test_Task():
    """
    Task.fork cannot be None
    Task.fork argument is callable
    """
    assert Task(None) is None, \
        "Task(None) is {}".format(Task(None))
    assert Task(lambda _, __: None) is not None, \
        "Task(lambda _, __: None) is {}".format(Task(lambda _, __: None))


# Generated at 2022-06-21 19:36:45.613886
# Unit test for method bind of class Task
def test_Task_bind():
    first = Task.of(1)
    second = Task.of(2)
    third = Task.of(3)
    fourth = Task.reject(4)

    result = []

    def mapper(value):
        result.append(value)
        if value == 2:
            return third
        elif value == 3:
            return fourth
        return Task.of(value)

    first.bind(mapper).fork(
        lambda arg: result.append(arg),
        lambda arg: result.append(arg)
    )

    assert result == [1, 2, 3, 4]

# Generated at 2022-06-21 19:36:56.157603
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Execute test for method bind of class Task

    :returns: if error occur during test return error
    :rtype: Bool
    """
    def func1(x):
        return Task.of(x * 2)

    def func2(x):
        return Task.of(x * 3)

    def func3(x):
        return Task.of(x * 4)

    def func4(x):
        return Task.of(x * 5)

    def func5(x):
        return Task.of(x * 6)

    def func6(x):
        return Task.of(x * 7)

    def func7(x):
        return Task.of(x * 8)

    def func8(x):
        return Task.reject(x * 9)


# Generated at 2022-06-21 19:37:05.949215
# Unit test for method map of class Task
def test_Task_map():
    from pytest import raises
    from hypothesis import given
    from .strategies import task

    @given(task, task)
    def test_Task_map_with_function(task_a, task_b):
        def fn(x):
            return x * 2

        assert task_a.map(fn).fork(
            lambda x: 1,
            lambda x: x * 2
        ) == task_a.fork(
            lambda x: 1,
            lambda x: x * 2
        ) * 2
        assert task_a.map(fn).fork(
            lambda x: x,
            lambda x: x * 10
        ) == task_a.fork(
            lambda x: x * 2,
            lambda x: x * 10
        ) * 2


# Generated at 2022-06-21 19:37:11.991777
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of Task class.

    :returns: None
    :rtype: None
    """
    def tester(reject, resolve):
        return resolve(23)

    # test that fork is storing
    assert Task(tester).fork == tester
    assert Task(tester)().fork() == 23


# Generated at 2022-06-21 19:37:32.228205
# Unit test for method map of class Task
def test_Task_map():
    def true_assertion(resolved_value):
        """
        True assertion function for testing.

        :param resolved_value: test value
        :type resolved_value: Int
        """
        assert resolved_value == 10

    def false_assertion(resolved_value):
        """
        False assertion function for testing.

        :param resolved_value: test value
        :type resolved_value: Int
        """
        assert resolved_value == 20

    def mapping_function(a):
        """
        Mapping function for testing.

        :param a: test value
        :type a: Int
        :returns: mapped value
        :rtype: Int
        """
        return a * 2

    # Test mapping actualy works
    task = Task.of(5)

# Generated at 2022-06-21 19:37:38.302691
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve("value")

    def mapper(value):
        return "mapped_" + value

    task = Task(fork)
    assert isinstance(task, Task), "Result of constructor of class Task must be instance of this class"

    mapped = task.map(mapper)
    assert mapped.fork(lambda _: "error", lambda value: "success") == "success"



# Generated at 2022-06-21 19:37:42.184400
# Unit test for constructor of class Task
def test_Task():
    value = Task(lambda reject, resolve: resolve(42) )
    assert value.fork(
        lambda reject: {
            'fork': True,
            'reject': reject,
            'resolve': None
        },
        lambda resolve: {
            'fork': True,
            'reject': None,
            'resolve': resolve
        }
    ) == {
        'fork': True,
        'reject': None,
        'resolve': 42
    }



# Generated at 2022-06-21 19:37:47.385030
# Unit test for constructor of class Task
def test_Task():
    def test_of(resolve):
        def test():
            assert Task.of('value').fork(lambda _: None, resolve) == 'value'
        return test

    def test_reject(reject):
        def test():
            assert Task.reject('value').fork(reject, lambda _: None) == 'value'
        return test

    run_test(test_of)
    run_test(test_reject)


# Generated at 2022-06-21 19:37:58.877431
# Unit test for constructor of class Task
def test_Task():
    # test for Task.of()
    assert_equal(Task(lambda _, resolve: resolve(1)).map(lambda x: x + x).fork(
        lambda x: x,
        lambda x: x
    ), 2)

    # test for Task.reject()
    assert_equal(Task(lambda reject, _: reject(2)).map(lambda x: x + x).fork(
        lambda x: x,
        lambda x: x
    ), 4)

    # test for Task.__init__()
    assert_equal(Task(lambda reject, resolve: resolve(2)).map(lambda x: x + x).fork(
        lambda x: x,
        lambda x: x
    ), 4)

# Generated at 2022-06-21 19:38:04.783077
# Unit test for method bind of class Task
def test_Task_bind():
    import asyncio
    async def test():
        task = Task.of(1)
        assert task.fork(lambda arg: arg, lambda arg: arg) == 1

        new_task = task.bind(lambda arg: Task.of(arg + 1))
        assert new_task.fork(lambda arg: arg, lambda arg: arg) == 2

    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()

if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-21 19:38:13.304344
# Unit test for method bind of class Task
def test_Task_bind():
    """
        Async map testing.
    """

    def make_request():
        """
        Function will be passed to task.
        """
        return Task(lambda reject, resolve: resolve({'data': 'OK'}))

    def parse_response(response):
        """
        Function will be passed to map.
        """
        return response['data']

    task = Task.of(None).bind(make_request).map(parse_response)

    assert task.fork(lambda _: None, lambda data: data) == 'OK'



# Generated at 2022-06-21 19:38:20.985260
# Unit test for constructor of class Task
def test_Task():
    def resolve(value):
        return value

    def reject(value):
        raise Exception(value)

    def example_fork(reject, resolve):
        resolve(5)

    assert Task(fork=example_fork).fork(reject, resolve) == 5

    class ExampleException(Exception):
        pass

    def example_reject(reject, resolve):
        reject(ExampleException('raised'))

    with pytest.raises(Exception, message='raised'):
        Task(fork=example_reject).fork(reject, resolve)

    def example_resolve(reject, resolve):
        resolve('resolved')

    assert Task(fork=example_resolve).map(lambda value: value + 'd').fork(reject, resolve) == 'resolvedd'


# Generated at 2022-06-21 19:38:26.381196
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> task_reject = Task.reject("Boom!")
    >>> task = task_reject.bind(lambda _: Task.of("OK"))
    >>> task.fork(lambda value: print("reject:", value), lambda value: print("resolve:", value)) # => reject: Boom!
    reject: Boom!
    """


# Generated at 2022-06-21 19:38:28.365908
# Unit test for constructor of class Task
def test_Task():
    """
    testing Task functions: of, reject, map and bind.
    """
    def fork(reject, resolve):
        retur

# Generated at 2022-06-21 19:38:52.332827
# Unit test for method bind of class Task
def test_Task_bind():
    f = lambda x: Task.of(x)
    g = lambda x: Task.of(x + 1)
    value = Task.of(1).bind(f).bind(g)
    assert value.fork(lambda _: False, lambda x: x == 2)

    f = lambda x: Task.of(x + 1)
    g = lambda x: Task.of(x + 1)
    value = Task.of(1).bind(f)
    assert value.bind(g).fork(lambda _: False, lambda x: x == 3)


# Generated at 2022-06-21 19:38:53.755148
# Unit test for method bind of class Task
def test_Task_bind():
    # TODO: implement test
    assert "Ok"


# Generated at 2022-06-21 19:39:04.625034
# Unit test for method bind of class Task
def test_Task_bind():
    error_text1 = 'error_text1'
    error_text2 = 'error_text2'
    error_text3 = 'error_text3'
    error_text4 = 'error_text4'

    def test_case1(reject, resolve):
        reject(error_text1)

    def test_case2(reject, resolve):
        resolve(error_text2)

    def test_case3(reject, resolve):
        resolve(error_text3)

    def test_case4(reject, resolve):
        reject(error_text4)

    task1 = Task(test_case1)
    task2 = Task(test_case2)
    task3 = Task(test_case3)
    task4 = Task(test_case4)


# Generated at 2022-06-21 19:39:11.071912
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    task1 = task.bind(lambda x: Task.of(x + 1))
    assert task1.fork(lambda x: x, lambda x: x) == 2
    task2 = task.bind(lambda x: Task.reject(x + 1))
    assert task2.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-21 19:39:14.441583
# Unit test for constructor of class Task
def test_Task():
    """
    Test case to check constructor of class Task

    :returns: None
    :rtype: None
    """
    assert Task(lambda _, resolve: resolve(5)).fork(None, lambda a: a) == 5
    assert Task(lambda reject, _: reject(6)).fork(lambda a: a, None) == 6



# Generated at 2022-06-21 19:39:24.986784
# Unit test for constructor of class Task
def test_Task():
    def add2(number):
        return number + 2

    def reject_task(number):
        return Task.reject(number)

    def resolve_task(number):
        return Task.of(number)

    def fork(reject, resolve):
        return resolve(2)

    task = Task(fork)
    assert task.fork(lambda _: 1, lambda arg: arg) == 2
    assert task.map(add2).fork(lambda _: 0, lambda arg: arg) == 4
    assert task.bind(reject_task).fork(lambda arg: arg, lambda _: 0) == 2
    assert task.bind(resolve_task).fork(lambda _: 0, lambda arg: arg) == 2



# Generated at 2022-06-21 19:39:32.915686
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind

    :returns: None
    :rtype: NoneType
    """
    assert Task.of(1).bind(
        lambda val: Task.reject(2)
    ).fork(lambda arg: arg, lambda arg: None) == 2

    assert Task.reject(1).bind(
        lambda val: Task.reject(2)
    ).fork(lambda arg: arg, lambda arg: None) == 1

    assert Task.of(1).bind(
        lambda val: Task.of(2)
    ).fork(lambda arg: arg, lambda arg: None) == 2


# Generated at 2022-06-21 19:39:36.531577
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        pass

    assert(Task(fork).fork == fork)


# Generated at 2022-06-21 19:39:42.298551
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for bind method of Task class.
    """
    result = Task.of(1).bind(
        lambda value: Task.of(value + 1)
    )

    assert result == Task.of(2)

    result = Task.reject(1).bind(
        lambda value: Task.of(value + 1)
    )

    assert result == Task.reject(1)

# Generated at 2022-06-21 19:39:48.958227
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(None, None) == 1
    Task(lambda _, resolve: resolve(1)).fork(None, None) == 1
    Task(lambda reject, _: reject(2)).fork(None, None) == 2
    Task.of(1).fork(None, None) == 1
    Task.reject(2).fork(None, None) == 2


# Generated at 2022-06-21 19:40:40.153640
# Unit test for method bind of class Task
def test_Task_bind():
    def left(value):
        return Task.reject(value)

    def right(value):
        return Task.of(value)

    assert Task(lambda _, resolve: resolve(1)).bind(left).fork(lambda arg: print(arg), lambda _: 0) == 1
    assert Task(lambda _, resolve: resolve(1)).bind(right).fork(lambda _: 0, lambda arg: print(arg)) == 1
    assert Task(lambda reject, _: reject(1)).bind(left).fork(lambda arg: print(arg), lambda _: 0) == 1
    assert Task(lambda reject, _: reject(1)).bind(right).fork(lambda arg: print(arg), lambda _: 0) == 1



# Generated at 2022-06-21 19:40:44.548101
# Unit test for constructor of class Task
def test_Task():
    def fork(on_reject, on_resolve):
        on_resolve(3)

    task = Task(fork)
    assert task.fork(lambda err: err, lambda res: res) == 3


# Generated at 2022-06-21 19:40:48.233644
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test behavior of bind method of class Task.
    Execute method `fork` of returned Task should be called with
    resolve function of class Task.
    """
    def test_fork(reject, resolve):
        resolve(arg)

    obj = MagicMock(Task)
    obj.fork = test_fork

    result = Task.bind(obj, lambda _: obj)
    result.fork(lambda _: None, lambda _: None)

    obj.fork.assert_called_once_with(lambda _: None, lambda _: None)



# Generated at 2022-06-21 19:40:50.192334
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return 'test_Task'

    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-21 19:40:52.159894
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1)
    assert Task.of("Test").map(lambda x: x + " !")


# Generated at 2022-06-21 19:41:03.023938
# Unit test for method map of class Task
def test_Task_map():
    from unittest import TestCase
    from unittest.mock import patch

    class TaskMapTest(TestCase):
        """
        Unit tests for Task class method map
        """

        def test_Task_map(self):
            """
            Unittest for map method of Task class
            """
            mock_reject = patch('tasks.Task.reject').start()
            mock_resolve = patch('tasks.Task.resolve').start()

            def test_func(_, resolve):
                mock_resolve(resolve)
                return 10

            task = Task(test_func)

            def test_mapper(value):
                return value * 2

            task_mapped = task.map(test_mapper)

            task_mapped.fork(mock_reject, mock_resolve)

            mock

# Generated at 2022-06-21 19:41:06.398758
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(lambda value: value ** 2 + 2)

    task = Task(fork).bind(mapper)

    assert task.fork(None, None) == 4


# Generated at 2022-06-21 19:41:13.098766
# Unit test for method map of class Task

# Generated at 2022-06-21 19:41:20.550563
# Unit test for method map of class Task
def test_Task_map():

    def sync_fn(value):
        return value + 1

    def async_fn(value):
        return Task.of(value + 1)

    def sync_map(task):
        return task.map(sync_fn)

    def async_map(task):
        return task.map(async_fn)

    assert sync_map(Task.of(1)).fork(lambda x: x, lambda x: x) == 2

    assert async_map(Task.of(1)).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-21 19:41:25.855310
# Unit test for constructor of class Task

# Generated at 2022-06-21 19:43:22.345003
# Unit test for constructor of class Task
def test_Task():
    # check of type
    assert isinstance(Task(lambda _, __: None), Task)
    # check init attribute
    assert Task(lambda _, __: None).fork
    # check of class method of
    assert Task.of(None).fork(lambda _: None, lambda _: None) is None
    # check of class method reject
    assert Task.reject(None).fork(lambda _: None, lambda _: None) is None
    # check of class method map
    assert Task.of(1).map(lambda x: x + 1).fork(lambda _: None, lambda _: None) == 2
    # check of class method bind
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(lambda _: None, lambda _: None) == 2
    # check of class method bind

# Generated at 2022-06-21 19:43:26.861415
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(42).fork(lambda _: False, lambda arg: arg) == 42
    assert Task.reject(42).fork(lambda arg: arg, lambda _: False) == 42


# Generated at 2022-06-21 19:43:32.347034
# Unit test for method bind of class Task
def test_Task_bind():
    """
    This unit test demonstrate how to use method bind of class Task.
    """
    fn1 = Task.of('lorem ipsum')
    fn2 = Task.of('dolor sit amet')

    fn1.bind(lambda value: fn2).fork(print, print)


# Generated at 2022-06-21 19:43:36.373068
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map.
    Check that method map transform input function and then call it.
    """
    add = lambda x: x + 1
    def test_task(reject, resolve):
        assert add(1) == 2
        resolve(add)

    assert Task(test_task).map(add)(1) == 3



# Generated at 2022-06-21 19:43:39.355193
# Unit test for method bind of class Task
def test_Task_bind():
    def t0(reject, resolve):
        time.sleep(1)
        resolve(1)

    def t1(reject, resolve):
        time.sleep(2)
        resolve(2)


# Generated at 2022-06-21 19:43:42.891504
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(2)
    task = task.bind(lambda value: Task.of(value + 2))

    assert task.fork(lambda x: x + 1, lambda x: x - 1) == 3

# Generated at 2022-06-21 19:43:48.255009
# Unit test for method bind of class Task
def test_Task_bind():
    def setup():
        def _(reject, resolve):
            resolve('text')

        return Task(_)

    def validator(result):
        return result == 'TEXT'

    task = setup()

    task = task.bind(lambda x: Task.of(x.upper()))

    return task, validator



# Generated at 2022-06-21 19:43:55.847271
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method map of class Task
    """
    def _assert(a, b):
        if not a == b:
            raise AssertionError('%s is not equal to %s' % (a, b))

    def resolve(value):
        _assert(value, 20)

    def reject(value):
        _assert(value, 0)

    def bind(value):
        _assert(value, 10)
        return Task.of(value * 2)

    def fmapper(value):
        _assert(value, 10)
        return value * 2

    Task.of(10).bind(bind).fork(reject, resolve)
    Task.of(10).map(fmapper).fork(reject, resolve)



# Generated at 2022-06-21 19:44:01.121985
# Unit test for method map of class Task
def test_Task_map():
    """test_Task_map"""

    mul_two = lambda i: i * 2
    map_two = Task.of(5).map(mul_two)

    def run(resolve): return map_two.fork(lambda i: i, resolve)

    assert run(lambda i: i) == 10


# Generated at 2022-06-21 19:44:06.775251
# Unit test for method map of class Task
def test_Task_map():
    def make_task(value):
        def fork(_, resolve):
            return resolve(value)

        return Task(fork)

    def f(value):
        return value + 1

    assert f(2) == make_task(2).map(f).fork(
        lambda e: e,
        lambda value: value
    )
