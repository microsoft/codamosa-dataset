

# Generated at 2022-06-21 19:34:19.555100
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1


# Generated at 2022-06-21 19:34:23.729936
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve('test')

    resolve = lambda x: x


# Generated at 2022-06-21 19:34:35.740915
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind should return a task that will be resolved with the result of
    running the binded function.
    """
    task = Task.reject("error")
    response_task = task.bind(lambda x: Task.reject("error2"))
    assert response_task.fork("reject", "resolve") == "reject"
    assert response_task.fork("reject", "resolve") == "reject"
    assert response_task.fork("reject", "resolve") == "reject"

    task = Task.of("ok")
    response_task = task.bind(lambda x: Task.of("ok2"))
    assert response_task.fork("reject", "resolve") == "resolve"
    assert response_task.fork("reject", "resolve") == "resolve"
   

# Generated at 2022-06-21 19:34:40.415134
# Unit test for method map of class Task
def test_Task_map():
    # data
    x = Task.of(1)
    fn = lambda value: value + 1

    # perform
    y = x.map(fn)

    # evaluate
    assert y.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-21 19:34:42.304450
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-21 19:34:47.163481
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method.
    """
    # Get example task
    example = Task.of(2)
    # Get expected task
    expected = Task.of(4)
    # Get assert function
    def assert_f(reject, resolve):
        ok = resolve(example) == resolve(expected)
        if not ok:
            print("Test error Task.map")
            exit(ok)

    Task(assert_f).fork(lambda _: _, lambda _: None)


# Generated at 2022-06-21 19:34:57.587854
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        assert callable(reject)
        assert callable(resolve)
        resolve(1)

    task = Task(fork)

    assert task
    assert callable(task.fork)

    assert Task.of(1).map(lambda arg: arg + 1).fork(lambda error: error, lambda value: value) == 2
    assert Task.reject(1).map(lambda arg: arg + 1).fork(lambda error: error, lambda value: value) == 1
    assert Task.of(1).bind(lambda arg: Task.of(arg + 1)).fork(
        lambda error: error,
        lambda value: value
    ) == 2

# Generated at 2022-06-21 19:35:02.101221
# Unit test for method map of class Task
def test_Task_map():
    def function(value):
        return value * 2

    task = Task.of(2)

    assert task\
        .map(function)\
        .fork(lambda arg: None, lambda arg: arg)\
        == 4



# Generated at 2022-06-21 19:35:07.226479
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task(lambda r, r1: r1(1))
    new_task = task.map(fn)

    assert type(new_task) == Task
    assert new_task.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-21 19:35:11.365332
# Unit test for method map of class Task
def test_Task_map():
    """Unit test for method map of class Task"""

    def fork(reject, resolve):
        return resolve(5)

    task_instance = Task(fork)
    assert task_instance.map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 6



# Generated at 2022-06-21 19:35:16.723142
# Unit test for constructor of class Task
def test_Task():
    def test_fork(reject, resolve):
        return resolve(42)

    task = Task(test_fork)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 42


# Generated at 2022-06-21 19:35:23.094774
# Unit test for method map of class Task
def test_Task_map():
    fn = lambda i: i ** 2

    def fork(reject, resolve):
        reject.assert_not_called()
        resolve.assert_not_called()
        resolve(42)

    task = Task(fork).map(fn)
    with mock.patch('tasks.Task.fork') as mock_fork:
        task.fork(lambda _: True, lambda _: True)
        mock_fork.assert_called_once()
        (_, args, _) = mock_fork.mock_calls[0]
        args[0](None)
        args[1].assert_called_once_with(fn(42))


# Generated at 2022-06-21 19:35:24.340562
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(1, 2) == 2
    assert Task.reject(1).fork(2, 1) == 2



# Generated at 2022-06-21 19:35:28.579339
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject('Test reject response')
        resolve('Test resolve response')

    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-21 19:35:33.928361
# Unit test for method bind of class Task
def test_Task_bind():
    def bind_function(arg):
        try:
            return Task.of(arg * 2)
        except Exception as err:
            return Task.reject(err)

    assert Task.of(2).bind(bind_function).fork(reject, resolve) == 4
    assert Task.reject(2).bind(bind_function).fork(reject, resolve) == 2


# Generated at 2022-06-21 19:35:38.534794
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(x):
        assert x is 10
        return Task.of(2 * x)

    def fork(reject, resolve):
        resolve(10)


# Generated at 2022-06-21 19:35:47.349477
# Unit test for method bind of class Task
def test_Task_bind():
    value: int = 0
    add_1 = lambda value: value + 1
    task = Task.of(value).bind(lambda arg: Task.of(add_1(arg)))

    def inc(x):
        return x + 1

    def inc_2(x):
        return Task.of(inc(inc(x)))

    def inc_3(x):
        return Task.of(inc(inc(inc(x))))

    assert Task.reject(30).bind(inc).fork(
        lambda value: 0,
        lambda value: 1
    ) == 0

    assert Task.of(2).bind(inc).fork(
        lambda value: 0,
        lambda value: 1
    ) == 3


# Generated at 2022-06-21 19:35:58.988374
# Unit test for constructor of class Task
def test_Task():
    @Task.of(14)
    def res():
        pass

    assert len(inspect.getargspec(Task.__init__).args) == 2
    assert isinstance(Task(lambda reject, resolve: reject(2)), Task)
    assert res.fork(lambda arg: None, lambda arg: arg * 2) == 28
    assert Task.of(1).fork(lambda arg: None, lambda arg: arg * 2) == 2
    assert Task.reject(1).fork(lambda arg: arg * 2, lambda arg: None) == 2
    assert Task.of(1).map(lambda arg: arg * 2).fork(lambda arg: None, lambda arg: arg) == 2
    assert Task.of(1).bind(lambda arg: Task.of(arg * 2)).fork(lambda arg: None, lambda arg: arg) == 2



# Generated at 2022-06-21 19:36:08.930335
# Unit test for method map of class Task
def test_Task_map():
    def success(value):
        return Task.of(value)

    def fail(value):
        return Task.reject(value)

    def test_success(value):
        return Task.of(value + 1)

    def test_fail(value):
        return Task.reject(value + 1)

    def identity(value):
        return value

    assert success(0).map(identity).fork(reject, resolve) == (0, )
    assert fail(0).map(identity).fork(reject, resolve) == (0, )
    assert fail(0).map(identity).map(test_success).fork(reject, resolve) == (0, )
    assert fail(0).map(identity).map(test_fail).fork(reject, resolve) == (0, )


# Generated at 2022-06-21 19:36:18.295190
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(10)

    def mapper(value):
        return Task.of(value + 10)

    def mapper2(value):
        return Task.of(value + 20)

    task = Task(fork).bind(mapper).bind(mapper2)

    assert task.fork(
        lambda arg: print(arg),
        lambda arg: print(arg)
    ) == 40

    task = Task(fork).bind(mapper).bind(mapper2)

    assert task.fork(
        lambda arg: print(arg),
        lambda arg: print(arg)
    ) == 40


# Generated at 2022-06-21 19:36:27.097188
# Unit test for method bind of class Task
def test_Task_bind():
    def assert_futures(reject, resolve):
        def assert_result(value):
            assert value == 'foo'
            resolve('foo')

        def assert_reject(value):
            assert value == 'bar'
            resolve('bar')

        return reject, assert_result

    # reject two times
    assert_reject, assert_resolve = assert_futures
    task = Task(assert_reject).bind(Task.of).bind(Task.of)
    assert_resolve('foo') == task.fork(assert_reject, assert_resolve)

    # reject two times
    assert_reject, assert_resolve = assert_futures
    task = Task(assert_reject).bind(Task.reject).bind(Task.of)

# Generated at 2022-06-21 19:36:29.731251
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject("foo")

    task = Task(fork)

    assert task.fork is fork


# Generated at 2022-06-21 19:36:41.190487
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for map method of Task class.
    """

    def counter(reject, resolve):
        """
        Generate function with store variable, which could be increased by 1.

        :param reject: function to call with reject value
        :type reject: Function(error) -> Any
        :param resolve: function to call with resolve value
        :type resolve: Function(value) -> Any
        :returns: count of called
        :rtype: Function() -> Count
        """
        count = 0

        def inc():
            nonlocal count
            count += 1
            return count

        return resolve(inc)


# Generated at 2022-06-21 19:36:52.179279
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    assert task.map(lambda x: x + 1).fork(lambda x: None, lambda x: x) == 2

    task = Task.of(1)
    assert task.map(lambda x: x).fork(lambda x: None, lambda x: x) == 1

    task = Task.reject(1)
    assert task.map(lambda x: x).fork(lambda x: x, lambda x: None) == 1

    task = Task.reject('rejected')
    assert task.map(lambda x: 'mapped result').fork(lambda x: x, lambda x: None) == 'rejected'



# Generated at 2022-06-21 19:37:02.754174
# Unit test for method map of class Task
def test_Task_map():
    def assert_element(task, expected):
        assert task.fork is None
        assert task.fork(None, None) == expected

    result = (
        Task
        .of(2)
        .map(lambda value: value + 10)
    )

    assert_element(result, 12)

    result = (
        Task
        .of(2)
        .map(lambda value1: value1 + 5)
        .map(lambda value2: value2 + 10)
    )

    assert_element(result, 17)

    result = (
        Task
        .of(2)
        .map(lambda value1: value1 + 5)
        .map(lambda value2: value2 + 10)
        .map(lambda value3: value3 + 10)
    )

    assert_element(result, 27)

   

# Generated at 2022-06-21 19:37:07.049164
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(_):
        return Task.of(2)

    def mapper_error(_):
        return Task.reject('error')

    def error(task):
        try:
            task.fork(
                lambda _: None,
                lambda _: None
            )
        except ValueError:
            return True
        return False

    assert Task.of(True).bind(mapper).fork(error, lambda _: True)


# Generated at 2022-06-21 19:37:11.170266
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve('foo')

    task = Task(fork)
    assert isinstance(task, Task)
    assert task.fork({}, {}) == 'foo'


# Generated at 2022-06-21 19:37:14.192368
# Unit test for constructor of class Task
def test_Task():
    t = Task(lambda reject, resolve: resolve('foo'))
    assert isinstance(t, Task) is True
    assert t.fork(None, None) == 'foo'


# Generated at 2022-06-21 19:37:22.925298
# Unit test for method bind of class Task
def test_Task_bind():
    # create Task which contain function that return reject
    task_reject = Task(lambda reject, _: reject('fail'))
    # call bind function of this class in wrong way
    # (task_reject doesn't contain resolve function)
    # and assert that result is equal task_reject
    assert task_reject.bind(lambda _: _) == task_reject

    # create Task which contain function that return resolve
    task_resolve = Task(lambda _, resolve: resolve('success'))
    # assert that result is equal task_resolve,
    # value of task_resolve will be pass to lambda,
    # and result of this lambda will return resolve function
    assert task_resolve.bind(lambda _: _).fork(None, lambda x: x) == 'success'

# Generated at 2022-06-21 19:37:24.179138
# Unit test for constructor of class Task
def test_Task():
    assert(Task)



# Generated at 2022-06-21 19:37:35.644968
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(arg):
        one = Task.of(1)
        two = Task.of(2)
        return Task.reject(one.bind(lambda n: n + 1).bind(lambda n: Task.reject(n + 2)))
    result = Task(test_function)
    assert result.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 4


# Generated at 2022-06-21 19:37:38.591125
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda _, resolve: resolve(1)).map(lambda v: v + 1).bind(
        lambda v: Task.of(v * 2)
    ).fork(None, None) == 4


# Generated at 2022-06-21 19:37:47.986995
# Unit test for constructor of class Task
def test_Task():
    """
    Run unit tests for Task class constructor
    """

# Generated at 2022-06-21 19:38:00.313236
# Unit test for method map of class Task
def test_Task_map():
    def f(x): return x + 1

    def g(x): return x * 2

    def h(x, y): return (x + y) ** 2

    x = Task.of(0)

    assert x.fork(lambda x: x, lambda x: x) == 0

    assert x.map(f).fork(lambda x: x, lambda x: x) == 1

    x = Task.of(1)
    assert x.fork(lambda x: x, lambda x: x) == 1

    assert x.map(f).fork(lambda x: x, lambda x: x) == 2

    x = Task.of(2)
    assert x.fork(lambda x: x, lambda x: x) == 2

    assert x.map(f).map(g).fork(lambda x: x, lambda x: x) == 6



# Generated at 2022-06-21 19:38:03.937753
# Unit test for constructor of class Task
def test_Task():
    task = Task.of('foo')
    assert task.fork('rej', 'res') == 'foo'

    another_task = Task.reject('foo')
    assert another_task.fork('rej', 'res') == 'foo'


# Generated at 2022-06-21 19:38:11.166904
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task(
        lambda reject, resolve: resolve(4)
    )


# Generated at 2022-06-21 19:38:20.432041
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Run some unit tests to check method bind of class Task.
    """

    def test_first():
        """
        Test for example of first property of bind.
        """
        x = Task.of(1)
        y = Task.of(2)
        assert binary(x, y) == 3

    def test_first_next():
        """
        Test for example of first property of bind.
        """
        x = Task.of(1)
        y = Task.reject(2)
        assert binary(x, y) == 1

    def test_second():
        """
        Test for example of second property of bind.
        """
        x = Task.reject(1)
        y = Task.of(2)
        assert binary(x, y) == 1


# Generated at 2022-06-21 19:38:26.677471
# Unit test for constructor of class Task
def test_Task():
    a1 = Task(lambda _, resolve: resolve(1))
    a2 = Task.of(2)
    assert a1.fork(lambda _: -1, lambda arg: arg) == a2.fork(lambda _: -1, lambda arg: arg)
    assert a1.fork(lambda arg: arg, lambda _: -1) == a2.fork(lambda arg: arg, lambda _: -1)


# Generated at 2022-06-21 19:38:30.008897
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).map(lambda arg: arg + 1) == Task.of(2)
    assert Task.of(1).map(lambda arg: arg + 1).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 2



# Generated at 2022-06-21 19:38:37.169545
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve():
        return Task.of('result')

    def reject():
        return Task.reject('error')

    def test_resolve(val):
        assert val == 'result'

    def test_reject(val):
        assert val == 'error'

    assert Task.of('value').bind(resolve).fork(test_reject, test_resolve)
    assert Task.of('value').bind(reject).fork(test_reject, None)


# Generated at 2022-06-21 19:38:50.395586
# Unit test for constructor of class Task
def test_Task():
    task = Task((lambda reject, resolve: resolve('task')))

    assert isinstance(task.fork, FunctionType)
    assert task.fork(None, None) == 'task'



# Generated at 2022-06-21 19:38:52.970736
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve(123)

    task = Task(fork)

    assert task.fork(lambda _: None, assert_equal(123)) is None


# Generated at 2022-06-21 19:38:56.307908
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    assert task.map(lambda x: x + 1).fork(None, lambda x: x) == 2

    task = Task.reject(2)
    assert task.map(lambda x: x + 1).fork(lambda x: x) == 2


# Generated at 2022-06-21 19:38:58.125048
# Unit test for constructor of class Task
def test_Task():
    """Simple unit test for constructor of class Task with argument fork"""
    assert Task(lambda _, __: 1) == Task(lambda _, __: 1)  # __: noqa


# Generated at 2022-06-21 19:39:07.472700
# Unit test for method bind of class Task
def test_Task_bind():
    """
    "bind" method should pass argument to mapper function

    """
    a = Task.of(1).bind(lambda x: Task.reject(x + 1))
    assert a.fork(lambda x: x, lambda x: x) == 2

    b = Task.of(1).bind(lambda x: Task.reject(-x))
    assert b.fork(lambda x: x, lambda x: x) == -1

    c = Task.of(1).bind(lambda x: Task.of(x))
    assert c.fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-21 19:39:08.831082
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of('x').map(lambda x: x.upper()).fork(
        lambda rejection: False,
        lambda resolution: resolution == 'X'
    )



# Generated at 2022-06-21 19:39:10.630989
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: resolve(42)).fork(None, None)



# Generated at 2022-06-21 19:39:16.860296
# Unit test for method map of class Task
def test_Task_map():
    """
    Test check behavior of method map.
    """

# Generated at 2022-06-21 19:39:19.230821
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(1))
    assert task.fork(lambda _: 0, lambda value: value) == 1


# Generated at 2022-06-21 19:39:24.565635
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve('foo')

    task = Task(fork)

    new_task = task.map(lambda value: value + '_bar')


# Generated at 2022-06-21 19:39:55.088005
# Unit test for method bind of class Task
def test_Task_bind():
    def inc(x): return x + 1
    def add(x, y): return x + y


# Generated at 2022-06-21 19:39:57.822452
# Unit test for method map of class Task
def test_Task_map():
    source = Task(lambda a, b: b(1))
    fn = lambda x: x + 1
    assert source.map(fn).fork(None, None) == 2


# Generated at 2022-06-21 19:40:04.446608
# Unit test for constructor of class Task
def test_Task():
    @Task.of(100)
    def add(a, b):
        return a + b

    assert add.fork(lambda _: 0, lambda _: 1) == 1
    assert add.fork(None, None) == 1

    @Task.reject(100)
    def add(a, b):
        return a + b

    assert add.fork(lambda _: 0, lambda _: 1) == 0
    assert add.fork(None, lambda _: 0) == 0


# Generated at 2022-06-21 19:40:07.567868
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(42).fork(lambda x: x, lambda x: x) == 42, 'Task store value'
    assert Task.reject('Hello, world').fork(lambda x: x, lambda x: x) == 'Hello, world', 'Task store reject value'



# Generated at 2022-06-21 19:40:11.237397
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda a, b: None)


# Generated at 2022-06-21 19:40:15.104807
# Unit test for method bind of class Task
def test_Task_bind():
    def test(value):
        mapper = lambda arg: Task.of(arg)
        return Task.reject(value).bind(mapper).fork(lambda arg: value, lambda _: False)

    assert test(1) == 1


# Generated at 2022-06-21 19:40:18.142628
# Unit test for constructor of class Task
def test_Task():
    """
    Test for test of class Task
    """
    def fork(_, resolve):
        return resolve(42)

    value = Task(fork).fork(lambda res: 'rejected', lambda res: res)
    assert value == 42


# Generated at 2022-06-21 19:40:24.149901
# Unit test for method bind of class Task
def test_Task_bind():
    def get_rejected():
        return Task.of(2).bind(lambda _: Task.reject(1)).fork(
            lambda value: value,
            lambda _: 0
        )

    assert get_rejected() == 1

    def get_resolved():
        return Task.of(2).bind(lambda _: Task.of(1)).fork(
            lambda _: 0,
            lambda value: value
        )

    assert get_resolved() == 1

    def get_rejected_with_mapped_value():
        return Task.of(2).bind(lambda _: Task.reject(1)).fork(
            lambda value: value,
            lambda _: 0
        )

    assert get_rejected_with_mapped_value() == 1


# Generated at 2022-06-21 19:40:27.565053
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    double_task = task.bind(lambda arg: Task.of(arg * 2))
    assert double_task.fork(lambda reject, _: reject, lambda _, resolve: resolve) == 2


# Generated at 2022-06-21 19:40:30.646863
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(5)

    def use(arg):
        return Task.of(arg + 1)

    task = Task(fork)
    result = task.bind(use).fork(None, None)
    assert result == 6


# Generated at 2022-06-21 19:41:19.627310
# Unit test for constructor of class Task
def test_Task():
    """
    Check is fork attribute right after creation
    """
    t = Task(lambda _, resolve: resolve('test'))
    assert t.fork == (lambda _, resolve: resolve('test'))


# Generated at 2022-06-21 19:41:23.826345
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> Task.of(5).bind(lambda a: Task.of(a + 1)).fork(lambda _: False, lambda a: a) == 6
    True
    """


# Generated at 2022-06-21 19:41:25.016353
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return 'fork'

    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-21 19:41:28.551536
# Unit test for method map of class Task
def test_Task_map():
    count = 0
    def task(_, resolve):
        resolve(1)

    def mapper(value):
        assert value == 1
        return value + 1

    assert Task(task).map(mapper).fork(
        lambda _: 'Fail',
        lambda value: value
    ) == 2


# Generated at 2022-06-21 19:41:32.169958
# Unit test for method bind of class Task
def test_Task_bind():
    task_int = Task.of(1)
    result = Task.of(2)

    def add_and_return_task(arg):
        assert arg == 1
        return result

    assert task_int.bind(add_and_return_task).fork(None, lambda a: a) == 2

# Generated at 2022-06-21 19:41:38.452967
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(10)

    def map(value):
        return Task.of(value + 20)

    def bind(value):
        return Task.of(value + 20)

    task = Task(fork)
    assert task.map(map).fork(lambda x: x, lambda x: x) == 40
    assert task.bind(bind).fork(lambda x: x, lambda x: x) == 40



# Generated at 2022-06-21 19:41:45.253918
# Unit test for constructor of class Task
def test_Task():
    # Define error_collector for received errors
    error_collector = []

    # Define resolve mock for resolve in fork parameter
    def resolve(value):
        if value == 'from_fork':
            print(value)
        else:
            error_collector.append('mock_was_called_with_wrong_value')

    # Define reject mock for reject in fork parameter
    def reject(value):
        if value == 'from_fork':
            print(value)
        else:
            error_collector.append('mock_was_called_with_wrong_value')

    # Call fork with defined mocks
    # Point of interest: nothing happen, because async Task
    Task(lambda reject, resolve: 'from_fork').fork(reject, resolve)

    # Check, that mocks was not called

# Generated at 2022-06-21 19:41:50.922793
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    # Create Task with resolve, reject attributes
    task = Task(lambda reject, resolve: reject(2))

    # Add 1 to rejected value and check result
    task_map = task.map(mapper)
    assert task_map.fork(lambda err: err, lambda res: res) == 3


# Generated at 2022-06-21 19:41:54.389098
# Unit test for constructor of class Task
def test_Task():
    task = Task.of(10)
    assert task.fork(lambda a: a, lambda a: a) == 10

    task = Task.reject(10)
    assert task.fork(lambda a: a, lambda a: a) == 10


# Generated at 2022-06-21 19:41:58.668010
# Unit test for method map of class Task
def test_Task_map():
    """
    :returns: assertion error or pass
    :rtype: AssertionError | None
    """
    # pylint: disable=missing-return-doc, missing-return-type-doc
    def _test_map(_, resolve):
        return resolve(2)

    def double(value):
        return value * 2

    task = Task(_test_map)
    task = task.map(double)

    assert task.fork(lambda _: False, lambda arg: arg == 4)


# Generated at 2022-06-21 19:43:49.009557
# Unit test for method bind of class Task
def test_Task_bind():
    task_1 = Task.of(1)
    task_2 = task_1.bind(
        lambda arg: Task.of(arg + 1)
    )
    assert task_2.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 2

# Generated at 2022-06-21 19:43:55.270612
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Create inner function and pass it to bind as arg, this function should be called with
    value stored in Task (argument of resolve function stored in Task). Store result of called
    and pass to resolve in returned Task. Resolve should be called with stored value.

    :returns: True if test passed
    :rtype: bool
    """
    value = 1
    task = Task.of(value)
    result = task.bind(lambda arg: Task.of(arg + 1)).fork(lambda arg: False, lambda arg: arg == value + 1)

    return result

# Generated at 2022-06-21 19:44:07.745624
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(arg):
        return Task.of('function called')

    task = Task.of('value')
    task = task.bind(test_function)
    # Task.fork is called
    assert task.fork(
        lambda error: 'rejected with error: {}'.format(error),
        lambda value: 'resolved with value: {}'.format(value)
    ) == 'resolved with value: function called'

    task = Task.reject('error')
    task = task.bind(test_function)
    # Task.fork is called
    assert task.fork(
        lambda error: 'rejected with error: {}'.format(error),
        lambda value: 'rejected with value: {}'.format(value)
    ) == 'rejected with error: error'



# Generated at 2022-06-21 19:44:17.661298
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map(Function(A) -> B) -> Task[B]
    """

    # Example:
    fibonacci = Task.of(0).bind(lambda _:
        Task.of(1).bind(lambda _:
            Task.of(1).bind(lambda _:
                fibonacci.bind(lambda a:
                    fibonacci.bind(lambda b:
                        Task.of(a + b)
                    )
                ).bind(lambda c:
                    fibonacci.bind(lambda _:
                        Task.of(c)
                    )
                )
            )
        )
    )

    fibonacci_map = fibonacci.map(lambda arg: arg + 1)

    assert fibonacci_map.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1

