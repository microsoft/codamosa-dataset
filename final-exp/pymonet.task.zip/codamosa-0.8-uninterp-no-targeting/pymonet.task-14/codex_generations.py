

# Generated at 2022-06-21 19:34:20.292909
# Unit test for method map of class Task
def test_Task_map():
    def fn_to_map(value):
        return "fn_to_map({})".format(value)

    assert Task.of("A").map(fn_to_map).fork(None, assert_equal.func("fn_to_map(A)"))
    assert Task.reject("A").map(fn_to_map).fork(assert_equal.func("A"), None)


# Generated at 2022-06-21 19:34:26.868938
# Unit test for method bind of class Task
def test_Task_bind():
    """Test for Task.bind method"""

    # Create some simple functions for test
    def get_value(arg):
        return arg  # For example function, return arg during call

    def to_resolve(arg):
        return Task.of(arg)  # Return resolved Task

    def to_reject(arg):
        return Task.reject(arg)  # Return rejected Task

    # Test Task with to_resolve mapper
    task = Task.of('value')
    task = task.bind(to_resolve)
    assert isinstance(task, Task)
    assert task.fork(get_value, get_value) == 'value'

    # Test Task with to_reject mapper
    task = Task.of('value')
    task = task.bind(to_reject)
    assert isinstance(task, Task)

# Generated at 2022-06-21 19:34:30.065922
# Unit test for method map of class Task
def test_Task_map():
    @Task.of(1)
    def task_map():
        pass

    result = task_map.map(lambda x: x + 1)
    assert result.fork(lambda r: r, lambda r: r) == 2

test_Task_map()


# Generated at 2022-06-21 19:34:34.253666
# Unit test for method map of class Task
def test_Task_map():
    def resolver(reject, resolve):
        reject('reject')
        resolve('resolve')

    def rejector(reject, resolve):
        resolve('reject')
        reject('resolve')

    task = Task(resolver)
    task_resolved = task.map(lambda x: True)
    task_rejected = Task(rejector).map(lambda x: True)

    assert task_resolved.fork(False, True) == True
    assert task_rejected.fork(True, False) == True


# Generated at 2022-06-21 19:34:42.263787
# Unit test for method map of class Task
def test_Task_map():
    def test_f(n):
        return n + 1

    def test_g(arg):
        return Task.of(test_f(arg))

    assert Task.of(1).map(test_f).fork(lambda a: a, lambda a: a) == 2
    assert Task.of(2).map(lambda a: test_f(a)).fork(lambda a: a, lambda a: a) == 3
    assert Task.of(3).bind(lambda a: test_g(a)).fork(lambda a: a, lambda a: a) == 4


# Generated at 2022-06-21 19:34:48.910959
# Unit test for constructor of class Task
def test_Task():
    t = Task(lambda _, resolve: resolve(3))
    def result(reject, resolve):
        return t.fork(lambda err: reject(err), lambda x: resolve(x))
    assert Task(result).fork(lambda err: err, lambda x: x) == 3


# Generated at 2022-06-21 19:34:54.954944
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for constructor of class Task
    """
    assert Task.of('test').fork(
        lambda _: False,
        lambda value: value == 'test'
    )

    assert Task.reject(None).fork(
        lambda _: True,
        lambda _: False
    )


# Generated at 2022-06-21 19:34:59.201191
# Unit test for method bind of class Task
def test_Task_bind():
    # mock function and create Task with it
    def mock_function(a):
        return Task.of(a)

    task = Task.of(1).bind(mock_function)

    # call fork method
    task.fork(lambda _: print('reject'), lambda resolve: print(resolve))


# Generated at 2022-06-21 19:35:07.427477
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x: Task.of(x + 1)) == Task.of(2)
    assert Task.reject(1).bind(lambda x: Task.reject(x + 1)) == Task.reject(2)
    assert Task.of(1).bind(lambda x: Task.reject(x + 1)) == Task.reject(2)
    assert Task.reject(1).bind(lambda x: Task.of(x + 1)) == Task.reject(1)



# Generated at 2022-06-21 19:35:16.878412
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    def fn_throw(value):
        raise Exception

    def fn_side_effect(value):
        print('Side-effect!', value)
        return value

    assert Task.of(1).map(fn).fork(None, lambda value: value) == 2
    assert Task.reject(1).map(fn).fork(lambda value: value, None) == 1
    assert Task.of(1).map(fn_throw).fork(None, lambda value: value) == 1
    assert Task.reject(1).map(fn_throw).fork(lambda value: value, None) == 1
    assert Task.of(1).map(fn_side_effect).fork(None, lambda value: value) == 1

# Generated at 2022-06-21 19:35:23.879169
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task.
    """
    def fork(reject, resolve):
        assert reject == reject_test
        assert resolve == resolve_test
        return reject(resolve_test)

    reject_test = 42
    resolve_test = 43

    task = Task(fork)
    assert 42 == task.fork(reject_test, resolve_test)


# Generated at 2022-06-21 19:35:34.641245
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Check Task.bind method with positive values.
    """
    def add_one(number):
        return Task.of(number + 1)

    def multiply_two(number):
        return Task.of(number * 2)

    def test_add_one_then_multiply_two(number):
        return Task.of(number).bind(add_one).bind(multiply_two).fork(
            lambda arg: "reject: " + str(arg),
            lambda arg: "resolve: " + str(arg)
        )

    assert test_add_one_then_multiply_two(3) == 'resolve: 8', "test_add_one_then_multiply_two"


# Generated at 2022-06-21 19:35:42.685879
# Unit test for method bind of class Task
def test_Task_bind():
    # non-monadic function
    def func(arg):
        return arg + 1

    # monadic function
    def monadic_func(arg):
        return Task.of(arg + 1)

    # non-monadic function
    assert Task.of(1).bind(func).fork(
        lambda reject: None,
        lambda resolve: resolve
    ) == 2

    # monadic function
    assert Task.of(1).bind(monadic_func).fork(
        lambda reject: None,
        lambda resolve: resolve
    ) == 2


# Generated at 2022-06-21 19:35:46.469521
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task
    :return: 
    """
    def fork(reject, resolve):
        return reject([1, 2, 3])

    task = Task(fork)
    assert task


# Generated at 2022-06-21 19:35:58.221470
# Unit test for method map of class Task
def test_Task_map():
    def task_resolve(reject, resolve):
        return resolve(2)

    def task_reject(reject, resolve):
        return reject(1)

    def add_one(value):
        return value + 1

    def times_two(value):
        return value * 2

    task = Task(task_resolve)

    assert task.map(add_one).fork(lambda x: x, lambda x: x) == 3
    assert task.map(times_two).fork(lambda x: x, lambda x: x) == 4

    task = Task(task_reject)

    assert task.map(add_one).fork(lambda x: x, lambda x: x) == 1
    assert task.map(times_two).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-21 19:36:00.885282
# Unit test for constructor of class Task
def test_Task():
    def fork(_, resolve):
        resolve(2)
        return None

    assert Task(fork).fork(
        lambda x: 0,
        lambda x: x
    ) == 2


# Generated at 2022-06-21 19:36:05.405483
# Unit test for method map of class Task
def test_Task_map():
    task_rejected = Task.reject(1)
    task_resolved = Task.of(1)

    def plus(num):
        return num + 1

    assert task_resolved.map(plus)().get() == 2
    assert task_rejected.map(plus)().get() == 1



# Generated at 2022-06-21 19:36:09.126450
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(should_raise, lambda arg: arg) == 1
    assert Task.reject(1).fork(lambda arg: arg, should_raise) == 1
    assert Task(lambda _, resolve: resolve(1)).fork(should_raise, lambda arg: arg) == 1


# Generated at 2022-06-21 19:36:13.035181
# Unit test for constructor of class Task
def test_Task():
    def test_constructor(resolve, reject):
        reject('ok')

    assert Task.of('ok').fork(lambda arg: False, lambda arg: isinstance(arg, Task))


# Generated at 2022-06-21 19:36:19.600974
# Unit test for method bind of class Task
def test_Task_bind():
    def get_task(num):
        return Task.of(num)

    def get_string(num):
        return "{}_str".format(num)

    task = Task.of(10)
    task = task.bind(get_task)
    assert task.fork("", lambda x: x) == 10
    task = task.map(get_string)
    assert task.fork("", lambda x: x) == "10_str"


# Generated at 2022-06-21 19:36:23.650336
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x + 1) == Task.of(3)


# Generated at 2022-06-21 19:36:29.364759
# Unit test for method bind of class Task
def test_Task_bind():
    val = Task(lambda _, resolve: resolve(2))
    def f(value):
        return Task(lambda _, resolve: resolve(value + 3))

    assert val.bind(f).fork(lambda x: x, lambda x: x) == 5
    assert val.bind(f).fork(lambda x: x, lambda x: x) == 5

test_Task_bind()

# Generated at 2022-06-21 19:36:34.980593
# Unit test for constructor of class Task
def test_Task():
    """
    Test Task constructor

    :returns: Test result
    :rtype: bool
    """
    def result(reject, resolve):
        resolve(True)
    task = Task(result)

    if task.fork(lambda arg: reject(arg), lambda arg: resolve(arg)):
        return True
    else:
        return False



# Generated at 2022-06-21 19:36:39.939184
# Unit test for constructor of class Task
def test_Task():
    """
    Test Task class.
    Check constructor.
    """
    fork = lambda _, resolve: resolve('yay')

    task1 = Task(fork)

    assert fork is task1.fork
    assert task1.fork(lambda reject, resolve: resolve('Resolved value')) == 'Resolved value'


# Generated at 2022-06-21 19:36:44.291201
# Unit test for method bind of class Task
def test_Task_bind():
    assert (
        Task.of(2)
        .bind(lambda arg: Task.of(arg + 1))
        .fork(print, print)
    ) == 3

    assert (
        Task.of(2)
        .bind(lambda arg: Task.of(arg + 1))
        .bind(lambda arg: Task.of(arg + 2))
        .fork(print, print)
    ) == 5


# Generated at 2022-06-21 19:36:47.409979
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    assert Task(fork).fork(lambda arg: None, lambda arg: arg) == 1


# Generated at 2022-06-21 19:36:53.323994
# Unit test for method map of class Task
def test_Task_map():
    def add_one(arg):
        return arg + 1

    def sub_two(arg):
        return arg - 2

    def is_result_equal(arg):
        assert arg == 10

    task = Task.of(9)
    argument = task.map(add_one).map(sub_two)
    fork = argument.fork
    fork(lambda arg: None, is_result_equal)
    assert fork == argument.fork


# Generated at 2022-06-21 19:36:57.197991
# Unit test for method map of class Task
def test_Task_map():
    def add2(x):
        return x + 2

    assert Task.of(10).map(add2).fork(None, lambda x: x) == 12
    assert Task.reject(10).map(add2).fork(lambda x: x, None) == 10


# Generated at 2022-06-21 19:37:01.609091
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)

    def fn(value):
        return Task.of(value)

    def fn_error(value):
        assert False

    assert task.bind(fn).fork(fn_error, lambda value: value == 1)


# Generated at 2022-06-21 19:37:03.484179
# Unit test for constructor of class Task
def test_Task():
    uut = Task(lambda _, b: b(1))
    assert uut.fork(*[None] * 2) == 1



# Generated at 2022-06-21 19:37:14.193054
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value * 2

    task = Task.of(1)
    task = task.map(mapper)

    def fork(reject, resolve):
        resolve(3)
        assert task.fork(reject, resolve) == 6, 'incorrect map operator'


# Generated at 2022-06-21 19:37:23.617256
# Unit test for method bind of class Task
def test_Task_bind():
    def get_github_username(url):
        #  regex = re.compile(r'https://github.com/(\w+)')
        match = re.search('https://github.com/(\w+)', url)
        if match:
          return match.group(1)

    def get_github_username_task(url):
        username = get_github_username(url)
        if username:
            return Task.of(username)
        else:
            raise ValueError('Could not get username')

    def get_github_page(username):
        time.sleep(2)
        return '{}\'s page'.format(username)

    def get_github_page_task(username):
        page = get_github_page(username)
        return Task.of(page)

    github_username_task = Task.of

# Generated at 2022-06-21 19:37:33.490911
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def assert_result(task, expect):
        assert task.fork(None, lambda value: value) == expect

    task = Task.of(1)
    task = task.map(add_one).map(add_two).map(add_three)
    assert_result(task, 6)

    task = Task.of(2)
    task = task.map(add_one).map(add_two).map(add_three)
    assert_result(task, 7)

    task = Task.of(3)
    task = task.map(add_one).map(add_two).map(add_three)

# Generated at 2022-06-21 19:37:42.266989
# Unit test for method bind of class Task
def test_Task_bind():
    def get_task(value):
        return Task.of(value)

    task = Task.of(4).bind(get_task).map(lambda value: value + 3)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 7

    task = Task.of(None).bind(get_task).map(lambda value: value + 3)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 3
    
    task = Task.of(6).bind(get_task).map(lambda value: value + 3).map(lambda value: value + 4)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 13


# Generated at 2022-06-21 19:37:43.310182
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1)



# Generated at 2022-06-21 19:37:51.364040
# Unit test for constructor of class Task
def test_Task():
    tester = unittest.TestCase()

    def fork(reject, resolve):
        return 42

    def fn(value):
        return value + 42

    task = Task(fork)
    value = task.fork(None, None)
    tester.assertEqual(value, 42)
    task = task.map(fn)
    value = task.fork(None, None)
    tester.assertEqual(value, 84)
    value = task.map(lambda x: x + 2).fork(None, None)
    tester.assertEqual(value, 86)
    task = Task.of(42)
    value = task.fork(None, None)
    tester.assertEqual(value, 42)
    task = task.map(fn)
    value = task.fork(None, None)
   

# Generated at 2022-06-21 19:37:57.424716
# Unit test for constructor of class Task
def test_Task():
    result = Task.of(1)
    assert result.fork(lambda _: False, lambda arg: arg == 1)
    assert not result.fork(lambda _: True, lambda _: False)

    result = Task.reject(1)
    assert result.fork(lambda arg: arg == 1, lambda _: False)
    assert not result.fork(lambda _: False, lambda _: True)


# Generated at 2022-06-21 19:38:00.742633
# Unit test for method map of class Task
def test_Task_map():
    value = 'zxcv'
    task = Task.of(value).map(lambda val: val + 'asdf')
    assert task.fork(None, lambda val: val) == 'zxcvasdf'


# Generated at 2022-06-21 19:38:06.589921
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method `map` of class `Task`.
    """

    def task_of_num(n):
        """
        return Task of n, it is ready to resolve
        """
        return Task.of(n)

    def task_of_fn(fn):
        """
        return Task of fn, it is ready to resolve
        """
        return Task.of(fn)

    def triple(num):
        return num * 3

    def double(num):
        return num * 2

    # Test case 1
    # Increase Task 1.5 by 3
    task_of_fn(triple).map(lambda fn: task_of_num(1.5).map(fn)).fork(
        lambda error: print(error),
        lambda value: print('Expected value 3, actual {}'.format(value))
    )

# Generated at 2022-06-21 19:38:09.629489
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    assert Task(fork).fork(None, None) == 1


# Generated at 2022-06-21 19:38:22.003931
# Unit test for method bind of class Task
def test_Task_bind():
    def _reject(value):
        _reject.value = value
        return _reject

    def _resolve(value):
        _resolve.value = value
        return _resolve

    def _fork(reject, resolve):
        return reject('resolve')

    _Task = Task(_fork)

    def test_mapper(value):
        return Task.of('mapped_value')

    _Task.bind(test_mapper).fork(_reject, _resolve)

    assert _resolve.value == 'mapped_value'



# Generated at 2022-06-21 19:38:26.090984
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.
    """
    after_map = Task.of(7).map(lambda arg: arg + 3)
    assert after_map.fork(lambda arg: arg + 42, lambda arg: arg - 5) == 5


# Generated at 2022-06-21 19:38:32.050575
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method
    """
    # Resolved Task
    add_one = Task.of(1).map(lambda arg: arg + 1)

# Generated at 2022-06-21 19:38:36.582293
# Unit test for constructor of class Task
def test_Task():
    try:
        Task(42)
        assert False
    except TypeError:
        assert True

    assert Task.of(42).fork(lambda x: x, lambda y: y) == 42
# Run unit test for constructor of class Task
test_Task()


# Generated at 2022-06-21 19:38:41.860307
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one_to_arg(arg):
        return arg + 1

    def get_add_one_to_arg(arg):
        return Task.of(add_one_to_arg(arg))

    assert Task.of(1).bind(get_add_one_to_arg).fork(lambda _: None, lambda arg: arg) == 2
    assert Task.of(1).bind(get_add_one_to_arg).bind(get_add_one_to_arg).fork(lambda _: None, lambda arg: arg) == 3


# Generated at 2022-06-21 19:38:45.502093
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    assert Task(fork).fork(
        lambda _: 1,
        lambda arg: arg
    ) == 1

# Unit test of Task.of method

# Generated at 2022-06-21 19:38:49.603862
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('test_value')

    task = Task(fork)

    assert isinstance(task, Task)

# Generated at 2022-06-21 19:38:56.584148
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)).map(lambda x: x + 1).fork(None, assert_equals(2)) == None
    assert Task(lambda _, resolve: resolve(1)).map(lambda x: x * 2).fork(None, assert_equals(2)) == None
    assert Task(lambda _, resolve: resolve(1)).map(lambda x: x + '2').fork(None, assert_equals('12')) == None
    assert Task(lambda _, resolve: resolve(1)).map(lambda x: [ x, x ]).fork(None, assert_equals([1, 1])) == None


# Generated at 2022-06-21 19:39:00.288146
# Unit test for constructor of class Task
def test_Task():
    # assert Task((lambda _, resolve: resolve(1))).fork(lambda arg: arg, lambda arg: arg) == 1
    assert Task((lambda _, resolve: resolve(1))).fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-21 19:39:12.253430
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map method.

    :returns: None
    :rtype: None
    """
    def test_function_for_map(resolve, reject):
        """
        Function which need to map.

        :returns: None
        :rtype: int | str
        """
        resolve(1)

    def test_function_for_map_result(value):
        """
        Function which need to map returned Task.

        :param value: value returned into fork function of Task
        :type value: int
        :returns: None
        :rtype: str
        """
        return str(value)

    # test: returned Task must call resolve with test_function_for_map_result result

# Generated at 2022-06-21 19:39:22.309957
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: reject("test")).fork(lambda arg: arg, throw) == "test"
    assert Task(lambda reject, resolve: resolve("test")).fork(throw, lambda arg: arg) == "test"

# Unit test of method Task.of

# Generated at 2022-06-21 19:39:25.525830
# Unit test for method map of class Task
def test_Task_map():
    """
    >>> result = Task.of(1).map(lambda value: value + 1)
    >>> assert result.fork(lambda reject, resolve: resolve(0)) == 2
    """


# Generated at 2022-06-21 19:39:31.798959
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(42)

    def mapper(value):
        return value + 1

    def fork_mapper(reject, resolve):
        resolve(mapper(42))

    result = True
    task = Task(fork)
    mapper_task = Task(fork_mapper)
    assert result == task.bind(lambda value: mapper_task).fork(lambda _: False, lambda arg: arg == 43)


# Generated at 2022-06-21 19:39:36.140934
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        # fake function
        pass

    task = Task(fork)

    assert isinstance(task, Task)
    assert task.fork == fork

    assert isinstance(task.of(42), Task)
    assert isinstance(task.of(42).fork, FunctionType)

    assert isinstance(task.reject(42), Task)
    assert isinstance(task.reject(42).fork, FunctionType)



# Generated at 2022-06-21 19:39:39.692418
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(42)).fork(None, None) == 42
    assert Task(lambda reject, _: reject(42)).fork(None, None) == 42


# Generated at 2022-06-21 19:39:46.072966
# Unit test for constructor of class Task
def test_Task():
    # Test for constructor of class Task
    fork = lambda reject, resolve: reject(1)
    task = Task(fork)
    assert task.fork == fork
    assert task.fork(lambda x: None, lambda x: None) == 1
    assert Task.of(1).fork(lambda x: None, lambda x: None) == 1
    assert Task.reject(1).fork(lambda x: None, lambda x: None) == 1
    assert Task.of(1).map(lambda x: None).fork(lambda x: x, lambda x: None) == None


# Generated at 2022-06-21 19:39:50.504936
# Unit test for method map of class Task
def test_Task_map():
    """
    Test is Task map method works properly.
    """
    def add(x, y):
        """
        Return sum of x and y.
        """
        return x + y

    assert Task.of(5).map(add)(5).fork(lambda _: False, lambda r: r == 10)


# Generated at 2022-06-21 19:39:59.047734
# Unit test for method bind of class Task
def test_Task_bind():
    # test bind on reject
    assert Task.of('a').bind(lambda arg: Task.of(arg)).fork(lambda value: value, lambda value: value) == 'a'
    assert Task.reject('a').bind(lambda arg: Task.of(arg)).fork(lambda value: value, lambda value: value) == 'a'

    # test bind on resolve
    assert Task.of('a').bind(lambda arg: Task.reject(arg)).fork(lambda value: value, lambda value: value) == 'a'
    assert Task.of('a').bind(lambda arg: Task.reject('b')).fork(lambda value: value, lambda value: value) == 'b'


# Generated at 2022-06-21 19:40:03.791098
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(42)

    def mapper(value):
        assert value == 42
        return Task.of(10)

    task = Task(fork)

# Generated at 2022-06-21 19:40:07.055619
# Unit test for constructor of class Task
def test_Task():
  def fork(reject, resolve):
    return reject(15)

  task = Task(fork)
  assert task.fork(lambda i: 15, lambda i: 16) == 15
  assert task.fork(lambda i: 15, lambda i: 16) == 15



# Generated at 2022-06-21 19:40:20.034986
# Unit test for method map of class Task
def test_Task_map():
    def inc(arg):
        return arg + 1

    task = Task.of(1).map(inc)
    assert task.fork(lambda reject: reject, lambda resolve: resolve) == 2

    task = Task.of(None).map(lambda _: 1)
    assert task.fork(lambda reject: reject, lambda resolve: resolve) == 1

    task = Task.reject(1).map(inc)
    assert task.fork(lambda reject: reject, lambda resolve: resolve) == 1


# Generated at 2022-06-21 19:40:22.933934
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda x, y: x + y)(1, 2) == 3
    assert Task(lambda x, y: x + y).fork(lambda i: i, lambda j: j)(1, 2) == 3


# Generated at 2022-06-21 19:40:26.817746
# Unit test for method map of class Task
def test_Task_map():
    def times_two(value):
        return value * 2

    def wrong(value):
        return value / 0

    task = Task.of(2)
    assert task.map(wrong).map(times_two).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 4

# Generated at 2022-06-21 19:40:30.455906
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(arg):
        return Task.of(arg)

    def fork_return_value(reject, resolve):
        return resolve(1)

    task = Task(fork_return_value)

    assert_equal(task.bind(mapper).fork, mapper(1).fork)


# Generated at 2022-06-21 19:40:35.589575
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test function for method bind of class Task
    """
    def is_even(num):
        return num % 2 == 0

    def incr(num):
        return num + 1

    def success(num):
        assert num == 3

    def error(num):
        assert False, 'invalid argument: %s' % num

    num = 2
    Task.of(num)\
        .bind(lambda num: Task.of(num) if is_even(num) else Task.reject(False))\
        .bind(lambda num: Task.of(incr(num)))\
        .fork(error, success)


# Generated at 2022-06-21 19:40:36.528580
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task(lambda r, s: r(1)), Task)


# Generated at 2022-06-21 19:40:44.605111
# Unit test for constructor of class Task
def test_Task():
    t = Task(lambda _, resolve: resolve(1))
    assert t.fork(lambda err: None, lambda res: res) == 1
    t = Task.of(1)
    assert t.fork(lambda err: None, lambda res: res) == 1
    t = Task.reject(1)
    assert t.fork(lambda err: err, lambda res: None) == 1


# Generated at 2022-06-21 19:40:46.107110
# Unit test for method map of class Task
def test_Task_map():
    def inc(x):
        return x + 1

    task = Task.of(1)

    assert task.map(inc).fork(None, lambda arg: arg) == 2


# Generated at 2022-06-21 19:40:53.537327
# Unit test for method bind of class Task
def test_Task_bind():
    """
    create a variable with Task of value 0 and
    test map and bind for value 1
    """
    t0 = Task.of(0)
    t1 = t0.map(lambda a: a + 1)
    t2 = t1.bind(lambda a: Task.of(a + 1))


# Generated at 2022-06-21 19:41:04.480014
# Unit test for method bind of class Task
def test_Task_bind():
    from hypothesis import given
    from hypothesis.strategies import integers
    from hypothesis.strategies import composite

    def it_should_return_identity_function(arg1, arg2):
        def mapper(arg):
            return Task.of(arg)

        assert Task.of(arg1).bind(mapper) == Task.of(arg1)
        assert Task.reject(arg2).bind(mapper) == Task.reject(arg2)

    @composite
    def test_case(draw):
        arg1 = draw(integers())
        arg2 = draw(integers())

        return it_should_return_identity_function(arg1, arg2)

    @given(test_case())
    def test_Task_bind(fn):
        fn()



# Generated at 2022-06-21 19:41:23.157838
# Unit test for method map of class Task
def test_Task_map():
    """
    1. Create Task with A as returned value
    2. Map Task with function f
    3. Expect result is Task with f(A)
    """
    def f(x):
        return x + 'a'

    task = Task(lambda _, resolve: resolve('b'))

    assert(
        task.map(f) ==
        Task(lambda _, resolve: resolve(f('b')))
    )


# Generated at 2022-06-21 19:41:24.683035
# Unit test for constructor of class Task
def test_Task():
    def fork_add(reject, resolve):
        resolve(1 + 1)

    task = Task(fork_add)
    assert task.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-21 19:41:29.631351
# Unit test for method bind of class Task
def test_Task_bind():

    task_reject = Task.reject(10)
    task_resolve = Task.of(20)

    def foo(x):
        # (x, y) -> Task[reject, x + y]
        return Task.of(x + y)

    assert task_resolve.bind(foo).fork(reject, resolve) == 30
    assert task_reject.bind(foo).fork(reject, resolve) == 10


# Generated at 2022-06-21 19:41:35.759194
# Unit test for method map of class Task
def test_Task_map():
    """
    Test verify if Task.map(fn) returns a new Task with function `fn`
    stored as resolve argument.
    """
    def fn(arg):
        return arg ** 2

    task = Task.of(2)
    assert task.map(fn).fork(lambda _: None, lambda arg: arg) == 4

# References:
# [1] Haskell Monad Laws - https://wiki.haskell.org/Monad_laws

# Generated at 2022-06-21 19:41:39.712978
# Unit test for method map of class Task
def test_Task_map():
    def resolve_fn(x):
        return x + 100

    def reject_fn(x):
        return x * 10

    task = Task.of(10).map(resolve_fn)

    result = task.fork(reject_fn, resolve_fn)

    assert result == 110, "result should be 110"


# Generated at 2022-06-21 19:41:43.553767
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda a: a + 1).fork(lambda r: False, lambda r: r) == 2
    assert Task.of(3).map(lambda a: a - 1).fork(lambda r: False, lambda r: r) == 2
    assert Task.of(2).map(lambda a: a * 2).fork(lambda r: False, lambda r: r) == 4


# Generated at 2022-06-21 19:41:49.910436
# Unit test for constructor of class Task
def test_Task():
    def fake_resolve():
        return True

    def fake_reject():
        return False

    task = Task(fake_resolve)
    assert isinstance(task, Task)
    assert task.fork(fake_reject, fake_resolve)
    assert not task.fork(fake_reject, fake_reject)


# Generated at 2022-06-21 19:41:57.476698
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Function use to test method bind of class Task
    """
    Task.reject('Unexpected error').bind(lambda _: Task.reject('Handle error')).fork(print, print) # reject is not executed
    Task.of('value').bind(lambda _: Task.reject('Handle error')).fork(print, print) # resolve is not executed
    Task.reject('Unexpected error').bind(lambda _: Task.of('Handle error')).fork(print, print) # reject is executed
    Task.of('value').bind(lambda _: Task.of('Handle error')).fork(print, print) # resolve is executed

if __name__ == '__main__':
    test_Task_bind();

# Generated at 2022-06-21 19:42:06.625129
# Unit test for method map of class Task
def test_Task_map():
    """
    During test we create new Task with stored function sum and call map method with function lambda x: x + 1
    for increment and return new Task.
    First we call fork method with stored function in new Task and success and fail methods.
    First success method will be called because stored function not return exception and passed in result of
    calling fork method.

    :returns: AssertionError with message if test failed
    :rtype: AssertionError
    """
    def test(resolve, reject):
        return resolve(1 + 2)

    actual = Task(test).map(lambda x: x + 1).fork(lambda x: 'fail', lambda x: x)
    expected = 4


# Generated at 2022-06-21 19:42:13.873530
# Unit test for method bind of class Task
def test_Task_bind():
    def callback(resolve, reject):
        return resolve('Test value')
    def mapper(value):
        return Task.of(value + ' - after map')

    task = Task.reject('Test')
    task2 = task.bind(mapper)
    assert task2.fork(lambda arg: arg + ' rejected', lambda arg: arg + ' rejected') == 'Test rejected'

    task = Task(callback)
    task2 = task.bind(mapper)
    assert task2.fork(lambda arg: arg + ' rejected', lambda arg: arg + ' resolved') == 'Test value - after map resolved'


# Generated at 2022-06-21 19:42:34.931019
# Unit test for method bind of class Task
def test_Task_bind():
    failure_case = Task.of(1).bind(lambda x: Task.reject(2 * x))
    assert failure_case.fork(lambda x: print('failure case: {}'.format(x)), lambda _: False) == 2

    success_case = Task.of(1).bind(lambda x: Task.of(2 * x))
    assert success_case.fork(lambda _: False, lambda x: print('success case: {}'.format(x))) == 2


# Generated at 2022-06-21 19:42:37.205115
# Unit test for method map of class Task
def test_Task_map():
    def square(value):
        return value * value

    result = Task.of(3).map(square)
    assert result.fork(None, lambda r: r) == 9



# Generated at 2022-06-21 19:42:39.012503
# Unit test for method map of class Task
def test_Task_map():
    @task.map
    def add1(arg):
        return arg + 1

    task = Task.of(1)

    assert run(add1) == 2


# Generated at 2022-06-21 19:42:49.571348
# Unit test for method bind of class Task
def test_Task_bind():
    def request():
        def send_request():
            def parse_response(response):
                def result(reject, resolve):
                    resolve(response)

                return Task(result)

            content_type = 'application/json'

            if 'application/json' in content_type:
                return Task.of(42)

            return Task.reject('Content type is: ' + content_type)

        def request_error_handler(error):
            def result(reject, resolve):
                reject(error)

            return Task(result)

        def request_ok_handler(response):
            def parse_response(response):
                def result(reject, resolve):
                    resolve(response)

                return Task(result)

            content_type = 'application/json'
            if 'application/json' in content_type:
                return Task

# Generated at 2022-06-21 19:42:56.590064
# Unit test for method map of class Task
def test_Task_map():
    called_fork = False

    def fork(reject, resolve):
        nonlocal called_fork
        called_fork = True
        resolve(1)

    task = Task(fork)

    def fn(value):
        return value + 1

    assert called_fork == False

# Generated at 2022-06-21 19:42:57.141748
# Unit test for constructor of class Task
def test_Task():
    assert Task is not None

# Generated at 2022-06-21 19:43:04.771006
# Unit test for method bind of class Task
def test_Task_bind():
    def f(value):
        print('[f] called: ' + str(value))
        return Task.reject(value + 'error')

    def g(value):
        print('[g] called: ' + str(value))
        return Task.of(value + 'handler')

    def h(value):
        print('[h] called: ' + str(value))
        return Task.of(value + 'handler')

    # t = Task.of('test').bind(f).bind(g).bind(h)
    # t.fork(
    #     lambda value: print('caught error: ' + str(value)),
    #     lambda value: print('value: ' + str(value))
    # )

    # Task.of('test\n').bind(f).bind(g).bind(h).fork(
   

# Generated at 2022-06-21 19:43:08.089269
# Unit test for method bind of class Task
def test_Task_bind():
    def test_func(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(test_func)
    assert task.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-21 19:43:17.427386
# Unit test for constructor of class Task
def test_Task():
    def plus_one(a):
        return a + 1

    def div(a, b):
        return a / b

    def minus_one(a):
        return  a - 1

    # resolve function
    assert Task(lambda _, resolve: resolve(1)).fork(None, lambda arg: arg) == 1

    # reject function
    assert Task(lambda reject, _: reject(2)).fork(lambda arg: arg, None) == 2

    # resolve function
    assert Task.of(3).fork(None, lambda arg: arg) == 3

    # reject function
    assert Task.reject(4).fork(lambda arg: arg, None) == 4

    # map function
    assert Task.of(1).map(plus_one).fork(None, lambda arg: arg) == 2

    # map function

# Generated at 2022-06-21 19:43:21.953067
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """
    def fork(reject, resolve):
        return resolve(3)

    def mapper(value):
        return value * 2

    result = Task(fork)
    result = result.map(mapper)

    assert result.fork(None, None) == 6


# Generated at 2022-06-21 19:43:41.013230
# Unit test for method map of class Task
def test_Task_map():
    # test_Task_map: (value) -> Task[value]
    def test_Task_map(x):
        return Task.of(x).map(lambda x: x * 2)


# Generated at 2022-06-21 19:43:51.879957
# Unit test for method map of class Task
def test_Task_map():

    # Test 0: test for checking work with simple types
    @Task.of(1)
    def method1(task):
        assert task == 1
        return task + 1

    @method1.map(lambda x: x + 1)
    def method2(task):
        assert task == 3
        return task * 2

    @method2.map(lambda x: x * 2)
    def method3(task):
        assert task == 6
        return task

    assert method3.fork(lambda _: False, lambda result: True) is True

    # Test 1: test for checking work with Task
    @Task.of(1)
    def method1(task):
        assert task == 1
        return Task.of(task + 1)


# Generated at 2022-06-21 19:43:54.649026
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(arg):
        return Task.reject(arg)

    task = Task.of('str')
    binded_task = task.bind(fn)

    assert binded_task.fork(lambda value: 'str', lambda value: 'str') == 'str'


# Generated at 2022-06-21 19:43:59.072943
# Unit test for constructor of class Task
def test_Task():
    assert Task.of("").fork(lambda x: True, lambda x: False) == False
    assert Task.reject("").fork(lambda x: True, lambda x: False) == True


# Generated at 2022-06-21 19:44:07.020623
# Unit test for method map of class Task
def test_Task_map():
    """
    Test of Task.map method
    """
    import unittest.mock as mock

    task = Task.of("a")
    task2 = task.map(lambda arg: arg + "b")

    with mock.patch('builtins.print') as patched:
        task2.fork(
            lambda arg: print("reject"),
            lambda arg: print("resolve")
        )

    patched.assert_called_with("resolve")


# Generated at 2022-06-21 19:44:08.573554
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(5).map(lambda arg: arg + 1)
    assert result.fork(lambda arg: arg, lambda arg: arg) == 6


# Generated at 2022-06-21 19:44:16.179009
# Unit test for method bind of class Task
def test_Task_bind():
    # Test error handling
    def error(arg):
        raise arg
    try:
        Task.of(error).map('mapper').bind(lambda value: value('error')).fork(
                lambda error: print(error.args[0]),
                lambda value: print(value)
            )
    except Exception as error:
        print(error)

    # Test without error
    Task.of(5).map(lambda arg: arg + 5).bind(lambda arg: Task.of(arg + 5)).fork(
        lambda arg: print(arg),
        lambda arg: print(arg)
    )
test_Task_bind()