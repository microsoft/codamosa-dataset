

# Generated at 2022-06-21 19:34:18.039886
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(6)
    assert Task(lambda _, resolve: resolve(2)).fork(None, lambda arg: arg) == 2


# Generated at 2022-06-21 19:34:20.523154
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1) == Task(lambda _, resolve: resolve(1))
    assert Task.reject(1) == Task(lambda reject, _: reject(1))


# Generated at 2022-06-21 19:34:21.499891
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: None).fork is not None


# Generated at 2022-06-21 19:34:23.163690
# Unit test for method map of class Task
def test_Task_map():
    def inc(i):
        return i + 1


# Generated at 2022-06-21 19:34:32.814590
# Unit test for method bind of class Task
def test_Task_bind():
    @g
    def on_rejected(x):
        return x

    @g
    def on_fulfilled(x):
        return x

    def test_1(x):
        return Task.of(x).bind(lambda a: Task.reject(a + 1)).fork(on_rejected, on_fulfilled)

    assert test_1(12) == 13

    def test_2(x):
        return Task.of(x).bind(lambda a: Task.of(a + 1)).fork(on_rejected, on_fulfilled)

    assert test_2(12) == 13



# Generated at 2022-06-21 19:34:37.568480
# Unit test for constructor of class Task
def test_Task():
    # Task with resolve function
    task1 = Task(lambda reject, resolve: resolve(1))
    assert task1.fork(lambda error: None, lambda result: result + 1) == 2
    # Task with reject function
    task2 = Task(lambda reject, resolve: reject('err'))
    assert task2.fork(lambda error: error, lambda result: None) == 'err'


# Generated at 2022-06-21 19:34:38.987536
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(10)
    assert task.map(lambda x: x+5).fork(None, lambda x: x) == 15


# Generated at 2022-06-21 19:34:44.003516
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(lambda x: x + 1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 3
    assert Task.of(1).map(lambda x: Task.of(x)).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-21 19:34:48.912689
# Unit test for constructor of class Task
def test_Task():
    task_a = Task.of(1)
    assert task_a.fork(Checkers.equal(None), Checkers.equal(1))
    task_b = Task.reject(1)
    assert task_b.fork(Checkers.equal(1), Checkers.equal(None))


# Generated at 2022-06-21 19:34:51.969366
# Unit test for method map of class Task
def test_Task_map():
    a = Task(lambda _, resolve: resolve(1))
    a = a.map(lambda x: 2 * x)
    assert a.fork(None, lambda x: x) == 2


# Generated at 2022-06-21 19:34:59.259106
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case(value):
        def result(resolve, reject):
            return resolve(value)
        return Task(result)

    def map_result(value):
        return test_case(value)

    task = Task.of(123)
    assert isinstance(task.bind(map_result), Task)
    assert task.bind(map_result).fork(lambda a: a, lambda a: a) == 123



# Generated at 2022-06-21 19:35:10.557504
# Unit test for method map of class Task
def test_Task_map():
    def run_task(x):
        print('run_task ' + str(x))
        return Task.of(x + 1)

    def run_task_map(x):
        print('run_task_map ' + str(x))
        return Task.of(x + 2)

    t = Task.of(1)
    assert isinstance(t, Task)
    assert t.fork(lambda x: x, lambda x: x) == 1

    assert isinstance(t, Task)
    t1 = t.map(lambda x: x + 1)
    assert isinstance(t1, Task)
    assert t1.fork(lambda x: x, lambda x: x) == 2

    assert isinstance(t1, Task)
    t2 = t1.map(lambda x: x + 1)

# Generated at 2022-06-21 19:35:15.236606
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method
    """
    assert Task.of(1).map(lambda x: x + 1).fork(lambda x: False, lambda x: x == 2)
    assert Task.of(1).map(lambda x: x + 1).map(lambda x: x + 1).fork(lambda x: False, lambda x: x == 3)


# Generated at 2022-06-21 19:35:17.956587
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)


# Generated at 2022-06-21 19:35:25.495899
# Unit test for method bind of class Task
def test_Task_bind():
    # Next test cover bind functionality of method bind
    def correct_bind_result(resolve, reject):
        resolve(1)
        return 2

    task = Task(correct_bind_result)

    def mapper(value):
        return value ** 2

    task = task.bind(mapper)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 1

    # Next test cover reject functionality of method bind
    def reject(resolve, reject):
        reject('error')
        return 2

    task = Task(reject)

    def mapper(value):
        raise Exception(value)

    task = task.bind(mapper)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 'error'

    # Next test cover fork functionality of method bind

# Generated at 2022-06-21 19:35:32.704033
# Unit test for method map of class Task
def test_Task_map():
    task1 = Task.of(lambda x: x + 1)
    task2 = task1.map(lambda x: x(1))

    def fork(reject, resolve):
        return resolve(task2.fork(reject, resolve))

    task3 = Task(fork)
    result = task3.fork(lambda x: x, lambda x: x)
    equal = result == 2
    assert equal



# Generated at 2022-06-21 19:35:43.930391
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map method.

    :returns: None
    """
    def not_mocked_task(fn):
        """
        Task mock with assert call of fn.
        :param fn: function to store and call after fork
        :type fn: Function()
        """
        fn()
        return Task(lambda _, resolve: resolve(1))

    def mocked_task(fn):
        """
        Task mock with assert call of fn.
        :param fn: function to store and call after fork
        :type fn: Function()
        """
        fn()
        return Task(lambda _, resolve: resolve(2))

    @patch('monad.Task', mocked_task)
    def test():
        """
        Function to test Task map.
        """

# Generated at 2022-06-21 19:35:50.633823
# Unit test for method bind of class Task
def test_Task_bind():
    import random, string

    random_word = lambda: ''.join(random.choice(string.ascii_letters) for _ in range(10))

    # Suppose to be a function that request http
    mock_http_request = lambda url: Task.of({
        "url": url,
        "status": random.choice([200, 302, 404, 500]),
        "data": random_word()
    })

    # Suppose to be a function that works with result of http request
    mock_request_with_result = lambda response: Task.of("Response: {response}".format(response=response))

    # Suppose to be a function that works with error of http request
    mock_request_with_error = lambda error: Task.reject("Error: {error}".format(error=error))

    # Compose all mock functions to mock Task


# Generated at 2022-06-21 19:35:55.695343
# Unit test for constructor of class Task
def test_Task():
    t1 = Task.reject(1)
    t2 = Task.of(2)

    assert t1.fork(lambda i: i + 1, lambda _: None) == 2
    assert t2.fork(lambda _: None, lambda i: i + 1) == 3


# Generated at 2022-06-21 19:35:57.910547
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)

    assert task.map(lambda value: value + 1).fork(lambda a: None, lambda a: a) == 2


# Generated at 2022-06-21 19:36:06.076145
# Unit test for constructor of class Task
def test_Task():
    try:
        Task(None)
    except TypeError:
        print('Incorrect initialization test passed')
    else:
        raise AssertionError('Incorrect initialization test failed')

# Unit test of Task.of

# Generated at 2022-06-21 19:36:11.820754
# Unit test for method bind of class Task
def test_Task_bind():
    def add_2(n):
        return n + 2
    def double(n):
        return n * 2

    def add_2_and_double(n):
        return Task.of(n).bind(lambda n: Task.of(n + 2)).bind(lambda n: Task.of(n * 2))

    assert Task.of(1).map(add_2).map(double).fork(lambda x: None, lambda x: x) == 6
    assert add_2_and_double(1).fork(lambda x: None, lambda x: x) == 6



# Generated at 2022-06-21 19:36:15.716684
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    assert (
        Task(lambda reject, resolve: resolve(1))
        .map(lambda x: add(x, 2))
        .fork(None, lambda x: x) == 3
    )



# Generated at 2022-06-21 19:36:17.908336
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject(1)

    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-21 19:36:22.649888
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method Task.map
    """
    def mult2(x):
        return x * 2

    def add1(x):
        return x + 1

    t = Task.of(3)
    t = t.map(mult2)
    t = t.map(add1)
    assert t.fork(lambda _: False, lambda x: x == 7)

# Generated at 2022-06-21 19:36:24.881441
# Unit test for method map of class Task
def test_Task_map():
    def fork(_, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.map(lambda x: x + 1).fork(lambda x: None, lambda x: x) == 2


# Generated at 2022-06-21 19:36:30.390231
# Unit test for constructor of class Task
def test_Task():
    """
    :param fn: function for testing fork constructor function
    :type fn: Function() -> Bool
    :returns: Result of test
    :rtype: Bool
    """
    def pass_test():
        return True

    return Task(pass_test).fork(
        lambda _: False,
        lambda _: True
    )


# Generated at 2022-06-21 19:36:36.095929
# Unit test for method bind of class Task
def test_Task_bind():
    def success(resolve, reject):
        resolve("success")

    def mapping(value):
        return Task.of("mapping " + value)

    assert isinstance(Task(success).bind(mapping), Task)
    assert Task(success).bind(mapping).fork(lambda arg: arg, lambda arg: arg) == "mapping success"



# Generated at 2022-06-21 19:36:40.462819
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(5))
    assert isinstance(Task(lambda _, resolve: resolve(5)), Task)
    assert Task(lambda _, resolve: resolve(5)).fork
    assert Task(lambda _, resolve: resolve(5)).fork(True, False) == False



# Generated at 2022-06-21 19:36:47.992578
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    new_task = task.map(lambda x: x + 1)

    assert new_task.fork(lambda x: None, lambda x: x) == 2


# Generated at 2022-06-21 19:37:07.073044
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task.
    """

    def is_Task(arg):
        """
        Check is arg is instance of Task.

        :param arg: value for checking
        :type arg: Any
        :returns: result of checking
        :rtype: bool
        """
        return isinstance(arg, Task)

    def fork(reject, resolve):
        """
        Testable fork function.

        :param reject: function for reject
        :type reject: Function
        :param resolve: function for resolve
        :type resolve: Function
        """
        resolve(1)

    task = Task(fork)
    assert is_Task(task)
    assert task.fork is fork

    task = Task.of(2)
    assert is_Task(task)
    assert isinstance(task.fork, FunctionType)

# Generated at 2022-06-21 19:37:18.174815
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    If result of calling fork function is rejected,
    function bind must return rejected Task with stored result of calling reject function from argument.
    Otherwise in case result of calling fork function is resolved,
    function bind must return Task, result of calling fork function
    which contains result of calling fork function of argument.
    """
    TestCase = namedtuple('TestCase', ['name', 'arg', 'expected_reject', 'expected_resolve'])

# Generated at 2022-06-21 19:37:19.128127
# Unit test for constructor of class Task
def test_Task():
    assert Task is not None


# Generated at 2022-06-21 19:37:21.746530
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test assertion for Task.bind
    """
    assert Task.of(4).bind(lambda x: Task.of(x + 1)) == Task.of(5)


# Generated at 2022-06-21 19:37:22.925378
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task.
    """
    pass


# Generated at 2022-06-21 19:37:33.081113
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Expected result
    {"status": "ok", "result": [{"sum": 9}, {"sum": 18}]}
    """
    # Create Task with resolve attribute
    task = Task.of(3)

    def add_1(value):
        """
        Function to add one to value.

        :param value: value to add one
        :type value: int
        :returns: value plus one
        :rtype: int
        """
        return value + 1

    # Call method map of Task with add_1 function
    task_mapped = task.map(add_1)

    def add_2(value):
        """
        Function to add two to value.

        :param value: value to add two
        :type value: int
        :returns: value plus two
        :rtype: int
        """

# Generated at 2022-06-21 19:37:43.493868
# Unit test for method bind of class Task
def test_Task_bind():
    print("*** begin Task::bind test ***")
    Task.of("success").bind(lambda x: Task.of("{}!".format(x))).fork(
        lambda x: print("error: {}".format(x)), lambda x: print("resolve: {}".format(x))
    )
    Task.of("success").bind(lambda x: Task.reject("{}!".format(x))).fork(
        lambda x: print("error: {}".format(x)), lambda x: print("resolve: {}".format(x))
    )
    Task.reject("error").bind(lambda x: Task.of("{}!".format(x))).fork(
        lambda x: print("error: {}".format(x)), lambda x: print("resolve: {}".format(x))
    )

# Generated at 2022-06-21 19:37:45.469295
# Unit test for constructor of class Task
def test_Task():
    """
    Create new Task with value attribute and call it.
    Test that it return value.
    """
    def fork(_, resolve):
        r

# Generated at 2022-06-21 19:37:50.104251
# Unit test for constructor of class Task
def test_Task():
    """
    test of Task that it's fork function can called with
    2 function as argument.
    """
    called = 0
    def resolve(value):
        nonlocal called
        called += 1

    def reject(value):
        nonlocal called
        called += 1

    test_task = Task(lambda resolve, reject: resolve(1))

    test_task.fork(reject, resolve)
    assert called == 1


# Generated at 2022-06-21 19:37:53.448099
# Unit test for constructor of class Task
def test_Task():
    fork_func = lambda a, b: a(b)

    task = Task(fork_func)
    assert task.fork is fork_func

# Generated at 2022-06-21 19:38:20.150478
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind.
    """
    task = Task.of(0).bind(lambda val: Task.of(val + 1))
    assert task.fork(lambda val: None, lambda val: val) == 1

    task = Task.of(0).bind(lambda val: Task.reject(val + 1))
    assert task.fork(lambda val: val, lambda val: None) == 1

    task = Task.reject(0).bind(lambda val: Task.reject(val + 1))
    assert task.fork(lambda val: val, lambda val: None) == 0



# Generated at 2022-06-21 19:38:26.636345
# Unit test for constructor of class Task
def test_Task():
    Task.of(5).fork(
        lambda arg: print('Reject: {}'.format(arg)),
        lambda arg: print('Resolve: {}'.format(arg))
    )

    task = Task(
        lambda reject, resolve: reject(6)
    )
    task.fork(
        lambda arg: print('Reject: {}'.format(arg)),
        lambda arg: print('Resolve: {}'.format(arg))
    )


# Generated at 2022-06-21 19:38:33.832884
# Unit test for method map of class Task
def test_Task_map():
    def test_task():
        return Task(lambda reject, resolve: resolve(True))

    assert test_task().map(lambda v: str(v)) == Task(lambda reject, resolve: resolve(str(True)))
    assert test_task().map(lambda v: v).map(lambda v: str(v)) == Task(lambda reject, resolve: resolve(str(True)))

    def test_reject_task():
        return Task(lambda reject, resolve: reject(True))

    assert test_reject_task().map(lambda v: str(v)) == Task(lambda reject, resolve: reject(True))
    assert test_reject_task().map(lambda v: v).map(lambda v: str(v)) == Task(lambda reject, resolve: reject(True))


# Generated at 2022-06-21 19:38:42.116702
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test suite for method bind of class Task.
    """

    # Create Task of string 'foo'
    foo = Task.of('foo')

    # Create Task of string 'bar'
    bar = Task.of('bar')

    # Create Task of string 'baz'
    baz = Task.of('baz')

    # Replace previous Task of strings with Task of function (resolve, reject) -> [resolve, reject, 'foo', 'bar', 'baz']
    test_foo_bar_baz = foo.bind(
        lambda v: bar.bind(
            lambda v2: baz.map(
                lambda v3: [resolve, reject, v, v2, v3]
            )
        )
    )

    # Call fork method of Task

# Generated at 2022-06-21 19:38:47.050077
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for constructor of class Task
    """
    task = Task.of(42)
    assert task.fork(None, lambda value: value) == 42

    task = Task.reject(42)
    assert task.fork(lambda value: value, None) == 42


# Generated at 2022-06-21 19:38:50.144511
# Unit test for method map of class Task
def test_Task_map():
    def func(a):
        return a + 1

    assert Task.of(1).map(func).fork(
        lambda e: e,
        lambda a: a
    ) == 2


# Generated at 2022-06-21 19:38:53.092039
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(3)).fork(None, lambda arg: arg + 3) == 6
    assert Task(lambda reject, _: reject("error")).fork(lambda arg: arg + "!", None) == "error!"


# Generated at 2022-06-21 19:38:59.411053
# Unit test for method map of class Task
def test_Task_map():
    def inner_resolve_1(value):
        return value + 1

    def inner_resolve_2(value):
        return value + 1

    def inner_error(value):
        return value + 1

    test_data = [
        Task.of(1).map(inner_resolve_1),
        Task.reject(1).map(inner_error),
        Task.of(2).map(inner_resolve_1).map(inner_resolve_2)
    ]

    valid_result = [
        Task(lambda _, resolve: resolve(inner_resolve_1(1))),
        Task(lambda reject, _: reject(1)),
        Task(lambda _, resolve: resolve(inner_resolve_2(inner_resolve_1(2))))
    ]


# Generated at 2022-06-21 19:39:11.404618
# Unit test for method map of class Task
def test_Task_map():

    # add + 1
    res = Task.of(7).map(lambda x: x + 1).fork(lambda _: print("rejected"), lambda x: print("resolved: " + str(x)))
    assert(res == "resolved: 8")

    # add + 1
    res = Task.reject(7).map(lambda x: x + 1).fork(lambda _: print("rejected"), lambda x: print("resolved: " + str(x)))
    assert(res == "rejected")

    # multiply by 2
    res = Task.of(7).map(lambda x: x * 2).fork(lambda _: print("rejected"), lambda x: print("resolved: " + str(x)))
    assert(res == "resolved: 14")

    # reject task with + 1

# Generated at 2022-06-21 19:39:20.542890
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        if (resolve == 'error'):
            return reject(resolve)
        return resolve(resolve)

    # Test for positive call bind of Task
    # Task(fork).bind(lambda value: Task.of(value)).fork('error', 'resolve') -> Task.of(value)
    Task(fork).bind(lambda value: Task.of(value)).fork('error', 'resolve')
    # Test for negative call bind of Task
    # Task.reject('error').bind(lambda value: Task.of(value)).fork(error, resolve) -> Task.reject(error)
    Task.reject('error').bind(lambda value: Task.of(value)).fork('error', 'resolve')


# Generated at 2022-06-21 19:40:06.163573
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task
    """
    def resolve(value):
        assert value == 'ok'

    def reject(value):
        assert value == 'err'

    task = Task(lambda reject, resolve: resolve('ok'))
    task.fork(reject, resolve)

    task = Task(lambda reject, resolve: reject('err'))
    task.fork(reject, resolve)



# Generated at 2022-06-21 19:40:10.907732
# Unit test for method map of class Task
def test_Task_map():
    def resolve_decorator(fn):
        def result(*args):
            return Task.of(fn(*args))
        return result

    def reject_decorator(fn):
        def result(*args):
            return Task.reject(fn(*args))
        return result

    # Test map return resolved Task with mapped value
    @resolve_decorator
    def add(a, b):
        return a + b

    assert add(1, 2).map(lambda v: v * 2).fork(lambda v: v, lambda v: v) == 6

    # Test map will return rejected Task if replaceable Task returned by map rejected
    @reject_decorator
    def return_rejected(_):
        return 'ERROR'


# Generated at 2022-06-21 19:40:14.799972
# Unit test for constructor of class Task
def test_Task():
    """
    Check that we can create new Task with functions.
    """
    def fork(reject, resolve):
        return reject('error')

    task = Task(fork)

    assert task.fork is fork


# Generated at 2022-06-21 19:40:20.380301
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    task2 = task.bind(lambda x: Task.of(x + 1))
    assert task2.fork(lambda x: x, lambda x: x) == 2

    task = Task.of(1)
    task2 = task.bind(lambda x: Task.reject(x + 1))
    assert task2.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-21 19:40:24.563603
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)

    def bind_fn(x):
        return Task.of(x + 20)

    def map_fn(x):
        return x * 10

    assert task.bind(bind_fn).map(map_fn).fork(lambda _: None, lambda result: result == 30)


# Generated at 2022-06-21 19:40:27.262696
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return "fork"

    task = Task(fork)
    assert task.fork(0, 1) == "fork"



# Generated at 2022-06-21 19:40:29.114991
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('foo')

    task = Task(fork)
    assert task.fork is fork


# Generated at 2022-06-21 19:40:34.071212
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def reject():
        return 'reject'

    def resolve():
        return 'resolve'

    def fn(x):
        return Task.reject(resolve()) if x == 1 else Task.of(add(x))

    t1 = fn(1)
    t2 = fn(2)

    assert t1.map(add).fork(reject, resolve) == 'resolve'
    assert t2.fork(reject, resolve) == 3


# Generated at 2022-06-21 19:40:36.954759
# Unit test for method bind of class Task
def test_Task_bind():
    def add(num):
        return Task.of(num + 1)

    assert Task.of(2).bind(add).fork(lambda x: x, lambda x: x) == 3



# Generated at 2022-06-21 19:40:49.476476
# Unit test for method bind of class Task
def test_Task_bind():

    def compose(a, b):
        return lambda x: b(a(x))

    def add(x):
        return x + 1

    def multiply(x):
        return x * 2

    def square(x):
        return x ** 2

    def square_root(x):
        return x ** 0.5

    def assert_task_equal(task, value):
        assert task.fork(lambda x: 0, lambda x: x) == value

    assert_task_equal(Task.of(0).bind(lambda x: Task.of(add(x))), 1)
    assert_task_equal(Task.of(0).bind(lambda x: Task.reject(add(x))), 1)

# Generated at 2022-06-21 19:42:28.630475
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject(2)
        resolve(3)
        resolve(5)

    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-21 19:42:30.000136
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(0).fork(lambda _: None, lambda x: x) == 0
    assert Task.reject(0).fork(lambda x: x, lambda _: None) == 0



# Generated at 2022-06-21 19:42:37.527522
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Example of usage Task.bind method.
    Result of calculation is stored in Task.
    After binding with Task.bind, calling fork method and pass
    callbacks functions, that handle reject and resolve.
    """

    def calc_square(value):
        return Task.of(value ** 2)

    def on_reject(error):
        print("Rejected with error: ", error)
        return

    def on_resolve(result):
        print("Resolved with result: ", result)
        return

    task = Task.of(1)
    task = task.bind(calc_square)
    task = task.bind(calc_square)
    task.fork(on_reject, on_resolve)

# Generated at 2022-06-21 19:42:39.799093
# Unit test for constructor of class Task
def test_Task():
    def fork(_, resolve):
        return resolve(1)

    t = Task(fork)
    assert t.fork(0, lambda x:x) == 1


# Generated at 2022-06-21 19:42:44.792638
# Unit test for method map of class Task
def test_Task_map():
    double = lambda x: x*2
    double_after_triple = lambda x: double(x) / 3
    task = Task.of(3)
    result_task = task.map(double).map(double_after_triple)
    result = result_task.fork(
        lambda x: None,
        lambda x: x
    )

    assert result == 4



# Generated at 2022-06-21 19:42:49.661193
# Unit test for method map of class Task
def test_Task_map():
    def test(reject, resolve):
        resolve(1)

    task = Task(test)
    result = task.map(lambda arg: arg * 2)

    if result.fork(lambda arg: arg, lambda arg: arg) != 2:
        raise AssertionError("Invalid resolve value")


# Generated at 2022-06-21 19:42:56.925020
# Unit test for method map of class Task
def test_Task_map():
    def fun(resolve, reject):
        return resolve(3)

    def add(a):
        return a + 1

    def addLazy(a):
        return Task.of(a + 1)

    task = Task(fun).map(add)
    assert task.fork(lambda x: x, None) == 4

    task = Task(fun).bind(addLazy)
    assert task.fork(lambda x: x, None) == 4



# Generated at 2022-06-21 19:43:02.423315
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    def test_func(value):
        assert value == 2 + 2
        return value * 2

    task = Task.of(2 + 2).map(test_func)

    result = task.fork(lambda err: err, lambda val: val)
    assert result == 2 * 2 * 2

    task = Task.reject(2 + 2).map(test_func)

    result = task.fork(lambda err: err, lambda val: val)
    assert result == 2 + 2



# Generated at 2022-06-21 19:43:05.257838
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(3).fork(
        lambda _: False,
        lambda arg: arg == 3
    )

    assert Task.reject(3).fork(
        lambda arg: arg == 3,
        lambda _: False
    )


# Generated at 2022-06-21 19:43:08.489396
# Unit test for method bind of class Task
def test_Task_bind():
    fork = lambda reject, resolve: resolve(1)
    task = Task(fork)
    task.bind(lambda value: Task.of(value)).fork(lambda reject: print(reject), lambda value: print(value))

test_Task_bind()