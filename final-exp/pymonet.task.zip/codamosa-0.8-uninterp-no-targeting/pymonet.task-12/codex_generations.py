

# Generated at 2022-06-21 19:34:18.041169
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve():
        return Task.of('start')

    def reject():
        return Task.reject('error')

    def mapped_reject(value):
        return Task.of(value + ' mapped')

    def mapped_resolve(value):
        return Task.of(value + ' mapped')

    assert Task.of('start').bind(mapped_resolve).fork(reject, resolve) == 'start mapped'
    assert Task.reject('start').bind(mapped_reject).fork(reject, resolve) == 'start mapped'

# Generated at 2022-06-21 19:34:22.047360
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(arg):
        if arg == 1:
            return Task.of("Ok")
        else:
            return Task.reject("Error")

    task = Task.bind(Task.of(1), fn)
    assert task.fork(_, lambda arg: arg) == "Ok"

    task = Task.bind(Task.of(2), fn)
    assert task.fork(lambda arg: arg, _) == "Error"


# Generated at 2022-06-21 19:34:28.568983
# Unit test for constructor of class Task
def test_Task():
    """
    Test creating new Task with value and checking it with of method.
    """
    value = 1

    task = Task(lambda _, resolve: resolve(value))
    same_task = Task.of(value)

    assert task.fork(lambda arg: arg, lambda arg: arg) == same_task.fork(lambda arg: arg, lambda arg: arg)


# Generated at 2022-06-21 19:34:32.775857
# Unit test for constructor of class Task
def test_Task():
    def fork_reject(reject, _):
        reject("value")

    def fork_resolve(_, resolve):
        resolve("value")

    task_reject = Task(fork_reject)
    task_resolve = Task(fork_resolve)

    assert task_reject.fork(lambda value: value, lambda value: value) == "value"
    assert task_resolve.fork(lambda value: value, lambda value: value) == "value"


# Generated at 2022-06-21 19:34:35.142354
# Unit test for constructor of class Task
def test_Task():
    def task():
        return Task(lambda _, resolve: resolve(10))

    assert isinstance(task(), Task)



# Generated at 2022-06-21 19:34:40.722218
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(0)).fork(
        lambda arg: 1,
        lambda arg: 2
    ) == 2
    assert Task(lambda reject, _: reject(0)).fork(
        lambda arg: 1,
        lambda arg: 2
    ) == 1


# Generated at 2022-06-21 19:34:44.239792
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(
        lambda arg: Task.reject(arg + 1)
    ).fork(
        lambda value: value,
        lambda value: -1
    ) == 2

    assert Task.reject(1).bind(
        lambda arg: Task.of(arg + 1)
    ).fork(
        lambda value: value,
        lambda value: -1
    ) == 1


# Generated at 2022-06-21 19:34:48.177148
# Unit test for method map of class Task
def test_Task_map():
    value = 1
    plus_one = Task.of(1).map(lambda a: a + value)
    assert plus_one.fork(lambda a: a, lambda a: a) == 2, 'plus one is wrong'


# Generated at 2022-06-21 19:34:53.858889
# Unit test for constructor of class Task
def test_Task():
    # Common case
    def function(reject, resolve):
        return 10
    task = Task(function)

    assert task.fork(lambda x: None, lambda x: None) is 10



# Generated at 2022-06-21 19:34:59.453166
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: resolve(1)).fork(
        lambda arg: None,
        lambda arg: 'test'
    ) == 'test'

    assert Task(lambda reject, resolve: reject(1)).fork(
        lambda arg: 'test',
        lambda arg: None
    ) == 'test'


# Generated at 2022-06-21 19:35:06.617967
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(100)

    task = Task(fork)
    mapped_task = task.map(mapper)
    assert mapped_task.fork(_, resolve) == 101

# Generated at 2022-06-21 19:35:08.505030
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(_, identity) == 1
    assert Task(lambda reject, _: reject(1)).fork(identity, _) == 1


# Generated at 2022-06-21 19:35:17.703767
# Unit test for method bind of class Task
def test_Task_bind():
    def f1(x):
        return Task.of(x + 1)

    def f2(x):
        return Task.reject(x + 1)

    def f3(x):
        return Task.of(x + 1)

    task1 = Task.of(1).bind(f1).bind(f1).bind(f1)
    assert(task1.fork(lambda x: False, lambda x: x == 4))

    task2 = Task.of(1).bind(f1).bind(f2)
    assert(task2.fork(lambda x: x == 2, lambda x: False))

    task3 = Task.of(1).bind(f1).bind(f1).bind(f1).bind(f1).bind(f1).bind(f1)

# Generated at 2022-06-21 19:35:22.234966
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(
        lambda arg: 'rejected',
        lambda arg: 'resolved' + str(arg)
    ) == 'resolved1'

    assert Task.reject(1).fork(
        lambda arg: 'rejected' + str(arg),
        lambda arg: 'resolved'
    ) == 'rejected1'


# Generated at 2022-06-21 19:35:27.748460
# Unit test for constructor of class Task
def test_Task():
    assert (type(Task(lambda _, resolve: resolve(1))) is Task)
    assert (Task(lambda _, resolve: resolve(1)).fork(lambda _, resolve: resolve(1), lambda _, resolve: resolve(1))) == 1


# Generated at 2022-06-21 19:35:30.579904
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve('foo'))

    assert task.fork(fail, lambda value: True) is True


# Generated at 2022-06-21 19:35:33.634252
# Unit test for method map of class Task
def test_Task_map():
    """
    Implement Task as class (see Task above).

    Implement unit-test for method map of class Task,
    that check Task.map works as expected (see Task.map above).
    """
    pass


# Generated at 2022-06-21 19:35:44.170166
# Unit test for method map of class Task
def test_Task_map():
    def spy(fn, *args):
        fn(*args)
        return args

    def test_one_argument(resolve, reject):
        resolve('A')

    def test_two_arguments(reject, resolve):
        reject('A')

    def test_three_arguments(resolve, reject):
        reject('B')
        resolve('A')

    def test_four_arguments(reject):
        reject('A')
        resolve('B')  # not called

    def test_five_arguments(resolve, reject):
        resolve('B')
        reject('A')

    def test_six_arguments(reject):
        resolve('A')  # not called
        reject('B')

    def test_seven_arguments(resolve, reject):
        return


# Generated at 2022-06-21 19:35:47.314371
# Unit test for method bind of class Task
def test_Task_bind():
    task_chain = Task.of(1).bind(
        lambda arg: Task.of(arg + 1).bind(
            lambda arg: Task.of(arg + 1)
        )
    )

    assert task_chain.fork(lambda _: _, lambda _: _) == 3

# Generated at 2022-06-21 19:35:54.291327
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method map of Task class.

    :returns: True if all test passed else False
    :rtype: Boolean
    """
    def add(arg):
        return arg + 1

    task = Task.of(42).map(add)
    result = task.fork(lambda arg: arg, lambda _: _)
    return result == 43


# Generated at 2022-06-21 19:36:04.107275
# Unit test for constructor of class Task
def test_Task():
    called = 0
    is_rejected = False

    def fork(reject, resolve):
        nonlocal called
        nonlocal is_rejected
        called += 1

        if not is_rejected:
            return resolve(1)
        else:
            return reject(1)

    task = Task(fork)
    assert task.fork(lambda x: 0, lambda x: 1) == 1
    assert called == 1

    is_rejected = True
    assert task.fork(lambda x: 0, lambda x: 1) == 0
    assert called == 2


# Generated at 2022-06-21 19:36:09.757184
# Unit test for method map of class Task
def test_Task_map():
    # Test function
    def fn(value):
        return value * 2

    # Test for constructor method of class Task
    task = Task(lambda reject, resolve: resolve(1))
    assert task.fork(lambda n: n*2, lambda n: n*3) == 3

    # Test for method map of class Task
    task_mapped = task.map(fn)
    assert task_mapped.fork(lambda n: n, lambda n: n) == 2


# Generated at 2022-06-21 19:36:13.337657
# Unit test for constructor of class Task
def test_Task():
    """
    test of constructor of class Task
    """
    assert Task(lambda reject, resolve: resolve(None)) is not None
    assert Task(lambda reject, resolve: reject(None)) is not None


# Generated at 2022-06-21 19:36:14.390939
# Unit test for constructor of class Task
def test_Task():
    pass


# Generated at 2022-06-21 19:36:24.013362
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Check bind method of class Task.
    """
    def assert_task_result(task, expected):
        class UnitError(Exception):
            """ Error to handle unit test errors."""

        def handle_error(msg):
            raise UnitError(msg)

        task.fork(handle_error, lambda result: assert_equals(expected, result))

    assert_task_result(
        Task.of(1).bind(lambda value: Task.reject(value + 1)),
        2
    )

    assert_task_result(
        Task.reject('error').bind(lambda value: Task.reject(value)),
        'error'
    )

    assert_task_result(
        Task.reject('error').bind(lambda value: Task.of(value)),
        'error'
    )

    assert_task

# Generated at 2022-06-21 19:36:29.615870
# Unit test for method bind of class Task
def test_Task_bind():
    def test_bind_task():
        def fork(reject, resolve):
            resolve(1)

        task = Task(fork)

        def mapper(value):
            return Task.of(value * 2)

        result = task.bind(mapper)
        assert result.fork(lambda value: None, lambda value: print(value)) == 2

    test_bind_task()

# Generated at 2022-06-21 19:36:34.836610
# Unit test for method bind of class Task
def test_Task_bind():
    result = []

    def reject(*args): pass

    def resolve(arg):
        result.append(arg)

    task = Task.of(1)
    task = task.bind(lambda value: Task.of(value + 2))
    task.fork(reject, resolve)

    assert result == [3]

# Generated at 2022-06-21 19:36:40.202246
# Unit test for method map of class Task
def test_Task_map():
    def run(reject, resolve):
        resolve(True)

    def error(reject, resolve):
        reject('error')

    assert Task(run).map(lambda value: value * 2).fork(reject, resolve) == resolve(True)
    assert Task(error).map(lambda value: value * 2).fork(reject, resolve) == reject('error')


# Generated at 2022-06-21 19:36:42.652207
# Unit test for constructor of class Task
def test_Task():
    # Given
    test_func = lambda resolve: resolve("Test")

    # When
    task = Task(test_func)

    # Then
    assert callable(task.fork)


# Generated at 2022-06-21 19:36:53.324583
# Unit test for method bind of class Task
def test_Task_bind():

    # Function returns Task by mapping value:
    #   1 -> Task.of(1 -> 2)
    #   other -> Task.reject(other)
    def fn(value):
        if value == 1:
            return Task.of(value + 1)
        else:
            return Task.reject(value)

    t = Task.of(1)
    assert t.bind(fn).fork(lambda _: None, lambda arg: arg) == 2

    t = Task.of(2)
    assert t.bind(fn).fork(lambda arg: arg, lambda _: None) == 2

    t = Task.reject(1)
    assert t.bind(fn).fork(lambda arg: arg, lambda _: None) == 1


# Generated at 2022-06-21 19:37:05.430961
# Unit test for constructor of class Task
def test_Task():
    assert_equal(Task.of('value').fork(lambda x: None, lambda x: x), 'value')
    assert_equal(
        Task(lambda _, resolve: resolve('value')).fork(
            lambda x: None, lambda x: x
        ),
        'value'
    )

    assert_equal(Task.reject('value').fork(lambda x: x, lambda x: None), 'value')
    assert_equal(
        Task(lambda reject, _: reject('value')).fork(
            lambda x: x, lambda x: None
        ),
        'value'
    )



# Generated at 2022-06-21 19:37:09.251798
# Unit test for constructor of class Task
def test_Task():
    value = 'my value'
    assert Task(lambda _, resolve: resolve(value)).fork(raise_error, lambda arg: arg) == value


# Generated at 2022-06-21 19:37:12.153229
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task map method
    """
    def fn1(value):
        return value + "2"

    def fn2(value):
        return Task.of(value + "3")

    assert Task.of("1").map(fn1).fork(lambda _: 0, lambda value: value) == "12"
    assert Task.of("1").bind(fn2).fork(lambda _: 0, lambda value: value) == "13"


# Generated at 2022-06-21 19:37:21.646098
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(10)

    task = Task(fork)
    assert isinstance(task, Task)
    assert task.fork(lambda x: x, lambda x: x) == 10

    def fork2(reject, resolve):
        resolve(task)

    task2 = Task(fork2)
    assert isinstance(task2, Task)
    assert task2.fork(lambda x: x, lambda x: x).fork(lambda x: x, lambda x: x) == 10

    def fork3(reject, resolve):
        resolve(task2)

    task3 = Task(fork3)
    assert isinstance(task3, Task)

# Generated at 2022-06-21 19:37:26.955942
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return 2 + x

    def mul(y):
        return y * 3

    assert Task(lambda _, resolve: resolve(1)).map(add).fork(lambda _: None, lambda result: result)(None) == 3
    assert Task(lambda _, resolve: resolve(2)).map(mul).map(add).fork(lambda _: None, lambda result: result)(None) == 9


# Generated at 2022-06-21 19:37:33.386530
# Unit test for constructor of class Task
def test_Task():
    ok_ = 'ok'
    error_ = 'error'

    def error_handler(value):
        assert value == ok_

    def success_handler(value):
        assert value == error_

    task = Task(lambda reject, resolve: reject(ok_))
    task.fork(error_handler, success_handler)

    task = Task(lambda reject, resolve: resolve(error_))
    task.fork(error_handler, success_handler)


# Generated at 2022-06-21 19:37:40.404391
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        print('resolve value: {}'.format(value))

    def fork(reject, resolve):
        resolve(3)

    task = Task(fork)
    task.map(lambda x: x * x).fork(lambda _: None, resolve)

    assert Task.of(2).map(lambda x: x * x).fork(lambda _: None, resolve) == 4

    Task.reject(3).map(lambda x: x * x).fork(lambda _: None, resolve)


# Generated at 2022-06-21 19:37:46.541862
# Unit test for method map of class Task
def test_Task_map():
    input_value = 5
    transform_fn = lambda x: x + 1
    expected_result = 6

    def fork(reject, resolve):
        return resolve(input_value)

    task = Task(fork)
    task = task.map(transform_fn)

    def on_error(_):
        raise Exception("Reject shouldn't be called!")

    def on_success(result):
        assert result == expected_result

    return task.fork(on_error, on_success)


# Generated at 2022-06-21 19:37:48.994428
# Unit test for constructor of class Task
def test_Task():
    # Test of constructor
    def task_init(reject, resolve):
        return resolve(1)

    task_init = Task(task_init)
    assert isinstance(task_init, Task)


# Generated at 2022-06-21 19:37:59.831317
# Unit test for method bind of class Task
def test_Task_bind():
    t1 = Task.of(2)
    t2 = Task.of(3)
    t3 = Task.of(5)
    # t1 will be rejected,
    # t3 is passed to resolve,
    # t2 is passed to reject
    t = t1.bind(lambda x: t2.map(lambda y: x + y)).bind(lambda x: t3.map(lambda y: x + y)).bind(
        lambda x: Task.reject(x)
    )
    r = t.fork(lambda x: x, lambda x: 0)
    assert r == 5, "test_Task_bind"

test_Task_bind()


# Generated at 2022-06-21 19:38:16.684233
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1).bind(lambda x: Task.of('a' if x == 1 else 'b'))
    assert task.fork(lambda x: None, lambda x: x) == 'a'

    def bind_to_reject(x):
        return Task.reject('a' if x == 1 else 'b')
    task = Task.of(1).bind(bind_to_reject)
    assert task.fork(lambda x: x, lambda x: None) == 'a'


# Generated at 2022-06-21 19:38:23.449025
# Unit test for method map of class Task
def test_Task_map():
    def get_value(reject, resolve):
        resolve(10)

    # Task with type(result) == Task[int]
    task = Task(get_value).map(lambda arg: arg * 2)

    # Task[int] -> int
    assert task.fork(None, lambda arg: arg) == 20
    # Task with type(result) == int
    assert isinstance(task.fork(None, lambda arg: arg), int)


# Generated at 2022-06-21 19:38:28.645385
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.
    Return True if map function work and False if not.

    :returns: result of the tests
    :rtype: Bool
    """
    def inc(x): return x + 1
    assert Task.of(4).map(inc).fork(
        lambda e: e,
        lambda a: a
    ) == 5

    return True


# Generated at 2022-06-21 19:38:33.610644
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of Task class.

    Tested: creation of Task with function, that returns value.
    """
    t = Task(lambda reject, resolve: resolve(10))
    assert(t.fork(lambda reject, resolve: resolve(10)) == 10)


# Generated at 2022-06-21 19:38:39.859814
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method Task.map.
    """
    def add(arg):
        return arg + 1

    def add_to_number(number):
        return Task.of(number).map(add)

    task = Task.of(5)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 5
    assert add_to_number(5).fork(lambda arg: arg, lambda arg: arg) == 6


# Generated at 2022-06-21 19:38:45.140518
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)

    def fn(value):
        assert value == 1, 'Task.bind(fn) fn(value) -> value'
        return Task.of(2)

    assert task.bind(fn) == Task.of(2), 'Task.bind(fn) -> Task(fn(value))'


# Generated at 2022-06-21 19:38:50.247619
# Unit test for method map of class Task
def test_Task_map():
    def task() -> Task[int]:
        return Task.of(42)

    def mapper_function(value: int) -> int:
        return value + 5

    assert task() \
        .map(mapper_function) \
        .map(str) \
        .fork(lambda _: None, lambda x: x) == "47"


# Generated at 2022-06-21 19:38:57.562561
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_one(reject, resolve):
        resolve(1)

    def reject_one(reject, resolve):
        reject(1)

    def resolve_two(reject, resolve):
        resolve(2)

    assert Task(resolve_one).bind(lambda x: Task.of(x + 1)) == Task(resolve_two)
    assert Task(resolve_one).bind(lambda x: Task.reject(x + 1)) == Task.reject(2)
    assert Task(reject_one).bind(lambda x: Task.of(x + 1)) == Task.reject(1)
    assert Task(reject_one).bind(lambda x: Task.reject(x + 1)) == Task.reject(1)

# Generated at 2022-06-21 19:39:04.261408
# Unit test for method bind of class Task
def test_Task_bind():
    assert equal(Task.of(7).bind(lambda x: Task.of(x + 2)), Task.of(9))
    assert equal(Task.of(7).bind(lambda x: Task.of(x + 2)).bind(lambda x: Task.of(x ** 4)), Task.of(6561))
    assert equal(Task.of(7).bind(lambda x: Task.of(x * 2)), Task.of(14))

# Generated at 2022-06-21 19:39:08.340281
# Unit test for constructor of class Task
def test_Task():
    subject = Task(lambda _, resolve: resolve(1))
    
    assert subject.fork is not None
    assert subject.fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-21 19:39:36.541386
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map with not async call.
    """
    def test_reject_with_foo(reject, _):
        """
        Reject function with value foo.

        :param reject: function to call
        :type reject: Function(A)
        """
        return reject('foo')

    task_with_reject = Task(test_reject_with_foo)

    def test_resolve_with_foo(reject, resolve):
        """
        Resolve function with value foo.

        :param resolve: function to call
        :type resolve: Function(A)
        """
        return resolve('foo')

    task_with_resolve = Task(test_resolve_with_foo)


# Generated at 2022-06-21 19:39:43.400768
# Unit test for method map of class Task
def test_Task_map():
    def function(resolve, reject):
        if random.randint(0, 1) == 0:
            reject(random.randint(0, 10))
        else:
            resolve(random.randint(0, 10))

    for _ in range(100):
        random_fork = Task(function)

# Generated at 2022-06-21 19:39:47.692485
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: resolve(0)).fork(
        lambda arg: "bad",
        lambda arg: "good"
    ) == "good"



# Generated at 2022-06-21 19:39:48.959117
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task(lambda _, __: None), Task)


# Generated at 2022-06-21 19:39:53.394962
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return Task.reject(x + 1)

    task = Task.of(1)

    result = task.map(fn).fork(
        lambda reject: reject,
        lambda resolve: resolve
    )

    assert result == 2



# Generated at 2022-06-21 19:39:55.235807
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(1))
    assert isinstance(task.fork, types.FunctionType)


# Generated at 2022-06-21 19:39:59.188400
# Unit test for method bind of class Task
def test_Task_bind():
    """Expect Task.bind return Task with fork function as result of calling Task.fork."""
    assert Task.of('x').bind(lambda y: Task.of(lambda x: x + y)).fork(lambda x: x, lambda x: x)('y') == 'yx'


# Generated at 2022-06-21 19:40:07.535094
# Unit test for method bind of class Task
def test_Task_bind():
    # Test simple bind that return resolved Task
    def test_simple_bind():
        def func1(value):
            return Task.of(value + 1)

        assert Task.of(1).bind(func1).fork(
            lambda value: False,
            lambda value: value == 2
        )

    # Test simple bind that return rejected Task
    def test_simple_reject_bind():
        def func1(value):
            return Task.reject(value + 1)

        assert Task.of(1).bind(func1).fork(
            lambda value: value == 2,
            lambda value: False
        )

    test_simple_bind()
    test_simple_reject_bind()


# Generated at 2022-06-21 19:40:12.107265
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(10)

    result = Task(fork)
    assert result
    assert result.fork


# Generated at 2022-06-21 19:40:15.501024
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """
    assert Task.of(2).map(lambda x: x * 2).fork(lambda x: None, lambda x: x) == 4


# Generated at 2022-06-21 19:41:00.875402
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    task = task.bind(lambda value: Task.of(value + 2))
    task = task.bind(lambda value: Task.of(value * 2))

# Generated at 2022-06-21 19:41:09.090168
# Unit test for method bind of class Task
def test_Task_bind():

    # !!! There is some workaround for handling of async function in pytest !!!

    @gen.coroutine
    def plus_one(x):
        return x + 1

    @gen.coroutine
    def multiply_by_two(x):
        return x * 2

    @gen.coroutine
    def create_task():
        reject, resolve = yield Task.of(2) # Task[Function(_, resolve) -> 2]
        return (yield Task.of(reject)), (yield Task.of(resolve)) # Task[Function(resolve, resolve) -> Tuple(resolve, resolve)]

    @gen.coroutine
    def create_task_with_incorrect_type():
        reject, resolve = yield Task.reject(2) # Task[Function(reject, _) -> 2]

# Generated at 2022-06-21 19:41:14.936733
# Unit test for method map of class Task
def test_Task_map():
    # Python function, which return we will store in Task
    def add_one(value):
        return value + 1
    # Python function, which return we will store in Task
    def error(value):
        return 'error'

    # Task with resolve value. Call map and bind with add_one.
    task = Task.of(1) \
        .map(add_one) \
        .bind(lambda value: Task.of(value + 2))

    # Check that in map function was called.
    # Check that in bind function was called.
    # Check that value in task is correct.
    assert task.fork(error, lambda value: value + 1) == 5

    # Python function, which return we will store in Task
    def add_one(value):
        return value + 1

    def error(value):
        return 'error'

# Generated at 2022-06-21 19:41:19.883806
# Unit test for method map of class Task
def test_Task_map():
    """
    If call Task.map method with identity function,
    then should return new Task with resolve attribute equal to passed.
    """
    task = Task.of(42)
    def identity(x): return x
    assert task.map(identity).fork(lambda x: x, lambda x: x) == 42


# Generated at 2022-06-21 19:41:21.867407
# Unit test for constructor of class Task
def test_Task():
    f = lambda _, resolve: resolve(10)
    task = Task(f)
    assert task.fork is f


# Generated at 2022-06-21 19:41:24.756763
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda arg: arg, lambda arg: arg) == 1



# Generated at 2022-06-21 19:41:27.408866
# Unit test for constructor of class Task
def test_Task():
    """
    Task constructor save fork function in attribute fork.
    """
    def fork(reject, resolve):
        pass

    task = Task(fork)
    assert task.fork == fork, 'Task save fork function in his attribute'


# Generated at 2022-06-21 19:41:30.204279
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve('data')

    task = Task(fork)

    assert task.fork('reject', 'resolve') == 'resolve'


# Generated at 2022-06-21 19:41:37.816949
# Unit test for method bind of class Task
def test_Task_bind():
    def task_reject(reject, resolve):
        return reject(1)

    def task_resolve(reject, resolve):
        return resolve(1)

    def mapper(arg):
        return Task.reject(arg)

    task_reject_object = Task(task_reject)
    task_resolve_object = Task(task_resolve)

    assert task_reject_object.bind(mapper).fork(lambda reject: reject) == 1
    assert task_resolve_object.bind(mapper).fork(lambda reject: reject) == 1


# Generated at 2022-06-21 19:41:42.537200
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        assert value == 'mapped'
        print("Resolve method was called")

    def reject(value):
        assert False

    def test_fork(reject, resolve):
        resolve('Test')

    task = Task(test_fork)

    def test_bind(val):
        print(val)
        return Task.of('mapped')

    task.bind(test_bind).fork(reject, resolve)


# Generated at 2022-06-21 19:43:25.459601
# Unit test for constructor of class Task
def test_Task():
    if (Task(lambda x, y: None) is not None):
        print('Task constructor is incorrect')


# Generated at 2022-06-21 19:43:35.796454
# Unit test for method map of class Task
def test_Task_map():
    def test(value):
        return value * 2

    def test_reject(value):
        return value * 3

    def result_reject(value):
        return value * 4


    def result_resolve(value):
        return value * 5

    task = Task(lambda reject, resolve: resolve(result_resolve(value=2)))
    assert task.fork(reject=test_reject, resolve=test) == 10
    task.map(test)
    assert task.fork(reject=test_reject, resolve=test) == 10
    task.map(lambda value: result_resolve(value=value))
    assert task.fork(reject=test_reject, resolve=test) == 25


# Generated at 2022-06-21 19:43:38.208594
# Unit test for constructor of class Task
def test_Task():
    """
    Testing implementation of Task constructor.
    """
    def fn(x):
        return x

    task = Task(fn)
    assert isinstance(task, Task)


# Generated at 2022-06-21 19:43:48.368751
# Unit test for method map of class Task
def test_Task_map():
    def square(x):
        return x * x

    def cube(x):
        return x * x * x

    def square_and_cube(x):
        return square(x) + cube(x)

    task = Task.of(2).map(square).map(cube).map(square_and_cube)
    assert task.fork(lambda _: False, lambda x: x == 168) is True

    task = Task.reject('Error').map(cube)
    assert task.fork(lambda x: x == 'Error', lambda _: False) is True

    task = Task.reject('Error').map(cube).map(square)
    assert task.fork(lambda x: x == 'Error', lambda _: False) is True



# Generated at 2022-06-21 19:43:51.665437
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda value: Task.of(value + 1)).fork(
        lambda reject: reject(1),
        lambda resolve: resolve(1)
    ) == 2


# Generated at 2022-06-21 19:43:53.360279
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(10))
    assert task.fork(lambda x: None, lambda x: x) == 10


# Generated at 2022-06-21 19:43:56.688467
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    def check_task(task_value):
        assert task_value is not None
        assert task_value.fork(None, lambda value: value) == 2

    task = Task.of(1).map(mapper)
    check_task(task)

    task = Task.of(1).map(mapper).map(mapper)
    check_task(task)



# Generated at 2022-06-21 19:44:04.087507
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return value

    def reject(value):
        return value

    def mapper(value):
        return value + 1

    assert(
        Task(lambda reject, resolve: resolve(1)).map(mapper).fork(reject, resolve) == 2
    )

    assert(
        Task(lambda reject, resolve: reject(1)).map(mapper).fork(reject, resolve) == 1
    )


# Generated at 2022-06-21 19:44:14.421028
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    """
    # Define function, which return resolved Task with argument value
    def fn(value):
        return Task.of(value + 1)

    # Define function, which return rejected Task with argument value
    def reject_fn(value):
        return Task.reject(value + 1)

    # Create instance of class Task
    task1 = Task(lambda reject, resolve: reject(1))
    task2 = Task(lambda reject, resolve: resolve(1))

    # Create instance of class Task
    task_error = task1.bind(reject_fn)
    task = task2.bind(fn)

    # Check if result of fork function is correct
    assert task_error.fork(lambda value: value, lambda value: value) == 2