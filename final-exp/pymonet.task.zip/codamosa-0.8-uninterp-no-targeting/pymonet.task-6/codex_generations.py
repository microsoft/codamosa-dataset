

# Generated at 2022-06-21 19:34:22.549284
# Unit test for method bind of class Task
def test_Task_bind():
    """
    test_Task_bind
    """

    def fork(reject, resolve):
        resolve(3)
        return True

    def fn(value):
        assert value == 3

        def fn2(_):
            return True

        return Task(fn2)

    task = Task(fork)
    t2 = task.bind(fn)

    assert t2.fork(lambda _: False, lambda _: True)

    fork = Task.reject("Error").map(lambda _: False).bind(lambda _: True).fork
    assert fork(lambda _: True, lambda _: False)


# Unit tests for class Task

# Generated at 2022-06-21 19:34:27.978832
# Unit test for method bind of class Task
def test_Task_bind():
    def foo(reject, resolve):
        resolve(5)

    task = Task(foo)
    assert 5 == task.bind(lambda x: Task.of(x + 5)).fork(
        lambda reject: reject,
        lambda resolve: resolve
    )


# Generated at 2022-06-21 19:34:32.074018
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda res, rej: res(5)).fork(lambda a: a, lambda a: a) == 5
    assert Task(lambda res, rej: rej(5)).fork(lambda a: a, lambda a: a) == 5


# Generated at 2022-06-21 19:34:36.495898
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve('Test Task')

    task = Task(fork)
    value = task.fork(
        lambda arg: print('rejected: ' + str(arg)),
        lambda arg: print('resolved: ' + str(arg))
    )
    print(value)


# Generated at 2022-06-21 19:34:40.128708
# Unit test for constructor of class Task
def test_Task():
    """
    Check if Task constructor work correctly.
    """
    fork = lambda reject, res: res(10)
    task = Task(fork)
    assert task.fork(lambda _: None, lambda x: x) == 10


# Generated at 2022-06-21 19:34:47.384910
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test result value of passed Task by Task.bind.

    :returns: True if passed else raise error with message about specific point of fail.
    :rtype: Boolean
    """
    res = Task.of(2)\
        .bind(lambda x: Task.of(x * 2))\
        .bind(lambda x: Task.of(x + 2))
    assert res.fork(
        lambda arg: arg,
        lambda arg: arg
    ) is 6
    return True

if __name__ == "__main__":
    if test_Task_bind():
        print("All passed!")

# Generated at 2022-06-21 19:34:57.727549
# Unit test for method bind of class Task
def test_Task_bind():
    # Use for decorate function for transform Task[function(arg) -> Task[function(arg) -> Task[function(arg) -> ...]]]
    # on Task[function(arg) -> ...]
    def recursive(fn):
        def result(arg):
            return fn(arg)
        return result

    def fn(arg):
        return Task.of(arg + 1)

    # Create Tasks
    task = Task.of(1)

    # Transform Task[Int] to Task[Int] -> Task[Int] -> ... -> Task[Int]
    task = recursive(recursive(recursive(recursive(recursive(fn)))))

    # Bind function to Task[Int] -> Task[Int] -> ... -> Task[Int]
    task = task.bind(task)

    # Pass function, that return Task[Int] -> Task[Int

# Generated at 2022-06-21 19:35:09.754472
# Unit test for method bind of class Task
def test_Task_bind():
    class DummyClass:
        def __init__(self):
            self.arg = None
            self.is_resolve_called = False

        def resolve(self, arg):
            self.is_resolve_called = True
            self.arg = arg

        def reject(self, arg):
            pass

    dummy = DummyClass()
    task = Task.of(2)

    def fn(x):
        return Task.of(x * 2)

    task.bind(fn).fork(dummy.reject, dummy.resolve)

    assert dummy.arg == 4
    assert dummy.is_resolve_called == True


    dummy = DummyClass()
    task = Task.reject("Error")

    def fn(x):
        return Task.of(x * 2)

    task.bind(fn).fork

# Generated at 2022-06-21 19:35:13.477833
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task
    """
    # Case 1: Simple task
    simple_task = Task(lambda reject, resolve: resolve(2))
    assert_equal(simple_task.fork(lambda value: value, lambda value: value), 2)



# Generated at 2022-06-21 19:35:17.368385
# Unit test for method map of class Task
def test_Task_map():
    def identity(val):
        return val

    assert Task.of(2).map(identity).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task.of(7).map(lambda x: x + 1).fork(
        lambda x: x,
        lambda x: x
    ) == 8

# Generated at 2022-06-21 19:35:29.434119
# Unit test for method bind of class Task
def test_Task_bind():
    def string_to_int(string):
        return Task.of(int(string))

    def add_to(value):
        def add(to):
            return Task.of(value + to)

        return add

    def add_to_strict(value):
        """
        :type value: int
        :type to: int
        """
        def add(to):
            return Task.of(value + to)

        return add

    task = Task.of('2').bind(
        string_to_int
    ).bind(
        add_to(2)
    )

    assert task.fork(lambda value: value, lambda value: value) == 4


# Generated at 2022-06-21 19:35:36.841568
# Unit test for method map of class Task
def test_Task_map():
    """
    test_Task_map - assert that method map of class Task work correct
    :param assertEqual: asserts that class Task with map function work correctly
    :return:
    """
    def add(a):
        return a + 1

    def mul(a):
        return a * 2

    assert isinstance(
        Task.of(5).map(add).map(mul),
        Task
    )

    assert Task.of(5).map(add).map(mul).fork(
        lambda arg: assertEqual(arg, 2),
        lambda arg: assertEqual(arg, 12)
    )


# Generated at 2022-06-21 19:35:41.170201
# Unit test for constructor of class Task
def test_Task():
    """
    Testing constructor of class Task.

    :returns: None
    :rtype: None
    """
    value = 'test_Task'

    def fn(_, resolve):
        return resolve(value)

    assert Task(fn).fork == fn
    assert Task(fn).fork(None, None) == value



# Generated at 2022-06-21 19:35:46.689299
# Unit test for method bind of class Task
def test_Task_bind():
    """
    call method bind on Task and check that stored function calling
    with Task value and return value of nested function.
    """
    def fork(reject, resolve):
        resolve(5)

    def mapper(x):
        def fork(reject, resolve):
            resolve(x + 7)

        return Task(fork)

    task = Task(fork)
    transformed_task = task.bind(mapper)
    assert transformed_task.fork(lambda reject: -1, lambda resolve: resolve) == 12



# Generated at 2022-06-21 19:35:51.192651
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of('value').bind(lambda arg: Task.reject('error'))
    assert result.fork(lambda arg: arg, lambda _: None) == 'error'


# Task abstraction for working with asynchronous functions

# Generated at 2022-06-21 19:35:54.731073
# Unit test for constructor of class Task
def test_Task():
    t = Task(lambda _, resolve: resolve(3))

# Generated at 2022-06-21 19:35:56.665996
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(10).map(lambda x: x+1).fork(None, lambda value: value) == 11


# Generated at 2022-06-21 19:35:59.477644
# Unit test for constructor of class Task
def test_Task():
    assert Task.of('hi')    == Task(lambda _, resolve: resolve('hi'))
    assert Task.reject('hi') == Task(lambda reject, _: reject('hi'))


# Generated at 2022-06-21 19:36:04.936376
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Run assert tests for bind method of class Task

    :returns: void
    :rtype: None
    """
    assert Task.of(2).bind(lambda v: Task.of(v + 5)) == Task.of(7)
    assert Task.reject(2).bind(lambda v: Task.of(v + 5)) == Task.reject(2)


# Generated at 2022-06-21 19:36:12.823593
# Unit test for method bind of class Task
def test_Task_bind():
    def task(value):
        return Task(lambda reject, resolve: resolve(value))

    def take_first(value):
        return task(str(value))

    def take_second(value):
        return task(value * 2)

    def reject():
        return Task(lambda reject, resolve: reject('Reject'))

    def test_chain(reject, resolve):
        # Chain calls
        return task(1)\
        .bind(take_first)\
        .bind(take_second)\
        .bind(lambda value: reject())\
        .fork(reject, resolve)

    def test_reject(reject, resolve):
        # Test reject
        return test_chain(reject, resolve)

# Generated at 2022-06-21 19:36:22.650054
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject(1)
        resolve(2)
        return None

    assert fork(reject_value, resolve_value) is None

    task = Task(fork)
    assert reject_value[0] == 1
    assert resolve_value[0] == 2

    reject_value[0] = None
    resolve_value[0] = None


# Generated at 2022-06-21 19:36:28.856780
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method Task::bind
    """
    def is_string(value):
        """
        Test if value is string
        :param value: value
        :type value: Any
        :return: True if value is string, else False
        :rtype: Bool
        """
        return isinstance(value, str)

    def is_int(value):
        """
        Test if value is int
        :param value: value
        :type value: Any
        :return: True if value is int, else False
        :rtype: Bool
        """
        return isinstance(value, int)


# Generated at 2022-06-21 19:36:40.418700
# Unit test for method bind of class Task
def test_Task_bind():
    def send_email_after_validating_email_address(address):
        if '@' not in address:
            return Task.reject('Not a valid email address')

        return Task.of(address)

    def send_email(address):
        if '@example.com' not in address:
            return Task.reject('Error sending email')

        return Task.of('Email sent to ' + address)

    def validate_and_send_email(address):
        return Task.of(address).bind(send_email_after_validating_email_address).bind(send_email)

    task = validate_and_send_email('example@example.com')


# Generated at 2022-06-21 19:36:49.247848
# Unit test for method map of class Task
def test_Task_map():
    def mapper(arg):
        return arg + 1

    def test(resolve, reject):
        resolve(1)

    def reject(resolve, reject):
        reject("reject")

    assert Task(test).map(mapper).fork(lambda arg: arg, lambda arg: arg) == 2

    assert Task(reject).map(mapper).fork(lambda arg: arg, lambda arg: arg) == "reject"


# Generated at 2022-06-21 19:36:51.272167
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(5).map(lambda arg: arg + 5).fork(lambda arg: None, lambda arg: arg) == 10


# Generated at 2022-06-21 19:36:58.649754
# Unit test for constructor of class Task
def test_Task():
    def task_resolve(reject, resolve):
        return resolve(42)

    assert Task(task_resolve).fork(lambda x: x + 100, lambda x: x - 100) == 42
    assert Task.of(42).fork(lambda x: x + 100, lambda x: x - 100) == 42
    assert Task.reject(42).fork(lambda x: x + 100, lambda x: x - 100) == 142

    # This test will fail if fork function will be called without resolve or reject
    # and due it fact that every function have their own 'return' statement
    try:
        Task.of(42).fork()
    except TypeError:
        pass
    else:
        raise Exception('TypeError expected')


# Generated at 2022-06-21 19:37:00.021998
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: resolve(10)) == Task(lambda reject, resolve: resolve(10))


# Generated at 2022-06-21 19:37:01.844929
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(42)
    assert task.map(lambda x: x + 1).fork(None, lambda x: x) == 43



# Generated at 2022-06-21 19:37:04.639712
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('foo')

    task = Task(fork)

    assert isinstance(task, Task)
    assert task.fork == fork
    assert task.fork == task.fork



# Generated at 2022-06-21 19:37:10.210179
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(lambda x: x, lambda x: x) == 1
    assert Task.of(1).fork(lambda x: x, lambda x: x) == 1
    assert Task.reject(1).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-21 19:37:20.428843
# Unit test for method map of class Task
def test_Task_map():
    def add_2(value):
        return value + 2
    def mul_2(value):
        return value * 2

    task = Task.of(42)
    new_task = task.map(add_2).map(mul_2)
    assert type(new_task) == Task
    assert new_task.fork(lambda v: v, lambda v: v) == 46


# Generated at 2022-06-21 19:37:23.613129
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve('foo')

    task = Task(fork)

    assert task.fork(lambda e: e, lambda a: a) == 'foo', 'constructor should properly store fork function'


# Generated at 2022-06-21 19:37:26.584391
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task.
    """
    @Task
    def test(reject, resolve):
        resolve('test')

    assert test.fork(lambda _: False, lambda val: val == 'test')


# Generated at 2022-06-21 19:37:37.127988
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map method.
    """
    def call_1(resolve, reject):
        return reject(3)

    def call_2(resolve, reject):
        return reject(-1)

    def call_3(resolve, reject):
        return resolve(2)

    fn_1 = lambda x: x * 2
    fn_2 = lambda x: x * x
    fn_3 = lambda x: x * x * x

    task = Task(call_1)

    assert task.map(fn_1).fork(lambda x: x, lambda x: x) == 3
    assert task.map(fn_2).fork(lambda x: x, lambda x: x) == 3
    assert task.map(fn_3).fork(lambda x: x, lambda x: x) == 3


# Generated at 2022-06-21 19:37:41.089605
# Unit test for method bind of class Task
def test_Task_bind():
    def next_task(arg):
        return Task.of(arg * 2)

    task = Task.of(1).bind(next_task)

    assert callable(task.fork)

    result = task.fork(lambda _: None, lambda value: value)
    assert result == 2

# Generated at 2022-06-21 19:37:44.705790
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 2)

    def reject(value):
        return value

    def resolve(value):
        return value

    assert Task.of(10).bind(mapper).fork(reject, resolve) == 12


# Generated at 2022-06-21 19:37:47.583313
# Unit test for method map of class Task
def test_Task_map():
    def fn(arg):
        return arg + 5
    arg = Task(lambda _, resolve: resolve(5)).map(fn)
    assert arg.fork(lambda _: 0, lambda arg: arg) == 10


# Generated at 2022-06-21 19:37:53.397980
# Unit test for method bind of class Task
def test_Task_bind():
    def calculate_the_right_answer():
        return Task.of(42)

    def make_it_forty_two():
        return Task.reject("There is no answer")

    def call_it_the_answer():
        return Task.of("The answer is 42")

    task = calculate_the_right_answer().bind(make_it_forty_two).bind(call_it_the_answer)
    assert task.fork(lambda reject: (reject, "reject"), lambda resolve: (resolve, "resolve")) == ("The answer is 42", "reject")


# Generated at 2022-06-21 19:37:57.018441
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    test_task = Task(fork)

    assert test_task.fork(lambda x: x + 1, lambda x: x + 1) == 2



# Generated at 2022-06-21 19:38:02.972345
# Unit test for method bind of class Task
def test_Task_bind():
    print("testing Task.bind() method...")

    called = False

    def test_run(done, assert_done):
        called = True
        assert_done()

    Task.of(1).bind(
        lambda value: Task.of(value ** 2)
    ).fork(
        lambda error: assert_done(error),
        lambda value: assert_done(value, 4)
    )

    assert_done(called, True)


# Generated at 2022-06-21 19:38:15.844695
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method
    """
    config = {'value': 10}

    def check_fork(reject, resolve):
        assert reject is None
        resolve(config['value'])

    def some_mapper(value):
        assert value == config['value']
        return value * 2

    task = Task(check_fork)
    result = task.map(some_mapper)
    assert result.fork is not check_fork
    assert callable(result.fork)


# Generated at 2022-06-21 19:38:17.627512
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method Task.map
    """
    assert Task.of(2).map(lambda val: val * 2).fork(None, lambda result: result) == 4


# Generated at 2022-06-21 19:38:21.851679
# Unit test for method map of class Task
def test_Task_map():
    def f(n):
        return n + 1

    assert Task(lambda _, resolve: resolve(1)).map(f).fork(lambda error: error, lambda result: result) == 2


# Generated at 2022-06-21 19:38:28.449188
# Unit test for constructor of class Task
def test_Task():
    def resolver(_, resolve):
        resolve('A')
    def rejector(reject, _):
        reject('B')

    assert Task(resolver) == Task(resolver)
    assert Task(resolver).fork == resolver
    assert Task(rejector).fork == rejector
    assert Task(resolver).map(lambda x: x) == Task(resolver)
    assert Task(rejector).map(lambda x: x) == Task(rejector)


# Generated at 2022-06-21 19:38:36.130786
# Unit test for method bind of class Task
def test_Task_bind():
    def return_reject(arg):
        return Task.reject(arg)

    def return_value(arg):
        return Task.of(arg * 2)

    task = (
        Task.of(20)
        .bind(return_value)
        .bind(return_value)
        .bind(return_reject)
    )

    assert task.fork(lambda value: value, lambda value: value) == 20

    task = (
        Task.of(20)
        .bind(return_reject)
        .bind(return_value)
        .bind(return_value)
    )

    assert task.fork(lambda value: value, lambda value: value) == 20


# Generated at 2022-06-21 19:38:38.193252
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(42)

    def fn(value):
        return Task.of(2 * value)

    assert task.bind(fn).fork(lambda arg: arg, lambda arg: arg) == 84


# Generated at 2022-06-21 19:38:47.919340
# Unit test for method map of class Task
def test_Task_map():
    # Test function should call with argument A and return B
    def test_function(value):
        return value * 2

    # Call task.map with test_function
    result = Task.of(2).map(test_function)

    # Check call result
    assert result.fork(lambda _: False, lambda arg: arg) == 4

    # Test function should call with argument A and return B
    def test_function(value):
        return value * 3

    # Call task.map with test_function
    result = Task.of(2).map(test_function)

    # Check call result
    assert result.fork(lambda _: False, lambda arg: arg) == 6

# Generated at 2022-06-21 19:38:56.758500
# Unit test for method map of class Task
def test_Task_map():
    def increase_value(value):
        return value + 1

    def task_of_1():
        return Task.of(1)

    def task_of_2():
        return Task.of(2)

    def result_ok(value):
        assert type(value) == int
        assert value == 2

    @test_case(
        task_of_1(),
        result_ok
    )
    def common_case(_, resolve):
        return resolve(1)


    @test_case(
        task_of_1().map(increase_value),
        result_ok
    )
    def map_case(_, resolve):
        return resolve(1)



# Generated at 2022-06-21 19:38:59.321424
# Unit test for method map of class Task
def test_Task_map():
    t = Task.of(1).map(lambda x: x + 2)
    assert t.fork(lambda x: 2, lambda y: y) == 3



# Generated at 2022-06-21 19:39:03.377525
# Unit test for method map of class Task
def test_Task_map():
    fn = lambda arg: arg ** 2
    assert Task.of(5).map(fn).fork(reject, resolve) == 25
    assert Task.reject(5).map(fn).fork(reject, resolve) == 5


# Generated at 2022-06-21 19:39:14.151861
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of Task class.
    """
    # Test of resolve value

# Generated at 2022-06-21 19:39:16.462432
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for function map of Task class
    """
    def fn(arg):
        return arg + 1

    task = Task.of(1).map(fn)
    assert task.fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-21 19:39:20.451256
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 10).fork(lambda x: x, lambda x: x) == 11
    assert Task.reject(1).map(lambda x: x + 10).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-21 19:39:24.914200
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        def fork(_, resolve):
            resolve(value + 1)
        return Task(fork)

    task_fork = Task(lambda _, resolve: resolve(1)).bind(fn)
    assert task_fork.fork(None, None) == 2


# Generated at 2022-06-21 19:39:34.429116
# Unit test for method map of class Task
def test_Task_map():
    def test_task_map_should_return_task_with_resolved_value_when_task_has_resolved_value():
        expected = 2

        @Task.of(1)
        def map_task(val):
            return val + 1

        assert expected == map_task.fork(lambda _, __: None, lambda a: a)

    def test_task_map_should_return_task_with_resolved_value_when_task_has_rejected_value():
        expected = 2

        @Task.reject(1)
        def lmap_task(_):
            assert False

        def rmap_task(val):
            return val + 1

        assert expected == rmap_task.bind(lmap_task).fork(lambda a, __: a, lambda _: None)

    test_task_map

# Generated at 2022-06-21 19:39:40.962404
# Unit test for method bind of class Task
def test_Task_bind():
    run = [0]

    def step_1(_, resolve):
        run[0] += 1
        return resolve('a')

    def step_2(_, resolve):
        run[0] += 1
        return resolve('b')

    def step_3(_, resolve):
        run[0] += 1
        return resolve('c')

    def step_4(_, resolve):
        run[0] += 1
        return resolve('d')

    def step_5(_, resolve):
        run[0] += 1
        return resolve('e')


# Generated at 2022-06-21 19:39:44.606082
# Unit test for constructor of class Task
def test_Task():
    # resolve test
    task = Task.of(10)

# Generated at 2022-06-21 19:39:55.006670
# Unit test for method bind of class Task
def test_Task_bind():
    T = Task

    increment = lambda x: x + 1
    add = lambda x, y: x + y
    a = T.of(3).bind(lambda _: T.of(4))
    b = T.of(3).bind(lambda _: T.of(4)).bind(lambda _: T.of(5))

    assert a.fork(None, increment) == 5
    assert b.fork(None, increment) == 6

    c = T.of(3).bind(lambda _: T.of(4)).bind(lambda _: T.reject(4))
    assert c.fork(increment, None) == 5

    d = T.of(3).bind(lambda x: T.of(4).bind(lambda y: T.of(add(x, y))))

    assert d.fork(None, increment)

# Generated at 2022-06-21 19:39:57.737277
# Unit test for method map of class Task
def test_Task_map():
    def test_function(arg):
        return arg + 1

    assert Task.of(1).map(test_function).fork(_, lambda x: x) == 2


# Generated at 2022-06-21 19:40:02.504632
# Unit test for constructor of class Task
def test_Task():
    """
    Constructor of class Task must return instance of Task with function as fork attribute.
    """
    def not_called(reject, resolve):
        raise AssertionError('Not called')

    task = Task(not_called)
    assert task

    task = Task(lambda reject, resolve: None)
    assert task


# Generated at 2022-06-21 19:40:22.521366
# Unit test for method bind of class Task
def test_Task_bind():

    def throw_error():
        raise Exception('error handle')

    resolve = "resolve"
    reject = "reject"

    def resolve_wrap(reject, resolve):
        resolve(resolve)

    def reject_wrap(reject, resolve):
        reject(reject)

    def pipeline_wrap(reject, resolve):
        resolve([[resolve, reject], [throw_error, reject]])

    assert_equals(Task(resolve_wrap).bind(lambda res: Task(lambda _, resolve: resolve(res))).fork(lambda _: None, lambda res: res), resolve)
    assert_equals(Task(reject_wrap).bind(lambda res: Task(lambda _, resolve: resolve(res))).fork(lambda rej: rej, lambda _: None), reject)

# Generated at 2022-06-21 19:40:26.141883
# Unit test for method map of class Task
def test_Task_map():
    mock_resolve = Mock()
    mock_reject = Mock()

    Task.of(1).map(lambda value: 2).fork(mock_reject, mock_resolve)

    mock_resolve.assert_called_once_with(2)


# Generated at 2022-06-21 19:40:29.940727
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve("Fork")

    task = Task(fork)
    try:
        assert task.fork("reject", "resolve") == "Fork"
    except AssertionError:
        print("ERROR: Error in constructor of class Task")


# Generated at 2022-06-21 19:40:32.818095
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(f1, f2):
        f1(1)

    task = Task(fork)

# Generated at 2022-06-21 19:40:35.946645
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1)
    assert Task.reject(1)


# Generated at 2022-06-21 19:40:37.057435
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(-10).bind(lambda x: Task.of(x * x)).fork(None, assert_equal(-10 * -10))

# Generated at 2022-06-21 19:40:42.540552
# Unit test for method map of class Task
def test_Task_map():
    def negate(value):
        return -value

    def test_negate():
        original = Task.of(1)
        after = original.map(negate)
        return after.fork(None, lambda value: value)

    assert test_negate() == -1


# Generated at 2022-06-21 19:40:47.989238
# Unit test for method map of class Task
def test_Task_map():
    def fn(arg):
        return arg + 1

    # create Task with value 1, map it and call fork function
    task = Task.of(1).map(fn).fork(
        lambda arg: None,
        lambda arg: print(arg)
    )

    # Expect: 2
    print(task)


# Generated at 2022-06-21 19:40:55.740323
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind.

    It seems like there no way to write tests for bind method without
    using of state. So I just check that result of bind method is
    instance of Task class.

    :returns: True if all methods of bind return instance of Task class
    :rtype: Boolean
    """

    # Create Task with resolve and reject functions
    resolve_pre = Task(lambda reject_pre, resolve_pre: 'resolve_pre')
    reject_pre = Task(lambda reject_pre, resolve_pre: 'reject_pre')

    # Create Task with resolve and reject functions where resolve function
    # in second task are implemented with calling of resolve function in
    # first task.
    resolve_post = Task(lambda reject_post, resolve_post: resolve_pre.fork(reject_post, resolve_post))
    reject_

# Generated at 2022-06-21 19:40:57.855786
# Unit test for method bind of class Task
def test_Task_bind():
    result = 'value'
    task = Task.of('value')

    assert task.bind(lambda arg: Task.of(arg + arg)) == result + result

# Generated at 2022-06-21 19:41:31.571916
# Unit test for method map of class Task
def test_Task_map():
    def test_Task_map_resolve():
        def mapper(value):
            return value + 1

        task = Task(lambda _, resolve: resolve(1))
        result_task = task.map(mapper)

        assert result_task == Task(mapper(task.fork(lambda _, resolve: resolve(1))))

    def test_Task_map_reject():
        def mapper(value):
            return value + 1

        task = Task(lambda reject, _: reject(1))
        result_task = task.map(mapper)

        assert result_task == task

    test_Task_map_reject()
    test_Task_map_resolve()


# Generated at 2022-06-21 19:41:38.202803
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda reject, resolve: resolve(1)).bind(lambda arg: Task(lambda reject, resolve: resolve(arg + 1))) == Task(lambda reject, resolve: resolve(2))
    assert Task(lambda reject, resolve: resolve(1)).bind(lambda arg: Task(lambda reject, resolve: resolve(arg + 1))).bind(lambda arg: Task(lambda reject, resolve: resolve(arg + 1))) == Task(lambda reject, resolve: resolve(3))


# Generated at 2022-06-21 19:41:40.528109
# Unit test for method map of class Task
def test_Task_map():
    def fn(arg):
        return arg + 1

    src = Task.of(1)
    new_src = src.map(fn)
    assert new_src.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-21 19:41:43.119607
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('error')

    task = Task(fork)

    assert hasattr(task, 'fork')
    assert callable(task.fork)


# Generated at 2022-06-21 19:41:45.275669
# Unit test for constructor of class Task
def test_Task():
    """
    :returns: None
    :rtype: NoneType
    """
    def fork(_, resolve):
        return resolve('test')

    assert Task(fork).fork(lambda _: None, lambda arg: arg) == 'test'


# Generated at 2022-06-21 19:41:50.538855
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind method of Task class.
    """
    def f1(value):
        return Task.of(value + 1)

    return Task.of(1).bind(f1).bind(f1).fork(
        lambda x: 'Error!',
        lambda x: x
    ) # return 3


# Generated at 2022-06-21 19:41:53.377483
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of("test").map(lambda str: str + " res")
    assert isinstance(result, Task)
    assert result.fork("rejected", "resolved") == "test res"


# Generated at 2022-06-21 19:41:56.876568
# Unit test for method map of class Task
def test_Task_map():
    # Success case
    def add_one(x):
        return x + 1

    assert Task.of(2).map(add_one).fork(lambda _: False, lambda arg: arg == 3)
    # Failure case
    assert 'this' == Task.reject('this').map(add_one).fork(lambda arg: arg, lambda _: False)


# Generated at 2022-06-21 19:42:00.251424
# Unit test for constructor of class Task
def test_Task():
    """
    Test case for constructor of class Task.
    """

    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    assert task.fork is fork


# Generated at 2022-06-21 19:42:03.479356
# Unit test for method map of class Task
def test_Task_map():
    def fork(_, resolve):
        return resolve(3)

    def mapper(val):
        return val * 2

    tsk = Task(fork)
    tsk.map(mapper)
    assert tsk.fork(None, None) == 6



# Generated at 2022-06-21 19:43:09.941125
# Unit test for method bind of class Task
def test_Task_bind():
    # @ type: Task[Int, Int]
    task = Task.of(10)
    # @ type: Int -> Task[Int, String]
    def bind(i):
        return Task.of(str(i))

    # @ type: Task[Int, String]
    result = task.bind(bind)

    res = []
    def resolve(x):
        res.append(x)
    def reject(x):
        res.append(x)

    result.fork(reject, resolve)
    assert res[0] == '10'


# Generated at 2022-06-21 19:43:17.761599
# Unit test for method bind of class Task
def test_Task_bind():
    def test(value):
        return Task.of(value)

    def test_reject(value):
        return Task.reject(value)

    assert Task.of(1).bind(test).fork(lambda arg: False, lambda arg: arg) == 1
    assert Task.of(1).bind(test_reject).fork(lambda arg: arg, lambda arg: False) == 1
    assert Task.reject(1).bind(test).fork(lambda arg: arg, lambda arg: False) == 1
    assert Task.reject(1).bind(test_reject).fork(lambda arg: arg, lambda arg: False) == 1



# Generated at 2022-06-21 19:43:20.548480
# Unit test for constructor of class Task
def test_Task():
    fork = lambda resolve, reject: resolve('ok')
    result = Task(fork)

    assert result.fork == fork


# Generated at 2022-06-21 19:43:23.322065
# Unit test for method map of class Task
def test_Task_map():
    start = Task.of(42)

    assert start.fork(lambda _: False,
                      lambda arg: arg == 42)

    mapped = start.map(lambda x: x + 1)

    assert mapped.fork(lambda _: False,
                       lambda arg: arg == 43)



# Generated at 2022-06-21 19:43:28.112162
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(5)

    task = Task(fork)

    assert task.map(fn).fork(lambda _: False, lambda arg: arg == 6)


# Generated at 2022-06-21 19:43:32.765201
# Unit test for method map of class Task
def test_Task_map():
    def test(assert_):
        assert_.equal('ok', Task.of(1).map(lambda x: 'ok').fork(
            lambda arg: arg,
            lambda arg: arg
        ))
    tdd(test)


# Generated at 2022-06-21 19:43:36.413320
# Unit test for constructor of class Task
def test_Task():
    # comparing result of resolve and reject
    assert Task.of('hi').fork(reject=lambda x: x, resolve=lambda x: x) == 'hi'
    assert Task.reject('hi').fork(reject=lambda x: x, resolve=lambda x: x) == 'hi'


# Generated at 2022-06-21 19:43:38.960245
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.reject(1)
    mapped = task.bind(lambda arg: Task.of(arg + 1))

    def call_with(resolve, reject):
        return reject(1)

    assert mapped.fork(resolve=None, reject=call_with) == 2


# Generated at 2022-06-21 19:43:40.633813
# Unit test for method map of class Task
def test_Task_map():
    def mapper(arg):
        return arg + 1
    value = 10
    expected = Task(lambda _, resolve: resolve(mapper(value)))

    assert Task.of(value).map(mapper) == expected


# Generated at 2022-06-21 19:43:43.453756
# Unit test for method bind of class Task
def test_Task_bind():
    def associate(value):
        return Task.of(value + 1)

    fork = Task.of(2).bind(associate)

    assert(fork(lambda _: None, lambda arg: arg)) == 3
