

# Generated at 2022-06-21 19:34:16.801390
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind function of Task.
    Test will be passed if bind call new Task with value of
    passed function.

    :returns: None
    :rtype: None
    """
    def _(arg):
        return Task.of(arg + 1)

    task = Task.of(0).bind(_)
    assert task.fork(None, lambda x: x + 1) == 1


# Generated at 2022-06-21 19:34:22.269448
# Unit test for method bind of class Task
def test_Task_bind():
    success = Task.of(1)
    fail = Task.reject(2)

    def result(reject, resolve):
        return success.fork(lambda x: reject(x), lambda x: resolve(x + 1))

    assert Task(result) == success.bind(lambda x: Task.of(x + 1))
    assert Task(result) != success.bind(lambda x: Task.of(x))
    assert Task(result) != success.bind(lambda x: Task.reject(x + 1))

    assert fail == fail.bind(lambda x: Task.of(x + 1))


# Generated at 2022-06-21 19:34:26.308377
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)

    assert task.fork(lambda x: x, lambda x: x) == 1



# Generated at 2022-06-21 19:34:29.054434
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda x, y: x(y))

    assert task.fork('a', 'b') == 'b'


# Generated at 2022-06-21 19:34:38.303326
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.
    """
    def double_value(_, resolve):
        resolve(2)

    assert Task(double_value).map(lambda arg: arg + arg).fork(lambda x: x, lambda y: y) == 4
    assert Task(double_value).map(lambda arg: arg + arg).fork(lambda x: 0, lambda y: y) == 4
    assert Task(double_value).map(lambda arg: arg + arg).fork(lambda x: x, lambda y: y + 1) == 4
    assert Task(double_value).map(lambda arg: arg + arg).fork(lambda x: x, lambda y: y) == 4

# Use "doctest" module tests
if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 19:34:46.014029
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method 'bind' of class Task.
    """
    counter = 0

    # Test with no errors
    def run_test_with_no_errors(resolve):
        # Resolve task and increase counter on 1
        resolve(1)

    def increase_counter_by_one(value):
        nonlocal counter
        counter += value

    fn = Task(run_test_with_no_errors)
    fn.bind(increase_counter_by_one)()

    assert counter == 1, "Test bind failed."

    # Test with failed result
    counter = 0

    def run_test_with_failed_result(resolve, reject):
        # Reject task and increase counter on 2
        reject(2)

    def increase_counter_by_two(value):
        nonlocal counter

# Generated at 2022-06-21 19:34:54.683212
# Unit test for method map of class Task
def test_Task_map():
    """
    Return Task with plus by 1 value if result of fork is greater then 5,
    else return Task with same value.
    """
    def test_fork(reject, resolve):
        value = random.randint(0, 10)
        if value > 5:
            return resolve(value)
        else:
            return resolve(value)

    def test_fn(x):
        return x + 1

    task = Task(test_fork)

    # test for Task of function
    assert task.map(test_fn).fork(lambda x: x, lambda x: x) >= 6



# Generated at 2022-06-21 19:35:01.699031
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(reject, resolve) == 1

    assert Task(lambda _, resolve: resolve(1)) == Task.of(1)

    assert Task.reject(1).fork(reject, resolve) == 1



# Generated at 2022-06-21 19:35:05.195002
# Unit test for method map of class Task
def test_Task_map():
    def func(a):
        return a+1

    assert Task.of(5).map(func).fork(lambda a: a*2, lambda a: a*2) == 12

# Generated at 2022-06-21 19:35:10.951809
# Unit test for method bind of class Task
def test_Task_bind():
    def plus(first_value):
        return Task(lambda _, resolve: resolve(first_value + 2))

    def mult(first_value):
        return Task(lambda _, resolve: resolve(first_value * 3))

    plus_to_mult = Task(lambda _, resolve: resolve(1)).bind(plus).bind(mult)
    assert plus_to_mult.fork(lambda _: 1, lambda value: value) == 9


# Generated at 2022-06-21 19:35:17.678677
# Unit test for method map of class Task
def test_Task_map():
    fun = lambda x: x * x
    task = Task.of(2).map(fun)
    assert task.fork(None, lambda x: x) == 4

    task = Task.of(5).map(fun).map(fun)
    assert task.fork(None, lambda x: x) == 625



# Generated at 2022-06-21 19:35:25.306283
# Unit test for method map of class Task
def test_Task_map():
    def fork(_, resolve):
        nonlocal called
        called = True
        return resolve('Test string')

    called = False
    task = Task(fork)

    assert isinstance(task.map(len), Task)

# Generated at 2022-06-21 19:35:35.200168
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def fail(x):
        return Task.reject(-1)

    # Add one to value

# Generated at 2022-06-21 19:35:43.494612
# Unit test for method bind of class Task
def test_Task_bind():
    task_resolve = Task.of("value")
    task_reject = Task.reject("value")
    task_after_resolve = Task.of("another value")

    assert task_resolve.bind(lambda arg: Task.reject(arg)) == task_reject
    assert task_resolve.bind(lambda arg: Task.of(arg)) == task_resolve
    assert task_resolve.bind(lambda arg: task_after_resolve) == task_after_resolve
    assert task_reject.bind(lambda arg: task_after_resolve) == task_reject


# Generated at 2022-06-21 19:35:50.482800
# Unit test for method map of class Task
def test_Task_map():
    success_numbers = [1, 2, 3]
    fail_numbers = [-1, -2, -3]

    def resolved(arg):
        assert type(arg) == int
        assert arg in success_numbers
        success_numbers.remove(arg)
        return arg + 10

    def rejected(arg):
        assert type(arg) == int
        assert arg in fail_numbers
        fail_numbers.remove(arg)
        return arg + 10

    def tasker(reject, resolve, value):
        assert value in [-3, -2, -1, 1, 2, 3]
        value > 0 and resolve(value) or reject(value)

    task = Task(tasker)

    Task.reject(-3).map(rejected)
    Task.of(-2).reject(rejected)


# Generated at 2022-06-21 19:36:01.002066
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    test_faker = Faker()

    task_with_random_value = Task.of(test_faker.random_int())

    assert task_with_random_value.map(add_one) == Task.of(add_one(task_with_random_value.fork(None, lambda v: v)))

    def fail(value):
        raise Exception(f'Failed with value {value}')

    assert Task.reject(test_faker.random_int()).map(add_one) == Task.reject(test_faker.random_int())

    assert Task.of(test_faker.random_int()).map(fail) == Task.reject(fail(test_faker.random_int()))


# Generated at 2022-06-21 19:36:08.079210
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(3)

    def fork_error(reject, resolve):
        return reject(3)

    def mapper(n):
        @Task
        def _mapper(reject, resolve):
            return resolve(n + 1)

        return _mapper


# Generated at 2022-06-21 19:36:12.898360
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).map(lambda x: x + 1).fork(
        lambda a: print(a),
        lambda a: print(a)) == 2

# Unit tests for method map of class Task

# Generated at 2022-06-21 19:36:17.710217
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(resolve, reject):
        resolve(2)

    def fn_bind(value):
        def inner_fn(resolve, reject):
            resolve(value * 2)

        return Task(inner_fn)

    assert Task(fn).bind(fn_bind).fork(lambda _: "err", lambda arg: arg) == 4


# Generated at 2022-06-21 19:36:19.645199
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task(lambda r, f: f(1)), Task)


# Generated at 2022-06-21 19:36:28.498902
# Unit test for method bind of class Task
def test_Task_bind():
    def join_word(word):
        return Task.of(word + 'join')

    def join_words(from_word, to_word):
        return Task.of(from_word + ' ' + to_word + 'join')

    def concat_word(word):
        return Task.of(word + 'concat')

    def concat_and_join_all_words(from_word, to_word, third_word):
        return Task.of(from_word + to_word + third_word + ' concat and join result!')


# Generated at 2022-06-21 19:36:38.619091
# Unit test for method bind of class Task
def test_Task_bind():
    def f1(value):
        return Task.of(value * 2)

    def f2(value):
        return Task.of(value + 2)

    def f3(value):
        return Task.reject(value + 2)

    assert Task.of(2).bind(f1).bind(f2).fork(lambda d: d, lambda r: r) == 6
    assert Task.of(2).bind(f1).bind(f3).fork(lambda d: d, lambda r: r) == 4
    assert Task.of(2).bind(f3).bind(f2).fork(lambda d: d, lambda r: r) == 4

test_Task_bind()

# Generated at 2022-06-21 19:36:42.023461
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(4).map(lambda x: x * 2)
    assert result.fork(
        lambda value: print("ERROR: {}".format(value)),
        lambda value: print("RESOLVE: {}".format(value))
    ) == 8


# Generated at 2022-06-21 19:36:46.867276
# Unit test for constructor of class Task
def test_Task():
    """
    Check function Task constructor.
    """
    def fork_func(reject, resolve):
        return 'fork'

    task = Task(fork_func)

    assert task.fork == fork_func



# Generated at 2022-06-21 19:36:50.098883
# Unit test for constructor of class Task
def test_Task():
    """
    Task -> Unit
    """
    task = Task(lambda _, resolve: resolve(32))
    assert task.fork(lambda _: [], lambda result: result) == [32]



# Generated at 2022-06-21 19:37:00.947768
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind method.

    :returns: true
    :rtype: None
    """
    # Get successed Task
    t = Task.of(2)
    # Bind lambda function to t
    t1 = t.bind(lambda v: Task.of(v + 2))
    # Bind method must return new Task
    assert t != t1
    # Bind method must return new Task with value same like for passed function
    assert t1.fork(None, int) == 4
    # Test rejected Task with method bind
    t = Task.reject("2")
    # Bind must return new Task rejected with stored value in 't'
    t1 = t.bind(lambda v: Task.of(v + 2))
    # Bind method must return new Task
    assert t != t1
    # Bind method must return new Task

# Generated at 2022-06-21 19:37:05.747540
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind(fn)

    Task.bind return Task with resolve attribute equal to result of called
    fn with Task resolve value
    """
    # create Task
    task = Task(lambda _, resolve: resolve(10))

    # test Task.bind(fn)
    result = task.bind(lambda arg: Task.of(arg + 10))

    assert result.fork(None, lambda arg: arg) == 20



# Generated at 2022-06-21 19:37:09.656459
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve("execute fork")

    task = Task(fork)
    assert(task.fork == fork)


# Generated at 2022-06-21 19:37:12.846554
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    result = task.bind(lambda v: Task.of(v + 1))

    assert result.fork(lambda e: e, lambda v: v) == 2


# Generated at 2022-06-21 19:37:16.454860
# Unit test for constructor of class Task
def test_Task():
    def fork(_, resolve):
        resolve(1)

        return 2

    result_task = Task(fork)

    assert isinstance(result_task, Task)
    assert hasattr(result_task, 'fork')

    assert result_task.fork is fork


# Generated at 2022-06-21 19:37:26.137980
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(5).bind(lambda arg: Task.of(arg + 10))
    assert result.fork(
        lambda e: e,
        lambda v: v
    ) == 15
    result = Task.reject(55).bind(lambda e: e)
    assert result.fork(
        lambda e: e,
        lambda v: v
    ) == 55


# Generated at 2022-06-21 19:37:28.382401
# Unit test for method map of class Task
def test_Task_map():
    @Task
    def add2(value):
        return value + 2

    assert Task.of(1).map(add2).fork(identity, identity) == 3



# Generated at 2022-06-21 19:37:34.911796
# Unit test for method bind of class Task
def test_Task_bind():
    value = Task.of(2).bind(lambda arg: Task.of(arg*2))

    def test_1():
        assert value.fork(lambda _: False, lambda arg: arg == 4)
    def test_2():
        try:
            value.fork(lambda _: True, lambda _: False)
            assert False
        except:
            pass
    test_1()
    test_2()


# Generated at 2022-06-21 19:37:38.638405
# Unit test for constructor of class Task
def test_Task():
    assert Task
    assert Task.of
    assert Task.reject
    assert Task.of(1).fork(lambda _: False, lambda arg: arg == 1)
    assert Task.reject(1).fork(lambda arg: arg == 1, lambda _: False)


# Generated at 2022-06-21 19:37:42.851096
# Unit test for constructor of class Task
def test_Task():
    t = Task(lambda reject, resolve: resolve(None))

    # check attributes
    if not hasattr(t, 'fork') or not hasattr(t, 'map') or not hasattr(t, 'bind'):
        raise AssertionError("Task class must have fork, map and bind attributes")



# Generated at 2022-06-21 19:37:45.592059
# Unit test for constructor of class Task
def test_Task():
    """
    Test that constructor of Task class will return same output.
    """
    Fork = lambda _, resolve: resolve(42)

    task = Task(Fork)

    assert task.fork == Fork

# Generated at 2022-06-21 19:37:52.665762
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(5).map(lambda x: x + 1).fork(
        lambda value: "fork rejected",
        lambda value: value
    ) == 6

    # case argument is None
    assert Task.of(None).map(lambda x: x).fork(
        lambda value: "fork rejected",
        lambda value: value
    ) == None

    # case "rejected" argument
    assert Task.reject("rejected").map(lambda x: x).fork(
        lambda value: value,
        lambda value: "fork resolved"
    ) == "rejected"

    # case function map argument is None
    assert Task.of(5).map(None).fork(
        lambda value: "fork rejected",
        lambda value: value
    ) == 5


# Generated at 2022-06-21 19:37:55.121985
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        assert reject is None
        assert resolve is None

    assert Task(fork) is not None



# Generated at 2022-06-21 19:37:58.167587
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(None, print) == 1
    assert Task(lambda reject, _: reject(1)).fork(print, None) == 1


# Generated at 2022-06-21 19:38:03.797228
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.

    Test setup:
    Call Task.of with 1 number, call bind method with lambda expression
    which return rejected Task with 2 number.

    Test fail condition:
    Resolved Task value argument not equal to 2 or rejected.

    Test success condition:
    Rejected Task value argument equal to 2.
    """
    def on_reject(value):
        """
        Take value argument and assert it.

        :param value: argument from Task
        :type value: int
        """
        assert value == 2

    def on_resolve(value):
        """
        Take value argument and assert it.

        :param value: argument from Task
        :type value: int
        """
        assert False


# Generated at 2022-06-21 19:38:16.365948
# Unit test for method bind of class Task
def test_Task_bind():
    """
    :returns: test result of Task.bind method
    :rtype: Bool
    """
    task = Task.of(0)
    task2 = task.bind(lambda x: Task.of(x + 1))
    return task2.fork(
        lambda _: False,
        lambda value: value == 1
    )


# Generated at 2022-06-21 19:38:19.012525
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve('foo'))
    assert task.fork(lambda reject: reject('foo'), lambda resolve: resolve('bar')) == 'bar'


# Generated at 2022-06-21 19:38:29.697287
# Unit test for method bind of class Task
def test_Task_bind():
    t1 = Task.of(10)
    t2 = Task.of(20)
    t3 = Task.reject('rejected')

    def add_10(x):
        return x + 10

    def add_20(x):
        return x + 20

    def f(x):
        if x == 100:
            return t1
        elif x == 200:
            return t2
        else:
            return t3

    t4 = Task.of(100).bind(f).map(add_10)
    t5 = Task.of(200).bind(f).map(add_20)
    t6 = Task.of(300).bind(f).map(add_20)

    assert t4.fork(lambda arg: arg, lambda arg: arg) == 20

# Generated at 2022-06-21 19:38:33.945765
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(lambda x: 0, lambda y: y) == 2
    assert Task.reject(1).map(lambda x: x + 1).fork(lambda x: 0, lambda y: y) == 0


# Generated at 2022-06-21 19:38:40.063744
# Unit test for method map of class Task
def test_Task_map():
    """
    Test passed when Task.map(lambda x: x + 1, x) == Task.of(x + 1)

    :returns: True if test passed
    :rtype: Boolean
    """
    def mapper(x):
        return x + 1

    def fork(reject, resolve):
        return resolve(1)

    assert Task(fork).map(mapper) == Task.of(2)


# Generated at 2022-06-21 19:38:43.005634
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve('value')

    task = Task(fork)

    assert task.fork(lambda arg: arg, lambda arg: arg) == 'value'


# Generated at 2022-06-21 19:38:48.232030
# Unit test for constructor of class Task
def test_Task():
    # test without fork param
    assert Task() == Task().fork == Task().fork.__name__ == Task().__name__ == 'fork'

    # test with fork param
    def fork(reject, resolve):
        return resolve('Hello')

    assert Task(fork).fork(lambda arg: arg, lambda arg: arg) == 'Hello'


# Generated at 2022-06-21 19:38:56.990884
# Unit test for method bind of class Task
def test_Task_bind():
    """
    This function check Task.bind function.
    Create Task with resolve value and reject value.
    Chain some Task using bind and check result of these Task.
    """

    def delay_print(x):
        """
        Create Task with resolve value.

        :returns: resolved Task with stored resolve value
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task(lambda _, resolve: resolve(x))

    def delay_print_resolve():
        """
        Create Task with resolve value.

        :returns: resolved Task with stored resolve value
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task(lambda _, resolve: resolve())


# Generated at 2022-06-21 19:39:01.441881
# Unit test for method map of class Task
def test_Task_map():
    value = Task.of('Hi')
    new_value = value.map(lambda x: x[1])
    assert new_value.fork(lambda x: x, lambda x: x) == 'i'
    assert new_value.fork(lambda x: x, lambda _: 'default') == 'i'



# Generated at 2022-06-21 19:39:10.779036
# Unit test for method map of class Task
def test_Task_map():
    """
    Function to test Task.map
    :returns: test result or raise exception
    :rtype: bool | Exception
    """

    def assertion_incr(a):
        return a + 1

    def assertion_decr(a):
        return a - 1

    def assertion(fn):
        return Task(lambda _, resolve: resolve(1)).map(fn).fork(
            lambda arg: False,
            lambda arg: arg == 2
        )

    return (
        assertion(assertion_incr) and
        assertion(assertion_decr)
    )


# Generated at 2022-06-21 19:39:33.825797
# Unit test for method bind of class Task
def test_Task_bind():
    def extended_task(value):
        return Task.of(value + 1)
    
    assert Task.of(2).bind(extended_task).fork(lambda x: 'Reject', lambda x: x) == 3



# Generated at 2022-06-21 19:39:39.327507
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind.
    """
    val = Task.of(10)
    val = val.bind(lambda x: Task.of(x + 20))
    assert val.fork(lambda x: x, lambda x: x) == 30


# Generated at 2022-06-21 19:39:46.365898
# Unit test for method bind of class Task
def test_Task_bind():
    def async_divide(a, b, reject, resolve):
        if b == 0:
            resolve(a / b)

    assert Task.of(42).bind(async_divide) == Task(lambda reject, resolve: async_divide(42, 2, reject, resolve))
    assert Task.reject('Division by zero').bind(async_divide) == Task(lambda reject, resolve: async_divide('Division by zero', 2, reject, resolve))


# Generated at 2022-06-21 19:39:52.342920
# Unit test for method bind of class Task
def test_Task_bind():
    def initial_reject(value):
        print(f'reject {value}')

    def initial_resolve(value):
        print(f'resolve {value}')

    def mapper(value):
        print(f'mapper {value}')
        return Task.of(value)

    Task.of(1) \
        .bind(mapper) \
        .fork(initial_reject, initial_resolve)


# Generated at 2022-06-21 19:39:55.721385
# Unit test for constructor of class Task

# Generated at 2022-06-21 19:40:00.216829
# Unit test for method bind of class Task
def test_Task_bind():
    def result(reject, resolve):
        return Task.of(3).bind(lambda x: Task.of(x + 5)).fork(reject, resolve)

    def reject(value):
        return AssertionError("unexpected error")

    def resolve(value):
        return value

    assert result(reject, resolve) == 8


# Generated at 2022-06-21 19:40:05.954951
# Unit test for constructor of class Task
def test_Task():
    def resolve(x):
        r = Task.of(1)
        r.fork(print, resolve)
        return x + 1

    def reject(x):
        x = Task.reject(1)
        x.fork(reject, print)
        return x + 1

    assert Task.of(1).fork(reject, resolve) == 2
    assert Task.reject(1).fork(reject, resolve) == 2


# Generated at 2022-06-21 19:40:09.952190
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task
    """
    def some_increment(value):
        """
        increment argument and return new Task with result

        :param value: value to increment
        :type value: int
        :returns: new Task
        :rtype: Task[Function(reject, resolve) -> int]
        """
        return Task.of(value + 1)


# Generated at 2022-06-21 19:40:20.542580
# Unit test for method map of class Task
def test_Task_map():
    from nose.tools import assert_equal, assert_true

    task = Task.of(2)
    assert_equal(task.fork(lambda _: None, lambda a: a), 2)

    def inc(a):
        return a + 1
    mapped_task = task.map(inc)
    assert_equal(mapped_task.fork(lambda _: None, lambda a: a), 3)

    def stringify(a):
        return str(a)
    mapped_task = task.map(stringify)
    assert_equal(mapped_task.fork(lambda _: None, lambda a: a), '2')

    task = Task.reject(2)
    assert_equal(task.fork(lambda a: a, lambda _: None), 2)


# Generated at 2022-06-21 19:40:24.421337
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 10

    def multiply(x):
        return x * 2

    task = Task.of(20)
    task = task.map(add).map(multiply)

    assert task.fork(None, lambda x: x) == 60



# Generated at 2022-06-21 19:41:10.566091
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of('value').map(lambda arg: str(arg)).fork(lambda arg: arg, lambda arg: arg) == 'value'
    assert Task.of(1).map(lambda arg: arg + 1).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-21 19:41:15.263876
# Unit test for constructor of class Task
def test_Task():
    def check_result(*args, **kwargs):
        if kwargs.get('error', False):
            raise ValueError('Some error')

        return args

    task = Task(check_result)

    return task.fork(lambda _: None, lambda arg: arg[0] == [])


# Generated at 2022-06-21 19:41:20.222098
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(v):
        print(v)

    def reject(v):
        print(v)

    Task(
        lambda reject, resolve: resolve(1)
    ).bind(
        lambda value: Task(
            lambda _, resolve: resolve(value + 1)
        )
    ).fork(reject, resolve)


# Generated at 2022-06-21 19:41:27.791219
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind method
    """

    counter1 = 0
    counter2 = 0

    def fork1(reject, resolve):
        nonlocal counter1
        counter1 += 1

    def fork2(reject, resolve):
        nonlocal counter2
        counter2 += 1
        reject(1)

    task1 = Task(fork1)
    task2 = Task(fork2)

    def fn(arg):
        return task2

    task1.bind(fn)

    assert counter1 == 1
    assert counter2 == 1



# Generated at 2022-06-21 19:41:30.738138
# Unit test for constructor of class Task
def test_Task():
    def resolve(arg):
        assert arg == 1, "Task.of method failed"
    def rejected(arg):
        assert False, "Task.of mustn't be rejected"

    Task.of(1).fork(rejected, resolve)



# Generated at 2022-06-21 19:41:40.555635
# Unit test for method map of class Task
def test_Task_map():
    def test_success(assert_):
        def fork(reject, resolve):
            return resolve(1)

        def is_equal(value):
            assert_.equal(value, 2)

        return Task(fork).map(lambda x: x + 1).fork(
            lambda _: assert_.throw(),
            is_equal
        )

    def test_fail(assert_):

        def fork(reject, resolve):
            return reject(1)

        def is_equal(value):
            assert_.equal(value, 1)

        return Task(fork).map(lambda x: x + 1).fork(
            is_equal,
            lambda _: assert_.throw()
        )


# Generated at 2022-06-21 19:41:51.842628
# Unit test for method bind of class Task
def test_Task_bind():
    def test_with_resolve(arg):
        return Task(lambda _, resolve: resolve(arg))

    def test_with_reject(arg):
        return Task(lambda reject, _: reject(arg))

    def test_with_error(arg):
        return Task(lambda _, _not: error(arg))

    assert Task.of(1).bind(test_with_resolve).fork(reject=error, resolve=identity) == 1
    assert Task.of(1).bind(test_with_reject).fork(reject=identity, resolve=error) == 1
    assert Task.reject(1).bind(test_with_resolve).fork(reject=identity, resolve=error) == 1

# Generated at 2022-06-21 19:41:53.446405
# Unit test for constructor of class Task
def test_Task():
    """
    Test Task constructor and check if fork function can be located in Task object.
    """
    def fork(): pass
    task = Task(fork)

    assert type(task.fork) is types.FunctionType


# Generated at 2022-06-21 19:42:00.978131
# Unit test for method map of class Task
def test_Task_map():
    # All this examples can be called in `doctest`
    example = Task.of(1)
    task = example.map(lambda x: x + 1)
    assert task.fork(lambda x: x, lambda x: x) == 2

    task = example.map(lambda x: x * 5)
    assert task.fork(lambda x: x, lambda x: x) == 5

    task = example.map(lambda x: x / 2)
    assert isinstance(task.fork(lambda x: x, lambda x: x), float)
    assert task.fork(lambda x: x, lambda x: x) == 0.5


# Generated at 2022-06-21 19:42:03.351839
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject('error')
        resolve('data')
    task = Task(fork)

    assert task.fork(print, print) == None


# Generated at 2022-06-21 19:43:53.703899
# Unit test for method bind of class Task
def test_Task_bind():
    value = lambda name: Task.of(lambda age: Task.of((name, age)))

    t1 = value("Alex")
    t2 = value("Nikita")

    t3 = t1.bind(lambda name: value(name).map(lambda age: age(33)))
    t4 = t2.bind(lambda name: value(name).map(lambda age: age(25)))

    assert t3.fork(None, None) == (("Alex", 33), True)
    assert t4.fork(None, None) == (("Nikita", 25), True)

# Generated at 2022-06-21 19:43:59.072865
# Unit test for constructor of class Task
def test_Task():
    def fork_mock(reject, resolve):
        assert isinstance(reject, types.FunctionType)
        assert isinstance(resolve, types.FunctionType)

    task = Task(fork_mock)

    assert task is not None


# Generated at 2022-06-21 19:44:10.451770
# Unit test for method bind of class Task
def test_Task_bind():
    test_passed = True

    def resolve(value):
        assert value == "RIGHT_VALUE"

    def rejected(value):
        assert value == "RIGHT_ERROR"

    def right_value():
        # type: () -> Task[error_value, right_value]
        return Task.of("RIGHT_VALUE")

    def right_value_with_error():
        # type: () -> Task[error_value, right_value]
        return Task.of("RIGHT_ERROR").reject()

    def error_value():
        # type: () -> Task[error_value, right_value]
        return Task.reject("RIGHT_ERROR")


# Generated at 2022-06-21 19:44:18.214061
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for correct working bind method of class Task
    """

    task = Task.of(2).bind(lambda val: Task.of(val * 3))
    assert task.fork(None, lambda resolved: resolved == 6)

    task = Task.of(2).bind(lambda _: Task.reject("error"))
    assert task.fork(lambda rejected: rejected == "error", None)

    task = Task.reject("error").bind(lambda _: Task.of(2))
    assert task.fork(lambda rejected: rejected == "error", None)
