

# Generated at 2022-06-21 19:34:26.005657
# Unit test for method bind of class Task
def test_Task_bind():
    """return string"""
    def func1():
        return 1

    def func2(data):
        return str(data)

    def t2(reject, resolve):
        resolve(func1())

    def t3(reject, resolve):
        resolve(func2(1))

    t3 = Task(t3)
    t2 = Task(t2)
    assert Task.of(1).bind(func2) == Task.of(1).map(func2)
    assert Task.bind(None, t3) == Task.of(1).map(func2)
    assert Task.bind(None, t2) == Task.of(1).map(func1)


# Generated at 2022-06-21 19:34:36.847986
# Unit test for method bind of class Task
def test_Task_bind():
    # Create Task fork function with resolve and reject attributes
    task_fork = lambda reject, resolve: resolve(1)

    # Create Task with fork function
    task = Task(task_fork)

    # Create expected function to bind
    def fn(arg):
        return Task.of(arg + 1)

    # Bind function
    result = task.bind(fn)

    # Assert Task fork function is called
    class TaskSpy(Task):
        def __init__(self, fork):
            self.fork = fork

        def fork(self, reject, resolve):
            resolve(1)

    # Create Task with fork function
    task = TaskSpy(task_fork)

    # Bind function
    result = task.bind(fn)

    # Find result of bind function
    assert result.fork(lambda _: None, lambda result: result)

# Generated at 2022-06-21 19:34:46.168329
# Unit test for method map of class Task
def test_Task_map():
    def wait_job():
        return Task(lambda reject, resolve: resolve(3))

    def resolve_fn(value):
        return value

    def reject_fn(value):
        return value

    # Positive example
    test_task = Task.of(1)
    assert test_task.fork(reject_fn, resolve_fn) == 1
    assert test_task.map(lambda val: val * 2).fork(reject_fn, resolve_fn) == 2
    assert test_task.map(lambda val: val + 2).fork(reject_fn, resolve_fn) == 3
    assert test_task.map(lambda val: val ** 2).fork(reject_fn, resolve_fn) == 1

    # Negative example
    test_task = Task.reject(5)

# Generated at 2022-06-21 19:34:49.670757
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    a = Task.of(3)
    res = a.map(lambda x: add(x, 2)).fork(None, None)
    assert res == 5



# Generated at 2022-06-21 19:34:55.954875
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve("true")

    def mapper_func(result):
        assert result == "true"
        return Task.of("mapped_true")

    task = Task(fork)
    mapped_task = task.bind(mapper_func)
    assert mapped_task.fork(lambda _: None, lambda _: None) == "mapped_true"


# Generated at 2022-06-21 19:34:58.284486
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task, that it should store all properties
    """
    assert Task(lambda _, __: 1).fork(None, None) == 1



# Generated at 2022-06-21 19:35:05.459840
# Unit test for method map of class Task
def test_Task_map():
    def assert_map(task, value):
        assert task.map(lambda el: value).fork(
            lambda arg: arg,
            lambda arg: arg
        ) == value

    assert_map(Task.of(123), 1)
    assert_map(Task.of(2), 3)
    assert_map(Task.of('abc'), 'afewfe')
    assert_map(Task.of(123.12), 123)


# Generated at 2022-06-21 19:35:09.013540
# Unit test for method map of class Task
def test_Task_map():
    def test(value):
        return value * 2

    task = Task.of(2)
    task_map = task.map(test)
    assert task_map.fork(None, test) == 4

    def test2(value):
        return value * 3

    task = Task.of(2)
    task_map = task.map(test2)
    assert task_map.fork(None, test2) == 6



# Generated at 2022-06-21 19:35:11.975883
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind method should return result of called mapper function
    """
    assert Task.of('value').bind(lambda x: Task.of(x * 2)).fork(
        lambda error: None,
        lambda value: value
    ) == 'valuevalue'



# Generated at 2022-06-21 19:35:17.631708
# Unit test for method map of class Task
def test_Task_map():
    def successful_task():
        return Task(lambda reject, resolve: resolve(42))

    def failed_task():
        return Task(lambda reject, resolve: reject(42))

    def add(arg):
        return arg + 1

    assert successful_task().map(add).fork(lambda x: x, lambda x: x) == 43, 'Map test failed'
    assert failed_task().map(add).fork(lambda x: x, lambda x: x) == 42, 'Map test failed'


# Generated at 2022-06-21 19:35:22.782229
# Unit test for constructor of class Task
def test_Task():
    def reject(_, __):
        raise Exception

    def resolve(_, __):
        raise Exception

    assert Task(reject).fork == reject
    assert Task(resolve).fork == resolve


# Generated at 2022-06-21 19:35:24.434965
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(2)).fork(lambda _: 1, lambda arg: arg) == 2


# Generated at 2022-06-21 19:35:31.036419
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_with_Task_reject(arg):
        return Task.reject(arg)

    def fn_with_Task_resolve(arg):
        return Task.of(arg)

    assert Task.of(10) \
        .bind(fn_with_Task_reject) \
        .fork(lambda arg: arg, None) == 10

    assert Task.of(10) \
        .bind(fn_with_Task_resolve) \
        .fork(None, lambda arg: arg) == 10



# Generated at 2022-06-21 19:35:33.198373
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('error')

    task = Task(fork)
    assert task.fork is fork


# Generated at 2022-06-21 19:35:35.400169
# Unit test for method map of class Task
def test_Task_map():
    assert Task(
        lambda _, resolve: resolve(1)
    ).map(lambda x: x + 4).fork(lambda _: False, lambda x: x == 5)


# Generated at 2022-06-21 19:35:38.744217
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(10).fork(lambda _: None, lambda arg: arg) == 10
    assert Task.reject(10).fork(lambda arg: arg, lambda _: None) == 10


# Generated at 2022-06-21 19:35:42.686235
# Unit test for constructor of class Task
def test_Task():
    # Create task with anonymous function
    task = Task.of(None)
    assert isinstance(task, Task)

    # Create task with lambda function
    task = Task(lambda _, resolve: resolve(1))
    assert isinstance(task, Task)



# Generated at 2022-06-21 19:35:50.342146
# Unit test for method map of class Task
def test_Task_map():
    def test_1_map():
        def mapper(value):
            return value * 2

        def fork(reject, resolve):
            return resolve(2)

        task = Task(fork)
        result = task.map(mapper).fork(None, lambda value: value)
        expected = 4

        assert (result == expected)

    def test_2_map():
        def mapper(value):
            return value * 2

        def fork(reject, resolve):
            return resolve(10)

        task = Task(fork)
        result = task.map(mapper).fork(None, lambda value: value)
        expected = 20

        assert (result == expected)

    def test_3_map():
        def mapper(value):
            return value * 2


# Generated at 2022-06-21 19:35:54.338127
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(fn)
    assert task.fork(None, lambda value: value) == 2



# Generated at 2022-06-21 19:36:00.008578
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve():
        return Task.reject('C')

    def reject():
        return Task.reject('D')

    assert Task.reject('A').bind(resolve).fork(
        lambda arg: 'A',
        lambda arg: 'B'
    ) == 'A'

    assert Task.of('A').bind(reject).fork(
        lambda arg: 'A',
        lambda arg: 'B'
    ) == 'A'


# Generated at 2022-06-21 19:36:09.846971
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task(lambda reject, resolve: resolve(1))
    inc_task = task.bind(lambda arg: Task(lambda reject, resolve: resolve(arg + 1)))
    assert inc_task.fork(lambda arg: arg, lambda arg: arg) == 2, "inc_task not equal 2"
    task = Task(lambda reject, resolve: reject(1))
    inc_task = task.bind(lambda arg: Task(lambda reject, resolve: resolve(arg + 1)))
    assert inc_task.fork(lambda arg: arg, lambda arg: arg) == 1, "inc_task not equal 2"


# Generated at 2022-06-21 19:36:19.170827
# Unit test for method bind of class Task
def test_Task_bind():
    def foo(_, resolve):
        resolve('foo')

    def bar(_, resolve):
        resolve('bar')

    def baz(reject, resolve):
        reject('baz')

    def qux(reject, resolve):
        resolve('qux')

    assert Task(foo).bind(lambda _: Task(bar)).fork(lambda _: None, lambda arg: arg) == 'bar'
    assert Task(foo).bind(lambda _: Task(baz)).fork(lambda arg: arg, lambda _: None) == 'baz'
    assert Task(baz).bind(lambda _: Task(qux)).fork(lambda arg: arg, lambda _: None) == 'baz'

# Generated at 2022-06-21 19:36:22.128164
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return "Hello"

    task = Task(fork)

    assert isinstance(task, Task)
    assert task.fork(lambda x: "rejected", lambda x: "resolved") == "Hello"



# Generated at 2022-06-21 19:36:24.190253
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(3).map(lambda val: val + 1).map(lambda val: val + 1)

    assert task.fork(None, lambda val: val) == 5


# Generated at 2022-06-21 19:36:26.437031
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve(2)

    task = Task(fork)
    mapped = task.map(lambda value: value * 2)

# Generated at 2022-06-21 19:36:29.101263
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return 'fork called'

    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-21 19:36:33.871429
# Unit test for constructor of class Task
def test_Task():
    resolve = lambda value: value
    reject = lambda value: value
    assert Task(lambda _, resolve: resolve(None)).fork(reject, resolve) == None
    assert Task(lambda reject, _: reject(None)).fork(reject, resolve) == None


# Generated at 2022-06-21 19:36:36.547526
# Unit test for constructor of class Task
def test_Task():
    """
    Check Task initialisation and fork result.
    """
    fork = lambda _, resolve: resolve(2)
    task = Task(fork)

    assert isinstance(task, Task)
    assert task.fork is fork



# Generated at 2022-06-21 19:36:45.033590
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method.

    :returns: True if test is successful
    :rtype: Bool
    """
    def add_one(x):
        return x + 1

    def add_one_async(x):
        return Task.of(x + 1)

    def reject(x):
        return Task.reject(x + 1)

    def reject_async(x):
        return Task.reject(x + 1)

    assert Task(lambda _, resolve: resolve(1)).map(
        add_one
    ).fork(lambda _: False, lambda x: x)

    assert Task(lambda _, resolve: resolve(1)).map(
        add_one_async
    ).fork(lambda _: False, lambda x: x)

    assert Task(lambda reject, _: reject(1)).map

# Generated at 2022-06-21 19:36:47.939562
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return Task.of(x + 1)

    assert Task.of(1).map(add).fork(None, lambda x: x) == 2


# Generated at 2022-06-21 19:36:56.248534
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1)\
        .map(lambda value: value + 1)\
        .fork(lambda _: assert_(False), lambda value: assert_(2, value))\
        is None


# Generated at 2022-06-21 19:37:04.126918
# Unit test for method map of class Task
def test_Task_map():
    def test_map_on_resolved_task():
        task = Task.of(1)
        mapped_task = task.map(lambda arg: arg + 1)
        assert mapped_task.fork(None, lambda val: val) == 2

    def test_map_on_rejected_task():
        task = Task.reject(1)
        mapped_task = task.map(lambda arg: arg + 1)
        assert mapped_task.fork(lambda val: val, None) == 1

    test_map_on_resolved_task()
    test_map_on_rejected_task()


# Generated at 2022-06-21 19:37:09.069452
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def test_case(value):
        """
        Create Task and apply binding to it.

        :param value: value for apply binding
        :type value: A
        :returns: result of binding
        :rtype: A | B
        """
        def mock_fork(reject, resolve):
            resolve(value)

        task = Task(mock_fork)
        bind_fn = lambda value: Task.of(value + 2)

        return task.bind(bind_fn).fork(lambda value: value, lambda value: value)

    assert test_case(5) == 7
    assert test_case(24) == 26
    assert test_case(100) == 102



# Generated at 2022-06-21 19:37:19.129242
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + "!"

    value = "Hello world"

    task_resolve = Task.of(value)
    task_resolve_mapped = task_resolve.map(fn)
    t_resolve = task_resolve_mapped.fork(
        lambda value: "reject: " + value,
        lambda value: "resolve: " + value
    )

    assert t_resolve == "resolve: " + fn(value)

    task_reject = Task.reject(value)
    task_reject_mapped = task_reject.map(fn)
    t_reject = task_reject_mapped.fork(
        lambda value: "reject: " + value,
        lambda value: "resolve: " + value
    )

    assert t_

# Generated at 2022-06-21 19:37:22.263362
# Unit test for constructor of class Task
def test_Task():
    def result(reject, resolve):
        assert reject is None, "reject is %s" % reject
        assert resolve is None, "resolve is %s" % resolve
    task = Task(result)

    assert task.fork is result


# Generated at 2022-06-21 19:37:29.373474
# Unit test for method map of class Task
def test_Task_map():
    def test_map_Task_of(value):
        def plus_10(value):
            return value + 10

        assert Task.of(value).map(plus_10).fork(lambda _: _, lambda __: __) == value + 10

    def test_map_Task_reject(value):
        def plus_10(value):
            return value + 10

        assert Task.reject(value).map(plus_10).fork(lambda _: _, lambda __: __) == value

    test_map_Task_of(8)
    test_map_Task_reject(8)


# Generated at 2022-06-21 19:37:34.089586
# Unit test for method bind of class Task
def test_Task_bind():
    t = lambda x: x
    a = Task.of(5)
    b = Task.of(lambda x: x)
    c = b.bind(lambda fn: Task.of(t(fn(5))))
    assert c.fork(t, t) == b.fork(t, t)(5)(5)

# Generated at 2022-06-21 19:37:44.361088
# Unit test for method bind of class Task
def test_Task_bind():
    def positive(resolve, reject):
        return resolve(10)

    def mapped(value):
        return value + 5

    def negative(resolve, reject):
        return reject(20)


# Generated at 2022-06-21 19:37:47.907939
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve(2)

    def mapper(value):
        return value + 1

    task = Task(fork)
    result = task.map(mapper).fork(lambda _: False, lambda arg: arg == 3)

    assert result


# Generated at 2022-06-21 19:37:52.665372
# Unit test for method bind of class Task
def test_Task_bind():
    def get_id(id):
        if id == 0:
            return Task.reject('Not found user')

        def get_user(user):
            return Task.of(user)

        return Task.of({'id': id}).bind(get_user)

    assert Task.of(1).bind(get_id).fork(lambda x: x, lambda x: None) == {'id': 1}
    assert Task.reject(0).bind(get_id).fork(lambda x: x, lambda x: None) == 'Not found user'

# Generated at 2022-06-21 19:38:10.013394
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method map of class Task.
    """
    # define mapping function
    def f(x):
        return x + 1

    # define Task
    task = Task.of(1)

    # map this Task
    mapped = task.map(f)

    # check Task
    assert Task.of(f(1)).fork(lambda x: x, lambda x: x) == mapped.fork(lambda x: x, lambda x: x)



# Generated at 2022-06-21 19:38:19.655451
# Unit test for method map of class Task
def test_Task_map():
    """
    Test next scenarios:
    1. Call map method on Task with resolved resolve attribute.
    2. Call map method on Task with rejected resolve attribute.
    3. Call map method with not callable argument.
    """
    def fork_resolve(reject, resolve):
        """
        Resolve with integer value 5.

        :param reject: reject function
        :type reject: Function(reject_value)
        :param resolve: resolve function
        :type resolve: Function(resolve_value)
        """
        resolve(5)

    def fork_reject(reject, resolve):
        """
        Reject with string value 'bad'.

        :param reject: reject function
        :type reject: Function(reject_value)
        :param resolve: resolve function
        :type resolve: Function(resolve_value)
        """

# Generated at 2022-06-21 19:38:21.427973
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(lambda _: None, lambda _: None) == 1
    assert Task(lambda reject, _: reject(None)).fork(lambda _: None, lambda _: None) == None


# Generated at 2022-06-21 19:38:25.294274
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(x):
        return Task.of(x + x)

    result = Task.of(3).bind(fn)
    assert result.fork(lambda x: x, lambda x: x) == 6



# Generated at 2022-06-21 19:38:29.776759
# Unit test for method bind of class Task
def test_Task_bind():
    class AA:
        pass

    class BB:
        pass

    def call_hook(reject, resolve):
        return reject(AA())

    def fn(value):
        return Task.of(BB())

    is_right = True
    task = Task(call_hook)
    task.bind(fn)

    assert is_right, "Should be True"


# Generated at 2022-06-21 19:38:35.203382
# Unit test for method bind of class Task
def test_Task_bind():
    test_task = Task.of(1).bind(lambda a: Task.of(a + 1))
    assert test_task.fork(lambda a: False, lambda a: True) == 2
    assert test_task.map(lambda a: a + 1).fork(lambda a: False, lambda a: True) == 3


# Generated at 2022-06-21 19:38:39.500503
# Unit test for method bind of class Task
def test_Task_bind():
    def test(value):
        return Task.of(value * 2)

    assert Task.of(1).bind(test).fork(lambda _: None, lambda a: a) == 2
    assert Task.reject(1).bind(test).fork(lambda a: a, lambda _: None) == 1


# Generated at 2022-06-21 19:38:45.557241
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve("foo")).fork(lambda _: "rejected", lambda value: f"resolved: {value}") == "resolved: foo"
    assert Task(lambda reject, _: reject("foo")).fork(lambda value: f"rejected: {value}", lambda _: "resolved") == "rejected: foo"


# Generated at 2022-06-21 19:38:53.699453
# Unit test for method bind of class Task
def test_Task_bind():
    @Task.of
    def create(value):
        return value

    @Task.of
    def increment(value):
        return value + 1

    task = create(0).bind(increment)
    expected_fork_result = 1
    assert task.fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == expected_fork_result

    @Task.of
    def decrement(value):
        return value - 1
    task = create(0).bind(decrement)
    expected_fork_result = -1
    assert task.fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == expected_fork_result

# Generated at 2022-06-21 19:38:56.618204
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(1)

    def fn(value):
        return value + 1

    task = Task(fork)
    mappedTask = task.map(fn)
    assert mappedTask.fork(_, resolve=lambda arg: arg) == 2


# Generated at 2022-06-21 19:39:24.605390
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda arg: arg, lambda arg: arg) == 1
    assert Task.reject(2).fork(lambda arg: arg, lambda arg: arg) == 2

    @Task
    def fork(reject, resolve):
        resolve(1)

    assert fork.fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-21 19:39:32.876156
# Unit test for method map of class Task
def test_Task_map():
    def identity(value):
        return value

    # doing the same with Task
    task = Task.of(5)
    task2 = task.map(identity)
    assert task2.fork(lambda _: False, lambda x: x == 5)

    # mapping a number to its string representation
    task = Task.of(5)
    task2 = task.map(str)
    assert task2.fork(lambda _: False, lambda x: x == "5")

    task = Task.reject("ERROR")

    task2 = task.map(identity)
    assert task2.fork(lambda e: e == "ERROR", lambda _: False)



# Generated at 2022-06-21 19:39:39.326599
# Unit test for constructor of class Task
def test_Task():
    t1 = Task.reject('reject')
    t2 = Task.of(42)
    assert t1.fork(lambda v: v, lambda v: None) == 'reject'
    assert t2.fork(lambda v: None, lambda v: v) == 42


# Generated at 2022-06-21 19:39:41.997569
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    assert Task
    assert Task.reject
    assert Task.of
    assert Task(lambda _, __: None)



# Generated at 2022-06-21 19:39:44.529069
# Unit test for constructor of class Task
def test_Task():
    value = [1, 2, 3]
    task = Task.of(value)
    assert task.fork(lambda: False, lambda value: value == [1, 2, 3])


# Generated at 2022-06-21 19:39:48.519565
# Unit test for constructor of class Task
def test_Task():
    def fn(reject, resolve):
        """
        Function to calls during fork
        """
        return reject('test_reject_value')

    result = Task(fn)

    assert result.fork == fn


# Generated at 2022-06-21 19:39:54.172016
# Unit test for method map of class Task
def test_Task_map():
    def f(a): return a
    def g(a): return a + 1

    assert Task.of(1).map(f) is not None
    assert Task.of(1).map(g) is not None
    assert Task.of(1).map(f).fork(lambda x:x, lambda x:x) == 1
    assert Task.of(1).map(g).fork(lambda x:x, lambda x:x) == 2


# Generated at 2022-06-21 19:39:57.234341
# Unit test for constructor of class Task
def test_Task():
    """
    :returns: Nothing
    :rtype: None
    """
    def fork(reject, resolve):
        resolve(1)

    assert Task(fork).fork is fork


# Generated at 2022-06-21 19:40:03.868142
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x * 2

    def fn2(x):
        return Task.of(x * 2)

    task = Task.of(2)
    task2 = task.map(fn)
    task3 = task.bind(fn2)

    assert task.fork(None, lambda x: x) == 2
    assert task2.fork(None, lambda x: x) == 4
    assert task3.fork(None, lambda x: x) == 4


# Generated at 2022-06-21 19:40:08.734020
# Unit test for method map of class Task
def test_Task_map():
    def identity(x):
        return x

    def add(x, y):
        return x + y

    def throw(exception):
        raise exception

    # Identity
    assert Task.of(1).map(identity).fork(lambda x: None, lambda x: x) == 1
    # Composition
    assert Task.of(1).map(lambda x: add(x, 1)).map(lambda x: add(x, 1)).fork(lambda x: None, lambda x: x) == 3


# Generated at 2022-06-21 19:40:58.527140
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value.upper()

    task = Task.of('test').map(mapper)
    assert task.fork(
        lambda value: 'is invalid',
        lambda value: 'is valid'
    ) == 'is valid'


# Generated at 2022-06-21 19:41:06.070941
# Unit test for constructor of class Task
def test_Task():
    task1 = Task(lambda reject, resolve: resolve(2))
    assert task1.fork(
        lambda arg: "The second argument is not callable",
        lambda arg: arg * 2
    ) == 4

    task2 = Task.of(2)
    assert task2.fork(
        lambda arg: "The second argument is not callable",
        lambda arg: arg * 2
    ) == 4

    task3 = Task.reject(2)
    assert task3.fork(
        lambda arg: arg * 2,
        lambda arg: "The first argument is not callable"
    ) == 4



# Generated at 2022-06-21 19:41:14.860240
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task

    :returns: None
    :rtype: None
    """
    def fail(arg):
        return Task.reject(arg)

    def successful(arg):
        return Task.of(arg + 1)

    def test(scenario, fn, value, expected):
        """
        Test for method bind of Task

        :param scenario: name of scenario
        :type scenario: str
        :param fn: function to testing
        :param fn: Task.of[Function(arg) -> Task]
        :param value: value for testing
        :type value: Any
        :param expected: expected result
        :type expected: str
        :returns: None
        :rtype: None
        """

# Generated at 2022-06-21 19:41:17.728411
# Unit test for method map of class Task
def test_Task_map():
    def test_map(reject, resolve):
        resolve(1)

    assert Task(test_map).map(lambda arg: arg + 1).fork(lambda arg: None, lambda arg: arg) == 2


# Generated at 2022-06-21 19:41:23.814010
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task

    :returns: None (for assert)
    :rtype: NoneType
    """
    def mapper(value):
        """
        Test mapper function.

        :param value: value to map and return in Task
        :type value: A
        :returns: mapped value
        :rtype: A
        """
        return value

    assert Task(lambda reject, resolve: resolve(1)).bind(mapper).fork(lambda reject, resolve: assertEqual(1, resolve))


# Generated at 2022-06-21 19:41:28.334419
# Unit test for method bind of class Task
def test_Task_bind():
    def __fork(reject, resolve):
        resolve(1)

    def __reject(value):
        print("reject: " + str(value))

    def __resolve(value):
        print("resolve: " + str(value))

    def __map(value):
        return Task.of(value + 5)

    def __task(value):
        return Task.of(value + 3)

    task = Task(__fork)
    bind_task = task.bind(__map)
    bind_task.fork(__reject, __resolve) # out: reject: 1

    task = Task(__fork)
    bind_task = task.bind(__task)
    bind_task.fork(__reject, __resolve) # out: resolve: 4



# Generated at 2022-06-21 19:41:34.764133
# Unit test for method map of class Task
def test_Task_map():
    task_rejected = Task.reject('error on fork')
    task_resolved = Task.of(1)

    assert task_rejected.map(lambda x: x + 1).fork(
        lambda arg: arg,
        lambda result: result
    ) == 'error on fork'
    assert task_resolved.map(lambda x: x + 1).fork(
        lambda arg: arg,
        lambda result: result
    ) == 2


# Generated at 2022-06-21 19:41:42.150385
# Unit test for method bind of class Task
def test_Task_bind():
    def callback_reject(value):
        reject_result = value
        return reject_result

    def callback_resolve(value):
        resolve_result = value
        return resolve_result

    def mapper(value):
        if value == "ab":
            return Task.of("ABC")
        elif value == "c":
            return Task.reject("123")
        else:
            return Task.of("XYZ")

    task = Task.of(None)
    task = task.bind(lambda _: Task.of("ab")).map(lambda x: x + x).bind(mapper)
    task.fork(callback_reject, callback_resolve)

test_Task_bind()

# Generated at 2022-06-21 19:41:51.069106
# Unit test for method map of class Task
def test_Task_map():
    def add(*args):
        return sum(args)

    def identity(value):
        return value

    def spy(reject, resolve):
        resolve(spy.value)

    spy.value = 5
    assert Task(spy).map(identity).fork(None, lambda value: value) == 5
    assert Task(spy).map(lambda arg: arg + 5).fork(None, lambda value: value) == 10
    assert Task(spy).map(add, 5).fork(None, lambda value: value) == 10


# Generated at 2022-06-21 19:41:52.829314
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: resolve('hello')).fork(lambda x: None, lambda x: None) == 'hello'
    assert Task(lambda reject, resolve: reject('hello')).fork(lambda x: None, lambda x: None) == 'hello'


# Generated at 2022-06-21 19:43:47.576856
# Unit test for constructor of class Task
def test_Task():
    def success_fork(_, resolve):
        resolve(1)

    t0 = Task(success_fork)

    assert isinstance(t0, Task)



# Generated at 2022-06-21 19:43:51.229604
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    task = task.bind(lambda arg: Task.of(arg + 1))
    assert task.fork(
        lambda arg: reject(arg),
        lambda arg: resolve(arg)
    ) == 2

# Generated at 2022-06-21 19:43:53.252435
# Unit test for method map of class Task
def test_Task_map():
    def function(value):
        return value * 2

    assert Task.of(2).map(function).fork(None, lambda arg: arg) == 4


# Generated at 2022-06-21 19:43:58.389450
# Unit test for method bind of class Task
def test_Task_bind():
    calls = []

    def handle_success(value):
        calls.append('success')

    def handle_failure(error):
        calls.append('failure')

    def get_value():
        return 42

    def add_one(value):
        return value + 1

    def error(value):
        return Task.reject(value)

    def task_of():
        return Task.of(get_value())

    def task_of_one():
        return Task.of(1)

    Task.of(get_value()) \
        .map(Task.of) \
        .bind(task_of) \
        .bind(lambda x: task_of()) \
        .bind(add_one) \
        .fork(handle_failure, handle_success)

    actual = calls
    expected = ['success']

# Generated at 2022-06-21 19:44:06.733473
# Unit test for constructor of class Task
def test_Task():
    def fork_a(reject, resolve):
        resolve('a')
    task_a = Task(fork_a)
    assert task_a.fork(lambda x: x + 'b', lambda x: x + 'c') == 'ac'

    def fork_b(reject, resolve):
        reject('b')
    task_b = Task(fork_b)
    assert task_b.fork(lambda x: x + 'b', lambda x: x + 'c') == 'bb'


# Generated at 2022-06-21 19:44:10.375396
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda arg: Task.of(arg + 1)).fork(None, lambda result: result) == 2
    assert Task.of(1).bind(lambda arg: Task.reject(arg + 1)).fork(lambda result: result, None) == 2

# Test for method of of class Task

# Generated at 2022-06-21 19:44:13.660642
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('test')

    with pytest.raises(TypeError):
        Task(None)

    assert isinstance(Task(fork), Task)
