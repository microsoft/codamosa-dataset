

# Generated at 2022-06-21 19:34:19.963714
# Unit test for method map of class Task
def test_Task_map():
    # mock task
    task = Task(lambda reject, resolve: resolve(1))

    # check map method
    assert task.map(lambda x: 2 * x).fork(None, assert_equal(2))


# Generated at 2022-06-21 19:34:23.535539
# Unit test for method map of class Task
def test_Task_map():
    chain = Task.of(2)\
        .map(lambda x: x + 1)\
        .map(lambda x: x * 2)\
        .map(lambda x: x ** 2)

    assert chain.fork(lambda e: e, lambda a: a) == 16


# Generated at 2022-06-21 19:34:29.248355
# Unit test for constructor of class Task
def test_Task():
    def identity(x):
        return x

    task = Task.of(10)
    assert task.map(identity).fork(None, identity) == 10

    task = Task.reject(10)
    assert task.map(identity).fork(identity, None) == 10


# Generated at 2022-06-21 19:34:31.761149
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda value: value + 2).fork(None, lambda resolve: resolve) == 3


# Generated at 2022-06-21 19:34:37.652380
# Unit test for constructor of class Task
def test_Task():
    """
    Test task with resolve "foo" and reject "bar"
    """
    task = Task(lambda reject, resolve: resolve('foo'))

# Generated at 2022-06-21 19:34:47.132651
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a1, a2):
        return Task.of(a1 + a2)

    def mul(a1, a2):
        return Task.of(a1 * a2)

    def result(a1, a2, a3):
        return (a1, a2, a3)

    def local_test():
        test_value_0 = 2
        test_value_1 = 1


# Generated at 2022-06-21 19:34:57.544504
# Unit test for method bind of class Task
def test_Task_bind():
    day_generator = Task.reject("day")
    night_generator = Task.reject("night")

    time = True
    if time:
        time_generator = day_generator
    else:
        time_generator = night_generator

    def get_time(time):
        return Task.of(time)

    def task_from_time(time):
        if time:
            return day_generator
        else:
            return night_generator


    check_task_from_time = Task.of(time)\
        .bind(task_from_time)\
        .fork(print, print)

    check_time_generator = time_generator\
        .fork(print, print)



# Generated at 2022-06-21 19:35:01.325803
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject('Test error')
        resolve('Test value')

    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-21 19:35:04.832965
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(5)

    task = Task(fork)
    assert task.fork(lambda x: x, lambda x: x) == 5

# Generated at 2022-06-21 19:35:09.030665
# Unit test for method map of class Task
def test_Task_map():
    assert isinstance(
        Task.of(42).map(lambda x: x + 1),
        Task
    )
    assert Task.of(42).map(lambda x: x + 1).fork(
        lambda x: x,
        lambda x: x
    ) == 43


# Generated at 2022-06-21 19:35:15.450550
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject(10)
        resolve(20)
    task = Task(fork)

    assert isinstance(task.fork, FunctionType)
    assert task.fork(
        lambda arg: None,
        lambda arg: None
    ) is None


# Generated at 2022-06-21 19:35:19.861810
# Unit test for method map of class Task
def test_Task_map():
    value = 10
    def fn(x):
        return x + 10

    task = Task.of(value)
    result_task = task.map(fn)

    assert isinstance(result_task, Task)

    def wrapper(reject, resolve):
        resolve(result_task.fork(reject, resolve))
    task = Task(wrapper)

    assert task.fork(lambda value: False, lambda value: value == fn(value))



# Generated at 2022-06-21 19:35:21.960714
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(_, _) == 1
    assert Task(lambda reject, _: reject(None)).fork(_, _) == None



# Generated at 2022-06-21 19:35:25.079013
# Unit test for method map of class Task
def test_Task_map():
    count = 0
    def test(res, rej):
        nonlocal count
        count += 1
        rej(0)
        return 1

    def test2(value):
        return value + 1

    task = Task(test).map(test2)
    result = task.fork(lambda v: v, lambda v: v)
    assert count == 1, 'Task was called not one time'
    assert result == 2, 'Task should resolve result of test2'



# Generated at 2022-06-21 19:35:28.617214
# Unit test for constructor of class Task
def test_Task():
    """Check initialization of Task"""

    def fork(reject, resolve):
        return None

    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-21 19:35:34.315544
# Unit test for method map of class Task
def test_Task_map():
    """
    :returns: pytest.fail() if test not passed, nothing if passed
    :rtype: None | pytest.fail()
    """
    def test(obj):
        assert obj == 7

    task = Task.of(3).map(lambda x: x * 2).map(test)
    task.fork(lambda _: pytest.fail(), lambda _: None)


# Generated at 2022-06-21 19:35:44.790496
# Unit test for method map of class Task
def test_Task_map():
    """
    Create Task object with fork function. Call map with function add_3.
    Assert that fork is called with add_3(value).

    :returns: nothing
    :rtype: None
    """
    class DummyTask(Task):
        def __init__(self):
            def dummy_func(reject, resolve):
                self.reject_called = reject
                self.resolve_called = resolve
            super().__init__(dummy_func)

    class Dummy:
        pass

    dummy = Dummy()

    add_3 = lambda x: x + 3
    dummy_task = DummyTask()
    dummy_task_mapped = dummy_task.map(add_3)
    dummy_task_mapped.fork(dummy.reject, dummy.resolve)
    assert dummy_task

# Generated at 2022-06-21 19:35:47.666554
# Unit test for constructor of class Task
def test_Task():
    # is instance
    assert isinstance(Task(lambda _, _1: None), Task)
    # is instance with store value
    assert isinstance(Task.of(1), Task)
    assert isinstance(Task.reject(1), Task)


# Generated at 2022-06-21 19:35:51.141602
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda x: 2, lambda x: x) == 1
    assert Task.reject(1).fork(lambda x: x, lambda x: 2) == 1

# Generated at 2022-06-21 19:36:01.880099
# Unit test for constructor of class Task
def test_Task():
    from fp import Function, _
    from task import Task
    from maybe import Just, Nothing

    assert Task(10) == Task(10)

    assert Task(10) != Task(11)

    assert 10 == Task(10).fork(Function.id, Function.id)

    assert Task(Function.id) == Task(Function.id)

    assert Task(Function.id)(10) == Function.id(10)

    assert Task(Function.id)(11) == Function.id(11)

    assert Task(Function.id) != Task(Function.const(11))

    assert (
        Task.of(10).fork(Function.const(Nothing()), Just)
        == Just(10)
    )


# Generated at 2022-06-21 19:36:14.246823
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method of class Task
    """
    def resolve(value):
        """
        Return new Task with stored value argument.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task(A)
        """
        return Task.of(value ** 2)

    def reject(err):
        """
        Return new Task with stored value argument.

        :param err: value to store in Task
        :type err: A
        :returns: resolved Task
        :rtype: Task(A)
        """
        return Task.reject(err)

    task = Task.of(2)

    assert task.bind(resolve).fork(reject, resolve) == 16

# Generated at 2022-06-21 19:36:19.602268
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.
    """
    def fn(value):
        return value + 1

    def fork(_, resolve):
        return resolve(100)

    assert Task(fork).map(fn).fork(
        lambda value: (False, value),
        lambda value: (True, value)
    ) == (True, 101)


# Generated at 2022-06-21 19:36:23.274903
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve('Resolve')).fork(lambda arg: 'Reject', lambda arg: arg) == 'Resolve'
    assert Task(lambda reject, _: reject('Reject')).fork(lambda arg: arg, lambda arg: 'Resolve') == 'Reject'



# Generated at 2022-06-21 19:36:25.034182
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(1).map(lambda v: v + 2)
    assert result.fork(lambda _: None, lambda v: v) == 3


# Generated at 2022-06-21 19:36:36.046386
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method.
    """
    def to_resolve(value):
        return Task.of(value)

    # Test for bind with resolved Task
    assert Task.of(1) \
        .bind(to_resolve) \
        .fork(None, lambda arg: arg) == 1

    # Test for bind with rejected Task
    assert Task.reject(1) \
        .bind(to_resolve) \
        .fork(lambda arg: arg, None) == 1


# Task.of(1).map(lambda arg: arg * 2).fork(None, print)
# Task.of(1).bind(lambda arg: Task.of(arg * 2)).fork(None, print)

# Generated at 2022-06-21 19:36:39.708484
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        arg = {'value': 1}
        resolve(arg)

    task = Task(fork)

# Generated at 2022-06-21 19:36:46.510652
# Unit test for method map of class Task
def test_Task_map():
    def add_xy(x, y):
        return Task.of(x + y)

    def multiply_xy(x, y):
        return Task.of(x * y)

    mapped_task = Task.of(2).map(lambda x: 2 * x).bind(lambda x: Task.of(x / 2))

    assert 5 == mapped_task.fork(lambda err: None, lambda x: x)

    composed_task = Task.of(2).map(lambda x: 2 * x).bind(lambda x: multiply_xy(x, 6))

    assert 24 == composed_task.fork(lambda err: None, lambda x: x)


# Generated at 2022-06-21 19:36:48.462912
# Unit test for method bind of class Task
def test_Task_bind():
    """
    !!! TODO:
    function to test bind Task, unit test
    """
    pass



# Generated at 2022-06-21 19:36:51.207448
# Unit test for method map of class Task
def test_Task_map():
    f = Task.of(10).map(lambda x: x * 2)
    assert f.fork(lambda x: None, lambda x: x) == 20


# Generated at 2022-06-21 19:37:01.557244
# Unit test for method bind of class Task
def test_Task_bind():
    def const(value, fn):
        return fn(value)

    def add(x, y):
        return x + y

    def add_10(x):
        return Task.of(x + 10)

    def add_20(x):
        return Task.of(x + 20)

    assert const(Task.of(10), lambda x: x.bind(add_10)).fork(lambda x: x, lambda x: x) == 20
    assert const(Task.of(10), lambda x: x.bind(add_10).bind(add_20)).fork(lambda x: x, lambda x: x) == 30
    assert const(Task.reject(10), lambda x: x.bind(add_10)).fork(lambda x: x, lambda x: x) == 10


# Generated at 2022-06-21 19:37:18.311589
# Unit test for method bind of class Task
def test_Task_bind():
    @Task.of
    def return_3():
        return 3

    @Task.of
    def add_3(value):
        return value + 3

    @Task.of
    def not_task(value):
        return value + 1

    assert return_3.bind(add_3).fork(None, lambda x: x) == 6
    assert return_3.bind(add_3).bind(add_3).fork(None, lambda x: x) == 9
    try:
        return_3.bind(not_task)
    except TypeError:
        pass



# Generated at 2022-06-21 19:37:23.679886
# Unit test for method bind of class Task
def test_Task_bind():
    def make_request():
        return Task.of('json')

    def get_name(user):
        return Task.of('user name')

    def run(value):
        return Task.of(value)

    task = make_request().bind(get_name).bind(lambda user: run(user))
    assert task.fork(reject=lambda x: 1, resolve=lambda x: 2) == 2

test_Task_bind()

# Generated at 2022-06-21 19:37:26.011411
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(42))

    assert 42 == task.fork(lambda reject: -1, lambda resolve: resolve)



# Generated at 2022-06-21 19:37:31.616294
# Unit test for method map of class Task
def test_Task_map():
    called = False

    # Set flag when fn called
    def fn(arg):
        nonlocal called
        called = True
        return arg

    # Set flag when resolve called
    def resolve(arg):
        nonlocal called
        called = True
        return arg

    task = Task.of(1).map(fn)

    def assert_called():
        assert called

    task.fork(lambda _: None, assert_called)



# Generated at 2022-06-21 19:37:33.638809
# Unit test for constructor of class Task
def test_Task():
    fork = lambda reject, resolve: None
    assert Task(fork).fork is fork


# Generated at 2022-06-21 19:37:36.846571
# Unit test for method map of class Task
def test_Task_map():
    n = 5
    task = Task.of(n).map(lambda n: n + 1)
    assert task.fork(lambda arg: arg, lambda arg: arg) == n + 1


# Generated at 2022-06-21 19:37:42.658564
# Unit test for method bind of class Task
def test_Task_bind():
    def _load(timeout):
        def _defer(_):
            import time
            time.sleep(timeout)

        def _done(_):
            return Task.of(timeout)

        return Task(lambda reject, resolve: _defer(_)).bind(_done)

    task = _load(1.0)
    assert task.fork(_.__class__.__name__, lambda x: x == 1.0) == 'NoneType'


# Generated at 2022-06-21 19:37:50.994065
# Unit test for method bind of class Task
def test_Task_bind():
    def divide(what):
        return what / 2

    def square(what):
        return what * what

    def throw(what):
        raise Exception('Test error')

    # create task with chain of operations
    task = Task.of(10) \
        .bind(lambda what: Task.of(what).map(square)) \
        .bind(lambda what: Task.of(what).map(divide)) \
        .bind(lambda what: Task.of(what).map(square))

    @task
    def resolve(value):
        assert isinstance(value, int)
        assert value == 100

    @task
    def reject(value):
        assert False, 'Should be resolved'

    # create task with chain of operations and throw exception

# Generated at 2022-06-21 19:37:54.657125
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject(100)

    task = Task(fork)

    assert task.fork(lambda arg: None, lambda arg: None) == 100


# Generated at 2022-06-21 19:37:55.856405
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(10).bind(lambda value: Task.of(value + 10)).fork(lambda _: None, lambda val: val) == 20


# Generated at 2022-06-21 19:38:18.799852
# Unit test for constructor of class Task
def test_Task():
    assert Task.reject(1).fork(lambda x: x, lambda x: x) == 1
    assert Task.of(1).fork(lambda x: x, lambda x: x) == 1

# Unit tests for Task.map function

# Generated at 2022-06-21 19:38:28.406719
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind(reject, resolve) -> reject | Task.bind(reject, resolve)

    reject -> reject
    resolve -> mapping -> Task.bind(reject, resolve)
    """
    def resolve(v):
        return v + 2

    def reject(v):
        return v + 1

    # resolve
    task_resolve = Task(lambda reject, resolve: resolve(1))
    task_reject = Task(lambda reject, resolve: reject(1))

    assert task_reject.bind(resolve).fork(reject, lambda v: v) == 2
    assert task_resolve.bind(resolve).fork(reject, lambda v: v) == 3


# Generated at 2022-06-21 19:38:36.070996
# Unit test for constructor of class Task
def test_Task():
    """
    >>> Task(lambda resolve, reject: resolve(1)).fork(None, lambda x: x)
    1
    >>> Task(lambda reject, resolve: reject(1)).fork(lambda x: x, None)
    1
    >>> Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x)
    2
    >>> Task.reject(1).map(lambda x: x + 1).fork(lambda x: x, None)
    1
    >>> Task.of(1).bind(lambda x: Task.of(x + 1)).fork(None, lambda x: x)
    2
    >>> Task.reject(1).bind(lambda x: Task.of(x + 1)).fork(lambda x: x, None)
    1
    """


# Generated at 2022-06-21 19:38:41.302253
# Unit test for method map of class Task
def test_Task_map():
    """
    :returns: True
    :rtype: Bool
    """

    def add1(x):
        return x + 1

    def add5(y):
        return y + 5

    def add10(z):
        return z + 10

    assert Task.of(1) \
        .map(add1) \
        .map(add5) \
        .map(add10) \
        .fork(None, lambda result: result) == 17
    return True


# Generated at 2022-06-21 19:38:42.239901
# Unit test for constructor of class Task
def test_Task():
    pass


# Generated at 2022-06-21 19:38:52.191247
# Unit test for method map of class Task
def test_Task_map():
    def add1(value):
        return value + 1

    def fn(value):
        if value != 5:
            raise AssertionError(
                'Type "{0}" of "{1}" is not "{2}"'.format(
                    type(value),
                    value,
                    'int'
                )
            )
        if value != 6:
            raise AssertionError(
                'Argument "{0}" of "{1}" is not "{2}"'.format(
                    'value',
                    value,
                    6
                )
            )
        return 'Ok'

    Task.of(5).map(add1).map(fn).fork(
        lambda arg: print(arg),
        lambda arg: print(arg)
    )


# Generated at 2022-06-21 19:38:57.249020
# Unit test for method map of class Task
def test_Task_map():
    def identity(x):
        return x

    def add1(x):
        return x + 1

    assert Task(identity).map(add1).fork(identity, identity) == 2
    assert Task(identity).map(add1).fork(identity, identity) == 2
    assert Task(identity).map(identity).map(add1).fork(identity, identity) == 2
    assert Task.of(1).map(add1).fork(identity, identity) == 2


# Generated at 2022-06-21 19:38:59.967950
# Unit test for constructor of class Task
def test_Task():
    """
    >>> task = Task.of(10)
    >>> task.fork(lambda arg: arg, lambda arg: arg)
    10
    """
    pass


# Generated at 2022-06-21 19:39:06.898150
# Unit test for method map of class Task
def test_Task_map():
    # Test case map:
    # @param a is Task of number
    # @param f is function(int) -> string
    #
    # @assert Task[f] a
    #     ==> "1"
    a = Task.of(1)
    f = lambda a: str(a)
    assert a.map(f).fork(None, lambda v: v) == "1"


# Generated at 2022-06-21 19:39:09.068368
# Unit test for constructor of class Task
def test_Task():
    def forked(reject, resolve):
        return reject('forked')

    task = Task(forked)
    (rejected, resolved) = task.fork(lambda v: 'rejected: ' + v, lambda v: 'resolved: ' + v)

    assert rejected == 'rejected: forked'
    assert resolved is None


# Generated at 2022-06-21 19:39:53.090186
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    add1 = lambda v: Task.of(v + 1)

# Generated at 2022-06-21 19:39:59.340568
# Unit test for method bind of class Task
def test_Task_bind():
    # Task class
    assert Task is not None

    def rejecter(n):
        return Task.reject(n)

    def resolver(n):
        return Task.of(n)

    def mapper(n):
        return n + 1

    def taskCaller(task):
        return task.fork(lambda x: x, lambda x: x * x)

    assert taskCaller(Task.of(1).bind(resolver).bind(rejecter)) == 1
    assert taskCaller(Task.of(1).bind(resolver).bind(resolver)) == 4
    assert taskCaller(Task.of(1).bind(rejecter).bind(rejecter)) == 1
    assert taskCaller(Task.of(1).bind(rejecter).bind(resolver)) == 1


# Generated at 2022-06-21 19:40:07.909620
# Unit test for method bind of class Task
def test_Task_bind():
    def test_state1(resolve, reject):
        resolve(123)

    def test_state2(resolve, reject):
        reject(321)

    test_task1 = Task(test_state1)
    test_task2 = Task(test_state2)

    def test_func(arg):
        return Task(lambda resolve, reject: (
            resolve(arg * 2) if arg > 0 else reject('Error')
        ))

    assert test_task1.bind(test_func).fork(lambda _: ':(' , lambda _: ':)') == ':('
    assert test_task2.bind(test_func).fork(lambda _: ':(' , lambda _: ':)') == ':)'


# Generated at 2022-06-21 19:40:16.073154
# Unit test for method bind of class Task
def test_Task_bind():
    def inc(x):
        return x + 1
    def dec(x):
        return x - 1

    assert Task.of(3).bind(lambda x: Task.of(x + 1)).bind(dec).fork(None, lambda x: x) == 3
    assert Task.reject(3).bind(lambda x: Task.of(x + 1)).bind(dec).fork(lambda x: x, None) == 3



# Generated at 2022-06-21 19:40:18.648593
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        assert reject('resolved') == 'resolved'
        assert resolve('rejected') == 'rejected'

    assert isinstance(Task(fork), Task)


# Generated at 2022-06-21 19:40:22.560260
# Unit test for method map of class Task
def test_Task_map():
    def foo(value):
        return value + 1

    task = Task.of(1)

    assert(
        task.map(foo).fork(
            lambda arg: arg - 1,
            lambda arg: arg - 1
        ) == 1
    )


# Generated at 2022-06-21 19:40:25.453360
# Unit test for constructor of class Task
def test_Task():
    """
    Stored fork function
    """
    result = Task(lambda reject, resolve: resolve(None))
    assert result.fork == Task(lambda reject, resolve: resolve(None)).fork


# Generated at 2022-06-21 19:40:33.151395
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def test_map_on_resolved_Task():
        Task.of(1).map(add_one).fork(
            lambda arg: print('Failed with %s' % arg),
            lambda arg: print('Passed with %s' % arg)
        )

    def test_map_on_rejected_Task():
        Task.reject(1).map(add_one).fork(
            lambda arg: print('Failed with %s' % arg),
            lambda arg: print('Passed with %s' % arg)
        )

    test_map_on_resolved_Task()
    test_map_on_rejected_Task()


# Generated at 2022-06-21 19:40:38.265374
# Unit test for constructor of class Task
def test_Task():
    task = Task.of(42)
    assert task.fork(lambda f: None, lambda r: r) == 42
    assert task.fork(lambda f: True, lambda r: None) == None

    def fn(reject, resolve):
        return reject(42)
    task = Task(fn)
    assert task.fork(lambda f: f, lambda r: None) == 42



# Generated at 2022-06-21 19:40:49.302873
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        print('resolve ' + str(value))
        return value

    def reject(value):
        print('reject ' + str(value))
        return value

    Task(lambda reject, resolve: resolve(5)) \
        .map(lambda value: value + 1) \
        .fork(reject, resolve)

    print()

    Task(lambda reject, resolve: resolve(5)) \
        .map(lambda value: value + 1) \
        .map(lambda value: value + 1) \
        .fork(reject, resolve)

    print()

    Task(lambda reject, resolve: reject(5)) \
        .map(lambda value: value + 1) \
        .fork(reject, resolve)



# Generated at 2022-06-21 19:42:21.983426
# Unit test for constructor of class Task
def test_Task():
    """Unit test for constructor of class Task."""
    assert Task(lambda _, resolve: resolve(1)).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-21 19:42:27.086572
# Unit test for constructor of class Task
def test_Task():
    """
    Test of initializing Task and methods of.
    """
    def handler_resolve_empty_task(resolve, reject):
        """
        Resolve empty task.
        """
        resolve(None)

    def handler_reject_empty_task(resolve, reject):
        """
        Reject empty task.
        """
        reject('Error')

    assert Task(handler_resolve_empty_task) is not None
    assert Task(handler_reject_empty_task) is not None


# Generated at 2022-06-21 19:42:31.442127
# Unit test for method bind of class Task
def test_Task_bind():
    print('\n--test_Task_bind')

    def task_of_2():
        return Task.of(2)

    def task_of_3():
        return Task.of(3)

    def map_plus_3(_):
        return Task.of(_ + 3)

    def map_plus_3_and_deffer(_):
        return task_of_3().bind(map_plus_3)

    def map_plus_2_and_deffer(_):
        return task_of_2().bind(map_plus_3_and_deffer)

    Task.of(1).bind(map_plus_2_and_deffer).fork(
        lambda arg: print('reject:', arg),
        lambda arg: print('resolve:', arg)
    )

    Task.reject(1).bind

# Generated at 2022-06-21 19:42:38.582456
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method map of class Task
    :returns: True if ok
    :rtype: bool
    """
    task = Task.of(42)
    task = task.map(lambda value: value + 1)

    def run(reject, resolve):
        """
        Call Task fork function.
        :param reject: reject attribute
        :type reject: Function
        :param resolve: resolve attribute
        :type resolve: Function
        :returns: result of calling fork function
        :rtype: int
        """
        return task.fork(reject, resolve)

    result = run(lambda rejected_value: False, lambda value: value)

    return result == 43


# Generated at 2022-06-21 19:42:44.868093
# Unit test for method bind of class Task
def test_Task_bind():
    print("Test on method bind of class Task")
    def fn1(resolve, reject) -> Task:
        return Task.of(resolve('hello'))

    def fn2(resolve, reject) -> Task:
        return Task.of(resolve('world'))

    def add(resolve, reject) -> Task:
        return fn1(resolve, reject).bind(lambda arg: fn2(resolve, reject))

    print('Test Value:')
    print(add(lambda arg: arg, lambda arg: arg))

# Generated at 2022-06-21 19:42:52.871853
# Unit test for constructor of class Task
def test_Task():
    task = Task.of(10)
    assert task.fork(
        lambda _: "It's error!",
        lambda value: value * value
    ) == 100

    task = Task.reject(10)
    assert task.fork(
        lambda value: value * value,
        lambda _: "It's success!"
    ) == 100

    task = Task(lambda reject, resolve: resolve(10))
    assert task.fork(
        lambda _: "It's error!",
        lambda value: value * value
    ) == 100



# Generated at 2022-06-21 19:42:56.750189
# Unit test for constructor of class Task
def test_Task():
    def fn(_, resolve):
        return resolve(1)

    task = Task(fn)


# Generated at 2022-06-21 19:43:04.377361
# Unit test for method map of class Task
def test_Task_map():
    def task_of(value) -> Task:
        """
        Helper function to create Task with value.

        :param value:
        :type value: A
        :returns: resolved Task
        :rtype: Task[resolve, reject]
        """
        return Task.of(value)

    def test_two_plus_three() -> Task[resolve, reject]:
        """
        Test for map method of class Task.
        Testing with map: (number + 2) * 3
        :returns: resolved Task
        :rtype: Task[resolve, reject]
        """
        return task_of(2).map(lambda number: number + 2).map(lambda number: number * 3)


# Generated at 2022-06-21 19:43:13.255041
# Unit test for method bind of class Task
def test_Task_bind():
    def square(value):
        return value ** 2

    def double(value):
        return value * 2

    def sum(x, y):
        return x + y

    task = Task.of(5)
    task = task.bind(lambda arg: Task.of(square(arg)))
    result = task.fork(lambda arg: 0, lambda arg: arg)
    expected = 25
    try:
        assert result == expected
    except AssertionError:
        raise Exception(
            'test_Task_bind failed, actual: {0}, expected: {1}'.format(
                result, expected
            )
        ) # pragma: no cover

    task = Task.of(7)
    task = task.bind(lambda arg: Task.of(double(arg)))

# Generated at 2022-06-21 19:43:17.241556
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(arg):
        return Task.of(arg.upper())

    task = Task.of(1).map(lambda arg: str(arg))
    assert task.bind(fn).fork(lambda arg: arg, lambda arg: arg) == '1'
