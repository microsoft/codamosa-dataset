

# Generated at 2022-06-21 19:34:18.436246
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Create Task with value and return new Task with doubled value.
    """
    def task_fn(reject, resolve):
        """
        Create Task with value and return new Task with doubled value.
        """
        resolve(10)

    def task_fn_map(value):
        """
        Double value and return result.
        """
        return value * 2

    test_task = Task(task_fn)
    assert test_task.bind(task_fn_map).fork(lambda err: err, lambda result: result) == 20


# Generated at 2022-06-21 19:34:22.930671
# Unit test for method map of class Task
def test_Task_map():
    """
    Check map method of Task class.
    """
    def _identity(value):
        return value

    def resolve(value):
        assert value == 'Test_value'

    def reject(value):
        assert False, 'Must not call reject'

    Task.of('Test_value').map(_identity).fork(reject, resolve)


# Generated at 2022-06-21 19:34:35.095719
# Unit test for method map of class Task
def test_Task_map():
    @pytest.fixture
    def task():
        def fork(reject, resolve):
            resolve(2)

        return Task(fork)

    def call_fork(resolve, reject):
        raise RuntimeError

    def test_map_fn_call(mocker):
        mock = mocker.MagicMock()
        t = Task(call_fork).map(mock)
        t.fork(None, None)
        mock.assert_called_once_with(2)

    def test_map_reject_call(mocker):
        mock = mocker.MagicMock()
        t = Task(call_fork).map(None).map(None).fork(mock, None)
        mock.assert_called_once_with(2)


# Generated at 2022-06-21 19:34:45.544947
# Unit test for method map of class Task
def test_Task_map():
    # Test catch exception inside mapper function
    with assert_raises(TypeError):
        Task(lambda _, resolve: resolve("foo")) \
            .map(lambda value: 1 / 0) \
            .fork(lambda _: None, lambda value: None)

    # Test catch exception inside mapper function
    with assert_raises(TypeError):
        Task(lambda reject, _: reject("foo")) \
            .map(lambda value: 1 / 0) \
            .fork(lambda _: None, lambda value: None)

    # Test work with resolve
    assert Task(lambda _, resolve: resolve("foo")) \
            .map(lambda value: value.upper()) \
            .fork(lambda _: None, lambda value: value) \
        == "FOO"

    # Test work with reject

# Generated at 2022-06-21 19:34:49.182084
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    t = Task(fork)
    assert t.fork(lambda a: a, lambda a: a) == 1


# Generated at 2022-06-21 19:34:54.590448
# Unit test for constructor of class Task
def test_Task():
    def assert_value(task, value):
        assert value == task.fork(lambda _: None, lambda value: value)

    assert_value(Task.of(None), None)

    assert_value(Task(lambda _, resolve: resolve(None)), None)



# Generated at 2022-06-21 19:34:58.966983
# Unit test for method map of class Task
def test_Task_map():
    called = False
    def function(value):
        nonlocal called
        assert value == 1
        called = True
        return value

    Task.of(1).map(function).fork(lambda _: None,
                                  lambda _: None)

    assert called


# Generated at 2022-06-21 19:35:02.049413
# Unit test for method map of class Task
def test_Task_map():
    def add10(x):
        return x + 10

    assert Task.of(5).map(add10).fork(None, lambda value: value) == 15


# Generated at 2022-06-21 19:35:05.140583
# Unit test for constructor of class Task
def test_Task():
    """
    Test wheter constructor works well.
    """
    assert Task(lambda reject, resolve: resolve(0)).fork(_, _)



# Generated at 2022-06-21 19:35:10.115024
# Unit test for constructor of class Task

# Generated at 2022-06-21 19:35:15.495733
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + '_defined')

    task = Task.of('defined')
    assert task.bind(fn).fork(*stubs) == 'defined_defined'


# Generated at 2022-06-21 19:35:18.443912
# Unit test for method map of class Task
def test_Task_map():
    called = 0
    def fn(x):
        nonlocal called
        called += 1
        return x + 1

    task = Task.of(1).map(fn)
    assert task.fork(None, None) == 2
    assert called == 1


# Generated at 2022-06-21 19:35:21.053993
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(lambda arg: arg, lambda _: 0) == 0
    assert Task(lambda reject, _: reject(1)).fork(lambda arg: arg, lambda _: 0) == 1


# Generated at 2022-06-21 19:35:23.463776
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Call bind method of Task and return result as Promise.
    """
    return Task.of(1).bind(lambda a: Task.of(a + 1))


# Generated at 2022-06-21 19:35:29.085473
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject('reject')
        resolve('resolve')

    task = Task(fork)

    assert task.fork('reject', 'resolve') == 'reject'


# Generated at 2022-06-21 19:35:33.284472
# Unit test for method map of class Task
def test_Task_map():
    value = Task.of(1)
    mapped_value = value.map(lambda arg: arg + 1)

# Generated at 2022-06-21 19:35:40.880809
# Unit test for method map of class Task
def test_Task_map():
    # test for base case:
    # test for result
    assert Task.of(5).map(lambda x: x * 3).fork(None, lambda x: x) == 15
    # test for exception
    # assert Task.of(5).map(lambda x: x/0).fork(None, lambda: None) is ZeroDivisionError

    # test for bind case:
    # test for result
    assert Task.of(5).map(lambda x: Task.of(x * 3)).fork(None, lambda x: x) == 15
    # test for exception
    # assert Task.of(5).map(lambda x: Task.of(x/0)).fork(None, lambda: None) is ZeroDivisionError


# Generated at 2022-06-21 19:35:43.069299
# Unit test for constructor of class Task
def test_Task():
    fork = lambda _, resolve: resolve(1)
    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-21 19:35:48.342164
# Unit test for method bind of class Task
def test_Task_bind():
    def add2(value):
        return Task.of(value + 2)

    def mul10(value):
        return Task.of(value * 10)

    def pow10(value):
        return Task.reject(value ** 10)

    task = Task.of(0)
    task.bind(add2).bind(mul10).bind(pow10)

    assert task.fork(
        lambda value: value == 10,
        lambda value: False
    )

# Generated at 2022-06-21 19:35:57.956542
# Unit test for method bind of class Task
def test_Task_bind():
    def double(arg):
        return arg * 2

    def add(arg):
        return arg + 2

    def add2(arg):
        return Task.of(arg + 2)

    # check without errors
    assert Task.of(2) \
            .bind(double) \
            .bind(add) \
            .fork(None, lambda result: result == 8)

    # check with error
    assert Task.of(2) \
            .bind(lambda _: Task.reject("error")) \
            .bind(add2) \
            .fork(
                lambda error: error == "error",
                lambda _: False
            )



# Generated at 2022-06-21 19:36:07.470855
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda _, resolve: resolve(10)).bind(
        lambda value: Task.of(value * 2)
    ).fork(
        lambda error: error * 3,
        lambda value: value
    ) == 20

    assert Task(lambda reject, _: reject(10)).bind(
        lambda value: Task.of(value * 2)
    ).fork(
        lambda error: error * 3,
        lambda value: value
    ) == 30


# Generated at 2022-06-21 19:36:13.110907
# Unit test for method map of class Task
def test_Task_map():
    # resolve
    assert Task.of(42).map(lambda x: x + 1).fork(None, lambda x: x) == 43

    # reject
    assert Task.reject(42).map(lambda x: x + 1).fork(lambda x: x, None) == 42


# Generated at 2022-06-21 19:36:23.168958
# Unit test for method map of class Task
def test_Task_map():
    """
    Test function Task.map.

    :returns: None
    :rtype: None
    """
    def f1(reject, resolve):
        return resolve(1)

    def f2(reject, resolve):
        return resolve(2)

    def add_1(value):
        return value + 1

    def mul_2(value):
        return value * 2

    def sub_3(value):
        return value - 3

    def test_result_with_map_several_functions():
        """
        Test result of called Task.fork with map of several functions.

        :returns: None
        :rtype: None
        """

# Generated at 2022-06-21 19:36:27.449544
# Unit test for method bind of class Task
def test_Task_bind():
    def calc(x):
        return Task.of(x*2)
    task = Task.of(2)
    result = task.bind(calc)
    assert result.fork(None, lambda x: x) == 4


# Generated at 2022-06-21 19:36:36.590392
# Unit test for method map of class Task
def test_Task_map():
    def add_three(value):
        return value + 3

    def add_three_async(value):
        return Task.of(value + 3)

    assert Task.of(1).map(add_three).fork(None, lambda value: value) == 4
    assert Task.reject(1).map(add_three).fork(lambda value: value, None) == 1

    assert Task.of(1).bind(add_three_async).fork(None, lambda value: value) == 4
    assert Task.reject(1).bind(add_three_async).fork(lambda value: value, None) == 1

# Generated at 2022-06-21 19:36:40.553896
# Unit test for method bind of class Task
def test_Task_bind():
    task_1 = Task.of(1)
    task_2 = task_1.bind(lambda arg: Task.of(arg + arg))
    assert task_1.fork(None, None) == 1
    assert task_2.fork(None, None) == 2


# Generated at 2022-06-21 19:36:51.798802
# Unit test for constructor of class Task
def test_Task():
    # test Task.of
    task = Task.of("foo")
    assert type(task) == Task
    assert type(task.fork) == FunctionType

    def result(reject, resolve):
        resolve("bar")

    assert task.fork(reject=None, resolve=result) == "bar"

    # test Task.reject
    task = Task.reject("foo")
    assert type(task) == Task
    assert type(task.fork) == FunctionType

    def result(reject, resolve):
        reject("bar")

    assert task.fork(reject=result, resolve=None) == "bar"


# Generated at 2022-06-21 19:36:56.337258
# Unit test for method map of class Task
def test_Task_map():
    def fork(_, resolve):
        return resolve(50)

    task = Task(fork)
    mapped_task = task.map(lambda x: x + 1)

    assert task.fork(lambda x: x, lambda x: x) == 50
    assert mapped_task.fork(lambda x: x, lambda x: x) == 51


# Generated at 2022-06-21 19:36:57.872632
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(2))
    assert task.fork is not None
    assert task.fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-21 19:37:00.907286
# Unit test for method map of class Task
def test_Task_map():
    def func(a):
        return a ** 2

    assert Task.of(2).map(func).fork(lambda x: None, lambda x: x) == 4


# Generated at 2022-06-21 19:37:07.376187
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    def get_result(x):
        return Task.of(x)

    result = Task.of(2) \
        .map(add(1)) \
        .map(add(3)) \
        .bind(get_result)

    assert(result.fork(_, lambda x: x) == 6)


# Generated at 2022-06-21 19:37:16.498614
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method `map` of class `Task`.
    """
    def test_of():
        """
        Test resolved task.
        """
        task = Task.of(1).map(lambda x: x + 1)
        assert task.fork(lambda x: x, lambda x: x) == 2

    def test_reject():
        """
        Test rejected task.
        """
        task = Task.reject(1).map(lambda x: x + 1)
        assert task.fork(lambda x: x, lambda x: x) == 1

    test_of()
    test_reject()


# Generated at 2022-06-21 19:37:18.634232
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(10))
    assert task.fork(Func.id, Func.id) == 10



# Generated at 2022-06-21 19:37:27.743521
# Unit test for method bind of class Task
def test_Task_bind():
    @Task
    def get_task(reject, resolve):
        resolve(10)

    @Task
    def get_task2(reject, resolve):
        resolve(20)

    def map_fn(value):
        return value * 2

    def result(resolve, reject):
        return get_task(reject, resolve)

    assert Task(result).map(map_fn).fork(lambda reject: '', lambda resolve: resolve) == 20

    def result2(resolve, reject):
        return get_task2(reject, resolve)

    def result3(resolve, reject):
        return get_task(reject, lambda value: result2(resolve, reject))

    assert Task(result3).bind(map_fn).fork(lambda reject: '', lambda resolve: resolve) == 40



# Generated at 2022-06-21 19:37:31.228300
# Unit test for constructor of class Task
def test_Task():
    """
    >>> def fork(resolve, reject):
    ...     resolve(1)

    >>> task = Task(fork)
    >>> result = task.fork(None, lambda x: x)
    >>> result
    1
    """


# Generated at 2022-06-21 19:37:41.896552
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """
    # Return expected result
    def double(value):
        """
        Return double of received value.

        :param value: value to double
        :type value: int | float
        :returns: double of received value
        :rtype: int | float
        """
        return value * 2

    # Call Task.of with 3, create new Task with mapped value (6)
    # If new Task will be resolve (TODO: and no reject)
    # assert will be True (6 == expected_result)
    # else assert will be False
    try:
        assert 6 == Task.of(3).map(double).fork(None, lambda x: x)
    except AssertionError:
        print('Fail test_Task_map!')



# Generated at 2022-06-21 19:37:46.421743
# Unit test for method map of class Task
def test_Task_map():
    """
    Case:
    - Create Task with resolve value = 1,
    - map it with function inc and assert that new resolve value is 2.
    """
    def inc(value): return value + 1
    def reject(_): pass
    def resolve(value):
        assert value == 2

    Task.of(1).map(inc).fork(reject, resolve)


# Generated at 2022-06-21 19:37:48.910241
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value ** 2

    assert Task.of(2).map(fn).fork(
        lambda x: None,
        lambda y: y
    ) == 4


# Generated at 2022-06-21 19:37:57.020859
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    def fn2(value):
        return Task.reject(Task.of(value + 1))

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda x: x) == 2
    assert Task.of(1).bind(fn2).fork(lambda x: x, lambda _: None) == Task.of(2)
    


# Generated at 2022-06-21 19:38:03.857453
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.

    Caller of method bind get result Task value, so fork method of Task is not called.
    But it should call during caller fork method.
    """
    def test():
        task = Task.reject(1).bind(lambda x: Task.of(2))
        assert task.fork(lambda x: None, lambda x: None) == None

# Generated at 2022-06-21 19:38:12.548592
# Unit test for constructor of class Task
def test_Task():
    """
    Test create correct Task.

    :returns: None
    """
    assert Task(lambda _, resolve: resolve(1)).fork(None, identity) == 1
    assert Task.of(2).fork(None, identity) == 2
    assert Task.reject(3).fork(identity, None) == 3



# Generated at 2022-06-21 19:38:19.454357
# Unit test for method map of class Task
def test_Task_map():
    """
    Test of method map of class Task
    """
    def fork(reject, resolve):
        resolve(123)

    task = Task(fork)
    new_task = task.map(lambda value: value * 2)

    def new_fork(reject, resolve):
        resolve(value * 2)

    assert task.fork == fork
    assert new_task.fork == new_fork

    new_task = task.map(lambda value: Task.of(value * 2))
    assert new_task.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 246


# Generated at 2022-06-21 19:38:21.306639
# Unit test for method map of class Task
def test_Task_map():
    def test(value):
        return value + 1

    task = Task(lambda reject, resolve: resolve(1))
    mapped = task.map(test)
    assert mapped.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-21 19:38:24.423130
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve("ok")

    assert Task(fork).fork(lambda _: "error", lambda value: value) == "ok"


# Generated at 2022-06-21 19:38:28.598296
# Unit test for method map of class Task
def test_Task_map():
    data = [1, 2, 3, 4, 5]
    task = Task.of(data)
    mapped_task = task.map(lambda x: x ** 2)
    result = mapped_task.fork(lambda x: x, lambda x: x)
    assert result == [1, 4, 9, 16, 25]



# Generated at 2022-06-21 19:38:40.237886
# Unit test for method map of class Task
def test_Task_map():
    @pytest.fixture
    def task(request):
        def fork(reject, resolve):
            resolve(request.param)

        return Task(fork)

    @pytest.fixture
    def mapper():
        return lambda arg: arg + 1

    @pytest.fixture
    def context():
        class Context:
            def __init__(self):
                self.result = None

            def fork(self, value):
                self.result = value

        return Context()

    def test_task_map(task, mapper, context):
        task.map(mapper).fork(context.fork)

        assert context.result == mapper(task.fork(None, None))
    test_task_map.params = [1, 'Hello world!', ['1', '2', '3']]


# Generated at 2022-06-21 19:38:47.457663
# Unit test for method bind of class Task
def test_Task_bind():
    def callback(resolve):
        resolve('value')

    def mapper(value):
        return value + '_mapped'

    def task(reject, resolve):
        resolve('value')

    def task2(arg):
        return Task(task)

    result = Task(task).bind(task2)
    assert isinstance(result, Task)
    assert result.fork(lambda arg: arg + '_failed', lambda arg: arg + '_mapped') == 'value_mapped'


# Generated at 2022-06-21 19:38:48.766908
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda x: x, lambda x: x) == 1

# Generated at 2022-06-21 19:38:51.766140
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    result = task.map(lambda x: x + 1).fork(lambda x: x, lambda x: x)
    assert result == 2


# Generated at 2022-06-21 19:38:53.778282
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(5).fork(None, lambda arg: arg) == 5
    assert Task.reject(5).fork(lambda arg: arg, None) == 5


# Generated at 2022-06-21 19:39:08.742066
# Unit test for method map of class Task

# Generated at 2022-06-21 19:39:12.823079
# Unit test for method map of class Task
def test_Task_map():
    def identity(x):
        return x

    def add(x, y):
        return x + y

    task = Task.of(1)

    assert task.fork(identity, identity) == 1
    assert task.map(add).fork(identity, identity) == 2


# Generated at 2022-06-21 19:39:18.201523
# Unit test for method bind of class Task
def test_Task_bind():
    def result_task(x):
        return Task.of(x*x)

    def result_task_fail(x):
        return Task.reject(x*x)

    task = Task.of(2)
    task_fail = Task.reject(2)

    assert task.bind(result_task).fork(lambda value: value + 1, lambda value: value + 1) == 5
    assert task_fail.bind(result_task).fork(lambda value: value + 1, lambda value: value + 1) == 5

    class TestException(Exception):
        pass

    assert task.bind(result_task_fail).fork(lambda value: value + 1, lambda value: value + 1) == 5

# Generated at 2022-06-21 19:39:24.024208
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a, b):
        return a + b

    def add2(a):
        return Task.of(add(a, 2))

    assert Task.of(1).bind(add2).fork(lambda x: x, lambda x: x) == 3
    assert Task.reject(1).bind(add2).fork(lambda x: x, lambda x: x) == 1

# Generated at 2022-06-21 19:39:27.484029
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        assert reject is not None
        assert resolve is not None

    task = Task(fork)
    assert isinstance(task, Task)
    assert callable(task.fork)


# Generated at 2022-06-21 19:39:29.280422
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return "fork"

    assert Task(fork).fork == fork


# Generated at 2022-06-21 19:39:36.781355
# Unit test for method bind of class Task
def test_Task_bind():
    """
    :returns: True if it pass test, False if not
    :rtype: Boolean
    """
    def fork_one(reject, resolve):
        def callback_one():
            reject("one")

        def callback_two():
            resolve("two")
        
        random.choice((callback_one, callback_two))()

    def fork_two(reject, resolve):
        def callback_one():
            resolve("one!")

        def callback_two():
            reject("two!")
        
        random.choice((callback_one, callback_two))()

    def fork_three(reject, resolve):
        def callback_one():
            resolve("one!!")

        def callback_two():
            reject("two!!")
        
        random.choice((callback_one, callback_two))()


# Generated at 2022-06-21 19:39:43.196479
# Unit test for method bind of class Task
def test_Task_bind():
    def add_1(x):
        return x + 1

    def square(x):
        return x * x

    def test(resolve, reject):
        resolve(1)

    t = Task(test) \
        .bind(lambda x: Task.of(add_1(x))) \
        .map(square)

    assert t.fork(lambda x: x, lambda x: x) == 4

# Unit test strict equality of methods of and reject of class Task

# Generated at 2022-06-21 19:39:47.829003
# Unit test for method map of class Task
def test_Task_map():
    a = Task(lambda _, resolve: resolve(1))
    b = a.map(lambda x: x + 1)
    assert 2 == b.fork(lambda _: None, lambda res: res)


# Generated at 2022-06-21 19:39:54.887260
# Unit test for constructor of class Task
def test_Task():
    success = False

    @curry
    def fork(reject, resolve):
        """
        Example fork function
        """
        if success:
            resolve('success')
        else:
            reject('fail')

    task = Task(fork)

    # test success
    success = True
    result = task.fork(lambda arg: arg, lambda arg: arg)
    assert result == 'success'

    # test failure
    success = False
    result = task.fork(lambda arg: arg, lambda arg: arg)
    assert result == 'fail'


# Generated at 2022-06-21 19:40:05.888896
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    # --- positive cases
    # Task.of(1).map(add_one) => of(2)
    expected_result = Task.of(2)
    Test.assert_equals(Task.of(1).map(add_one).fork(lambda x: 0, lambda x: x), expected_result.fork(lambda x: 0, lambda x: x))

    # --- negative cases
    # false result
    Test.assert_equals(Task.of(1).map(add_one).fork(lambda x: 0, lambda x: x), Task.of(3).fork(lambda x: 0, lambda x: x))


# Generated at 2022-06-21 19:40:08.217572
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda value: value + 2).map(lambda value: value * 3)

    assert task.fork(lambda reject: None, lambda resolve: resolve * 2) == 9


# Generated at 2022-06-21 19:40:18.451721
# Unit test for method map of class Task
def test_Task_map():
    def f(a):
        return a + 1

    def g(a):
        return Task.of(a - 1)

    def h(a):
        return Task.reject(a - 1)

    assert Task.of(1).map(f).fork(lambda a: a, lambda b: b) == 2
    assert Task.reject(1).map(f).fork(lambda a: a, lambda b: b) == 1
    assert Task.of(1).bind(g).fork(lambda a: a, lambda b: b) == 0
    assert Task.of(1).bind(h).fork(lambda a: a, lambda b: b) == 0


# Generated at 2022-06-21 19:40:22.014384
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(10)

    # Test return type:
    assert isinstance(Task(fork).map(lambda x: x), Task)
    # Test return value:
    assert Task(fork).map(lambda x: x+10).fork(lambda x: False, lambda arg: arg == 20)


# Generated at 2022-06-21 19:40:27.731452
# Unit test for method map of class Task
def test_Task_map():
    # should return resolved task
    assert Task.of(1).map(lambda x: x + 1).fork(
        lambda x: 0,
        lambda x: x
    ) == 2
    # should return rejected task
    assert Task.reject(1).map(lambda x: x + 1).fork(
        lambda x: 0,
        lambda x: x
    ) == 0

test_Task_map()



# Generated at 2022-06-21 19:40:32.323547
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(11)
    returned_task = task.bind(lambda value: Task.of(value + 1))
    assert Task.of(12).fork(*returned_task.fork)

    task = Task.reject('error')
    returned_task = task.bind(lambda value: Task.of(value + 1))
    assert Task.reject('error').fork(*returned_task.fork)



# Generated at 2022-06-21 19:40:38.095043
# Unit test for method map of class Task
def test_Task_map():
    def _deepEqual(a, b):
        return a == b

    def fn(value):
        return value + 1

    task = Task.of(1)
    assert _deepEqual(task.map(fn).fork(None, None), fn(1))

    task = Task.reject(1)
    assert _deepEqual(task.map(fn).fork(None, None), 1)


# Generated at 2022-06-21 19:40:41.473621
# Unit test for constructor of class Task
def test_Task():
    t = Task(lambda _, __: None)
    assert isinstance(t, Task), "Constructor of Task should create instance of Task"


# Generated at 2022-06-21 19:40:46.442757
# Unit test for method map of class Task
def test_Task_map():
    def double(a):
        return a*2

    def resolve(a):
        assert a == 2

    def reject(a):
        raise Exception('Should be rejected')

    Task(lambda reject, resolve: resolve(1)).map(double).fork(reject, resolve)



# Generated at 2022-06-21 19:40:49.727479
# Unit test for constructor of class Task
def test_Task():
    # Valid construction of Task
    task = Task(lambda _, resolve: resolve(1))
    assert isinstance(task, Task)

    # Invalid construction of Task
    with pytest.raises(TypeError):
        task = Task(1)


# Generated at 2022-06-21 19:41:11.099240
# Unit test for method bind of class Task
def test_Task_bind():
    # 1. Simple bind test
    fork = Task(lambda reject, resolve: resolve(10)).bind(lambda a: Task(lambda reject, resolve: resolve(a + 1)))
    result = fork(lambda a: a, lambda a: a)
    assert result == 11

    # 2. Bind in task.of test
    fork = Task(lambda reject, resolve: resolve(10)).bind(lambda a: Task.of(a + 1))
    result = fork(lambda a: a, lambda a: a)
    assert result == 11

    # 3. Bind in task.reject test
    fork = Task(lambda reject, resolve: resolve(10)).bind(lambda a: Task.reject(a + 1))
    result = fork(lambda a: a, lambda a: a)
    assert result == 11

    # 4. Bind with error
    fork = Task

# Generated at 2022-06-21 19:41:16.318871
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for constructor of class Task.
    """
    reject = Mock()
    resolve = Mock()

    task = Task(lambda reject, resolve: None)
    task.fork(reject, resolve)

    assert resolve.called is False
    assert reject.called is False
    reject.reset_mock()
    resolve.reset_mock()


# Generated at 2022-06-21 19:41:25.661624
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test that Task.bind transform data from Task with reject and resolve function.
    """
    def Сase(value):
        # pylint: disable=missing-docstring
        def on_reject(arg):
            # pylint: disable=missing-docstring
            return Task.of(arg)

        def on_resolve(arg):
            # pylint: disable=missing-docstring
            return Task.of(arg)

        return Task.of(value).bind(on_reject).bind(on_resolve)

    assert Сase(None).fork(lambda arg: arg, lambda arg: arg) is None
    assert Сase(True).fork(lambda arg: arg, lambda arg: arg) is True

# Generated at 2022-06-21 19:41:35.577446
# Unit test for method bind of class Task
def test_Task_bind():
    import pytest

    success_task = Task.of(1)
    assert success_task.fork(lambda arg: None, lambda arg: arg) == 1

    failed_task = Task.reject(1)
    assert failed_task.fork(lambda arg: arg, lambda arg: None) == 1

    def error_task(reject, resolve):
        reject("i'm not a number")

    assert Task(error_task).fork(lambda arg: arg, lambda arg: None) == "i'm not a number"

    def success_task_2(reject, resolve):
        resolve("i'm a number")

    assert Task(success_task_2).fork(lambda arg: None, lambda arg: arg) == "i'm a number"

    def error_task_2(reject, resolve):
        reject("i'm not a string")

# Generated at 2022-06-21 19:41:40.556209
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 5

    def square(x):
        return x ** 2

    def triple(x):
        return x * 3

    def deep_square(x):
        return Task.of(square(square(triple(x))))

    assert Task.of(2).map(add).fork(lambda x: x, lambda x: x) == 7
    assert Task.of(2).map(add).map(square).fork(lambda x: x, lambda x: x) == 49
    assert Task.of(2).map(square).map(add).fork(lambda x: x, lambda x: x) == 9
    assert Task.of(2).bind(deep_square).fork(lambda x: x, lambda x: x) == 6561


# Generated at 2022-06-21 19:41:51.844521
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Run test for function Task.bind

    :returns: True if test runs correctly
    :rtype: Boolean
    """
    def reject_fn(value):
        return Task.reject(value)

    def resolve_fn(value):
        return Task.of(value)

    def add_one(value):
        return value + 1

    def map_two(value):
        return Task.of(value * 2)

    result_reject = Task.reject(1).bind(reject_fn)
    result_resolve = Task.reject(1).bind(resolve_fn).map(add_one)
    result_mapper = Task.reject(2).bind(map_two).map(add_one)


# Generated at 2022-06-21 19:41:53.216106
# Unit test for constructor of class Task
def test_Task():
    Task(lambda reject, resolve: resolve(1))


# Generated at 2022-06-21 19:41:57.633210
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(1).map(lambda x: x + 1)
    assert result.fork(None, lambda x: x) == 2

    def treject(_):
        raise TypeError()

    def tresolve(_):
        raise TypeError()

    with pytest.raises(TypeError):
        Task.reject(1).map(lambda x: x).fork(treject, tresolve)


# Generated at 2022-06-21 19:42:01.585698
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(a)

    a = 2
    t1 = Task(fork)
    t2 = t1.map(lambda x: x + x)
    assert t2.fork(lambda x: None, lambda x: x) == 4


# Generated at 2022-06-21 19:42:02.326977
# Unit test for constructor of class Task
def test_Task():
    assert Task



# Generated at 2022-06-21 19:42:23.252167
# Unit test for method map of class Task
def test_Task_map():
    """Test for method map of class Task."""
    assert Task.of(1).map(lambda value: value + 2).fork(None, lambda resolve: resolve) == 3



# Generated at 2022-06-21 19:42:27.086651
# Unit test for method bind of class Task
def test_Task_bind():
    """Test for function bind of class Task."""
    def fn(value):
        return Task.of(value + 1)

    result = Task.of(1) \
        .bind(fn) \
        .bind(fn) \
        .bind(fn) \
        .fork(
            lambda err: None,
            lambda res: res
        )

    assert result == 4


# Generated at 2022-06-21 19:42:34.870244
# Unit test for method map of class Task
def test_Task_map():
    # Test with callback
    def callback(reject, resolve):
        resolve(1)

    t = Task(callback)

# Generated at 2022-06-21 19:42:42.559339
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value*2

    def fn_1(value):
        return value+'!'

    def fn_2(value):
        return Task.of(value+'?')

    def assert_Task_map_rejects(task):
        def rejecter(reject, _):
            return reject('error')


# Generated at 2022-06-21 19:42:50.419909
# Unit test for method bind of class Task
def test_Task_bind():
    def fork_1(reject, resolve):
        return resolve(1)

    def fork_2(reject, resolve):
        return resolve(2)

    task_1 = Task(fork_1)
    task_2 = Task(fork_2)

    assert task_1.bind(lambda _: task_2).fork(None, lambda result: result) == 2


# Execute test
if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-21 19:42:59.786635
# Unit test for method bind of class Task
def test_Task_bind():
    arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    def random_number(arr):
        return Task(lambda _, resolve: resolve(random.choice(arr)))

    def multiple_by_ten(arr):
        return Task(lambda reject, resolve: resolve([el * 10 for el in arr]))

    def get_result(arr):
        return random_number(arr).bind(multiple_by_ten)

    result = get_result(arr).fork(lambda _: _, lambda _: _)
    assert type(result) == list
    assert len(result) == 10
    assert min(result) == 10
    assert max(result) == 100


# Generated at 2022-06-21 19:43:06.456039
# Unit test for method bind of class Task
def test_Task_bind():
    # Create Task instance
    task = Task.of(1)
    # Create second Task instance
    second_task = Task.of(2)
    # Create third Task instance
    def fork(reject, resolve):
        resolve(3)
        return 'result'

    third_task = Task(fork)
    # Test resolving
    assert task.bind(lambda _: task).fork(None, lambda x: x) == 1
    # Test rejecting
    assert task.bind(lambda _: Task.reject(2)).fork(lambda x: x, None) == 2
    # Test returning another Task from mapper
    assert task.bind(lambda _: second_task).fork(None, lambda x: x) == 2
    # Test returning another Task from mapper with fork function

# Generated at 2022-06-21 19:43:10.810823
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(value, result):
        def mapper(value):
            return Task.of(value * value)

        data = Task.of(value).bind(mapper)
        assert isinstance(data, Task)
        assert data.fork(lambda _: False, lambda x: x) == result

    assert test_function(10, 100)



# Generated at 2022-06-21 19:43:12.794867
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)

    assert task.map(lambda x: x + 1) == Task.of(2)


# Generated at 2022-06-21 19:43:17.191263
# Unit test for method map of class Task
def test_Task_map():
    def func(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    mapped = task.map(func)
    assert mapped.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-21 19:43:52.099874
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(1))
    assert isinstance(task, Task)


# Generated at 2022-06-21 19:43:54.292981
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject('reject')
        resolve('resolve')

    task = Task(fork)
    assert task.fork(print, print) == None


# Generated at 2022-06-21 19:44:00.013922
# Unit test for method bind of class Task
def test_Task_bind():
    def positive(value):
        return Task.of(value + 1)

    def negative(value):
        return Task.of(value - 1)

    task = Task.of(2)
    assert t.isinstance(task, Task)
    assert task.fork(negative, positive) == 3

# Generated at 2022-06-21 19:44:04.127540
# Unit test for method bind of class Task
def test_Task_bind():
    identity = lambda arg: arg
    twice = lambda arg: arg * 2
    assert Task(identity).bind(twice).fork(identity, identity) == 2
    assert Task(identity).map(twice).fork(identity, identity) == 2
    # dump(Task(identity).bind(twice))
    # dump(Task(identity).bind(twice).fork(identity, identity))
    # dump(Task(identity).map(twice))
    # dump(Task(identity).map(twice).fork(identity, identity))

# Task.of(3).map(lambda x: x + 1).map(lambda x: 2 * x).fork(identity, identity) // 8
# Task.of(3).map(lambda x: x + 1).bind(lambda x: Task.of(2 *

# Generated at 2022-06-21 19:44:07.860346
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    fork = lambda reject, resolve: resolve(42)

    task = Task(fork)

    assert isinstance(task, Task)
    assert callable(task.fork)


# Generated at 2022-06-21 19:44:10.412322
# Unit test for method map of class Task
def test_Task_map():
    def sum(value):
        return value + 1

    t1 = Task.of(1)
    result = t1.map(sum)
    assert result.fork(None, None) == 2