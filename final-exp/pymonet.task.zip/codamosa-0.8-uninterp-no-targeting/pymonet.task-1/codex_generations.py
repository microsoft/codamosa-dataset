

# Generated at 2022-06-21 19:34:22.146644
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value)

    def mapper_reject(value):
        return Task.reject(value)

    def mapper_strange(value):
        return Task.of(value).bind(mapper_reject)

    def fork_resolve(f):
        def g(reject, resolve):
            return f(lambda arg: resolve(arg))
        return g

    assert fork_resolve(Task.of(42).bind(mapper).fork)(lambda _: None, lambda arg: arg) == 42
    assert fork_resolve(Task.of('Test').bind(mapper).fork)(lambda _: None, lambda arg: arg) == 'Test'

# Generated at 2022-06-21 19:34:34.394429
# Unit test for method bind of class Task
def test_Task_bind():
    def div(num):
        def result(reject, resolve):
            return resolve(2.0 / num)

        return Task(result)

    def result(reject, resolve):
        return resolve(2.0)

    task = Task(result)

    def div_by_zero(reject, resolve):
        return reject('Division by zero.')

    task = task.bind(lambda arg: div(arg)).bind(lambda arg: div(arg))

# Generated at 2022-06-21 19:34:40.479275
# Unit test for method bind of class Task
def test_Task_bind():
    def add_two(value):
        return Task.of(value + 2)

    def multiply_two(value):
        return Task.of(value * 2)

    def return_error_if_less(value):
        return Task.of(value) if value > 2 else Task.reject(value)

    def return_value(value):
        return value

    def do_nothing(_):
        pass

    assert Task.of(2).bind(add_two).bind(multiply_two).fork(return_error_if_less, return_value) == 8
    assert Task.of(2).bind(add_two).bind(multiply_two).fork(do_nothing, return_value) == None

# Generated at 2022-06-21 19:34:48.572724
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of('hello')
    task = task.map(lambda x: x + ' world!')
    is_equal = task.fork(lambda x: None, lambda x: x == 'hello world!')
    if not is_equal:
        raise AssertionError('task.fork() has wrong results')

    # And now test reject branch
    task = Task.reject('hello')
    task = task.map(lambda x: x + ' world!')
    is_equal = task.fork(lambda x: x, lambda x: None)
    if is_equal is not None:
        raise AssertionError('task.fork() has wrong results')



# Generated at 2022-06-21 19:34:59.589486
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind should return new task with stored result
    Task.bind should return rejected task with stored error
    Task.bind should be reentrant
    """

    def assert_fork(reject, resolve):
        assert isinstance(resolve, Function)
        assert isinstance(reject, Function)

    def assert_map(value):
        assert isinstance(value, int)
        return value * 2

    def assert_bind(value):
        assert isinstance(value, int)
        return Task.of(value * 3)

    def assert_error(error):
        assert error == 0

    task = Task.of(1)
    task = task.map(assert_map)
    task = task.bind(assert_bind)


# Generated at 2022-06-21 19:35:04.056571
# Unit test for method bind of class Task
def test_Task_bind():
    def f(value):
        return Task.reject({"key1": value})

    assert Task.reject({"key": "value"}).bind(f).fork(lambda arg: arg, lambda _: True) == {"key1": {"key": "value"}}


# Generated at 2022-06-21 19:35:06.218046
# Unit test for constructor of class Task
def test_Task():
    returned_value = 1
    task = Task(lambda _, resolve: resolve(returned_value))

    assert returned_value == task.fork(lambda r: r, lambda r: r)


# Unit test of method Task.of()

# Generated at 2022-06-21 19:35:09.560815
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_task(a):
        return Task.of(a+1)

    task = Task.of(1)
    assert task.bind(fn_task).fork(lambda _: None, lambda x: x) == 2



# Generated at 2022-06-21 19:35:12.918711
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(5))
    assert task.fork(None, None) == 5

    task = Task(lambda reject, _: reject(5))
    assert task.fork(None, None) == 5


# Generated at 2022-06-21 19:35:17.097391
# Unit test for method map of class Task
def test_Task_map():
    def test_map_handler(value):
        return value

# Generated at 2022-06-21 19:35:22.384338
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(10)

    assert Task(fork).map(lambda arg: arg + 1).fork(
        lambda reject: reject(0),
        lambda resolve: resolve(1)
    ) == 11


# Generated at 2022-06-21 19:35:28.193560
# Unit test for method bind of class Task
def test_Task_bind():
    def inner_fn(value):
        return Task.of(value + 5)

    fn = lambda reject, resolve: resolve(2)
    task = Task(fn)

# Generated at 2022-06-21 19:35:31.834870
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: resolve(5)).fork(None, lambda x: x)
    assert not Task(lambda reject, resolve: reject(5)).fork(lambda x: x, None)


# Generated at 2022-06-21 19:35:34.930860
# Unit test for method map of class Task
def test_Task_map():
    assert Task(identity).map(identity)(1, 2)(-1, -2) == 2
    assert Task(identity).map(lambda x: x + 1)(1, 2)(-1, -2) == 3



# Generated at 2022-06-21 19:35:43.677315
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return value

    def reject(value):
        return value

    def inc(value):
        return value + 1

    def double(value):
        return value * 2

    b = Task(lambda reject, resolve: resolve(5))
    c = b.map(inc)
    assert c.fork(reject, resolve) == resolve(6)

    d = Task(lambda reject, resolve: resolve(2))
    e = d.map(double).map(inc)
    assert e.fork(reject, resolve) == resolve(5)

if __name__ == "__main__":
    test_Task_map()

# Generated at 2022-06-21 19:35:48.056389
# Unit test for constructor of class Task
def test_Task():
    def run(resolve, reject):
        assert type(resolve) is Function
        assert type(reject) is Function
        assert type(resolve(5)) is Task
        assert type(reject(5)) is Task
        assert resolve(5).fork is resolve
        assert reject(5).fork is reject

    t = Task(run)
    print('Task: constructor: ok\n')


# Generated at 2022-06-21 19:35:59.614106
# Unit test for constructor of class Task
def test_Task():
    # Testing correct behaviour
    a_val = 'hello_world'
    b_val = 'hello_world!'

    def a_task():
        return Task.of(a_val)

    def b_task():
        return Task.reject(b_val)

    # Test of
    assert(a_task().fork(lambda x: None, lambda y: y) == a_val)
    assert(b_task().fork(lambda x: x, lambda y: None) == b_val)

    # Test map
    assert(a_task().map(lambda x: b_val).fork(lambda x: None, lambda y: y) == b_val)
    assert(b_task().map(lambda x: b_val).fork(lambda x: x, lambda y: None) == a_val)

    # Test bind
   

# Generated at 2022-06-21 19:36:03.539109
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(5)

    def fn(value):
        return value ** 2

    task = Task(fork)
    mapped = task.map(fn)

    assert fn(5) == mapped.fork(None, lambda arg: arg)


# Generated at 2022-06-21 19:36:06.531520
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(10)
    task = task.bind(lambda x: Task.of(x + 1))
    assert task.fork(lambda arg: None, lambda arg: arg) == 11


# Generated at 2022-06-21 19:36:14.161620
# Unit test for method bind of class Task
def test_Task_bind():
    # Test for sum of 2 integers
    def add(x):
        return Task.of(x + x)

    assert Task.of(2).bind(add).fork(lambda x: x, lambda x: x) == 4

    # Test for division by zero
    def division_by_zero(x):
        def division(x):
            if x == 0:
                raise ZeroDivisionError()
            return x / x

        try:
            return Task.of(division(x))
        except ZeroDivisionError:
            return Task.reject("Division by zero exception")

    assert (
        Task.of(0).bind(division_by_zero).fork(
            lambda x: x, lambda x: x
        ) == "Division by zero exception"
    )

# Unit tests for method map of class Task

# Generated at 2022-06-21 19:36:24.011840
# Unit test for constructor of class Task
def test_Task():
    """
    Test is used as example of usage Task
    """
    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert type(task) == Task

    task = Task.of(1)
    assert type(task) == Task
    assert task.fork(None, lambda arg: arg) == 1

    task = Task.reject(1)
    assert type(task) == Task
    assert task.fork(lambda arg: arg, None) == 1


# Generated at 2022-06-21 19:36:28.358999
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind
    """
    assert Task(lambda _, resolve: resolve(3)).bind(lambda arg: Task.reject(arg * 2)).fork(
        lambda arg: arg * 2,
        lambda arg: arg * 3
    ) == 12



# Generated at 2022-06-21 19:36:35.359950
# Unit test for method bind of class Task
def test_Task_bind():
    def fork_to_one(reject, resolve):
        resolve(1)

    def bind_to_two(arg):
        def fork_to_two(reject, resolve):
            resolve(2)

        return Task(fork_to_two)

    task = Task(fork_to_one)
    task = task.bind(bind_to_two)
    assert task.fork(lambda reject: reject, lambda resolve: resolve) == 2


# Generated at 2022-06-21 19:36:42.201212
# Unit test for method map of class Task
def test_Task_map():
    def add_number(number):
        def add(value):
            return value + number

        return add

    def compare_result_with_expected(result):
        expected = Task.of(2)

        assert result.fork == expected.fork

    t1 = Task.of(1).map(add_number(1))
    t2 = Task.of(1).map(lambda x: x + 1)

    compare_result_with_expected(t1)
    compare_result_with_expected(t2)


# Generated at 2022-06-21 19:36:53.911339
# Unit test for constructor of class Task
def test_Task():
    # unit test of constructor

    # Unit test for constructor of class Task
    def test_Task():
        # unit test of constructor

        def func(rej, res):
            res('data')

        task = Task(func)
        assert task.fork(lambda a: 'rej', lambda a: 'res') == 'res'

    # unit test for method of class Task
    def test_Task_of():
        # unit test for method of class Task
        def test_of():
            task = Task.of('data')
            assert task.fork(lambda a: 'rej', lambda a: 'res') == 'res'

    # unit test for method of class Task
    def test_Task_reject():
        # unit test for method of class Task
        def test_reject():
            task = Task.reject('rejected')


# Generated at 2022-06-21 19:36:57.027632
# Unit test for constructor of class Task
def test_Task():
    """
    Test Task contructor
    """
    def result(reject, resolve):
        resolve(10)
    assert Task(result).fork(lambda _: None, lambda result: result) == 10


# Generated at 2022-06-21 19:37:01.771072
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, __: reject(3))
    assert task.fork(lambda a: a, lambda b: b) == 3
    task.__init__(lambda reject, __: reject(4))
    assert task.fork(lambda a: a, lambda b: b) == 4


# Generated at 2022-06-21 19:37:07.073797
# Unit test for method map of class Task
def test_Task_map():
    def test_Task_map_finished():
        def add_one(x):
            return x + 1

        assert Task.of(1).map(add_one).fork(S.reject, S.resolve) == 2

    def test_Task_map_rejected():
        def add_one(x):
            return x + 1

        assert Task.reject(1).map(add_one).fork(S.reject, S.resolve) == 1

    test_Task_map_finished()
    test_Task_map_rejected()

# Generated at 2022-06-21 19:37:13.269583
# Unit test for constructor of class Task
def test_Task():
    def test_factory(a, b):
        return Task(lambda r, s: r(a) if a else s(b))
    assert test_factory(False, 10).fork(lambda x: x, lambda x: x) == 10
    assert test_factory(True, 10).fork(lambda x: x, lambda x: x) == True


# Generated at 2022-06-21 19:37:15.794456
# Unit test for constructor of class Task
def test_Task():
    def fork(_, resolve):
        resolve('ok')

    task = Task(fork)

    assert task.fork(print, print) == 'ok'


# Generated at 2022-06-21 19:37:35.887683
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    """
    # Construct instance of Task
    task = Task(lambda reject, resolve: resolve('value'))

    # Construct function which return resolved Task with store value argument
    def fn(value):
        return Task(lambda _, resolve: resolve(value + 'mapped'))

    # Call method bind with function as argument
    result = task.bind(fn)

    # Construct function with no arguments
    # If all will be good, call resolve, else reject
    def result_resolve(_):
        assert False

    def result_reject(error):
        # If all will be good, this function will never call
        assert False

    # Call fork of stored function, it resolve value argument with function result_resolve
    # and reject value argument with function result_reject

# Generated at 2022-06-21 19:37:43.994139
# Unit test for method bind of class Task
def test_Task_bind():
    def tester(reject, resolve):
        resolve(10)

    def tester_2(reject, resolve):
        resolve(20)

    first = Task(tester)
    second = Task(tester_2)

    def sum_or_minus(value):
        def map_fn(value_2):
            return value - value_2

        if value > 0:
            return second.map(map_fn)
        else:
            return first.map(map_fn)

    assert (first.bind(sum_or_minus)).fork(lambda _: False, lambda x: x == 10)


# Generated at 2022-06-21 19:37:48.224028
# Unit test for method map of class Task
def test_Task_map():
    def fork(_, resolve):
        return resolve(24)

    task = Task(fork)

    assert task.fork(lambda _: 'a', lambda _: 'b') == 'b'

    task2 = task.map(lambda value: value * 2)

    assert task2.fork(lambda _: 'a', lambda _: 'b') == 'b'



# Generated at 2022-06-21 19:37:53.497755
# Unit test for method map of class Task
def test_Task_map():
    def test():
        task = Task.of('foo')
        result = task.map(lambda arg: arg + 'bar')
        assert result.fork(lambda err: err, lambda arg: arg) == 'foobar'
    test()


# Generated at 2022-06-21 19:38:03.760905
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    # def of(cls, value):
    #     """
    #     Return resolved Task with stored value argument.

    #     :param value: value to store in Task
    #     :type value: A
    #     :returns: resolved Task
    #     :rtype: Task[Function(_, resolve) -> A]
    #     """
    resolved = Task.of(12)
    # Check that this Task resolved with stored attribute
    assert resolved.fork(lambda _: False, lambda arg: arg == 12)

    # def reject(cls, value):
    #     """
    #     Return rejected Task with stored value argument.

    #     :param value: value to store in Task
    #     :type value: A
    #     :returns: rejected Task
   

# Generated at 2022-06-21 19:38:09.527374
# Unit test for constructor of class Task
def test_Task():
    value = 42
    task = Task.of(value)
    assert task.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == value

    value = 42
    task = Task.reject(value)
    assert task.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == value


# Generated at 2022-06-21 19:38:12.965450
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    assert Task.of(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-21 19:38:21.012270
# Unit test for method map of class Task
def test_Task_map():
    from random import randint
    from time import sleep

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_five(value):
        return value + 5

    def random_sleep(value):
        sleep(randint(1, 5))
        return value

    def sleep_f(value):
        return random_sleep(value)

    assert Task(lambda _, resolve: resolve(2)).map(add_two).fork(lambda _: -1, lambda r: r) == 4
    assert Task(lambda _, resolve: resolve(2)).map(add_three).fork(lambda _: -1, lambda r: r) == 5

# Generated at 2022-06-21 19:38:22.844527
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve('foo'))
    assert task.fork


# Generated at 2022-06-21 19:38:27.315912
# Unit test for method bind of class Task
def test_Task_bind():
    add = lambda x: Task.of(x + 2)
    subtract = lambda x: Task.of(x - 2)
    res = Task.of(1).bind(add).bind(subtract)
    assert res.fork(lambda err: None, lambda res: res) == 1


# Generated at 2022-06-21 19:38:48.815679
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map function.

    :returns: None
    :rtype: None
    """
    def plus_a(a):
        return 1 + a
    task = Task.of(1)
    assert task.map(plus_a).fork(lambda x: x, lambda x: x) == 2
    assert task.map(plus_a).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-21 19:38:51.468817
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(8)
    assert task.map(lambda v: v*2).fork(lambda v: v*2, lambda v: v*2) == 16



# Generated at 2022-06-21 19:38:54.634328
# Unit test for method map of class Task
def test_Task_map():
    t = Task(lambda _, resolve: resolve(1))
    t_1 = t.map(lambda arg: arg + 1)
    t_2 = t_1.fork(lambda _: None, lambda arg: arg)
    assert t_2 == 2


# Generated at 2022-06-21 19:38:59.070097
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method Task.bind.
    """
    # Test if Task.bind works correctly with rejection
    assert Task(lambda reject, _: reject(1)) \
        .bind(lambda arg: arg) \
        .fork(lambda reject, resolve: resolve(reject(1)), lambda _: False) is True

    # Test if Task.bind works correctly with resolve
    assert Task(lambda _, resolve: resolve(1)) \
        .bind(lambda arg: Task.of(arg)) \
        .fork(lambda _: False, lambda resolve: resolve(1)) is True


# Generated at 2022-06-21 19:39:11.070984
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """

    def side_effect(value, do_success=True):
        """
        Side effect for Task.fork

        :param value: argument for side effect
        :type value: A
        :returns: resolved Task with stored value if do_success is True, rejected if False
        :rtype: Task[A]
        """
        if do_success:
            return Task.of(value)
        else:
            return Task.reject(value)

    def check_ret_value(reject_value, resolve_value):
        """
        Check task return values for side_effect

        :param reject_value: reject value for test
        :type reject_value: A
        :param resolve_value: resolve value for test
        :type resolve_value: A
        """


# Generated at 2022-06-21 19:39:13.963093
# Unit test for constructor of class Task
def test_Task():
    # of
    assert Task.of(2).fork(None, lambda value: value) == 2

    # reject
    assert Task.reject('Error').fork(lambda value: value, None) == 'Error'


# Generated at 2022-06-21 19:39:17.640964
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test of method bind of class Task
    """

    def mapper(value):
        """
        mapper function
        """
        return Task.of(value + 1)

    # test resolve of mapper
    assert Task.of(1).bind(mapper).fork(lambda x: x, lambda x: x) == 2

    # test reject of mapper
    assert Task.of(1).bind(lambda x: Task.reject(x)).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-21 19:39:22.546111
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(2)

    result = task.bind(lambda x: Task.of(x + 2))

    def test(reject, resolve):
        assert reject(3) == 3
        assert resolve(2) == 4

    result.fork(
        lambda arg: arg,
        lambda arg: arg
    )

# Generated at 2022-06-21 19:39:27.191512
# Unit test for method map of class Task
def test_Task_map():
    """
    Test to see that method map of class Task is working properly.
    """
    def test_func(arg):
        return arg + 1

    task = Task.of(1)
    assert task.map(test_func).fork(None, lambda x: x) == 2


# Generated at 2022-06-21 19:39:35.664892
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    def plus_one(value):
        """
        unit test mapper function
        """
        return value + 1

    def times_two(value):
        """
        unit test mapper function
        """
        return value * 2

    def equals_two(value):
        """
        unit test reject function
        """
        if value == 2:
            return True
        else:
            return False

    def equals_one(value):
        """
        unit test resolve function
        """
        if value == 1:
            return True
        else:
            return False

    task_one = Task.of(1)
    task_two = task_one.bind(plus_one)
    result = task_two.fork(equals_one, equals_two)


# Generated at 2022-06-21 19:40:21.311545
# Unit test for method map of class Task
def test_Task_map():
    def my_mapper(value):
        return "mapped_" + value

    def fork(reject, resolve):
        return resolve("test")

    def test():
        assert Task(fork).map(my_mapper).fork(lambda a: None, lambda a: a) == "mapped_test"
        assert Task(fork).map(my_mapper).fork(lambda a: a, lambda a: None) == None

    test()


# Generated at 2022-06-21 19:40:24.235138
# Unit test for constructor of class Task
def test_Task():
    """
    Check constructor of class Task
    """
    assert Task(lambda reject, resolve: resolve("A")).fork(lambda rej, res: res("A")) == "A"


# Generated at 2022-06-21 19:40:31.515069
# Unit test for method map of class Task
def test_Task_map():
    """
    To test Task.map method have to create Task with fork function which call resolve function with arg.
    Then call map with function which return arg * 2 for example.
    To make sure that map return new Task with result of calling resolve * 2 have to call fork of this Task and make
    sure that it's resolve with arg * 2.
    """

    resolve = None
    task = Task(lambda _, _resolve: resolve(_resolve))
    mapped_task = task.map(lambda arg: arg * 2)


# Generated at 2022-06-21 19:40:34.614732
# Unit test for constructor of class Task
def test_Task():
    # of method
    assert Task.of(1).fork(None, lambda x: x) == 1
    # reject method
    assert Task.reject(1).fork(lambda x: x, None) == 1
    # __init__ method
    assert Task(lambda reject, resolve: resolve(1)).fork(None, lambda x: x) == 1


# Generated at 2022-06-21 19:40:38.726937
# Unit test for method bind of class Task
def test_Task_bind():
    # without error
    assert Task.of(2).bind(lambda number: Task.of(number * 2)) == Task.of(4)
    # with error
    assert Task.reject(2).bind(lambda number: Task.of(number * 2)) == Task.reject(2)
    # error types
    assert Task.of(TypeError).bind(lambda number: Task.of(number + 2)) == Task.of(TypeError)

# Generated at 2022-06-21 19:40:42.304354
# Unit test for method bind of class Task
def test_Task_bind():
    Task.of(3).bind(mapper).fork(
        lambda arg: print('reject: ', arg),
        lambda arg: print('resolve: ', arg)
    )


# Generated at 2022-06-21 19:40:48.157587
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for fork function of Task class.
    """
    assert Task.of("test").fork(lambda _: False, lambda arg: arg == "test"), "test_Task_fork_ok"
    assert Task.reject("test").fork(lambda arg: arg == "test", lambda _: False), "test_Task_fork_reject_ok"


# Generated at 2022-06-21 19:40:55.870716
# Unit test for method bind of class Task
def test_Task_bind():
    """
    C3: Task bind
    """
    def test_case(case_number, expected, actual):
        """
        :param case_number: number of test case
        :param expected: expected value of function to test
        :param actual: actual value of function to test
        :returns: None
        """
        if case_number == 42:
            assert expected == actual
        else:
            print(
                'in line {} of test_Task_bind: "{}" != "{}"'.format(
                    case_number,
                    expected,
                    actual,
                )
            )

    value = 42

    task_of_value = Task.of(value)
    result = task_of_value.bind(
        lambda arg: Task.of(arg + 1)
    )


# Generated at 2022-06-21 19:40:58.879548
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.

    :returns: None
    """
    def fork(reject, resolve):
        reject('a')
        return resolve('b')

    task = Task(fork)
    assert task.fork is fork

# Generated at 2022-06-21 19:41:02.457546
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve('value')

    result = Task(fork).fork(lambda value: 'rejected', lambda value: 'resolved')
    assert result == 'resolved'


# Generated at 2022-06-21 19:42:41.115635
# Unit test for constructor of class Task
def test_Task():
    def task():
        def fork(reject, resolve):
            resolve(1)

        return Task(fork)

    assert task().fork(lambda _: 'reject', lambda _: 'resolve') == 'resolve'


# Generated at 2022-06-21 19:42:45.852542
# Unit test for constructor of class Task
def test_Task():
    # TaskOf
    assert isinstance(Task.of(5), Task)
    assert Task.of(5).fork(lambda _: _, lambda _: _) == 5

    # TaskReject
    assert isinstance(Task.reject(5), Task)
    assert Task.reject(5).fork(lambda _: _, lambda _: _) == 5



# Generated at 2022-06-21 19:42:49.520400
# Unit test for constructor of class Task
def test_Task():
    identity = Task(lambda reject, resolve: resolve(1))
    assert identity.fork(lambda arg: arg + 1, lambda arg: arg - 1) == 0


# Generated at 2022-06-21 19:42:52.495982
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(1))
    assert task.fork(
        lambda _: False,
        lambda value: value == 1
    )


# Generated at 2022-06-21 19:42:59.161452
# Unit test for constructor of class Task
def test_Task():
    def test_task_fork(reject, resolve):
        return reject(1)
    
    def test_task_map(reject, resolve):
        return resolve(2)

    task = Task(test_task_fork)
    task.fork(lambda a: "rejected")
    task.resolve(lambda a: "resolved")
    task.map(lambda a: a + 1)
    task.bind(lambda a: Task(test_task_map))


# Generated at 2022-06-21 19:43:03.273539
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(arg):
        return Task.of("R" + arg)

    def reject(arg):
        return Task.reject("E" + arg)

    assert Task(resolve).bind(lambda x: Task.of("V" + x)).fork(reject, resolve) == "RVV"
    assert Task(reject).bind(lambda x: Task.of("V" + x)).fork(reject, resolve) == "EV"

# Generated at 2022-06-21 19:43:06.375263
# Unit test for method bind of class Task
def test_Task_bind():
    return Task.of(2).bind(
        lambda value: Task.of(value ** 2)
    ).fork(
        lambda arg: arg,
        lambda arg: arg
    )

# Result will be 4
print(test_Task_bind())



# Generated at 2022-06-21 19:43:11.209204
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for constructor of class Task.
    """
    expected_value = [1, 2, 3]
    actual_value = []

    def mapper(value):
        actual_value.append(value)

    task = Task(lambda _, resolve: resolve(expected_value))
    task.map(mapper)

    assert expected_value == actual_value, "Task constructor works wrong!"



# Generated at 2022-06-21 19:43:15.272811
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(x):
        return x + 1

    def stub_task(rej, res):
        res(1)

    assert Task(stub_task).bind(add_one).fork(lambda x: x, lambda x: x) == 2



# Generated at 2022-06-21 19:43:20.703932
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    def test(resolve, reject):
        resolve('test')
        reject('test')

    task = Task(test).bind(lambda x: Task.of('bind')).bind(lambda x: Task.of('another bind'))

    assert task.fork(lambda x: False, lambda x: x) == 'another bind'
