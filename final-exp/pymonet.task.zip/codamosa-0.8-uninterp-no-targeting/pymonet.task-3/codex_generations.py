

# Generated at 2022-06-21 19:34:20.975780
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for constructor of class Task
    """
    test_task = Task(
        lambda reject, resolve: resolve("TEST")
    )

# Generated at 2022-06-21 19:34:27.600779
# Unit test for constructor of class Task
def test_Task():
    """ Testing constructor of Task class."""
    func = Task.of(1).fork

    assert isinstance(func, types.FunctionType)
    assert func(None, None) == 1

    err = Task.reject(1).fork

    assert isinstance(err, types.FunctionType)
    assert err(None, None) == 1


# Unit tests for map

# Generated at 2022-06-21 19:34:34.297474
# Unit test for method bind of class Task
def test_Task_bind():
    def reject_add1(reject, resolve):
        resolve(0)

    def resolve_add1(reject, resolve):
        resolve(1)

    assert Task(reject_add1).bind(lambda x: Task.of(x + 1)) == Task(reject_add1)
    assert Task(resolve_add1).bind(lambda x: Task.of(x + 1)) == Task(resolve_add1).map(lambda x: x + 1)

# Generated at 2022-06-21 19:34:44.500629
# Unit test for method bind of class Task
def test_Task_bind():
    """
    This function test bind method of Task.

    :returns: Nothing
    :rtype: None
    """
    #Test case for successful calling of bind function
    #in format (funcname, (input arguments), (expected result))
    test_cases = [
        (
            "Task.of(3).bind(lambda x: Task.of(x + 3)).fork",
            (lambda x: x, lambda x: x),
            6
        ),
        (
            "Task.reject(3).bind(lambda x: Task.reject(x + 3)).fork",
            (lambda x: x + 3, lambda x: x),
            6
        )
    ]

    #Running test cases
    for test_case in test_cases:
        #Unpacking test case
        funcname = test_case[0]


# Generated at 2022-06-21 19:34:55.596243
# Unit test for method bind of class Task
def test_Task_bind():
    # Test with Task.of(5)
    task_5 = Task.of(5)
    task_7 = task_5.bind(lambda arg: Task.of(arg + 2))
    assert task_7.fork(lambda arg: arg, lambda arg: arg) == 7

    # Test with Task.reject(5)
    task_5 = Task.reject(5)
    task_7 = task_5.bind(lambda arg: Task.of(arg + 2))
    assert task_7.fork(lambda arg: arg, lambda arg: arg) == 5

    # Test with Task.of(5)
    task_5 = Task.of(5)
    task_7 = task_5.bind(lambda arg: Task.reject(arg + 2))

# Generated at 2022-06-21 19:35:03.188955
# Unit test for method bind of class Task
def test_Task_bind():
    """

    """
    def resolve(value):
        return Task.of(value)

    def reject(value):
        return Task.reject(value)

    def fn_1(value):
        return value + 1

    def fn_2(value):
        return value * 2

    task_value = Task.of(1)
    assert task_value.fork(reject, resolve).fork(reject, fn_1).fork(reject, fn_2).fork(reject, resolve).fork(reject, fn_1) == 5


# Generated at 2022-06-21 19:35:06.479605
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def map_value(val):
        return val + 1

    def bind_value(val):
        return Task(lambda reject, resolve: resolve(val + 5))

    assert Task(fork).map(map_value).fork(None, lambda result: result) == 2
    assert Task(fork).bind(bind_value).fork(None, lambda result: result) == 6

# Unit test

# Generated at 2022-06-21 19:35:16.174764
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return reject(2)

    task = Task(fork)

    def fork_reject(reject, resolve):
        return reject('err')

    def fork_resolve(reject, resolve):
        return resolve('res')

    def bind_func(arg):
        return Task(fork_reject)

    task_reject = task.bind(bind_func).fork(lambda value: 'rejected', lambda value: 'resolved')
    assert task_reject == 'rejected'

    def bind_func(arg):
        return Task(fork_resolve)

    task_resolve = task.bind(bind_func).fork(lambda value: 'rejected', lambda value: 'resolved')
    assert task_resolve == 'resolved'


# Generated at 2022-06-21 19:35:23.080745
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        print('resolve: ' + str(value))

    def reject(value):
        print('reject: ' + str(value))

    def add(value):
        return value + 1

    def add2(value):
        return Task((lambda _, resolve: resolve(value + 2)))

    def error(value):
        raise ValueError(value)

    Task.of(1).map(add).fork(reject, resolve) # 2
    Task.of(1).map(add2).fork(reject, resolve) # 3
    Task.of(1).map(error).fork(reject, resolve) # error


# Generated at 2022-06-21 19:35:24.957009
# Unit test for method map of class Task
def test_Task_map():
    def id_function(arg):
        return arg

    def task_with_id(arg):
        return Task.of(id_function(arg))

    assert task_with_id(1).map(id_function).fork(
        lambda arg: False,
        id_function
    ) == 1


# Generated at 2022-06-21 19:35:30.823002
# Unit test for method map of class Task
def test_Task_map():
    t = Task.of(2).map(lambda x: x * 2)
    assert t.fork(lambda x: None, lambda y: y) == 4


# Generated at 2022-06-21 19:35:34.848559
# Unit test for method map of class Task
def test_Task_map():
    assert_task = Task.of(10)

    def test_map(x): return x*10
    assert_map = assert_task.map(test_map)

    assert assert_task.fork(None, None) == 10
    assert assert_map.fork(None, None) == 100



# Generated at 2022-06-21 19:35:39.103521
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(_):
        raise Exception('Task should be rejected')

    def reject(value):
        assert value == 'reject'

    Task(lambda reject, _: reject('reject')).bind(lambda _: Task.of('value')).fork(reject, resolve)

# Generated at 2022-06-21 19:35:44.826974
# Unit test for constructor of class Task
def test_Task():
    class UnitTestTask(unittest.TestCase):
        def test_of(self):
            self.assertEqual(Task.of(2).fork(lambda _: False, lambda x: x), 2)

        def test_reject(self):
            self.assertEqual(Task.reject(2).fork(lambda x: x, lambda _: False), 2)

    unittest.main()


# Generated at 2022-06-21 19:35:47.184414
# Unit test for constructor of class Task
def test_Task():
    assert Task is not None
    assert Task.of is not None
    assert Task.reject is not None
    assert Task.map is not None
    assert Task.bind is not None


# Generated at 2022-06-21 19:35:50.481378
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of('lol').map(len).fork(lambda x: x, lambda x: x) == 3



# Generated at 2022-06-21 19:35:54.483103
# Unit test for constructor of class Task

# Generated at 2022-06-21 19:35:58.550601
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        reject(reject)

    return Task(fork).bind(lambda arg: Task.reject(resolve)).fork(
        lambda reject: 'rejected value: {}'.format(reject),
        lambda resolve: 'resolved value: {}'.format(resolve)
    )


# Generated at 2022-06-21 19:36:08.571819
# Unit test for method bind of class Task
def test_Task_bind():
    # create counter
    counter = itertools.count()

    def return_task(value):
        """
        Create task with passed value.

        :param value: value to store in task
        :type value: A
        :returns:  resolved task
        :rtype: Task
        """
        return Task.of(value)

    task = Task.of(next(counter))

    def check_value(value):
        """
        Check passed value, and return task with next value from counter.

        :param value: value to check
        :type value: A
        :returns: resolved task
        :rtype: Task
        """
        assert value == 0
        return return_task(next(counter))

    assert task.bind(check_value).fork(None, lambda value: value) == 1

# Generated at 2022-06-21 19:36:15.138668
# Unit test for constructor of class Task
def test_Task():
    value = 1

    def mapper(resolve, reject):
        return resolve(value)

    mapper_zip = zip(
        [None] * 100,
        [value] * 100,
    )

    task = Task(mapper)
    assert task.fork == mapper
    for args in mapper_zip:
        assert task.fork(*args) == value



# Generated at 2022-06-21 19:36:22.897514
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method
    """
    value = 2
    task = Task.of(value)
    mapped_task = task.map(lambda x: x * 2)

    def did_fork(reject, resolve):
        resolve(mapped_task.fork(reject, resolve))

    assert did_fork(lambda arg: arg, lambda arg: arg) == 4


# Generated at 2022-06-21 19:36:28.410296
# Unit test for method bind of class Task
def test_Task_bind():
    t = Task.of(1)
    t2 = t.bind(lambda x: Task.of(x + 1))
    r = t2.fork(
        lambda arg: str(arg),
        lambda arg: str(arg)
    )
    assert r == '2'



# Generated at 2022-06-21 19:36:30.292039
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda r, _: None).fork(None, None) == None



# Generated at 2022-06-21 19:36:35.126004
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)

    assert task.fork == fork
    assert task.bind(lambda x: Task.of(x + 1)).fork(lambda _: 'error', lambda result: result) == 2



# Generated at 2022-06-21 19:36:38.691564
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def multiply_two(x):
        return x * 2

    task_of_one = Task.of(1)
    assert task_of_one.map(add_one).fork(lambda _: None, lambda x: x) == 2
    assert task_of_one.map(multiply_two).fork(lambda _: None, lambda x: x) == 2


# Generated at 2022-06-21 19:36:43.688492
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve('hello')
        return reject

    def fn(arg):
        return Task.of(arg)

    def fn2(arg):
        def fork(reject, resolve):
            resolve('world')
            return reject

        return Task(fork)

    task = Task(fork)
    assert task.bind(fn).bind(fn2).fork(lambda arg: arg, lambda arg: arg) == 'hello'


# Generated at 2022-06-21 19:36:50.658418
# Unit test for constructor of class Task
def test_Task():
    # test construction of task with just print
    # here we do not care about arguments to fork
    t = Task(lambda _, __: print('called'))

    # test construction of resolved task
    t = Task.of(3)
    assert t.fork(lambda _: None, lambda x: x) == 3

    # test construction of rejected task
    t = Task.reject(3)
    assert t.fork(lambda x: x, lambda _: None) == 3


# Generated at 2022-06-21 19:36:53.960794
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task.
    """
    task = Task.of(42)
    assert task.fork is not None

    task = Task.reject(42)
    assert task.fork is not None


# Generated at 2022-06-21 19:36:57.406836
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(2)

    def double(value):
        return value * 2

    task = Task(fork)

    assert task.map(double).fork(_, resolve) == 4


# Generated at 2022-06-21 19:37:03.444932
# Unit test for method bind of class Task
def test_Task_bind():
    sum_a_b = lambda a, b: Task.of(a + b)

    def add_a_b_c(a):
        return Task.of(a + 5).bind(lambda b: sum_a_b(b, 2))

    a = 3
    assert add_a_b_c(a).fork(
        lambda arg: print('reject', arg),
        lambda arg: arg == a + 5 + 2
    )

# Generated at 2022-06-21 19:37:13.447406
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve("test")

    def f(x):
        def g(reject, resolve):
            resolve("test2")

        return Task(g)

    assert Task(fork).bind(f).fork(
        lambda x: None,
        lambda x: x
    ) == "test2"


# Generated at 2022-06-21 19:37:20.726154
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Word "add" have length 3, in this test we call method bind with function
    to add length of word to length of word "add",
    so "addadd".length() = 6.
    """
    def add_word(word):
        return Task.of(word + word)

    def add_word_length(word):
        return Task.of(word.length() + word.length())

    assert Task.of("add").bind(add_word).bind(add_word_length).fork(
        lambda reject: -1,
        lambda resolve: resolve
    ) == 6


# Generated at 2022-06-21 19:37:26.993635
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind(Function(value) -> Task[resolve, value]) -> Task[reject, mapped_value]
    """
    def my_fork(reject, resolve):
        resolve(3)

    def add_one(value):
        return Task.of(value + 1)

    def mult_two(value):
        return Task.of(value * 2)

    task = Task(my_fork).bind(add_one).bind(mult_two)

    assert task.fork(lambda reject: reject, lambda resolve: resolve) == 8

# Generated at 2022-06-21 19:37:33.385980
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for constructor of class Task
    """
    assert Task(lambda reject, resolve: resolve('foo')).fork(
        lambda reject, resolve: reject('foo'),
        lambda reject, resolve: resolve('foo')
    ) == 'foo'

    assert Task(lambda reject, resolve: reject('foo')).fork(
        lambda reject, resolve: reject('foo'),
        lambda reject, resolve: resolve('foo')
    ) == 'foo'


# Generated at 2022-06-21 19:37:40.059607
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_callback(value):
        return Task.of(value + '!')

    def reject_callback(value):
        return Task.of(value + '!')

    task = Task.of('Hello')
    task = task.map(lambda arg: arg + ', ')
    task = task.map(lambda arg: arg + 'World')
    task = task.bind(resolve_callback)

    assert task.fork(reject_callback, resolve_callback) == 'Hello, World!'



# Generated at 2022-06-21 19:37:42.408300
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject("test")

    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-21 19:37:43.812217
# Unit test for constructor of class Task
def test_Task():
    assert Task(1).fork(1, 1) == 1



# Generated at 2022-06-21 19:37:51.244295
# Unit test for method map of class Task
def test_Task_map():
    def identity(value):
        return value

    assert Task.of(1).map(identity).fork(
        lambda error: 'We have error',
        lambda value: value
    ) == 1

    assert Task.of(1).map(lambda x: x + 1).fork(
        lambda error: 'We have error',
        lambda value: value
    ) == 2

    assert Task.of(1).map(identity).map(lambda x: x + 1).fork(
        lambda error: 'We have error',
        lambda value: value
    ) == 2

    assert Task.reject(1).map(identity).fork(
        lambda error: error,
        lambda value: 'We have value'
    ) == 1


# Generated at 2022-06-21 19:37:53.012665
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1) == Task(lambda _, resolve: resolve(1))
    assert Task.reject(1) == Task(lambda reject, _: reject(1))



# Generated at 2022-06-21 19:37:56.237400
# Unit test for constructor of class Task
def test_Task():
  assert Task.of(1).fork(lambda x: False, lambda x: x == 1)
  assert Task.reject(1).fork(lambda x: x == 1, lambda x: False)


# Generated at 2022-06-21 19:38:11.167033
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task constructor.

    :raises: AssertionError if test not pass
    """
    greater = Task(lambda reject, resolve: resolve(100))
    assert greater.fork(lambda reject, resolve: resolve(100)) is not None


# Generated at 2022-06-21 19:38:16.997033
# Unit test for method bind of class Task
def test_Task_bind():
    def f(value):
        return Task.of(value * 2)

    task = Task.of(2)

    assert task.bind(f).fork(lambda _: None, lambda arg: arg) == 4

    def g(value):
        return Task.reject(value * 2)

    assert task.bind(g).fork(lambda arg: arg, lambda _: None) == 4


# Generated at 2022-06-21 19:38:22.570618
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map(fn) method.
    """
    def test(resolve, reject):
        ok = False
        if resolve(1).map(lambda x: x + 1) == Task.of(2):
            ok = True
        return ok

    assert test(Task.of, Task.reject)



# Generated at 2022-06-21 19:38:25.576021
# Unit test for constructor of class Task
def test_Task():
    with raises(AssertionError):
        Task()

    fork = lambda _, _: None

    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-21 19:38:29.734570
# Unit test for method map of class Task
def test_Task_map():
    def test_task(resolve, _):
        resolve(7)

    # Mapper function
    def plus_two(value):
        return value + 2

    plus_two_task = Task(test_task).map(plus_two)

    assert plus_two_task.fork(lambda res: res, lambda res: res) == 9


# Generated at 2022-06-21 19:38:40.401458
# Unit test for method bind of class Task
def test_Task_bind():
    @Task.of
    def task_of(reject, resolve):
        resolve('hello')

    @Task.of
    def next_task_of(reject, resolve):
        resolve('hello 2')

    @Task.reject
    def task_reject(reject, resolve):
        reject('error')

    @Task.reject
    def next_task_reject(reject, resolve):
        reject('error 2')


    # next_task_of(arg)
    task_of\
        .bind(lambda x: next_task_of(x + ' world'))\
        .fork(
            lambda err: None,
            lambda value: print(value)
        )
    # hello world 2

# Generated at 2022-06-21 19:38:42.910952
# Unit test for constructor of class Task
def test_Task():
    fork = lambda _, resolve: resolve("test")

    task = Task(fork)
    assert_equal(task.fork("reject", "resolve"), "test")


# Generated at 2022-06-21 19:38:47.412143
# Unit test for method map of class Task
def test_Task_map():
    def task(resolve, reject):
        resolve(1)

    def mapper(x):
        return x + 1

    t = Task(task)
    result = t.map(mapper).fork(None, None)

    assert result == 2


# Generated at 2022-06-21 19:38:53.350601
# Unit test for method map of class Task
def test_Task_map():
    def add(value):
        return value + 1

    def fn1(resolve, reject):
        resolve(10)

    def fn2(resolve, reject):
        reject(10)

    assert Task(fn1).map(add).fork(lambda _: None, lambda value: value) == 11
    assert Task(fn2).map(add).fork(lambda value: value, lambda _: None) == 10


# Generated at 2022-06-21 19:38:56.308602
# Unit test for method bind of class Task
def test_Task_bind():

    def fork(reject, resolve):
        return resolve(5)

    def fn(arg):
        return Task.of(arg + 5)

    task = Task(fork)
    result = task.bind(fn)
    assert result.fork(None, print) == 10



# Generated at 2022-06-21 19:39:21.854106
# Unit test for method map of class Task
def test_Task_map():
    def mapped_value(x):
        return x + 1

    result = Task.of(1).map(mapped_value)
    assert result.fork(lambda value: value, lambda value: value) == 2


# Generated at 2022-06-21 19:39:25.485069
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2
    assert Task.reject(1).map(lambda x: x + 1).fork(print, None) == 1


# Generated at 2022-06-21 19:39:28.788581
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda _: None, lambda value: value) == 1
    assert Task.reject(1).fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-21 19:39:32.625627
# Unit test for method bind of class Task
def test_Task_bind():
    def run(value):
        return Task.of(value)

    assert Task.of(1).bind(run).fork(lambda: None, lambda x: x) == 1
    assert Task.of(0).bind(run).fork(lambda: None, lambda x: x) == 0


# Generated at 2022-06-21 19:39:38.269341
# Unit test for method map of class Task
def test_Task_map():
    # Test Task.of(value).map(lambda x: x) equals Task.of(value)
    def test_map_identity():
        value = 'value'

        def task(reject, resolve):
            return resolve(value)

        task = Task.of(value)
        assert task.map(lambda x: x).fork(lambda x: x, lambda x: x) == task.fork(lambda x: x, lambda x: x)

    # Test Task.of(value).map(lambda _: another) equals Task.of(another)
    def test_map_another_value():
        value = 'value'
        another = 'another'

        def task(reject, resolve):
            return resolve(another)

        task = Task.of(value)

# Generated at 2022-06-21 19:39:43.716816
# Unit test for method map of class Task
def test_Task_map():
    # Test for resolve method
    assert Task.of(1).map(lambda x: x + 1).fork(
        reject=None,
        resolve=lambda x: x == 2
    )

    # Test for reject method
    assert Task.reject(1).map(lambda x: x + 1).fork(
        reject=lambda x: x == 1,
        resolve=None
    )


# Generated at 2022-06-21 19:39:49.182062
# Unit test for method bind of class Task
def test_Task_bind():
    """Task.bind() should return new Task with mapper resolve attribute."""
    task = Task.of(2)
    mapped_task = task.bind(lambda arg: Task.of(arg + 5))
    assert mapped_task.fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 7


# Generated at 2022-06-21 19:39:51.121497
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, r: r(42))
    assert Task(lambda r, _: r(42))


# Generated at 2022-06-21 19:40:01.178512
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    test = get_test()

    test.assertTrue(Task.of(None).fork())
    test.assertTrue(Task.of('Some data').fork())

    test.assertTrue(Task.reject(None).fork('Some error'))
    test.assertTrue(Task.reject('Some error').fork())

    test.assertEqual(
        Task.of('Some data').fork(lambda arg: arg, lambda arg: arg),
        'Some data'
    )

    test.assertEqual(
        Task.reject('Some error').fork(lambda arg: arg, lambda arg: arg),
        'Some error'
    )

    test.assertTrue(isinstance(Task(lambda _, resolve: resolve()), Task))



# Generated at 2022-06-21 19:40:06.767715
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.

    :returns: result of testing
    :rtype: Boolean
    """
    def add_one(value):
        return value + 1
    task = Task.of(2).map(add_one)
    assert task.fork(lambda _: None, lambda value: value + 1) == 4


# Generated at 2022-06-21 19:40:54.773288
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(100).map(lambda value: value * 2).fork(lambda arg: arg, lambda arg: arg) == 200
    assert Task.of(2).map(lambda value: Task.of(value * 10)).fork(lambda arg: arg, lambda arg: arg) == 20
    assert Task.of(2).map(lambda value: Task.reject(value * 100)).fork(lambda arg: arg, lambda arg: arg) == 200


# Generated at 2022-06-21 19:41:02.653689
# Unit test for method bind of class Task
def test_Task_bind():
    def add3(n):
        return Task.of(n + 3)

    def mul2(n):
        return Task.of(n * 2)

    def with_error(n):
        return Task.reject(n * n)

    assert Task.of(2).bind(add3).bind(mul2).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 10

    assert Task.of(2).bind(with_error).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 4

# Generated at 2022-06-21 19:41:08.759256
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value, fn, expected):
        """
        Test case for method map of class Task.

        :param value: value to store in Task
        :type value: Any
        :param fn: function that will be called during invoke fork function
        :type fn: Function(Any) -> Any
        :param expected: value that will be return during call fork
        :type expected: Any
        """
        assert Task(lambda _, resolve: resolve(value)).map(fn).fork(None, lambda arg: arg) == expected

    test_map(2, lambda x: x * 2, 4)


# Generated at 2022-06-21 19:41:16.888793
# Unit test for method map of class Task
def test_Task_map():
    def assertEqual(expected, actual):
        assert expected == actual, "Expected: {}, but actual: {}".format(expected, actual)

    def fn(value):
        return value * 2

    def error(x):
        return x

    assertEqual(Task(lambda _, resolve: resolve(2)), Task.of(1).map(fn))
    assertEqual(Task(lambda reject, _: reject(1)), Task.reject(1).map(fn))
    assertEqual(Task(lambda _, resolve: resolve(1)), Task.of(1).map(error))



# Generated at 2022-06-21 19:41:20.349592
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1)\
        .map(lambda x: x + 1)\
        .map(lambda x: x * 2)\
        .fork(lambda err: err, lambda val: val) == 4


# Generated at 2022-06-21 19:41:30.325519
# Unit test for method map of class Task
def test_Task_map():
    def positive_number(number):
        return number > 0

    def double_value(number):
        return number * 2

    # Task of list with one positive number
    task_of_positive_number_list = Task.of([-1, 2, -3])

    # Task of list with one positive number
    task_of_positive_number_list_double = task_of_positive_number_list.map(lambda list_of_numbers: list(filter(positive_number, list_of_numbers)))

    # Task of list with one even positive number
    task_of_positive_number_list_double_even = task_of_positive_number_list_double.map(lambda list_of_numbers: map(double_value, list_of_numbers))

    # Call fork method
    result = task_of_positive

# Generated at 2022-06-21 19:41:40.172598
# Unit test for method map of class Task
def test_Task_map():
    """
    Function unit test for method map of class Task
    """

    # Function to resolve task
    def resolve_str(value):
        """
        Function to resolve task

        :param value: value to return
        :type value: str
        :returns: string with test text
        :rtype: str
        """
        return 'Resolve ' + value

    # Function to reject task
    def reject_str(value):
        """
        Function to reject task

        :param value: value to return
        :type value: str
        :returns: string with test text
        :rtype: str
        """
        return 'Reject ' + value

    task_resolve = Task(lambda reject, resolve: resolve('test'))
    task_reject = Task(lambda reject, resolve: reject('test'))

    assert task_

# Generated at 2022-06-21 19:41:42.096721
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve(3)

    task = Task(fork)

    assert task.fork(lambda value: value + 1, lambda value: value + 2) == 5


# Generated at 2022-06-21 19:41:46.393060
# Unit test for constructor of class Task
def test_Task():
    # Given
    def fork(reject, resolve):
        return reject('Task')

    # When
    task = Task(fork)

    # Then
    assert task.fork == fork


# Generated at 2022-06-21 19:41:56.365309
# Unit test for constructor of class Task
def test_Task():
    def test_of(value):
        """
        Unit test for Task.of.

        Check return of Task.of is Task and fork function is choice
        resolve function with value.
        """
        assert isinstance(Task.of(value), Task)
        assert Task.of(value).fork(lambda _: False,
                                   lambda v: v == value)

    def test_reject(value):
        """
        Unit test for Task.reject.

        Check return of Task.reject is Task and fork function is choice
        reject function with value.
        """
        assert isinstance(Task.reject(value), Task)
        assert Task.reject(value).fork(lambda v: v == value,
                                       lambda _: False)


# Generated at 2022-06-21 19:43:48.101802
# Unit test for constructor of class Task
def test_Task():
    """ Test constructor of class Task """

    def task(reject, resolve):
        """ Task test function """
        resolve(42)

    task = Task(task)

    assert isinstance(task, Task)


# Generated at 2022-06-21 19:43:53.015177
# Unit test for constructor of class Task
def test_Task():
    task_constructor_should_call_fork_method_with_two_arguments(Task).run()
    task_of_static_method_should_return_resolved_task_with_value_stored(Task).run()
    task_rejext_static_method_should_return_rejected_task_with_value_stored(Task).run()


# Generated at 2022-06-21 19:43:57.169733
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)).map(lambda x: x + 1).fork(
        lambda x: x,
        lambda x: x
    ) == 2

    assert Task(lambda _, resolve: resolve(1)).map(lambda x: x + 1).map(lambda x: x + 1).fork(
        lambda x: x,
        lambda x: x
    ) == 3

    assert Task(lambda reject, _: reject(1)).map(lambda x: x + 1).fork(
        lambda x: x,
        lambda x: x
    ) == 1



# Generated at 2022-06-21 19:44:01.394441
# Unit test for constructor of class Task
def test_Task():
    def check_constructor(reject, resolve, expected):
        resolve(expected)

    task = Task(check_constructor)
    result = task.fork(lambda x: x, lambda y: y)
    assert result == expected


# Generated at 2022-06-21 19:44:10.667404
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 3

    def reject(x):
        return x

    def resolve(x):
        return x

    def result_reject(value):
        return reject(value)

    def result_resolve(value):
        return resolve(add(value))

    task = Task.of(10)
    assert callable(task.fork)
    assert task.fork(reject, resolve) == 10
    mapped_task = task.map(add)
    assert mapped_task.fork(result_reject, result_resolve) == 13
    task = Task.reject(10)
    assert task.fork(reject, resolve) == 10


# Generated at 2022-06-21 19:44:19.856861
# Unit test for method map of class Task
def test_Task_map():
    from utils import Composable
    from functools import reduce

    def frob(x):
        return x + 10
    def inc(x):
        return x + 1
    def mul(x, y):
        return x * y

    assert Task.of(5).map(frob).fork(None, Composable(mul, inc))(6) == 132

    mapper = reduce(lambda x, y: x.map(y), [frob, inc, mul], Task.of(5))
    assert mapper.fork(None, Composable(mul, inc))(6) == 132

    assert Task.reject(5).map(lambda x: x + 1).fork(
        lambda x: x + 1,
        lambda x: None
    ) == 6
