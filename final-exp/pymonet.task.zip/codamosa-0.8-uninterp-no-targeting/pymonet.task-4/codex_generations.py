

# Generated at 2022-06-21 19:34:18.770512
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task(lambda _, __: None), Task)


# Generated at 2022-06-21 19:34:23.933341
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.reject(10).bind(lambda v: Task.reject(v + 1)).fork(
        lambda arg: arg,
        lambda arg: arg + 1,
    ) == 11

    assert Task.of(10).bind(lambda v: Task.of(v + 1)).fork(
        lambda arg: arg,
        lambda arg: arg + 1,
    ) == 12


# Generated at 2022-06-21 19:34:31.081003
# Unit test for constructor of class Task
def test_Task():
    def fn(reject, resolve):
        reject('reject')
        resolve('resolve')

    task = Task(fn)
    assert isinstance(task, Task)
    assert callable(task.fork)


# Generated at 2022-06-21 19:34:35.469575
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x ** 2

    x = Task.of(2)
    assert x.map(fn).fork(lambda v: v, lambda v: v) == 4
    assert x.map(lambda v: v ** 2).fork(lambda v: v, lambda v: v) == 4


# Generated at 2022-06-21 19:34:41.030386
# Unit test for constructor of class Task
def test_Task():
    true_func = Task(lambda _, resolve: resolve(True))
    assert true_func.fork(lambda _: False, lambda _: True)
    false_func = Task(lambda reject, _: reject(False))
    assert false_func.fork(lambda _: True, lambda _: False)
    return True


# Generated at 2022-06-21 19:34:45.756656
# Unit test for method map of class Task
def test_Task_map():
    def mapper(arg):
        return arg + 1

    def other_mapper(arg):
        return arg + 2

    task = Task.of(1)
    task1 = task.map(mapper)
    task2 = task.map(other_mapper)

    assert task1.fork(lambda arg: arg, lambda arg: arg) == 2
    assert task2.fork(lambda arg: arg, lambda arg: arg) == 3


# Generated at 2022-06-21 19:34:53.551865
# Unit test for method bind of class Task
def test_Task_bind():
    task_01 = Task.of(10)
    task_02 = task_01.bind(lambda x: Task.of(x + 20))

    def fork_test(reject, resolve):
        assert reject == task_01.fork(reject, resolve), \
            'resolve should be equal reject'
        assert resolve == task_02.fork(reject, resolve), \
            'result of second map should be equal resolve'

    task_01.fork(fork_test, fork_test)


# Generated at 2022-06-21 19:35:01.470048
# Unit test for method map of class Task
def test_Task_map():
    def double(arg):
        return arg + arg

    five = Task.of(2)
    result = five.map(double)
    result.fork(print, print)


# Generated at 2022-06-21 19:35:06.617035
# Unit test for constructor of class Task
def test_Task():
    def test_function(reject, resolve):
        resolve(1)

    t = Task(test_function)
    assert t.fork(lambda x: print(x), lambda x: print(x)) == 1
    assert t.fork(lambda x: print(x), lambda x: print(x)) == 1



# Generated at 2022-06-21 19:35:10.359740
# Unit test for method map of class Task
def test_Task_map():
    """
    Test simple mapping
    """
    def mapper(arg):
        return arg * 2

    task = Task.of(4).map(mapper)

    assert task.fork(lambda x: x, lambda x: x) == 8


# Generated at 2022-06-21 19:35:16.567452
# Unit test for method map of class Task
def test_Task_map():
    """
    Test case for method map.
    It should return Task with resolve function, which multiply arg by three.
    """
    t = Task.of(3)
    fn = lambda arg: arg * 3
    r = t.map(fn)

    assert r.fork(None, None) == 9


# Generated at 2022-06-21 19:35:24.135553
# Unit test for method bind of class Task
def test_Task_bind():
    """Unit test for method bind of class Task
    """
    assert Task(lambda _, resolve: resolve(2)).bind(
        lambda value: Task(lambda _, resolve: resolve(value * value))
    ).fork(
        lambda err: err,
        lambda value: value
    ) == 4

    assert Task(lambda _, resolve: resolve(3)).bind(
        lambda _: Task(lambda _, resolve: resolve(4))
    ).fork(
        lambda err: err,
        lambda value: value
    ) == 4

    assert Task(lambda _, resolve: resolve(None)).bind(
        lambda _: Task(lambda _, resolve: resolve(4))
    ).fork(
        lambda err: err,
        lambda value: value
    ) == 4


# Generated at 2022-06-21 19:35:28.578991
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve('foo'))
    eq_(task.fork(lambda _: _, lambda _: _)('bar'), 'foo')


# Generated at 2022-06-21 19:35:34.283513
# Unit test for method bind of class Task
def test_Task_bind():
    print(Task.of(2).bind(lambda x: Task.of(x + 1).bind(lambda y: Task.of(y + 1))).fork(lambda _: None, lambda arg: arg))
    assert Task.of(2).bind(lambda x: Task.of(x + 1).bind(lambda y: Task.of(y + 1))).fork(lambda _: None, lambda arg: arg) == 4

# Generated at 2022-06-21 19:35:35.754399
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        pass

    task = Task(fork)
    assert isinstance(task, Task)
    assert fork == task.fork


# Generated at 2022-06-21 19:35:45.735961
# Unit test for constructor of class Task
def test_Task():
    good_result = 0
    bad_result = 1

    @Task
    def make_good_task(_, resolve):
        return resolve(good_result)

    @Task
    def make_bad_task(reject, _):
        return reject(bad_result)

    print('Test Task.map...')
    def assert_eq(a, b):
        if a == b:
            print('Ok!')
        else:
            print('Fail.')


    assert_eq(make_good_task.map(lambda x: x).fork(lambda _: None, lambda x: x), good_result)
    assert_eq(make_bad_task.map(lambda x: x).fork(lambda x: x, lambda _: None), bad_result)

    print('Test Task.of...')

# Generated at 2022-06-21 19:35:50.763203
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(data):
        return Task.reject(data)

    def fn2(data):
        return Task.of(data)

    def fn3(data):
        return data + 1

    assert Task.of(1).bind(fn).fork(None, None) == 1

    assert Task.of(1).bind(fn2).bind(fn3).fork(None, None) == 2

    assert Task.of(1).bind(fn2).bind(fn3).bind(Task.of).fork(None, None) == Task.of(2)

    assert Task.of(1).bind(fn2).bind(fn3).bind(Task.of).bind(Task.of).fork(None, None) == Task.of(Task.of(2))

if __name__ == '__main__':
    test_Task_

# Generated at 2022-06-21 19:36:01.291461
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Tests for method :py:meth:`Task.bind` of class :py:class:`Task`

    Description
    -----------

    bind for Task.

    :returns: True if all tests passed
    :rtype: Boolean
    """
    # success bind function
    def succesFn1(value):
        def fork(reject, resolve):
            resolve(value * 2)

        return Task(fork)

    # success bind function
    def succesFn2(value):
        def fork(reject, resolve):
            resolve(value + 1)

        return Task(fork)

    # error bind function
    def errorFn1(value):
        raise TypeError("This is Error in bind")

    # error bind function

# Generated at 2022-06-21 19:36:02.864351
# Unit test for constructor of class Task
def test_Task():
    """
    Test True if constructor is working correctly
    """
    assert Task(lambda _, resolve: resolve(2)).fork(reject=None, resolve=None) == 2


# Generated at 2022-06-21 19:36:04.660393
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda a, b: 1).fork(lambda a: a, lambda a: a) == 1


# Generated at 2022-06-21 19:36:10.965097
# Unit test for method map of class Task
def test_Task_map():

    def fn(x):
        return x + 2

    task_of_x = Task.of(2)
    task_of_fn = task_of_x.map(fn)

    assert task_of_x.map(fn) is task_of_fn
    assert task_of_fn.fork(None, lambda x: x) == 4


# Generated at 2022-06-21 19:36:19.822848
# Unit test for method bind of class Task
def test_Task_bind():
    def inner_reject(value):
        return Task.reject(value)

    def inner_resolve(value):
        return Task.of(value)

    Task.of(1)\
        .bind(lambda result: inner_reject(result))\
        .fork(lambda rejected_value: print("Rejected:", rejected_value),
              lambda resolved_value: print("Resolved:", resolved_value))

    Task.of(1)\
        .bind(lambda result: inner_resolve(result))\
        .fork(lambda rejected_value: print("Rejected:", rejected_value),
              lambda resolved_value: print("Resolved:", resolved_value))



# Generated at 2022-06-21 19:36:23.167709
# Unit test for constructor of class Task
def test_Task():
    # should return Task with fork function
    assert Task.of(42).fork('ignore', lambda arg: arg) == 42
    # should return Task with fork function
    assert Task.reject(42).fork(lambda arg: arg, 'ignore') == 42


# Generated at 2022-06-21 19:36:25.986380
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1))
    assert Task(lambda reject, _: reject(1))



# Generated at 2022-06-21 19:36:34.115268
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method.
    """
    result = Task.of(2).bind(lambda value: Task.of(value + 2)).fork(
        lambda result: 'Left',
        lambda result: result
    )
    assert result == 4

    result = Task.of(2).bind(
        lambda value: Task.reject(value + 2)
    ).fork(
        lambda result: 'Left',
        lambda result: 'Right'
    )

    assert result == 'Left'


# Generated at 2022-06-21 19:36:42.515177
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return value + 1

    def reject(value):
        return value - 1

    assert Task.reject(1).map(resolve).fork(reject, resolve) == 0
    assert Task.of(1).map(resolve).fork(reject, resolve) == 2

    # Test with multiple arguments
    def resolve(first, second):
        return first + second

    def reject(first, second):
        return first - second

    assert Task.reject(1, 2).map(resolve).fork(reject, resolve) == -3
    assert Task.of(1, 2).map(resolve).fork(reject, resolve) == 3


# Generated at 2022-06-21 19:36:47.624433
# Unit test for method bind of class Task
def test_Task_bind():
    def run(resolve, reject):
        resolve(5)

    def called(value):
        return Task.of(value + 5)

    task = Task(run).bind(called)
    assert task.fork(lambda x: {}, lambda x: x) == 10


# Generated at 2022-06-21 19:36:56.853505
# Unit test for method map of class Task
def test_Task_map():
    def mapper(arg):
        return arg * 2

    def inc(arg):
        return arg + 1

    # 1. Test map method mapped value
    task = Task.of(2).map(mapper)
    assert task.fork(lambda _: None, lambda arg: arg) == 4

    # 2. Test map method mapped data-type
    task = Task.of(2).map(mapper).map(inc)
    assert task.fork(lambda _: None, lambda arg: arg) == 5

    # 3. Test map method on rejected Task
    task = Task.reject(2).map(mapper)
    assert task.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-21 19:37:00.131984
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda value: value + 1)

# Generated at 2022-06-21 19:37:03.121277
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> t = Task.of(5).map(lambda x: x * 2).bind(lambda x: Task.of(x - 2))
    >>> t.fork(print, print)
    8
    """



# Generated at 2022-06-21 19:37:16.884504
# Unit test for method map of class Task
def test_Task_map():
    # call function with resolve and reject arguments
    task = Task.of(5).map(lambda x: x * 2)

    # Check value of resolved task
    assert task.fork(
        lambda reject: None,
        lambda resolve: resolve == 10
    )

    # Check value of rejected task
    assert task.fork(
        lambda reject: reject == 5,
        lambda resolve: None
    )

    # Call function with reject and resolve arguments
    task = Task.reject(5).map(lambda x: x * 2)

    # Check value of resolved task
    assert task.fork(
        lambda reject: None,
        lambda resolve: resolve == 10
    )

    # Check value of rejected task
    assert task.fork(
        lambda reject: reject == 5,
        lambda resolve: None
    )



# Generated at 2022-06-21 19:37:21.360335
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        test_fn.value = value
        return Task.of(value + 1)

    task = Task.of(1).bind(test_fn)
    task.fork(lambda value: print('reject: ' + str(value)), lambda value: print('resolve: ' + str(value)))
    print(test_fn.value)


# Generated at 2022-06-21 19:37:25.886278
# Unit test for constructor of class Task
def test_Task():
    def reject(_, resolve):
        resolve(1)

    def resolve(_, reject):
        reject(2)

    task_rej = Task(resolve)
    task_res = Task(reject)
    assert task_rej.fork(lambda arg: arg, lambda arg: arg) == 2
    assert task_res.fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-21 19:37:29.195136
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(1)

    assert task.bind(fn).fork(
        reject = lambda _: "error",
        resolve = lambda value: value
    ) == 2


# Generated at 2022-06-21 19:37:33.131385
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task((lambda reject, resolve: resolve(x + 1)))

    task = Task.of(1).bind(add).fork(lambda value: print('Rejected'),
                                    lambda value: print(value))

# Generated at 2022-06-21 19:37:42.313859
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def minus(x):
        return x - 1

    def sub(x):
        return x - 2

    def resolve_add(x):
        return Task.of(x).map(add)

    def reject_minus(x):
        return Task.reject(x).map(minus)

    def resolve_sub(x):
        return Task.of(x).map(sub)

    assert resolve_add(5).fork(None, lambda x: x) == 6
    assert reject_minus(5).fork(lambda x: x, None) == 4
    assert resolve_sub(5).fork(None, lambda x: x) == 3


# Generated at 2022-06-21 19:37:45.177049
# Unit test for constructor of class Task
def test_Task():
    def test_of(x):
        assert isinstance(x, Task)
        assert x.fork is not None

    test_of(Task(lambda x, y: x))

# Unit tests for class method of Task

# Generated at 2022-06-21 19:37:49.263407
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve(3)

    task = Task(fork)

    assert Task.of(3) == task
    assert Task.of(3).fork(lambda x: x, lambda x: x) == 3
    assert Task.reject(None).fork(lambda x: x, lambda x: x) == None


# Generated at 2022-06-21 19:37:54.952499
# Unit test for method bind of class Task
def test_Task_bind():
    def plus2(num): return num + 2
    def times2(num): return num * 2
    def minus2(num): return num - 2
    def div2(num): return num / 2

    task1 = Task.of(10)

    task2 = task1.bind(lambda num: Task.of(num ** 2))
    task2.fork(
        lambda error: print('error: {}'.format(error)),
        lambda value: print('success: {}'.format(value))
    )

    task3 = task1.bind(lambda a: Task.of(a * 2)
                       .bind(lambda b: Task.of(b * 3)
                             .bind(lambda c: Task.of(c * 5))))

# Generated at 2022-06-21 19:37:57.217719
# Unit test for constructor of class Task
def test_Task():
    def identity(a):
        return a
    task = Task(identity)
    assert task.fork(identity, identity) == identity


# Generated at 2022-06-21 19:38:05.932617
# Unit test for method map of class Task
def test_Task_map():
    def sample_fork(reject, resolve):
        resolve(1)

    def sample_mapper(value):
        return value + 1

    result = Task(sample_fork).map(sample_mapper).fork(
        lambda arg: arg + 1,
        lambda arg: arg + 1
    )

    assert result == 3


# Generated at 2022-06-21 19:38:13.199472
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Call method map of class Task

    :returns: None
    :rtype: None
    """
    def fork(reject, resolve):
        return resolve(2)

    value = Task(fork).bind(lambda x: Task.of(x + 2)).fork(
        lambda x: print('reject with {}'.format(x)),
        lambda x: print('resolve with {}'.format(x))
    )


# Generated at 2022-06-21 19:38:14.851511
# Unit test for constructor of class Task
def test_Task():
    task = Task(None)
    assert task.fork is None


# Generated at 2022-06-21 19:38:18.565118
# Unit test for method bind of class Task
def test_Task_bind():
    def task(resolve, reject):
        resolve(3)

    def mapper(value):
        def result(resolve, reject):
            resolve(value + 2)

        return Task(result)

    assert Task(task).bind(mapper).fork(lambda arg: arg, lambda arg: arg) == 5


# Generated at 2022-06-21 19:38:22.146236
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1) + 1).fork(
        lambda _: print('rejected'),
        lambda value: print('resolve with {}'.format(value))
    ) == 2


# Generated at 2022-06-21 19:38:28.408267
# Unit test for method bind of class Task
def test_Task_bind():
    def task_mapper(value):
        return Task.of(value * 2)

    print("Task(lambda _, resolve: resolve(3)).bind(task_mapper).fork(lambda _: print('rejected'), lambda arg: print(arg + 1)) # Should print 7")

    Task(lambda _, resolve: resolve(3)).bind(task_mapper).fork(lambda _: print('rejected'), lambda arg: print(arg + 1)) # Should print 7


test_Task_bind()

# Generated at 2022-06-21 19:38:36.069912
# Unit test for method map of class Task
def test_Task_map():
    """
    Map is a function that takes a function and a functor,
    applies the function to each of the functor’s values, and returns a functor of the same shape.

    :returns: True if test passed
    :rtype: bool
    """
    def add2(x):
        return x + 2

    def doubleIt(x):
        return x * 2

    def squareIt(x):
        return x ** 2

    def cube(x):
        return x ** 3

    # Functor
    maybe = Task.of(3)

    # Functor containing function
    maybeDouble = Task.of(doubleIt)

    # Mapping from functor to functor
    mappedMaybe = maybe.map(add2).map(doubleIt).map(squareIt)

    # Mapping from functor containing function to functor


# Generated at 2022-06-21 19:38:37.541845
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).value == 1



# Generated at 2022-06-21 19:38:39.347166
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x * x).fork(None, print) == 4


# Generated at 2022-06-21 19:38:47.552043
# Unit test for method map of class Task
def test_Task_map():

    # Check map method with unsuccessful Task
    t1 = Task(lambda reject, _: reject(1))
    t2 = t1.map(lambda x: x+1)
    assert t2.fork(lambda arg: arg, lambda _: False) == 1

    # Check map method with successful Task
    t3 = Task(lambda _, resolve: resolve(1))
    t4 = t3.map(lambda x: x+1)
    assert t4.fork(lambda _: True, lambda arg: arg) == 2


# Generated at 2022-06-21 19:39:03.325287
# Unit test for method bind of class Task
def test_Task_bind():
    def fun1(value):
        return value * 2

    def fun2(value):
        return Task.of(value * 2)

    assert Task.of(10) \
               .map(fun1) \
               .fork(None, assertequal(20))

    assert Task.of(10) \
               .bind(fun2) \
               .fork(None, assertequal(20))


# Generated at 2022-06-21 19:39:07.157015
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    task = Task.of(1)
    task2 = task.map(mapper)

    assert task2.fork(None, None) == 2


# Generated at 2022-06-21 19:39:10.096314
# Unit test for constructor of class Task
def test_Task():
    def fork_fn(_, fn):
        return fn(1)

    assert Task(fork_fn).fork(lambda _: 0, lambda arg: arg) == 1


# Generated at 2022-06-21 19:39:14.847689
# Unit test for method bind of class Task
def test_Task_bind():

    def test_base_bind():
        def mapper(arg):
            return Task.of(arg + 1)

        result = Task.of(0).bind(mapper)

        expected = Task.of(1)


# Generated at 2022-06-21 19:39:18.387310
# Unit test for method map of class Task
def test_Task_map():
    Task(a).map(lambda x: x * 2).fork(
        lambda x: print(x),
        lambda x: print(x)
    )



# Generated at 2022-06-21 19:39:20.594592
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(10).map(lambda x: x * x).fork(None, assert_equal(100))


# Generated at 2022-06-21 19:39:23.941244
# Unit test for method map of class Task
def test_Task_map():

    def _test():
        return Task.of(1).map(lambda x: x + 1)

    assert _test().fork(None, lambda value: value) == 2


# Generated at 2022-06-21 19:39:33.511667
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    """

    # Setup
    def add_one(value):
        """
        Add one to given value

        :param value: value to add one
        :type value: Integer
        :returns: new value
        :rtype: Integer
        """
        return value + 1

    def add_one_task(term):
        """
        Create new Task and add one to stored value

        :param term: stored value
        :type term: Integer
        :returns: new Task
        :rtype: Task(Integer)
        """
        return Task.of(term).map(add_one)

    # Exercise
    result = Task.of(1).bind(add_one_task)
    assert result.fork(lambda _: None, lambda value: value) == 2

   

# Generated at 2022-06-21 19:39:40.168342
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 12

    task = Task.of(1)
    assert task.map(fn).fork(lambda err: err, lambda val: val) == 13

    task = Task.reject(1)
    assert task.map(fn).fork(lambda err: err, lambda val: val) == 1


# Generated at 2022-06-21 19:39:43.360958
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(2)

    t = Task(fork)
    result = t.map(lambda x: x + 2).fork(lambda e: e, lambda s: s)

    assert result == 4



# Generated at 2022-06-21 19:40:05.725195
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(arg):
        mocking = mocker.patch('src.models.Task')
        return mocking

    task = Task(lambda _, resolve: resolve(1))
    task = task.bind(fn)
    assert task == fn(1)


# Generated at 2022-06-21 19:40:07.937825
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value*2)

    task = Task.of(1).bind(fn)

    assert task.fork(lambda x: None, lambda x: x) == 2



# Generated at 2022-06-21 19:40:14.903505
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.bind(Task.of(1), lambda v: Task.of(v + 1)).fork(lambda e: e, lambda v: v) == 2
    assert Task.bind(Task.reject('error'), lambda _: Task.of(1)).fork(lambda e: e, lambda _: 'not error') == 'error'



# Generated at 2022-06-21 19:40:17.646943
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(val):
        return Task.of(val * 2)

    task = Task.of(2)
    assert task.bind(fn).fork(None, lambda val: val) == 4


# Generated at 2022-06-21 19:40:20.603399
# Unit test for constructor of class Task
def test_Task():
    def fork_without_param(reject, resolve):
        resolve('Hello, world')

    assert Task(fork_without_param).fork(None, print) == 'Hello, world'



# Generated at 2022-06-21 19:40:24.845676
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Should return rejected Task with value 5

    :returns: rejected Task
    :rtype: Task[reject, mapped_value]
    """
    def _fork(_reject, resolve):
        yield 0.01
        resolve(5)

    return Task(_fork).bind(lambda x: Task.reject(x))


# Generated at 2022-06-21 19:40:29.154256
# Unit test for method bind of class Task
def test_Task_bind():
    """
    This is unit test for method bind of class Task.
    """
    assert Task.of(10).bind(lambda value: Task.of(value + 10)) == Task.of(20)
    assert Task.reject(10).bind(lambda value: Task.reject(value + 10)) == Task.reject(20)


# Generated at 2022-06-21 19:40:31.594157
# Unit test for constructor of class Task
def test_Task():
    is_instance = isinstance(Task(lambda x: x), Task)
    is_callable = callable(Task(lambda x: x))
    assert is_instance and is_callable



# Generated at 2022-06-21 19:40:40.447368
# Unit test for method bind of class Task
def test_Task_bind():
    """
    This function run unit test for bind method of Task class.
    """
    def add(a, b):
        return a + b

    def subtract(a, b):
        return a - b

    def test(reject, resolve):
        return Task.of(3).bind(
            lambda arg: Task.of(arg + 1)
        ).bind(
            lambda arg: Task.of(arg - 1)
        ).fork(lambda arg: reject(arg), lambda arg: resolve(arg))

    assert test(lambda arg: "Error!", lambda arg: arg) == 4


# Generated at 2022-06-21 19:40:43.036143
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 2).fork == 2
    assert Task.of(3).map(lambda x: x * 5).fork == 15


# Generated at 2022-06-21 19:41:07.555051
# Unit test for constructor of class Task
def test_Task():
    """
    Test function of module.
    """
    # pylint: disable=protected-access
    obj = Task(None)
    assert obj.fork is None

    assert Task._reject(None) is None
    assert Task._resolve(None) is None

if __name__ == '__main__':
    test_Task()

# Generated at 2022-06-21 19:41:13.901953
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for map method of class Task.
    """
    def add_one(arg):
        return arg + 1

    def sub_two(arg):
        return arg - 2

    def add(arg1, arg2):
        return arg1 + arg2

    t1 = Task.of(5)
    assert t1.map(add_one).fork(lambda _: None, lambda arg: arg) == 6
    assert t1.map(sub_two).fork(lambda _: None, lambda arg: arg) == 3
    assert t1.map(lambda arg: add_one(arg)).fork(lambda _: None, lambda arg: arg) == 6
    assert t1.map(lambda arg: sub_two(arg)).fork(lambda _: None, lambda arg: arg) == 3


# Generated at 2022-06-21 19:41:21.461047
# Unit test for constructor of class Task
def test_Task():
    def resolve_task_factory(value):
        def resolve_task(rejected, resolved):
            return resolved(value)

        return resolve_task

    def reject_task_factory(value):
        def reject_task(rejected, resolved):
            return rejected(value)

        return reject_task

    assert Task(reject_task_factory("my value")).fork(lambda x: x, lambda x: "my value") == "my value"
    assert Task(resolve_task_factory("my value")).fork(lambda x: "my value", lambda x: x) == "my value"


# Generated at 2022-06-21 19:41:25.584773
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve("Value")

    task = Task(fork)

    assert isinstance(task, Task)
    assert task.fork is fork
    assert task.map is Task.map


# Generated at 2022-06-21 19:41:31.603569
# Unit test for method map of class Task
def test_Task_map():
    """
    test_Task_map: Function makes unit test for method map of class Task
    :returns:  None
    :rtype: NoneType
    """
    def mapper(x):
        return x * 2

    def caller(reject, resolve):
        return reject(1)

    tested = Task(caller)

    assert isinstance(tested.map(mapper), Task)

# Generated at 2022-06-21 19:41:35.333656
# Unit test for method bind of class Task
def test_Task_bind():
    def handler_unwrap_task(value):
        print("Test of Task.bind: catched value is", value)
        return Task.of(value*2)

    def handler_unwrap_task_error(value):
        print("Test of Task.bind: catched error is", value)
        return Task.of(value*2)

    Task.of(2.1).bind(
        lambda value: handler_unwrap_task(value)
    ).fork(
        reject=lambda value: handler_unwrap_task_error(value),
        resolve=lambda value: print("Test of Task.bind: result is", value)
    )


# Generated at 2022-06-21 19:41:39.941828
# Unit test for method map of class Task
def test_Task_map():
    add_one = lambda x: x + 1
    add_two = lambda x: x + 2
    add_three = lambda x: x + 3

    result = Task.of(0)\
        .map(add_one)\
        .map(add_two)\
        .map(add_three)\
        .fork(lambda _: None, lambda x: x)

    assert result == 6



# Generated at 2022-06-21 19:41:43.258527
# Unit test for method map of class Task
def test_Task_map():
    def fn(number):
        return number + 1

    task = Task.of(1)
    task2 = task.map(fn)

    assert task2.fork(None, lambda value: value) == 2
    assert task.fork(None, lambda value: value) == 1


# Generated at 2022-06-21 19:41:54.734376
# Unit test for method map of class Task
def test_Task_map():
    compute_with_error = lambda value: value if value > 5 else Exception('Value should be more than 5')
    run = lambda value: Task.of(value).map(compute_with_error)

    assert run(7).fork(lambda arg: arg, lambda _: None) is None
    assert isinstance(run(1).fork(lambda arg: arg, lambda _: None), Exception)

    # Test with Task
    compute_with_error = lambda value: Task.of(value) if value > 5 else Task.reject(Exception('Value should be more than 5'))
    run = lambda value: Task.of(value).bind(compute_with_error)

    assert run(7).fork(lambda arg: arg, lambda _: None) is None

# Generated at 2022-06-21 19:41:59.056570
# Unit test for method bind of class Task
def test_Task_bind():
    def arg_to_reject():
        return True

    def arg_to_resolve(arg):
        return arg

    def map_function(value):
        return Task(lambda _, resolve: resolve(value))

    with pytest.raises(Exception):
        Task(lambda _, resolve: resolve(None)).bind(map_function).fork(arg_to_reject, arg_to_resolve)

    assert Task.reject(None).bind(map_function).fork(arg_to_reject, arg_to_resolve)

# Generated at 2022-06-21 19:42:30.437554
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject('test')
        resolve('test')
    fork_test = Task(fork)
    assert fork_test.fork(lambda a: a, lambda a: a) == 'test'


# Generated at 2022-06-21 19:42:35.319930
# Unit test for method map of class Task
def test_Task_map():
    value = 6
    task = Task.of(value)
    len_2 = lambda value: len(value) ** 2
    def len_3(value):
        return len(value) ** 3

    assert task.map(len_2).fork(None, lambda res: res) == value ** 4
    assert task.map(len_3).fork(None, lambda res: res) == value ** 8


# Generated at 2022-06-21 19:42:37.770576
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(2).map(lambda x: x).fork(
        lambda _: print('test_Task_map: Error'),
        lambda _: print('test_Task_map: Ok')
    )


# Generated at 2022-06-21 19:42:46.606987
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1) \
        .bind(lambda x: Task.of(x + 2)) \
        .fork(lambda err: "REJECTED", lambda res: "RESOLVED: " + str(res)) == "RESOLVED: 3"

    assert Task.of(1) \
        .bind(lambda x: Task.reject("error message")) \
        .fork(lambda err: "REJECTED: " + str(err), lambda res: "RESOLVED") == "REJECTED: error message"

    assert Task.reject("error message") \
        .bind(lambda x: Task.of(x + 2)) \
        .fork(lambda err: "REJECTED: " + str(err), lambda res: "RESOLVED") == "REJECTED: error message"



# Generated at 2022-06-21 19:42:51.302342
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of('value') \
        .bind(lambda value: Task.reject(value)) \
        .fork(lambda reject: reject, lambda resolve: resolve)

    assert result == 'value'

# Generated at 2022-06-21 19:43:00.202318
# Unit test for method map of class Task
def test_Task_map():
    def identity_square(x): return x ** 2

    def square_identity(x): return x

    def throw(): return Task.reject('error')

    # Test for issue #100 on github
    # https://github.com/sloria/cookiecutter-flask/issues/100
    task = Task.of(1)
    task.map(square_identity)
    task.map(identity_square)
    task.map(throw)
    assert task.fork(raise_, identity) == 1

    task = Task.of(1)
    task.bind(throw)
    assert task.fork(identity, raise_) == 'error'

# Generated at 2022-06-21 19:43:04.277342
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task
    """
    assert Task(lambda _, resolve: resolve(1)).fork(lambda a: a, lambda a: a) == 1
    assert Task(lambda reject, _: reject(1)).fork(lambda a: a, lambda b: b) == 1


# Generated at 2022-06-21 19:43:11.133255
# Unit test for method map of class Task
def test_Task_map():
    """
    Task#map(Function) -> Task[Function(resolve, reject) -> mapped_value]
    """

    def mapper(value):
        if isinstance(value, int):
            return value + 1
        if isinstance(value, str):
            return value[:1]
        return value

    assert Task.of(1).map(mapper).fork(raise_error, identity) == 2
    assert Task.of('hello world').map(mapper).fork(raise_error, identity) == 'h'
    assert Task.of(None).map(mapper).fork(raise_error, identity) is None

# Generated at 2022-06-21 19:43:17.872118
# Unit test for method map of class Task
def test_Task_map():
    """
    It should be able to map Task[String] to Task[Integer]
    """
    def mapper(arg):
        try:
            return int(arg)
        except ValueError:
            return arg

    # should return resolved Task with integer as value
    assert Task.of("1").map(mapper).fork(lambda reject: reject, lambda resolve: resolve) == 1
    # should return resolved Task with value
    assert Task.of("value").map(mapper).fork(lambda reject: reject, lambda resolve: resolve) == "value"


# Generated at 2022-06-21 19:43:23.823375
# Unit test for method bind of class Task
def test_Task_bind():
    """
    This is unit tests for Task.bind() method.
    """
    assert Task.of(42).bind(
        lambda arg: Task.of(arg)
    ).fork(lambda arg: arg, lambda arg: arg) == 42

    assert Task.of(42).bind(
        lambda arg: Task.of(arg * 10)
    ).fork(lambda arg: arg, lambda arg: arg) == 420

    assert Task.of(42).bind(
        lambda arg: Task.reject(arg)
    ).fork(lambda arg: arg, lambda arg: arg) == 42



# Generated at 2022-06-21 19:43:51.740238
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, __: None)


# Generated at 2022-06-21 19:43:55.241564
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def add_three(x):
        return x + 3

    def mocked_fork(reject, resolve):
        return resolve(1)

    assert Task(mocked_fork) \
        .map(add_one) \
        .map(add_three).fork(None, lambda x: x) == 5


# Generated at 2022-06-21 19:43:59.827562
# Unit test for constructor of class Task
def test_Task():
    """
    Test implementation of constructor of class Task
    """
    fork_value = 1
    fork = lambda _, resolve: resolve(fork_value)
    task = Task(fork)

    assert isinstance(task, Task)


# Generated at 2022-06-21 19:44:10.852387
# Unit test for method bind of class Task
def test_Task_bind():
    sequence = (10, 20, 30, 40, 50)
    result_sequence = (20, 40, 60, 80, 100)
    index = 0

    def fork(reject, resolve):
        try:
            resolve(sequence[index])
        except IndexError:
            reject('Was called fork more than {} times'.format(len(sequence)))

    def bind(value):
        return Task.of(value * 2)

    task = Task(fork)

    def resolve(value):
        nonlocal index

        assert index < len(sequence)
        assert value == result_sequence[index]
        index += 1

    def reject(error):
        assert error == 'Was called fork more than {} times'.format(len(sequence))
        assert index == len(sequence)

    while True:
        task = task.bind(bind)
        task

# Generated at 2022-06-21 19:44:15.245506
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(value):
        return Task.of(value * 10)

    task = Task.of(1)
    task_bind = task.bind(test_function)
    assert task_bind.fork(
        lambda value: None,
        lambda value: value == 10
    ) is True
