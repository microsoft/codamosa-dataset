

# Generated at 2022-06-21 19:34:15.424710
# Unit test for method map of class Task
def test_Task_map():
    def example_fork(reject, resolve):
        resolve(2)

    task = Task(example_fork)
    result = Task(example_fork).map(lambda x:  x * 2)

    assert result.fork(lambda _: None, lambda x:  x) == 4


# Generated at 2022-06-21 19:34:18.037093
# Unit test for constructor of class Task
def test_Task():
    assert Task.of("Hello") != Task.of("HellO")
    assert Task.of("HellO") == Task.reject("HellO")
    assert Task.of("HellO") != Task.of("World")



# Generated at 2022-06-21 19:34:19.043509
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task(lambda _, __: None), Task)

# Generated at 2022-06-21 19:34:23.932293
# Unit test for constructor of class Task
def test_Task():
    """
    >>> test_Task()
    {'fork': <function Task.__init__.<locals>.test_Task.<locals>.<lambda> at 0x1108ff620>}
    """

    def inner_function(reject, resolve):
        return None

    task = Task(inner_function)
    print(task.__dict__)


# Generated at 2022-06-21 19:34:33.682128
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        assert reject is not None
        assert resolve is not None

    fork_1 = lambda _, resolve: resolve(10)
    fork_2 = lambda reject, _: reject(20)

    task = Task(fork)
    try:
        task.fork(None, None)
    except IOError as error:
        assert error.message == 'fork is None'

    task = Task(fork_1)
    assert task.fork(None, None) == 10

    task = Task(fork_2)
    assert task.fork(None, None) == 20


# Generated at 2022-06-21 19:34:40.212588
# Unit test for method bind of class Task
def test_Task_bind():
    """Task.bind is called during fork.
    If Task.reject is called, new Task is rejected.
    Otherwise new Task is resolved with result of calling bind function.
    """
    called = []
    task = Task(lambda reject, resolve: resolve(2))
    def fn(arg):
        called.append(arg)
        return Task.of(arg * 2)
    result = task.bind(fn)
    assert called == []
    assert result.fork(lambda x: x, lambda x: x) == 4
    assert called == [2]

    called = []
    task = Task.reject('err')
    result = task.bind(fn)
    assert called == []
    assert result.fork(lambda x: x, lambda x: x) == 'err'
    assert called == []


# Generated at 2022-06-21 19:34:46.290453
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    """
    # hello -> HELLO
    def to_upper(value):
        return Task.of(value.upper())

    # None -> hello
    def hello(value):
        return Task.of('hello')

    # assert Task.reject(None).bind(hello) == Task.reject(None)
    # assert Task.of(None).bind(hello) == Task.of('hello')
    # assert Task.of('hello').bind(to_upper) == Task.of('HELLO')
    # assert Task.of('hello').bind(lambda value: Task.reject(value)).bind(to_upper) == Task.reject('hello')
    # assert Task.of('hello').bind(lambda value: Task.reject(value)).bind(to_upper) == Task.

# Generated at 2022-06-21 19:34:49.670703
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject('error')
        return resolve('value')

    task = Task(fork)
    assert isinstance(task.fork, Function)
    assert task.fork.name == 'fork'


# Generated at 2022-06-21 19:34:51.785042
# Unit test for constructor of class Task
def test_Task():
    def fork_example(reject, resolve):
        pass

    task = Task(fork_example)

    assert task.fork == fork_example


# Generated at 2022-06-21 19:34:54.457072
# Unit test for constructor of class Task
def test_Task():
    def mock_fork(reject, resolve):
        return 1

    task = Task(mock_fork)

    assert task.fork(mock_fork) == 1


# Generated at 2022-06-21 19:35:03.126436
# Unit test for method bind of class Task
def test_Task_bind():
    # Setup fixture
    def fn(arg):
        return Task.of(arg + 1)

    task = Task.of(1)

    # Exercise and verify
    assert task.bind(fn).fork(lambda _: None, lambda result: result) == 2


# Generated at 2022-06-21 19:35:08.060600
# Unit test for method bind of class Task
def test_Task_bind():
    def mock_fork(reject, resolve):
        resolve(1)

    def mock_map(arg):
        return Task.of(arg + 1)

    task = Task(mock_fork)
    assert task.bind(mock_map).fork(None, lambda value: value) == 2

# Generated at 2022-06-21 19:35:10.867709
# Unit test for constructor of class Task
def test_Task():
    value = randint(0, 100)

    def result(reject, resolve):
        return value

    assert Task(result).fork(lambda _: None, lambda _: None) == value

# Generated at 2022-06-21 19:35:19.457002
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    assert_equal = lambda task, reject, resolve: task.fork(reject, resolve)

    def add_one(value):
        return Task.of(value + 1)

    def fail_task(_):
        return Task.reject('Error!')

    assert_equal(
        Task.of(0).bind(add_one),
        lambda error: False,
        lambda result: result == 1
    )

    assert_equal(
        Task.of(0).bind(fail_task),
        lambda error: error == 'Error!',
        lambda _: False
    )


# Generated at 2022-06-21 19:35:23.244998
# Unit test for constructor of class Task
def test_Task():
    """
    Create new task, resolve it and check if stored value equals value stored in Task.

    :return: None
    :rtype: None
    """
    def fork(reject, resolve):
        resolve(5)

    task = Task(fork)
    assert task.fork(lambda _: None, lambda value: value) == 5


# Generated at 2022-06-21 19:35:28.153074
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda value: 2 * value).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-21 19:35:35.598590
# Unit test for method bind of class Task
def test_Task_bind():
    task_reject = Task.reject("an error")
    task_reject_2 = task_reject.bind(lambda _: Task.of("a value"))

    assert task_reject_2.fork(lambda arg: arg, lambda _: None) == "an error"

    task_resolve = Task.of("a value")
    task_resolve_2 = task_resolve.bind(lambda arg: Task.reject("an error"))

    assert task_resolve_2.fork(lambda arg: arg, lambda _: None) == "an error"


# Generated at 2022-06-21 19:35:41.085045
# Unit test for constructor of class Task
def test_Task():
    def test_of(reject, resolve):
        resolve(1)

    def test_reject(reject, resolve):
        reject(1)

    assert Task(test_of).fork(lambda x: x, lambda x: x) == 1
    assert Task(test_reject).fork(lambda x: x, lambda x: x) == 1



# Generated at 2022-06-21 19:35:43.969758
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda *_: None, lambda arg: arg) == 1
    assert Task.reject(1).fork(lambda arg: arg, lambda *_: None) == 1


# Generated at 2022-06-21 19:35:46.716019
# Unit test for constructor of class Task
def test_Task():
    def func():
        return None

    instance = Task(func)

    assert isinstance(instance, Task)
    assert callable(instance.fork)
    assert instance.fork == func


# Generated at 2022-06-21 19:35:56.710756
# Unit test for method bind of class Task
def test_Task_bind():
    """
        Unit test for method "bind" of class Task
    """

    task = Task.of(1)
    task = task.bind(lambda x: Task.of(x + 1))
    task = task.bind(lambda x: Task.of(x + 1))
    task = task.bind(lambda x: Task.reject(x + 1))
    assert task.fork(lambda x: x, lambda x: -x) == 4


if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-21 19:36:06.753224
# Unit test for constructor of class Task
def test_Task():
    """
    Test show how Task works.
    """
    # assert Task.of('foo').fork(
    #     lambda value: 'foo',
    #     lambda value: value
    # ) == 'foo'

    # assert Task.of('bar').fork(
    #     lambda value: value,
    #     lambda value: 'bar'
    # ) == 'bar'

    # assert Task.reject('foo').fork(
    #     lambda value: 'foo',
    #     lambda value: value
    # ) == 'foo'

    # assert Task.reject('bar').fork(
    #     lambda value: value,
    #     lambda value: 'bar'
    # ) == 'bar'
    # print(Task.of(5).map(lambda x: x + 1).map(lambda x: x + 2).fork

# Generated at 2022-06-21 19:36:14.273896
# Unit test for constructor of class Task
def test_Task():
    @pytest.mark.parametrize('value', range(10))
    def test_of(value):
        assert Task.of(value).fork(lambda x: False, lambda y: x == y)

    @pytest.mark.parametrize('value', range(10))
    def test_reject(value):
        assert Task.reject(value).fork(lambda x: x == x, lambda y: False)

    @pytest.mark.parametrize('value', range(10))
    def test_map(value):
        assert Task.of(value).map(lambda x: x + 1).fork(lambda x: False, lambda y: y == value + 1)

    @pytest.mark.parametrize('value', range(10))
    def test_bind(value):
        assert Task.of

# Generated at 2022-06-21 19:36:21.155252
# Unit test for method bind of class Task
def test_Task_bind():
    def throw(value):
        raise RuntimeError('Error during execution of Task')

    def success(value):
        return Task.of(value + value)

    assert Task.of('test') \
        .bind(success) \
        .fork(throw, lambda value: value == 'testtest') \
        == True

    assert Task.of('test') \
        .bind(lambda arg: Task.reject(arg)) \
        .fork(lambda arg: arg == 'test', throw) \
        == True


# Generated at 2022-06-21 19:36:23.369045
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        def g(y):
            return x + y
        return g

    value = Task.of(1).bind(f)(1)

    assert value == 2


# Generated at 2022-06-21 19:36:26.184127
# Unit test for constructor of class Task
def test_Task():
    # Equal
    assert Task.of(1).fork(_, identity) == 1

    # No-Equal
    assert Task.of(1).fork(identity, _) != 2

    # Error
    try:
        Task.of(1).fork(error, identity)
    except AssertionError as e:
        assert True


# Generated at 2022-06-21 19:36:37.970629
# Unit test for method bind of class Task
def test_Task_bind():
    counter = 0

    def increment_counter():
        def increment(counter):
            return Task.of(counter + 1)
        return increment

    def decrement_counter():
        def decrement(counter):
            return Task.of(counter - 1)
        return decrement

    def task_counter(reject, resolve):
        return Task(lambda _, resolve: resolve(counter)).bind(increment_counter()).bind(increment_counter()).bind(decrement_counter()).fork(reject, resolve)

    def test_task(reject, resolve):
        Task(task_counter).fork(reject, resolve)

    def task_assert(value):
        return Task.of(1 == value)

    Task(task_assert).fork(lambda value: sys.exit(1), lambda value: sys.exit(0))


# Generated at 2022-06-21 19:36:44.227941
# Unit test for method bind of class Task
def test_Task_bind():
    def get_op(op):
        def operation(arg):
            return Task.of(arg + op)
        return operation

    def get_task(op):
        return Task.of(op).map(lambda arg: arg * 2).bind(get_op("!"))

    assert "10!" == get_task("5").fork(None, lambda arg: arg)
    assert "0!" == get_task("0").fork(None, lambda arg: arg)
    assert "22!" == get_task("11").fork(None, lambda arg: arg)


# Generated at 2022-06-21 19:36:49.452590
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        def fn(arg):
            return Task.of(arg * 10)

        return Task.of(10).bind(fn).fork(reject, resolve)

    def reject(arg):
        assert False

    def resolve(arg):
        assert arg == 100

    Task(fork).fork(reject, resolve)

# Generated at 2022-06-21 19:37:00.422494
# Unit test for constructor of class Task
def test_Task():
    def ok_fork(reject, resolve):
        return reject('OK_REJECT_VALUE')

    def nok_fork(reject, resolve):
        return reject('NOK_REJECT_VALUE')

    def fork_with_value(value):
        def fn(reject, resolve):
            return resolve(value)
        return fn

    assert Task(ok_fork).fork(lambda arg: arg, lambda arg: arg) == 'OK_REJECT_VALUE'
    assert Task(nok_fork).fork(lambda arg: arg, lambda arg: arg) == 'NOK_REJECT_VALUE'
    assert Task(fork_with_value(None)).fork(lambda arg: arg, lambda arg: arg) is None
    assert Task(fork_with_value(42)).fork(lambda arg: arg, lambda arg: arg) == 42
   

# Generated at 2022-06-21 19:37:06.641235
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: resolve(1)).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1

    assert Task(lambda reject, resolve: reject(1)).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1


# Generated at 2022-06-21 19:37:11.074490
# Unit test for constructor of class Task
def test_Task():
    def fork(rejected, resolved):
        resolved(2)

    task = Task(fork)
    assert task.fork(lambda rejected: rejected, lambda resolved: resolved) == 2


# Generated at 2022-06-21 19:37:15.319826
# Unit test for constructor of class Task
def test_Task():
    t = Task(lambda reject, resolve: resolve(42))
    assert t.fork(lambda _: None, lambda value: value) == 42
    assert t.fork(lambda _: None, lambda _: None) is None
    assert t.fork(lambda _: None, lambda _: 1) == 1


# Generated at 2022-06-21 19:37:18.127158
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    task = task.map(lambda x: x * 2)
    assert task.fork(lambda x: None, lambda x: x) == 4


# Generated at 2022-06-21 19:37:22.458761
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(42)
    task = task.bind(lambda x: Task.of(x + 1))
    result = task.fork(lambda x: f'error: {x}', lambda x: x)

    if result == 43:
        print('[✓] test_Task_bind')
    else:
        print('[✗] test_Task_bind')


# Generated at 2022-06-21 19:37:26.138198
# Unit test for constructor of class Task
def test_Task():
    def test_fork_call(reject, resolve):
        return reject("bad")

    t = Task(test_fork_call)

    assert t.fork(
        lambda arg: "Success",
        lambda arg: "Fail"
    ) == "Success"


# Generated at 2022-06-21 19:37:36.618860
# Unit test for method bind of class Task
def test_Task_bind():
    """Unit test for method bind of class Task"""
    # Call method with None argument
    def test_with_None_argument(method):
        """Unit test with None argument"""
        try:
            method(None)
            raise AssertionError('"bind" method of class Task should raise TypeError')
        except TypeError:
            pass

    def test_with_wrong_argument_type(method):
        """Unit test with wrong argument type"""
        try:
            method(lambda x: x)
            raise AssertionError('"bind" method of class Task should raise TypeError')
        except TypeError:
            pass

    def test_with_wrong_return_type(method):
        """Unit test with wrong return type"""

# Generated at 2022-06-21 19:37:46.358548
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    def make_error():
        raise Error("test error")

    def make_error_with_try_catch():
        try:
            make_error()
        except Error:
            pass

    def make_ok(arg):
        return arg

    def make_ok_with_try_catch(arg):
        try:
            make_error()
        except Error:
            return arg

    # test for case, when resolve function throwed error
    assert Task.of(1)\
        .map(make_ok)\
        .bind(lambda value: Task.of(3).map(make_error))\
        .fork(lambda err: err.message, lambda _: 0) == "test error"

    # test for case, when first map function throwed error

# Generated at 2022-06-21 19:37:53.013677
# Unit test for method map of class Task
def test_Task_map():
    source = Task(lambda r, rs: rs(1))
    mapped = source.map(lambda x: x + 1)
    assert 1 == mapped.fork(lambda x: "I can't resolve this task", lambda x: x)


# Generated at 2022-06-21 19:38:03.463491
# Unit test for method bind of class Task
def test_Task_bind():
    def add1(x):
        return Task.of(x + 1)

    def double_bind(x):
        return Task.of(x ** 2).bind(add1).bind(add1).bind(add1)

    def add1_map(x):
        return Task.of(x + 1).map(lambda x: x + 1)

    def double_map(x):
        return Task.of(x ** 2).map(lambda x: x + 1).map(lambda x: x + 1)

    assert double_bind(1).fork(lambda x: x, lambda x: x) == 9
    assert add1_map(2).fork(lambda x: x, lambda x: x) == 4
    assert double_map(2).fork(lambda x: x, lambda x: x) == 9

# Generated at 2022-06-21 19:38:13.651936
# Unit test for method bind of class Task
def test_Task_bind():
    def result(reject, resolve):
        Task(lambda _, resolve: resolve(1)).bind(
            lambda arg: Task(
                lambda _, resolve: resolve(arg + 1)
            )
        ).fork(reject, resolve)

    assert Task(result).fork(raise_, lambda a: a) == 2

# Generated at 2022-06-21 19:38:14.879284
# Unit test for constructor of class Task
def test_Task():
    ''' lambda should be set as fork
    '''
    def fork(*args):
        pass
    task = Task(fork)
    assert task.fork is fork


# Generated at 2022-06-21 19:38:17.248391
# Unit test for method map of class Task
def test_Task_map():
    def check(value, fn):
        assert Task.of(value).map(fn).fork(None, lambda value: value) == fn(value)

    check(10, lambda n: n * n)
    check("Hello", lambda s: s + s)


# Generated at 2022-06-21 19:38:20.681812
# Unit test for method map of class Task
def test_Task_map():
    """
    Function, which test map method of Task class.
    """
    # Init objects of Task to check tests
    task = Task.of(3)
    task_mapper = task.map(lambda value: value + 1)
    # Check right work of task.map
    assert task_mapper.fork(lambda value: value, lambda value: value) == 4


# Generated at 2022-06-21 19:38:24.573317
# Unit test for method map of class Task
def test_Task_map():
    """
    To run test execute in console:
    python -m doctest ./task.py -v
    """
    assert Task.of(2).map(lambda x: x * 2).fork(identity, identity) == 4


# Generated at 2022-06-21 19:38:28.840658
# Unit test for constructor of class Task

# Generated at 2022-06-21 19:38:33.267944
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        if value == 2:
            return Task.reject("wrong value")
        return Task.of(value * 2)

    assert Task.of(2).bind(mapper).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == "wrong value"

    assert Task.of(1).bind(mapper).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 2


# Generated at 2022-06-21 19:38:36.838026
# Unit test for method bind of class Task
def test_Task_bind():
    def result(resolve, reject):
        Task.of(43) \
            .bind(lambda value: Task.of(value + 1)) \
                .fork(reject, resolve)

    task = Task(result)
    wrapper = task.fork(lambda _: None, lambda value: value)
    assert wrapper == 44


# Generated at 2022-06-21 19:38:41.125411
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        reject('Error')

    def fork_mapper(reject, resolve):
        resolve('mapped')

    error_mapped = Task(fork).bind(lambda value: Task(fork_mapper))
    assert 'mapped' == error_mapped.fork(print, print)


# Generated at 2022-06-21 19:38:51.812041
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Method bind of class Task must return Task with resolve with result
    of calling bind function and reject with result of calling function bind with error.

    :returns: assert result be equals to result of calling bind function
    :rtype: None
    """
    # Generate mock resolve function and store it in value to use it in test_Task_resolve
    result = None
    def resolve_mock(value):
        """
        Mock resolve function to overwrite during test

        :param value: value to store in result
        :type value: A
        :returns: None
        :rtype: None
        """
        nonlocal result
        result = value

    # Generate mock reject function, but not use it in method reject

# Generated at 2022-06-21 19:39:09.203435
# Unit test for method map of class Task
def test_Task_map():
    def toUpper(_):
        return 'A'

    result = Task(lambda _, resolve: resolve('a')).map(toUpper)
    assert isinstance(result, Task)

    inner_value = result._fork(
        lambda arg: 'reject',
        lambda arg: 'resolve: %s' % arg
    )

    assert inner_value == 'resolve: A'


# Generated at 2022-06-21 19:39:16.758641
# Unit test for method bind of class Task
def test_Task_bind():
    def test_reject():
        @Task.of
        def error(reject):
            return reject('error')

        @Task.of
        def binded_error(reject):
            @Task.of
            def error_resolve():
                return 'ok'

            @error.bind
            def error_binded(resolve):
                return error_resolve

            return 'ok'

        assert binded_error.fork('error', lambda arg: arg) == 'error'

    def test_resolve():
        @Task.of
        def resolve(reject):
            return 'ok'

        @Task.of
        def binded_resolve(reject):
            @Task.of
            def resolve_resolve(arg):
                assert arg == 'ok'
                return 'ok'


# Generated at 2022-06-21 19:39:19.957865
# Unit test for constructor of class Task
def test_Task():
    def test_1(reject, resolve):
        return resolve(1)

    t = Task(test_1)
    assert t.fork(lambda _: None, lambda v: None) == 1


# Generated at 2022-06-21 19:39:25.203925
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    def sub(a, b):
        return a - b

    result = Task.of(1).map(add, 2).map(sub, 4)
    assert result.fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == -1



# Generated at 2022-06-21 19:39:28.833437
# Unit test for constructor of class Task
def test_Task():
    def _(reject, resolve):
        return resolve("test task")

    assert Task(_).fork(
        lambda value: "error " + value,
        lambda value: "test task"
    ) == "test task"


# Generated at 2022-06-21 19:39:31.673689
# Unit test for constructor of class Task
def test_Task():
    def test_fork(reject, resolve):
        reject('foo')
        resolve('bar')

    task = Task(test_fork)
    assert task.fork == test_fork


# Generated at 2022-06-21 19:39:36.854804
# Unit test for method bind of class Task
def test_Task_bind():
    """
    call bind method with Task of 1
    return new Task of 1 and call bind method with Task of 1 again
    check, that all methods was called
    """
    fork_mock = Mock(return_value=None)
    task = Task(fork_mock)
    task.bind(lambda _: Task(fork_mock))

    assert fork_mock.call_count == 3
    fork_mock.assert_any_call(ANY, ANY)
    fork_mock.assert_any_call(ANY, ANY)
    fork_mock.assert_any_call(ANY, ANY)


# Generated at 2022-06-21 19:39:42.935528
# Unit test for constructor of class Task
def test_Task():

    task = Task(lambda reject, resolve: resolve("Hello World!"))
    assert("Hello World!" == task.fork(lambda _: '', lambda res: res))

    task = Task.of("Hello world")
    assert("Hello world" == task.fork(lambda _: '', lambda res: res))

    task = Task.reject("Hello world")
    assert("Hello world" == task.fork(lambda res: res, lambda _: ''))


# Generated at 2022-06-21 19:39:54.327279
# Unit test for constructor of class Task

# Generated at 2022-06-21 19:40:04.524929
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method map of Task class
    """
    class TaskTester:
        """
        Wrapper class for test Task
        """
        task = None
        reject_arg = None
        resolve_arg = None
        fork_counter = 0

    def fork(reject, resolve):
        TaskTester.fork_counter += 1
        TaskTester.reject_arg = reject
        TaskTester.resolve_arg = resolve
        TaskTester.task.fork(reject, resolve)

    class TaskContainer:
        """
        Container for test methods
        """

        def test_map_integer(self):
            """
            Test method map with integer value
            """
            TaskTester.task = Task.of(5)
            mapped = TaskTester.task.map(lambda x: x * 2)
            mapped

# Generated at 2022-06-21 19:40:28.844119
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task(lambda _, r: r(None)), Task)


# Generated at 2022-06-21 19:40:31.590704
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task constructor.
    """

    def func(reject, resolve):
        """
        Test fork function.
        """
        resolve(0)
        reject(1)

    task = Task(func)

    assert task.fork is func

# Generated at 2022-06-21 19:40:35.106554
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return x + 1

    def fn_1(x):
        return Task.of(x).map(add)

    def fn_2(x):
        return Task.of(x).map(lambda _: None).map(add)

    assert Task.of(1).bind(fn_1).fork(None, print) == 2
    assert Task.of(1).bind(fn_2).fork(None, print) == 2

# Generated at 2022-06-21 19:40:40.178205
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for testing map method.
    """

    def f(x):
        return x + 1

    def g(x):
        return x * 2

    declared_task = Task(lambda _, resolve: resolve(2))

    actual_task = declared_task.map(f).map(g)

    expected_task = Task(lambda _, resolve: resolve(g(f(2))))

    assert hash(actual_task) == hash(expected_task)

    assert actual_task.fork(lambda arg: arg, lambda arg: arg) == expected_task.fork(lambda arg: arg, lambda arg: arg)



# Generated at 2022-06-21 19:40:44.545157
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve('val')

    task = Task(fork)
    assert task.fork(lambda x: 'reject', lambda x: 'resolve') == 'resolve'


# Generated at 2022-06-21 19:40:48.117078
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(None, assert_equal)(None, 2)
    assert Task.reject(1).map(lambda x: x + 1).fork(assert_equal, None)(None, 2)


# Generated at 2022-06-21 19:40:52.453979
# Unit test for method map of class Task
def test_Task_map():
    """
    test of method map of class Task:
        method take function and call it with Unwrapped value of Task.
        method return new Task with mapped result of function.
    """
    value = Task.of(2).map(lambda x: x * 2).fork(lambda x: None, lambda x: x)
    assert value == 4, "Task map method error"


# Generated at 2022-06-21 19:40:57.935282
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for .bind method of Task class.
    """
    # Setup
    value = 5

    # Exercise
    result = Task \
        .of(value) \
        .bind(lambda v: Task.of(v * 10)) \
        .fork(lambda _: None, lambda v: None)

    # Verify
    assert result == 50


# Generated at 2022-06-21 19:41:01.424100
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    test_fork = MagicMock()
    T = Task(test_fork)

    assert T.fork == test_fork



# Generated at 2022-06-21 19:41:04.052731
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    assert Task(lambda reject, resolve: resolve('Here is value')).fork(None, lambda arg: arg) == 'Here is value'


# Generated at 2022-06-21 19:41:55.665442
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda _: 'wrong', lambda value: value) == 1
    assert Task.reject(1).fork(lambda value: value, lambda _: 'wrong') == 1



# Generated at 2022-06-21 19:41:59.034020
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        if value == 0:
            return Task.of(1)
        else:
            return Task.reject(2)

    t = Task.of(0).bind(fn)
    assert t.fork(lambda x: x, lambda x: x) == 1

    t = Task.of(1).bind(fn)
    assert t.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-21 19:42:04.218979
# Unit test for constructor of class Task
def test_Task():
    value = 5

    mapping_function = lambda _: value + 1

    forked_function = lambda reject, resolve: resolve(value)

    task = Task(forked_function)

    assert task.fork(lambda arg: arg, lambda arg: arg) == value
    assert task.map(mapping_function).fork(lambda arg: arg, lambda arg: arg) == value + 1
    assert task.bind(Task.of).fork(lambda arg: arg, lambda arg: arg) == value


# Generated at 2022-06-21 19:42:12.900888
# Unit test for method map of class Task
def test_Task_map():
    def plus_one(x): return x + 1
    def return_two(): return Task.of(2)
    def return_three(x): return Task.of(x + 2)

    assert Task.of(1).map(return_two)\
            .map(return_three).fork(None, lambda x: x) == 5

    assert Task.of(1).bind(return_two)\
            .bind(return_three).fork(None, lambda x: x) == 5

    def return_negative(x): return Task.reject(-x)

    assert Task.of(1).bind(return_negative)\
            .map(plus_one).fork(lambda x: x, None) == 1

# Generated at 2022-06-21 19:42:14.712354
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return 42

    task = Task(fork)
    assert task.fork(lambda x: None, lambda x: None) == 42


# Generated at 2022-06-21 19:42:16.682023
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)

    def fn(val):
        return Task.of(val + 1)

    print(task.bind(fn).fork(print, print))



# Generated at 2022-06-21 19:42:20.361092
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for map method of class Task.
    """
    assert isinstance(Task.of(5), Task)
    assert Task.of(5).map(lambda x: x * 10).fork(__, lambda x: x) == 50


# Generated at 2022-06-21 19:42:24.018480
# Unit test for method bind of class Task
def test_Task_bind():
    root = Task.of(1)
    double = root.bind(lambda x: Task.of(x * 2))
    triple = root.map(lambda x: x * 3)

    assert double.fork(lambda x: x, lambda x: x) == 2
    assert triple.fork(lambda x: x, lambda x: x) == 3


# Generated at 2022-06-21 19:42:26.991258
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        print(value)
        return value

    def reject(value):
        raise Exception('Value is rejected')

    def add1(number):
        return number + 1

    assert Task(resolve).map(add1).fork(reject, resolve) == 2


# Generated at 2022-06-21 19:42:29.551046
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(42).fork(raise_, echo) == 42
    assert Task.reject(42).fork(echo, raise_) == 42
