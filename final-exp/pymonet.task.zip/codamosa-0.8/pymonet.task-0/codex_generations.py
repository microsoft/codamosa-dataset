

# Generated at 2022-06-12 05:36:11.360092
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value): return Task.of(2 * value)

    fn1 = Task.of(1).map(lambda value: value * 2).bind(fn)
    fn2 = Task.of(1).bind(fn).map(lambda value: value * 2)
    fn3 = Task.of(1).bind(lambda value: Task.of(value * 2)).map(fn)
    fn4 = Task.of(1).map(lambda value: value * 2).map(fn)

    assert fn1.fork(lambda error: error, lambda value: value) == 8
    assert fn2.fork(lambda error: error, lambda value: value) == 8
    assert fn3.fork(lambda error: error, lambda value: value) == 8
    assert fn4.fork(lambda error: error, lambda value: value) == 8

# Unit

# Generated at 2022-06-12 05:36:16.024689
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> Task.of(2).bind(lambda x: Task.of(x + 1)).fork(
    ...     lambda x: 'Reject!' + str(x),
    ...     lambda x: 'Resolve!' + str(x)
    ... )
    'Resolve!3'
    """


# Generated at 2022-06-12 05:36:21.181181
# Unit test for method bind of class Task
def test_Task_bind():
    def f1(x):
        return Task.of(x + 1)

    def f2(x):
        return Task.of(x * 3)

    def f3(x):
        return Task.of(x ** 2)

    # ((1 + 1) * 3) ** 2
    assert (Task.of(1).bind(f1).bind(f2).bind(f3)
            == Task.of(1).bind(lambda x: f1(x).bind(f2).bind(f3)))

# Generated at 2022-06-12 05:36:29.043730
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method.
    """
    class MockIdentity:
        def __init__(self):
            self.value = 3

    def test_bind(arg):
        def plus_one(x):
            return Task.of(x + 1)

        return arg.bind(plus_one).map(lambda x: x * 2)

    assert test_bind(Task.of(MockIdentity())).fork(None, lambda arg: arg.value) == 8
    assert test_bind(Task.reject(MockIdentity())).fork(lambda arg: arg.value, None) == 3

# Generated at 2022-06-12 05:36:33.576762
# Unit test for method bind of class Task
def test_Task_bind():
    def greet(name):
        return name

    def say_hello(name):
        return Task.of(greet(name))

    task = Task.of("John").bind(say_hello)

    assert task.fork(lambda reason: "Error", lambda value: value) == "John"

# Generated at 2022-06-12 05:36:45.135135
# Unit test for method bind of class Task
def test_Task_bind():
    """Test for Task class."""
    assert math.isclose(
        42,
        Task.of(84)
            .bind(lambda v: Task.of(v / 2))
            .bind(lambda v: Task.of(v * 2))
            .fork(
                reject=lambda e: 0,
                resolve=lambda v: v
            )
    )

    assert math.isclose(
        84,
        Task.of(84)
            .bind(lambda v: Task.reject(v / 2))
            .bind(lambda v: Task.of(v * 2))
            .fork(
                reject=lambda e: e,
                resolve=lambda v: 0
            )
    )


Task.of(42).map(lambda x: x + 1)

# Generated at 2022-06-12 05:36:54.017565
# Unit test for method bind of class Task
def test_Task_bind():
    # Test case 1
    # Not task value and not mapped
    # Resolved task value
    @Task.of(5)
    def test_data(value):
        assert value == 5

    # Test case 2
    # Task value but not mapped
    # Resolved task value
    @Task.of(Task.of(5))
    def test_data(value):
        assert value == 5

    # Test case 3
    # Task value and mapped
    # Resolved mapped task value
    @Task.of(Task.of(5)).bind(lambda value: Task.of(value + 1))
    def test_data(value):
        assert value == 6

    # Test case 4
    # Task value and mapped
    # Resolved mapped task value

# Generated at 2022-06-12 05:36:59.719918
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(rejected, resolved):
        resolved('return')

    def mapper(value):
        return Task.of(value + ' added')

    def fail(reason):
        assert False

    def success(value):
        assert value == 'return' + ' added'

    task = Task(fork)
    task.bind(mapper).fork(fail, success)

# Generated at 2022-06-12 05:37:10.365402
# Unit test for method bind of class Task
def test_Task_bind():
    def a(arg):
        assert arg == 'value'
        return Task.of('mapped value')


# Generated at 2022-06-12 05:37:19.113414
# Unit test for method bind of class Task
def test_Task_bind():
    import pytest

    A = Task(lambda reject: reject(101))
    B = Task.of(True)
    C = Task.of(True)
    D = Task.of(True)

    task = Task(lambda reject, resolve: resolve(100))
    task = task.bind(lambda x: A)  # fork: call of A - throw reject(101)
    with pytest.raises(Exception) as exc:
        task.fork(identity, identity)  # fork(reject, resolve) -> reject(101) -> Exception
    assert exc.value.args[0] == 101

    task = Task(lambda reject, resolve: resolve(100))
    task = task.bind(lambda x: B)  # fork: call of B - return True
    assert task.fork(identity, identity)  # fork(reject,

# Generated at 2022-06-12 05:37:28.939569
# Unit test for method bind of class Task
def test_Task_bind():
    def first_task(reject, resolve):
        resolve(1)

    def second_task(reject, resolve):
        reject(2)

    def third_task(reject, resolve):
        resolve(3)

    task = Task(first_task).bind(lambda arg: Task(second_task))
    assert task.fork(lambda arg: arg, lambda arg: arg) == 2

    task = Task(first_task).bind(lambda arg: Task(third_task))
    assert task.fork(lambda arg: arg, lambda arg: arg) == 3


# Generated at 2022-06-12 05:37:40.744844
# Unit test for method bind of class Task
def test_Task_bind():
    def async_func(*args, **kwargs):
        def cb(reject, resolve):
            if 'err' in kwargs:
                setTimeout(lambda: reject(kwargs['err']), 0)

            setTimeout(lambda: resolve(args[0]), 0)

        return Task(cb)

    def not_async_func(ignore, reject, resolve):
        resolve('result')

    assert Task.of('value').bind(lambda arg: Task.of(arg + ' 2')).fork(
        lambda err, res: res
    ) == 'value 2', 'Simple check for bind'

    assert Task.of('value').bind(lambda arg: Task.reject(arg + ' 2')).fork(
        lambda err, res: err
    ) == 'value 2', 'Simple check for bind with reject Task'


# Generated at 2022-06-12 05:37:44.704416
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.
    """
    def async_func(resolve, reject):
        resolve(5)

    def mapper(value):
        return value + 1

    task = Task(async_func)
    mapped = task.map(mapper)
    assert 6 == mapped.fork(None, None)


# Generated at 2022-06-12 05:37:48.074320
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x + 2).fork(
        lambda x: None,
        lambda x: x
    ) == 4



# Generated at 2022-06-12 05:37:56.167763
# Unit test for method map of class Task
def test_Task_map():
    def test_map_with_resolved_task(mapper, assert_):
        result = Task.of(1).map(mapper)

        def assert_result(result):
            return assert_.equal(result, mapper(1))

        def assert_error(error):
            return assert_.fail(error)

        return result.fork(assert_error, assert_result)

    TestCase(
        test_map_with_resolved_task,
        TestCase.mapper_eq_2,
        Assert()
    ).run()



# Generated at 2022-06-12 05:37:59.438676
# Unit test for method map of class Task
def test_Task_map():
    map_fn = lambda arg: arg + 1
    resolve_value = 2
    task = Task.of(resolve_value).map(map_fn)

    assert task.fork(lambda _: 1, lambda arg: arg) == map_fn(resolve_value)


# Generated at 2022-06-12 05:38:03.174554
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)).map(lambda arg: arg + 1).fork(
        lambda _: False,
        lambda arg: arg == 2
    )


# Generated at 2022-06-12 05:38:12.462426
# Unit test for method map of class Task
def test_Task_map():
    def test_of_map(arg):
        assert Task.of(5).map(lambda x: x + arg) == Task.of(5 + arg)

    test_of_map(0)
    test_of_map(1)
    test_of_map(10)
    test_of_map(100)

    def test_Task(arg):
        assert Task.of(5).map(lambda x: x + arg).fork(lambda x: x, lambda x: x) == 5 + arg

    test_Task(0)
    test_Task(1)
    test_Task(10)
    test_Task(100)


# Generated at 2022-06-12 05:38:16.719766
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve('test')).map(lambda arg: arg + '_mapped').fork(lambda err: err, lambda result: result) == 'test_mapped'


# Generated at 2022-06-12 05:38:25.378921
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test implementation of bind method for Task.

    Test check that task resolve with 2 as value and then bind with function +4 and returns 6
    Test check that task reject with 1 as value and then bind with function +4 and returns rejected with 1
    """
    def plus_four(value):
        return Task.of(value + 4)

    task = Task.of(2)
    assert task.bind(plus_four).fork(lambda x: x, lambda x: x) == 6

    task = Task.reject(1)
    assert task.bind(plus_four).fork(lambda x: x, lambda x: x) == 1



# Generated at 2022-06-12 05:38:34.393846
# Unit test for method map of class Task
def test_Task_map():
    T = Task
    assert T.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2
    assert T.reject(1).map(None).fork(lambda x: x, None) == 1


# Generated at 2022-06-12 05:38:38.071341
# Unit test for method map of class Task
def test_Task_map():
    t = Task.of(2)
    assert t.map(add(2)).fork(lambda x: None, lambda x: x) == 4


# Generated at 2022-06-12 05:38:49.361122
# Unit test for method bind of class Task

# Generated at 2022-06-12 05:38:59.308560
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> test_Task_bind()
    6
    """

    # return value of Task after calling fork method
    def add_one(value):
        return Task.of(value + 1)

    # return value of Task after calling fork method
    def add_two(value):
        return Task.of(value + 2)

    def add_three(value):
        return Task.of(value + 3)

    def add_four(value):
        return Task.of(value + 4)

    def add_five(value):
        return Task.of(value + 5)


# Generated at 2022-06-12 05:39:06.868085
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    def fork(reject, resolve):
        resolve(1)

    def add(arg):
        return Task.of(f'{arg + 1}')

    def sub(arg):
        return Task.of(f'{arg - 1}')

    task = Task(fork).bind(add).bind(sub)

    assert task.fork(None, lambda arg: arg) == '1'



# Generated at 2022-06-12 05:39:11.869569
# Unit test for method bind of class Task
def test_Task_bind():
    value = None
    def mock_fork(reject, resolve):
        resolve(value)

    def mock_bind(arg):
        assert arg == value

    mock_task = Task(mock_fork)
    mock_task.bind(mock_bind).fork(lambda _: None, lambda _: None)

# Generated at 2022-06-12 05:39:18.620855
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(val):
        assert val == 2
        return Task.of(3)

    def test(reject, resolve):
        assert reject == 'reject'
        assert resolve == 'resolve'
        return Task.of(2)

    t = Task(test)
    result = t.bind(fn)

    assert result.fork('reject', 'resolve') == 3



# Generated at 2022-06-12 05:39:23.499264
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        def g(y):
            def h(z):
                return Task.of(x+y+z)

            return Task.of(y).bind(h)

        return Task.of(x).bind(g)

    assert False not in [f(100).fork(lambda r: False, lambda r: r == 300),
                         f(200).fork(lambda r: False, lambda r: r == 600)]


# Generated at 2022-06-12 05:39:24.598650
# Unit test for method map of class Task
def test_Task_map():
    c_Task_map()


# Generated at 2022-06-12 05:39:28.612326
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind of Task.
    """
    my_task = Task.of(1).bind(lambda value: Task.of(value + 1))
    assert my_task.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-12 05:39:42.307626
# Unit test for method map of class Task
def test_Task_map():
    def foo(value):
        return value + 2

    task = Task.of(5)

    assert task.fork(lambda x: x, lambda x: x) == 5
    assert task.map(foo).fork(lambda x: x, lambda x: x) == 7


# Generated at 2022-06-12 05:39:45.418003
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(20).bind(lambda x: Task.of(x + 10)).fork(
        lambda result: result == 30,
        lambda result: False
    )


# Generated at 2022-06-12 05:39:53.521665
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test to check working of method bind.
    Method of class Task return new Task which value is result of call of given function.

    :returns: True if test is passed, else False
    :rtype: bool
    """

    def add(x):
        """
        Add 1 to given number

        :param x: number for increment by 1
        :type x: int
        :returns: number + 1
        :rtype: int
        """
        return x + 1

    def resolve_Task(x):
        """
        Return resolved Task with given number

        :param x: number for store
        :type x: int
        :returns: resolved Task with stored number
        :rtype: Task[Function(_, resolve) -> int]
        """
        return Task.of(x)


# Generated at 2022-06-12 05:39:58.818647
# Unit test for method map of class Task
def test_Task_map():
    """ Unit test for method map of class Task """
    task = Task.reject(5)
    r_task = task.map(lambda a: a * 2)

    assert r_task.fork(lambda a: a, lambda a: a) == 5

    task = Task.of(5)
    r_task = task.map(lambda a: a * 2)

    assert r_task.fork(lambda a: a, lambda a: a) == 10


# Generated at 2022-06-12 05:40:06.733549
# Unit test for method bind of class Task
def test_Task_bind():
    def create_task():
        return Task.of("value")

    def fork_test(reject, resolve):
        resolve("result")

    assert Task.reject("error").bind(create_task) == Task.reject("error")
    assert Task.of("value").bind(create_task) == Task.of("value")
    assert Task(fork_test).bind(create_task) == Task.of("result")
    assert Task(fork_test).bind(lambda value: Task.reject("error")) == Task.reject("error")


# Generated at 2022-06-12 05:40:12.231146
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x * 2

    task = Task.of(10)
    task1 = task.map(fn)

    assert task is not task1
    assert task1.fork(lambda x: x, lambda x: x) == 20


# Generated at 2022-06-12 05:40:21.441831
# Unit test for method map of class Task
def test_Task_map():
    # resolve path
    value = 1
    appended_value = ' ' + str(value)
    task = Task.of(value)
    result = task.map(lambda x: x + appended_value).fork(
        lambda reject: reject,
        lambda resolve: resolve
    )

    assert result == value + appended_value
    assert isinstance(result, str)

    # reject path
    value = 1
    appended_value = ' ' + str(value)
    task = Task.reject(value)
    result = task.map(lambda x: x + appended_value).fork(
        lambda reject: reject,
        lambda resolve: resolve
    )

    assert result == value
    assert isinstance(result, int)



# Generated at 2022-06-12 05:40:25.705327
# Unit test for method map of class Task
def test_Task_map():
    """
    Run unit test for method map of class Task.
    """

    def mapping_func(arg):
        return arg + 1

    value = 2
    t = Task.of(value)
    t_1 = t.map(mapping_func)

    assert t_1.fork(lambda _: None, lambda arg: arg == (value + 1))


# Generated at 2022-06-12 05:40:28.111850
# Unit test for method map of class Task
def test_Task_map():
    """
    Function test for method map of class Task.
    """
    def add10(value): return value + 10

    assert Task.of(10).map(add10) == Task.of(20)


# Generated at 2022-06-12 05:40:40.169247
# Unit test for method bind of class Task
def test_Task_bind():
    def timeout_fn(reject, resolve):
        def timeout_callback():
            resolve(1)

        setTimeout(timeout_callback, 1)

    timeout_task = Task(timeout_fn)

    def double(x):
        return x * 2

    to_zero_task = timeout_task.bind(lambda a: 0)

    # Test for correct result
    assert to_zero_task.fork(
        lambda a: True,
        lambda b: False
    ) is True

    # Test for correct fork of binded task
    assert to_zero_task.fork(
        lambda a: False,
        lambda b: b == 0
    ) is True

    # Test for correct fork of original task
    assert timeout_task.fork(
        lambda a: True,
        lambda b: False
    ) is True

    # Test for

# Generated at 2022-06-12 05:41:09.123260
# Unit test for method map of class Task
def test_Task_map():
    @Task
    def fibonacci(n, resolve, reject):
        if n == 0:
            return resolve(0)
        elif n == 1:
            return resolve(1)
        else:
            return fibonacci(n-1).fork(reject, lambda x1: \
                   fibonacci(n-2).fork(reject, lambda x2: resolve(x1 + x2)))

    def start_fibonacci(n):
        return Task.of(n).map(fibonacci)

    assert Task.of(0).map(fibonacci).fork(lambda _: False, lambda x: x == 0)
    assert Task.of(1).map(fibonacci).fork(lambda _: False, lambda x: x == 1)

# Generated at 2022-06-12 05:41:18.272013
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for implementation of method bind of class Task.
    """
    import unittest

    class TestBind(unittest.TestCase):
        """
        Unit test for method bind.
        """

        def test_return_mapper_value_type(self):
            """
            Test for return mapper value type.
            """

            def add(arg):
                """
                Function for transform number.

                :param arg: argument for transform
                :type arg: Int | Float
                :returns: new number
                :rtype: Int | Float
                """
                return arg + arg

            task = Task.of(1)

            self.assertIsInstance(task.map(add), Task)


# Generated at 2022-06-12 05:41:23.271446
# Unit test for method map of class Task
def test_Task_map():
    T = Task
    assert T.of(1).map(lambda x: x + 1).fork(None, test_eq(2))
    assert T.of([]).map(lambda xs: xs + [1, 2, 3]).fork(None, test_eq([1, 2, 3]))



# Generated at 2022-06-12 05:41:27.881579
# Unit test for method map of class Task
def test_Task_map():
    # Arrange
    task = Task.of(1).map(lambda x: x * 2)

    # Act
    result = task.fork(_.throw, lambda x: x)

    # Assert
    assert result == 2


# Generated at 2022-06-12 05:41:32.295599
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    task = Task.of(1).map(add_one)
    result = task.fork(
        lambda arg: 'Error',
        lambda arg: arg
    )
    assert result == 2


# Generated at 2022-06-12 05:41:41.418778
# Unit test for method bind of class Task
def test_Task_bind():
    def async_function(value):
        return Task.of(value + 1)

    # task = Task.of(1).bind(async_function)
    # (reject, resolve) = task.fork

    # resolve(1)
    # assert reject(1) == 2

    @asyncio.coroutine
    def test_function_async():
        task = Task.of(1).bind(lambda value: async_function(value))
        (reject, resolve) = task.fork
        yield from resolve(1)
        assert reject(1) == 2

    asyncio.get_event_loop().run_until_complete(
        test_function_async()
    )



# Generated at 2022-06-12 05:41:47.358008
# Unit test for method bind of class Task

# Generated at 2022-06-12 05:41:57.727110
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_double(n):
        return Task.of(n * 2)

    def fn_triple(n):
        return Task.of(n * 3)

    def fn_fail(n):
        return Task.of("fail")

    assert Task.of(2).bind(fn_double).fork(lambda x: None, lambda x: x) == 4
    assert Task.of(2).bind(fn_double).bind(fn_triple).fork(lambda x: None, lambda x: x) == 12
    assert Task.of(2).bind(fn_fail).bind(fn_triple).fork(lambda x: x, lambda x: None) == "fail"
    assert Task.of(2).bind(lambda n: n).fork(lambda x: None, lambda x: x) == 2


# Generated at 2022-06-12 05:42:00.805102
# Unit test for method map of class Task
def test_Task_map():
    def root(x):
        return x ** 0.5

    t = Task.of(4).map(root)
    assert type(t) == Task
    assert t.fork(None, lambda value: value) == 2.0



# Generated at 2022-06-12 05:42:05.389370
# Unit test for method bind of class Task
def test_Task_bind():
    def task_creator(result):
        def fork(_, resolve):
            return resolve(result)

        return Task(fork)

    task = task_creator(1)
    new_task = task.bind(lambda value: task_creator(value+1))
    assert new_task.fork(
        lambda _: 'Rejected',
        lambda value: value
    ) == 2

# Generated at 2022-06-12 05:42:54.426907
# Unit test for method bind of class Task
def test_Task_bind():
    # Declare test variables
    count = [0]

    # Create Task with fork function
    # for test bind function
    task = Task(lambda reject, resolve: resolve(count[0]))

    def fn(value):
        # Increase value of count by 1
        count[0] = value + 1

        # Return Task with new value
        return Task.of(value + 1)

    # Test method bind with checking count value
    assert count[0] == 0
    task.bind(fn).fork(lambda _: None, lambda _: None)
    assert count[0] == 1


# Generated at 2022-06-12 05:42:57.545092
# Unit test for method map of class Task
def test_Task_map():
    def mapper(arg):
        return arg + 5

    task = Task.of(5)
    result = task.map(mapper).fork(None, None)

    assert result == 10



# Generated at 2022-06-12 05:43:07.809088
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map methods from Task type.
    """
    # Test map:
    assert Task.of(True).map(lambda x: not x).fork(
        lambda arg: arg,
        lambda arg: arg
    ) is False

    assert Task.of(True).map(lambda x: not x).fork(
        lambda arg: arg,
        lambda arg: arg
    ) is False

    assert Task.of(None).map(lambda x: x or True).fork(
        lambda _: True,
        lambda arg: arg
    ) is True

    assert Task.of(None).map(lambda x: x or None).fork(
        lambda arg: arg,
        lambda _: True
    ) is None


# Generated at 2022-06-12 05:43:13.382210
# Unit test for method map of class Task
def test_Task_map():
    """
    map is the most important method in Task, because it is a basis of all other methods.

    Idea of map - mapper function takes stored value and return new value.

    .... code:: python

        Task.of(5).map(lambda x: x + 10).fork(
            lambda value: print(value))
        >>> 15

    """
    assert Task.of(5).map(lambda x: x + 10).fork(
        lambda value: value
    ) == 15


# Generated at 2022-06-12 05:43:16.564471
# Unit test for method bind of class Task
def test_Task_bind():
    Task.of(1).bind(lambda arg: Task.of(arg + 1)).fork(
        lambda reject: print(reject),
        lambda resolve: print(resolve)
    )


# Generated at 2022-06-12 05:43:20.107055
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1) \
        .map(lambda num: num + 1) \
        .fork(
            lambda error: False,
            lambda value: value == 2
        )



# Generated at 2022-06-12 05:43:26.918251
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(arg):
        return Task.of(arg + 1)

    def minus_one(arg):
        return Task.of(arg - 1)

    def not_return_Task_reject_test(arg):
        return Task.of(arg)

    def not_return_Task_resolve_test(arg):
        return arg

    def raise_exception_test(arg):
        raise Exception(arg)

    def raise_exception_in_chain_test(arg):
        return Task.reject(arg)

    def ensure_equal(result, expected):
        if result != expected:
            raise Exception('Expected: {0}, but result {1}'.format(expected, result))

    # Rejected test cases

# Generated at 2022-06-12 05:43:31.168778
# Unit test for method bind of class Task
def test_Task_bind():
    """
    This unit test check that method bind maps
    Task resolve attribute correctly.
    """
    mock = Mock()
    Task.of('a').bind(lambda value: mock.map(value))

    mock.map.assert_called_with('a')


# Generated at 2022-06-12 05:43:42.017984
# Unit test for method bind of class Task
def test_Task_bind():
    def extract_dict_value(obj):
        return obj['value']

    def call_task_return_value(value):
        return Task.of(value)

    def call_task_return_reject_value(value):
        return Task.reject(value)

    def create_dict(value):
        return {'value': value}

    assert Task.of(1).bind(call_task_return_value).fork(lambda _: False, lambda value: value == 1)
    assert Task.of(1).bind(call_task_return_reject_value).fork(lambda value: value == 1, lambda _: False)


# Generated at 2022-06-12 05:43:50.219860
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(number):
        return Task.of(number)

    def new_fn(number):
        return Task.reject(number)

    task = Task.of(5).bind(fn)
    assert task.fork(None, lambda x: x) == 5

    task = Task.reject(5).bind(fn)
    assert task.fork(lambda x: x, None) == 5

    task = Task.of(5).bind(new_fn)
    assert task.fork(lambda x: x, None) == 5

    task = Task.reject(5).bind(new_fn)
    assert task.fork(lambda x: x, None) == 5


# Generated at 2022-06-12 05:45:25.584387
# Unit test for method bind of class Task
def test_Task_bind():
    def reject(value):
        assert_that(value, equal_to('error'))

    def resolve(value):
        assert_that(value, equal_to('value'))

    def test_mapper(value):
        return Task.of(value)

    Task.of('value') \
        .bind(test_mapper) \
        .fork(reject, resolve)


# Generated at 2022-06-12 05:45:32.966758
# Unit test for method bind of class Task
def test_Task_bind():
    def a(arg):
        print('a')
        return arg

    def b(arg):
        print('b')
        return Task.of(arg)

    def c(arg):
        print('c')
        return Task.of(arg)

    def d(arg):
        print('d')
        return Task.of(arg)

    def e(arg):
        print('e')
        return Task.of(arg)

    def f(arg):
        print('f')
        return Task.of(arg)

    Task.of(1).bind(a).bind(b).bind(c).bind(d).bind(e).bind(f).fork(lambda _: None, lambda _: None)


# Generated at 2022-06-12 05:45:36.536734
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    result = Task.of(1).map(fn).fork(None, lambda value: value)

    assert isinstance(result, int) is True
    assert result == fn(1)


# Generated at 2022-06-12 05:45:47.225974
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method map of class Task.

    :returns: None
    """
    # TODO: implement
    # Task that raises error during fork
    def error():
        raise RuntimeError('not expected function')

    task = Task(error)
    assert task.map(lambda _: _)(None, lambda _: _)(None, lambda _: _) is None

    def one(resolve, reject):
        """
        Return 1 in callback.

        :param resolve: callback for resolve
        :type resolve: Function(value) -> A
        :param reject: callback for reject
        :type reject: Function(value) -> B
        :return: None
        :rtype: None
        """
        resolve(1)


# Generated at 2022-06-12 05:45:49.194683
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x * 2) == Task.of(4)


# Generated at 2022-06-12 05:45:52.640008
# Unit test for method bind of class Task
def test_Task_bind():
    delay_ms(1000)

    def test_task():
        return Task.of(1).bind(lambda v: Task.of(v + 1))

    assertEquals(test_task().fork(lambda v: v, lambda v: v), 2)


# Generated at 2022-06-12 05:45:56.722387
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda reject, resolve: resolve(4)).bind(
        lambda _: Task(lambda reject, resolve: resolve(5))
    ).fork(None, lambda x: x) == 5



# Generated at 2022-06-12 05:46:00.967739
# Unit test for method bind of class Task
def test_Task_bind():
    def task_foo():
        return Task(lambda _, resolve: resolve(100))
    def task_bar(value):
        return Task(lambda _, resolve: resolve(value))

    assert task_foo().bind(task_bar)[1] == 100
    assert task_foo().bind(task_foo)[1] == 100

