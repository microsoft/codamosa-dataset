

# Generated at 2022-06-12 05:36:10.828296
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value): return value + "!"

    def fork(reject, resolve):
        resolve("Hello world")

    task = Task(fork)
    task = task.map(mapper)
    assert task.fork(lambda value: value) == "Hello world!"

    def fork_reject(reject, resolve):
        reject("Error")

    task = Task(fork_reject)
    task = task.map(mapper)
    assert task.fork(None, lambda value: value) == "Error"


# Generated at 2022-06-12 05:36:20.715836
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.

    Function test_Task_bind check behaviour for method bind in class Task.
    Function test_Task_bind check method bind for work with
    rejecting Task and resolved Task.
    """
    def fork_mock_reject(reject, _):
        """
        Mock for reject case.

        :param reject: reject function for Task
        :type reject: Function(value) -> Any
        :param _: fake param
        """
        reject(0)

    def fork_mock_resolved(reject, resolve):
        """
        Mock for resolve case.

        :param reject: reject function for Task
        :type reject: Function(value) -> Any
        :param resolve: resolve function for Task
        :type resolve: Function(value) -> Any
        """
        resolve(10)

# Generated at 2022-06-12 05:36:30.534981
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function_Task_bind():
        t = Task.of("value")
        result = t.bind(lambda _: Task.of("mapped_value")).fork(
            lambda reject: "rejected",
            lambda resolve: resolve
        )

        assert result == "mapped_value"

    def fn_rejected():
        t = Task.reject("rejected_value")
        result = t.bind(lambda _: Task.of("mapped_value")).fork(
            lambda reject: reject,
            lambda resolve: resolve
        )

        assert result == "rejected_value"

    def fn_throw_error():
        t = Task.of("value")

# Generated at 2022-06-12 05:36:33.810197
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(test_function).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-12 05:36:38.030149
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value)

    assert Task.of(1).bind(mapper).fork(lambda x: x == 1, lambda x: False)

    def throw_error_function(_):
        raise Exception("error")

    assert Task.of(1).bind(throw_error_function).fork(
        lambda x: type(x) == Exception and "error" in x.args,
        lambda x: False
    )


# Generated at 2022-06-12 05:36:43.600963
# Unit test for method bind of class Task
def test_Task_bind():
    def ok(value):
        return Task.of(value + 10)

    def ng(value):
        return Task.reject(value + 10)

    task = Task.of(10).bind(ok)
    err = Task.of(10).bind(ng)

    assert task.fork(lambda reject, _: reject, lambda resolve, _: resolve) == 20

    assert err.fork(
        lambda reject, _: reject,
        lambda resolve, _: None
    ) == 20


# Generated at 2022-06-12 05:36:53.578352
# Unit test for method bind of class Task
def test_Task_bind():
    """
    """
    class MockTask:
        def __init__(self, resolve):
            self.resolve = resolve

    def function_return_rejected_task():
        return Task.reject('error')

    def function_return_resolved_task():
        return Task.of('success')

    # test for method bind with rejected task
    fork = Task(function_return_rejected_task).bind(function_return_resolved_task).fork

# Generated at 2022-06-12 05:37:00.465488
# Unit test for method map of class Task
def test_Task_map():
    """
    Tests for method map
    """

    assert Task.of(10).map(lambda x: x * 2) == Task(
        lambda _, resolve: resolve(20))
    assert Task.of(10).map(lambda _: 'foo').map(lambda _: 20) == Task(
        lambda _, resolve: resolve(20))
    assert Task.reject(10).map(lambda _: 20) == Task(
        lambda reject, _: reject(10))


# Generated at 2022-06-12 05:37:10.520670
# Unit test for method bind of class Task
def test_Task_bind():
    # Task should be bind with another Task
    def bind_task_with_task(resolve, reject):
        resolve(5)
        return Task(lambda _, resolve: resolve(5))
    bind_task_with_task.fork = bind_task_with_task
    task = Task.of(3).bind(bind_task_with_task)
    assert task.fork(lambda err: False, lambda res: res == 5)

    # Task should be bind with function
    def bind_task_with_function(resolve, reject):
        resolve(5)
        return lambda arg: arg
    bind_task_with_function.fork = bind_task_with_function
    task = Task.of(3).bind(bind_task_with_function)
    assert task.fork(lambda err: False, lambda res: res == 5)

# Generated at 2022-06-12 05:37:13.961401
# Unit test for method map of class Task
def test_Task_map():
    def task():
        return Task.of('hello')

    def fn(arg):
        return arg + ' world'

    assert task().map(fn).fork(None, lambda arg: arg) == fn('hello')


# Generated at 2022-06-12 05:37:27.951610
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task. It should call next map of Task
    """
    def bind_test(reject, resolve):
        """
        :param reject: callback for reject branch when Task forked
        :type reject: Function(value) -> Any
        :param resolve: callback for resolve branch when Task forked
        :type resolve: Function(value) -> Any
        """
        resolve('response')

    def fn(value):
        """
        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value)

    Task(bind_test).bind(fn).fork(lambda x: 'reject', lambda x: x) == 'response'


# Generated at 2022-06-12 05:37:31.457728
# Unit test for method map of class Task
def test_Task_map():
    t1 = Task.of('test string')
    t2 = t1.map(lambda value: value + ' another string')
    assert t2.fork(lambda arg: arg, lambda arg: arg) == 'test string another string'



# Generated at 2022-06-12 05:37:34.580155
# Unit test for method map of class Task
def test_Task_map():
    test = Task.of(1).map(lambda x: x + 1)
    test.fork(None, lambda x: print(x))


# Generated at 2022-06-12 05:37:40.918243
# Unit test for method map of class Task
def test_Task_map():
    value1 = Task.of("value")
    value2 = value1.map(lambda x: x + "1")

    def fork_value1(reject, resolve):
        reject("error")
        resolve("value")

    def fork_value2(reject, resolve):
        reject("error")
        resolve("value1")

    assert value1.fork == fork_value1
    assert value2.fork == fork_value2


# Generated at 2022-06-12 05:37:45.381502
# Unit test for method map of class Task
def test_Task_map():
    """
    Test that method map of class Task
    return new Task with mapped resolve attribute.
    """
    add = lambda value: value + 1  # Lambda func to add to input 1
    task = Task(lambda reject, resolve: resolve(5))
    mapped_task = task.map(add)
    assert mapped_task.fork(None, None) == 6  # call to mapped task should return 6



# Generated at 2022-06-12 05:37:48.721780
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method
    """
    val = Task.of(2).map(lambda x: x ** 2)
    assert val.fork(None, lambda x: x == 4)


# Generated at 2022-06-12 05:37:56.685317
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    task = Task(lambda reject, resolve: resolve(1))
    mapped = task.map(add_one).map(add_two)

    assert mapped.fork(lambda arg: None, lambda arg: arg) == 4

    def nope(value):
        return None

    rejected = task.map(lambda arg: arg > 2).map(nope)
    assert rejected.fork(lambda arg: arg, lambda arg: arg) is None


# Generated at 2022-06-12 05:38:03.282741
# Unit test for method bind of class Task
def test_Task_bind():
    from utils.test_utils import assert_resolved_always_true, assert_resolved_always_false

    def assert_reject_resolved_is_false(resolved):
        return not resolved

    def _test_resolved_task(x):
        assert(x == 'test1')
        return Task.of(True)

    def _test_rejected_task(x):
        assert(x == 'test2')
        return Task.reject(False)

    assert_resolved_always_true(
        Task.of('test1').bind(_test_resolved_task)
    )

    assert_resolved_always_false(
        Task.of('test2').bind(_test_rejected_task)
    )


# Generated at 2022-06-12 05:38:07.430225
# Unit test for method bind of class Task
def test_Task_bind():
    tx = Task.of(True)
    def mapper(value):
        return Task.of(not value)

    ty = tx.bind(mapper)
    assert ty.fork(None, None) == False


# Generated at 2022-06-12 05:38:11.289548
# Unit test for method bind of class Task
def test_Task_bind():
    def task(value):
        def fork(reject, resolve):
            resolve(value)

        return Task(fork)

    assert Task.of(1).bind(task).fork(lambda v: v * 2, None) == 2


# Generated at 2022-06-12 05:38:22.168446
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task(lambda reject, resolve: resolve("asd"))
    taskAfterBind = task.bind(lambda arg: Task.reject("qwe"))
    taskAfterBind.fork(
        lambda arg: print("Failed with value " + arg),
        lambda arg: print("Success with value " + arg)
    )
    # output: Failed with value qwe

# Generated at 2022-06-12 05:38:31.996744
# Unit test for method map of class Task
def test_Task_map():
    # TESTED: map(Task.of(1), lambda x: x + 1) -> [2]
    # TESTED: map(Task.reject(1), lambda x: x + 1) -> []
    # TESTED: map(Task.of(1), lambda x: x / 0) -> []
    def test_Task_map():
        t1 = Task.of(1).map(lambda x: x + 1)
        assert t1.fork(mock.ANY, lambda x: x == 2)

        t2 = Task.reject(1).map(lambda x: x + 1)
        assert t2.fork(mock.ANY, mock.ANY)

        t3 = Task.of(1).map(lambda x: x / 0)
        assert t3.fork(mock.ANY, mock.ANY)



#

# Generated at 2022-06-12 05:38:40.125958
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind method.
    """
    # Prepare
    value = 21
    mock_fork = MagicMock(return_value=value)
    mock_task = Task(mock_fork)
    def mock_map(arg):
        return arg**2

    def mock_bind(arg):
        return Task.of(mock_map(arg))

    # Test
    result = mock_task.bind(mock_bind)
    assert result.fork(None, None) == value

    # Verify
    mock_fork.assert_called_once_with(ANY, ANY)


# Generated at 2022-06-12 05:38:46.355616
# Unit test for method map of class Task
def test_Task_map():
    def mapper(x):
        return x + x

    def reject(x):
        return x * 2

    def resolve(x):
        return x - 1

    task = Task.of(2).map(mapper).map(reject).map(resolve)

    assert task.fork(lambda x: x, lambda x: x) == 3

# Generated at 2022-06-12 05:38:53.436196
# Unit test for method map of class Task
def test_Task_map():
    # Should resolve Task with mapped value
    def test_resolve():
        def test(resolve, _):
            resolve(3)
        f = Task(test).map(lambda arg: arg * 2).fork(None, assert_equal(6))

    # Should reject Task with mapped error
    def test_reject():
        def test(_, resolve):
            resolve(2)
        f = Task(test).map(lambda arg: arg * 2).fork(assert_equal(6), None)

    # Should not change state of Task
    def test_not_change_state():
        def test(_, resolve):
            resolve(2)
        f = Task(test).map(lambda arg: arg * 2).fork(None, assert_equal(2))

    # Should not change state of Task
    def test_of():
        Task.of

# Generated at 2022-06-12 05:38:59.745640
# Unit test for method bind of class Task
def test_Task_bind():
    counter = 0
    def inc():
        nonlocal counter
        counter += 1

    def success():
        inc()
        return Task.of(1)

    def fail():
        inc()
        return Task.reject(1)

    def inc_if_even(x):
        if x % 2 == 0:
            inc()
        return x

    assert Task.of(0).bind(success).bind(success).bind(fail).map(inc_if_even).fork(lambda _: 0, lambda _: 0) == 0
    assert counter == 2


if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-12 05:39:10.405753
# Unit test for method map of class Task
def test_Task_map():
    """
    Check method map(self, fn) of class Task.

    :returns: prints test result
    :rtype: None
    """

    def assert_equal(description, arg, result):
        if arg == result:
            print('Ok: {description} expected: {arg} result: {result}'.format(
                description=description,
                arg=arg,
                result=result
            ))
        else:
            print('Fail: {description} expected: {arg} result: {result}'.format(
                description=description,
                arg=arg,
                result=result
            ))

    task = Task.of(1)
    assert_equal('Task map(self, fn)', task.map(lambda a: a + 1).fork(None, lambda a: a), 2)


# Generated at 2022-06-12 05:39:17.970298
# Unit test for method map of class Task
def test_Task_map():
    def to_float(x):
        return float(x)

    assert Task(lambda reject, resolve: resolve(15)).map(to_float).fork(
        lambda e: e,
        lambda x: x == 15.0
    )

    assert Task(lambda reject, resolve: resolve(15)).map(
        lambda x: x * 2).map(to_float).fork(
        lambda e: e,
        lambda x: x == 30.0
    )


# Generated at 2022-06-12 05:39:23.385170
# Unit test for method bind of class Task
def test_Task_bind():
    def inner_fork(reject, resolve):
        resolve('Hello World!')

    def inner_bind(value):
        return Task(lambda _, resolve: resolve(value + '!'))

    task = Task(inner_fork).bind(inner_bind)

    try:
        value = task.fork(lambda _: 1, lambda value: value)
        assert value == 'Hello World!!'

    except AssertionError:
        print('TEST FAILED')


# Generated at 2022-06-12 05:39:30.252211
# Unit test for method map of class Task
def test_Task_map():
    """Test"""
    def fork(reject, resolve):
        """Fake task"""
        resolve(5)

    task = Task(fork).map(lambda value: value + 1)

    def on_rejected(value):
        """Fake rejected function"""
        assert False

    def on_resolved(value):
        """Fake resolved function"""
        assert value == 6

    task.fork(on_rejected, on_resolved)

# # Unit test for class method Task.of of class Task

# Generated at 2022-06-12 05:39:39.624460
# Unit test for method map of class Task
def test_Task_map():
    """
    Test successful Task execution with mapped value
    """
    assert Task.of(1).map(lambda arg: arg + 2).fork(lambda _: False, lambda arg: arg == 3)


# Generated at 2022-06-12 05:39:49.811101
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    def fork_second(reject, resolve):
        resolve(2)

    def fork_error(reject, resolve):
        reject(2)

    mock_result = mock.MagicMock()
    task = Task(fork)
    binding_task = task.bind(lambda arg: Task(fork_second))
    binding_task.fork(lambda arg: mock_result(), lambda arg: mock_result())

    mock_result.assert_called_once_with()

    mock_error = mock.MagicMock()
    binding_task_error = task.bind(lambda arg: Task(fork_error))
    binding_task_error.fork(lambda arg: mock_error(), lambda arg: mock_error())

    mock_error.assert_called_once_with()



# Generated at 2022-06-12 05:39:55.704253
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + value

    def resolve(value):
        return value * 2

    def reject(value):
        return value * 3

    def fork(_reject, _resolve):
        return _resolve('test')

    task = Task(fork).map(mapper).map(resolve)
    assert task.fork(reject, resolve) == 'testtesttest'



# Generated at 2022-06-12 05:40:06.694185
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Assert that bind function work properly.
    """
    @prop
    def test(value: [str], fn: [str]) -> bool:
        """
        Check that bind run mapper function with expected value
        Check that bind return new Task with transform result of mapper function.

        :param value: string value to store in initial Task
        :type value: str
        :param fn: string value to store in mapper function
        :type fn: str
        :returns: property of function
        :rtype: bool
        """
        task = Task.of(value)
        mapper = lambda arg: Task.of(fn + arg)

        called = False

        def fake_fork(reject, resolve):
            assert called

        mapper.fork = fake_fork

        task.bind(mapper)

        called = True

# Generated at 2022-06-12 05:40:15.935732
# Unit test for method bind of class Task
def test_Task_bind():
    value = 0

    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return 2

    task = Task(fork)
    assert isinstance(task.bind(lambda x: Task.of(x)), Task)
    task.fork(lambda x: value.__setitem__(0, x), lambda x: x)
    assert value == 1
    assert task.bind(mapper).fork(lambda x: value.__setitem__(0, x), lambda x: x) == 2
    assert value == 2

# Generated at 2022-06-12 05:40:19.280806
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda x: x + 1)
    assert(task.fork(lambda arg: arg, lambda arg: arg) == 2)


# Generated at 2022-06-12 05:40:26.775408
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map(fn)

    Take function, store it and call with Task value during calling fork function.
    Return new Task with result of called.

    :param fn: mapper function
    :type fn: Function(value) -> B
    :returns: new Task with mapped resolve attribute
    :rtype: Task[Function(resolve, reject -> A | B]
    """
    assert Task.of(2).map(lambda x: x * 2).fork(lambda x: 'reject', lambda x: x) == 4
    assert Task.reject(2).map(lambda x: x * 2).fork(lambda x: 'reject', lambda x: x) == 'reject'


# Generated at 2022-06-12 05:40:38.241160
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(x):
        # type: (int) -> int
        return x * 2

    def mapper(x):
        # type: (int) -> Task[int, int]
        return Task.of(fn(x))

    result1 = Task.of(2)\
        .bind(mapper)\
        .fork(lambda x: x, lambda x: x)

    result2 = Task.of(2)\
        .map(fn)\
        .fork(lambda x: x, lambda x: x)
    assert result1 == result2

    result3 = Task.of(2)\
        .bind(lambda x: Task.of(fn(x)))\
        .fork(lambda x: x, lambda x: x)
    assert result1 == result3



# Generated at 2022-06-12 05:40:47.030413
# Unit test for method bind of class Task
def test_Task_bind():
    store = []

    def resolve(arg): store.append(arg)
    def reject(arg): store.append(arg)

    Task(lambda reject, resolve: resolve(1)).bind(
        lambda arg: Task(lambda reject, resolve: resolve(arg + 1))
    ).fork(reject, resolve)
    assert store[0] == 2

    Task(lambda reject, resolve: reject(1)).bind(
        lambda arg: Task(lambda reject, resolve: resolve(arg + 1))
    ).fork(reject, resolve)
    assert store[1] == 1

    Task(lambda reject, resolve: reject(1)).bind(
        lambda arg: Task(lambda reject, resolve: reject(arg + 1))
    ).fork(reject, resolve)
    assert store[2] == 2


# Generated at 2022-06-12 05:40:50.316617
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    result = Task.of(1) \
                 .map(fn) \
                 .fork(None, print)

    assert result == 2


# Generated at 2022-06-12 05:40:59.257954
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(2)
    result = result.map(lambda x: x*2)
    assert result.fork(lambda x: None, lambda x: x) == 4


# Generated at 2022-06-12 05:41:05.403672
# Unit test for method map of class Task
def test_Task_map():
    def assert_map(fn, value, expected):
        assert Task.of(value).map(fn).fork(lambda x: x, lambda x: x) == expected

    assert_map(lambda x: x + 1, 1, 2)
    assert_map(lambda x: x + "1", "1", "11")


# Generated at 2022-06-12 05:41:07.315434
# Unit test for method map of class Task
def test_Task_map():
    def inc(value):
        return value + 1

    assert Task.of(0).map(inc).fork(None, lambda a: a) == 1

# Generated at 2022-06-12 05:41:12.539992
# Unit test for method bind of class Task
def test_Task_bind():
    value = 1
    def fn(value):
        return Task.of(value)

    result = Task.of(value).bind(fn)
    result.fork(lambda x: None, lambda x: None)

    assert result.fork(lambda x: None, lambda x: x) == value

# Generated at 2022-06-12 05:41:17.356198
# Unit test for method bind of class Task
def test_Task_bind():
    init_value = 12
    def mapper(value):
        return Task(lambda reject, resolve: resolve(value * 2))

    def result_function(reject, resolve):
        return Task.of(init_value).bind(mapper).fork(reject, resolve)

    assert result_function(None, None) == init_value * 2


# Generated at 2022-06-12 05:41:24.903067
# Unit test for method bind of class Task
def test_Task_bind():
    def task_injector(value):
        return Task.of(value)

    def task_adder(value):
        return Task.of(value + 1)

    def task_reject(value):
        return Task.reject(value)

    assert Task(lambda _, resolve: resolve(1)).bind(task_injector).fork(None, lambda arg: arg) == 1
    assert Task(lambda _, resolve: resolve(1)).bind(task_adder).fork(None, lambda arg: arg) == 2


# Generated at 2022-06-12 05:41:29.103932
# Unit test for method map of class Task
def test_Task_map():
    def id(x):
        return x

    test_task = Task.of(1)
    assert test_task.map(id).fork(lambda x: x, lambda x: x) == 1



# Generated at 2022-06-12 05:41:36.546739
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    """
    def is_even(value):
        """
        Check if value is even.

        :param value: value to check
        :type value: int
        :returns: True if value is even
        :rtype: bool
        """
        return value % 2 == 0

    def is_string(value):
        """
        Check if value is string.

        :param value: value to check
        :type value: str
        :returns: True if value is string
        :rtype: bool
        """
        return type(value) == str

    def double(value):
        """
        Double given value.

        :param value: value to double
        :type value: int
        :returns: value * 2
        :rtype: int
        """


# Generated at 2022-06-12 05:41:43.336150
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.

    :returns: pass or test failed
    :rtype: bool
    """
    def test_fn(value):
        return -value

    def map_task(value):
        return Task.of(value).map(test_fn)

    result = Task.of(2).bind(map_task)
    if result.fork(lambda arg: arg, lambda arg: arg) == -2:
        return True
    else:
        return False


# Generated at 2022-06-12 05:41:46.508606
# Unit test for method map of class Task
def test_Task_map():
    def task_fork(reject, resolve):
        return resolve(32)

    task = Task(task_fork)

    def mapper(value):
        return value * 2

    result = task.map(mapper).fork(lambda _: None, lambda x: x)

    assert result == 64


# Generated at 2022-06-12 05:41:58.341314
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.reject(value)

    assert Task.of(1) \
        .bind(mapper) \
        .fork(lambda arg: ['error', arg], lambda arg: ['ok', arg]) == ['error', 1]

    assert Task.of(2) \
        .bind(lambda value: Task.of(value + 1)) \
        .fork(lambda arg: ['error', arg], lambda arg: ['ok', arg]) == ['ok', 3]


# Generated at 2022-06-12 05:42:00.912264
# Unit test for method map of class Task
def test_Task_map():
    _ = Task.of('something')
    assert _.map(lambda arg: arg).fork(lambda _: _, lambda _: _) == 'something'


# Generated at 2022-06-12 05:42:07.665278
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map method.
    Test that map method return Task with mapped function

    :returns: 1 if Test passed, otherwise 0
    :rtype: int
    """

    def result(success, fail):
        success(10)

    task = Task(result)

    def test_fn(resolve, reject):
        def is_success(value):
            return value == 20

        def is_fail(value):
            return value is not None

        task.map(lambda x: x * 2).fork(is_fail, is_success)

    run_test(test_fn)


# Generated at 2022-06-12 05:42:11.659618
# Unit test for method map of class Task
def test_Task_map():
    new_Task = Task.of(1).map(lambda x: x + 1)

    def fork(reject, resolve):
        resolve(2)

    old_Task = Task(fork)

    assert new_Task.fork(lambda x: x, lambda y: y) == old_Task.fork(lambda x: x, lambda y: y)


# Generated at 2022-06-12 05:42:18.743971
# Unit test for method bind of class Task
def test_Task_bind():
    def second(a_value):
        return Task(lambda _, resolve: resolve(a_value * 2))

    task_fork_arg = None
    def first(reject, resolve):
        nonlocal task_fork_arg
        task_fork_arg = resolve
        resolve(1)

    task = Task(first) # -> Task(resolve, reject)
    task_result = task.bind(second) # -> Task(reject, resolve)
    task_result.fork(lambda arg: None, lambda arg: None)
    task_fork_arg(5)

    assert task_result.fork(lambda arg: None, lambda arg: None) == 10


# Generated at 2022-06-12 05:42:25.529353
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.reject(1).bind(lambda _: Task.of(2)).fork(
        lambda arg: arg,
        lambda _: 1,
    ) == 1

    assert Task.reject(1).bind(lambda _: Task.reject(2)).fork(
        lambda arg: arg,
        lambda _: 1,
    ) == 2

    assert Task.of(1).bind(lambda _: Task.reject(2)).fork(
        lambda arg: arg,
        lambda _: 1,
    ) == 2


# Generated at 2022-06-12 05:42:30.794911
# Unit test for method map of class Task
def test_Task_map():

    def fn(x):
        return x * 2

    def assertFn(x):
        assert x == 2

    task = Task.of(1)

    task2 = task.map(fn)
    task2.fork(lambda arg: None, assertFn)

    task3 = task.map(fn).map(fn)
    task3.fork(lambda arg: None, assertFn)


# Generated at 2022-06-12 05:42:37.996265
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def reject_fn(value):
        return value, 'reject_fn'

    def resolve_fn(value):
        return value, 'resolve_fn'

    def fork_test(reject, resolve):
        resolve(5)
        reject(10)
        return 'is_not_return'

    result = Task(fork_test).map(add_one).fork(reject_fn, resolve_fn)
    expected_result = 6, 'resolve_fn'

    assert result == expected_result


# Generated at 2022-06-12 05:42:49.377996
# Unit test for method bind of class Task
def test_Task_bind():
    def inc(x):
        return x + 1

    def double(x):
        return x * 2

    def triple(x):
        return x * 3

    def quad(x):
        return x * 4

    def square(x):
        return x ** x

    def string(x):
        return x.decode('utf-8')

    def result(x):
        return x

    def test():
        assert Task.of(2).bind(Task.of).fork(None, result) == 2
        assert Task.of(2).bind(inc).fork(None, result) == 3
        assert Task.of(2).bind(inc).bind(inc).fork(None, result) == 4
        assert Task.of(2).bind(inc).bind(double).fork(None, result) == 6
        assert Task.of

# Generated at 2022-06-12 05:42:57.701374
# Unit test for method bind of class Task
def test_Task_bind():
    def _case1():
        t1 = Task.of(1)
        t2 = Task.of(2)
        t3 = Task.of(3)
        t4 = Task.of(4)
        return t1 \
            .bind(lambda a: t2) \
            .bind(lambda a: t3) \
            .bind(lambda a: t4)

    def _case2():
        t1 = Task.of(1)
        t2 = Task.reject(2)
        return t1 \
            .bind(lambda a: t2) \
            .bind(lambda a: Task.of(3)) \
            .bind(lambda a: Task.of(4))

    def _case3():
        t1 = Task.of(1)
        t2 = Task.reject(2)


# Generated at 2022-06-12 05:43:12.822462
# Unit test for method bind of class Task
def test_Task_bind():
    def test(value):
        def get_value(reject, resolve):
            if value:
                resolve(value)
            else:
                reject(value)

        return Task(get_value)

    task = test(1)

# Generated at 2022-06-12 05:43:15.975532
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value)

    result = Task.of('foo').bind(fn)
    result.fork(lambda rejected: 'FAIL', lambda resolved: resolved)



# Generated at 2022-06-12 05:43:25.491246
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method
    """
    import pytest
    from pytest import raises

    # Test: Given Task(resolved) return,
    # Then second Task is called and return
    @pytest.mark.parametrize('value', [1, 2, 3])
    def test_given_resolved_task_return_second_called_task(value):
        task_value = 0
        def first_task(reject, resolve):
            resolve(value)
        def second_task(value):
            nonlocal task_value
            task_value = value
            return Task.of(value)

        Task(first_task).bind(second_task).fork(lambda _: None, lambda _: None)
        assert value == task_value
        assert value == 1

    # Test: Given Task(rejected

# Generated at 2022-06-12 05:43:35.593235
# Unit test for method bind of class Task
def test_Task_bind():
    def square(number):
        return number ** 2

    def cube(number):
        return number ** 3

    task_with_one = Task(lambda reject, resolve: resolve(1))
    assert type(task_with_one.bind(lambda _: Task.of(2))) is Task
    assert task_with_one.bind(lambda _: Task.of(2)).fork(lambda _: None, lambda arg: arg) == 2

    task_with_one = Task(lambda reject, resolve: resolve(1))
    assert task_with_one.bind(lambda arg: Task.of(arg * 2)).fork(lambda _: None, lambda arg: arg) == 2

    task_with_one = Task(lambda reject, resolve: resolve(1))

# Generated at 2022-06-12 05:43:39.947666
# Unit test for method map of class Task
def test_Task_map():
    def resolve(num):
        return num + 1

    def reject(num):
        return num - 1

    task = Task(lambda reject, resolve: resolve(3))
    new_task = task.map(lambda num: num + 1)

    assert new_task.fork(reject, resolve) == 5



# Generated at 2022-06-12 05:43:46.041028
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> Task.of(1).bind(lambda x: Task.of(x + 1)).fork(lambda x: x, lambda y: y)
    2

    >>> Task.of(1).bind(lambda x: Task.reject(x + 1)).fork(lambda x: x, lambda y: y)
    2

    >>> Task.reject(1).bind(lambda x: Task.of(x + 1)).fork(lambda x: x, lambda y: y)
    1
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 05:43:54.146076
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(
        lambda value: Task.reject(value)
    ).fork(
        lambda reject_value: reject_value == 1,
        lambda resolve_value: False
    )

    assert Task.of(1).bind(
        lambda value: Task.of(2)
    ).fork(
        lambda reject_value: False,
        lambda resolve_value: resolve_value == 2
    )

    assert Task.of(1).bind(
        lambda value: Task.of(2).bind(
            lambda value2: Task.reject(3)
        )
    ).fork(
        lambda reject_value: reject_value == 3,
        lambda resolve_value: False
    )



# Generated at 2022-06-12 05:44:02.647942
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_task():
        return Task.of(1)
    def reject_task():
        return Task.reject(2)

    assert Task.of(1).bind(resolve_task).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 1
    assert Task.of(1).bind(reject_task).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 2
    assert Task.reject(1).bind(reject_task).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 1


# Generated at 2022-06-12 05:44:06.622602
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + '2')

    src = Task.of('value')
    result = src.bind(mapper)
    assert result.fork(
        lambda value: 'error',
        lambda value: value
    ) == 'value2'



# Generated at 2022-06-12 05:44:08.853855
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda arg: arg + 1) == Task(lambda _, resolve: resolve(2))

# Generated at 2022-06-12 05:44:27.366708
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(3)

    def fmap(x):
        return x + 5

    t = Task(fork).map(fmap)

    assert t.fork(None, lambda val: val) == 8


# Generated at 2022-06-12 05:44:31.036890
# Unit test for method bind of class Task

# Generated at 2022-06-12 05:44:34.942127
# Unit test for method map of class Task
def test_Task_map():
    fn = lambda arg: arg + arg
    assert Task(lambda _, resolve: resolve(3)).map(fn).fork(lambda a: a, lambda a: a) == 6
    assert Task(lambda _, resolve: resolve(3)).map(fn).map(fn).fork(lambda a: a, lambda a: a) == 12


# Generated at 2022-06-12 05:44:40.187801
# Unit test for method map of class Task
def test_Task_map():
    is_right_mapped = Task.of(2).map(lambda x: x * x)
    is_right_mapped.fork(lambda x: 4, lambda x: x)

    assert is_right_mapped.fork(lambda x: 4, lambda x: x) == 4

test_Task_map()


# Generated at 2022-06-12 05:44:43.123347
# Unit test for method map of class Task
def test_Task_map():
    def fn(x): return x+2

    def reject(x): return x

    def resolve(x): return x

    assert Task.of(1).map(fn).fork(reject, resolve) == 3


# Generated at 2022-06-12 05:44:53.648231
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value ** 2

    task = Task(lambda _, resolve: resolve(2))
    assert task.map(mapper).fork(_, lambda x: x) == 4
    assert task.map(mapper).fork(lambda x: x, _) == 4

    task = Task(lambda _, resolve: resolve(4))
    assert task.map(mapper).fork(_, lambda x: x) == 16
    assert task.map(mapper).fork(lambda x: x, _) == 16

    task = Task(lambda _, resolve: resolve(0))
    assert task.map(mapper).fork(_, lambda x: x) == 0
    assert task.map(mapper).fork(lambda x: x, _) == 0


# Generated at 2022-06-12 05:44:57.733423
# Unit test for method bind of class Task
def test_Task_bind():
    task_rejected = Task.reject('Error')
    def mapper(arg):
        return arg + 5

    assert task_rejected.bind(mapper).fork(lambda arg: arg, lambda _: None) == 'Error'

    task_rejected = Task.of('Data')
    assert task_rejected.bind(mapper).fork(_, lambda arg: arg) == 'Data5'


# Generated at 2022-06-12 05:44:58.983805
# Unit test for method bind of class Task
def test_Task_bind():

    def fn(_):
        return Task.of(3)

    result = Task.of(1).bind(fn)

    assert result.fork() == 3

# Generated at 2022-06-12 05:45:07.755587
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task map method.

    Test passed if:
    - Task with Function(A -> B) as argument return Task
      with Function(resolve, reject) -> C
    - Task is resolved if argument Task is resolved
    - Task is rejected if argument Task is rejected
    """
    def test(fork, expected_result, expected_bool=True):
        Task(fork).fork(
            lambda _: failed(
                "Task is rejected with {} but it should be resolved".format(
                    repr(_)
                )
            ),
            lambda result: expected_bool
            if result == expected_result
            else failed("{} != {}".format(repr(result), repr(expected_result)))
        )

    add1 = lambda x: x + 1
    task = Task.of(2).map(add1)


# Generated at 2022-06-12 05:45:14.604241
# Unit test for method map of class Task

# Generated at 2022-06-12 05:45:46.309856
# Unit test for method map of class Task
def test_Task_map():
    # Create instance of Task with incrementation as fork
    task = Task(lambda _, resolve: resolve(1))

    # Task with incremented result of fork
    task = task.map(lambda arg: arg + 1)

    # Check result of fork
    assert task.fork(lambda reject: reject, lambda resolve: resolve) == 2



# Generated at 2022-06-12 05:45:50.729048
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda value: value * 2).fork(None, lambda value: value) == 4

    assert Task.reject(2).map(lambda value: value * 2).fork(lambda value: value, None) == 2


# Generated at 2022-06-12 05:45:54.925639
# Unit test for method bind of class Task
def test_Task_bind():
    def handle_reject(value):
        assert(value == 4)

    def handle_resolve(value):
        assert(value == 6)

    task = Task.reject(4)
    task2 = task.map(lambda x: x * 2)
    task2.fork(handle_reject, None)

    task = Task.of(4)
    task2 = task.map(lambda x: x * 2)
    task2.fork(None, handle_resolve)

# Generated at 2022-06-12 05:46:00.857904
# Unit test for method bind of class Task
def test_Task_bind():
    task_1 = Task.of(2)
    task_2 = task_1.bind(lambda x: Task.of(x+1))

    assert task_2.fork(None, lambda v: v) == 3

    task_3 = Task.of(2).bind(lambda f: Task.of(3).bind(lambda s: Task.of([f, s])))

    assert task_3.fork(None, lambda v: v) == [2, 3]


# Generated at 2022-06-12 05:46:04.422658
# Unit test for method bind of class Task
def test_Task_bind():
    def inc(arg):
        return Task.of(arg + 1)

    def doubl(arg):
        return Task.of(arg * 2)

    task = Task.of(5)

    assert task.bind(inc).bind(doubl).fork(lambda x: x, lambda x: x) == 12

