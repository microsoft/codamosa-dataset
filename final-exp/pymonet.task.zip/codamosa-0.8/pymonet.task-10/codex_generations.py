

# Generated at 2022-06-12 05:36:11.424639
# Unit test for method bind of class Task
def test_Task_bind():

    def add_1(x):
        return Task.of(x + 1)

    def multiple_2(x):
        return Task.of(x * 2)

    task = Task.of(1).bind(add_1).bind(multiple_2)
    assert task.fork(lambda x: x, lambda x: x) == 4

    task = Task.reject(1).bind(add_1)
    assert task.fork(lambda x: x, lambda x: x) == 1



# Generated at 2022-06-12 05:36:16.957751
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_one(reject, resolve):
        return resolve(1)

    def task_to_task(value):
        return Task(resolve_one)
    
    task = Task(resolve_one).bind(task_to_task)

    # this should return a task with resolve 1
    assert task.fork(lambda x: False, lambda x: x == 1)


# Generated at 2022-06-12 05:36:28.658215
# Unit test for method bind of class Task
def test_Task_bind():
    def get_the_value():
        return value

    def get_the_err():
        return err

    def add_two(arg):
        return arg + 2

    def add_ten(arg):
        return Task.of(arg + 10)

    def add_twenty(arg):
        return Task.of(arg + 20)

    def add_thirty(arg):
        return Task.of(arg + 30)

    def double_error(arg):
        return Task.reject(arg * 2)

    value = 5
    err = 0
    task = Task.of(value)
    res_task_rejected = task.bind(add_ten).bind(double_error)
    assert(res_task_rejected.fork(get_the_err, get_the_value) == err * 2)

    res

# Generated at 2022-06-12 05:36:33.198382
# Unit test for method map of class Task
def test_Task_map():
    one = Task.of(1)
    two = one.map(lambda x: x + 1)
    assert two.fork(
        lambda x: 'reject',
        lambda x: x
    ) == 2, 'Task.map'

# Generated at 2022-06-12 05:36:38.205130
# Unit test for method bind of class Task
def test_Task_bind():
    class Program(ABC):
        @abstractmethod
        def run(self):
            pass

    class Logger(Program):
        def run(self):
            return Task.of('logged')

    class User(Program):
        def run(self):
            return Logger().bind(lambda _: Task.of('user')).bind(lambda x: Task.of(f'{x} set'))

    assert User().run().fork(lambda _: None, lambda x: x) == 'user set'



# Generated at 2022-06-12 05:36:46.746498
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    def add_10(n):
        return Task.of(n + 10)

    def double(n):
        return Task.of(n * 2)

    task = Task.of(1)
    task = task.bind(add_10).bind(double).bind(double)
    assert task.fork(lambda n: n, lambda n: n) == 42


####################################################################################################
"""
Monad Task is container for Task. None of Task should be resolved/rejected before forking.
"""

# Generated at 2022-06-12 05:36:54.902480
# Unit test for method bind of class Task
def test_Task_bind():
    def text_content(arg):
        return Task.of(arg.text)

    def get_text(request):
        return request.map(text_content)

    def test_text_content_value(response):
        return Task.of(response == '<title>Title</title>')

    def response_to_title(response):
        return get_text(response).bind(test_text_content_value)

    request = Task.of(MagicMock(text = '<title>Title</title>'))

    assert response_to_title(request).fork(
        lambda _: False,
        lambda value: True
    )

    request = Task.of(MagicMock(text = '<title></title>'))


# Generated at 2022-06-12 05:37:04.252378
# Unit test for method bind of class Task
def test_Task_bind():
    def func1(a):
        return Task.of(a + 1)

    def func2(a):
        return Task.of(a + 2)

    def func3(a):
        return Task.of(a + 3)

    def func4(a):
        return Task.of(a + 4)

    def func5(a):
        return Task.of(a + 5)

    def func6(a):
        return Task.of(a + 6)

    def func7(a):
        return Task.of(a + 7)

    def func8(a):
        return Task.of(a + 8)

    def func9(a):
        return Task.of(a + 9)

    def func10(a):
        return Task.of(a + 10)


# Generated at 2022-06-12 05:37:11.496025
# Unit test for method bind of class Task
def test_Task_bind():
    def first_task_reject(value):
        assert value == 1

    def first_task_resolve(value):
        assert value == 1

    def second_task_reject(value):
        assert value == 1

    def second_task_resolve(value):
        assert value == 1

    Task(lambda reject, resolve: resolve(1)).bind(
        lambda value: Task(lambda reject, resolve: resolve(value))
    ).fork(first_task_reject, first_task_resolve)

    Task(lambda reject, resolve: resolve(1)).bind(
        lambda value: Task(lambda reject, _: reject(value))
    ).fork(second_task_reject, second_task_resolve)

# Generated at 2022-06-12 05:37:16.521041
# Unit test for method bind of class Task
def test_Task_bind():
    def map_fn(value):
        return Task.of(value + 1)

    def resolve(value):
        print('$: {}'.format(value))

    def reject(value):
        print('X: {}'.format(value))

    _test = Task.of(1)
    result = _test.bind(map_fn)
    result.fork(reject, resolve)


# Generated at 2022-06-12 05:37:26.625115
# Unit test for method bind of class Task
def test_Task_bind():
    import unittest

    class TestTaskBind(unittest.TestCase):
        def setUp(self):
            self.fn = lambda value: Task.of('result: {}'.format(value))

        def test_task_bind_map(self):
            task = Task.of('value')
            result = task.bind(self.fn).fork(lambda arg: arg, lambda arg: arg)
            self.assertEqual(result, 'result: value')

    unittest.main()

test_Task_bind()

# Generated at 2022-06-12 05:37:30.600014
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(2)
    result = task.bind(
        lambda arg: Task((lambda _, resolve: resolve(arg * 2)))
    )
    assert result.fork(
        lambda _: 'error',
        lambda arg: arg
    ) == 4


# Generated at 2022-06-12 05:37:38.185890
# Unit test for method bind of class Task
def test_Task_bind():
    class T:
        pass

    def MyTask():
        def fork(reject, resolve):
            resolve(T())

        return Task(fork)

    def bind_task(instance):
        def fork(reject, resolve):
            resolve(instance.attr)

        return Task(fork)

    t = MyTask()
    a = t.bind(bind_task)
    assert type(a.fork(None, lambda x: x)) == T


# Generated at 2022-06-12 05:37:41.878198
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        return Task.of(x+1)


# Generated at 2022-06-12 05:37:45.208133
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of('test').map(lambda a: a + '!') == Task(
        lambda _, resolve: resolve('test!')
    )
    assert Task.of(2).map(lambda a: a + 2) == Task(
        lambda _, resolve: resolve(4)
    )


# Generated at 2022-06-12 05:37:56.458089
# Unit test for method bind of class Task
def test_Task_bind():
    t = Task.reject(1).bind(lambda x: Task.reject(2))

    assert t.fork(reject, resolve) == 2

    t = Task.of(1).bind(lambda x: Task.of(x + 1))

    assert t.fork(reject, resolve) == 2

    t = Task.of(1).bind(
        lambda x: Task.of(2).bind(
            lambda y: Task.of(x + y)
        )
    )

    assert t.fork(reject, resolve) == 3

    t = Task.of(1).bind(
        lambda x: Task.of(2).bind(
            lambda y: Task.reject(x + y)
        )
    )

    assert t.fork(reject, resolve) == 3

# Simple example of using Task


# Generated at 2022-06-12 05:38:03.206582
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        time.sleep(1)
        resolve(4)

    def fork2(reject, resolve):
        time.sleep(2)
        resolve(5)

    def fork_rejected(reject, resolve):
        time.sleep(3)
        reject('reject')

    task = Task(fork)
    task2 = Task(fork2)
    task_rejected = Task(fork_rejected)

    assert task.bind(lambda a: task2).fork(lambda a: a, lambda b: b) == 5
    assert task2.bind(lambda a: task).fork(lambda a: a, lambda b: b) == 4
    assert task.bind(lambda a: task_rejected).fork(lambda a: a, lambda b: b) == 'reject'

# Unit test

# Generated at 2022-06-12 05:38:13.874847
# Unit test for method bind of class Task
def test_Task_bind():
    def inc(value):
        return value + 1

    def dec(value):
        return value - 1

    def incTask(inc_value):
        return Task.of(inc_value)

    def decTask(dec_value):
        return Task.reject(dec_value)

    store_list = []

    def resolve(value):
        store_list.append(value)
        return value

    def reject(value):
        store_list.append(value)
        return value

    # Diagram:
    #
    #     original_value | inc | dec
    #  ------------------+-----+-----
    #      inc_value     |  x  |  x
    #  ------------------+-----+-----
    #     dec_value      |  x  |  x
    #  ------------------+-----+-----
    #       error

# Generated at 2022-06-12 05:38:18.380151
# Unit test for method bind of class Task
def test_Task_bind():
    def double(x):
        return Task(
            lambda rejection, value: value(x * 2)
        )

    res = Task(
        lambda reject, value: value(1)
    ).bind(double).fork(lambda x: x, lambda x: x)
    assert res == 2


# Generated at 2022-06-12 05:38:29.392376
# Unit test for method bind of class Task
def test_Task_bind():
    # fork function of argument Task
    def fork_of(t):
        return t.fork

    # t is Task, which store result of f
    # (argument of bind, which is called with result of fork of Task on which it is called)
    # t == Task(lambda _, resolve: resolve(f(1)))
    t = Task.of(1).bind(lambda x: Task.of(f(x)))
    # t.fork == lambda reject, resolve: resolve(f(1))
    assert fork_of(t) == fork_of(Task.of(f(1)))

    # t is Task, which store result of f
    # (argument of bind, which is called with result of fork of Task on which it is called)
    # t == Task(lambda _, resolve: resolve(f(1)))

# Generated at 2022-06-12 05:38:39.660089
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    result = task.map(lambda value: value ** 2).fork(lambda value: None, lambda value: value)
    assert 4 == result

    empty_task = Task.of(None)
    result = empty_task.map(lambda value: value ** 2).fork(lambda value: value, lambda value: value)
    assert result is None


# Generated at 2022-06-12 05:38:43.214982
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)).map(lambda x: x + 1).fork(
        lambda _: False,
        lambda x: True if x == 2 else False
    )

# Generated at 2022-06-12 05:38:52.316537
# Unit test for method bind of class Task
def test_Task_bind():
    from monad import Just
    from monad import Nothing

    task_just = Task.of(Just(5))

    def mapper1(value):
        assert value == 5
        return Task.reject(Nothing())

    def mapper2(value):
        assert value == 5
        return Task.of(Just(value + 2))

    def mapper3(value):
        assert value == 7
        return Task.reject(Nothing())

    def mapper4(value):
        assert value == 7
        return Task.of(Just(value + 3))

    assert task_just.bind(mapper1).fork(lambda _: True, lambda _: False)
    assert task_just.bind(mapper2).bind(mapper3).fork(lambda _: True, lambda _: False)

# Generated at 2022-06-12 05:38:55.032193
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda x: x * 2)

    assert task.fork(lambda x: x * 3, lambda x: x * 3) == 6


# Generated at 2022-06-12 05:39:04.879163
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(1).map(lambda x: x + 1).map(lambda x: str(x)).fork(lambda x: x, lambda x: x)
    assert result == '2'

    result = Task.of(1).map(lambda x: x - 1).map(lambda x: str(x)).fork(lambda x: x, lambda x: x)
    assert result == '0'

    assert Task.of(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).map(lambda x: x - 1).fork(lambda x: x, lambda x: x) == 0


# Generated at 2022-06-12 05:39:11.511364
# Unit test for method map of class Task
def test_Task_map():
    def fork_task(reject, resolve):
        resolve(1)

    task = Task(fork_task)
    mapped_task = task.map(lambda x: x * 2)

# Generated at 2022-06-12 05:39:19.242352
# Unit test for method bind of class Task
def test_Task_bind():
    add_one = Task.of(1).bind(lambda a: Task.of(a + 1))
    add_two = Task.of(1).bind(lambda a: Task.of(a + 2))
    task = Task(lambda reject, resolve:
                add_one.fork(reject, lambda a:
                add_two.fork(reject, lambda b:
                resolve(a + b))))

    assert task.fork(lambda a: a, lambda b: b) == 4

# Generated at 2022-06-12 05:39:24.479450
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """
    add_two = Task.of(2)
    add_two_map = add_two.map(lambda x: x + 2)
    assert add_two_map.fork(None, lambda x: x) == 4


# Generated at 2022-06-12 05:39:35.296572
# Unit test for method map of class Task
def test_Task_map():
    """
    Test function should work with __init__, fork, resolve, reject and map methods of Task class.
    This function should not check internal implementation of class.
    """
    def resolver(arg):
        """
        resolve function with argument

        :param arg: argument of the function
        :type arg: B
        :returns: result of the function
        :rtype: B
        """
        return arg

    def mapper(arg):
        """
        mapper function with argument

        :param arg: argument of the function
        :type arg: A
        :returns: result of the function
        :rtype: B
        """
        return arg * 2


# Generated at 2022-06-12 05:39:38.683059
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of("Hello").map(lambda x: x + "World").fork(None, lambda x: x) == "HelloWorld"


# Generated at 2022-06-12 05:39:52.813121
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(lambda e: e, lambda v: v) == 2
    assert Task.reject(1).map(lambda x: x + 1).fork(lambda e: e, lambda v: v) == 1


# Generated at 2022-06-12 05:39:57.272291
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(
        None,
        lambda result: result == 2
    ) == True

    assert Task.reject(1).map(lambda x: x + 1).fork(
        None,
        lambda result: result == 2
    ) == False



# Generated at 2022-06-12 05:40:06.460009
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task.
    """
    def check(resolve, reject):
        """
        Check that resolve take value and reject take None.

        :param resolve: function with one argument
        :type resolve: Function(value)
        :param reject: function with one argument
        :type reject: Function(None)
        """
        resolve(1)
        reject(None)

    assert Task(check).map(lambda x: x+1).fork(lambda x: None, lambda x: x) == 2
    assert Task(check).map(lambda x: x+1).fork(lambda x: x, lambda x: None) is None



# Generated at 2022-06-12 05:40:10.412422
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda v: v + 1).fork(None, lambda v: v) == 2


# Generated at 2022-06-12 05:40:16.763151
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        reject("error")

    def fn(value):
        return Task.of("resolve")

    task = Task(fork)
    # Task.reject("error")
    assert task.fork(lambda value: value, lambda value: value) == "error"
    # Task.of("resolve")
    assert task.bind(fn).fork(lambda value: value, lambda value: value) == "resolve"



# Generated at 2022-06-12 05:40:21.120454
# Unit test for method map of class Task
def test_Task_map():
    def test_fork(reject, resolve):
        assert reject is not None
        assert resolve is not None
        resolve(1)

    task = Task(test_fork)

    new_task = task.map(lambda x: x * 2)

    assert new_task is not task
    assert new_task.fork(lambda x: None, lambda x: x) == 2


# Generated at 2022-06-12 05:40:28.522943
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda __, resolve: resolve(None)).map(lambda __: None).fork(None, lambda _: None) is None
    assert Task(lambda __, resolve: resolve(3)).map(lambda x: x + 3).fork(None, lambda x: x) == 6
    assert Task(lambda __, resolve: resolve(3)).map(lambda x: x + 3).fork(lambda x: x, None) == 3

    try:
        Task(
            lambda __, resolve: resolve(3)
        ).map(
            lambda x: x
        ).fork(
            lambda x: x,
            lambda _: NotImplementedError()
        )
    except NotImplementedError:
        pass
    else:
        assert False


# Generated at 2022-06-12 05:40:34.920152
# Unit test for method bind of class Task
def test_Task_bind():
    def foo(x):
        return Task.of(2 * x)

    def bar(x):
        return Task.reject(3 * x)

    assert Task.of(1).bind(foo).fork(None, lambda x: x) == 2
    assert Task.of(1).bind(bar).fork(lambda x: x, None) == 3



# Generated at 2022-06-12 05:40:36.986056
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda _: Task.of(2)).fork(
        lambda arg: False,
        lambda arg: True if arg == 2 else False
    )

    assert Task.reject(1).bind(lambda _: Task.of(2)).fork(
        lambda arg: True if arg == 1 else False,
        lambda arg: True if arg == 1 else False
    )


# Generated at 2022-06-12 05:40:46.518012
# Unit test for method bind of class Task
def test_Task_bind():
    assert_that(Task.of("Hello").bind(lambda x: Task.of(" ")).bind(lambda x: Task.of("World")).fork(lambda _: None, lambda v: v), equal_to("Hello World"))
    assert_that(Task.of("Hello").bind(lambda x: Task.of(" ")).bind(lambda x: Task.reject("")).fork(lambda _: None, lambda v: v), equal_to("Hello "))
    assert_that(Task.of("Hello").bind(lambda x: Task.reject("")).bind(lambda x: Task.of("World")).fork(lambda _: None, lambda v: v), equal_to("Hello"))

# Generated at 2022-06-12 05:41:10.430690
# Unit test for method map of class Task
def test_Task_map():
    def mapper(x): return x+1

    def forker(_, resolve): return resolve(4)

    task = Task(forker)
    task2 = task.map(mapper)

    def forker_resolve_4(_, resolve): return resolve(4)

    assert task2.fork == forker_resolve_4


# Generated at 2022-06-12 05:41:12.562412
# Unit test for method bind of class Task
def test_Task_bind():
    result = (
        Task.of(1)
        .bind(lambda value: Task.of(value + 1))
        .bind(lambda value: Task.of(value * 2))
    )

    assert result.fork(lambda: None, lambda value: value) == 4


# Generated at 2022-06-12 05:41:15.318914
# Unit test for method map of class Task
def test_Task_map():
    fn = lambda x: x + 1
    assert Task.of(1).map(fn).fork(None, fn) == 2


# Generated at 2022-06-12 05:41:22.215257
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(
        lambda rejected: False,
        lambda resolved: resolved
    ) == 2

    assert Task.reject(1).map(lambda x: x + 1).fork(
        lambda rejected: rejected,
        lambda resolved: False
    ) == 1


# Generated at 2022-06-12 05:41:27.726266
# Unit test for method map of class Task
def test_Task_map():
    def mapper(x):
        return x + 1

    resolved = Task.of(1).map(mapper).fork(lambda x: x, lambda x: x)
    assert resolved == 2

    rejected = Task.reject(1).map(mapper).fork(lambda x: x, lambda x: x)
    assert rejected == 1


# Generated at 2022-06-12 05:41:36.083367
# Unit test for method bind of class Task
def test_Task_bind():
    """
    NOTE: Task.bind(lambda arg: arg) === Task.map(lambda arg: arg)
    """
    assert Task(lambda _, resolve: resolve(1)) \
           .bind(lambda arg: Task.of(arg)) \
           .fork(lambda value: False, lambda value: value) == 1
    assert Task(lambda _, resolve: resolve(1)) \
           .bind(lambda arg: Task.reject(arg)) \
           .fork(lambda value: value, lambda _: False) == 1
    assert Task(lambda reject, _: reject(1)) \
           .bind(lambda arg: Task.of(arg)) \
           .fork(lambda value: value, lambda _: False) == 1

# Generated at 2022-06-12 05:41:41.840577
# Unit test for method map of class Task
def test_Task_map():
    number = Task(lambda _, resolve: resolve(666))
    string = number.map(str)
    assert string.fork(lambda _: None, lambda _: None) == "666"
    tuple_ = string.map(lambda x: (x, x))
    assert tuple_.fork(lambda _: None, lambda _: None) == ("666", "666")


# Generated at 2022-06-12 05:41:44.561696
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for correct transformation with map method.
    """
    assert Task.of(23).map(lambda value: value + 3).fork(None, lambda value: value == 26)

# Generated at 2022-06-12 05:41:55.499802
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of Task data-type
    """

    class TestTaskFork:
        """
        Stub for Task.fork attribute.
        Store all values in list.
        """

        def __init__(self):
            self.log = []

        def __call__(self, reject, resolve):
            self.log.append([reject, resolve])

    StubTask = namedtuple('StubTask', ['fork'])

    def test_call_map():
        """
        Test call of map method of Task data-type.
        """
        fork = TestTaskFork()
        stub_task = StubTask(fork)
        stub_function = lambda arg: arg + 1

        task = stub_task.map(stub_function)

# Generated at 2022-06-12 05:42:01.265261
# Unit test for method bind of class Task
def test_Task_bind():
    def get_Task(value):
        def fn(reject, resolve):
            resolve(value)

        return Task(fn)

    assert Task(lambda _, resolve: resolve(
        1
    )).bind(lambda arg: get_Task(arg + 1)).fork(lambda _: None, lambda result: result) == 2
    assert Task(lambda _, resolve: resolve(
        1
    )).bind(lambda arg: get_Task(None)).fork(lambda _: None, lambda result: result) == None



# Generated at 2022-06-12 05:42:43.010902
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task(lambda _, resolve: resolve(3))
    result = result.bind(lambda number: Task(lambda _, resolve: resolve(number - 1)))
    print(result)



# Generated at 2022-06-12 05:42:53.748185
# Unit test for method bind of class Task
def test_Task_bind():

    increment_value = lambda value: value + 1

    msg = 'Result of Task.bind must be Task class'
    task1 = Task.of(1)
    task2 = Task(lambda _, resolve: resolve(1))

    assert isinstance(task1.bind(lambda _: Task.of(1)), Task), msg
    assert isinstance(task2.bind(lambda _: Task.of(1)), Task), msg

    msg = 'Task.bind(increment_value) must return Task with value 2'
    assert task1.bind(increment_value).fork(lambda _: None, lambda value: value) == 2, msg

    msg = 'Task.bind(increment_value) must return Task with value 2'
    assert task2.bind(increment_value).fork(lambda _: None, lambda value: value) == 2, msg

# Generated at 2022-06-12 05:42:59.033082
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(arg):
        return Task.of(arg + 1)

    task_src = Task.of(1)
    task_dst = task_src.bind(fn)

    assert isinstance(task_dst, Task)
    assert task_dst.fork == fn(1).fork



# Generated at 2022-06-12 05:43:08.408586
# Unit test for method map of class Task
def test_Task_map():
    # Make Exception for testing
    class TestError(Exception):
        pass

    # Make obj for testing
    obj = {
        'value': 0,
        'error': TestError()
    }

    def assert_func(get_resolve, get_reject):
        # Update value in obj
        obj['value'] += 1

        @Task.of(obj)
        def task_of(resolve):
            # Testing of(value) function
            assert resolve is get_resolve
            return resolve(obj)

        @task_of
        def map_task(mapper):
            # Test map function
            add_one = lambda arg: arg['value'] + 1
            assert mapper(add_one) is not task_of
            assert mapper(add_one).fork is not task_of.fork

# Generated at 2022-06-12 05:43:12.123123
# Unit test for method map of class Task
def test_Task_map():
    def test(arg, count):
        assert arg == count
        return arg

    assert Task.of(0).map(test).fork(test, lambda _: None)(0) is None
    assert Task.of(1).map(test).fork(test, lambda _: None)(1) is None


# Generated at 2022-06-12 05:43:17.069096
# Unit test for method map of class Task
def test_Task_map():
    """
    Method map of class Task must return Task with resolved value.
    """
    task = Task(
        lambda reject, resolve: resolve(2)
    )
    result = Task.of(2)
    assert task.map(lambda x: x + 1).fork == result.fork


# Generated at 2022-06-12 05:43:23.454139
# Unit test for method bind of class Task
def test_Task_bind():
    def get_value(value):
        return Task.of(value)

    def get_error_value(value):
        return Task.reject(value)

    assert Task.of(4).bind(get_value).fork(lambda x: x, lambda x: x) == 4
    assert Task.of(4).bind(get_error_value).fork(lambda x: x, lambda x: x) == 'error'


# Generated at 2022-06-12 05:43:32.556242
# Unit test for method map of class Task
def test_Task_map():
    def func(x):
        return x * 2

    # When task.resolve value is integer
    task = Task.of(1)
    result = task.map(func)
    assert result.fork(None, None) == 2

    # When task.resolve value is string
    task = Task.of('a')
    result = task.map(func)
    assert result.fork(None, None) == 'aa'

    # When task is rejected
    task = Task.reject(1)
    result = task.map(func)
    assert result.fork(None, None) == 1


# Generated at 2022-06-12 05:43:37.363179
# Unit test for method bind of class Task
def test_Task_bind():
    def test(arg):
        def res(reject, resolve):
            reject(arg)
            resolve(arg)

        return Task(res)

    result = Task.of(1).bind(test)

    assert result.fork(lambda r: r, lambda _: 1) == 1

# Generated at 2022-06-12 05:43:46.041708
# Unit test for method map of class Task
def test_Task_map():
    # task = Task.of(10).map(lambda x: x * x)
    # assert task.fork(lambda x: x, lambda x: x) == 100

    # task = Task.of(10).map(lambda x: x * x).map(lambda x: x + 10)
    # assert task.fork(lambda x: x, lambda x: x) == 110

    task = Task.of(10).map(lambda x: x * x).map(
        lambda x: Task.of(x + 10)
    ).bind(
        lambda x: Task.of(x + 20)
    )
    assert task.fork(lambda x: x, lambda x: x) == 140

    task = Task.reject(100).map(lambda x: x * x)
    assert task.fork(lambda x: x, lambda x: x)

# Generated at 2022-06-12 05:45:14.853543
# Unit test for method bind of class Task
def test_Task_bind():
    flag = [False]
    def fork(reject, resolve):
        (reject if flag[0] else resolve)(1)
    another_flag = [False]
    def mapper(value):
        (reject if another_flag[0] else resolve)(value + 1)

    flag[0] = False
    another_flag[0] = False
    result = Task(fork).bind(mapper).fork(None, lambda val: val)
    assert result == 2

    flag[0] = False
    another_flag[0] = True
    result = Task(fork).bind(mapper).fork(lambda val: val, None)
    assert result == 2

    flag[0] = True
    another_flag[0] = False
    result = Task(fork).bind(mapper).fork(lambda val: val, None)

# Generated at 2022-06-12 05:45:19.134031
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Check that bind method of Task class works correctly.
    """
    assert Task(lambda _, resolve: resolve('value')).bind(lambda a: Task.of('mapped_' + a)).fork(lambda _: None, lambda a: a) == 'mapped_value'


# Generated at 2022-06-12 05:45:23.805247
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return 2 * value

    result = Task.of(1).map(fn)
    assert result.fork(
        lambda value: False,
        lambda value: value == 2
    )


# Generated at 2022-06-12 05:45:26.864525
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    assert Task.of(1).map(add_one).fork(lambda _: None, lambda x: x) == 2


# Generated at 2022-06-12 05:45:33.598169
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x * 2

    def fn_with_errors(x):
        if x < 0:
            raise ValueError("x must be positive value")
        return x * 2

    task = Task(lambda reject, resolve: resolve(1))
    assert task.fork(lambda x: x, lambda x: x) == 1
    assert task.map(fn).fork(lambda x: x, lambda x: x) == 2

    task = Task(lambda reject, resolve: reject(1))
    assert task.fork(lambda x: x, lambda x: x) == 1
    assert task.map(fn).fork(lambda x: x, lambda x: x) == 1

    task = Task(lambda reject, resolve: resolve(-1))
    assert task.fork(lambda x: x, lambda x: x) == -1
   

# Generated at 2022-06-12 05:45:39.765167
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value * 2

    # test for correct execution of function
    task = Task(lambda _, resolve: resolve(2))
    assert task.map(fn).fork(lambda _: False, lambda value: value == 4)

    # test for error rejection
    assert not Task.reject(2).map(fn).fork(lambda _: True, lambda _: False)


# Generated at 2022-06-12 05:45:48.062878
# Unit test for method map of class Task
def test_Task_map():
    """
    Test of method Task.map
    """

    task = Task.of('value')
    assert task.map(lambda x: x + '2').fork(lambda x: x, lambda x: x) == 'value2'

    task = Task.of('value')
    assert task.map(lambda x: x + '2').map(lambda x: x + '3').fork(
        lambda x: x,
        lambda x: x
    ) == 'value23'

    task = Task.of('value')
    assert task.map(lambda x: x + '2').bind(lambda x: Task.of(x + '3')).fork(
        lambda x: x,
        lambda x: x
    ) == 'value23'


# Generated at 2022-06-12 05:45:55.572869
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        """
        Run reject and resolve
        """
        reject(3)
        return resolve(2)

    def fork_reject(reject, resolve):
        reject(None)
        return resolve(None)

    t = Task(fork)
    t_reject = Task(fork_reject)

    def fn_a(v):
        return Task.of(v + 1)

    def fn_b(v):
        return Task.reject(v)

    def fn_c(v):
        return Task.of(v)

    def fn_d(v):
        return Task.of(v + 1)

    def fn_e(_):
        return Task.reject(2)

    def fn_f(v):
        return Task.of(v)


# Generated at 2022-06-12 05:46:04.588884
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Function check how work bind metod of class Task with two arguments.

    :returns: void
    :rtype: None
    """
    def resolve_function(value):
        """
        Function return value with added 'resolve_test' string.

        :param value: value which need to be resolved
        :type value: A
        :returns: value with added 'resolve_test' string
        :rtype: A
        """
        return value + ' resolve_test'

    def reject_function(value):
        """
        Function return value with added 'reject_test' string.

        :param value: value which need to be rejected
        :type value: A
        :returns: value with added 'reject_test' string
        :rtype: A
        """
        return value + ' reject_test'