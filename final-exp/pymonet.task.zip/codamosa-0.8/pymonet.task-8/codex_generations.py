

# Generated at 2022-06-12 05:36:12.656192
# Unit test for method map of class Task
def test_Task_map():
    def temp(reject, resolve):
        resolve(1)
        reject(2)

    def add_one(x):
        return x + 1

    assert add_one(1) == Task(temp).map(add_one).fork(lambda x: x, lambda x: x)
    assert 2 == Task(temp).fork(lambda x: x, lambda x: x)


# Generated at 2022-06-12 05:36:21.493720
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method map of class Task.
    """
    def test_positive_case():
        """
        Test method map of class Task in positive case.
        """
        @Task.of(2)
        def task(resolve):
            return resolve

        def double(number):
            return number * 2

        @task.map(double)
        def result(reject, resolve):
            return resolve
        assert result == 4

    def test_negative_case():
        """
        Test method map of class Task in negative case.
        """
        @Task.of(2)
        def task(resolve):
            return resolve

        def double(number):
            return number * 2

        @task.map(double)
        def result(reject, resolve):
            return reject
        assert result == 2

    test_positive

# Generated at 2022-06-12 05:36:26.514035
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for map method of class Task.
    Simple use case: it called with function that add 2 to argument.
    """
    Task.of(1).map(lambda x: x + 2).fork(
        lambda arg: arg,
        lambda arg: print(arg)
    )



# Generated at 2022-06-12 05:36:30.835573
# Unit test for method map of class Task
def test_Task_map():
    lazy_increment = Task(fork(lambda reject, resolve: resolve(1)))
    result = lazy_increment.map(lambda v: v + 1)
    assert result.fork(lambda _: None, lambda v: v) == 2


# Generated at 2022-06-12 05:36:32.041662
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(5).map(lambda x: x * 2).fork(None, lambda x: x) == 10


# Generated at 2022-06-12 05:36:45.421723
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind method of class Task.
    """
    t = Task.of(10)

    def mapper(value):
        """
        :param value: value to increment
        :type value: int
        :returns: new incremented value
        :rtype: int
        """
        return value + 10

    def rejected_mapper(value):
        """
        :param value: value to increment
        :type value: int
        :returns: rejected Task with incremented value
        :rtype: Task[int]
        """
        return Task.reject(value + 10)

    resolved = t.bind(mapper)
    rejection = t.bind(rejected_mapper)

    assert resolved.fork(identity, identity) == 20
    assert rejection.fork(identity, identity) == 20

#

# Generated at 2022-06-12 05:36:48.468424
# Unit test for method map of class Task
def test_Task_map():
    def f(value):
        return value + 1

    task = Task.of(1).map(f)
    assert task.fork(None, lambda x: x) == 2



# Generated at 2022-06-12 05:37:00.941096
# Unit test for method map of class Task
def test_Task_map():
    def run_Task(task):
        def fork(reject, resolve):
            return task.fork(reject, resolve)
        return Task(fork)

    # TODO: add more test data

    assert Task.of(1) == run_Task(Task.of(1).map(lambda x: x))
    assert Task.of(3) == run_Task(Task.of(2).map(lambda x: x + 1))
    assert Task.of(True) == run_Task(Task.of(1).map(lambda x: True))
    assert Task.of(None) == run_Task(Task.of(2).map(lambda x: None))
    assert Task.reject(False) == run_Task(Task.reject(False).map(lambda x: x))
    assert Task.reject(True) == run_

# Generated at 2022-06-12 05:37:04.796071
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(3).map(lambda x: x + 3) is Task.of(6)
    assert Task.of(3).map(lambda x: x + 3).fork(None, lambda x: x) == 6

# Generated at 2022-06-12 05:37:08.826578
# Unit test for method bind of class Task
def test_Task_bind():
    assert (
        Task.of(2).bind(lambda x: Task.of("x" + str(x))).bind(lambda y: Task.of(y.upper())).fork(
            lambda rejected: "FAIL",
            lambda resolved: resolved
        ) == "X2"
    )


# Generated at 2022-06-12 05:37:17.344402
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        return Task.of(x+1)
    t = Task.of(1).bind(f).bind(f).bind(f)
    assert t.fork(lambda x: x, lambda x: x) == 4
while True:
    Task.of(1).bind(lambda x: Task.of(x+1)).bind(lambda x: Task.of(x+2)).bind(lambda x: Task.of(x+3))

# test_Task_bind()

# Generated at 2022-06-12 05:37:24.242549
# Unit test for method map of class Task
def test_Task_map():
    def get_task(value):
        return Task(lambda _, resolve: resolve(value))

    def mapper(value):
        return value + 1

    def mapper_negative(value):
        return value - 1

    assert get_task(1).map(mapper).fork(None, lambda value: value) == 2
    assert get_task(1).map(mapper_negative).fork(None, lambda value: value) == 0


# Generated at 2022-06-12 05:37:29.238684
# Unit test for method map of class Task
def test_Task_map():
    def add(value):
        assert value == 2
        return 2 + 3

    def reject(value):
        assert value == 2
        return 2

    def fork(reject, resolve):
        assert reject(2) == 2
        assert resolve(2) == None

    Task(fork).map(add).fork(None, None)
    Task(fork).fork(reject, None)

if __name__ == '__main__':
    test_Task_map()

# Generated at 2022-06-12 05:37:31.565769
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1).bind(lambda value: Task.of(value + 1))
    assert isinstance(task, Task)


# Generated at 2022-06-12 05:37:37.759019
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return str(value) + '!'

    def method(reject, resolve):
        resolve(1)

    task = Task(method)
    new_task = task.map(mapper)

    assert task is not new_task
    assert new_task.fork(lambda value: value, lambda _: None) == '1!'


# Generated at 2022-06-12 05:37:42.538224
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    task = Task.of(1)
    task_add_one = task.map(add(1))
    task_add_one_value = task_add_one.fork(None, lambda x: x)

    assert(task_add_one_value == 2)


# Generated at 2022-06-12 05:37:47.069501
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def error(arg):
        if arg == 1:
            return Task.reject("error")
        return Task.reject(arg)

    assert Task.of(2).bind(add).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 3

    assert Task.of(2).bind(error).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == "error"



# Generated at 2022-06-12 05:37:55.580908
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(lambda x: None, lambda x: x) == 2
    assert Task.of(1).bind(lambda x: Task.reject(x + 1)).fork(lambda x: x, lambda x: None) == 2
    assert Task.reject(1).bind(lambda x: Task.of(x + 1)).fork(lambda x: x, lambda x: None) == 1
    assert Task.reject(1).bind(lambda x: Task.reject(x + 1)).fork(lambda x: x, lambda x: None) == 1

# Generated at 2022-06-12 05:38:00.127241
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Try to call Task.reject with value 42.
    Then call bind with function, that return Task with resolve value.
    Then call fork of this Task and check that failure will be called.
    """
    assert Task.reject(42).bind(
        lambda _: Task.of(666)
    ).fork(
        lambda failure: failure,
        lambda success: None
    ) == 42


# Generated at 2022-06-12 05:38:05.796719
# Unit test for method map of class Task
def test_Task_map():
    def assert_map(args, expected):
        task = Task.of(args)
        result = task.map(lambda x: x * 2)
        assert expected == result.fork(lambda x: x, lambda x: x)

    assert_map(10, 20)
    assert_map(0.5, 1)



# Generated at 2022-06-12 05:38:09.841271
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    result = Task.of(1).bind(add).bind(add).fork(None, None)
    assert result == 3


# Generated at 2022-06-12 05:38:16.629892
# Unit test for method bind of class Task
def test_Task_bind():
    import pytest

    def test_happy_path(mocker):
        m = mocker.MagicMock()
        m.fork = mocker.MagicMock()
        result = Task.of(1).bind(lambda i: Task.of(i + 1))
        result.fork(None, None)
        m.fork.assert_called_with(None, mocker.ANY)

    def test_with_stub_fork(mocker):
        m = mocker.MagicMock()
        m.fork = mocker.MagicMock()
        result = Task.of(1).bind(lambda i: Task.of(i + 1))
        result.fork(None, None)
        m.fork.assert_called_with(None, mocker.ANY)


# Generated at 2022-06-12 05:38:22.078397
# Unit test for method bind of class Task
def test_Task_bind():
    def inner(x, y):
        return x - y

    task = Task.of(22)
    task = task.bind(lambda x: Task.of(x + 10))
    task = task.bind(lambda x: Task.of(inner(x, 10)))
    assert task.fork(None, lambda x: x) == 22


# Generated at 2022-06-12 05:38:31.078960
# Unit test for method bind of class Task
def test_Task_bind():
    def double(num):
        return num * 2

    def triple(num):
        return num * 3

    def quad(num):
        return num * 4

    def Penta(num):
        return num * 5

    task = Task.of(2) \
        .bind(lambda x: Task.of(x + 1)) \
        .bind(lambda x: Task.of(double(x))) \
        .bind(lambda x: Task.of(triple(x))) \
        .bind(lambda x: Task.of(quad(x))) \
        .bind(lambda x: Task.of(Penta(x)))

    assert task.fork(lambda x: x, lambda x: x) == 240



# Generated at 2022-06-12 05:38:35.690395
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind method
    """
    assert Task(lambda _, resolve: resolve(2)).bind(lambda arg: Task.of(arg * 2)).fork(None, lambda arg: arg) == 4


# Generated at 2022-06-12 05:38:39.264941
# Unit test for method map of class Task
def test_Task_map():
    @Task.of(1)
    @Task.map(lambda x: x + 1)
    def task(reject, resolve):
        pass

    assert task.fork(
        lambda arg: None,
        lambda arg: arg
    ) == 2


# Generated at 2022-06-12 05:38:49.453765
# Unit test for method bind of class Task
def test_Task_bind():
    def add(i):
        return i + 1

    def get_i(request):
        return Task(lambda _, resolve: resolve(request.args.get("i")))

    @app.route("/", methods=["GET"])
    def main():
        i = Task(lambda _, resolve: resolve(request.args.get("i"))).bind(add).fork(
            lambda error: str(error),
            lambda value: value
        )
        return Response(i, mimetype="text/json")

    with app.test_client() as client:
        res = client.get("/?i=4")
        assert res.data == b"5"


# Generated at 2022-06-12 05:38:59.379813
# Unit test for method map of class Task
def test_Task_map():
    def f(x):
        return x * 2

    def g(x):
        return Task.of(x * 3)

    def h(x):
        return Task.of(x * 4)

    task_x = Task.of(5).map(f).map(g)
    assert task_x.fork(lambda _: _, lambda _: _) == 30

    task_x = Task.of(5).map(f).map(g).map(h)
    assert task_x.fork(lambda _: _, lambda _: _) == 120

    task_x = Task.of(5).bind(g).bind(h)
    assert task_x.fork(lambda _: _, lambda _: _) == 60


# Generated at 2022-06-12 05:39:05.272568
# Unit test for method bind of class Task
def test_Task_bind():
    state = 0
    def get_state():
        nonlocal state
        state += 1
        return state

    task = Task.reject(1).bind(lambda x: Task.of(2)).bind(lambda x: Task.reject(3))
    task.fork(lambda x: get_state())
    assert state == 1


# Generated at 2022-06-12 05:39:08.859760
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Should return Task with value.
    """
    value = Task.of(1)
    fn = lambda value: Task.of(value + 1)

    result = value.bind(fn)

    assert result.fork(None, identity) == 2


# Generated at 2022-06-12 05:39:18.020408
# Unit test for method bind of class Task
def test_Task_bind():
    origin = Task.of(2)
    origin2 = origin.bind(lambda arg: Task.reject(arg * 3))
    assert origin2.fork(lambda arg: arg, lambda _: None) == 6

    assert origin.bind(lambda arg: Task.of(arg * 3)).fork(lambda arg: arg, lambda _: None) == 6


# Generated at 2022-06-12 05:39:21.077497
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    task = task.map(lambda x: x + 1)
    assert task.fork(lambda _ : '', lambda x: x == 2)


# Generated at 2022-06-12 05:39:25.050035
# Unit test for method map of class Task
def test_Task_map():
    def func1(value):
        return value ** 2

    assert Task.of(3).map(func1) == Task.of(9)



# Generated at 2022-06-12 05:39:35.729527
# Unit test for method map of class Task
def test_Task_map():
    def test_success(result, expect):
        if result != expect:
            raise Exception(
                "Expect {}, get instead {}".format(expect, result)
            )

    def to_upper(s):
        return s.upper()

    def to_lower(s):
        return s.lower()

    def a_plus_b(a, b):
        return a + b

    def a_to_b(a, b):
        return b

    def a_b_plus(a, b):
        return a + b

    def b_a_plus(a, b):
        return b + a

    def square(x):
        return x ** 2

    def succ(x):
        return x + 1


# Generated at 2022-06-12 05:39:43.529635
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for handle nested Task.
    """
    dbl = lambda num: num * 2
    dec = lambda num: num - 1

    def testTask(reject, resolve):
        resolve(2)

    task = Task(testTask)
    assert task.bind(lambda n: Task.of(n * 2)).fork(lambda _: False, lambda n: n == 4)
    assert task.bind(lambda n: Task.of(n * 2)).fork(lambda _: False, lambda n: n == 3) == False

# Generated at 2022-06-12 05:39:52.472507
# Unit test for method map of class Task
def test_Task_map():
    # we can use this function to test Task.reject
    def tester(res_value, res_fn, rej_value, rej_fn):
        res_fn(res_value)
        rej_fn(rej_value)

    def test(res_value, res_fn, rej_value, rej_fn):
        task = Task(lambda res, rej: tester(res_value, res_fn, rej_value, rej_fn))
        mapped_task = task.map(lambda v: v * 2)
        mapped_task.fork(rej_fn, res_fn)

    test(2, lambda v: print('resolved:', v), 10, lambda _: print('rejected'))

# Generated at 2022-06-12 05:39:59.591314
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(5)

    task = Task(fork).bind(lambda a: Task(lambda _, resolve: resolve(a + 5)))
    promise = Promise()
    task.fork(lambda err: promise.reject(err), lambda res: promise.resolve(res))
    assert promise.value.get() == 10

    def fork(reject, resolve):
        return reject(5)

    task = Task(fork).bind(lambda a: Task(lambda _, resolve: resolve(a + 5)))
    promise = Promise()
    task.fork(lambda err: promise.reject(err), lambda res: promise.resolve(res))
    assert promise.error.get() == 5



# Generated at 2022-06-12 05:40:09.006008
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method.
    """
    def add(value):
        """
        Add 1 to input value.

        :param value: value to add to
        :type value: Number
        :returns: value + 1
        :rtype: Number
        """
        return value + 1

    # Mapped task with `add` function
    mapped = Task.of(1).bind(lambda x: Task.of(x * 2))

    def fork(resolve, reject):
        """
        Fork function for mapped task.

        :param resolve: resolve function
        :type resolve: Function(value)
        :param reject: reject function
        :type reject: Function(value)
        """
        return mapped.fork(reject, resolve)

    test_case = assertEqual(fork(add, add), 4)


# Generated at 2022-06-12 05:40:14.181457
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x + 1

    assert Task.of(1).map(fn).fork(lambda a: a, lambda b: b) == 2
    assert Task.of("1").map(fn).fork(lambda a: a, lambda b: b) == 2

test_Task_map()


# Generated at 2022-06-12 05:40:19.712114
# Unit test for method bind of class Task
def test_Task_bind():
    def get_task(value):
        def fork(reject, resolve):
            resolve(value)

        return Task(fork)

    def say_hi(value):
        return get_task('hi ' + str(value))

    result = get_task('world').bind(say_hi).bind(say_hi)
    assert result.fork(lambda e: e, lambda d: d) == 'hi hi world'  # noqa



# Generated at 2022-06-12 05:40:27.798872
# Unit test for method bind of class Task
def test_Task_bind():
    def test():
        return Task.of(1)\
            .bind(lambda val: Task.of(val + 1))\
            .bind(lambda val: Task.of(val + 2))\
            .bind(lambda val: Task.of(val + 3))

    t = test()
    assert t.fork(lambda val: val, lambda _: None) == None
    assert t.fork(lambda _: None, lambda val: val) == 7



# Generated at 2022-06-12 05:40:33.140889
# Unit test for method map of class Task
def test_Task_map():
    def test_function(value):
        return value + 1

    def assert_function(value):
        assert value == 2

    Task.of(1).map(test_function).map(assert_function).fork(lambda _: None, lambda _: None)


# Generated at 2022-06-12 05:40:41.164351
# Unit test for method bind of class Task
def test_Task_bind():
    from unittest import TestCase, main

    class TaskTest(TestCase):
        def test_task_bind(self):
            def some_function():
                return 'some'

            def another_function():
                return 'another'

            task = Task.of('task')
            some_task = task.bind(lambda _: Task.of(some_function()))
            another_task = some_task.bind(lambda _: Task.of(another_function()))

            self.assertEqual(another_task.fork(None, lambda value: value), 'another')

    main()


# Generated at 2022-06-12 05:40:45.363561
# Unit test for method map of class Task
def test_Task_map():
    def fn():
        return 1

    def task(resolve, reject):
        return resolve(fn)

    def mapper(fn):
        return fn()

    new_task = Task(task).map(mapper)
    assert new_task.fork(lambda _: reject, lambda val: val()) == 1


# Generated at 2022-06-12 05:40:52.603141
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    # Make function to test
    fn = lambda arg: arg + 2

    # Make Task
    task = Task.of(3).bind(
        lambda arg: Task.of(fn(arg))
    )

    # Test and assert results
    def resolve(result):
        """
        Test result and add value to result of tests.
        """
        assert result == 5
        return 0

    def reject(_):
        """
        Test reject and add value to result of tests.
        """
        return 1
    assert task.fork(reject, resolve) == 0


# Generated at 2022-06-12 05:40:55.414109
# Unit test for method bind of class Task
def test_Task_bind():
    assert (Task.of(1).bind(lambda number: Task.of(number + 2)).fork(lambda _: None, lambda value: value)) == 3


# 8. List



# Generated at 2022-06-12 05:41:03.704929
# Unit test for method bind of class Task
def test_Task_bind():
    def task_of_2():
        return Task.of(2)

    def task_of_3():
        return Task.of(3)

    def times_two(x):
        return x * 2

    def times_two_then_three(x):
        return Task.of(x * 2).map(lambda x: x * 3)

    def error(err):
        raise AssertionError('{error}'.format(error=err))


# Generated at 2022-06-12 05:41:08.443811
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit testing for method "bind" in class Task
    """
    def my_fork(reject, resolve):
        resolve(0)

    assert Task(my_fork) == Task.reject(0).bind(lambda value: Task.of(value))

    def my_fork(reject, resolve):
        resolve(0)

    assert Task(my_fork) == Task.of(0).bind(lambda value: Task.of(value))

# Generated at 2022-06-12 05:41:15.820474
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Tests for method bind of Task.
    """
    def mapper(value):
        return Task.of(value + 1)

    task = Task.of(10)
    assert task.bind(mapper).fork(lambda _: None, None) == 11

    def second_mapper(value):
        return Task.reject(value + 1)

    assert task.bind(second_mapper).fork(None, lambda _: None) == 11


# Generated at 2022-06-12 05:41:24.636230
# Unit test for method bind of class Task
def test_Task_bind():
    is_rejected = False
    is_resolved = False

    def reject(error):
        assert error == 'error'
        nonlocal is_rejected
        is_rejected = True

    def resolve(result):
        nonlocal is_resolved
        is_resolved = True

    task = Task.reject('error')
    task.bind(lambda value: Task.of(value + 1)).fork(reject, resolve)

    assert is_resolved is False
    assert is_rejected is True


# Generated at 2022-06-12 05:41:32.297674
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    # Task.of(42).map(fn).fork(lambda v: print(v), lambda v: print(v))
    assert Task.of(42).map(fn).fork(lambda v: v, lambda v: v) == 43


# Generated at 2022-06-12 05:41:40.104133
# Unit test for method map of class Task
def test_Task_map():
    """
    Test of method map of class Task.
    """
    # Define function to map
    def function(value):
        """
        Simple mapper.
        :param value: any value
        :type value: A
        :returns: value + 1
        :rtype: A + 1
        """
        return value + 1

    task = Task.of(42)

    assert isinstance(task, Task) is True
    assert isinstance(task.map(function), Task) is True
    assert task.fork(lambda x: x * 2, lambda x: x * 2) == 43


# Generated at 2022-06-12 05:41:45.371240
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test case for Task.bind method.
    """
    def fork(reject, resolve):
        resolve('value')

    def mapper(value):
        return Task.of(value + '_mapped')

    task = Task(fork)
    mapped_value = task.bind(mapper)
    assert mapped_value.fork(lambda _: 'fail', lambda value: value) == 'value_mapped'


# Generated at 2022-06-12 05:41:50.275285
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> a = Task.of(4)
    >>> b = Task.of(2)
    >>> c = Task.of(3)
    >>> (a.bind(lambda x: b.bind(lambda y: c.map(lambda z: x + y + z)))
    ...     .fork(lambda x: x, lambda x: x))
    9
    """


# Generated at 2022-06-12 05:41:57.628283
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    """
    def add(x):
        return Task.of(x + 1)

    source = Task.of(1)
    assert source.bind(add).fork(lambda x: x, lambda x: x) == 2

    source = Task.of(4)
    assert source.bind(add).bind(add).fork(lambda x: x, lambda x: x) == 6

    source = Task.reject(2)
    assert source.bind(add).fork(lambda x: x, lambda x: x) == 2

# Generated at 2022-06-12 05:42:00.723136
# Unit test for method bind of class Task
def test_Task_bind():
    def div(a):
        return Task.of(lambda b: b / a)

    task = Task.of(2).bind(div)

    assert task.fork(None, lambda fn: fn(4)) == 2


# Generated at 2022-06-12 05:42:09.343006
# Unit test for method bind of class Task
def test_Task_bind():
    count = {'num': 0}

    # create Task object with resolve value
    task = Task.of({"id": 1, "name": "User 1"})
    assert task.fork(
        lambda arg: count['num'] == 0 and True,
        lambda arg: count['num'] == 1 and True
    )

    # bind method with function, which returns Task.of.
    # result of bind method should be new task with resolve value equal
    # to result of function, which passed to bind method
    task_fn = lambda arg: Task.of(arg['id'])
    assert task.bind(task_fn).fork(
        lambda arg: count['num'] == 1 and True,
        lambda arg: count['num'] == 2 and arg == 1
    )
    assert count['num'] == 2


# Generated at 2022-06-12 05:42:16.153808
# Unit test for method bind of class Task
def test_Task_bind():
    def add_1(x):
        return x + 1

    def square(x):
        return x * x

    def divide_by_2(x):
        return x / 2

    result = Task.of(1) \
        .bind(Task.of) \
        .map(add_1) \
        .bind(Task.of) \
        .map(square) \
        .bind(Task.of) \
        .map(divide_by_2) \
        .fork(
            lambda err: None,
            lambda res: print(res)
        )
    
    assert result == 4



# Generated at 2022-06-12 05:42:20.102168
# Unit test for method bind of class Task
def test_Task_bind():
    def add(arg):
        return Task.of(arg+1)

    def reject(arg):
        return Task.reject(arg)

    assert Task.of(2).bind(add).fork(lambda _: False, lambda arg: arg == 3)
    assert Task.of(2).bind(reject).fork(lambda _: True, lambda _: False)



# Generated at 2022-06-12 05:42:22.605435
# Unit test for method map of class Task
def test_Task_map():
    import promis
    fn = lambda call_reject: Task.of(call_reject)
    assert fn(1).map(lambda arg: arg + 1).fork(lambda _: -1, lambda arg: arg) == 2


# Generated at 2022-06-12 05:42:32.615383
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    mapped_task = task.map(lambda arg: arg + 1)

    assert mapped_task.fork(lambda arg: print("Error: ", arg), lambda arg: arg) == 2


# Generated at 2022-06-12 05:42:37.609131
# Unit test for method map of class Task
def test_Task_map():
    def test_side_effect(x):
        return x

    def fork(_, resolve):
        resolve(42)

    def test_map(x):
        return x + 1

    task = Task(fork)
    mapped = task.map(test_map)

    assert isinstance(mapped, Task)

    assert mapped.fork(test_side_effect, test_side_effect) == 43



# Generated at 2022-06-12 05:42:43.334541
# Unit test for method map of class Task
def test_Task_map():
    def function_for_Task(reject, resolve):
        resolve("some value")

    def mapper(value):
        return value + "_mapped"

    task = Task(function_for_Task)
    mapped_task = task.map(mapper).fork(None, lambda value: print(value))
    return "some value_mapped"



# Generated at 2022-06-12 05:42:49.201256
# Unit test for method bind of class Task
def test_Task_bind():
    def reject_task(value):
        return Task(lambda reject, _: reject(value))

    def resolve_task(value):
        return Task(lambda _, resolve: resolve(value))

    assert Task.of(5).bind(resolve_task).fork(lambda arg: arg, None) == 5
    assert Task.of(5).bind(reject_task).fork(None, lambda arg: arg) == 5

# Generated at 2022-06-12 05:42:57.195769
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind method.
    """

    task0 = Task.of(0)
    task1 = Task.of(1)
    task2 = Task.of(2)

    assert task0.bind(lambda _: task1).fork(
        lambda x: x,
        lambda y: y
    ) == 1

    assert task1.bind(lambda _: task2).fork(
        lambda x: x,
        lambda y: y
    ) == 2

    task3 = Task.of(3).bind(lambda _: Task.of(4).bind(lambda _: Task.of(5)))

    assert task3.fork(
        lambda x: x,
        lambda y: y
    ) == 5

# Generated at 2022-06-12 05:43:00.830176
# Unit test for method map of class Task
def test_Task_map():
    def identity(x):
        return x

    fn = Task(lambda _, resolve: resolve(2)).map(identity)
    assert fn.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-12 05:43:05.618891
# Unit test for method map of class Task
def test_Task_map():
    def check(another, expected):
        actual = Task.of(
            0
        ).map(
            lambda x: x + 10
        ).map(
            lambda x: x * 5
        ).fork(
            lambda _: another,
            lambda _: another
        )

        assert actual == expected

    check(5, 50)



# Generated at 2022-06-12 05:43:07.872701
# Unit test for method bind of class Task
def test_Task_bind():
    async with Task(lambda reject, resolve: resolve(1)) \
                .bind(lambda value: Task.of(value + 1)) as result:
        assert result == 2

# Generated at 2022-06-12 05:43:11.915516
# Unit test for method map of class Task
def test_Task_map():
    """
    Test to check that method map call mapper function with result of Task and return
    new Task with result of this call.
    """
    class Mock(object):

        def __init__(self, fn):
            self.fn = fn

        def __call__(self, resolve, reject):
            return self.fn(resolve, reject)

    def test_fn_call(*args):
        assert args == (lambda _: _, lambda arg: arg+1)

    def test_fn_call_error(*args):
        assert args == (lambda _: _, lambda arg: arg+1)

    task = Task(test_fn_call) \
        .map(lambda arg: arg+1)
    task.fork(lambda _: _, lambda _: _)


# Generated at 2022-06-12 05:43:16.418243
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(5).bind(lambda x: Task.of(x * 2)).fork(lambda x: x, lambda x: x) == 10
    assert Task.of(5).bind(lambda x: Task.reject(x)).fork(lambda x: x, lambda x: x) == 5


# Generated at 2022-06-12 05:43:32.598778
# Unit test for method map of class Task
def test_Task_map():
    def test_case(value, fn, expected_value):
        assert Task.of(value).map(fn).fork == expected_value

    def adder(x):
        return x + 1

    test_case(1, adder, Task(lambda _, resolve: resolve(2)).fork)



# Generated at 2022-06-12 05:43:38.232612
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(None)
    task = task.map(lambda arg: arg + 1)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 1

    assert Task.of(2).map(lambda arg: arg ** 2).fork(lambda arg: arg, lambda arg: arg) == 4


# Generated at 2022-06-12 05:43:42.522136
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task method 'map'.
    Check if method map return new Task with mapped result.
    """

    task = Task.of(42).map(lambda arg: arg + 1)


# Generated at 2022-06-12 05:43:49.202284
# Unit test for method bind of class Task
def test_Task_bind():
    def binder(arg):
        return Task.of('binded')

    def binded_rejected(arg):
        assert arg == 'rejected'

    def binded_resolved(arg):
        assert arg == 'binded'

    Task.reject('rejected').bind(binder).fork(binded_rejected, binded_resolved)
    Task.of('resolved').bind(binder).fork(binded_rejected, binded_resolved)


# Generated at 2022-06-12 05:43:53.239938
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(5)
    assert task.bind(lambda _: Task.of(10)).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 10

    def err(x): return Task.reject(x)
    assert task.bind(err).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 5


# Generated at 2022-06-12 05:44:02.846293
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Basic tests that method bind work as expected.
    """
    def mapper(arg): return arg.map(lambda v: v * 2)

    def f1(arg):
        raise ValueError("Unexpected")

    def f2(arg):
        raise ValueError("Not handled")

    def f3(arg):
        raise ValueError("Not handled")

    assert Task.of('test').bind(mapper).fork(f1, f2) == 'testtest'
    assert Task.reject('test').bind(mapper).fork(f3, f2) == 'test'

test_Task_bind()


# Generated at 2022-06-12 05:44:06.392469
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda _, resolve: resolve(1))

    assert task.map(lambda v: v + 5).fork(None, lambda v: v) == 6
    assert task.map(lambda v: v - 5).fork(None, lambda v: v) == -4


# Generated at 2022-06-12 05:44:13.704682
# Unit test for method map of class Task
def test_Task_map():
    def assert_if(value):
        return Task.of(value + 1)

    def assert_else(value):
        return Task.reject(value - 1)

    def assert_map(value):
        return Task.of(value).map(lambda v: v * 2)

    assert_if(10).fork(assert_false, assert_true)
    assert_else(10).fork(assert_true, assert_false)
    assert_map(4).fork(assert_false, assert_equal(8))


# Generated at 2022-06-12 05:44:23.151289
# Unit test for method map of class Task
def test_Task_map():
    def left(value):
        return Left(value)

    def right(value):
        return Right(value)

    # Map on Left
    result = Task.of(left(1)).map(right)
    assert isinstance(result.fork(lambda arg: arg, lambda arg: arg), Left)
    assert result.fork(lambda arg: arg, lambda arg: arg).value == 1

    # Map on Right
    result = Task.of(right(1)).map(right)
    assert isinstance(result.fork(lambda arg: arg, lambda arg: arg), Right)
    assert result.fork(lambda arg: arg, lambda arg: arg).value == 1


# Generated at 2022-06-12 05:44:28.812957
# Unit test for method map of class Task
def test_Task_map():
    def tester(actual, expected):
        task = Task(lambda reject, resolve: resolve(actual))
        res_task = task.map(lambda arg: arg + 100)
        actual = res_task.fork(lambda _: None, lambda arg: arg)
        assert actual == expected

    tester(10, 110)
    tester(None, 100)
    tester(False, False)


# Generated at 2022-06-12 05:44:57.365044
# Unit test for method bind of class Task
def test_Task_bind():
    def test(reject, resolve):
        return resolve(1)

    _test = Task(test)
    test_result = _test.map(lambda arg: arg + 1).bind(
        lambda arg: _test.map(lambda arg: arg + 10)
    )
    assert test_result.fork(lambda arg: None, lambda arg: arg) == 12


# Generated at 2022-06-12 05:44:59.614391
# Unit test for method bind of class Task
def test_Task_bind():
    def forker(_, resolve):
        resolve("It works!")

    task = Task(forker)
    task_two = task.bind(lambda value: Task.reject(value + '??'))

    assert task_two.fork(lambda arg: arg, lambda arg: arg) == "It works!?"


# Generated at 2022-06-12 05:45:05.190533
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    assert task.fork(None, lambda x: x) == 1

    task = task.map(lambda x: x + 1)
    assert task.fork(None, lambda x: x) == 2

    task = task.map(lambda x: 'value: {}'.format(x))
    assert task.fork(None, lambda x: x) == 'value: 2'


# Generated at 2022-06-12 05:45:09.604216
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(lambda err: 'error', lambda value: value) == 2


# Generated at 2022-06-12 05:45:19.972653
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind.
    """

    def test(name, actual, expected):
        """
        Test if actual is equal to expected.

        :param name: name of test
        :type name: str
        :param actual: result to test
        :type actual: A
        :param expected: expected value
        :type expected: A
        """
        assert actual == expected,\
            f'Test {name} - Expected: {expected}, actual: {actual}'

    def square_task(x):
        """
        Return Task with square of given number.

        :param x: number to square
        :type x: int
        :returns: new Task with square of number
        :rtype: Task[int]
        """

        def fork(_, resolve):
            resolve(x ** 2)


# Generated at 2022-06-12 05:45:23.715098
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2).map(lambda x: x**2)
    assert task.fork(lambda reject: reject, lambda resolve: resolve) == 4


# Generated at 2022-06-12 05:45:29.422703
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    called = False

    def _(reject, resolve):
        nonlocal called
        called = True
        resolve(2)

    a = Task(_)
    b = a.map(lambda x: x + 2)
    assert b.fork(None, None) == 4
    assert called



# Generated at 2022-06-12 05:45:33.110406
# Unit test for method bind of class Task
def test_Task_bind():
    def add(value):
        return Task.of(value + 1)

    assert Task(lambda _, resolve: resolve(2)).bind(add).fork(None, lambda value: value) == 3


# Generated at 2022-06-12 05:45:44.768042
# Unit test for method map of class Task
def test_Task_map():
    """
    Set up async environment for testing async code.
    """
    loop = asyncio.get_event_loop()
    loop.run_until_complete(async_Task_map())
    loop.close()


async def async_Task_map():
    """
    Async function for testing async code.
    """
    # Test data
    success_promise_data = 4
    callback_success_data = 'Success'
    callback_error_data = 'Error'

    # Task with resolve call
    success_promise = Task(lambda reject, resolve: resolve(success_promise_data))
    success_callback = Task.of(callback_success_data)
    error_callback = Task.reject(callback_error_data)

    # Check result data and task type
    assert await async_task_map_result

# Generated at 2022-06-12 05:45:49.483329
# Unit test for method map of class Task
def test_Task_map():
    """
    Call method map of Task with 3 functions and assert rightness of result.
    """
    task = Task.of(42)
    task_after_map = task.map(lambda val: val + 1)
    (err, val) = task_after_map.fork(lambda err: err, lambda val: val)
    assert val == 43

    def foo(arg):
        return Task.reject(arg)

    (err, val) = task_after_map.fork(lambda err: err, lambda val: foo(val))
    assert err == 43
