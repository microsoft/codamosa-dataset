

# Generated at 2022-06-12 05:36:11.775075
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)).map(lambda x: x * 2).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 2


# Generated at 2022-06-12 05:36:19.506037
# Unit test for method bind of class Task
def test_Task_bind():
    def add1(x):
        return x + 1
    def mul3(x):
        return x * 3

    Task.of(3) \
        .bind(lambda x: Task.of(add1(x))) \
        .bind(lambda x: Task.of(mul3(x))) \
        .fork(print, print)

    assert Task.of(3) \
        .bind(lambda x: Task.of(add1(x))) \
        .bind(lambda x: Task.of(mul3(x))) \
        .fork(print, print) == 12


# Generated at 2022-06-12 05:36:29.756703
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(resolve, reject):
        def callback(value):
            if value == 1:
                resolve(2)
            elif value == 2:
                reject(3)
            else:
                raise TypeError()

        return callback

    task = Task(fn)
    expected_resolved = Task.of(2)
    expected_rejected = Task.reject(3)
    assert task.bind(Task.of).fork(lambda x: None, lambda x: None) == None
    assert task.bind(Task.reject).fork(_, lambda x: None) == None
    assert task.bind(Task.of).fork(lambda x: None, lambda x: None) == expected_resolved.fork(lambda x: None, lambda x: None)

# Generated at 2022-06-12 05:36:32.413317
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(8).map(lambda x: x * 2)
    assert result.fork(lambda x: 'error', lambda x: x) == 16

# Generated at 2022-06-12 05:36:40.994559
# Unit test for method map of class Task
def test_Task_map():
    # Positive test
    task = Task.of(5).map(lambda arg: arg + 7)
    reject, resolve = task.fork(f=None, s=None)
    assert resolve(8) == 13

    # Negative test
    task = Task.of(5).map(lambda arg: arg + 7)
    reject, resolve = task.fork(f=None, s=None)
    assert reject(8) == 8


# Generated at 2022-06-12 05:36:47.772246
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map should return Task with resolve, which
    mapped with given function.
    """
    def mapper(x):
        return x**2

    task_a = Task(lambda _, resolve: resolve(2))
    task_b = Task(lambda _, resolve: resolve(3))
    task_c = Task(lambda _, resolve: resolve(4))
    task_d = task_a.map(mapper)

    assert task_d.fork(_, resolve) == task_b.fork(_, resolve)
    assert task_d.fork(_, resolve) == task_c.fork(_, resolve)


# Generated at 2022-06-12 05:36:52.041299
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.map with of method
    """
    assert Task("42").bind(lambda x: Task.of(str(x))).fork(None, lambda x: x) == "42"


# Generated at 2022-06-12 05:36:56.536476
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test case for method bind of class Task

    :returns: check result of test
    :rtype: bool
    """
    def resolve(x):
        return Task.of(x + 3)

    return Task.of(7).bind(resolve).fork(None, lambda x: x) == 10

# Generated at 2022-06-12 05:37:00.096081
# Unit test for method map of class Task
def test_Task_map():
    value = 10
    mapped = 15
    result = Task.of(value).map(lambda arg: arg + mapped)
    assert result.fork(lambda arg: arg, lambda arg: arg) == 15


# Generated at 2022-06-12 05:37:07.223870
# Unit test for method bind of class Task
def test_Task_bind():
    def f(value):
        def fork(rej, res):
            res(value + 2)

        return Task(fork)

    def fork(rej, res):
        res(2)

    task = Task(fork)


# Generated at 2022-06-12 05:37:13.960205
# Unit test for method map of class Task
def test_Task_map():
    def add_3(v):
        return v + 3

    def success(v):
        assert v == 4

    def fail(v):
        assert v == 5

    t = Task.of(1).map(add_3).fork(fail, success)


# Generated at 2022-06-12 05:37:19.012317
# Unit test for method bind of class Task
def test_Task_bind():
    from monad import Task

    @Task
    def f():
            return 1

    @Task
    def g():
        return 2

    def h():
        return 3

    def test_func(resolve):
        def callback(result):
            assert result == 3

        return f().bind(g).bind(h).fork(lambda _: None, callback)

    test_func(lambda x: x)

# Generated at 2022-06-12 05:37:23.297235
# Unit test for method map of class Task
def test_Task_map():
    def get(value):
        def fork(_, resolve):
            resolve(value)

        return Task(fork)

    assert get(1).map(lambda value: value + 1).fork(None, lambda _: True) == True


# Generated at 2022-06-12 05:37:27.685931
# Unit test for method bind of class Task
def test_Task_bind():
    def wrong_fn(_):
        assert False

    def right_fn(_):
        return Task.of(0)

    Task.reject(None).bind(wrong_fn)
    Task.reject(None).bind(wrong_fn)


"""
============================================================
    Implementation of class Maybe
============================================================
"""


# Generated at 2022-06-12 05:37:34.895540
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind
    """
    def fn(_):
        return Task.of(1)

    assert Task.of(1).bind(fn).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1

    def fn(_):
        return Task.reject(1)

    assert Task.of(1).bind(fn).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1


# Generated at 2022-06-12 05:37:40.835593
# Unit test for method map of class Task
def test_Task_map():
    def inc(arg): return arg + 1

    def task_fork(reject, resolve): return reject(1)

    task = Task(task_fork)
    task_after_map = task.map(inc)

    assert task_after_map.fork(lambda arg: arg, lambda arg: 0) == 1
    assert task.fork(lambda arg: arg, lambda arg: 0) == 1



# Generated at 2022-06-12 05:37:44.480083
# Unit test for method bind of class Task
def test_Task_bind():
    def f(v):
        return Task.of(v + 1)

    def g(v):
        return Task.of(v + 2)

    assert Task.of(0).bind(f).bind(g).fork(
        lambda x: 0,
        lambda x: 1
    ) == 3



# Generated at 2022-06-12 05:37:56.062873
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        if value == 4:
            raise Exception('value 4')
        return Task.of(value * 2) if value <= 0 else Task.of(Task.of(value * 2))

    assert Task.of(0).bind(mapper).fork(lambda _: None, lambda b: b == 1)
    assert Task.of(1).bind(mapper).fork(lambda _: None, lambda b: b == 4)
    assert Task.of(2).bind(mapper).fork(lambda _: None, lambda b: b == 8)
    try:
        Task.of(-1).bind(mapper).fork(lambda a: False, lambda _: None)
    except:
        assert True


# Generated at 2022-06-12 05:37:59.368208
# Unit test for method bind of class Task
def test_Task_bind():
    def _check(fn, arg, result):
        task = Task.of(arg)
        return equals(task.bind(fn), Task.of(result))

    return _check(lambda x: Task.of(x + 1), 0, 1)



# Generated at 2022-06-12 05:38:11.483768
# Unit test for method bind of class Task
def test_Task_bind():
    """
    If a function returns a Promise, the next function in the chain will
    wrap itself around the promise, and so on.
    """
    def fetch_user(id):
        if id == -1:
            return Task.reject('error')

        return Task.of({
            'name': 'Max Mustermann',
            'email': 'max@mustermann.de',
            'likes': ['Reading', 'Python']
        })

    def valid_email(user):
        if '@' not in user['email']:
            return Task.reject('invalid email')

        return Task.of(user)

    def render_email(user):
        return Task.of('<html><body>Hello {{name}}, welcome to our website!')


# Generated at 2022-06-12 05:38:24.970600
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one_by_one(a, b):
        return Task.of(a + b)

    def task_of_five():
        return Task.of(5)

    def task_of_three():
        return Task.of(3)

    def task_of_two():
        return Task.of(2)

    assert task_of_five() \
        .bind(lambda arg: task_of_three()) \
        .bind(lambda arg: task_of_two()) == Task.of(10)
    assert task_of_five() \
        .bind(lambda arg: task_of_three()) \
        .bind(lambda arg: task_of_two() \
        .map(lambda arg: arg + 10)) == Task.of(20)

# Generated at 2022-06-12 05:38:28.231579
# Unit test for method map of class Task
def test_Task_map():
    assert (
        Task.of(1)
        .map(lambda x: x + 1)
        .fork(lambda x: x, lambda x: x)
    ) == 2


# Generated at 2022-06-12 05:38:33.133036
# Unit test for method bind of class Task
def test_Task_bind():
    def sum(a, b):
        return a + b

    def sum_lazy(x):
        return Task.of(sum(2, 3))

    def lazy_task_test(reject, resolve):
        return sum_lazy(5).fork(reject, resolve)

    task = Task(lazy_task_test)

    assert task.fork(lambda x: x, lambda x: x) == 5



# Generated at 2022-06-12 05:38:36.761734
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x * x).fork(
        lambda _: False,
        lambda y: y == 4
    )


# Generated at 2022-06-12 05:38:39.052082
# Unit test for method bind of class Task
def test_Task_bind():
    # Define test case
    def test(value):
        return Task.reject(value)

    # Run test
    result = Task.of(2).bind(test)
    result.fork(print, print)

# Generated at 2022-06-12 05:38:50.394712
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        print('I resolve:', value)
        return value

    def reject(value):
        print('I reject:', value)
        return value

    # Create Task instance which store function that print resolve value
    task = Task.of(resolve)
    print(task.fork(reject, resolve)) # resolve

    # We can create example of Task which store everything
    task = Task.of(1)
    print(task.fork(reject, resolve)) # 1
    task = Task.of(2)
    print(task.fork(reject, resolve)) # 2

    # We can create example of Task which store everything
    def add1(value):
        return Task.of(value + 1)

    print(task.bind(add1).fork(reject, resolve)) # 3

# Generated at 2022-06-12 05:38:57.340687
# Unit test for method map of class Task
def test_Task_map():
    def test_of_map():
        task = Task.of(1)
        assert task.map(lambda arg: arg + 1).fork(lambda x: None, lambda x: x) == 2

    def test_reject_map():
        task = Task.reject(1)
        assert task.map(lambda arg: arg + 1).fork(lambda x: x, lambda x: None) == 1

    test_of_map()
    test_reject_map()

# Generated at 2022-06-12 05:39:09.206518
# Unit test for method bind of class Task
def test_Task_bind():
    """
    test Task.bind
    """
    def raise_error(*_):
        raise Exception("test error")
    def return_ok(value):
        return value

    assert Task(lambda reject, resolve: resolve(1)).bind(
        lambda value: Task(lambda _, resolve: resolve(value + 1))
    ).fork(raise_error, return_ok) == 2
    assert Task(lambda reject, resolve: resolve(1)).bind(
        lambda _: Task(lambda _, resolve: resolve(2))
    ).fork(raise_error, return_ok) == 2
    assert Task(lambda reject, resolve: resolve(1)).bind(
        lambda _: Task(lambda reject, _: reject(3))
    ).fork(return_ok, raise_error) == 3
    assert Task(lambda reject, resolve: reject(1)).bind

# Generated at 2022-06-12 05:39:20.755989
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task_bind method

    test_Task_bind: Task[A] -> (Any -> Task[B]) -> Task[B]
    """
    def add1(value):
        """
        Increment value by 1

        :param value: value to increment
        :type value: Number
        :returns: number with incremented value by 1
        :rtype: Task[Number]
        """
        return Task.of(value + 1)

    def add2(value):
        """
        Increment value by 2

        :param value: value to increment
        :type value: Number
        :returns: number with incremented value by 2
        :rtype: Task[Number]
        """
        return Task.of(value + 2)


# Generated at 2022-06-12 05:39:28.347359
# Unit test for method map of class Task
def test_Task_map():
    def resolve(result):
        assert result == 2

    def reject(result):
        assert False, 'rejected'

    fork = lambda reject, resolve: resolve(1)
    Task(fork).map(lambda x: x + 1).fork(reject, resolve)

    fork2 = lambda reject, resolve: reject('Error')
    Task(fork2).map(lambda x: x + 1).fork(reject, resolve)


# Generated at 2022-06-12 05:39:38.317892
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + '!'

    def reject(value):
        assert value == '404'

    def resolve(value):
        assert value == 'success!'

    task = Task.reject('404')
    assert task.fork == task.fork

    task = task.map(fn)
    assert task.fork == task.map(fn).fork

    task.fork(reject, resolve)

    task2 = Task.of('success')
    assert task2.fork == task2.fork
    assert task2.map(fn).fork == task2.map(fn).fork

    task2.map(fn).fork(reject, resolve)

    assert task2.map(fn).fork == task2.map(fn).fork


# Generated at 2022-06-12 05:39:48.770617
# Unit test for method map of class Task
def test_Task_map():
    count = 0

    def task_map_test(count):
        count += 1
        return Task.of(count)

    start_time = time()
    task = Task.of(0)
    task = task.map(lambda x: x + 1)
    task = task.map(lambda x: x + 3)
    task = task.map(lambda x: x * 3)
    task = task.map(lambda x: x ** 2)
    task = task.map(lambda x: x + 1)
    task = task.map(lambda x: x ** 2)
    task = task.map(lambda x: x + 1)
    task.fork(lambda _: _, lambda y: y)
    end_time = time() - start_time
    print(end_time)
    assert end_time > 0

    start

# Generated at 2022-06-12 05:39:53.365006
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task(lambda reject, resolve: resolve([1, 2, 3]))
    bind_task = task.bind(lambda arg: Task.of(arg + [4]))
    assert bind_task.fork(lambda arg: arg, lambda arg: arg) == [1, 2, 3, 4]


# Generated at 2022-06-12 05:39:58.210565
# Unit test for method map of class Task
def test_Task_map():
    value = 1
    mapped_value = 3
    task = Task.of(value)
    task_map = task.map(lambda arg: mapped_value)

    assert callable(task_map.fork)
    assert task.fork(lambda arg: arg, lambda arg: arg) == value
    assert task_map.fork(lambda arg: arg, lambda arg: arg) == mapped_value


# Generated at 2022-06-12 05:40:08.257622
# Unit test for method map of class Task
def test_Task_map():
    """
    Test case for method map of class Task

    :returns: Nothing
    :rtype: None
    """

    # Test 1
    # Test case for mapping to integer value
    task = Task(lambda _, resolve: resolve(123))
    result = task.map(int)
    def fork(reject, resolve):
        resolve(123)  # Store expected result value
    assert result.fork == fork

    # Test 2
    # Test case for mapping to float value
    task = Task(lambda _, resolve: resolve(123))
    result = task.map(float)
    def fork(reject, resolve):
        resolve(123.0)  # Store expected result value
    assert result.fork == fork

    # Test 3
    # Test case for mapping to string value

# Generated at 2022-06-12 05:40:14.499188
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map behavior.
    """
    def plus_one_mapper(value):
        return value + 1

    def reject(value):
        assert value == "error"

    def resolve(value):
        assert value == 2

    task_instance = Task(lambda reject, resolve: resolve(1))
    Task(task_instance.map(plus_one_mapper).fork(reject, resolve))


# Generated at 2022-06-12 05:40:24.030962
# Unit test for method bind of class Task
def test_Task_bind():
    def assertEquals(exp, act):
        assert exp == act

    # assertEquals(
    #     Task.of(1).bind(
    #         lambda a: Task.of(a * 2).bind(
    #             lambda b: Task.of(b + 3)
    #         )
    #     ).fork(
    #         lambda e: 'reject',
    #         lambda v: v
    #     ),
    #     5
    # )

    # assertEquals(
    #     Task.of(1).bind(
    #         lambda a: Task.reject(a).bind(
    #             lambda b: Task.of(b + 3)
    #         )
    #     ).fork(
    #         lambda e: 'reject',
    #         lambda v: v
    #     ),


# Generated at 2022-06-12 05:40:26.541886
# Unit test for method bind of class Task
def test_Task_bind():
    def task(_, resolve):
        resolve(42)
    assert Task(task).bind(lambda arg: Task.of(arg * 2)).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 84


# Generated at 2022-06-12 05:40:36.767849
# Unit test for method map of class Task
def test_Task_map():
    def f1(x):
        return x + 1

    def f2(x):
        return x ** 2

    def f3(x):
        return x * 2

    def f4(x):
        return x * 3


# Generated at 2022-06-12 05:40:46.250729
# Unit test for method map of class Task
def test_Task_map():
    """
    Map function of Task should map resolve attribute of Task.
    """
    def add2(x):
        return x + 2

    def divBy2(x):
        return x // 2

    def divBy3(x):
        return x // 3

    def sub3(x):
        return x - 3

    def subBy2(x):
        return x - 2

    def subBy3(x):
        return x - 3


# Generated at 2022-06-12 05:40:57.202385
# Unit test for method map of class Task
def test_Task_map():
    def function(x):
        return x * x

    @test.capture_output
    def example_Test_map():
        Task.of(2).map(function).fork(lambda x: print(f"rejected {x}"), lambda x: print(f"resolved {x}"))

    result, output = test.get_output(example_Test_map)
    assert result == ''
    assert output == 'resolved 4\n'


# Generated at 2022-06-12 05:41:04.191836
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    :return: void
    """
    def add_two_fork(reject, resolve):
        time.sleep(1)
        resolve(2)

    def add_three_fork(reject, resolve):
        time.sleep(1)
        resolve(3)

    def add_two(n):
        return Task(add_two_fork)

    def add_three(n):
        return Task(add_three_fork)

    assert Task(add_two_fork).bind(add_two).fork(
        lambda err: print(err),
        lambda res: print(res)
    ) == None


# Generated at 2022-06-12 05:41:10.529915
# Unit test for method bind of class Task
def test_Task_bind():
    # Initial data
    func = lambda a: Task.of(a + 1)
    res = Task.of(1).bind(func)

    def test_reject(reject):
        assert reject == None, "Task not rejected"

    def test_resolve(resolve):
        assert resolve == 2, "Bind function not working"

    res.fork(test_reject, test_resolve)



# Generated at 2022-06-12 05:41:12.445225
# Unit test for method map of class Task
def test_Task_map():
    def test_fn(value):
        return value * 5

    task = Task.of(2)
    assert task.map(test_fn).fork(
        lambda _: None,
        lambda value: value == 10
    )



# Generated at 2022-06-12 05:41:16.835033
# Unit test for method map of class Task
def test_Task_map():
    def fn(v): return v * 2
    def reject(v): return v
    def resolve(v): return v * 3

    task = Task(lambda reject, resolve: resolve(2))
    task_ = task.map(fn)

    assert 2 * 3 == task_.fork(reject, resolve)


# Generated at 2022-06-12 05:41:21.504276
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of('hello, world')
    task = task.map(lambda value: len(value))
    assert task.fork(lambda reason: None, lambda value: value) == 12


# Generated at 2022-06-12 05:41:24.765434
# Unit test for method map of class Task
def test_Task_map():
    increment = lambda x: x + 1
    t = Task(lambda _, resolve: resolve(1))
    u = t.map(increment)
    assert u.fork(lambda e: e, lambda x: x) == 2


# Generated at 2022-06-12 05:41:28.498886
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1) \
        .map(lambda value: value + 1) \
        .fork(lambda value: value, lambda value: value) == 2


# Generated at 2022-06-12 05:41:33.206883
# Unit test for method bind of class Task
def test_Task_bind():
    def execute(reject, resolve):
        arg = random.random()
        return Task.reject(arg).map(lambda x: x * 2).bind(lambda x: resolve(x)).fork(lambda x: x, lambda x: x)

    assert execute(reject, resolve) == reject


# Generated at 2022-06-12 05:41:38.029217
# Unit test for method map of class Task
def test_Task_map():
    def add1(number):
        return number + 1

    def double(number):
        return number * 2

    task = Task.of(5)
    expect(task.map(add1)).to.be(Task.of(6))
    expect(task.map(double)).to.be(Task.of(10))



# Generated at 2022-06-12 05:41:49.524254
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Bind method should return new Task and
    when resolve(5) -> resolve(7)
    clamp should return rejected with 10.
    """

    def clamp(value):
        if value < 10:
            return Task.reject(value + 5)
        return Task.of(value + 7)

    def fork(reject, resolve):
        return resolve(6)

    def rejected_fork(reject, resolve):
        return reject(-1)

    task = Task(fork)
    assert task.bind(clamp).fork(
        lambda res: assert_that(res, equal_to(11)),
        lambda res: assert_that(res, equal_to(13))
    )

    task1 = Task(rejected_fork)

# Generated at 2022-06-12 05:41:55.120696
# Unit test for method bind of class Task
def test_Task_bind():
    f = Task.of(1).bind(lambda x: Task.reject(x + 1))
    assert f.fork(lambda x: x, lambda x: 'Error') == 2

    f = Task.reject(1).bind(lambda x: Task.of(x + 1))
    assert f.fork(lambda x: x, lambda x: 'Error') == 1


# Generated at 2022-06-12 05:41:57.466642
# Unit test for method map of class Task
def test_Task_map():
    a = Task.of("hi")
    b = a.map(lambda x: [x])

    assert("hi" == b.fork(None, lambda x: x)[0])


# Generated at 2022-06-12 05:42:01.892785
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(42).bind(lambda x: Task.of(x * 2)) == Task.of(84)
    # assert Task.reject(42).bind(lambda x: Task.reject(x * 2)) == Task.of(None)
    # assert Task.of(lambda: 1 / 0).bind() == Task.reject(ZeroDivisionError('division by zero'))

# Generated at 2022-06-12 05:42:10.525412
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda _, resolve: resolve(21)).bind(
        lambda value: Task.of(value * 2)
    ).fork(lambda x: x, lambda x: x) == 42

    assert Task(lambda _, resolve: resolve(21)).bind(
        lambda value: Task.of(value * 2)
    ).fork(lambda x: x, lambda x: x) != 0

    assert Task(lambda reject, _: reject(21)).bind(
        lambda value: Task.of(value * 2)
    ).fork(lambda x: x, lambda x: x) == 21

    def div(value):
        if value == 0:
            return Task.reject(ZeroDivisionError('Division by zero'))

        return Task.of(16 / value)


# Generated at 2022-06-12 05:42:13.257775
# Unit test for method map of class Task
def test_Task_map():
    def task(reject, resolve):
        reject(0)

    result = Task(task).map(lambda arg: arg + 1)

    assert result.fork(lambda arg: arg, lambda arg: False) == 0


# Generated at 2022-06-12 05:42:16.153752
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x * 2).fork(
        lambda arg: arg + 1,
        lambda arg: arg - 1
    ) == 4

# ==================
# Promise (polyfill)
# ==================

# Generated at 2022-06-12 05:42:19.208367
# Unit test for method map of class Task
def test_Task_map():
    test_result = Task(lambda _, resolve: resolve(1)) \
        .map(lambda arg: arg + 1) \
        .map(lambda arg: arg * 2) \
        .fork(None, lambda x: x)

    assert 4 == test_result


# Generated at 2022-06-12 05:42:24.150606
# Unit test for method bind of class Task
def test_Task_bind():
    def plus_one(value):
        return Task.of(value + 1)

    def fail(value):
        return Task.of(value).bind(lambda result: Task.reject(result))

    assert Task.of(1).bind(plus_one).fork(lambda result: result, lambda result: result) == 2

    assert Task.reject(1).bind(fail).fork(lambda result: result, lambda result: result) == 1

# Generated at 2022-06-12 05:42:32.363524
# Unit test for method bind of class Task
def test_Task_bind():
    def say_hello(name):
        return Task.of("Hello " + name)

    def say_goodbye(name):
        return Task.of("Goodbye " + name)

    def assert_equals(expect, actual):
        assert expect == actual

    task = Task.of("World")

    task \
        .bind(say_hello) \
        .bind(say_goodbye) \
        .fork(
            lambda value: assert_equals("Goodbye Hello World", value),
            lambda value: assert_equals(None, value)
        )


# Generated at 2022-06-12 05:42:48.258357
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    @assert_equals
    def _(task):
        return task.bind(fn).fork(lambda _: 0, lambda v: v)

    yield _(Task.of(1)), 2


# Generated at 2022-06-12 05:42:56.126058
# Unit test for method map of class Task
def test_Task_map():
    def record(value):
        return { 'result': value }

    def record_mapper(value):
        return Task.of(record(value))

    def record_mapper_2(value):
        return Task.of(record(value + '_2'))

    assert Task.reject(1).map(record_mapper) == Task.reject(1)
    assert Task.of(1).map(record_mapper) == Task.of(record(1))
    assert Task.of(1).map(record_mapper).map(record_mapper_2) == Task.of(record(1)).map(record_mapper_2)


# Generated at 2022-06-12 05:43:01.287507
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task.
    """
    value = 5
    task = Task.of(value)
    task = task.map(lambda x: x * 2)

    assert task.fork(
        lambda x: False,
        lambda x: x == value * 2
    )


# Generated at 2022-06-12 05:43:04.752566
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Bind work as expected.
    """
    def func(arg):
        return Task.of(str(arg))

    print(Task.of(1).bind(func).fork(print, print))


# Generated at 2022-06-12 05:43:11.677152
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return value + 1

    def mul_two(value):
        return Task.of(value * 2)

    def throw_err(value):
        return Task.reject('Error')

    task = Task.of(1)
    assert task.bind(add_one).bind(mul_two).fork(lambda _: False, lambda v: v == 4)

    task = Task.of(1)
    assert task.bind(add_one).bind(throw_err).fork(lambda v: v == "Error", lambda _: True)


# Generated at 2022-06-12 05:43:14.630355
# Unit test for method map of class Task
def test_Task_map():
    def increase_by_two(value):
        return value + 2

    assert Task.of(2).map(increase_by_two).fork(lambda arg: arg, lambda arg: arg) == 4
    assert Task.reject(2).map(increase_by_two).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-12 05:43:24.887997
# Unit test for method bind of class Task
def test_Task_bind():
    def async_task(reject, resolve):
        """
        Emulate async task.

        :param reject: function to handle reject
        :type reject: Function(error) -> Any
        :param resolve: function to handle resolve
        :type resolve: Function(value) -> Any
        """
        time.sleep(0.001)
        resolve(1000)

    def async_task_error(reject, resolve):
        """
        Emulate async task with error handling.

        :param reject: function to handle reject
        :type reject: Function(error) -> Any
        :param resolve: function to handle resolve
        :type resolve: Function(value) -> Any
        """
        time.sleep(0.001)
        reject(1000)


# Generated at 2022-06-12 05:43:30.740387
# Unit test for method map of class Task
def test_Task_map():
    """
    Call map method of Task class.
    """
    a = 1
    b = 2
    fn = lambda x: x + 1
    def fork(reject, resolve):
        resolve(a)
    task = Task(fork)
    assert task.map(fn).fork(
        lambda x: None,
        lambda x: x
    ) == b


# Generated at 2022-06-12 05:43:35.297505
# Unit test for method bind of class Task
def test_Task_bind():
    div = lambda x, y: Task.of(x / y)
    get_one_half = lambda x: div(x, 2)

    result = Task.of(6).bind(get_one_half).fork(
        lambda e: e,
        lambda r: r
    )

    assert result == 3



# Generated at 2022-06-12 05:43:44.833658
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return value

    def reject(value):
        return value

    def _(arg, resolve):
        return resolve(arg)

    def _add_one(value):
        return value + 1

    def _add_one_and_reject(value):
        return Task.reject(_add_one(value))

    assert Task(_, resolve).map(_add_one)(reject, resolve) is resolve(1)
    assert Task(_, resolve).map(_add_one).map(_add_one)(reject, resolve) is resolve(2)
    assert Task(_add_one, resolve).map(_add_one).map(_add_one)(reject, resolve) is resolve(3)

# Generated at 2022-06-12 05:44:18.648446
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda reject, resolve: resolve(1))
    assert task.fork(lambda reject, resolve: reject(1), lambda arg: arg) == 1

    mapped_task = task.map(lambda arg: arg + 1)
    assert mapped_task.fork(lambda reject, resolve: reject(1), lambda arg: arg) == 2

# Generated at 2022-06-12 05:44:29.442236
# Unit test for method bind of class Task
def test_Task_bind():
    def wait(value, latency, callback):
        sleep(latency)
        callback(value)

    def sleep(secs):
        time.sleep(secs)

    def print_and_double(x):
        print('Result from print_and_double: ', x)
        return x * 2

    def add_one(x):
        print('Result from add_one: ', x + 1)
        return Task.of(x + 1)

    def lazy_result(value):
        print('Lazy result called with value: ', value)
        return value

    task = Task(lambda _, resolve: wait(5, 1, resolve)).bind(print_and_double).bind(
        add_one).map(lazy_result)
    assert task.fork(lambda x: x, lambda x: x) == 6

# Unit

# Generated at 2022-06-12 05:44:36.020027
# Unit test for method map of class Task
def test_Task_map():
    def add_one_and_square(value):
        return value + 1

    def get_task_with_one():
        return Task.of(1)

    def get_task_with_two():
        return Task.of(2)

    assert Task.of(1).map(add_one_and_square).fork(None, lambda value: value) == 4
    assert Task.reject(1).map(add_one_and_square).fork(lambda value: value, None) == 1
    assert get_task_with_one().bind(get_task_with_two).fork(None, lambda value: value) == 2


# Generated at 2022-06-12 05:44:43.586283
# Unit test for method map of class Task
def test_Task_map():
    def thrice(x):
        return x * 3

    # case Task[rejected, task]: map call,
    # but reject called before resolve
    assert Task(lambda reject, _: reject(3)).map(thrice).fork(
        lambda reason: reason,
        lambda _: False
    ) is True

    # case Task[resolved, task]: map call,
    # but resolve called before reject
    assert Task(lambda _, resolve: resolve(3)).map(thrice).fork(
        lambda _: False,
        lambda value: value
    ) == 9


# Generated at 2022-06-12 05:44:48.994862
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda value: value + 1).fork(
        lambda reject: None,
        lambda resolve: resolve
    ) == 2

    assert Task.reject(1).map(lambda value: value + 1).fork(
        lambda reject: reject,
        lambda resolve: None
    ) == 1


# Generated at 2022-06-12 05:44:57.677624
# Unit test for method map of class Task
def test_Task_map():
    from unittest import TestCase, main

    class Test(TestCase):
        def test_resolve_map(self):
            result = Task.of(8).map(lambda x: x + 1)
            assert 9 == result.fork(
                lambda arg: arg,
                lambda arg: arg
            )

        def test_resolve_reject(self):
            result = Task.reject(8).map(lambda x: x + 1)
            assert 8 == result.fork(
                lambda arg: arg,
                lambda arg: arg
            )

        def test_nested_resolve_map(self):
            result = Task.of(8).map(lambda x: x + 1).map(lambda x: x * 2)

# Generated at 2022-06-12 05:44:58.983203
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda value: value ** 2)
    assert task.fork(None, None) == 1 ** 2


# Generated at 2022-06-12 05:45:03.582966
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of("value")
    task_mapped = task.map(lambda value: value + "_mapped")

    # fork must give us "value_mapped"
    assert_equals("value_mapped", task_mapped.fork(lambda _: 0, lambda value: value))


# Generated at 2022-06-12 05:45:08.826701
# Unit test for method map of class Task
def test_Task_map():
    def resolve_fn(arg): return arg + 1
    def fork_fn(reject, resolve): resolve(1)
    task = Task(fork_fn)
    new_task = task.map(resolve_fn)

    assert new_task.fork(lambda x: x + 2, lambda x: x + 3) == 4


# Generated at 2022-06-12 05:45:10.656581
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda arg: arg + 1)

    assert task.fork(lambda arg: arg, lambda arg: arg) == 2
