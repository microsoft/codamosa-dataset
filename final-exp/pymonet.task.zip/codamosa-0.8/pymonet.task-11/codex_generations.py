

# Generated at 2022-06-12 05:36:10.722196
# Unit test for method bind of class Task
def test_Task_bind():
    """Test method bind of class Task"""
    def plus(a, b):
        return a + b

    def plus3(value):
        return Task.of(value) \
            .map(lambda arg: plus(arg, 3))

    assert Task.of(6) \
        .bind(plus3) \
        .fork(lambda _: 'Error', lambda arg: arg) == 9


# Generated at 2022-06-12 05:36:15.329204
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda a: a + 2).fork(lambda x: x, lambda x: x) == 3
    assert Task.reject(1).map(lambda a: a + 2).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-12 05:36:20.297330
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(_, resolve):
        return resolve(10)

    task = Task.of(10)
    task = task.bind(lambda t: Task.of(t + 10))
    assert task.fork(None, lambda t: t) == 20

    task = Task.reject(10)
    task = task.bind(lambda t: Task.of(t + 10))
    assert task.fork(lambda t: t, None) == 10


# Generated at 2022-06-12 05:36:26.811098
# Unit test for method map of class Task
def test_Task_map():
    @Task.of(8)
    def task_a():
        return task_a

    @task_a.map(lambda x: x * x)
    def task_b(value):
        assert value == 64

        @task_b.map(lambda x: x + 1)
        def task_c(value):
            assert value == 65

    task_a.fork(lambda x: x, lambda x: x)

# Generated at 2022-06-12 05:36:30.783380
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(arg):
        return Task.of(2 * arg)

    assert Task.of(1).bind(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-12 05:36:35.109052
# Unit test for method map of class Task
def test_Task_map():
    def fn_int(v):
        return int(v)

    def fn_plus_one(v):
        return v + 1

    assert Task.of('1').map(fn_int).map(fn_plus_one).fork(lambda _: None, lambda x: x)() == 2


# Generated at 2022-06-12 05:36:46.307278
# Unit test for method bind of class Task
def test_Task_bind():
    # test for function which return resolved task
    def f_resolve(arg):
        return Task.of(arg)

    # test for function which return rejected task
    def f_reject(arg):
        return Task.reject(arg)

    # create resolved task
    task = Task.of(123).bind(f_resolve)
    assert task.fork(lambda reject: reject(1), lambda resolve: resolve(0)) == 0
    assert task.fork(lambda reject: resolve(0), lambda resolve: reject(1)) == 0

    # create rejected task
    task = Task.of(123).bind(f_reject)
    assert task.fork(lambda reject: resolve(0), lambda resolve: reject(1)) == 1
    assert task.fork(lambda reject: reject(1), lambda resolve: resolve(0)) == 1


#

# Generated at 2022-06-12 05:36:48.516253
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(5)).map(lambda arg: arg + 1).fork(lambda _: None, lambda arg: arg) == 6

# Generated at 2022-06-12 05:37:00.930671
# Unit test for method map of class Task
def test_Task_map():
    def resolve(x):
        return x

    def reject(x):
        return x

    def multiply(x):
        return 2 * x

    def add(x):
        return x + 10

    def odd(x):
        return x % 2 == 1

    assert Task([1, 2, 3]).map(add).map(multiply).fork(reject, resolve) == [32, 36, 40]
    assert Task(1).map(add).map(multiply).fork(reject, resolve) == 22
    assert Task(None).map(add).map(multiply).fork(reject, resolve) == 12
    assert Task(1).map(add).fork(reject, resolve) == 11

# Generated at 2022-06-12 05:37:06.349343
# Unit test for method map of class Task
def test_Task_map():
    """
    Add 2 to number and compare with expected value.
    """
    def mapper(value):
        return value + 2

    assert Task(lambda _, resolve: resolve(3)).map(mapper).fork(
        lambda _: False,
        lambda arg: arg is 5
    )


# Generated at 2022-06-12 05:37:18.857928
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(x):
        return Task.of(x + 1)

    def double(x):
        return Task.of(x + x)

    def is_even(x):
        return x % 2 == 0

    def add_three(arr):
        return Task.of(arr + [3])

    def test_Task_add_one_and_double_and_add_three():
        return Task.of(1).bind(add_one).bind(double).bind(add_three)

    assert test_Task_add_one_and_double_and_add_three().fork(
        lambda error: error,
        lambda value: value == [3, 4]
    )


# Generated at 2022-06-12 05:37:25.586852
# Unit test for method map of class Task
def test_Task_map():
    # Setup
    task = Task.of('result')

    # Exercise & verify
    assert 'result' == task.fork(lambda _: 'reject', lambda value: value)

    # Setup
    task = task.map(lambda value: value + ' mapped')

    # Exercise & verify
    assert 'result mapped' == task.fork(lambda _: 'reject', lambda value: value)


# Generated at 2022-06-12 05:37:28.967051
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    assert task.map(lambda arg: arg ** 2).fork(
        lambda arg: "error",
        lambda arg: arg
    ) == 4


# Generated at 2022-06-12 05:37:40.333320
# Unit test for method bind of class Task
def test_Task_bind():
    def add1(x):
        return x + 1

    def add2(x):
        return x + 2

    assert Task.of(2).bind(Task.of).fork(lambda x: 0, add1) == 3

    assert Task.of(2).bind(lambda x: Task.of(3).bind(lambda y: Task.of(x + y))).fork(lambda x: 0, add1) == 6

    assert Task.reject(2).bind(lambda x: Task.of(3).bind(lambda y: Task.of(x + y))).fork(add1, lambda x: 0) == 3

    assert Task.of(2).bind(lambda x: Task.reject(x + 2)).fork(add1, lambda x: 0) == 4


# Generated at 2022-06-12 05:37:46.267983
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test that Task.bind is valid.
    """
    def increment_number(number):
        return Task.of(number + 1)

    t0 = Task.of(42)
    t1 = t0.bind(increment_number)
    t2 = t1.bind(increment_number)
    t3 = t2.bind(increment_number)

    assert t0.fork(lambda _: None, lambda v: v) == 42
    assert t3.fork(lambda _: None, lambda v: v) == 45



# Generated at 2022-06-12 05:37:52.842468
# Unit test for method map of class Task
def test_Task_map():
    value = 0
    result = Task.of(value)

    # Test with valid operation
    assert result.map(lambda x: x + 1).fork(lambda x: None, lambda x: x) == (value + 1)

    # Test with illegal operation
    with pytest.raises(ZeroDivisionError):
        result.map(lambda x: 1 / 0).fork(lambda x: None, lambda x: None)


# Generated at 2022-06-12 05:37:55.920343
# Unit test for method map of class Task
def test_Task_map():
    fn = lambda x: x + 2
    resolved = Task.of(2).map(fn)
    assert resolved.fork(lambda _: None, lambda x: x) == 4


# Generated at 2022-06-12 05:37:59.198025
# Unit test for method map of class Task
def test_Task_map():

    def resolve(arg):
        assert arg == 2

    def reject(arg):
        assert False

    def add(arg):
        return arg + 1

    result = Task.of(1).map(add)

    result.fork(reject, resolve)


# Generated at 2022-06-12 05:38:11.388101
# Unit test for method map of class Task
def test_Task_map():

    # test for type Task
    assert Task.of(1).map(lambda arg: arg + 1).fork(__, __) == 2
    assert type(Task.of(1).map(lambda arg: arg + 1)) == Task

    # test for type int
    assert Task.of(1).map(lambda arg: arg + 1).fork(__, lambda arg: arg) == 2
    assert type(Task.of(1).map(lambda arg: arg + 1).fork(__, lambda arg: arg)) == int

    # test for type string
    assert Task.of(1).map(lambda arg: str(arg + 1)).fork(__, lambda arg: arg) == '2'
    assert type(Task.of(1).map(lambda arg: str(arg + 1)).fork(__, lambda arg: arg)) == str

    # test for

# Generated at 2022-06-12 05:38:16.207476
# Unit test for method bind of class Task
def test_Task_bind():
    # Task[reject, value] -> Task[reject, map(value)]
    add_one_Task = Task.of(lambda x: x + 1)

    # Task[reject, value]
    Task_3 = Task.of(3)

    Task_3_add_one = Task_3.bind(add_one_Task)

    def fn(value):
        return Task.of(value + 1)

    Task_3 = Task_3.bind(fn)
    assert Task_3.fork(
        lambda arg: False,
        lambda arg: arg == 4
    )



# Generated at 2022-06-12 05:38:26.668635
# Unit test for method bind of class Task
def test_Task_bind():
    def mock_fork(_, resolve):
        resolve('resolve')

    def mock_mapper(value):
        return Task.of(value)

    task = Task(mock_fork)
    next_task = task.bind(mock_mapper)

    assert_equal(
        next_task.fork,
        lambda _, resolve: mock_mapper('resolve').fork(_, resolve)
    )

# Generated at 2022-06-12 05:38:30.991791
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of('foo').bind(
        lambda value: Task.reject(value)
    ).fork(id, id) == 'foo'

    assert Task.of('foo').bind(
        lambda value: Task.of(value)
    ).fork(id, id) == 'foo'


# Generated at 2022-06-12 05:38:37.474203
# Unit test for method bind of class Task
def test_Task_bind():
    def _fork(reject, resolve):
        return resolve(10)

    def task_gen_mapper(v):
        def _fork(reject, resolve):
            return resolve(v + 10)
        return Task(_fork)


    task = Task(_fork)
    assert task.bind(task_gen_mapper).fork(None, lambda v: v) == 20



# Generated at 2022-06-12 05:38:41.202491
# Unit test for method map of class Task
def test_Task_map():
    # Create test value
    value = 0
    # Create test function and store it
    fn = lambda x: x + 1 
    # Create test Task with test function and store it
    task = Task.of(value).map(fn)
    # Call fork with two empty functions
    task.fork(lambda x: None, lambda x: None)



# Generated at 2022-06-12 05:38:51.898478
# Unit test for method map of class Task
def test_Task_map():
    def fn(reject, resolve):
        assert len(arguments) == 2
        resolve(arguments[0] + arguments[1])

    arguments = [42, 420]
    task = Task(fn)

    result = task.map(lambda value: value ** 2).map(lambda value: value - 1).fork(lambda err: None, lambda value: value)
    assert result == 176364

    task = Task.of(42)
    callback = lambda value: value ** 2

    result = task.map(callback).fork(lambda err: None, lambda value: value)
    assert result == callback(42)

    task = Task.of(42)
    mapper = lambda value: Task.of(value ** 2)

    result = task.bind(mapper).fork(lambda err: None, lambda value: value)

# Generated at 2022-06-12 05:38:56.931949
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)

    def mapper(value):
        def fork(reject, resolve):
            resolve(2)
        return Task(fork)

    result = task.bind(mapper)

    assert 2 == result.fork(lambda _: None, lambda value: value)


# Generated at 2022-06-12 05:39:08.160542
# Unit test for method bind of class Task
def test_Task_bind():
    """Unit test for method bind of class Task."""
    value_one = Task.of(1).map(
        lambda val: val + 2
    )
    value_two = Task.of(2).map(
        lambda val: val + 2
    )
    value_three = Task.of(3).map(
        lambda val: val + 2
    )

    task_one = value_one.bind(
        lambda val: value_two.bind(
            lambda val_two: value_three.map(
                lambda val_three: val + val_two + val_three
            )
        )
    )

    assert task_one.fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 8


# Generated at 2022-06-12 05:39:19.784109
# Unit test for method bind of class Task
def test_Task_bind():
    def even_or_odd(a):
        return Task.of(
            a % 2 == 0 and 'even' or 'odd'
        )

    def greater_or_less_zero(a):
        return Task.of(
            a > 0 and 'positive' or 'negative'
        )

    task = Task.of(-10)
    task = task.bind(even_or_odd)
    task = task.bind(greater_or_less_zero)
    assert task.fork(
        lambda x: 'reject: ' + x,
        lambda x: 'resolve: ' + x
    ) == 'resolve: negative'

    task = Task.of(10)
    task = task.bind(even_or_odd)
    task = task.bind(greater_or_less_zero)
    assert task

# Generated at 2022-06-12 05:39:26.149986
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method.
    """
    double_fn = lambda arg: arg + arg
    double_bind = lambda arg: Task.of(arg).map(double_fn)

    task = Task.of(1).bind(double_bind)
    assert task.fork(lambda _: False, lambda arg: arg == 2)


# Generated at 2022-06-12 05:39:28.127198
# Unit test for method bind of class Task
def test_Task_bind():
    Task.of(2).bind(lambda v: Task.reject(v + 2))



# Generated at 2022-06-12 05:39:36.966102
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return 'foo'

    def reject(value):
        raise ValueError(str(value))

    def resolve(value):
        assert value == 'foo'

    task = Task.reject('error')
    task = task.map(mapper).map(mapper)
    task.fork(reject, resolve)


# Generated at 2022-06-12 05:39:48.416498
# Unit test for method bind of class Task
def test_Task_bind():
    # create Task with no arguments
    Task.of([]).bind(lambda _: Task.of([1])).fork(assert_error, assert_result)

    # create Task with variant arguments
    Task.of(1).bind(lambda _: Task.of(2)).fork(assert_error, assert_result)
    Task.of(1).bind(lambda _: Task.reject(2)).fork(assert_result, assert_error)
    Task.reject(1).bind(lambda _: Task.of(2)).fork(assert_result, assert_error)
    Task.reject(1).bind(lambda _: Task.reject(2)).fork(assert_result, assert_error)

    # create Task with list arguments

# Generated at 2022-06-12 05:39:51.311213
# Unit test for method map of class Task
def test_Task_map():
    # Arrange
    task = Task(lambda reject, resolve: resolve(1))

    # Act
    result = task.map(lambda arg: arg*2)

    # Assert
    assert result.fork(lambda reject, resolve: resolve) == 2

# Generated at 2022-06-12 05:39:55.977765
# Unit test for method bind of class Task
def test_Task_bind():
    result = 0
    task = Task.of(10).bind(lambda a: Task.of(a + 2))
    task.fork(
        lambda a: print('error'),
        lambda a: result.__setattr__('value', a)
    )

    assert result.value == 12


# Generated at 2022-06-12 05:40:06.964189
# Unit test for method bind of class Task
def test_Task_bind():
    def task_reject(value):
        """
        Return rejected Task with stored value argument.

        :param value: value to store in Task
        :type value: A
        :returns: rejected Task
        :rtype: Task[Function(reject, _) -> A]
        """
        return Task.reject(value)

    def task_resolve(value):
        """
        Return resolved Task with stored value argument.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value)


# Generated at 2022-06-12 05:40:18.803846
# Unit test for method map of class Task
def test_Task_map():
    """
    Testing map method of Task class
    """

    def add_one(x):
        return x + 1

    def add_two(x):
        return x + 2

    def double(x):
        return x * 2

    assert Task(lambda _, resolve: resolve(2))\
                .map(add_one).fork(None, lambda x: x) == 3

    assert Task(lambda _, resolve: resolve(2))\
                .map(double).fork(None, lambda x: x) == 4

    assert Task(lambda reject, _: reject(42))\
                .map(add_one).fork(lambda x: x, None) == 42

    assert Task(lambda reject, _: reject(42))\
                .map(add_one) == Task.of(42)


# Generated at 2022-06-12 05:40:21.154955
# Unit test for method bind of class Task
def test_Task_bind():
    def add(n):
        return Task.of(2 + n)

    assert Task.of(2).bind(add).fork(None, None) == 4



# Generated at 2022-06-12 05:40:27.907694
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method map of class Task.
    """
    dummy = 0
    setattr(Task, "of", Task.of)
    setattr(Task, "reject", Task.reject)

    def my_map(a):
        return a * a

    dummy_task = Task.of(3)
    dummy_task = dummy_task.map(my_map)

    def my_fork(reject, resolve):
        reject(dummy_task)

    dummy_task.fork = my_fork
    dummy_task.fork(lambda a: setattr(dummy, "value", 9), lambda a: setattr(dummy, "value", 0))

    assert dummy.value == 9


# Generated at 2022-06-12 05:40:39.267600
# Unit test for method map of class Task
def test_Task_map():
    def test_number(str_number, expected_number):
        def f_of(reject, resolve):
            resolve(str_number)

        task = Task(f_of)
        result = task.map(len).fork(
            lambda arg: arg,
            lambda arg: arg
        )
        if result == expected_number:
            print("test_Task_map: OK")
        else:
            print("test_Task_map: Failed")

    test_number("", 0)
    test_number("1", 1)
    test_number("12", 2)
    test_number("123", 3)
    test_number("1234", 4)
    test_number("12345", 5)


# Generated at 2022-06-12 05:40:47.548986
# Unit test for method map of class Task
def test_Task_map():
    @Task.of
    def of(value):
        return value

    @Task.reject
    def reject(value):
        return value

    assert of(2).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 3
    assert of(2).map(lambda x: x ** 2).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 5
    assert of(2).map(lambda x: x + 1).map(lambda x: x ** 2).fork(lambda x: x, lambda x: x) == 9
    assert of(2).map(lambda x: x + 1).map(lambda x: x ** 2).map(lambda x: x / 2).fork(lambda x: x, lambda x: x) == 4.5

# Generated at 2022-06-12 05:41:01.236159
# Unit test for method bind of class Task
def test_Task_bind():
    resolve = lambda x:([x], print(x))
    reject = lambda x:([], print(x))

    Task.of(1)\
        .bind(lambda x:Task.of(2 * x))\
        .fork(reject, resolve) == ([2], print(2))

    Task.reject('error')\
        .bind(lambda x:Task.of(2 * x))\
        .fork(reject, resolve) == ([], print('error'))

    Task.of(1)\
        .bind(lambda x: Task.reject('error'))\
        .fork(reject, resolve) == ([], print('error'))


# Generated at 2022-06-12 05:41:05.305074
# Unit test for method map of class Task
def test_Task_map():
    def return_3(_, resolve):
        return resolve(3)

    def fn_add_2(value):
        return value + 2

    result = Task(return_3).map(fn_add_2)
    assert result.fork(lambda a: a, lambda b: b) == 5

# Generated at 2022-06-12 05:41:12.540625
# Unit test for method bind of class Task
def test_Task_bind():
    from monad_exercise import Task

    task = Task.of(3)
    assert task.bind(lambda value: Task.of(value + 1)).fork(None, lambda value: value) == 4
    assert task.bind(lambda value: Task.of(value - 3)).fork(None, lambda value: value) == 0
    assert task.bind(lambda value: Task.of(value * 2)).fork(None, lambda value: value) == 6


# Generated at 2022-06-12 05:41:19.254335
# Unit test for method map of class Task
def test_Task_map():
    # Test for map with "of"
    task = Task.of(4).map(lambda x: x + 2)
    assert task.fork(lambda e: e, lambda v: v) == 6

    # Test for map with reject
    task = Task.reject(4).map(lambda x: x + 2)
    assert task.fork(lambda e: e, lambda v: v) == 4

    # Test for map with only resolve
    def reject_mock(arg):
        assert False

    def resolve_mock(arg):
        assert arg == 6

    task = Task(lambda reject, resolve: resolve(4)).map(lambda x: x + 2)
    task.fork(reject_mock, resolve_mock)


# Generated at 2022-06-12 05:41:25.797725
# Unit test for method bind of class Task
def test_Task_bind():
    add_1 = lambda x: Task.of(x + 1)
    mul_2 = lambda x: Task.of(x * 2)

    assert Task.of(1).bind(add_1).bind(mul_2).fork(
        lambda x: False,
        lambda x: x == 4
    )

    assert Task.of(1).bind(add_1).bind(mul_2).bind(add_1).bind(
        lambda x: Task.reject(x)
    ).fork(
        lambda x: x == 7,
        lambda x: False
    )


# Generated at 2022-06-12 05:41:32.583013
# Unit test for method bind of class Task
def test_Task_bind():
    def forked_method(reject, resolve):
        resolve(1)

    task = Task(forked_method)

    def mapper(value):
        return Task(forked_method)

    result = task.bind(mapper)

    result.fork(
        lambda arg: print('Task rejected: {}'.format(arg)),
        lambda arg: print('Task resolved: {}'.format(arg))
    )

test_Task_bind()


# Generated at 2022-06-12 05:41:39.301219
# Unit test for method map of class Task
def test_Task_map():
    #
    # return Task with value
    def return_task(value):
        def resolved_callback(_, resolve):
            return resolve(value)
        return Task(resolved_callback)
    #
    def map_callback(x):
        return str(x) + '_mapped'
    #
    result = return_task(10).map(map_callback)
    #
    assert result.fork(lambda x: x, lambda x: x) == '10_mapped'


# Generated at 2022-06-12 05:41:43.559511
# Unit test for method map of class Task
def test_Task_map():
    import unittest

    Task.of(1).fork(lambda _: unittest.TestCase.fail, lambda value: unittest.TestCase.assertEqual(value, 1))
    Task.of(3).map(lambda x: x + 1).fork(lambda _: unittest.TestCase.fail,
                                         lambda value: unittest.TestCase.assertEqual(value, 4))
    Task.reject(1).fork(lambda value: unittest.TestCase.assertEqual(value, 1), lambda _: unittest.TestCase.fail)
    Task.reject(3).map(lambda x: x + 1).fork(lambda value: unittest.TestCase.assertEqual(value, 3),
                                             lambda _: unittest.TestCase.fail)



# Generated at 2022-06-12 05:41:49.446239
# Unit test for method bind of class Task
def test_Task_bind():
    t1 = Task.of(1)
    t2 = t1.bind(lambda a: Task.of(a + 1)).bind(lambda a: Task.of(a * 2))
    assert t2.fork(lambda _: None, lambda a: a) == 4

    t3 = Task.of(1)
    t4 = t3.bind(lambda a: Task.reject(a + 1))
    assert t4.fork(lambda a: a, lambda _: None) == 2

    t5 = Task.reject(1)
    t6 = t5.bind(lambda a: Task.of(a + 1)).bind(lambda a: Task.of(a * 2))
    assert t6.fork(lambda a: a, lambda _: None) == 1

    t7 = Task.reject(1)
    t8

# Generated at 2022-06-12 05:41:57.789194
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a):
        return Task.of(a + 2)

    def err(a):
        if a == 5:
            return Task.reject("bad value")
        return Task.of(a + 2)

    assert Task.of(3).bind(add).fork(lambda a: "reject", lambda a: a) == 5
    assert Task.of(3).bind(lambda _: Task.reject("reject")).fork(lambda a: a, lambda a: "resolve") == "reject"

    assert Task.of(3).bind(lambda _: err(3)).fork(lambda a: a, lambda a: "resolve") == "reject"


# Generated at 2022-06-12 05:42:13.499593
# Unit test for method bind of class Task
def test_Task_bind():

    def identity(x):
        return Task.of(x)

    def add1(x):
        return Task.of(x + 1)

    def error(_):
        return Task.reject('Boom!')

    print(Task.of(2).bind(add1).bind(add1).fork(print, print))
    print(Task.of(20).bind(add1).bind(error).bind(add1).fork(print, lambda _: "Not happend"))

# Generated at 2022-06-12 05:42:17.473322
# Unit test for method map of class Task
def test_Task_map():
    """Testing Task.map method"""
    def test_reject(err):
        assert err == 'ArgError'

    def test_resolve(result):
        assert result == 'test'

    def test_map(arg):
        return 'test'

    Task.of('ArgError').map(test_map).fork(test_reject, test_resolve)


# Generated at 2022-06-12 05:42:22.082108
# Unit test for method map of class Task
def test_Task_map():
    @Task.of
    def fn():
        return 'lol'

    @Task.of
    def fn2():
        return 1

    assert fn.map(lambda el: el+'world').fork(lambda lol: lol+'|', lambda lol: lol) == 'lolworld'
    assert fn2.map(lambda el: el+2).fork(lambda lol: lol+'|', lambda lol: lol) == 3


# Generated at 2022-06-12 05:42:33.332080
# Unit test for method bind of class Task
def test_Task_bind():
    def isOdd(arg):
        return Task.of(arg % 2 == 1)

    def isEven(arg):
        return Task.of(arg % 2 == 0)

    def isPrime(arg):
        if arg < 2:
            return Task.of(False)
        if arg == 2:
            return Task.of(True)
        if arg % 2 == 0:
            return Task.of(False)
        for i in range(3, int(arg**0.5) + 2, 2):
            if arg % i == 0:
                return Task.of(False)
        return Task.of(True)

    def test(reject, resolve):
        def print_is_odd(n):
            if n is True:
                print('is odd')

# Generated at 2022-06-12 05:42:41.602170
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    """
    def test_fork(reject, resolve):
        return resolve(1)

    def mapper(number):
        def inner_fork(inner_reject, inner_resolve):
            return inner_resolve(number)

        return Task(inner_fork)

    init_task = Task(test_fork)
    mapped_task = init_task.bind(mapper)
    result = mapped_task.fork(
        lambda arg: arg,
        lambda arg: arg
    )

    assert 1 == result, "Task.bind don't work"

# Generated at 2022-06-12 05:42:42.695553
# Unit test for method map of class Task
def test_Task_map():
    def uppercase(a):
        return a.upper()

    assert Task.of('Hello').map(uppercase).fork(None, lambda a: a) == 'HELLO'


# Generated at 2022-06-12 05:42:46.996349
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task

    >>> a = Task.of(42)
    >>> b = a.map(lambda arg: arg + arg)
    >>> b.fork(lambda arg: arg, lambda arg: arg)
    84
    """
    pass


# Generated at 2022-06-12 05:42:51.256168
# Unit test for method bind of class Task
def test_Task_bind():
    fn = lambda value: Task.reject(value + 1)
    assert Task(lambda _, resolve: resolve(1)).bind(fn).fork(assert_equal, None)(2)
    assert Task(lambda _, resolve: resolve(3)).bind(fn).fork(None, None)(0)


# Generated at 2022-06-12 05:42:58.462052
# Unit test for method map of class Task
def test_Task_map():
    """
    This method test map method of class Task.
    """
    # Test with simple numbers
    number_one = 1
    number_two = 2
    task = Task.of(number_one)

    # Test with simple functions
    def numeric_increment(value):
        return value + number_two

    def numeric_double(value):
        return value * 2

    def numeric_double_increment(value):
        return numeric_increment(numeric_double(value))

    # Test Task of simple numbers with simple functions
    assert task.map(numeric_increment).fork(lambda _: 0, lambda a: a) == number_one + number_two
    assert task.map(numeric_double).fork(lambda _: 0, lambda a: a) == number_one * 2

# Generated at 2022-06-12 05:43:06.794119
# Unit test for method bind of class Task
def test_Task_bind():
    def test_reject():
        return Task.bind(Task.reject('x'), lambda _: Task('y'))

    assert test_reject().fork(sink, None) == 'x'

    def test_resolve():
        return Task.bind(Task('x'), lambda _: Task('y'))

    assert test_resolve().fork(None, sink) == 'y'

    def test_reject_nest():
        return Task.bind(Task('x'), lambda _: Task.reject('y'))

    assert test_reject_nest().fork(sink, None) == 'y'


# Generated at 2022-06-12 05:43:36.110287
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Return Task with resolved value, which is square of next identical
    value after square of current value in Task.

    :param value: current value
    :type value: int
    :returns: new Task with mapped resolve attribute
    :rtype: Task[Function(resolve, reject -> int | int]
    """
    def test(value):
        return Task.of(value * value) \
            .bind(lambda x: Task.of(x + 1)) \
            .map(lambda x: x * x)

    assert test(1).fork(lambda x: x, lambda x: x) == 16
    assert test(2).fork(lambda x: x, lambda x: x) == 25



# Generated at 2022-06-12 05:43:44.294155
# Unit test for method map of class Task
def test_Task_map():
    """
    Testing of method map of class Task.
    """
    test_value = 1

    def test_fn(param):
        return param + test_value

    def reject_fn(param):
        return param

    def resolve_fn(param):
        return param

    def fork_func(reject, resolve):
        return resolve(test_value)

    task = Task(fork_func)

    mapped_task = task.map(test_fn)

    mapped_value = mapped_task.fork(reject_fn, resolve_fn)

    assert mapped_value == 2
    assert task.fork(reject_fn, resolve_fn) == 1


# Generated at 2022-06-12 05:43:50.730382
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    task1 = Task.of(1)
    task2 = Task.of(2)

    task3 = task1.bind(fn)
    assert task3.fork(lambda err: err, lambda res: res) == 2

    task4 = task2.bind(fn)
    assert task4.fork(lambda err: err, lambda res: res) == 3


# Generated at 2022-06-12 05:43:52.709793
# Unit test for method map of class Task
def test_Task_map():
    assert (
        Task
        .of(2)
        .map(lambda v: v + 1)
        .fork(lambda v: v, lambda v: v)
        == 3
    )


# Generated at 2022-06-12 05:44:03.849764
# Unit test for method map of class Task
def test_Task_map():
    """
    Call three Task with map method and check their value.
    """
    def add_one(x): return x + 1

    def sub_one(x): return x - 1

    assert Task.of(1).map(add_one).map(add_one).fork(_, lambda x: x) == 3, 'Test: map method of class Task'
    assert Task.of(1).map(add_one).map(add_one).map(sub_one).fork(_, lambda x: x) == 2, 'Test: map method of class Task'
    assert Task.of(1).map(add_one).map(add_one).map(add_one).fork(_, lambda x: x) == 4, 'Test: map method of class Task'



# Generated at 2022-06-12 05:44:13.880806
# Unit test for method bind of class Task
def test_Task_bind():
    def async_call(resolve, reject, arg):
        try:
            if arg == 42:
                resolve(arg)
            else:
                reject(ValueError('Not 42'))
        except Exception as err:
            reject(err)

    def task_builder(arg):
        return Task(lambda reject, resolve: async_call(resolve, reject, arg))

    def resolve_mapper(value):
        return value**2

    def reject_mapper(value):
        return value.args[0]

    assert Task(lambda reject, resolve: async_call(resolve, reject, 1)) \
        .bind(task_builder) \
        .fork(reject_mapper, resolve_mapper) == 'Not 42'


# Generated at 2022-06-12 05:44:18.183269
# Unit test for method map of class Task
def test_Task_map():
    def add_1(value):
        return value + 1

    assert isinstance(Task.of(4).map(add_1), Task)
    assert Task.of(4).map(add_1).fork(lambda arg: arg, lambda arg: arg) == 5



# Generated at 2022-06-12 05:44:21.363098
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of('result')

    assert result.map(lambda x: x + x).map(lambda x: x + x).fork('err', lambda x: x) == 'resultresultresultresult'


# Generated at 2022-06-12 05:44:25.361468
# Unit test for method map of class Task
def test_Task_map():
    def double(x): return 2*x
    double_task = Task(lambda reject, resolve: resolve(1)).map(double)
    assert double_task.fork(lambda _: False, lambda x: x == 2)


# Generated at 2022-06-12 05:44:34.706883
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test task map
    """
    def success_mapper(value):
        return Task.of(value + " mapped")

    def failure_mapper(value):
        return Task.reject(value + " mapped")

    def run_task(task):
        return task.fork(lambda value: value, lambda value: value)

    assert run_task(
        Task.of("value")
        .bind(success_mapper)
    ) == "value mapped"

    assert run_task(
        Task.reject("value")
        .bind(failure_mapper)
    ) == "value mapped"

    assert run_task(
        Task.of("value")
        .bind(failure_mapper)
        .bind(success_mapper)
    ) == "value mapped mapped"

    assert run_

# Generated at 2022-06-12 05:45:31.447746
# Unit test for method map of class Task
def test_Task_map():
    def return_result_for_two(*args):
        resolve, _ = args
        return resolve(2)

    def return_result_for_four(*args):
        resolve, _ = args
        return resolve(4)

    def return_result_for_eight(*args):
        resolve, _ = args
        return resolve(8)

    task = Task(return_result_for_two)
    assert task.fork(lambda _: None, lambda arg: arg) == 2
    new_task = task.map(lambda x: x * 2)
    assert new_task.fork(lambda _: None, lambda arg: arg) == 4
    new_task = new_task.map(lambda x: x * 2)
    assert new_task.fork(lambda _: None, lambda arg: arg) == 8


# Generated at 2022-06-12 05:45:35.979081
# Unit test for method bind of class Task
def test_Task_bind():
    def get_task(value):
        return Task.of(value).map(lambda arg: arg + 1)

    task_to_test = Task.of(1).bind(get_task)

    task_to_test.fork(
        print,
        print
    )


# Generated at 2022-06-12 05:45:46.734135
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function_with_callback_as_argument(callback):
        callback(True)
    
    def test_function_with_function_as_argument(fn):
        fn(True)

    def test_function_with_task_as_argument(task):
        task.fork(lambda a: True, lambda a: False)


# Generated at 2022-06-12 05:45:51.286476
# Unit test for method bind of class Task
def test_Task_bind():
    task_for_bind = Task(lambda _, resolve: resolve(1))
    task_for_bind.bind(lambda x: Task.of(x * 2)).fork(
        lambda result: print(result),
        lambda error: print(error)
    )

test_Task_bind()


# Generated at 2022-06-12 05:45:54.030575
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(42).map(lambda item: item + 42).fork(None, lambda item: item) == 84
    assert Task.reject(42).map(lambda item: item + 42).fork(lambda item: item, None) == 42


# Generated at 2022-06-12 05:46:02.109540
# Unit test for method bind of class Task
def test_Task_bind():
    value = 'foo'

    def test_fork(reject, resolve):
        resolve(value)

    t1 = Task(test_fork)
    t2 = t1.bind(lambda x: Task.of(x + 'bar'))
    t3 = t2.bind(lambda x: Task.reject(x + 'bar'))

    assert value  == t1.fork(lambda _: None, lambda x: x)
    assert value + 'bar' == t2.fork(lambda _: None, lambda x: x)
    assert value == t3.fork(lambda x: x, lambda _: None)


# Generated at 2022-06-12 05:46:06.222418
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(42)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)

    next_task = task.bind(mapper)