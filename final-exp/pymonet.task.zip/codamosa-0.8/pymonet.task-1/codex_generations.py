

# Generated at 2022-06-12 05:36:03.786191
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task map method.

    :returns: None
    :rtype: None
    """
    def map(reject, resolve):
        def task(reject, resolve):
            resolve(10)

        return Task(task).map(lambda x: x + 10).fork(reject, resolve)

    assert performWithPromise(map) == 20



# Generated at 2022-06-12 05:36:10.203132
# Unit test for method bind of class Task
def test_Task_bind():
    def mock(x):
        return Task(lambda _, resolve: resolve(x))

    assertTask(
        Task.of(0).bind(mock).fork(lambda _: True, lambda x: False),
        False,
        0
    )

    assertTask(
        Task.of(0).bind(
            lambda x: Task.reject(x)
        ).map(lambda _: True).fork(lambda _: False, lambda _: True),
        True,
        0
    )


# Generated at 2022-06-12 05:36:18.584779
# Unit test for method bind of class Task
def test_Task_bind():
    def double(x):
        return x * 2

    def square(x):
        return x * x

    def create_task(x):
        return Task.of(x).map(double).map(square)

    assert Task.of(10) \
        .bind(create_task) \
        .fork(lambda x: x, lambda x: x) == 400

    assert Task.of(10) \
        .map(double) \
        .bind(create_task) \
        .fork(lambda x: x, lambda x: x) == 400


# Generated at 2022-06-12 05:36:26.567292
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(arg):
        return Task.of(arg)

    def fork(reject, resolve):
        resolve("Test")

    def test_ok(resolve):
        assert resolve("Test") == "Test"

    def test_error(reject):
        assert reject("Test") == "Test"

    task = Task(fork)
    task.bind(fn).fork(test_ok, test_error)
    task.fork(test_error, test_ok)


# Generated at 2022-06-12 05:36:34.698909
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task stores function and resolve/reject status
    and when fork is called -> it calls function with resolve/reject callback.
    """
    def node(reject, resolve):
        print('fork is called')
        resolve(5)

    fn = Task(node).bind(lambda x: Task.of(x + 7))
    def reject(v):
        print('rejected: %s' % v)
    def resolve(v):
        print('resolved %s' % v)
    fn.fork(reject, resolve)



# Generated at 2022-06-12 05:36:39.146271
# Unit test for method map of class Task
def test_Task_map():
    def test_map():
        """
        Example of test_map argument.
        """

    task = Task(test_map)
    assert task.map(lambda x: x).fork(lambda y: 0, lambda y: 1) == 1



# Generated at 2022-06-12 05:36:46.502346
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task are data-type for handle execution of functions (in lazy way)
    transform results of this function and handle errors.
    """

    def fork_with_increment(reject, resolve):
        """
        increment value of input arg and return it

        :param arg:
        :returns: arg incremented by 1
        """
        return resolve(arg + 1)

    task = Task(fork_with_increment)
    assert task.fork(lambda arg: reject(arg), lambda arg: resolve(arg + 1)) == 2



# Generated at 2022-06-12 05:36:51.120519
# Unit test for method map of class Task
def test_Task_map():
    """ Test for method map of class Task"""
    task = Task.of(1).map(lambda value: value + 1)
    assert task.fork(lambda reject: reject, lambda resolve: resolve) == 2

    task = Task.reject(1).map(lambda value: value + 1)
    assert task.fork(lambda reject: reject, lambda resolve: resolve) == 1


# Generated at 2022-06-12 05:36:55.677043
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x + 2

    task = Task.of(1).map(fn)

    def fork(reject, resolve):
        # assert task.fork == fork
        return resolve(3)

    assert task.fork == fork


# Generated at 2022-06-12 05:36:58.768317
# Unit test for method map of class Task
def test_Task_map():
    def increment(number):
        return number+1

    assert Task.of(42).map(increment).fork(lambda _: _, lambda arg: arg) == 43


# Generated at 2022-06-12 05:37:09.815819
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task

    :returns: True if test success
    :rtype: bool
    """
    T = Task.of(5)
    T1 = T.map(lambda x: x * 2)
    T2 = T.map(lambda x: str(x))
    assert T1.fork(None, lambda x: x) == 10
    assert T2.fork(None, lambda x: x) == "5"

    R = Task.reject(5)
    R1 = R.map(lambda x: x * 2)
    assert R1.fork(lambda x: x, None) == 5

    return True


# Generated at 2022-06-12 05:37:17.475501
# Unit test for method map of class Task
def test_Task_map():
    """
    Create and resolve Task with function which return value.
    Create and resolved Task with function which return Task with value.
    """
    def transform(value):
        return value + ' world'

    task = Task.of('hello')
    assert task.map(transform).fork(
        lambda value: None,
        lambda value: value
    ) == 'hello world'

    def transform(value):
        return Task.of(value + ' world')

    assert task.bind(transform).fork(
        lambda value: None,
        lambda value: value
    ) == 'hello world'


# Generated at 2022-06-12 05:37:25.133625
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind for Task.
    """
    def add(x):
        def inner(y):
            return x + y

        return Task.of(inner)

    def multiply(x):
        def inner(y):
            return x * y

        return Task.of(inner)

    assert Task.of(8).bind(add(2)).bind(multiply(10)).fork(
        lambda e: e,
        lambda r: r
    ) == 100


# Generated at 2022-06-12 05:37:30.491797
# Unit test for method map of class Task
def test_Task_map():

    # Arrange
    expected = 'foo'
    task = Task.of('bar')
    result = task.map(lambda value: value + 'foo')

    # Act
    def resolve(value):
        assert value == expected


# Generated at 2022-06-12 05:37:42.251338
# Unit test for method map of class Task

# Generated at 2022-06-12 05:37:47.760413
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.reject(123).bind(lambda value: Task.of(value * 2)).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 123
    assert Task.of(123).bind(lambda value: Task.reject(value * 2)).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 246


# Generated at 2022-06-12 05:37:51.408839
# Unit test for method bind of class Task
def test_Task_bind():
    def add1(x):
        return Task.of(x + 1)

    assert Task.of(1).bind(add1).fork(lambda _: None, lambda arg: arg) == 2



# Generated at 2022-06-12 05:37:59.227488
# Unit test for method bind of class Task
def test_Task_bind():
    def call(fn):
        foo = fn()
        return foo.fork(
            lambda msg: "Reject: " + str(msg),
            lambda msg: "Resolve: " + str(msg))

    assert call(lambda: Task.of(1).bind(lambda x: Task.of(x + 1))) == 'Resolve: 2'
    assert call(lambda: Task.of(1).bind(lambda x: Task.reject(x + 1))) == 'Reject: 2'
    assert call(lambda: Task.reject(1).bind(lambda x: Task.of(x + 1))) == 'Reject: 1'


# Generated at 2022-06-12 05:38:11.387099
# Unit test for method map of class Task
def test_Task_map():
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.task = Task.of(5)

        def test_should_return_Task(self):
            self.assertIsInstance(
                self.task.map(lambda x: x + 4),
                Task
            )

        def test_should_return_correct_value(self):
            value = self.task.map(lambda x: x + 4).fork()

            self.assertEqual(value, 9)

        # It will never happens that exception will be
        # catched during fork execution, because all
        # exceptions will be caught in Task.__init__.

# Generated at 2022-06-12 05:38:16.909132
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map function
    """
    data = 2
    result = Task.of(2).map(lambda arg: arg * 2).fork(lambda _: "", lambda arg: arg)
    assert result == data * 2, ("Task.of(2).map(lambda arg: arg * 2).fork(lambda _: "", lambda arg: arg) must be {}, but it is {}".format(data * 2, result))



# Generated at 2022-06-12 05:38:23.535042
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(mapper)
    assert task.fork(
        lambda value: AssertionError(value),
        lambda value: value == 2
    )


# Generated at 2022-06-12 05:38:33.036204
# Unit test for method map of class Task
def test_Task_map():
    """
    Take function, store it and call with Task value during calling fork function.
    Return result of called.

    :param fn: mapper function
    :type fn: Function(value) -> B
    :returns:  new Task with mapper resolve attribute
    :rtype: Task[reject, mapped_value]
    """

    def fn(*args):
        return 10

    t1 = Task.of(1)
    t2 = Task.of(2)
    t3 = Task.of(3)

    t11 = t1.map(fn)
    t22 = t2.map(fn)
    t33 = t3.map(fn)

    assert t11.fork(None, lambda val: val) == 10
    assert t22.fork(None, lambda val: val) == 10

# Generated at 2022-06-12 05:38:37.792735
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value)

    assert Task.of(42).bind(fn) == Task.of(42), \
        "Task.of(42).bind(fn) must be equal to Task.of(42)"


# Generated at 2022-06-12 05:38:48.990871
# Unit test for method map of class Task
def test_Task_map():
    def resolve_value(value):
        return Task.of(value)

    def reject_value(value):
        return Task.reject(value)

    def add_five_on_success(value):
        return Task.of(value + 5)

    def plus_five_mapper_on_success(value):
        return add_five_on_success(value).map(lambda v: v * 2)

    def plus_five_mapper_on_reject(value):
        return add_five_on_success(value).map(lambda v: v + 5)

    # when mapped on success value

# Generated at 2022-06-12 05:38:59.035605
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    def testFunc():
        """
        Helper function for test suite
        """
        def from_promise(promise):
            """
            Take promise and return task
            :param promise: promise to convert
            :type promise: Promise[reject, resolve]
            :returns: task
            :rtype: Task[reject, resolve]
            """
            return Task(lambda reject, resolve: promise.fork(reject, resolve))

        def get_value(value):
            """
            Helper function to return task with resolve function
            :param value: result of resolve function
            :type value: A
            :returns: task with resolve function
            :rtype: Task[reject, resolve]
            """
            return Task.of(value)


# Generated at 2022-06-12 05:39:09.973017
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task::map with Task::of and Task::reject.
    """
    def f1(value):
        """
        :param value: int value
        :type value: int
        :returns: the same value
        :rtype: int
        """
        return value

    def f2(value):
        """
        :param value: int value
        :type value: int
        :returns: the same value
        :rtype: int
        """
        return value

    def f3(value):
        """
        :param value: string value
        :type value: str
        :returns: the same value
        :rtype: str
        """
        return value

    # test Task::map
    assert Task.of(15).map(f1) == Task.of(15)

# Generated at 2022-06-12 05:39:21.497190
# Unit test for method bind of class Task
def test_Task_bind():
    def check(a, b, c):
        if a == b:
            return Task.of(c)
        else:
            return Task.reject("false")

    def tokenize(sentence):
        return Task.of(sentence.split(" "))

    def check_with_sentence(sentence):
        return (
            tokenize(sentence)
            .bind(lambda tokens: check("Hello", tokens[0], "Hello"))
        )

    assert check_with_sentence("Hello world!").fork(lambda x: x, lambda x: x) == "Hello"
    assert check_with_sentence("Goodbye world!").fork(lambda x: x, lambda x: x) == "false"

    print("Unit tests for method bind of class Task was successful")



# Generated at 2022-06-12 05:39:26.456467
# Unit test for method map of class Task
def test_Task_map():
    def resolve(reject, resolve):
        return resolve(100)

    def mapper(x):
        return x * 2

    assert Task(resolve).map(mapper).fork(print, print) == 200


# Generated at 2022-06-12 05:39:33.254584
# Unit test for method bind of class Task
def test_Task_bind():
    from random import randint
    
    def random_int():
        return Task.of(randint(0, 100))

    def square_int(value):
        return Task.of(value * value)

    for _ in range(0, 10):
        assert random_int() \
            .bind(square_int) \
            .fork(
                lambda _: None,
                lambda value: value in range(0, 10000)) == True

# Generated at 2022-06-12 05:39:37.570174
# Unit test for method map of class Task
def test_Task_map():
    def stub_resolve(x):
        return x

    def stub_reject(x):
        return x

    def foo(x):
        return x + 1

    assert Task(lambda _, resolve: resolve(2)).map(foo).fork(stub_reject, stub_resolve) == 3

    assert Task(lambda reject, _: reject('err')).map(foo).fork(
        stub_resolve, stub_reject
    ) == 'err'


# Generated at 2022-06-12 05:39:43.239998
# Unit test for method map of class Task
def test_Task_map():
    # Define function to chain with Task.
    def fn(value):
        assert value == 1
        return 2

    # Create resolved Task.
    task = Task.of(1)

    # Call map method and check result.
    result = task.map(fn)
    assert result.fork(lambda _: True, lambda arg: arg == 2)


# Generated at 2022-06-12 05:39:48.113899
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_mapper(value):
        return Task.reject(value)

    def fork(reject, resolve):
        reject('test')

    fork_mapped = Task(fork).bind(fn_mapper)
    assert fork_mapped.fork('test_value', 'test_value') == 'test'


# Generated at 2022-06-12 05:39:53.221523
# Unit test for method bind of class Task
def test_Task_bind():
    def add(value):
        return Task.of(value + 1)

    def fail():
        return Task.reject(Exception("Fail"))

    def recv_value(value):
        assert value == 2
        return

    assert Task.of(1).bind(add).fork(fail, recv_value)

# Generated at 2022-06-12 05:39:59.553520
# Unit test for method map of class Task
def test_Task_map():
    def identity(x):
        return x

    def multiply_by_two(x):
        return x * 2

    def multiply_by_three(x):
        return x * 3

    task = Task.of(42)
    task = task.map(multiply_by_two)
    result = task.fork(identity, identity)

    assert result == 84

    task = Task.of(42)
    task = task.map(multiply_by_two)
    task = task.map(multiply_by_three)
    result = task.fork(identity, identity)

    assert result == 126


# Generated at 2022-06-12 05:40:06.024446
# Unit test for method map of class Task
def test_Task_map():
    # Test for case when value is None
    assert Task.of(None).map(lambda value: value + 1) == Task.of(1)

    # Test for case when value is int
    assert Task.of(2).map(lambda value: value + 1) == Task.of(3)

    # Test for case when value is str
    assert Task.of('3').map(lambda value: value + '1') == Task.of('31')



# Generated at 2022-06-12 05:40:15.085468
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    """
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(1).bind(lambda x: Task.reject(x + 1)).fork(lambda x: x, lambda x: x) == 2
    assert Task.reject(1).bind(lambda x: Task.of(x + 1)).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-12 05:40:20.043114
# Unit test for method map of class Task
def test_Task_map():
    def test_mapper(a):
        return a + 1

    # test for Exception handling
    assert Task(lambda reject, resolve: resolve(1)).map(test_mapper).fork(lambda e: -1, lambda a: a) == 2
    assert Task(lambda reject, resolve: reject(1)).map(test_mapper).fork(lambda e: -1, lambda a: a) == -1


# Generated at 2022-06-12 05:40:24.577185
# Unit test for method bind of class Task
def test_Task_bind():
    """
    test for Task.bind
    """
    # task with value equals 2
    task = Task.of(2)
    # function wich take value, double it and return rejected Task
    def fn(value):
        return Task.reject(value * 2)

    assert task.bind(fn).fork(lambda value: value, lambda _: None) == 4


# Generated at 2022-06-12 05:40:34.402023
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return value

    def reject(value):
        return value

    def add(value):
        return value + 10

    def equals(first, second):
        return first == second

    value = 1

    task = Task(lambda reject, resolve: resolve(value))

    assert task.map(add).fork(reject, resolve) == add(value)

    assert task.map(add).fork(reject, resolve) != add(value + 100)

    assert task.map(add).fork(reject, resolve) != add(value - 10)

    task = Task(lambda reject, resolve: reject(value))

    assert task.map(add).fork(reject, resolve) == value


# Generated at 2022-06-12 05:40:38.506019
# Unit test for method map of class Task
def test_Task_map():
    # Start data
    task = Task.of(1)

    # End data
    end_task = task.map(lambda x: x + 1)

    # Check of correctness
    assert 2 == end_task.fork(lambda x: x, lambda x: x)


# Generated at 2022-06-12 05:40:49.726422
# Unit test for method map of class Task
def test_Task_map():
    """
    This test show us that Task.map(fn)
    return Task object with fork function, which
    call second function parameter(it is resolve function)
    with result of called function parameter(first parameter of map function)
    with value stored in Task.
    """
    mapper = Mock()
    value = Mock()

    mapper.return_value = value

    task = Task.of(value)
    mapped_task = task.map(mapper)
    mapper.assert_not_called()

    resolve = Mock()
    reject = Mock()

    mapped_task.fork(reject, resolve)
    mapper.assert_called_with(value)
    resolve.assert_called_with(value)
    reject.assert_not_called()


# Generated at 2022-06-12 05:41:00.841443
# Unit test for method map of class Task
def test_Task_map():
    def identity(value):
        return value

    def neg(value):
        return -value

    def add2(value):
        return value + 2

    def minus2(value):
        return value - 2

    def square(value):
        return value ** 2

    def double(value):
        return value * 2

    def echo(value):
        return value

    def echo_square(value):
        return echo(square(value))

    def double_neg(value):
        return double(neg(value))

    def square_double(value):
        return square(double(value))

    def neg_double(value):
        return neg(double(value))

    def double_square(value):
        return double(square(value))

    def add2_double(value):
        return add2(double(value))

   

# Generated at 2022-06-12 05:41:09.183325
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map(fn)
    :returns: Task with stored value
    :rtype: Task[Function(resolve, reject)]
    """
    def test_helper(self, fn, resolve, reject):
        """
        Helper function that calls Task.fork.
        :param self: Task
        :type self: Task[Function(resolve, reject)]
        :param fn: mapper function
        :type fn: Function(value) -> A
        :param resolve: callback for resolve
        :type resolve: Function(value)
        :param reject: callback for reject
        :type reject: Function(value)
        """
        def wrapper(_, resolve):
            self.map(fn).fork(reject, resolve)

        wrapper(None, resolve)

    return task_resolve_reject(test_helper)

# Generated at 2022-06-12 05:41:17.079602
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task
    """
    def mapper(arg):
        return Task.of(arg + 1)

    result = (Task.of(1)
              .bind(mapper)
              .bind(mapper)
              .bind(mapper))

    assert result.fork(None, lambda arg: arg) == 4

    error = (Task.of(1)
             .bind(mapper)
             .bind(lambda _: Task.reject('error'))
             .bind(mapper))

    assert error.fork(lambda arg: arg, None) == 'error'


# Generated at 2022-06-12 05:41:21.504926
# Unit test for method map of class Task
def test_Task_map():
    def add(a):
        return a + 1

    task = Task.of(2)
    assert task.map(add).fork(lambda x: x, lambda x: x) == 3


# Generated at 2022-06-12 05:41:33.173446
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method
    """

    def init_task():
        """
        Create task that resolve to True.

        :returns: Task that resolve to True
        :rtype: Task[function, function]
        """
        return Task.of(True)

    def task_of_True():
        """
        Create Task that resolve to True.

        :returns: Task that resolve to True
        :rtype: Task[Function(_, resolve) -> Bool]
        """
        return Task.of(True)

    def task_of_False():
        """
        Create Task that resolve to False.

        :returns: Task that resolve to False
        :rtype: Task[Function(_, resolve) -> Bool]
        """
        return Task.of(False)


# Generated at 2022-06-12 05:41:43.425459
# Unit test for method bind of class Task
def test_Task_bind():
    # "BIND method" | "VALUE" | "CALLED RESULT"
    test_data = [
        ("with rejection", Task.reject(1), Task.reject(1)),
        ("with resolve", Task.of(1), Task.of(1).map( lambda arg: arg + 1 )),
    ]

    for (name, value, expected_result) in test_data:
        result = value.bind(
            lambda arg: Task.of(arg + 1)
        )

        assert result.fork(
            lambda arg: "reject" ,
            lambda arg: "resolve"
        ) == expected_result.fork(
            lambda arg: "reject" ,
            lambda arg: "resolve"
        ), \
            "Method bind() is failed with {}".format(name)


# Generated at 2022-06-12 05:41:47.249806
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(4)

    def fn(value):
        return value ** 2

    task = Task(fork)
    assert isinstance(task, Task)

    task_mapped = task.map(fn)
    assert isinstance(task_mapped, Task)
    assert 16 == task_mapped.fork(lambda x: x, lambda x: x)


# Generated at 2022-06-12 05:41:53.064080
# Unit test for method map of class Task
def test_Task_map():
    def plus_one(value):
        return value + 1

    rejected = Task.reject(1)
    resolved = Task.of(1)

    assert rejected.map(plus_one).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1
    assert resolved.map(plus_one).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 2


# Generated at 2022-06-12 05:41:56.443069
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(arg):
        return Task.of(arg * 2)

    assert Task.of(1).bind(test_fn).fork(None, lambda value: value) == 2


# Generated at 2022-06-12 05:42:12.077871
# Unit test for method bind of class Task
def test_Task_bind():
    double = lambda x: x * 2
    double_task = lambda x: Task.of(double(x))

    def assert_double_task(x, y):
        assert_that(Task.of(x).bind(double_task).fork(resolve=identity, reject=identity), is_(y))

    test_cases = {
        1: 2,
        2: 4,
        3: 6
    }

    for x, y in test_cases.items():
        yield assert_double_task, x, y


# Generated at 2022-06-12 05:42:15.976936
# Unit test for method map of class Task
def test_Task_map():
    def double(x):
        return x * 2

    def bad_double(_):
        return 'bad result'


# Generated at 2022-06-12 05:42:21.942224
# Unit test for method map of class Task
def test_Task_map():
    def resolve(resolve):
        return Task(
            lambda _, resolve: resolve(2)
        )

    def reject(reject):
        return Task(
            lambda reject, _: reject(3)
        )

    def fn(x):
        return Task(
            lambda _, resolve: resolve(x + 1)
        )

    assert resolve(resolve).map(fn).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 3

    assert reject(reject).map(fn).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 3


# Generated at 2022-06-12 05:42:31.341684
# Unit test for method bind of class Task
def test_Task_bind():
    """ test_Task_bind() -> None
    This method is unit-test of method bind of class Task.
    """
    def bind_value(value):
        """ bind_value(A) -> A
        Helper function to be called in bind function of Task.
        """
        def map_value(arg):
            """ map_value(A) -> Task[A, A]
            Helper function to be called in map function of Task.
            """
            return Task.of(arg * 2)

        return Task.of(value).map(map_value)

    assert Task.of(5).bind(bind_value).fork(None, lambda arg: arg) == 10


# Generated at 2022-06-12 05:42:39.559604
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of class Task.
    To do:
    1. Create task with stored value;
    2. Map stored value;
    3. Check that fork method will return converted value.
    """
    # Test data
    test_value = 42
    test_value_mapped = test_value * 2

    # Pin and test
    task = Task.of(test_value)
    task_mapped = task.map(lambda value: value * 2)
    assert(task_mapped.fork(lambda err: err, lambda res: res) == test_value_mapped)


# Generated at 2022-06-12 05:42:47.133108
# Unit test for method map of class Task
def test_Task_map():
    @Task
    def resolve(reject, resolve):
        time.sleep(1)
        resolve(1)

    @Task
    def reject(reject, resolve):
        time.sleep(1)
        reject(2)

    resolved = resolve.map(lambda x: x + 1)
    assert resolved.fork(lambda x: x, lambda x: x) == 2

    rejected = reject.map(lambda x: x + 1)
    assert rejected.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-12 05:42:51.768772
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value ** 2

    def fn_equals(value):
        return value ** 2 == 9

    assert Task.of(3).map(fn).fork(None, fn_equals)
    assert not Task.reject(3).map(fn).fork(None, fn_equals)


# Generated at 2022-06-12 05:42:58.379630
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return value + 1

    def sub_one(value):
        return value - 1

    assert Task(lambda reject, resolve: resolve(2)).bind(lambda value: Task.of(value + 1)) \
        .fork(lambda arg: arg, lambda arg: arg) == 3

    assert Task(lambda reject, resolve: resolve(2)).bind(lambda value: task_for_test) \
        .fork(lambda arg: arg, lambda arg: arg) == 3

    assert Task(lambda reject, resolve: resolve(2)).bind(lambda value: Task.of(add_one(value))).bind(
        lambda value: Task.of(sub_one(value))) \
        .fork(lambda arg: arg, lambda arg: arg) == 2

# Generated at 2022-06-12 05:43:08.099801
# Unit test for method bind of class Task
def test_Task_bind():
    "test for Task_bind"
    def add1(number):
        return number + 1

    def add2(number):
        return number + 2

    def function_with_error(number):
        raise Exception("Error")

    assert Task(lambda reject, resolve: resolve(1)).bind(add1).fork(lambda reject: None, lambda resolve: resolve) == 2
    assert Task(lambda reject, resolve: reject(1)).bind(add1).fork(lambda reject: reject, lambda reject: None) == 1

    assert Task(lambda reject, resolve: resolve(1)).bind(add1).bind(add2).fork(lambda reject: None,
                                                                             lambda resolve: resolve) == 4


# Generated at 2022-06-12 05:43:11.897189
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    def assert_Task(task, expected):
        actual = None
        def resolve(value):
            nonlocal actual
            actual = value

        task.fork(reject, resolve)
        assert actual == expected

    assert_Task(Task.of(1).map(fn), 2)
    assert_Task(Task.of(2).bind(lambda x: Task.of(x + 1)), 3)
    assert_Task(Task.of(3).bind(lambda x: Task.reject(x + 1)), 4)
    assert_Task(Task.reject(4).bind(lambda x: Task.reject(x + 1)), 5)

if __name__ == '__main__':
    test_Task_map()

# Generated at 2022-06-12 05:43:35.257739
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda reject, resolve: resolve('World'))
    task = task.map(lambda string: f'Hello, {string}')
    assert task.fork(lambda error: None, lambda string: string) == 'Hello, World'



# Generated at 2022-06-12 05:43:39.360845
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map. Check that the result is the same.
    """

    # Check that the result is the same.
    assert Task(lambda _, resolve: resolve(5)).map(lambda x: x * 2).fork(None, lambda value: value) == 10



# Generated at 2022-06-12 05:43:43.583723
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return Task.of(42).fork(reject, resolve)

    task = Task(fork)
    new_task = task.bind(lambda a: Task.of(a * 2))
    assert new_task.fork(lambda a: a, lambda a: a) == 84


# Generated at 2022-06-12 05:43:50.590996
# Unit test for method map of class Task
def test_Task_map():
    identity = lambda value: value

    def double(value):
        return value * 2

    task = Task.of(10)

    assert('Task(fork=<function test_Task_map.<locals>.result at 0x7f2a68c4a510>) == Task(fork=task.map(identity))')
    assert('Task(fork=<function test_Task_map.<locals>.result at 0x7f2a68c4a598>) == Task(fork=task.map(double))')


# Generated at 2022-06-12 05:44:00.017073
# Unit test for method map of class Task
def test_Task_map():
    # return Task[Function(_ -> 'resolve')]
    resolved = Task.of('resolve')

    def test_function(value):
        return value + ' mapped'

    # returned Task[Function(_ -> 'resolve mapped')]
    mapped = resolved.map(test_function)
    # assert 'resolve mapped' == mapped(reject, resolve)
    assert 'resolve mapped' == mapped.fork(lambda _: 'reject', lambda _: 'resolve')

    # return Task[Function(reject -> 'reject')]
    rejected = Task.reject('reject')
    # returned Task[Function(reject -> 'reject')]
    mapped  = rejected.map(test_function)
    # assert 'reject' == mapped(reject, resolve)

# Generated at 2022-06-12 05:44:07.049754
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(_, resolve):
        resolve(2)

    task = Task(fork)
    # task = Task.of(2)

    def mapper(value):
        def fork(_, resolve):
            value += 1
            resolve(value)

        return Task(fork)

    new_task = task.bind(mapper)

    def fork(reject, resolve):
        def fork(_, resolve):
            value = 3 + 1
            resolve(value)

        return Task(fork).fork(reject, resolve)

    assert new_task.fork == fork


# Generated at 2022-06-12 05:44:16.374359
# Unit test for method map of class Task
def test_Task_map():
    """
    Run unit test for method map of class Task.

    :returns: test results
    :rtype: bool
    """
    def plus1(a):
        return a + 1

    def result_plus1(result):
        return result == 4

    def result_plus1_plus1(result):
        return result == 5

    task = Task.of(3) \
        .map(plus1) \
        .map(plus1)

    return task.fork(None, result_plus1) and \
        task.bind(Task.of).fork(None, result_plus1_plus1)


# Generated at 2022-06-12 05:44:25.537677
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> t0 = Task.of(1)
    >>> def fn(x):
    ...     return Task.of(x * 2)
    >>> t1 = t0.bind(fn)
    >>> result = t1.fork(lambda x: x, lambda x: x)
    >>> assert result is 2
    >>> t0 = Task.of(1)
    >>> def fn(x):
    ...     return Task.reject(x * 2)
    >>> t1 = t0.bind(fn)
    >>> result = t1.fork(lambda x: x, lambda x: x)
    >>> assert result is 2
    """
    pass


# Generated at 2022-06-12 05:44:29.272961
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """
    def fork(reject, resolve):
        return reject(0)

    assert Task(fork).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 0



# Generated at 2022-06-12 05:44:33.033941
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    assert task.map(lambda x: x + 1).fork(None, lambda x: x) == 2
    assert task.map(lambda x: x ** 2).fork(None, lambda x: x) == 1


# Generated at 2022-06-12 05:45:18.460689
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda reject, resolve: resolve(4))
    result = task.map(lambda x: x + 3).fork(lambda x: x, lambda y: y)
    assert result == 7


# Generated at 2022-06-12 05:45:24.418263
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(10)
    task = task.map(lambda arg: arg + arg)
    assert task.fork(lambda x: x, lambda x: x) == 20

    task = Task.reject(10)
    task = task.map(lambda arg: arg + arg)
    assert task.fork(lambda x: x, lambda x: x) == 10



# Generated at 2022-06-12 05:45:30.478193
# Unit test for method bind of class Task
def test_Task_bind():
    def task(reject, resolve):
        resolve(5)

    def task_to_resolve(reject, resolve):
        resolve('another_task')

    task_original = Task(task)
    task_resolved = Task(task_to_resolve)

    assert task_original.bind(lambda x: task_resolved).fork(lambda x: None, lambda x: x) == 'another_task'



# Generated at 2022-06-12 05:45:41.572927
# Unit test for method map of class Task
def test_Task_map():
    """
    Test work of the method map of class Task
    """
    mock_value_1 = 'resolved'
    mock_value_2 = 'rejected'
    mock_function_1 = lambda value: value.capitalize()
    mock_function_2 = lambda value: Task.reject(value.upper())
    mock_function_3 = lambda value: Task.of(value.lower())
    mock_function_4 = lambda value: value * 2
    mock_function_5 = lambda value: value.swapcase()

    # compose mock functions
    composed_mock_function_1 = compose(mock_function_1, mock_function_2)
    composed_mock_function_2 = compose(mock_function_1, mock_function_3)

# Generated at 2022-06-12 05:45:47.985986
# Unit test for method bind of class Task
def test_Task_bind():
    def reject(value):
        assert False

    def resolve(value):
        assert value == 2

    comment = '#' * 100

# Generated at 2022-06-12 05:45:52.132524
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    expected = Task.of(2)
    actual = Task.of(1).map(mapper)
    assert expected.fork(lambda x: x, lambda x: x) == actual.fork(lambda x: x, lambda x: x)



# Generated at 2022-06-12 05:45:57.580132
# Unit test for method bind of class Task
def test_Task_bind():
    def inc(value):
        return Task.of(value + 1)

    assert  Task(lambda reject, resolve: resolve(1)).bind(inc).fork(None, lambda value: value) == 2
    assert  Task(lambda reject, resolve: reject(1)).bind(inc).fork(lambda value: value, None) == 1