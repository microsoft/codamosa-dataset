

# Generated at 2022-06-12 05:36:11.232730
# Unit test for method bind of class Task
def test_Task_bind():
    def map_plus_1(value):
        return Task.of(value + 1)

    def assert_equal_Task(value, expected):
        task = Task.of(value).bind(map_plus_1)
        assert task.fork(lambda arg: 0, lambda arg: arg) == expected

    assert_equal_Task(1, 2)
    assert_equal_Task(0, 1)
    assert_equal_Task(-1, 0)


# Generated at 2022-06-12 05:36:20.851782
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Check behavior Task.bind method
    """
    def resolve(x):
        return Task.of(x+1)

    def reject(x):
        return Task.reject(x+1)

    def fork_resolved(reject, resolve):
        return resolve(40)

    def fork_rejected(reject, _):
        return reject(20)

    assert Task(fork_resolved).bind(resolve).fork(lambda x: x, lambda _: "fail") == 41
    assert Task(fork_resolved).bind(reject).fork(lambda x: x, lambda _: "fail") == 21
    assert Task(fork_rejected).bind(resolve).fork(lambda x: x, lambda _: "fail") == 21

# Generated at 2022-06-12 05:36:30.620383
# Unit test for method bind of class Task
def test_Task_bind():
    def bind_with_resolve_mapper(arg):
        def resolve_mapper(reject, resolve):
            resolve(arg * 2)

        return Task(resolve_mapper)

    def bind_with_reject_mapper(arg):
        def reject_mapper(reject, resolve):
            reject(arg * 2)

        return Task(reject_mapper)

    def fork_with_resolve(reject, resolve):
        resolve(123)

    def fork_with_reject(reject, resolve):
        reject(123)

    task = Task(fork_with_resolve).bind(bind_with_resolve_mapper)
    assert task.fork(is_rejected, is_resolved) == 246


# Generated at 2022-06-12 05:36:35.004466
# Unit test for method map of class Task
def test_Task_map():
    # arrange
    t1 = Task.of(1)
    def incr(x): return x + 1
    # act
    t2 = t1.map(incr)
    # assert
    assert 2 == t2.run(lambda v: v, lambda v: v), "Task map method error"


# Generated at 2022-06-12 05:36:42.336480
# Unit test for method bind of class Task
def test_Task_bind():
    def f(reject, resolve):
        resolve(2)

    def fn(value):
        return Task(lambda reject, resolve: resolve(value * 2))

    t = Task(f)
    assert t.fork(None, lambda x: x * 2) == 4
    assert t.map(lambda x: x * 2).fork(None, lambda x: x) == 4

# Generated at 2022-06-12 05:36:44.954245
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    assert task.map(lambda x: x + 1).fork(lambda x: False, lambda x: x) == 2



# Generated at 2022-06-12 05:36:49.173474
# Unit test for method map of class Task
def test_Task_map():
    def side_effect(rejected, resolved):
        resolve("side_effect")

    def mapper(value):
        return value + "_mapped"

    task = Task(side_effect)
    assert task.map(mapper).fork("", resolve) == "side_effect_mapped"


# Generated at 2022-06-12 05:36:54.411798
# Unit test for method bind of class Task
def test_Task_bind():
    def _function(value):
        return Task.of(value + 1)

    assert Task(lambda _, resolve: resolve(0)).bind(_function).fork(
        lambda x: error(),
        lambda x: assertEqual(x, 1)
    )

test_Task_bind()


# Generated at 2022-06-12 05:37:00.806092
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for check bind method in class Task.
    Use Task.of to create a resolved Task and then bind function with return new
    resolved Task. It's enough check type of result instance.
    """
    from nose.tools import assert_is_instance
    def sum(arg):
        return arg + arg

    test = Task.of(4).bind(lambda arg: Task.of(sum(arg)))
    assert_is_instance(test, Task)

# Generated at 2022-06-12 05:37:06.732772
# Unit test for method bind of class Task
def test_Task_bind():
    fn_assert = (
        lambda x: Task.of(x + 11),
        lambda x: Task.reject(x + 22),
    )

    for fn in fn_assert:
        assert_ok = Task(lambda _, resolve: resolve(1)).bind(fn).fork(
            assert_,
            lambda result: assert_(result)
        )
        assert_fail = Task(lambda _, resolve: resolve(2)).bind(
            lambda x: Task(lambda _, resolve: resolve(x))
        ).bind(
            lambda x: Task(lambda reject, _: reject(x))
        ).fork(
            assert_,
            lambda result: assert_(result)
        )
        assert_ok
        assert_fail


# Generated at 2022-06-12 05:37:14.667393
# Unit test for method map of class Task
def test_Task_map():
    value = Task.of(2).map(lambda x: x * 3).fork(lambda x: x, lambda x: x)
    assert value == 6

    value = Task.reject(2).map(lambda x: x * 3).fork(lambda x: x, lambda x: x)
    assert value == 2


# Generated at 2022-06-12 05:37:21.320752
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve("test value")

    def map(value):
        return Task.of(value + " map")

    def map2(value):
        return Task.of(value + " map2")

    task = Task(fork)

    assert task.bind(lambda _: None).fork(None, None) is None
    assert task.bind(map).map(map2).fork(None, lambda value: value) == "test value map map2"



# Generated at 2022-06-12 05:37:30.280933
# Unit test for method bind of class Task
def test_Task_bind():
    def fork_add_3(reject, resolve):
        return resolve(1 + 3)

    def fork_add_rejected(reject, resolve):
        return reject(1 + 3)

    def fork_add_any(reject, resolve):
        return reject(1 + 3)

    def fn(value):
        def fork(reject, resolve):
            return resolve(value)
        return Task(fork)

    task_add_3 = Task(fork_add_3)

    task_add_rejected = Task(fork_add_rejected)

    task_add_any = Task(fork_add_any)

    assert isinstance(task_add_3, Task)
    assert isinstance(task_add_3.bind(fn), Task)

# Generated at 2022-06-12 05:37:42.087992
# Unit test for method map of class Task
def test_Task_map():
    def to_upper(text):
        return text.upper()

    def to_html(text):
        if not text:
            return ''

        return '<span>%s</span>' % text

    hello_task = Task.of('Hello')
    hello_upper_task = hello_task.map(to_upper)
    assert 'HELLO' == hello_upper_task.fork(
        lambda arg: '',
        lambda arg: arg
    )

    hello_html_task = hello_upper_task.map(to_html)
    assert '<span>HELLO</span>' == hello_html_task.fork(
        lambda arg: '',
        lambda arg: arg
    )

    empty_html_task = Task.of(None).map(to_html)
    assert '' == empty_html

# Generated at 2022-06-12 05:37:46.684238
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(res):
        print(res)
        return Task.of(res)

    def reject(res):
        print(res)
        return Task.reject(res)

    Task(lambda _, resolve: resolve(1)).bind(resolve).fork(reject, resolve)




# Generated at 2022-06-12 05:37:53.170785
# Unit test for method map of class Task
def test_Task_map():
    """
    Take function, store it and call with Task value during calling fork function.
    Return new Task with result of called.
    """
    def mock_fork_fn(reject, resolve):
        reject('rejected')
        resolve('resolved')
    value = Task(mock_fork_fn).map(str.upper)
    assert value.fork(str, str.upper) == 'REJECTEDresolved'


# Generated at 2022-06-12 05:38:01.186068
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def exception_func(x):
        raise Exception('some problem')

    # resolve case

# Generated at 2022-06-12 05:38:12.658474
# Unit test for method map of class Task
def test_Task_map():
    # Function for testing
    def plus2(x):
        return x + 2

    # Functions for checking correct result
    def check_ok(x):
        return x == 4

    def check_err(x):
        raise Exception('Rejected with value {0}'.format(x))

    # Rejected Task
    assert Task.reject(10).map(check_ok).fork(
        lambda arg: True,
        lambda arg: False
    )

    # Resolved Task
    assert Task.of(2).map(check_ok).fork(
        lambda arg: False,
        lambda arg: True
    )

    # Checking transforming of Task
    # Rejected Task
    assert Task.reject(10).map(plus2).map(check_ok).fork(
        lambda arg: True,
        lambda arg: False
    )

# Generated at 2022-06-12 05:38:21.942636
# Unit test for method map of class Task
def test_Task_map():
    """
    Test basic functionality of Task map method.

    :returns: result of test
    :rtype: bool
    """
    def fork(reject, resolve):
        time.sleep(1)
        return resolve('test')

    task = Task(fork)
    mapped_task = task.map(lambda value: value + ' mapped')

    result = wrap(
        lambda maybe: assert_equal(maybe.get_or_else('failed'), 'test mapped')
    )(mapped_task.fork(lambda _: Maybe.nothing(), Maybe.of))

    return result


# Generated at 2022-06-12 05:38:27.724298
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(16)

    def fork2(reject, resolve):
        reject(18)

    task = Task(fork)
    task2 = Task(fork2)

    assert task.bind(lambda v: Task.of(v ** 2)).fork == (None, 256)
    assert task2.bind(lambda v: Task.of(v ** 2)).fork != (None, 256)


# Generated at 2022-06-12 05:38:36.810795
# Unit test for method bind of class Task
def test_Task_bind():
    def increment_number(number):
        return Task.of(number + 1)

    def test_function(number, expect):
        assert Task.of(number).bind(increment_number).fork(
            lambda x: x) == expect

    test_function(42, 43)
    test_function(0, 1)
    test_function(-3, -2)


# Generated at 2022-06-12 05:38:46.149933
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.reject(5).bind(lambda arg: arg + arg) == Task.reject(5)
    assert Task.of(5).bind(lambda arg: arg + arg) == Task.of(10)
    assert Task.of(5).bind(lambda arg: Task.of(arg + arg)) == Task.of(10)
    assert Task.of(5).bind(lambda arg: Task.of(arg + arg)).bind(lambda arg: arg + arg) == Task.of(20)
    assert Task.of(5).bind(lambda arg: Task.of(arg + arg)).bind(lambda arg: Task.of(arg + arg)) == Task.of(20)



# Generated at 2022-06-12 05:38:53.087627
# Unit test for method map of class Task
def test_Task_map():
    # create task with lambda add one to value
    task = Task(lambda reject, resolve: resolve(1))
    result_task = task.map(lambda value: value + 1)
    assert result_task.fork(lambda arg: arg, lambda arg: arg) == 2

    # create task with true value
    task2 = Task.of(True)
    result = task2.map(lambda value: not value)
    assert result.fork(lambda arg: arg, lambda arg: arg) == False

    # create rejected task
    task3 = Task(lambda reject, resolve: reject(False))
    result = task3.map(lambda value: not value).fork(
        lambda arg: arg,
        lambda arg: arg
    )
    assert result == False


# Generated at 2022-06-12 05:39:00.372241
# Unit test for method bind of class Task
def test_Task_bind():
    def fork_inner_reject(reject, resolve):
        resolve(1)

    def fork_inner_resolve(reject, resolve):
        reject(2)

    fork_inner = Task(fork_inner_resolve)
    fork_inner2 = Task(fork_inner_reject)

    def fork_reject(reject, resolve):
        reject(3)

    def fork_resolve(reject, resolve):
        resolve(4)

    fork = Task(fork_reject)
    fork2 = Task(fork_resolve)
    # fork2.fork(lambda arg: print(arg), lambda arg: print(arg))

    assert fork.bind(fork_inner.fork) == Task(fork_inner_reject)

# Generated at 2022-06-12 05:39:10.822428
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Testing method bind of Task class.
    In this method we use 2 mapper functions:
    1. simple mapper that return Task with stored value in resolve attribute
    2. mapper that return Task whose resolve attribute is the result of previous Task resolve attribute plus 1.
    """
    def simple_mapper(value):
        return Task.of(value)

    def incrementor(value):
        return Task.of(value + 1)

    task = Task.of(0).bind(simple_mapper).bind(incrementor)
    assert task.fork(lambda x: x, lambda x: x) == 1

    task = Task.of(0).bind(incrementor).bind(simple_mapper)
    assert task.fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-12 05:39:14.412003
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of('test')
    mapper = Task.of('mapped')

    result = task.bind(lambda value: mapper)

    assert result.fork(None, lambda arg: arg) == 'mapped'

# Generated at 2022-06-12 05:39:18.620623
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(1).bind(lambda x: Task.of(x + 2)).fork(
        lambda err: print("Error! {}".format(err)),
        lambda val: print("Value! {}".format(val)))



# Generated at 2022-06-12 05:39:22.776733
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value * 2

    task = Task.of(5)
    maped = task.map(mapper)

    assert maped is not task, "task.map should return not self"
    assert maped.fork(None, lambda value: value) == 10, "task.map is not work"


# Generated at 2022-06-12 05:39:32.017270
# Unit test for method map of class Task
def test_Task_map():
    def identity(x): return x

    # Create Task instance
    task = Task.of(42)

    # Create new instance with mapped result
    mapped = task.map(identity)

    # Create another mapped instance
    doubled = task.map(lambda x: 2 * x)

    # Check these instances are not equal
    is_equal = lambda a, b: a.fork(lambda x: b.fork(lambda y: x == y, lambda _: False),
                                   lambda x: b.fork(lambda _: False, lambda y: x == y))
    assert is_equal(mapped, doubled) is False


# Generated at 2022-06-12 05:39:38.652193
# Unit test for method bind of class Task
def test_Task_bind():
    class Query:
        def __init__(self, query):
            self.query = query

        def map(self, fn):
            return Query(fn(self.query))

    def query_to_task(query):
        if query.query != "":
            return Task.of((query.query, 1))
        else:
            return Task.reject(query)

    # be sure that we don't have query param in Query class
    def query_result_fn(query):
        return Task.of((query[0], query[1] * 2))

    # be sure that we always get 0 as query param
    def always_zero_fn(query):
        return Task.reject((query[0], 0))

    # be sure that we have query param in Query class
    def query_error_fn(query):
        return Task

# Generated at 2022-06-12 05:39:47.202082
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(2)

    assert Task(fork).bind(lambda value: Task.of(value * 2)).fork(lambda _: None, lambda resolved: resolved) == 4

# Generated at 2022-06-12 05:39:56.745118
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda value: Task.of(2)).fork(None, lambda value: 'ok') == 'ok'
    assert Task.reject('error').bind(lambda value: Task.of(2)).fork(lambda value: 'error', lambda value: 'ok') == 'error'
    assert Task.of(1).bind(lambda value: Task.reject('error')).fork(lambda value: 'error', lambda value: 'ok') == 'error'
    assert Task.reject('error').bind(lambda value: Task.of(2)).fork(lambda value: 'error', lambda value: 'ok') == 'error'


# Generated at 2022-06-12 05:40:07.332681
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Method bind of class Task
    """

# Generated at 2022-06-12 05:40:18.849271
# Unit test for method map of class Task
def test_Task_map():
    # type: () -> None
    def plus_1(a):
        # type: (int) -> int
        return a + 1

    def minus_1(a):
        # type: (int) -> int
        return a - 1

    def minus_2(a):
        # type: (int) -> int
        return a - 2

    def plus_2(a):
        # type: (int) -> int
        return a + 2

    assert Task.of(2).map(plus_1).fork(None, None) == 3
    assert Task.of(3).map(plus_1).map(plus_1).fork(None, None) == 5
    assert Task.of(3).map(minus_1).map(plus_1).map(plus_2).fork(None, None) == 5

# Generated at 2022-06-12 05:40:21.943722
# Unit test for method map of class Task
def test_Task_map():
    a = Task(lambda _, resolve: resolve(1))
    b = a.map(lambda arg: arg + 1)
    assert b.fork(lambda arg: arg + 1, lambda arg: arg + 1) == 3



# Generated at 2022-06-12 05:40:27.749297
# Unit test for method bind of class Task
def test_Task_bind():
    # If Task will be resolved with simple type, this type will be mapped
    # If Task will be resolved with Task, this Task will be mapped too.
    task = Task.of(10).map(lambda value: value + 1).bind(lambda value: Task.of(value + 2))
    assert task.fork(None, lambda arg: arg) == 13

    task = Task.of(10).map(lambda value: value + 1).bind(lambda value: Task.of(Task.of(value + 2)))
    assert task.fork(None, lambda arg: arg.fork(None, lambda arg_: arg_)) == 13


# Generated at 2022-06-12 05:40:34.719004
# Unit test for method map of class Task
def test_Task_map():
    """
    Take Task with int value, map it and check that result is Task with mapped value.
    
    >>> test_Task_map()
    """
    import pytest

    value = Task.of(1).map(lambda arg: arg + 1)
    assert value.fork(
        lambda arg: pytest.fail(arg),
        lambda arg: arg
    ) == 2



# Generated at 2022-06-12 05:40:42.552743
# Unit test for method map of class Task
def test_Task_map():
    def plus(arg):
        return arg + 1

    task = Task.of(1)

    assert task.fork(lambda x: x, lambda x: x) == 1
    assert task.map(plus).fork(lambda x: x, lambda x: x) == 2

    task = Task.of(Task.of(1))
    assert task.map(plus).fork(lambda x: x, lambda x: x) == Task.of(2)
    assert task.bind(plus).fork(lambda x: x, lambda x: x) == Task.of(2)


# Generated at 2022-06-12 05:40:47.349620
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    """
    def fake_resolve(resolve):
        return lambda _: resolve(12)

    def fake_task(_):
        def fork(_, resolve):
            return fake_resolve(resolve)
        return Task(fork)

    def fork(reject, resolve):
        return fake_task(resolve)

    task = Task(fork)

    assert task.fork(lambda x: x, lambda x: x) == 12


# Generated at 2022-06-12 05:40:50.532171
# Unit test for method map of class Task
def test_Task_map():
    data = "test"
    value = Task.of(data).map(lambda value: value * 2)

    assert value.fork(None, lambda value: value) == "testtest"



# Generated at 2022-06-12 05:41:06.331695
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return Task.of(str(value))

    def reject(value):
        return Task.reject(str(value))

    assert Task(resolve).map(lambda x: x + ' World!').fork(reject, resolve).fork(reject, resolve).fork(reject, resolve) == Task.of('Hello World!')


# Generated at 2022-06-12 05:41:16.119441
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    """
    # Define first function - 'mapper'
    def mapper(value):
        return Task.of(value + value)

    # Test with correct argument

# Generated at 2022-06-12 05:41:22.778407
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda reject, resolve: resolve(1)).bind(lambda value: Task.of(value + 1)).fork(lambda reject, resolve: resolve(1)) == 2
    assert Task(lambda reject, resolve: reject(1)).bind(lambda value: Task.of(value + 1)).fork(lambda reject, resolve: reject(1)) == 1


# Generated at 2022-06-12 05:41:34.077735
# Unit test for method map of class Task
def test_Task_map():
    """
    test task map function
    """

    def addOne(value):
        """
        add one to value in param

        :param value: value to add one
        :type value: int
        """
        return value + 1

    def subOne(value):
        """
        substract one to input value

        :param value: value to sub one
        :type value: int
        """
        return value - 1

    def test_map_pass(reject, resolve):
        """
        test function return passed value

        :param resolve: resolve function to pass value
        :type resolve: Function(A) -> Any
        """
        resolve(0)


# Generated at 2022-06-12 05:41:40.752512
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for check Task.bind.
    """

# Generated at 2022-06-12 05:41:44.405176
# Unit test for method map of class Task
def test_Task_map():
    t = Task.of(2)
    res = t.map(lambda i: i ** 2)
    # res.fork(lambda e: e, lambda v: v) # 4
    assert res.fork(lambda e: e, lambda v: v) == 4


# Generated at 2022-06-12 05:41:50.149854
# Unit test for method map of class Task
def test_Task_map():
    def add1(value):
        return value + 1

    def multiplyBy2(value):
        return value * 2

    assert Task.of(2).map(add1).fork(
        lambda err: err,
        lambda val: val
    ) == 3
    assert Task.of(3).map(add1).map(multiplyBy2).fork(
        lambda err: err,
        lambda val: val
    ) == 8

# Generated at 2022-06-12 05:41:56.724246
# Unit test for method bind of class Task
def test_Task_bind():
    actual = Task.of(10) \
        .map(lambda value_map: value_map * 2) \
        .bind(
            lambda value_bind1: Task.of(value_bind1 + 10) \
                .map(lambda value_map: value_map + 10) \
                .bind(
                    lambda value_bind2: Task.of(value_bind2 + 10)
                )
        )

    assert actual.fork(None, print) == 50


# Generated at 2022-06-12 05:42:03.426377
# Unit test for method bind of class Task
def test_Task_bind():
    reject_call_argument = []
    resolve_call_argument = []

    def reject(value):
        reject_call_argument.append(value)

    def resolve(value):
        resolve_call_argument.append(value)

    def fork(reject, resolve):
        return resolve(2)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork).map(mapper)
    value = task.fork(reject, resolve)
    print(value)

    assert reject_call_argument == []
    assert resolve_call_argument == [3]


# Generated at 2022-06-12 05:42:08.464719
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for bind method of class Task

    :return: None
    :rtype: None
    """
    input_task = Task.of(5)
    def test_fn(value):
        assert value == 5
        return Task.of(value + 1)

    assert input_task.bind(test_fn).fork(
        lambda value: None,
        lambda value: value
    ) == 6

test_Task_bind()

# Generated at 2022-06-12 05:42:42.089587
# Unit test for method map of class Task
def test_Task_map():
    assert Task\
        .of(1)\
        .map(lambda value: value + 1)\
        .fork(
            lambda value: None,
            lambda value: value
        ) == 2

    assert Task\
        .of(1)\
        .map(lambda value: value + 1)\
        .map(lambda value: value * 3)\
        .fork(
            lambda value: None,
            lambda value: value
        ) == 6

    assert Task\
        .of(1)\
        .map(lambda value: value + 1)\
        .map(lambda value: value * 3)\
        .map(lambda value: value - 1)\
        .fork(
            lambda value: None,
            lambda value: value
        ) == 17


# Generated at 2022-06-12 05:42:50.154167
# Unit test for method bind of class Task
def test_Task_bind():
    task1 = Task.of(["a", "b", "c"]) # task1: reject -> ["a", "b", "c"]
    task2 = task1.map(lambda x: x + ["d"]) # task2: reject -> ["a", "b", "c", "d"]
    task3 = task2.bind(lambda x: Task.of(["e", "f", "g"])) # task3: reject -> ["e", "f", "g"]
    result = task3.fork(
        lambda _: False,
        lambda _: True
    )
    assert result


# Generated at 2022-06-12 05:42:54.427155
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test object with Task resolve value.

    :rtype: object
    """
    return Task(lambda reject, resolve: resolve(
        Task.of(0)
            .bind(lambda arg: arg + 2)
            .bind(lambda arg: arg - 2)
    ))



# Generated at 2022-06-12 05:43:00.879359
# Unit test for method map of class Task
def test_Task_map():
    # Given
    task = Task.of(1)
    fn = lambda v: v + 1
    # When
    new_task = task.map(fn)
    assert new_task.fork is not task.fork
    # Then
    result = []
    new_task.fork(
        lambda arg: result.append("reject"),
        lambda arg: result.append(arg)
    )
    assert result == [2]


# Generated at 2022-06-12 05:43:06.603461
# Unit test for method map of class Task
def test_Task_map():
    # execute function, call fork function with result of function
    # and call resolve with this result
    task = Task(lambda reject, resolve: resolve(lambda x: x + 1))
    # call map with mapper function
    # return Task with result of mapped resolve
    result = task.map(lambda fn: fn(2))

    assert result.fork(
        lambda err: err,
        lambda val: val
    ) == 3


# Generated at 2022-06-12 05:43:14.521001
# Unit test for method map of class Task
def test_Task_map():
    def increment(value):
        return value + 1

    def stringify(value):
        return str(value)

    assert Task(lambda _, resolve: resolve(1)).map(increment).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 2

    assert Task(lambda _, resolve: resolve(1)).map(
        lambda arg: arg + 1
    ).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 2

    assert Task(
        lambda _, resolve: resolve(1)
    ).map(lambda arg: arg + 1) \
     .map(stringify).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == '2'



# Generated at 2022-06-12 05:43:18.690706
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1) \
        .map(lambda res: res + 1) \
        .map(lambda res: res + 1) \
        .fork(lambda err: err, lambda res: res) == 3



# Generated at 2022-06-12 05:43:25.134210
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(10)

    task = Task(fork)

    result = task \
        .bind(lambda x: Task.reject(x + 1)) \
        .bind(lambda x: Task.of(x + 1)) \
        .fork(
            lambda err: "err",
            lambda res: res
        )

    expected_value = "err"
    assert result == expected_value, 'test_Task_bind function returns %s, but must return %s' % (result, expected_value)

test_Task_bind()



# Generated at 2022-06-12 05:43:34.010429
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task.

    :returns: None
    :rtype: None
    """
    def test_fn(value):
        """
        Test mapping function.

        :param value: value to map
        :type value: A
        :returns: negated value
        :rtype: A
        """
        return -value

    assert Task.of(10).map(test_fn).fork(identity, identity) == -10
    assert Task.reject(10).map(test_fn).fork(identity, identity) == 10

if __name__ == '__main__':
    test_Task_map()

# Generated at 2022-06-12 05:43:43.767949
# Unit test for method bind of class Task
def test_Task_bind():
    # Test 1
    # Condition: original Task has resolve value
    # Result: new Task has resolve value
    # We test map method of class Task
    # 0. Arrange
    original_task = Task.of(1)
    expected_result = Task.of(2)
    # 1. Act
    actual_result = original_task.bind(
        lambda value: Task.of(value + 1)
    )
    # 2. Assert
    assert expected_result.fork(lambda value: False, lambda value: True) == actual_result.fork(lambda value: False, lambda value: True)

    # Test 2
    # Condition: original Task has reject value
    # Result: new Task has reject value
    # We test map method of class Task
    # 0. Arrange
    original_task = Task.reject(1)
   

# Generated at 2022-06-12 05:44:36.961218
# Unit test for method map of class Task
def test_Task_map():
    def map_fn(a):
        return a*2

    def fork(reject, resolve):
        return resolve(2)

    def test():
        return Task(fork).map(map_fn)

    t0 = test()

    assert t0.fork(None, lambda a: a) == 4


# Generated at 2022-06-12 05:44:41.073041
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        def run():
            resolve(1)

        Process(target=run).start()

    task = Task(fork)

    assert task.map(lambda value: value * 2).fork(lambda _: '', lambda value: value) == 2


# Generated at 2022-06-12 05:44:44.800663
# Unit test for method bind of class Task
def test_Task_bind():
    def f(arg):
        return Task.of(arg + '1')

    task = Task.of('3').bind(f)
    assert task.fork(None, lambda arg: arg) == '31'



# Generated at 2022-06-12 05:44:55.181277
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map(Function(value) -> B) -> Task[Function(resolve, reject -> A | B]
    """
    def resolve(arg):
        return arg

    def reject(arg):
        return arg

    ref_fn = lambda arg: arg + arg
    ref_arg = 10
    ref_res = 20
    ref_reject = None

    # test Task.map method with resolved container
    task = Task.of(ref_arg).map(fn=ref_fn)

    res = task.fork(reject=None, resolve=resolve)

    assert ref_res == res, "assert Task.map method with resolved container"

    # test Task.map method with rejected container
    task = Task.reject(ref_arg).map(fn=ref_fn)


# Generated at 2022-06-12 05:45:03.967039
# Unit test for method map of class Task
def test_Task_map():
    def check_map(fn, expected, value):
        task = Task.of(value)
        assert task.map(fn) == expected

    check_map(lambda value: value + 1, Task.of(2), 1)
    check_map(lambda value: value + '1', Task.of('11'), '1')
    check_map(lambda value: Task.of(value + 1), Task.of(2), 1)
    check_map(lambda value: Task.of(value + '1'), Task.of('11'), '1')


# Generated at 2022-06-12 05:45:08.325629
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of("foo")
    mappedTask = Task.of("mapped_foo")
    assert task.bind(lambda arg: mappedTask).fork(lambda x: x, lambda x: x) == "mapped_foo"

# Generated at 2022-06-12 05:45:13.372772
# Unit test for method map of class Task
def test_Task_map():
    def add_1(x): return x + 1
    def raise_error(x): raise Exception(x)
    input = 1
    task_success = Task.of(input)
    task_failure = Task.of(input).bind(raise_error)
    assert task_success.map(add_1).fork(lambda _: False, lambda x: x == 2)
    assert task_failure.map(add_1).fork(lambda x: isinstance(x, Exception), lambda _: False)


# Generated at 2022-06-12 05:45:21.712976
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test that bind method of Task class
    store passed function and call it during execution with fork.

    :return: success message
    """
    def mapper(value):
        return value

    class TestCase:
        called = False

        def task(self):
            return Task(lambda reject, resolve: resolve(True))

        def resolve_passed(self):
            return Task(lambda reject, resolve: resolve(True))

        def reject_passed(self):
            return Task(lambda reject, resolve: reject(True))

        def called_true(self, arg):
            self.called = True

    test = TestCase()

    task = Task.of(None).bind(test.task)
    assert task.fork(test.called_true, mapper)
    assert test.called


# Generated at 2022-06-12 05:45:27.061548
# Unit test for method bind of class Task
def test_Task_bind():
    def hello(name):
        return Task.of('Hello ' + name)

    def world(name):
        return Task.of('world of ' + name)

    assert Task.of('Vadim').bind(hello).bind(world).fork(lambda value: value, lambda value: value) == 'Hello world of Vadim'

test_Task_bind()


# Generated at 2022-06-12 05:45:30.877813
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x + 2).fork(None, lambda x: x) == 4
    assert Task.of('pizza').map(lambda x: x.upper()).fork(None, lambda x: x) == 'PIZZA'
