

# Generated at 2022-06-12 05:36:15.276384
# Unit test for method map of class Task
def test_Task_map():
    def test_case(task):
        def fn(value_of_task):
            return value_of_task + 1

        mapped = task.map(fn)
        expected_result = task.fork(lambda b: b, lambda a: a + 1)

        assert mapped.fork(lambda b: b, lambda a: a) == expected_result

    test_case(Task.of(1))
    test_case(Task.reject(1))


# Generated at 2022-06-12 05:36:19.149724
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        return Task.of(x + 1)

    def g(x):
        return Task.of(x * 2)

    value = Task.of(1).bind(f).bind(g)
    assert value.fork(lambda x: x, lambda x: x) == 4



# Generated at 2022-06-12 05:36:24.736065
# Unit test for method map of class Task
def test_Task_map():
    def value_one():
        return Task.of(1)

    def check_map_method(texture, expected_value):
        assert texture.map(lambda arg: arg + 5).fork(lambda arg: -1, lambda arg: arg) == expected_value

    check_map_method(
        value_one(),
        6
    )


# Generated at 2022-06-12 05:36:26.494304
# Unit test for method map of class Task
def test_Task_map():
    def switch(value):
        return not value

    assert Task.of(True).map(switch) == Task.of(False)



# Generated at 2022-06-12 05:36:34.605764
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Create Task with return function that reject with the value 1,
    then call bind with function that return Task with value 2 and return False.
    After that return True

    :returns: True | Flase
    :rtype: boolean
    """
    def rejected(value):
        return Task.reject(1)

    task1 = Task.of(1).bind(rejected)

    def resolve(value):
        return False

    def reject(value):
        return True

    assert task1.fork(reject, resolve)



# Generated at 2022-06-12 05:36:41.207470
# Unit test for method bind of class Task
def test_Task_bind():
    def f(a):
        return Task.of(a + 1)

    def g(a):
        return Task.reject(a + 1)

    assert Task.of(1).bind(f).fork(lambda _: 0, lambda x: x) == 2
    assert Task.reject(1).bind(g).fork(lambda x: x, lambda _: 0) == 2


# Generated at 2022-06-12 05:36:50.677739
# Unit test for method map of class Task
def test_Task_map():
    # Helper functions
    def add_one(x): return x + 1
    def multiply_by_two(x): return x * 2

    # Test function
    def test():
        # Case 1: map multiply_by_two to Task.of(2)
        assert Task.of(2).map(multiply_by_two).fork(lambda x: x, lambda x: x) == 4

        # Case 2: map add_one to Task.of(2)
        assert Task.of(2).map(add_one).fork(lambda x: x, lambda x: x) == 3

        # Case 3: map add_one to Task.reject(2)
        assert Task.reject(2).map(add_one).fork(lambda x: x, lambda x: x) == 2

    # Run test
    test()


# Generated at 2022-06-12 05:36:55.630023
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda reject, resolve: resolve(1)).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2
    assert Task(lambda reject, resolve: reject(1)).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-12 05:37:02.303922
# Unit test for method map of class Task
def test_Task_map():
    def test_with_Task_of_map(value, mapper, expected):
        result = Task.of(value).map(mapper)
        assert result.fork(None, None) == expected

    test_with_Task_of_map(1, lambda value: value + 1, 2)
    test_with_Task_of_map(2, lambda value: value + 1, 3)
    test_with_Task_of_map(3, lambda value: value + 1, 4)


# Generated at 2022-06-12 05:37:07.933969
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(Task.of) == Task.of(1)
    assert Task.of(1).bind(Task.reject) == Task.reject(1)
    assert Task.reject(1).bind(Task.of) == Task.reject(1)
    assert Task.reject(1).bind(Task.reject) == Task.reject(1)


# Generated at 2022-06-12 05:37:19.143993
# Unit test for method map of class Task
def test_Task_map():
    """
    Function for testing Task.map method.
    """
    # Function for set values as a result of Task.map function
    def add1(value):
        return value + 1

    # Function for set values as a result of Task.map function
    def multiply2(value):
        return value * 2

    # Create task for value 2
    task = Task.of(2)

    # Function in map call should be applied to argument of resolved task
    result = task.map(add1)
    assert result.fork(None, None) == 3

    # Check composition of map functions
    result = task.map(add1).map(multiply2)
    assert result.fork(None, None) == 6

    # Check reject result
    result = Task.reject(2).map(add1)

# Generated at 2022-06-12 05:37:27.916891
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a):
        return a + 3

    def mul(a):
        return Task.of(a * 2)

    def div(a):
        return Task.reject(a / 0)

    assert Task.of(1).bind(add).bind(add).bind(mul).bind(add).fork(identity, identity) == 13
    assert Task.of('error').bind(add).bind(mul).bind(add).fork(identity, identity) == 'error'
    assert Task.of(1).bind(div).bind(add).bind(mul).bind(add).fork(identity, identity) == 0

# Generated at 2022-06-12 05:37:39.678814
# Unit test for method bind of class Task

# Generated at 2022-06-12 05:37:44.778572
# Unit test for method map of class Task
def test_Task_map():
    first = 1000
    second = 2
    third = 3
    fourth = 4
    fifth = 5
    result = first / (second + third) * fourth + fifth
    Task.of(first).map(lambda it: it / (second + third)).map(lambda it: it * fourth).map(lambda it: it + fifth).fork(
        print,
        lambda it: console.assert_equal(it, result)
    )


# Generated at 2022-06-12 05:37:56.413211
# Unit test for method bind of class Task
def test_Task_bind():
    def sqr(x):
        return x**2

    def sum(x, y):
        return x + y

    def double(x):
        return x * 2

    def to_task(value):
        return Task.of(value)

    def fork_call(task):
        return task.fork(lambda reject: reject(None), lambda resolve: resolve(None))

    to_task(2).bind(lambda x: to_task(x)).bind(lambda x: to_task(sqr(x))).bind(lambda x: to_task(sum(x, 4))).bind(lambda x: to_task(double(x))).bind(lambda x: to_task(x/2))

# Generated at 2022-06-12 05:38:02.971183
# Unit test for method bind of class Task
def test_Task_bind():
    # Define function for test
    def fn_resolve_task(arg):
        return Task.of(arg * 3)

    def fn_resolve(arg):
        return arg + 1

    # Create Task
    test_task = Task.of(2)
    assert test_task.fork(lambda arg: arg, lambda arg: arg) == 2

    # Test bind
    bind_test_task = test_task.bind(fn_resolve_task)
    assert bind_test_task.fork(lambda arg: arg, lambda arg: arg) == 6

    # Test map
    map_test_task = test_task.bind(fn_resolve_task).map(fn_resolve)
    assert map_test_task.fork(lambda arg: arg, lambda arg: arg) == 7

# Generated at 2022-06-12 05:38:13.726933
# Unit test for method map of class Task
def test_Task_map():
    def fn_should_call(arg):
        return arg * 2

    storage = []
    fork_result = 100
    task = Task(lambda _, __: fork_result)

    assert task.fork(None, lambda res: storage.append(res)) == fork_result  # Call fork function
    assert storage == [fork_result]
    assert task.map(fn_should_call).fork(None, lambda res: storage.append(res)) == fork_result  # Call fork function
    assert storage == [fork_result, fork_result * 2]
    assert Task.reject(fork_result).map(fn_should_call).fork(_, lambda res: storage.append(res)) == fork_result  # Call fork function
    assert storage == [fork_result, fork_result * 2]


# Generated at 2022-06-12 05:38:17.258209
# Unit test for method map of class Task
def test_Task_map():
    def add(resolve, reject):
        resolve(9)

    assert Task(add).map(lambda x: x + 1).fork(
        lambda _: None,
        lambda arg: arg
    ) == 10


# Generated at 2022-06-12 05:38:22.260460
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task's bind method.
    """
    def mapper(value):
        return Task.of(value * 2)

    result = Task.of(2).bind(mapper).fork(
        lambda reason: None,
        lambda value: value
    )

    assert result == 4


# Generated at 2022-06-12 05:38:30.537208
# Unit test for method bind of class Task
def test_Task_bind():
    # return rejected task
    def rejected_fn(arg):
        return Task.reject(arg)

    # return resolved task
    def resolved_fn(arg):
        return Task.of(arg)

    # return nothing
    def nothing_fn(arg):
        return None

    assert Task(rejected_fn).reject(3).fork(lambda arg: arg, lambda arg: arg) == 3
    assert Task(resolved_fn).resolve(3).fork(lambda arg: arg, lambda arg: arg) == 3
    assert Task(nothing_fn).resolve(3).fork(lambda arg: arg, lambda arg: arg) == 3

# Generated at 2022-06-12 05:38:42.068828
# Unit test for method map of class Task
def test_Task_map():
    def add_1(value):
        return value + 1

    def double(value):
        return value * 2

    def test_positive():
        task = Task.of(2)
        task = task.map(add_1)
        assert task.fork(None, lambda value: value) == 3

    def test_with_another_map():
        task = Task.of(2)
        task = task.map(add_1)
        task = task.map(double)
        def try_assert():
            assert task.fork(None, lambda value: value) == 6
        assert task.fork(lambda value: False, try_assert)

    def test_with_reject():
        task = Task.reject('test')
        task = task.map(add_1)

# Generated at 2022-06-12 05:38:52.062922
# Unit test for method bind of class Task
def test_Task_bind():
    """ Unit test for method bind of class Task """
    def get_resolved_task_of_value(value):
        """
        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        def fork(_, resolve):
            return resolve(value)
        return Task(fork)

    def get_rejected_task_of_value(value):
        """
        :param value: value to store in Task
        :type value: A
        :returns: rejected Task
        :rtype: Task[Function(reject, _) -> A]
        """
        def fork(reject, _):
            return reject(value)
        return Task(fork)


# Generated at 2022-06-12 05:38:54.785765
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(10).map(lambda value: value * 2).fork(
        lambda value: value,
        lambda value: value
    ) == 20


# Generated at 2022-06-12 05:38:57.586573
# Unit test for method map of class Task
def test_Task_map():
    """Task should store left function and calling right function during calling fork."""
    assert Task.of(1).map(add(10)).fork(
        lambda left: fail(),
        lambda right: right
    ) == 11


# Generated at 2022-06-12 05:39:00.550386
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(None, lambda x: x) == 2


# Generated at 2022-06-12 05:39:03.690501
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(3).map(lambda x: x ** 2).fork(print, print)
    assert not result



# Generated at 2022-06-12 05:39:12.010186
# Unit test for method bind of class Task
def test_Task_bind():
    def test_reject():
        return Task.reject('value')

    def test_function_return_reject(value):
        return Task.reject(value)

    def test_function_return_resolve(value):
        return Task.of(value)

    def test_fork_called():
        task_called = Task(
            lambda _, __: 'called'
        )

        return task_called.bind(lambda x: Task.of(x))

    def test_reject_called(value_to_reject):
        return Task.reject(value_to_reject)

    assert test_reject().bind(
        lambda _: 'not_called'
    ) == 'value'

    assert test_reject().bind(
        lambda _: 'called'
    ) == 'value'


# Generated at 2022-06-12 05:39:23.039581
# Unit test for method bind of class Task
def test_Task_bind():
    value = 'value'

    class StoreTask(Task):
        def __init__(self, store, resolve):
            if store == value:
                resolve(value)
            else:
                super(StoreTask, self).__init__(
                    lambda reject, _: reject(store)
                )

    class ReturnTask(Task):
        def __init__(self):
            super(ReturnTask, self).__init__(
                lambda reject, resolve: resolve(value)
            )

    assert Task.of(value).fork(None, lambda arg: arg) == value
    assert Task.of(value).bind(ReturnTask).fork(None, lambda arg: arg) == value
    assert Task.of(value).bind(lambda store: StoreTask(store, value)).fork(None, lambda arg: arg) == value

    assert Task.reject

# Generated at 2022-06-12 05:39:27.215266
# Unit test for method map of class Task
def test_Task_map():
    def test1(result):
        assert(result == 1)

    def test2(result):
        assert(result == 2)

    Task.of(1).map(lambda item: item + 1).fork(lambda result: test2(result), test1)



# Generated at 2022-06-12 05:39:31.446503
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    result = task.map(lambda x: x * 2)

    assert result.fork(lambda reject: None, lambda resolve: resolve)() == 2


# Generated at 2022-06-12 05:39:39.845016
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        assert value == 'value'

    def reject(value):
        raise Exception('reject with: ' + value)

    def mapper(value):
        return Task.of(value + ' mapper')

    task = Task.of('value').bind(mapper)
    task.fork(reject, resolve)

# Generated at 2022-06-12 05:39:42.933543
# Unit test for method map of class Task
def test_Task_map():
    def add_one(number):
        return number + 1


# Generated at 2022-06-12 05:39:49.150636
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(2)

    def _reject(err):
        print('implement reject')

    def _resolve(value):
        print('implement resolve')

    task = Task(fork)
    task.bind(lambda value:
        Task.of(value + 2)
    )

    task.fork(_reject, _resolve)

test_Task_bind()

# Generated at 2022-06-12 05:39:52.146521
# Unit test for method bind of class Task
def test_Task_bind():
    def a():
        return Task.of(1).bind(lambda arg: Task.of(arg + 1))

    fork = a().fork(print, print)
    assert fork == 2



# Generated at 2022-06-12 05:39:59.631964
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Check if methods bind and map work correctly in class Task.
    """
    def add(value):
        return Task.of(value + 1)

    def substract(value):
        return Task.of(value - 1)

    result1 = Task.of(1).bind(add).bind(substract).fork(
        lambda a: 'Rejected',
        lambda a: a
    )

    result2 = Task.of(1).map(add).map(substract).fork(
        lambda a: 'Rejected',
        lambda a: a
    )

    assert result1 == result2


# Generated at 2022-06-12 05:40:03.874967
# Unit test for method bind of class Task
def test_Task_bind():
    resolved = Task.bind(Task.of(None), lambda _: Task(
        lambda reject, resolve: resolve(None)
    ))

    assert(resolved.fork(lambda _: None, lambda _: None) is None)


# Generated at 2022-06-12 05:40:10.307709
# Unit test for method map of class Task
def test_Task_map():
    """
    Test equality of instance type of Task and new Task after applying map method.
    """
    task = Task(lambda _, resolve: resolve(1))
    func = lambda arg: arg + 1
    assert isinstance(task.map(func), Task)

    task = Task(lambda _, resolve: reject(1))
    func = lambda arg: arg + 1
    assert isinstance(task.map(func), Task)


# Generated at 2022-06-12 05:40:20.455254
# Unit test for method map of class Task
def test_Task_map():
    def assert_helper(task, reject, resolve, value):
        task.fork(reject, resolve)

        assert_equal(reject_arg, None, "task should be resolve")
        assert_equal(resolve_arg, value, "task should be resolve with value")

    reject_arg = None
    resolve_arg = None

    def reject(arg):
        nonlocal reject_arg
        reject_arg = arg

    def resolve(arg):
        nonlocal resolve_arg
        resolve_arg = arg

    # Call map with lambda function
    task_value = 5
    task = Task.of(task_value).map(lambda x: x * 2)

    assert_helper(task, reject, resolve, task_value * 2)

    # Call map with function
    task_value = 2

# Generated at 2022-06-12 05:40:26.585061
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Function for test side-effect of bind function.
    """
    def fork(reject, resolve):
        def rejected_call():
            reject(4)
            return 5

        def resolve_call():
            resolve(4)
            return 6

        return resolve_call() + rejected_call()

    task = Task(fork)

    def bind(value):
        def fork(reject, resolve):
            resolve(value ** 2)

        return Task(fork)

    result = task.bind(bind).fork(identity, identity)
    assert result == 16, "Error bind"

# Generated at 2022-06-12 05:40:31.573917
# Unit test for method map of class Task
def test_Task_map():
    def mapFunc(value):
        assert value == 10
        return value - 3

    def forkFunc(_, resolve):
        return resolve(10)

    task = Task(forkFunc).map(mapFunc)

    assert task.fork(lambda _: False, lambda value: value == 7)

# Generated at 2022-06-12 05:40:38.682576
# Unit test for method bind of class Task
def test_Task_bind():
    def _reject(_):
        assert 0

    def _resolve(result):
        assert result == 4

    def _tranform(value):
        return Task.of(value + 2)

    Task.of(2).bind(_tranform).fork(_reject, _resolve)


# Generated at 2022-06-12 05:40:46.072985
# Unit test for method map of class Task
def test_Task_map():
    """
    Call method map of class Task with value of type int
    and mapper function, which increment argument and return str.

    Should return new Task with attribute resolve witch is Function(resolve, reject) -> str
    """
    task = Task.of(1)
    task_mapped = task.map(lambda x: str(x + 1))
    assert isinstance(task_mapped, Task)
    assert hasattr(task_mapped, 'fork')
    assert callable(task_mapped.fork)
    assert task_mapped.fork(lambda a: a, lambda a: a) == '2'


# Generated at 2022-06-12 05:40:50.738893
# Unit test for method map of class Task
def test_Task_map():
    # Task start
    task = Task.of(42)

    # Add mapper function
    new_task = task.map(lambda x: x + 1)

    # Expectation
    expected = Task.of(43)

    assert expected.fork(lambda x: x) == new_task.fork(lambda x: x)



# Generated at 2022-06-12 05:40:53.595085
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Method bind of class Task is unit test.
    """
    pass


# Generated at 2022-06-12 05:40:59.880732
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for behavior of method map for class Task

    :returns: True
    :rtype: Bool
    """
    def fork(reject, resolve):
        resolve(3)
        return 1

    def fn(value):
        return value + 1

    task = Task(fork)
    mapped = task.map(fn)

    assert mapped.fork(lambda x: 'err', lambda x: x) == 4
    return True


# Generated at 2022-06-12 05:41:08.760510
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind(fn) -> Task[reject, mapped_value]
    fn(value) -> Task[reject, mapped_value]
    """
    def mapper(x):
        """
        :param x: some value
        :type x: Int
        :returns: resolved Task with result of sum x with Int argument.
        :rtype: Task[Function(_, resolve) -> Int]
        """
        return Task.of(x + 1)

    t1 = Task.of(1)

    t2 = t1.bind(mapper)

    m1 = m1.bind(Task.of)

    assert t2.fork(lambda _: False, lambda x: x == 2)



# Generated at 2022-06-12 05:41:13.743862
# Unit test for method bind of class Task
def test_Task_bind():
    def task():
        return Task.of("test")

    def task_bind():
        return Task.of("test1").bind(lambda x: Task.of("test2"))

    assert task().fork(lambda x: x) == "test"
    assert task_bind().fork(lambda x: x) == "test2"

# Generated at 2022-06-12 05:41:19.862381
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Function for test of method bind for class Task
    """
    def test_function_for_Task(value, reject=lambda _: None, resolve=lambda _: None):
        """
        Function for testing of method bind

        :param value: value to store
        :type value: A
        :param reject: function to call if we want to reject task
        :type reject: Function(value) -> Any
        :param resolve: function to call if we want to resolve task
        :type resolve: Function(value) -> Any
        """
        reject(value)

    # Some value for testing
    value_to_store = 'test_value'

    # Create Task for testing
    task = Task(test_function_for_Task)

    # Create Task for testing map function

# Generated at 2022-06-12 05:41:26.832865
# Unit test for method bind of class Task
def test_Task_bind():
    def multiply_by_2(arg):
        return Task.of(arg * 2)

    def assert_equal(expected_value, task):
        result = task.fork(echo_reject, echo_resolve)
        assert result == expected_value, \
            "Expected value: " + str(expected_value) + "\n" + \
            "Actual value: " + str(result)

    task = Task(lambda _, resolve: resolve(1))

    assert_equal(2, task.bind(multiply_by_2))
    assert_equal(4, task.bind(multiply_by_2).bind(multiply_by_2))

test_Task_bind()

# Task, that return reject with value from getter

# Generated at 2022-06-12 05:41:35.828093
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a):
        return Task.of(a + 2)

    def reject(a):
        return Task.reject(a + 5)

    def test(a):
        return Task(
            lambda reject, resolve: resolve(a)
        )

    def test_reject(a):
        return Task(
            lambda reject, resolve: reject(a)
        )

    assert Task.of(5).bind(add).fork(lambda a: a, lambda a: a) == 7
    assert Task.of(5).bind(reject).fork(lambda a: a, lambda a: a) == 10
    assert Task.reject(5).bind(add).fork(lambda a: a, lambda a: a) == 10

# Generated at 2022-06-12 05:41:48.382506
# Unit test for method bind of class Task
def test_Task_bind():
    # Task with only reject
    reject_value = False
    def reject_handler(arg):
        nonlocal reject_value
        reject_value = arg

    reject_task = Task.reject(True)
    reject_task.fork(reject_handler, lambda _: None)

    assert reject_value

    # Task with bind.
    def fn(arg):
        return Task.of(arg)

    # Not called.
    def reject_handler(arg):
        assert False

    # Always called with "True".
    resolve_value = False
    def resolve_handler(arg):
        nonlocal resolve_value
        resolve_value = arg

    t = Task.of(True)
    t.bind(fn).fork(reject_handler, resolve_handler)

    assert resolve_value


# Generated at 2022-06-12 05:41:52.677817
# Unit test for method map of class Task
def test_Task_map():
    test1 = Task(lambda reject, resolve: resolve(1))
    assert test1.fork(lambda arg: None, lambda arg: arg) == 1

    test2 = test1.map(lambda arg: arg + 1)
    assert test2.fork(lambda arg: None, lambda arg: arg) == 2



# Generated at 2022-06-12 05:42:00.108811
# Unit test for method bind of class Task
def test_Task_bind():
    task1 = Task.of(1)
    task2 = Task.of(2)

    def mapper1(arg):
        return task1

    def mapper2(arg):
        return task2

    def mapper3(arg):
        return Task.of(arg + 2)

    def mapper4(arg):
        return Task.reject(arg + 3)

    assert task1.bind(mapper1).fork(None, None) == 1
    assert task1.bind(mapper2).fork(None, None) == 2
    assert task2.bind(mapper1).fork(None, None) == 1
    assert task2.bind(mapper2).fork(None, None) == 2

    assert task1.bind(mapper3).fork(None, None) == 3

# Generated at 2022-06-12 05:42:03.031059
# Unit test for method map of class Task
def test_Task_map():
    resolve = Task.of(1)
    result = resolve.map(lambda x: x * 2)

    assert result.fork(
        lambda err: print(err),
        lambda res: res
    ) == 2


# Generated at 2022-06-12 05:42:05.592575
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(2)).map(lambda x: x + 1).fork(lambda x: 0, lambda x: x) == 3



# Generated at 2022-06-12 05:42:12.457630
# Unit test for method bind of class Task
def test_Task_bind():
    # Define functions
    def f(x):
        return Task.of(x + 1)

    def g(x):
        return Task.of(x * 2)

    def h(x):
        return Task.of(x - 3)

    # Create Task with number 5,
    # and apply functions f, g and h with result of previous function,
    # and return result of last function
    task = Task.of(5).bind(f).bind(g).bind(h)

    # Get result of fork method
    result = task.fork(lambda x: x, lambda y: y)

    # Check result is equal 8
    assert result == 8


# Generated at 2022-06-12 05:42:15.408539
# Unit test for method map of class Task
def test_Task_map():
    def fn(arg):
        return arg * 2
    Task.of(3).map(fn).fork(
        lambda arg: print("rejected with", arg),
        lambda arg: print("resolved with", arg)
    )


# Generated at 2022-06-12 05:42:19.994573
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for fork method of Task class

    :returns: True if test ok, False - if failed
    :rtype: bool
    """
    def resolve(value):
        print(value)

    def reject(value):
        print(value)

    task = Task((lambda reject, resolve: resolve(2)))

    task.map(lambda x: x + 1).fork(reject, resolve)

    return True


# Generated at 2022-06-12 05:42:30.237035
# Unit test for method bind of class Task
def test_Task_bind():
    """
    This is first version of test of bind method of class Task.
    """
    def square(value):
        return value * value

    def add(value):
        return value + value

    def sub(value):
        return value - 10

    def divide_by_zero(value):
        return 1 / 0

    def test_correct_function(value):
        assert value == 12

    def test_zero_division(value):
        assert value == ZeroDivisionError

    def test_false_function(value):
        assert value == "False function"

    def test_false_function_2(value):
        assert value == "False function 2"

    correct_task = Task.of(1)\
        .map(square)\
        .map(add)\
        .map(sub)


# Generated at 2022-06-12 05:42:35.153672
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    """
    assert Task.of('test').bind(lambda arg: Task.of('test')).fork(lambda arg: arg, lambda arg: arg) == 'test'
    assert Task.reject(0).bind(lambda _: Task.of(1)).fork(None, None) == 0


# Generated at 2022-06-12 05:42:50.679365
# Unit test for method map of class Task
def test_Task_map():
    def square(x):
        return x ** 2

    def delay(resolve):
        return Task.of(5).fork(
            lambda arg: arg,
            lambda arg: resolve(arg)
        )

    def callback(resolve):
        return delay(resolve).map(square)

    assert callback(lambda arg: arg) == 25

# Generated at 2022-06-12 05:42:55.788335
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of('after bind').bind(lambda x: x + ': bind').fork(_, lambda x: x) == 'after bind: bind'
    assert Task.of(True).bind(lambda x: Task.of(x)).fork(_, lambda x: x) == True
    assert Task.reject('error').bind(lambda x: Task.reject('mapper error')).fork(lambda x: x, _) == 'error'



# Generated at 2022-06-12 05:43:02.804819
# Unit test for method map of class Task
def test_Task_map():
    def assert_equal(first, second):
        if first == second:
            print("OK")
        else:
            print("Error: %s <> %s" % (first, second))

    task = Task.of(1).map(lambda value: value + 1)

    assert_equal(task.fork(lambda arg: arg, lambda arg: arg), 2)

if __name__ == '__main__':
    test_Task_map()

# Generated at 2022-06-12 05:43:06.832870
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    single_resolved_value_task = Task.of(2)
    result_task = single_resolved_value_task.map(add_one)

    assert result_task.fork(
        lambda _: False,
        lambda value: value == 3
    )


# Generated at 2022-06-12 05:43:13.300511
# Unit test for method map of class Task
def test_Task_map():
    test_1 = Task.of(1).map(lambda x: x + 1)
    assert test_1.fork(lambda arg: arg, lambda arg: arg) == 2

    test_2 = Task.of(None).map(lambda x: x + 1)
    assert test_2.fork(lambda arg: arg, lambda arg: arg) == None

    test_3 = Task.reject(1).map(lambda x: x + 1)
    assert test_3.fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-12 05:43:18.393119
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value * 2

    def test(value):
        assert Task.of(value).map(mapper).fork(None, lambda o: o) == mapper(value)

    test(0)
    test(1)
    test(10)


# Generated at 2022-06-12 05:43:22.577210
# Unit test for method map of class Task
def test_Task_map():
    def add(value):
        return value + 1

    value = 1
    resolved = Task.of(value)
    bound = resolved.map(add)
    actual = bound.fork(None, lambda value: value)

    assert actual == 2, "Task map test failed"


# Generated at 2022-06-12 05:43:26.566983
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(a):
        return Task.of(a + 1)

    assert Task.of(2).bind(test_fn).fork(
        lambda e: e,
        lambda r: r
    ) == 3


# Generated at 2022-06-12 05:43:34.303599
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """
    @classmethod
    def add1(cls, value):
        return value + 1

    @classmethod
    def add2(cls, value):
        return value + 2

    def test():
        """
        Implementation of test case
        """

# Generated at 2022-06-12 05:43:44.019756
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind method of class Task.
    Test should not raise any exceptions.
    """
    def add_1(value):
        return value + 1

    def add_2(value):
        return value + 2

    def add_3(value):
        return value + 3

    def fail(error):
        pass

    def noop():
        pass

    task_of_0 = Task.of(0)

    task_of_1 = task_of_0.map(add_1)
    assert task_of_1.fork(noop, lambda value: value) == 1

    task_of_3 = task_of_1.bind(lambda value: Task.of(value + 2))
    assert task_of_3.fork(noop, lambda value: value) == 3

    task_of_4 = task

# Generated at 2022-06-12 05:44:15.280172
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task

    :returns: result of test
    :rtype: Bool
    """
    task = Task.of(1)
    new_task = task.bind(
        lambda arg: Task.of(arg + 1)
    )

    assert not task.fork(lambda arg: arg, lambda arg: False)
    assert new_task.fork(lambda arg: False, lambda arg: arg) == 2

    return True

# Generated at 2022-06-12 05:44:20.642549
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    task = Task.of(5).map(mapper)
    assert task.fork(lambda _: None, lambda value: value) == 6

    task = Task.reject(None).map(mapper)
    assert task.fork(lambda value: value, lambda _: None) == None


# Generated at 2022-06-12 05:44:23.077864
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2


# Generated at 2022-06-12 05:44:33.331065
# Unit test for method map of class Task
def test_Task_map():
    def is_string(value):
        return isinstance(value, str)

    def is_int(value):
        return isinstance(value, int)

    def get_int(value):
        return int(value)

    def resolve(value):
        return '#' + str(value)

    def reject(value):
        return "!" + str(value)

    task_1 = Task.of('5')
    task_2 = task_1.map(is_string)
    task_3 = task_1.map(is_int)
    task_4 = task_1.map(get_int)
    task_5 = task_1.map(is_int).map(get_int)
    task_6 = task_1.map(get_int).map(is_int)
    task_7 = task

# Generated at 2022-06-12 05:44:37.440424
# Unit test for method bind of class Task
def test_Task_bind():
    def func(reject, resolve):
        resolve(6)

    def mul(x):
        return Task(func)

    task = Task(func)
    assert task.bind(mul).fork(lambda e: e, lambda _: 'ok') == 'ok'


# Generated at 2022-06-12 05:44:42.412032
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for bind method of Task class.
    """
    @Task.of(2)
    def assert_result(value):
        assert value == 2

    def assert_reject(value):
        assert value == 'Rejected'

    def double(value):
        return Task.of(value * 2)

    Task.of(1).bind(double).fork(assert_reject, assert_result)



# Generated at 2022-06-12 05:44:49.840030
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    # Test value
    message = 'Hello World'

    # Ok callback
    def ok_handler(*_):
        print(message)

    # Error callback
    def error_handler(error):
        print(error)

    # Task with bind
    task = Task.of(message)
    task = task.bind(lambda message: Task.of(message))

    # Fork
    task.fork(error_handler, ok_handler)


# Generated at 2022-06-12 05:44:52.631054
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(add(3)).fork(
        lambda _: _,
        lambda value: value
    ) == 5


# Generated at 2022-06-12 05:44:55.462953
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map.
    """
    assert Task(lambda _, resolve: resolve(2)).map(lambda arg: arg + 2).fork(
        lambda _: None,
        lambda arg: arg
    ) == 4


# Generated at 2022-06-12 05:45:01.228019
# Unit test for method map of class Task
def test_Task_map():
    """
    tests Task map function.
    """
    def double(number):
        return number * 2

    task = Task.of(42)

    assert task.map(double).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 84


# Generated at 2022-06-12 05:45:53.092213
# Unit test for method map of class Task
def test_Task_map():
    def run(reject, resolve):
        return resolve("test")

    t = Task(run)
    fn = lambda a: a * 2

    assert t.map(fn).fork(None, lambda a: a) == "testtest"


# Generated at 2022-06-12 05:45:57.535222
# Unit test for method map of class Task
def test_Task_map():
    """
    Function check Task.of.map(...) implementation.
    """
    def add(value):
        return value + 1

    assert Task.of(1).map(add).map(add).fork(lambda x: x, lambda x: x) == 3


# Generated at 2022-06-12 05:46:02.931466
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Count sum of elements of list in Task(fork) way
    """
    args = [1,2,3,4]

    def fork(_, resolve):
        resolve(args)

    def mapper(value):
        return Task(lambda _, resolve: resolve(sum(value)))

    task = Task(fork)

# Generated at 2022-06-12 05:46:11.039369
# Unit test for method map of class Task
def test_Task_map():
    """
    Case of map method of Task class.

    :returns: True if Tasks is correct
    :rtype: Boolean
    """
    def add(x, y):
        return x + y

    def fn(a):
        return Task.of(add(a, a))

    def assert_(a, b):
        return a  == b

    Task.of(1).map(lambda x: add(1, x)).fork(lambda _: False, lambda x: assert_(x, 2))
    Task.of(1).bind(fn).fork(lambda _: False, lambda x: assert_(x, 2))

    return True
