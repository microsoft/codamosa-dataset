

# Generated at 2022-06-12 05:36:07.863322
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda arg: arg + 1)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-12 05:36:19.078163
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test function example:
        1. Call Task.of with some value.
        2. Call bind with some function.
        3. In this example we calling bind with Task.of function, so after step 3
           we will call bind again with result of 2.
        4. After step 3 we will call bind again with some function that takes argument
           and return result of execution of Task.of method with argument.

    :return: None
    """
    example_value = "example"

    def map_fn(x):
        return Task.of(x * 2)

    def compose_fn(x):
        return Task.of(x * 2)


# Generated at 2022-06-12 05:36:22.998290
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    result = task.bind(lambda arg: Task.of(arg + 1))

    assert result.fork(lambda arg: arg, lambda arg: arg) == 2

# Generated at 2022-06-12 05:36:30.964694
# Unit test for method bind of class Task
def test_Task_bind():
    def identity(x):
        return Task.of(x)

    def addThree(x):
        return Task.of(x + 3)

    def mulTwo(x):
        return Task.of(x * 2)

    assert Task.reject(0).bind(addThree).fork(lambda e: e, lambda _: None) is 0,\
        'first argument of fork should be a reject'

    assert Task.of(1).bind(identity).fork(lambda _: None, lambda s: s) is 1,\
        'second argument of fork should be a resolve'

    assert Task.of(3).bind(addThree).bind(mulTwo).fork(lambda _: None, lambda s: s) is 12,\
        'should apply two tasks'

# Generated at 2022-06-12 05:36:40.589254
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """

    def test_bind_fork_resolve():
        """
        Case with resolve branch of fork method
        """
        def fork(reject, resolve):
            resolve(1)

        def bind_fn(value):
            def fork_fn(reject, resolve):
                resolve(value)
                return 1

            return Task(fork_fn)

        task = Task(fork)
        bind_res = task.bind(bind_fn)
        assert bind_res.fork(lambda e: None, lambda v: v) == 1

    def test_bind_fork_reject():
        """
        Case with reject branch of fork method
        """
        def fork(reject, resolve):
            reject(1)


# Generated at 2022-06-12 05:36:47.313142
# Unit test for method bind of class Task
def test_Task_bind():
    """
    [Task Class]
    [Task.bind()]
    [Test Task]
    """
    def fun(arg):
        return Task.of(arg)

    def bind(value):
        return Task.of(value).bind(fun).bind(fun)

    assert bind(True).fork(lambda x: False, lambda x: x)

    def fun(arg):
        return Task.reject(arg)

    def bind(value):
        return Task.of(value).bind(fun).bind(fun)

    assert bind(True).fork(lambda x: x, lambda x: x)

# Generated at 2022-06-12 05:36:55.218862
# Unit test for method map of class Task
def test_Task_map():
    def task_1(resolve, reject):
        resolve(10)

    def task_2(resolve, reject):
        resolve(20)

    @Task.of(30)
    def task_3(reject, resolve):
        reject(40)
        resolve(50)

    @Task.of(60)
    def task_4(_, resolve):
        resolve(70)
        reject(80)

    def task_5(reject, resolve):
        resolve(90)
        reject(100)

    task_1_mapped = Task(task_1).map(lambda value: value * 2)
    task_2_mapped = Task(task_2).map(lambda value: value * 2)
    task_3_mapped = task_3.map(lambda value: value * 2)
    task_3_

# Generated at 2022-06-12 05:36:58.721009
# Unit test for method map of class Task
def test_Task_map():
    t = Task.of(1)
    t1 = t.map(lambda x: x + 1)
    assert t1.fork(None, lambda x: x) == 2



# Generated at 2022-06-12 05:37:02.987439
# Unit test for method map of class Task
def test_Task_map():
    def success(value):
        return Task.of(value)

    def fail(value):
        return Task.reject(value)

    assert success(1).map(lambda value: value + 1).fork(None, lambda value: value) == 2

    assert fail(1).map(lambda value: value + 1).fork(lambda value: value, None) == 1


# Generated at 2022-06-12 05:37:11.478142
# Unit test for method bind of class Task
def test_Task_bind():
    def return_True(arg):
        """
        Return True.

        :param arg: argument
        :return: True
        """
        return True

    def return_False(arg):
        """
        Return False.

        :param arg: argument
        :return: False
        """
        return False

    def return_None(arg):
        """
        Return None.

        :param arg: argument
        :return: None
        """
        return None

    assert Task.of(1).bind(lambda x: Task.of(1)).bind(lambda _: Task.of(2)).fork(return_False, return_True) == True

    assert Task.of(1).bind(lambda _: Task.reject(1)).bind(lambda _: Task.of(2)).fork(return_True, return_False) == True

   

# Generated at 2022-06-12 05:37:25.210074
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_time(a):
        def resolve(b):
            return a + b

        def reject(b):
            return a - b

        return Task(lambda reject, resolve: resolve(b))

    def resolve_time_plus(a):
        def resolve(b):
            return a + b

        def reject(b):
            return a - b

        return Task(lambda reject, resolve: resolve(a + b))

    def reject_time_plus(a):
        def resolve(b):
            return a + b

        def reject(b):
            return a - b

        return Task(lambda reject, resolve: reject(b))

    expect(
        Task.of(1).bind(resolve_time).fork(None, print)
    ).to_equal(2)


# Generated at 2022-06-12 05:37:37.403563
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Bind methods of class Task:
    with Task.reject return this Task,
    with Task.resolve return passed Task.
    """

    def reject(arg):
        return Task.reject(arg)

    def resolve(arg):
        return Task.of(arg)

    assert Task.of('a').bind(reject) == Task.reject('a')
    assert Task.reject('a').bind(resolve) == Task.reject('a')
    assert Task.reject('a').bind(reject) == Task.reject('a')

    assert Task.of('a').bind(resolve) == Task.of('a')
    assert Task.of('a').bind(lambda arg: Task.of(arg)) == Task.of('a')

# Generated at 2022-06-12 05:37:46.351549
# Unit test for method map of class Task
def test_Task_map():
    """
    Task map method.
    """
    def divide_by_2(number):
        """
        Divide number by 2.

        :param number: parametr to divide
        :type number: int
        :returns: number divided by 2
        :rtype: int
        """
        return number // 2

    def multiply_by_2(number):
        """
        Multiply number by 2.

        :param number: parametr to multiply
        :type number: int
        :returns: number multiplied by 2
        :rtype: int
        """
        return number * 2

    assert Task.of(2).map(divide_by_2).fork(
        lambda arg: 'reject',
        lambda arg: arg
    ) == 1

# Generated at 2022-06-12 05:37:52.508381
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of('one')
    new_task = task.map(lambda x: x + ' two')
    assert new_task.fork(
        lambda reject_value: True,
        lambda resolve_value: False
    ) == False
    assert new_task.fork(
        lambda reject_value: False,
        lambda resolve_value: resolve_value
    ) == 'one two'


# Generated at 2022-06-12 05:37:59.192691
# Unit test for method bind of class Task
def test_Task_bind():

    def foo(x):
        return Task.of(x + 1)

    def baz(x):
        return Task.of(x * 10)

    def err(x):
        return Task.reject(x - 1)

    assert Task.of(1).bind(foo).bind(baz).fork(None, lambda v: v) == 20

    try:
        assert Task.of(10).bind(err).fork(None, lambda v: v) == None
    except Exception as e:
        assert e == 9


# Generated at 2022-06-12 05:38:02.845382
# Unit test for method map of class Task
def test_Task_map():
    value = 1
    task = Task.of(value).map(lambda x: x * 1000)
    assert task.fork(lambda _: None, lambda result: result) == value * 1000


# Generated at 2022-06-12 05:38:07.006773
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map function with sync function.
    """
    task = Task.of(1).map(lambda x: x + 1)
    assert task.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-12 05:38:12.387449
# Unit test for method map of class Task
def test_Task_map():
    def test_mapper(value):
        return value + 1

    class TestTask(Task):
        def __init__(self, value):
            Task.__init__(
                self,
                lambda reject, resolve: resolve(value)
            )


# Generated at 2022-06-12 05:38:18.535514
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(10)

    def add(n):
        return n + 10

    def mul(n):
        return n * 10

    task = Task(fork)
    assert task.map(add).map(mul).fork(None, lambda x: x) == 200


# Generated at 2022-06-12 05:38:22.478778
# Unit test for method bind of class Task
def test_Task_bind():
    def function_to_test(value):
        return Task.of(value + 1)

    res = Task.of(1).bind(function_to_test).fork(lambda: None, lambda arg: arg)

    assert res == 2


# Generated at 2022-06-12 05:38:31.196365
# Unit test for method map of class Task
def test_Task_map():
    def mock_Task_fork(sub_resolve, sub_reject):
        sub_resolve(1)

    def mock_fn(arg):
        assert arg == 1
        return 42

    task = Task(mock_Task_fork)
    result = task.map(mock_fn)
    assert result.fork(lambda reject: mock_fn(reject), lambda resolve: mock_fn(resolve)) == 42


# Generated at 2022-06-12 05:38:38.200647
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(i):
        return Task(lambda _, resolve: resolve(i + 1))

    def value():
        return Task(lambda _, resolve: resolve(1))

    def reject(i):
        return Task(lambda reject, _: reject(i))

    assert value().bind(fn).fork(None, lambda i: i) == 2
    assert reject(2).bind(fn).fork(lambda i: i, None) == 2



# Generated at 2022-06-12 05:38:44.653417
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    task = Task.of(1).map(mapper)
    assert task.fork(lambda _, reject: reject(0), lambda _, resolve: resolve(0)) == 2

    task = Task.reject(1).map(mapper)
    assert task.fork(lambda _, reject: reject(0), lambda _, resolve: resolve(0)) == 1


# Generated at 2022-06-12 05:38:51.746270
# Unit test for method bind of class Task
def test_Task_bind():
    clock = []

    def result(reject, resolve):
        clock.append('fork')
        resolve(10)

    task = Task(result)
    mapped = task.bind(lambda x: Task.of(x + 1) if x > 7 else Task.reject(x))
    task.fork(lambda x: print('reject', x), lambda x: print('resolve', x))
    print(clock)

    clock = []
    mapped.fork(lambda x: print('reject', x), lambda x: print('resolve', x))
    print(clock)

# test_Task_bind()


# Generated at 2022-06-12 05:38:55.690689
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(arg):
        def fork(_, resolve):
            return resolve(arg)

        return Task(fork)

    task = Task.of(1)
    task_result = task.bind(fn)
    assert task_result.fork(lambda _: False, lambda _: True)

# Generated at 2022-06-12 05:39:07.553049
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x, y): return x + y

    def task(reject, resolve):
        resolve(1)

    def task_with_error(reject, resolve):
        reject('error')

    def task_that_return_error(reject, resolve):
        reject('error')

    def task_to_bind(reject, resolve):
        resolve(2)

    def task_to_bind_with_error(reject, resolve):
        reject('another error')

    assert Task(task).bind(lambda x: Task.of(add(x, x))).fork(lambda x: print(x), lambda x: x) == 2
    assert Task(task_with_error).bind(lambda x: Task.of(add(x, x))).fork(lambda x: print(x), None) == 'error'

# Generated at 2022-06-12 05:39:19.469819
# Unit test for method bind of class Task
def test_Task_bind():
    task_of_1 = Task.of(1)
    task_of_2 = Task.of(2)
    task_of_mined_1 = Task.of(-1)

    # Check reject with Task.reject
    def reject_never(_, reject):
        return reject(2)

    def resolve_always(resolve, _):
        return resolve(1)


# Generated at 2022-06-12 05:39:31.030962
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    """

    # Task[Function(resolve, reject) -> 'hello']
    first_task = Task.of('hello')

    # Task[Function(resolve, reject) -> 'world']
    second_task = Task.of('world')

    # Task[Function(resolve, reject) -> 'hello world']
    result_task = first_task.bind(lambda first_value: second_task.map(lambda second_value: first_value + ' ' + second_value))

    # set result task value to result
    result = []
    result_task.fork(lambda arg: None, lambda arg: result.append(arg))

    # check that result task value is 'hello world'
    assert result[0] == 'hello world'


# Generated at 2022-06-12 05:39:35.762157
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(0)

    new_task = task.map(lambda x: x + 1)

    assert new_task.fork(lambda x: x, lambda x: x) == 1

    # assert task.map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 1



# Generated at 2022-06-12 05:39:42.660508
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        print(value)
        return 2 * value

    def reject(value):
        print(value)

    task = Task(lambda rejector, resolver: resolver(1))

    assert task.map(resolve).fork(reject, resolve) == 2

    task = Task(lambda rejector, resolver: rejector(1))

    assert task.map(resolve).fork(reject, resolve) == 1


# Generated at 2022-06-12 05:39:58.466199
# Unit test for method map of class Task
def test_Task_map():

    # create some task with resolve and reject values
    task1 = Task.of(1)
    task2 = Task.of(2)
    task_reject = Task.reject(1)

    # create sum function
    def sum(arg1):
        return arg1 + 2

    # create some task with mapped values
    task3 = task1.map(sum)
    task4 = task2.map(sum)
    task_reject_map = task_reject.map(sum)

    # test for map function for Task class
    assert task1.fork(None, None) == 1
    assert task2.fork(None, None) == 2
    assert task_reject.fork(None, None) == 1

    assert task3.fork(None, None) == 3

# Generated at 2022-06-12 05:40:03.974534
# Unit test for method map of class Task
def test_Task_map():
    def t_(value):
        return Task(lambda reject, resolve: resolve(value))

    def inc(value):
        return value + 1

    assert t_(1).map(inc).fork(lambda arg: arg, lambda arg: arg) == 2
    assert t_(1).bind(inc).fork(lambda arg: arg, lambda arg: arg) == 2



# Generated at 2022-06-12 05:40:13.501271
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind func
    Test values and types
    """
    def get_task_with_result(value):
        """
        Take value and return resolved Task with it.

        :param value: value to store in Task and return.
        :type value: Number
        :returns: resolved Task with stored value.
        :rtype: Task[Function(_, resolve) -> Number]
        """
        return Task.of(value)

    assertTask(
        Task.of(10)
            .bind(get_task_with_result)
            .fork(lambda reject: reject(), lambda resolve: resolve()),
        10
    )


# Generated at 2022-06-12 05:40:17.775559
# Unit test for method map of class Task
def test_Task_map():
    def example(arg):
        return arg

    def example_second(arg):
        return arg

    def example_fail(arg):
        return Task.of(arg)

    def example_fail_second(arg):
        return Task.of(arg)

    assert Task(example).map(example_second).fork(
        lambda arg: print(arg),
        lambda arg: print(arg)
    ) == None

    assert Task(example_fail).map(example_fail_second).fork(
        lambda arg: print(arg),
        lambda arg: print(arg)
    ) == None



# Generated at 2022-06-12 05:40:26.448157
# Unit test for method map of class Task
def test_Task_map():
    success_value = Task.of(2)
    assert success_value.fork(None, lambda value: value) == 2

    failed_value = Task.reject(2)
    assert failed_value.fork(lambda value: value, None) == 2

    value = Task.of(2).map(lambda value: value ** 2).fork(None, lambda value: value)
    assert value == 4

    value = Task.of(2).map(lambda value: value).map(lambda value: value).fork(None, lambda value: value)
    assert value == 2

    value = Task.reject(2).map(lambda value: value).map(lambda value: value).fork(lambda value: value, None)
    assert value == 2


# Generated at 2022-06-12 05:40:38.332056
# Unit test for method bind of class Task
def test_Task_bind():
    def square(x):
        return x * x

    def throw_error(x):
        if x < 10:
            return Task.reject(x)
        else:
            return Task.of(x)

    def tester(x):
        return Task.of(x)

    def Promise(fn):
        def run_fn(*args):
            return Task.of(fn(*args))
        return run_fn

    @Promise
    def pythagoras(a, b):
        """
        :param a: side A
        :type a: number
        :param b: side B
        :type b: number
        :returns: side C (pythagoras)
        :rtype: number
        """
        return math.sqrt(a*a + b*b)

    task1 = Task.re

# Generated at 2022-06-12 05:40:46.117085
# Unit test for method map of class Task
def test_Task_map():
    class TestClass:
        """
        Test class with property.
        """
        def __init__(self):
            self.value = 'value'

        @property
        def prop(self):
            """
            Property for test.
            """
            return self.value

    def test_fn(value):
        """
        Test function.
        """
        if callable(getattr(value, 'prop', None)):
            return value.prop
        return None


    obj = TestClass()
    assert Task.of(obj).map(test_fn) == obj.value
    assert Task.of(obj).bind(Task.of).map(test_fn) == obj.value

# Generated at 2022-06-12 05:40:51.730988
# Unit test for method map of class Task
def test_Task_map():

    def sum_two (value):
        return value + 2

    # map is not called yet
    assert Task.of(1).map(sum_two) == Task(
        lambda _, resolve: resolve(
            sum_two(1)
        )
    )
    # result of map is called
    assert Task.of(1).map(sum_two).fork(lambda x: x, lambda x: x) == 3


# Generated at 2022-06-12 05:41:01.380046
# Unit test for method map of class Task
def test_Task_map():
    a = 1
    b = 2

    @Task.of
    def add_b(a, b):
        return a + b

    @Task.of
    def add_c(b):
        return b + 1

    @Task.of
    def add_d(a, b, c):
        return a + b + c

    task = Task.of(a)

    task_a = task.map(lambda v: v + b).fork(lambda v: v, lambda v: v)
    assert task_a == a + b

    task_b = task.bind(add_b).map(add_c).bind(add_d).fork(lambda v: v, lambda v: v)
    assert task_b == a + b + 1 + 1


# Generated at 2022-06-12 05:41:09.220084
# Unit test for method map of class Task
def test_Task_map():
    # test_Task_map_with_correct_function_and_value
    def test_Task_map_with_correct_function_and_value():
        assert Task.of(2).map(lambda x: x ** 2).fork(lambda _: None, lambda res: res) == 4

    # test_Task_map_with_correct_function_and_rejected_value
    def test_Task_map_with_correct_function_and_rejected_value():
        assert Task.reject(2).map(lambda x: x ** 2).fork(lambda res: res, lambda _: None) == 2

    test_Task_map_with_correct_function_and_value()
    test_Task_map_with_correct_function_and_rejected_value()



# Generated at 2022-06-12 05:41:26.992720
# Unit test for method bind of class Task

# Generated at 2022-06-12 05:41:32.912381
# Unit test for method bind of class Task
def test_Task_bind():
    task_resolve = Task.of(1)
    task_reject = Task.reject(1)

    assert task_resolve.bind(lambda arg: Task.of(arg)).fork(identity, identity) == 1
    assert task_reject.bind(lambda arg: Task.of(arg)).fork(identity, identity) == 1


# Generated at 2022-06-12 05:41:35.876532
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task's bind method.
    """
    assert Task(lambda r, s: s(1)) \
    .bind(lambda v: Task.of(v + 5)) \
    .fork(lambda e: '', lambda v: v) == 6


# Generated at 2022-06-12 05:41:45.797536
# Unit test for method bind of class Task

# Generated at 2022-06-12 05:41:55.497145
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for correct work of Task.bind method.
    """
    test_case_1 = Task(
        lambda reject, resolve: resolve(2)
    ).bind(
        lambda arg: Task(
            lambda reject, resolve: resolve(arg * 2)
        )
    )

    test_case_2 = Task(
        lambda reject, resolve: reject(2)
    ).bind(
        lambda _: Task(
            lambda reject, resolve: resolve(3)
        )
    )
    assert test_case_1.fork(lambda _: None, lambda arg: arg) == 4
    assert test_case_2.fork(lambda arg: arg, lambda _: None) == 2


# Generated at 2022-06-12 05:41:57.699563
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x + 2).fork(
        lambda x: False,
        lambda x: x == 4
    )


# Generated at 2022-06-12 05:42:01.853266
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    task = Task.of(1).map(add_one)

    @task.fork
    def reject(value):
        assert False, 'should not be called'
    def resolve(value):
        assert value == 2, 'should be called with incremented argument'



# Generated at 2022-06-12 05:42:06.028543
# Unit test for method map of class Task
def test_Task_map():
    """
    test_Task_map: check if map method return same result if function has same result with it argument.
    """
    value = 2

    def fn(value):
        return value

    assert Task.of(value).map(fn).fork.__name__ == Task.of(value).fork.__name__


# Generated at 2022-06-12 05:42:14.148190
# Unit test for method bind of class Task
def test_Task_bind():
    """
    import test_Task_bind
    test_Task_bind.run()
    """

    def test_function_resolve_1(reject, resolve):
        resolve(1)

    def test_function_resolve_2(reject, resolve):
        resolve(2)

    def test_function_reject(reject, resolve):
        reject(1)

    task = Task(test_function_resolve_1).bind(lambda x: Task(test_function_resolve_2))
    assert task.fork(lambda x: x, lambda x: x) == 2

    task2 = Task(test_function_resolve_1).bind(lambda x: Task(test_function_reject))
    assert task2.fork(lambda x: x, lambda x: x) == 1



# Generated at 2022-06-12 05:42:17.267876
# Unit test for method bind of class Task
def test_Task_bind():
    value = 1

    def assert_fn(result):
        assert result == value

    task = Task.of(value)
    task_mapped = task.bind(lambda arg: Task.of(arg * 2))

# Generated at 2022-06-12 05:42:45.620371
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for map method of Task class

    :returns: None

    >>> Task.of(2).map(lambda x: x + 1)
    Task(lambda _, resolve: resolve(3))

    >>> Task.reject(2).map(lambda x: x + 1)
    Task(lambda reject, _: reject(2))
    """
    pass


# Generated at 2022-06-12 05:42:50.930997
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + '_1'

    def fork(reject, resolve):
        resolve('ok' + '_0')

    task = Task(fork)

    assert(task.map(fn).fork(lambda _: 'fail', lambda value: value) == 'ok_0_1')

test_Task_map()



# Generated at 2022-06-12 05:42:56.512745
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    """
    def resolve_fn(arg):
        """
        Resolve function for Task.
        """
        return Task.of(arg + 1)

    def reject_fn(arg):
        """
        Reject function for Task.
        """
        return Task.of(arg + 1)

    task = Task.of(1)
    assert task.fork(reject_fn, resolve_fn).fork(lambda a: not a, lambda a: a == 2)

# Generated at 2022-06-12 05:43:07.306359
# Unit test for method map of class Task
def test_Task_map():
    """
    Take function, store it and call with Task value during calling fork function.
    Return new Task with result of called.

    :param fn: mapper function
    :type fn: Function(value) -> B
    :returns: new Task with mapped resolve attribute
    :rtype: Task[Function(resolve, reject -> A | B]
    """
    def add(a, b):
        return a + b

    def f1(c):
        if c[0] < 0:
            return Task.reject(c[0])
        else:
            return Task.of(c[1])

    def f2(c):
        if c[0] == 1:
            return Task.of(c[1] * 10)
        else:
            return Task.reject(ValueError('Error'))


# Generated at 2022-06-12 05:43:11.029233
# Unit test for method map of class Task
def test_Task_map():
    def taskify(resolve, reject):
        return Task.of(10)

    assert Task(taskify).map(lambda value: value * 2).fork(lambda reject, resolve: resolve(reject)) == 20


# Generated at 2022-06-12 05:43:14.203770
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task map method.
    """
    def add_one(num):
        return num + 1

    obj = Task.of(2)
    result = obj.map(add_one)

    assert result.fork(
        lambda err: {},
        lambda value: value
    ) == 3


# Generated at 2022-06-12 05:43:19.973243
# Unit test for method bind of class Task
def test_Task_bind():
    # --- Prepare test data
    # --- Run tested method
    result = Task.of(1)\
                 .bind(lambda x: Task.of(x + 1))\
                 .bind(lambda x: Task.of(x + 1))\
                 .bind(lambda x: Task.reject(x + 1))

    # --- Check result
    assert result == Task.reject(4)

# Generated at 2022-06-12 05:43:26.870363
# Unit test for method bind of class Task
def test_Task_bind():
    def res(msg):
        assert msg == 'reject'

    def res1(m):
        return Task.of(m + '1')

    def res2(m):
        return Task.of(m + '2')

    def res4(m):
        return Task.reject(m)

    # Returned Task contains mapped result of first Task,
    # but not from second
    v = Task(lambda reject, resolve: resolve('value'))
    v.bind(res1).bind(res2).fork(res, res)

    # Returned Task contains nothing, because second Task was reject
    v = Task(lambda reject, resolve: resolve('value'))
    v.bind(res1).bind(res4).fork(res, res)

    # Returned Task contains nothing, because second Task was reject

# Generated at 2022-06-12 05:43:36.330398
# Unit test for method map of class Task
def test_Task_map():
    def get_number(resolve, reject):
        return resolve(42)

    def test_resolve(resolve, reject):
        return resolve(None)

    def test_reject(resolve, reject):
        return reject(None)

    def map_number(x):
        return x * 2

    def map_reject(x):
        return x * 2

    def throw_error(x):
        return x.s

    task_42 = Task(get_number).map(map_number)
    task_84 = Task(get_number).map(map_number).map(map_number)

    assert task_42.fork(lambda arg: arg, lambda arg: arg) == 84
    assert task_84.fork(lambda arg: arg, lambda arg: arg) == 168

# Generated at 2022-06-12 05:43:45.523893
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(msg):
        print("Receive value %s" % msg)

    def reject(msg):
        print("Receive error %s" % msg)

    def func(value):
        return Task.of("%s!" % value)

    def error_func(value):
        return Task.reject("%s!" % value)

    Task.of("Hello").bind(func).bind(func).fork(reject, resolve)
    Task.of("Hello").bind(func).bind(error_func).fork(reject, resolve)
    Task.of("Hello").bind(error_func).bind(func).fork(reject, resolve)
    Task.of("Hello").bind(error_func).bind(error_func).fork(reject, resolve)

# Generated at 2022-06-12 05:44:21.766704
# Unit test for method bind of class Task
def test_Task_bind():
    # prepare
    def take_error(result):
        assert result == "error"
        return "ok"

    def take_ok(result):
        assert result == "ok"
        return "ok"

    # test
    assert Task.reject("error").bind(take_error).fork(
        take_error,
        take_ok
    ) == "ok"
    assert Task.of("ok").bind(take_ok).fork(
        take_error,
        take_ok
    ) == "ok"

test_Task_bind()

# Generated at 2022-06-12 05:44:28.530324
# Unit test for method bind of class Task
def test_Task_bind():
    def bind_fork(reject, resolve):
        def fork(error, value):
            if error:
                return reject(error)
            resolve(value)
        return fork

    def method(x):
        return Task(bind_fork(x))

    task = Task(lambda _, resolve: resolve(42))
    assert task.bind(method).fork(
        lambda error: error,
        lambda value: value
    ) == [[42], 42]


# Generated at 2022-06-12 05:44:35.511306
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_arg(val):
        return Task.of(val)

    def reject_arg(val):
        return Task.reject(val)

    assert Task.of(1).bind(resolve_arg) == Task.of(1)
    assert Task.reject(1).bind(resolve_arg) == Task.reject(1)
    assert Task.of(1).bind(reject_arg) == Task.reject(1)
    assert Task.reject(1).bind(reject_arg) == Task.reject(1)
    # assert Task.bind(Task.of(1), )


# Generated at 2022-06-12 05:44:45.236323
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test result of Task method bind.
    """
    # pylint: disable=unnecessary-lambda
    def test(value):
        return Task.of(value)

    assert(
        Task.of(42).bind(lambda value: Task.of(len(str(value)))).fork(
            lambda rejected: rejected,
            lambda resolved: resolved
        ) == 2
    )

    assert(
        Task.of(42).bind(lambda value: Task.reject(value + 1)).fork(
            lambda rejected: rejected,
            lambda resolved: resolved
        ) == 43
    )

    assert(
        Task.reject(43).bind(lambda value: Task.reject(value + 1)).fork(
            lambda rejected: rejected,
            lambda resolved: resolved
        ) == 44
    )


# Generated at 2022-06-12 05:44:55.261720
# Unit test for method map of class Task
def test_Task_map():
    """
    Test mapping function to Task with resolved state.
    """
    def add_three(value):
        return value + 3

    def test():
        task = Task.of(2)
        task = task.map(add_three)

        task.fork(
            lambda value: raises(AssertionError(), "Task shouldn't be rejected"),
            lambda value: eq(value, 5)
        )

    test()

    def test_reject():
        task = Task.reject(2)
        task = task.map(add_three)

        task.fork(
            lambda value: eq(value, 2),
            lambda value: raises(AssertionError(), "Mapped task shouldn't be resolved")
        )

    test_reject()


# Generated at 2022-06-12 05:44:59.361818
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 2).fork(
        lambda err: 'Failure',
        lambda value: value
    ) == 3


# Generated at 2022-06-12 05:45:05.029380
# Unit test for method bind of class Task
def test_Task_bind():
    def inc(x):
        return x + 1

    def double(x):
        return x * 2

    def test_fn(x):
        return Task.of(x).map(inc).bind(lambda x: Task.reject(double(x)))

    assert Task.of(2).bind(test_fn).fork(lambda x: x, lambda _: None) == 6


# Generated at 2022-06-12 05:45:09.012015
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(None).bind(lambda _: Task.of("OK")).fork(None, None)
    assert result == "OK"



# Generated at 2022-06-12 05:45:11.224968
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(5)
    task2 = task.bind(lambda x: Task.of(x + 1))
    assert task2.fork(None, lambda x: x == 6)


# Generated at 2022-06-12 05:45:16.219465
# Unit test for method bind of class Task
def test_Task_bind():
    def addThenDouble(number):
        return Task.of(number + 1).map(lambda x: x * 2)

    assert Task.of(1).bind(addThenDouble).fork(
        lambda x: None,
        lambda x: x
    ) == 4


# Generated at 2022-06-12 05:45:46.002849
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(3)
    task = task.map(lambda x: x + 1)
    assert task.fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-12 05:45:52.757380
# Unit test for method bind of class Task
def test_Task_bind():
    def task_with_result(arg):
        return Task.of(lambda val: val + 1)(arg)

    def task_with_error(arg):
        return Task.of(lambda val: val + 1)(arg - 1)

    assert Task.of(1).bind(task_with_result).fork(None, lambda a: a) == 2
    assert Task.of(2).bind(task_with_error).fork(lambda a: a, None) == 2


# Generated at 2022-06-12 05:46:03.258086
# Unit test for method map of class Task
def test_Task_map():
    def test_1(resolve):
        resolve(Task.of(5).map(lambda x: x + 10))

    def test_2(resolve):
        resolve(Task.of(5).map(lambda x: x + 10).map(lambda x: x + 5))

    def test_2(resolve):
        resolve(Task.reject(5).map(lambda x: x + 10))

    def test_3(resolve):
        resolve(Task.reject(5).map(lambda x: x + 10).map(lambda x: x + 5))
