

# Generated at 2022-06-12 05:36:13.426988
# Unit test for method map of class Task

# Generated at 2022-06-12 05:36:21.821712
# Unit test for method map of class Task
def test_Task_map():
    def resolve(val):
        resolve.result.append(val)

    def reject(val):
        reject.result.append(val)

    def good_fn(x):
        good_fn.result.append(x)
        return x + 1

    def bad_fn(x):
        bad_fn.result.append(x)
        raise ValueError(x)

    def good_task():
        good_task.result.append('exec')
        return Task.of(1)

    resolve.result = []
    reject.result = []
    good_fn.result = []
    bad_fn.result = []
    good_task.result = []
    assert [1] == Task.of(1).map(good_fn).fork(reject, resolve).result
    assert [1] == good_fn.result
   

# Generated at 2022-06-12 05:36:26.379825
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(arg):
        return Task.of(arg * 2)

    task = Task.of(1)
    task_of_2 = task.bind(mapper)

    assert task_of_2.fork(None, lambda arg: arg) == 2

# Generated at 2022-06-12 05:36:36.397913
# Unit test for method bind of class Task
def test_Task_bind():
    def onCanceled(reject):
        return reject('canceled')

    def onLoaded(resolve):
        return resolve({'data': 'result'})

    def firstFn(data):
        promise = Task(onCanceled)
        return promise

    def secondFn(data):
        promise = Task(onLoaded)
        return promise

    task = Task(onLoaded)

    assert task.fork(lambda data: data, lambda data: data) == {'data': 'result'}
    assert task.bind(firstFn).fork(lambda data: data, lambda data: data) == 'canceled'
    assert task.bind(secondFn).fork(lambda data: data, lambda data: data) == {'data': 'result'}


# Generated at 2022-06-12 05:36:46.007112
# Unit test for method map of class Task
def test_Task_map():

    # Mock function to work with
    def mock_reject(arg):
        raise Exception(arg)

    def mock_resolve(arg):
        return arg

    # Mock function to work with
    def mock_fn(arg):
        return arg + 1

    # Result of mapping mock_fn at mock_resolved_task
    result = mock_resolved_task.map(mock_fn)
    assert result.fork(mock_reject, mock_resolve) == 2

    # Result of mapping mock_fn at mock_rejected_task
    result = mock_rejected_task.map(mock_fn)
    with pytest.raises(Exception):
        result.fork(mock_reject, mock_resolve)


# Generated at 2022-06-12 05:36:48.988059
# Unit test for method bind of class Task
def test_Task_bind():
    def test(resolve):
        return Task.of(resolve('value'))

    assert Task.of('something').bind(test).fork(lambda _: None, lambda arg: arg) == 'value'



# Generated at 2022-06-12 05:36:52.580302
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda num: num + 1)
    assert task.fork(None, lambda x: x) == 2


# Generated at 2022-06-12 05:37:02.051491
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        if value == 'foo':
            return Task.reject('Error')
        elif value == 'bar':
            return Task.of(
                'baz'
            )
        else:
            return Task.of(
                'foo'
            )

    def test_failure(handler, _, value):
        assert handler(value) == 'Error'

    def test_success(handler, value, _):
        assert handler(value) == 'baz'

    task = Task.of('bar')

    task.fork(
        lambda value: test_failure(fn, None, value),
        lambda value: test_success(fn, value, None)
    )

# Generated at 2022-06-12 05:37:10.997254
# Unit test for method bind of class Task
def test_Task_bind():
    def task_fork_reject_int(reject, resolve):
        return reject(10)

    def task_fork_resolve_int(reject, resolve):
        return resolve(20)

    def task_fork_resolve_none(reject, resolve):
        return resolve(None)

    task_reject = Task(task_fork_reject_int)
    task_resolve = Task(task_fork_resolve_int)

    def not_None(value):
        return Task(task_fork_resolve_none) if value is not None else Task.reject(None)

    assert task_resolve.bind(not_None).fork(
        lambda value: True,
        lambda value: False
    ) is False


# Generated at 2022-06-12 05:37:19.529439
# Unit test for method bind of class Task
def test_Task_bind():
    def test_Task_bind_passed(reject, resolve):
        resolve('passed')

    def test_Task_bind_failed(reject, resolve):
        reject('failed')

    test_passed = Task(test_Task_bind_passed)
    test_failed = Task(test_Task_bind_failed)

    def second_step(_, resolve):
        resolve('second_step')

    def first_step(_, resolve):
        resolve('first_step')

    def first_step_failed(_, resolve):
        resolve('first_step_failed')

    @Task.of
    def result_step(_, resolve):
        resolve('result_step')


# Generated at 2022-06-12 05:37:27.418074
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(arg):
        assert arg == 'Hello'
        return Task.of('World')

    def rejector(arg):
        assert arg == 'Error'

    def resolver(arg):
        assert arg == 'World'

    task = Task.of('Hello').bind(mapper)
    task.fork(rejector, resolver)


# Generated at 2022-06-12 05:37:39.118429
# Unit test for method bind of class Task
def test_Task_bind():
    def add1(x):
        return x + 1

    def mul2(x):
        return x * 2

    def div4(x):
        return x / 4

    def err_fn(err):
        def fn(x):
            return err(x)

        return Task(fn)

    def assert_err(expected):
        def fn(actual):
            assert actual == expected
            return True

        return fn

    def make_task(fn):
        return Task(lambda _, resolve: resolve(fn))

    assert Task.of(42).bind(err_fn(assert_err(42))).map(add1).bind(make_task).map(mul2).bind(make_task).map(div4).bind(make_task).fork() == Task.of(0).fork()

# Generated at 2022-06-12 05:37:42.458772
# Unit test for method map of class Task
def test_Task_map():
    val = Task.of("a").map(lambda a: a + "b")

# Generated at 2022-06-12 05:37:48.074458
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(x):
        return Task.of(x + 1)

    def mapper2(x):
        return Task.of(x * x)

    task = Task.of(1).bind(mapper).bind(mapper2)
    assert task.fork(lambda x: x, lambda x: x) == 4, 'Task.bind works incorrect'


# Generated at 2022-06-12 05:37:55.327482
# Unit test for method bind of class Task
def test_Task_bind():
    def get_task(value):
        return Task.of(value).map(lambda _: Lazy(lambda: 2 * _))

    # chain together two tasks
    assert Task.of(1).bind(get_task).fork(None, lambda x: x.value) == 2

    # chain together four tasks
    assert Task.of(1).bind(get_task).bind(get_task).bind(get_task).bind(get_task).fork(None, lambda x: x.value) == 16


# Generated at 2022-06-12 05:37:58.606835
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value * 2)

    result = Task.of(2).bind(mapper)
    assert result.fork(lambda _: False, lambda x: x == 4), 'fail on execution'


# Generated at 2022-06-12 05:38:06.720148
# Unit test for method map of class Task
def test_Task_map():
    """Test map method of class Task"""

    def fake_reject(arg):
        """Fake reject function for test"""

# Generated at 2022-06-12 05:38:10.200834
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)

    def add_5(value):
        return value + 5

    assert task.map(add_5).fork(lambda x: None, lambda x: x) == 6


# Generated at 2022-06-12 05:38:10.901021
# Unit test for method map of class Task
def test_Task_map():
    check_Task_map(Resolve(3))
    check_Task_map(Reject('error'))


# Generated at 2022-06-12 05:38:12.882917
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(6).map(lambda x: x * 7).fork(lambda x: x, lambda x: x) == 42


# Generated at 2022-06-12 05:38:18.438012
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda val: Task.of(val + 1)).fork(
        lambda value: None,
        lambda value: value
    ) == 2

# Generated at 2022-06-12 05:38:22.747047
# Unit test for method map of class Task
def test_Task_map():
    def test(value):
        return value

    assert Task.of('a').map(test).fork(lambda x: x, lambda x: x) == 'a'
    assert Task.of(2).map(test).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-12 05:38:27.818657
# Unit test for method map of class Task
def test_Task_map():
    add_one = Task.of(1).map(lambda result: result + 1)
    add_two = Task.of(1).map(lambda result: result + 2)
    assert add_one.fork(lambda x: x, lambda x: x) == 2
    assert add_two.fork(lambda x: x, lambda x: x) == 3


# Generated at 2022-06-12 05:38:33.132903
# Unit test for method bind of class Task
def test_Task_bind():
    def test_A(resolve, reject):
        return reject(ValueError('test_A'))

    def test_B(resolve, reject):
        return resolve(1)

    t = Task(test_B)
    t_with_mapper = t.bind(lambda _: Task(test_A))
    assert t_with_mapper.fork(
        lambda arg: isinstance(arg, ValueError),
        lambda arg: arg == 1
    )



# Generated at 2022-06-12 05:38:42.147437
# Unit test for method map of class Task
def test_Task_map():
    """
    JSON decoder didn't return dict,
    but collections.OrderedDict that not have __getitem__ method
    """

    def foo(dct):
        return dct['title'].strip()

    def fn(reject, resolve):
        resolve(json.loads('{ "title": "  Hello, World!  " }'))

    def foobar(reject, resolve):
        resolve(foo(json.loads('{ "title": "  Hello, World!  " }')))

    def foobar_with_map(reject, resolve):
        resolve(Task.of(json.loads('{ "title": "  Hello, World!  " }'))
                .map(foo).fork(reject, resolve))

    # resolve have to be a function

# Generated at 2022-06-12 05:38:47.074732
# Unit test for method map of class Task
def test_Task_map():
    def task_fork(reject, resolve):
        return resolve(1)

    def fn1(x):
        return x + 1

    task = Task(task_fork).map(fn1)

    assert task.fork(None, lambda arg: arg == 2)


# Generated at 2022-06-12 05:38:51.953652
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + value

    # of method of Task return new Task with stored value
    task = Task.of(1)

    # map will be called with stored value and mapper function
    task = task.map(mapper)

    # calling of fork attribute of task will called function from task.fork(reject, resolve)
    # and it will called mapped function with stored value
    assert task.fork(None, lambda value: value) == 2


# Generated at 2022-06-12 05:38:59.994524
# Unit test for method bind of class Task
def test_Task_bind():
    """
    test method Task.bind
    """
    from utils.utils import test
    from operator import add

    @test
    def test_Task_bind_fail():
        """
        test method Task.bind with rejected Task
        """
        def bind(reject, resolve):
            return reject(100)

        def fail(resolve, reject):
            return reject(200)

        task = Task(bind)
        mapped_task = task.bind(lambda _: Task(fail))

        def func(reject, resolve):
            return mapped_task.fork(reject, resolve)

        return Task(func).fork(
            lambda value: value == 200,
            lambda value: False
        )

    @test
    def test_Task_bind_ok():
        """
        test method Task.bind with resolved Task
        """

# Generated at 2022-06-12 05:39:04.589087
# Unit test for method map of class Task
def test_Task_map():
    @Task.of
    def add(a, b):
        return a + b

    assert add.map(lambda r: r * 10).fork( lambda _: None, lambda r: r ) == (3 + 4) * 10


# Generated at 2022-06-12 05:39:12.290126
# Unit test for method map of class Task
def test_Task_map():
    """
    Tests for Task.map.
    """
    @Task.of(10)
    def task(reject, resolve):
        """
        Function to create task.

        :param reject: function to reject task
        :param resolve: function to resolve task
        """
        resolve(10)

    @task.map(lambda value: value * 2)
    def double_task(reject, resolve):
        """
        Function to create task with map function.

        :param reject: function to reject task
        :param resolve: function to resolve task
        """
        resolve(10)


# Generated at 2022-06-12 05:39:24.340138
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        print('resolved with value: ', value)

    def reject(value):
        print('rejected with value: ', value)

    def add1(value):
        return value + 1

    def add2(value):
        return value + 2

    def add3(value):
        return value + 3

    def multiply10(value):
        return value * 10

    value = 10

    Task.reject(value) \
        .map(add1) \
        .map(add2) \
        .map(add3) \
        .map(multiply10) \
        .fork(reject, resolve)

    Task.of(value) \
        .map(add1) \
        .fork(reject, resolve)


# Generated at 2022-06-12 05:39:35.181085
# Unit test for method bind of class Task
def test_Task_bind():
    """
    test_Task_bind :: Task a -> Task b -> Task b
    test_Task_bind t1 t2 = t1 >>= (\_ -> t2)
    """
    def test_Task_bind_immutability():
        bound = lambda: None

        def callback1(_unused, resolve):
            bound()
            resolve(None)

        def callback2(_unused, resolve):
            resolve(None)

        task1 = Task(callback1)
        task2 = Task(callback2)

        # Check immutability of Task instances
        Task.Unit.bind(task1, lambda _unused: task2)
        assert bound.__closure__ == None

    test_Task_bind_immutability()

    def test_Task_bind_memoization():
        task1_called = False
        task1_

# Generated at 2022-06-12 05:39:47.202103
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method.
    """
    def check_Task_bind(check_function, test_function, value_count):
        """
        Test for check Task.bind with specified functions.

        :param check_function: check function
        :type check_function: Function(value) -> Bool
        :param test_function: test function
        :type test_function: Function(value) -> Task[Function(), _]
        :param value_count: count of generated value
        :type value_count: Int
        """
        for number in range(value_count):
            task = Task.of(number)
            while number != 0:
                number = number - 1
                task = task.bind(test_function)
            assert check_function(task.fork(lambda arg: arg, lambda arg: arg))

    #

# Generated at 2022-06-12 05:39:51.847392
# Unit test for method map of class Task
def test_Task_map():
    def mapper(x: int) -> int:
        return x + 1

    task = Task.of(3).map(mapper)
    assert task.fork(lambda x: x, lambda x: x) == 4



# Generated at 2022-06-12 05:39:59.783301
# Unit test for method bind of class Task
def test_Task_bind():
    def reject(arg):
        print("Task rejected with: {0}".format(arg))

    def resolve(arg):
        print("Task resolved with: {0}".format(arg))

    # define some functions
    double = lambda v: v * 2
    print_resolve = lambda v: print("Resolve function called with {0}".format(v))
    print_reject = lambda v: print("Reject function called with {0}".format(v))
    # define some tasks
    resolved_task = Task.of(3)
    rejected_task = Task.reject(4)
    # test mapped Task
    (resolved_task
     .map(double)
     .map(print_resolve)
     .fork(print_reject, print_resolve))

    # test rejected Task

# Generated at 2022-06-12 05:40:07.995023
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(arg):
        return Task.of(arg + 1)

    assert Task.of(1).bind(fn).fork.__name__ == '__lambda0'
    assert Task.of(1).bind(fn).fork(lambda arg: arg - 1, lambda arg: arg * 3) == 5
    assert Task.of(1).bind(lambda _: Task.reject(100)).fork.__name__ == '__lambda0'
    assert Task.of(1).bind(lambda _: Task.reject(100)).fork(
        lambda arg: arg - 1,
        lambda arg: arg * 3
    ) == -99


# Generated at 2022-06-12 05:40:12.132934
# Unit test for method map of class Task
def test_Task_map():
    def plus_one(x):
        return x + 1

    task = Task.of(1)

    result = task.map(plus_one).fork(None, None)

    print("TASK TEST:", result)


# Generated at 2022-06-12 05:40:17.202123
# Unit test for method map of class Task
def test_Task_map():
    def double(value):
        return value * 2

    def func(test):
        test.assertEqual(
            Task.of(5).map(double).fork(lambda _: None, lambda value: value),
            10
        )

    t.it("should return new task with mapped outcome value", func)


# Generated at 2022-06-12 05:40:22.342168
# Unit test for method map of class Task
def test_Task_map():

    def add(value):
        return value + 10

    test = Task(lambda reject, resolve: resolve(5)).map(add)

# Generated at 2022-06-12 05:40:25.210165
# Unit test for method map of class Task
def test_Task_map():
    def square(value):
        return value ** 2

    promise = Task.of(5)
    new_promise = promise.map(square)

    assert new_promise.fork(None, None) == 25


# Generated at 2022-06-12 05:40:40.169247
# Unit test for method map of class Task
def test_Task_map():
    def add_value(x):
        return x + 1

    def sub_value(x):
        return x - 1

    def task_of():
        return Task.of(1)

    def task_map_add():
        return task_of().map(add_value)

    def task_map_sub():
        return task_of().map(sub_value)

    def task_map_map():
        return task_of().map(sub_value).map(add_value)

    assert task_of().fork(lambda x: 0, lambda x: 1) == 1
    assert task_map_add().fork(lambda x: 0, lambda x: 1) == 2
    assert task_map_sub().fork(lambda x: 0, lambda x: 1) == 0

# Generated at 2022-06-12 05:40:44.310477
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(1)

    def increment(value):
        return value + 1

    task = Task(fork)
    fn_map = task.map(increment)

    assert fn_map.fork(None, lambda value: value) == 2


# Generated at 2022-06-12 05:40:51.824947
# Unit test for method map of class Task
def test_Task_map():
    """
    Tests for method map of class Task.
    """
    def resolve_call(reject, resolve):
        """
        Mock function for fork function.
        """
        return resolve('test_value')
    def test_resolve(value):
        """
        Mock function for map function.
        """
        return 'test_result'
    task = Task(resolve_call)

    expected = Task(
        lambda reject, resolve: resolve('test_result')
    )
    actual = task.map(test_resolve)

    assert expected == actual


# Generated at 2022-06-12 05:41:00.526040
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map(value) -> Task[resolve -> value]
    Task.map(value).map(fn) -> Task[resolve -> fn(value)]
    """
    assert Task.of('test').map(lambda x: x.upper()).fork(
        lambda x: '%s is not upper' % x,
        lambda x: x
    ) == 'TEST'

    assert Task.of('test').map(lambda x: x.upper()).map(
        lambda x: '%s is upper' % x
    ).fork(
        lambda x: x,
        lambda x: x
    ) == 'TEST is upper'



# Generated at 2022-06-12 05:41:05.651186
# Unit test for method map of class Task
def test_Task_map():
    # Given
    def fork(_, resolve):
        return resolve(1)

    task = Task(fork)

    def fn(value):
        return value + 1

    # When
    new_task = task.map(fn)

    # Then
    assert new_task.fork(lambda _: None, lambda result: result) == 2


# Generated at 2022-06-12 05:41:11.357573
# Unit test for method map of class Task
def test_Task_map():
    def double(num):
        return num * 2

    def reject(_):
        return 'Error'

    def resolve(value):
        return value

    @Task
    def fork(reject, resolve):
        return resolve(1)

    assert fork.map(double).fork(reject, resolve) == 2



# Generated at 2022-06-12 05:41:16.929886
# Unit test for method bind of class Task
def test_Task_bind():
    def reject(arg):
        raise Exception(arg)
    def resolve(arg):
        return arg + 10

    task = Task.of(42)
    assert task.fork(reject, resolve) == 52

    # Testing bind
    def mapper(value):
        return Task.of(value + 10)
    assert task.bind(mapper).fork(reject, resolve) == 62


# Generated at 2022-06-12 05:41:22.996694
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind method.
    """
    task = Task.of(1)
    task = task.bind(lambda value: Task.of(value + 1))
    task = task.bind(lambda value: Task.reject(value))

    assert task.fork(lambda x: x, lambda _: False) == 2



# Generated at 2022-06-12 05:41:33.005793
# Unit test for method map of class Task
def test_Task_map():
    """
    map return task with resolve function that call mapper function with arg.

    :returns: True if test pass
    :rtype: bool
    """
    def resolve_factory(a):
        return lambda x: x * a

    def reject_factory(a):
        return lambda x: x - a

    a, b = random.randint(1000, 100000), random.randint(1000, 100000)
    func = Task.of(a).map(lambda x: x * b)
    return resolve_factory(b)(a) == func.fork(reject_factory(b), resolve_factory(b))


# Generated at 2022-06-12 05:41:43.233259
# Unit test for method bind of class Task
def test_Task_bind():
    def success(args):
        assert isinstance(args, list)
        assert args[0] == 'a'
        assert args[1] == 'b'

    def error(args):
        assert isinstance(args, list)
        assert args[0] == 'abort'

    def resolve(arg):
        return Task.of(arg)

    def reject(arg):
        return Task.reject(arg)

    def map_mock(arg):
        return arg + 'b'

    def bind_mock(arg):
        if arg == 'a':
            return Task.of(arg)
        elif arg == 'abort':
            return Task.reject(arg)


# Generated at 2022-06-12 05:41:56.965784
# Unit test for method bind of class Task
def test_Task_bind():

    def test_case_1():
        def mock(reject, resolve):
            resolve(1)
        mock.fork = mock
        assert Task(mock).bind(lambda x: Task.of(x)).fork(None, assertEqual(1))

    def test_case_2():
        def mock(reject, resolve):
            resolve(1)
        mock.fork = mock
        assert Task(mock).bind(lambda x: Task.of(x + 1)).fork(None, assertEqual(2))

    def test_case_3():
        def mock(reject, resolve):
            resolve(1)
        mock.fork = mock
        assert Task(mock).bind(lambda x: Task.reject(x)).fork(assertEqual(1), None)

    test_case_1()
    test_case_

# Generated at 2022-06-12 05:42:05.989680
# Unit test for method bind of class Task
def test_Task_bind():
    number = 5

    def double(x):
        return Task.of(x + x)

    def add_10(x):
        return Task.of(x + 10)

    task = Task.of(number)
    binded_task = task.bind(double).bind(double)

    def fork(reject, resolve):
        resolve(binded_task)


# Generated at 2022-06-12 05:42:09.861139
# Unit test for method map of class Task
def test_Task_map():
    """
    Test that map method works correctly.
    """
    def fn(value):
        return 2 * value

    def fork(reject, resolve):
        return resolve(3)

    task = Task(fork).map(fn)
    result = task.fork(
        lambda arg: arg,
        lambda arg: arg
    )

    assert result == 6


# Generated at 2022-06-12 05:42:18.105728
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(10)\
        .bind(lambda arg: Task.of(arg + 1))\
        .bind(lambda arg: Task.of(arg * 2))\
        .fork(
            lambda reject: None,
            lambda resolve: resolve
        ) == 22

    assert Task.reject(10)\
        .bind(lambda arg: Task.of(arg + 1))\
        .bind(lambda arg: Task.of(arg * 2))\
        .fork(
            lambda reject: None,
            lambda resolve: resolve
        ) == 10

    assert Task.of(10)\
        .bind(lambda arg: Task.of(arg + 1))\
        .bind(lambda arg: Task.reject(arg * 2))\
        .fork(
            lambda reject: reject,
            lambda resolve: resolve
        ) == 22

# Generated at 2022-06-12 05:42:27.956849
# Unit test for method bind of class Task
def test_Task_bind():
    # TODO: mock all methods of Task class
    # any way to mock using of @classmethod?
    def mock_fork(reject, resolve):
        return "result from fork call"

    def mock_fork2(reject, resolve):
        return "result from fork2 call"

    class TaskMock(Task):
        @classmethod
        def of(cls, value):
            return Task(mock_fork)

        @classmethod
        def reject(cls, value):
            return Task(mock_fork)

    task = TaskMock.of(1000)

    with mock.patch.object(TaskMock, "__init__", return_value=None) as mock_init:
        # assert and setup what TaskMock.__init__ was called
        assert mock_init.call_count == 1
        task

# Generated at 2022-06-12 05:42:34.219272
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test that Task(fork) have attribute bind.
    Test that Task(fork).bind(fn) return Task with new fork attribute
    """
    fork_a = lambda _, resolve: resolve('a')
    fn = lambda value: Task.of(value + 'b')

    result = Task(fork_a).bind(fn)

    assert isinstance(result, Task)
    assert result.fork(lambda _: None, lambda value: value) == 'ab'


# Generated at 2022-06-12 05:42:45.333046
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    def fork(_, resolve):
        resolve(5)

    def fork2(reject, resolve):
        resolve(5)

    task = Task(fork)
    assert(task.map(mapper).fork(None, lambda value: value) == 6)
    assert(task.map(mapper).fork(lambda value: value, None) == 5)
    assert(task.map(mapper).fork(None, None) is None)

    task = Task(fork2)
    assert(task.map(mapper).fork(None, lambda value: value) == 6)
    assert(task.map(mapper).fork(lambda value: value, None) == 5)
    assert(task.map(mapper).fork(None, None) is None)


# Generated at 2022-06-12 05:42:53.471421
# Unit test for method map of class Task
def test_Task_map():
    def add_one(arg):
        return arg + 1

    def fail(arg):
        return Task.of(arg).map(lambda arg: arg / 0)

    def fail_map(arg):
        return arg / 0

    assert_equal(Task.of(1).map(add_one).fork(None, None), 2)
    assert_throws(lambda: Task.reject(1).map(fail_map).fork(None, None), ZeroDivisionError)
    assert_equal(Task.of(1).map(fail_map).fork(lambda _: None, None), None)


# Generated at 2022-06-12 05:42:56.802607
# Unit test for method map of class Task
def test_Task_map():
    def two():
        return Task.of(2)

    assert two().fork(lambda _: True, lambda arg: arg == 2)    # -> True

    def assert_two(value):
        return value == 2
    assert two().map(assert_two).fork(lambda _: True, lambda arg: arg)    # -> True


# Generated at 2022-06-12 05:43:04.154375
# Unit test for method bind of class Task
def test_Task_bind():
    def bind_resolved_task(value):
        return Task.of(value + 1)

    def bind_rejected_task(_):
        return Task.reject(3)

    def fork(reject, resolve):
        return resolve(1)

    assert Task(fork).bind(bind_resolved_task).fork(None, lambda value: value) == 2
    assert Task(fork).bind(bind_rejected_task).fork(lambda value: value, None) == 3

# Generated at 2022-06-12 05:43:15.417506
# Unit test for method bind of class Task
def test_Task_bind():
    """test_Task_bind return result of function in Task.
    test_Task_bind return Task.reject result.
    """
    value = None
    value_task = Task.of(value)

    def fn(arg):
        return Task.of(arg)
    def fn_fail(arg):
        return Task.reject(arg)

    st.check(value_task.bind(fn).fork(lambda x: x, lambda x: x))(st.just(value))
    st.check(value_task.bind(fn_fail).fork(lambda x: x, lambda x: x))(st.just(value))

    return None


# Generated at 2022-06-12 05:43:22.015322
# Unit test for method bind of class Task
def test_Task_bind():
    def check_results(reject, resolve):
        reject('error')
        resolve('success')

    task = Task(check_results)
    def mapper(value):
        return Task.of(value + '_mapped')


# Generated at 2022-06-12 05:43:28.757826
# Unit test for method bind of class Task
def test_Task_bind():
    value = "value"
    rejected = ValueError("Rejected value")
    def resolver(value):
        return Task.of(value)
    def rejecter(value):
        return Task.reject(rejected)
    case = Task.of(value)
    assert case.bind(resolver).fork(lambda _: False, lambda arg: value == arg)
    assert case.bind(rejecter).fork(lambda arg: rejected == arg, lambda _: False)


# Generated at 2022-06-12 05:43:36.452662
# Unit test for method bind of class Task
def test_Task_bind():
    def result_error(a):
        print(a)

    def result_ok(a):
        print("resolve: {}".format(a))

    def execute_first_f(value):
        print("executed first f with argument: {}".format(value))
        return Task.of(value)

    def execute_second_f(value):
        print("executed second f with argument: {}".format(value))
        return Task.reject("an error")

    Task.of("start") \
        .bind(execute_first_f) \
        .bind(execute_second_f) \
        .fork(result_error, result_ok)


# Generated at 2022-06-12 05:43:44.264619
# Unit test for method map of class Task
def test_Task_map():
    def add(value):
        return value + 1

    def multiply(value):
        return value * 2

    assert Task.of(1).map(add).fork(lambda _: None, lambda value: value) == 2
    assert Task.of(1).map(add).map(multiply).fork(lambda _: None, lambda value: value) == 4

    def test_Task_map_rejected():
        def add_throws_error(value):
            raise Exception("error")

        assert Task.of(1).map(add_throws_error).fork(lambda value: value, lambda _: None) == "error"



# Generated at 2022-06-12 05:43:50.731319
# Unit test for method map of class Task
def test_Task_map():
    def mul(x):
        return x * x

    def inc(x):
        return x + x

    def mul_inc(x):
        return mul(x) + inc(x)

    def test_map():
        value = Task.of(2).map(mul).map(inc).map(mul_inc).fork(None, lambda value: value)
        assert value == 20

    test_map()


# Generated at 2022-06-12 05:44:00.239068
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(test_obj):
        @Task.of(7)
        def gen():
            test_obj.assertEqual(test_obj.value, 7)
            def fork(reject, resolve):
                resolve(test_obj.value + 3)
            return Task(fork)

        @Task.of(5)
        def gen1():
            test_obj.assertEqual(test_obj.value, 5)
            def fork(reject, resolve):
                resolve(test_obj.value + 5)
            return Task(fork)


# Generated at 2022-06-12 05:44:07.302142
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """

    assert Task.of(1).bind(lambda arg: Task.of(arg + 1)).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 2

    assert Task.of(1).bind(lambda arg: Task.of(arg + 1)).bind(lambda arg: Task.of(arg + 1)).bind(lambda arg: Task.of(arg + 1)).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 4

if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-12 05:44:18.457832
# Unit test for method bind of class Task
def test_Task_bind():
    def of(value):
        def fork(_, resolve):
            return resolve(value)
        return Task(fork)

    def bind(task, fn):
        def fork(reject, resolve):
            return task.fork(reject, lambda arg: fn(arg).fork(reject, resolve))
        return Task(fork)



# Generated at 2022-06-12 05:44:29.273202
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method map of class Task
    """
    test_function_is_resolved = []
    test_function_is_rejected = []

    test_result_reject = []
    test_result_resolve = []

    function_for_mapper = lambda arg: arg * 5

    def check_mapper(value):
        """
        Method for check mapped value.

        :param value: value for check
        :type value: int
        """
        if value in test_result_reject:
            test_result_reject.remove(value)
        else:
            test_result_resolve.remove(value)

        if test_result_reject == [] and test_result_resolve == []:
            test_function_is_resolved.append(True)


# Generated at 2022-06-12 05:44:52.631953
# Unit test for method bind of class Task
def test_Task_bind():
    def return_task(value):
        return Task.of(value)

    def inc(value):
        return value + 1

    def inc_task(value):
        return Task.of(inc(value))

    def error_task(value):
        return Task.reject(value)

    result = Task.of(1).bind(inc_task)
    assert resolve(result) == 2

    result = Task.of(1).bind(inc_task).bind(return_task)
    assert resolve(result) == 2

    result = Task.of(1).bind(inc_task).bind(return_task).bind(inc_task)
    assert resolve(result) == 3

    result = Task.of(1).bind(inc_task).bind(inc_task)
    assert resolve(result) == 3


# Generated at 2022-06-12 05:44:54.474338
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2


# Generated at 2022-06-12 05:44:58.307583
# Unit test for method bind of class Task
def test_Task_bind():
    def one():
        return Task.of(1)

    def two():
        return Task.of(2)

    def thr():
        return Task.of(3)

    task = one() \
        .bind(lambda _: two()) \
        .bind(lambda _: thr())

    fork = task.fork(lambda _: None, None)
    assert fork == 3


# Generated at 2022-06-12 05:45:03.780349
# Unit test for method map of class Task
def test_Task_map():
    identity = lambda x: x
    assert Task(identity).map(identity).fork(identity, identity)(
        lambda arg: None,
        lambda arg: arg
    ) == 5

    assert Task(identity).map(
        lambda arg: arg + 1
    ).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 6


# Generated at 2022-06-12 05:45:08.736153
# Unit test for method map of class Task
def test_Task_map():

    def fn(arg):
        return arg + arg

    task = Task.of(2)
    task = task.map(fn)

    def reject(_):
        return 'Reject'

    def resolve(result):
        return result

    assert task.fork(reject, resolve) == 4



# Generated at 2022-06-12 05:45:13.586379
# Unit test for method bind of class Task
def test_Task_bind():
    def fork_value_10(reject, resolve):
        return resolve(10)

    def fork_value_20(reject, resolve):
        return resolve(20)

    def mapper(arg):
        return Task.of(arg * 2)

    assert Task(fork_value_10).bind(mapper).fork(lambda arg: arg, lambda arg: arg) == 20
    assert Task(fork_value_20).bind(mapper).fork(lambda arg: arg, lambda arg: arg) == 40


# Generated at 2022-06-12 05:45:19.354670
# Unit test for method bind of class Task
def test_Task_bind():
    add = Task(lambda reject, resolve: resolve(1 + 1))
    add_to_task = lambda value: Task(lambda reject, resolve: resolve(value + 1))

    assert add.bind(add_to_task).fork(lambda arg: arg, lambda arg: arg) == 3
    assert Task.reject(1).bind(add_to_task).fork(lambda arg: arg, lambda arg: arg) == 1

# Generated at 2022-06-12 05:45:29.386387
# Unit test for method map of class Task
def test_Task_map():
    def test_resolve():
        def test():
            def fn(value):
                return value + 1

            def fork(reject, resolve):
                resolve(1)

            return Task(fork).map(fn)

        assert test().fork(lambda arg: -1, lambda arg: arg) == 2

    def test_reject():
        def test():
            def fork(reject, resolve):
                reject(1)

            return Task(fork).map(lambda _: 1)

        assert test().fork(lambda arg: arg, lambda _: -1) == 1

    test_resolve()
    test_reject()


# Generated at 2022-06-12 05:45:32.190751
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda a: Task.of(a + 3)).fork(None, lambda a: a) == 4


# Generated at 2022-06-12 05:45:38.162287
# Unit test for method map of class Task
def test_Task_map():
    """
    test_Task_map() -> None
    """
    def fork(reject, resolve):
        resolve(3)

    def mapper(x):
        return x * 2

    task = Task(fork)
    returned = task.map(mapper)
    assert returned.fork(lambda x: x, lambda y: y) == 6
