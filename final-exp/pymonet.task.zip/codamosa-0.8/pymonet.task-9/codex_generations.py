

# Generated at 2022-06-12 05:36:12.628458
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """

    # definition of function for mapping
    mapping_functions = []
    def mapping_function(value):
        mapping_functions.append(value)
        return value * 10

    # definition of function
    def fn(value):
        return Task.of(value).map(
            lambda arg: arg * 10
        )

    # call fork of task with bind method
    task = Task.of(2).bind(fn)

    # call fork of new task
    task.fork(
        lambda arg: None,
        lambda arg: mapping_functions.append(arg)
    )

    # check result of calling
    assert mapping_functions == [2, 20]


# Generated at 2022-06-12 05:36:20.851297
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    def add(x, y):
        return x + y

    def get_task(value):
        return Task.of(value)

    def example(x, y):
        return Task.of((x, y)).bind(get_task).bind(lambda value: get_task(add(*value)))

    assert example(1, 1).fork(None, lambda value: value) == 2

    def example2(x, y):
        return Task.of((x, y)).bind(get_task).bind(lambda _: add(x, y))

    assert example2(1, 1).fork(None, lambda value: value) == 2


# Generated at 2022-06-12 05:36:30.620387
# Unit test for method map of class Task
def test_Task_map():

    def test_Task_map_none_value_with_none_mapper():
        # Task[None] -> Task[A]
        task = Task.of(None)
        result_task = task.map(lambda _: "hello world")

        def assert_fork(reject, resolve):
            assert(reject(True) is None)
            assert(resolve("hello world") == "hello world")

        result_task.fork(assert_fork)

    def test_Task_map_none_value_with_mapper():
        # Task[A] -> Task[B]
        task = Task.of("hello world")
        result_task = task.map(lambda arg: arg.upper())

        def assert_fork(reject, resolve):
            assert(reject(True) is None)

# Generated at 2022-06-12 05:36:35.280119
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve("value")

    def mapper(value):
        return Task(lambda _, r: r("mapped_value"))

    task = Task(fork)
    result = task.bind(mapper)
    assert result.fork(None, lambda v: v) == "mapped_value"

# Generated at 2022-06-12 05:36:38.320372
# Unit test for method bind of class Task
def test_Task_bind():
    Task.of(1).bind(lambda x: Task.of(x + 1))


# Generated at 2022-06-12 05:36:44.411519
# Unit test for method map of class Task
def test_Task_map():
    # Randomly generated test data with seed 0
    value = -5819088120798001668

    # Check function work correctly
    assert Task.of(value).map(lambda x: x + 1).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == value + 1



# Generated at 2022-06-12 05:36:53.768095
# Unit test for method bind of class Task
def test_Task_bind():
    # Test 1: bind resolve task with resolve task and receive resolve task
    def test1(reject, resolve):
        resolve(1)

    def test2(value):
        return Task.of(2)

    result = Task(test1).bind(test2)

    assert isinstance(result, Task)
    assert result.fork(reject=lambda x: False, resolve=lambda x: x == 2)

    # Test 2: bind resolve task with reject task and receive reject task
    def test3(value):
        return Task.reject(2)

    result2 = Task(test1).bind(test3)

    assert isinstance(result2, Task)
    assert result2.fork(reject=lambda x: x == 2, resolve=lambda x: False)

    # Test 3: bind reject task with some other and receive reject task


# Generated at 2022-06-12 05:37:02.444291
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        """
        In this case reject and resolve are just function wrapper,
        that stores value in closure.
        """
        reject.value = None
        resolve.value = None

    task = Task(fork)

    def mapper(value):
        return value * 2

    new_task = task.map(mapper)

    def reject(value):
        assert reject.value is None
        reject.value = value

    def resolve(value):
        assert resolve.value is None
        resolve.value = value

    new_task.fork(reject, resolve)

    assert reject.value is None
    assert resolve.value is None


# Generated at 2022-06-12 05:37:11.218292
# Unit test for method map of class Task
def test_Task_map():
    @pytest.fixture
    def mock_resolve(mocker):
        return mocker.Mock()

    @pytest.fixture
    def mock_reject(mocker):
        return mocker.Mock()

    @pytest.fixture
    def mock_fn(mocker):
        return mocker.Mock()

    @pytest.fixture
    def mock_fork(mocker):
        return mocker.Mock()

    def test_Task_call_resolve_with_result_of_mapper_called_on_resolve_value(mock_resolve, mock_reject, mock_fn):
        # Given
        task = Task(mock_fork)
        task.fork.side_effect = lambda reject, resolve: resolve(42)

# Generated at 2022-06-12 05:37:14.246150
# Unit test for method bind of class Task
def test_Task_bind():
    resolved = Task.of(42, 'fin')
    rejected = Task.reject(42, 'fin')

    assert not resolved.fork('fst', 'fin')
    assert rejected.fork('fst', 'fin')

# Generated at 2022-06-12 05:37:23.643320
# Unit test for method map of class Task
def test_Task_map():
    promise = Promise()
    resolve = lambda value: promise.resolve(value)
    reject = lambda value: promise.reject(value)

    def fork(reject, resolve):
        resolve(10)

    def double(value):
        return value * 2

    task = Task(fork).map(double)
    task.fork(reject, resolve)

    assert promise.value() == 20


# Generated at 2022-06-12 05:37:30.765548
# Unit test for method bind of class Task
def test_Task_bind():
    def mock_execute(res):
        def m(reject, resolve):
            return res

        return Task(m)

    def mapper(arg):
        return mock_execute(arg)

    def f1(reject, resolve):
        return resolve(1)

    def f2(reject, resolve):
        return reject(2)

    t1 = Task(f1)
    t2 = Task(f2)

    assert(1 == t1.bind(mapper).fork(lambda x: x, lambda _: None))
    assert(1 == t1.bind(mapper).fork(lambda _: None, lambda x: x))
    assert(2 == t2.bind(mapper).fork(lambda x: x, lambda _: None))

# Generated at 2022-06-12 05:37:39.729094
# Unit test for method bind of class Task
def test_Task_bind():
    data = [1, 2, 3, 4, 5]

    def map_fn(value):
        return Task.of(value + 1)

    def fork_fn(reject, resolve):
        return resolve(data)

    task = Task(fork_fn)
    to_task = task.map(lambda value: map_fn(value))
    result = to_task.bind(lambda value: value)
    assert result.fork(
        lambda value: False,
        lambda value: value == [2, 3, 4, 5, 6]
    )


# Generated at 2022-06-12 05:37:47.387768
# Unit test for method bind of class Task
def test_Task_bind():
    def map_string(value):
        """
        Return new Task with string-type argument

        :param value: value to return in new Task
        :type value: Any
        :rtype: Task
        """
        return Task.of(str(value))

    def map_int(value):
        """
        Return new Task with int-type argument

        :param value: value to return in new Task
        :type value: Any
        :rtype: Task
        """
        return Task.of(int(value))

    def map_exception(value):
        """
        Return new Task with TypeError exception (from int-type).

        :param value: value to return in new Task
        :type value: Any
        :rtype: Task
        """
        return Task.reject(TypeError('From map of exception'))

   

# Generated at 2022-06-12 05:37:50.693915
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    task = task.map(lambda v: v + 2)

    assert task.fork(None, lambda v: v) == 4



# Generated at 2022-06-12 05:37:53.592949
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)).map(lambda x: x * 2).fork(
        lambda _: False,
        lambda value: value == 2
    )


# Generated at 2022-06-12 05:37:58.568571
# Unit test for method bind of class Task
def test_Task_bind():
    def mock_add_one(arg):
        return arg + 1

    mock_argument = 1
    mock_add_one_task = Task.of(mock_add_one)
    task = Task.of(mock_argument)
    result = task.bind(mock_add_one_task.fork)

    assert result.fork(None, None) == 2



# Generated at 2022-06-12 05:38:02.197448
# Unit test for method bind of class Task
def test_Task_bind():
    # call of bind must return empty function
    def fn(value):
        return Task.of(1)

    task = Task.of(1).bind(fn)
    assert task.fork is not None


# Generated at 2022-06-12 05:38:06.485334
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind method of Task.
    """
    r = Task.of(43).bind(lambda x: Task.of(x + 1))
    assert r.fork(lambda x: x, lambda x: x) == 44

# Generated at 2022-06-12 05:38:12.268949
# Unit test for method bind of class Task
def test_Task_bind():
    def first_function(x):
        return Task.of(x + x)

    def second_function(y):
        return Task.of(y * y)

    def test_function(x):
        return Task.of(x + x).bind(first_function).bind(second_function)

    assert test_function(10).fork(lambda _: 0, lambda x: x) == 400


# Generated at 2022-06-12 05:38:19.332281
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve('test')

    def mapper(value):
        return Task.reject(True)


# Generated at 2022-06-12 05:38:24.926631
# Unit test for method bind of class Task
def test_Task_bind():
    def go(x):
        return x

    @Task.of
    def go1(x):
        return x

    assert go(1) == 1
    assert go1(1).fork(None, go) == 1
    assert go(go1(1)).fork(None, go) == 1
    assert Task.of(go1(1)).bind(go).fork(None, go) == 1


# Generated at 2022-06-12 05:38:33.859227
# Unit test for method bind of class Task
def test_Task_bind():
    import unittest

    class TestFirstTask(unittest.TestCase):
        def test_call_with_argument(self):
            def do(fn, value):
                return fn(value)

            def task(reject):
                return do(reject, 'reject')

            def task_mapper(value):
                return Task(task)

            assert Task(task).bind(task_mapper).fork(lambda x: x, lambda x: x) == 'reject', \
                "Expected 'reject', got {0}".format(Task(task).bind(task_mapper).fork(lambda x: x, lambda x: x))

    class TestSecondTask(unittest.TestCase):
        def test_call_with_argument(self):
            def do(fn, value):
                return fn(value)

# Generated at 2022-06-12 05:38:37.793187
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        print('asd')
        return Task.of(value.strip())

    Task.reject("asd\n  ").bind(fn)


# Generated at 2022-06-12 05:38:47.024473
# Unit test for method bind of class Task
def test_Task_bind():
    # Bind with class Task.
    def test(value):
        return Task.of(value)

    result = (Task.of(10)
        .bind(test)
        .bind(test)
        .fork
    )
    assert result(None, lambda a: a) == 10

    # Bind with func Task.
    def test2(value):
        return Task(lambda _, res: res(value))

    result = (Task.of(10)
        .bind(test2)
        .bind(test2)
        .fork
    )
    assert result(None, lambda a: a) == 10


# Generated at 2022-06-12 05:38:49.548801
# Unit test for method bind of class Task
def test_Task_bind():
    Task.of(1).bind(lambda x: Task.of(x + 1))
    Task.reject(1).bind(lambda x: Task.of(x + 1))



# Generated at 2022-06-12 05:38:59.451355
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test different arguments in Task.bind

    :returns: None
    :rtype: None
    """
    def fork(reject, resolve):
        def resolve_delayed(value):
            sleep(0.01)
            resolve(value)

        return setTimeout(lambda: resolve_delayed(1), 0.01)

    task = Task(fork)
    assert_task_result(
        task.bind(lambda arg: Task.reject(arg)).fork(
            lambda arg: arg + 1,
            lambda arg: arg - 1
        ),
        2,
        -1,
    )


# Generated at 2022-06-12 05:39:05.818683
# Unit test for method map of class Task
def test_Task_map():
    value = 'hello'
    task = Task.of(value)
    assert task.map(lambda x: x).fork(lambda _: True, lambda x: x == value) == value
    assert task.map(lambda x: x + ' world').fork(lambda _: True, lambda x: x == value + ' world') == value + ' world'


# Generated at 2022-06-12 05:39:12.710693
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def fn(value):
        return Task.of(value + 1)

    task = Task.of(0)

    assert isinstance(task, Task)
    assert isinstance(task.bind(fn), Task)
    assert task.bind(fn).fork(lambda arg: arg, lambda arg: arg) == 1

    def fnerr(value):
        return Task.reject(value + 1)

    task = Task.reject(0)

    assert isinstance(task, Task)
    assert isinstance(task.bind(fnerr), Task)
    assert task.bind(fn).fork(lambda arg: arg, lambda arg: arg) == 1

    def fn(value):
        return Task.of(value + 1)


# Generated at 2022-06-12 05:39:19.376019
# Unit test for method map of class Task
def test_Task_map():
    def reject(arg):
        raise Exception(arg)

    implement = Task.of(123).map(lambda value: value + 1)

# Generated at 2022-06-12 05:39:29.459597
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for map method of Task class.
    """
    assert Task.of(3).map(lambda x: x + 1).fork(None, lambda x: x) == 4
    assert Task.of('foo').map(lambda x: x + 'bar').fork(None, lambda x: x) == 'foobar'


# Generated at 2022-06-12 05:39:34.955416
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Some test for testing work of method bind
    """
    task = Task(lambda reject, resolve: resolve(1))
    fn = lambda arg: Task(lambda _, resolve: resolve(arg * 10))

    assert task.fork(*[None] * 2) == 1
    assert task.bind(fn).fork(*[None] * 2) == 10


# Generated at 2022-06-12 05:39:46.982252
# Unit test for method bind of class Task
def test_Task_bind():
    def fail_task():
        return Task(lambda reject, _: reject(None))

    def return_task(number):
        return Task.of(number)

    def assert_passed(number):
        print("assert_passed({})".format(number))
        assert number == 1

    def assert_fail(number):
        print("assert_fail({})".format(number))
        assert number == None

    # Pass
    Task.of(1).bind(return_task).fork(
        lambda arg: assert_fail(arg),
        lambda arg: assert_passed(arg),
    )

    # Fail
    Task.of(1).bind(fail_task).fork(
        lambda arg: assert_passed(arg),
        lambda arg: assert_fail(arg),
    )

test_Task_bind()

# Generated at 2022-06-12 05:39:54.614374
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return Task.of(value + 1)

    assert Task.of(1) == Task.of(1).bind(add_one)
    assert Task.of(2) == Task.of(1).bind(add_one).bind(add_one)
    assert Task.of(3) == Task.of(1).bind(add_one).bind(add_one).bind(add_one)



# Generated at 2022-06-12 05:39:57.638710
# Unit test for method map of class Task
def test_Task_map():
    def result(reject, resolve):
        return Task.of(3).map(lambda arg: arg * 2).fork(reject, resolve)

    assert Task(result) == Task.of(6)


# Generated at 2022-06-12 05:40:02.535577
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve(7)

    task = Task(fork)
    new_task = task.map(lambda value: value * 2)
    reject, resolve = new_task.fork

    assert resolve(6) == 14
    assert reject('error') == 'error'


# Generated at 2022-06-12 05:40:06.615050
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    value = 1
    task = Task(lambda _, resolve: resolve(value))
    task.map(fn).fork(
        lambda _: None,
        lambda result: assert_equal(result, fn(value))
    )



# Generated at 2022-06-12 05:40:11.387449
# Unit test for method bind of class Task
def test_Task_bind():
    def add1(arg):
        return Task.of(arg + 1)

    assert Task.of(2).bind(add1).fork(None, lambda arg: arg) == 3


# Generated at 2022-06-12 05:40:21.499095
# Unit test for method bind of class Task
def test_Task_bind():
    # Create task with success result
    task = Task.of(1)

    # Testing of bind function when argument is function

# Generated at 2022-06-12 05:40:27.261896
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test func for Task.
    Test success work of bind.
    """
    def add(x):
        return Task.of(x + 1)

    def calc(task, expected_result):
        """ Task[1] -> Task[2] -> Task[3] """
        return task.bind(add).bind(add).fork(
            lambda x: print("Rejected with: {}.".format(x)),
            lambda x: print("Success: {}.".format(x == expected_result))
        )

    calc(Task.of(1), 3)


# Generated at 2022-06-12 05:40:46.771872
# Unit test for method map of class Task
def test_Task_map():
    # Test for type checking
    def test_check(arguments):
        """
        Test of arguments types.
        """
        if isinstance(arguments, Task):
            assert isinstance(arguments.fork, FunctionType)
            assert len(signature(arguments.fork).parameters) == 2
            assert isinstance(arguments.fork.__defaults__, tuple)
            assert len(arguments.fork.__defaults__) == 2
        else:
            raise TypeError('first argument must be Task type')

    def resolve(value, err=None):
        """
        Function for calls in tests for storing result of fork.
        """
        if err:
            raise ValueError('error test')
        return value

    # Test for correct working of method map
    def test_resolve(arguments, fn):
        test_

# Generated at 2022-06-12 05:40:54.355998
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind.
    """

    def double(x):
        return Task.of(x*2)

    def not_double(x):
        return Task.reject("NOT IMPLEMENTED")

    def throw(x):
        raise Exception("NOT IMPLEMENTED")

    def fork_double(x):
        return Task(lambda _, resolve: resolve(x*2))

    def fork_not_double(x):
        return Task(lambda reject, _: reject("NOT IMPLEMENTED"))

    def fork_throw(x):
        return Task(lambda reject, _: throw(x))

    assert Task.reject(0).bind(double).fork(lambda x: 0, lambda x: 1) == 0

# Generated at 2022-06-12 05:41:03.090501
# Unit test for method bind of class Task

# Generated at 2022-06-12 05:41:08.349880
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        print(value)

    def reject(value):
        print(value)

    def double(value):
        return value * 2

    Task.of(3).map(double).fork(reject, resolve)
    # 6
    Task.of(3).map(double).map(double).fork(reject, resolve)
    # 12
    Task.reject(3).map(double).fork(reject, resolve)
    # 3


# Generated at 2022-06-12 05:41:14.486865
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, reject: reject(1)) \
        .map(lambda x: x + 1) \
        .fork(lambda reject: reject, lambda resolve: resolve) == 1

    assert Task(lambda _, resolve: resolve(1)) \
        .map(lambda x: x + 1) \
        .fork(lambda reject: reject, lambda resolve: resolve) == 2


# Generated at 2022-06-12 05:41:21.310769
# Unit test for method map of class Task
def test_Task_map():
    actual = Task.of(1).map(lambda x: x + 2).fork(
        lambda x: "error: " + str(x),
        lambda x: "value: " + str(x)
    )
    expected = 'value: 3'

    assert actual == expected


# Generated at 2022-06-12 05:41:30.214707
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Define two Task instances, in one resolve and in another reject.
    After bind result Task will be rejected.
    """
    def example(s):
        def _(reject, resolve):
            resolve('Example ' + s)

        return Task(_)

    def mapper(s):
        return Task.of(s + ' mapper')

    task = example('task') \
        .bind(mapper)

    assert task.fork(
        lambda result: result,
        lambda result: result + ' never call'
    ) == 'Example task mapper'


# Generated at 2022-06-12 05:41:36.037373
# Unit test for method map of class Task
def test_Task_map():
    # transform simple value
    assert Task.of(1).map(lambda x: x + 2).fork(
        lambda err: "Rejected",
        lambda val: val
    ) == 3

    # transform value from function
    assert Task.of(lambda x: x ** 2).map(lambda fn: fn(2)).fork(
        lambda err: "Rejected",
        lambda val: val
    ) == 4

    # transform value with throwing error
    assert Task.of(1).map(lambda x: 1 / (x - 1)).fork(
        lambda err: "Rejected",
        lambda val: val
    ) == "Rejected"


# Generated at 2022-06-12 05:41:39.752669
# Unit test for method map of class Task
def test_Task_map():
    def test_fn(a):
        return a + 1

    result = Task.of(1).map(test_fn)
    assert result.fork(None, lambda arg: arg == 2)


# Generated at 2022-06-12 05:41:45.083357
# Unit test for method map of class Task
def test_Task_map():
    # Success test
    assert Task.of(2)\
        .map(lambda x: x * 2)\
        .fork(
            lambda e: e,
            lambda r: r == 4
        )

    # Failure test
    assert Task.reject(2)\
        .map(lambda x: x * 2)\
        .fork(
            lambda e: e == 2,
            lambda r: r
        )


# Generated at 2022-06-12 05:42:14.291903
# Unit test for method bind of class Task
def test_Task_bind():
    # Create task for testing
    task = Task(
        lambda reject, resolve: resolve(42)
    )

    # Create task for testing
    with_value_resolver = Task(
        lambda reject, resolve: resolve(1)
    )

    # Create task for testing
    without_value_resolver = Task(
        lambda reject, resolve: reject(2)
    )

    # Create task for testing
    with_value_rejecter = Task(
        lambda reject, resolve: reject(3)
    )

    # Test bind with resolved value
    task.bind(lambda _: with_value_resolver)
    assert task.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1

    # Test bind with rejected value
    task.bind(lambda _: without_value_resolver)

# Generated at 2022-06-12 05:42:17.614193
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return str(value)

    def reject(value):
        return str(value)

    assert Task(lambda reject, resolve: resolve("ABC"))\
        .map(lambda x: "D" + x)\
        .fork(reject, resolve)\
        == "DABC"


# Generated at 2022-06-12 05:42:20.465898
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(2).map(lambda a: a * 2)
    result.fork(
        lambda r: assert_(r) == 4,
        lambda r: assert_(r) == 4
    )


# Generated at 2022-06-12 05:42:26.154064
# Unit test for method map of class Task
def test_Task_map():
    def to_upper(value):
        return value.upper()

    @Task.of('hello')
    def source(reject, resolve):
        return resolve(value)

    @source.map(to_upper)
    def target(reject, resolve):
        return resolve(value)

    assert target.fork(lambda arg: arg, lambda arg: arg) == 'HELLO'


# Generated at 2022-06-12 05:42:29.191780
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(a):
        return Task.of(a + 1)

    t = Task.of(5)
    assert t.bind(mapper).fork(None, identity) == 6


# Generated at 2022-06-12 05:42:35.936893
# Unit test for method map of class Task
def test_Task_map():
    def double(arg):
        return arg * 2

    task = Task.of(5).map(double)
    assert task.fork(lambda _: None, assert_equal)(None, 10)

    task = Task.of(5).map(lambda _: None).map(lambda _: 10)
    assert task.fork(lambda _: None, assert_equal)(None, 10)

    task = Task.of(5).map(double).map(double)
    assert task.fork(lambda _: None, assert_equal)(None, 20)


# Generated at 2022-06-12 05:42:41.402615
# Unit test for method map of class Task
def test_Task_map():
    def mapper(arg):
        return arg + 5

    task = Task(lambda _, resolve: resolve(10))
    assert task.fork[0](None) == 15

    task = Task(lambda _, resolve: resolve(10)).map(mapper)
    assert task.fork[0](None) == 15


# Generated at 2022-06-12 05:42:46.441655
# Unit test for method bind of class Task
def test_Task_bind():
    task1 = Task(lambda reject, resolve: resolve(5))
    task2 = task1.bind(lambda value: Task(lambda reject, resolve: resolve(value + 10)))
    task3 = task2.bind(lambda value: Task(lambda reject, resolve: resolve(value - 7)))
    assert task3.fork(
        lambda value: None,
        lambda value: value
    ) == 8

# Generated at 2022-06-12 05:42:51.735072
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test function for Task bind method.
    Returned value of bind method should be other task.
    """
    test = Task.of(1)
    test = test.bind(lambda x: Task.of(x + 1))
    assert isinstance(test, Task)
    assert test.fork(lambda _: False, lambda x: x == 2)


# Generated at 2022-06-12 05:42:58.207231
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    # function return Task with resolved value twice
    def twice(value):
        return Task.of(value * 2)

    # Task reject with value = None
    task_reject = Task.reject(None)
    def expect_reject(_):
        pass

    # Task resolve with value = 10
    task_resolve = Task.of(10)
    def expect_resolve(value):
        assert value == 20

    task_reject.bind(twice).fork(expect_reject, expect_reject)
    task_resolve.bind(twice).fork(expect_reject, expect_resolve)


# Generated at 2022-06-12 05:43:44.727349
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.reject("mapper_value")

    def resolve(value):
        return "resolve"

    def reject(value):
        return "reject"

    assert b"mapper_value" == Task.reject("value").bind(mapper).fork(reject, resolve)

# Generated at 2022-06-12 05:43:49.108201
# Unit test for method map of class Task
def test_Task_map():

    def map_test(reject, resolve):
        resolve(1)

    task = Task(map_test)

    assert task.map(lambda arg: arg + 1).fork(None, lambda arg: arg) == 2


# Generated at 2022-06-12 05:43:51.498027
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(12).bind(lambda x: Task.of(x + 20))
    assert result.fork(lambda x: x, lambda y: y) == 32



# Generated at 2022-06-12 05:43:57.595145
# Unit test for method map of class Task
def test_Task_map():
    def add_one(num):
        return num + 1

    def check_equal(value):
        assert value == 6

    def check_raise_error(error):
        assert error == 'error'

    Task.of(5).map(add_one).fork(check_raise_error, check_equal)  # result 6
    Task.reject('error').map(add_one).fork(check_equal, check_raise_error)  # result 'error'


# Generated at 2022-06-12 05:44:07.137949
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value * 2)

    task = Task.reject(1).map(lambda v: v * 2)

# Generated at 2022-06-12 05:44:18.275528
# Unit test for method bind of class Task
def test_Task_bind():
    # create our "fetch"
    fetch = lambda url: Task.of(url)
    # create our fake db
    db = {'todos': '12'}
    # fake fetch to db
    fetch_db = lambda url: Task.of(db[url])
    # fake fetch to db but with error
    fetch_error_db = lambda url: Task.reject(db[url])

    # fetch all todos and return if exist, else return 0
    fetch_todos = lambda: fetch_db('todos').map(lambda todos: len(todos) if todos else 0)

    # fetch all todos and return if exist, else return 0

# Generated at 2022-06-12 05:44:20.688717
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x + 2).fork(lambda x: "", lambda x: x) == 4


# Generated at 2022-06-12 05:44:27.832183
# Unit test for method bind of class Task
def test_Task_bind():
    def fn1(arg):
        return Task.of(arg + '!!!')

    def fn2(arg):
        return Task.reject(arg + ' !!!')

    assert Task.of('hello') \
        .bind(fn1) \
        .fork(lambda arg: None, lambda arg: arg) == 'hello!!!'

    assert Task.of('hello') \
        .bind(fn2) \
        .fork(lambda arg: arg, lambda arg: None) == 'hello !!!'



# Generated at 2022-06-12 05:44:36.128400
# Unit test for method map of class Task
def test_Task_map():
    # Test for klass resolved Task
    task_resolved = Task.of("test")
    def plus_one(value):
        return value + "1"
    task_resolved_map = task_resolved.map(plus_one)

    assert task_resolved.fork(lambda x: "rejected", lambda x: "resolved") == "resolved"
    assert task_resolved_map.fork(lambda x: "rejected", lambda x: "resolved") == "resolved"

    # Test for klass rejected Task
    task_rejected = Task.reject("test")
    task_rejected_map = task_rejected.map(plus_one)

    assert task_rejected.fork(lambda x: "rejected", lambda x: "resolved") == "rejected"
    assert task_rejected_map

# Generated at 2022-06-12 05:44:44.672625
# Unit test for method map of class Task
def test_Task_map():
    """
    Task: map: test function
    """
    @Task.of(2)
    @Task.map(lambda x: x + 1)
    def res(resolve, reject):
        """
        return resolve of task with argument x + 1

        :param resolve: call by Task.of
        :type resolve: Function(value) -> Task.of(value)
        :param reject: call by Task.of
        :type reject: Function(value) -> Task.of(value)
        :return: resolution result with value
        :rtype: Task.of(value)
        """
        return resolve(x)

    assert res == Task.of(3)
