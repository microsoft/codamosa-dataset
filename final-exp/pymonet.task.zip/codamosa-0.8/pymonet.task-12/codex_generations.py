

# Generated at 2022-06-12 05:36:12.425690
# Unit test for method map of class Task
def test_Task_map():
    def test_map_reject(reject, resolve):
        return reject(1)

    def test_map_resolve(reject, resolve):
        return resolve("test")

    def test_mapper(value):
        return value+" 123"

    def test_mapper_raise_error(value):
        raise Exception("error")

    assert Task(test_map_reject).map(test_mapper).fork(
        lambda reject: isinstance(reject, int),
        lambda resolve: False
    )

    assert Task(test_map_resolve).map(test_mapper).fork(
        lambda reject: False,
        lambda resolve: resolve == "test 123"
    )


# Generated at 2022-06-12 05:36:21.395158
# Unit test for method map of class Task
def test_Task_map():
    value = 'new'

    def get_value():
        return value

    def set_value(arg):
        nonlocal value
        value = arg

    def get_result():
        return value

    def clear():
        nonlocal value
        value = None

    def check(arg):
        assert get_result() == arg

    # check that map works for sequence of map calls
    clear()
    set_value('old')
    check('old')
    Task.of(get_value).map(lambda x: x + '1').map(lambda x: x + '2').fork(
        lambda reject: reject('fail'),
        lambda resolve: check(resolve + '3')
    )

    # check that map works for Task.of
    clear()

# Generated at 2022-06-12 05:36:30.297926
# Unit test for method map of class Task
def test_Task_map():
    class TestException(Exception):
        pass

    inc = lambda x: x + 1

    # task for map
    task = Task.of(1).map(inc)
    # task for fork
    task_fork = task.fork(lambda x: x, lambda x: x)
    assert task_fork == 2

    task = Task.of(1).map(inc).map(inc)
    task_fork = task.fork(lambda x: x, lambda x: x)
    assert task_fork == 3

    # try fork rejected Task
    task_fork = Task.reject(TestException()).map(inc).fork(lambda x: x, lambda x: x)
    assert isinstance(task_fork, TestException)


# Generated at 2022-06-12 05:36:36.172354
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 3)

    task = Task.of(6)
    assert task.bind(fn).fork(noop, noop) == 9

    task = Task.of(9)
    assert task.bind(fn).fork(noop, noop) == 12

    task = Task.reject("error")
    assert task.bind(fn).fork(lambda err: err, noop) == "error"

# Generated at 2022-06-12 05:36:40.894912
# Unit test for method map of class Task
def test_Task_map():
    double = lambda x: x * 2

    task = Task.of(2)
    double_task = task.map(double)

    assert double_task.fork(lambda x: x, lambda x: x) == 4
    assert task.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-12 05:36:47.706073
# Unit test for method map of class Task
def test_Task_map():
    # Test for resolve Task
    task_resolve = Task.of('Hello World!')
    result = task_resolve.map(lambda text: text + ' - Alfa')
    assert result.fork(lambda _: 'Rejected!', lambda text: text) == 'Hello World! - Alfa'

    # Test for reject Task
    task_reject = Task.reject('Hello World!')
    result = task_reject.map(lambda text: text + ' - Alfa')
    assert result.fork(lambda text: text, lambda _: 'Rejected!') == 'Hello World!'

    print('Task.map succesfully complete!')


# Generated at 2022-06-12 05:36:51.056502
# Unit test for method bind of class Task

# Generated at 2022-06-12 05:36:55.187492
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Check that method bind of class Task works correctly.
    """
    return Task.of(12).bind(lambda x: Task.of(x ** 2)).fork(None, lambda x: x == 144)


# Generated at 2022-06-12 05:37:01.974249
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve({ 'value': '123' })

    def mapper(value):
        def fork(reject, resolve):
            return resolve({ 'value': '456' })

        return Task(fork)

    expected = '456'
    actual = Task(fork).bind(mapper).fork(lambda *args: None, lambda arg: arg['value'])
    assert expected == actual

if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-12 05:37:05.509719
# Unit test for method map of class Task
def test_Task_map():
    def test_fork(reject, resolve):
        print('Fork:')

    def test_map(value):
        return value + 1

    task = Task(test_fork)
    task.map(test_map)


# Generated at 2022-06-12 05:37:12.892967
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task bind method
    """
    def test_Task_bind_True():
        """
        Test Task bind method
        """
        value = Task.of(1).bind(
            lambda arg: Task.of(arg)
        )

        def fork(reject, resolve):
            resolve(1)
        assert value.fork == fork

    def test_Task_bind_False():
        """
        Test Task bind method
        """
        value = Task.of(1).bind(
            lambda arg: Task.of(arg)
        )

        def fork(resolve, reject):
            reject(1)

        assert value.fork != fork


# Generated at 2022-06-12 05:37:18.660858
# Unit test for method bind of class Task
def test_Task_bind():
    def map_to_Task(inc):
        def result(reject, resolve):
            return reject(inc)

        return Task(result)

    t1 = Task.of(2).bind(map_to_Task)
    t1.fork(lambda value: value == 2, lambda _: False)

    t2 = Task.reject('error').bind(map_to_Task)
    t2.fork(lambda value: value == 'error', lambda _: False)


# Generated at 2022-06-12 05:37:28.944044
# Unit test for method bind of class Task
def test_Task_bind():
    # Successful case
    def foo():
        return Task.of(42)

    # Reject case
    def reject():
        return Task.reject(42)

    # Successful case after rejection
    def foo_after_reject():
        return Task.of(42)

    # Reject case after rejection
    def reject_after_reject():
        return Task.reject(42)

    # Successful case after successful case
    def foo_after_foo():
        return Task.of(42)

    # Successful case after successful case with value
    def foo_after_foo_with_value(value):
        return Task.of(value)

    # Execute successful case

# Generated at 2022-06-12 05:37:32.548622
# Unit test for method bind of class Task
def test_Task_bind():
    """Test for Task.bind method.
    """
    def add1(x):
        return Task.of(x + 1)

    t = Task.of(2)
    assert t.bind(add1).fork(None, print_) == 3

# Generated at 2022-06-12 05:37:37.452480
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(2)

    t1 = Task(fork)
    t2 = t1.map(lambda v: v * 3)
    assert t2.fork(lambda a: a, lambda a: a) == 6


# Generated at 2022-06-12 05:37:41.610921
# Unit test for method map of class Task
def test_Task_map():
    t = Task(lambda _, resolve: resolve(1))
    def fn(a):
        return a + 1

    assert t.map(fn).fork(lambda arg: arg, lambda arg: arg) == 2,\
        "map method of Task class doesn't work correctly"


# Generated at 2022-06-12 05:37:53.081207
# Unit test for method bind of class Task
def test_Task_bind():
    def assert_task(result, expected):
        """
        Run resolve and reject callbacks for Task and
        compare result of resolve to expected.

        :param task: Task to resolve
        :type task: Task
        :param expected:
        :type expected: Any
        """
        def reject(value):
            raise AssertionError("Task rejected with value:" + str(value))

        def resolve(value):
            assert value == expected

        result.fork(reject, resolve)

    value1 = 1
    value2 = 2
    value3 = 3

    task1 = Task.reject(value1)
    task2 = Task.of(value2)
    task3 = Task.of(value3)

    fn = lambda arg: Task.reject(arg * 2)

# Generated at 2022-06-12 05:37:58.146650
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(10).bind(lambda x: Task.of(x + 2)).fork(
        lambda err: print('Reject'),
        lambda res: res is 12
    )
    assert Task.reject(10).bind(lambda x: Task.of(x + 2)).fork(
        lambda err: err is 10,
        lambda _: False
    )


# Generated at 2022-06-12 05:38:01.587858
# Unit test for method map of class Task
def test_Task_map():
    def plus(x):
        return x + 1
    task = Task.of(1)
    assert task.map(plus).fork(None, lambda x: x == 2)


# Generated at 2022-06-12 05:38:11.957259
# Unit test for method map of class Task
def test_Task_map():
    def add_x(x):
        return lambda y: x + y

    assert Task(lambda reject, resolve: resolve(1)).map(add_x(2)).fork(lambda reject: 'error', lambda resolve: resolve)() == 3
    assert Task(lambda reject, resolve: resolve(1)).map(add_x(2)).map(add_x(3)).map(add_x(4)).fork(lambda reject: 'error', lambda resolve: resolve)() == 10

    # But in this case we lost reject possibility, because function reject is not called in map function
    assert Task(lambda reject, resolve: reject('error')).map(add_x(2)).fork(lambda reject: 'error', lambda resolve: resolve)() == 3


# Generated at 2022-06-12 05:38:19.228049
# Unit test for method map of class Task
def test_Task_map():
    # Check map of Task of function
    assert Task.of(lambda x: x + 1).map(lambda f: f(1)) == Task.of(2)
    # Check map of Task of number
    assert Task.of(1).map(lambda x: x + 1) == Task.of(2)


# Generated at 2022-06-12 05:38:24.832053
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        if x == 2:
            return Task.reject(2)
        return Task.of(x)

    # reject
    assert Task.of(1).bind(f).fork(lambda reject: reject, lambda resolve: resolve) == 1
    ## reject
    assert Task.of(2).bind(f).fork(lambda reject: reject, lambda resolve: resolve) == 2


# Generated at 2022-06-12 05:38:33.803468
# Unit test for method bind of class Task
def test_Task_bind():
    test_list = [
        {
            'input': {
                'task': None,
                'fn': None,
                'resolve': None,
                'reject': None,
            },
            'expect': None,
        }
    ]

    for test in test_list:
        input = test.get('input')
        if not input:
            continue

        task = input.get('task')
        if not task:
            continue

        fn = input.get('fn')
        if not fn:
            continue

        resolve = input.get('resolve')
        if not resolve:
            continue

        reject = input.get('reject')
        if not reject:
            continue

        task.bind(fn).fork(reject, resolve)

        assert task.fork(reject, resolve) == test.get

# Generated at 2022-06-12 05:38:39.778339
# Unit test for method bind of class Task
def test_Task_bind():
    """
    def fork(reject, resolve):
        return resolve(42)

    task_42 = Task(fork)
    task_42.fork(
        lambda arg: assert arg == 42,
        lambda arg: assert arg == 42
    )

    assert task_42.bind(lambda arg: Task.of(arg * 10)) is Task.of(420)
    """
    pass


# Generated at 2022-06-12 05:38:48.804653
# Unit test for method bind of class Task
def test_Task_bind():
    print("Test method bind of class Task")

    # Define test
    @Task.of
    def call_fn_with_arg(arg):
        return "arg is '{}'".format(str(arg))

    # Execute test
    def test_task_with_value(value):
        task = Task.of(value)
        task.bind(call_fn_with_arg).fork(print)

    test_task_with_value("string")
    test_task_with_value(123)
    test_task_with_value(True)


# Generated at 2022-06-12 05:38:58.866843
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Testing method bind of class Task
    """

# Generated at 2022-06-12 05:39:09.833231
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task class.
    """
    def is_even(value):
        """
        Check input value for even.
        """
        return value % 2 == 0

    def double(value):
        """
        Double value.
        """
        return value * 2

    def decrement(value):
        """
        Decrement value.
        """
        return value - 1

    def equals(value, arg):
        """
        Check equality of input value and arg.
        """
        return value == arg

    def fork(reject, resolve):
        """
        Fork of Task. Return resolved Task with value.
        """
        return resolve(2)

    task = Task(fork)
    task_even = task.map(is_even)

# Generated at 2022-06-12 05:39:17.323395
# Unit test for method map of class Task
def test_Task_map():
    # Task.of(2) -> Task[Function(_, resolve) -> A]
    # Task[Function(_, resolve) -> A].map(lambda x: x + 1) -> Task[Function(_, resolve) -> A + 1]
    # result = Task[Function(_, resolve) -> A + 1]
    result = Task.of(2).map(lambda x: x + 1)
    assert result.fork(lambda x: x, lambda x: x) == 3



# Generated at 2022-06-12 05:39:22.743001
# Unit test for method map of class Task
def test_Task_map():
    inc = lambda x: x + 1
    double = lambda x: x * 2

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork).map(inc).map(double)
    assert task.fork(
        lambda reject_arg: False,
        lambda resolve_arg: resolve_arg
    ) == 4, "Task.map"


if __name__ == "__main__":
    test_Task_map()

# Generated at 2022-06-12 05:39:27.163621
# Unit test for method map of class Task
def test_Task_map():
    t1 = Task.of(1)
    t2 = t1.map(lambda x: x + 1)
    assert t1.fork(None, assert_equal(1))
    assert t2.fork(None, assert_equal(2))


# Generated at 2022-06-12 05:39:37.377812
# Unit test for method bind of class Task
def test_Task_bind():
    def f(_):
        return Task.of(1)

    def g(x):
        return Task.of(x + 1)

    # return 1 after Task.of(1) execution
    assert Task.of(1).bind(f).fork(None, lambda x: x) == 1
    # return 2 after Task.of(1) execution
    assert Task.of(1).bind(g).fork(None, lambda x: x) == 2


# Generated at 2022-06-12 05:39:46.036494
# Unit test for method map of class Task
def test_Task_map():
    """
    Test work of map method of class Task

    :return: True if method works properly
    :rtype boolean:
    """
    def assertWork(value):
        """
        Assert that value is equals to expected

        :param value: result of call map
        :type value: A
        :return: True if value is equal to expected
        :rtype: boolean
        """
        expected = 10
        return value == expected

    task = Task.of(5).map(lambda x: x * 2)
    return task.fork(lambda _: False, assertWork)


# Generated at 2022-06-12 05:39:52.082260
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    assert task.fork(lambda x: x, lambda x: x) == 2

    task = task.map(lambda x: x + 1)
    assert task.fork(lambda x: x, lambda x: x) == 3

    task = task.map(lambda x: x * x)
    assert task.fork(lambda x: x, lambda x: x) == 4

    task = task.map(lambda x: -x)
    assert task.fork(lambda x: x, lambda x: x) == -4



# Generated at 2022-06-12 05:39:56.238840
# Unit test for method bind of class Task
def test_Task_bind():
    from cpyutils.test.test_utils import check_eq

    def f(x):
        return Task.of(x + 1)

    task = Task.of(6)
    check_eq(task.bind(f).fork(lambda x: x, lambda x: x), 7)

# Generated at 2022-06-12 05:40:05.122069
# Unit test for method bind of class Task
def test_Task_bind():
    @Task
    def fetch(resolve, reject):
        return requests.get('http://numbersapi.com/1')

    @Task
    def extract_response(resolve, reject):
        return fetch(reject, resolve)

    @Task
    def decode(resolve, reject):
        return extract_response(reject, resolve).text

    @Task
    def extract_number(resolve, reject):
        return regexp.search(r'[0-9]+', decode(reject, resolve)).group()

    assert extract_number(lambda _: None, lambda arg: arg) == '1'


# Generated at 2022-06-12 05:40:09.990047
# Unit test for method map of class Task
def test_Task_map():
    add = lambda x, y: x + y
    add_task = Task.of(add)
    task = add_task.map(lambda add: add(3, 2))
    assert task.fork(lambda _: False, lambda x: x == 5)



# Generated at 2022-06-12 05:40:20.200297
# Unit test for method bind of class Task
def test_Task_bind():
    def upper(value):
        return str(value).upper()

    def task1(reject, resolve):
        time.sleep(1)
        resolve('Arg1')

    def task2(reject, resolve):
        time.sleep(1)
        resolve('Arg2')

    def task3(reject, resolve):
        time.sleep(2)
        resolve('Arg3')

    task1 = Task(task1)
    task2 = Task(task2)
    task3 = Task(task3)

    def task4(reject, resolve):
        task2.bind(upper).bind(lambda x: task3).map(upper).fork(
            lambda arg: reject(arg),
            lambda arg: resolve(arg)
        )

    task4 = Task(task4)

# Generated at 2022-06-12 05:40:26.156093
# Unit test for method bind of class Task
def test_Task_bind():
    """
    <pre>
    Task<A>.bind(Task<B>): -> Task<A>
    </pre>
    """
    def fork(reject, resolve):
        return resolve(100)

    task = Task(fork)

    def mapper(x):
        return Task.of(x * 2)

    result = task.bind(mapper)

    def fork(reject, resolve):
        return resolve(result)

    assert Task(fork).fork(
        lambda arg: False,
        lambda arg: arg == 200
    )

# Generated at 2022-06-12 05:40:34.348387
# Unit test for method map of class Task
def test_Task_map():
    def is_even(arg):
        return arg % 2 == 0

    def is_odd(arg):
        return arg % 2 == 1

    assert Task.of(2).map(is_even).fork(None, lambda arg: is_even(arg)) == True

    assert Task.of(2).map(is_odd).fork(None, lambda arg: is_even(arg)) == False

    assert Task.of(2).map(is_even).map(is_odd).fork(None, lambda arg: is_even(arg)) == False


# Generated at 2022-06-12 05:40:39.309776
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return "resolve: " + str(value)

    def reject(value):
        return "reject: " + str(value)
    print(Task(lambda reject, resolve: resolve(resolve("one"))).map(lambda x: x(2)).fork(reject, resolve))


# Generated at 2022-06-12 05:41:00.271445
# Unit test for method map of class Task
def test_Task_map():
    """
    Invert function return True if function argument, SimpleTask,
    was resolved and was called with arguments (1, 2, 3)

    :returns: inverted function
    :rtype: Function(SimpleTask[1, 2, 3]) -> Bool
    """
    def result(task):
        def resolve(arguments):
            return arguments != (1, 2, 3)

        return task.fork(lambda _: True, resolve)

    def resolve(*args):
        pass

    def reject(*args):
        pass

    return Task(resolve).map(lambda x: (
        x, x + 1, x + 2)).fork(reject, result) == False



# Generated at 2022-06-12 05:41:07.602463
# Unit test for method bind of class Task
def test_Task_bind():
    def double(x):
        return Task.of(x + x)

    def add_four(x):
        return Task.of(x + 4)

    def is_number(val):
        if isinstance(val, int):
            return val
        else:
            return Task.reject(val)

    result = Task.of(1).bind(double).bind(add_four).bind(is_number)

    assert result.fork(
        lambda err: err,
        lambda val: val + 3
    ) == 8

# Generated at 2022-06-12 05:41:16.929349
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map
    map is a function for transform Task`s value
    """

    def increment(value):
        return value + 1

    # Ensure that Task.of return dict with correct 'fork' key
    assert Task.of(1).map(increment).fork(None, None) == 2

    # Ensure that map function properly transform value
    assert Task.of(1).map(increment).map(increment).fork(None, None) == 3

    # Ensure that Task.reject return dict with correct 'fork' key
    assert Task.reject(1).map(increment).fork(None, None) == 1

# Generated at 2022-06-12 05:41:21.127366
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)).map(lambda value: value + 1).fork(lambda arg: arg, lambda arg: arg) == 2
    return True


# Generated at 2022-06-12 05:41:28.088027
# Unit test for method map of class Task
def test_Task_map():
    """
    Test if Task map method work

    :returns: `True` if tests pass, `False` otherwise
    :rtype: bool
    """
    func_mapper = lambda x: x * x
    value = 2
    task = Task.of(value)
    mapped_task = task.map(func_mapper)
    result = mapped_task.fork(None, lambda x: x)

    assert result == func_mapper(value)
    return True



# Generated at 2022-06-12 05:41:33.509233
# Unit test for method bind of class Task
def test_Task_bind():
    """
    When call fork method of class Task
    then it should return value
    """
    def fork(reject, resolve):
        resolve(5)

    task = Task(fork)

    result = task.bind(lambda _: Task.of('abc')).fork(
        lambda _: 'test_failed'
    )

    assert result == 'abc'



# Generated at 2022-06-12 05:41:43.516457
# Unit test for method bind of class Task
def test_Task_bind():
    """Unit test for method bind of class Task."""

    def fork(value):
        return lambda _, resolve: resolve(value)

    task = Task(fork(5)).bind(lambda value: Task.of(value * 2))
    assert task.fork(lambda _: _, lambda arg: arg) == 10

    map_result = Task.of(5).bind(
        lambda value: Task.of(value * 4)
    ).fork(
        lambda _: _,
        lambda arg: arg
    )
    assert map_result == 20

    task_resolve = Task.reject(5).bind(
        lambda _: Task.of(4)
    ).fork(
        lambda _: _,
        lambda _: _
    )
    assert task_resolve == 5



# Generated at 2022-06-12 05:41:48.467669
# Unit test for method bind of class Task
def test_Task_bind():
    fork1 = lambda reject, resolve: resolve(1)
    task1 = Task(fork1)

    fork2 = lambda reject, resolve: resolve(2)
    task2 = Task(fork2)

    def fn(x):
        return task2

    result = task1.bind(fn)

    def fork1_check(reject, resolve):
        def fork2_check(x):
            assert x == 2
            return resolve(x)

        return task2.fork(reject, fork2_check)


# Generated at 2022-06-12 05:41:56.185694
# Unit test for method map of class Task
def test_Task_map():
    """
    Test have to show that, when call method map of class Task,
    all supposing handlers will be called with correct args.

    Return:
        correct_execution :: Boolean
    """
    a = 3
    b = 4
    def mapper(arg):
        return arg + b
    fn = mapper
    value = a

    def resolve(arg):
        return arg == value + b
    def reject(arg):
        return False

    return Task.of(value).map(fn).fork(reject, resolve)


# Generated at 2022-06-12 05:42:05.472086
# Unit test for method bind of class Task
def test_Task_bind():
    def _():
        assert Task(lambda _, resolve: resolve(4)).bind(lambda value: Task.of(value * 2)) == Task(lambda _, resolve: resolve(8))

    def _():
        def mapper(value):
            return Task.reject(value)

        assert Task(lambda _, resolve: resolve(4)).bind(mapper) == Task(lambda reject, _: reject(4))

    def _():
        assert Task(lambda reject, _: reject(4)).bind(lambda value: Task.of(value * 2)) == Task(lambda reject, _: reject(4))

    def _():
        def mapper(value):
            return Task.reject(value)

        assert Task(lambda reject, _: reject(4)).bind(mapper) == Task(lambda reject, _: reject(4))

    _()

# Generated at 2022-06-12 05:42:36.407200
# Unit test for method bind of class Task
def test_Task_bind():
    def generate_Task(value):
        def inner(reject, resolve):
            resolve(value)
        return Task(inner)

    def fn(value):
        return generate_Task(value * 2)

    # check correct call
    assert Task.of(1).bind(fn).fork(lambda v: False, lambda v: v) == 2
    # check correct call with `reject`
    assert Task.reject(0).bind(fn).fork(lambda v: v, lambda v: None) == 0



# Generated at 2022-06-12 05:42:43.612718
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(1).bind(lambda x: Task.of(3 * x))
    assert isinstance(result, Task)
    assert result.fork(lambda x: -1, lambda x: x) == 3

    result = Task.reject("kakawka").bind(lambda x: Task.of("kakawka"))
    assert isinstance(result, Task)
    assert result.fork(lambda x: x, lambda x: x) == "kakawka"


# Generated at 2022-06-12 05:42:47.132054
# Unit test for method map of class Task
def test_Task_map():
    origin = Task.of(2)
    new = origin.map(lambda arg: arg + 2)

    assert new.fork(lambda arg: arg, lambda arg: arg) == 4



# Generated at 2022-06-12 05:42:56.420808
# Unit test for method bind of class Task
def test_Task_bind():
    def create_user(email):
        if email == 'root@root.com':
            return Task.reject('Error! Try again!')
        return Task.of({'email': email, 'id': 1})

    def create_token(user):
        return Task.of({'user': user, 'token': generate_token()})

    def generate_token():
        return 'tttttttttttt'

    def test_result(reject, resolve):
        return resolve('test')

    task = Task(test_result)
    result = task.map(lambda x: x.upper()).bind(
        lambda x: create_user('root@root.com')
    )
    assert result == 'Error!'


# Generated at 2022-06-12 05:43:02.121338
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return lambda y: x + y

    def fork(*argv):
        assert len(argv) == 2
        assert type(argv[0]) is not type(argv[1])
        return argv[1](10)

    assert Task(fork).map(add(10)) == 20


# Generated at 2022-06-12 05:43:07.873995
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(arg):
        return arg
    def fn2(arg):
        return arg + 2
    def fn3(arg):
        return Task.of(arg + 3)

    assert Task.of(2) \
        .map(fn) \
        .map(fn2) \
        .bind(fn3) \
        .fork(
            lambda arg: -1,
            lambda arg: arg
        ) == 7


# Generated at 2022-06-12 05:43:12.922325
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        assert type(value) == int
        return value + 1

    def fn(operation):
        assert type(operation) == Task
        return operation.map(mapper)

    def test(reject, resolve):
        return fn(Task.of(42)).fork(reject, resolve)

    assert Task(test).fork(lambda x: x, lambda x: x) == 43

# Generated at 2022-06-12 05:43:18.016642
# Unit test for method map of class Task
def test_Task_map():
    def f(x):
        return x * 2

    def result(a):
        return Task.of(a).map(f).fork(lambda _: "Error", lambda res: res)

    assert result(1) == 2
    assert result(-1) == -2
    assert result(0) == 0


# Generated at 2022-06-12 05:43:23.565533
# Unit test for method map of class Task

# Generated at 2022-06-12 05:43:27.031068
# Unit test for method map of class Task
def test_Task_map():
    task_value = Task.of(10)
    assert task_value.map(lambda value: value + 10).fork(lambda value: value, lambda value: value) == 20


# Generated at 2022-06-12 05:44:30.716524
# Unit test for method map of class Task
def test_Task_map():
    # import Task and Identity
    from monad import Task, Identity

    # function to resolve argument
    def resolver(value):
        return value

    # function to reject argument
    def rejecter(value):
        raise value

    def test_map_a_to_a():
        # define base value
        a = 1

        # define mapper
        mapper = lambda value: value

        # define Task with base value and mapper
        task = Task.of(a).map(mapper)

        # define expected result
        expected = Task.of(a)

        # call fork of Task above
        result = task.fork(rejecter, resolver)

        # assert if result is equal expected
        assert result == expected

    def test_map_a_to_b():
        # define base value
        a = 1

        #

# Generated at 2022-06-12 05:44:34.397515
# Unit test for method bind of class Task
def test_Task_bind():
    """Return resolved Task with stored value argument."""
    assert Task(lambda _, resolve: resolve(1))\
        .bind(lambda x: Task.of(x + 1))\
        .bind(lambda x: Task.of(x + 2))\
        .fork(lambda _: 'fail', lambda x: x) == 4


# Generated at 2022-06-12 05:44:40.317447
# Unit test for method map of class Task
def test_Task_map():
    def add_10(x):
        return x + 10

    assert Task(lambda _, resolve: resolve(10)).map(add_10).fork(
        lambda error: error,
        lambda value: value
    ) == 20

    assert Task(lambda reject, _: reject(10)).map(add_10).fork(
        lambda error: error,
        lambda value: value
    ) == 10


# Generated at 2022-06-12 05:44:45.864359
# Unit test for method map of class Task
def test_Task_map():
    # pylint: disable=protected-access
    value = 'value'
    task = Task.of(value)
    expected = 'mapped_value'
    mapped_task = task._map(lambda arg: expected)

    assert mapped_task._fork is None
    assert mapped_task._map is not None
    assert mapped_task._fork(lambda reject: reject('err'), lambda resolve: resolve('value')) == expected


# Generated at 2022-06-12 05:44:55.180956
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """

    # Test that function handle resolve action
    assert Task.of('test').bind(lambda arg: Task.of(arg.upper())).fork(lambda _: None, lambda result: result == 'TEST')

    # Test that function handle reject action
    assert Task.reject('test').bind(lambda arg: Task.of(arg.upper())).fork(lambda result: result == 'TEST',lambda _: None)

    # Test that function handle mixed resolve/reject actions
    assert Task.of('test').bind(lambda arg: Task.reject('error')).fork(lambda result: result == 'error', lambda _: None)


# Generated at 2022-06-12 05:45:03.967391
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value

    task1 = Task.of(1).map(mapper)
    assert task1.fork(lambda arg: arg, lambda arg: arg) == 1

    task2 = Task.of(1).map(lambda arg: arg + 1)
    assert task2.fork(lambda arg: arg, lambda arg: arg) == 2

    task3 = Task.reject(1).map(mapper)
    assert task3.fork(lambda arg: arg, lambda arg: arg) == 1



# Generated at 2022-06-12 05:45:07.966783
# Unit test for method map of class Task
def test_Task_map():
    def double(value):
        return value * 2

    task = Task.of(2).map(double)

    assert task.fork(None, lambda result: result) == 4


# Generated at 2022-06-12 05:45:13.373483
# Unit test for method bind of class Task
def test_Task_bind():
    def times_two(x):
        return Task.of(2 * x)

    def add(x, y):
        return Task.of(x + y)

    x = Task.of(20)
    y = Task.of(30)

    assert x.bind(times_two).bind(lambda r: add(r, 10)).fork(None, lambda x: x) == 60
    assert x.bind(times_two).bind(lambda r: add(r, 10)).fork(lambda x: x, None) is None


# Generated at 2022-06-12 05:45:20.212457
# Unit test for method map of class Task
def test_Task_map():
    """Unit test for method map of class Task."""
    task_resolved = Task.of(1).map(lambda x: x + 1)
    assert task_resolved.fork(lambda x: None, lambda x: x) == 2

    task_rejected = Task.reject(1)
    task_rejected_mapped = task_rejected.map(lambda x: x + 1)
    assert task_rejected_mapped.fork(lambda x: x, lambda x: None) == 1


# Generated at 2022-06-12 05:45:26.815050
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map.

    :raises: AssertionError if result Task not equal by Task.
    """
    value = 1
    mapped_value = value + 1

    task = Task.of(value).map(lambda arg: arg + 1)

    def run_test():
        assert mapped_value == task.fork(None, lambda arg: arg)

    run_test()

