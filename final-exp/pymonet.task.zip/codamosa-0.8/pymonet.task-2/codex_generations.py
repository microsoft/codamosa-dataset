

# Generated at 2022-06-12 05:36:11.356537
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    """
    def success_fn_double(val):
        """
        Take argument, double it and return new Task with this argument.

        :param val: value to map
        :type val: A
        :returns: new Task with mapped value
        :rtype: Task[A | B]
        """
        return Task.of(val * 2)

    def success_fn_triple(val):
        """
        Take argument, triple it and return new Task with this argument.

        :param val: value to map
        :type val: A
        :returns: new Task with mapped value
        :rtype: Task[A | B]
        """
        return Task.of(val * 3)


# Generated at 2022-06-12 05:36:15.603691
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(100)

    assert Task.of(100).bind(fn).fork(None, lambda value: value) == 100
    assert Task.reject(100).bind(fn).fork(lambda value: value, None) == 100

# Generated at 2022-06-12 05:36:22.768188
# Unit test for method map of class Task
def test_Task_map():
    def case_of_map():
        return Task.of(2)

    def test_Task_map_resolve():
        def test_map_resolve(value):
            if value == 2:
                return 'ok'
            else:
                return 'fail'

        actual = case_of_map().map(test_map_resolve)
        expected = Task.of('ok')

        assert actual.fork(None, lambda arg: arg) == expected.fork(None, lambda arg: arg)

    def case_of_map_error():
        return Task.reject('Task error')

    def test_Task_map_reject(value):
        if value == 'Task error':
            return 'ok'
        else:
            return 'fail'


# Generated at 2022-06-12 05:36:31.272884
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(2)

    def fork2(reject, resolve):
        return resolve(1)

    def fork3(reject, resolve):
        return reject(1)

    def fork4(reject, resolve):
        return resolve(3)

    def mapper1(value):
        return Task(fork2).bind(lambda value: Task(fork3).bind(lambda value: Task(fork4)))

    def mapper2(value):
        return Task(fork2).bind(lambda value: Task(fork3))

    def mapper3(value):
        return Task(fork3).bind(lambda value: Task(fork4))

    def mapper4(value):
        return Task(fork4)

    def mapper5(value):
        return Task(fork3)


# Generated at 2022-06-12 05:36:37.209398
# Unit test for method map of class Task
def test_Task_map():
    def mapper(x):
        return x * 2

    def add(x):
        return x + 2

    def reject(arg):
        return arg

    def resolve(arg):
        return arg

    task = Task(lambda reject, resolve: resolve(5))
    assert task.fork(reject, resolve) == resolve(5)
    task = task.map(mapper)
    assert task.fork(reject, resolve) == resolve(10)
    task = task.map(add)
    assert task.fork(reject, resolve) == resolve(12)



# Generated at 2022-06-12 05:36:42.753484
# Unit test for method map of class Task
def test_Task_map():
    """
    Map should return new Task with mapped resolve attribute.
    """
    def fn(value):
        return value + 2

    value = 1
    task = Task.of(value).map(fn)

    result = task.fork(
        lambda _: None,
        lambda arg: arg
    )

    assert fn(value) == result



# Generated at 2022-06-12 05:36:46.316208
# Unit test for method bind of class Task
def test_Task_bind():
    val = 1
    expected = val
    assert Task.of(expected).bind(lambda a: Task.of(a)).fork(None, lambda a: a) == val


# Generated at 2022-06-12 05:36:54.681205
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    test_value = 1
    test_result = 2
    test_error = 3

    def test_function_success(value):
        """
        Take value, apply to it some transformation and return.

        :param value: integer value
        :type value: int
        :returns: result of transformation
        :rtype: int
        """
        assert value == test_value
        return value + 1

    def test_function_fail(value):
        """
        Take value, apply to it some transformation and return.

        :param value: integer value
        :type value: int
        :returns: result of transformation
        :rtype: int
        """
        assert value == test_value
        return Task.reject(value + 1)


# Generated at 2022-06-12 05:37:04.088240
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    # Success test, check if enclosed value is equal to result of
    # computations which done with Task
    def f(x):
        return Task.of(x + 1)

    def g(x):
        return Task.of(x + 1)

    expected = 5

    assert Task.of(1).bind(f).bind(g).fork(lambda _: False, lambda result: result == expected)

    # Failure test, check if enclosed value is equal to enclosed value
    # after one error which return value of error
    def f(x):
        return Task.reject(x * x)

    def g(x):
        return Task.of(x + 1)

    expected = 1


# Generated at 2022-06-12 05:37:09.205444
# Unit test for method map of class Task
def test_Task_map():
    def add2(num):
        return num + 2

    def err(num):
        return num ** 2

    task = Task(lambda reject, resolve: resolve(5))
    assert task.map(add2).fork(None, None) == 7

    task = Task(lambda reject, resolve: reject(5))
    assert task.map(add2).fork(None, None) == 25


# Generated at 2022-06-12 05:37:14.807672
# Unit test for method map of class Task
def test_Task_map():
    inc = lambda value: value + 1
    result = Task.of(2).map(inc)
    assert 3 == result.fork(lambda _: 0, lambda value: value)


# Generated at 2022-06-12 05:37:20.406079
# Unit test for method map of class Task
def test_Task_map():
    def f(x):
        return x * 2

    x = Task(lambda _, resolve: resolve(1))
    assert x.map(f).fork(lambda _: None, lambda x: x) == 2

    x = Task(lambda reject, _: reject('error'))
    assert x.map(f).fork(lambda err: err, lambda _: None) == 'error'


# Generated at 2022-06-12 05:37:26.547919
# Unit test for method map of class Task
def test_Task_map():
    def plus_one(value):
        return value + 1

    task = Task(lambda reject, resolve: resolve(1))
    assert isinstance(task, Task)

    computed_task = task.map(plus_one)
    assert isinstance(computed_task, Task)
    assert computed_task.fork(lambda _: None, lambda result: result) == 2


# Generated at 2022-06-12 05:37:28.904624
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(1).map(lambda arg: arg + 1)
    assert result.fork(lambda arg: arg, lambda arg: arg) == 2

# Generated at 2022-06-12 05:37:34.528867
# Unit test for method map of class Task
def test_Task_map():
    """Test for method map of class Task."""
    # pylint: disable=expression-not-assigned

    assert Task(lambda _, resolve: resolve(5)) \
        .map(lambda x: x + 1) \
        .fork(lambda _: None, lambda x: x) \
        == 6



# Generated at 2022-06-12 05:37:43.406535
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test: Task.bind
    Case: function to be called not return Task instance
    Expected: raise TypeError
    """
    def fn(arg):
        return arg

    try:
        Task.of(1).bind(fn)
    except TypeError:
        pass
    else:
        raise TypeError("Bound value after fork must be a Task")

    """
    Test: Task.bind
    Case: function to be called return Task instance
    Expected: binded Task
    """
    result = Task.of(1).bind(lambda _: Task.of(2)).fork(
        lambda arg: arg,
        lambda arg: arg
    )
    assert result == 2

# Generated at 2022-06-12 05:37:54.913246
# Unit test for method bind of class Task
def test_Task_bind():
    def test_success():
        assert Task.of('Test').bind(lambda v: Task.of(v + '_Task')).fork(lambda _: None, lambda v: v) == 'Test_Task'

    def test_success_mul():
        def bind_add(v):
            return Task.of(v + '_bind')

        def bind_add_a(v):
            return Task.of(v + '_a')

        assert Task.of('Test').bind(bind_add).bind(bind_add_a).fork(lambda _: None, lambda v: v) == 'Test_bind_a'

    def test_success_mul_x2():
        def bind_add(v):
            return Task.of(v + '_bind')


# Generated at 2022-06-12 05:38:02.416154
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)).map(lambda value: value + 1).fork(
        lambda value: (1, value),
        lambda value: (0, value)
    ) == (0, 2)

    assert Task.of(1).map(lambda value: value + 1).fork(
        lambda value: (1, value),
        lambda value: (0, value)
    ) == (0, 2)

    assert Task.reject(1).map(lambda value: value + 1).fork(
        lambda value: (1, value),
        lambda value: (0, value)
    ) == (1, 1)


# Generated at 2022-06-12 05:38:07.054199
# Unit test for method bind of class Task
def test_Task_bind():
    # two arguments, return first
    f = lambda a, b: a
    result = Task.of(1).bind(lambda arg: Task.of(f(arg, 2))).fork(lambda arg: arg, lambda arg: arg)
    assert result == 1


# Generated at 2022-06-12 05:38:12.735267
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda reject, resolve: resolve(1))\
        .map(lambda value: value + 2)\
        .fork(None, lambda value: value) == 3

    assert Task(lambda reject, resolve: reject(1))\
        .map(lambda value: value + 2)\
        .fork(lambda value: value, None) == 1
# End unit test for method map of class Task


# Generated at 2022-06-12 05:38:22.748862
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(arg):
        return Task(lambda _, resolve: resolve(arg + 1))

    task = Task(lambda _, resolve: resolve(2))

# Generated at 2022-06-12 05:38:32.197375
# Unit test for method map of class Task
def test_Task_map():
    assert isinstance(Task.of(2).map(lambda x: x**2), Task)
    assert Task.of(2).map(lambda x: x**2).fork(lambda x: x, lambda x: x) == 4
    assert Task.of(None).map(lambda x: x**2).fork(lambda x: x, lambda x: x) is None

    assert isinstance(Task.of(2).map(lambda x: Task.of(x**2)), Task)
    assert Task.of(2).map(lambda x: Task.of(x**2)).fork(lambda x: x, lambda x: x) == 4
    assert Task.of(None).map(lambda x: Task.of(x**2)).fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-12 05:38:36.909123
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return reject('first')

    task = Task(fork)
    task = task.map(lambda x: x + ' second')

    assert task.fork(lambda x: x, lambda x: x) == 'first second'


# Generated at 2022-06-12 05:38:47.982609
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind method with map function and
    function, which return Task.resolve or Task.reject.
    """
    def run():
        """
        Run test for Task.bind
        """
        def add_one(value):
            """
            Add one to given value

            :param value: value to add
            :type value: int
            :returns: new value
            :rtype: int
            """
            return value + 1

        # mapper function
        def add_two(_):
            """
            Add two to given value

            :param _: value to add
            :type _: int
            :returns: new value
            :rtype: int
            """
            return _ + 2

        # function returns Task.resolve with given value

# Generated at 2022-06-12 05:38:58.110025
# Unit test for method bind of class Task
def test_Task_bind():
    """Tests for method bind of class Task"""
    def task(value):
        # Get a new task with setted value
        def fork(reject, resolve):
            resolve(value)
            return None

        return Task(fork)

    def increment(value):
        # Function to increment valu
        return value + 1

    # Test some cases
    result = task(0).bind(task)
    assert result.fork(lambda _: None, lambda arg: arg) == 0

    result = task(1).bind(lambda arg: task(arg + 1))
    assert result.fork(lambda _: None, lambda arg: arg) == 2

    result = task(1).bind(lambda arg: task(arg + 1)).bind(lambda arg: task(arg + 3))
    assert result.fork(lambda _: None, lambda arg: arg)

# Generated at 2022-06-12 05:39:00.550350
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    def fn(_):
        return 'a'
    task_resul

# Generated at 2022-06-12 05:39:10.938316
# Unit test for method map of class Task
def test_Task_map():
    def task_factory(resolve_value, reject_value):
        def function(reject, resolve):
            if reject_value is not None:
                reject(reject_value)
                return
            resolve(resolve_value)

        return Task(function)

    def mapper(value):
        return value * 2

    mock_reject = mock.Mock()

    task = task_factory(20, None)
    task.map(mapper)
    task.fork(mock_reject, mock.Mock())
    mock_reject.assert_not_called()

    mock_resolve = mock.Mock()
    task = task_factory(20, None)
    task.map(mapper)
    task.fork(mock.Mock(), mock_resolve)
    mock_resolve

# Generated at 2022-06-12 05:39:14.851472
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(5)

    task = Task(fork)
    assert task.bind(lambda x: Task.of(x + 3)).fork(lambda x: x, lambda x: x) == 8



# Generated at 2022-06-12 05:39:19.325026
# Unit test for method map of class Task
def test_Task_map():
    fork = lambda _, resolve: resolve('Hello')
    task = Task(fork)

    task_map = task.map(lambda value: value.upper())
    assert _call_task(task_map) == 'HELLO'



# Generated at 2022-06-12 05:39:24.196730
# Unit test for method map of class Task
def test_Task_map():
    expected = Task.of(2)
    actual = Task.of(1).map(lambda value: value)
    assert expected.fork(lambda value: value, lambda value: value) \
        == actual.fork(lambda value: value, lambda value: value)


# Generated at 2022-06-12 05:39:43.842887
# Unit test for method map of class Task
def test_Task_map():
    def _test_Task_map(test_cases):
        for test in test_cases:
            assert test['task'].map(test['mapFunction']).fork(
                lambda arg: 'rejected',
                lambda arg: arg,
            ) == test['result']

    _test_Task_map({
        'task': Task(lambda _, resolve: resolve(1)),
        'mapFunction': lambda x: x + 2,
        'result': 3
    })

    _test_Task_map({
        'task': Task.of(1),
        'mapFunction': lambda x: x + 2,
        'result': 3
    })


# Generated at 2022-06-12 05:39:47.157372
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    task = task.map(lambda arg: arg + 1)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-12 05:39:58.082703
# Unit test for method bind of class Task
def test_Task_bind():
    count = 0

    def test_fn(resolve, reject):
        nonlocal count
        count += 1
        raise Exception('test error')

    def MyTask(arg):
        return Task(test_fn)

    def MyMap(arg):
        return arg + 2

    def MyBind(arg):
        return Task(lambda reject, resolve: resolve(arg))

    Task.reject('test').bind(MyMap).fork(lambda arg: None, lambda arg: print(arg))
    Task.of('test').bind(MyMap).fork(lambda arg: None, lambda arg: print(arg))
    Task.of('test').bind(MyBind).fork(lambda arg: print(arg), lambda arg: print(arg))

# Generated at 2022-06-12 05:40:03.173626
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)).map(lambda x: x + 1).fork(None, lambda x: x) == 2
    assert Task(lambda _, resolve: resolve(3)).map(lambda x: x ** 4).fork(None, lambda x: x) == 81


# Generated at 2022-06-12 05:40:09.004506
# Unit test for method bind of class Task
def test_Task_bind():
    # Create a Task with resolve attribute
    task = Task.of(42)
    # Bind resolve attribute to the function, take 42, add 2, return result
    result = task.bind(lambda value: Task.of(value + 2))

    # Expect that result is a Task with resolve attribute 44
    assert result.fork(lambda arg: arg, lambda arg: arg) == 44

if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-12 05:40:13.293070
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(_):
        return Task(lambda _, resolve: resolve(2))

    task = Task(lambda _, resolve: resolve(1))
    result = task.bind(fn)

    assert result.fork(lambda _: "error", lambda value: value) == 2



# Generated at 2022-06-12 05:40:18.661087
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return value

    def reject(value):
        return value
    def mapper(value):
        return value + 1

    assert Task(lambda reject, resolve: resolve(0)).map(mapper).fork(reject, resolve) == 1
    assert Task(lambda reject, resolve: reject(0)).map(mapper).fork(reject, resolve) == 0


# Generated at 2022-06-12 05:40:24.578567
# Unit test for method bind of class Task
def test_Task_bind():
    resolve = lambda x: x
    reject = lambda x: x
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(reject, resolve) == 2
    assert Task.reject(1).bind(lambda x: Task.of(x + 1)).fork(reject, resolve) == \
        1

# Base class for encoding/decoding JSON.
# It take schema of this type and instance of data that should valid by this schema.
# During run checks validation and returns result.

# Generated at 2022-06-12 05:40:28.418323
# Unit test for method bind of class Task
def test_Task_bind():
    def add_1_to_value_in_task(value):
        return Task.of(value + 1)

    task = Task.of(1).bind(add_1_to_value_in_task)
    assert task.fork(
        lambda value: False,
        lambda value: value == 2
    )


# Generated at 2022-06-12 05:40:33.670442
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind.
    """
    def unit(value):
        return Task.of(value)
    assert Task.of(1).bind(lambda value: unit(value)).fork(lambda _: None, lambda result: result) == 1


# Generated at 2022-06-12 05:40:55.358944
# Unit test for method bind of class Task
def test_Task_bind():
    return Task.of(1).bind(lambda value: Task.of(value + 1))


# Generated at 2022-06-12 05:41:03.657821
# Unit test for method bind of class Task
def test_Task_bind():
    def lata_fetch_countries_translations_request(locale):
        def request(reject, resolve):
            def fetch(url, options):
                time.sleep(0.5)
                return resolve(u'fetch rus -> {0}'.format(url))

            return fetch(u'url', {})

        return Task(request)

    def lata_fetch_countries_translations_response(
        locale,
        request
    ):
        def response(reject, resolve):
            def fetch(url, options):
                time.sleep(0.5)
                return resolve(u'fetch rus translations -> {0}'.format(request))

            return fetch(u'url', {})

        return Task(response)


# Generated at 2022-06-12 05:41:07.365588
# Unit test for method map of class Task
def test_Task_map():
    def check(arg):
        return Task.of(arg).map(lambda x: x * 2)

    assert check(3).fork(None, lambda x: x) == 6
    assert check(3).fork(lambda x: -x, None) == 3


# Generated at 2022-06-12 05:41:17.517392
# Unit test for method map of class Task
def test_Task_map():
    def task_of():
        return Task.of('value')

    def task_of_fn():
        def fn(value):
            return value + ' mapped'
        return Task.of('value').map(fn)

    def task_reject_fn():
        def fn(value):
            return value + ' mapped'
        return Task.reject('value').map(fn)

    assert task_of().fork(lambda _: None, lambda resolve: resolve) == 'value'
    assert task_of_fn().fork(lambda _: None, lambda resolve: resolve) == 'value mapped'
    assert task_reject_fn().fork(lambda reject: reject, lambda _: None) == 'value'



# Generated at 2022-06-12 05:41:26.474181
# Unit test for method bind of class Task
def test_Task_bind():
    async def async_function(arg):
        print('async_function')
        return arg

    async def async_function_as_Task(arg):
        print('async_function_as_Task')
        return Task.of(arg)

    def function_with_result_as_Task(arg):
        print('function_with_result_as_Task')
        return Task.of(arg)

    def function_with_result_as_Future(arg):
        print('function_with_result_as_Future')
        return IO.of(Future.of(arg))

    def function_with_error():
        print('function_with_error')
        return Task.reject('error')

    def function_with_result_as_IO(arg):
        print('function_with_result_as_IO')
        return

# Generated at 2022-06-12 05:41:29.156599
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    assert task.map(lambda value: value + 1) == Task.of(2)



# Generated at 2022-06-12 05:41:35.162205
# Unit test for method map of class Task
def test_Task_map():
    t = Task.of(2)

    t2 = t.map(lambda x: x ** 2)
    assert t2.fork(None, lambda x: x) == 4

    t = Task.reject(2)

    t2 = t.map(lambda x: x ** 2)
    assert t2.fork(lambda x: x, None) == 2

    t = Task.of(2)

    t2 = t.map(identity)
    assert t2.fork(None, lambda x: x) == 2


# Generated at 2022-06-12 05:41:39.754845
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + "!"

    source_task = Task.of(value="Hello")
    mapped_task = source_task.map(fn)

    assert "Hello!" == mapped_task.fork(lambda err: None, lambda result: result)


# Generated at 2022-06-12 05:41:41.389342
# Unit test for method map of class Task
def test_Task_map():
    task = Task(
        lambda reject, resolve: resolve(1)
    )

    assert task.map(lambda x: x + 1).fork(
        lambda reject: 'no',
        lambda resolve: resolve
    ) == 2


# Generated at 2022-06-12 05:41:48.135476
# Unit test for method bind of class Task
def test_Task_bind():
    """
    For example task have value ```a``` and function ```fn```
    that return new task with value ```a``` and ```b```.
    ```bind``` just return this new task.

    Next we have task with value ```a``` and ```fn```
    that return new task with value ```b```.
    ```bind``` return new task with value ```b```
    """
    def resolve(value):
        assert value == 'a'

    def reject(error):
        pass

    Task(lambda r, res: res('a')).bind(
        lambda a: Task(lambda r, res: res(a))
    ).fork(reject, resolve)



# Generated at 2022-06-12 05:42:33.819137
# Unit test for method bind of class Task
def test_Task_bind():
    def addTen(val):
        return Task.of(val + 10)

    def square(val):
        return Task.of(val ** 2)

    task = Task.of(1).bind(addTen).bind(square)

    assert task.fork(None, lambda res: res == 121)


# Generated at 2022-06-12 05:42:37.416281
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map.

    :returns: True if success, False if failure
    :rtype: bool
    """
    assert Task.of(1).map(lambda x: x+1).fork(None, lambda x: x) == 2




# Generated at 2022-06-12 05:42:42.055808
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value * 2

    task = Task.of(42)
    mapped_task = task.map(fn)
    assert fn(42) == mapped_task.fork(
        lambda _: 0,
        lambda arg: arg
    )


# Generated at 2022-06-12 05:42:52.632544
# Unit test for method map of class Task
def test_Task_map():
    identity = lambda x: x
    identity_task = Task.of(identity)
    mapped_task = identity_task.map(identity)

    assert isinstance(mapped_task, Task)
    assert mapped_task.fork(lambda x: x, lambda x: x) == identity_task.fork(lambda x: x, lambda x: x)
    assert mapped_task.fork(lambda x: x + 1, lambda x: x) == identity
    assert mapped_task.fork(lambda x: x, lambda x: x + 1) == identity_task.fork(lambda x: x, lambda x: x + 1)

    assert identity_task.fork(lambda x: x, lambda x: x) == identity
    assert identity_task.fork(lambda x: x + 1, lambda x: x) == identity
    assert identity_task.fork

# Generated at 2022-06-12 05:42:56.785336
# Unit test for method bind of class Task
def test_Task_bind():
    def reject(task):
        assert task == "bad"

    def resolve(task):
        assert task == "good"

    def make_task(msg):
        return Task(lambda reject, resolve: msg == "good" and resolve(msg) or reject(msg))

    make_task("good").bind(make_task).fork(reject, resolve)


# Generated at 2022-06-12 05:43:07.478349
# Unit test for method bind of class Task
def test_Task_bind():
    fork_1 = lambda reject, resolve: resolve(1)
    task_1 = Task(fork_1)
    fork_2 = lambda reject, resolve: resolve(2)
    task_2 = Task(fork_2)
    fork_3 = lambda reject, resolve: resolve(3)
    task_3 = Task(fork_3)

    def fork(reject, resolve):
        resolve(1)
    fork_1 = Task(fork)
    fork_2 = Task(lambda reject, resolve: resolve(2))
    test = fork_1.bind(lambda x: fork_2)
    assert test.fork(lambda x: None, lambda x: x) == 2

    def fork(reject, resolve):
        resolve(1)
    fork_1 = Task(fork)

# Generated at 2022-06-12 05:43:11.180025
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(x):
        return Task.reject(x + 1)

    a = Task.reject(1).bind(fn)
    assert a.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-12 05:43:17.819088
# Unit test for method map of class Task
def test_Task_map():
    def async_action(value):
        def wrapped_action(resolve):
            def action():
                resolve(value)

            setTimeout(action, 1000)

        return Task(wrapped_action)

    assert async_action(1).bind(lambda value: async_action(value + 1)).fork(
        lambda value: assertEqual(value, 2),
        lambda value: assertEqual(value, 2))


# Generated at 2022-06-12 05:43:20.281633
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(
        lambda x: None,
        lambda x: x
    ) == 2


# Generated at 2022-06-12 05:43:24.781570
# Unit test for method map of class Task
def test_Task_map():
    """
    Check possibility to call map of class Task.
    """
    def resolve(value):
        assert value is True
        print('Map resolved value:', value)

    def reject(error):
        raise AssertionError('Map rejected value: %r' % error)

    Task.of(True).map(lambda arg: not arg).fork(reject, resolve)



# Generated at 2022-06-12 05:44:57.231263
# Unit test for method map of class Task
def test_Task_map():
    """
    Test that Task.map return new Task with expected resolve attribute.
    """
    def resolve(value):
        def result(_, resolve):
            resolve(value)

        return Task(result)

    task = resolve('a').map(lambda value: value)
    assert task.fork(None, lambda arg: arg) == 'a'

# Generated at 2022-06-12 05:45:05.097854
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(
        lambda value: None,
        lambda value: value) == 2

    # Test for laziness
    def lazy_falsy(resolve):
        resolve(True)

    def mapper(value):
        assert value == True

    def falsy(reject):
        assert False

    Task(lazy_falsy).map(mapper).fork(falsy, lambda _: None)


# Generated at 2022-06-12 05:45:09.861481
# Unit test for method map of class Task
def test_Task_map():
    def fn(result):
        return result * 2

    task = Task.of(1)
    task_mapped = task.map(fn)

    assert task_mapped.fork(None, i) == 2


# Generated at 2022-06-12 05:45:17.855373
# Unit test for method bind of class Task
def test_Task_bind():
    def double_then_triple_mapper(value):
        return Task.of(2 * value).map(lambda value: 3 * value)

    assert Task.of(5).bind(double_then_triple_mapper).fork(lambda value: 0, lambda value: value) == 30

    def double_then_triple_mapper_rejected(value):
        return Task.reject(2 * value)

    assert Task.of(5).bind(double_then_triple_mapper_rejected).fork(lambda value: value, lambda value: 0) == 10


# Generated at 2022-06-12 05:45:21.617320
# Unit test for method bind of class Task
def test_Task_bind():
    def apple(name):
        return "Hello, {0}".format(name)

    assert Task("world").map(apple).fork(None, lambda value: value) == "Hello, world"


# Generated at 2022-06-12 05:45:30.943121
# Unit test for method map of class Task
def test_Task_map():
    def resolve_test(resolve):
        resolve(1)

    def reject_test(reject):
        reject(0)

    result = Task(resolve_test).map(lambda arg: arg + 1)
    assert result.fork(lambda arg: reject_test, lambda arg: arg) == 2

    result = Task(resolve_test).map(lambda arg: arg + 1).map(lambda arg: arg * 2)
    assert result.fork(lambda arg: reject_test, lambda arg: arg) == 4

    result = Task(reject_test).map(lambda arg: arg + 1)
    assert result.fork(lambda arg: arg, lambda arg: reject_test) == 0


# Generated at 2022-06-12 05:45:39.429656
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a, b): return a + b

    task = Task.of(1)
    task = task.map(lambda a: add(a, 1))
    task = task.map(lambda a: add(a, 2))
    task = task.map(lambda a: add(a, 3))

    def bind_add(a):
        return Task.of(add(a, 4))

    task = task.bind(bind_add)
    result = task.fork(lambda x: 'No!', lambda x: x)

    assert result == 11


# Generated at 2022-06-12 05:45:47.194519
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        return Task.of(value)

    def reject(value):
        return Task.reject(value)

    def fork(reject, resolve):
        return resolve('hello world')

    def nothing(value):
        return None

    task = Task(fork)

    assert task.bind(nothing) == Task(fork)
    assert task.bind(reject) == Task(lambda rej, res: fork(rej, lambda val: rej(val)))
    assert task.bind(resolve) == Task(lambda rej, res: fork(rej, lambda val: res(val)))



# Generated at 2022-06-12 05:45:52.985166
# Unit test for method bind of class Task
def test_Task_bind():
    def test_bind(resolve, reject):
        return resolve(1)
    t1 = Task.of(1).bind(lambda x: Task.of(x + 1))
    assert t1.fork(lambda x: x, lambda x: x) == 2
    t2 = Task.of(2).bind(lambda x: Task.reject(x + 1))
    assert t2.fork(lambda x: x, lambda x: x) == 3


# Generated at 2022-06-12 05:45:57.487814
# Unit test for method bind of class Task
def test_Task_bind():
    def count(n):
        return Task.of(n + 1)

    task = Task.of(1)
    task = task.bind(count).bind(count).bind(count)

    assert 4 == task.fork(lambda _: None, lambda v: v)
