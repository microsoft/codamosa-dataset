

# Generated at 2022-06-12 05:36:12.272025
# Unit test for method map of class Task
def test_Task_map():

    def mapper(value):
        return value + '!'

    task = Task.of('Hello').map(mapper)
    result = task.fork(lambda _: 'Rejected', lambda value: value)

    assert result == 'Hello!'

# Generated at 2022-06-12 05:36:16.907922
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    map_of_task = task.map(lambda x: x + 2)

# Generated at 2022-06-12 05:36:28.590617
# Unit test for method bind of class Task
def test_Task_bind():
    # Case 1:
    #     Task is resolved
    #     mapper is return resolved Task
    #       result is resolved Task
    task_1 = Task.of(1)
    def mapper(value):
        return Task.of(value + 1)

# Generated at 2022-06-12 05:36:36.532152
# Unit test for method bind of class Task
def test_Task_bind():
    """
    This test check method bind. It should work like bind method in Haskell.
    """

    task_a = Task.of(20)
    task_b = Task.of(10)

    def fn(value):
        if value == 10:
            return task_a
        else:
            return task_b

    result = task_b.bind(fn)

    assert result.fork(
        lambda value: "rejected",
        lambda value: value
    ) == task_a.fork(
        lambda value: "rejected",
        lambda value: value
    )


# Generated at 2022-06-12 05:36:45.555179
# Unit test for method bind of class Task
def test_Task_bind():
    # test: map value in resolved Task[reject, resolve]
    def test_map():
        task = Task.of(1).bind(lambda value: Task.of(value + 1))
        assert isinstance(task, Task)

# Generated at 2022-06-12 05:36:49.675231
# Unit test for method map of class Task
def test_Task_map():
    # For example: test Task.of
    # Build method Task.of

    of123 = Task.of(1).map(lambda x: x + 1).map(lambda x: x * 2)

    assert of123.fork(lambda x: print(x), lambda x: x) == 4


# Generated at 2022-06-12 05:37:01.166182
# Unit test for method bind of class Task
def test_Task_bind():
    def test_divide(value, expected_result):
        def divide(number):
            if number == 0:
                return Task.reject(ZeroDivisionError('Divide by zero'))

            return Task.of(123.0 / number)

        def divide_and_log(d):
            return d.bind(lambda r: Task.of(r).map(lambda res: {'result': res}))

        def test_reject(res):
            assert res == ZeroDivisionError('Divide by zero')
            print('Rejected!')

        def test_resolve(res):
            assert res['result'] == expected_result
            print('Resolved!')

        Task.of(value).bind(divide).bind(divide_and_log).fork(test_reject, test_resolve)

    test_div

# Generated at 2022-06-12 05:37:06.721085
# Unit test for method bind of class Task
def test_Task_bind():
    called = []

    def fn(val):
        called.append(val)
        return Task.of('mapped')

    Task.of('value').bind(fn).fork(
        lambda _: None,
        lambda _: called.append('result')
    )

    assert called == ['value', 'mapped', 'result']


# Generated at 2022-06-12 05:37:11.465162
# Unit test for method bind of class Task
def test_Task_bind():
    fn = lambda _: Task.of(10)
    task = Task.of(1).bind(fn)
    assert task.fork(
        reject = lambda x: "error",
        resolve = lambda x: x
    ) == 10


# Generated at 2022-06-12 05:37:19.789345
# Unit test for method map of class Task
def test_Task_map():

    def check(test_case):
        check_value = test_case['check_value']
        mapper = test_case['mapper']

        def fork(reject, resolve):
            return resolve(check_value)

        task = Task(fork)
        result = task.map(mapper)
        assert result.fork(
            lambda r: 'Rejected',
            lambda r: r
        ) == test_case['expected_value']


# Generated at 2022-06-12 05:37:26.585066
# Unit test for method map of class Task
def test_Task_map():
    def fork(i):
        def reject(v):
            return v

        def resolve(v):
            return v

        return Task(lambda reject, resolve: reject(i)).fork(reject, resolve)

    assert fork(2) == 2


# Generated at 2022-06-12 05:37:31.845468
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map method

    :returns: None
    """
    def fork(reject, resolve):
        resolve(100)
    def fn(value):
        return value + 5
    task = Task(fork)
    new_task = task.map(fn)
    assert new_task.fork(lambda _: None, lambda value: value) == 105



# Generated at 2022-06-12 05:37:39.480828
# Unit test for method bind of class Task
def test_Task_bind():
    @Task.of
    def fn_success(*args, **kwargs):
        return args, kwargs

    @Task.reject
    def fn_error(*args, **kwargs):
        return args, kwargs

    assert Task.of(1).bind(fn_success) == ((), {})
    assert Task.of(1).bind(fn_success).value == ((), {})
    assert Task.of(1).bind(fn_error).value == 1


# Generated at 2022-06-12 05:37:45.209190
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Assert that Task.bind method calls fork of task with result of
    Task.bind argument and then reject or resolve it by command of result of fork.
    """
    def fork(reject, resolve):
        return None

    def test_fn(value):
        def fork(reject, resolve):
            return value
        return Task(fork)

    test_Task = Task(fork)

    result = test_Task.bind(test_fn)

    assert result.fork == fork


# Generated at 2022-06-12 05:37:49.051355
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value - 1

    assert Task.of(0).map(mapper).fork(
        lambda arg: False,
        lambda arg: True if arg == -1 else False
    )


# Generated at 2022-06-12 05:37:53.402453
# Unit test for method map of class Task
def test_Task_map():
    with mock.patch.object(Task, "fork") as fake_fork:
        Task(fake_fork).map(lambda arg: arg).fork(lambda _, __: None)

        fake_fork.assert_called_with(mock.ANY, mock.ANY)


# Generated at 2022-06-12 05:38:01.718596
# Unit test for method map of class Task
def test_Task_map():
    def test_case(fork, fn, expected_result):
        task = Task(fork)
        result = task.map(fn)
        assert result.fork(None, None) == expected_result

    def first_case_fork(_, resolve):
        return resolve(2)
    def first_case_fn(value):
        return value + 1
    test_case(first_case_fork, first_case_fn, 3)

    def second_case_fork(_, resolve):
        return resolve('a')
    def second_case_fn(value):
        return value + 'b'
    test_case(second_case_fork, second_case_fn, 'ab')

    def third_case_fork(_, resolve):
        return resolve({
            'value': 2
        })

# Generated at 2022-06-12 05:38:13.027576
# Unit test for method map of class Task
def test_Task_map():
    """
    Function to test map method of Task.
    """
    def f1(x):
        return x + 1

    def f2(x):
        return x * 2

    def f3(x):
        return x ** 2

    def f4(x):
        return x // 2

    def f5(x):
        return x + 3

    def f6(x):
        return x - 2

    # 5 == 4
    # 4 == 5
    # 9 == 9
    assert Task.of(1).map(f1).map(f2).map(f3).map(f4).fork(
        lambda x: x * 2,
        lambda x: x - 3
    ) == 4

# Generated at 2022-06-12 05:38:17.109674
# Unit test for method bind of class Task
def test_Task_bind():
    a = Task(lambda _, resolve: resolve(10))
    b = a.bind(lambda arg: Task(lambda _, resolve: resolve(arg + 20)))
    assert b.fork(lambda x: None, lambda x: x) == 30


# Generated at 2022-06-12 05:38:21.480482
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(arg):
        return Task.of(arg + 41)

    task = Task.of(10).bind(mapper)
    assert (task.fork(
        lambda arg: None,
        lambda arg: arg
    ) == 51)


# Generated at 2022-06-12 05:38:31.311482
# Unit test for method map of class Task
def test_Task_map():
    """
    Test mapping on resolved Task.
    """
    def increment_if_positive(value):
        """
        Increment value if it positive.
        """
        return value + 1 if value > 0 else value

    resolved = Task.of(1)
    assert resolved.map(increment_if_positive).fork(None, lambda value: value) == 2


# Generated at 2022-06-12 05:38:38.906900
# Unit test for method map of class Task
def test_Task_map():
    """
    Test task map method.
    """
    assert Task.of(1).map(lambda x: x + 1).fork(
        lambda res: False,
        lambda res: res == 2
    ) == True

    assert Task.of("foo").map(lambda x: x + 1).fork(
        lambda res: True,
        lambda res: False
    ) == True


# Generated at 2022-06-12 05:38:44.039547
# Unit test for method map of class Task
def test_Task_map():
    """
    >>> @returns(int)
    ... @check_types(value=int)
    ... def add(value):
    ...     return value + value
    >>> Task.of(3).map(add).fork(None, print)
    6
    """
    pass


# Generated at 2022-06-12 05:38:52.510474
# Unit test for method map of class Task
def test_Task_map():
    # Success case
    def resolve(x):
        return x

    def reject(x):
        raise x

    def add_one(x):
        return x + 1

    # Task without value
    noop_task = Task(lambda reject, resolve: resolve())

    assert_equal(
        noop_task.map(add_one).fork(reject, resolve),
        add_one(noop_task.fork(reject, resolve))
    )

    # Task with value
    some_task = Task(lambda reject, resolve: resolve(1))
    assert_equal(
        some_task.map(add_one).fork(reject, resolve),
        add_one(some_task.fork(reject, resolve))
    )


# Generated at 2022-06-12 05:38:55.596167
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value)

    result = Task.of(2) \
        .map(lambda value: value * 2) \
        .bind(fn)


# Generated at 2022-06-12 05:39:06.615111
# Unit test for method bind of class Task
def test_Task_bind():
    def decorator_error_in_task(fn):
        def wrapper(arg):
            if not arg:
                return Task.reject('error')

            return fn(arg)

        return wrapper

    def add_ten(arg):
        return Task.of(arg + 10)

    assert Task.of(1).bind(add_ten).fork(
        lambda error: error,
        lambda arg: arg
    ) == 11, 'Task_bind with no errors in tasks'
    assert Task.of(0).bind(add_ten).bind(decorator_error_in_task(add_ten)).fork(
        lambda error: error,
        lambda arg: arg
    ) == 'error', 'Task_bind with errors in tasks'


# Generated at 2022-06-12 05:39:10.638379
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def fork_add_one(reject, resolve):
        return resolve(1)

    task = Task(fork_add_one)
    mapped_task = task.map(add_one)

    assert mapped_task.fork(lambda _: True, lambda arg: arg) == 2


# Generated at 2022-06-12 05:39:14.986097
# Unit test for method bind of class Task
def test_Task_bind():
    # pass
    Task.of(1).bind(lambda x: Task.of(x+1)).fork(print, print)
    # fail
    Task.of(1).bind(lambda x: Task.reject(x+1)).fork(print, print)


# Generated at 2022-06-12 05:39:20.199589
# Unit test for method map of class Task
def test_Task_map():
    def fn(value): return 2 * value

    def fork(reject, resolve):
        resolve(5)

    task = Task(fork)
    new_task = task.map(fn)
    assert new_task.fork(lambda arg: False, lambda arg: arg == 10)


# Generated at 2022-06-12 05:39:28.762498
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def error(s):
        return Task.reject(s)

    def test(x):
        return Task.of(x)

    assert Task.of(1).bind(test).bind(add).fork(lambda s: print("error: " + str(s)), lambda x: x) == 2
    assert Task.of(1).bind(error).fork(lambda s: print("error: " + str(s)), lambda x: x) == 1


# Generated at 2022-06-12 05:39:41.845386
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(1)
        return 2

    task = Task(fork)
    result = task.map(lambda x: x * 2)

    assert (result.fork(lambda x: None, None) == 2)


# Generated at 2022-06-12 05:39:43.464421
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    assert Task.of(1).map(add) == Task(lambda _, resolve: resolve(add(1)))


# Generated at 2022-06-12 05:39:47.295230
# Unit test for method map of class Task
def test_Task_map():
    def fn(val):
        return val + 1

    mapped = Task.of(1).map(fn)
    assert mapped.fork(lambda _: 'reject', lambda arg: arg) == fn(1)


# Generated at 2022-06-12 05:39:51.137060
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(1).bind(lambda value: Task.of(value * 2))
    assert result.fork(lambda e: e, lambda d: d) == 2

# Generated at 2022-06-12 05:39:59.553610
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task

    :returns: True if test passed or raise AssertionError
    :rtype: bool
    :raises AssertionError:
    """
    req = 0
    res = 0
    rej = 0
    task = Task(
        lambda reject, resolve: req and resolve(req)
    )

    task2 = task.map(lambda arg: res and arg + res)
    task2.fork(lambda arg: rej and arg, lambda arg: res and arg + res)

    # Check resolve value
    assert task2.fork(None, lambda arg: arg) == 2

    task = Task(
        lambda reject, resolve: req and reject(req)
    )

    task2 = task.map(lambda arg: res and arg + res)

# Generated at 2022-06-12 05:40:05.289141
# Unit test for method bind of class Task
def test_Task_bind():
    # initialize task with resolve value
    task = Task.of('value')

    # bind it with callback which return new Task with another resolve value
    task = task.bind(lambda _: Task.of('mapped value'))

    # test result
    res = task.fork(lambda err: 'err ' + err, lambda res: res)
    assert res == 'mapped value'


# Generated at 2022-06-12 05:40:13.294101
# Unit test for method map of class Task
def test_Task_map():
    # setup object
    task = Task.of('my_test_value')

    # call map with lambda
    mapped = task.map(lambda arg: arg + '_mapped')

    # call fork on mapped to resolve Task
    result, error = mapped.fork(
          lambda arg: ('fail', arg),
          lambda arg: ('success', arg)
    )

    # assert result is
    assert result == 'success'

    # assert value is
    assert error == 'my_test_value_mapped'


# Generated at 2022-06-12 05:40:18.326536
# Unit test for method bind of class Task
def test_Task_bind():

    def fn(value):
        return Task.of(value * 2)

    task = Task.of(1)
    assert 2 == task.bind(fn).fork(reject=None, resolve=lambda arg: arg)

    task = Task.reject(1)
    assert 1 == task.bind(fn).fork(reject=lambda arg: arg, resolve=None)



# Generated at 2022-06-12 05:40:26.837768
# Unit test for method map of class Task
def test_Task_map():
    def assert_equal(a, b, msg):
        if a != b:
            raise AssertionError(msg)


# Generated at 2022-06-12 05:40:30.979273
# Unit test for method bind of class Task
def test_Task_bind():
    num = 3
    task = Task.of(num)
    task_plus = task.bind(lambda value: Task.of(value + 1))
    task_plus.fork(lambda _: False, lambda value: value == num + 1)


# Generated at 2022-06-12 05:40:58.421594
# Unit test for method bind of class Task
def test_Task_bind():
    def gen_task_of(value):
        return Task.of(value)

    def gen_task_bind(value):
        return Task.of(value).bind(gen_task_of)

    def test_resolve():
        assert Task(lambda _, resolve: resolve(42)).bind(gen_task_of) == Task.of(42)

    def test_reject():
        assert Task(lambda reject, _: reject(42)).bind(gen_task_of) == Task.of(42)

    test_resolve()
    test_reject()

# Generated at 2022-06-12 05:41:05.729587
# Unit test for method map of class Task
def test_Task_map():
    """
    Test is Task.map work correctly.
    """
    def mul2(x):
        return x * 2

    resolved = Task.of(2)
    assert resolved.map(mul2).fork(lambda _: 'reject', lambda value: value) == 4

    rejected = Task.reject(2)
    assert rejected.map(mul2).fork(lambda reject_value: reject_value, lambda _: 'resolve') == 2


# Generated at 2022-06-12 05:41:16.017854
# Unit test for method bind of class Task
def test_Task_bind():
    @Task.of
    def test_task(x):
        return x + 1

    @Task.reject
    def test_reject(x):
        return x - 1

    assert test_task\
        .bind(lambda x: test_task)\
        .fork(lambda x: x, lambda x: x) == 2

    assert test_task\
        .bind(lambda x: test_reject)\
        .fork(lambda x: x, lambda x: x) == 0

    assert test_reject\
        .bind(lambda x: test_task)\
        .fork(lambda x: x, lambda x: x) == -1


# Generated at 2022-06-12 05:41:24.718640
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task(lambda reject, resolve: resolve(x + x))
    assert Task.of(2).map(add).bind(add).fork(lambda x: x, lambda x: x) == 8
    def error(x):
        return 'Error!'
    assert Task.of(2).map(error).bind(add).fork(lambda x: x, lambda x: x) == 'Error!'

if __name__ == '__main__':
    test_Either_bind()
    test_Task_bind()

# Generated at 2022-06-12 05:41:31.908196
# Unit test for method map of class Task
def test_Task_map():
    """
    :raises:  AssertionError
    """
    assert Task.of(1).map(lambda x: x + 1).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 2

    assert Task.reject(1).map(lambda x: x + 1).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1


# Generated at 2022-06-12 05:41:35.454996
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Method ``bind`` should return Task, which map Task which returns argument.
    """
    expect = Task.of(100)
    actual = Task.of(101) \
        .bind(lambda x: Task.of(x - 1)) \
        .bind(lambda x: Task.of(x - 1))

    assert expect == actual

# Generated at 2022-06-12 05:41:38.500050
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda a: a + 3).fork(None, lambda a: a) == 4


# Generated at 2022-06-12 05:41:44.829606
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        time.sleep(1)
        resolve(3)

    def bind(value):
        def fork(reject, resolve):
            if value % 2 == 0:
                resolve(value * 5)
            else:
                reject(None)

        return Task(fork)

    task = Task(fork)

# Generated at 2022-06-12 05:41:47.004579
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(3).map(lambda x: x * 3).fork(
            lambda _Exception: 'Error',
            lambda value: value
        ) == 9


# Generated at 2022-06-12 05:41:55.342029
# Unit test for method bind of class Task
def test_Task_bind():
    def test_value_of(expected_value, actual_value):
        if actual_value != expected_value:
            raise AssertionError()

    Task.of(1) | (lambda x: Task.of(x + 1)) | (lambda x: Task.of(x * 2)) | (lambda z: test_value_of(4, z))

    Task.reject(1) | (lambda x: Task.of(x + 1)) | (lambda x: Task.of(x * 2)) | (lambda z: test_value_of(4, z))



# Generated at 2022-06-12 05:42:39.657869
# Unit test for method map of class Task
def test_Task_map():
    def f(value):
        return value ** 2

    task = Task.of(2)
    assert_equal(task.map(f).fork(lambda i: i, lambda i: i), 4)

    assert_equal(
        Task.of(2).map(lambda i: i ** 2).fork(lambda i: i, lambda i: i),
        4
    )


# Generated at 2022-06-12 05:42:50.251316
# Unit test for method map of class Task
def test_Task_map():
    def fork(_, resolve):
        return resolve(5)

    # Create instance of Task with fork function
    task = Task(fork)

    # Create instance of Task with mapped fork function
    task_invert = task.map(lambda v: v * -1)

    def _assert_fork(reject, resolve):
        reject_called = False
        resolve_called = False

        def assert_reject(arg):
            nonlocal reject_called
            reject_called = True

        def assert_resolve(arg):
            nonlocal resolve_called
            resolve_called = True

            assert arg == -5

        task_invert.fork(assert_reject, assert_resolve)
        assert not reject_called
        assert resolve_called


# Generated at 2022-06-12 05:42:55.051440
# Unit test for method map of class Task
def test_Task_map():
    def add_10(x):
        return x + 10

    task1 = Task.of(5).map(add_10)
    assert task1.fork(lambda x: None, lambda x: None) == 15

    task2 = Task.reject(5).map(add_10)
    assert task2.fork(lambda x: None, lambda x: None) == 5


# Generated at 2022-06-12 05:42:59.901474
# Unit test for method map of class Task
def test_Task_map():
    def add_ten(value):
        return value + 10

    assert Task.of(90).map(add_ten).fork(lambda reject, resolve: resolve(reject)) == 100
    assert Task.reject(90).map(add_ten).fork(lambda reject, resolve: resolve(reject)) == 90


# Generated at 2022-06-12 05:43:06.283822
# Unit test for method bind of class Task
def test_Task_bind():
    """
    :returns: True
    :rtype: boolean
    """
    # AssertionError: TypeError: 'NoneType' object is not iterable
    # Task.reject(None).bind(lambda _: Task.reject(None))
    return True

Task.of(3).bind(lambda _: Task.reject(None))

Task.reject(None).bind(lambda _: Task.reject(None))


# Generated at 2022-06-12 05:43:10.722687
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value * 2

    assert Task.of(1).map(fn).fork(lambda x: None, lambda x: x) == 2
    assert Task.reject(1).map(fn).fork(lambda x: x, lambda x: None) == 1


# Generated at 2022-06-12 05:43:14.776557
# Unit test for method bind of class Task
def test_Task_bind():
    def result(reject, resolve):
        print('result')
        resolve('a')
        reject('b')

    task = Task(result)
    wrapped = task.bind(lambda arg: Task.reject(arg))
    wrapped.fork(lambda arg: print(arg), lambda arg: None)


# Generated at 2022-06-12 05:43:16.224641
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    task = Task.of(1)
    assert task.map(add).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-12 05:43:20.234465
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        return Task.of(x + 1)

    task = Task.of(1).bind(f).bind(f).bind(f)

    assert task.fork(lambda e: e, lambda v: v) == 4


# Generated at 2022-06-12 05:43:22.946596
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x: Task.of(x)).fork(lambda x: 1, lambda x: x) == 1

# Generated at 2022-06-12 05:44:51.920040
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda reject, resolve: resolve('value'))
    new_task = task.map(lambda value: value + ' mapped')
    assert new_task.fork(
        lambda reject: 'reject',
        lambda resolve: resolve
    ) == 'value mapped'



# Generated at 2022-06-12 05:44:55.543627
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(1)

    def mapper(value):
        return value * 2

    task = Task(fork)
    result = task.map(mapper).fork(lambda arg: arg, lambda arg: arg)

    assert 2 == result, "returns wrong value"


# Generated at 2022-06-12 05:45:04.111661
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Imitate example from page https://www.reddit.com/r/elixir/comments/5hu2zk/can_someone_explain_elixirs_bindoperator_to_me/
    """
    def add(x):
        def f(v):
            return Task.of(x + v)

        return Task.of(f)

    task = Task.of(1).bind(add(2)).bind(add(3))
    assert task.fork(lambda x: x, lambda x: x) == 6

# Generated at 2022-06-12 05:45:08.917763
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """
    assert Task(lambda _, resolve: resolve(1)) \
        .map(lambda v: v + 2) \
        .fork(lambda v: v, lambda v: v) == 3


# Generated at 2022-06-12 05:45:12.132679
# Unit test for method map of class Task
def test_Task_map():
    def test_map(task):
        def mapper(value):
            return value + 1

        def result(mapped):
            return mapped == 2

        return task.map(mapper).fork(
            lambda _: False, result)

    assert test_map(Task.of(1)) is True


# Generated at 2022-06-12 05:45:16.800481
# Unit test for method bind of class Task
def test_Task_bind():
    number = 5
    add_five = lambda x: Task.of(x + 5)
    result = Task.of(number).bind(add_five)
    assert result.fork(lambda x: x, lambda x: x) == number + 5


# Generated at 2022-06-12 05:45:21.282672
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        assert value == 'value'
        return 'mapped'


# Generated at 2022-06-12 05:45:31.497883
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test that bind method in Task class work correct.
    """
    # call function return Task with value 'bar'
    def call_foo(value):
        return Task.of(value + 'foo')

    # call function return Task with value a + b
    def call_a_b(value):
        def result(a, b):
            return Task.of(a + b)

        return Task(result)

    # call function return resolve value
    def call_reject(value):
        return Task.reject(value)

    task_success = Task.of('bar').bind(call_foo)

# Generated at 2022-06-12 05:45:43.177808
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    side_effect = "side_effect"
    side_effect_double = "side_effect_double"

    global_resolve_arg = None
    global_reject_arg = None

    def reject(arg):
        global global_reject_arg
        global_reject_arg = arg

    def resolve(arg):
        global global_resolve_arg
        global_resolve_arg = arg

    def fork(resolve, reject):
        resolve(side_effect)

    def map_fn(arg):
        return side_effect_double

    def bind_fn(arg):
        return Task(fork)

    task = Task(fork)
    task = task.map(map_fn)
    task = task.bind(bind_fn)
    task

# Generated at 2022-06-12 05:45:46.308402
# Unit test for method map of class Task
def test_Task_map():
    def square_map(num):
        return num * num

    def square_fork(reject, resolve):
        resolve(2)

    value = Task(square_fork).map(square_map)

    assert value == 4
