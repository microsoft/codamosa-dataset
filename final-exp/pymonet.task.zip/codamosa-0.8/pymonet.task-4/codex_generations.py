

# Generated at 2022-06-12 05:36:10.368793
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of class Task
    """

    def resolver(reject, resolve):
        resolve('a')

    task = Task(resolver)

    def mapper(value):
        return value + 'b'

    result_task = task.map(mapper)

    def resolve(value):
        assert value == 'ab'

    def reject(value):
        raise RuntimeError('Task is rejected')

    result_task.fork(reject, resolve)


# Generated at 2022-06-12 05:36:14.657840
# Unit test for method map of class Task
def test_Task_map():
    """
    Test function for method map of class Task
    """
    @Task.of
    def double(number):
        return 2 * number

    assert double(4).map(lambda x: x / 2) == Task.of(4)



# Generated at 2022-06-12 05:36:20.684541
# Unit test for method map of class Task
def test_Task_map():
    """
    If the result of fork function is different from value,
    than exception will raised.

    :returns: None
    :rtype: NoneType
    """
    def fork(reject, resolve):
        return resolve(4)

    async def test():
        is_equal = await Task(fork).map(lambda x: x * x).fork(lambda _: False, lambda x: x == 16)
        assert is_equal is True

    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())


# Generated at 2022-06-12 05:36:26.381843
# Unit test for method map of class Task
def test_Task_map():
    def f(x):
        return x + 1

    def g(x):
        return x * 2

    assert Task.of(6).map(f).map(g).fork(
        lambda _: raise_to_str(TypeError('Task must be resolved')),
        lambda val: val
    ) == 14


# Generated at 2022-06-12 05:36:30.509093
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda _, resolve: resolve(1))

    # assert isinstance(task.map(lambda x: x * 2), Task)
    assert task.map(lambda x: x * 2).fork(-1, -1) == 2


# Generated at 2022-06-12 05:36:33.434134
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value * 10

    assert Task.of(10).map(fn).fork(None, lambda arg: arg) == 100



# Generated at 2022-06-12 05:36:45.422328
# Unit test for method map of class Task
def test_Task_map():
    """
    Check Task.map function.
    """
    def square(arg):
        return arg ** 2

    def double(arg):
        return arg * 2

    def sum(arg, arg_2):
        return arg + arg_2

    # Wrap Task.map function with a method.
    # Make function type more clear
    def map(self, fn):
        def result(reject, resolve):
            return self.fork(
                lambda arg: reject(arg),
                lambda arg: resolve(fn(arg))
            )
        return Task(result)

    # Check Task.map function with a square function
    task = Task(lambda reject, resolve: resolve(5))

    assert map(task, square)(lambda _, resolve: resolve(None)) == 25
    assert map(task, square)(lambda _, resolve: resolve(None))

# Generated at 2022-06-12 05:36:49.582399
# Unit test for method bind of class Task
def test_Task_bind():
    def step2(x):
        return Task.of(x+2)

    def step3(x):
        return Task.of(x*3)

    res = Task.of(1).bind(step2).bind(step3)
    assert res.fork(lambda x: None, lambda x: x) == 9

# Generated at 2022-06-12 05:36:54.612538
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(2)

    task = Task(fork)

    def fn(value):
        return Task.of(value + 1)

    task_mapped = task.bind(fn)
    assert task_mapped.fork(None, lambda v: v) == 3


# Generated at 2022-06-12 05:36:59.334480
# Unit test for method bind of class Task
def test_Task_bind():
    def test():
        """ Return resolved task with string 'test' """
        return Task.of('test')

    task = Task.of(1).bind(test).bind(lambda arg: Task.of(arg + 1))
    assert task.fork(lambda arg: arg, lambda arg: arg) == 2

# Generated at 2022-06-12 05:37:06.628545
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda reject, resolve: resolve(1))

    def fn(value):
        return value + 1

    mapped_task = task.map(fn)

    assert callable(mapped_task.fork)

    result = mapped_task.fork(None, None)

    assert result == 2, result

# Generated at 2022-06-12 05:37:17.599847
# Unit test for method bind of class Task
def test_Task_bind():
    # Define result function
    result = None
    # Success resolve
    t1 = Task.of(1)
    # Success resolve
    t2 = Task.of(2)

    # Failure resolve
    tn = Task.of(None)
    # Failure resolve
    te = Task.reject(Exception('Exception'))

    # Success resolve
    def _reject(r):
        """Call if rejected"""
        nonlocal result
        result = -1 * r

    # Success resolve
    def _resolve(r):
        """Call if resolved"""
        nonlocal result
        result = r

    # Success resolve
    t1.bind(lambda v: t2).fork(_reject, _resolve)
    assert result == 2

    # Success resolve
    result = None
    # Success resolve

# Generated at 2022-06-12 05:37:26.851702
# Unit test for method bind of class Task
def test_Task_bind():
    def sync_chain(*args):
        return reduce(lambda result, fn: fn(result), args, 100)

    def async_chain(*args):
        return reduce(lambda task, fn: task.bind(fn), args, Task.of(100))

    f1 = lambda x: Task.of(x ** 2)
    f2 = lambda x: Task.of(x + 10)
    f3 = lambda x: Task.of(x / 12)

    assert sync_chain(f1, f2, f3) == async_chain(f1, f2, f3).fork(
        lambda _: None,
        lambda result: result
    )



# Generated at 2022-06-12 05:37:32.596305
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(mapper).fork(lambda _: None, lambda value: value) == 2

    def non_task_mapper(value):
        return value + 1

    assert Task.of(1).bind(non_task_mapper).fork(lambda _: None, lambda value: value) == 2


# Generated at 2022-06-12 05:37:38.606064
# Unit test for method map of class Task
def test_Task_map():
    resolved_task = Task.of(3)

    def test_map_of_resolved_task(value):
        assert value == 3


# Generated at 2022-06-12 05:37:45.974156
# Unit test for method map of class Task
def test_Task_map():
    t1 = Task.of(1)
    t2 = t1.map(lambda x: x + 1)
    t3 = t1.map(lambda x: x + 10)
    assert t2.fork(lambda x: x, id) == 2
    assert t3.fork(lambda x: x, id) == 11

    t4 = Task.reject(1)
    t5 = t4.map(lambda x: x + 1)
    assert t5.fork(lambda x: x, id) == 1

    t6 = t4.map(lambda x: x + 100)
    assert t6.fork(lambda x: x, id) == 1


# Generated at 2022-06-12 05:37:52.173945
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task#bind
    """
    x = 0

    def side_effect(value):
        nonlocal x
        x = value

    @Task.of
    def mapper(arg):
        return Task.of(arg * 2)

    task = Task.of(1).bind(mapper)

    task.fork(side_effect, side_effect)

    assert x == 2


# Generated at 2022-06-12 05:37:56.990112
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task(lambda reject, resolve: resolve(2))
    assert task.bind(lambda value: Task.of(value + 1)).fork(lambda value: None, lambda value: value) == 3
    assert task.bind(lambda value: Task.reject(value + 1)).fork(lambda value: value, lambda value: None) == 3


# Generated at 2022-06-12 05:38:01.412774
# Unit test for method map of class Task
def test_Task_map():
    def sum(a, b): return a + b

    task = Task.of(3)
    assert task.map(lambda x: x + 1).fork(
        lambda x: x + 1, lambda x: x + 1
    ) == 5

    task = Task.of(3)
    assert task.bind(lambda x: Task.of(x+1)).fork(
        lambda x: x + 1, lambda x: x + 1
    ) == 5


# Generated at 2022-06-12 05:38:12.846059
# Unit test for method bind of class Task
def test_Task_bind():
    """
        Task.bind must be return new Task with new resolved callback
        and it must execute returned callback during execution of fork
    """

    def resolve_callback(a):
        return a

    def reject_callback(a):
        return a

    def result_callback(a):
        return a

    def handler(reject, resolve):
        def executor():
            resolve('foo')
        setTimeout(executor, 0)

    task = Task(handler)

    reject_spy = Spy(reject_callback)

    resolved_spy = Spy(resolve_callback)

    result_spy = Spy(result_callback)

    def mapper(value):
        def handler(reject, resolve):
            def executor():
                resolve(value + 'bar')
            setTimeout(executor, 0)

# Generated at 2022-06-12 05:38:20.850686
# Unit test for method map of class Task
def test_Task_map():
    dummy = Task.of(1)

    assert dummy.map(lambda arg: arg + 1).fork(
        lambda _: None,
        lambda arg: arg
    ) == 2

    assert dummy.map(lambda arg: arg + 1).map(lambda arg: arg + 2).fork(
        lambda _: None,
        lambda arg: arg
    ) == 4


# Generated at 2022-06-12 05:38:31.463824
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method.
    """
    # define some dummy functions
    def val_to_reject(value):
        return Task.reject(value)

    def val_to_resolve(value):
        return Task.of(value)

    # define dummy values
    VAL_1 = 1
    VAL_2 = 2

    # call reject method via bind
    assert Task.of(VAL_1).bind(val_to_reject).fork(
        lambda x: x,
        lambda _: None,
    ) == VAL_1

    # call resolve method via bind
    assert Task.reject(VAL_2).bind(val_to_resolve).fork(
        lambda x: None,
        lambda _: x,
    ) == VAL_2



# Generated at 2022-06-12 05:38:34.140929
# Unit test for method map of class Task
def test_Task_map():
    """ Unit test Task map method. """

    assert Task.of(1).map(lambda x: x+1).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-12 05:38:42.535948
# Unit test for method map of class Task
def test_Task_map():
    """
    Add two number.

    :param a: first number
    :type a: Int
    :param b: second number
    :type b: Int
    :returns: sum of two number
    :rtype: Task[Int]
    """
    def add(a, b):
        return a + b

    def result(a, b):
        print('a:', a)
        print('b:', b)
        return Task.of(a + b)

    assert Task.of(2).map(lambda x: x * 2).fork(
        lambda err: None,
        lambda res: res
    ) == 4

    assert Task.reject(2).map(lambda x: x * 2).fork(
        lambda err: err * 3,
        lambda res: None
    ) == 6

    assert Task.of

# Generated at 2022-06-12 05:38:52.089652
# Unit test for method bind of class Task
def test_Task_bind():
    initial_value = 5
    second_value = initial_value - 1
    third_value = second_value - 2
    fourth_value = third_value - 3
    fifth_value = fourth_value - 4
    expected = fifth_value - 5
    value = Task.of(initial_value) \
                .bind(lambda x: Task.of(x - 1)) \
                .bind(lambda x: Task.of(x - 2)) \
                .bind(lambda x: Task.of(x - 3)) \
                .bind(lambda x: Task.of(x - 4)) \
                .bind(lambda x: Task.of(x - 5)) \
                .fork(
                    lambda x: Task.reject(x),
                    lambda x: Task.of(x)
                )

    assert(type(value) is Task)

# Generated at 2022-06-12 05:38:59.171823
# Unit test for method bind of class Task
def test_Task_bind():
    def reject(e):
        assert e == RuntimeError("test reject")
        return None

    def resolve(x):
        assert x == 1
        return None

    task = Task.of(1).bind(lambda x: Task.reject(RuntimeError("test reject")))
    task.fork(reject, resolve)

    task = Task.reject(RuntimeError("test reject")).bind(lambda x: Task.of(1))
    task.fork(reject, resolve)

    task = Task.of(1).bind(lambda x: Task.of(x + 5))

# Generated at 2022-06-12 05:39:04.589200
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(3)

    def fn(arg):
        return arg * 2

    task = Task(fork)
    assert isinstance(task.map(fn), Task)
    assert task.map(fn).fork(lambda arg: arg, lambda arg: arg) == 6


# Generated at 2022-06-12 05:39:10.699266
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        def fn(resolve, reject):
            return resolve(value)
        return Task(fn)

    def root_resolve(_):
        assert False

    def root_reject(value):
        assert value == 'error'

    Task.of(1).bind(test_fn).fork(root_reject, root_resolve)
    Task.reject('error').bind(test_fn).fork(root_reject, root_resolve)
    print('OK')


# Generated at 2022-06-12 05:39:19.244203
# Unit test for method map of class Task
def test_Task_map():
    """
    assert Task.of(value).map(fn).fork(reject, resolve) == Task.of(fn(value)).fork(reject, resolve)
    """

    def resolve_value(value):
        return value

    def reject_value(value):
        return value

    def double(value):
        return value * 2

    assert Task.of(5).map(double).fork(reject_value, resolve_value) == \
        Task.of(5 * 2).fork(reject_value, resolve_value)



# Generated at 2022-06-12 05:39:25.303931
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(A):
        def fn(arg):
            return Task.of(arg + A)

        return fn

    resultTask = Task.of(0)
    for i in xrange(0, 100):
        resultTask = resultTask.bind(test_fn(i))

    assert resultTask.fork(lambda err: err, lambda result: result) is 4950

# Generated at 2022-06-12 05:39:38.680578
# Unit test for method map of class Task
def test_Task_map():
    # Decorator for test
    def test_vowel(fn):
        # string input
        input_ = 'a test string'

        # expected value
        expected = 5

        # actual value
        actual = fn(input_)

        # is test failed
        if not actual == expected:
            raise Exception('Test failed. expected {} got {}'.format(expected, actual))

    # test
    test_vowel(lambda x: Task.of(x).map(lambda y: len(filter(lambda z: z in 'aeiou', y))).fork(_, _))


# Generated at 2022-06-12 05:39:45.484384
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case(value):
        def fn(arg):
            assert arg == value
            return Task.of(arg)

        assert Task.of(value).bind(fn).fork(lambda a: False, lambda a: a == value)

    test_case(1)
    test_case(True)
    test_case("string")

print("Unit test for method bind of class Task")
test_Task_bind()
print("Test success")


# Generated at 2022-06-12 05:39:51.238091
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda _, resolve: resolve(5))\
        .bind(lambda arg: Task.of(arg * 2))\
        .fork(
            lambda _: 'FAIL',
            lambda arg: arg
        ) == 10
    assert Task(lambda _, resolve: resolve(5))\
        .bind(lambda arg: Task.reject('FAIL'))\
        .fork(
            lambda error: error,
            lambda _: 'FAIL'
        ) == 'FAIL'


# Generated at 2022-06-12 05:39:55.901252
# Unit test for method map of class Task
def test_Task_map():
    def foo(number):
        return number + 1

    result = Task.of(1).map(foo)
    assert 2 == result.fork(reject, resolve)

    Task.reject(2).map(foo)
    assert 2 == Task.reject(2).fork(reject, resolve)


# Generated at 2022-06-12 05:40:01.842233
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.
    """
    def resolver(x):
        return x

    def mapper(x):
        return x + x

    assert Task.of(1).fork(resolver, resolver) == 1
    assert Task.of(1).map(mapper).fork(resolver, resolver) == 2


# Generated at 2022-06-12 05:40:09.806779
# Unit test for method bind of class Task
def test_Task_bind():
    # Task.bind( Task.of(1) ) == Task.of(1)
    assert Task.of(1).bind(Task.of).fork == Task.of(1).fork

    # Task.bind( Task.of(1), fn => Task.reject(fn(1)) ) == Task.reject(1)
    assert Task.of(1).bind(lambda arg: Task.reject(arg)).fork == Task.reject(1).fork

    # Task.bind( Task.reject(1) ) == Task.reject(1)
    assert Task.reject(1).bind(lambda arg: Task.of(arg)).fork == Task.reject(1).fork

    # Task.bind( Task.reject(1), fn => Task.reject(fn(1)), arg => arg + 1) == Task.reject(

# Generated at 2022-06-12 05:40:16.987281
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        assert value == 'a'

    def reject(_):
        assert False

    Task.of('a').map(lambda x: x).fork(reject, resolve)
    Task.of('a').map(lambda x, y: x).fork(reject, resolve)
    Task.of('a').map('a').fork(reject, resolve)

# Generated at 2022-06-12 05:40:24.788448
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Method bind should return Task without run function.
    """
    def run(resolve, reject):
        return reject('reject')

    task = Task(run)

# Generated at 2022-06-12 05:40:33.930822
# Unit test for method map of class Task
def test_Task_map():

    def ok(_, resolve):
        resolved_value = value * 2
        resolve(resolved_value)

    def error(reject):
        rejected_value = value * 3
        reject(rejected_value)

    value = 2

    task = Task.of(value)
    task = task.map(lambda x: x * 2)

    assert task.fork(error, ok) == (None, 8)

    value = 5

    task = Task.reject(value)
    task = task.map(lambda x: x * 2)

    assert task.fork(error, ok) == (None, 15)



# Generated at 2022-06-12 05:40:43.323406
# Unit test for method map of class Task
def test_Task_map():
    first = Task.of(1)
    second = Task.reject(None)
    third = first.map(lambda x: x + 1)
    fourth = second.map(lambda x: x + 1)

    assert isinstance(first, Task)
    assert isinstance(second, Task)
    assert isinstance(third, Task)
    assert isinstance(fourth, Task)

    assert first.fork(lambda x: x, lambda x: x) == 1
    assert second.fork(lambda x: x, lambda x: x) is None
    assert third.fork(lambda x: x, lambda x: x) == 2
    assert fourth.fork(lambda x: x, lambda x: x) is None


# Generated at 2022-06-12 05:40:57.495299
# Unit test for method bind of class Task
def test_Task_bind():
    check = Task.reject(None).bind(lambda _: None)
    assert isinstance(check, Task), 'Bind must return Task object'


# Generated at 2022-06-12 05:41:07.632029
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Method bind of Task need take result of ordinary function and bind to it inner Task.
    And after fork this Task, call fork with resolve argument to Task
    which returned by inner function.
    """
    task_resolve = Task.of(10)
    task_reject = Task.reject(10)

    def reject_func(arg):
        assert arg == 10

    def resolve_func(arg):
        assert arg == 20

    task_resolve.fork(reject_func, resolve_func)
    task_reject.bind(lambda x: task_reject).fork(reject_func, resolve_func)
    task_reject.bind(lambda x: task_resolve).fork(reject_func, resolve_func)

# Generated at 2022-06-12 05:41:18.177377
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    def double(value):
        return Task.of(value * 2)

    def square(value):
        return Task.of(value ** 2)

    def identity(value):
        return Task.of(value)

    def error(value):
        return Task.reject(value)

    task_of_all_error = Task.reject('error')
    task_of_all_double = Task.of(2).map(double).map(double)

    task_of_all_square = Task.of(3).bind(square).bind(square).bind(square)

    task_of_all_meth_bind = Task.of(4).bind(double).bind(square)


# Generated at 2022-06-12 05:41:22.501944
# Unit test for method map of class Task
def test_Task_map():
    value = 1
    fn = lambda x: x + 1
    task = Task.of(value)
    result = task.map(fn)
    assert result.fork(None, lambda x: x) == fn(value)


# Generated at 2022-06-12 05:41:31.949766
# Unit test for method map of class Task
def test_Task_map():
    def branch_resolve(value):
        return Task.of(value + 1)

    def branch_reject(value):
        return Task.reject(value)

    branch = branch_resolve if True else branch_reject

    assert Task.of(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(2).bind(branch).fork(lambda x: x, lambda x: x) == 2
    assert Task.of(3).bind(branch_reject).fork( lambda x: x, lambda x: 4) == 3

# Generated at 2022-06-12 05:41:34.240771
# Unit test for method map of class Task
def test_Task_map():
    """
    Create Task using of method. Then call map
    :return: None
    """
    Task.of(1).map(lambda x: x + 1).fork(print, print)

# Generated at 2022-06-12 05:41:43.284379
# Unit test for method map of class Task
def test_Task_map():
    """
    Example of test for method map of class Task
    """
    print("Test for Task_map()")

    assert Task.of(0).map(lambda x: x**2).fork(lambda x: None, lambda x: x) == 0
    assert Task.reject(0).map(lambda x: x**2).fork(lambda x: None, lambda x: None) == None

    assert Task.of(2).map(lambda x: x**2).fork(lambda x: None, lambda x: x) == 4
    assert Task.reject(2).map(lambda x: x**2).fork(lambda x: None, lambda x: None) == None


# Generated at 2022-06-12 05:41:46.917122
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind method of class Task.
    """
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(lambda err: 0, lambda val: val) == 2
    assert Task.reject(1).bind(lambda x: Task.of(x + 1)).fork(lambda err: err, lambda val: val) == 1


# Generated at 2022-06-12 05:41:55.946854
# Unit test for method map of class Task
def test_Task_map():
    """
    Create Task and check result of calling map method.
    """
    storage = -1
    fn = lambda x: x * 2
    task = Task(lambda _, resolve: resolve(storage))

    new_task = task.map(fn)

    def test_reject(value):
        raise RuntimeError('Reject function should not be called')

    def test_resolve(value):
        if value != storage * 2:
            raise RuntimeError('Resolve function must be called with same value, but you got: %s' % str(value))

    new_task.fork(test_reject, test_resolve)



# Generated at 2022-06-12 05:42:05.030828
# Unit test for method bind of class Task
def test_Task_bind():
    from do_assert import do_assert

    task1 = Task.of(1)
    task2 = Task.of(2)
    task3 = Task.of(3)
    task4 = Task.of(4)
    task5 = Task.of(5)
    task6 = Task.of(6)
    task3_mapper_1 = task3.map(lambda x: x + 1)
    task3_mapper_2 = task3.map(lambda x: x + 2)
    task3_mapper_3 = task3.map(lambda x: x + 3)
    task3_mapper_4 = task3.map(lambda x: x + 4)
    task3_mapper_5 = task3.map(lambda x: x + 5)
    task3_mapper_6 = task3.map

# Generated at 2022-06-12 05:42:34.453890
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map is a composition of functions
    """

    def inc(value):
        return value + 1

    def dec(value):
        return value - 1

    assert Task.of(1) \
        .map(inc) \
        .fork(lambda x: x, lambda x: x) == 2

    assert Task.of(1) \
        .map(inc) \
        .map(dec) \
        .fork(lambda x: x, lambda x: x) == 1



# Generated at 2022-06-12 05:42:37.004480
# Unit test for method map of class Task
def test_Task_map():
    def add(value):
        return value + 1

    assert Task(lambda _, resolve: resolve(3)).map(add)(None, lambda value: value) == 4


# Generated at 2022-06-12 05:42:41.219039
# Unit test for method map of class Task
def test_Task_map():
    def div(x):
        return x / 2

    assert Task.of(2).map(div).fork(None, None) == 1
    assert Task.of(1).map(div).fork(None, None) == 0.5


# Generated at 2022-06-12 05:42:51.827842
# Unit test for method map of class Task
def test_Task_map():
    """
    >>> t1 = Task.of(1)
    >>> t1
    <__main__.Task instance at 0x7f6e442a6fc8>
    >>> t1.fork(reject=lambda a: 'reject', resolve=lambda a: a)
    1
    >>> t1.map(lambda a: a + 1).fork(reject=lambda a: 'reject', resolve=lambda a: a)
    2
    >>> t1.map(lambda a: a + 1).map(lambda a: a + 2).fork(reject=lambda a: 'reject', resolve=lambda a: a)
    4
    >>> Task.of(1).map(None).fork(reject=lambda a: 'reject', resolve=lambda a: a)
    1
    """
    pass


# Generated at 2022-06-12 05:42:57.477248
# Unit test for method bind of class Task
def test_Task_bind():
    def change_to_upper(value):
        return value.upper()

    def make_task(value):
        return Task.of(change_to_upper(value))

    def test_task(value):
        return Task.of(change_to_upper(value)).bind(make_task)

    assert_equal(
        test_task('the value').fork(
            lambda arg: arg,
            lambda arg: arg
        ),
        'THE VALUE'
    )

if __name__ == '__main__':
    raise SystemExit(pytest.main(__file__))

# Generated at 2022-06-12 05:43:02.083198
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.reject("Hello World")
    def mapper(value):
        return Task.reject("Mapped: " + value)

    assert task.bind(mapper).fork(lambda arg: arg, lambda _: "") == "Mapped: Hello World"

# Generated at 2022-06-12 05:43:06.755049
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        def execute():
            return "result"

        return Task(execute).fork(reject, resolve)

    task = Task(fork)

    assert task.bind(lambda x: Task.of(x[::-1])).fork(None, lambda x: x) == "tsel,"


# Generated at 2022-06-12 05:43:12.374459
# Unit test for method bind of class Task
def test_Task_bind():
    def reject_value(reject):
        return reject('x')

    def resolve_value(resolve):
        return resolve(15)

    assert Task(reject_value).bind(lambda x: Task.of(x*2)).fork(lambda reject: reject, lambda resolve: resolve) == 'x'
    assert Task(resolve_value).bind(lambda x: Task.of(x*2)).fork(lambda reject: reject, lambda resolve: resolve) == 30

# Generated at 2022-06-12 05:43:23.779386
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    This function should return 'passed'.
    """
    def foo_task(number):
        return Task.of(number)

    def bar_task(number):
        return Task.reject(number)

    def wrapper(arg):
        if arg == 'bar':
            return bar_task(arg)
        return foo_task(arg)

    result = Task.of('foo').bind(wrapper)
    assert result.fork(lambda a: 'rejected', lambda a: a) == 'foo'

    result = Task.of('bar').bind(wrapper)
    assert result.fork(lambda a: a, lambda a: 'resolved') == 'bar'

print('Test passed.' if test_Task_bind() == 'Test passed.' else 'Test failed.')

# Generated at 2022-06-12 05:43:31.715835
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(5)

    task = Task(fork)
    assert task.__dict__ == {'fork': fork}
    mapper = lambda arg: Task.of(arg ** 2)
    assert task.bind(mapper).__dict__ == {
        'fork': lambda reject, resolve: task.fork(
            lambda arg: reject(arg),
            lambda arg: mapper(arg).fork(reject, resolve)
        )
    }



# Generated at 2022-06-12 05:44:22.876834
# Unit test for method bind of class Task
def test_Task_bind():
    def dummy(x):
        return Task.of(x)

    assert Task.of(4).bind(dummy) == Task.of(4).bind(dummy)


# Generated at 2022-06-12 05:44:33.145720
# Unit test for method map of class Task
def test_Task_map():
    def fn_raise_exception():
        raise ValueError 
    
    def rej(arg):
        raise Exception('rejected')

    def reso(arg):
        raise Exception('resolved')
        
    def fn_reject_not_reachable(arg):
        return Task.reject(arg)

    def fn_map_int(arg):
        return arg + 1

    def fn_map_return_string(arg):
        return str(arg)

    def fn_map_const(arg):
        return 'text'

    Task.reject(ValueError()).fork(rej, reso)
    Task.of(10).fork(rej, reso)
    
    Task.of(10).map(None).fork(rej, reso)

# Generated at 2022-06-12 05:44:38.994884
# Unit test for method map of class Task
def test_Task_map():
    def method_for_test(reject, resolve):
        resolve(1)
    # should be not changed
    task = Task(method_for_test)
    assert task.fork == method_for_test
    # should be changed
    task2 = task.map(lambda x: x * 2)

# Generated at 2022-06-12 05:44:49.209398
# Unit test for method map of class Task
def test_Task_map():
    # Type
    assert Task.of(("1", "2")) \
        .map(lambda v: "1" + "2") \
            .fork(lambda error: None, lambda result: type(result)) == str

    # Value
    assert Task.of(("1", "2")) \
        .map(lambda v: v[0] + v[1]) \
            .fork(lambda error: None, lambda result: result) == "12"

    # Exception in mapper function
    assert Task.of(("1", "2")) \
        .map(lambda v: v[0] + 3) \
            .fork(lambda error: type(error), lambda result: None) == TypeError

    # Exception in fork function
    assert Task.reject("exception") \
        .map(lambda v: v[0] + 3)

# Generated at 2022-06-12 05:44:57.581523
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function_fork(reject, resolve):
        return resolve(1)

    def mapper(x):
        return x

    def binder(x):
        def binder_function_fork(reject, resolve):
            return Task.reject(x)
        return Task(binder_function_fork)

    test_Task = Task(test_function_fork)
    test_Task_map = test_Task.map(mapper)
    test_Task_bind = test_Task_map.bind(binder)

    def fork_assert_reject(reject, resolve):
        assert test_Task_bind.fork(reject, resolve) == 1

    fork_assert_reject(lambda arg: arg, lambda _: False)


# Generated at 2022-06-12 05:45:01.670643
# Unit test for method map of class Task
def test_Task_map():
    def resolve(arg): return arg
    def reject(arg): return arg
    assert Task(lambda _, resolve: resolve(2)).map(lambda arg: arg * 2).fork(reject, resolve) == 4

# Generated at 2022-06-12 05:45:04.251225
# Unit test for method map of class Task
def test_Task_map():
    def square(value):
        return value * value

    task = Task.of(10).map(square)

    assert task.fork(None, lambda arg: arg) == 100

# Generated at 2022-06-12 05:45:12.681456
# Unit test for method bind of class Task
def test_Task_bind():
    def task_of(value):
        return Task.of(value)

    def plus_one(value):
        return value + 1

    def plus_two(value):
        return value + 2

    task_0 = Task.of(0)
    task_1 = task_of(0).bind(plus_one)
    task_2 = task_0.bind(plus_one).bind(plus_two)

    assert task_0.fork(None, lambda arg: arg) == 0
    assert task_1.fork(None, lambda arg: arg) == 1
    assert task_2.fork(None, lambda arg: arg) == 2



# Generated at 2022-06-12 05:45:21.628992
# Unit test for method map of class Task
def test_Task_map():
    """
    Check Task.map method to map resolve attribute of task.
    """
    def test1(reject, resolve):
        """
        Simple function with arg, but ignore __reject__ argument.
        """
        return resolve(4)

    def test2(value):
        """
        Default adder.
        """
        return value + 1

    def assert_task(reject, resolve):
        """
        Check assert of Task.of() method.
        """
        reject('Fail')
        assert(resolve(3) == 3)

    assert(Task.of(3).map(test2).fork == Task(test1).fork)
    assert(Task.of(3).fork(assert_task) == Task(test1).map(test2).fork(assert_task))


# Generated at 2022-06-12 05:45:30.681760
# Unit test for method bind of class Task
def test_Task_bind():
    def add_five(number):
        return Task.of(number + 5)

    def is_more_then_five(number):
        return number > 5

    # validation_result will be equal to Task.of(0)
    validation = Task.reject(0)
    validation_result = validation.bind(add_five)
    # validate_result will be equal to Task.reject(4)
    validate = Task.of(4)
    validate_result = validate.bind(add_five)

    assert validation_result.fork(lambda value: value, lambda value: value) == 0
    assert validate_result.fork(lambda value: value, lambda value: value) == 9