

# Generated at 2022-06-24 00:31:38.814637
# Unit test for method bind of class Task
def test_Task_bind():
    # Run monad Task
    def run(task):
        def result(reject):
            return task.fork(reject, lambda value: value)

        return result

    # Long operation inside fork
    def long_operation():
        return Task(lambda reject, resolve: resolve(5))

    # Another long operation inside fork
    def another_long_operation():
        return Task(lambda reject, resolve: resolve(10))

    # Condition: should return 20
    def should_be_20():
        def result():
            return Task(
                lambda reject, resolve: resolve('should be 20')
            )

        return result

    # Condition: should return 25
    def should_be_25():
        def result():
            return Task(
                lambda reject, resolve: resolve('should be 25')
            )

        return result

    # Condition: should

# Generated at 2022-06-24 00:31:47.411810
# Unit test for method bind of class Task
def test_Task_bind():
    def check_resolve_reject(resolve_value, reject_value):
        task = Task(lambda reject, resolve: resolve(resolve_value))
        task_mapped = task.bind(lambda arg: Task.of(reject_value))

        def mock_resolve(arg):
            assert arg == reject_value

        def mock_reject(arg):
            assert arg == resolve_value

        task_mapped.fork(mock_reject, mock_resolve)
    check_resolve_reject(2, 3)
    check_resolve_reject(3, "abrakadabra")
    # end of test


# Generated at 2022-06-24 00:31:52.046529
# Unit test for constructor of class Task
def test_Task():
    value = 1

    # Declare a function that create Task
    @Task.of
    def test_function(value):
        return value

    # Check is an instance of Task
    assert isinstance(test_function, Task)

    # Check is value is set in the Task
    assert test_function.fork(lambda _: False, lambda arg: arg) == value


# Generated at 2022-06-24 00:31:54.820362
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject()

    task = Task(fork)
    assert task.fork(lambda : None, lambda : None)


# Generated at 2022-06-24 00:31:56.804713
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task(lambda reject, resolve: resolve('ok')), Task)


# Generated at 2022-06-24 00:32:05.525759
# Unit test for method bind of class Task
def test_Task_bind():

    def test_value(arg):
        return arg

    def test_failing_value(arg):
        return Task.reject(arg)

    assert Task.of('some_value').bind(test_value).fork(str, str) == 'some_value'
    assert Task.of('some_value').bind(test_value).fork(str, str) == 'some_value'
    assert Task.reject('some_value').bind(test_value).fork(str, str) == 'some_value'
    assert Task.of('some_value').bind(test_failing_value).fork(str, str) == 'some_value'
    assert Task.reject('some_value').bind(test_failing_value).fork(str, str) == 'some_value'


# Generated at 2022-06-24 00:32:07.229651
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda x: 'rejected: {}'.format(x), lambda x: x) == 1


# Generated at 2022-06-24 00:32:17.710676
# Unit test for method bind of class Task
def test_Task_bind():
    def test_Task_bind_with_good_function():
        task = Task.of(0)

        def mapping(value):
            return Task.of(value + 1)

        task = task.bind(mapping)
        assert task.fork(None, lambda value: value) == 1

    def test_Task_bind_with_bad_function():
        task = Task.of(0)
        task = task.bind(lambda value: Task.reject(value + 1))

        assert task.fork(lambda value: value, None) == 1

    test_Task_bind_with_good_function()
    test_Task_bind_with_bad_function()


# Generated at 2022-06-24 00:32:19.755685
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve('value')

    task = Task(fork)
    assert isinstance(task, Task)


# Generated at 2022-06-24 00:32:27.453775
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map apply given function to Task's value
    """
    def double(value):
        return value * 2

    def err_mess(mess):
        return mess

    assert Task(lambda reject, resolve: resolve(1)).map(double).fork(err_mess, double) == 4
    assert Task(lambda reject, resolve: reject('failed')).map(double).fork(err_mess, double) == 'failed'
    assert Task(lambda reject, resolve: resolve(1)).map(double).fork(double, err_mess) == 'failed'


# Generated at 2022-06-24 00:32:29.765506
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(1))
    assert task


# Generated at 2022-06-24 00:32:33.810107
# Unit test for constructor of class Task
def test_Task():
    def fork(_, resolve):
        resolve('hi')

    assert Task(fork).fork(lambda _: None, lambda a: a) == 'hi'


# Generated at 2022-06-24 00:32:40.514592
# Unit test for method map of class Task
def test_Task_map():
    def test_func(a):
        return a + 1

    assert Task.of(1).map(test_func).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-24 00:32:43.354082
# Unit test for constructor of class Task
def test_Task():
    def test_fork(_, resolve):
        return resolve('test')

    assert Task(test_fork).fork(lambda _: False, lambda arg: arg == 'test')


# Generated at 2022-06-24 00:32:52.780156
# Unit test for method bind of class Task
def test_Task_bind():
    # this hooks will be called during fork of Task
    hooks = {
        'resolve': None,
        'reject': None
    }

    def fork(reject, resolve):
        hooks['resolve'] = resolve
        hooks['reject'] = reject

    # forget about hooks for now
    task = Task(fork)

    # nothing happened now
    assert None is hooks['resolve']
    assert None is hooks['reject']

    # calling fork with reversed reject and resolve will catch task.fork(a, b)
    task.fork(lambda _: None, lambda _: None)

    # fork function called now
    assert None is not hooks['resolve']
    assert None is not hooks['reject']


    # Test bind with task.fork(reject, resolve)

    # let's a function to convert value to Task
   

# Generated at 2022-06-24 00:32:58.702845
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Tests Task.bind method
    """
    def wrapped(param):
        return param + '_wrap'

    def multiply(param):
        return param * 3

    normal_chain = Task\
        .of(10)\
        .map(multiply)\
        .map(wrapped)

    binding_chain = Task\
        .of(10)\
        .bind(lambda param: Task.of(param * 3))\
        .bind(lambda param: Task.of(param + '_wrap'))

    assert normal_chain.fork(lambda arg: arg, lambda arg: arg) == '30_wrap'
    assert binding_chain.fork(lambda arg: arg, lambda arg: arg) == '30_wrap'


# Generated at 2022-06-24 00:33:02.083914
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(2)
    t = task.bind(lambda v: Task.of(v + 1))

    assert t.fork(lambda _: None, lambda v: v) == 3

# Generated at 2022-06-24 00:33:04.138620
# Unit test for method bind of class Task
def test_Task_bind():
    Task.of(300).bind(lambda value: Task.of(value)).fork(lambda arg: arg, lambda arg: arg)


# Generated at 2022-06-24 00:33:07.536736
# Unit test for method map of class Task
def test_Task_map():
    def init_fn(reject, resolve):
        resolve(1)

    def mapper(value):
        return value + 1

    t = Task(init_fn).map(mapper)
    res, err = t.fork(lambda reject: reject, lambda resolve: resolve)

    assert res == 2


# Generated at 2022-06-24 00:33:12.025419
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(4)
    assert 4 == task.fork(None, lambda arg: arg)
    task2 = task.map(lambda arg: arg + 1)
    assert 5 == task2.fork(None, lambda arg: arg)


# Generated at 2022-06-24 00:33:14.677834
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(x):
        return Task.of(x + 2)

    task1 = Task.of(2)

    assert task1.bind(test_fn).fork(
        lambda reject: None,
        lambda resolve: resolve
    ) == 4


# Generated at 2022-06-24 00:33:20.589073
# Unit test for method bind of class Task
def test_Task_bind():
    def make_task(value):
        return task.Task(lambda reject, resolve: resolve(value))

    def add_two(value):
        return make_task(value + 2)

    def add_three(value):
        return make_task(value + 3)

    def add_four(value):
        return make_task(value + 4)

    assert make_task(1).bind(add_two).bind(add_three).bind(add_four).fork(
        lambda x: None, lambda x: x
    ) == 10


# Generated at 2022-06-24 00:33:23.989154
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> from task import Task
    >>> task = Task.of(2)
    >>> task
    <task.Task object at ...>
    >>> task.map(lambda arg: arg + arg)
    <task.Task object at ...>
    >>> task.map(lambda arg: arg + arg).fork(lambda arg: print(arg), lambda arg: print(arg))
    4
    >>> task.bind(lambda arg: Task.of(arg + arg)).fork(lambda arg: print(arg), lambda arg: print(arg))
    4
    """



# Generated at 2022-06-24 00:33:27.667304
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(10) \
        .map(lambda arg: arg + 10)

    assert result.fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 20



# Generated at 2022-06-24 00:33:31.083981
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(1).map(lambda x: x * 2).fork(None, lambda x: x)
    assert result == 2


# Generated at 2022-06-24 00:33:40.112763
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    def sum_one(number):
        """
        Sum one to number

        :param number: number to plus one
        :type number: int
        "returns: number plus one
        :rtype: int
        """
        return number + 1

    def double(number):
        """
        Double number

        :param number: number to double
        :type number: int
        :returns: double of number
        :rtype: int
        """
        return number * 2


# Generated at 2022-06-24 00:33:44.487389
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(lambda value: value, lambda value: value) == 1
    assert Task(lambda reject, _: reject(2)).fork(lambda value: value, lambda value: value) == 2


# Generated at 2022-06-24 00:33:48.295022
# Unit test for method bind of class Task
def test_Task_bind():
    def bind_function(value):
        return Task.of(value + 10)

    assert Task.of(10).bind(bind_function).fork(
        lambda error: error,
        lambda result: result
    ) == 20


# Generated at 2022-06-24 00:33:51.573040
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    task = Task.of(1).map(mapper)

    assert task.fork == (lambda _, resolve: resolve(mapper(1)))


# Generated at 2022-06-24 00:33:56.021905
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda arg: arg, lambda arg: arg) == 1
    assert Task.reject(1).fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-24 00:34:02.838257
# Unit test for constructor of class Task
def test_Task():
    def fork1():
        task = Task(lambda _, resolve: resolve(1))

        def mock_resolve(value):
            assert value == 1

        def mock_reject(_):
            assert False

        task.fork(mock_reject, mock_resolve)

    def fork2():
        task = Task(lambda reject, _: reject(1))

        def mock_resolve(_):
            assert False

        def mock_reject(value):
            assert value == 1

        task.fork(mock_reject, mock_resolve)

    fork1()
    fork2()


# Generated at 2022-06-24 00:34:04.644033
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(1))
    assert task.fork(lambda _: None, lambda arg: arg) == 1


# Generated at 2022-06-24 00:34:08.766633
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(5)

    task = Task(fork)

    assert isinstance(task, Task)
    assert task.fork(lambda _: None, lambda _: None) == 5



# Generated at 2022-06-24 00:34:11.798447
# Unit test for method map of class Task
def test_Task_map():
    @Task
    def add(reject, resolve):
        resolve(1 + 1)

    assert add.map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 3


# Generated at 2022-06-24 00:34:17.089683
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.
    """

    # call map with value 1
    result = Task.of(1).map(lambda arg: arg + 1)

    # expect resolve value 2
    assert result.fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 2



# Generated at 2022-06-24 00:34:18.311216
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(2)).fork(None, None) == 2

# Generated at 2022-06-24 00:34:20.526885
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        assert reject
        assert resolve
        return 'Fork'

    task = Task(fork)
    assert fork == task.fork


# Generated at 2022-06-24 00:34:30.342525
# Unit test for constructor of class Task
def test_Task():
    task = Task_of(1)
    assert task == Task(lambda _, resolve: resolve(1))

    task = Task_of(1)
    mapped = task.map(lambda x: x + 1)
    assert mapped.fork(
        lambda a: "ERROR",
        lambda a: a
    ) == 2

    task = Task_of(1)
    mapped = task.map(lambda x: Task_of(x + 1))
    assert mapped.fork(
        lambda a: "ERROR",
        lambda a: a
    ) == 2

    task = Task_of(1)
    mapped = task.bind(lambda x: Task_of(x + 1))
    assert mapped.fork(
        lambda a: "ERROR",
        lambda a: a
    ) == 2

# Generated at 2022-06-24 00:34:32.005029
# Unit test for constructor of class Task
def test_Task():
    assert Task  # check if Task variable is defined
    assert callable(Task)  # check if Task is constructor

    assert False


# Generated at 2022-06-24 00:34:37.664838
# Unit test for method bind of class Task
def test_Task_bind():
    def createError(a):
        return Task.reject('error')

    def createSuccess(b):
        return Task.of('success')

    error = Task.of(0).bind(createError)

    success = Task.of(0).bind(createSuccess)

    assert error.fork(lambda a: a, lambda b: b) == 'error'
    assert success.fork(lambda a: a, lambda b: b) == 'success'


# Generated at 2022-06-24 00:34:38.586880
# Unit test for constructor of class Task
def test_Task():
    assert Task(None).fork is None


# Generated at 2022-06-24 00:34:40.741244
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(1))
    assert(isinstance(task, Task))


# Generated at 2022-06-24 00:34:50.001124
# Unit test for method map of class Task
def test_Task_map():
    def test_Task_of_map(value):
        called = False
        def func(arg):
            nonlocal called
            called = True
            assert arg == value

        Task.of(value).map(func).fork(lambda _: None, lambda _: None)
        assert called


    def test_Task_reject_map(value):
        called = False
        def func(_):
            nonlocal called
            called = True

        Task.reject(value).map(func).fork(lambda _: None, lambda _: None)
        assert not called


    test_Task_reject_map(10)
    test_Task_reject_map(None)
    test_Task_of_map(10)
    test_Task_of_map(None)



# Generated at 2022-06-24 00:35:00.229279
# Unit test for method bind of class Task
def test_Task_bind():
    def add(arg):
        return Task.of(arg + 1)

    def div(arg):
        if arg % 2 == 0:
            return Task.reject(arg % 2)
        return Task.of(arg / 2)

    assert Task.of(1).bind(add).bind(div).fork(
        lambda err: (True, err),
        lambda res: (False, res)
    ) == (True, 0.5)

    assert Task.of(2).bind(add).bind(div).fork(
        lambda err: (True, err),
        lambda res: (False, res)
    ) == (True, 1)


# Generated at 2022-06-24 00:35:06.824683
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        assert value == 4
        print("Task.map - is resolved with 4")

    def reject(value):
        assert value == None
        print("Task.map - is rejected with None")

    def sub_test():
        def failure():
            return Task.reject(None)

        def success(value):
            return Task.of(value)

        Task.reject(None).map(lambda error: reject(error)).fork(reject, resolve)

        result_failure = Task.of(2).map(lambda value: value)
        result_failure.fork(reject, reject)

        result_success = Task.of(3).map(lambda value: value + 1)
        result_success.fork(reject, resolve)

    return sub_test


# Generated at 2022-06-24 00:35:08.937679
# Unit test for constructor of class Task
def test_Task():
    def fork(resolve, reject):
        return reject('error')

    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-24 00:35:11.642358
# Unit test for constructor of class Task
def test_Task():
    def fork(_, resolve):
        return resolve(1)

    task = Task(fork)

    assert task.fork(lambda _: '_', lambda res: res) == 1


# Generated at 2022-06-24 00:35:18.522261
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve('test')

    @Task
    def task_with_fork(reject, resolve):
        return fork(reject, resolve)

    assert(task_with_fork.map(lambda arg: arg.upper()).fork(
        lambda arg: 'reject: ' + arg,
        lambda arg: 'resolve: ' + arg
    ) == 'resolve: TEST')


# Generated at 2022-06-24 00:35:25.000090
# Unit test for constructor of class Task
def test_Task():
    def identity(arg):
        return arg

    def add(arg):
        return arg+1

    task = Task(identity)
    # Add test
    assert isinstance(task.map(add), Task)
    assert task.fork(lambda x: x, lambda x: x) == identity

if __name__ == '__main__':
    test_Task()

# Generated at 2022-06-24 00:35:32.953829
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def subtract_one(value):
        return value - 1

    add_one_task = Task(lambda reject, resolve: resolve(1)).map(add_one)
    assert add_one_task.fork(None, lambda result: result) == 2

    add_one_and_subtract_one = Task(lambda reject, resolve: resolve(1)).map(add_one).map(subtract_one)
    assert add_one_and_subtract_one.fork(None, lambda result: result) == 1


# Generated at 2022-06-24 00:35:36.613119
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)


# Generated at 2022-06-24 00:35:40.960312
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.
    """
    assert Task.of(2).map(lambda a: a * 3).fork(lambda x: False, lambda x: x == 6)
    assert Task.reject(2).map(lambda a: a * 3).fork(lambda x: x == 2, lambda x: False)


# Generated at 2022-06-24 00:35:44.938802
# Unit test for method bind of class Task
def test_Task_bind():
    value = 1
    task = Task.of(value)
    result = task.bind(
        lambda arg: Task.of(arg + 10)
    ).fork(
        lambda _: None,
        lambda arg: arg
    )

    assert value + 10 == result

# Generated at 2022-06-24 00:35:53.307845
# Unit test for method bind of class Task
def test_Task_bind():
    def run(reject, resolve):
        resolve(1)

    def run2(reject, resolve):
        resolve(2)

    def run3(reject, resolve):
        resolve(3)

    assert Task(run).bind(lambda x: Task(run2)).bind(lambda x: Task(run3)).fork(
        lambda x: None,
        lambda x: x
    ) == 3


if __name__ == '__main__':
    print(
        Task(lambda reject, resolve: resolve(1))
            .map(lambda x: x + 1)
            .map(lambda x: x ** 2)
            .fork(
                None,
                lambda x: x
            )
    )

# Generated at 2022-06-24 00:36:00.719221
# Unit test for method map of class Task
def test_Task_map():
    from unittest import TestCase, main
    from random import random

    class TaskMapTestCase(TestCase):
        def test_mapping_resolve_value(self):
            """
            Test for mapping Task value after resolve.
            """
            for _ in range(10):
                value = random()
                called = False

                def reject(_):
                    self.fail('Reject function called with {:f}'.format(value))

                def resolve(arg):
                    nonlocal called

                    self.assertEqual(
                        arg,
                        0.5 * value,
                        'Resolve function called with {:f}'.format(0.5 * value)
                    )

                t = Task.of(value)
                t = t.map(lambda x: 0.5 * x)
                t.fork(reject, resolve)


# Generated at 2022-06-24 00:36:08.527126
# Unit test for method bind of class Task
def test_Task_bind():
    print('test_Task_bind')
    fn_spy = spy(lambda x: Task.of(x + 1))
    Task.of(1).bind(fn_spy).fork(
        lambda e: ('error', e),
        lambda arg: ('result', arg)
    )
    assert fn_spy.call_count == 1
    assert fn_spy.call_args[0][0] == 1
    assert fn_spy.call_args[0][1] is None


# Generated at 2022-06-24 00:36:17.240410
# Unit test for constructor of class Task
def test_Task():
    """
    >>> def fork(reject, resolve):
    ...     assert reject
    ...     assert resolve
    ...     return resolve(1)

    >>> assert fork == Task(fork).fork

    >>> def fork(reject, resolve):
    ...     return reject(1)

    >>> assert fork == Task(fork).fork

    >>> assert None == Task(fork).fork(lambda _: None, lambda _: None)

    >>> assert 1 == Task(lambda _, resolve: resolve(1)).fork(lambda _: None, lambda value: value)
    """


# Generated at 2022-06-24 00:36:21.849778
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(
        lambda err: None,
        lambda value: value
    ) == 2


# Generated at 2022-06-24 00:36:28.077652
# Unit test for method bind of class Task
def test_Task_bind():

    def async_fn(x):
        def task(reject, resolve):
            def callback():
                resolve(x + 1)
            Timer(1, callback).start()
        return Task(task)

    def sync_fn(x):
        return x + 1

    assert Task.of(1).bind(sync_fn).fork(
        lambda x: None,
        lambda x: x
    ) == 2

    assert Task.of(1).bind(async_fn).fork(
        lambda x: None,
        lambda x: x
    ) == 2



# Generated at 2022-06-24 00:36:38.697173
# Unit test for method map of class Task
def test_Task_map():
    @Task
    def f(_, resolve):
        resolve(90)

    @Task
    def g(_, resolve):
        resolve(9000)

    fn = lambda x: Task.of(x + 1)
    fn2 = lambda x: Task.of(x + 2)
    fn3 = lambda x: Task.of(x + 3)

    assert f.map(fn).fork(None,
                         lambda x: True) == 91
    assert f.map(fn).map(fn2).fork(None,
                                   lambda x: True) == 92

    assert g.map(lambda x: Task.reject(False)).fork(
        lambda y: True,
        lambda _: True
    )


# Generated at 2022-06-24 00:36:44.636195
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def bind(value):
        return Task.of(value + 5)

    task = Task(fork)

    binded_task = task.bind(bind)

    def bind_fork(reject, resolve):
        return binded_task.fork(reject, resolve)

    resolve_value = 0
    reject_value = 0
    def fork_reject(value):
        nonlocal reject_value
        reject_value = value

    def fork_resolve(value):
        nonlocal resolve_value
        resolve_value = value

    Task(bind_fork).fork(fork_reject, fork_resolve)

    assert reject_value == 0
    assert resolve_value == 6


# Generated at 2022-06-24 00:36:50.254739
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind method of class Task.

    Call bind method of Task with function, that call resolve function of passed Task.
    """
    assert Task(ok(lambda _, resolve: resolve(10))).bind(
        lambda arg: Task(ok(lambda _, resolve: resolve(arg * 2)))
    ).fork(log, log) == 20


# Generated at 2022-06-24 00:36:52.955102
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    task = Task.of(1)
    assert task.map(add_one).fork(lambda: None, lambda x: x) == 2


# Generated at 2022-06-24 00:36:55.380321
# Unit test for constructor of class Task
def test_Task():
    # Test resolve
    assert Task.of(42).fork(lambda _, resolve: resolve(42))
    # Test reject
    assert Task.reject(42).fork(lambda reject, _: reject(42))

# Generated at 2022-06-24 00:37:04.263533
# Unit test for method bind of class Task
def test_Task_bind():
    # Define pseudo-function for test
    def add(value):
        return Task.of(value+1)

    def mul(value):
        return Task.of(value*2)

    task = Task.of(0).bind(add).bind(mul)
    assert task.fork(lambda x: x, lambda x: x) == 2

    def mul_reject(value):
        return Task.reject(value*2)

    task = Task.of(0).bind(add).bind(mul_reject)
    assert task.fork(lambda x: x, lambda x: x) == 2

# Generated at 2022-06-24 00:37:09.131084
# Unit test for method bind of class Task
def test_Task_bind():
    def read_file(file_name):
        def fork(reject, resolve):
            with open(file_name) as file:
                resolve(file.read())

        return Task(fork)

    def count_words(data):
        return Task.of(len(data.split()))

    result = read_file('data/lorem_ipsum.txt').bind(count_words)
    assert result.fork(lambda _: 0, lambda arg: arg) == 290



# Generated at 2022-06-24 00:37:14.949754
# Unit test for constructor of class Task
def test_Task():
    resolve_number, reject_number = 0, 0
    def resolve_fn(value):
        nonlocal resolve_number
        resolve_number += value

    def reject_fn(value):
        nonlocal reject_number
        reject_number += value

    f = Task(lambda reject, resolve: resolve(1))

    assert f.fork(
        reject_fn,
        resolve_fn
    ) == resolve_fn(1)

    assert resolve_number == 1
    assert reject_number == 0

    assert f.map(lambda value: value + 1) == Task(lambda reject, resolve: resolve(2))
    assert resolve_number == 2
    assert reject_number == 0

    assert f.bind(lambda value: Task.of(value + 1)) == Task(lambda reject, resolve: resolve(2))
    assert resolve_number == 3
   

# Generated at 2022-06-24 00:37:21.620023
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    # resolved Task
    task = Task.of(1)
    # should not throw any exception
    assert task.map(add_one).fork(None, None) == 2, "Map method returns incorrect value"

    # rejected Task
    task = Task.reject(1)
    # should not throw any exception
    assert task.map(add_one).fork(None, None) == 1, "Map method returns incorrect value"


# Generated at 2022-06-24 00:37:30.023811
# Unit test for constructor of class Task
def test_Task():
    task = Task.of('test')

# Generated at 2022-06-24 00:37:33.685567
# Unit test for method map of class Task
def test_Task_map():
    # test map
    def test_fn(value):
        return value * 2

    real_result = Task(lambda reject, resolve: resolve(2)).map(test_fn).fork(
        reject=lambda x: None,
        resolve=lambda x: x
    )

    assert real_result == 4


# Generated at 2022-06-24 00:37:35.180902
# Unit test for constructor of class Task
def test_Task():
    """
    Test Task constructor.
    """
    Task(lambda _, resolve: resolve(None))


# ----------------------------------------------------------------------------



# Generated at 2022-06-24 00:37:38.981068
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of Task
    """
    def mul_two(value):
        return value * 2

    def square(value):
        return value ** 2

    task = Task.of(2)
    assert task.map(mul_two).fork(lambda x, _y: None, lambda x, _y: x) == 4
    assert task.map(mul_two).map(square).fork(lambda x, _y: None, lambda x, _y: x) == 16


# Generated at 2022-06-24 00:37:41.270985
# Unit test for constructor of class Task
def test_Task():
    promise = Task(lambda reject, resolve: resolve(5))
    assert(promise.fork(lambda v: v, lambda v: v) == 5)
    promise = Task(lambda reject, resolve: reject(5))
    assert(promise.fork(lambda v: v, lambda v: v) == 5)


# Generated at 2022-06-24 00:37:52.511271
# Unit test for constructor of class Task
def test_Task():
    """
    Test Task constructor.

    :returns: True if tests is passed else raise error
    :rtype: boolean | Exception
    """

    # Task with resolve
    a = Task(lambda reject, resolve: resolve("a")).fork(
        lambda arg: 'a',
        lambda arg: arg
    )
    assert a == 'a'

    # Task with resolve
    b = Task(lambda reject, resolve: resolve(2)).fork(
        lambda arg: 'b',
        lambda arg: arg
    )
    assert b == 2

    # Task with reject
    c = Task(lambda reject, resolve: reject("c")).fork(
        lambda arg: arg,
        lambda arg: arg
    )
    assert c == 'c'

    # Task with reject
    d = Task(lambda reject, resolve: reject(3)).fork

# Generated at 2022-06-24 00:38:00.312400
# Unit test for method bind of class Task
def test_Task_bind():
    def function_with_error(value):
        raise Exception('Some error')

    def function_without_error(value):
        return value

    def function_with_task_with_task(value):
        return Task.reject('Some error')

    Task.of(9) \
        .bind(function_with_task_with_task) \
        .fork(
            lambda arg: print('rejected value: {}'.format(arg)),
            lambda arg: print('resolved value: {}'.format(arg))
        )

# Generated at 2022-06-24 00:38:06.834922
# Unit test for method map of class Task
def test_Task_map():
    """Unit test for method map of class Task."""
    def add_one(val):
        return val + 1

    assert Task.of(1).map(add_one).fork(
        lambda reject: None,
        lambda resolve: resolve == 2
    )

# Generated at 2022-06-24 00:38:16.200534
# Unit test for method map of class Task
def test_Task_map():
    """
    Test correctness of Task.map method.
    """
    def test1_map(value):
        """
        Test correctness of Task.map with function
        that is necessary for application.

        :param value:
        :type value:
        """
        def map_fn(x):
            return x * 2

        assert Task.of(value).map(map_fn).fork(None, id) == value * 2

    def test2_map(value):
        """
        Test correctness of Task.map with not necessary
        but important case.

        :param value:
        :type value:
        """
        def map_fn(x):
            return x

        assert Task.of(value).map(map_fn).fork(None, id) == value


# Generated at 2022-06-24 00:38:27.205509
# Unit test for method map of class Task
def test_Task_map():
    def run_Task(task):
        """
        Transform task to function with two arguments and call this function.
        """
        def function(reject, resolve):
            task.fork(reject, resolve)

        return function

    def task_to_result(task):
        """
        Transform task to result of fork call in case of reject and resolve.
        """
        return task.fork(lambda arg: arg, lambda arg: arg)

    task = Task.of(1).map(lambda arg: arg + 1)
    assert task_to_result(task) == 2

    task = Task.reject(1).map(lambda arg: arg + 2)
    assert task_to_result(task) == 1

    task = run_Task(Task.of(1).bind(lambda arg: Task.of(arg + 2)))
    assert task

# Generated at 2022-06-24 00:38:30.449695
# Unit test for method bind of class Task
def test_Task_bind():
    def _reject(_):
        raise RuntimeError("")

    def _resolve(arg):
        return arg

    task = Task(lambda _, resolve: resolve("test"))

    assert task.bind(lambda _: Task.reject("second test")).fork(_reject, _resolve) == "second test"

# Generated at 2022-06-24 00:38:34.672928
# Unit test for method bind of class Task
def test_Task_bind():
    def add2(value):
        return Task.of(value + 2)

    def raise_error(value):
        return Task.reject(value + ' is string')

    assert Task.of(1).bind(add2).fork(identity, identity) == 3
    assert Task.of('abc').bind(raise_error).fork(identity, identity) == 'abc is string'

# Generated at 2022-06-24 00:38:40.622756
# Unit test for method bind of class Task

# Generated at 2022-06-24 00:38:43.068590
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(2))
    assert task.fork(lambda a: "Error", lambda a: a) == 2


# Generated at 2022-06-24 00:38:49.006661
# Unit test for method map of class Task
def test_Task_map():
    # Test of map success
    result = Task.of(1).map(lambda x: x + 1)
    assert result.fork(lambda x: x, lambda x: x) == 2
    # Test of map failure
    result = Task.of(1).map(lambda x: Task.reject(x))
    assert result.fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-24 00:38:51.347596
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('error')

    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-24 00:38:59.547819
# Unit test for method bind of class Task
def test_Task_bind():

    v = Task(lambda reject, resolve: resolve(3))
    v1 = Task(lambda reject, resolve: resolve(4))

    def mul(x):
        def m(resolve, reject):
            return resolve(x * 3)

        return Task(m)

    def div(x):
        def d(resolve, reject):
            return resolve(x/2)

        return Task(d)

    assert v.bind(mul).fork(lambda x: 'rej', lambda x: x) == 9
    assert v1.bind(div).fork(lambda x: 'rej', lambda x: x) == 2

    v2 = Task.of(3)
    v3 = Task.of(4)

    assert v2.bind(mul).fork(lambda x: 'rej', lambda x: x) == 9
   

# Generated at 2022-06-24 00:39:04.595888
# Unit test for method bind of class Task
def test_Task_bind():
    def result(value):
        return Task.reject('rejected')

    task = Task.of('value')
    assert task.bind(result).fork(lambda x: x, lambda x: x) == 'rejected'

# Generated at 2022-06-24 00:39:08.303551
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Check that calling bind on Task call function bind on value from Task
    and return new Task with returned by bind of value
    """

    def bind(val):
        return Task.of(val + 1)

    task = Task.of(0)
    assert task.bind(bind).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-24 00:39:13.187412
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(5)
    result = task.map(lambda x: x + 1)

    assert result.fork(lambda x: x, lambda x: x) == 6


# Generated at 2022-06-24 00:39:17.339133
# Unit test for constructor of class Task
def test_Task():
    def fork_task(reject, resolve):
        resolve(1)

    task = Task(fork_task)
    assert task
    assert isinstance(task, Task)
    assert callable(task.fork)


# Generated at 2022-06-24 00:39:20.289008
# Unit test for method map of class Task
def test_Task_map():
    """
    This function test method map for class Task.
    """
    assert Task.of(1).map(lambda x: x + 1) == Task.of(2)
    assert Task.reject(1).map(lambda x: x + 1) == Task.reject(1)


# Generated at 2022-06-24 00:39:29.438832
# Unit test for method bind of class Task
def test_Task_bind():
    # Should create Task object
    value = Task(lambda reject, resolve: resolve(44))

    def add_one(arg):
        print('add_one call with arg {}'.format(arg))
        return arg + 1

    def add_value(arg):
        print('add_value call with arg {}'.format(arg))
        return Task(lambda reject, resolve: resolve(arg - 10))

    assert value.bind(add_one).bind(add_value).bind(add_one).fork(
        error=lambda arg: arg,
        success=lambda arg: arg
    ) == 33, "Should return 33"

    print('test_Task_bind - ok')


# Generated at 2022-06-24 00:39:38.907268
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def divide_by_two(x):
        return x / 2

    def multiply_by_four(x):
        return x * 4

    task_of_one = Task.of(1)
    task_of_two = Task.of(2)
    task_of_three = Task.of(3)

    assert task_of_one.map(add_one).map(multiply_by_four).map(divide_by_two).fork(lambda _: None, lambda r: r) == 4
    assert task_of_two.map(add_one).map(multiply_by_four).map(divide_by_two).fork(lambda _: None, lambda r: r) == 8

# Generated at 2022-06-24 00:39:41.820881
# Unit test for constructor of class Task
def test_Task():
    result = Task(lambda _, resolve: resolve(1)).fork(
        lambda reject: False,
        lambda resolve: resolve
    )

    assert result == 1

# Test for call of class method of

# Generated at 2022-06-24 00:39:44.533734
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)

# Generated at 2022-06-24 00:39:47.005213
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        assert value == -7

    def reject(value):
        raise Exception("Test failed")

    def mapper(value):
        return -value

    result = Task.of(7)
    result.map(mapper).fork(reject, resolve)


# Generated at 2022-06-24 00:39:54.626531
# Unit test for method bind of class Task
def test_Task_bind():
    def assert_Task_bind(rejected, expected_value):
        task = Task.of(1) \
            .bind(lambda x: Task.of(x + 1)) \
            .bind(lambda x: Task.of(x * 7)) \
            .bind(lambda x: Task.of(x / 2))
        rejected, value = task.fork(rejected, lambda arg: None)
        assert not rejected
        assert value == expected_value

    assert_Task_bind(lambda arg: None, 7)

# Generated at 2022-06-24 00:40:01.654198
# Unit test for method bind of class Task
def test_Task_bind():
    import unittest

    class Test(unittest.TestCase):
        def test_arg(self):
            def result(reject, resolve):
                return reject('error')

            def mapper(arg):
                return Task.of(arg)

            expected = 'error'
            actual = Task(result).bind(mapper)
            self.assertEquals(expected, actual)

    unittest.main(module=__name__, exit=False)

# Generated at 2022-06-24 00:40:10.337962
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Tests bind method of class Task
    """
    def sum_two(first, second):
        return Task(
            lambda reject, resolve: resolve(first + second)
        )

    def mul_two(first, second):
        return Task(
            lambda reject, resolve: resolve(first * second)
        )

    assert Task.of(1).bind(
        lambda first: Task.of(2).bind(
            lambda second: sum_two(first, second)
        )
    ).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 3


# Generated at 2022-06-24 00:40:17.055604
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for map function of Task.
    """
    from functools import partial

    def twice(x):
        """
        Return two times than input.
        """
        return x * 2

    assert Task.of(12).map(twice).fork(None, partial(assertEqual, result=24))
    assert Task.reject(12).map(twice).fork(partial(assertEqual, result=12), None)


# Generated at 2022-06-24 00:40:18.412243
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(1))
    assert task.fork(lambda e: 1, lambda a: a) == 1


# Generated at 2022-06-24 00:40:23.984693
# Unit test for method map of class Task
def test_Task_map():
    def task(resolve, reject):
        resolve(1)

    def task1(resolve, reject):
        resolve(2)

    def mapper(value):
        return value * value

    task = Task(task)
    assert_equal(task.map(mapper).fork(lambda _: None, lambda value: value), 1)
    assert_equal(task.fork(lambda _: None, lambda value: value), 1)
    assert_equal(task1.map(mapper).fork(lambda _: None, lambda value: value), 4)


# Generated at 2022-06-24 00:40:33.952013
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).map(lambda v: v + 1).fork(lambda x: x, lambda x: x) == 2
    assert Task.of('try').map(lambda v: v + ' fail').map(lambda v: v.upper()).fork(lambda x: x, lambda x: x) == 'TRY FAIL'

    assert Task.reject('fail').map(lambda v: v + ' fail').fork(lambda x: x, lambda x: x) == 'fail'
    assert Task.of('try').map(lambda v: v + ' fail').fork(lambda x: x, lambda x: x) == 'try fail'


# Generated at 2022-06-24 00:40:37.883851
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _: None).fork(None, None) == None
    assert Task(lambda _, resolve: resolve(1)).fork(None, lambda _: None) == None


# Generated at 2022-06-24 00:40:45.178599
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    value = "Hello"
    task = Task.of(value)
    assert task.fork(lambda _: "Reject", lambda arg: arg) == "Hello"

    value2 = "World"
    task2 = Task.reject(value2)
    assert task2.fork(lambda arg: arg, lambda _: "Resolve") == "World"

    def fn(arg):
        return Task.reject(arg)

    result = task.bind(fn)
    assert result.fork(lambda arg: arg, lambda _: "Resolve") == "Hello"

    def fn2(arg):
        if arg == "Hello":
            return Task.reject(arg)

        return Task.of(arg)

    result = task.bind(fn2)

# Generated at 2022-06-24 00:40:50.462549
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)


# Generated at 2022-06-24 00:40:59.357115
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def plus_one_mapper(x):
        return x + 1

    def minus_one_mapper(x):
        return x - 1

    task_with_plus_one_mapper = Task.of(0).map(plus_one_mapper)

# Generated at 2022-06-24 00:41:02.844585
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)

    assert task.map(lambda x: x).fork(lambda x: 'error', lambda x: x) == 2
    assert task.map(lambda x: x ** 2).fork(lambda x: 'error', lambda x: x) == 4


# Generated at 2022-06-24 00:41:13.709994
# Unit test for method map of class Task
def test_Task_map():
    def tester(fn):
        def result(reject, resolve):
            return fn(lambda arg: reject(arg), lambda arg: resolve(arg))

        return Task(result)

    def rejector(reject, _):
        return reject('rejected')

    def resolver(_, resolve):
        return resolve('resolved')


# Generated at 2022-06-24 00:41:21.610096
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(x):
        return x**2

    def test_resolve(x):
        return x

    def test_reject(x):
        raise Exception(x)

    def task_reject(x):
        return Task.reject(x)

    def task_resolve(x):
        return Task.of(x)

    # Test reject
    target = Task(lambda reject, _: reject(1)).bind(lambda x: Task.of(x))
    assert target.fork(test_reject, test_resolve) == 1

    # Test resolve
    target = Task(lambda _, resolve: resolve(1)).bind(lambda x: Task.reject(2))
    assert target.fork(test_reject, test_resolve) == 2

    # Test resolve

# Generated at 2022-06-24 00:41:27.826491
# Unit test for method bind of class Task
def test_Task_bind():
    def my_fn(value):
        return Task.of(value * 2)

    task = Task.of(1)

    assert task.fork(None, lambda first: first * 2) == 2
    assert task.bind(my_fn).fork(None, lambda second: second) == 2
    assert task.bind(lambda *args: Task.of(*args)
                     ).bind(my_fn).fork(None, lambda third: third) == 2


# Generated at 2022-06-24 00:41:30.668732
# Unit test for constructor of class Task
def test_Task():
    """
    >>> fn = lambda _, resolve: resolve(1)
    >>> t = Task(fn)
    >>> t.fork(lambda x: assert (x == 1))
    """


# Generated at 2022-06-24 00:41:38.376846
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        assert value == 7
        print('test_Task_map: ' + TestColor.OKBLUE + TestColor.BOLD + 'OK' + TestColor.ENDC)

    def reject(value):
        print('test_Task_map: ' + TestColor.FAIL + TestColor.BOLD + 'FAIL' + TestColor.ENDC)

    def adder(value):
        return value + 2

    task = Task.of(5)
    task.map(adder).fork(reject, resolve)

