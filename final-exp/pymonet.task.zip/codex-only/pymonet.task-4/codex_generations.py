

# Generated at 2022-06-24 00:31:35.721278
# Unit test for method map of class Task
def test_Task_map():
    def dec(value):
        return value - 1

    assert Task.of(1).map(dec).fork(noop, noop) == 0

    try:
        Task.reject(1).map(dec).fork(noop, noop)
    except Exception as e:
        assert e == 1


# Generated at 2022-06-24 00:31:37.560323
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map function of Task class
    """
    result = Task.of(1).map(lambda value: value + 1)
    assert result.fork(lambda value: value, lambda _: None) == 2


# Generated at 2022-06-24 00:31:41.903967
# Unit test for method map of class Task
def test_Task_map():
    """
        Task.map return Task of resolve function
        :type Task: Task
        :type resolve: Function(value) -> B
        :return: Task
        :rtype: Task
    """

    def resolve(value):
        return value

    def reject(value):
        return value

    task = Task(lambda r, resolve: resolve(1))
    result = task.map(resolve)
    assert result.fork(reject, resolve) == 1



# Generated at 2022-06-24 00:31:48.242962
# Unit test for method map of class Task
def test_Task_map():
    def _(v):
        return v ** 2

    def __(v):
        return v * 3

    assert Task.of(2).map(_).fork(None, _) == 4
    assert Task.of(2).map(_).map(_).fork(None, _) == 16
    assert Task.of(2).map(_).map(_).map(_).fork(None, _) == 64
    assert Task.of(2).map(_).map(_).map(_).map(_).fork(None, _) == 256

    assert Task.of(2).map(_).map(__).fork(None, _) == 18
    assert Task.of(2).map(_).map(_).map(__).fork(None, _) == 54

# Generated at 2022-06-24 00:31:52.296870
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def binder(x):
        return Task.of(x + 1)

    def tester(x):
        assert x == 2

    t = Task.of(1)
    t.map(add).fork(lambda _: None, tester)
    t.bind(binder).fork(lambda _: None, tester)


# Generated at 2022-06-24 00:32:02.348197
# Unit test for method bind of class Task
def test_Task_bind():
    mock_reject = Mock()
    mock_resolve = Mock()

    def fork_reject(_, resolve):
        def inner_reject(reject, _):
            return reject('Error')
        return resolve(Task(inner_reject).fork(mock_reject, mock_resolve) )

    def fork_resolve(reject, _):
        def inner_resolve(_, resolve):
            return resolve('Success')
        return reject(Task(inner_resolve).fork(mock_reject, mock_resolve) )

    Task(fork_reject).bind(lambda _: Task.of('')).fork(mock_reject, mock_resolve)
    assert mock_reject.called
    assert not mock_resolve.called


# Generated at 2022-06-24 00:32:07.925148
# Unit test for constructor of class Task
def test_Task():
    from random import randint
    from functools import partial

    # Check init method
    assert Task(lambda _, __: None) is not None

    # Check of method
    assert Task.of(1).fork(lambda _: False, lambda v: v == 1)
    assert Task.of([1]).fork(lambda _: False, lambda v: v == [1])
    assert Task.of({'a': 1}).fork(lambda _: False, lambda v: v == {'a': 1})
    assert Task.of('a').fork(lambda _: False, lambda v: v == 'a')
    assert Task.of(1.1).fork(lambda _: False, lambda v: v == 1.1)

    # Check reject method

# Generated at 2022-06-24 00:32:13.271462
# Unit test for constructor of class Task
def test_Task():
    def noop(reject, resolve):
        return True

    task = Task(noop)
    assert task.fork == noop

# Generated at 2022-06-24 00:32:19.802514
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    """

    def assert_test(test_name, expected, actual):
        """
        Print test result.
        """
        if expected == actual:
            print('\033[92mTest {}: passed\033[0m'.format(test_name))
        else:
            print('\033[91mTest {}: failed\033[0m'.format(test_name))

    def test_async_fn(resolve):
        """
        Test function for testing class Task.
        """
        sleep(1)
        resolve(5)

    def expected_value(value):
        """
        Return expected value for Task.
        """
        return Task.of(3).bind(lambda value: Task.of(value * 2))


# Generated at 2022-06-24 00:32:30.756351
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    For testing asynchronous interface we use time.sleep.
    """
    def _test(test_case, test_number, fork, result):
        print(test_case, test_number)

        def check_result(reject, resolve):
            resolve(reject == result['reject'] and resolve == result['resolve'])

        Task(fork).bind(check_result).fork(
            lambda arg: print(arg, "OK" if arg else "FAILED"),
            lambda _: print("UNEXPECTED RESOLVED")
        )

    test_case = "Test method bind of class Task"


# Generated at 2022-06-24 00:32:35.648535
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x + 5).fork(None, lambda x: x) == 7
    assert Task.of(7).map(lambda x: x - 5).fork(None, lambda x: x) == 2
    assert Task.of(10).map(lambda x: x / 2).fork(None, lambda x: x) == 5


# Generated at 2022-06-24 00:32:38.427170
# Unit test for method map of class Task
def test_Task_map():
    @Task
    def fork(reject, resolve):
        return resolve(2)

    assert fork.map(lambda x: x ** 2).fork(lambda _: None, lambda result: result) == 4


# Generated at 2022-06-24 00:32:44.916013
# Unit test for constructor of class Task
def test_Task():
    @pytest.fixture
    def data():
        return {
            'value': 'value',
            'reject': lambda reject, _: reject(True),
            'resolve': lambda _, resolve: resolve(True)
        }

    def test_of(data):
        task = Task.of(data['value'])

        assert task.fork(data['reject'], data['resolve'])

    def test_reject(data):
        task = Task.reject(data['value'])

        assert task.fork(data['reject'], data['resolve']) is False

    test_of(data())
    test_reject(data())


# Generated at 2022-06-24 00:32:55.360135
# Unit test for method map of class Task
def test_Task_map():
    """
    :param map_fn: function to test in Task class
    :type map_fn: Function(func: Function(value) -> B)
    :returns: True if Unit test is passed
    :rtype: bool
    """
    def map_fn(value):
        """
        Increment value on 1.

        :param value: value to increment on 1
        :type value: int
        :returns: incremented value on 1
        :rtype: int
        """
        return value + 1

    def exec_fn(reject, resolve):
        """
        :param reject: function to handle error
        :type reject: Function(error) -> A
        :param resolve: function to handle result
        :type resolve: Function(result) -> B
        """
        reject('error')


# Generated at 2022-06-24 00:33:01.890335
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.reject(value + 1)

    task = Task.reject(1).bind(fn)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 2

    task = Task.of(2).bind(fn)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 3



# Generated at 2022-06-24 00:33:07.212499
# Unit test for method bind of class Task
def test_Task_bind():
    input = 1

    def fn(value):
        assert value == input
        return Task.of(value + 1)

    result = Task.of(input).bind(fn)

    try:
        result.fork(
            lambda value: False,
            lambda value: value == input + 1
        )
    except:
        False



# Generated at 2022-06-24 00:33:16.189567
# Unit test for method bind of class Task
def test_Task_bind():
    resolve = lambda arg: arg
    reject = lambda arg: arg

    def mapper(value):
        return Task.of(value).map(lambda arg: arg * 2)

    assert Task.of(5).bind(mapper).fork(reject, resolve) == 10

    def mapper(value):
        return Task.reject(value).map(lambda arg: arg * 2)

    assert Task.of(5).bind(mapper).fork(resolve, reject) == 5

    def mapper(value):
        return Task.of(value).map(lambda arg: arg * 2)

    assert Task.reject(5).bind(mapper).fork(resolve, reject) == 5


# Generated at 2022-06-24 00:33:19.590003
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    task = Task.of(1)
    task = task.bind(mapper)
    assert task.fork(lambda reject: reject, lambda resolve: resolve) == 2


# Generated at 2022-06-24 00:33:24.793654
# Unit test for method bind of class Task
def test_Task_bind():
    """
    This method test if Task.bind works correctly.
    """
    assert Task.of(1).bind(lambda _: Task.of(2)).fork(None, print) == 2
    assert Task.of(1).bind(lambda arg: Task.of(arg + 2)).fork(None, print) == 3


# Generated at 2022-06-24 00:33:27.774582
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve(2)

    result = Task(fork).map(lambda value: value ** 2)
    assert result == 4


# Generated at 2022-06-24 00:33:33.154636
# Unit test for method bind of class Task
def test_Task_bind():
    test_Task = Task(lambda reject, resolve: reject(2))
    new_Task = test_Task.bind(lambda value: Task.of(value ** 2))
    assert new_Task.fork(
        lambda value: value == 2 ** 2,
        lambda value: False
    )


# Generated at 2022-06-24 00:33:39.327988
# Unit test for method map of class Task
def test_Task_map():
    with mock.patch("builtins.print") as mock_print:
        Task.of(1).map(lambda arg: arg + 1).fork(None, lambda arg: print(arg))
        mock_print.assert_called_once_with(2)

    with mock.patch("builtins.print") as mock_print:
        Task.of(None).map(lambda arg: arg + 1).fork(None, lambda arg: print(arg))
        mock_print.assert_called_once_with(None)

test_Task_map()


# Generated at 2022-06-24 00:33:47.136514
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(lambda _: False, lambda x: x == 2)()
    assert Task.of(1).map(lambda x: x + 1).map(lambda x: x + 1).fork(lambda _: False, lambda x: x == 3)()
    assert Task.reject(-1).map(lambda _: True).fork(lambda x: x == -1, lambda _: False)()


# Generated at 2022-06-24 00:33:50.000044
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda arg: arg + 1).fork(
        lambda arg: False,
        lambda arg: arg == 2
    )

# Generated at 2022-06-24 00:33:53.086946
# Unit test for method bind of class Task
def test_Task_bind():
    t = Task.of(2)
    t2 = t.bind(lambda x: Task.of(x + 1))
    assert t2.fork(lambda x: 'rejected', lambda x: x) == 3
    t3 = t.bind(lambda x: Task.reject(x + 1))
    assert t3.fork(lambda x: x, lambda x: 'resolved') == 3


# Generated at 2022-06-24 00:33:59.594082
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of('a').map(lambda value: value.capitalize()).fork(
        lambda rejection: rejection,
        lambda resolution: resolution
    ) == 'A'

    # testing propagation of rejections
    assert Task.reject('a').map(lambda value: value.capitalize()).fork(
        lambda rejection: rejection,
        lambda resolution: resolution
    ) == 'a'


# Generated at 2022-06-24 00:34:04.328925
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test to bind Task with function, which return new Task and
    try call bind with different argument.
    """
    def stub(value):
        def fork(reject, resolve):
            if value == 1:
                return reject(value)
            else:
                return resolve(value)

        return Task(fork)

    def tester(arg):
        return stub(arg)

    assert Task.of(1).bind(tester).fork(lambda _: True, lambda __: False)
    assert Task.of(2).bind(tester).fork(lambda __: False, lambda _: True)

# Generated at 2022-06-24 00:34:05.706634
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)

    assert task.map(lambda x: x + 2).fork(None, lambda a: a) == 3


# Generated at 2022-06-24 00:34:10.742529
# Unit test for method bind of class Task
def test_Task_bind():
    def f(value):
        if value == 2:
            return Task.reject(2)
        return Task.of(value + 1)

    def fail(value, message='Value is not equal 2'):
        assert value == 2, message


# Generated at 2022-06-24 00:34:19.232270
# Unit test for method bind of class Task
def test_Task_bind():
    fs_readFile = Task(lambda reject, resolve:
                       fs.readFile(path.join(__dirname, './Task.js'), 'utf8',
                       lambda err, data: resolve(data) if not err else reject(err)))

    result = fs_readFile.bind(
        lambda file_data: Task(
            lambda reject, resolve: resolve(file_data.replace('module.exports', 'console.log'))
        )
    )

    assert result.fork(lambda err: err, lambda data: data) == 'console.log = {\n    Task: Task,\n};\n'


# Generated at 2022-06-24 00:34:20.986558
# Unit test for method map of class Task
def test_Task_map():
    t = Task.of(1)
    assert t.fork(lambda _: (), lambda r: assert_equal(r, 1))



# Generated at 2022-06-24 00:34:25.672433
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: reject(1))
    assert task.fork(lambda arg: arg, lambda _: 0) == 1
    assert type(task) is Task


# Generated at 2022-06-24 00:34:27.972251
# Unit test for constructor of class Task
def test_Task():
    def test_fork(reject, resolve):
        return resolve('ok')

    task = Task(test_fork)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 'ok'


# Generated at 2022-06-24 00:34:29.653278
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        pass

    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-24 00:34:31.783133
# Unit test for method bind of class Task
def test_Task_bind():
    value = 1

    task = Task.of(1).bind(lambda arg: Task.of(arg + 1)).fork(
        lambda arg: arg,
        lambda arg: arg
    )

    assert task == value + 1

# Generated at 2022-06-24 00:34:35.069409
# Unit test for method bind of class Task
def test_Task_bind():
    def add1(value):
        return Task.of(value + 1)

    def multiply2(value):
        return Task.of(value * 2)

    def square_async(value):
        def square(reject, resolve):
            resolve(value ** 2)
            return None
        return Task(square)

    task = square_async(2)
    task = task.bind(add1).bind(multiply2)
    result = task.fork(lambda err: 'err', lambda res: res)
    assert result == 8



# Generated at 2022-06-24 00:34:45.280023
# Unit test for method map of class Task
def test_Task_map():
    def not_reject(value):
        assert False

    def not_resolve(value):
        assert False

    # Test Task.of behavior
    assert Task.of(1).fork(not_reject, lambda value: value) == 1

    # Test map method of class Task
    assert Task.of(1).map(lambda value: value + 1).fork(not_reject, lambda value: value) == 2
    assert Task.of(2).map(lambda value: value * 2).fork(not_reject, lambda value: value) == 4

    # Test Task.reject behavior
    assert Task.reject(1).fork(lambda value: value, not_resolve) == 1

    # Test Task.reject behavior with map method

# Generated at 2022-06-24 00:34:51.315776
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task constructor
    """
    assert Task.of(42).fork(
        lambda _: False,
        lambda arg: arg == 42
    )

    assert Task.reject(42).fork(
        lambda arg: arg == 42,
        lambda _: False
    )

    assert Task(lambda reject, resolve: resolve(42)).fork(
        lambda _: False,
        lambda arg: arg == 42
    )


# Generated at 2022-06-24 00:35:01.273373
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Only use for test.
    """
    # pylint: disable=R0914
    def success_1(resolve, reject):
        """
        Simple function for test.

        :param resolve: reject function of wrapped Task
        :type resolve: Function(value) -> None
        :param reject: reject function of wrapped Task
        :type reject: Function(value) -> None
        """
        reject('success_1 inner reject')

    def success_2(resolve, reject):
        """
        Simple function for test.

        :param resolve: reject function of wrapped Task
        :type resolve: Function(value) -> None
        :param reject: reject function of wrapped Task
        :type reject: Function(value) -> None
        """
        resolve(1)


# Generated at 2022-06-24 00:35:06.564240
# Unit test for method bind of class Task
def test_Task_bind():
    def value(value):
        return value

    def mapper(value):
        return Task.of(value * 2)

    def task_mapper(value):
        return Task.of(value)

    assert Task.of(2).bind(mapper).fork(value, value) == 4
    assert Task.of(2).bind(task_mapper).fork(value, value) == 2
    assert Task.reject(5).bind(mapper).fork(value, value) == 5


# Generated at 2022-06-24 00:35:11.852932
# Unit test for constructor of class Task
def test_Task():
    is_resolved = False
    x = 'test'

    def fork(reject, resolve):
        resolve(x)

    result = Task(fork)

    def resolve(y):
        nonlocal is_resolved
        is_resolved = True

        assert y == x

    def reject(y):
        raise AssertionError("Task is rejected")

    result.fork(reject, resolve)

    assert is_resolved



# Generated at 2022-06-24 00:35:21.269254
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    """
    def double(a):
        return a * 2
    def quintuple(a):
        return a * 5
    def total_length(a, b):
        return len(a + b)

    _Task = Task(lambda _, resolve: resolve(3))
    _Task2 = Task(lambda _, resolve: resolve('ab'))
    mapped_task = _Task.map(double).bind(lambda first:
                                           _Task2.map(quintuple).map(lambda second:
                                                                       total_length(first, second)))
    assert 42 == mapped_task.fork(lambda reject: reject('error'), lambda value: value)

    _Task = Task(lambda reject, _: reject('error'))
    mapped_task = _Task.map(double).map

# Generated at 2022-06-24 00:35:22.203337
# Unit test for constructor of class Task
def test_Task():
    def func(reject, resolve):
        resolve(1)

    assert Task(func).fork == func


# Generated at 2022-06-24 00:35:32.442531
# Unit test for method map of class Task
def test_Task_map():
    def assert_functional_call(
        testCase,
        method,
        expected_resolve_arg,
        expected_reject_arg,
        fork_arg,
    ):
        resolve = mock.Mock()
        reject = mock.Mock()
        method(resolve, reject)

        assert_called_once_with(
            testCase,
            resolve,
            (expected_resolve_arg,),
        )
        assert_called_once_with(
            testCase,
            reject,
            (expected_reject_arg,),
        )

    class TestMapCase(unittest.TestCase):
        def test_map_with_one_arg_resolve_function(self):
            def resolve_function(arg):
                return arg


# Generated at 2022-06-24 00:35:42.138802
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.

    Test cases:
    1. Test with data-type synchronous
    2. Test with data-type asynchronous
    3. Test with rejected Task
    """
    def function(value):
        return value + 2

    # Test 1.
    # Test with data-type synchronous
    task = Task.of(5).map(function)

# Generated at 2022-06-24 00:35:45.139689
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve('test_value')

    task = Task(fork)

    assert task.fork(lambda arg: arg, lambda arg: arg) == 'test_value'


# Generated at 2022-06-24 00:35:52.616301
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind must return Task with mapped resolve attribute.
    """
    start_time = get_time()
    x = 100500

    def fork(reject, resolve):
        resolve(x)

    def mapper(arg):
        return Task(fork)

    t = Task(fork)

    def reject(arg):
        assert arg == x
        assert get_time() - start_time > x

    def resolve(arg):
        assert arg == x
        assert get_time() - start_time < x

    t.bind(mapper).fork(reject, resolve)



# Generated at 2022-06-24 00:35:58.579205
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task.
    """
    @Task.of
    def async_sum(a, b):
        return a + b

    @async_sum.bind
    def f(future):
        return future

    # Chain like: [Task(10), Task(20), Task(30)] -> Task(60)
    result = Task.reject(10).bind(lambda t: Task.of(20)) \
        .bind(lambda t: Task.reject(30)) \
        .fork(lambda t: print(t))

    assert result == 60

if __name__ == "__main__":
    test_Task_map()

# Generated at 2022-06-24 00:35:59.791055
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)) == Task.of(1)


# Generated at 2022-06-24 00:36:10.355435
# Unit test for method bind of class Task
def test_Task_bind():
    def double(value):
        return value * 2

    def empty_and_double(value):
        return double(value)

    def triple(value):
        return value * 3

    def double_and_triple(value):
        return double(value) | triple

    def empty_and_double_and_triple(value):
        return double_and_triple(value)

    assert Task.of(3) | double_and_triple == Task.of(18)
    assert Task.of(3) | empty_and_double_and_triple == Task.of(18)
    assert Task.of(3) | empty_and_double | double_and_triple == Task.of(36)
    assert Task.of(3) | empty_and_double_and_triple | empty_and_double == Task

# Generated at 2022-06-24 00:36:15.925374
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Function test Task bind method,
    1. Check that all values in Task of and Task bind are equal.
    2. Check that all values in Task of and Task bind are equal (with map).
    """
    assert Task.of(2).bind(lambda x: Task.of(x + 1)).fork(None, lambda x: x) == 3
    assert Task.of(2).bind(lambda x: Task.of(x + 1)).map(lambda x: x + 1).fork(None, lambda x: x) == 4


# Generated at 2022-06-24 00:36:21.736311
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(
        lambda x: x,
        lambda x: x
    ) == 2


# Generated at 2022-06-24 00:36:25.174491
# Unit test for method map of class Task
def test_Task_map():
    """
    Method 'map' of class Task should return Task with result of
    called function 'fn' with Task value.
    """
    @Task.map
    def fn(a):
        return a * 2

    assert fn(2).fork(lambda _: 0, lambda v: v) == 4


# Generated at 2022-06-24 00:36:27.598601
# Unit test for constructor of class Task
def test_Task():
    """
    Case when Task is created
    """
    assert Task(lambda reject, resolve: resolve("test")).fork(None, None) == "test"


# Generated at 2022-06-24 00:36:36.465446
# Unit test for method bind of class Task
def test_Task_bind():
    result_1 = Task.of(2).bind(lambda num: Task.of(num * 2))
    assert result_1.fork(lambda _: 0, lambda result: result) == 4
    result_2 = Task.of(4).bind(lambda num: Task.of(num * 2))
    assert result_2.fork(lambda _: 0, lambda result: result) == 8
    result_3 = Task.of(4).bind(lambda num: Task.of(num * 2).bind(lambda r: Task.of(r * 3)))
    assert result_3.fork(lambda _: 0, lambda result: result) == 24


# Generated at 2022-06-24 00:36:39.711777
# Unit test for method bind of class Task
def test_Task_bind():
    def adder(x):
        return Task.of(x + 1)

    def add_two(x):
        return x + 2

    def add_four(x):
        return x + 4

    def ok_adder(x):
        return Task.of(adder(x))

    assert Task.of(1).bind(adder).fork(not_called, identity) == 2
    assert Task.of(1).bind(ok_adder).bind(adder).fork(not_called, identity) == 3


# Generated at 2022-06-24 00:36:46.439861
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    def mapper_error(value):
        return Task.of(value + 1) if value > 10 else Task.reject(value)

    assert Task.of(1).bind(mapper).fork(lambda x: "error", lambda x: x) == 2
    assert Task.reject(1).bind(mapper_error).fork(lambda x: x, lambda x: "error") == 1

# Generated at 2022-06-24 00:36:49.361779
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('test')
    assert Task(fork).fork(lambda arg: arg, lambda arg: arg) == 'test'


# Generated at 2022-06-24 00:36:54.808397
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(5)

    def test_fork(reject, resolve):
        return Task(fork).fork(reject, resolve)

    def fn(arg):
        return Task.of(arg * 2)

    assert Task(test_fork).bind(fn).fork(lambda e: e, lambda v: v) == 10

if __name__ == '__main__':
    # Test for Task class
    test_Task_bind()

# Generated at 2022-06-24 00:37:02.553999
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Simple test for method bind of class Task.
    Call `Task.of(4).bind(lambda a: Task.of(a * 3))` and
    check if it's return resolved Task with correct value.
    """
    def check_result(resolve, reject):
        assert resolve(12)

    Task.of(4).bind(lambda a: Task.of(a * 3)).fork(
        lambda arg: None,
        check_result
    )



# Generated at 2022-06-24 00:37:08.019028
# Unit test for method bind of class Task
def test_Task_bind():
    @Task.of.register(int)
    def of_int(a):
        return Task.of(a)

    @Task.of.register(bool)
    def of_boolean(a):
        return Task.of(a)

    t = Task.of(1).bind(lambda x: of_boolean(x == 1))

    assert t.fork(lambda x: False, lambda x: x)

    t = Task.reject(1).bind(lambda x: of_boolean(x == 1))

    assert not t.fork(lambda x: False, lambda x: x)


# Generated at 2022-06-24 00:37:11.253561
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(_, resolve):
        return resolve(2)

    def mapper(x):
        return Task.of(x + 2)

    task = Task(fork)
    new_task = task.bind(mapper)
    assert new_task.fork(lambda _: False, lambda arg: arg == 4)


# Generated at 2022-06-24 00:37:21.975839
# Unit test for constructor of class Task
def test_Task():
    """
    Test for checking working of public API of Task.
    """
    def forker(reject, resolve):
        """
        Simple function for testing.
        """
        resolve('Initial Value')

    task = Task(forker)

    assert 'Initial Value' == task.fork(lambda arg: arg, lambda arg: arg)

    assert 'Mapped Value' == task.map(lambda arg: 'Mapped Value').fork(lambda arg: arg, lambda arg: arg)
    assert 'Mapped Value' == task.bind(lambda arg: Task.of('Mapped Value')).fork(lambda arg: arg, lambda arg: arg)

    assert 'Initial Value' == Task.of('Initial Value').fork(lambda arg: arg, lambda arg: arg)

# Generated at 2022-06-24 00:37:23.781307
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(3))
    assert task.fork(lambda _: 0, lambda n: n) == 3


# Generated at 2022-06-24 00:37:32.869271
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for map function of Task.
    """
    def resolve_fn(resolve, reject):
        resolve(2)

    def reject_fn(resolve, reject):
        reject(2)

    def mapper_fn(value):
        return value + 2

    task_resolve = Task(resolve_fn)
    task_reject = Task(reject_fn)

    assert isinstance(task_resolve.map(mapper_fn), Task)
    assert task_resolve.map(mapper_fn).fork(
        lambda x: 'reject', lambda x: x) == 4
    assert task_reject.map(mapper_fn).fork(
        lambda x: 'reject', lambda x: x) == 'reject'


# Generated at 2022-06-24 00:37:34.293446
# Unit test for constructor of class Task
def test_Task():
    assert Task.of('value') == Task(lambda _, resolve: resolve('value'))


# Generated at 2022-06-24 00:37:40.162784
# Unit test for constructor of class Task
def test_Task():

    # Resolve
    def hello(resolve, _):
        resolve('hello')

    resolved = Task(hello)
    assert 'hello' == resolved.fork(lambda x: x, lambda x: x)
    assert 'hello' == resolved.map(lambda x: x).fork(lambda x: x, lambda x: x)

    # Reject
    def bye(_, resolve):
        resolve('bye')

    rejected = Task(bye)
    assert 'bye' == rejected.fork(lambda x: x, lambda x: x)
    assert 'bye' == rejected.map(lambda x: x).bind(lambda x: Task.reject(x)).fork(lambda x: x, lambda x: x)


# Generated at 2022-06-24 00:37:48.840687
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind
    """
    def add(a, b):
        """
        Helper function for add two argument.

        :param a: first argument for adding
        :type a: Int
        :param b: second argument for adding
        :type b: Int
        :returns: result of adding
        :rtype: Int
        """
        return a + b

    def get_response_from_check(arg):
        """
        Wrapper and mock for method get_response_from_check

        :param arg:  argument for mock
        :type arg: Any
        :returns: Task with resolved True value
        :rtype: Task[True]
        """
        return Task.of(True)


# Generated at 2022-06-24 00:37:51.644494
# Unit test for method bind of class Task
def test_Task_bind():
    fn = lambda x: x + 1
    task = Task.of(1).map(fn).bind(fn)

    assert task.fork(lambda x: False, lambda x: x == 3)
    assert task.fork(lambda x: True, lambda x: False)

# Generated at 2022-06-24 00:37:53.274684
# Unit test for constructor of class Task
def test_Task():
    print("Test #1")
    print("Task constructor check")
    assert type(Task(lambda _, __: None)) is Task
    print("Passed\n")


# Generated at 2022-06-24 00:38:00.414687
# Unit test for constructor of class Task
def test_Task():
    def add1(x):
        return (x + 1)

    # Test for Task.of method
    assert Task.of(1).fork(
        lambda reject: None,
        lambda resolve: add1(resolve)
    ) == 2

    # Test for Task.reject method
    assert Task.reject(1).fork(
        lambda reject: add1(reject),
        lambda resolve: None
    ) == 2


# Generated at 2022-06-24 00:38:01.647321
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(add(1)).fork(None, None) == 1


# Generated at 2022-06-24 00:38:07.239123
# Unit test for method map of class Task
def test_Task_map():
    value = [1, 2, 3]
    task = Task.of(value)
    mapped_task = task.map(lambda arg: 3 * arg)
    assert mapped_task.fork(lambda arg: arg, lambda arg: arg) == [3, 6, 9]



# Generated at 2022-06-24 00:38:11.455386
# Unit test for method map of class Task
def test_Task_map():
    my_task = Task.of(1)
    mapper = lambda value: value + 10
    result_task = my_task.map(mapper)

    assert isinstance(result_task, Task)
    assert result_task.fork(lambda arg: arg, lambda arg: arg) == 11


# Generated at 2022-06-24 00:38:14.473500
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(arg):
        return Task.of(arg + 1)

    result = Task.of(1).bind(mapper).fork(lambda _: None, lambda arg: arg)

    assert result == 2



# Generated at 2022-06-24 00:38:18.303570
# Unit test for constructor of class Task
def test_Task():
    expected_value = 'value'
    task = Task(lambda _, resolve: resolve(expected_value))
    result = task.fork(lambda _: 'reject', lambda arg: arg)

    assert result == expected_value



# Generated at 2022-06-24 00:38:22.151938
# Unit test for method map of class Task
def test_Task_map():
    def on_resolve(value):
        return value + 20

    value = 14
    task = Task.of(value)
    result = task.map(on_resolve).fork(lambda arg: arg, lambda arg: arg)

    assert result == 34


# Generated at 2022-06-24 00:38:29.269764
# Unit test for method bind of class Task
def test_Task_bind():
    # Create Task with fork(Task[Function(_, resolve) -> A])
    actual = Task(lambda _, resolve: resolve(10))
    # Bind fork with mapper(Function(value) -> Task[Function(_, resolve) -> B])
    mapped_actual = actual.bind(lambda value: Task(lambda _, resolve: resolve(value / 10)))
    # Call fork(reject, resolve)
    mapped_actual.fork(
        lambda arg: print("Rejected"),
        lambda arg: print("Resolved value: " + str(arg))
    )



# Generated at 2022-06-24 00:38:30.939518
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(None)).fork(lambda _: None, lambda value: value) is None


# Generated at 2022-06-24 00:38:33.547500
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1) == Task(lambda _, resolve: resolve(1))
    assert Task.reject(None) == Task(lambda reject, _: reject(None))


# Generated at 2022-06-24 00:38:36.977785
# Unit test for method bind of class Task
def test_Task_bind():
    """Test bind method of Task class"""
    def fork(reject, resolve):
        resolve(3)

    def mapper(arg):
        def fork(reject, resolve):
            resolve(arg + 3)
        return Task(fork)

    assert Task(fork).bind(mapper).fork(lambda x: x, lambda x: x) == 6


# Generated at 2022-06-24 00:38:39.668635
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(2)

    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-24 00:38:43.558870
# Unit test for constructor of class Task
def test_Task():
    def assertion_error(_):
        raise AssertionError()

    def fork(reject, resolve):
        resolve(0)

    assert Task(fork).fork(assertion_error, lambda x: \
        (x == 0 and x or assertion_error(x))
    )


# Generated at 2022-06-24 00:38:47.753759
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, res: res(1)).fork(lambda _: -1, lambda res: res) == 1
    assert Task(lambda rej, _: rej(0)).fork(lambda rej: rej, lambda _: -1) == 0


# Generated at 2022-06-24 00:38:51.724744
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject("reject")

    task = Task(fork)
    assert task.fork(lambda reject: reject("reject"), lambda resolve: resolve("resolve")) == "reject"


# Generated at 2022-06-24 00:38:54.612283
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    task = Task(lambda _, resolve: resolve('foo'))
    assert task.fork(lambda _: 'foo', lambda _: 'bar') == 'foo'


# Generated at 2022-06-24 00:39:00.997630
# Unit test for method bind of class Task
def test_Task_bind():
    state = ""

    def handler_object(arg):
        nonlocal state
        state = "called " + arg

    promise = Task.of("first task")
    promise.bind(lambda arg: handler_object("handler")).bind(lambda arg: handler_object("handler2")).fork(
        lambda arg: handler_object("handler3"),
        lambda _: None
    )
    assert state == "called handler"

# Generated at 2022-06-24 00:39:07.859549
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve('My name is Task')

    task = Task(fork)

    def mapper(value):
        def fork(reject, resolve):
            resolve(value + ' and I know how do it.')
        return Task(fork)

    result = task.bind(mapper)

    def assert_eql(reject, resolve):
        assert resolve('My name is Task and I know how do it.')

    result.fork(assert_eql, assert_eql)


# Generated at 2022-06-24 00:39:16.260511
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """

    def test(reject, resolve):
        return resolve(3)

    def mapper(value):
        """
        :param value: value to map
        :type value: int
        :returns: mapped value
        :rtype: str
        """
        return str(value)

    task = Task(test).map(mapper)

    task.fork(
        lambda value: assert_(value, '3'),
        lambda value: assert_(value, '3')
    )


# Generated at 2022-06-24 00:39:21.765691
# Unit test for method bind of class Task
def test_Task_bind():
    def task_resolved(arg):
        return Task.of(arg)

    def task_rejected(arg):
        return Task.reject(arg)

    assert Task.of(10).bind(task_resolved).fork(None, lambda value: isinstance(value, int)).get() == True
    assert Task.of(10).bind(task_rejected).fork(lambda value: isinstance(value, int), None).get() == True
    assert Task.reject(10).bind(task_rejected).fork(lambda value: isinstance(value, int), None).get() == True


# Generated at 2022-06-24 00:39:27.897519
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda v: v + 1).fork(
        lambda v: v,
        lambda v: v
    ) == 2, "Task of(1).map(plus_one)"
    assert Task.reject(1).map(lambda v: v + 1).fork(
        lambda v: v,
        lambda v: v
    ) == 1, "Task reject(1).map(plus_one)"


# Generated at 2022-06-24 00:39:36.892307
# Unit test for method bind of class Task
def test_Task_bind():
    def is_even(num):
        return num % 2 == 0

    def data_of(num):
        return 'even' if is_even(num) else 'odd'

    assert Task.of(2).bind(lambda x: Task.reject(2)) == Task.reject(2)
    assert Task.reject(1).bind(lambda x: Task.reject(2)) == Task.reject(1)
    assert Task.of(1).bind(lambda x: Task.reject('odd')) == Task.reject('odd')
    assert Task.of(2).bind(lambda x: Task.of('even')) == Task.of('even')
    assert Task.of(2).bind(lambda x: Task.of(data_of(x))) == Task.of('even')

# Generated at 2022-06-24 00:39:42.583612
# Unit test for method map of class Task
def test_Task_map():
    def add_x(x):
        return lambda value: value + x

    def add_y(y):
        return lambda value: value + y

    task = Task(lambda reject, resolve: resolve(1))

    assert task.map(add_x(1)).fork(None, lambda x: x) == 2
    assert task.map(add_x(1)).map(add_y(1)).fork(None, lambda x: x) == 3


# Generated at 2022-06-24 00:39:46.528938
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.reject(1).bind(lambda x: Task.of(x + 2)).fork(identity, identity) == 1
    assert Task.of(1).bind(lambda x: Task.of(x + 2)).fork(identity, identity) == 3


# Generated at 2022-06-24 00:39:51.282499
# Unit test for method bind of class Task
def test_Task_bind():
    def add(b):
        return Task.of(b + 10)

    return (Task.of(10)
            .bind(lambda a: Task.of(a + 10))
            .bind(add)
            .map(lambda a: a + 10))


# Generated at 2022-06-24 00:40:02.478013
# Unit test for method map of class Task
def test_Task_map():
    counter = 0
    context = {'task_value': 0}

    def default_reject(value):
        nonlocal counter
        counter += 1
        context['task_value'] = value

    def default_resolve(value):
        nonlocal counter
        counter -= 1
        context['task_value'] = value

    def error1(a):
        return a + 1

    def error2(a):
        return a + 1

    def error3(a):
        return a + 1

    Task(lambda reject, resolve: resolve(1)).map(error1).fork(default_reject, default_resolve)
    assert counter == 0
    assert context['task_value'] == 2


# Generated at 2022-06-24 00:40:10.157922
# Unit test for method bind of class Task
def test_Task_bind():
    """
    :var t1: Task[Function(resolve, reject) -> Int]
    :var t2: Task[Function(resolve, reject) -> Int]
    :var t_res: Task[Function(resolve, reject) -> Int]
    """
    t1 = Task.of(42)
    t2 = Task.reject(42)
    t_res = t1.bind(lambda arg: t2)
    assert t1.fork(lambda reject, resolve: reject(arg), lambda resolve, reject: resolve(arg)) == 42
    assert t1.fork(lambda reject, resolve: reject(arg), lambda resolve, reject: resolve(arg)) == 42
    assert t_res.fork(lambda reject, resolve: reject(arg), lambda resolve, reject: resolve(arg)) == 42

# Generated at 2022-06-24 00:40:16.240947
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)

    assert isinstance(task, Task)
    
    assert task.fork(lambda _: None, lambda arg: arg) == 1
    assert task.map(lambda arg: arg + 2).fork(lambda _: None, lambda arg: arg) == 3
    assert task.map(lambda arg: arg * 2).fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-24 00:40:18.850905
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(5).fork(
        lambda _: True,
        lambda value: value == 5
    )



# Generated at 2022-06-24 00:40:22.456983
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(
        lambda arg: assert_(False, {'arg': arg}),
        lambda arg: assert_(arg == 1)
    )
    assert Task.reject(1).fork(
        lambda arg: assert_(arg == 1),
        lambda arg: assert_(False, {'arg': arg})
    )


# Generated at 2022-06-24 00:40:27.575760
# Unit test for constructor of class Task
def test_Task():
    # Test for constructor of: Task with value
    assert Task.of(5).fork(lambda _: False, lambda arg: arg == 5)
    # Test for constructor of: Task without value
    assert Task.of().fork(lambda _: True, lambda arg: arg is None)
    # Test for constructor of: Task with error
    assert Task.reject(5).fork(lambda arg: arg == 5, lambda _: False)
    # Test for constructor of: Task without error
    assert Task.reject().fork(lambda arg: arg is None, lambda _: True)


# Generated at 2022-06-24 00:40:33.322565
# Unit test for constructor of class Task
def test_Task():
    def process(reject, resolve):
        resolve(1)

    task = Task(process)
    assert isinstance(task.fork, Process)


# Generated at 2022-06-24 00:40:44.150899
# Unit test for method bind of class Task
def test_Task_bind():
    value = random.randint(1, 100)
    t1 = Task.of(value)
    t2 = Task.of(value + 1).bind(lambda arg: Task.of(arg + 1))

    assert t1.fork(lambda arg: None, lambda arg: arg) == value
    assert t2.fork(lambda arg: None, lambda arg: arg) == value + 2

    value = random.randint(1, 100)
    t1 = Task.reject(value)
    t2 = Task.of(value + 1).bind(lambda arg: Task.of(arg + 1))

    assert t1.fork(lambda arg: arg, lambda arg: None) == value
    assert t2.fork(lambda arg: None, lambda arg: arg) == value + 2

    value = random.randint(1, 100)
   

# Generated at 2022-06-24 00:40:54.689007
# Unit test for method bind of class Task
def test_Task_bind():
    from expect import expect

    class Reject(Exception):
        pass

    class Resolve(Exception):
        pass

    def case_of_error(exception):
        def result(reject, _):
            raise exception

        return Task(result)

    def case_of_success(value):
        def result(_, resolve):
            return resolve(value)

        return Task(result)

    def case_of_reject(value):
        def result(reject, _):
            return reject(value)

        return Task(result)

    expect(case_of_success(1).bind(lambda _: case_of_success(2)).fork(None, None)).to_equal(2)

# Generated at 2022-06-24 00:41:05.904438
# Unit test for method map of class Task
def test_Task_map():
    callback = Mock()
    callback.name = 'callback'

    callback_mock = Mock()
    callback_mock.name = 'callback_mock'

    task_without_resolve = Task(lambda reject, _: callback_mock())
    task_without_reject = Task(lambda _, resolve: callback_mock())

    task_with_everything = Task(lambda reject, resolve: callback_mock())

    task_without_resolve.fork(
        lambda arg: callback(arg),
        lambda arg: callback(arg)
    )

    task_without_reject.fork(
        lambda arg: callback(arg),
        lambda arg: callback(arg)
    )

    task_with_everything.fork(
        lambda arg: callback(arg),
        lambda arg: callback(arg)
    )

    assert callback

# Generated at 2022-06-24 00:41:10.525333
# Unit test for method map of class Task
def test_Task_map():
    def to_upper(arg):
        return arg.upper()

    def to_lower(arg):
        return arg.lower()

    task = Task.of('test')

    result = task.map(to_upper)
    assert isinstance(result, Task)

    assert result.fork(None, None) == None
    assert result.fork(None, to_lower) == 'TEST'



# Generated at 2022-06-24 00:41:17.435559
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(10)

    def mapper_function(value):
        def fork(reject, resolve):
            resolve(value + 1)
        return Task(fork)

    task = Task(fork)
    task2 = task.bind(mapper_function)

# Generated at 2022-06-24 00:41:21.928808
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    task = task.map(lambda x: x + 1)

    def resolve(value):
        assert value == 2, "result is {}".format(value)

    task.fork(lambda _: None, resolve)



# Generated at 2022-06-24 00:41:26.515301
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task.
    """
    assert Task.of(2).map(lambda x: x*2).fork(None, assert_equal)(4)
    assert Task.reject(1).map(lambda x: x+1).fork(assert_equal, None)(1)


# Generated at 2022-06-24 00:41:29.613183
# Unit test for constructor of class Task
def test_Task():
    check.equal(Task(lambda reject, resolve: None), Task(lambda reject, resolve: None))
    check.not_equal(Task(lambda reject, resolve: None), Task(lambda reject, resolve: reject(1)))
    check.not_equal(Task(lambda reject, resolve: None), None)


# Generated at 2022-06-24 00:41:40.377438
# Unit test for constructor of class Task
def test_Task():

    # Case 1
    task = Task(lambda a, b: b(13))
    assert task.fork(lambda a: a, lambda b: b) == 13
    assert task.fork(lambda a: a, lambda b: b) == Task.of(13).fork(lambda a: a, lambda b: b)

    # Case 2
    assert Task.of(17).fork(lambda a: a, lambda b: b) == 17
    assert Task.of(17).fork(lambda a: a, lambda b: b) == Task(lambda a, b: b(17)).fork(lambda a: a, lambda b: b)

    # Case 3
    assert Task.reject(17).fork(lambda a: a, lambda b: b) == 17