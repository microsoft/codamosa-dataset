

# Generated at 2022-06-24 00:31:43.839800
# Unit test for method map of class Task
def test_Task_map():
    def inc(value):
        return value + 1

    def double(value):
        return value * 2

    def double_and_inc(value):
        return double(inc(value))

    task_of_one = Task.of(1)
    result_task = task_of_one.map(inc)
    result_value = result_task.fork(
        lambda reject: reject
    )(
        lambda resolve: resolve
    )
    assert result_value == 2

    result_task = task_of_one.map(double)
    result_value = result_task.fork(
        lambda reject: reject
    )(
        lambda resolve: resolve
    )
    assert result_value == 2

    result_task = task_of_one.map(double_and_inc)

# Generated at 2022-06-24 00:31:52.486329
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.

    :returns: None
    :rtype: None
    """
    # Callable object to check passed parameters of bind
    class Holder:
        """
        Class to store parameter error.
        """

        def __init__(self, error):
            """
            Initialize Holder

            :param error:
            :type error: None | int
            """
            self.error = error

        def __call__(self, value):
            """
            Call Holder.

            :param value: object to store
            :type value: Any
            :returns: None
            :rtype: None
            """
            self.error = value

    # Callable object to check passed parameters of bind
    class Store:
        """
        Class to store parameter result.
        """


# Generated at 2022-06-24 00:31:59.850176
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_three(value):
        return value + 3

    resolve = lambda value: value
    assert Task.of(1).map(add_one).map(add_three).fork(None, resolve) == 5

    resolve = lambda value: value
    assert Task.of(1).bind(lambda value: Task.of(add_one(value))) \
        .bind(lambda value: Task.of(add_three(value))) \
        .fork(None, resolve) == 5

# Generated at 2022-06-24 00:32:07.909080
# Unit test for method bind of class Task
def test_Task_bind():
    """
    (Task[reject, resolve], fn: reject, resolve) -> Task[reject, mapped_value]
    """
    def task_reject_fn(reject):
        """
        (reject, _) -> reject
        """
        return reject("reject")

    def task_resolve_fn(_, resolve):
        """
        (_, resolve) -> resolve
        """
        return resolve("resolve")

    def bind_fn(value):
        """
        (value) -> Task[resolve, reject]
        """
        return Task(task_resolve_fn)

    task = Task(task_reject_fn)
    assert task.bind(bind_fn) == Task(task_reject_fn)

    task = Task(task_resolve_fn)

# Generated at 2022-06-24 00:32:10.358538
# Unit test for constructor of class Task
def test_Task():
    def fork(_, __):
        pass

    T = Task(fork)
    fork(None, None)


# Generated at 2022-06-24 00:32:17.231696
# Unit test for method map of class Task
def test_Task_map():
    """
    Test example for method map of class Task.
    """
    def resolve(num):
        return num + 1

    def reject(num):
        return num - 1

    def mapper(num):
        return num * 2

    task = Task(lambda _, resolve: resolve(1))
    assert task.map(mapper).fork(resolve, reject) == 2
    assert Task.of(2).map(mapper).fork(resolve, reject) == 4
    assert Task.reject(1).map(mapper).fork(resolve, reject) == 0


# Generated at 2022-06-24 00:32:21.364626
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Verify correctness of function bind.
    """
    # Given
    promise = Task.of(1)

    # When
    task = promise.bind(lambda x: Task.of(x + 1))

    # Then
    assert task.fork(lambda x: x, lambda x: x) == 2

# Generated at 2022-06-24 00:32:23.789859
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(42))
    assert task # todo: case when fork call reject function?


# Generated at 2022-06-24 00:32:26.410854
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve('value'))

    assert task.fork(lambda x: x, lambda x: x) == 'value'


# Generated at 2022-06-24 00:32:36.816168
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        if value == 0:
            return Task.reject(u"value equal to zero")
        elif value > 0:
            def handle(resolve, reject):
                if value > 10:
                    reject(u"value more than 10")
                else:
                    resolve(value * 2)

            return Task(handle)

    assert Task.of(0).bind(fn).fork(lambda reject, _: reject, lambda _, resolve: resolve) == u"value equal to zero"
    assert Task.of(1).bind(fn).fork(lambda reject, _: reject, lambda _, resolve: resolve) == 2
    assert Task.of(11).bind(fn).fork(lambda reject, _: reject, lambda _, resolve: resolve) == u"value more than 10"

    

# Generated at 2022-06-24 00:32:44.864913
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    @Task.of
    def square(x):
        return x * x

    @Task.reject
    def squareRoot(x):
        if x < 0:
            raise ValueError('Square root of negative number: %d' % x)
        return math.sqrt(x)

    @Task.of
    def isEven(x):
        return x % 2 == 0

    # Case of resolved squareRoot
    assert square(20)\
        .map(lambda x: str(x))\
        .map(len)\
        .fork(lambda x: False, lambda x: x == 2) is True

    # Case of rejected squareRoot

# Generated at 2022-06-24 00:32:53.992764
# Unit test for method map of class Task
def test_Task_map():
    # Test with arithmetic functions
    assert Task.of(2).map(lambda x: x + 3).fork(lambda a: None, lambda b: b) == 5
    assert Task.of(2).map(lambda x: x * 3).fork(lambda a: None, lambda b: b) == 6
    assert Task.of(2).map(lambda x: x * x).fork(lambda a: None, lambda b: b) == 4
    assert Task.of(3).map(lambda x: x * x + 2).fork(lambda a: None, lambda b: b) == 11
    # Test with functions that are not arithmetic
    assert Task.of(2).map(lambda x: str(x) + '1').fork(lambda a: None, lambda b: b) == '21'

# Generated at 2022-06-24 00:32:56.883707
# Unit test for constructor of class Task
def test_Task():
    task_from_function = Task(lambda _,resolve: resolve(1))
    assert type(task_from_function) is Task

# Test for static Task.of method of class Task

# Generated at 2022-06-24 00:33:01.015343
# Unit test for constructor of class Task
def test_Task():
    control = 10
    task = Task(lambda _, resolve: resolve(control))
    assert task.fork(lambda _: None, lambda value: value) is control


# Generated at 2022-06-24 00:33:04.981923
# Unit test for constructor of class Task
def test_Task():
    test_value = 40
    task = Task(lambda _, resolve: resolve(test_value))
    check_result = None

    def check(arg):
        nonlocal check_result
        check_result = arg

    task.fork(assert_false, check)
    assert check_result == 40


# Generated at 2022-06-24 00:33:12.820937
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    def increment(arg):
        """
        Add one to `arg`.

        :param arg: number to add one
        :type arg: int
        :returns: sum of one and `arg`
        :rtype: int
        """
        return arg + 1

    assert Task.of(1).map(increment).fork(lambda __: None, lambda arg: arg) == 2


# Generated at 2022-06-24 00:33:20.203109
# Unit test for method map of class Task
def test_Task_map():
    a = Task.of(1)
    def result(reject, resolve):
        resolve(reject(a.fork(lambda _: 0, lambda x: x + 1)))
        return
    b = Task(result)
    assert b.fork(lambda x: x, lambda x: x) == 2



# Generated at 2022-06-24 00:33:22.724480
# Unit test for constructor of class Task
def test_Task():
    def resolve(x):
        return x

    def reject(x):
        return x

    def fork(reject, resolve):
        return reject('42')

    assert Task(fork).fork(reject, resolve) == reject('42')



# Generated at 2022-06-24 00:33:29.247761
# Unit test for method map of class Task
def test_Task_map():
    # for assert
    b = 1
    c = 1
    d = 3

    # for assert
    def f(callback, x):
        callback(x+b)

    def g(callback, x):
        callback(x*c+d)

    # assert

# Generated at 2022-06-24 00:33:39.328084
# Unit test for method bind of class Task
def test_Task_bind():
    # Extract result from Task
    def extract(task):
        return task.fork(
            lambda arg: arg,
            lambda arg: arg
        )

    # Multiply by 2
    def multiply_by_2(value):
        return value * 2

    # Multiply by 3
    def multiply_by_3(value):
        return value * 3

    # Multiply by 5
    def multiply_by_5(value):
        return value * 5

    # Calculate result of multiplication
    def calculate(value):
        return multiply_by_2(value) + multiply_by_3(value) + multiply_by_5(value)

    # Create 5 tasks

# Generated at 2022-06-24 00:33:44.436058
# Unit test for constructor of class Task
def test_Task():
    """
    test_Task is unit test for checking
    that Task works correct.
    """

    # create new Task for testing forking
    fork = "fork"
    task = Task(fork)

    # check Task
    assert task.fork == fork


# Generated at 2022-06-24 00:33:53.424121
# Unit test for method map of class Task
def test_Task_map():

    # Function to map
    def add_one(x):
        return x + 1

    # Task of 1
    task_one = Task.of(1)

    # Task of 2
    task_two = task_one.map(add_one)

    # Task of 3
    task_three = task_two.map(add_one)

    # Test result
    assert task_one.fork(lambda _: False, lambda x: x) == 1
    assert task_two.fork(lambda _: False, lambda x: x) == 2
    assert task_three.fork(lambda _: False, lambda x: x) == 3


# Generated at 2022-06-24 00:34:03.369808
# Unit test for method bind of class Task
def test_Task_bind():
    def plus(num):
        return Task.of(num + 1)

    plus_one_Task = Task.of(1).bind(plus).bind(plus).bind(plus)

    def minus(num):
        return Task.of(num - 1)

    minus_one_Task = Task.of(1).bind(minus)

    def minus_or_plus(num):
        if num > 0:
            return plus(num)
        else:
            return minus(num)

    minus_or_plus_Task = Task.of(1).bind(minus_or_plus).bind(minus_or_plus).bind(minus_or_plus)

    assert plus_one_Task.fork(
        lambda fail: fail,
        lambda success: success
    ) == 3 + 1


# Generated at 2022-06-24 00:34:14.193441
# Unit test for method bind of class Task
def test_Task_bind():
    def add1(arg):
        return arg + 1

    def add2(arg):
        return Task.of(arg + 2)

    def throw(arg):
        return Task.reject(arg + 3)

    assert Task.of(1).bind(add1).fork(lambda _: None, lambda arg: arg) == 2
    assert Task.of(1).bind(add1).bind(add1).fork(lambda _: None, lambda arg: arg) == 3
    assert Task.of(1).bind(add2).bind(add2).fork(lambda _: None, lambda arg: arg) == 5
    assert Task.of(1).bind(add1).bind(throw).fork(lambda arg: arg, lambda _: None) == 4


# Generated at 2022-06-24 00:34:19.758758
# Unit test for method bind of class Task
def test_Task_bind():
    def mock_fork(reject, resolve):
        resolve('original')

    def mock_map(value):
        return value + ' mapped'

    def mock_bind(value):
        return Task.of(value + ' bound')

    task = Task(mock_fork)

    assert task.map(mock_map).bind(mock_bind).fork(None, lambda arg: arg) == 'original mapped bound'



# Generated at 2022-06-24 00:34:29.068434
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        pass

    def reject(value):
        pass

    def resolve(value):
        pass

    assert Task(fork).bind(Task.of).fork is fork, \
        "Task(fork).bind(Task.of).fork is not equal fork"

    assert Task(fork).bind(lambda value: Task.reject(value)).fork(reject, resolve) == fork(reject, resolve), \
        "Task(fork).bind(lambda value: Task.reject(value)).fork(reject, resolve) is not equal fork(reject, resolve)"



# Generated at 2022-06-24 00:34:29.882830
# Unit test for constructor of class Task
def test_Task():
    pass


# Generated at 2022-06-24 00:34:31.169201
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return None

    obj = Task(fork)
    assert obj.fork == fork


# Generated at 2022-06-24 00:34:32.349457
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve(1)
    task = Task(fork)
    assert fork == task.fork


# Generated at 2022-06-24 00:34:34.840378
# Unit test for method map of class Task
def test_Task_map():
    def square(value):
        return value ** 2

    assert Task.of(2).map(square).fork(None, lambda a: a) == 4
    assert Task.reject(2).map(square).fork(lambda a: a, None) == 2


# Generated at 2022-06-24 00:34:41.635730
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task#map(fn)

    test.assert_equals(Task.of(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x),
                       2)
    test.assert_equals(Task.reject(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x),
                       1)
    """
    import sys
    sys.path.append('..')
    import test_suit
    test_suit.Task_map(Task)


# Generated at 2022-06-24 00:34:45.198495
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    mapped_task = task.map(lambda value: value * 3)
    assert mapped_task.fork(
        lambda _: None,
        lambda value: value == 6
    )


# Generated at 2022-06-24 00:34:48.330652
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    assert task.bind(lambda x: Task.of(x + 1)).fork(
        lambda _: False,
        lambda x: x == 2
    ) == True


# Generated at 2022-06-24 00:34:58.611794
# Unit test for method map of class Task
def test_Task_map():
    """
    This test for map function for Task
    """

    # Task.map(value -> value + 1) create new Task and call fork with resolve
    # test_reject and test_resolve
    task = Task.of(0)
    task_map_result = task.map(lambda value: value + 1)
    test_reject = []
    test_resolve = []

    def test_reject_resolve(reject, resolve):
        """
        This function will be called during
        task_map_result.fork(reject, resolve)
        """
        test_resolve.append(resolve)
        test_reject.append(reject)


# Generated at 2022-06-24 00:35:00.684645
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(5)).fork(lambda x: x, lambda x: x + 5) == 10


# Generated at 2022-06-24 00:35:07.150986
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Assert Task.bind method with calculation of two numbers.
    """
    def add(x):
        return x + 1

    def add_two(x, y):
        return Task.of(x + y)

    assert Task.of(1).bind(
        lambda first: Task.of(2).bind(
            lambda second: add_two(
                first,
                second
            )
        )
    ).fork(
        lambda _: 0,
        lambda x: x
    ) == 4

    # equal

# Generated at 2022-06-24 00:35:12.676423
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor
    """
    task = Task(lambda _, resolve: resolve(42))

    assert task.fork is not None

# Generated at 2022-06-24 00:35:19.851895
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    """
    def double(val):
        return val * 2

    def triple(val):
        return val * 3

    def fn(value):
        return Task.of(value).map(double).map(triple)

    task = Task.of(4).bind(fn)
    value = task.fork(lambda x: x, lambda x: x)

    try:
        assert value == 24
    except AssertionError:
        raise AssertionError("method bind should return Task with mapped value")

    try:
        assert Task.of(4).bind(Task.reject).fork(lambda x: x, lambda x: x) == 4
    except AssertionError:
        raise AssertionError("method bind should return rejected Task")


# Generated at 2022-06-24 00:35:25.408930
# Unit test for method bind of class Task
def test_Task_bind():
    # define two functions for testing
    def fn(value):
        return Task.of(value + 1)

    def fn2(value):
        return Task.of(value + 2)

    task = Task.of(2).map(fn).map(fn2)

    assert task.fork(lambda x: x, lambda x: x) == 5

test_Task_bind()

# Generated at 2022-06-24 00:35:34.469588
# Unit test for method bind of class Task
def test_Task_bind():
    def task1(resolve, reject):
        import random
        import time
        time.sleep(0.3)
        resolve('task1')

    def task2(resolve, reject):
        import random
        import time
        time.sleep(0.4)
        reject('task2')

    def task3(resolve, reject):
        import random
        import time
        time.sleep(0.3)
        resolve('task3')

    def test1(resolve, reject):
        import random
        import time
        time.sleep(0.4)
        resolve('task4')

    def test2(resolve, reject):
        import random
        import time
        time.sleep(0.3)
        reject('task5')

    def task4(_, resolve):
        import random
        import time
        time

# Generated at 2022-06-24 00:35:41.850052
# Unit test for constructor of class Task
def test_Task():
    def f(resolve, reject):
        resolve(3)

    assert Task(f).fork(lambda a: None, lambda a: a) == 3
    assert Task(f).fork(lambda a: a, lambda a: None) == None

    assert Task.of(3).fork(lambda a: None, lambda a: a) == 3
    assert Task.reject(3).fork(lambda a: a, lambda a: None) == 3


# Generated at 2022-06-24 00:35:45.232641
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve('ok')

    task = Task(fork)
    result = task.bind(lambda value: Task.of(value))
    assert result.fork(lambda x: 'error', lambda x: x) == 'ok'

# Generated at 2022-06-24 00:35:47.379168
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)
    assert Task.of(1).bind(add).fork(lambda err: None, lambda v: v) == 2


# Generated at 2022-06-24 00:35:50.615667
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)

    assert 1 == task.fork(lambda reject: None, lambda resolve: resolve)


# Generated at 2022-06-24 00:35:53.572406
# Unit test for constructor of class Task
def test_Task():
    def mock_fork(reject, resolve):
        raise AssertionError('Mock fork should not be called')

    test = Task(mock_fork)

    assert isinstance(test, Task)
    assert test.fork is mock_fork


# Generated at 2022-06-24 00:35:57.812558
# Unit test for constructor of class Task
def test_Task():
    """
    Task with fork attribute must be defined.
    """
    assert isinstance(Task(None).__str__(), str)
    assert Task(None).__str__() == "Task({'fork': <function Task.__init__.<locals>.<lambda> at 0x7fefd40a0e18>})"


# Generated at 2022-06-24 00:36:00.667402
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)

    assert isinstance(task, Task)
    assert task.fork(lambda v: v, lambda v: v) == 1


# Generated at 2022-06-24 00:36:07.415118
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for Task constructor
    """
    # Test for stored value in Task
    def test_value(resolve):
        """
        Check function for resolve attribute
        """
        resolve('value')

    # Create task
    task = Task(test_value)
    # Call fork and get value
    assert task.fork(None, lambda value: value) == 'value'


# Generated at 2022-06-24 00:36:15.583434
# Unit test for constructor of class Task
def test_Task():
    @pytest.mark.parametrize('arg', [2, 3.14, "abrakadabra", lambda x: x + 1])
    def test_of(arg):
        assert Task.of(arg).fork(None, None) == arg

    # ---------------------------

    @pytest.mark.parametrize('arg', [2, 3.14, "abrakadabra", lambda x: x + 1])
    def test_reject(arg):
        assert Task.reject(arg).fork(None, None) == arg

    # ---------------------------


# Generated at 2022-06-24 00:36:21.342838
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(2)
    t = Task(fork)
    assert isinstance(t, Task)


# Generated at 2022-06-24 00:36:26.290580
# Unit test for method map of class Task
def test_Task_map():
    x = Task.of(1).map(lambda value: value + 1)
    assert x.fork(None, lambda result: result) == 2



# Generated at 2022-06-24 00:36:29.743100
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of('test')
    task_map = task.map(lambda value: value + '_mapped')
    task_map.fork(lambda e: e, lambda r: r)
    assert 'test_mapped'


# Generated at 2022-06-24 00:36:38.991797
# Unit test for method map of class Task
def test_Task_map():
    def assert_task(task, value):
        def rej():
            raise RuntimeError("Must be rejected Task")

        def res(task_value):
            assert task_value == value
        assert_task = Task(lambda rej, res: res(task.fork(rej, res)))

    task = Task.of(12)
    assert_task(task, 12)

    task = task.map(lambda x: x * 2)
    assert_task(task, 24)

    task = task.map(lambda x: str(x))
    assert_task(task, "24")

    task = task.map(lambda x: int(x) * 3)
    assert_task(task, 72)


# Generated at 2022-06-24 00:36:43.223335
# Unit test for method bind of class Task
def test_Task_bind():
    def take(value):
        def result(reject, resolve):
            return resolve(value)

        return Task(result)

    value = Task.of(1) \
        .bind(take) \
        .bind(lambda value: take(value + 2)) \
        .fork(lambda err: err, lambda value: value)

    assert value == 3, 'Bind method of Task class should make Task with resolved value 3, but get {}'.format(value)


# Generated at 2022-06-24 00:36:46.383070
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(2).fork(None, lambda arg: arg) == 2
    assert Task.reject(None).fork(lambda arg: arg, lambda arg: arg) is None


# Generated at 2022-06-24 00:36:50.475556
# Unit test for constructor of class Task
def test_Task():
    def double_and_send_to_resolve(a, b):
        a(1)
        b(2)

    task = Task(double_and_send_to_resolve)

    assert task.fork(lambda a: a, lambda b: b) == 2


# Generated at 2022-06-24 00:36:52.448689
# Unit test for method map of class Task
def test_Task_map():
    t = Task.of(100)
    assert t.map(lambda x: x * 2).fork(identity, identity) == 200



# Generated at 2022-06-24 00:36:53.952399
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(1))
    assert task.fork is not None



# Generated at 2022-06-24 00:36:56.385025
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda _, resolve: resolve(3))
    new_task = task.map(lambda arg: arg + 1)

    assert new_task.fork(
        lambda _: 'Failed',
        lambda arg: arg
    ) == 4


# Generated at 2022-06-24 00:37:06.876954
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task map. This function test map with different input and expected result.

    :raises: AssertionError
    """
    resolve_value = 10
    reject_value = 10

    def add2(value):
        return value + 2

    def mult2(value):
        return value * 2

    def add(value):
        return value + 1

    def concat(value):
        return b'11' + value

    def reject_function(value):
        return Task.reject(value + 2)

    def return_function(value):
        return Task.of(value + 2)

    # Test map with resolve task
    nok_task = Task(lambda reject, resolve: resolve(resolve_value))
    mapped_task = nok_task.map(add)

# Generated at 2022-06-24 00:37:13.006846
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a, b):
        return a + b

    def raise_error(a, b):
        raise TypeError('Cannot add not position number')

    result = Task.of(1).bind(lambda a: Task.of(2).map(partial(add, a)))
    assert isinstance(result, Task)
    assert result.fork(lambda reject: reject, lambda resolve: resolve) == 3

    result = Task.of(1).bind(lambda a: Task.of('2').map(partial(raise_error, a)))
    assert isinstance(result, Task)
    assert result.fork(lambda reject: reject, lambda resolve: resolve) == TypeError('Cannot add not position number')



# Generated at 2022-06-24 00:37:22.063631
# Unit test for method bind of class Task
def test_Task_bind():
    # Task result value
    expected_result = 1313 # <-- choose magic number you want.

    # First task: call reject with magic number.
    task = Task.of('test').map(lambda _: Task.of(expected_result))

    # Second task: call reject with magic number.
    task = task.bind(lambda _: Task.of(expected_result))

    # Third task: call resolve with magic number.
    task = task.bind(lambda _: Task.of(expected_result))

    # Final task: call resolve with magic number with custom Task.
    task = task.bind(
        lambda _: Task.of(expected_result)
    )


# Generated at 2022-06-24 00:37:24.340082
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    result = task.bind(lambda value: Task.of(value + 1))
    assert result.fork(lambda value: value, lambda value: value) == 2



# Generated at 2022-06-24 00:37:28.416861
# Unit test for method map of class Task

# Generated at 2022-06-24 00:37:30.483536
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve('test')

    task = Task(fork)
    assert task.fork is fork


# Generated at 2022-06-24 00:37:34.987918
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task.
    """
    def identity(arg):
        return arg

    def mul_by_two(arg):
        return arg * 2

    task_ = Task(identity)
    assert task_.fork(identity, identity) == identity
    assert task_.map(mul_by_two).fork(identity, mul_by_two) == 4


# Generated at 2022-06-24 00:37:37.544276
# Unit test for method bind of class Task
def test_Task_bind():
    def task_reject(value):
        return Task.reject(value)

    def task_map(value):
        return Task.of(value).map(lambda x: x + 4)

    assert Ta

# Generated at 2022-06-24 00:37:43.561806
# Unit test for method map of class Task

# Generated at 2022-06-24 00:37:47.709801
# Unit test for method map of class Task
def test_Task_map():
    """
    Test functionality map method of class Task
    """

    def function(a):
        return a + 1

    assert function(2) == Task.of(2).map(function).fork(lambda _, __: None, identity)


# Generated at 2022-06-24 00:37:54.242087
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method map of class Task.
    """

    error_message = 'Task throw error'

    def get_value(value):
        """
        Fake function to mapper_task
        """
        return value + (1, )

    def get_value_raise():
        """
        Fake function to raise error
        """
        raise ValueError(error_message)

    def get_value_reject(value):
        """
        Fake function to reject_task
        """
        return Task.reject(value + (1, ))

    def get_value_raise_reject():
        """
        Fake function to raise error in reject_task
        """
        raise ValueError(error_message)

    def get_value_resolve(value):
        """
        Fake function to resolve_task
        """
        return

# Generated at 2022-06-24 00:38:03.113772
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    path = os.path.join(os.path.dirname(__file__), './../test/test_files/')
    expected_content = 'test content'

    def test_fork(reject, resolve):
        try:
            with open(path) as file:
                content = file.readlines()[0]
                resolve(content)
        except IOError:
            reject(IOError('File does not exist'))

    test_task = Task(test_fork)
    actual_content = test_task.fork(
        lambda arg: arg,
        lambda content: content
    )
    assert actual_content == expected_content


# Generated at 2022-06-24 00:38:10.083072
# Unit test for method bind of class Task
def test_Task_bind():
    def m1(i):
        print("  m1: %d" % i)
        return Task.of(i * 2)

    def m2(i):
        print("  m2: %d" % i)
        return Task.of(i + 5)

    def m3(i):
        print("  m3: %d" % i)
        return Task.of(i ** 2)

    def m4(i):
        print("  m4: %d" % i)
        return Task.of(i / 2)

    task = Task.of(7)
    result = task.bind(m1).bind(m2).bind(m3).bind(m4)

# Generated at 2022-06-24 00:38:13.128327
# Unit test for method map of class Task
def test_Task_map():
    def test_function(x):
        return x * 2

    assert Task.of(1).map(test_function).fork(lambda x: None, lambda x: x) == 2



# Generated at 2022-06-24 00:38:20.927030
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(10)

    task = Task(fork)

# Generated at 2022-06-24 00:38:29.710362
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test case for Task with bind method
    """

    def add_one(value):
        """
        Add one to value and return new Task with added value.

        :param value: value to add one
        :type value: int
        :returns: new Task with added value
        :rtype: Task(int)
        """
        return Task.of(value + 1)

    def add_two(value):
        """
        Add two to value and return new Task with added value.

        :param value: value to add two
        :type value: int
        :returns: new Task with added value
        :rtype: Task(int)
        """
        return Task.of(value + 2)

    task = Task.of(0)
    task.bind(add_one).bind(add_two)


# Generated at 2022-06-24 00:38:33.086585
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Expected: result is Task with value of 1.
    """
    def plus_one(num):
        return Task.of(num + 1)

    task = Task.of(1)
    task_bound = task.bind(plus_one)
    assert task_bound.fork(lambda _: None, lambda value: value) == 1

# Generated at 2022-06-24 00:38:36.437961
# Unit test for method bind of class Task
def test_Task_bind():
    bound_task = Task.of(1).bind(
        lambda a: Task.of(a + 1)
    )

    assert bound_task.fork(
        lambda _: False,
        lambda a: a == 2
    )


# Generated at 2022-06-24 00:38:40.683477
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(mapper).fork(lambda _: None, lambda x: x) == 2


if __name__ == "__main__":
    test_Task_bind()

# Generated at 2022-06-24 00:38:43.704973
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x+1).fork(print, print) == 2
    assert Task.of(1).map(lambda x: x+1).fork(print, print) == 2


# Generated at 2022-06-24 00:38:53.338990
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    def reject_mapper(value):
        return Task.reject(value)

    task = Task.of(2).map(mapper)
    assert task.fork(lambda value: value, lambda value: value)() == 3

    task = Task.reject(2).map(mapper)
    assert task.fork(lambda value: value, lambda value: value)() == 2

    task = Task.of(2).map(reject_mapper)
    assert task.fork(lambda value: value, lambda value: value)() == 2


# Generated at 2022-06-24 00:38:58.630581
# Unit test for method bind of class Task
def test_Task_bind():
    """
        Test case:
        1. create Task.reject(1)
        2. bind Task.of(2) to this Task
        3. call fork of binded Task
        4. check that resolve was called
        5. check that stored value of resolve call is 2
    """
    def success(value: int):
        assert value == 2
        print("Success")

    def failure(value: int):
        assert False, "Failure was called"

    Task.reject(1).bind(Task.of).fork(failure, success)

# Generated at 2022-06-24 00:39:04.750361
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve): return reject(None)
    assert Task(fork).fork(lambda _: True, lambda _: False)

    assert Task.of(1).fork(lambda _: False, lambda value: value == 1)
    assert Task.reject(1).fork(lambda value: value == 1, lambda _: False)


# Generated at 2022-06-24 00:39:09.646275
# Unit test for method map of class Task
def test_Task_map():
    def get_3(resolve, reject):
        resolve(3)
        return "Get 3"

    # task = Task.of(3)
    # assert task.fork(
    #     reject="Get 3",
    #     resolve=lambda arg: arg
    # ) == 3

    task = Task(get_3)

    assert task.map(lambda arg: arg * 0) == Task.of(0)
    assert task.map(lambda arg: arg + 1) == Task.of(4)
    assert task.map(lambda arg: arg - 1) == Task.of(2)


# Generated at 2022-06-24 00:39:20.723191
# Unit test for method bind of class Task
def test_Task_bind():
    def value_to_reject(value):
        return Task.reject(value)
    def value_to_resolve(value):
        return Task.of(value)
    def mapped_task(value):
        return Task.of(value)
    def empty_task():
        return Task.reject(None)

    assert Task(lambda reject, resolve: resolve(10)).bind(value_to_resolve).fork(
        lambda value: value == 0,
        lambda value: value == 10
    )
    assert Task(lambda reject, resolve: resolve(10)).bind(value_to_reject).fork(
        lambda value: value == 10,
        lambda value: value == 0
    )

# Generated at 2022-06-24 00:39:23.291552
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(6).map(lambda x: x * 7)
    assert result.fork(lambda x: x, lambda x: x) == 42



# Generated at 2022-06-24 00:39:28.769853
# Unit test for method map of class Task
def test_Task_map():
    # Arrange
    t_map = Task.of(1).map(lambda x: x + 1)

    # Act
    value = t_map.fork(lambda x: x, lambda x: x)

    # Assert
    assert value == 2


# Generated at 2022-06-24 00:39:35.378279
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test implementation of method bind of class Task.
    """
    assert Task(lambda _, resolve: resolve(2)).bind(lambda x: Task.of(x ** 2)).fork(None, None) == 4
    assert Task(lambda _, resolve: resolve(3)).bind(lambda x: Task.of(x ** 2)).fork(None, None) == 9
    assert Task(lambda _, resolve: resolve(4)).bind(lambda x: Task.of(x ** 2)).fork(None, None) == 16

# Generated at 2022-06-24 00:39:43.669367
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test case to handle everything seem to work with method bind
    """
    t = Task.of("foo").bind(
        lambda v: Task.reject("bar")
    )
    assert t.fork(lambda e: e, lambda v: v) == "bar"

    t = Task.reject("foo").bind(
        lambda v: Task.reject("baz")
    )
    assert t.fork(lambda e: e, lambda v: v) == "foo"

    t = Task.of("foo").bind(
        lambda v: Task.of("baz")
    )
    assert t.fork(lambda e: e, lambda v: v) == "baz"



# Generated at 2022-06-24 00:39:47.604570
# Unit test for method map of class Task
def test_Task_map():
    """
    >>> Task.of(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x)
    2
    >>> Task.reject(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x)
    1
    """

    pass


# Generated at 2022-06-24 00:39:57.189834
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test that result of fork method is result of call
    reject and resolve functions of first Task.
    """
    def fork_mock(reject, resolve):
        reject('reject')
        resolve('resolve')

    task = Task(fork_mock)
    task_mock = Task(
        lambda reject, resolve:
            reject('reject_mock') or
            resolve('resolve_mock')
    )
    task_bound = task.bind(lambda _: task_mock)

    assert task_bound.fork('reject_result', 'resolve_result') == \
           'reject_result'
    assert task.fork('reject_result', 'resolve_result') == 'reject'


# Generated at 2022-06-24 00:39:59.979577
# Unit test for constructor of class Task
def test_Task():
    mock_fork = mocker.Mock()
    task = Task(mock_fork)

    assert task.fork == mock_fork



# Generated at 2022-06-24 00:40:03.332517
# Unit test for method map of class Task
def test_Task_map():
    # Test if function return value of function for resolve value passed as argument
    task = Task.of(4)
    task2 = task.map(lambda x: x + 1)  # type: Task[int]
    assert task2.fork(lambda _: 0, lambda x: x == 5) is True
    # Test if function return value of function for reject value passed as argument
    task = Task.reject(4)
    task2 = task.map(lambda x: x + 1)  # type: Task[int]
    assert task2.fork(lambda x: x == 4, lambda _: 0) is True



# Generated at 2022-06-24 00:40:08.608623
# Unit test for constructor of class Task
def test_Task():
    class Spy:
        def __init__(self):
            self.call_count = 0

        def __call__(self, *args, **kwargs):
            self.call_count = self.call_count + 1

    spy = Spy()

    def fork(reject, resolve):
        reject('error')
        resolve('value')
        spy()

    task = Task(fork)

    task.fork(lambda error: None, lambda value: None)
    assert spy.call_count == 1


# Generated at 2022-06-24 00:40:10.407309
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    assert task.map(lambda arg: arg * arg).fork(identity, identity) == 4


# Generated at 2022-06-24 00:40:15.100453
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    def add_one(value):
        return value + 1

    assert Task.of(5).map(add_one).fork(lambda _: False, lambda value: value == 6)


# Generated at 2022-06-24 00:40:23.085035
# Unit test for constructor of class Task
def test_Task():
    def noop(_, resolve):
        pass

    def noop_reject(reject, _):
        reject(Exception())

    noop_task = Task(noop)
    noop_reject_task = Task(noop_reject)

    assert noop_reject_task.fork(lambda: True, lambda: False)
    assert not noop_task.fork(lambda: True, lambda: False)

    assert isinstance(noop_reject_task.fork(lambda x: x, lambda x: x), Exception)
    assert noop_task.fork(lambda x: x, lambda x: x) is None

# Unit-test for method of

# Generated at 2022-06-24 00:40:27.747306
# Unit test for constructor of class Task
def test_Task():
    """
    >>> test_Task()
    1
    """
    fork = lambda _, resolve: resolve(1)
    task = Task(fork)
    assert task.fork(lambda _: None, lambda _: None) == 1


# Generated at 2022-06-24 00:40:37.995788
# Unit test for method map of class Task
def test_Task_map():
    def succ(arg):
        return arg + 1

    def err(arg):
        return arg + 10

    def fork(_, resolve):
        return resolve(1)

    value = Task(fork)

    assert value.map(succ).map(succ).map(succ).fork(err, succ) == 4
    assert value.map(succ).map(succ).map(succ).map(succ).map(succ).map(succ).fork(err, succ) == 7
    assert value.map(succ).map(succ).map(succ).map(succ).map(succ).map(succ).map(succ).map(succ).map(succ).fork(err, succ) == 10

# Generated at 2022-06-24 00:40:41.381901
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(2).bind(lambda value:Task.of(value * 3)) == \
           Task(lambda _, resolve: resolve(6))



# Generated at 2022-06-24 00:40:47.353683
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_called(called_list):
        def fn(arg):
            called_list.append(arg)
            return Task.of(arg)
        return fn

    called_list = []

    task = Task.of(1)
    task_bind = task.bind(fn_called(called_list))

    task_bind.fork(lambda err: None, lambda arg: None)

    assert called_list == [1]


# Generated at 2022-06-24 00:40:55.826922
# Unit test for method bind of class Task
def test_Task_bind():
    def echo(value):
        """Return Task with resolved attribute"""
        return Task(lambda _, resolve: resolve(value))

    def throw_error(value):
        """Return Task with rejected attribute"""
        return Task(lambda reject, _: reject(value))

    def throw_error_later(value):
        """Return Task with rejected attribute"""
        return Task(lambda reject, resolve: setTimeout(lambda: reject(value), 50))

    def throw_error_with_then(value):
        """
        Return Task with rejected attribute and call .then() with
        passed arguments
        """
        def result(reject, resolve):
            return reject(value).then(
                lambda resolved: resolve(resolved),
                lambda rejected: reject(rejected)
            )
  
        return Task(result)


# Generated at 2022-06-24 00:41:04.163756
# Unit test for method map of class Task
def test_Task_map():
    def add(a):
        return a + a

    def call(resolve, reject):
        return resolve(10)

    assert Task(call).map(add)().get_result() == 20

    def call(resolve, reject):
        return resolve(10)

    assert Task(call).map(lambda _: Task.of(20))().get_result() == 20

    def call(resolve, reject):
        return resolve(10)

    assert Task(call).map(lambda _: Task.of(20)).map(add)() == 20



# Generated at 2022-06-24 00:41:06.343279
# Unit test for constructor of class Task
def test_Task():
    """
    Test case for Task class.

    >>> test_Task()
    Task
    """
    print('Task')


# Generated at 2022-06-24 00:41:10.002205
# Unit test for method map of class Task
def test_Task_map():
    assert_equal(
        Task.of(1).map(lambda x: x + 1),
        Task.of(2)
    )

    assert_equal(
        Task.reject(1).map(lambda x: x + 1),
        Task.reject(1)
    )


# Generated at 2022-06-24 00:41:16.390314
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of Task class
    """
    def add_five(number):
        return number + 5

    five = Task.of(5)

    assert isinstance(five.map(add_five), Task)
    assert five.map(add_five).fork(lambda _: "", lambda arg: arg) == 10


# Generated at 2022-06-24 00:41:27.595142
# Unit test for method bind of class Task
def test_Task_bind():
    def get_task_1():
        return Task.of(1)

    def get_task_2():
        return Task.reject(2)

    def get_task_3():
        return Task.of(3)

    def run_tests():
        return (
            Task.of(get_task_1)
                .bind(lambda task: task)
                .fork(
                    lambda arg: print('Fail: {}'.format(arg)),
                    lambda arg: print('Success: {}'.format(arg))
                )
        )


# Generated at 2022-06-24 00:41:30.199152
# Unit test for method map of class Task
def test_Task_map():
    """
    Simple test for map method of Task class.
    """
    assert Task(lambda _, resolve: resolve(1)) \
        .map(lambda x: x + 1) \
        .fork(lambda: 0, lambda x: x) == 2


# Generated at 2022-06-24 00:41:31.745571
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task(lambda _, __: None), Task)

# Unit tests for of method

# Generated at 2022-06-24 00:41:34.861288
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    assert Task(lambda _, resolve: resolve('value')).fork(None, lambda: 'value') == 'value'
