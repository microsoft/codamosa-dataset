

# Generated at 2022-06-24 00:31:39.594680
# Unit test for constructor of class Task
def test_Task():
    """
    test Task creation
    """

    class Counter:
        """
        Counter is helper class for store number of times.
        """

        def __init__(self):
            self.value = 0

        def __call__(self, *args, **kwargs):
            return self.value

    counter = Counter()
    def fork(reject, resolve):
        counter.value += 1
        resolve(counter.value)

    assert Task(fork).fork(lambda _: None, lambda _: None) == 1


# Generated at 2022-06-24 00:31:45.145118
# Unit test for method bind of class Task
def test_Task_bind():
    def f1(value):
        return Task.of(value + 1)

    def f2(value):
        return Task.of(value * 2)

    def f3(value):
        return Task.of(str(value))

    assert Task.of(1) \
        .bind(f1) \
        .bind(f2) \
        .bind(f3) \
        .fork(None, lambda value: value == "4")

    def f1(value):
        return Task.of(value + 1)

    def f2(value):
        return Task.reject(value)

    def f3(value):
        return Task.of(str(value))


# Generated at 2022-06-24 00:31:48.913649
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve(4)

    t = Task(fork)

    def add_two(value):
        return value + 2

    assert t.map(add_two).fork(throw_err, lambda x: x) == 6


# Generated at 2022-06-24 00:31:51.206741
# Unit test for method bind of class Task
def test_Task_bind():
    identity = lambda x: Task.of(x)
    task = Task.of(1).bind(identity).fork(lambda x: None, lambda x: x)
    assert task == 1


# Generated at 2022-06-24 00:31:56.892761
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 10

    def resolve(value):
        print(f'I am resolve: {value}')

    def reject(value):
        print(f'I am reject: {value}')

    task = Task(lambda reject, resolve: resolve(10))

    result = task.map(add)
    result.fork(reject, resolve)

    assert result.fork == task.fork

# Generated at 2022-06-24 00:32:01.572939
# Unit test for method map of class Task

# Generated at 2022-06-24 00:32:09.167909
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Given a Task I want call bind to this Task and get new Task with resolved value mapped by function
    """
    def add(first, second):
        """
        add two value

        :param first: first value
        :type first: Int
        :param second: second value
        :type second: Int
        :returns: first + second
        :rtype: Int
        """
        return first + second

    def double(value):
        """
        Double value

        :param value: value to double
        :type value: Int
        :returns: doubled value
        :rtype: Int
        """
        return value * 2


# Generated at 2022-06-24 00:32:12.618662
# Unit test for method bind of class Task
def test_Task_bind():
    result = fork(Task.of(5).bind(lambda arg: Task.of(arg + 1)))

    assert result == 6


# Generated at 2022-06-24 00:32:17.506880
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(42))
    assert task.fork is not None


# Generated at 2022-06-24 00:32:22.001335
# Unit test for constructor of class Task
def test_Task():
    assert Task(
        lambda _, resolve: resolve(4)
    ).fork(
        lambda _: 4,
        lambda a: a
    ) == 4

    assert Task(
        lambda reject, _: reject(4)
    ).fork(
        lambda a: a,
        lambda _: 4
    ) == 4



# Generated at 2022-06-24 00:32:24.365797
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(lambda _: False, lambda val: val == 1)


# Generated at 2022-06-24 00:32:31.516948
# Unit test for method map of class Task
def test_Task_map():
    # define mapper and value for stored in Task
    mapper = lambda value: value + 1
    task_value = 2

    # create resolved Task with stored value in argument
    task = Task.of(task_value)

    # define expected result
    expected = mapper(task_value)

    # assert method map return new Task with mapped resolve attribute
    assert task.map(mapper).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == expected



# Generated at 2022-06-24 00:32:41.073940
# Unit test for method map of class Task
def test_Task_map():
    def test_positive(assert_):
        # Create new Task with value: 2
        task2 = Task.of(2)
        # Call map with function `x -> x*x` function
        task4 = task2.map(lambda x: x*x)

        # Test that task4 is not None
        assert_(task4 is not None, "Task was not created")

        # Test that result of task4 is 4
        assert_(
            task4.fork(
                lambda _: None,
                lambda arg: arg
            ) == 4,
            "Result of Task is not 4"
        )

    def test_negative(assert_):
        # Create new Task with value: 2
        task2 = Task.of(2)
        # Call map with function `x -> x*x` function

# Generated at 2022-06-24 00:32:47.079123
# Unit test for method bind of class Task
def test_Task_bind():
    def double(n):
        return n + n

    def inc(n):
        return n + 1

    def bind(value):
        return Task.of(value + 100)

    def resolve(value):
        print(value)

    def reject(err):
        print(err)

    expected = 103

    Task.of(1).bind(bind).map(inc).map(double).fork(reject, resolve)

    assert expected



# Generated at 2022-06-24 00:32:56.683186
# Unit test for method map of class Task
def test_Task_map():
    def f(arg):
        return arg + arg

    def f2(arg):
        return arg + arg + arg

    def t(arg):
        return Task.of(f(arg))

    def t2(arg):
        return Task.of(f2(arg))

    assert Task.of(10).map(f).fork(None, lambda arg: arg) == 20
    assert Task.of(None).map(f).fork(None, lambda arg: arg) == None
    assert Task.of(10).map(t).fork(None, lambda arg: arg.fork(None, lambda arg: arg)) == 20
    assert Task.of(10).map(t).map(t2).fork(None, lambda arg: arg.fork(None, lambda arg: arg)) == 60

# Generated at 2022-06-24 00:33:04.939870
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return reject(1)

    def fork2(reject, resolve):
        return resolve(1)

    def bind_with(value):
        def bind_fork(reject, resolve):
            resolve(value)
        return Task(bind_fork)

    task = Task(fork)
    assert isinstance(task.bind(bind_with), Task)

    task2 = Task(fork2)
    assert task2.bind(bind_with).fork(lambda x: None, lambda x: x) == 1

# Generated at 2022-06-24 00:33:12.821215
# Unit test for method bind of class Task
def test_Task_bind():
    def test_async_call(callback, amount, value):
        def task(reject, resolve):
            if amount > 1:
                task(None, resolve).fork(reject, resolve)
            else:
                callback(resolve(value))

        return Task(task)

    def task_callback(value):
        assert value == 42

    test_async_call(task_callback, 4, 42)


# Generated at 2022-06-24 00:33:19.938854
# Unit test for method map of class Task
def test_Task_map():
    def test_function(reject, resolve):
        resolve(3)

    task = Task(test_function)
    mapped_task = task.map(lambda x: x * 2)
    assert mapped_task.fork(lambda x: None, lambda x: x) == 6


# Generated at 2022-06-24 00:33:24.397244
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(2)

    task = Task(fork)

    assert task.fork(
        lambda _: None,
        lambda value: assert_equals(value, 2)
    )

    def fork(reject, resolve):
        reject("error")

    task = Task(fork)

    task.fork(
        lambda value: assert_equals(value, "error"),
        lambda _: None
    )


# Generated at 2022-06-24 00:33:29.302937
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    task_two = task.bind(lambda value: Task.of(value + 1))
    assert task_two.fork(lambda x: None, lambda value: value) == 2

    task_reject = Task.reject(1)
    another_task_reject = task_reject.bind(lambda value: Task.of(value + 1))
    assert task_reject.fork(lambda value: value, lambda _: None) == 1
    assert another_task_reject.fork(lambda value: value, lambda _: None) == 1


# Generated at 2022-06-24 00:33:37.478237
# Unit test for method bind of class Task
def test_Task_bind():
    """

    """
    class TestObj:
        def __init__(self, value):
            self.value = value

        def test_method(self, other_value):
            return TestObj(self.value + other_value)

    test_value = 123
    test_obj = TestObj(test_value)

    result = Task.of(test_obj)\
                 .bind(lambda value: value.test_method(test_value))\
                 .fork(
                    lambda error: False,
                    lambda value: value.value == test_value + test_value
    )

    assert result is True


# Generated at 2022-06-24 00:33:38.298886
# Unit test for constructor of class Task
def test_Task():
    pass


# Generated at 2022-06-24 00:33:39.707907
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map method.
    """
    arg = Task.of(2)
    arg = arg.map(lambda x: x ** 2)
    assert arg.fork(lambda x: x, lambda x: x) == 4

# Generated at 2022-06-24 00:33:45.003538
# Unit test for method map of class Task
def test_Task_map():
    def fn(argument):
        return argument * 2

    assert Task.of(10).map(fn).fork(lambda _: None, lambda value: value) == 20
    assert Task.reject(10).map(fn).fork(lambda value: value, lambda _: None) == 10


# Generated at 2022-06-24 00:33:54.678780
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        return Task.of(x + 1)

    def g(x):
        return Task.reject(x)

    task_2 = Task.of(2).bind(f).bind(f)

# Generated at 2022-06-24 00:34:00.069415
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value): return value + '_map'
    def mapper2(value): return value + '_map2'

    Task(lambda _, resolve: resolve('value')) \
        .bind(lambda value: Task(lambda _, resolve: resolve(mapper(value)))) \
        .map(lambda value: mapper2(value)) \
        .fork(lambda arg: None, lambda arg: print(arg))

test_Task_bind()

# Generated at 2022-06-24 00:34:06.300648
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    """
    value = 0

    def add_task_builder(result):
        """
        Builder for resolved task for adding.
        """
        return Task.of(value + result)

    def throw_task_builder(result):
        """
        Builder for rejected task for adding with error.
        """
        return Task.reject(None)

    def throw_task_catcher(error):
        """
        Handler of error in Task.
        """
        nonlocal value
        value = 6
        return Task.of(value)

    # task = Task.of(42).bind(add_task_builder).bind(throw_task_builder)

# Generated at 2022-06-24 00:34:10.153139
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(lambda _: None, lambda value: value) == 1
    assert Task(lambda reject, _: reject("Error")).fork(lambda value: value, lambda _: None) == "Error"


# Generated at 2022-06-24 00:34:15.100482
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject('reject')

    task = Task(fork)
    assert task.fork
    assert task.fork(lambda arg: None, lambda arg: None) == fork(lambda arg: None, lambda arg: None)


# Generated at 2022-06-24 00:34:23.581042
# Unit test for method map of class Task
def test_Task_map():
    """
    :returns: success unit testing
    :rtype: bool
    """
    def fn(arg):
        return arg * 2

    def fork_reject(arg):
        return arg

    def fork_resolve(arg):
        return arg

    def fork(reject, resolve):
        return reject("reject")

    my_taske = Task(fork)
    my_taske = my_taske.map(fn)

    assert my_taske.fork(fork_reject, fork_resolve) == "reject"

    return True



# Generated at 2022-06-24 00:34:26.978363
# Unit test for method bind of class Task
def test_Task_bind():
    def check(fn, result):
        assert Task.of(fn).bind(lambda fn: fn(2)).fork(None, lambda arg: arg) == result

    check(lambda a: a + 2, 4)
    check(lambda a: a + 3, 5)
    check(lambda a: a + 1, 3)



# Generated at 2022-06-24 00:34:34.401333
# Unit test for method bind of class Task
def test_Task_bind():
    def sum(a, b):
        return Task.of(a + b)

    def sum2(a, b):
        return Task.of(a + 2 * b)

    task = Task.of(1)
    task = task.bind(lambda a: Task.of(a * 2))
    task = task.bind(lambda a: Task.of(a * 3))

    assert task.fork(None, lambda a: a) == 12
    assert 1 == Task.of(1).bind(lambda _: Task.reject("error in bind")).fork("error in bind", lambda _: 1)

    task = Task.of(1)
    task = task.bind(lambda a: sum(a, 1))
    task = task.bind(lambda b: sum2(b, 2))

# Generated at 2022-06-24 00:34:37.756574
# Unit test for method bind of class Task
def test_Task_bind():
    async def _():
        def fork(reject, resolve):
            return resolve(1)

        def bind(value):
            return Task.of(value + 1)

        task = Task(fork).bind(bind)

        assert 2 == await task.exec()


# Generated at 2022-06-24 00:34:42.301722
# Unit test for constructor of class Task
def test_Task():
    def _(reject, resolve):
        '''[Task] -> True'''
        return reject(True)

    assert Task(None) is not None
    assert type(Task(None)) is Task
    assert Task(_) is not None
    assert type(Task(_)) is Task



# Generated at 2022-06-24 00:34:45.866597
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x * 2

    task = Task.of(2).map(fn)

    def test_fork(reject, resolve):
        return resolve(fn(2))

    assert task.fork == test_fork


# Generated at 2022-06-24 00:34:48.338212
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject('reject')
        resolve('resolve')

    task = Task(fork)

    assert task.fork is fork


# Generated at 2022-06-24 00:34:51.664049
# Unit test for method map of class Task
def test_Task_map():
    @Task.of
    def my_task():
        return 10

    @my_task.map
    def mapper(arg):
        return arg + 1

    assert mapper.fork(lambda _: None, lambda arg: arg) == 11


# Generated at 2022-06-24 00:34:56.619179
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value * 2)

    assert Task.of(1).bind(mapper).fork(None, lambda value: value) == 2


# Generated at 2022-06-24 00:35:01.040401
# Unit test for method bind of class Task
def test_Task_bind():
    task1 = Task.of(1)
    task2 = Task.of(3)
    task3 = Task.of(5)
    task4 = Task.of(7)

    result = task1.bind(lambda x: task2)
    assert result.fork(lambda x: x, lambda x: x) == 3

    result = task2.bind(lambda x: task3.bind(lambda y: task4))
    assert result.fork(lambda x: x, lambda x: x) == 7


# Generated at 2022-06-24 00:35:04.377417
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """
    def test_map(x):
        return x ** 2

    def fn(reject, resolve):
        resolve(10)

    task = Task(fn)
    new_task = task.map(test_map)
    assert new_task.fork(None, lambda a: None) == 100


# Generated at 2022-06-24 00:35:13.696391
# Unit test for constructor of class Task
def test_Task():
    """
    Test: constructor of class Task
    """
    # Make setup
    t_reject_value = 'reject'
    t_reject = lambda reject, resolve: reject(t_reject_value)
    t_resolve_value = 'resolve'
    t_resolve = lambda reject, resolve: resolve(t_resolve_value)

    # Testing
    task = Task(t_reject)
    assert task.fork(lambda arg: arg, None) == t_reject_value
    assert task.fork(None, lambda arg: arg) is not t_reject_value

    task = Task(t_resolve)
    assert task.fork(None, lambda arg: arg) == t_resolve_value
    assert task.fork(lambda arg: arg, None) is not t_resolve_value


# Generated at 2022-06-24 00:35:21.099526
# Unit test for constructor of class Task
def test_Task():
    @check.isinstance(Task)
    def of_class():
        return Task.of(True)

    @check.isinstance(Task)
    def reject_class():
        return Task.reject(True)

    @check.isinstance(Function)
    def fork():
        return Task.of(True).fork

    @check.equals(True)
    def fork_of():
        return Task.of(True).fork(lambda _: False, lambda arg: arg)

    @check.equals(True)
    def fork_reject():
        return Task.reject(True).fork(lambda arg: arg, lambda _: False)

    return CheckSuite.run([
        of_class(),
        reject_class(),
        fork(),
        fork_of(),
        fork_reject(),
    ])

#

# Generated at 2022-06-24 00:35:27.455522
# Unit test for method bind of class Task
def test_Task_bind():
    counter = []
    task = Task.of(10)

    def callback_if_resolved_counter(value):
        counter.append(value)

    def callback_if_rejected_counter(value):
        counter.append(value)

    task.fork(callback_if_rejected_counter, callback_if_if_resolved_counter)

    def callback(value):
        return Task.of(value + 1)

    task.bind(callback).fork(callback_if_rejected_counter, callback_if_resolved_counter)
    assert counter == [10, 11]


# Generated at 2022-06-24 00:35:32.804589
# Unit test for constructor of class Task
def test_Task():
    # If fork is not callable, raise TypeError.
    with raises(TypeError):
        Task(object())

    # If fork is callable, return Task instance with stored callable.
    assert Task(lambda _, _1: None).fork



# Generated at 2022-06-24 00:35:40.124808
# Unit test for constructor of class Task
def test_Task():
    res = False

    def result(_, resolve):
        resolve(True)

    task = Task(result)
    assert isinstance(task, Task)
    assert isinstance(task.fork, types.FunctionType)

    task.fork(lambda _: 0, lambda val: res.__setitem__(0, val))
    assert res

test_Task()


# Generated at 2022-06-24 00:35:44.695500
# Unit test for constructor of class Task
def test_Task():
    fork = lambda _, resolve: resolve('value')

    result = Task(fork)

    assert isinstance(result, Task), \
        'Task must be instance of Task'
    assert result.fork is fork, \
        'Fork of result must be reference to argument fork'


# Generated at 2022-06-24 00:35:53.930248
# Unit test for constructor of class Task
def test_Task():
    # Create simple resolved and rejected task
    resolvedTask = Task.of(1)
    rejectedTask = Task.reject('error')

    # Create mapper function
    def inc(arg):
        return arg + 1

    # Create task with mapped function for resolved task
    mappedTask = resolvedTask.map(inc)

    # Create task with rejected attribute
    rejectedTask1 = rejectedTask.map(inc)

    # Create task with binded function
    bindedTask = resolvedTask.bind(
        lambda value: Task.of('value: ' + str(value))).map(str.lower)

    # Create chain of binded task

# Generated at 2022-06-24 00:35:59.909231
# Unit test for method bind of class Task
def test_Task_bind():
    actual_resolve_value = None
    actual_reject_value = None

    def resolve(value):
        nonlocal actual_resolve_value
        actual_resolve_value = value

    def reject(value):
        nonlocal actual_reject_value
        actual_reject_value = value

    def fork(reject, resolve):
        resolve(4)

    task = Task(fork)
    task.bind(lambda value: Task.of(value * 2)).fork(reject, resolve)
    assert actual_resolve_value == 8
    assert actual_reject_value == None

# Generated at 2022-06-24 00:36:01.183633
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(0)) == Task.of(0)



# Generated at 2022-06-24 00:36:07.977913
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of('test').map(lambda x: x).fork(None, lambda x: x) == 'test'
    assert Task.of('test').map(lambda x: 'mappedTest').fork(None, lambda x: x) == 'mappedTest'
    assert Task.of('test').map(lambda x: 'mappedTest').fork(lambda x: x, None) == 'test'


# Generated at 2022-06-24 00:36:18.809085
# Unit test for method map of class Task
def test_Task_map():
    def task_of(value):
        return Task.of(value)
    def add(value):
        return value + 10
    def multiply(value):
        return value * 5
    def task_reject(value):
        return Task.reject(value)

    assert Task.of(1).map(add).map(multiply).fork(lambda x: x, lambda x: x) == 55
    assert Task.of(1).map(lambda x: task_of(x + 10)).map(lambda x: x + 10).fork(lambda x: x, lambda x: x) == 22
    assert Task.reject(1).map(lambda x: x + 10).fork(lambda x: x, lambda x: x) == 1

# Generated at 2022-06-24 00:36:22.322742
# Unit test for constructor of class Task
def test_Task():
    @Task
    def fn(reject, resolve):
        resolve(1)

    assert fn.fork(lambda reject: reject(True), lambda resolve: resolve(True)) == 1



# Generated at 2022-06-24 00:36:25.141643
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(42)

    assert Task(fork).bind(lambda x: Task.of(str(x))).fork(lambda _: False, lambda x: x == '42')


# Generated at 2022-06-24 00:36:34.922539
# Unit test for constructor of class Task
def test_Task():
    from functools import partial

    def test_reject(error):
        task1 = Task.reject(error)
        task2 = Task(lambda reject, _: reject(error))

        assert task1.fork(lambda e: e, None) == error
        assert task2.fork(lambda e: e, None) == error

    def test_of(value):
        task1 = Task.of(value)
        task2 = Task(partial(lambda _, resolve: resolve(value), None))

        assert task1.fork(None, lambda v: v) == value
        assert task2.fork(None, lambda v: v) == value

    test_of("ok")
    test_reject("error")


# Generated at 2022-06-24 00:36:43.035605
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of Task class.
    """
    def test_of(fn, arg, result):
        """
        Test map method of Task class with argument resolver
        (see :meth:`test_Task_map_resolver`).

        :param fn: function to test
        :type fn: Function(value) -> B
        :param arg: first argument of function
        :type arg: A
        :param result: expected result of function
        :type result: B
        """
        assert Task.of(arg).map(fn).fork(lambda x: x, lambda x: x) == result


# Generated at 2022-06-24 00:36:53.238416
# Unit test for method map of class Task
def test_Task_map():
    test_Task_map_track = []

    def add(x):
        test_Task_map_track.append('add')
        return x + 1

    def square(x):
        test_Task_map_track.append('square')
        return x ** 2

    def test_Task_map_reject(arg):
        test_Task_map_track.append('test_Task_map_reject')

    def test_Task_map_resolve(arg):
        test_Task_map_track.append('resolve')

    task = Task.of(2).map(add).map(square)
    assert isinstance(task, Task)

    task.fork(test_Task_map_reject, test_Task_map_resolve)

# Generated at 2022-06-24 00:36:54.080022
# Unit test for constructor of class Task
def test_Task():
    assert Task is not None


# Generated at 2022-06-24 00:36:55.473552
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(5)

    task = Task(fork)

    assert tas

# Generated at 2022-06-24 00:37:03.743067
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    def fork_reject(reject, resolve):
        reject('Test error')

    assert Task(fork).fork(reject, resolve) == resolve(1)
    assert Task(fork_reject).fork(reject, _) == reject('Test error')
    assert Task.of(1).fork(reject, resolve) == resolve(1)
    assert Task.reject('Test error').fork(reject, _) == reject('Test error')


# Generated at 2022-06-24 00:37:09.520696
# Unit test for method map of class Task
def test_Task_map():
    """
    Case 1: method map of Task class
    """
    def add1(value):
        """
        Take and add 1 to value.

        :param value: value to add 1
        :type value: A
        :returns: value + 1
        :rtype: A
        """
        return value + 1

    value = 5
    result = Task.of(value).map(add1).fork(
        lambda item: item + 2,
        lambda item: item - 1
    )

    assert result == value + add1(value) - 1


# Generated at 2022-06-24 00:37:13.660835
# Unit test for method map of class Task
def test_Task_map():
    """
    Test function for Task.map method.
    """
    def mapper(value):
        if value == 2:
            raise Exception('error')
        return value * 2

    def fork(reject, resolve):
        resolve(5)

    task = Task(fork)
    result = task.map(mapper)
    assert result.fork(lambda arg: arg, lambda arg: arg) == 10

    try:
        result.fork(lambda arg: arg, lambda arg: arg)
    except Exception:
        assert True



# Generated at 2022-06-24 00:37:18.747488
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map(fn).
    """
    first_function = lambda resolve: resolve(1)
    second_function = lambda reject: reject(2)

    increment = lambda arg: arg + 1
    double = lambda arg: arg * 2

    # Check with function which resolves value
    assert Task(first_function).map(increment).fork(lambda reject: reject, lambda resolve: resolve) == 2
    assert Task(first_function).map(double).fork(lambda reject: reject, lambda resolve: resolve) == 2

    # Check with function which rejects value
    assert Task(second_function).map(increment).fork(lambda reject: reject, lambda resolve: resolve) == 2
    assert Task(second_function).map(double).fork(lambda reject: reject, lambda resolve: resolve) == 2


# Generated at 2022-06-24 00:37:28.179455
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return x + 1

    def sub(x):
        return x - 1

    add_1 = Task.of(1)
    add_2 = Task.of(2)

    def add3(arg1, arg2):
        return Task.of(arg1 + arg2)

    def sub3(arg1, arg2):
        return Task.of(arg1 - arg2)

    result = (add_1
              .bind(add)
              .bind(sub)
              .bind(sub)
              .bind(sub)
              .bind(sub)
              .bind(sub)
              .bind(add))

    assert result.fork(lambda _: False, lambda value: value) == 0


# Generated at 2022-06-24 00:37:33.685957
# Unit test for constructor of class Task
def test_Task():
    assert (Task.of(5).fork(5, 5) == None)
    assert (Task.reject(5).fork(5, 5) == None)
    assert (Task(lambda _, resolve: resolve(5)).map(lambda x: x + 1).fork(5, 5) == None)
    assert (Task(lambda _, resolve: resolve(5)).bind(lambda x: Task.of(x + 1)).fork(5, 5) == None)

test_Task()

# Generated at 2022-06-24 00:37:35.146387
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda resolve, reject: resolve('foo'))
    assert task.fork is not None


# Generated at 2022-06-24 00:37:37.229451
# Unit test for constructor of class Task
def test_Task():
    # resolve
    assert Task.of(1).fork(lambda arg: arg, lambda arg: arg) == 1

    # reject
    assert Task.reject(1).fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-24 00:37:42.736333
# Unit test for method bind of class Task
def test_Task_bind():
    # Unit test: task.bind(lambda value: task)
    assert Task.reject(2).bind(lambda value: Task.reject(3)).fork(identity, lambda a: False) == 2

    # Unit test: task.bind(lambda value: task)
    assert Task.reject(2).bind(lambda value: Task.of(3)).fork(identity, lambda a: False) == 2

    # Unit test: task.bind(lambda value: task)
    assert Task.of(2).bind(lambda value: Task.reject(3)).fork(identity, lambda a: False) == 3

    # Unit test: task.bind(lambda value: task)
    assert Task.of(2).bind(lambda value: Task.of(3)).fork(lambda a: False, identity) == 3

    # Unit test: task.bind

# Generated at 2022-06-24 00:37:47.619717
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(20)
    task = task.map(lambda value: value + 3)
    result = task.fork(
        lambda reject: reject,
        lambda resolve: resolve
    )

    assert result == 23



# Generated at 2022-06-24 00:37:49.729608
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(lambda x: None, lambda x: x) == 2


# Generated at 2022-06-24 00:37:54.378607
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('rejected')

    task = Task(fork)
    reject, resolve = task.fork

    assert reject('rejected') == 'rejected'
    assert resolve('resolved') == 'resolved'


# Generated at 2022-06-24 00:37:59.602160
# Unit test for method bind of class Task
def test_Task_bind():
    arg = Task(lambda _, resolve: resolve(1))
    fn = lambda x: Task(lambda _, resolve: resolve(x + 1))
    assert arg.bind(fn).fork(lambda x: None, lambda y: y) == 2



# Generated at 2022-06-24 00:38:01.415564
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject(12)
        resolve(12)

    task = Task(fork)
    assert task.fork is fork


# Generated at 2022-06-24 00:38:02.890530
# Unit test for constructor of class Task
def test_Task():
    dummy_function = lambda x: x
    task = Task(dummy_function)
    assert task.fork == dummy_function


# Generated at 2022-06-24 00:38:04.814856
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve('asd')

    task = Task(fork)
    assert task.fork(
        lambda reject: reject('error'),
        lambda resolve: resolve('value')
    ) == 'value'


# Generated at 2022-06-24 00:38:10.791266
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for correct work of map method for class Task.
    """
    value = 10
    test_function = Task.of(value).map(lambda arg: arg + 1)

    def reject(_):
        raise ValueError('reject must be not called')

    def resolve(arg):
        assert arg == value + 1

    test_function.fork(reject, resolve)


# Generated at 2022-06-24 00:38:18.221242
# Unit test for constructor of class Task
def test_Task():
    # Successful case
    assert Task(lambda _, resolve: resolve(1)).fork(lambda arg: arg, lambda arg: arg) == 1

    # Raise TypeError with two arguments
    try:
        Task(lambda _, _: None)
    except TypeError:
        pass
    else:
        assert False

    # Raise TypeError with no arguments
    try:
        Task(lambda: None)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-24 00:38:20.688735
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(2))
    assert task.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-24 00:38:25.382669
# Unit test for method map of class Task
def test_Task_map():
    def Fork(resolve, reject):
        return reject("error")

    Task = Task(Fork)

    def Mapper(value):
        return value + " mapper"

    task = Task.map(Mapper)

    assert task.fork(
        lambda arg: arg,
        lambda arg: "fail"
    ) == "error"


# Generated at 2022-06-24 00:38:28.834058
# Unit test for constructor of class Task
def test_Task():
    func1 = lambda reject, resolve: resolve(1)
    func2 = lambda reject, resolve: resolve(2)
    assert Task(func1) != Task(func2)
    assert Task(func1) == Task(func1)


# Generated at 2022-06-24 00:38:31.640845
# Unit test for method map of class Task
def test_Task_map():
    expected_result = 10
    result = Task.of(expected_result).fork(
        lambda value: None,
        lambda value: value
    )
    assert result == expected_result


# Generated at 2022-06-24 00:38:35.405166
# Unit test for method map of class Task
def test_Task_map():
    @Task
    def task_number(reject, resolve):
        time.sleep(1)
        return resolve(42)

    assert task_number.fork(None, None) == 42

    def double(value):
        return value * 2

    assert task_number.map(double).fork(None, None) == 84


# Generated at 2022-06-24 00:38:39.315370
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value * value)

    actual = Task.of(5)\
        .bind(fn)\
        .fork(lambda arg: arg, lambda arg: arg)

    assert actual == 25


# Generated at 2022-06-24 00:38:41.282888
# Unit test for method map of class Task
def test_Task_map():
    def resolve(x):
        assert x == 2
        return x

    def reject(x):
        assert False

    mockFn = lambda x: x + 1
    Task.of(1).map(mockFn).fork(reject, resolve)


# Generated at 2022-06-24 00:38:46.291941
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(0);
        return True

    def mapper(value):
        def mapper_fork(reject, resolve):
            resolve(value + 1)
            return True
        return Task(mapper_fork)

    task = Task(fork)

    assert task.bind(mapper).fork(lambda _: False, lambda arg: arg)


# Generated at 2022-06-24 00:38:57.361023
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a, b):
        return a + b

    def add_one(a):
        return Task.of(add(a, 1))

    def add_two(a):
        return Task.of(add(a, 2))

    def add_task(a):
        return add_one(a)

    task = Task.of(1)
    assert task.bind(add_one).bind(add_two).bind(add_task).fork(lambda a: a, lambda a: a) == 5

    # Use connect
    task = Task.of(1)
    assert task.bind(add_one.bind(add_two).bind(add_task)).fork(lambda a: a, lambda a: a) == 5
    # -> add_one(1) = Task(2)
    # -> add_two(2

# Generated at 2022-06-24 00:39:03.075087
# Unit test for constructor of class Task
def test_Task():
    task1 = Task(lambda _, resolve: resolve(5))
    task2 = Task.of(5)
    assert task1.fork(lambda err: 'error', lambda value: value) == 5
    assert task2.fork(lambda err: 'error', lambda value: value) == 5


# Generated at 2022-06-24 00:39:05.422418
# Unit test for method map of class Task
def test_Task_map():
    value = Task.of(2).map(lambda arg: arg ** 2)
    assert value.fork(lambda arg: arg, lambda arg: arg) == 4


# Generated at 2022-06-24 00:39:09.951768
# Unit test for method map of class Task
def test_Task_map():
    def stub_reject(value):
        pass

    def stub_resolve(value):
        pass

    def result(reject, resolve):
        resolve(3)

    def mapper(value):
        return value + 2

    task = Task(result)
    mapped = task.map(mapper)
    assert mapped.fork(stub_reject, stub_resolve) == 5


# Generated at 2022-06-24 00:39:15.040630
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    task_with_one = Task.of(1)

    assert task_with_one.map(add_one).fork(lambda x: x, lambda x: x) == 2
    

# Generated at 2022-06-24 00:39:17.028095
# Unit test for constructor of class Task
def test_Task():
    @Task
    def fork(reject, resolve):
        resolve("foo")

    @fork
    def handle(value):
        return "bar"

    assert handle() == "bar"


# Generated at 2022-06-24 00:39:19.777262
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(2)).fork(lambda _: _, lambda _: _) == 2
    assert Task(lambda _, resolve: resolve(4)).fork(lambda _: _, lambda _: _) == 4


# Generated at 2022-06-24 00:39:25.864969
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.reject(0) \
               .bind(lambda arg: Task.of(arg + 1)) \
               .fork(lambda value: value,
                     lambda value: value) == 0

    assert Task.of(0) \
               .bind(lambda arg: Task.of(arg + 1)) \
               .fork(lambda value: value,
                     lambda value: value) == 1


# Generated at 2022-06-24 00:39:31.889948
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(payload):
        def resolve_fn(value):
            assert value == payload + payload
            print('Success bind')

        def reject_fn(value):
            assert False
            print('Can not reject in this context')

        return Task.reject(payload).bind(lambda value: Task.of(value + value)).fork(reject_fn, resolve_fn)

    test_fn('object')


# Generated at 2022-06-24 00:39:34.066381
# Unit test for method map of class Task
def test_Task_map():
    def foo(x):
        return x * 2

    assert Task.of(2).map(foo).fork(None, lambda x: x) == 4


# Generated at 2022-06-24 00:39:39.178390
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(2)) \
        .map(lambda value: value + 1) \
        .fork(lambda _: None, lambda resolve_value: resolve_value == 3)


# Generated at 2022-06-24 00:39:41.149126
# Unit test for constructor of class Task
def test_Task():
    task_of = Task.of(10)

# Generated at 2022-06-24 00:39:45.511896
# Unit test for method bind of class Task
def test_Task_bind():
    t1 = Task(Forkable.of(1))
    t2 = Task.of(2)

    assert t1.bind(lambda _: t2).fork(reject, resolve) == 2
    assert t1.map(lambda _: 2).fork(reject, resolve) == 2

# Generated at 2022-06-24 00:39:52.407114
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(arg):
        a.append(arg)

    def reject(arg):
        b.append(arg)

    a = []
    b = []

    t = Task.of(2)
    t = t.bind(lambda arg: Task.reject(arg ** 2))
    t = t.map(lambda arg: arg ** 2)
    t.fork(reject, resolve)

    assert (a == []) and (b == [4])



# Generated at 2022-06-24 00:40:00.188364
# Unit test for method map of class Task
def test_Task_map():
    def add1(x):
        return x + 1
    def add2(x):
        return x + 2
    def error(x):
        return x

    assert Task.of(1).map(add1).fork(error, add1).fork(error, add2) == 4
    assert Task.of(1).map(add1).fork(error, add2).fork(error, add1) == 4


# Generated at 2022-06-24 00:40:04.282227
# Unit test for method map of class Task
def test_Task_map():
    # Test resolve
    task = Task.of(1).map(lambda x: x * 3)
    assert task.fork(None, lambda x: x) == 3

    # Test reject
    task = Task.reject(1).map(lambda x: x * 3)
    assert task.fork(lambda x: x, None) == 1


# Generated at 2022-06-24 00:40:06.390474
# Unit test for constructor of class Task
def test_Task():
    def fn(reject, resolve):
        assert reject is None
        assert resolve is None

    instance = Task(fn)
    assert instance.fork is fn



# Generated at 2022-06-24 00:40:15.237640
# Unit test for method bind of class Task
def test_Task_bind():
    def map_fn(value):
        return value + 1

    def fork_task(reject, resolve):
        return reject(5)

    def fork_resolving_mapper(reject, resolve):
        return resolve(map_fn(5))

    def fork_rejecting_mapper(reject, resolve):
        return reject(map_fn(5))

    fork_task = Task(fork_task)
    fork_resolving_mapper = Task(fork_resolving_mapper)
    fork_rejecting_mapper = Task(fork_rejecting_mapper)

    assert Task.of(5).bind(map_fn).fork(lambda value: value, lambda _: 'do not called') == 6

# Generated at 2022-06-24 00:40:21.041375
# Unit test for constructor of class Task
def test_Task():
    add_one = lambda x: x + 1
    assert Task.of(1).fork(lambda x: x, lambda x: x) == 2
    assert Task.reject(1).fork(lambda x: x, lambda x: x) == 1
    assert Task.of(1).map(add_one).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-24 00:40:27.949666
# Unit test for method bind of class Task
def test_Task_bind():
    def fork_factory(mapper, value):
        return lambda reject, resolve: mapper(value)

    def case_bind_map(assert_equal, value, mapper):
        task = Task(fork_factory(mapper, value))
        assert_equal(task.bind(lambda value: Task.of(value)).fork(lambda _: None, lambda value: value), value)

    assert_exception = lambda assert_equal, value, _: assert_equal(assert_exception.exception, value)
    assert_exception.exception = None

    def exception_setter(exception):
        assert_exception.exception = exception

    def case_bind_reject(assert_equal, value, mapper):
        task = Task(fork_factory(mapper, value))

# Generated at 2022-06-24 00:40:31.126169
# Unit test for method bind of class Task

# Generated at 2022-06-24 00:40:37.696970
# Unit test for method map of class Task
def test_Task_map():
    # Test of function Task.of
    assert Task.of(10).fork(lambda error: None, lambda value: value) == 10

    # Test of function Task.reject
    assert Task.reject(10).fork(lambda error: error, lambda value: None) == 10

    # Test of method map of class Task
    def test_function_map_of(value):
        return value ** 2

    assert Task.of(10).map(test_function_map_of).fork(lambda error: None, lambda value: value) == 100



# Generated at 2022-06-24 00:40:43.476545
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind(fn): Take function, store it and call with Task value during calling fork function.
    Return result of called.
    """
    def add_argument(arg):
        return Task.of(arg + 1)

    def multiply_by_2(arg):
        return Task.of(arg * 2)

    assert Task.of(2).bind(add_argument).bind(multiply_by_2).fork(
        lambda error: None,
        lambda result: result
    ) == 6



# Generated at 2022-06-24 00:40:47.749988
# Unit test for constructor of class Task
def test_Task():
    expected = 'Hello'
    task = Task(lambda _, resolve: resolve(expected))
    assert task.fork(lambda _: None, lambda result: result) == expected



# Generated at 2022-06-24 00:40:51.145653
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(fn):
        def callback(value):
            fn(value)

        return Task(callback)

    assert Task.of(10).bind(fork) == Task.of(10)

# Generated at 2022-06-24 00:40:53.465459
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(10)
    def plus(x):
        return x + 10

    assert(task.map(plus).fork(None, lambda x: x) == 20)


# Generated at 2022-06-24 00:41:00.303498
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return str(value)

    initial_value = 10
    task = Task.of(initial_value)
    task.map(fn)

    result = task.fork(
        lambda arg: None,
        lambda arg: arg
    )

    assert result == fn(initial_value)


# Generated at 2022-06-24 00:41:01.661025
# Unit test for constructor of class Task
def test_Task():
    t = Task(lambda _, resolve: resolve(1))

    if t.fork(lambda _: None, lambda x: x) != 1:
        raise AssertionError("Task creation constructor function test failed")


# Generated at 2022-06-24 00:41:10.859044
# Unit test for constructor of class Task
def test_Task():
    assert_false(hasattr(Task, 'of'))
    assert_false(hasattr(Task, 'reject'))
    assert_false(hasattr(Task, 'map'))
    assert_false(hasattr(Task, 'bind'))
    assert_false(hasattr(Task, 'fork'))

    Task = imp.import_module(
        '/home/vitaliy/Study/DesignPatterns/src/make_classes/Task.py')

    assert_true(hasattr(Task, 'of'))
    assert_true(hasattr(Task, 'reject'))
    assert_true(hasattr(Task, 'map'))
    assert_true(hasattr(Task, 'bind'))
    assert_false(hasattr(Task, 'fork'))


# Generated at 2022-06-24 00:41:16.348183
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return 'result'

    task = Task(fork)

    assert task.fork(lambda arg: arg, lambda arg: arg) == 'result'


# Generated at 2022-06-24 00:41:27.594514
# Unit test for constructor of class Task
def test_Task():
    """
    It will be tested class Task. It was not tested any internal methods (except constructor).

    Tests will be based on:
     - class constructor
     - class methods
      - of
      - reject

    """

    class SimpleTask(Task):
        def __init__(self, fork):
            Task.__init__(self, fork)

        def __repr__(self):
            return 'SimpleTask'

        def __eq__(self, other):
            return other.fold(
                lambda _: False,
                lambda _: True
            )

    # class constructor
    simple_task = SimpleTask(lambda _, __: True)
    assert simple_task.fork(lambda _: False, lambda _: True)

    # class methods
    # of

# Generated at 2022-06-24 00:41:38.466022
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve('foo')).fork(
        lambda _: 'bar',
        lambda _: 'baz'
    ) == 'baz'

    assert Task(lambda reject, _: reject('foo')).fork(
        lambda _: 'baz',
        lambda _: 'bar'
    ) == 'baz'

    assert Task(
        lambda _, resolve: resolve('foo')
    ).map(
        lambda _: 'bar'
    ).fork(
        lambda _: 'foo',
        lambda _: 'baz'
    ) == 'baz'
