

# Generated at 2022-06-24 00:31:38.064007
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(3)

    def assert_reject(arg):
        assert False

    def assert_resolve(arg):
        assert arg == 6

    task = Task(fork)
    task.bind(lambda x: Task.of(x * 2)).fork(assert_reject, assert_resolve)


# Generated at 2022-06-24 00:31:39.748605
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task(lambda _, resolve: resolve(x + 1))

    assert Task.of(1).bind(add).fork(lambda x: x, lambda x: x) == 2

# Generated at 2022-06-24 00:31:43.802375
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(value):
        return Task.of(value + 1)
    
    def result_wrong_value(reject, resolve):
        resolve(1)
        reject(2)
    
    def result_correct_value(reject, resolve):
        resolve(1)
    
    # example of resolved Task
    assert Task(result_correct_value).bind(test_fn).fork(lambda a: 'bad', lambda a: a) == 2

    # example of rejected Task
    assert Task(result_wrong_value).bind(test_fn).fork(lambda a: a, lambda a: 'bad') == 2


# Generated at 2022-06-24 00:31:48.331667
# Unit test for constructor of class Task
def test_Task():
    # Use: Task.of(2)
    t = Task(lambda reject, resolve: resolve(2))
    assert isinstance(t, Task)
    assert t.fork(lambda reject: None, lambda resolve: None) is None


# Generated at 2022-06-24 00:31:52.136525
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(3)

    def fork_2(reject, resolve):
        resolve(5)

    def mapper(value):
        return Task(fork_2)

    task = Task(fork)
    assert task.bind(mapper).fork(lambda _: 0, lambda x: x) == 5



# Generated at 2022-06-24 00:31:55.745685
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task map
    """
    new_task = Task.of(5).map(lambda arg: arg + 5)
    result = new_task.fork(lambda reject: None, lambda resolve: resolve)
    print(result)


# Generated at 2022-06-24 00:31:59.001269
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve("Fork")

    task = Task(fork)
    assert task.fork(lambda arg: arg, lambda arg: arg) == "Fork"



# Generated at 2022-06-24 00:32:02.347064
# Unit test for constructor of class Task
def test_Task():
    def func(reject, resolve):
        return resolve("Hello World")

    task = Task(func)
    assert task.fork is func, "Constructor should create new instance of Task"


# Generated at 2022-06-24 00:32:08.474964
# Unit test for method bind of class Task
def test_Task_bind():
    def test_Task(value):
        return Task(lambda _, resolve: resolve(value))

    task = Task.of(2)

    def increaser(value):
        return Task.of(value + 1)

    assert task.bind(increaser).fork(lambda _: 0, lambda arg: arg) == 3

    try:
        task.bind(lambda _: None).fork(lambda _: 1, lambda _: 0)
    except TypeError:
        pass
    else:
        assert False

    assert Task.reject(2).bind(increaser).fork(lambda arg: arg, lambda _: 0) == 2

test_Task_bind()



# Generated at 2022-06-24 00:32:14.183010
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    task = task.map(lambda x: x ** 2)


# Generated at 2022-06-24 00:32:19.401703
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(2).bind(lambda x: Task.of(x + 10)).fork(None, lambda x: x) == 12
    assert Task.of(None).bind(lambda x: Task.of(x + 10)).fork(lambda x: x, None) == None



# Generated at 2022-06-24 00:32:23.062547
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda val: val + 1)
    assert isinstance(task, Task)
    assert task.fork(
        lambda arg: None,
        lambda arg: arg
    ) == 2


# Generated at 2022-06-24 00:32:34.172587
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind(fn) -> Task[reject, mapped_value]
    """
    task = Task.of(5).bind(square).bind(square)
    assert task.fork(*function_stub) == 625

    task = Task.of(5).bind(square).bind(square).bind(square)
    assert task.fork(*function_stub) == 390625

    task = Task.of(5).bind(square).bind(Task.of)
    assert task.fork(*function_stub) == 25

    task = Task.reject('error').bind(square)
    assert task.fork(*function_stub) == 'error'

    task = Task.of(5).bind(square).bind(Task.reject)
    assert task.fork(*function_stub) == 'error'



# Generated at 2022-06-24 00:32:43.698253
# Unit test for method map of class Task
def test_Task_map():
    def add(x, y):
        return x+y

    def mul(x, y):
        return x*y

    def square(x):
        return x**2

    def task_add(reject, resolve):
        return resolve(add(3, 5))

    def task_mul(reject, resolve):
        return resolve(mul(3, 5))

    task1 = Task(task_add)
    assert task1.fork(None, lambda x: x) == 8
    assert task1.map(square).fork(None, lambda x: x) == 64

    task2 = Task(task_mul)
    assert task2.fork(None, lambda x: x) == 15
    assert task2.map(square).fork(None, lambda x: x) == 225



# Generated at 2022-06-24 00:32:54.316569
# Unit test for method bind of class Task
def test_Task_bind():
    def square(x):
        return Task.of(x ** 2)

    def half(x):
        return Task.of(x / 2)

    def f(x):
        return Task.of(x(0))

    assert Task.reject(1).bind(f) == Task.reject(1)
    assert Task.reject(1).bind(square) == Task.reject(1)
    assert Task.of(0).bind(f) == Task.of(f(0))
    assert Task.of(0).bind(square) == Task.of(square(0).fork(lambda x, _: x, lambda x, _: x))

# Generated at 2022-06-24 00:32:56.612680
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        pass

    assert isinstance(Task(fork), Task)


# Generated at 2022-06-24 00:33:07.406162
# Unit test for method map of class Task
def test_Task_map():
    def test_1(value):
        return Task.of(value + 1)

    def test_2(value):
        return Task.of(value + 2)

    def test_3(value):
        return Task.of(value + 3)

    def test_4(value):
        return Task.of(value + 4)

    def test_5(value):
        return Task.of(value + 5)

    def test_6(value):
        return Task.of(value + 6)

    def test_7(value):
        return Task.of(value + 7)

    t1 = Task.of(10).map(test_1).map(test_2).map(test_3)

# Generated at 2022-06-24 00:33:10.078679
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(5))

    assert task.fork(_, resolve) == 5


# Generated at 2022-06-24 00:33:16.950485
# Unit test for method bind of class Task

# Generated at 2022-06-24 00:33:21.856859
# Unit test for method bind of class Task
def test_Task_bind():
    def resolved(value):
        return Task.of(value)

    def mapped_rejected(value):
        return Task.reject(value)

    Task.of(1).bind(resolved)
    Task.of(1).bind(mapped_rejected)
    Task.reject(1).bind(resolved).bind(resolved)
    Task.reject(1).bind(mapped_rejected)


# Generated at 2022-06-24 00:33:25.015724
# Unit test for constructor of class Task
def test_Task():
    called = []
    t = Task(lambda reject, resolve: called.append(resolve))
    assert called == []

# Generated at 2022-06-24 00:33:28.932098
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task.
    """
    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2

    # left identity
    assert Task.of(1).map(lambda x: x).fork(None, lambda x: x) == 1

    # right identity
    assert Task.of(1).bind(lambda x: Task.of(x)).fork(None, lambda x: x) == 1


# Generated at 2022-06-24 00:33:35.470612
# Unit test for constructor of class Task
def test_Task():
    f_rejected = lambda _: None
    f_resolved = lambda _: None

    def fork(reject, resolve):
        f_resolved(resolve)
        f_rejected(reject)

    task = Task(fork)
    task.fork(f_rejected, f_resolved)

    assert f_rejected.call_count == 1
    assert f_resolved.call_count == 1


# Generated at 2022-06-24 00:33:44.764507
# Unit test for method bind of class Task
def test_Task_bind():
    def resolved_task(*args):
        return Task.of(*args)

    def rejected_task(*args):
        return Task.reject(*args)

    for task in map(resolved_task, range(0, 100)):
        assert task.bind(lambda x: Task.of(2*x)).fork(lambda *args: None, lambda *args: 2*x) == 200
        assert task.bind(lambda x: Task.reject(2*x)).fork(lambda *args: 2*x, lambda *args: None) == 200

    for task in map(rejected_task, range(0, 100)):
        assert task.bind(lambda x: Task.of(2*x)).fork(lambda *args: x, lambda *args: None) == x



# Generated at 2022-06-24 00:33:49.017702
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2
    assert Task.reject(1).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-24 00:33:53.524512
# Unit test for constructor of class Task
def test_Task():
    log = []
    task = Task(lambda reject, resolve: log.append(["fork called"]))
    task.fork(lambda value: log.append(["reject", value]),
              lambda value: log.append(["resolve", value]))
    assert log == [["fork called"]]


# Generated at 2022-06-24 00:34:03.516538
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case_1(name, fn, result):
        task = Task.of(10)

# Generated at 2022-06-24 00:34:10.646336
# Unit test for method map of class Task
def test_Task_map():
  def add_2(a):
    return a + 2

  def add_3(a):
    return a + 3

  task_add_2 = Task.of(2).map(add_2)
  assert task_add_2.fork(
    lambda err: None,
    lambda value: value
  ) == 4

  task_add_2_add_3 = Task.of(2).map(add_2).map(add_3)
  assert task_add_2_add_3.fork(
    lambda err: None,
    lambda value: value
  ) == 7

  task = Task.of(2).map(lambda a: a + 2)
  assert task.fork(
    lambda err: None,
    lambda value: value
  ) == 4


# Generated at 2022-06-24 00:34:15.310254
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(5).map(lambda x: x * 2) == Task.of(10)
    assert Task.reject(5).map(lambda x: x * 2) == Task.reject(5)


# Generated at 2022-06-24 00:34:19.862457
# Unit test for constructor of class Task
def test_Task():
    """
    Test check id constructor of class Task will raise ValueError if argument
    is not a function.
    """
    with pytest.raises(ValueError):
        Task(10)

# Generated at 2022-06-24 00:34:27.422161
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.reject(value)

    assert Task(lambda _, resolve: resolve(1)).bind(mapper).fork(
        lambda reject: True,
        lambda resolve: False
    )
    assert not Task(lambda _, resolve: resolve(1)).bind(mapper).fork(
        lambda reject: False,
        lambda resolve: True
    )


# Generated at 2022-06-24 00:34:28.551497
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(2) is not None
    assert Task.reject(2) is not None


# Generated at 2022-06-24 00:34:34.721613
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of Task class.
    """
    class FunctionMock:
        """
        Class used to check result of Task constructor.
        """
        def __init__(self):
            self.counter = 0
            self.reject = lambda _: None
            self.resolve = lambda _: None

        def __call__(self, reject, resolve):
            self.reject = reject
            self.resolve = resolve
            self.counter += 1

    mock = FunctionMock()
    task = Task(mock)

    assert task.fork == mock
    assert mock.reject != None
    assert mock.resolve != None
    assert mock.counter == 1


# Generated at 2022-06-24 00:34:42.395317
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind
    """
    # assert Task.of(1).bind(lambda arg: Task.of(arg + 1)).fork(lambda err: None, lambda result: assert result == 2)
    # assert Task.reject(Exception('Error')).bind(lambda arg: Task.of(arg + 1)).fork(lambda err: assert err.args == 'Error', lambda result: None)

# Generated at 2022-06-24 00:34:47.688862
# Unit test for method bind of class Task
def test_Task_bind():
    def reject(x):
        assert(x == 42)

    def resolve(x):
        assert(x == 42)

    def func(value):
        return Task.of(value)

    def func2(value):
        return Task.of(value ** 2)

    Task.of(42).bind(func).fork(reject, resolve)
    Task.of(42).bind(func2).fork(reject, resolve)


# Generated at 2022-06-24 00:34:50.739839
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 10)

    assert Task.of(5).bind(fn).fork(lambda err: None, lambda res: res) == 15



# Generated at 2022-06-24 00:34:55.839988
# Unit test for constructor of class Task
def test_Task():
    def test_of():
        task = Task.of('value')
        assert task.fork(None, lambda arg: arg) == 'value'

    def test_reject():
        task = Task.reject('error')
        assert task.fork(lambda arg: arg, None) == 'error'

    test_of()
    test_reject()


# Generated at 2022-06-24 00:34:57.248744
# Unit test for constructor of class Task
def test_Task():
    def func(reject, resolve):
        return reject(resolve(42))

    task = Task(func)
    assert task.fork == func


# Generated at 2022-06-24 00:35:01.241652
# Unit test for method bind of class Task
def test_Task_bind():
    def add_a(a):
        return Task.of(lambda b: a + b)

    def add_b(b):
        return Task.of(lambda a: (a, b))

    result = Task.of(1).bind(add_a).bind(add_b)

    def fork_result(reject, resolve):
        return resolve((1, 2))

    assert result.fork == fork_result


# Generated at 2022-06-24 00:35:09.347727
# Unit test for method map of class Task
def test_Task_map():
    """
    Test class Task method map
    """
    def mapper(value):
        """
        :param value: input value
        :type value: int
        :returns: mapped value
        :rtype: int
        """
        return value + 10

    def resolver(value):
        """
        :param value: input value
        :type value: int
        :returns: boolean value
        :rtype: bool
        """
        return value == 32

    task = Task.of(22).map(mapper)
    task.fork(lambda __: print('Error'), lambda result: print(resolver(result)))


# Generated at 2022-06-24 00:35:12.678682
# Unit test for constructor of class Task
def test_Task():
    value = 10
    task = Task.reject(value)
    assert task.fork(lambda arg: arg, lambda _: 0) == value

    task = Task.of(value)
    assert task.fork(lambda _, arg: arg, 0) == value



# Generated at 2022-06-24 00:35:17.262772
# Unit test for method map of class Task
def test_Task_map():
    # value is a resolve
    t = Task.of(2)
    # call map with lambda, that call with x and return x * x
    t1 = t.map(lambda x: x * x)
    # get result of map
    result = t1.get_value()
    # check result
    assert result == 4

    # value is a reject
    t2 = Task.reject(5)
    # call map with lambda, that call with x and return x * x
    t3 = t2.map(lambda x: x * x)
    # get result of map
    result = t3.get_value()
    # check result
    assert result == 5



# Generated at 2022-06-24 00:35:23.003839
# Unit test for method bind of class Task
def test_Task_bind():

    def fork(reject, resolve):
        resolve(2)

    task = Task(fork)
    task = task.bind(lambda a: Task.of(a + 10))

    assert task.fork(None, lambda a: a) == 12


# Generated at 2022-06-24 00:35:26.741980
# Unit test for constructor of class Task
def test_Task():
    res = ['a']
    reject = lambda _: res.append(_)
    resolve = lambda _: res.append(_)
    task = Task(lambda reject, resolve: resolve('Hello'))
    task.fork(reject, resolve)

    assert res == ['Hello'], 'result should be equal to Hello'


# Generated at 2022-06-24 00:35:32.976933
# Unit test for method map of class Task
def test_Task_map():
    def add(x, y):
        return x + y

    def mul(x, y):
        return x * y

    def div(x, y):
        return x / y

    def error(x):
        return 1 / 0

    # | simple Task with valid function
    assert Task.of(10).map(add).fork(None, lambda x: x) == 20

    # | Task with valid function and mapper
    assert Task.of((5, 3)).map(add).map(mul).fork(None, lambda x: x) == 50

    # | throw error in bind
    assert Task.of(10).map(error).fork(lambda x: x, None) == "Exception('division by zero')"



# Generated at 2022-06-24 00:35:37.330170
# Unit test for constructor of class Task
def test_Task():
    todo = Task(lambda reject, resolve: resolve(42))
    assert todo.fork(lambda value: None, lambda value: value) == 42


# Generated at 2022-06-24 00:35:44.729256
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task.

    :returns: result of tests
    :rtype: Bool
    """
    def add(x):
        return x + 1

    def multiply(x):
        return x * x

    def concat(x, y):
        return x + y

    def inc(x):
        return Task.of(x + 1)

    def pow(x):
        return Task.of(x * x)

    def sqr(x):
        return Task.of(x ** 2)

    def new_add(x):
        return Task.of(x + 2)

    def new_multiply(x):
        return Task.of(x * x)

    def new_concat(x, y):
        return Task.of(x + y + 1)


# Generated at 2022-06-24 00:35:48.492623
# Unit test for method bind of class Task
def test_Task_bind():

    def test_func(arg):
        return Task.of(arg + 1)


# Generated at 2022-06-24 00:35:54.128485
# Unit test for method bind of class Task
def test_Task_bind():
    Task.of(3) \
        .bind(lambda x: Task.of(x * 2)) \
        .bind(lambda x: Task.of(x % 3)) \
        .fork(print, print)

    Task.of(3) \
        .bind(lambda x: Task.of(x * 2)) \
        .bind(lambda x: Task.of(x % 3)) \
        .bind(lambda x: Task.reject(x // 3)) \
        .fork(print, print)


# Generated at 2022-06-24 00:35:56.683314
# Unit test for constructor of class Task

# Generated at 2022-06-24 00:35:59.208036
# Unit test for constructor of class Task
def test_Task():
    assert Task.of('test')
    assert Task.reject('test')
    assert Task.of(4)
    assert Task.reject(5)


# Generated at 2022-06-24 00:36:09.657368
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test case for method Task.bind
    """
    called = False
    first_fork_called = False
    second_fork_called = False

    def fork_fir(reject, resolve):
        """
        Function for first Task instance

        :param reject: function for reject task
        :type reject: Function(value)
        :param resolve: function for resolve task
        :type resolve: Function(value) -> A
        :returns:
        """
        nonlocal first_fork_called
        first_fork_called = True
        resolve(1)


# Generated at 2022-06-24 00:36:16.104417
# Unit test for method bind of class Task
def test_Task_bind():
    def bind_fn_error(resolve):
        resolve(Task.of(5))

    def bind_fn_success(resolve):
        resolve(Task.reject())

    assert Task.of(5).map(lambda x: x + 5).fork(lambda x: x, lambda x: x) == 10
    assert Task.reject(10).bind(bind_fn_error).fork(
        lambda x: x, lambda x: x
    ) == 5
    assert Task.reject(10).bind(bind_fn_success).fork(
        lambda x: x, lambda x: x
    ) == None

test_Task_bind()

# Generated at 2022-06-24 00:36:22.364765
# Unit test for method bind of class Task
def test_Task_bind():
    @Task.fork
    def fork(reject, resolve):
        resolve(None)

    assert fork(Task.of('a')) == 'a'

    assert fork(Task.reject(None)) == None


# Generated at 2022-06-24 00:36:24.163159
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(10).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 11


# Generated at 2022-06-24 00:36:26.319358
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(1))
    assert task.fork(lambda _: 1, lambda a: a) == 1


# Generated at 2022-06-24 00:36:30.202583
# Unit test for method map of class Task
def test_Task_map():
    value = 1
    changed_value = 2

    task = Task.of(value)
    new_task = task.map(lambda value: value + 1)

    def resolve(value):
        assert value == changed_value

    new_task.fork(None, resolve)



# Generated at 2022-06-24 00:36:33.626410
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject(2)

    task = Task(fork)

    assert task.fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-24 00:36:39.828200
# Unit test for method bind of class Task
def test_Task_bind():
    value = 5

    # create reject task
    rejectTask = Task(lambda reject, _: reject(value))
    # create resolved task for bind
    resolveTask = Task(lambda _, resolve: resolve(value))

    # task with same value of rejectTask in resolve attribute
    bindTaske = rejectTask.bind(lambda value: resolveTask)

    def fork(reject, resolve):
        assert False, 'fork should not be called'

    assert bindTaske.fork == fork



# Generated at 2022-06-24 00:36:50.341183
# Unit test for method bind of class Task
def test_Task_bind():
    with pytest.raises(TypeError) as e:
        Task.reject(1).bind(lambda x: int(x))
    assert e.value.args[0] == "Can't take function from Task.reject"

    with pytest.raises(TypeError) as e:
        Task.reject(1).bind(lambda x: Task.of(int(x)))
    assert e.value.args[0] == "Can't take function from Task.reject"

    assert Task.of(1).bind(Task.of).fork(lambda _: "error", lambda x: "ok") == 'ok'
    assert Task.of(1).bind(Task.reject).fork(lambda e: e, lambda _: "error") == 1


# Generated at 2022-06-24 00:36:52.663734
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1) \
        .bind(lambda v: Task.of(v + 1)) \
        .fork(print, print) == 2


# Generated at 2022-06-24 00:36:55.116817
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject(1)
        return resolve(2)
    task = Task(fork)
    assert hasattr(task, 'fork')
    assert task.fork is fork


# Generated at 2022-06-24 00:37:01.134086
# Unit test for method map of class Task

# Generated at 2022-06-24 00:37:09.240739
# Unit test for method bind of class Task
def test_Task_bind():
    def add1(x):
        return Task.of(x + 1)

    add1_after_add1 = Task.of(1).bind(add1).bind(add1)
    assert add1_after_add1.fork(lambda _: 'rejected', lambda x: x) == 3

    add1_after_add1 = Task.of(1).bind(add1).bind(add1).bind(lambda x: Task.reject('fuuuuuuu'))
    assert add1_after_add1.fork(lambda x: x, lambda x: 'resolved') == 'fuuuuuuu'

# Generated at 2022-06-24 00:37:11.052517
# Unit test for constructor of class Task
def test_Task():
    """
    Check that constructor work correctly.
    """
    Task(lambda _, resolve: resolve(5))
    Task(lambda reject, _: reject("error"))


# Generated at 2022-06-24 00:37:21.954794
# Unit test for method bind of class Task
def test_Task_bind():

    def f(x):
        return Task.reject(x)

    def g(x):
        return Task.reject(x + 1)

    def h(x):
        return Task.of(x + 1)

    assert Task(lambda _, resolve: resolve(0))\
        .bind(f)\
        .bind(g)\
        .bind(h)\
        .fork(lambda x: x, lambda x: x) == 0

    assert Task(lambda _, resolve: resolve(0))\
        .bind(f)\
        .bind(h)\
        .fork(lambda x: x, lambda x: x) == 1

    assert Task(lambda _, resolve: resolve('str'))\
        .bind(f)\
        .fork(lambda x: x, lambda x: x) == 'str'

# Unit test

# Generated at 2022-06-24 00:37:23.742482
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(42))
    assert task.fork(_, lambda x: x) == 42


# Generated at 2022-06-24 00:37:25.804876
# Unit test for method map of class Task
def test_Task_map():
    Task.of(5).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 6


# Generated at 2022-06-24 00:37:34.912397
# Unit test for constructor of class Task
def test_Task():

    # return value == 9
    assert Task(lambda _, resolve: resolve(9)).fork(None, lambda arg: arg) == 9
    # return None
    assert Task(lambda _, resolve: resolve(None)).fork(None, lambda arg: arg) is None
    # return value
    value = []
    assert Task(lambda _, resolve: resolve(value)).fork(None, lambda arg: arg) is value

    # return reason == 9
    assert Task(lambda reject, _: reject(9)).fork(lambda arg: arg, None) == 9
    # return None
    assert Task(lambda reject, _: reject(None)).fork(lambda arg: arg, None) is None
    # return reason
    reason = []
    assert Task(lambda reject, _: reject(reason)).fork(lambda arg: arg, None) is reason

    # return very value

# Generated at 2022-06-24 00:37:37.135960
# Unit test for constructor of class Task
def test_Task():
    def fork(_, resolve):
        return resolve(True)

    task = Task(fork)
    assert task.fork(_, resolve) == True


# Generated at 2022-06-24 00:37:40.890439
# Unit test for method map of class Task
def test_Task_map():
    Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x == 2)


# Generated at 2022-06-24 00:37:43.706824
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda x, y: y(2)).map(lambda x: x + 3).fork(lambda x: x * 3, lambda x: x) == 5


# Generated at 2022-06-24 00:37:48.996021
# Unit test for method bind of class Task
def test_Task_bind():
    def fn():
        t = Task.of(2)
        t2 = Task.of(3)
        assert t.bind(lambda x: t2).fork(lambda x: x, lambda x: x) == 3
        assert t.bind(lambda x: Task.reject(x)).fork(lambda x: x, lambda x: x) == 2

    fn()


# Generated at 2022-06-24 00:37:54.323945
# Unit test for method bind of class Task
def test_Task_bind():
    data = Task.of(1).bind(lambda x: Task.of(x + 1))
    result = data.fork(
        lambda x: x,
        lambda x: x
    )
    assert result == 2, "Task.bind() should return resolved task with value 2"


# Generated at 2022-06-24 00:38:00.140402
# Unit test for constructor of class Task
def test_Task():
    # Should be OK
    Task(lambda reject, resolve: resolve(1))
    Task(lambda reject, resolve: reject('error'))

    # Should raise exception TypeError
    try:
        Task(lambda resolve: resolve(1))
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-24 00:38:06.521660
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-24 00:38:09.416714
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(15)

    assert task.map(lambda a: a + 15) == Task.of(30)
    assert task.map(lambda a: a * 2) == Task.of(30)


# Generated at 2022-06-24 00:38:14.259286
# Unit test for constructor of class Task
def test_Task():
    def fork_resolve(reject, resolve):
        resolve(5)

    def fork_reject(reject, resolve):
        reject(5)

    assert Task(fork_resolve).fork(lambda _: None, lambda arg: arg) == 5
    assert Task(fork_reject).fork(lambda arg: arg, lambda _: None) == 5


# Generated at 2022-06-24 00:38:16.719961
# Unit test for method map of class Task
def test_Task_map():
    """
    Simple test for map function.
    """
    def sum(a):
        return a + 10

    res = Task.of(30).map(sum)
    assert res.fork(None, sum) == 40


# Generated at 2022-06-24 00:38:19.665031
# Unit test for method map of class Task
def test_Task_map():
    def fork(resolve, reject):
        resolve(1)

    task = Task(fork)
    t = task.map(lambda val: val + 1)
    assert t.fork(lambda val: val, lambda val: val) == 2



# Generated at 2022-06-24 00:38:21.633603
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2


# Generated at 2022-06-24 00:38:24.322097
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        raise NotImplementedError()

    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-24 00:38:31.116823
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def square(x):
        return Task.of(x * x)

    def square_root(x):
        return Task.of(math.sqrt(x))


# Generated at 2022-06-24 00:38:33.702499
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda _, resolve: resolve(1)).bind(lambda arg: Task(lambda _, resolve: resolve(arg + 1))).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-24 00:38:36.654154
# Unit test for constructor of class Task
def test_Task():
    t = Task(lambda reject, resolve: resolve(1))
    assert isinstance(t, Task)
    assert t.fork(None, lambda x: x) == 1


# Generated at 2022-06-24 00:38:41.412466
# Unit test for method map of class Task
def test_Task_map():
    mock = Mock()
    task = Task.of(1).map(lambda val: val + 1).map(mock)

    task.fork(lambda err: None, lambda err: None)

    def _(val):
        mock.assert_called_once_with(2)

    _(None)


# Generated at 2022-06-24 00:38:43.878043
# Unit test for constructor of class Task
def test_Task():
    @Task
    def fork(reject, resolve):
        resolve(1)

    assert fork.fork(lambda reject: reject(), lambda resolve: resolve(1)) == 1

# Unit test of class method Task.of

# Generated at 2022-06-24 00:38:47.805573
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(2) \
        .map(lambda x: x + 2) \
        .map(lambda x: x * 2) \
        .fork(lambda x: x, lambda x: x)
    assert result == 8


# Generated at 2022-06-24 00:38:58.085891
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_f(reject, resolve):
        resolve(1)

    def reject_f(reject, resolve):
        reject(2)

    t_resolve = Task(resolve_f)
    t_reject = Task(reject_f)

    def mapper_res(arg):
        assert arg == 1
        return Task.of(arg+1)

    def mapper_rej(arg):
        assert arg == 2
        return Task.reject(arg)

    def mapper_both(arg):
        assert arg == 1
        return Task.of(arg+1)


# Generated at 2022-06-24 00:39:02.693451
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    task = Task(lambda _, resolve: resolve('test'))
    assert isinstance(task, Task)
    assert callable(task.fork)


# Generated at 2022-06-24 00:39:06.034877
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 10).fork(None, lambda x: x) == 11
    assert Task.reject(1).map(lambda x: x + 10).fork(lambda x: x, None) == 1


# Generated at 2022-06-24 00:39:08.423361
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(42).fork(None, lambda fork: isinstance(fork, int)) is True
    assert Task.reject(42).fork(lambda reject: isinstance(reject, int), None) is True

# Generated at 2022-06-24 00:39:12.054034
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1) == Task(lambda _, resolve: resolve(1))



# Generated at 2022-06-24 00:39:16.853624
# Unit test for constructor of class Task
def test_Task():
    """
    Test that constructor of class Task store passed arguments
    """
    res = None
    rej = None

    def fork(a, b):
        nonlocal res, rej
        res = a
        rej = b

    task = Task(fork)
    task.fork(lambda a: a, lambda a: a)
    assert res == (lambda a: a)
    assert rej == (lambda a: a)


# Generated at 2022-06-24 00:39:20.658708
# Unit test for method map of class Task
def test_Task_map():
    def adder(x):
        return x + 1

    one = Task.of(0)
    two = Task.of(1)
    one_plus_one = one.map(adder)
    two_plus_one = two.map(adder)

    assert one_plus_one.fork(None, lambda value: value) == 1
    assert two_plus_one.fork(None, lambda value: value) == 2


# Generated at 2022-06-24 00:39:28.149954
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(4).bind(lambda x: Task.of(x+2))
    assert result.fork(lambda x: x, lambda x: x) == 6
    result = Task.of(4).bind(lambda x: Task.reject(x+2))
    assert result.fork(lambda x: x, lambda x: x) == 6
    result = Task.reject(4).bind(lambda x: Task.of(x+2))
    assert result.fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-24 00:39:32.135878
# Unit test for constructor of class Task
def test_Task():
    def resolve(_):
        raise Exception('Shouldn\'t be called')

    def reject(error):
        assert error == 'Error'

    task = Task(lambda reject, reject_: reject('Error'))
    task.fork(reject, resolve)


# Generated at 2022-06-24 00:39:37.175729
# Unit test for method bind of class Task
def test_Task_bind():
    def f(value):
        return Task.of(value + 10)

    def g(value):
        return Task.reject(value + 100)

    assert Task.of(2).bind(f).fork(lambda x: -1, lambda x: x) == 12
    assert Task.reject(2).bind(g).fork(lambda x: x, lambda x: -1) == 102



# Generated at 2022-06-24 00:39:43.415586
# Unit test for constructor of class Task
def test_Task():
    def sum_function(a, b):
        return a + b

    # Fork of returned Task should be result of sum_function
    assert (Task(lambda _, resolve: resolve(sum_function(2, 3))).fork(lambda: 'test', lambda: 1) == 5)

    # Reject of returned Task should be result of sum_function
    assert (Task(lambda reject, _: reject(sum_function(2, 3))).fork(lambda: 1, lambda: 'test') == 5)


# Generated at 2022-06-24 00:39:49.212913
# Unit test for method map of class Task
def test_Task_map():
    """ Unit test for method map of class Task """

    # Test with map function, that doesn't throw error
    def map_A_to_B(value):
        """ Test map function """
        return value * 2

    # Test with map function, that throw error
    def map_A_to_B_with_error(value):
        """ Test map function, that throw error """
        raise Exception('Something wrong')

    # Test with map function, that throw error
    def map_A_to_B_with_reject(value):
        """ Test map function, that throw error """
        return Task.reject(-1)

    # Test with function, that throw error
    def reject_A_to_B(reject, resolve):
        """ Test map function, that throw error """
        reject(-1)


# Generated at 2022-06-24 00:39:56.396073
# Unit test for method bind of class Task
def test_Task_bind():
    def f1(reject, resolve):
        nonlocal called_with
        called_with = [reject, resolve]
        resolve('value')

    def f2(value):
        return value + 1

    later = Task(f1)
    (Task(f1)
        .map(f2)
        .fork(*called_with.pop()))

    assert called_with == [f2]


# Generated at 2022-06-24 00:40:04.196922
# Unit test for method map of class Task
def test_Task_map():
    def square(x):
        return x * x

    def square_root(x):
        return Task.of(math.sqrt(x))

    assert Task.of(3).map(square) == Task.of(9)
    assert Task.of(4).map(square).map(square_root) == Task.of(2)
    assert Task.reject(4).map(square).map(square_root) == Task.reject(4)
    assert Task.reject(4).map(square).map(square_root).map(square) == Task.reject(4)


# Generated at 2022-06-24 00:40:07.262008
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of('hi').map(lambda value: value[0]).fork(None, lambda value: value) == 'h'
    assert Task.of('hi').map(lambda value: value[1]).fork(None, lambda value: value) == 'i'


# Generated at 2022-06-24 00:40:13.432992
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test that method bind of class Task is working correctly
    """
    task = Task(lambda _, resolve: resolve(1))
    second = Task(lambda _, resolve: resolve(2))
    third = Task(lambda _, resolve: resolve(3))

    assert task.bind(lambda a: second).bind(lambda b: third).fork(lambda _: None, lambda x: x) == 3


# Generated at 2022-06-24 00:40:18.068694
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 'foo'

    def fork(reject, resolve):
        resolve(12)

    task = Task(fork)

    assert task.map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 13
    assert task.map(mapper).fork(lambda x: x, lambda x: x) == '12foo'



# Generated at 2022-06-24 00:40:23.274758
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for bind of function Task
    """

    assert Task.of(1).bind(lambda value: Task.of(value + 1)).fork(lambda arg: arg, lambda arg: arg) == 2

    assert Task.of(1).bind(lambda _: Task.reject(3)).fork(lambda arg: arg, lambda arg: arg) == 3

    assert Task.reject(1).bind(lambda _: Task.of('hi')).fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-24 00:40:30.546811
# Unit test for constructor of class Task
def test_Task():
    start_test('test_Task')

    def fork(reject, resolve):
        return resolve('task_value')

    task = Task(fork)

    assertEqual(
        'Task.fork should return "task_value"',
        'task_value',
        task.fork(lambda x: 'reject', lambda x: x)
    )

    end_test()


# Generated at 2022-06-24 00:40:32.366523
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: None).fork(lambda arg: arg, lambda arg: arg) is None


# Generated at 2022-06-24 00:40:36.183723
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task bind should return Task with mapped value by received function.
    """
    def fn(v):
        return Task.of(v + '!')

    def fork(reject, resolve):
        return 'Hello'

    t = Task(fork)
    t = t.bind(fn)
    assert t.fork(lambda _: None, lambda v: v) == 'Hello!'


# Generated at 2022-06-24 00:40:40.501470
# Unit test for method map of class Task
def test_Task_map():
    success = Task.of(1).map(lambda x: x + 1)
    assert success.fork(lambda _: False, lambda x: x == 2)
    assert Task.reject(1).map(lambda _: None).fork(lambda _: True, lambda _: False)


# Generated at 2022-06-24 00:40:50.238692
# Unit test for method map of class Task
def test_Task_map():
    def reject_value(value):
        def t(reject, _):
            return reject(value)
        return Task(t)

    def resolve_value(value):
        def t(_, resolve):
            return resolve(value)
        return Task(t)

    def multiply_by_two(value):
        return value * 2

    def fn(value):
        raise Exception('boom!')


# Generated at 2022-06-24 00:40:56.362846
# Unit test for method map of class Task
def test_Task_map():
    """
    Return Unit-test for method map of class Task
    """
    def test_map_with_success(fn, value, expected_result):
        """
        Return Unit-test for method map of class Task with success

        :param fn: function to test
        :type fn: Function(value) -> B
        :param value: value witch pass to function
        :type value: A
        :param expected_result: result of execution of function
        :type expected_result: B
        :returns: Unit-test for method map with success
        :rtype: Function(test) -> None
        """

# Generated at 2022-06-24 00:41:00.794455
# Unit test for constructor of class Task
def test_Task():
    # function which call during fork
    def fork(_, resolve):
        resolve(1)

    # initialize Task with fork function
    task = Task(fork)

    # check type of result
    assert type(task) == Task

    # check inner attributes
    assert task.fork == fork


# Generated at 2022-06-24 00:41:07.061490
# Unit test for method bind of class Task
def test_Task_bind():
    def get_data(arg, delay):
        def fork(reject, resolve):
            time.sleep(delay)
            resolve(arg)

        return Task(fork)

    def get_result(arg):
        assert arg == 1

    Task.of(1)\
        .bind(lambda arg: get_data(arg, 2))\
        .fork(
            None,
            get_result
        )

    # time.sleep(3)
    # assert 1 == 2


# Generated at 2022-06-24 00:41:10.782289
# Unit test for method map of class Task
def test_Task_map():
    def result(reject, resolve):
        resolve(5)

    def mapper(value):
        return 6 + value

    def assert_mapper(value):
        assert value is 11

    task = Task(result)
    task.map(mapper).fork(lambda _: None, assert_mapper)


# Generated at 2022-06-24 00:41:16.502155
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(12)
    mapped_task = task.map(lambda value: value * 10)
    # Function fork of mapped task will call resolve with 120 argument
    assert 120 == mapped_task.fork(lambda reject, resolve: resolve(12))


# Generated at 2022-06-24 00:41:20.747489
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(2) \
        .map(lambda x: x + 1) \
        .map(lambda x: x * 2) \
        .fork(
            lambda arg: arg,
            lambda arg: arg
        )

    assert result == 6


# Generated at 2022-06-24 00:41:22.386651
# Unit test for constructor of class Task
def test_Task():
    fork = lambda _, resolve: resolve(42)
    a = Task(fork)

    assert a.fork == fork, 'Task should store a fork function'


# Generated at 2022-06-24 00:41:27.816102
# Unit test for constructor of class Task
def test_Task():
    v = 'test string'

    t = Task.of(v)
    v_res = t.fork(
        lambda arg: arg,
        lambda arg: arg
    )
    assert v == v_res

    t = Task.reject(v)
    v_res = t.fork(
        lambda arg: arg,
        lambda arg: arg
    )
    assert v == v_res



# Generated at 2022-06-24 00:41:33.276570
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task, to ensure that
    during task.map(lambda a: a + 1) call,
    task.fork will be called with new fork function,
    that call resolve with result of lambda a: a + 1
    """

    def task_fork(reject, resolve):
        reject('I am rejected value')
        resolve('I am resolved value')

    def task_reject(value):
        assert value == 'I am rejected value'

    def task_resolve(value):
        assert value == 'I am mapped resolved value'

    def is_mapped_task_fork_called(reject, resolve):
        task_fork(reject, lambda arg: resolve('I am mapped ' + arg))

    task = Task(task_fork)

# Generated at 2022-06-24 00:41:44.987231
# Unit test for constructor of class Task
def test_Task():
    import pytest

    def test_task_raw():
        def result():
            return 'result'

        def fail():
            return 'fail'

        task = Task(lambda reject, resolve: result())

        assert task.fork(fail, result) == result()

    def test_task_then_or_catch():
        def result():
            return 'result'

        def fail():
            return 'fail'

        task = Task(lambda reject, resolve: reject('fail'))

        assert task.fork(fail, result) == fail()

    def test_task_of():
        task = Task.of(1)

        assert task.fork(lambda fail: fail, lambda success: success) == 1

    def test_task_reject():
        task = Task.reject(1)
