

# Generated at 2022-06-24 00:31:42.134951
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve("42")) == Task(lambda _, resolve: resolve("42"))
    assert Task(lambda _, resolve: resolve("42")) != Task(lambda _, resolve: resolve("24"))
    assert Task(lambda _, resolve: resolve("42")) != 42


# Generated at 2022-06-24 00:31:44.711199
# Unit test for constructor of class Task
def test_Task():
    a = Task.of(1)
    b = Task(lambda _, resolve: resolve(1))
    assert a.fork == b.fork


# Generated at 2022-06-24 00:31:48.365397
# Unit test for constructor of class Task
def test_Task():
    def return_resolve_value(reject, resolve):
        resolve('value')

    def return_reject_value(reject, resolve):
        reject('value')

    resolved_task = Task(return_resolve_value)
    rejected_task = Task(return_reject_value)


# Generated at 2022-06-24 00:31:51.238658
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    task = Task.of(42).bind(mapper)

    assert task.fork(assert_false, lambda val: val == 43)


# Generated at 2022-06-24 00:31:57.330361
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve('first_task')

    def fn(task_value):
        def task_resolve(reject, resolve):
            resolve(task_value + '_second_task')

        return Task(task_resolve)

    result = Task(fork).bind(fn)

    assert result.fork(lambda x: x, lambda x: x) == 'first_task_second_task'


# Generated at 2022-06-24 00:32:02.546062
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind() method
    """
    task = Task.of(10)
    task2 = task.bind(lambda x: Task.of(x + 1))
    task3 = task2.bind(lambda x: Task.reject(x * 2))
    task4 = task3.bind(lambda x: Task.of(x ** 3))

    assert task4.fork(lambda x: x, lambda x: x) == 20



# Generated at 2022-06-24 00:32:08.734659
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value)

    def test_Task_resolve_mapped_resolve_value(resolve, reject):
        assert Task.of(1).bind(fn).fork(reject, resolve) == 1

    def test_Task_reject_mapped_reject_value(resolve, reject):
        assert Task.reject(2).bind(fn).fork(reject, resolve) == 2


# Generated at 2022-06-24 00:32:11.123057
# Unit test for method map of class Task
def test_Task_map():
    def test_f(value):
        return value + '1'

    assert Task.of('ok').map(test_f).fork(None, lambda value: value) == 'ok1'



# Generated at 2022-06-24 00:32:19.504854
# Unit test for method map of class Task
def test_Task_map():
    def testIterator():
        for i in range(4):
            yield i

    def test_mapper(iter):
        def test_map(value):
            next(iter)
            return value + 1
        return test_map

    def test_fork(reject, resolve):
        resolve(0)

    task = Task(test_fork)

    int_iterator = testIterator()
    row_map_task = task.map(test_mapper(int_iterator))
    row_fork = row_map_task.fork

    row_fork(lambda arg: None, lambda arg: assertEqual(arg, 1))
    row_fork(lambda arg: None, lambda arg: assertEqual(arg, 1))
    row_fork(lambda arg: None, lambda arg: assertEqual(arg, 1))

# Generated at 2022-06-24 00:32:21.797152
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.bind(Task.of(1), lambda x: Task.reject(x)) == Task.reject(1)


# Generated at 2022-06-24 00:32:32.947913
# Unit test for method bind of class Task
def test_Task_bind():
    test_value = 10
    test_mapper = lambda arg: arg + 1
    reject = lambda arg: arg
    resolve = lambda arg: arg

    # resolve -> resolve
    promise = Task(lambda reject, resolve: resolve(test_value))
    result = promise.bind(lambda arg: Task(lambda reject, resolve: resolve(arg + 1))).fork(reject, resolve)
    assert result == test_value + 1

    # resolve -> reject
    promise = Task(lambda reject, resolve: resolve(test_value))
    result = promise.bind(lambda arg: Task(lambda reject, resolve: reject(arg + 1))).fork(reject, resolve)
    assert result == test_value

    # reject -> resolve
    promise = Task(lambda reject, resolve: reject(test_value))

# Generated at 2022-06-24 00:32:37.245355
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind method for class Task
    """
    assert Task.of(1).bind(lambda value: Task.of(value + 1)).fork(None, lambda value: value) == 2
    assert Task.reject(1).bind(lambda value: Task.of(value + 1)).fork(lambda value: value, None) == 1


# Generated at 2022-06-24 00:32:44.522799
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind for class Task.
    """
    def resolve_fn(value):
        assert(value == 1)

    def reject_fn(value):
        assert(value == 2)

    def get_task(value):
        if value == 1:
            return Task.of(1)
        elif value == 2:
            return Task.reject(2)

    task = Task.of(1)
    task.bind(get_task).fork(reject_fn, resolve_fn)

    task = Task.of(2)
    task.bind(get_task).fork(reject_fn, resolve_fn)

    print('test_Task_bind_: OK')


# Generated at 2022-06-24 00:32:55.280255
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test case for method bind of class Task
    """
    def add_3(value):
        return value + 3

    def add_2(value):
        return Task.of(value + 2)

    def add_1(value):
        return Task.of(value + 1)

    def add_7(value):
        return Task.of(value + 7)

    value = 0

    task1 = Task.of(value).map(add_3).map(add_2).bind(add_1).bind(add_7)
    assert task1.fork(lambda _: -1, lambda res: res) == (value + 3 + 2 + 1 + 7)

    task2 = Task.reject(value).map(add_3).map(add_2).bind(add_1).bind(add_7)
   

# Generated at 2022-06-24 00:32:59.160480
# Unit test for method map of class Task
def test_Task_map():
    def add_one(v):
        return v + 1

    assert Task.of(1).map(add_one).fork(lambda x: x) == 2


# Generated at 2022-06-24 00:33:03.280573
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(0)
    task = task.bind(lambda value: Task.of(1))
    task = task.bind(lambda value: Task.of(2))
    assert task.fork(lambda value: None, lambda value: value) == 2


# Generated at 2022-06-24 00:33:07.168573
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task map method.

    :returns: None
    """
    def func(value):
        return value + 1

    task = Task.of(3)

    assert task.fork(lambda _, resolve: resolve(3)) == task.map(func).fork(lambda _, resolve: resolve(3))


# Generated at 2022-06-24 00:33:09.476778
# Unit test for constructor of class Task
def test_Task():
    chain = Task(lambda reject, resolve: resolve("result"))
    assert chain.fork(None, lambda result: result) == "result"



# Generated at 2022-06-24 00:33:15.421454
# Unit test for method map of class Task
def test_Task_map():
    def assert_map(task, expect):
        def get_value(resolve, reject):
            return resolve(task.map(lambda x: x * 2))

        assert expect == Task(get_value).fork(lambda x: False, lambda x: x.fork(lambda x: False, lambda x: x))

    assert_map(Task.of(2), 4)
    assert_map(Task.reject(2), False)


# Generated at 2022-06-24 00:33:19.090902
# Unit test for method bind of class Task
def test_Task_bind():
    task1 = Task.of(1)
    task2 = Task.of(2)

    task3 = task1.bind(lambda i: task2.map(lambda j: str(i + j)))
    def fork(reject, resolve):
        try:
            assert resolve('3') == task3.fork(reject, resolve)
        except:
            raise AssertionError
    task3.fork(fork, fork)


# Generated at 2022-06-24 00:33:22.423305
# Unit test for constructor of class Task
def test_Task():
    fork = lambda _, resolve: resolve(2)
    task = Task(fork)
    assert task.fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-24 00:33:27.448544
# Unit test for constructor of class Task
def test_Task():
    def fork_test(reject, resolve):
        return reject(reject)

    task = Task(fork_test)

    assert isinstance(task.fork, Function)
    assert task.fork(lambda _: 1, lambda _: 2) == fork_test(lambda _: 1, lambda _: 2)


# Generated at 2022-06-24 00:33:36.872507
# Unit test for method map of class Task
def test_Task_map():
    def test_map(value):
        def mapper(value):
            return value * 2

        def mapper_with_error(value):
            raise ValueError('some error')

        def reject(value):
            assert(False)

        def resolve(value):
            assert value == 2

        Task.of(1).map(mapper).fork(reject, resolve)
        Task.of(1).map(mapper_with_error).map(mapper).fork(reject, resolve)
        Task.reject(1).map(mapper).fork(resolve, reject)

    test_map(1)


# Generated at 2022-06-24 00:33:45.037629
# Unit test for method map of class Task
def test_Task_map():
    # Test of methods map with pure function:
    def mock_reject(arg):
        arg.append(1)

    def mock_resolve(arg):
        arg.append(2)

    def mock_mapper(arg):
        arg.append(3)
        return arg

    task_mock_data = []
    task_mock = Task(lambda resolve, reject: resolve(task_mock_data))

    task_mock_mapped = task_mock.map(mock_mapper)

    assert task_mock_mapped.fork(reject=mock_reject, resolve=mock_resolve) == [2, 3]

    # Test of methods map with impure function:
    def mock_reject_1(exp):
        if exp == 'ok':
            return exp


# Generated at 2022-06-24 00:33:49.292829
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(
        lambda _: 'throw',
        lambda arg: arg + 1
    ) == 2

    assert Task.reject(1).fork(
        lambda arg: arg + 1,
        lambda _: 'throw'
    ) == 2


# Generated at 2022-06-24 00:33:53.765530
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map method.
    """
    assert Task.of(10).map(lambda arg: arg + 10).fork(const(None), id) == 20
    assert Task.reject('test').map(lambda arg: arg + 10).fork(id, const(None)) == 'test'


# Generated at 2022-06-24 00:33:55.766297
# Unit test for constructor of class Task
def test_Task():
    # Check that Task creation works
    task = Task(None)
    assert isinstance(task, Task), 'Task creation failed!'


# Generated at 2022-06-24 00:34:04.566088
# Unit test for method bind of class Task
def test_Task_bind():
    def reject_resolve(x):
        def resolve(value):
            return 'Resolved: ' + str(value)

        def reject(value):
            return 'Rejected: ' + str(value)

        return Task(lambda reject, resolve: resolve(x)).fork(reject, resolve)

    assert reject_resolve(42) == 'Resolved: 42'

    def identity(x):
        return x

    assert Task.of('Result').map(identity).map(identity).fork(identity, identity) == 'Result'

    # Task to call during fork
    def not_resolve_this_task(reject, resolve):
        resolve("Not called")

    def never_called(reject, resolve):
        reject("Not called")


# Generated at 2022-06-24 00:34:05.955364
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(5)
    task = task.map(lambda a: a + 3)
    assert task.fork(None, lambda a: a) == 8


# Generated at 2022-06-24 00:34:09.093328
# Unit test for method map of class Task
def test_Task_map():
    def add_one(arg):
        return arg + 1

    assert Task.of(1).map(add_one).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-24 00:34:13.644218
# Unit test for method map of class Task
def test_Task_map():
    def test(num):
        def success(resolve, reject):
            resolve(num)

        return Task(success)

    assert (test(1).map(lambda num: num + 1).fork(lambda _: False, lambda arg: arg == 2) == True)


# Generated at 2022-06-24 00:34:17.680589
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for constructor of class Task

    >>> def fn(reject, resolve):
    ...     resolve(1)

    >>> task = Task(fn)

    >>> task.fork(lambda x: print("Error", x), print)
    1
    """


# Generated at 2022-06-24 00:34:22.936522
# Unit test for method bind of class Task
def test_Task_bind():
    def reject(value):
        assert value == 5

    def reject2(value):
        assert value == 10

    def resolve(value):
        assert value == 15

    def fork(reject, resolve):
        return resolve(5)

    def fork2(reject, resolve):
        return reject(10)

    def fork3(reject, resolve):
        return resolve(15)

    assert Task(fork).bind(lambda arg: Task(fork2)).fork(reject, resolve) == Task(fork3).fork(reject, resolve)


# Generated at 2022-06-24 00:34:27.199928
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method 'map' of class 'Task'
    """
    def add(a):
        return a + 12

    def mult(a):
        return a * 100

    def sub(a):
        return a - 5

    def div(a):
        return a / 2

    assert Task.of(2).map(add).map(mult).map(sub).map(div).fork(None, None) == 25



# Generated at 2022-06-24 00:34:29.731806
# Unit test for method bind of class Task
def test_Task_bind():
    func = Task.of(lambda x: x + 1)
    result = Task.of(1).bind(func)
    assert result.fork(lambda reject: None,
                       lambda resolve: resolve) == 2

# Generated at 2022-06-24 00:34:30.794268
# Unit test for constructor of class Task
def test_Task():
    test = Task(lambda reject, resolve: reject("Hello"))
    assert test.fork is not None


# Generated at 2022-06-24 00:34:33.960210
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(10)
    task = task.bind(lambda x: Task.of(x + 2))
    result = task.fork(lambda x: x, lambda x: x)
    assert result == 12

    task = Task.reject(20)
    task = task.bind(lambda x: Task.of(x + 2))
    result = task.fork(lambda x: x, lambda x: x)
    assert result == 20


# Generated at 2022-06-24 00:34:36.762983
# Unit test for constructor of class Task
def test_Task():
    def _fork(reject, resolve):
        return 'is called'

    task = Task(_fork)

    assert isinstance(task, Task)
    assert task.fork is _fork



# Generated at 2022-06-24 00:34:39.069870
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(5).map(lambda value: value + 1).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 6


# Generated at 2022-06-24 00:34:43.602522
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        assert value == 2

    def reject(value):
        assert False

    task = Task(lambda reject, resolve: resolve(1))
    task.map(lambda value: value + 1).fork(reject, resolve)


# Generated at 2022-06-24 00:34:48.735471
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda v: v + 1)
    assert task.fork(lambda _: False, lambda v: v == 2)

    task = Task.reject(1).map(lambda v: v + 1)
    assert task.fork(lambda v: v == 1, lambda _: False)


# Generated at 2022-06-24 00:34:50.829856
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task
    """
    assert Task(lambda _, resolve: resolve(4)).fork(lambda a: a, lambda a: a) == 4



# Generated at 2022-06-24 00:34:54.358485
# Unit test for method map of class Task
def test_Task_map():
    """
    test map method
    """
    assert Task(lambda _, resolve: resolve(5)).map(lambda arg: arg + 10).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 15


# Generated at 2022-06-24 00:34:57.748122
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task map method
    """

    # Create resolved Task
    task = Task.of(None)

    # Create new mapped Task
    mapped_task = task.map(lambda _: None)

    # Check that task is correct instance of Task class
    assert isinstance(mapped_task, Task)

    # Check that task have correct value
    assert mapped_task.fork(lambda x: isinstance(x, Exception), lambda x: x == None)


# Generated at 2022-06-24 00:35:02.022588
# Unit test for method bind of class Task
def test_Task_bind():
    # define test data
    data = {
        'for': 'bind',
        'task': Task(lambda _, resolve: resolve(1))
    }

    # resolve task with map method
    def resolve_with_bind_method(data):
        return data['task']\
            .bind(lambda arg: Task.of(arg + 1))\
            .bind(lambda arg: Task.reject(arg + 1))\
            .bind(lambda arg: Task.of(arg + 1))

    # result should be rejected
    assert isinstance(resolve_with_bind_method(data), Task) == True
    # and has value 2
    assert resolve_with_bind_method(data).fork(lambda reject_arg: reject_arg, lambda resolve_arg: resolve_arg) == 2


# Generated at 2022-06-24 00:35:06.128105
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind from class Task

    :return: None
    """
    def fork(reject, resolve):
        return resolve(10)

    def mapper(value):
        return Task.of(value ** 2)

    assert Task(fork).bind(mapper) == Task.of(100)



# Generated at 2022-06-24 00:35:15.124441
# Unit test for method bind of class Task
def test_Task_bind():
    def foo(arg):
        return arg

    def foo_reject(arg):
        return Task.reject(arg)

    def foo_resolve(arg):
        return Task.of(arg)

    def test_bind00(resolve, reject):
        return Task.of(
            0
        ).bind(foo).fork(reject, resolve)

    assert Task(test_bind00).fork(_, foo) == 0

    def test_bind01(resolve, reject):
        return Task.reject(
            'error'
        ).bind(foo_reject).fork(resolve, reject)

    assert Task(test_bind01).fork(foo, _) == 'error'


# Generated at 2022-06-24 00:35:18.992279
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(42)
    assert task.map(lambda x: x + 1).fork(lambda e: e, lambda a: a) == 43
    task = Task.reject(42)
    assert task.map(lambda x: x + 1).fork(lambda e: e, lambda a: a) == 42



# Generated at 2022-06-24 00:35:26.652850
# Unit test for constructor of class Task
def test_Task():
    assert 0 == Task(lambda _, resolve: resolve(0)).fork(lambda reject, resolve: 0)
    assert 0 == Task(lambda reject, _: reject(0)).fork(lambda reject, resolve: 0)

    assert 1 == Task.of(1).fork(lambda reject, resolve: resolve)
    assert 1 == Task.reject(1).fork(lambda reject, resolve: reject)

    task = Task.of(0)
    assert task.map(lambda arg: arg + 1).fork(lambda reject, resolve: resolve) == 1


# Generated at 2022-06-24 00:35:29.949355
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject('test')
        resolve('test')

    test_task = Task(fork)

    assert test_task.fork == fork

# Unit test of static method Task.of(value)

# Generated at 2022-06-24 00:35:32.594904
# Unit test for method map of class Task
def test_Task_map():
    with pytest.raises(Exception) as e:
        assert Task.of(1).map(lambda e: 1 / e).fork(None, None)
    assert e.value.args[0] == "division by zero"



# Generated at 2022-06-24 00:35:39.742966
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda value: Task.of(value + 1)).fork(
        lambda error: error,
        lambda value: value
    ) == 2
    assert Task.of(1).bind(lambda value: Task.reject(value + 1)).fork(
        lambda error: error,
        lambda value: value
    ) == 2

# Generated at 2022-06-24 00:35:47.247143
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(12).map(lambda arg: arg * arg)
    assert result.fork(lambda arg: arg, lambda arg: arg) == 144

    result = Task.reject(12).map(lambda arg: arg * arg)
    assert result.fork(lambda arg: arg, lambda arg: arg) == 12

    result = Task.reject(12).map(lambda arg: arg * arg)
    assert result.fork(lambda arg: arg, lambda arg: arg) == 12


# Generated at 2022-06-24 00:35:50.498266
# Unit test for constructor of class Task
def test_Task():
    """
    Test Task constructor.
    """
    def fork(reject, resolve):
        reject('fork function')

    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-24 00:35:55.688833
# Unit test for method map of class Task
def test_Task_map():
    # Case: Task contains `resolve` value
    task = Task(
        lambda reject, resolve: resolve(42)
    )

    mappedTask = task.map(lambda arg: arg * 2)

    assert mappedTask.fork(lambda _, __: 0, lambda arg: arg) == 84

    # Case: Task contains `reject` value
    task = Task(
        lambda reject, resolve: reject(42)
    )

    mappedTask = task.map(lambda arg: arg * 2)

    assert mappedTask.fork(lambda arg, __: arg, lambda _: 0) == 42

# Generated at 2022-06-24 00:36:00.717208
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def fail(value):
        raise Exception("ERROR")

    def throws_error(value):
        raise Exception("ERROR")

    def plus(x, y):
        return x + y

    res = Task(lambda reject, resolve: resolve(1))
    assert res.map(add_one).fork(fail, add_one) == 2
    assert res.map(throws_error).fork(add_one, fail) == 1
    assert res.map(lambda x: plus(x, 1)).fork(fail, add_one) == 2


# Generated at 2022-06-24 00:36:07.850026
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    t1 = Task.of(3)
    t2 = t1.map(add_one)

    def fork1(reject, resolve):
        return reject(0)

    def fork2(reject, resolve):
        return resolve(4)

    assert t1.fork == fork1
    assert t2.fork == fork2, 'Task function was not mapped'


# Generated at 2022-06-24 00:36:10.317197
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(69)

    task = Task(fork)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 69


# Generated at 2022-06-24 00:36:13.375032
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case(x):
        return x + 1

    assert Task.of(4).bind(lambda value: Task.of(test_case(value))).fork(
        lambda error: error,
        lambda result: result
    ) == 5



# Generated at 2022-06-24 00:36:18.177420
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(msg):
        print("resolve: {}".format(msg))

    def reject(msg):
        print("reject: {}".format(msg))

    def mapper(msg):
        return Task.reject("mapped of {}".format(msg))

    task = Task.of("1") \
        .bind(mapper) \
        .map(lambda msg: "mapped of {}".format(msg))

    assert task.fork(reject, resolve) == None


# Generated at 2022-06-24 00:36:20.889399
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda _: 0, lambda arg: arg) == 1


# Generated at 2022-06-24 00:36:26.861886
# Unit test for method map of class Task
def test_Task_map():
    """
    test_Task_map:
    This test suite test map method of Task class.
    """

    def test_map():
        """
        test_map:
        This test case test map method of Task class.
        """

        @do(Task[None])
        def test():
            """
            function test:
            This function test map method of Task class.
            """
            value = yield Task.of(3)
            result = yield value.map(plus(value))
            assert result == 6

        test()

    def test_map_throw():
        """
        test_map_throw:
        This test case test map method of Task class.
        Test case: method map map throw error.
        """


# Generated at 2022-06-24 00:36:36.517425
# Unit test for method map of class Task
def test_Task_map():
    add5_mapper = lambda arg: arg + 5
    add10_mapper = lambda arg: arg + 10

    assert Task.of(3).map(add5_mapper).fork(None, lambda a: a) == 8
    assert Task.of(5).map(add10_mapper).map(add5_mapper).fork(None, lambda a: a) == 20

    # Check fail-fast behavior
    assert Task.reject(3).map(add5_mapper).fork(lambda a: a, None) == 3
    assert Task.reject(3).map(add5_mapper).map(add10_mapper).fork(lambda a: a, None) == 3


# Generated at 2022-06-24 00:36:37.963437
# Unit test for constructor of class Task
def test_Task():
    def fork(_, resolve):
        return resolve('data')

    t = Task(fork)
    assert t.fork(_, resolve) == 'data'


# Generated at 2022-06-24 00:36:41.355593
# Unit test for method bind of class Task
def test_Task_bind():
    source = Task(lambda reject, resolve: resolve([1, 2, 3]))
    result = source.bind(lambda x: Task.of([y**2 for y in x]))

    assert result.fork(lambda _: _, lambda _: _) == [1, 4, 9]

# Unit test

# Generated at 2022-06-24 00:36:49.881163
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for map method of Task class.
    """
    logger.debug('test Task map')

    # assert Task.of(1).map(lambda res: res + 1).fork(lambda _: 'error', lambda res: res) == 2
    # assert Task.reject('error').map(lambda res: res + 1).fork(lambda _: 'error', lambda res: res) == 'error'
    # assert Task.of(1).map(lambda res: Task.of(res + 1)).fork(lambda _: 'error', lambda res: res).fork(lambda _: 'error', lambda res: res) == 2


# Generated at 2022-06-24 00:36:54.252476
# Unit test for method map of class Task
def test_Task_map():
    """
    Test of Task.map method.
    """
    def map_test(value):
        def fn(resolve, reject):
            resolve(value)

        return Task(fn)

    assert map_test(5).map(lambda value: value + 1).fork(
        lambda _: None,
        lambda value: value == 6
    )


# Generated at 2022-06-24 00:36:57.861097
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(resolve, reject):
        setTimeout(lambda: resolve(1), 0)

    Task1 = Task(fn)
    Task2 = Task1.bind(lambda value: Task.of(value + 1))  # get Task2(2)


# Generated at 2022-06-24 00:37:02.886340
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    def fn(resolve, reject):
        resolve(3)

    def fm(value):
        return Task.of(value * 2)

    task = Task(fn)
    result = task.bind(fm)

    assert result.fork(lambda reject: reject, lambda resolve: resolve) == 6

# Generated at 2022-06-24 00:37:10.766129
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for bind method of class Task.

    :rtype: None
    """

# Generated at 2022-06-24 00:37:12.485776
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(0).bind(lambda i: Task.of(i + 1))
    assert result.fork(None, None) == 1


# Generated at 2022-06-24 00:37:17.730396
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Simple unit test for Task.bind method.
    """
    def later(value):
        return Task(lambda _, resolve: setTimeout(lambda: resolve(value), 100))

    def later_reject(value):
        return Task(lambda reject, _: setTimeout(lambda: reject(value), 100))

    def task_mapper(value):
        return Task(lambda reject, resolve: setTimeout(lambda: resolve(value), 100))

    task = later("test")
    later_reject("error") \
        .bind(lambda _: task.bind(task_mapper)) \
        .fork(lambda arg: print("Rejected with arg: {0}".format(arg)),
              lambda arg: print("Resolved with arg: {0}".format(arg)))

    # Resolved with arg: test

# Unit test

# Generated at 2022-06-24 00:37:19.877014
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        try:
            resolve(2)
        except Exception as err:
            reject(err)

    task = Task(fork)
    assert task.bind(Task.of).fork(throw, identity) == 2
    assert task.bind(lambda arg: Task.reject(arg)).fork(identity, throw) == 2

# Generated at 2022-06-24 00:37:25.831799
# Unit test for method map of class Task
def test_Task_map():
    t = Task.of(1)
    t = t.map(lambda x: x + 1)
    assert t.fork(lambda x: x, lambda y: y) == 2

    t = Task.of(2)
    t = t.map(lambda x: x * 2)
    assert t.fork(lambda x: x, lambda y: y) == 4

    t = Task.of(3)
    t = t.map(lambda x: x ** 2)
    assert t.fork(lambda x: x, lambda y: y) == 9


# Generated at 2022-06-24 00:37:28.816230
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x + 2).fork(lambda _: True, lambda x: x == 4) == True
    assert Task.of(3).map(lambda x: x + 2).fork(lambda _: False, lambda x: x == 4) == False
    assert Task.reject(2).map(lambda x: x + 2).fork(lambda _: True, lambda x: False) == True


# Generated at 2022-06-24 00:37:32.354395
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(5)

    def fn(value):
        return Task.of(value * 10)

    task = Task(fork)

    assert task.bind(fn).fork(None, lambda val: val) == 50


# Generated at 2022-06-24 00:37:35.671582
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(x):
        return Task.of(x + 10)

    task = Task.of(10)

    assert(task.bind(fn).fork(lambda _: None, lambda res: res) == 20)



# Generated at 2022-06-24 00:37:40.735274
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        assert reject
        assert resolve

    task = Task(fork)
    assert task.fork is fork


# Generated at 2022-06-24 00:37:42.524153
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    assert Task(lambda r, _: _(7)).bind(lambda x: Task.of(x * 2)).fork(lambda r: r, lambda v: v) == 14


# Generated at 2022-06-24 00:37:52.606203
# Unit test for method bind of class Task
def test_Task_bind():
    def get_fail():
        def fork(reject, _):
            reject("fail")

        return Task(fork)

    def r(value):
        assert value == "done"

    def f(value):
        raise AssertionError("this is failure")

    get_fail().bind(lambda _: Task.of("done")).fork(f, r)

    def get_success():
        def fork(_, resolve):
            resolve("success")

        return Task(fork)

    get_success().bind(lambda _: Task.reject("fail")).fork(r, f)

    def r(value):
        assert value == "done"

    def f(value):
        raise AssertionError("this is failure")

    def fail():
        def fork(reject, _):
            reject("fail")

        return Task

# Generated at 2022-06-24 00:37:58.940055
# Unit test for method map of class Task
def test_Task_map():
    minus = lambda x: x * -1
    plus = lambda x, y: x + y
    result_task = Task.of(1)\
        .map(minus)\
        .map(fix(plus, 1))

    assert result_task.fork(lambda _: False, lambda x: x == -1), "Error Task.map"



# Generated at 2022-06-24 00:38:01.400616
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.map(lambda x: x + 2).fork(lambda x: x, lambda x: x) == 3


# Generated at 2022-06-24 00:38:07.634661
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    def test_success(state, value):
        """
        :param state: state of binded value
        :type state: String
        :param value: value of binded value
        :type value: String
        :returns: state and value in special format
        :rtype: String
        """
        return "{}: {}".format(state, value)

    def failure(state, value):
        """
        :param state: state of binded value
        :type state: String
        :param value: value of binded value
        :type value: String
        :returns: state and value in special format
        :rtype: String
        """
        return "{}: {}".format(state, value)


# Generated at 2022-06-24 00:38:09.500273
# Unit test for method map of class Task
def test_Task_map():
    Task.of(1).map(lambda x: x + 1).fork(None, lambda v: print(v))  # 2


# Generated at 2022-06-24 00:38:12.264103
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(None) == Task(lambda _, resolve: resolve(None))
    assert Task.reject(None) == Task(lambda reject, _: reject(None))

# Generated at 2022-06-24 00:38:18.119250
# Unit test for constructor of class Task
def test_Task():
    # Task should be call with function to run in future
    Task(lambda _, resolve: resolve(1)).fork(lambda _: None, lambda result: result == 1)
    Task(lambda _, resolve: resolve(1)).fork(lambda _: None, lambda result: not isinstance(result, str))
    Task(lambda _, resolve: resolve(1)).fork(lambda _: None, lambda result: not isinstance(result, int))


# Generated at 2022-06-24 00:38:26.489286
# Unit test for method bind of class Task
def test_Task_bind():
    first_task = Task.of(5)
    second_task = Task.of(5)
    third_task = Task.of(5)

    tasks = [first_task, second_task, third_task]

    task = (
        tasks[0]
        .map(lambda v: v * 2)
        .bind(lambda v: tasks[1].map(lambda v: v * 2))
        .bind(lambda v: tasks[2].map(lambda v: v * 2))
    )

    def fork(reject, resolve):
        assert reject is None
        assert resolve(task) == 40

    assert fork(None, None) is None

# Generated at 2022-06-24 00:38:31.468100
# Unit test for method map of class Task
def test_Task_map():
    fn = lambda x: x + 10
    resolve = lambda v: v
    reject = lambda e: e

    # map function body,
    # without calling resolve and reject function
    expected = lambda r, s: Task.of(10).fork(r, lambda arg: s(fn(arg)))

    actual = Task.of(10).map(fn)
    assert expected.__name__ == actual.fork.__name__



# Generated at 2022-06-24 00:38:38.496414
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """

    def setup_function(function):
        """
        Setup function
        """
        Task = task.Task

        def resolve(x):
            """
            Resolve function
            """
            return x

        def reject(x):
            """
            Reject function
            """
            return x

        task1 = Task(lambda reject, resolve: resolve(1))
        task2 = Task(lambda reject, resolve: resolve(2))

        task1.fork(reject, resolve)
        task2.fork(reject, resolve)

    def teardown_function(function):
        """
        Teardown function
        """
        pass

    def test_Task_map_positive():
        """
        Test for Task map function with positive argument
        """
        Task = task

# Generated at 2022-06-24 00:38:42.662156
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda a, b: a(1)).fork(
        lambda v1: v1,
        lambda _: 0
    ) == 1

    assert Task(lambda a, b: b(1)).fork(
        lambda _: 0,
        lambda v2: v2
    ) == 1

# Generated at 2022-06-24 00:38:53.520813
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind method of Task class.
    """
    def map_task(value):
        """
        Function, which return Task

        :param value: value to store in returned Task
        :type value: int
        :returns: Task with stored value
        :rtype: Task[int]
        """
        return Task.of(value + 1)

    def double(value):
        """
        Function to mapping Task value

        :param value: value to double
        :type value: int
        :returns: doubled value
        :rtype: int
        """
        return value * 2

    result = Task.of(0).bind(map_task).map(double).fork(identity, identity)

    assert result == 2


# Generated at 2022-06-24 00:38:56.765323
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for function Task.map.
    """
    print("test for function map")
    task = Task.of(42).map(lambda n: n + 1)
    assert task.fork(lambda n: n, lambda m: m) == 43


# Generated at 2022-06-24 00:38:59.024697
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x + 2).fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-24 00:39:08.861600
# Unit test for method bind of class Task
def test_Task_bind():
    def to_list(data):
        """
        Function returns list from input.

        :param data: input data
        :type data: A
        :returns: list from input data
        :rtype: [A]
        """
        return [data]

    def to_dict(data):
        """
        Function returns dictionary from input.

        :param data: input data
        :type data: A
        :returns: dictionary from input data
        :rtype: {'data': A}
        """
        return {'data': data}

    def add(data):
        """
        Function returns sum of input data and 7.

        :param data: input data
        :type data: Int
        :returns: sum of input data and 7
        :rtype: Int
        """
        return data + 7


# Generated at 2022-06-24 00:39:13.599361
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda _, resolve: resolve(20)).bind(
        lambda value: Task(lambda _, resolve: resolve(value + 10))
    ).fork(None, None) == 30


# Generated at 2022-06-24 00:39:16.339467
# Unit test for constructor of class Task
def test_Task():
    assert Task(mocked_fork).__dict__ == {'fork': mocked_fork}


# Generated at 2022-06-24 00:39:22.193121
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task for two different task: Task of
    and Task.reject
    """

    task1 = Task.of(2)
    task2 = Task.reject("rejected")

    assert isinstance(task1.bind(lambda x: Task.of(x ** 2)), Task)
    assert isinstance(task2.bind(lambda x: Task.of(x ** 2)), Task)

    res1 = task1.bind(lambda x: Task.of(x ** 2))
    res2 = task2.bind(lambda x: Task.of(x ** 2))

    assert res1.fork(lambda x: None, lambda y: y) == 4
    assert res2.fork(lambda x: x, lambda y: None) == "rejected"


# Generated at 2022-06-24 00:39:27.095459
# Unit test for method map of class Task
def test_Task_map():
    def callback(reject, resolve):
        resolve(4)

    # Create test Task
    task = Task(callback)

    # Call map
    fn = lambda arg: arg + 1
    result = task.map(fn)

    assert result.fork(
        lambda arg: None,
        lambda arg: arg
    ) == 5


# Generated at 2022-06-24 00:39:29.035596
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a):
        return Task.of(a + 1)

    def result(_, resolve):
        resolve(10)

    assert Task(result).bind(add).fork(lambda err: err, lambda value: value) == 11


# Generated at 2022-06-24 00:39:30.496352
# Unit test for constructor of class Task
def test_Task():
    assert Task
    assert Task(lambda _, __: None)


# Generated at 2022-06-24 00:39:33.452822
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind method of class Task
    Assert that Task(reject, resolve) raise resolve with 42.
    """
    assert Task(lambda reject, resolve: 42).bind(lambda x: Task.of(x)).fork(lambda x: x, lambda x: x) == 42


# Generated at 2022-06-24 00:39:36.168107
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(None, lambda x: x) == 1
    assert Task.reject('some error').fork(lambda x: x, None) == 'some error'
    assert Task(lambda reject, resolve: resolve('some result')).fork(None, lambda x: x) == 'some result'
    pass


# Generated at 2022-06-24 00:39:40.391698
# Unit test for method bind of class Task
def test_Task_bind():
    def reject_mapper(value):
        """ Mapper for test Task.bind method """
        return Task.reject(value)

    # Create task with reject mapper
    task = Task.of(1).bind(reject_mapper)
    # Assert that task is rejected.
    assert not task.fork(lambda _: True, lambda _: False)


# Generated at 2022-06-24 00:39:44.574645
# Unit test for constructor of class Task
def test_Task():
    called1 = False
    called2 = False
    called3 = False
    called4 = False

    task = Task(
        lambda reject, resolve: (
            called1, called2, called3, called4,
            resolve(1),
            reject(2),
            called1
        )
    )


# Generated at 2022-06-24 00:39:49.945028
# Unit test for method map of class Task
def test_Task_map():
    def task_success(resolve):
        return resolve("1")

    def task_fail(reject):
        return reject("2")

    def inc(value):
        return int(value) + 1

    result = (
        Task.of("2")
            .map(inc)
            .fork(
                lambda arg: "failure",
                lambda arg: "success")
    )
    assert (result == "success")

    result = (
        Task.reject("2")
            .map(inc)
            .fork(
                lambda arg: "failure",
                lambda arg: "success")
    )
    assert (result == "failure")


# Generated at 2022-06-24 00:39:54.265504
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    assert callable(task.fork)


# Generated at 2022-06-24 00:40:05.208075
# Unit test for method map of class Task
def test_Task_map():
    from tddmonad import Task

    def square(value):
        if value == 0: return 0
        return value * value

    # It should be resolved with 5
    assert 0 == Task.of(0).map(square).value

    # It should be resolved with 25
    assert 25 == Task.of(5).map(square).value

    # It should be resolved with 'hello world'
    assert 'hello world' == Task.of({
        'hello': Task.of(['hello']),
        'world': Task.of(['world', 'earth'])
    }).map(lambda data: ' '.join(data['hello']) + ' ' + ' '.join(data['world'])).value

    # It should be resolved with 25
    assert 25 == Task.of(5).map(lambda value: square(value)).value

    #

# Generated at 2022-06-24 00:40:07.736788
# Unit test for method map of class Task
def test_Task_map():
    def method(value):
        return value + 1

    task = Task.of(1)
    task = task.map(method)
    assert task.fork(lambda _: None, lambda x: x) == 2


# Generated at 2022-06-24 00:40:12.169952
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for correct work of method bind of class Task
    """
    assert Task.of(1).bind(lambda x: Task.of(x+1)) == Task.of(2)


# Generated at 2022-06-24 00:40:15.552045
# Unit test for method map of class Task
def test_Task_map():
    def add1(value):
        return value + 1

    task = Task.of(1)

    assert task.map(add1).fork(None, lambda task_value: task_value) == 2



# Generated at 2022-06-24 00:40:17.652139
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(None, lambda v: v) == 1
    assert Task.reject(1).fork(lambda v: v, None) == 1


# Generated at 2022-06-24 00:40:23.172717
# Unit test for method bind of class Task
def test_Task_bind():
    from py_monad_experiments import Maybe
    def mul(a):
        return a * 2

    def div(a):
        return a / 2

    def bound_mul_div(a):
        return Task.of(a).map(mul).map(div)

    assert Task.of(2).bind(bound_mul_div).fork(None, lambda x: x) == 1
    assert Task.of(None).bind(bound_mul_div).fork(lambda x: x, None) == Maybe.Nothing



# Generated at 2022-06-24 00:40:32.823557
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.reject(1).bind(lambda x: Task.of(1)).fork(lambda x: x, lambda y: y) == 1
    assert Task.reject(1).bind(lambda x: Task.reject(1)).fork(lambda x: x, lambda y: y) == 1
    assert Task.of(1).bind(lambda x: Task.reject(1)).fork(lambda x: x, lambda y: y) == 1
    assert Task.of(1).bind(lambda x: Task.of(1)).fork(lambda x: x, lambda y: y) == 1


# Generated at 2022-06-24 00:40:36.044888
# Unit test for constructor of class Task

# Generated at 2022-06-24 00:40:39.065625
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task.
    """
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(lambda err: err, lambda res: res) == 2


# Generated at 2022-06-24 00:40:43.327720
# Unit test for constructor of class Task
def test_Task():
    """Test constructor of class Task"""
    def f(reject, resolve):
        resolve(1)

    task = Task(f)
    assert task.fork == f


# Generated at 2022-06-24 00:40:48.758606
# Unit test for method bind of class Task

# Generated at 2022-06-24 00:40:54.202178
# Unit test for constructor of class Task
def test_Task():
    # Function run on right execution
    def _resolve(value):
        assert value == 1
        return value

    # Function run on wrong execution
    def _reject(value):
        assert value == 2
        return value

    # Function to call during fork
    def fork(_reject, _resolve):
        _resolve(1)
        _reject(2)
        return

    task = Task(fork)
    assert task.fork(_reject, _resolve) == 1


# Generated at 2022-06-24 00:41:00.075418
# Unit test for method bind of class Task
def test_Task_bind():

    def fork(reject, resolve):
        resolve(1)

    def fn(arg):
        return Task.reject(arg)

    assert Task(fork).bind(fn).fork(
        lambda num: 'reject',
        lambda num: 'resolve'
    ) == 'reject'


# Generated at 2022-06-24 00:41:03.189126
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(4).bind(lambda value: Task.of(value + 10))
    assert isinstance(task, Task)
    assert task.fork(lambda err: None, lambda value: value == 14)


# Generated at 2022-06-24 00:41:10.249014
# Unit test for method map of class Task
def test_Task_map():
    """
    Test that map function of Task work as expected.
    """
    # Test example
    task = Task.of("test")
    task = task.map(lambda arg: arg)
    assert task.fork(None, None) == None

    # Test that i can not change value of resolvde attribute of Task
    task = Task.of("test")
    task = task.map(lambda arg: arg)
    assert task.fork(None, None) == None

    task = task.map(lambda arg: arg)
    assert task.fork(None, None) == None


# Generated at 2022-06-24 00:41:18.544795
# Unit test for method bind of class Task
def test_Task_bind():
    def task_reject(value):
        Task.reject(value.upper())

    def task_of_value(value):
        return Task.of(value.lower())

    # call task_reject
    assert Task.reject('test').bind(task_reject).fork(
        lambda v: v,
        lambda v: None
    ) == 'TEST'

    # call task_of_value
    assert Task.of('test').bind(task_of_value).fork(
        lambda v: None,
        lambda v: v
    ) == 'test'

# Generated at 2022-06-24 00:41:22.611274
# Unit test for constructor of class Task
def test_Task():
    def task_fork(reject, resolve):
        reject(1)
        resolve(2)


# Generated at 2022-06-24 00:41:26.559046
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(1))
    assert task.fork(_, resolve) == 1

# Unit test of of function in Task

# Generated at 2022-06-24 00:41:32.616655
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test task value and it's handler
    """
    def get_called_result(called):
        return called[0] if len(called) > 0 else None

    def check_behavior(value, expected, error_case=False):
        called = []

        def fork(reject, resolve):
            if error_case:
                reject(value)
            else:
                resolve(value)

        def handler(arg):
            called.append(arg)

        task = Task(fork)
        if expected is not None:
            task.bind(handler)

        assert get_called_result(called) == expected

    check_behavior(42, 42)
    check_behavior(42, 42)
    check_behavior(None, None)
    check_behavior('42', '42')

# Generated at 2022-06-24 00:41:39.267258
# Unit test for constructor of class Task
def test_Task():
    def resolve(x): return x + x
    def reject(x): return x - x
    value = 10

    task = Task(lambda reject, resolve: reject(value))
    assert task.fork(reject, resolve) == reject(value)

    task = Task(lambda reject, resolve: resolve(value))
    assert task.fork(reject, resolve) == resolve(value)
