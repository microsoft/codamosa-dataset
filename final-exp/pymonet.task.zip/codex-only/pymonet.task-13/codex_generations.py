

# Generated at 2022-06-24 00:31:34.599698
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(10)

    assert Task(fork).fork(None, lambda arg: arg) == 10

# Generated at 2022-06-24 00:31:43.269469
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Take function that return resolved Task with stored value argument.
    Bind returned Task to function that will resolve/reject to new value.

    :returns: Unit Test Result
    :rtype: TestResult
    """

    a = 10
    b = 20
    c = 30

    task_a = Task.of(a)

    bind_result = task_a.bind(lambda arg: Task.of(b + arg))
    bind_result = bind_result.bind(lambda arg: Task.of(c + arg))

    def on_accept(result):
        return result == (b + a + c)

    def on_reject(error):
        return False

    return bind_result.fork(on_reject, on_accept)


# Generated at 2022-06-24 00:31:52.404149
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for Task class bind method.

    :returns: None
    :rtype: None
    """
    def resolve(value='?'):
        return Task.of('Task -> ' + value)
    def reject(value='!'):
        return Task.reject('Task -> ' + value)

    def method_of_Task():
        return Task.of('value')

    function_of_Task = lambda: Task.of('value')

    test_passed = True

    # Test with value -> resolved Task
    test_passed = test_passed and Task.of('value').bind(resolve).fork(identity, identity) == 'Task -> value'
    test_passed = test_passed and Task.of('value').bind(reject).fork(identity, identity) == 'Task -> !'

   

# Generated at 2022-06-24 00:31:56.114984
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value)

    assert Task.of('test value').bind(fn).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 'test value'



# Generated at 2022-06-24 00:32:00.351959
# Unit test for method map of class Task
def test_Task_map():
    def resolve(arg):
        print(arg)

    def reject(arg):
        print(arg)

    def fn(x):
        return x + 1

    Task(lambda reject, resolve: resolve(1)) \
        .map(fn) \
        .fork(reject, resolve)


# Generated at 2022-06-24 00:32:02.188087
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(lambda _: None, lambda value: value()) == 2


# Generated at 2022-06-24 00:32:07.630761
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(5)
    tpass = None

    task.map(lambda value: tpass is None and value == 5)

    task = Task.reject(5)
    tpass = None

    task.map(lambda value: tpass is None and value == 5)

test_Task_map()

# Generated at 2022-06-24 00:32:12.390122
# Unit test for method map of class Task

# Generated at 2022-06-24 00:32:15.552736
# Unit test for constructor of class Task
def test_Task():
    assert True == Task(lambda _, resolve: resolve(True)).fork(lambda _: False, lambda _: True)


# Generated at 2022-06-24 00:32:20.149214
# Unit test for method bind of class Task
def test_Task_bind():
    from unittest import TestCase
    from unittest.mock import Mock

    class MockTest(TestCase):
        """
        Helper for testing Task.
        """

        def _check(self, value, fn):
            """
            :param value: value for Task
            :type value: Any
            :param fn: function for Task
            :type fn: Function(resolve, reject) -> Any
            """
            fork = Mock()
            task1 = Task(fork)
            task2 = task1.bind(value)

            task1.fork(value, value)

            self.assertTrue(fork.called)
            fork.assert_called_once_with(value, value)

            fork.reset_mock()

            task2.fork(value, value)

            self.assertTrue(fork.called)
            fork

# Generated at 2022-06-24 00:32:23.248533
# Unit test for constructor of class Task
def test_Task():
    result = [0]
    task = Task(lambda _, resolve: result.append(1))
    task.fork(lambda _: _, lambda _: _)
    assert result == [0, 1]


# Generated at 2022-06-24 00:32:29.176962
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        return Task.of(value)

    def reject(value):
        return Task.reject(value)

    task = resolve(5).bind(lambda v: v*v)
    assert task.fork(reject, resolve) == resolve(25).fork(reject, resolve)
    assert task.fork(reject, reject) == resolve(25).fork(reject, reject)


# Generated at 2022-06-24 00:32:35.114696
# Unit test for constructor of class Task
def test_Task():
    test_resolve = Task(lambda reject, resolve: resolve(42))
    assert test_resolve.fork(lambda x: x, lambda x: x) == 42

    test_reject = Task(lambda reject, resolve: reject(42))
    assert test_reject.fork(lambda x: x, lambda x: x) == 42


# Generated at 2022-06-24 00:32:41.185529
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map
    """
    task = Task.of(2)
    task = task.map(lambda value: value + 3)

    # call fork of Task and get result
    result = task.fork(None, lambda value: value)

    assert result == 5


# Generated at 2022-06-24 00:32:44.046769
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x * x).fork(
        lambda x: x,
        lambda x: x
    ) == 4


# Generated at 2022-06-24 00:32:46.593028
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve(1337)

    task = Task(fork)
    assert callable(task.fork)


# Generated at 2022-06-24 00:32:52.197505
# Unit test for method map of class Task
def test_Task_map():
    def add_one_and_two(value):
        return value + 1 + 2

    def add_one(value):
        return value + 1

    # Resolved Task
    task = Task.of(2)
    task_1 = task.map(add_one_and_two)
    task_2 = task_1.map(add_one)

    assert(task_2.fork(None, lambda arg: arg) == 6)
    

# Generated at 2022-06-24 00:32:58.104158
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind
    """

    def add_one(value):
        """
        Return new Task, which wraps result of adding one to value argument.

        :param value: value for add 1.
        :type value: Number
        :returns: New Task which wraps vale of adding one to value argument.
        :rtype: Task[Number]
        """
        new_value = value + 1
        return Task.of(new_value)

    task = Task.of(2).bind(add_one)
    # assertion first, because method bind takes lazy evaluation.
    assert 4 == task.fork(raise_error, get_value)

# Generated at 2022-06-24 00:33:05.337152
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        if value % 2:
            return Task.reject(value)

        return Task.of(value * 2)

    t1 = Task.of(1)
    # Reject
    assert t1.bind(mapper).fork(_, __) == 1

    t2 = Task.of(2)
    assert t2.bind(mapper).fork(__, _) == 4

    t3 = Task.of(3)
    assert t3.bind(mapper).fork(_, __) == 3


# Generated at 2022-06-24 00:33:12.456432
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(4).map(lambda x: x * 2).fork(None, lambda x: x) == 8
    assert Task.of(4).map(lambda x: x * 3).fork(None, lambda x: x) == 12
    assert Task.of(4).map(lambda x: x * 5).fork(None, lambda x: x) == 20

test_Task_map()


# Generated at 2022-06-24 00:33:17.048496
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(1)\
        .bind(lambda val: Task.of(val + 1))\
        .bind(lambda val: Task.reject(val))\
        .bind(lambda val: Task.of(val - 1))\
        .fork(
            lambda val: print(f'Reject with arg {val}'),
            lambda val: print(f'Resolve with arg {val}')
        )
    # => Reject with arg 2


# Generated at 2022-06-24 00:33:21.925090
# Unit test for constructor of class Task
def test_Task():
    """
    Task should return instance of class Task with correct
    attribute fork.
    """
    def fork(reject, resolve):
        resolve(42)

    task = Task(fork)
    expected = 42
    actual = task.fork(lambda _: None, lambda arg: arg)

    assert actual == expected, \
        "Task should return instance of class Task with correct attribute " \
        "fork, but got: %s" % actual


# Generated at 2022-06-24 00:33:27.352494
# Unit test for method bind of class Task
def test_Task_bind():
    def wait_and_return(value, delay=0.1):
        time.sleep(delay)
        return Task.of(value)

    def print_result():
        print(task_test.fork(lambda _: None, print))
        another_task.fork(lambda _: None, print)

    task_test = Task.of(42)
    another_task = task_test.bind(lambda value: wait_and_return(value + 1))

    threading.Thread(target=print_result).start()
    task_test.bind(lambda value: wait_and_return(value + 1)).fork(lambda _: None, print)



# Generated at 2022-06-24 00:33:35.471180
# Unit test for method bind of class Task
def test_Task_bind():
    """
    :returns: Unit test for method bind of class Task
    :rtype: None
    """
    def mapper(value):
        """
        Return Task with value + 1
        :param value: number
        :type value: Integer
        :returns: Task with value + 1
        :rtype: Task[Integer]
        """
        return Task.of(value + 1)

    assert Task.of(1).bind(mapper).fork(None, lambda value: value) == 2


# Generated at 2022-06-24 00:33:42.504989
# Unit test for constructor of class Task
def test_Task():
    value = 'value'

    # Task of value
    task = Task.of(value)
    assert isinstance(task, Task)
    assert task.fork(None, None) == value

    # Task reject value
    task = Task.reject(value)
    assert isinstance(task, Task)
    assert task.fork(None, None) == value


# Generated at 2022-06-24 00:33:46.074136
# Unit test for method map of class Task
def test_Task_map():
    """
    Test case for method map of class Task
    """
    assert Task.of(2).map(lambda x: x + 1).fork(None, lambda x: x) == 3


# Generated at 2022-06-24 00:33:51.572975
# Unit test for method bind of class Task
def test_Task_bind():
    def paje(name):
        return Task.of('paje of ' + name)

    # make an Task
    task = Task.of('david')
    # bind the string with a function
    new_task = task.bind(paje)
    # fork
    _, result = new_task.fork()

    assert result == 'paje of david'


# Generated at 2022-06-24 00:34:03.277708
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task bind method is a way to chain Task.
    """

    def succ(value):
        print(value)
        return Task.of('OK')

    def err(value):
        print(value)
        return Task.reject('FAIL')

    def twice(value):
        print('in twice ' + value)
        return Task.of(value * 2)

    def twice_fail(value):
        print(value)
        return Task.reject('FAIL')

    Task.of(0) \
        .bind(succ) \
        .bind(twice) \
        .bind(succ) \
        .fork(err, succ)

    Task.of(0) \
        .bind(succ) \
        .bind(twice_fail) \
        .bind(succ)

# Generated at 2022-06-24 00:34:08.483410
# Unit test for method map of class Task
def test_Task_map():
    def resolve_reject(reject, resolve):
        return resolve('foo')

    task = Task(resolve_reject)
    task_mapper = task.map(lambda arg: arg + arg)
    assert task_mapper.fork(lambda arg: None, lambda arg: arg) == 'foofoo'


# Generated at 2022-06-24 00:34:18.475010
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(7).bind(lambda x: Task.of(x + 1)).fork(
        lambda x: False,
        lambda x: x == 8
    )

    assert Task.of(None).bind(lambda x: Task.of(x + 1)).fork(
        lambda x: False,
        lambda x: x == 1
    )

    assert Task.of(7).bind(lambda x: Task.reject(x + 1)).fork(
        lambda x: x == 8,
        lambda x: False
    )

    assert Task.reject(7).bind(lambda x: Task.of(x + 1)).fork(
        lambda x: x == 7,
        lambda x: False
    )

# Generated at 2022-06-24 00:34:26.342355
# Unit test for method bind of class Task
def test_Task_bind():
    # First success task
    success1 = Task.of(0)
    task = success1.bind(lambda x: Task.of(x + 1)).bind(lambda x: Task.of(x * 100))
    assert 42 == task.fork(lambda _: -1, lambda x: x)

    # First failure task
    failure1 = Task.reject('')
    task2 = failure1.bind(lambda _: Task.of(42))
    assert -1 == task2.fork(lambda _: -1, lambda _: 0)

    # Second failure task
    failure2 = Task.of(0)
    task3 = failure2.bind(lambda x: Task.reject(x + 1)).bind(lambda x: Task.of(x * 100))

# Generated at 2022-06-24 00:34:33.219245
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(arg):
        return arg

    def test_reject(arg):
        raise AssertionError('rejected Task')

    Task.of(1).bind(lambda arg: Task.of(test_function(arg))).fork(test_reject, assert_equal(test_function(1)))
    Task.reject(1).bind(lambda arg: Task.of(test_function(arg))).fork(assert_equal(1), test_reject)


# Generated at 2022-06-24 00:34:37.452886
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        assert type(reject) is Function
        assert type(resolve) is Function
        reject("test")

    task = Task(fork)
    assert task.fork(
        lambda arg: print("reject:", arg),
        lambda arg: print("resolve:", arg)
    ) is None


# Generated at 2022-06-24 00:34:47.931950
# Unit test for constructor of class Task
def test_Task():
    """
    Task is a data-type for handle execution of functions (in lazy way),
    transform results of this function and handle errors.
    """
    # Check create of class
    example_func = lambda _, resolve: resolve('example_resolve')
    task = Task(example_func)
    assert task.fork == example_func

    # Check create of class with map
    example_resolve = 'example_resolve'
    mapped_fn = lambda arg: arg + '_mapped'
    task = Task.of(example_resolve).map(mapped_fn)
    assert task.fork(
        lambda arg: 'example_reject',
        lambda arg: arg
    ) == 'example_resolve_mapped'

    # Check create of class with bind

# Generated at 2022-06-24 00:34:58.229508
# Unit test for method bind of class Task
def test_Task_bind():
    def fn_b(val):
        return Task.of(val + 1)

    def f(val):
        return Task.of(val + 2)

    # Test with function f
    val = 1
    first_task = Task.of(val)

    # result = first_task.fork(lambda x: x, lambda x: x)
    # assert result == val
    # result = first_task.fork(lambda x: x, lambda x: x * 2)
    # assert result == val * 2
    result = first_task.bind(f).fork(lambda x: x, lambda x: x * 2)
    assert result == val * 2 + 4

    first_task = Task.of(val)
    result = first_task.bind(fn_b).fork(lambda x: x, lambda x: x * 2)
   

# Generated at 2022-06-24 00:35:02.690564
# Unit test for method map of class Task
def test_Task_map():
    """
    Test on correctness of method map of class Task.
    """
    multiplier = lambda arg: arg * 2

    task = Task.of(2)
    future = task.map(multiplier)
    result = future.fork(lambda _: None, lambda arg: arg)
    assert result == 4, 'Task.map test failed'


test_Task_map()


# Generated at 2022-06-24 00:35:08.803296
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda val: val + 1).fork.__name__ == 'resolved'
    assert Task.of(1).map(lambda val: val + 1).fork(None, None) == 2
    assert Task.of(1).map(lambda val: Task.of(val + 1)).fork.__name__ == 'resolved'
    assert Task.of(1).map(lambda val: Task.of(val + 1)).fork(None, None) == 2


# Generated at 2022-06-24 00:35:14.234175
# Unit test for method bind of class Task
def test_Task_bind():
    task_of_3 = Task.of(3)

    def plus1(value):
        return value + 1

    task_of_4 = task_of_3.bind(Task.of).map(plus1)
    assert task_of_4.fork(lambda preject: None, lambda resolve: resolve) == 4


# Generated at 2022-06-24 00:35:23.579540
# Unit test for method bind of class Task
def test_Task_bind():
    def mock_reject(arg):
        data['reject'] = True
        data['reject_value'] = arg

    def mock_resolve(arg):
        data['resolve'] = True
        data['resolve_value'] = arg

    data = {
        'reject': False,
        'reject_value': None,
        'resolve': False,
        'resolve_value': None
    }

    def fork(reject, resolve):
        return resolve(43)

    def mapped(value):
        return Task.of(value * 2)

    Task(fork).bind(mapped).fork(mock_reject, mock_resolve)

    assert data['resolve'] is True
    assert data['resolve_value'] == 86


# Generated at 2022-06-24 00:35:26.800877
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 3).fork(lambda x: None, lambda x: x) == 4
    assert Task.of(1).map(lambda x: x).fork(lambda x: None, lambda x: x) == 1
    assert Task.of(1).map(lambda x: 'string').fork(lambda x: None, lambda x: x) == 'string'


# Generated at 2022-06-24 00:35:31.953548
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test that check the correctness of Task.bind method.
    """
    resolve = Task.of(1)
    reject = Task.reject(1)
    fn = lambda x: Task.of(x + 1)

    assert resolve.bind(fn).fork(lambda x: x, lambda x: x) == 2
    assert reject.bind(fn).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-24 00:35:36.831786
# Unit test for constructor of class Task
def test_Task():
    Task.of(1).fork(lambda reject: None, lambda resolve: eq_(1, resolve))
    Task.reject(1).fork(lambda reject: eq_(1, reject), lambda resolve: None)



# Generated at 2022-06-24 00:35:40.689583
# Unit test for constructor of class Task
def test_Task():
    def test(resolve, reject):
        assert Task(lambda _, resolve: resolve(123)).fork(_, resolve) == 123
        assert Task(lambda reject, _: reject(123)).fork(reject, _) == 123

    Task(test).fork(_, _)


# Generated at 2022-06-24 00:35:43.656469
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(ArithmeticError())
    def raise_error(error):
        raise error
    task.bind(lambda error: Task.reject(raise_error(error)))

# Generated at 2022-06-24 00:35:53.279463
# Unit test for method map of class Task
def test_Task_map():
    """
    .. code-block:: python

       Task.of(5).map(lambda v: v + 1).fork(
           lambda r: reject(r),
           lambda r: assertEqual(r, 6)
       )

       Task.reject(5).map(lambda v: v + 1).fork(
           lambda r: assertEqual(r, 5),
           lambda r: reject(r)
       )
    """
    Task.of(5).map(lambda v: v + 1).fork(
        lambda r: reject(r),
        lambda r: assertEqual(r, 6)
    )

    Task.reject(5).map(lambda v: v + 1).fork(
        lambda r: assertEqual(r, 5),
        lambda r: reject(r)
    )


# Generated at 2022-06-24 00:35:59.297287
# Unit test for method map of class Task
def test_Task_map():
    def add(num):
        return num + 1

    def mul(num):
        return num * 2

    def double_wrapper(num):
        return Task.of(mul(add(num)))

    assert Task.of(5).map(add).map(mul).fork(lambda err: err, lambda res: res) == 14
    assert Task.of(100)\
        .map(double_wrapper)\
        .map(add)\
        .bind(double_wrapper)\
        .fork(lambda err: err, lambda res: res) == 406


# Generated at 2022-06-24 00:36:01.231008
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return 1

    task = Task(fork)
    assert task.fork(reject, resolve) == 1


# Generated at 2022-06-24 00:36:05.903507
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of('value').bind(lambda x: Task.reject(x)).fork(lambda x: 'rejected', lambda _: 'resolved')

    assert result == 'rejected'



# Generated at 2022-06-24 00:36:10.193164
# Unit test for method bind of class Task
def test_Task_bind():
    fake_reject = lambda x: x
    fake_resolve = lambda x: x

    identity = lambda x: x
    identity_task = Task.of(identity)

    result = Task.of(42).bind(identity_task)
    assert result.fork(fake_reject, fake_resolve) == 42


# Generated at 2022-06-24 00:36:12.602965
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve('Task'))
    assert task.fork(
        lambda error: error,
        lambda value: value
    ) == 'Task', 'Task constructor failed'



# Generated at 2022-06-24 00:36:14.761009
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        pass

    assert Task(fork) == Task(fork)
    assert Task(fork) is not Task(fork)


# Generated at 2022-06-24 00:36:20.194025
# Unit test for method bind of class Task
def test_Task_bind():
    TYPE_CHECK = typecheck.TypeCheck('test_bind')
    TYPE_CHECK.set_input(value=Type(int))
    TYPE_CHECK.set_output(value=Type(int))

    @TYPE_CHECK
    def add_one(value):
        return value + 1

    def call_add_one(value):
        return Task.of(value).bind(add_one)

    assert call_add_one(1).fork(lambda a: a, lambda a: a) == 2
    assert call_add_one(2).fork(lambda a: a, lambda a: a) == 3



# Generated at 2022-06-24 00:36:23.917355
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, x: x(1)).fork(None, lambda x: x) == 1
    assert Task(lambda _, x: x(1)).fork(lambda _: 0, lambda x: x) == 0
    assert Task.of(1).fork(None, lambda x: x) == 1


# Generated at 2022-06-24 00:36:34.031165
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test map result.
    """
    fork = lambda reject, resolve: reject('error')
    fork_resolve = lambda reject, resolve: resolve(1)
    result = Task(fork)
    result_resolve = Task(fork_resolve)

    assert unpack(result.bind(lambda value: result_resolve)) == 1
    assert unpack(result_resolve.bind(lambda value: result)) == 'error'

    fork_map = lambda reject, resolve: resolve(1)
    result_map = Task(fork_map)

    def mapper(value):
        """
        Test mapper.
        """
        return value + 1

    assert unpack(result_map.bind(lambda _: result_map.map(mapper))) == 2


# Generated at 2022-06-24 00:36:35.303635
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(10))
    assert task.fork(None, None) == 10


# Generated at 2022-06-24 00:36:41.043870
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def result(res):
        return res == 2

    task = Task.of('1').map(add)
    assert(isinstance(task, Task) and result(task.fork.__closure__[0].cell_contents(None, lambda x: x)))

    task = Task.reject(1).map(add)
    assert result(task.fork.__closure__[0].cell_contents(lambda x: x, None))


# Generated at 2022-06-24 00:36:42.471551
# Unit test for constructor of class Task
def test_Task():
    task = Task(None)
    assert task.fork == None


# Generated at 2022-06-24 00:36:45.796708
# Unit test for constructor of class Task
def test_Task():
    fork = lambda reject, resolve: resolve(5)
    task = Task(fork)
    assert task.fork(lambda a: print('Rejected: {0}'.format(a)), lambda b: print('Resolved: {0}'.format(b))) == 5

# Generated at 2022-06-24 00:36:55.380500
# Unit test for method map of class Task
def test_Task_map():
    def callback(fn, result):
        if result == 3:
            return Task.of(result)
        return Task.reject(result)

    mapper = lambda x: x * 2

    task_of_callback = Task(lambda _, resolve: resolve(2)).map(mapper)
    assert task_of_callback.fork(lambda arg: arg, lambda arg: arg) == 4

    task_reject_callback = Task(lambda _, resolve: resolve(2)).map(mapper).bind(callback)
    assert task_reject_callback.fork(lambda arg: arg, lambda arg: arg) == 3

    task_reject_callback = Task(lambda _, resolve: resolve(3)).map(mapper).bind(callback)
    assert task_reject_callback.fork(lambda arg: arg, lambda arg: arg) == 3

# Generated at 2022-06-24 00:36:59.173272
# Unit test for constructor of class Task
def test_Task():
    fork = lambda reject, resolve: resolve(1)
    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-24 00:37:01.914887
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(5).map(lambda num: num + 2).fork(
        lambda _: None,
        lambda num: num == 7
    )



# Generated at 2022-06-24 00:37:09.026789
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(5).map(lambda x: x + 1).fork(
        lambda reject: None,
        lambda resolve: resolve
    ) == 6

    assert Task.of(5).map(lambda x: x + 1).map(lambda y: y - 1).fork(
        lambda reject: None,
        lambda resolve: resolve
    ) == 5


# Generated at 2022-06-24 00:37:14.844523
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(1).map(lambda x: x * 2)
    a = result.fork(lambda x: x + 2, lambda x: x - 2)
    assert a == 0

    result = Task.of(1).map(lambda x: x).map(lambda x: x * 2)
    a = result.fork(lambda x: x + 2, lambda x: x - 2)
    assert a == 0

    result = Task.of(1).map(lambda x: x * 2).map(lambda x: x * 2)
    a = result.fork(lambda x: x + 2, lambda x: x - 2)
    assert a == 2

    result = Task.reject(1).map(lambda x: x + 2)
    a = result.fork(lambda x: x - 2, lambda x: x + 2)


# Generated at 2022-06-24 00:37:21.133477
# Unit test for method bind of class Task
def test_Task_bind():
    def idle_fn(value):
        if value > 5:
            return Task.reject("value > 5")
        return Task.of(value)

    assert Task(lambda o, e: e(1)).bind(idle_fn).fork(lambda o: o, lambda e: e) == 1
    assert Task(lambda o, e: e(6)).bind(idle_fn).fork(lambda o: o, lambda e: e) == "value > 5"


# Generated at 2022-06-24 00:37:32.475817
# Unit test for method bind of class Task
def test_Task_bind():

    def double(value):
        """
        Double argument.

        :param value: value for double
        :type value: int
        :returns: doubled value
        :rtype: int
        """
        return value * 2

    # Task with stored number
    stored_number = Task.of(2)

    # Doubled stored value in Task
    doubled = stored_number.map(double)

    # Task with stored number
    stored_number_again = Task.of(2)

    # Doubled stored value in Task
    doubled_again = stored_number_again.bind(lambda value: Task.of(value * 2))

    assert doubled.fork(lambda _: None, lambda value: value == 4)
    assert doubled_again.fork(lambda _: None, lambda value: value == 4)


# Generated at 2022-06-24 00:37:34.504390
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return (reject, resolve)

    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-24 00:37:38.190977
# Unit test for method bind of class Task
def test_Task_bind():
    """ Unit test for method bind of class Task """
    fork = lambda _, resolve: resolve(1)
    task_one = Task(fork)
    task_two = task_one.bind(lambda arg: Task.of(arg + 1))
    assert task_two.fork(None, lambda arg: arg) == 2


# Generated at 2022-06-24 00:37:43.348977
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        print('Call task')
        return Task.of(value + 1)

    cancel = Task.reject(2)
    task = Task.of(3)
    task.fork(
        lambda arg: print('Reject {}'.format(arg)),
        lambda arg: print('Resolve {}'.format(arg))
    )
    task = task.bind(fn)
    cancel = cancel.bind(fn)
    task.fork(
        lambda arg: print('Reject {}'.format(arg)),
        lambda arg: print('Resolve {}'.format(arg))
    )
    cancel.fork(
        lambda arg: print('Reject {}'.format(arg)),
        lambda arg: print('Resolve {}'.format(arg))
    )


# Generated at 2022-06-24 00:37:49.908283
# Unit test for constructor of class Task
def test_Task():
    def task_fork(reject, resolve):
        resolve('task_fork')

    task = Task(task_fork)

    assert callable(task.fork)
    assert isinstance(task.fork(lambda _: _, lambda _: _), object)
    assert isinstance(task.fork(lambda _: _, lambda _: _), str)
    assert task.fork(lambda _: _, lambda _: _) == 'task_fork'


# Generated at 2022-06-24 00:37:56.867945
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """
    def resolve(arg):
        return arg

    def reject(arg):
        return arg

    def add_one(val):
        return val + 1

    def add_three(task):
        return task.map(add_one).map(add_one).map(add_one)

    assert add_three(Task.of(0)).fork(reject, resolve) == 3
    assert add_three(Task.of(0)).map(lambda arg: arg + 2).fork(reject, resolve) == 5
    assert add_three(Task.of(100)).map(lambda arg: arg * 3).fork(reject, resolve) == 300
    assert add_three(Task.reject(0)).fork(reject, resolve) == 0

# Generated at 2022-06-24 00:38:00.938848
# Unit test for method bind of class Task
def test_Task_bind():
    do_some_effect = Task(lambda reject, resolve: resolve(1))
    do_some_effect_and_then = do_some_effect.bind(
        lambda x: Task(lambda reject, resolve: resolve(x + 1)))
    assert do_some_effect_and_then.fork(None, lambda x: x) == 2

# Generated at 2022-06-24 00:38:04.275936
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(None, lambda a: a) == 1, "Fork of simple Task must return value"
    assert Task.of("Hi").fork(None, lambda a: a) == "Hi", "Fork of simple Task must return value"
    assert Task.reject("Error").fork(lambda a: a, None) == "Error", "Fork of rejected Task must return value"


# Generated at 2022-06-24 00:38:07.769693
# Unit test for method map of class Task
def test_Task_map():
    def fn1(a):
        return a * 2

    task_identity = Task.of(2)
    task_mapped = task_identity.map(fn1)
    assert task_mapped.fork(None, identity) == 4


# Generated at 2022-06-24 00:38:10.005784
# Unit test for constructor of class Task
def test_Task():
    fork = lambda _, resolve: resolve(3)
    task = Task(fork)
    assert task.fork == fork

# Unit test of static class method Task.of

# Generated at 2022-06-24 00:38:15.572455
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method.
    """
    assert Task.reject("fail").bind(lambda _: Task.reject("fail2")) == Task.reject("fail")
    assert Task.reject("error").bind(lambda _: Task.of("ok")) == Task.reject("error")
    assert Task.of("ok").bind(lambda _: Task.of("ok2")) == Task.of("ok2")


# Generated at 2022-06-24 00:38:26.059147
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.reject(1).bind(
        lambda value: Task.reject(value * 2)
    )

    assert task.fork(lambda arg: arg, None) == 2

    task = Task.reject(1).bind(
        lambda value: Task.of(value * 2)
    )

    assert task.fork(None, lambda arg: arg) == 2

    task = Task.of(1).bind(
        lambda value: Task.reject(value * 2)
    )

    assert task.fork(lambda arg: arg, None) == 2

    task = Task.of(1).bind(
        lambda value: Task.of(value * 2)
    )

    assert task.fork(None, lambda arg: arg) == 2


# Generated at 2022-06-24 00:38:28.875553
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda x: x, lambda x: x) == 1
    assert Task.reject(1).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-24 00:38:32.029063
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda _, resolve: resolve(1))
    map_task = task.map(lambda value: value + 1)
    expected = Task(lambda _, resolve: resolve(2))

    assert map_task == expected


# Generated at 2022-06-24 00:38:35.405316
# Unit test for constructor of class Task
def test_Task():
    def fork_function(reject, resolve):
        assert callable(reject)
        assert callable(resolve)
        assert reject is not resolve
        assert reject != resolve

    assert Task(fork_function).fork is not None
    assert Task(fork_function).fork is fork_function


# Generated at 2022-06-24 00:38:42.120981
# Unit test for method bind of class Task
def test_Task_bind():
    def actual_function(number):
        return Task.of(number * 2)

    def expected_function(number):
        return Task.of(number * 3)

    actual = Task.of(3).bind(actual_function)
    expected = Task.of(3).bind(actual_function).bind(expected_function)

    assert actual.fork(lambda x: x, lambda x: x) == expected.fork(lambda x: x, lambda x: x)


# Generated at 2022-06-24 00:38:45.395874
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(None, test_equal_to(2))
    assert Task.of(1).map(lambda x: x + 1).map(lambda x: x + 1).fork(None, test_equal_to(3))
    assert Task.of(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).fork(
        None, test_equal_to(4))


# Generated at 2022-06-24 00:38:48.677839
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve('test1'))
    assert task.fork(lambda a: a, lambda a: a) == 'test1'


# Generated at 2022-06-24 00:38:58.412846
# Unit test for method bind of class Task
def test_Task_bind():
    def mk_task(value):
        return Task(lambda _, resolve: resolve(value))

    add_task = Task(lambda _, resolve: resolve('add'))
    mul_task = Task(lambda _, resolve: resolve('mul'))
    div_task = Task(lambda _, resolve: resolve('div'))

    def add_or_mul(arg):
        return Task.of(arg) \
            .bind(lambda arg: add_task if arg == 'add' else mul_task)

    def add_or_mul_or_div(arg):
        return Task.of(arg) \
            .bind(lambda arg: add_task if arg == 'add' else mul_task) \
            .bind(lambda arg: add_task if arg == 'mul' else div_task)

    assert add_or

# Generated at 2022-06-24 00:39:05.174112
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda arg: arg + 2).fork(lambda _: False, lambda arg: arg == 3)
    assert Task.of(3).map(lambda arg: arg + 2).fork(lambda _: False, lambda arg: arg == 5)
    assert Task.of(4).map(lambda arg: arg + 2).fork(lambda _: False, lambda arg: arg == 6)


# Generated at 2022-06-24 00:39:06.537326
# Unit test for constructor of class Task
def test_Task():
    def fn(success, failure):
        assert False
        return success()

    task = Task(fn)
    assert callable(task.fork)


# Generated at 2022-06-24 00:39:14.106076
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a, b):
        return a + b

    def f(x):
        return Task.of(add(x, 3))

    def g(x):
        return Task.of(add(x, 4))

    def bind(x):
        return x.bind(g).bind(f)

    print(bind(Task.of(1)).fork(
        lambda arg: "error",
        lambda arg: arg,
    ))


# Generated at 2022-06-24 00:39:23.050230
# Unit test for method bind of class Task
def test_Task_bind():
    def return_reject_task(value):
        return Task.reject(value)

    def return_resolve_task(value):
        return Task.of(value)

    # resolved Task

# Generated at 2022-06-24 00:39:25.400548
# Unit test for constructor of class Task
def test_Task():
    assert Task
    assert Task.of
    assert Task.bind
    assert Task.reject
    assert Task.map


# Generated at 2022-06-24 00:39:28.452941
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(5) \
        .map(lambda value: value + 5) \
        .fork(lambda reject: reject, lambda resolve: resolve)
    assert result == 10



# Generated at 2022-06-24 00:39:35.694599
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task
    """
    def identity(n):
        return n

    def test(resolve):
        def test_bind(arg):
            return Task.of(identity(arg))

        task = Task.of(1).bind(test_bind)
        task.fork(resolve, resolve)


# Generated at 2022-06-24 00:39:38.607687
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):  # pylint: disable=unused-argument
        assert True

    task = Task(fork)
    assert task.fork(lambda _: None, lambda _: None)

# Unit test of class Task.of

# Generated at 2022-06-24 00:39:46.115134
# Unit test for constructor of class Task
def test_Task():
    # Basic task
    task = Task(lambda r, s: s(13))
    assert todo(task) == (None, 13)

    # Rejected task
    task = Task(lambda r, s: r(13))
    assert todo(task) == (13, None)

    # task of value
    task = Task.of(3)
    assert todo(task) == (None, 3)

    # Rejected task of value
    task = Task.reject(3)
    assert todo(task) == (3, None)


# Generated at 2022-06-24 00:39:50.799193
# Unit test for constructor of class Task

# Generated at 2022-06-24 00:39:55.748166
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor
    """
    assert Task(lambda _, resolve: resolve(0)).fork(lambda x: x, lambda _: 1) == 1
    assert Task(lambda reject, _: reject(0)).fork(lambda x: x, lambda _: 1) == 0


# Generated at 2022-06-24 00:39:57.878841
# Unit test for constructor of class Task
def test_Task():
    # constructor of class Task
    assert isinstance(Task(lambda _, _2: None), Task)


# Generated at 2022-06-24 00:40:03.501220
# Unit test for method map of class Task
def test_Task_map():
    Task(lambda reject, resolve: resolve(1)).map(lambda value: value + 10).fork(lambda _: None,
                                                                                 lambda value: assert_that(value, equal_to(11)))
    Task(lambda reject, resolve: reject(1)).map(lambda value: value + 10).fork(lambda value: assert_that(value, equal_to(1)), lambda _: None)


# Generated at 2022-06-24 00:40:04.993624
# Unit test for constructor of class Task
def test_Task():
    value = Task.of(5).fork(None, lambda x: x)
    assert value == 5

    value = Task.reject(5).fork(lambda x: x, None)
    assert value == 5


# Generated at 2022-06-24 00:40:11.910409
# Unit test for method map of class Task
def test_Task_map():
    def functions(res, fork_arg):
        return Task.of(fork_arg + 1)

    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2
    assert Task.reject(1).map(lambda x: x + 1).fork(None, lambda x: x) == None
    assert Task(functions).map(lambda x: x * 4).fork(None, lambda x: x) == 10


# Generated at 2022-06-24 00:40:14.725947
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve('Hello')

    task = Task(fork)

    assert isinstance(task, Task)


# Generated at 2022-06-24 00:40:20.049857
# Unit test for constructor of class Task
def test_Task():
    resolved = Task.of(2)
    assert resolved.fork(lambda r: r, lambda r: r) == 2

    rejected = Task.reject(2)
    assert rejected.fork(lambda r: r, lambda r: r) == 2


# Generated at 2022-06-24 00:40:23.071181
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    task2 = task.map(lambda x: x * 2)
    task2.fork(lambda err: False, lambda res: res == 4)


# Generated at 2022-06-24 00:40:32.155156
# Unit test for constructor of class Task
def test_Task():
    def identity(element):
        return element

    task = Task.of(4)
    assert task.fork(lambda x: x, identity) == 4
    task = Task.of('4')
    assert task.fork(lambda x: x, identity) == '4'
    task = Task.reject(4)
    assert task.fork(identity, lambda x: x) == 4
    task = Task.reject('4')
    assert task.fork(identity, lambda x: x) == '4'


# Generated at 2022-06-24 00:40:37.705518
# Unit test for constructor of class Task
def test_Task():
    # setup
    reject = lambda value: 'reject'
    resolve = lambda value: value

    # method of
    assert Task.of('foo').fork(reject, resolve) == 'foo'
    assert Task.of(['foo', 'bar']).fork(reject, resolve) == ['foo', 'bar']

    # method reject
    assert Task.reject('foo').fork(reject, resolve) == 'reject'

    # method map
    assert Task.of('foo').map(lambda arg: arg + 'bar').fork(reject, resolve) == 'foobar'
    assert Task.of([1, 2, 3]).map(lambda arg: arg[::-1]).fork(reject, resolve) == [3, 2, 1]

    # method bind

# Generated at 2022-06-24 00:40:41.624232
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x * 2

    def fork(reject, resolve):
        return resolve(10)

    task = Task(fork)
    assert task.map(fn).fork == Task(fn(10)).fork

# Generated at 2022-06-24 00:40:47.556799
# Unit test for method bind of class Task
def test_Task_bind():
    """
    See also: test_Task_bind_1.py
    """
    def callback(value):
        return Task.of(value)

    def fork(reject, resolve):
        resolve("foo")

    Task(fork).bind(callback).fork(
        lambda arg: print("reject: {value}".format(value=arg)),
        lambda arg: print("success: {value}".format(value=arg))
    )

# Generated at 2022-06-24 00:40:51.270998
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda r, r1: r1(1)).bind(lambda a: Task(lambda r, r1: r1(a * 2))).fork(None, assert_equal(2))


# Generated at 2022-06-24 00:40:54.079921
# Unit test for method map of class Task
def test_Task_map():
    def left(error):
        return error

    def right(value):
        return value

    def fn(value):
        return value + 42

    res = Task.of(3).map(fn)
    assert res.fork(left, right) == 3 + 42



# Generated at 2022-06-24 00:40:59.656823
# Unit test for method map of class Task
def test_Task_map():
    task_of_number = Task.of(1)
    task_of_number_plus_one = task_of_number.map(lambda arg: arg + 1)
    assert task_of_number_plus_one.fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-24 00:41:01.628788
# Unit test for constructor of class Task
def test_Task():
    test_fork = lambda: None
    assert Task(test_fork).fork == test_fork
    return True



# Generated at 2022-06-24 00:41:04.343134
# Unit test for method bind of class Task
def test_Task_bind():
    def with_reject(arg):
        assert arg == 1
        return Task.reject(0)

    def with_resolve(arg):
        assert arg == 2
        return Task.of(1)


# Generated at 2022-06-24 00:41:07.685138
# Unit test for method bind of class Task
def test_Task_bind():
    value = Task.of(1)
    mapped = value.bind(lambda arg: Task.of(arg + 1))
    assert mapped.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 2


# Generated at 2022-06-24 00:41:18.089123
# Unit test for constructor of class Task
def test_Task():
    # check for type error
    try:
        Task(5)
        raise 'Should return TypeError'
    except TypeError: pass

    # constructor of Task should not call fork function
    def test_fork(reject, resolve):
        raise 'Should not call fork function'

    Task(test_fork)

    # should return resolved Task
    def fork(_, resolve):
        return resolve('test')


# Generated at 2022-06-24 00:41:26.205913
# Unit test for method map of class Task
def test_Task_map():
    """
    Example of testing Task::map method
    """
    def increment(value):
        return value + 1

    def double(value):
        return value * 2

    def is_even(value):
        return value % 2 == 0

    def fork_mock(reject, resolve):
        resolve(5)

    assert Task(fork_mock) \
        .map(increment) \
        .map(double) \
        .map(is_even) \
        .fork(pass_function, pass_function) == True


# Generated at 2022-06-24 00:41:34.001335
# Unit test for method bind of class Task
def test_Task_bind():
    """ This test suite will check method bind of class Task. """

    def add_two(value):
        return Task.of(value + 2)

    def mul_two(value):
        return Task.reject(value * 2)

    # Check bind on resolved Task
    task = Task.of(2)