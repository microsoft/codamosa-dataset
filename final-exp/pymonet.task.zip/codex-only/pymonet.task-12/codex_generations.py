

# Generated at 2022-06-24 00:31:43.230469
# Unit test for constructor of class Task
def test_Task():
    def func(reject, resolve):
        return resolve(123)

    assert Task(func).map(lambda value: value + 1).fork(lambda error: None, lambda value: value) == 124
    assert Task.of(123).map(lambda value: value + 1).fork(lambda error: None, lambda value: value) == 124
    assert Task.reject(123).map(lambda value: value + 1).fork(lambda error: None, lambda value: value) == 123
    assert Task.of(123).bind(lambda value: Task.of(value + 1)).fork(lambda error: None, lambda value: value) == 124
    assert Task.reject(123).bind(lambda value: Task.of(value + 1)).fork(lambda error: None, lambda value: value) == 123

if __name__ == '__main__':
    test

# Generated at 2022-06-24 00:31:47.860220
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + value)

    assert Task.of(2).bind(mapper).fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-24 00:31:57.910114
# Unit test for method bind of class Task
def test_Task_bind():
    def task_resolve():
        return Task.of(1)

    def task_reject():
        return Task.reject(2)

    def sum_resolve(value):
        return Task.of(value + 1)

    def sum_reject(value):
        return Task.reject(value - 1)

    assert task_resolve().bind(sum_resolve).fork(lambda x: x, lambda x: x) == 2
    assert task_resolve().bind(sum_reject).fork(lambda x: x, lambda x: x) == 1
    assert task_reject().bind(sum_resolve).fork(lambda x: x, lambda x: x) == 2
    assert task_reject().bind(sum_reject).fork(lambda x: x, lambda x: x) == 0


# Generated at 2022-06-24 00:32:04.901772
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_foo(resolve, reject):
        resolve('foo')

    def reject_foo(resolve, reject):
        reject('foo')

    def resolve_bar(resolve, reject):
        resolve('bar')

    def reject_bar(resolve, reject):
        reject('bar')

    def resolve_baz(resolve, reject):
        resolve('baz')

    def reject_baz(resolve, reject):
        reject('baz')

    # base case
    assert Task(resolve_foo).bind(lambda _: Task(resolve_bar)).fork(lambda reject: reject, lambda resolve: resolve) == 'bar'
    assert Task(reject_foo).bind(lambda _: Task(resolve_bar)).fork(lambda reject: reject, lambda resolve: resolve) == 'foo'
    # alternative

# Generated at 2022-06-24 00:32:11.732092
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)

    # bind function, not call
    mapped_task = task.bind(lambda arg: Task.of(arg + 1))

    # test of call of mapped_task
    assert mapped_task.fork(
        lambda arg: None,
        lambda arg: arg
    ) == 2

    # test of call of mapped_task.bind(mapper)
    assert mapped_task.bind(lambda arg: Task.of(arg + 1)).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 3

    # test of calling if first task is rejected
    task = Task.reject(2)

# Generated at 2022-06-24 00:32:17.721385
# Unit test for method map of class Task
def test_Task_map():
    def add1(value):
        return value + 1

    def sub3(value):
        return value - 3

    def f(reject, resolve):
        resolve(2)

    assert Task(f).map(add1).map(sub3).fork(lambda x: f"error: {x}", lambda x: f"value: {x}") == "value: 0"


# Generated at 2022-06-24 00:32:20.686670
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    mapped_task = task.map(lambda x: x * 3)

    assert mapped_task.fork(None, lambda x: x) == 6


# Generated at 2022-06-24 00:32:24.224784
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        return Task.of(x + 1)

    assert Task.of(1).bind(f).fork(
        lambda error: None,
        lambda value: value
    ) == 2


# Generated at 2022-06-24 00:32:35.091053
# Unit test for method map of class Task
def test_Task_map():
    def test(task, expected_task, fn_test_values, fn_test_attrs):
        """
        Test map method of class Task with given parameters.

        :param task: task to call map
        :type task: Task[A]
        :param expected_task: task with expected values
        :type expected_task: Task[B]
        :param fn_test_values: function to test values of fork
        :type fn_test_values: Function(reject_value, resolve_value) -> Any
        :param fn_test_attrs: function to test attributes of fork
        :type fn_test_attrs: Function(reject_value, resolve_value) -> Any
        """
        # Call fork method of expected task
        expected_reject_value, expected_resolve_value = None, None

# Generated at 2022-06-24 00:32:38.783868
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(None, lambda x: x) == 2


# Generated at 2022-06-24 00:32:46.691241
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> def bind_test(x):
    ...  return Task.reject('rejected') if x == 'rejected' else Task.of(x + 2)

    >>> task = Task.of(1).bind(bind_test).fork(
    ...   lambda x: 'rejected',
    ...   lambda x: x)
    >>> task
    3

    >>> task = Task.reject(1).bind(bind_test).fork(
    ...   lambda x: 'rejected',
    ...   lambda x: x)
    >>> task
    'rejected'
    """


# Generated at 2022-06-24 00:32:54.125587
# Unit test for constructor of class Task
def test_Task():
    def fun_resolve(a):
        return Task.of(a)

    def fun_reject(a):
        return Task.reject(a)

    task = Task(fun_resolve)
    assert task.fork(lambda x: x, lambda x: x) == "a"

    task = Task(fun_reject)
    assert task.fork(lambda x: x, lambda x: x) == "b"


# Generated at 2022-06-24 00:32:56.243783
# Unit test for method map of class Task
def test_Task_map():
    def my_map(x):
        """
        Test function
        """
        return x + 1

    result = Task.of(1).map(my_map)
    assert type(result) == Task
    assert result.fork(None, lambda x: x) == 2


# Generated at 2022-06-24 00:33:00.532294
# Unit test for method map of class Task
def test_Task_map():
    def add(a):
        return a + 2

    task = Task.of(2)
    result = task.map(add)
    assert result.fork(None, lambda x: x) == 4


# Generated at 2022-06-24 00:33:01.423055
# Unit test for constructor of class Task
def test_Task():
    expect(Task).not_to.be_none()
    expect(Task).not_to.be_callable()


# Generated at 2022-06-24 00:33:06.032790
# Unit test for method map of class Task
def test_Task_map():
    value = 0
    result = Task.of(value)
    after_map = result.map(lambda val: val + 10)

    def resolver(arg):
        assert arg == value + 10
        nonlocal after_map
        after_map = None

    after_map.fork(lambda _: None, resolver)

    assert after_map is None


# Generated at 2022-06-24 00:33:16.543191
# Unit test for constructor of class Task
def test_Task():
    """
    :returns: True if all tests were passed
    :rtype: Boolean
    """
    def test_case(description, expected):
        """
        Test case for test all of cases
        Check result of task with description and expected value.
        If it all ok will be return True, if not will be return False.

        :param description: description of current test
        :type description: String
        :param expected: expected value for test
        :returns: True if all is ok, else False
        :rtype: Boolean
        """
        def task(reject, resolve):
            resolve(expected)

        result = Task(task).fork(lambda arg: arg, lambda arg: arg)
        status = result == expected
        if not status:
            print(f'{description} failed. Expected {expected}, got {result}')


# Generated at 2022-06-24 00:33:19.930469
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of('some_string')
    mapper = lambda string: Task.of('some_mapper_result')
    binded = task.bind(mapper)
    result = binded.fork(lambda arg: 'rejected', lambda arg: 'resolved')


# Generated at 2022-06-24 00:33:23.306521
# Unit test for method bind of class Task
def test_Task_bind():
    def resolver(value):
        return Task.of(value)

    def mapper(value):
        return Task.of(value + value)

    assert Task.of(1).bind(resolver).bind(mapper).fork(
        lambda _: False,
        lambda arg: arg == 2,
    )



# Generated at 2022-06-24 00:33:33.806811
# Unit test for method map of class Task
def test_Task_map():
    def test_map_on_resolved():
        @add_tracing
        def fork(reject, resolve):
            resolve('test')

        task = Task(fork)
        result = task.map(lambda value: value * 2)

        processed = result.fork(
            lambda arg: arg,
            lambda arg: arg
        )
        assert processed == 'testtest'
        assert fork.calls == 1
        assert task.fork.calls == 1
        assert result.fork.calls == 1

    def test_map_on_rejected():
        @add_tracing
        def fork(reject, resolve):
            reject('test')

        task = Task(fork)
        result = task.map(lambda value: value * 2)


# Generated at 2022-06-24 00:33:36.089644
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    task_result = task.bind(lambda value: Task.of(value + 3))

    assert task_result.fork(lambda value: None, lambda value: value) == 4

'''
### 2.2. Implementing almost flatMap as a fork function
'''


# Generated at 2022-06-24 00:33:41.264682
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    task = Task.of(1).map(mapper)
    assert task.fork(lambda e: e, lambda r: r) == 2


# Generated at 2022-06-24 00:33:45.289773
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject(1)

    fork_mock = mock.Mock(side_effect=fork)

    task = Task(fork_mock)
    assert task.fork is fork_mock


# Generated at 2022-06-24 00:33:48.184932
# Unit test for constructor of class Task
def test_Task():
    async def async_test_Task():
        assert await Task.of(10) == 10
        assert await Task.reject(10) == 10


# Generated at 2022-06-24 00:33:53.174166
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject(1)

    def fork_1(reject, resolve):
        return resolve(2)

    assert Task(fork).fork(lambda arg: arg, lambda _: False) == 1
    assert Task(fork_1).fork(lambda _: False, lambda arg: arg) == 2


# Generated at 2022-06-24 00:34:02.496917
# Unit test for method bind of class Task
def test_Task_bind():
    def fork_reject(value):
        def result(reject, resolve):
            return reject(value)

        return Task(result)

    def fork_resolve(value):
        def result(reject, resolve):
            return resolve(value)

        return Task(result)

    def square(value):
        return fork_resolve(value ** 2)


# Generated at 2022-06-24 00:34:04.300283
# Unit test for constructor of class Task
def test_Task():
    def fork(_, resolve):
        resolve(10)

    task = Task(fork)
    assert task.fork(lambda value: None, print) == None, "Task was not created properly"


# Generated at 2022-06-24 00:34:10.889254
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(42)

    task_o = Task(fork)

    def mapper(value):
        def mapped_fork(reject, resolve):
            if value % 2 == 0:
                return resolve(value / 2)

            return reject(value)

        return Task(mapped_fork)

    new_task_o = task_o.bind(mapper)
    _, mapped_value = new_task_o.fork(fail, pass_through)
    assert mapped_value == 21

    def reject(value):
        return Task(lambda _, resolve: resolve(value))

    def mapper(value):
        return Task(lambda reject, _: reject(value))

    new_task_o = task_o.bind(mapper)
    rejected_value, _ = new_task

# Generated at 2022-06-24 00:34:21.267700
# Unit test for constructor of class Task
def test_Task():
    class Container:
        def __init__(self, value):
            self.value = value
    # Create function that return 1 with arg is None
    def get_one(reject, resolve):
        return resolve(1)
    # Create first Task with stored get_one function
    fork = Task(get_one)
    assert fork.fork(lambda _: None, lambda arg: arg) == 1, "Fork failed"
    # Create second Task with stored get_one function and with mapped attributes
    double = fork.map(lambda value: value * 2)
    assert double.fork(lambda _: None, lambda arg: arg) == 2, "Double failed"
    # Create third Task with stored get_one function and with bound attributes
    container = double.bind(lambda value: Task.of(Container(value)))

# Generated at 2022-06-24 00:34:27.584233
# Unit test for method map of class Task
def test_Task_map():
    def bound_value(reject, resolve):
        resolve('value')

    task = Task(bound_value)

    def mapper(value):
        return 'mapped_{}'.format(value)

    mapped_task = task.map(mapper)
    mapped_value = mapped_task.fork(lambda reject: None, lambda resolve: resolve)

    assert mapped_value == 'mapped_value'


# Generated at 2022-06-24 00:34:31.782960
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task

    :returns: information about result test
    :rtype: Boolean
    """
    def fork(_, resolve):
        return resolve('test')

    task = Task(fork)

    assert task.fork({}, {}) == 'test'

    def fn(value):
        return value + ' ' + 'test'

    assert task.map(fn).fork({}, {}) == 'test test'


# Generated at 2022-06-24 00:34:41.542551
# Unit test for constructor of class Task
def test_Task():
    assert Task(
        lambda reject, resolve: resolve(2)
    ).fork(lambda arg: arg, lambda arg: arg * 2) == 4

    assert Task(
        lambda reject, resolve: resolve(20)
    ).fork(lambda arg: arg + 1, lambda arg: arg) == 20

    assert Task(
        lambda reject, resolv: reject(2)
    ).fork(lambda arg: arg + 1, lambda arg: arg * 2) == 3

    assert Task(
        lambda reject, resolv: reject(2)
    ).fork(
        lambda arg: arg + 1,
        lambda arg: arg * 2
    ) == 3

    assert Task.of(4).fork(lambda arg: arg + 1, lambda arg: arg * 2) == 8

# Generated at 2022-06-24 00:34:45.508644
# Unit test for method map of class Task
def test_Task_map():
    """
    >>> t1 = Task.of(42)
    >>> t2 = t1.map(lambda x: x + 1)
    >>> t2.fork(lambda x: x, lambda x: x)
    43
    """

    pass



# Generated at 2022-06-24 00:34:49.413893
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda value: value*2).fork(None, lambda value: value) == 4
    assert Task.reject(2).map(lambda value: value*2).fork(lambda value: value, None) == 2


# Generated at 2022-06-24 00:34:52.569131
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(5).fork(lambda x: x, lambda x: x) == 5
    assert Task.reject('foo').fork(lambda x: x, lambda x: x) == 'foo'



# Generated at 2022-06-24 00:34:55.990764
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)

    def mapper(value):
        return Task.of(value + 1)

    assert task.bind(mapper).fork(lambda rejected: rejected, lambda resolved: resolved) == 2



# Generated at 2022-06-24 00:34:58.946301
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert bind(Task.of(2), fn).fork(
        lambda err: err,
        lambda value: value) == 3



# Generated at 2022-06-24 00:35:07.331377
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    def no_error(reject, resolve):
        resolve(True)

    def with_error(reject, resolve):
        reject('error')

    assert (
        Task(no_error)
        .bind(lambda _: Task.of(1))
        .fork(lambda value: False, lambda value: True)
    )

    assert (
        Task(no_error)
        .map(lambda _: 1)
        .fork(lambda value: False, lambda value: True)
    )

    assert not (
        Task(with_error)
        .bind(lambda _: Task.of(1))
        .fork(lambda value: True, lambda value: False)
    )


# Generated at 2022-06-24 00:35:14.172168
# Unit test for method bind of class Task
def test_Task_bind():
    def fail(msg):
        raise AssertionError(msg)

    task = Task.of(0)

# Generated at 2022-06-24 00:35:15.424144
# Unit test for constructor of class Task
def test_Task():
    def fn(reject, resolve):
        return 1

    task = Task(fn)
    assert task
    assert task.fork



# Generated at 2022-06-24 00:35:18.922549
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> add_1 = lambda value: Task.of(value + 1)
    >>> add_2 = lambda value: Task.of(value + 2)
    >>> str_value = lambda value: Task.of(str(value))
    >>> test = Task.of(1).bind(add_1).bind(add_2).bind(str_value)
    >>> test.fork(
    ... lambda error: 'error',
    ... lambda value: value
    ... )
    '4'
    """
    pass


# Generated at 2022-06-24 00:35:21.066174
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> def mapper(value):
    ...     return Task.of(value + 1)
    ...
    >>> Task.of(1).bind(mapper).fork(None, lambda value: value)
    2
    """
    pass


# Generated at 2022-06-24 00:35:22.943787
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return value

    assert Task.of(5).bind(fn).fork(lambda x: None, lambda x: x) == 5

# Generated at 2022-06-24 00:35:25.151259
# Unit test for method map of class Task
def test_Task_map():
    Task.of(5).map(lambda x: x * 2).fork(
        lambda x: 'error',
        lambda x: x
    ) == 10


# Generated at 2022-06-24 00:35:29.013984
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(3)).map(lambda x: x * 2).fork(lambda x: x, lambda y: y) == 6


# Generated at 2022-06-24 00:35:31.133780
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    assert task.map(lambda x: x + 1).fork(lambda x: None, lambda x: x) == 2


# Generated at 2022-06-24 00:35:34.492673
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    mapped_task = task.map(lambda x: x * 3)

    def fork(reject, resolve):
        context.value = { 'resolve': resolve }

    mapped_task.fork(fork)

    context.value['resolve']()
    assert mapped_task.value == 6

test_Task_map()


# Generated at 2022-06-24 00:35:44.021051
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test work of method bind of class Task.
    """
    # Simple call of method bind.

# Generated at 2022-06-24 00:35:52.653894
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve(42)

    task = Task(fork)
    assert task.fork(None, None) == 42

    def fork(reject, resolve):
        return resolve(42)

    task = Task.of(42)
    assert task.fork(None, None) == 42

    def fork(reject, resolve):
        return reject(42)

    task = Task.reject(42)
    assert task.fork(None, None) == 42

    def fork(reject, resolve):
        return resolve(42)

    task = task.map(lambda x: x + 1)
    assert task.fork(None, None) == 43


# Generated at 2022-06-24 00:35:56.078347
# Unit test for method map of class Task
def test_Task_map():
    assert (
        Task.of(3).map(lambda x: x * 2)
        ==
        Task(lambda _, resolve: resolve(3 * 2))
    )

    assert (
        Task.of(3).map(lambda x: x * 2).map(lambda x: x + 3)
        ==
        Task(lambda _, resolve: resolve((3 * 2) + 3))
    )


# Generated at 2022-06-24 00:36:03.960651
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind method of class Task.
    This method take function and call with value of Task during calling fork method of class Task.
    """
    @staticmethod
    def add1(x):
        """
        :param x: number
        :type x: int
        :returns: number + 1
        :rtype int
        """
        return x + 1

    @staticmethod
    def sub1(x):
        """
        :param x: number
        :type x: int
        :returns: number - 1
        :rtype int
        """
        return x - 1

    @staticmethod
    def add_error(x):
        """
        :param x: number
        :type x: int
        :returns: number + 1
        :rtype: Task[B]
        """
        return Task

# Generated at 2022-06-24 00:36:06.753750
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(2) == Task(lambda _, resolve: resolve(2))
    assert Task.reject(4) == Task(lambda reject, _: reject(4))


# Generated at 2022-06-24 00:36:09.933512
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: resolve('Hello')).fork(lambda error: None, lambda result: result) == 'Hello'
    assert Task(lambda reject, resolve: reject('Error')).fork(lambda error: error, lambda result: None) == 'Error'


# Generated at 2022-06-24 00:36:14.945688
# Unit test for method bind of class Task

# Generated at 2022-06-24 00:36:16.042968
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task.of(5), Task)


# Generated at 2022-06-24 00:36:21.735212
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject(1)

    assert Task(fork).fork(
        lambda arg: arg,
        lambda arg: arg) == 1



# Generated at 2022-06-24 00:36:26.344612
# Unit test for constructor of class Task
def test_Task():
    # test of Task.of
    resolved_task = Task.of(1)

# Generated at 2022-06-24 00:36:37.128174
# Unit test for method bind of class Task
def test_Task_bind():
    import pdb; pdb.set_trace()
    def sum(value):
        """
        Sum value with 5.

        :param value: value to sum with 5
        :type value: int
        :returns: sum value
        :rtype: int
        """
        return value + 5

    def divide(value):
        """
        Divide value by 2.

        :param value: value to divide by 2
        :type value: int
        :returns: division value
        :rtype: int
        """
        return value // 2

    def resolve(value):
        """
        Return Tasks with mapped value.

        :param value: value to divide by 2
        :type value: int
        :returns: division value
        :rtype: int
        """
        return Task.of(value).map(divide)

# Generated at 2022-06-24 00:36:39.557699
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, r: r(42)).fork(lambda _: None, lambda value: value) == 42

    called = []
    Task(lambda r, _: r(42)).fork(lambda value: called.append(value), lambda _: None)
    assert len(called) == 1
    assert called[0] == 42


# Generated at 2022-06-24 00:36:42.927636
# Unit test for constructor of class Task
def test_Task():
    test_fork = lambda _, resolve: resolve(1)
    task = Task(test_fork)

    isinstance(task, Task)
    assert task.fork  == test_fork


# Generated at 2022-06-24 00:36:50.746817
# Unit test for method map of class Task
def test_Task_map():
    """
    Testing Task.map
    """
    task = Task.of(1)
    mapped_task = task.map(lambda x: x + 1)
    assert Task.is_instance(mapped_task)
    assert mapped_task.fork(lambda x: None, lambda x: x) == 2

    task = Task.reject(1)
    mapped_task = task.map(lambda x: x + 1)
    assert Task.is_instance(mapped_task)
    assert mapped_task.fork(lambda x: x, lambda x: None) == 1


# Generated at 2022-06-24 00:36:53.036439
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> plusOne = lambda num: Task.of(num + 1)
    >>> plusOne(1).fork(print, print)
    2
    """


# Generated at 2022-06-24 00:36:59.568761
# Unit test for method map of class Task
def test_Task_map():
    t1 = Task.of(1)
    t2 = t1.map(lambda x: x + 1)
    t3 = t2.map(lambda x: x ** 2)
    assert t3.fork(lambda x: None, lambda x: x) == 4


# Generated at 2022-06-24 00:37:07.732602
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of Task class.
    """
    def sample_function(number):
        return float(number) / 2

    # Create resolve Task
    t = Task.of(2)
    # Create new Task with given function
    t_with_mapped = t.map(sample_function)
    # Check that it is same result
    assert t_with_mapped.fork(
        lambda _: None,
        lambda arg: arg
    ) == 1

    # Create reject Task
    t = Task.reject(2)
    # Create new Task with given function
    t_with_mapped = t.map(sample_function)
    # Check that it is same result
    assert t_with_mapped.fork(
        lambda arg: arg,
        lambda _: None
    ) == 2

#

# Generated at 2022-06-24 00:37:14.284816
# Unit test for method map of class Task
def test_Task_map():
    @Task
    def fetch_name():
        """
        :returns: name of author of this library
        :rtype: Task[Reject, A]
        """
        return 'volhovm'

    @Task
    def fetch_github_username(name):
        """
        :param name: user name
        :type name: str
        :returns: github username of user with name
        :rtype: Task[Reject, A]
        """
        return 'github.com/' + name

    def test(res):
        print('return value: ', res)
        return 'this is test'

    fetch_github_username(fetch_name()).map(test).fork(
        lambda err: print('error: ' + str(err)),
        lambda res: print('mapper: ' + res)
    )


# Generated at 2022-06-24 00:37:16.684378
# Unit test for method map of class Task
def test_Task_map():
    """
    Testing map method of class Task

    :returns: nothing
    :rtype: None
    """
    def resolve(value):
        assert value == 5

    def reject(value):
        assert False

    Task.of(2).map(lambda x: x+3).fork(reject, resolve)

if __name__ == "__main__":
    test_Task_map()

# Generated at 2022-06-24 00:37:22.350725
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind (mapping Task when it resolved)

    :returns: None
    :rtype: None
    """
    def fork(reject, resolve):
        resolve(1)

    def mapper(arg):
        return Task(lambda reject, resolve: resolve(arg * 2))

    task = Task(fork)
    result = task.bind(mapper).fork(reject=None, resolve=stub)

    assert result == 2, "Task value should be 2 after calling"

test_Task_bind()


# Generated at 2022-06-24 00:37:28.965275
# Unit test for method bind of class Task
def test_Task_bind():

    def fork(reject, resolve):
        return reject("error")

    def bind(value):
        def bfork(reject, resolve):
            return reject("binderror")

        return Task(bfork)

    task = Task(fork)
    btask = task.bind(bind)

    assert task.fork(lambda v: None, None) == "error"
    assert btask.fork(lambda v: None, None) == "binderror"


# Generated at 2022-06-24 00:37:32.789987
# Unit test for constructor of class Task
def test_Task():
    resolved = Task.of("a")
    assert(resolved.fork(lambda x: x, lambda x: x) == "a")
    rejected = Task.reject("a")
    assert(rejected.fork(lambda x: x, lambda x: x) == "a")


# Generated at 2022-06-24 00:37:34.504019
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x: Task.of(x+1)).fork(lambda x: None, lambda x: x) == 2


# Generated at 2022-06-24 00:37:39.437415
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(5).bind(lambda x: Task.of(6 + x))
    assert result.fork(lambda _: 0, lambda arg: arg) == 11

    result = Task.of(5).bind(lambda _: Task.reject(3))
    assert result.fork(lambda arg: arg, lambda _: 0) == 3

    result = Task.reject(3).bind(lambda x: Task.of(6 + x))
    assert result.fork(lambda arg: arg, lambda _: 0) == 3


# Generated at 2022-06-24 00:37:48.485938
# Unit test for method bind of class Task
def test_Task_bind():
    # @type: (Function(A) -> Task[Function(B) -> C]) -> (Function(Task[Function(A) -> B]) -> Task[Function(C) -> D])
    # @type: (Function(A) -> Task[Function(B) -> C]) -> (Task[Function(A) -> B] -> Task[Function(C) -> D])
    def mapper(fn):
        def task(arg):
            return Task.of(fn(arg))

        return task

    add_gen = lambda a, b: Task.of(a + b)
    multiply_gen = lambda a, b: Task.of(a * b)
    subtract_gen = lambda a, b: Task.of(a - b)
    sum_gen = lambda a, b: Task.of(sum([a, b]))

    task = Task

# Generated at 2022-06-24 00:37:52.809714
# Unit test for constructor of class Task
def test_Task():
    # Test for reject branch
    assert Task(reject=lambda reject, _: reject(None)).fork(
        lambda _: None,
        lambda value: value
    ) is None

    # Test for resolve branch
    assert Task(resolve=lambda reject, resolve: resolve(None)).fork(
        lambda value: value,
        lambda _: None,
    ) is None

    # Test for of class method
    assert Task.of(3).fork(
        lambda _: None,
        lambda value: value,
    ) == 3

    # Test for reject class method
    assert Task.reject(3).fork(
        lambda value: value,
        lambda _: None,
    ) == 3


# Generated at 2022-06-24 00:37:57.863681
# Unit test for constructor of class Task
def test_Task():
    """Unit test for constructor of class Task."""
    def identity(x):
        return x

    task = Task(identity)
    assert task.fork(identity, identity) == None


# Generated at 2022-06-24 00:38:01.334901
# Unit test for constructor of class Task
def test_Task():
    """
    Test Task

    :return: None
    :rtype: None
    """
    assert Task.of(1) is not Task.of(1)
    assert Task.of(1).fork(null, null) is None
    assert Task.reject(1).fork(null, null) is None


# Generated at 2022-06-24 00:38:07.461041
# Unit test for constructor of class Task
def test_Task():
    called = [0]

    def fork(reject, resolve):
        called[0] += 1
        resolve(1)

    task_a = Task(fork)

    assert task_a.fork(lambda _: 0, lambda b: b) == 1
    assert called[0] == 1


# Generated at 2022-06-24 00:38:08.320498
# Unit test for constructor of class Task
def test_Task():
    pass


# Generated at 2022-06-24 00:38:18.154624
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)
        return Task(fork)

    def map1(value):
        return value + 1

    def bind1(value):
        def fork_result(reject, resolve):
            resolve(value + 1)
            return Task(fork_result)

        return Task(fork_result)

    task = Task(fork)
    assert isinstance(task.map(map1), Task)
    assert isinstance(task.bind(bind1), Task)

# Generated at 2022-06-24 00:38:21.304689
# Unit test for constructor of class Task
def test_Task():
    # success case
    assert Task.of(100) == Task(lambda _, resolve: resolve(100))
    # failure case
    assert Task.reject(100) == Task(lambda reject, _: reject(100))

# Generated at 2022-06-24 00:38:27.214060
# Unit test for constructor of class Task
def test_Task():
    # check right initialization and stored fork
    fork = lambda r, s: r(1)
    task = Task(fork)
    assert task.fork == fork

    # check fork with resolve
    result = task.fork(lambda r: r, lambda s: s)
    assert result == 1

    # check fork with reject
    result = task.fork(lambda r: r, lambda s: r(1))
    assert result == 1


# Generated at 2022-06-24 00:38:28.869630
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(mapper).fork(lambda _: 0, lambda result: result) == 2

# Generated at 2022-06-24 00:38:31.062607
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve(5)
    result = Task(fork)
    assert result.fork(None, None) == 5


# Generated at 2022-06-24 00:38:36.894586
# Unit test for constructor of class Task
def test_Task():
    def throw_error(reject, resolve):
        return reject(Exception("Test exception"))

    def test_value(reject, resolve):
        return resolve("Test value")

    task_of_throw_error = Task(throw_error)
    task_of_test_value = Task(test_value)

    assert task_of_throw_error.fork(lambda reject: reject, lambda _: None) is not None
    assert task_of_test_value.fork(lambda reject: None, lambda resolve: resolve) == "Test value"



# Generated at 2022-06-24 00:38:40.736766
# Unit test for constructor of class Task
def test_Task():
    # Do run task
    def fork(reject, resolve):
        reject(None)

    # Check constructor
    task = Task(fork)
    assert task
    assert task.fork and callable(task.fork)


# Generated at 2022-06-24 00:38:44.916428
# Unit test for constructor of class Task
def test_Task():
    def test_reject_fork(reject, resolve):
        reject(1)

    def test_resolve_fork(reject, resolve):
        resolve(1)

    assert Task(test_reject_fork()).fork(lambda x: None, lambda x: None)
    assert Task(test_resolve_fork()).fork(lambda x: None, lambda x: None)


# Generated at 2022-06-24 00:38:47.604657
# Unit test for constructor of class Task
def test_Task():
    def check(x):
        return Task(lambda _, resolve: resolve(x))

    assert isinstance(check(1), Task)


# Generated at 2022-06-24 00:38:57.974203
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test that Task.bind method return new Task with mapped value
    """

    def fetch_string():
        """
        Dummy fetching function
        """
        return Task.of('Hello')

    def parse_string(value):
        """
        Dummy parsing function
        """
        return Task.of(value + ', World!')

    result = fetch_string().bind(parse_string)
    assert isinstance(result, Task)
    result.fork(lambda arg: 'fail', lambda arg: arg == 'Hello, World!')

    def raise_error():
        """
        Function that raise error on calling
        """
        raise RuntimeError('Error')

    result.bind(raise_error)
    result.fork(
        lambda arg: arg.message == 'Error',
        lambda *args: False
    )

# Generated at 2022-06-24 00:39:08.302083
# Unit test for method map of class Task
def test_Task_map():
    def pseudo_async(resolve):
        """ emulate async execution of fn """
        assert False, 'async is not allowed'
        resolve('1st')

    task = Task(lambda reject, resolve: pseudo_async(resolve))
    assert task.fork(lambda arg: arg, lambda arg: arg) == '1st'
    assert task.map(lambda arg: arg + ' is mapped').fork(lambda arg: arg, lambda arg: arg) == '1st is mapped'

    def pseudo_error(reject):
        """ emulate async execution of fn """
        assert False, 'async is not allowed'
        reject('error')

    task = Task(lambda reject, resolve: pseudo_error(reject))
    assert task.fork(lambda arg: arg, lambda arg: arg) == 'error'

# Generated at 2022-06-24 00:39:13.849129
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(4)
    task = Task(fork)

    task1 = task.map(lambda value: value + 1)
    assert task1.fork(lambda x: x, lambda x: x) == 5



# Generated at 2022-06-24 00:39:19.507495
# Unit test for method map of class Task
def test_Task_map():
    def test_fun(resolve, reject):
        return 1

    fun = Task(test_fun)
    fun_plus_two = fun.map(lambda x: x + 2)

    def test_fork(resolve, reject):
        x = fun_plus_two.fork(reject, resolve)

    assert Tester.deep_equal(run_task(test_fork), 3)


# Generated at 2022-06-24 00:39:22.607668
# Unit test for constructor of class Task
def test_Task():

    def fork(reject, resolve):
        resolve("value")

    task = Task(fork)

    assert task.fork(None, None) == "value"


# Generated at 2022-06-24 00:39:28.675219
# Unit test for method map of class Task
def test_Task_map():
    def test_failed_map(fork, fn):
        task = Task(fork)
        result_task = task.map(fn)
        rejected_value = result_task.fork(lambda arg: arg, None)

        if rejected_value != 'reject':
            raise Exception('fail test map for rejected value')

    def test_success_map(fork, fn, expected_value):
        task = Task(fork)
        result_task = task.map(fn)
        resolved_value = result_task.fork(None, lambda arg: arg)

        if resolved_value != expected_value:
            raise Exception('fail test map for resolved value')

    test_failed_map(
        lambda _, reject: reject('reject'),
        lambda arg: arg + 1
    )


# Generated at 2022-06-24 00:39:38.389292
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    def resolve_a(resolve):
        """
        Return resolved Task with stored value argument.

        :param resolve: resolve function from Task
        :type resolve: Function(value) -> A
        """
        resolve('a')

    def resolve_b(resolve):
        """
        Return resolved Task with stored value argument.

        :param resolve: resolve function from Task
        :type resolve: Function(value) -> B
        """
        resolve('b')

    task_a = Task(resolve_a)
    task_b = Task(resolve_b)
    task_ab = task_a.bind(lambda _: task_b)

    assert 'b' == task_ab.fork(lambda _: 'rejected', lambda arg: arg)

# Generated at 2022-06-24 00:39:41.069066
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject(1)

    task = Task(fork)

    assert isinstance(task, Task)
    assert task.fork == fork


# Generated at 2022-06-24 00:39:44.344795
# Unit test for method map of class Task
def test_Task_map():
    def check(value):
        assert value == 'hello'

    Task.of('hello').map(lambda value: check(value)).fork(lambda value: None, lambda value: None)


# Generated at 2022-06-24 00:39:47.087730
# Unit test for method bind of class Task

# Generated at 2022-06-24 00:39:48.279602
# Unit test for constructor of class Task
def test_Task():
    result = Task(lambda reject, resolve: 'some data')
    assert result.fork is not None


# Generated at 2022-06-24 00:39:53.139541
# Unit test for constructor of class Task
def test_Task():
    value = 'result of Task'

    def fork(reject, resolve):
        resolve(value)

    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-24 00:40:00.316236
# Unit test for method map of class Task
def test_Task_map():
    def double(value):
        return value * 2

    def null(_):
        return None

    def compose(f, g):
        return lambda x: g(f(x))

    assert Task(double).map(double).fork(null, double) == 16
    assert Task(double).map(compose(lambda x: x * 3, double)).fork(null, double) == 24



# Generated at 2022-06-24 00:40:08.753627
# Unit test for method map of class Task
def test_Task_map():
    from io import StringIO
    from mock import patch

    def func():
        with patch('__builtin__.raw_input', return_value='value'):
            assert Task.of('value').map(lambda x: x + '!')(lambda _, resolve: resolve('resolve')) == 'resolve'
            assert Task.of('value').map(lambda x: x + '!')(lambda reject, _: reject('reject')) == 'reject'
            assert Task.reject('value').map(lambda x: x + '!')(lambda reject, _: reject('reject')) == 'reject'
            assert Task.reject('value').map(lambda x: x + '!')(lambda _, resolve: resolve('resolve')) == 'resolve'
    assert not StringIO.getvalue()
    func()
    assert not String

# Generated at 2022-06-24 00:40:11.520982
# Unit test for method map of class Task
def test_Task_map():
    @Task.of(5)
    def task(reject, resolve):
        return resolve(5)

    @Task.of(5)
    def task2(reject, resolve):
        return resolve(10)

    assert task.map(lambda x: x*2) == task2



# Generated at 2022-06-24 00:40:14.921982
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    def fork():
        return 'fork'

    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-24 00:40:17.720847
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve("Hello")).fork("reject", "resolve") == "resolve"
    assert Task(lambda reject, _: reject("Error")).fork("reject", "resolve") == "reject"


# Generated at 2022-06-24 00:40:20.166895
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork == (
        lambda _, resolve: resolve(2)
    )

    assert Task.of(2).map(lambda x: x * x).fork == (
        lambda _, resolve: resolve(4)
    )


# Generated at 2022-06-24 00:40:28.722063
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Assert that bind function of Task class works as expected.
    """
    def first_task(resolve):
        return resolve('first_task')

    def second_task(resolve):
        return resolve('second_task')

    resolved_task = Task.of('initial').bind(lambda arg: first_task(arg)).bind(lambda arg: second_task(arg))
    assert resolved_task.fork(lambda arg: 'rejected', lambda arg: arg) == 'second_task'


# Generated at 2022-06-24 00:40:32.281978
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return value + 1

    assert Task.of(1) \
        .bind(lambda value: Task.of(add_one(value))).fork(None, lambda result: result) == 2


# Generated at 2022-06-24 00:40:36.310335
# Unit test for method bind of class Task
def test_Task_bind():
    def inc(value):
        return Task(lambda _, resolve: resolve(value + 1))

    task = Task.reject(5).bind(inc)
    result = task.fork(lambda arg: arg, lambda arg: arg)
    assert result == 5

    task = Task(lambda _, resolve: resolve(5)).bind(inc)
    result = task.fork(lambda arg: arg, lambda arg: arg)
    assert result == 6


# Generated at 2022-06-24 00:40:43.217681
# Unit test for method bind of class Task
def test_Task_bind():
    """
    To run tests execute:
        python -m unittest -v tests.task
    """

    import unittest

    class TestTask(unittest.TestCase):
        def test_Task_bind(self):
            def result_function(reject, resolve):
                reject(None)

            def forked_function(reject, resolve):
                reject(True)

            def empty_function(reject, resolve):
                pass

            Task(forked_function).bind(lambda _: Task(empty_function)).fork(lambda arg: self.assertEqual(True, arg))
            Task(forked_function).bind(lambda _: Task(result_function)).fork(lambda _: self.assertEqual(False, True), lambda arg: self.assertEqual(False, arg))
            Task(result_function).fork

# Generated at 2022-06-24 00:40:48.951548
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda _: None, lambda n: n) == 1
    assert Task.reject(1).fork(lambda n: n, lambda _: None) == 1

    assert Task.of(Task.of(1)).fork(lambda _: None, lambda n: n.fork(lambda _: None, lambda n: n)) == 1


# Generated at 2022-06-24 00:40:54.710551
# Unit test for method map of class Task
def test_Task_map():
    """
    Test method map of class Task.
    """
    assert Task.of(2).map(lambda arg: arg + 1) == Task.of(3)
    assert Task.of(2).map(lambda arg: arg + 1).fork(
        lambda arg: (lambda: None)(),
        lambda arg: arg
    ) == 3
    assert Task.reject(1).map(lambda arg: arg + 1).fork(
        lambda arg: arg,
        lambda arg: (lambda: None)()
    ) == 1


# Generated at 2022-06-24 00:41:00.303473
# Unit test for method bind of class Task
def test_Task_bind():
    res = Task.of(1).bind(
        lambda value: Task.of(value + 1)
    ).fork(
        lambda err: print(f'err: {err}'),
        lambda success: print(f'success: {success}')
    )
    assert res == 2


# Generated at 2022-06-24 00:41:05.371542
# Unit test for method map of class Task

# Generated at 2022-06-24 00:41:16.753365
# Unit test for constructor of class Task
def test_Task():
    """
    Test cases for constructor of class Task
    """
    def test_of():
        value = 12
        assert Task.of(value).fork(lambda arg: arg, lambda arg: arg) == value

    def test_of_with_empty_value():
        assert Task.of().fork(lambda arg: arg, lambda arg: arg) == None

    def test_reject():
        message = "error"
        assert Task.reject(message).fork(lambda arg: arg, lambda arg: arg) == message

    def test_reject_with_empty_value():
        assert Task.reject().fork(lambda arg: arg, lambda arg: arg) == None

    def test_task():
        def fork(reject, resolve):
            return resolve(1 + 1)


# Generated at 2022-06-24 00:41:27.137361
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test `Test.bind` method
    """

    assert Task.of(1).map(lambda x: x + 1).bind(Task.of).fork(
        lambda arg: "rejected",
        lambda arg: arg
    ) == 2

    assert Task.of(1).map(lambda x: x + 1).bind(
        lambda arg: Task.reject(2)
    ).fork(
        lambda arg: arg,
        lambda arg: "resolved"
    ) == 2

    assert Task.reject(1).map(lambda x: x + 1).bind(
        lambda arg: Task.of(2)
    ).fork(
        lambda arg: arg,
        lambda arg: "resolved"
    ) == 1


# Generated at 2022-06-24 00:41:31.620623
# Unit test for method map of class Task
def test_Task_map():
    def add_two(n, m):
        return n + m


# Generated at 2022-06-24 00:41:42.007671
# Unit test for method bind of class Task
def test_Task_bind():

    def sum(x):
        return lambda y: x + y

    def expect_even(x):
        if x % 2 == 0:
            return Task.of(x * x)
        else:
            return Task.reject(x)

    assert Task.of(2).bind(sum(2)).fork(None, lambda x: x) == 4
    assert Task.of(2).bind(sum(2)).bind(
        sum(2)).fork(None, lambda x: x) == 8

    assert Task.of(3).bind(sum(3)).bind(
        sum(3)).bind(lambda x: expect_even(x)).fork(lambda x: x, None) == 18
    assert Task.of(3).bind(sum(3)).fork(lambda x: x, None) == 9
    assert Task.of(3).bind