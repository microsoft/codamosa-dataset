

# Generated at 2022-06-24 00:31:37.715589
# Unit test for method bind of class Task
def test_Task_bind():
    def toUpper(s):
        return s.upper()

    def toLength(s):
        return Task.of(len(s))

    task = Task.of("world")
    result = task.bind(toUpper).bind(toLength)
    assert result.fork(None, None) == 10

# Generated at 2022-06-24 00:31:42.732356
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    plus_one = task.map(lambda arg: arg + 1).fork(lambda _: None, print)
    assert plus_one == 2

    task = Task.of(1)
    plus_one = task.map(lambda arg: arg + 1).map(lambda arg: arg * 2).fork(lambda _: None, print)
    assert plus_one == 4

    resolved = Task.of(1)
    rejected = resolved.map(lambda _: raise_error()).fork(raise_error, lambda _: None)
    assert rejected == None

    rejected = Task.reject(1)
    rejected2 = rejected.map(lambda _: raise_error()).fork(raise_error, lambda _: None)
    assert rejected2 == None


# Generated at 2022-06-24 00:31:52.223580
# Unit test for method map of class Task
def test_Task_map():
    """
    Call `Task.of(value)`, then call `Task.map(fn)` with some function.
    Call `fork` method of result `Task` and check that this `Task` returns the same value as
    `fn(value)` returns.
    """

    def check_correct(task, fn, value):
        def resolve(arg):
            assert arg == fn(value)

        def reject(arg):
            assert False

        task.fork(reject, resolve)

    link = lambda x: x + 1

    check_correct(Task.of(1), link, 1)
    check_correct(Task.of(2), link, 2)
    check_correct(Task.of(3), link, 3)
    check_correct(Task.of(4), link, 4)


# Generated at 2022-06-24 00:31:59.942897
# Unit test for method bind of class Task
def test_Task_bind():
    def before():
        print('before test')

    def after():
        print('after test')

    def fn(value):
        if value:
            return Task.of(value)
        else:
            return Task.of('return')

    assert Task.reject(1).bind(fn).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1

    before()
    fn2 = lambda _: after()
    assert Task.of(False).bind(fn).fork(
        fn2,
        fn2
    ) == 'return'


# Generated at 2022-06-24 00:32:01.850628
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x ** 2).fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-24 00:32:04.397205
# Unit test for method bind of class Task
def test_Task_bind():
    """
    This first test task is nested as fork function of and method bind of Task be applied
    with simple function of lambda x: Task.of(x + 10) that return new Task with value
    + 10 from argument Task.
    """
    test_task_bind_result()


# Generated at 2022-06-24 00:32:07.908714
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1).map(lambda x: x * 2)

    def result(reject, resolve):
        if resolve(2) != 2:
            reject('Task.map is broken')

    task.fork(
        reject=lambda error: raise_(error),
        resolve=result
    )

# Test Task.of

# Generated at 2022-06-24 00:32:17.485142
# Unit test for method bind of class Task
def test_Task_bind():
    # Task.bind will call resolve of Task by first argument
    resolve = Mock()
    # Task.bind will call reject of Task by second argument
    reject = Mock()

    # Task[reject, resolve] -> Task[resolve, reject]
    task = Task(lambda reject, resolve: resolve("result"))

    task = task.bind(lambda arg: Task(lambda reject, resolve: reject("rejected")))

    # call fork of task
    task.fork(resolve, reject)

    # Check it resolves
    reject.assert_called_with("rejected")

    # Check that reject doesn't called
    resolve.assert_not_called()


# Generated at 2022-06-24 00:32:19.934997
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(3)).map(lambda arg: arg + 2).fork(lambda _: None, lambda arg: arg) == 5


# Generated at 2022-06-24 00:32:22.129164
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x ** 2).fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-24 00:32:28.538319
# Unit test for constructor of class Task
def test_Task():
    # Case of success
    fork_1 = lambda _, resolve: resolve('resolved')
    task = Task(fork = fork_1)
    assert task.fork(lambda a: a, lambda a: a) == 'resolved'

    # Case of failure
    fork_2 = lambda reject, _: reject('rejected')
    task = Task(fork = fork_2)
    assert task.fork(lambda a: a, lambda a: a) == 'rejected'


# Generated at 2022-06-24 00:32:37.545035
# Unit test for method map of class Task
def test_Task_map():
    """ Unit test for method map of class Task """
    def add1(value):
        return value + 1

    def fork(reject, resolve):
        return reject(1)

    fork_calls = 0
    reject_calls = 0
    resolve_calls = 0

    def fake_reject(value):
        nonlocal reject_calls
        reject_calls += 1

    def fake_resolve(value):
        nonlocal resolve_calls
        resolve_calls += 1

    def fake_fork(reject, resolve):
        nonlocal fork_calls
        fork_calls += 1
        return fork(reject, resolve)

    task = Task(fake_fork)
    task.map(add1).fork(fake_reject, fake_resolve)

    assert fork_calls == 1

# Generated at 2022-06-24 00:32:42.251440
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    task = task.bind(lambda i: Task.of(i + 1))
    result_task = task.bind(lambda i: Task.of(i + 1))


# Generated at 2022-06-24 00:32:44.201611
# Unit test for method map of class Task
def test_Task_map():
    def add1(value):
        return value + 1

    for i in range(0, 100):
        assert Task.of(i).map(add1).fork(None, None) == i + 1


# Generated at 2022-06-24 00:32:55.032575
# Unit test for method bind of class Task
def test_Task_bind():
    task1 = Task.of(21)
    task2 = Task.of(2)
    task3 = Task.reject(3)

    def f1(value):
        """
        Return Task with stored value argument.

        :param value: value to store in Task
        :type value: A
        :returns: resolved Task
        :rtype: Task[Function(_, resolve) -> A]
        """
        return Task.of(value + 1)

    def f2(value):
        """
        Return Task with stored value argument.

        :param value: value to store in Task
        :type value: A
        :returns: rejected Task
        :rtype: Task[Function(reject, _) -> A]
        """
        return Task.reject(value + 2)


# Generated at 2022-06-24 00:32:59.161715
# Unit test for constructor of class Task
def test_Task():
    assert Task.of('value')
    assert Task.of(0)
    assert Task.reject('error')
    assert Task.reject(0)


# Generated at 2022-06-24 00:33:05.085866
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return 'Bonjour ' + value

    assert Task(lambda _, resolve: resolve('World')).map(mapper).fork(lambda a: '', lambda a: a) == 'Bonjour World'
    assert Task(lambda _, resolve: resolve('World')).map(mapper).map(str.lower).fork(lambda a: '', lambda a: a) == 'bonjour world'


# Generated at 2022-06-24 00:33:09.017666
# Unit test for constructor of class Task
def test_Task():
    def value_after_fork(reject, resolve):
        return resolve(5)

    assert Task(value_after_fork).fork(log, log) == 5

# Generated at 2022-06-24 00:33:13.837443
# Unit test for constructor of class Task
def test_Task():
    def fork_function(reject, resolve):
        raise AssertionError('Should not be called')

    def task_mapper(value):
        raise AssertionError('Should not be called')

    task = Task(fork_function)
    task = task.map(task_mapper)



# Generated at 2022-06-24 00:33:20.283520
# Unit test for method map of class Task
def test_Task_map():
    import random

    def div_2(value):
        return value / 2

    def five_times_plus_one(value):
        return value * 5 + 1

    def generate_random_number():
        return Task.of(random.randrange(100))

    def is_odd(value):
        return value % 2 != 0

    def plus_one(value):
        return value + 1

    expected = Task.of(2).map(plus_one).map(div_2)
    result = Task.of(4).map(plus_one).map(div_2)
    assert expected.fork(not_used, num) == result.fork(not_used, num)
    assert expected.fork(not_used, num) == 1.5


# Generated at 2022-06-24 00:33:28.859127
# Unit test for method map of class Task
def test_Task_map():
    a = Task(lambda reject, resolve: resolve(2))
    assert a.map(lambda x: x * x).fork(
        lambda _: None,
        lambda arg: arg
    ) == 4
    assert a.map(lambda x: x + 5).fork(
        lambda _: None,
        lambda arg: arg
    ) == 7
    assert Task.of(2).map(lambda x: x * x).fork(
        lambda _: None,
        lambda arg: arg
    ) == 4
    assert Task.of(2).map(lambda x: x + 5).fork(
        lambda _: None,
        lambda arg: arg
    ) == 7


# Generated at 2022-06-24 00:33:39.078137
# Unit test for method bind of class Task
def test_Task_bind():
    # Arrange
    first_value, second_value = 0, 5

    def mapper(value):
        """
        Mapper function

        :param value: value to increment
        :type value: Any
        :returns: increment value
        :rtype: Any
        """
        return value + 1

    def check_equal(value):
        """
        Check is value equals to expected value

        :param value: value to check
        :type value: Any
        :returns: result of equality
        :rtype: Task[reject, value]
        """
        return Task.of(value == second_value)

    # Act
    result = Task.of(first_value).bind(mapper).bind(check_equal)

    # Assert

# Generated at 2022-06-24 00:33:47.422822
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind should return Task with mapped resolve value
    """
    tokens = {
        0: 'foo',
        1: 'bar',
        2: 'baz',
        3: 'qux',
    }

    def getToken(index):
        fn = lambda reject, resolve: resolve(tokens[index])
        return Task(fn)

    def testTokenIs(resolve, reject):
        def verifyToken(index):
            def verify(value):
                assert value is tokens[index], "{} is not expected value".format(value)
                resolve()

            return verify

        return verifyToken


# Generated at 2022-06-24 00:33:51.575811
# Unit test for constructor of class Task
def test_Task():
    """
    Test for creating Task.
    """
    assert Task.of(10).fork(lambda x: 1, lambda x: x) == 10
    assert Task.reject(10).fork(lambda x: x, lambda x: 1) == 10


# Generated at 2022-06-24 00:33:57.244923
# Unit test for constructor of class Task
def test_Task():
    result = Task(lambda reject, resolve: resolve(1))
    assert hasattr(result, 'fork')
    assert isinstance(result.fork, types.FunctionType)
    assert result.fork(None, None) == 1


# Generated at 2022-06-24 00:34:00.530759
# Unit test for method map of class Task
def test_Task_map():
    def test(action): action()

    test(lambda: assertEqual(
        Task.of(1).map(lambda n: n * 2).fork(lambda _: None, lambda n: n * 3),
        6
    ))

# Generated at 2022-06-24 00:34:05.466035
# Unit test for constructor of class Task
def test_Task():
    # test of of constructor
    resolved = Task.of('resolved')
    assert resolved.fork(None, lambda value: value) == 'resolved'

    # test of rejected constructor
    rejected = Task.reject('rejected')
    assert rejected.fork(lambda value: value, None) == 'rejected'

    # test of map function
    wrapper = Task.of('value')
    mapped = wrapper.map(lambda x: len(x))
    assert mapped.fork(None, lambda value: value) == 5


# Generated at 2022-06-24 00:34:16.880557
# Unit test for method map of class Task
def test_Task_map():
    """
    Call task with mapped function and check that resolve function called with expected
    argument.

    :returns: None
    :rtype: NoneType
    """

    @pytest.fixture
    def data():
        """
        Create dict with value, resolve and reject functions.

        :returns: dict
        :rtype: dict
        """
        return {'value': None, 'resolution': None}

    @pytest.fixture
    def resolve():
        """
        Return function for set resolution of task.

        :returns: function
        :rtype: Function
        """
        def result(value):
            data['resolution'] = 'resolve'
            data['value'] = value

        return result


# Generated at 2022-06-24 00:34:18.436077
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, __: True).fork(lambda _: False, lambda __: True) is True


# Generated at 2022-06-24 00:34:24.664296
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test `bind` method of Task class.
    """

    def run_test(arg1, expected):
        """
        Run test for Task.bind method.

        :param arg1: value to store in Task
        :type arg1: A
        :param expected: value to compare arguments with
        :type expected: B
        """
        result = Task.of(arg1).bind(lambda x: Task.of(x))
        assert result.fork(lambda x: x, lambda x: x) == expected

    run_test(1, 1)
    run_test(2, 2)



# Generated at 2022-06-24 00:34:27.009480
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        return Task.of(x + 1)

    task = Task.of(5)
    task = task.bind(f)

    assert task.fork(None, lambda x: x) == 6


# Generated at 2022-06-24 00:34:29.845305
# Unit test for method map of class Task
def test_Task_map():
    source_task = Task(lambda reject, resolve: resolve(100))
    def mapper(value):
        return value * value

    assert source_task.map(mapper).fork(None, lambda x: x) == 10000


# Generated at 2022-06-24 00:34:31.136404
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(10)).fork(lambda _: None, print) == None


# Generated at 2022-06-24 00:34:36.638886
# Unit test for method map of class Task
def test_Task_map():
    def assert_correct_value(method, value, expected_value):
        def assert_(reject, resolve):
            reject('fail')
            resolve(expected_value)

        task = Task(assert_)
        assert task.map(method).fork('fail', lambda result: result) == expected_value

    assert_correct_value(lambda arg: arg + 1,      1, 2)
    assert_correct_value(lambda arg: arg + ' test', 'test', 'test test')
    assert_correct_value(lambda arg: [1, 2, 3], 'test', [1, 2, 3])
    assert_correct_value(lambda arg: {'test': 123}, 'test', {'test': 123})


# Generated at 2022-06-24 00:34:44.393402
# Unit test for method map of class Task
def test_Task_map():
    def handler(fn, argument, expected):
        def assert_map(result):
            assert result == expected

        task = Task.of(argument)

# Generated at 2022-06-24 00:34:48.431015
# Unit test for method bind of class Task
def test_Task_bind():

    assert Task.reject(1).bind(lambda x: Task.reject(2)).fork(
        lambda x: x,
        lambda _: None
    ) == 2


# Generated at 2022-06-24 00:34:52.782289
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map(add1)
    Task.of(1).map(add1) == Task.of(2)
    """
    def add1(x):
        return x + 1

    assert Task.of(1).map(add1) == Task.of(2)


# Generated at 2022-06-24 00:34:58.516920
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(x):
        return Task.of(x + 2)

    def mapper_2(x):
        return Task.of(x * 2)

    task = Task.of(10)
    task2 = task.bind(mapper).bind(mapper_2)

    assert task2.fork(
        lambda x: print(x, x == 14),
        lambda x: print(x, x == 14)
    )

# Generated at 2022-06-24 00:35:01.082221
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    another_task = task.bind(lambda arg: Task.of(arg + 1))
    assert another_task.fork(lambda arg: arg, lambda arg: arg) == 2
    task = Task.reject(1)
    another_task = task.bind(lambda arg: Task.of(arg + 1))
    assert another_task.fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-24 00:35:04.405697
# Unit test for method bind of class Task
def test_Task_bind():
    fn_to_map = lambda value: value * 2
    def fn_to_bind(value):
        return Task.of(value * 2)

    task = Task.of(2)
    assert task.map(fn_to_map).fork(None, None) == 4
    assert task.bind(fn_to_bind).fork(None, None) == 4



# Generated at 2022-06-24 00:35:07.151527
# Unit test for method map of class Task
def test_Task_map():
    def reject(arg):
        assert arg == 2
        print("reject: %d passed" % arg)

    def resolve(arg):
        assert arg == 4
        print("resolve: %d passed" % arg)

    Task.of(2).map(lambda x: 2 * x).fork(reject, resolve)


# Generated at 2022-06-24 00:35:13.115155
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map(fn) <=> Task(lambda reject, resolve: resolve(fn(value)))
    """

    task = Task(lambda _, resolve: resolve(2))
    result = task.map(lambda arg: arg * 2)

    assert isinstance(result, Task)
    assert result.fork(None, None) == 4


# Generated at 2022-06-24 00:35:16.911334
# Unit test for constructor of class Task
def test_Task():
    def check(result):
        assert result == 'value'

    def check_reject(error):
        assert error == 'error'

    def test_fn(_, resolve):
        assert True
        resolve('value')
    t = Task(test_fn)
    t.fork(check_reject, check)

    def test_fn_reject(reject, _):
        assert True
        reject('error')
    t = Task(test_fn_reject)
    t.fork(check_reject, check)


# Generated at 2022-06-24 00:35:23.263851
# Unit test for method map of class Task
def test_Task_map():
    def test_arg(value):
        return Task.of(value)

    assert isinstance(test_arg(1).map(lambda arg: arg + 1), Task)
    assert test_arg(1).map(lambda arg: arg + 1).fork(
        lambda arg: False,
        lambda arg: arg == 2
    )


# Generated at 2022-06-24 00:35:30.782733
# Unit test for constructor of class Task
def test_Task():
    def noop(_, __):
        pass

    def fn(_, __):
        return 10

    def fn_a(_, __):
        return 'a'

    Task(noop).map(str).fork(print, print)
    Task(fn).map(str).fork(print, print)
    Task(fn).map(lambda x: x * 2).fork(print, print)
    Task(fn_a).map(lambda x: x + 'b').fork(print, print)
    Task(fn_a).bind(
        lambda x: Task.of('test')).fork(
            print,
            print
        )

    Task.reject(100).map(print).fork(print, print)
    Task.of(100).map(print).fork(print, print)

# Generated at 2022-06-24 00:35:35.830048
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(100) \
        .bind(lambda value: Task.of(value * 5)) \
        .fork(None, None) == 500

    assert Task.reject(100) \
        .bind(lambda value: Task.of(value * 5)) \
        .fork(None, None) == 100

    assert Task.of(100) \
        .bind(lambda value: Task.reject(value * 5)) \
        .fork(None, None) == 500

    assert Task.reject(100) \
        .bind(lambda value: Task.reject(value * 5)) \
        .fork(None, None) == 100


# Generated at 2022-06-24 00:35:40.165472
# Unit test for constructor of class Task
def test_Task():
    def result(reject, resolve):
        assert reject is not None
        assert resolve is not None

    fork = Task(result)
    assert fork.fork is result


# Generated at 2022-06-24 00:35:44.297914
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(5))
    assert task.fork(lambda a: a, lambda a: a) == 5

    print('All Test Run !!!')

# Test for Task.of(value) method

# Generated at 2022-06-24 00:35:49.570590
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind functonality of class Task.
    """
    task = Task.of(4).bind(
        lambda x: Task.of(x + 1)
    )

    result, is_resolved = task.fork(lambda x: (x, False), lambda x: (x, True))

    assert is_resolved
    assert result == 5


# Generated at 2022-06-24 00:35:55.095227
# Unit test for method bind of class Task
def test_Task_bind():
    def assertFork(rejected, resolved):
        assert rejected(rejected) == rejected
        assert resolved(resolved) == resolved

    fork = lambda _, resolve: resolve(5)
    Task(fork).map(lambda arg: arg + 5).map(assertFork)
    Task(fork).bind(lambda arg: Task.of(arg + 5)).map(assertFork)
    Task(fork).bind(lambda arg: Task.reject(arg + 5)).map(assertFork)

if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-24 00:35:57.056535
# Unit test for method map of class Task
def test_Task_map():
    value = Task.of(0)
    assert value.map(lambda arg: arg + 2).fork(None, None) == 2


# Generated at 2022-06-24 00:36:00.836191
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(
        raise_it,
        lambda x: x
    ) == 2
    assert Task.reject(1).map(lambda x: x + 1).fork(
        lambda x: x,
        raise_it
    ) == 1


# Generated at 2022-06-24 00:36:04.707720
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        pass

    task = Task(fork=fork)

    assert task.fork == fork


# Generated at 2022-06-24 00:36:08.103541
# Unit test for method map of class Task
def test_Task_map():
    def test(fn, value, expected):
        assert Task.of(value).map(fn).fork(None, lambda arg: arg) == expected

    test(lambda x: x * 2, 1, 2)
    test(lambda x: x ** 3, 2, 8)


# Generated at 2022-06-24 00:36:09.617471
# Unit test for constructor of class Task
def test_Task():
    def two(reject, resolve):
        resolve(2)

    assert Task(two).fork == two


# Generated at 2022-06-24 00:36:12.327912
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of Task
    """
    def fork(reject, resolve):
        reject('error')
        return resolve('success')

    task = Task(fork)
    assert task.fork(print, print) == 'error'


# Generated at 2022-06-24 00:36:13.492404
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor Task.
    """

    pass


# Generated at 2022-06-24 00:36:16.140887
# Unit test for method map of class Task
def test_Task_map():
    def on_error(error):
        assert False

    def on_resolve(value):
        assert value == 2

    Task.of(1).map(lambda value: value + 1).fork(on_error, on_resolve)


# Generated at 2022-06-24 00:36:22.043849
# Unit test for method map of class Task
def test_Task_map():
    assert Task \
        .of("value") \
        .map(lambda arg: "mapped_" + arg) \
        .fork(None, lambda arg: arg) == "mapped_value"


# Generated at 2022-06-24 00:36:22.712700
# Unit test for constructor of class Task
def test_Task():
    assert Task  # TODO: make more useful test for test_Task



# Generated at 2022-06-24 00:36:27.357397
# Unit test for constructor of class Task
def test_Task():
    # create Task object with fork function to add 2 to argument of resolve function
    result = Task(lambda _, resolve: resolve(2)).fork(lambda _: _, lambda arg: arg + 2)

    # check result
    Test.describe('Task.fork')
    Test.it('should return result of calling fork function')
    Test.assert_equals(result, 4)


# Generated at 2022-06-24 00:36:30.517944
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task (without coverage).
    """
    task = Task(lambda reject, resolve: resolve(1))
    assert task.fork(None, lambda value: value == 1)


# Generated at 2022-06-24 00:36:40.535521
# Unit test for method map of class Task
def test_Task_map():
    # Task test with pass value
    task_test_pass_value = Task(lambda _, resolve: resolve(10))
    task_test_pass_value_result = task_test_pass_value.map(lambda x: x + 1).fork(
        lambda e: e,
        lambda x: x
    )
    print("Task with pass value: ", task_test_pass_value_result)

    # Task test with error value
    task_test_error_value = Task(lambda reject, _: reject("error_value"))
    task_test_error_value_result = task_test_error_value.map(lambda x: x + 1).fork(
        lambda e: e,
        lambda x: x
    )
    print("Task with error value: ", task_test_error_value_result)


# Generated at 2022-06-24 00:36:42.672263
# Unit test for constructor of class Task
def test_Task():
    @Task
    def test():
        return 1

    assert test.fork('reject', 'resolve') == 'resolve'



# Generated at 2022-06-24 00:36:46.999912
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(
        lambda value: False,
        lambda value: value == 1
    )

    assert Task(lambda reject, _: reject(1)).fork(
        lambda value: value == 1,
        lambda value: False
    )


# Generated at 2022-06-24 00:36:55.282600
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        """
        Function to map.

        :param value: value to map
        :type value: int
        :returns: new task, with mapped value
        :rtype: Task[reject, mapped_value]
        """
        def fork(reject, resolve):
            if value > 5:
                return reject(value)
            return resolve(value)

        return Task(fork)

    task = Task.of(10).bind(mapper)
    assert task.fork(lambda value: value, lambda value: value) == 10

    task = Task.of(3).bind(mapper)
    assert task.fork(lambda value: value, lambda value: value) == 3



# Generated at 2022-06-24 00:37:06.316744
# Unit test for method bind of class Task
def test_Task_bind():
    def skip(n):
        """
        Helper function to reject n times after resolving.

        :param n: number of resolving before rejecting
        :type n: int
        :returns: Task with resolve, reject
        :rtype: Task[Function(reject, resolve) -> int]
        """
        def result(reject, resolve):
            for i in range(n):
                resolve(i)
            reject('Reject me')
            return 0

        return Task(result)

    def do_nothing(_):
        """
        Do nothing.

        :param _: ignored argument
        :type: A
        :returns: None
        """
        return


# Generated at 2022-06-24 00:37:08.258021
# Unit test for method map of class Task
def test_Task_map():
    Task.of(None).map(lambda _: True).fork(
        lambda _: assertFalse(True),
        lambda value: assertTrue(value)
    )


# Generated at 2022-06-24 00:37:09.560637
# Unit test for method map of class Task
def test_Task_map():
    def increment(value):
        return value + 1

    task = Task.of(1)
    assert create_result(task.map(increment).fork(None, None)) == 2



# Generated at 2022-06-24 00:37:12.432602
# Unit test for method map of class Task
def test_Task_map():
    assert json.dumps(
        Task(lambda reject, resolve: resolve(["test", "message"]))
            .map(lambda arg: ["Task", "unit test"])
            .fork(lambda arg: arg, lambda arg: arg)
    ) == json.dumps(["Task", "unit test"])



# Generated at 2022-06-24 00:37:16.142241
# Unit test for method bind of class Task
def test_Task_bind():
    def fork_fn(reject, resolve):
        resolve(5)

    def map_fn(value):
        return value * 2

    task = Task(fork_fn)
    task = task.bind(lambda value: Task.of(value * 2))

    assert task.fork(lambda value: False, lambda value: value == 20)

    task = Task(fork_fn)
    task = task.bind(lambda value: Task.reject(value * 2))

    assert task.fork(lambda value: value == 10, lambda value: False)


# Generated at 2022-06-24 00:37:18.269367
# Unit test for constructor of class Task
def test_Task():
    res = Task(lambda _, resolve: resolve(5))
    # res = Task.of(5)

    if not isinstance(res, Task):
        raise Exception("Task is not instance of Task")


# Generated at 2022-06-24 00:37:22.106145
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda _: 'rejected', lambda _: 'resolved') == 'resolved'
    assert Task.reject(1).fork(lambda _: 'rejected', lambda _: 'resolved') == 'rejected'


# Generated at 2022-06-24 00:37:27.940613
# Unit test for method bind of class Task
def test_Task_bind():
    def get_Task():
        return Task.of(1)

    def add(num):
        return Task.of(num + 1)

    def subtract(num):
        return Task.of(num - 1)

    result = Task.of(1).bind(add).bind(subtract).fork(lambda x: x, lambda x: x)
    assert result == 1



# Generated at 2022-06-24 00:37:29.600845
# Unit test for constructor of class Task
def test_Task():
    fn = lambda arg: arg
    task = Task(fn)

    assert task.fork == fn


# Generated at 2022-06-24 00:37:31.648499
# Unit test for constructor of class Task
def test_Task():
    fork = lambda reject, resolve: resolve(2)
    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-24 00:37:34.740979
# Unit test for constructor of class Task
def test_Task():
    assert Task([]) == Task([])
    assert Task('s') != Task([])
    assert Task(1).fork(lambda: 1, lambda: 0) == 0
    assert Task(1).fork(lambda: 1, lambda: 0) != 1


# Generated at 2022-06-24 00:37:36.646381
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1) == Task(lambda _, resolve: resolve(1))
    assert Task.reject(1) == Task(lambda reject, _: reject(1))


# Generated at 2022-06-24 00:37:42.889307
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(a: int) -> Task[int, int]:
        return Task.of(a * 2)

    task = Task.of(10).bind(fn)
    result = task.fork(lambda _: None, lambda x: x)
    assert result == 20


# Generated at 2022-06-24 00:37:48.281481
# Unit test for method map of class Task
def test_Task_map():
    identity = lambda value: value
    identity_task = Task.of(identity)

    assert identity_task.fork(lambda _: None, lambda fn: fn(1)) == 1
    assert identity_task.fork(lambda _: None, lambda fn: fn(1)) == identity(1)



# Generated at 2022-06-24 00:37:53.140055
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    def callback(stat, data):
        """
        Test callback

        :param stat: callback stat
        :type stat: Boolean
        :param data: callback data
        :type data: Any
        """
        assert stat is True
        assert data == 'test'

    def rejected(stat, data):
        """
        Test callback for reject case

        :param stat: callback stat
        :type stat: Boolean
        :param data: callback data
        :type data: Any
        """
        assert stat is False
        assert data == 'error'

    resolved = Task.of('test')
    rejected = Task.reject('error')

    resolved.bind(lambda arg: arg).fork(rejected, callback)

# Generated at 2022-06-24 00:38:03.088675
# Unit test for method map of class Task
def test_Task_map():
    # add: Function(a: int, b: int) -> int
    add = lambda a, b: a + b
    # increment: Function(a: int) -> int
    increment = lambda a: a + 1
    # decreasing: Function(a: int) -> int
    decreasing = lambda a: a - 1

    # t1: Task[reject, add(2, 3)]
    t1 = Task.of(2).map(lambda x: add(x, 3))

    # t2: Task[reject, add(2, add(3, 4))]
    t2 = Task.of(2).map(lambda x: add(x, 3)).map(lambda x: add(x, 4))

    # t3: Task[reject, add(2, add(3, add(4, 5)))]

# Generated at 2022-06-24 00:38:06.795498
# Unit test for method map of class Task
def test_Task_map():
    def value_map(value):
        return value + 1

    assert Task.of(1).map(value_map).fork(
        lambda arg: None, lambda arg: arg == 2)



# Generated at 2022-06-24 00:38:14.726261
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test bind method of class Task

    :returns: true
    :rtype: bool
    """
    def fn(x):
        return Task.of(x + 1)

    def fn_mul_twice(x):
        return Task.of(x * 2)

    def fn_div_two(x):
        return Task.of(x / 2)

    assert Task([2]).bind(fn).bind(fn_mul_twice).fork([], lambda x: x)[0] == 6
    assert Task([2]).bind(fn).bind(fn_div_two).fork([], lambda x: x)[0] == 2

    return True


# Generated at 2022-06-24 00:38:16.552254
# Unit test for method map of class Task
def test_Task_map():
    foo = Task.of(1).map(lambda value: value + 1)
    assert foo.fork(lambda value: None, lambda value: value) == 2


# Generated at 2022-06-24 00:38:23.258295
# Unit test for method bind of class Task
def test_Task_bind():
    random_number = random.randint(1, 10)
    task = Task.of(random_number)
    task_2 = task.bind(lambda x: Task.of(x * 2))

    def resolve(value):
        assert value == random_number * 2
    def reject(_):
        raise AssertionError("Shouldn't be called")

    task_2.fork(reject, resolve)


# Generated at 2022-06-24 00:38:25.555927
# Unit test for method map of class Task
def test_Task_map():
    task = Task((lambda x, _: x(5))).map(lambda x: x*4)
    assert task.fork(lambda x: x) == 20



# Generated at 2022-06-24 00:38:29.406548
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x + 2

    # Create new task with fork attr
    task = Task(lambda reject, resolve: resolve(2))

    assert task.map(fn).fork(lambda _: None, lambda x: 2 + 2) == 4


# Generated at 2022-06-24 00:38:33.468668
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(
        lambda err: err,
        lambda value: value,
    ) == 2
    assert Task.reject('error').map(lambda x: x + 1).fork(
        lambda err: err,
        lambda value: value,
    ) == 'error'


# Generated at 2022-06-24 00:38:38.470619
# Unit test for constructor of class Task
def test_Task():
    # Positive tests
    # Check correct resolve
    a = 12
    task = Task.of(a)
    result = task.fork(lambda e: e, lambda s: s)
    assert result == a

    # Check correct reject
    b = 22
    reject_task = Task.reject(b)
    result_reject = reject_task.fork(lambda e: e, lambda s: s)
    assert result_reject == b

    # Negative tests
    # Check exception in case when fork wrong
    assert Task(lambda _: _).fork(lambda e: e, lambda s: s) is None



# Generated at 2022-06-24 00:38:46.132626
# Unit test for method map of class Task
def test_Task_map():
    def square(x): return x * x

    def id(x): return x

    def reject_as_square(x): return Task.reject(square(x))

    def resolve_as_square(x): return Task.of(square(x))

    square_task = Task.of(2).map(square)
    square_task_resolve = square_task.fork(id, id)
    assert square_task_resolve == 16

    square_task = Task.reject(2).map(square)
    square_task_reject = square_task.fork(id, id)
    assert square_task_reject == 2

    square_task = Task.of(2).map(square).map(id)
    square_task_resolve = square_task.fork(id, id)
    assert square_task_

# Generated at 2022-06-24 00:38:49.455421
# Unit test for constructor of class Task
def test_Task():
    """
    test_Task
    """
    task = Task(lambda _, resolve: resolve(5))
    assert task.fork is not None



# Generated at 2022-06-24 00:38:50.833746
# Unit test for constructor of class Task
def test_Task():
    t = Task(lambda _, resolve: resolve(2 + 2))

    assert t.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 4


# Generated at 2022-06-24 00:38:58.630645
# Unit test for method map of class Task
def test_Task_map():
    input_value = 42

    # task is resolved Task with stored value
    task = Task.of(input_value)

    # Mapper function take A and return B
    def mapper(value):
        return value * 2

    # apply mapper function to task
    result = task.map(mapper)

    # import pdb; pdb.set_trace()

    # To get value we need to fork result task
    # For fork using identity function
    result_value = result.fork(identity, identity)

    # Check value returned from task
    # Assert: input_value * 2 == result_value
    assert input_value * 2 == result_value



# Generated at 2022-06-24 00:39:03.257661
# Unit test for method map of class Task

# Generated at 2022-06-24 00:39:10.294170
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def double(x):
        return x * 2

    def reject(x):
        return Task.reject(x)


# Generated at 2022-06-24 00:39:20.781954
# Unit test for method map of class Task
def test_Task_map():
    """
    Test cases for Task.map method

    Test case:
    1. Test case with map function that f(x) = x - 1
    2. Test case:
        - Task.map(f)
        - Task.map(f)
        - Task.map(f)

    :returns: None
    :rtype: None
    """
    def task_1_fork(_, resolve):
        resolve(1)

    def task_2_fork(_, resolve):
        resolve(2)

    def task_3_fork(_, resolve):
        resolve(3)

    def f(x):
        return x - 1

    # Test case 1
    task_1 = Task(task_1_fork).map(f)
    res1 = task_1.fork(lambda x: x, lambda _: None)
   

# Generated at 2022-06-24 00:39:22.853834
# Unit test for constructor of class Task
def test_Task():
    assert Task((lambda reject, resolve: resolve(10))).fork(lambda a: a, lambda a: a) == 10

# Generated at 2022-06-24 00:39:31.571322
# Unit test for method map of class Task
def test_Task_map():
    def is_42(value):
        if value == 42:
            return True
        else:
            return False

    task = Task.of(42)
    mapped_task = task.map(is_42)

    def fork(reject, resolve):
        reject()
        resolve()

    another_mapped_task = Task(fork).map(is_42)

    # Test for resolved Task
    assert mapped_task.fork(None, lambda arg: arg) == True

    # Test for rejected Task
    assert another_mapped_task.fork(lambda arg: arg, None) == None


# Generated at 2022-06-24 00:39:36.847588
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(v):
        assert v == '42'

    # Rejected task with value '3.14' this will cause
    # that method bind will return rejected task
    # with value '3.14'
    Task.reject('3.14').bind(lambda _: Task.of('42')).fork(lambda x: x, resolve)

    # Resolved task with value '3.14' this will cause
    # that method bind will return resolved task
    # with value '42'
    Task.of('3.14').bind(lambda _: Task.of('42')).fork(lambda x: x, resolve)

if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-24 00:39:45.600170
# Unit test for constructor of class Task
def test_Task():
    """
    Test that Task construct with fork in constructor
    and able to map resolve
    and able to map reject
    """
    def test(resolve, reject):
        resolve(1)

    assert Task(test).fork(lambda _: 'reject', lambda _: 'resolve') == 'resolve'

    def test(resolve, reject):
        reject(1)

    assert Task(test).fork(lambda _: 'reject', lambda _: 'resolve') == 'reject'

    def func(value):
        return value + 1

    assert Task(test).map(func).fork(lambda _: 'reject', lambda _: 'resolve') == 'reject'



# Generated at 2022-06-24 00:39:53.687115
# Unit test for method bind of class Task
def test_Task_bind():
    # most simple case
    def mapper(value):
        return Task.of(value + 1)

    def adder(value):
        return value + 3

    result = Task.of(5).bind(mapper).map(adder)

    assert result.fork(lambda _: None, lambda value: value == 9)

    # case with error
    def mapper_error(value):
        return Task.reject(value + 1)

    def receiver_error(value):
        raise Exception("We should never see this message")

    result = Task.reject(5).bind(mapper_error).map(receiver_error)
    assert result.fork(lambda value: value == 6, lambda _: False)


# Generated at 2022-06-24 00:40:05.003632
# Unit test for method bind of class Task
def test_Task_bind():
    def bind(value):
        return Task.of(value).bind(lambda v: Task.of(v * 2))

    def bind_chain(value):
        return Task.of(value).bind(lambda v: Task.of(v * 2)).bind(lambda v: Task.of(v * 2))

    def test_with_resolved():
        assert bind(1).fork(lambda _: None, lambda v: v) == 2
        assert bind_chain(1).fork(lambda _: None, lambda v: v) == 4

    def test_with_rejected():
        assert bind(1).fork(lambda _: None, lambda _: None) is None
        assert bind_chain(1).fork(lambda _: None, lambda _: None) is None

    test_with_resolved()
    test_with_rejected()


# Generated at 2022-06-24 00:40:14.220402
# Unit test for constructor of class Task
def test_Task():
    def test_fork(reject, resolve):
        reject(10)

    def mapped_fork(reject, resolve):
        resolve(10)

    def reject_fork(_, reject):
        reject(10)

    t1 = Task(test_fork)
    assert t1.fork(lambda r: r, lambda r: r) == 10

    t2 = Task(lambda _, resolve: resolve(10)).map(lambda value: value*10)
    assert t2.fork(lambda r: r, lambda r: r) == 100

    t3 = Task(test_fork).bind(lambda value: Task(mapped_fork))
    assert t3.fork(lambda r: r, lambda r: r) == 10

    t4 = Task(test_fork).bind(lambda value: Task(reject_fork))

# Generated at 2022-06-24 00:40:22.769345
# Unit test for method map of class Task
def test_Task_map():
    # Default value for resolve and reject
    task = Task(lambda _, resolve: resolve(""))
    assert task.map(lambda arg: arg).fork("", print) == ""

    # Custom value for resolve
    task = Task(lambda _, resolve: resolve("Foo"))
    assert task.map(lambda arg: arg).fork("", print) == "Foo"

    # Custom value for reject
    task = Task(lambda reject, _: reject("Bar"))
    assert task.map(lambda arg: arg).fork(lambda arg: arg, print) == "Bar"

# Generated at 2022-06-24 00:40:27.647528
# Unit test for method bind of class Task
def test_Task_bind():
    def test(resolve, reject):
        return Task.of(1).bind(lambda x: Task.of(2 + x)).fork(reject, resolve)

    assert Task(test)(lambda r: r)(lambda r: r) == 3



# Generated at 2022-06-24 00:40:34.898921
# Unit test for method map of class Task
def test_Task_map():
    t1 = Task.of(1)
    t2 = Task.of(2)
    t2 = t2.bind(lambda v: t1.map(lambda v1: v + v1))
    res = t2.fork(lambda _: False, lambda a: a == 3)
    assert res


# Generated at 2022-06-24 00:40:40.088585
# Unit test for constructor of class Task
def test_Task():
    # Check constructor of class Task
    assert callable(Task), "Constructor is not callable"
    assert len(signature(Task).parameters) == 1, "Constructor has wrong number of arguments"

    # Check constructor of class Task
    # Case: constructor raise exception with wrong index of argument
    try:
        Task()
    except TypeError as error:
        assert True
    else:
        assert False, "Constructor hasn't raise exception"


# Generated at 2022-06-24 00:40:43.460142
# Unit test for method map of class Task

# Generated at 2022-06-24 00:40:49.818290
# Unit test for method bind of class Task
def test_Task_bind():
    def catch(fn):
        def catch_err(reject, resolve):
            try:
                resolve(fn())
            except Exception as e:
                reject(e)
        return Task(catch_err)
    #: Task[String]
    task = Task.reject('Error!').bind(lambda e: Task.of('Error: ' + e))
    #: Task[String]
    task = catch(lambda: 1 / 0).bind(lambda value: Task.of(value + 1))


# Generated at 2022-06-24 00:40:51.051058
# Unit test for constructor of class Task
def test_Task():
    def function(*args):
        return Task.of(args)
    assert Task(function)


# Generated at 2022-06-24 00:40:55.922977
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(
        lambda fail: fail,
        lambda success: success,
    ) == 2

    assert Task.reject(2).bind(
        lambda x: Task.of(x + 1)).fork(
        lambda fail: fail,
        lambda success: success,
    ) == 2

    assert Task.of(1).bind(
        lambda x: Task.reject(x + 1)).fork(
        lambda fail: fail,
        lambda success: success,
    ) == 2


# Generated at 2022-06-24 00:41:00.564824
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task constructor
    """
    t = Task(lambda _, resolve: resolve([1, 2, 3]))
    assert t.fork(None, lambda x: x) == [1, 2, 3]


# Generated at 2022-06-24 00:41:08.308052
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('internal error')
    task = Task(fork)
    assert task.fork(lambda value: value, lambda _: 'ok') == 'internal error'

    with pytest.raises(AttributeError):
        task.reject

    with pytest.raises(AttributeError):
        task.resolve

    task = Task.of('OK')
    assert task.fork(lambda value: value, lambda _: 'not ok') == 'OK'

    task = Task.reject('NOT OK')
    assert task.fork(lambda value: value, lambda _: 'not ok') == 'NOT OK'


# Generated at 2022-06-24 00:41:11.324389
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve(2 + 3)

    task = Task(fork)

    assert isinstance(task, Task)
    assert task.fork(lambda e: e, lambda s: s) == 5


# Generated at 2022-06-24 00:41:16.540128
# Unit test for method map of class Task
def test_Task_map():
    def value(string):
        return string.upper()

    def resolve(value):
        pass

    def reject(value):
        pass

    task = Task.of('string').map(value)
    assert task.fork(reject, resolve) == 'STRING'


# Generated at 2022-06-24 00:41:21.560774
# Unit test for method map of class Task
def test_Task_map():
    def run(reject, resolve):
        return reject('Error')
    def fn(value):
        return value + 1
    task = Task(run)
    result = task.map(fn)
    assert result.fork(lambda x: x, lambda x: x) == 'Error'



# Generated at 2022-06-24 00:41:25.637899
# Unit test for constructor of class Task
def test_Task():
    """
    >>> Task.of(42).fork(lambda a: a, lambda b: b)
    42
    >>> Task.reject(42).fork(lambda a: a, lambda b: b)
    42
    """


# Generated at 2022-06-24 00:41:31.141098
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(1))
    assert task.fork(
        lambda _: "rejected",
        lambda value: f"resolved({value})"
    ) == "resolved(1)"

print(Task(lambda _, resolve: resolve(1)).fork(
        lambda _: "rejected",
        lambda value: f"resolved({value})"
    ))
print(Task(lambda reject, _: reject(1)).fork(
        lambda value: f"rejected({value})",
        lambda _: "resolved"
    ))
print(Task.of(1).fork(
        lambda value: f"rejected({value})",
        lambda value: f"resolved({value})"
    ))

# Generated at 2022-06-24 00:41:37.265825
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of Task class.
    """
    task = Task(lambda _, resolve: resolve('foo'))
    assert task.fork(lambda _: 'failed', lambda arg: arg) == 'foo'

    task = Task(lambda reject, _: reject('bar'))
    assert task.fork(lambda arg: arg, lambda _: 'failed') == 'bar'

# Test for static method "of (value)" of class Task