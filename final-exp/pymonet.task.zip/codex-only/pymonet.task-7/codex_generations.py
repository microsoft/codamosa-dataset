

# Generated at 2022-06-24 00:31:46.339784
# Unit test for method bind of class Task
def test_Task_bind():
    '''
    Task.bind takes mapper argument that takes result of fork function and return new Task with mapped value.
    Task.bind returns new Task that takes resolve, reject argument.
    During calling of new Task.fork function, it calls argument function (resolve, reject)
    with result of calling fork function of mapper argument.
    '''
    def mapper(arg):
        return Task.of(arg + 1)

    task = Task.of(1)
    assert task.bind(mapper).fork(lambda err: err, lambda result: result) == 2

    def mapper(arg):
        if arg < 0:
            return Task.reject(arg)
        return Task.of(arg ** 2)

    task = Task.of(-1)

# Generated at 2022-06-24 00:31:52.572706
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        print("resolve = %s" % value)

    def reject(value):
        print("reject = %s" % value)

    task = Task.of(1)
    task.bind(lambda value: Task.of(value + 1)).fork(reject, resolve)

    task2 = Task.reject("mistakes")
    task2.bind(lambda value: Task.of(value + 1)).fork(reject, resolve)


# Generated at 2022-06-24 00:31:58.459473
# Unit test for method map of class Task
def test_Task_map():
    def initial_value(reject, resolve):  # Task[Function(_, _) -> A]
        return resolve(5)

    task = Task(initial_value)
    task_map = task.map(lambda arg: arg + 2)  # Task[Function(_, _) -> B]

    assert task_map.fork(lambda arg: arg, lambda arg: arg) == 7  # B


# Generated at 2022-06-24 00:32:05.211706
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for bind method of Task class.
    """
    from hypothesis import given, assume, settings

    from .generate_data import hypothesis_settings
    from .generate_data import Int

    settings(**hypothesis_settings)
    @given(Int, Int)
    def hoge(arg1, arg2):
        assume(arg1 != arg2)

        source_Task = Task.of(arg1)
        binded_Task = source_Task.bind(lambda arg: Task.of(arg + arg2))

        assert binded_Task.fork(lambda _: '', lambda arg: arg) == arg1 + arg2


# Generated at 2022-06-24 00:32:11.898643
# Unit test for method map of class Task
def test_Task_map():
    """
    Test function for method map of class Task.
    """
    assert(Task(lambda reject, resolve: resolve(1)).map(lambda x: x + 1).fork(
        lambda r: r,
        lambda r: r
    )) == 2

    assert(Task(lambda reject, resolve: reject(1)).map(lambda x: x + 1).fork(
        lambda r: r,
        lambda r: r
    )) == 1

    assert(Task(lambda reject, resolve: reject(1)).bind(lambda x: Task.reject(x + 1)).fork(
        lambda r: r,
        lambda r: r
    )) == 2


# Generated at 2022-06-24 00:32:13.153601
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject(5)

    assert Task(fork).fork(lambda arg: arg, lambda arg: arg) == 5


# Generated at 2022-06-24 00:32:16.874306
# Unit test for constructor of class Task
def test_Task():
    # should call `fork` with `reject` and `resolve` argument
    def fork(reject, resolve):
        return resolve(1)

    # new Task with provided `fork`
    test_task = Task(fork)
    assert test_task.fork(lambda a: a, lambda a: a) == 1
    assert test_task.fork(lambda a: a, lambda a: "a") == "a"


# Generated at 2022-06-24 00:32:24.411042
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    """
    def sum(x, y):
        return x + y

    def sum_task(x):
        return Task.of(lambda y: sum(x, y))


# Generated at 2022-06-24 00:32:27.454979
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return 'OK'

    assert Task(fork).fork(lambda _: 'FAIL', lambda _: 'FAIL') == 'OK'


# Generated at 2022-06-24 00:32:37.630674
# Unit test for method bind of class Task
def test_Task_bind():
    def hug(user: str) -> Task[str]:
        return Task.of('{0}: *hug* {0}'.format(user))

    def greet(user: str) -> Task[str]:
        return Task.of('{0}: Hello {0}'.format(user))

    def separate() -> Task[str]:
        return Task.of('-------------')

    def long_greeting(user: str) -> Task[str]:
        return Task.of(user)\
            .bind(greet)\
            .bind(lambda _: separate())\
            .bind(lambda _: hug(user))

    def expected_result(user: str) -> Task[str]:
        return Task.of('{0}: Hello {0}\n-------------\n{0}:\n *hug* {0}'.format(user))


# Generated at 2022-06-24 00:32:44.377950
# Unit test for method bind of class Task
def test_Task_bind():
    resolve = lambda f: f(lambda: True)
    reject = lambda f: f(lambda: False)
    value = 3
    task_ = Task.of(value).bind(lambda arg: Task.of(2 * arg))
    assert task_.fork(reject, lambda arg: arg == value * 2)
    assert task_.fork(reject, resolve)
    task_ = Task.of(value).bind(lambda arg: Task.reject(2 * arg))
    assert not task_.fork(reject, resolve)
    assert task_.fork(lambda value: value == value * 2, lambda: False)

import json
from functools import wraps


# Generated at 2022-06-24 00:32:47.004858
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject(1)

    task = Task(fork)

    assert task is not None
    assert hasattr(task, 'fork')


# Generated at 2022-06-24 00:32:53.223023
# Unit test for method map of class Task
def test_Task_map():
    def test_of_method(value):
        task = Task.of(value)
        def test_map(fn):
            mapped_task = task.map(fn)
            assert mapped_task.fork(None, lambda x: x) == fn(value)
        return test_map

    test_of_method(None)(lambda x: x)
    test_of_method(5)(lambda x: x + 5)
    test_of_method('value')(lambda x: ''.join((x, ' with map')))



# Generated at 2022-06-24 00:32:54.916509
# Unit test for constructor of class Task
def test_Task():
    resolve = lambda a: None
    reject = lambda a: None
    fn = lambda reject, resolve: None

    assert Task(fn).fork(reject, resolve) is None


# Generated at 2022-06-24 00:33:03.415458
# Unit test for constructor of class Task
def test_Task():
    def check(a):
        return a + 10

    x = Task.of(10)
    assert x.fork(lambda _: None, lambda a: assertEqual(a, 10))

    x = x.map(check)
    assert x.fork(lambda _: None, lambda a: assertEqual(a, 20))

    x = x.bind(lambda a: Task.of(a + 10))
    assert x.fork(lambda _: None, lambda a: assertEqual(a, 30))


# Generated at 2022-06-24 00:33:05.755445
# Unit test for constructor of class Task
def test_Task():
    """
    >>> task = Task.of(10)
    >>> task.fork(lambda x: x, lambda x: x)
    10
    """
    pass


# Generated at 2022-06-24 00:33:11.435462
# Unit test for constructor of class Task
def test_Task():
    # Return resolved Task with stored value argument.
    assert(Task.of(1) == Task(lambda _, resolve: resolve(1)))
    # Return rejected Task with stored value argument.
    assert(Task.reject(1) == Task(lambda reject, _: reject(1)))


# Generated at 2022-06-24 00:33:16.283532
# Unit test for method bind of class Task
def test_Task_bind():
    def _mapper(value):
        return value ** 2

    def _reject(value):
        raise Exception(value)

    def _resolve(value):
        return value

    task = Task.of(2)
    assert task.map(_mapper).fork(_reject, _resolve) == 4

    def _mapper(value):
        return Task.of(value ** 2)

    assert task.bind(_mapper).fork(_reject, _resolve) == 4

# Generated at 2022-06-24 00:33:20.897857
# Unit test for method bind of class Task
def test_Task_bind():
    Task.reject(2).bind(lambda _: Task.of(3)).fork(lambda x: print(x))
    Task.of(1).bind(lambda _: Task.reject(2)).fork(lambda _: None, lambda x: print(x))
    Task.of(1).bind(lambda _: Task.of(3)).fork(lambda _: None, lambda x: print(x))


# Generated at 2022-06-24 00:33:24.891178
# Unit test for method map of class Task
def test_Task_map():
    def add_42(value):
        return value + 42

    def result_is_42(resolve, reject):
        resolve(42)

    assert Task(result_is_42).map(add_42).fork(lambda _: False, lambda arg: arg == 84)


# Generated at 2022-06-24 00:33:28.806161
# Unit test for method map of class Task
def test_Task_map():
    @task
    def source():
        return 'foo'

    @task
    def mapper(arg):
        return arg + arg

    res = source().map(mapper)

    assert res.fork(None, lambda arg: arg) == 'foofoo'


# Generated at 2022-06-24 00:33:33.785733
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(10)

    assert task.map(lambda value: value + 1).fork(
        lambda rejected: assert_rejected(rejected),
        lambda resolved: assert_resolved(resolved, 11)
    )
# Test for method map of class Task
test_Task_map()


# Generated at 2022-06-24 00:33:41.313204
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task bind method with simple example.
    """
    def fn(value):
        if value == 1:
            return Task.of('foo')
        if value == 2:
            return Task.of('bar')

    assert Task.of(1).bind(fn).fork(None, lambda value: value) == 'foo'
    assert Task.of(2).bind(fn).fork(None, lambda value: value) == 'bar'

    def fn_error(value):
        raise Exception('Error')

    try:
        Task.of(1).bind(fn_error).fork(None, lambda value: value)
    except Exception as e:
        assert str(e) == 'Error'



# Generated at 2022-06-24 00:33:47.136349
# Unit test for method bind of class Task
def test_Task_bind():
    """
    assert that map method return Task of function with stored argument value
    """
    assert Task.of(5).bind(lambda x: Task.of(x * 2)).fork(None, lambda x: x) == 10
    assert Task.of(5).bind(
        lambda x: Task.reject(x * 2)).fork(lambda x: x, None) == 10


# Generated at 2022-06-24 00:33:53.423517
# Unit test for method map of class Task
def test_Task_map():
    # Create fixture
    task = Task.of(4)
    # Case: map must return new Task
    assert not isinstance(task.map(lambda value: value * 2), tuple)
    # Case: Task must map properly
    assert task.map(lambda value: value * 2).fork(
        lambda _: None,
        lambda arg: arg == 8
    )


if __name__ == "__main__":
    test_Task_map()

# Generated at 2022-06-24 00:33:57.439249
# Unit test for method map of class Task
def test_Task_map():
    called = [False]


# Generated at 2022-06-24 00:34:04.365008
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task

    :returns: True
    :rtype: bool
    """

    # Test for Function
    assert callable(Task)

    # Test for of method
    assert callable(Task.of)
    assert isinstance(Task.of(1), Task)
    assert Task.of(2).fork(lambda x: None, lambda x: x) == 2

    # Test for reject method
    assert callable(Task.reject)
    assert isinstance(Task.reject(1), Task)
    assert Task.reject(2).fork(lambda x: x, lambda x: None) == 2



# Generated at 2022-06-24 00:34:08.489620
# Unit test for method bind of class Task
def test_Task_bind():
    def to_upper(arg):
        return Task.reject(arg.upper())

    def to_lower(arg):
        return Task.of(arg.lower())

    assert Task.of("HELLO").bind(to_upper).bind(to_lower).fork(
        lambda r: print(r),
        lambda r: print(r)
    ) == "hello"

    assert Task.of("world").bind(to_upper).bind(to_lower).fork(
        lambda r: print(r),
        lambda r: print(r)
    ) == "WORLD"



# Generated at 2022-06-24 00:34:19.423271
# Unit test for method map of class Task
def test_Task_map():
    asserter = Asserter()

    def slow_method(value):
        time.sleep(2.0)
        return value * 10

    task = Task.of(1)
    mapped_task = task.map(slow_method)

    # will prove that map run during forking
    def run():
        def action_when_resolved(value):
            asserter.is_equal(value, 10)

        def action_when_rejected(value):
            asserter.is_equal(value, 'resolved error')

        mapped_task.fork(
            action_when_rejected,
            action_when_resolved
        )

    # run method in different thread than current
    thread = threading.Thread(target=run)
    thread.start()
    thread.join(2.0)

    #

# Generated at 2022-06-24 00:34:25.464914
# Unit test for method bind of class Task
def test_Task_bind():
    """Test for Task bind method"""
    # t_a = Task.reject("reject")
    # binded = t_a.bind(lambda a: Task.of("b"))
    # assert binded.fork(
    #     lambda a: assert a == "reject",
    #     lambda a: assert False
    # )

    task = Task.of(100)
    binded = task.bind(lambda x: Task.of(x*2))

# Generated at 2022-06-24 00:34:32.804226
# Unit test for method map of class Task
def test_Task_map():
    """
    Map of Task must return new Task with transformed resolve attribute.
    """
    # Define test data
    payload = 'This is my payload'
    test_task = Task.of(payload)
    test_task_two = Task.reject(payload)

    # Create test function
    def uppercase(value): return value.upper()

    # Create test assertions
    def test_map(value, task):
        assert isinstance(task.map(uppercase), Task)
        assert task.fork(None, lambda arg: arg) == value

    # Run test assertions
    test_map(payload, test_task)
    test_map(payload.upper(), test_task.map(uppercase))
    test_map(payload, test_task_two)

# Generated at 2022-06-24 00:34:36.204262
# Unit test for method bind of class Task
def test_Task_bind():
    value = Task.of(None)
    answer = value.bind(lambda _: Task.reject(Exception("error")))

    assert answer.fork(lambda error: error, lambda _: None) == Exception("error")



# Generated at 2022-06-24 00:34:46.808557
# Unit test for method map of class Task
def test_Task_map():
    # Must return value that passed to resolve function.
    def test_value_passed_to_resolve(value, expected_value):
        assert Task.of(value).map(lambda x: x).fork(None, lambda arg: arg) == expected_value

    # Must return value from mapped function
    def test_return_value_from_mapper_function(mapper,
                                               value,
                                               expected_value):
        assert Task.of(value).map(mapper).fork(None, lambda arg: arg) == expected_value

    # -----------------------------------------
    # Check resolve value.
    # -----------------------------------------
    # Must return value that passed to resolve function.
    test_value_passed_to_resolve(None, None)
    test_value_passed_to_resolve(1, 1)
    test_

# Generated at 2022-06-24 00:34:49.027287
# Unit test for constructor of class Task
def test_Task():
    fork = lambda _, resolve: resolve('foo')
    task = Task(fork)

    assert task.fork is fork

# Generated at 2022-06-24 00:34:50.791798
# Unit test for constructor of class Task
def test_Task():
    def fork(_, resolve): resolve(5)
    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-24 00:34:53.895048
# Unit test for method bind of class Task
def test_Task_bind():
    def add(a):
        return Task(lambda reject, resolve: resolve(a + 1))

    Task.of(1).bind(add).fork(lambda x: None, lambda x: print(x))

# Generated at 2022-06-24 00:35:03.359403
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(5)) == Task(lambda _, resolve: resolve(5))
    assert Task(lambda _, resolve: resolve(5)) is not Task(lambda _, resolve: resolve(5))
    assert Task(lambda _, resolve: resolve(5)) == Task(lambda _, resolve: resolve(6))
    assert Task(lambda _, resolve: resolve(None)) == Task(lambda _, resolve: resolve(None))
    assert Task(lambda _, resolve: resolve(None)) is not Task(lambda _, resolve: resolve(None))

    assert Task(lambda _, resolve: resolve(5)).fork(print, print) == 5
    assert Task(lambda reject, _: reject(5)).fork(print, print) == 5

# Generated at 2022-06-24 00:35:09.943755
# Unit test for method bind of class Task
def test_Task_bind():
    @fixture(scope="module")
    def setup():
        def fn(n):
            return Task.of(n + 1)

        return fn

    def test_bind(setup):
        task = Task.of(1).bind(setup)
        assert task.fork(None, list) == [2]

    def test_reject(setup):
        task = Task.of(1).bind(setup)
        assert task.fork(list, None) == []

    test_bind(setup)
    test_reject(setup)


# Generated at 2022-06-24 00:35:14.480616
# Unit test for method map of class Task
def test_Task_map():
    def plus(x):
        return x + 1

    def minus(x):
        return x - 1

    def fork(reject, resolve):
        resolve(5)

    assert Task(fork).map(plus).map(plus).fork(None, lambda arg: arg) == 7
    assert Task(fork).map(minus).map(minus).fork(None, lambda arg: arg) == 3


# Generated at 2022-06-24 00:35:21.944245
# Unit test for method bind of class Task
def test_Task_bind():

    assert (
        Task(lambda _, resolve: resolve(1)).bind(
            lambda value: Task.of(value ** 2)
        )
        ==
        Task.of(1 ** 2)
    )
    assert (
        Task.reject(1).bind(
            lambda value: Task.of(value ** 2)
        )
        ==
        Task.reject(1)
    )
    assert (
        Task(lambda _, resolve: resolve(1)).bind(
            lambda value: Task.reject(value ** 2)
        )
        ==
        Task.reject(1 ** 2)
    )
    assert (
        Task.reject(1).bind(
            lambda value: Task.reject(value ** 2)
        )
        ==
        Task.reject(1)
    )

#

# Generated at 2022-06-24 00:35:27.894260
# Unit test for method map of class Task
def test_Task_map():
    def check(fn, expected_value):
        def fork(_, resolve):
            resolve(fn())

        actual_task = Task(fork).map(identity)
        if expected_value == actual_task.fork(identity, identity):
            print('Success')
        else:
            print('Expected: ' + str(expected_value))
            print('Actual: ' + str(actual_task))

    check(lambda: 1, 1)
    check(lambda: 'str', 'str')

if __name__ == '__main__':
    test_Task_map()


# Generated at 2022-06-24 00:35:34.391936
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """
    def positive(x):
        """
        Take value == x and return x.
        """
        return x

    def negative(x):
        """
        Take value == x and return -x.
        """
        return -x

    def undefined(x):
        """
        Take value == x and return 0.
        """
        return 0

    assert Task.of(5).map(positive) == Task.of(5)
    assert Task.of(5).map(negative) == Task.of(-5)
    assert Task.of(5).map(undefined) == Task.of(0)


# Generated at 2022-06-24 00:35:42.086294
# Unit test for constructor of class Task
def test_Task():
    """
    Check if Task.of and Task.reject return Task with store value in proper attribute
    """
    # Type check
    assert isinstance(Task.of(5), Task)
    assert isinstance(Task.reject(5), Task)

    assert Task.of(4).fork(lambda _: None, lambda value: value) == 4
    assert Task.reject(4).fork(lambda value: value, lambda _: None) == 4



# Generated at 2022-06-24 00:35:48.271014
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return 'new_value'

    task = Task.of(None).map(fn)

    called = 0

    def resolve(result):
        nonlocal called
        called += 1
        assert called > 0
        assert result == 'new_value'

    def reject(error):
        nonlocal called
        called += 1
        assert called > 0
        assert False

    task.fork(reject, resolve)

    assert called > 0


# Generated at 2022-06-24 00:35:50.656731
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task
    """
    assert type(Task(lambda _, __: None)) == Task



# Generated at 2022-06-24 00:35:53.062050
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of Task.
    """
    def fork(reject, resolve):
        return reject("some_error")

    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-24 00:36:00.388104
# Unit test for method bind of class Task
def test_Task_bind():
    import unittest
    class TestTaskBind(unittest.TestCase):
        def test_resolve_chain(self):
            fork = Task.of(3).bind(lambda _: Task.of(5)).bind(lambda _: Task.reject(5)).bind(lambda _: Task.of(5))
            fork(lambda value: self.assertEqual(value, 5), lambda value: self.assertFalse(True))

        def test_reject_chain(self):
            fork = Task.of(3).bind(lambda _: Task.of(5)).bind(lambda _: Task.reject(5)).bind(lambda _: Task.of(5))
            fork(lambda value: self.assertEqual(value, 5), lambda value: self.assertFalse(True))

    unittest.main()


# Generated at 2022-06-24 00:36:08.816059
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Return Task with bound values for test method bind of class Task.

    :returns: Task with bound values for test method bind of class Task.
    :rtype: Task[Function(resolve, reject -> A | B | C]
    """
    task_1 = Task.of('value')
    task_2 = task_1.bind(lambda arg: Task.of(arg + '_resolve'))
    task_3 = task_2.bind(lambda arg: Task.reject(arg + '_reject'))

    return task_3


# Generated at 2022-06-24 00:36:10.697857
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve('value')

    task = Task(fork)

    assert isinstance(task, Task)


# Generated at 2022-06-24 00:36:18.342270
# Unit test for method map of class Task
def test_Task_map():
    def assert_equal_Task(task, expected_value):
        def assert_value(reject, resolve):
            resolve(expected_value)

        task.fork(lambda reject: assert_true(False), lambda resolve: assert_value(reject, resolve))

    assert_equal_Task(Task.of(1).map(lambda x: x + 2), 3)
    assert_equal_Task(
        Task.of(1).map(lambda x: x + 2).map(lambda x: x * 2),
        6
    )
    assert_equal_Task(
        Task.of(1).map(lambda x: x + 2).bind(lambda x: Task.of(x * 2)),
        6
    )
    assert_equal_Task(
        Task.reject(0),
        0
    )


# Generated at 2022-06-24 00:36:23.586995
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor Task.

    :return: no return
    :rtype: None
    """
    def fork(reject, resolve):
        """
        Fork function for test.

        :param reject: reject callback
        :type reject: Function(value) -> None
        :param resolve: resolve callback
        :type resolve: Function(value) -> None
        :return: no return
        :rtype: None
        """
        reject('rejected')
        resolve('resolved')

    task = Task(fork)
    assert isinstance(task, Task), "task is not Task"
    assert isinstance(task.fork, FunctionType), "task.fork is not function"



# Generated at 2022-06-24 00:36:26.690839
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value * 2

    def fork(reject, resolve):
        resolve(3)

    assert Task(fork).map(mapper).fork(None, lambda result: result == 6)


# Generated at 2022-06-24 00:36:31.092756
# Unit test for method bind of class Task
def test_Task_bind():
    x = Task.of(1)
    y = x.bind(lambda x: Task.of(x + 10))
    z = y.bind(lambda x: Task.of(x + 100))
    t = z.fork(lambda _: None, lambda x: x)
    assert(111 == t)



# Generated at 2022-06-24 00:36:35.364247
# Unit test for method map of class Task
def test_Task_map():
    assert isinstance(
        Task.of(1).map(lambda v: v + 1),
        Task
    )

    assert_equal(
        Task.of(1).map(lambda v: v + 1).fork(None, None),
        None
    )



# Generated at 2022-06-24 00:36:40.189821
# Unit test for method map of class Task
def test_Task_map():
    """
    Check that Task.map(fn) apply result Task with value mapped by provided function to a previous Task resolve value.
    """
    def forked(_, resolve):
        resolve(12)

    def map_value(value):
        return value * 2

    task = Task(forked)
    assert task.map(map_value).fork(lambda _: _, lambda arg: arg) == 24


# Generated at 2022-06-24 00:36:42.844234
# Unit test for constructor of class Task
def test_Task():
    """
    Check if constructor of class Task create object with type Task
    """
    assert Task(lambda _, __: None) == Task(lambda _, __: None)


# Generated at 2022-06-24 00:36:45.393329
# Unit test for constructor of class Task
def test_Task():
    assert Task(None).fork is None

    val = Task.of(5).fork(lambda _: _, lambda _: _)
    assert val == 5


# Generated at 2022-06-24 00:36:52.913126
# Unit test for constructor of class Task
def test_Task():
    """Unit test for Task.

    Test:
       - constructor with one parameter.
    """

    # Test failed case
    assert False, """
        Task constructor may be hold only one parameter.
    """

    # Test simple case
    assert Task(lambda reject, resolve: resolve(1)) is not None, """
        Task constructor should return not `None`.
    """

    # Test simple case
    assert Task(lambda reject, resolve: resolve(1)) is not Task(lambda reject, resolve: resolve(1)), """
        Task constructor should return new object.
    """


# Generated at 2022-06-24 00:36:55.559148
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: resolve(1)).fork(None, lambda value: value) == 1
    assert Task(lambda reject, resolve: reject(1)).fork(lambda error: error, None) == 1

# Unit tests for static methods of class Task

# Generated at 2022-06-24 00:37:01.181994
# Unit test for method map of class Task
def test_Task_map():
    def resolve(arg):
        return arg

    task = Task(lambda _, resolve: resolve('value'))
    task = task.map(lambda value: value + 'mapped')

    assert task.fork(_, resolve) == 'valuemapped'


# Generated at 2022-06-24 00:37:07.753101
# Unit test for method bind of class Task
def test_Task_bind():
    # test Task.bind for Task.of(123)
    assert Task.of(123).bind(lambda arg: Task.reject(arg*2)).fork(lambda arg: arg, lambda _: None) == 246

    # test Task.bind for Task.reject(123)
    assert Task.reject(123).bind(lambda arg: Task.of(arg*2)).fork(lambda arg: arg, lambda _: None) == 123


# Generated at 2022-06-24 00:37:14.318634
# Unit test for method bind of class Task
def test_Task_bind():
    def add1(value):
        return Task.of(value + 1)

    def task_reject(value):
        return Task.reject(value)

    assert Task.of(0)\
        .bind(add1)\
        .fork(
            lambda arg: 1,
            lambda arg: arg
        ) == 1, 'Task.of(0).bind(add1).fork(lambda arg: 1, lambda arg: arg) != 1'

    assert Task.of(0)\
        .bind(add1)\
        .bind(lambda arg: add1(arg))\
        .fork(
            lambda arg: 2,
            lambda arg: arg
        ) == 2, 'Task.of(0).bind(add1).bind(lambda arg: add1(arg)).fork(lambda arg: 2, lambda arg: arg) != 2'



# Generated at 2022-06-24 00:37:20.827104
# Unit test for method map of class Task
def test_Task_map():
    def even(value):
        return value % 2 == 0

    def double(value):
        return value * 2

    task = Task.of(5).map(double).map(lambda x: x + 3)

    def assert_eq(reject, resolve):
        return resolve(assertEqual(task.fork(lambda _: None,
                                             lambda x: x), 13))

    assert_eq(lambda _: None, lambda _: None)


# Generated at 2022-06-24 00:37:24.964304
# Unit test for constructor of class Task
def test_Task():
    def fork(rejected, resolved):
        return resolved({})

    assert Task(fork=fork) == Task(fork=fork)


# Generated at 2022-06-24 00:37:27.983238
# Unit test for method bind of class Task
def test_Task_bind():
    t = Task.of(2)
    t2 = t.map(lambda x: x + 1)
    assert(t2.fork(lambda x: x, lambda x: x) == 3)


# Generated at 2022-06-24 00:37:32.829156
# Unit test for method bind of class Task
def test_Task_bind():
    def plus_2(value):
        return Task.of(value + 2)

    def plus_3(value):
        return Task.of(value + 3)

    def plus_2_and_3(value):
        return Task.of(value).bind(plus_2).bind(plus_3)

    assert plus_2_and_3.fork(print, print)(-1) == 4



# Generated at 2022-06-24 00:37:34.537498
# Unit test for constructor of class Task
def test_Task():
    assert Task.reject(None)
    assert Task.of(None)
    assert Task(lambda a, b: None)


# Generated at 2022-06-24 00:37:37.579927
# Unit test for method map of class Task
def test_Task_map():
    def add_one(arg):
        return arg + 1

    def mock_reject(arg):
        raise Exception("Should not be called reject function")

    def mock_resolve(arg):
        assert arg == 4
        return arg

    value = Task.of(3).map(add_one).fork(mock_reject, mock_resolve)



# Generated at 2022-06-24 00:37:48.347929
# Unit test for method map of class Task
def test_Task_map():
    def test_value_resolve():
        a = 2
        result = Task(lambda _, resolve: resolve(a)).map(lambda x: x + 1)
        check = Task.of(a + 1)
        assert result.fork == check.fork

    def test_value_reject():
        a = 2
        result = Task(lambda reject, _: reject(a)).map(lambda x: x + 1)
        check = Task.reject(a)
        assert result.fork == check.fork

    def test_function_reject():
        a = lambda x: 2 * x
        result = Task(lambda _, resolve: resolve(a)).map(lambda fn: fn(2))
        check = Task.of(2 * 2)
        assert result.fork == check.fork

    def test_function_resolve():
        a

# Generated at 2022-06-24 00:37:50.374264
# Unit test for method bind of class Task
def test_Task_bind():
    # given, when
    class TestException(Exception):
        pass

    result = Task.reject(TestException) \
        .bind(lambda _: Task.of(True))

    # then
    assert result.fork(isinstance, lambda _: False)



# Generated at 2022-06-24 00:37:53.366025
# Unit test for method map of class Task
def test_Task_map():
    def add_42(value):
        return value + 42

    def div_42(value):
        return int(value / 42)

    assert Task(lambda _, resolve: resolve(0)).map(add_42).map(div_42).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 0


# Generated at 2022-06-24 00:38:03.214389
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task map method with some function
    """
    from src.fantasy import compose

    identity = lambda arg: arg

    assert Task((lambda _, resolve: resolve(1))).map(identity).fork(None, identity) == 1
    assert Task((lambda _, resolve: resolve(2))).map(identity).fork(None, identity) == 2
    assert Task((lambda _, resolve: resolve('b'))).map(identity).fork(None, identity) == 'b'

    mapper = lambda arg: arg * 2
    assert Task((lambda _, resolve: resolve(1))).map(mapper).fork(None, identity) == 2
    assert Task((lambda _, resolve: resolve(2))).map(mapper).fork(None, identity) == 4

# Generated at 2022-06-24 00:38:12.744979
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    def _(resolve, reject):
        resolve('Successful result')

    def succeed_mapper(value):
        assert value == 'Successful result'
        return 'Mapped successful result'

    def failed_mapper(value):
        assert value == 'Failed result'
        return 'Mapped failed result'

    succeed_task = Task(_).map(succeed_mapper)
    assert succeed_task.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 'Mapped successful result'

    failed_task = Task(_).map(failed_mapper)
    assert failed_task.fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 'Mapped failed result'


# Generated at 2022-06-24 00:38:17.726674
# Unit test for constructor of class Task
def test_Task():
    @pytest.fixture
    def value():
        return int()

    @pytest.fixture
    def task():
        return Task(lambda _, __: value)

    @pytest.fixture
    def fork(value):
        return lambda reject, resolve: resolve(value)

    def test_Task_ctor(task, fork):
        assert task.fork == fork

# Generated at 2022-06-24 00:38:21.874204
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test that bind should call fork with resolve attribute of task which will be returned by
    bind mapper function.
    """
    fork_call_counter = 0

    def fork(reject, resolve):
        nonlocal fork_call_counter
        fork_call_counter += 1

        resolve(arg)

    arg = "test_value"
    task = Task(fork)
    new_task = task.bind(lambda arg: Task.of(arg))

    new_task.fork(
        lambda value: None,
        lambda value: None
    )

    assert fork_call_counter == 2, "Task should call two times fork method"



# Generated at 2022-06-24 00:38:24.912306
# Unit test for constructor of class Task
def test_Task():
    # Test for constructor
    def constructor(reject, resolve):
        return resolve(10)

    task_test = Task(constructor)
    assert callable(task_test.fork)


# Generated at 2022-06-24 00:38:29.953213
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        return resolve(1)

    def mapper(value):
        return Task.of(value + 1)

    task = Task(fork)

    assert task.bind(mapper) == Task(
        lambda reject, resolve: Task(
            lambda _, __: resolve(2)
        ).fork(reject, resolve)
    )


# Generated at 2022-06-24 00:38:32.909068
# Unit test for constructor of class Task
def test_Task():
    """Unit test for constructor of class Task."""
    def my_fork(reject, resolve):
        return resolve(1)

    task = Task(my_fork)
    assert task.fork == my_fork


# Generated at 2022-06-24 00:38:39.333512
# Unit test for method map of class Task
def test_Task_map():
    def set_value(value):
        def fn(_, resolve):
            resolve(value)
        return Task(fn)

    def get_value(value):
        def fn(reject, resolve):
            resolve(value)
        return Task(fn)

    def throw_error(value):
        def fn(reject, _):
            reject(value)
        return Task(fn)

    def square(value):
        return value ** 2

    def length(value):
        return len(value)

    task = Task.of(10)
    assert task.fork(lambda _: None, lambda x: x) == 10

    task = Task.reject("boom")
    assert task.fork(lambda x: x, lambda _: None) == "boom"

    task = Task.of(10).map(square)
   

# Generated at 2022-06-24 00:38:46.131117
# Unit test for method bind of class Task
def test_Task_bind():
    add_one = lambda arg: arg + 1

    assert Task.of(3).bind(Task.of).fork(
        lambda value: False,
        lambda value: value == 4
    )

    assert Task.of(3).bind(lambda arg: Task.reject(arg + 1)).fork(
        lambda value: value == 4,
        lambda value: False
    )

    assert Task.reject(3).bind(Task.of).fork(
        lambda value: value == 3,
        lambda value: False
    )

    assert Task.of(3).bind(lambda arg: Task.of((arg, arg))).fork(
        lambda value: False,
        lambda value: value == (3, 3)
    )


# Generated at 2022-06-24 00:38:50.327326
# Unit test for constructor of class Task
def test_Task():
    """
    >>> Task.of(1).fork(lambda a: a, lambda a: a)
    1
    >>> Task.reject(1).fork(lambda a: a, lambda a: a)
    1
    """


# Generated at 2022-06-24 00:38:57.393301
# Unit test for method bind of class Task
def test_Task_bind():
    def task_of(value):
        return Task.of(value)

    def resolve(value):
        return Task.reject(value)

    def reject(value):
        return Task.of(value)

    result = task_of(1).bind(resolve).bind(reject)
    assert result.fork(lambda arg: arg, lambda arg: arg) == 1

    result = task_of(1).bind(reject).bind(resolve)
    assert result.fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-24 00:39:07.926953
# Unit test for method bind of class Task
def test_Task_bind():
    counter = 0

    def task_of(value):
        return Task.of(value)

    def task_test_of(value):
        assert value == 1
        return Task.of(value + 1)

    def task_test_bind(value):
        nonlocal counter
        counter += 1

        def task_test_bind_of(value):
            assert value == 2
            return Task.of(value + 1)

        return task_test_bind_of(value)


# Generated at 2022-06-24 00:39:13.479434
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        assert value == 1

    def reject(value):
        assert False

    Task.of(1)\
        .map(lambda arg: arg + 1)\
        .fork(reject, resolve)

test_Task_map()


# Generated at 2022-06-24 00:39:22.515569
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Testing for method bind of class Task
    """
    def check_bind(task, value, expected_result):
        """
        Check bind function of class Task

        :param task: task to check (Task)
        :type task: Task
        :param value: value to set in task
        :type value: Any
        :param expected_result: expected result when task fork called
        :type expected_result: Any
        """
        resolve_called = False
        reject_called = False

        def resolve(arg):
            """
            Fake resolve function

            :param arg: argument
            :type arg: Any
            """
            assert arg == expected_result
            resolve_called = True

        def reject(arg):
            """
            Fake reject function

            :param arg: argument
            :type arg: Any
            """

# Generated at 2022-06-24 00:39:27.284446
# Unit test for constructor of class Task
def test_Task():
    def fn(_, resolve):
        resolve('tutu')

    task = Task(fn)
    assert task.fork == fn


# Generated at 2022-06-24 00:39:28.598175
# Unit test for constructor of class Task
def test_Task():
    def func(_):
        assert False

    task = Task(func)

    assert callable(task.fork)


# Generated at 2022-06-24 00:39:33.708017
# Unit test for constructor of class Task
def test_Task():
    """
    Test cases for Task constructor.
    """

    def task(reject, resolve):
        resolve(1)

    assert Task(task).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1

    assert Task(task).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 1


# Generated at 2022-06-24 00:39:42.659990
# Unit test for method map of class Task
def test_Task_map():
    test_data = [
        {
            'value': 2,
            'fn': lambda value: value * 2,
            'expected': 4,
            'method': 'test_Task_map'
        },
        {
            'value': 2,
            'fn': lambda value: value * 2,
            'expected': 8,
            'method': 'test_Task_map'
        }
    ]

    def _test(element):
        logger.debug(element)
        task = Task.of(element['value'])
        mapped = task.map(element['fn'])
        result = mapped.fork(lambda _: 'reject', lambda value: value)
        assert result == element['expected']

    for element in test_data:
        _test(element)


# Generated at 2022-06-24 00:39:45.938234
# Unit test for constructor of class Task
def test_Task():
    """
    Run tests on class Task
    """
    def test(reject, resolve):
        resolve('value')

    task = Task(test)
    assert_equals(task.fork, test)


# Generated at 2022-06-24 00:39:51.254759
# Unit test for method bind of class Task
def test_Task_bind():
    resolve = lambda x: x
    reject = lambda x: x
    forty_two = Task(lambda reject, resolve: resolve(42)).bind(lambda x: Task.of(x + 2))
    assert forty_two.fork(reject, resolve) == 44



# Generated at 2022-06-24 00:39:59.819213
# Unit test for constructor of class Task
def test_Task():
    def func_reject(reject):
        return reject(4)
    assert Task(func_reject)
    assert Task(func_reject).fork(lambda arg: arg, lambda arg: arg) == 4
    assert Task(func_reject).map(lambda arg: arg * 2).fork(lambda arg: arg, lambda arg: arg) == 8
    assert Task(func_reject).bind(lambda arg: Task.reject(arg * 2)).fork(lambda arg: arg, lambda arg: arg) == 8
    assert Task(func_reject).bind(lambda arg: Task.reject(arg)).fork(lambda arg: arg, lambda arg: arg) == 4
    assert Task(func_reject).bind(lambda arg: Task.of(arg)).fork(lambda arg: arg, lambda arg: arg) == 4


# Generated at 2022-06-24 00:40:01.105359
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda _: 0, lambda arg: arg) == 1
    assert Task.reject(1).fork(lambda arg: arg, lambda _: 0) == 1


# Generated at 2022-06-24 00:40:06.833331
# Unit test for method map of class Task
def test_Task_map():
    def reject(*_):
        raise Exception('Should not happen')

    def resolve(value):
        assert value == 6
        return value

    def fn(a):
        return a * 2

    Task.of(3).map(fn).fork(reject, resolve)



# Generated at 2022-06-24 00:40:08.533679
# Unit test for constructor of class Task
def test_Task():
    value = 10
    task = Task.of(value)
    assert task.fork(None, lambda arg: arg) == value


# Generated at 2022-06-24 00:40:13.582345
# Unit test for method map of class Task
def test_Task_map():
    def test_map_with_reject():
        def result(reject, resolve):
            return reject("error")

        def mapper(arg):
            return arg + 1

        task = Task(result)

        assert task.map(mapper) == task

    def test_map_with_resolve():
        def result(reject, resolve):
            return resolve(123)

        def mapper(arg):
            return arg + 1

        task = Task(result)

        assert task.map(mapper) == Task.of(124)

    test_map_with_reject()
    test_map_with_resolve()



# Generated at 2022-06-24 00:40:22.918104
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda r, f: f(1)).map(lambda x: x + 1).fork(error, value) == 2
    assert Task(lambda r, f: r(1)).map(lambda x: x + 1).fork(error, value) == 1
    assert Task(lambda r, f: f(1)).bind(lambda x: Task.of(x + 1)).fork(error, value) == 2
    assert Task(lambda r, f: r(1)).bind(lambda x: Task.of(x + 1)).fork(error, value) == 1

# Unit tests for constructor of class Task of

# Generated at 2022-06-24 00:40:30.486897
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of Task class.
    """
    def mapper(value):
        """
        Incrase value on 1.

        :param value: value to increase
        :type value: Integer
        """
        return value + 1

    assert Task.of(1).map(mapper).fork(
        lambda _: False,
        lambda arg: arg == 2
    )


# Generated at 2022-06-24 00:40:38.034810
# Unit test for method bind of class Task
def test_Task_bind():
    def task_of_5(resolve):
        return resolve(5)

    def task_of_10(resolve):
        return resolve(10)

    def double(number):
        return Task.of(number * 2)

    def tripple(number):
        return Task.of(number * 3)

    def quadruple(number):
        return Task.of(number * 4)

    task_10 = Task.of(10)
    task_15 = task_10.bind(double).bind(tripple).bind(quadruple)
    assert task_15.fork(None, task_of_5) == 20

# Generated at 2022-06-24 00:40:42.197238
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(3).bind(
        lambda x: Task.of(x+1).bind(
            lambda x: Task.of(x+1)
        )
    )

    assert task.fork(lambda x: x, lambda x: x) == 5

# Generated at 2022-06-24 00:40:46.520681
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    task_result = task.map(lambda arg: arg * 2)
    assert task_result.fork(
            lambda _: False,
            lambda arg: arg == 4
        )


# Generated at 2022-06-24 00:40:55.326836
# Unit test for method bind of class Task
def test_Task_bind():
    def to_promise_mapper(value):
        def resolve(arg):
            return arg + str(value)

        def reject(arg):
            raise arg

        return Task(lambda error, ok: ok(value))

    task = Task.of(1)
    task2 = task.bind(to_promise_mapper)
    assert task2.fork(lambda error: True, lambda arg: arg == 1) == True
    assert task2.fork(lambda error: False, lambda arg: arg == 2) == True

    task = Task.reject(True)
    task2 = task.bind(to_promise_mapper)
    assert task2.fork(lambda error: True, lambda arg: False) == True
    assert task2.fork(lambda error: True, lambda arg: False) == True




# Generated at 2022-06-24 00:40:58.953959
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(10)).fork(lambda _: None, lambda a: a) == 10



# Generated at 2022-06-24 00:41:04.337136
# Unit test for method bind of class Task
def test_Task_bind():
    def test(a, b):
        return Task.of(a + b)
    assert Task.of(1).bind(lambda a: Task.of(2).bind(lambda b: Task.of(a + b))).fork(None, lambda x: x) == 3
    assert Task.of(1).bind(lambda a: Task.of(2).bind(test)).fork(None, lambda x: x) == 3


# Generated at 2022-06-24 00:41:08.052259
# Unit test for method map of class Task
def test_Task_map():
    """
    Correct map function of Task should return resolved Task with modified value.
    """
    def mapper(value):
        return value * 2

    assert Task.of(2).map(mapper).fork(
        None,
        lambda x: x == 4
    )


# Generated at 2022-06-24 00:41:10.113652
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(2).fork(None, None) == 2
    assert Task.reject(3).fork(None, None) == 3


# Generated at 2022-06-24 00:41:20.648039
# Unit test for method bind of class Task
def test_Task_bind():
    add_two = lambda x: Task.of(x + 2)
    times = lambda x: Task.of(x*2)
    error_add = lambda x: Task.reject(x + 2)
    error_times = lambda x: Task.reject(x*2)

    assert Task(lambda r, _: 1).bind(add_two).fork(lambda a: a, lambda b: b) == 3
    assert Task(lambda r, _: 2).bind(error_add).fork(lambda a: a, lambda b: b) == 4
    assert Task(lambda r, _: 2).bind(times).bind(add_two).fork(lambda a: a, lambda b: b) == 6

# Generated at 2022-06-24 00:41:25.763198
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(5).map(lambda x: x + 1).bind(lambda x: Task.of(x)).fork(
        lambda err: 'error',
        lambda res: res
    )

    assert result == 6, "Error"

# Generated at 2022-06-24 00:41:28.172084
# Unit test for constructor of class Task
def test_Task():
    """
    Checks class Task constructor.
    """
    assert Task.of(True)(lambda _, resolve: resolve(False))
    assert Task.reject(True)(lambda reject, _: reject(False))


# Generated at 2022-06-24 00:41:29.840331
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve(5)
    task = Task(fork)

    assert task.fork(lambda _: None, lambda value: value) == 5


# Generated at 2022-06-24 00:41:36.142877
# Unit test for method bind of class Task
def test_Task_bind():
    # resolve with 1
    f1 = Task.of(1)
    # resolve with 2
    f2 = Task.of(2)

    def add(arg1):
        # return resolve Task with 2
        return f2.map(lambda arg2: arg1 + arg2)

    # return resolve Task with 3
    result = f1.bind(add)

# Generated at 2022-06-24 00:41:46.802719
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method Task.map and Task.of.

    Test cases:
    1. Positive test case with resolved Task.
    2. Positive test case with rejected Task.
    3. Positive test case with mapped Task stream, when all tasks are resolved.
    4. Positive test case with mapped Task stream, when one of tasks is rejected.
    """

    # Positive test case with resolved Task
    def positive_case_1(T):
        def done(value):
            assert value == 2

        T.of(1).map(lambda x: x + 1).fork(
            lambda value: print(value),
            done
        )

    # Positive test case with rejected Task
    def positive_case_2(T):
        def done(value):
            assert value == 2
