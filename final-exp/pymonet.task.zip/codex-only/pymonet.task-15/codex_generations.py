

# Generated at 2022-06-24 00:31:38.634151
# Unit test for constructor of class Task
def test_Task():
    """
    Test if class Task has constructor with one argument.
    """
    result = Task(lambda reject, resolve: resolve(None))

    assert result is not None


# Generated at 2022-06-24 00:31:44.800931
# Unit test for method map of class Task
def test_Task_map():
    def addOne(arg):
        return arg + 1

    addResult = Task.of(1).map(addOne)


# Generated at 2022-06-24 00:31:46.190859
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return 'Hi'

    task = Task(fork)

    assert task.fork('', '') == 'Hi'



# Generated at 2022-06-24 00:31:50.414749
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(42).fork(None, assert_equal)(42)
    assert Task.reject(42).fork(assert_equal, None)(42)

### Utils

# Generated at 2022-06-24 00:31:57.029669
# Unit test for method map of class Task
def test_Task_map():
    # mapper function
    def f(arg):
        return arg

    # handle resolve
    def resolve(value):
        assert value == 1, 'Task map not works'
        print('All tests passed')

    # task with resolve stored value 1
    t = Task.of(1)

    # call fork with resolve function
    t.fork(None, resolve)

    # map task with mapper function
    t.map(f).fork(None, resolve)


# Generated at 2022-06-24 00:31:58.155513
# Unit test for constructor of class Task
def test_Task():
    Task.of(1)



# Generated at 2022-06-24 00:32:00.213811
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda a: a + 1).fork(None, lambda a: a) == 2


# Generated at 2022-06-24 00:32:03.004846
# Unit test for constructor of class Task
def test_Task():
    # Test if Task object is instance of object
    assert isinstance(Task(lambda _, __: None), object)
    # Test if Task object is instance of Task
    assert isinstance(Task(lambda _, __: None), Task)



# Generated at 2022-06-24 00:32:05.846669
# Unit test for constructor of class Task
def test_Task():
    fork = lambda reject, resolve: resolve(2)
    assert Task(fork).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-24 00:32:08.996247
# Unit test for constructor of class Task
def test_Task():
    def fn():
        return Task.reject('expected value if return rejected Task')

    def expected_output(resolve, reject):
        reject('expected value if return rejected Task')

    assert fn().fork == expected_output



# Generated at 2022-06-24 00:32:16.078749
# Unit test for constructor of class Task
def test_Task():
    # Test default constructor
    assert Task.__init__.__code__.co_argcount == 2
    # Test arguments of constructor
    assert Task.__init__.__code__.co_varnames == ("self", "fork")

    # Test correct call constructor
    def fork(_, resolve=lambda arg: arg):
        return resolve("foo")

    task = Task(fork)
    assert task.fork(lambda error: error, lambda value: value) == "foo"


# Generated at 2022-06-24 00:32:20.908784
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    fake_fun = Task(lambda reject, resolve: resolve(10))
    assert_equals(fake_fun.bind(lambda x: Task.of(x + 10)).fork(
        lambda err: err,
        lambda val: val
    ), 20)


# Generated at 2022-06-24 00:32:27.704852
# Unit test for method bind of class Task
def test_Task_bind():
    # Task with resolve result
    resolved_task = Task.of(5)

    # Task with reject result
    rejected_task = Task.reject(5)

    def plus_five(x):
        return Task.of(x + 5)

    # Calling method bind with result Task
    assert resolved_task.bind(plus_five).fork(lambda r: 5, lambda r: r) == 10
    assert rejected_task.bind(plus_five).fork(lambda r: r, lambda r: 5) == 5



# Generated at 2022-06-24 00:32:36.795044
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(10)
    inc = lambda a: Task.of(a + 1)
    mul = lambda a: Task.of(a * 2)
    neg = lambda a: Task.reject(-a)

    assert task.bind(inc).fork(lambda a: a, lambda a: a) == 11
    assert task.bind(mul).fork(lambda a: a, lambda a: a) == 20
    assert task.bind(neg).fork(lambda a: a, lambda a: a) == -10

    task = Task.of(10)
    add_inc = lambda a: inc(a + 1)

    assert task.bind(add_inc).fork(lambda a: a, lambda a: a) == 12


# Generated at 2022-06-24 00:32:44.310284
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    def mock_fn(arg):
        return Task.of(arg * 2)

    def mock_reject(arg):
        return arg

    def mock_resolve(arg):
        return arg

    task = Task.of(1)
    task.fork(
        mock_reject,
        mock_resolve,
    ) == 1

    task = task.bind(mock_fn)
    task.fork(
        mock_reject,
        mock_resolve,
    ) == 2

# Generated at 2022-06-24 00:32:52.840369
# Unit test for method map of class Task
def test_Task_map():
    def mapping(x):
        return x + 1

    def fork(reject, resolve):
        resolve(3)

    def fork2(reject, resolve):
        reject(3)

    assert Task(fork).map(mapping).fork(lambda x: str(x), lambda y: y) == 4
    assert Task(fork2).map(mapping).fork(lambda x: str(x), lambda y: y) == '3'

if __name__ == "__main__":
    test_Task_map()

# Generated at 2022-06-24 00:32:55.059109
# Unit test for constructor of class Task
def test_Task():
    """Test Task constructor"""
    def run_fork(reject, resolve):
        resolve(42)
    task = Task(run_fork)

    assert 42 == task.fork(lambda arg: arg, lambda arg: arg)


# Generated at 2022-06-24 00:32:59.160856
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(1).map(lambda value: value + 1)
    assert result.fork(None, lambda value: value) == 2


# Generated at 2022-06-24 00:33:02.533456
# Unit test for constructor of class Task
def test_Task():
    fork = lambda reject, resolve: resolve(20)
    task = Task(fork)

    assert task.fork(lambda value: 'Error', lambda value: value * 3) == 60


# Generated at 2022-06-24 00:33:09.098755
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        if value + 1:
            return Task.of(value + 1)
        else:
            return Task.reject(value)

    assert Task(lambda _, resolve: resolve(0)).bind(fn).fork(
        lambda value: "reject: {}".format(value),
        lambda value: "resolve: {}".format(value)
    ) == "reject: 0"

    assert Task(lambda _, resolve: resolve(1)).bind(fn).fork(
        lambda value: "reject: {}".format(value),
        lambda value: "resolve: {}".format(value)
    ) == "resolve: 2"


# Generated at 2022-06-24 00:33:13.261497
# Unit test for method map of class Task
def test_Task_map():
    """
    >>> Task.of(1).map(lambda a: a + 1).fork(lambda e: print("reject:", e), lambda a: print("resolve:", a))
    resolve: 2
    """
    pass



# Generated at 2022-06-24 00:33:20.231738
# Unit test for method bind of class Task
def test_Task_bind():
    """
    When fork is called
    Then return result of calling bind function
    """
    def fork(reject, resolve):
        reject('error')

    def assert_reject(error):
        assert error is 'error'

    task = Task(fork)
    task.bind(assert_reject)

# Generated at 2022-06-24 00:33:26.549920
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(value):
        return Task.of(value + 1)

    def reject(value):
        return Task.reject(value + 1)

    assert Task.of(2).bind(resolve).fork(reject, resolve).fork(reject, resolve).fork(reject, resolve).fork(reject, resolve).fork(lambda e: e, lambda s: s) == 6


# Generated at 2022-06-24 00:33:31.746953
# Unit test for constructor of class Task
def test_Task():
    rejected_task = Task.reject(10)
    resolved_task = Task.of(10)

    assert rejected_task.fork(lambda x: x, lambda _: _) == 10
    assert resolved_task.fork(lambda _: _, lambda x: x) == 10

# Generated at 2022-06-24 00:33:34.306511
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)

    assert isinstance(task, Task)
    assert task.fork is fork


# Generated at 2022-06-24 00:33:38.618625
# Unit test for method bind of class Task
def test_Task_bind():
    # Given
    def return_resolved_task():
        return Task.of(12)

    def return_rejected_task():
        return Task.reject('rejected_task')

    # When
    resolve_result = Task.of(1).bind(lambda x: Task.of(x + 11)).fork(lambda err: err, lambda result: result)
    rejected_result = Task.of(1).bind(lambda x: Task.of(x + 11)).fork(lambda err: err, lambda result: result)
    resolve_1 = Task.of(1).bind(return_resolved_task).fork(lambda err: err, lambda result: result)
    reject_1 = Task.of(1).bind(return_rejected_task).fork(lambda err: err, lambda result: result)

    # Then
    # Check calling of

# Generated at 2022-06-24 00:33:41.996597
# Unit test for method bind of class Task
def test_Task_bind():
    """Unit test for method bind of class Task"""

    # Given
    add2 = lambda value: Task.of(value + 2)
    subtract2 = lambda value: Task.reject(value - 2)
    case_1 = Task.of(3)
    case_2 = Task.of(4).map(add2).bind(subtract2)
    case_3 = Task.of(5).map(add2).map(add2).bind(subtract2)

    # When
    result_1 = case_1.bind(add2)
    result_2 = case_2.bind(add2)
    result_3 = case_3.bind(add2)

    # Then
    assert result_1.fork(lambda reject, resolve: resolve(reject)) == 3

# Generated at 2022-06-24 00:33:51.319589
# Unit test for constructor of class Task
def test_Task():
    assert Task
    assert Task(lambda _, resolve: resolve(True))

# Generated at 2022-06-24 00:33:55.520776
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve('test')
        return 'test value'

    # Constructor of Task
    task = Task(fork)

    # Value of fork
    assert task.fork(lambda _: 'reject', lambda _: 'resolve') == 'test value'


# Generated at 2022-06-24 00:34:01.039419
# Unit test for method bind of class Task
def test_Task_bind():
    def foo(value):
        def resolve(data):
            pass

        def reject(data):
            pass

        return Task(lambda reject, resolve: resolve(value))

    assert Task.of(100).bind(foo).fork(lambda x: x, lambda x: x) == 100

# Generated at 2022-06-24 00:34:06.616880
# Unit test for constructor of class Task
def test_Task():
    assert Task.of('test').fork(lambda _: None, lambda x: x) == 'test'
    assert Task.reject('test').fork(lambda x: x, lambda _: None) == 'test'


# Generated at 2022-06-24 00:34:16.356013
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def test_function(value):
        """
        Return Task with resolved value + 1 and rejected value + 2.
        """
        return Task.of(value).map(add_one).bind(lambda arg: Task.reject(arg + 2))


# Generated at 2022-06-24 00:34:18.269875
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(3).map(lambda x: x*2).fork(None, lambda value: value) == 6


# Generated at 2022-06-24 00:34:20.780993
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda val: False, lambda val: val) == 1
    assert Task.reject(1).fork(lambda val: val, lambda val: False) == 1



# Generated at 2022-06-24 00:34:29.821646
# Unit test for method map of class Task
def test_Task_map():
    def test1(reject, resolve):
        reject('reject value')

    def mapper(value):
        return 'mapped resolve value'

    task = Task(test1)
    result = task.map(mapper)

# Generated at 2022-06-24 00:34:34.881419
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task

    Function to test are:
      - def map(self, fn):
          Take function, store it and call with Task value during calling fork function.
          Return new Task with result of called.
    """
    def add3_to_value(value):
        return value + 3

    def reject_operation(arg):
        return Task.reject(arg)

    # Check if map work for resolved Task
    # =============================
    # If Task is resolved
    # Return new Task with mapped value
    map_task = Task.of(1).map(add3_to_value)

    def reject_mapper(reject, resolve):
        resolve(reject("test"))

    def resolve_mapper(reject, resolve):
        resolve(resolve(4))


# Generated at 2022-06-24 00:34:37.495509
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('test')

    task = Task(fork)

    assert task.fork(lambda arg: arg, lambda arg: arg) == 'test'


# Generated at 2022-06-24 00:34:47.972707
# Unit test for constructor of class Task
def test_Task():
    @Task.of.register(Task)
    def _Task(value):
        return Task(lambda _, resolve: resolve(value))

    @Task.reject.register(Task)
    def _Task(value):
        return Task(lambda reject, _: reject(value))

    fork = lambda reject, resolve: resolve(5)
    task = Task(fork)
    assert task.fork(lambda reject: None, lambda resolve: resolve) == 5
    assert task.bind(Task.of).fork(lambda reject: None, lambda resolve: resolve) == 5
    assert task.map(lambda value: value + 1).fork(
        lambda reject: None,
        lambda resolve: resolve
    ) == 6
    assert Task.of(3).fork(
        lambda reject: None,
        lambda resolve: resolve
    ) == 3
    assert not Task

# Generated at 2022-06-24 00:34:52.822648
# Unit test for method map of class Task
def test_Task_map():
    @Task
    def add(reject, resolve):
        return resolve(1 + 2)

    assert add.map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 4

    @Task
    def add_to_reject(reject, resolve):
        return reject(1)

    assert add_to_reject.map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-24 00:34:57.418641
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value

    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    task2 = task.map(fn)

# Generated at 2022-06-24 00:35:06.150548
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Return None.

    This function not return any value.
    This function make process of define task and bind with them functions.
    Just make some test for methods of class Task.
    """
    resolve_value = 'hello'
    reject_value = 'world'
    def reject(_, resolve):
        return resolve(resolve_value)

    def resolve(reject, _):
        return reject(reject_value)

    def mapper_resolve(value):
        return '%s_%s' % (value, resolve_value)

    def mapper_reject(value):
        return '%s_%s' % (value, reject_value)

    def test_success():
        task = Task(reject)

# Generated at 2022-06-24 00:35:08.394681
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(2 + 2))

    assert isinstance(task, Task)


# Generated at 2022-06-24 00:35:15.011502
# Unit test for constructor of class Task
def test_Task():
    """
    Testing constructor of class Task:
    Task(fork)
    """
    task = Task(lambda resolve, reject: resolve('Task'))

    assert task.fork(lambda x: x, lambda x: x) == 'Task'
    assert task.fork(lambda x: 'reject', lambda x: x) == 'Task'

    task = Task(lambda resolve, reject: reject('Task'))

    assert task.fork(lambda x: x, lambda x: 'resolve') == 'Task'
    assert task.fork(lambda x: x, lambda x: 'resolve') == 'Task'


# Generated at 2022-06-24 00:35:16.601270
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(1))
    assert task.fork == Task(lambda _, resolve: resolve(1)).fork


# Generated at 2022-06-24 00:35:21.116673
# Unit test for constructor of class Task
def test_Task():
    """
    >>> task = Task(lambda _, resolve: resolve('42'))
    >>> task.fork(lambda reject: reject('rejected'), lambda result: result)
    '42'
    """


# Generated at 2022-06-24 00:35:22.700778
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda a: 'rejected', lambda a: a) == 1
    assert Task.reject(1).fork(lambda a: a, lambda a: 'resolved') == 1


# Generated at 2022-06-24 00:35:24.542373
# Unit test for constructor of class Task
def test_Task():
    fork = lambda reject, resolve: None
    assert Task(fork).fork == fork



# Generated at 2022-06-24 00:35:27.427082
# Unit test for method map of class Task
def test_Task_map():
    pass


# Generated at 2022-06-24 00:35:28.849705
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for constructor of class Task
    """
    pass


# Generated at 2022-06-24 00:35:34.060867
# Unit test for method map of class Task
def test_Task_map():
    invoked = 0

    def fn(_):
        return _ + 2

    def arg(_, __):
        nonlocal invoked
        invoked = invoked + 1
        return 2

    task = Task(arg)
    task_result = task.map(fn)

    task_result.fork(
        lambda arg: print('rejected:', arg),
        lambda arg: print('resolved:', arg)
    )

    assert 1 == invoked, 'invoked'
    assert 4 == arg(None, None), 'arg'



# Generated at 2022-06-24 00:35:36.439042
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject('rejected')

    task = Task(fork)

    assert task.fork(
        lambda arg: arg == 'rejected' and 'rejectedTask',
        lambda arg: 'resolvedTask'
    ) == 'rejectedTask'


# Generated at 2022-06-24 00:35:40.662900
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve(1)

    fork = Task(fork)


# Generated at 2022-06-24 00:35:51.241243
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for ensure that method bind
    execute function binded from result of function from class Task
    """
    def double(value):
        """
        Double value of argument

        :param value: value to double
        :type value: Number
        :returns: doubled value
        :rtype: Number
        """
        return value * 2

    def add_two(value):
        """
        Add two to value

        :param value: value to add two
        :type value: Number
        :returns: value + 2
        :rtype: Number
        """
        return value + 2


# Generated at 2022-06-24 00:35:59.434911
# Unit test for constructor of class Task
def test_Task():
    """
    Test of:
        - constructor of class Task
        - class method Task.of
        - class method Task.reject

    :return: True if all tests passed
    :rtype: bool
    """
    def success(value):
        return value

    def failed(value):
        raise value

    # Create lazy Task with stored a function
    task = Task(lambda r, s: s(success))
    # Will create error if task.fork is not lazy
    assert task.fork(failed, failed) == success
    # result of calling resolve function
    assert Task.of(success).fork(failed, failed) == success
    # result of calling reject function
    assert Task.reject(success).fork(failed, failed) == success

    return True


# Generated at 2022-06-24 00:36:01.902131
# Unit test for method map of class Task
def test_Task_map():
    def add(a):
        return a + 1

    result = Task.of(1).map(add)

    assert result.fork(None, lambda v: v) == 2


# Generated at 2022-06-24 00:36:06.483785
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x

    def fork(reject, resolve):
        return resolve(1)

    result = Task(fork).map(fn)

    assert result.fork(fn, fn) == 1


# Generated at 2022-06-24 00:36:15.126170
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    task_A = Task.of('A')
    task_B = Task.of('B')
    task_AB = Task.of('AB')

    def get_task_from_A(arg):
        """
        Get Task from arg
        """
        if arg == 'A':
            return task_AB
        return task_B

    decorated_fn = task_A.bind(get_task_from_A)

    assert decorated_fn.fork(lambda _: False, lambda arg: arg == 'AB')



# Generated at 2022-06-24 00:36:19.989538
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task
    """
    # Init and check Fork function
    fork = lambda _, resolve: resolve(1)
    task = Task(fork)
    assert task.fork is fork

    # Create Task and check result
    fork = lambda _, resolve: resolve(2)
    task = Task.of(2)
    assert task.fork is fork

    # Create and check rejected Task
    fork = lambda reject, _: reject(3)
    task = Task.reject(3)
    assert task.fork is fork


# Generated at 2022-06-24 00:36:22.482571
# Unit test for constructor of class Task
def test_Task():
    assert str(Task(lambda _, __: None)) == '<Task: object at 0x{:x}>'.format(id(Task(lambda _, __: None)))


# Generated at 2022-06-24 00:36:24.228859
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(1))
    assert task.fork(lambda _: None, lambda arg: 1) == 1


# Generated at 2022-06-24 00:36:32.410514
# Unit test for method bind of class Task
def test_Task_bind():
    def call_with_first_arg(fn, arg):
        return fn(arg)

    def fork(reject, resolve):
        return call_with_first_arg(resolve, arg)

    arg = 2

    task = Task(fork)
    result = task.bind(lambda arg: Task.of(arg + 1))
    assert result.fork(lambda _: None, lambda arg: arg) == arg + 1

    reject_mapper = lambda _: Task.reject(True)
    result = task.bind(reject_mapper)
    assert result.fork(lambda _: None, lambda _: None)



# Generated at 2022-06-24 00:36:37.083188
# Unit test for method map of class Task
def test_Task_map():
    def test(assert_):
        def test_summ(reject, resolve):
            resolve(1 + 2)

        assert_(Task(test_summ).map(lambda arg: arg + 2).fork(None, lambda arg: assert_(arg == 5)))

    run_test(test)


# Generated at 2022-06-24 00:36:41.733094
# Unit test for constructor of class Task
def test_Task():
    value = 1

    # create Task with `of` method
    task = Task.of(value)

    # test resolved value with fork method
    assert task.fork(lambda value: False, lambda value: value == 1)

    # create Task with `reject` method
    task = Task.reject(value)

    # test rejected value with fork method
    assert task.fork(lambda value: value == 1, lambda value: not value)


# Generated at 2022-06-24 00:36:45.344711
# Unit test for constructor of class Task
def test_Task():
    def runner():
        def fork(reject, resolve):
            reject(1)
            resolve(2)
            return 0

        task = Task(fork)
        assert task.fork(lambda reject: reject, lambda resolve: resolve) == 0

test_Task()


# Generated at 2022-06-24 00:36:49.264735
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.reject(1)
    result = task.bind(lambda arg: Task.reject(arg * 2))
    result.fork(
        lambda arg: print(arg),
        lambda arg: print(arg)
    )


# Generated at 2022-06-24 00:36:50.615678
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task(lambda reject, resolve: None), Task)


# Generated at 2022-06-24 00:36:55.150396
# Unit test for method bind of class Task
def test_Task_bind():
    # fn is function that return new task
    def fn(value):
        return Task.of(value + 2)

    # task is new task with resolve value 4
    task = Task.of(2)
    task = task.bind(fn)

    def fork(reject, resolve):
        return task.fork(reject, resolve)

    assert fork(dump, dump) == 4


# Generated at 2022-06-24 00:36:59.694893
# Unit test for method map of class Task
def test_Task_map():
    def fn(a):
        return a + 1


# Generated at 2022-06-24 00:37:02.677903
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(10).fork(lambda x: x, lambda x: x) == 10
    assert Task.reject(10).fork(lambda x: x, lambda x: x) == 10


# Generated at 2022-06-24 00:37:05.683417
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        assert reject
        assert resolve
        return None

    task = Task(fork)
    assert task.fork == fork



# Generated at 2022-06-24 00:37:11.147911
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """

    actual = Task.of(1)
    assert actual.fork(lambda x: x, lambda x: x) == 1

    actual = Task.of('test')
    assert actual.fork(lambda x: x, lambda x: x) == 'test'


# Generated at 2022-06-24 00:37:17.249823
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(lambda value: 0, lambda value: value) == 1
    assert Task(lambda reject, _: reject(1)).fork(lambda value: value, lambda value: value) == 1


# Generated at 2022-06-24 00:37:23.408795
# Unit test for method map of class Task
def test_Task_map():
    """
    Method map must to return new Task with stored value or
    keep value if exception was occur during fork.

    :returns: status code
    :rtype: int
    """
    def resolve_test(resolve_value):
        def resolve(value):
            assert value == resolve_value
            assert False # Should not be called

        def reject(value):
            assert value == reject_value
            assert True # OK

        return Task(lambda reject_, resolve_: reject_(reject_value)).map(
            lambda _: resolve_value
        ).fork(reject, resolve)

    def reject_test(reject_value):
        def resolve(value):
            assert value == resolve_value
            assert False # Should not be called

        def reject(value):
            assert value == reject_value
            assert True # OK

       

# Generated at 2022-06-24 00:37:29.645759
# Unit test for method bind of class Task
def test_Task_bind():
    """
    check correct of method bind
    """
    # test for correct operation of method bind
    task_value = Task.of(5).bind(lambda value: Task.of(value * 3))
    assert task_value.fork(None, lambda v: v) == 15

    # test for correct operation of method bind with reject result
    task_value = Task.of(5).bind(lambda value: Task.reject(value * 3))
    assert task_value.fork(lambda v: v, None) == 15

# Generated at 2022-06-24 00:37:32.016072
# Unit test for method map of class Task
def test_Task_map():
    value = 5
    fn = lambda x: x * 2
    assert Task.of(value).map(fn).fork(None, None) == fn(value)


# Generated at 2022-06-24 00:37:34.401347
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject(1)

    task = Task(fork)
    assert isinstance(task, Task)
    assert callable(task.fork)


# Generated at 2022-06-24 00:37:37.316884
# Unit test for constructor of class Task
def test_Task():
    # create new task
    task = Task(lambda reject, resolve: resolve('OK'))

    # assert it
    print(task.fork(lambda value: print('ERROR: ' + str(value)), lambda value: print(value)))




# Generated at 2022-06-24 00:37:43.266077
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.reject(value)

    task = Task(lambda reject, resolve: resolve("test")).bind(fn)

    assert_that(
        task.fork(lambda arg: arg, lambda _: True),
        equal_to("test")
    )


# Generated at 2022-06-24 00:37:48.956220
# Unit test for method bind of class Task
def test_Task_bind():
    value = 42
    # generate Task
    task = Task.of(value)
    # wrap with map function
    # mapper function is function to double input value
    task = task.bind(lambda value: Task.of(value + 2))
    # get result
    assert task.fork(lambda _: None, lambda _: None) == value + 2
    
    

# Generated at 2022-06-24 00:37:52.024846
# Unit test for method bind of class Task
def test_Task_bind():
    def add_2(arg):
        return arg + 2

    def add_3(arg):
        return Task.of(arg + 3)

    task = Task.of(1).bind(add_2).bind(add_3)
    assert task.fork(None, lambda value: value) == 6



# Generated at 2022-06-24 00:37:57.163054
# Unit test for method map of class Task
def test_Task_map():
    @Task.of
    def foo(x):
        return x

    @Task.reject
    def bar(x):
        return x

    def _(x):
        return x

    def bar_mapper(x):
        return x + 1

    assert foo(5).map(_).fork(lambda x: x, lambda x: x) == 5
    assert foo(5).map(bar_mapper).fork(lambda x: x, lambda x: x) == 6
    assert bar(5).map(_).fork(lambda x: x, lambda x: x) == 5
    assert bar(5).map(bar_mapper).fork(lambda x: x, lambda x: x) == 5


# Generated at 2022-06-24 00:38:00.981514
# Unit test for method map of class Task
def test_Task_map():
    def test_fork(reject, resolve):
        resolve(1)

    task_instance = Task(test_fork)
    fn_mapper = lambda arg: arg + 1

    task_mapped = task_instance.map(fn_mapper)
    assert 2 == task_mapped.fork(lambda _: None, lambda a: a)


# Generated at 2022-06-24 00:38:07.009328
# Unit test for method bind of class Task
def test_Task_bind():
    # TODO: Rewrite test for make it more clear

    t1 = Task.of(1)
    t2 = t1.bind(lambda arg: Task.of(arg + 1))
    assert t2.fork(lambda reject: reject, lambda resolve: resolve) == 2

    t3 = t2.bind(lambda arg: Task.reject(arg + 1))
    assert t3.fork(lambda reject: reject, lambda resolve: resolve) == 3

    t4 = t3.bind(lambda arg: Task.of(arg + 1))
    assert t4.fork(lambda reject: reject, lambda resolve: resolve) == 3

    assert t4.fork(lambda arg: arg, lambda resolve: resolve) == 3

    t5 = Task.reject(1)

# Generated at 2022-06-24 00:38:14.348407
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for checking Task method bind.
    """
    def map_func(value):
        """
        Some function for binding.
        """
        return Task.of(value + 2)

    def fork_func(reject, resolve):
        """
        Fork function, when called return rejected Task with value 20.
        """
        return reject(20)

    task = Task(fork_func)
    result = task.bind(map_func).fork(
        lambda value: assert_equal(value, 20),
        lambda _: assert_fail()
    )

    assert_equal(result, None)


# Generated at 2022-06-24 00:38:18.447862
# Unit test for constructor of class Task
def test_Task():
    empty = None

    task = Task.of(2)
    task.fork(lambda x: empty, lambda x: x) == 2

    task = Task.reject(2)
    task.fork(lambda x: x, lambda x: empty) == 2


# Generated at 2022-06-24 00:38:24.092240
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    """
    assert Task.of(21).bind(add_2).fork == Task.of(23).fork
    assert Task.of(21).bind(lambda val: Task.of(val + 2)).fork == Task.of(23).fork
    assert Task.reject(21).bind(add_2).fork == Task.reject(21).fork


# Generated at 2022-06-24 00:38:27.912769
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task.
    You can run this test with nose:
    ```
    nosetests test/test_Task.py:test_Task
    ```
    """
    assert Task(lambda _, __: None)



# Generated at 2022-06-24 00:38:33.122725
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return value

    def reject(value):
        return value

    def mapper_value(value):
        return value + 3

    func = lambda _, resolve: resolve(3)
    task = Task(func)

    assert task.fork(reject, resolve) == 3
    assert task.map(mapper_value).fork(reject, resolve) == 6

test_Task_map()


# Generated at 2022-06-24 00:38:35.965609
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda reject, resolve: resolve(42))
    assert task.map(lambda arg: arg * 2).fork(
        lambda arg: -1,
        lambda arg: arg
    ) == 84

# Unit test: all Task must be isomorphic

# Generated at 2022-06-24 00:38:44.943516
# Unit test for constructor of class Task
def test_Task():
    def value(reject, resolve):
        return resolve(10)

    def error(reject, resolve):
        return reject('some error')

    assert isinstance(Task.of('value'), Task)
    assert Task.of('value').fork(lambda _ : _, lambda _ : _) == 'value'

    assert isinstance(Task.reject('error'), Task)
    assert Task.reject('error').fork(lambda _ : _, lambda _ : _) == 'error'

    assert isinstance(Task(value), Task)
    assert Task(value).fork(lambda _ : _, lambda _ : _) == 10

    assert isinstance(Task(error), Task)
    assert Task(error).fork(lambda _ : _, lambda _ : _) == 'some error'


# Generated at 2022-06-24 00:38:54.462529
# Unit test for method bind of class Task
def test_Task_bind():
    task1 = Task.of(1).bind(lambda x: Task.of(x + 1))
    assert task1.fork(lambda x: x, lambda x: x) == 2

    task2 = Task.of(1).bind(lambda x: Task.reject("Err"))
    assert task2.fork(lambda x: x, lambda x: x) == "Err"

    task3 = Task.reject("Err").bind(lambda x: Task.of(x))
    assert task3.fork(lambda x: x, lambda x: x) == "Err"

test_Task_bind()

# Generated at 2022-06-24 00:38:56.350015
# Unit test for constructor of class Task
def test_Task():
    fork = lambda _, resolve: resolve('ok')
    x = Task(fork)

    assert x.fork == fork


# Generated at 2022-06-24 00:39:07.590244
# Unit test for method map of class Task
def test_Task_map():
    # success case
    def success_resolve(value):
        expect(value).to.be(2)

    def success(resolve):
        def plus_one(value):
            return value + 1

        Task.of(1).map(plus_one).fork(lambda _: _, success_resolve)

    success()

    # failure case
    called = False

    def failure_reject(value):
        expect(value).to.be(15)
        nonlocal called
        called = True

    def failure(resolve):
        def plus_one(value):
            return value + 1

        Task.reject(15).map(plus_one).fork(failure_reject, lambda _: _)

    failure()
    expect(called).to.be(True)


# Generated at 2022-06-24 00:39:12.576036
# Unit test for constructor of class Task
def test_Task():
    def fork_creator(reject, resolve):
        reject('reject')
        resolve('resolve')

    task = Task(fork_creator)

    assert type(task) == Task
    assert task.fork == fork_creator


# Generated at 2022-06-24 00:39:16.513753
# Unit test for constructor of class Task
def test_Task():
    assert_equal(repr(Task.of(1)), 'Task[Function]')
    assert_equal(repr(Task.reject('error')), 'Task[Function]')



# Generated at 2022-06-24 00:39:20.375846
# Unit test for method map of class Task
def test_Task_map():
    # Test map
    success = Task.of(10)
    fail = Task.reject(10)
    assert(success.map(lambda x: x * 2).fork(lambda _: False, lambda x: x) == 20)
    assert(fail.map(lambda x: x * 2).fork(lambda _: False, lambda x: x) == 10)



# Generated at 2022-06-24 00:39:23.723419
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda arg: arg, lambda arg: arg) == 1
    assert Task.reject(1).fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-24 00:39:28.861972
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 2)

    def multiply(x):
        return Task.of(x * 2)

    result = Task.of(1) \
        .bind(add) \
        .bind(multiply) \
        .fork(lambda _: 'Error', lambda x: x)

    assert(result == 4)



# Generated at 2022-06-24 00:39:34.442329
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(1)\
        .map(lambda x: x + 1)\
        .map(lambda x: x * 2)\
        .fork(
            lambda reject: print(reject),
            lambda resolve: print(resolve)
        )
    assert result == 4


# Generated at 2022-06-24 00:39:39.208324
# Unit test for constructor of class Task
def test_Task():
    t = Task(lambda _, resolve: resolve("Hello world!"))
    assert t.fork(lambda _: 1, lambda v: v + " Test!") == "Hello world! Test!"


# Generated at 2022-06-24 00:39:42.534668
# Unit test for method bind of class Task
def test_Task_bind():
    def test(x):
        assert x == 2

    Task.of(1) \
        .bind(lambda x: Task.of(x + 1)) \
        .fork(lambda x: test(x), lambda x: test(x))

if __name__ == "__main__":
    test_Task_bind()

# Generated at 2022-06-24 00:39:46.751869
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(None, assert_equal(1))
    assert Task(lambda _, resolve: resolve(1)).fork(assert_equal(1), None)
    assert Task(lambda _, resolve: resolve(1)).fork(None, None)


# Generated at 2022-06-24 00:39:51.723752
# Unit test for constructor of class Task
def test_Task():
    import unittest

    class TestTask(unittest.TestCase):
        def test_constructor(self):
            def mock(reject, resolve):
                assert reject == 1
                assert resolve == 2

            t = Task(mock)
            t.fork(1, 2)

    return unittest.main()


# Generated at 2022-06-24 00:39:58.601079
# Unit test for method map of class Task
def test_Task_map():
    def test_case_1():
        def double(x):
            return x * 2

        double_task = Task.of(5).map(double)
        value = double_task.fork(lambda _: None, lambda arg: arg)
        expected = 5 * 2
        assert value == expected

    def test_case_2():
        def hello_world(x):
            return "Hello, world!".format(x)

        double_task = Task.of(5).map(hello_world)
        value = double_task.fork(lambda _: None, lambda arg: arg)
        expected = "Hello, world!"
        assert value == expected

    test_case_1()
    test_case_2()


# Generated at 2022-06-24 00:40:02.261644
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(
        lambda _: False,
        lambda arg: arg == 2
    )


# Generated at 2022-06-24 00:40:04.271989
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(0)

    assert task.fork(None, lambda arg: arg) == 0

    task = task.map(lambda a: a + 1)

    assert task.fork(None, lambda arg: arg) == 1

    task = task.map(lambda a: a + 1)

    assert task.fork(None, lambda arg: arg) == 2


# Generated at 2022-06-24 00:40:10.665223
# Unit test for method bind of class Task
def test_Task_bind():
    def case(value):
        def counter():
            counter.count += 1
            return Task.of(value)

        counter.count = 0

        begin_t = Task.of(1) \
            .bind(lambda _: counter()) \
            .bind(lambda _: counter())

        assert begin_t.fork(None, None) is None
        assert counter.count == 2

    case(1)
    case('1')



# Generated at 2022-06-24 00:40:15.191529
# Unit test for constructor of class Task
def test_Task():
    def fork_fn(reject, resolve):
        return reject("test")

    task = Task(fork_fn)

    assert task.fork(lambda reject, resolve: reject("test2"), lambda resolve, reject: reject("test2")) == "test2"

# Unit test to resolve Task

# Generated at 2022-06-24 00:40:18.769649
# Unit test for constructor of class Task
def test_Task():
    def fork(_, resolve):
        return resolve('test')

    task = Task(fork)
    assert isinstance(task, Task)


# Generated at 2022-06-24 00:40:19.843391
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(0).fork(lambda a: None, lambda b: b) == 0


# Generated at 2022-06-24 00:40:27.236384
# Unit test for method bind of class Task
def test_Task_bind():
    """
    test_Task_bind: should return value that stored in resolve argument.
    """
    task = Task.of(1)
        # resolve: 1, reject: None
    wrapped_task = task.bind(lambda value: Task.of(value + 1))
        # resolve: 1, reject: None
    assert wrapped_task.fork(lambda e: e, lambda v: v) == 2
        # 1 + 1 = 2



# Generated at 2022-06-24 00:40:30.632943
# Unit test for constructor of class Task
def test_Task():
    """
    Test of constructor of class Task
    """
    task = Task(lambda a, b: a)
    assert isinstance(task, Task)


# Generated at 2022-06-24 00:40:34.740784
# Unit test for method map of class Task
def test_Task_map():
    """
    map class method test case
    """
    assert Task.of(1).map(lambda x: x + 10) == Task.of(11)
    assert Task.of(1).map(lambda x: x + 10).map(lambda x: x * 10) == Task.of(110)


# Generated at 2022-06-24 00:40:40.979958
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind take function, store it and call with Task value during calling fork function.
    Return result of called.
    """
    print('\n__________ Test for method bind of class Task __________')

    ## Test case 1
    task = Task.of(2)

    def fn(value):
        print('Task:', value)
        return Task.of(3)

    task_result = task.bind(fn)
    print(task_result.fork(
        lambda arg: print('Error:', arg),
        lambda arg: print('Success:', arg)
    ))


# Generated at 2022-06-24 00:40:43.902938
# Unit test for method map of class Task
def test_Task_map():
    def addition(x):
        return x + 1
    
    assert Task.of(10).map(addition).fork(None, lambda x: x) == 11


# Generated at 2022-06-24 00:40:49.267354
# Unit test for constructor of class Task
def test_Task():
    """
    functions to call during fork
    """
    def fork1():
        return "foo"

    def fork2():
        return "bar"

    # construct Task object
    task1 = Task(fork1)
    task2 = Task(fork2)

    # test results
    assert task1.fork() == "foo"
    assert task2.fork() == "bar"


# Generated at 2022-06-24 00:40:53.368961
# Unit test for constructor of class Task
def test_Task():
    def a(reject, resolve):
        return resolve("a")

    def b(reject, resolve):
        return reject("b")

    assert Task(a).fork(lambda reject: reject("a"), lambda resolve: resolve("b")) == "b"
    assert Task(b).fork(lambda reject: reject("a"), lambda resolve: resolve("b")) == "a"


# Generated at 2022-06-24 00:41:00.655044
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Call Task method bind,
    expect to return Task binded with function
    """
    def result(reject, resolve):
        return resolve('result')

    task = Task(result)
    task = task.bind(lambda arg: Task(result))

    assert task.fork(lambda arg: arg, lambda arg: arg) == 'result'



# Generated at 2022-06-24 00:41:03.394966
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return resolve('fork')

    fn = Task(fork)
    assert fn.fork(lambda x: print(x), lambda x: print(x)) == 'fork'


# Generated at 2022-06-24 00:41:08.519484
# Unit test for method bind of class Task
def test_Task_bind():
    def to_five():
        return Task.of(5)

    def throw_error():
        return Task.reject("error")

    assert Task.of(1).bind(to_five).fork(lambda a: a, lambda b: b) == 5
    assert Task.reject("error").bind(throw_error).fork(lambda a: a, lambda b: b) == "error"


# Generated at 2022-06-24 00:41:15.445008
# Unit test for constructor of class Task
def test_Task():
    """
    Task called during initializing
    """
    def fork(reject, resolve):
        """
        Fork function that call reject with "reject" string and resolve with "resolve"
        string as arguments.
        """
        reject("reject")
        resolve("resolve")

    task = Task(fork)
    assert task.fork(lambda x: x) == "resolve"



# Generated at 2022-06-24 00:41:21.840111
# Unit test for method bind of class Task
def test_Task_bind():
    def f1(v): return v + 5

    def f2(v): return v * 2

    assert Task.of(5).bind(lambda v: Task.of(f1(v))).bind(lambda v: Task.of(f2(v))).fork(lambda v: None, lambda v: v) == 20



# Generated at 2022-06-24 00:41:30.598927
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test of Task.bind method.
    """
    def mapper_function(value):
        return Task.of(value * 2)

    def reject_function(value):
        return Task.reject(value * 2)

    def resolve_function(value):
        return Task.of(value * 2)

    assert Task(mapper_function).bind(resolve_function).fork(
        lambda f: 'reject: {0}'.format(f),
        lambda s: 'resolve: {0}'.format(s)
    ) == 'resolve: 4'


# Generated at 2022-06-24 00:41:41.224128
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task calling in bind, after calling of Task in bind method,
    called Task will handle error or resolve using fork function.
    """

    def create_counter(count=0):
        """
        Create counter with set counts.

        :param count: counts to set
        :type count: int
        :returns: counter
        :rtype: int
        """
        return count

    def fork_task(reject, resolve):
        """
        Call count argument reject or resolve.

        :param reject: reject function of Task
        :type reject: Function(count) -> Any
        :param resolve: resolve function of Task
        :type resolve: Function(count) -> Any
        """
        reject(create_counter(2))
        resolve(create_counter(5))
