

# Generated at 2022-06-24 00:31:45.603114
# Unit test for method bind of class Task
def test_Task_bind():
    def add_suffix(suffix):
        def inner(string):
            return string + suffix

        return Task.of(inner)

    assert Task.of('test') \
           .bind(add_suffix('d')) \
           .fork(lambda x: True, lambda x: False) is False

    assert Task.of('test') \
           .bind(add_suffix('ing')) \
           .fork(lambda x: True, lambda x: False) is False

    assert Task.of('test') \
           .bind(add_suffix('ed')) \
           .fork(lambda x: True, lambda x: False) is False



# Generated at 2022-06-24 00:31:52.314103
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task(lambda _, resolve: resolve(1)).bind(lambda x: Task.of(x + 1)).fork(lambda _: 0, lambda x: x) == 2
    assert Task(lambda _, resolve: resolve(1)).bind(lambda x: Task.reject(x + 1)).fork(lambda x: x, lambda _: 0) == 2
    assert Task(lambda reject, _: reject(1)).bind(lambda x: Task.of(x + 1)).fork(lambda x: x, lambda _: 0) == 1
    assert Task(lambda reject, _: reject(1)).bind(lambda x: Task.reject(x + 1)).fork(lambda x: x, lambda _: 0) == 1


# Generated at 2022-06-24 00:31:54.722404
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        pass

    result = Task(fork)
    assert result.fork is fork


# Generated at 2022-06-24 00:31:59.510728
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(42)
    task_mapped = task.bind(lambda x: Task.of(x + 1))
    task_mapped_result = task_mapped.fork(
        lambda _: 'error',
        lambda value: value
    )

    assert task_mapped_result == 43


# Generated at 2022-06-24 00:32:07.766814
# Unit test for method bind of class Task
def test_Task_bind():
    res_type = Task(lambda reject, resolve: resolve('a')).bind(
        lambda arg: Task(lambda reject, resolve: resolve(arg * 2))
    ).fork(lambda _: 'failed', lambda res: type(res))
    assert res_type == str

    res = Task(lambda reject, resolve: resolve('a')).bind(
        lambda arg: Task(lambda reject, resolve: resolve(arg * 2))
    ).fork(lambda _: 'failed', lambda res: res)
    assert res == 'aa'

    res = Task(lambda reject, resolve: reject(ValueError('123'))).bind(
        lambda arg: Task(lambda reject, resolve: resolve(arg * 2))
    ).fork(lambda err: str(err), lambda res: res)
    assert res == '123'



# Generated at 2022-06-24 00:32:11.609180
# Unit test for method map of class Task
def test_Task_map():
    def check_plus_1(resolve, reject):
        task = Task.of(2).map(lambda x: x + 1)
        task.fork(reject, resolve)

    assert fork(check_plus_1) == 3


# Generated at 2022-06-24 00:32:14.144369
# Unit test for constructor of class Task
def test_Task():
    def task(resolve, _):
        return resolve(1)

    task_obj = Task(task)
    assert task_obj.fork(None, None) == 1


# Generated at 2022-06-24 00:32:20.306495
# Unit test for constructor of class Task
def test_Task():

    def resolver(value):
        assert value == 1

    def rejector(value):
        assert value == 2

    Task(lambda reject, resolve: resolve(1)).fork(rejector, resolver)
    Task(lambda reject, resolve: reject(2)).fork(rejector, resolver)

test_Task()



# Generated at 2022-06-24 00:32:21.616816
# Unit test for constructor of class Task
def test_Task():
    """Test for Task constructor"""
    assert Task('fork')



# Generated at 2022-06-24 00:32:23.635033
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        pass

    assert Task(fork).fork == fork


# Generated at 2022-06-24 00:32:27.852878
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(123)
    print("Task value is:", task.fork(lambda _: "Rejected", lambda result: result))
    print("Task.map is:", task.map(lambda x: x + 1).fork(lambda _: "Rejected", lambda result: result))


# Generated at 2022-06-24 00:32:30.477725
# Unit test for constructor of class Task
def test_Task():
    test_fork = lambda r, s: None
    task = Task(test_fork)

    assert task.fork is test_fork


# Generated at 2022-06-24 00:32:40.670055
# Unit test for method bind of class Task
def test_Task_bind():
    def increment(number):
        return Task.of(number + 1)

    def resolve_action(number):
        return Task.of(number * 2)

    # It should be equal to Promise.resolve(4)
    task1 = Task.of(2).bind(increment).bind(resolve_action)
    assert task1.fork(None, lambda value: value) == 4

    def reject_action(number):
        return Task.reject(number * 4)

    # It should be equal to Promise.reject(8)
    task2 = Task.of(2).bind(increment).bind(reject_action)
    assert task2.fork(lambda value: value, None) == 8

    # It should be equal to Promise.reject(4)

# Generated at 2022-06-24 00:32:43.553767
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda value: Task.of(value + 1)).fork(lambda reject: reject, lambda resolve: resolve) == 2


# Generated at 2022-06-24 00:32:52.945269
# Unit test for method bind of class Task
def test_Task_bind():
    def first_task(reject, resolve):
        return resolve("First Task")

    def second_task(reject, resolve):
        reject("Second Task")

    def third_task(reject, resolve):
        resolve("Third Task")

    def error_handler(result):
        assert result == "Second Task"
        return "Error handled successfully"

    def assert_resolved(result):
        assert isinstance(result, Task) and result.fork(lambda _: _, lambda _: _) == "Error handled successfully"

    def assert_rejected(result):
        assert isinstance(result, Task) and result.fork(lambda _: _, lambda _: _) == "Error handled successfully"


# Generated at 2022-06-24 00:32:59.108350
# Unit test for method bind of class Task
def test_Task_bind():
    def fixture():
        # def double(x: int) -> int
        def double(x):
            return x * 2

        # def square(x: int) -> int
        def square(x):
            return x ** 2

        # def double_square(x: int) -> Task[int]
        def double_square(x):
            return Task(
                lambda _, result: result(square(x) + double(x))
            )

        # def reject_square(x: int) -> Task[int]
        def reject_square(x):
            return Task(
                lambda reject, _: reject(square(x))
            )

        # def task_of(x: int) -> Task[int]
        def task_of(x):
            return Task(
                lambda _, result: result(x)
            )



# Generated at 2022-06-24 00:33:04.676142
# Unit test for constructor of class Task
def test_Task():
    def assert_result_of(task, expected):
        result = []

        def resolve(arg):
            result.append(arg)

        def reject(arg):
            result.append(arg)

        task.fork(reject, resolve)
        assert result == expected

    assert_result_of(Task.of(5), [5])
    assert_result_of(Task.reject(5), [5])



# Generated at 2022-06-24 00:33:12.546538
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_task(value):
        return Task.of(value)

    def reject_task(value):
        return Task.reject(value)

    # Call reject task
    assert Task.reject(1).bind(resolve_task).fork(resolve_task, reject_task).fork(None, None) == 1
    assert Task.reject(2).bind(reject_task).fork(resolve_task, reject_task).fork(None, None) == 2

    # Call resolve task
    assert Task.of(3).bind(resolve_task).fork(reject_task, resolve_task).fork(None, None) == 3
    assert Task.of(4).bind(reject_task).fork(reject_task, resolve_task).fork(None, None) == 4


# Generated at 2022-06-24 00:33:16.724312
# Unit test for method map of class Task
def test_Task_map():
    def some_function(obj):
        return obj * obj

    task = Task.of(12).map(some_function)
    assert task.fork(None, lambda value: value == 12 * 12)

    task = Task.reject(12).map(lambda value: value * value)
    assert task.fork(lambda reason: reason == 12, None)


# Generated at 2022-06-24 00:33:21.050137
# Unit test for method map of class Task
def test_Task_map():
    def identity(value):
        return value

    def inc(value):
        return value + 1

    assert Task.of(1).map(identity).fork(None, identity) == Task.of(1).fork(None, identity)
    assert Task.of(1).map(inc).fork(None, identity) == Task.of(2).fork(None, identity)


# Generated at 2022-06-24 00:33:29.221893
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task.
    """
    def resolve(value):
        return value

    def reject(value):
        return value

    deferred = Task(lambda rej, res: res(True))
    deferred.fork(reject, resolve)

    assert deferred.fork(reject, resolve) == True

    deferred = Task(lambda rej, res: rej(False))
    deferred.fork(reject, resolve)

    assert deferred.fork(reject, resolve) == False

    assert Task.of(True).fork(reject, resolve) == True
    assert Task.reject(False).fork(reject, resolve) == False



# Generated at 2022-06-24 00:33:33.687265
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + ' and bbb')

    result = Task.of('AAA')
    assert result.bind(fn).fork(lambda r: 'reject', lambda r: r) == 'AAA and bbb'


# Generated at 2022-06-24 00:33:41.235291
# Unit test for method bind of class Task
def test_Task_bind():
    def test_return_value(expected_value):
        task = Task.of(expected_value)
        result = task.bind(lambda arg: Task.of('mapped'))
        called_resolve = False

        def resolve(value):
            nonlocal called_resolve
            called_resolve = True
            assert value == 'mapped'

        result.fork(lambda arg: False, resolve)
        return called_resolve

    assert test_return_value(1) == True
    assert test_return_value(0) == True
    assert test_return_value('') == True
    assert test_return_value('some value') == True
    assert test_return_value(None) == True


# Generated at 2022-06-24 00:33:44.772317
# Unit test for method map of class Task
def test_Task_map():
    promise = Task.of(5)

# Generated at 2022-06-24 00:33:48.321862
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(arg):
        print("resolve: " + arg)

    def reject(arg):
        print("reject: " + arg)

    # Example
    # Task.of("5").bind(lambda arg: Task.of(arg+"5")).fork(reject, resolve)
    # Output:
    # resolve: 55
    Task.of("5").bind(lambda arg: Task.of(int(arg) + 5)).map(str).fork(reject, resolve)
    # Output:
    # resolve: 10
    # Task.of("5").map(int).bind(lambda arg: Task.of(str(arg + 5))).fork(reject, resolve)
    # Output:
    # resolve: 55

# Generated at 2022-06-24 00:33:49.969647
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x * x

    def fork(reject, resolve):
        return resolve(5)

    assert Task(fork).map(fn).fork(lambda x: x, lambda x: x) == fn(5)


# Generated at 2022-06-24 00:33:53.982686
# Unit test for method map of class Task
def test_Task_map():
    def increment(number):
        return number + 1

    def decrement(number):
        return number - 1

    def error(message):
        raise Exception(message)

    def result_1(resolve, reject):
        resolve(1)
        reject(error)

    def result_2(reject, resolve):
        resolve(2)
        reject(error)

    assert Task(result_1).map(increment).fork(error, lambda x: x) == 2
    assert Task(result_2).map(decrement).fork(error, lambda x: x) == 1


# Generated at 2022-06-24 00:33:59.782547
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.
    """
    def fork(reject, resolve):
        pass

    arg = Task(fork)
    assert isinstance(arg, Task)
    assert isinstance(arg.fork, FunctionType)
    assert arg.fork == fork


# Generated at 2022-06-24 00:34:02.182536
# Unit test for method map of class Task
def test_Task_map():
    @Task.of.map
    def add1(value):
        return value + 1

    assert add1(0) == 1

    @Task.of.map
    def add2(value):
        raise Exception()

    assert not callable(add2)



# Generated at 2022-06-24 00:34:07.953618
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test that method bind of class Task work as expected.
    """
    is_mock = True
    value = 1000
    value2 = 500
    value3 = 100
    value4 = 375

    fork = lambda _, resolve: resolve(value)
    task = Task(fork)

    def fn(arg):
        assert is_mock
        assert value == arg
        return Task.of(value2)

    def reject(_):
        assert not True
        return False

    def resolve(arg):
        assert value2 == arg

    task.bind(fn).fork(reject, resolve)

    def fn2(arg):
        assert is_mock
        assert value2 == arg
        return Task.of(value3)

    def fn3(arg):
        assert is_mock
        assert value3 == arg


# Generated at 2022-06-24 00:34:13.293178
# Unit test for constructor of class Task
def test_Task():
    """Unit test for constructor """

    # Test function into constructor argument
    def fork(reject, resolve):
        pass

    # Initialization of Task
    res = Task(fork)

    # Asserting fork attribute is callable function
    assert callable(res.fork)

# Unit test of method of class Task

# Generated at 2022-06-24 00:34:15.453282
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1) == Task(lambda _, resolve: resolve(1))


# Generated at 2022-06-24 00:34:24.908479
# Unit test for method map of class Task
def test_Task_map():
    from threading import Thread
    from time import sleep

    def fake_sleep(value, timeout=5):
        sleep(timeout)
        return value

    def sleep_task():
        return Task(lambda reject, resolve: fake_sleep(resolve, 1))

    def threaded_map(value):
        def thread_work():
            return sleep_task().map(lambda x: x + value)

        td = Thread(target=thread_work)
        td.start()
        return td

    assert 5 == threaded_map(5).join().fork(lambda _: None, lambda x: x)
    assert 10 == threaded_map(5).join().fork(lambda _: None, lambda x: x)



# Generated at 2022-06-24 00:34:26.471959
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return fork

    task = Task(fork)
    assert task.fork is fork


# Generated at 2022-06-24 00:34:32.784670
# Unit test for method map of class Task
def test_Task_map():
    def mock_resolve(arg):
        return arg

    def mock_reject(arg):
        return arg

    def mock_value(arg):
        return arg

    task = Task(lambda reject, resolve: resolve(mock_value))

    assert task.map(mock_value).fork(mock_reject, mock_resolve) == mock_value

# Generated at 2022-06-24 00:34:35.516826
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task constructor
    """
    task = Task(lambda _, resolve: resolve(None))
    assert isinstance(task, Task)


# Generated at 2022-06-24 00:34:38.500971
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    task = Task.of(2)
    task_mapped = task.map(fn)

    assert task_mapped.fork(lambda error: error, lambda result: result) == 3


# Generated at 2022-06-24 00:34:44.932482
# Unit test for method map of class Task
def test_Task_map():
    """
    Check result of calling Task with method map.
    """
    def resolve_mapper(value):
        """
        Function to test method map of class Task.
        """
        return value + 10

    task = Task.of(10)
    task = task.map(resolve_mapper)
    result = task.fork(
        lambda reject: reject,
        lambda resolve: resolve
    )
    assert result == 20


# Generated at 2022-06-24 00:34:47.738138
# Unit test for constructor of class Task
def test_Task():
    value = 1

    actual = Task(lambda _, resolve: resolve(value)).fork(None, None)
    expected = value

    assert actual == expected


# Generated at 2022-06-24 00:34:51.085125
# Unit test for constructor of class Task
def test_Task():
    """
    :returns: Bool
    :rtype: bool
    """
    f = lambda _, resolve: resolve(2)

    unit = Task(fork=f)

    assert unit.fork(reject=lambda _: _, resolve=lambda _: _) == 2



# Generated at 2022-06-24 00:34:54.205318
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value + 1)

    assert Task.of(1).bind(fn).fork(
        lambda e: e,
        lambda r: r
    ) == 2

# Generated at 2022-06-24 00:35:03.605823
# Unit test for method bind of class Task
def test_Task_bind():
    def two_fork_bind(reject, resolve):
        def first_fork(reject, resolve):
            return resolve(2)

        def second_fork(reject, resolve):
            return resolve(3)

        return Task(first_fork).bind(
            lambda value: Task(second_fork)
        ).fork(reject, resolve)

    assert Task(two_fork_bind).fork(lambda _: False, lambda value: value == 2)
    assert Task(two_fork_bind).fork(lambda _: False, lambda value: value == 3)




# ##############################
# 5. Applicative
# ##############################

# All applicative types must implement the following operations:
# pure, apply

# A value of type <*> t k must have the following properties:
#   <*> pure f

# Generated at 2022-06-24 00:35:11.601509
# Unit test for method map of class Task
def test_Task_map():
    def test_1():
        assert Task.of(1).map(lambda x: x + 2).fork(lambda _: False, lambda x: x == 3)

    def test_2():
        assert Task.of(1).map(lambda x: Task.of(x + 2)).fork(
            lambda _: False,
            lambda x: x.fork(lambda _: False, lambda x: x == 3)
        )

    def test_3():
        assert Task.of(1).map(lambda x: Task.reject(x + 2)).fork(
            lambda x: x == 3, lambda _: False
        )

    test_1()
    test_2()
    test_3()

# Generated at 2022-06-24 00:35:13.774863
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(42)

    task = Task(fork)

    assert isinstance(task, Task)
    assert task.fork is fork


# Generated at 2022-06-24 00:35:17.653013
# Unit test for method map of class Task
def test_Task_map():
    @Task.of
    def task(reject, resolve):
        resolve('Hello')

    # check function of
    assert task.fork(lambda _: '', lambda arg: arg) == 'Hello'

    # check map
    mapped_task = task.map(lambda arg: arg + ' World!')
    assert mapped_task.fork(lambda _: '', lambda arg: arg) == 'Hello World!'


# Generated at 2022-06-24 00:35:20.168865
# Unit test for method map of class Task
def test_Task_map():
    def add1(value):
        return value + 1

    task = Task.of(1)

# Generated at 2022-06-24 00:35:28.274556
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """
    start = time.time()

    # create resolved task with value 1
    task = Task.of(1)

    # call fork method to start execution
    def task_resolved(reject, resolve):
        return task.fork(
            lambda err: reject(err),
            lambda value: resolve(value)
        )

    # check if bind in the workflow of this task works correctly

# Generated at 2022-06-24 00:35:33.303913
# Unit test for method map of class Task
def test_Task_map():
    result = Task.of(2) \
        .map(lambda arg: arg + 2) \
        .map(lambda arg: arg * 5)

    expected = 20

    assert result.fork(lambda _: False, lambda value: value == expected)


# Generated at 2022-06-24 00:35:35.147384
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task constructor.
    """
    result = Task(lambda reject, resolve: resolve(1)).fork(
        lambda arg: 'bad',
        lambda arg: 'good'
    )
    assert 'good' == result



# Generated at 2022-06-24 00:35:40.911915
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2


# Generated at 2022-06-24 00:35:51.280592
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for constructor of class Task
    """

    def test_value(index, reject, resolve):
        """
        Function to check values to resolve and reject.
        Raise exception if it has wrong arguments.

        :param index: number of task
        :type index: int
        :param reject: reject function for Task[index]
        :type reject: Function(value)
        :param resolve: resolve function for Task[index]
        :type resolve: Function(value)
        :raises: Exception if one of arguments is wrong
        """
        if not isinstance(index, int):
            raise Exception('Method fork get wrong first argument')
        if not callable(resolve):
            raise Exception('Method fork get wrong second argument')
        if not callable(reject):
            raise Exception('Method fork get wrong third argument')


# Generated at 2022-06-24 00:35:56.808865
# Unit test for method bind of class Task
def test_Task_bind():
    Task.of(2)\
        .bind(lambda x: Task.of(x + 1))\
        .fork(print, print)

    Task.reject(2)\
        .bind(lambda x: Task.of(x + 1))\
        .fork(print, print)

    Task.reject(2)\
        .bind(lambda x: Task.of(x + 1))\
        .fork(print, print)


# Generated at 2022-06-24 00:36:03.044785
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of class Task
    """
    def run():
        def pow_iter(num):
            """
            Simple function, that return number in power of 3
            """
            return num**3

        # Create Task with stored vale = 2
        task = Task.of(2)
        assert task.fork == None

        # Transform resolving value of Task
        new_task = task.map(pow_iter)
        assert new_task.fork(lambda value: value, lambda value: value) == 8

    run()


# Generated at 2022-06-24 00:36:05.257334
# Unit test for method map of class Task
def test_Task_map():
    counter = 0

    def inc(value):
        global counter
        counter += 1
        return value + 1

    def fork(reject, resolve):
        assert True

    task = Task(fork)
    result = task.map(inc)
    result.fork(lambda _: reject(False), lambda _: None)
    assert counter == 1


# Generated at 2022-06-24 00:36:06.389462
# Unit test for method bind of class Task
def test_Task_bind():
    t = Task.of(1)
    assert t.bind(lambda x: Task.of(x + 1)).fork(lambda x: x, lambda x: x) == 2



# Generated at 2022-06-24 00:36:09.027828
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)\
        .map(lambda value: value + 1)\
        .map(lambda value: value * 2)

    fork_result = task.fork(lambda _: None, lambda value: value)
    assert fork_result == 4



# Generated at 2022-06-24 00:36:19.429370
# Unit test for method bind of class Task
def test_Task_bind():
    from operator import add, sub
    from functools import partial

    assert Task.of(1).bind(partial(Task.of, 2)) == Task.of(2)
    assert Task.of(1).bind(partial(Task.of, 2)).bind(partial(Task.of, 3)) == Task.of(3)
    assert Task.of(1).bind(Task.of).bind(Task.of) == Task.of(1)
    assert Task.of(3).bind(partial(Task.of, add, 2)).bind(partial(Task.of, sub, 2)) == Task.of(3)

    def par(reject, resolve, value):
        resolve(value)
    t1 = Task(par)
    t1.fork(lambda a: None, lambda a: None)

# Generated at 2022-06-24 00:36:21.356339
# Unit test for method map of class Task
def test_Task_map():
    value = 'test'
    result = Task.of(value).map(lambda arg: arg.upper()).fork(None, lambda arg: arg)

    assert result == value.upper(), 'Value is not mapped'


# Generated at 2022-06-24 00:36:23.881781
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of("Hello world").map(lambda v: v + "!!!").fork(None, lambda v: v) == "Hello world!!!"
    assert Task.reject("Error").map(lambda v: v + "!!").fork(lambda v: v, None) == "Error!!"



# Generated at 2022-06-24 00:36:26.323894
# Unit test for method map of class Task
def test_Task_map():
    resolve = lambda arg: print("resolve: %s" % arg)
    reject = lambda arg: print("reject: %s" % arg)

    task = Task(lambda reject, resolve: resolve(1)).map(lambda arg: arg + 1)
    task.fork(reject, resolve)


# Generated at 2022-06-24 00:36:28.844935
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(10).map(lambda x: x + 20)
    assert task.fork(None, lambda x: x) == 30


# Generated at 2022-06-24 00:36:33.625937
# Unit test for method bind of class Task
def test_Task_bind():
    @task
    def f():
        return 2

    g = Task(lambda reject, resolve: resolve(4))

    assert f().bind(lambda x: g).fork(
        lambda value: assertFalse(value),
        lambda value: assertEquals(value, 4)
    )


# Generated at 2022-06-24 00:36:38.496099
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value * 10

    async def async_mapper(value):
        sleep(1)
        return value * 10

    task = Task.of(10)
    assert task.map(mapper).fork(lambda _: None, lambda value: None) == 100

    async_task = Task(lambda reject, resolve: resolve(task.fork(reject, lambda value: value)))
    assert async_task.map(async_mapper).fork(lambda _: None, lambda value: None) == 100

    assert task.map(None).fork(lambda _: None, lambda value: None) == 10
    assert task.map(mapper).map(None).fork(lambda _: None, lambda value: None) == 10

# Generated at 2022-06-24 00:36:47.820915
# Unit test for method map of class Task
def test_Task_map():
    def fn1(value):
        return value

    def fn2(value):
        return value * value

    def fn3(value):
        return value * value * value

    def fn4(value):
        return value * value * value * value

    def fn5(value):
        return value * value * value * value * value

    def test(state):
        return (
            Task.of(state)
                .map(fn1)
                .map(fn2)
                .map(fn3)
                .map(fn4)
                .map(fn5)
                .fork(
                    lambda reject: reject,
                    lambda resolve: resolve
                )
        )

    assert test(10) == 10000000000



# Generated at 2022-06-24 00:36:52.295607
# Unit test for method bind of class Task
def test_Task_bind():
    def f(_):
        return Task.of(42)

    assert Task(lambda reject, resolve: resolve(42)).bind(f).fork(lambda e: e, lambda v: v) == 42


# Generated at 2022-06-24 00:36:57.278130
# Unit test for method map of class Task
def test_Task_map():
    def assert_equal(x, y):
        if not x == y:
            raise AssertionError('{} not equal to {}'.format(x, y))

    number = Task.of(2).map(lambda x: x + 2)

    assert_equal(number.fork(lambda _: None, lambda x: x), 4)

    def test_reject():
        number = Task.reject(0)
        assert_equal(number.fork(lambda _: None, lambda x: x), None)

    test_reject()


# Generated at 2022-06-24 00:37:03.202900
# Unit test for method map of class Task
def test_Task_map():
    def _(fn, value, assertion):
        assert Task.of(value).map(fn).fork(lambda _: None, assertion)

# Generated at 2022-06-24 00:37:06.257290
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1) == Task(
        lambda _, resolve: resolve(1)
    )
    assert Task.reject(1) == Task(
        lambda reject, _: reject(1)
    )


# Generated at 2022-06-24 00:37:14.155485
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test Task.bind method.

    :returns: None
    :rtype: None
    """
    task = Task.of(2)
    task2 = task.bind(lambda val: Task.of(val * 3))
    task3 = task.bind(lambda _: Task.reject('ERROR'))

    def tester(result, value, error):
        if not isinstance(result, Task):
            print('should return a task')
        elif not result.fork(lambda err: err, lambda val: val) == value:
            print(result.fork(lambda err: err, lambda val: val), 'should be', value)

# Generated at 2022-06-24 00:37:15.347919
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, r: r(1))
    assert task.fork(lambda _: 0, lambda r: r) == 1


# Generated at 2022-06-24 00:37:17.619594
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda: 1).fork(lambda: None, lambda: 1) == 1


# Generated at 2022-06-24 00:37:20.073006
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task.of(x + 1)

    def multiply(x):
        return Task.of(x * x)

    def resolve(value):
        assert value == 16

    def reject(error):
        raise Exception("Error with value = {}".format(error))

    Task.of(1).bind(add).bind(multiply).fork(reject, resolve)


# Generated at 2022-06-24 00:37:23.845579
# Unit test for method bind of class Task
def test_Task_bind():
    def first_task(value):
        return Task.of(value)

    def second_task(value):
        return Task.of(value + 1)

    first_task(1).bind(second_task).fork(print, print)


# Generated at 2022-06-24 00:37:33.250231
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def add_three(value):
        return value + 3

    def add_four(value):
        return value + 4

    assert Task.of(1) \
        .map(add_one) \
        .fork(None, lambda x: x) == 2

    assert Task.of(2) \
        .map(add_two) \
        .map(add_three) \
        .fork(None, lambda x: x) == 7

    assert Task.of(2) \
        .map(add_two) \
        .map(add_three) \
        .map(add_four) \
        .fork(None, lambda x: x) == 9


# Generated at 2022-06-24 00:37:38.173186
# Unit test for constructor of class Task
def test_Task():
    """
    Check work of constructor of class Task
    """
    promise_of_2 = Task(lambda reject, resolve: resolve(2))

    assert isinstance(promise_of_2.fork, FunctionType)

    assert promise_of_2.fork(lambda _: None, lambda arg: arg) == 2

    is_rejected = False
    promise_of_2.fork(lambda _: is_rejected.__setattr__('value', True), lambda _: None)
    assert is_rejected.value

    promise_of_2.fork(lambda _: None, lambda _: None)


# Generated at 2022-06-24 00:37:43.514653
# Unit test for method bind of class Task
def test_Task_bind():
    def functionA(value):
        """
        FunctionA (:param value) -> Task[reject, value + a]

        :param value: value to process
        :type value: int
        :returns: new Task
        :rtype: Task[reject, value + a]
        """
        return Task(lambda reject, resolve: resolve(value + 10))

    def functionB(value):
        """
        FunctionB (:param value) -> Task[reject, value + b]

        :param value: value to process
        :type value: int
        :returns: new Task
        :rtype: Task[reject, value + b]
        """
        return Task(lambda reject, resolve: resolve(value + 100))


# Generated at 2022-06-24 00:37:52.690417
# Unit test for method bind of class Task
def test_Task_bind():
    def long_computations(value):
        time.sleep(5)
        return value

    def long_computations_task(value):
        return Task.of(value).map(long_computations)

    def sum_number(number):
        def result(value):
            return value + number
        return result


# Generated at 2022-06-24 00:37:59.013069
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor Task(fork)
    """
    def fork(reject, resolve):
        resolve(1)
        return 1

    task = Task(fork)

    assert hasattr(task, 'fork')


# Generated at 2022-06-24 00:38:04.914897
# Unit test for method map of class Task
def test_Task_map():

    add_one = lambda arg: arg + 1

    task = Task.of(1)
    assert task.fork(lambda a: a, lambda a: a) == 1

    assert task.map(add_one).fork(lambda a: a, lambda a: a) == 2
    assert task.map(add_one).map(add_one).fork(lambda a: a, lambda a: a) == 3
    assert task.map(lambda a: a + a).map(add_one).map(add_one).fork(lambda a: a, lambda a: a) == 5

    assert task.map(lambda a: a * a).map(add_one).map(add_one).fork(lambda a: a, lambda a: a) == 4


# Generated at 2022-06-24 00:38:13.382126
# Unit test for method bind of class Task
def test_Task_bind():
    """
    test method bind of Task
    """
    def square(n):
        if not isinstance(n, int):
            raise TypeError
        if n < 0:
            raise ValueError
        return n ** 2

    def sqrt(n):
        if not isinstance(n, int):
            raise TypeError
        if n < 0:
            raise ValueError
        return math.sqrt(n)

    def cube(n):
        if not isinstance(n, int):
            raise TypeError
        if n < 0:
            raise ValueError
        return n ** 3

    task_square_root_of_4 = Task.of(4).bind(task_square_root)

# Generated at 2022-06-24 00:38:21.064254
# Unit test for method bind of class Task
def test_Task_bind():
    def method_fork(reject, resolve):
        return resolve('test')

    def method_fork___(reject, resolve):
        return reject('test')

    def mapper(x):
        def task(reject, resolve):
            return resolve(x + x)

        return Task(task)

    def mapper___(x):
        def task(reject, resolve):
            return reject(x + x)

        return Task(task)

    assert Task(method_fork).bind(mapper).fork(
        lambda value: value + '_error',
        lambda value: value + '_mapped'
    ) == 'test_mapped'

    assert Task(method_fork___).bind(mapper).fork(
        lambda value: value + '_error',
        lambda value: value + '_mapped'
    )

# Generated at 2022-06-24 00:38:30.985029
# Unit test for method map of class Task
def test_Task_map():
    def mock_reject(_):
        nonlocal reject
        reject += 1

    def mock_resolve(value):
        nonlocal resolve
        resolve += 1
        return value

    def mock_fork_resolve_error(reject, resolve):
        reject('Very problems')

    def mock_fork_resolve_value(reject, resolve):
        resolve(100500)

    def mock_mapper_error(arg):
        raise TypeError(arg)

    def mock_mapper_value(arg):
        return arg / 2

    # reject = before fork + reject in fork
    # reject = 1 + 1
    reject = 0
    # resolve = before fork + resolve in fork + resolve in map
    # resolve = 1 + 1 + 1
    resolve = 0
    task = Task(mock_fork_resolve_error)


# Generated at 2022-06-24 00:38:32.238727
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, __: None)


# Generated at 2022-06-24 00:38:36.774719
# Unit test for method map of class Task
def test_Task_map():
    def request(arg, resolve):
        resolve(arg+1)

    def failed(arg, reject):
        reject('Reject')

    task = Task(request)
    assert task.map(lambda arg: arg*2).fork(lambda reject: None, lambda arg: arg) == 2

    failed_task = Task(failed)
    assert failed_task.map(lambda arg: arg*2).fork(lambda reject: reject, lambda arg: arg) == 'Reject'


# Generated at 2022-06-24 00:38:41.909633
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1) \
        .bind(lambda x: Task.of(x + 1)) \
        .bind(lambda x: Task.of(x + 1))

    def fork(reject, resolve):
        return task.fork(reject, resolve)

    assert fork(str, str) == '3'


# Generated at 2022-06-24 00:38:44.867948
# Unit test for method bind of class Task
def test_Task_bind():
    task_of_1 = Task.of(1)
    task_of_2 = task_of_1.bind(
        lambda x: Task.of(x + 1)
    )

    def test_of_2(resolve, reject):
        assert resolve(2) == 2

    task_of_2.fork(
        lambda arg: print("rejected 'task of 2' with arg: ", arg) ,
        test_of_2
    )

# Generated at 2022-06-24 00:38:48.018505
# Unit test for constructor of class Task
def test_Task():
    fork = lambda _, resolve: resolve('value')
    task = Task(fork)

    assert task.fork(reject=None, resolve=None) == 'value'


# Generated at 2022-06-24 00:38:51.638717
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    assert Task.of(1).map(add_one).fork(lambda x: x, lambda x: x) == 2



# Generated at 2022-06-24 00:38:59.596020
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(x):
        return Task.of(x + 1)

    def add_two(x):
        return Task.reject(x + 2)

    def test_add_one():
        task = Task.reject(1).bind(add_one)
        assert task.fork(lambda _: True, lambda _: False)

    def test_add_two():
        task = Task.of(1).bind(add_two)
        assert task.fork(lambda _: True, lambda _: False)

    test_add_one()
    test_add_two()

# Generated at 2022-06-24 00:39:04.278968
# Unit test for constructor of class Task
def test_Task():
    def assert_Task(task, value):
        result = task.fork(lambda a: a, lambda b: b)
        assert result == value

    assert_Task(Task.of(10), 10)


# Generated at 2022-06-24 00:39:09.617192
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x * 2

    assert Task(lambda _, resolve: resolve(1)).map(fn).fork(
        lambda _: False,
        lambda x: x == 2
    )



# Generated at 2022-06-24 00:39:13.697117
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    assert Task.of(1).map(mapper).fork(lambda _: None, lambda value: value) == 2



# Generated at 2022-06-24 00:39:17.463393
# Unit test for method map of class Task
def test_Task_map():
    @task
    def example(reject, resolve):
        return resolve(1)

    assert example.map(lambda arg: arg + 1).fork(None, lambda c: c) == 2



# Generated at 2022-06-24 00:39:21.834046
# Unit test for method map of class Task
def test_Task_map():
    value = 3
    task = Task.of(value)
    expected = value * 3

    actual = task.map(lambda x: x * 3).fork(lambda x: None, lambda x: x)

    assert expected == actual



# Generated at 2022-06-24 00:39:27.945830
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        if value == 0:
            return Task.reject('zero')
        return Task.of(value * 10)

    assert Task.of(2).bind(mapper).fork(
        lambda err: err,
        lambda value: value
    ) == 20

    assert Task.of(0).bind(mapper).fork(
        lambda err: err,
        lambda value: value
    ) == 'zero'



# Generated at 2022-06-24 00:39:30.291560
# Unit test for method map of class Task
def test_Task_map():
    def add1(value):
        return value + 1

    def promise_add1(resolve):
        resolve(add1(1))

    task = Task.of(1)
    mapped_task = task.map(add1)
    result = mapped_task.fork(lambda _: '', lambda arg: arg)
    assert result == 2


# Generated at 2022-06-24 00:39:35.773134
# Unit test for method map of class Task
def test_Task_map():
    # Mapper function
    fn = lambda value: value + 1

    # Create new Task of type Integer
    task = Task.of(1)
    # Map task value
    mapped_task = task.map(fn)
    # Fork mapped task, and receive result (yield)
    result, error = mapped_task.fork(reject=lambda unused: None, resolve=lambda value: value)
    # Assert that result is equal to fn(task.value)
    assert result == fn(1)


# Generated at 2022-06-24 00:39:42.537432
# Unit test for method bind of class Task
def test_Task_bind():
    def fn1(x):
        return Task.reject(-x)

    def fn2(x):
        return Task.reject(x)

    def fn3(x):
        return Task.of(x)
    assert Task.of(2).bind(fn1).fork(lambda a: a, lambda b: b) == -2
    assert Task.of(2).bind(fn2).fork(lambda a: a, lambda b: b) == 2
    assert Task.of(2).bind(fn3).fork(lambda a: a, lambda b: b) == 2

# Generated at 2022-06-24 00:39:45.854971
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve("test"))
    assert task.fork(lambda a: "Error", lambda a: a) == "test"

test_Task()



# Generated at 2022-06-24 00:39:48.369917
# Unit test for constructor of class Task
def test_Task():
    """Test constructor of class Task"""
    def result(reject, resolve):
        """Result for testing"""
        return resolve('value')

    instance = Task(result)

    assert callable(instance.fork)
    assert instance.fork(lambda arg: arg, lambda arg: arg) == 'value'


# Generated at 2022-06-24 00:39:49.876943
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(2)).fork == (lambda _, resolve: resolve(2))


# Generated at 2022-06-24 00:39:56.559554
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for map method of Task class.

    :return: None
    :rtype: None
    """
    assert Task.of(3).map(lambda x: x * 3).fork(lambda x: x, lambda x: x) == 9
    assert Task.of(3).map(lambda _: None).fork(lambda x: x, lambda x: x) is None



# Generated at 2022-06-24 00:39:58.805510
# Unit test for constructor of class Task
def test_Task():
    """
    Testing constructor of class Task
    """
    assert Task(lambda _, resolve: resolve(0)) == Task.of(0)


# Generated at 2022-06-24 00:40:07.971774
# Unit test for method bind of class Task
def test_Task_bind():
    def func(arg):
        return arg + 1
    def new_func(arg):
        return Task.reject(arg - 2)
    def second_func(arg):
        return Task.reject(arg)

    assert Task(
        lambda reject, resolve: resolve(2)
    ).bind(
        lambda arg: Task.reject(arg)
    ).fork(
        lambda value: True and value == 2,
        lambda value: False and value
    )

    assert Task(
        lambda reject, resolve: resolve(2)
    ).bind(
        lambda arg: Task.of(arg)
    ).bind(
        lambda arg: Task.reject(arg - 1)
    ).fork(
        lambda value: True and value == 1,
        lambda value: False and value
    )


# Generated at 2022-06-24 00:40:12.724958
# Unit test for constructor of class Task
def test_Task():
    def fork_ok(reject, resolve):
        return resolve(42)

    def fork_err(reject, resolve):
        return reject(42)

    task = Task(fork_err)
    assert task.fork(lambda err: err, lambda ok: ok) == 42
    assert task.fork(lambda err: err + 1, lambda ok: ok) == 43

    task = Task(fork_ok)
    assert task.fork(lambda err: err, lambda ok: ok) == 42
    assert task.fork(lambda err: err + 1, lambda ok: ok) == 42


# Generated at 2022-06-24 00:40:17.688763
# Unit test for method map of class Task
def test_Task_map():
    """
    Test function for method map of class Task
    """
    test_values = [1, 1.0, True, [1, 2, 3], {}]
    for value in test_values:
        task = Task.of(value)
        task_mapped = task.map(lambda arg: arg)
        assert task_mapped.fork(lambda arg: arg, lambda arg: arg) == value


# Generated at 2022-06-24 00:40:19.611355
# Unit test for constructor of class Task
def test_Task():
    """Test that Task constructor works properly without any arguments."""
    task = Task(lambda _, __: None)
    assert True


# Generated at 2022-06-24 00:40:23.370827
# Unit test for constructor of class Task
def test_Task():
    import types
    assert isinstance(Task(lambda: None), Task)
    assert isinstance(Task.of(None), Task)
    assert isinstance(Task.reject(None), Task)
    assert Task.of(42).fork(lambda: None, lambda: None) is None
    assert Task.reject(42).fork(lambda: None, lambda: None) is None


# Generated at 2022-06-24 00:40:28.146870
# Unit test for constructor of class Task
def test_Task():
    def fork_true(reject, resolve):
        assert True

    def fork_false(reject, resolve):
        assert False

    good = Task(fork_true)
    bad = Task(fork_false)


# Generated at 2022-06-24 00:40:34.496207
# Unit test for constructor of class Task
def test_Task():
    def test(reject, resolve):
        resolve(1)

    task = Task(test)


# Generated at 2022-06-24 00:40:44.220242
# Unit test for constructor of class Task

# Generated at 2022-06-24 00:40:47.661648
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    nested_task = task.map(lambda a: Task.of(a + 1))

    assert isinstance(nested_task, Task)
    assert nested_task.fork(lambda _: 0, lambda v: v) == 2


# Generated at 2022-06-24 00:40:55.993799
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind return Task with resolve function that recieve first Task result and
    return result of second one. If first one is rejected than second one not be call.

    :returns:
    :rtype: None
    """
    def resolve(value, expected_value):
        if value != expected_value:
            raise AssertionError("First Task return wrong value.")

    def reject(value, expected_value, message=""):
        if value != expected_value:
            raise AssertionError("Second Task return wrong value: " + message)

    # 1. Test rejected Task must be rejected
    Task.of(True).bind(lambda _: Task.reject(False)).fork(
        lambda value: reject(value, False, "without calling second Task"),
        lambda _: resolve(True, True)
    )

    # 2.

# Generated at 2022-06-24 00:41:02.509781
# Unit test for method bind of class Task
def test_Task_bind():
    # Call mock function with mock argument
    task = Task.of(3)
    task = task.bind(lambda arg: Task.of(arg * 2))

    # Function to handle error
    def reject(arg):
        raise Exception("Error")

    # Function to handle result
    def resolve(arg):
        assert arg == 6
        print("success")

    task.fork(reject, resolve)


# Generated at 2022-06-24 00:41:06.133883
# Unit test for method map of class Task
def test_Task_map():
    """
    Assert that Task.map return Task with mapped resolve attribute.
    """
    def mapper(arg):
        return arg ** 2

    task = Task.of(12).map(mapper)
    assert task.fork(lambda x: x, None) == 144

# Generated at 2022-06-24 00:41:09.250155
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value * 2)

    task = Task.of(1)

# Generated at 2022-06-24 00:41:17.539011
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(3) \
        .bind(lambda val: Task.of(val * 5)) \
        .bind(lambda val: Task.reject(val - 1)) \
        .bind(lambda val: Task.of(val)) \

    resolved_value = result \
        .fork(lambda val: val, lambda val: val)

    if resolved_value == 15:
        return 1
    else:
        return 0

print("Test Task: {}".format(test_Task_bind()))


# Generated at 2022-06-24 00:41:20.474642
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: 'Test')
    assert task.fork(lambda _: '', lambda _: '') == 'Test'


# Generated at 2022-06-24 00:41:25.639084
# Unit test for method bind of class Task
def test_Task_bind():
    def test_map(resolve, reject):
        a = Task.of(5)
        f = lambda x: a.map(lambda y: x + y)
        f(10).fork(reject, resolve)

    assert run_test(test_map) == (15, None)


# Generated at 2022-06-24 00:41:27.512860
# Unit test for method bind of class Task
def test_Task_bind():
    def r(x):
        return Task.reject(x)

    def f(x):
        return x + 1

    r(1).bind(f)
    done()


# Generated at 2022-06-24 00:41:28.313439
# Unit test for method map of class Task
def test_Task_map():
    assert False


# Generated at 2022-06-24 00:41:31.811304
# Unit test for method map of class Task
def test_Task_map():
    identity = lambda a: a

    first_task = Task.of(Task.of(1))
    second_task = Task.of(Task.of(2))

    tasks = [first_task, second_task]
    results = [first_task.map(identity), second_task.map(identity)]

    for index, task in enumerate(tasks):
        task.fork(
            lambda arg: print(f"Rejected {arg} with {results[index]}"),
            lambda arg: print(f"Resolved {arg}")
        )


# Generated at 2022-06-24 00:41:38.515387
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task constructor.
    """
    assert Task.of(10) == Task(lambda _, resolve: resolve(10))
    assert Task.reject(10) == Task(lambda reject, _: reject(10))
    assert Task.reject('error') == Task(lambda reject, _: reject('error'))
    assert Task.of('success') == Task(lambda _, resolve: resolve('success'))
