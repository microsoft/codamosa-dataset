

# Generated at 2022-06-24 00:31:42.494096
# Unit test for method map of class Task
def test_Task_map():
    print('test map of Task')
    # Task.of(value).map(mapper) == Task.of(mapper(value))

    # Task.of(value) == Task.of(value).map(lambda x: x)
    assert Task.of(10).map(lambda x: x) == Task.of(10)


# Generated at 2022-06-24 00:31:50.117665
# Unit test for method bind of class Task
def test_Task_bind():
    def reject(value):
        return value * 2

    def resolve(value):
        return value + 2

    def bind(value):
        return Task.of(value * 10)

    # test reject
    assert Task(lambda reject, _: reject('foo')).bind(bind).fork(reject, resolve) == 'foo' * 2
    # test resolve
    assert Task(lambda _, resolve: resolve('foo')).bind(bind).fork(reject, resolve) == 'foo' * 10 + 2



# Generated at 2022-06-24 00:31:56.271829
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value + 1)

    task = Task.of(5)

    assert task.bind(mapper).fork(lambda _: 0, lambda x: x) == 6
    assert task.bind(mapper).fork(lambda x: x, lambda _: 0) == 5
    assert Task.reject(5).bind(mapper).fork(lambda x: x, lambda _: 0) == 5


# Generated at 2022-06-24 00:31:59.050284
# Unit test for constructor of class Task
def test_Task():
    def task(reject, resolve):
        resolve(1)

    value = Task(task).fork(lambda x: x, lambda x: x)
    assert value == 1



# Generated at 2022-06-24 00:32:05.265436
# Unit test for constructor of class Task
def test_Task():
    task = Task.of(1)
    assert task.fork(lambda *_: None, lambda arg: arg) == 1

    task = Task.reject(1)
    assert task.fork(lambda arg: arg, lambda *_: None) == 1

    task = Task(lambda reject, resolve: resolve(1))
    assert task.fork(lambda *_: None, lambda arg: arg) == 1

    task = Task(lambda reject, resolve: reject(1))
    assert task.fork(lambda arg: arg, lambda *_: None) == 1


# Generated at 2022-06-24 00:32:15.936875
# Unit test for method bind of class Task
def test_Task_bind():
    mock_reject = Mock()
    mock_resolve = Mock()
    pass_assert_equal = Mock()

    task = Task(lambda reject, resolve: reject(1))
    result = task.bind(lambda value: Task(lambda reject, resolve: resolve(2)))
    result.fork(mock_reject, mock_resolve)

    # Check Control flow
    assert mock_reject.call_count == 1
    assert mock_resolve.call_count == 0
    # Check input
    assert mock_reject.call_args_list == [call(1)]

    task = Task(lambda reject, resolve: resolve(1))
    result = task.bind(lambda value: Task(lambda reject, resolve: resolve(2)))
    result.fork(mock_reject, mock_resolve)

    # Check Control flow
   

# Generated at 2022-06-24 00:32:26.512238
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task
    """
    # get value from resolved task
    task = Task.of(None).bind(lambda _: Task.of(54))
    assert task.fork(lambda err: -1, lambda v: v) == 54

    # get value from task with task
    task = Task.of(None).bind(lambda _: Task.of(None).bind(lambda _: Task.of(54)))
    assert task.fork(lambda err: -1, lambda v: v) == 54

    # get value from rejected task
    task = Task.reject(None).bind(lambda _: Task.of(54))
    assert task.fork(lambda err: -1, lambda _: 0) == -1

    # get error from task

# Generated at 2022-06-24 00:32:33.645783
# Unit test for method bind of class Task
def test_Task_bind():

    def f(x):
        if x == 1:
            return Task.of('one')
        else:
            return Task.reject('more than one')


# Generated at 2022-06-24 00:32:35.603572
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value + 1

    assert Task(lambda _, resolve: resolve(3)).map(mapper).fork(None, lambda r: r) == 4



# Generated at 2022-06-24 00:32:40.830514
# Unit test for method bind of class Task
def test_Task_bind():
    a = Task.of(1)
    def fn(value):
        assert value == 1
        return Task.of(2)
    b = a.bind(fn)

    def called(resolve, reject):
        resolve(3)

    def failed(error):
        assert error == 2

    assert b.fork(failed, called) == 3


# Generated at 2022-06-24 00:32:50.786157
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for method bind of class Task
    """

    def get_mapping_function(value):
        def mapping_function(arg):
            assert value == arg
            return Task.of(arg + "_mapped")
        return mapping_function

    def test_fork(reject_value, resolve_value):
        assert reject_value == "reject_value"
        assert resolve_value == "value_mapped"
        return "test_fork_done"

    task = Task.of("value")
    task = task.bind(get_mapping_function("value"))

    assert test_fork == task.fork(reject_value="reject_value", resolve_value="resolve_value")

# Test method bind and map of class Task

# Generated at 2022-06-24 00:33:00.022887
# Unit test for constructor of class Task
def test_Task():
    def assert_TypeError(func, *args, **kwargs):
        try:
            func(*args, **kwargs)
        except TypeError:
            return True
        raise Exception("Function doesn't raise TypeError")

    assert isinstance(Task(lambda _, _: None), Task)
    assert not isinstance(None, Task)
    assert not isinstance([], Task)
    assert not isinstance({}, Task)
    assert not isinstance(1, Task)
    assert not isinstance("", Task)
    assert not isinstance(b'', Task)
    assert_TypeError(Task, 'False')
    assert_TypeError(Task, object, object)


# Unit tests for constructor of class Task for of method

# Generated at 2022-06-24 00:33:04.049962
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(3)

    def mapper(number):
        return number + 1

    task = Task(fork)
    result = task.map(mapper)
    assert result.fork(lambda err: err, lambda res: res) == 4

# Generated at 2022-06-24 00:33:07.790304
# Unit test for method map of class Task
def test_Task_map():
    def add_one(arg):
        return arg + 1

    def test_fork(reject, resolve):
        return resolve(10)

    task = Task(test_fork)
    task_a = task.map(add_one)
    assert task_a.fork(None, lambda arg: arg) == 11



# Generated at 2022-06-24 00:33:14.755540
# Unit test for method bind of class Task
def test_Task_bind():
    def id(x):
        return Task.of(x)

    def f(x):
        return Task.of(x + 1)

    def g(x):
        return Task.of(x + 2)

    def error(x):
        return Task.reject(x + 1)

    result = Task.of(1)

    assert result.bind(id).bind(f).bind(g).fork(lambda arg: arg, lambda arg: arg) == 4
    assert result.bind(id).bind(f).bind(error).bind(g).fork(lambda arg: arg, lambda arg: arg) == 2
    assert result.bind(f).bind(error).bind(g).fork(lambda arg: arg, lambda arg: arg) == 2

# Generated at 2022-06-24 00:33:17.817442
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve('value')

    task = Task(fork)
    assert task.fork(lambda _: True, lambda arg: arg) == 'value'


# Generated at 2022-06-24 00:33:21.749429
# Unit test for constructor of class Task
def test_Task():
    """
    :param fork: function to call during fork
    :type fork: Function(reject, resolve) -> Any
    """
    def task_fork(reject, resolve):
        return resolve("test")

    task = Task(task_fork)
    assert task.fork(reject=None, resolve=None) == "test"


# Generated at 2022-06-24 00:33:24.628664
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, b: b(1))
    assert task.fork(lambda a: a, lambda b: b) == 1

    task = Task(lambda a, _: a(1))
    assert task.fork(lambda a: a, lambda b: b) == 1



# Generated at 2022-06-24 00:33:33.408516
# Unit test for method bind of class Task
def test_Task_bind():
    def get_Task(value):
        def fork(reject, resolve):
            resolve(value)

        return Task(fork)

    def async_mapper(value):
        def fork(reject, resolve):
            set_timeout(lambda: resolve(value + 1), 1000)
        return Task(fork)

    def result(resolve, reject):
        get_Task(1).bind(async_mapper).fork(reject, resolve)

    def assertion(value):
        assert value == 2
        return value

    got = Task(result).map(assertion).fork(identity, identity)
    assert got == 2



# Generated at 2022-06-24 00:33:37.986706
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve("apple")

    def f(value):
        return "banana"

    task_apple = Task(fork)
    task_banana = task_apple.map(f)

    assert task_banana.fork(lambda _: "rejected!", lambda value: value) == "banana"


# Generated at 2022-06-24 00:33:40.551824
# Unit test for method map of class Task
def test_Task_map():
    def multiply(a):
        return a*2

    assert Task(
        lambda _, resolve: resolve(1)
    ).map(multiply).fork(None, lambda a: a) == 2


# Generated at 2022-06-24 00:33:46.190211
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test method bind of class Task.
    """

    assert Task.of(10).bind(lambda x: Task.of(x + 10)).fork(
        lambda x: None,
        lambda x: x
    ) == 20

    assert Task.of("Some text").bind(lambda x: Task.of(len(x))).fork(
        lambda x: None,
        lambda x: x
    ) == 9


# Generated at 2022-06-24 00:33:47.819481
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve(1))

    assert task.fork(
        lambda arg: arg + 1,
        lambda arg: arg + 1
    ) == 2


# Generated at 2022-06-24 00:33:48.839619
# Unit test for constructor of class Task
def test_Task():
    task = Task.of(1)
    assert isinstance(task, Task)


# Generated at 2022-06-24 00:33:56.452808
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda x: x).fork(lambda x: x, lambda x: x) == None
    assert Task(lambda x: x).fork(lambda x: -x, lambda x: -x) == None
    assert Task(lambda x, y: x).fork(1, 2) == None
    assert Task(lambda x, y: y).fork(1, 2) == None
    assert Task(lambda x, y: x + y).fork(1, 2) == None
    assert Task(lambda x, y: x * y).fork(3, 4) == None


# Generated at 2022-06-24 00:34:04.525395
# Unit test for method bind of class Task
def test_Task_bind():
    def test_reject_mapper(arg):
        return Task.reject(arg)

    def test_resolve_mapper(arg):
        return Task.of(arg)

    def test_fork(reject, resolve):
        resolve('test string')

    task = Task(test_fork)
    assert isinstance(task.bind(test_resolve_mapper), Task)
    assert task.bind(test_reject_mapper).fork('reject', 'resolve') == 'reject'
    assert task.bind(test_resolve_mapper).fork('reject', 'resolve') == 'resolve'

# Generated at 2022-06-24 00:34:05.951503
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(0).fork(None, lambda x: x) == 0


# Generated at 2022-06-24 00:34:17.252602
# Unit test for method bind of class Task
def test_Task_bind():
    def resolved_method(resolve):
        return resolve(10)

    def rejected_method(reject):
        return reject("Error")

    def resolved_method2(value):
        return Task.of(value+2)

    def rejected_method2(value):
        return Task.of(value+2)

    assert Task(resolved_method).bind(resolved_method2).fork(lambda arg: None, lambda arg: arg) == 12, "resolved-resolved"
    assert Task(rejected_method).bind(resolved_method2).fork(lambda arg: arg, lambda arg: None) == "Error", "rejected-resolved"
    assert Task(resolved_method).bind(rejected_method2).fork(lambda arg: arg, lambda arg: None) == None, "resolved-rejected"

# Generated at 2022-06-24 00:34:21.035904
# Unit test for method map of class Task
def test_Task_map():
    """
    Should return new Task with num value which mapped
    by fn: lambda x: x + 1.
    """
    num = 0
    task = Task.of(num)
    new_task = task.map(lambda x: x + 1)
    assert new_task.fork(None, lambda x: x) == num + 1



# Generated at 2022-06-24 00:34:30.961461
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Method bind of class Task takes function which return Task and return new Task
    which fork function is based on fork function of previous Task and
    fork function of task returned by stored function.
    """
    def fork_function(reject, resolve):
        resolve(5)

    def get_Task_with_fork_function(resolve):
        resolve(5)

    def mult_by_five(resolve):
        Task.of(5).fork(lambda _: None, resolve)

    test = Task(fork_function).bind(mult_by_five)

# Generated at 2022-06-24 00:34:33.622861
# Unit test for method map of class Task
def test_Task_map():
    def add_two(arg):
        return arg + 2

    task = Task.of(3)
    result = task.map(add_two)

    assert result.fork(lambda x: x, lambda x: x) == 5


# Generated at 2022-06-24 00:34:38.193765
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Should return new Task with mapped resolve attribute,
    should not return original value.
    """
    assert Task.of(5).bind(lambda value: Task.of(value + 1)).fork(None, None) == 6
    assert Task.of(5).bind(lambda value: Task.of(value + 1)).fork(None, None) != 5


# Generated at 2022-06-24 00:34:42.834463
# Unit test for constructor of class Task
def test_Task():
    assert Task.reject(1).fork(
        lambda value: assert_(1, value),
        lambda _: assert_(True, False)
    )

    assert Task.of(1).fork(
        lambda _: assert_(True, False),
        lambda value: assert_(1, value)
    )


# Generated at 2022-06-24 00:34:48.445370
# Unit test for method bind of class Task
def test_Task_bind():
    def test_fn(x):
        if x % 2 == 0:
            return Task.reject(ValueError(x))
        return Task.of(x)

    assert Task.of(3).map(test_fn).fork(lambda x: x, lambda y: y) == ValueError(3)
    assert Task.of(2).map(test_fn).fork(lambda x: x, lambda y: y) == ValueError(2)



# Generated at 2022-06-24 00:34:55.456893
# Unit test for constructor of class Task
def test_Task():
    """
    Test creation and using of tasks.
    """

    # Building Task and handle reject
    def hello_world(reject, resolve):
        resolve('hello world')

    task = Task(hello_world)
    assert task.fork(lambda _: 'rejected', lambda value: value) == 'hello world'

    # Building Task and handle resolve
    def rejector(reject, resolve):
        reject('with love')

    task = Task(rejector)
    assert task.fork(lambda value: value, lambda _: 'resolved') == 'with love'

    # Transform Task
    def double(value):
        return value * 2

    task = Task.of(2)
    assert task.map(double).fork(lambda _: 'reject', lambda value: value) == 4

    # Bind Task

# Generated at 2022-06-24 00:35:00.595114
# Unit test for method bind of class Task
def test_Task_bind():

    def return_after_1s(result):
        return Task(
            lambda reject, resolve:
                setTimeout(
                    lambda: resolve(result),
                    1000
                )
        )

    Task.of(1) \
        .map(lambda x: x + 1) \
        .bind(return_after_1s) \
        .map(print) \
        .fork(print, print)


# Generated at 2022-06-24 00:35:04.347012
# Unit test for method map of class Task
def test_Task_map():
    def test_result(value):
        return Task.of(value).map(lambda x: x + 1)

    assert test_result(5).fork(None, lambda result: result) == 6
    assert test_result(5).fork(None, lambda result: result) == 6


# Generated at 2022-06-24 00:35:06.950633
# Unit test for constructor of class Task
def test_Task():
    value = 'some'
    task = Task(lambda _, resolve: resolve(value))
    assert task.fork(None, None) == value


# Generated at 2022-06-24 00:35:12.228029
# Unit test for method bind of class Task
def test_Task_bind():
    t1 = Task(lambda reject, resolve: resolve(2))
    t2 = t1.bind(lambda x: Task.of(x * 2))
    t3 = t2.bind(lambda x: Task.reject(x * 4))
    def test(resolve, reject):
        return t3.fork(reject, resolve)
    assert IOLazy.run(IOLazy.of(test)) == 8


# Generated at 2022-06-24 00:35:13.761470
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(5).bind(lambda a: Task.of(a + 1)).fork(lambda a: a, lambda a: a) == 6


# Generated at 2022-06-24 00:35:18.286726
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve('test'))
    assert callable(task.fork)


# Generated at 2022-06-24 00:35:21.998843
# Unit test for method bind of class Task
def test_Task_bind():
    def fx(x):
        return Task.of(x * 2)

    task_a = Task.of(2)
    task_a_bind = task_a.bind(fx)

    def fork_task_a(resolve, reject):
        resolve(11)

    task_a.fork = fork_task_a

    result = task_a_bind.fork(
        lambda arg: "reject",
        lambda arg: arg
    )

    assert result == 22


# Generated at 2022-06-24 00:35:27.930196
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        return Task.of(x ** 2)

    def g(x):
        return Task.of(x + 1)

    def h(x):
        return Task.reject(x + 1)

    a = Task(lambda _, resolve: resolve(1))
    b = a.bind(f).bind(g)
    c = a.bind(h).bind(g)

    assert b.fork(lambda x: x, lambda x: x) == 4
    assert c.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-24 00:35:34.444718
# Unit test for constructor of class Task
def test_Task():

    resolved_value = 'Value'
    rejected_value = 'Error'

    def fork(reject, resolve):
        resolve(resolved_value)
        reject(rejected_value)

    task = Task(fork)

    @task
    def _(reject, resolve):
        assert resolved_value == resolve
        assert rejected_value == reject

    task = Task.of(resolved_value)

    @task
    def _(reject, resolve):
        assert resolved_value == resolve

    task = Task.reject(rejected_value)

    @task
    def _(reject, resolve):
        assert rejected_value == reject


# Generated at 2022-06-24 00:35:36.668503
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(2))
    assert type(task) == Task


# Generated at 2022-06-24 00:35:42.925329
# Unit test for method map of class Task
def test_Task_map():
    def add_request_prefix(value):
        return "request_result_" + value

    def add_response_prefix(value):
        return "response_result_" + value

    def add_response_prefix_2(value):
        return "response_result_2_" + value

    def add_error_prefix(value):
        return "error_result_" + value

    result = Task.of('test_string').map(None)
    assert result.fork(None, None) == 'test_string'

    result = Task.of('test_string').map(add_request_prefix)
    assert result.fork(None, None) == 'request_result_test_string'

    result = Task.reject('test_string').map(add_error_prefix)

# Generated at 2022-06-24 00:35:47.134894
# Unit test for method bind of class Task
def test_Task_bind():
    def test(x):
        return Task.of('a' + x)

    task = Task.of('b').bind(test)

    assert isinstance(task, Task)

    assert 'ab' == task.fork(
        lambda x: x,
        lambda x: x
    )


# Generated at 2022-06-24 00:35:51.369246
# Unit test for constructor of class Task

# Generated at 2022-06-24 00:35:54.611106
# Unit test for method bind of class Task
def test_Task_bind():
    """unit test for Task class"""

# Generated at 2022-06-24 00:36:01.274984
# Unit test for method map of class Task
def test_Task_map():
    """
    Testing Task.map calling with variables
    :returns: undefined
    """
    def dummy_function(value):
        return value * 2

    def dummy_function2(value):
        return value * 3

    def dummy_function3(value):
        if value % 3 == 0:
            return Task.reject(value)
        return Task.of(value)

    result = Task.of(4).map(dummy_function)
    assert result.fork(lambda err: err, lambda res: res) == 8

    result = Task.of(4).map(dummy_function).map(dummy_function2)
    assert result.fork(lambda err: err, lambda res: res) == 24

    result = Task.reject(4).map(dummy_function).map(dummy_function2)

# Generated at 2022-06-24 00:36:11.874522
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Take Task.of with value 1, and pass it to Task.bind with add2 mapper,
    which add 2 to passed value.
    """
    def add2(value):
        return Task.of(value + 2)

    r = Task.of(1).bind(add2).fork(None, identity)
    assert r == 3

    """
    Take Task.of with value 1, and pass it to Task.bind with add2 mapper,
    which add 2 to passed value and then to Task.bind(add3) mapper, which add 3 to passed value.
    """
    def add3(value):
        return Task.of(value + 3)

    r = Task.of(1).bind(add2).bind(add3).fork(None, identity)
    assert r == 6

test_Task_bind()

# Generated at 2022-06-24 00:36:17.491306
# Unit test for method map of class Task
def test_Task_map():
    def get_loud_text(text):
        """
        Make text loud.

        :param text: for processing
        :type text: str
        :returns: loud text
        :rtype: str
        """
        return text.upper()

    task1 = Task.of("ABC")
    task2 = task1.map(get_loud_text)
    result = task2.fork(lambda x: x, lambda x: x)
    expected = "ABC"
    assert result == expected, "Expected %s but got %s" % (expected, result)


# Generated at 2022-06-24 00:36:25.135387
# Unit test for constructor of class Task
def test_Task():
    # Empty constructor is not allowed.
    def constructor_no_arguments():
        Task()
    test.expect_error(constructor_no_arguments)

    # Class without arguments are not allowed
    def constructor_not_callable():
        Task({})
    test.expect_error(constructor_not_callable)

    # Valid arg is function.
    def constructor_callable():
        Task(lambda: None)
    test.expect_no_error(constructor_callable)


# Generated at 2022-06-24 00:36:34.125257
# Unit test for method bind of class Task
def test_Task_bind():
    """
    >>> task = Task.of(1)
    >>> def add_one(x):
    ...     return x + 1
    >>> def double(x):
    ...     return x * 2
    >>> bind_result = task.bind(
    ...     lambda x: Task(
    ...         lambda reject, resolve: resolve(add_one(x))
    ...     )
    ... ).bind(
    ...     lambda x: Task(
    ...         lambda reject, resolve: resolve(double(x))
    ...     )
    ... )
    >>> bind_result.fork(lambda arg: arg, lambda arg: arg)
    4
    """
    pass


# Generated at 2022-06-24 00:36:39.241938
# Unit test for method map of class Task
def test_Task_map():
    """
    func call two times with same argument (1) and
    return task that have resolved value with argument passed to fork (2).

    :returns: Task
    :rtype: Task[Function(reject, resolve) -> 2]
    """
    def func(v):
        return Task.of(v * 2)

    return Task.of(1).map(func)


# Generated at 2022-06-24 00:36:41.796703
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 1

    def task():
        return Task.of(5)

    assert task().map(add).fork(lambda x: x-1, lambda y: y+1) == 7



# Generated at 2022-06-24 00:36:48.317418
# Unit test for method map of class Task
def test_Task_map():
    def sum_two(x):
        return x+2

    assert Task.of(3).map(sum_two) == Task.of(5)
    assert Task.of(3).map(sum_two).fork(lambda x: print("Reject:" + str(x)), lambda x: print("Result:" + str(x))) == Task.of(5)
    assert Task.of("++").map(sum_two) != Task.of("++2")


# Generated at 2022-06-24 00:36:53.953406
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    assert Task.of(42).map(add_one).fork(lambda x: x, lambda x: x) == 43
    assert Task.of(42).map(add_one).map(add_one).fork(lambda x: x, lambda x: x) == 44
    assert Task.reject(42).map(add_one).fork(lambda x: x, lambda x: x) == 42


# Generated at 2022-06-24 00:37:02.476562
# Unit test for constructor of class Task
def test_Task():
    def test_fn_false(reject, resolve):
        resolve(False)

    def test_fn_true(reject, resolve):
        resolve(True)

    resolved_false = Task(test_fn_false)
    resolved_true = Task(test_fn_true)

    assert resolved_false.fork(
        lambda x: False,
        lambda x: True
    ) is False

    assert resolved_true.fork(
        lambda x: False,
        lambda x: True
    ) is True


# Generated at 2022-06-24 00:37:09.024035
# Unit test for method bind of class Task
def test_Task_bind():
    # result is Task which was rejected
    def test_function_reject(value):
        if value == 3:
            return Task.reject('error')

        return Task.of(value)

    # result is Task which was resolved
    def test_function_resolve(value):
        if value == 3:
            return Task.reject('error')

        return Task.of(value)

    task = Task.of(3)
    actual_result = task.bind(test_function_reject).fork(lambda reject: reject(reject), lambda resolve: resolve)
    expected_result = 'error'
    assert actual_result == expected_result

    task = Task.of(5)
    actual_result = task.bind(test_function_reject).fork(lambda reject: reject(reject), lambda resolve: resolve)
    expected

# Generated at 2022-06-24 00:37:13.903588
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task.
    """
    assert Task.of(5).fork == Task(lambda reject, resolve: resolve(5)).fork
    assert Task.reject('reject').fork == Task(lambda reject, resolve: reject('reject')).fork
    assert (
        Task(lambda reject, resolve: reject('reject')).fork ==
        Task(lambda reject, resolve: reject('reject')).fork
    )
    assert (
        Task(lambda reject, resolve: reject('reject')).fork !=
        Task(lambda reject, resolve: resolve('resolve')).fork
    )


# Generated at 2022-06-24 00:37:17.459865
# Unit test for method bind of class Task
def test_Task_bind():
    def task_of_1():
        return Task.of(1)

    # Task.bind(Task.of(1)).map(lambda x: x + 1)
    assert task_of_1().bind(lambda x: Task.of(x + 1)).fork(None, lambda x: x) == 2

    # Task.bind(Task.reject(1)).map(lambda x: x + 1)
    assert task_of_1().bind(lambda x: Task.reject(x + 1)).fork(lambda x: x, None) == 2


# Generated at 2022-06-24 00:37:21.816768
# Unit test for method map of class Task
def test_Task_map():
    def map_assert(resolve, reject):
        assert resolve(head)(0) == 0
        assert resolve(head)(3) == 1
        assert resolve(head)(4) == 1
        assert resolve(head)(8) == 2
        assert resolve(head)(10) == 3
        assert resolve(head)(20) == 4
        assert resolve(head)(40) == 5
        assert resolve(head)(42) == 6
        assert resolve(tail)(0) == 0
        assert resolve(tail)(3) == 3
        assert resolve(tail)(4) == 4
        assert resolve(tail)(8) == 8
        assert resolve(tail)(10) == 10
        assert resolve(tail)(20) == 20
        assert resolve(tail)(40) == 40
        assert resolve(tail)(42) == 42


# Generated at 2022-06-24 00:37:23.358525
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1) is not None
    assert Task.reject(1) is not None



# Generated at 2022-06-24 00:37:25.757429
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x + 2).fork(
        lambda x: 'error',
        lambda x: x
    ) == 4


# Generated at 2022-06-24 00:37:29.046049
# Unit test for constructor of class Task
def test_Task():
    """
    Test Task initialization
    """
    def task(reject, resolve):
        return resolve(1)

    t = Task(task)
    assert t.fork(lambda _: None, lambda value: value) == 1


# Generated at 2022-06-24 00:37:31.515255
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda i: Task.of(i + 1)).fork(lambda i: i, lambda i: i) == 2


# Generated at 2022-06-24 00:37:33.358826
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _, resolve: resolve('Foobar'))
    assert task.fork(_, resolve) == 'Foobar'


# Generated at 2022-06-24 00:37:37.706078
# Unit test for method bind of class Task
def test_Task_bind():
    # Create Task with resolve(1)
    task_1 = Task.of(1)
    # Create Task with Function(value) -> Task[resolve, 2 * value]
    task_2 = task_1.map(lambda number: Task.of(number * 2))
    # fork task_2 => resolve(2)
    assert task_2.fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-24 00:37:43.598902
# Unit test for method map of class Task
def test_Task_map():
    def callback(resolve, reject):
        return resolve(11)

    task = Task(callback)
    assert task.map(lambda arg: arg + 2).fork(lambda _: None, lambda arg: arg) == 13
    assert task.map(lambda arg: arg).fork(lambda _: None, lambda arg: arg) == 11


# Generated at 2022-06-24 00:37:49.319619
# Unit test for method bind of class Task
def test_Task_bind():
    def identity(value):
        return Task.of(value)

    def add1(value):
        return Task.of(value + 1)

    def add2(value):
        return Task.of(value + 2)

    task = Task.of(0) \
        .bind(add1) \
        .bind(add2)

    must(task.fork(None, lambda value: value == 3))

# Generated at 2022-06-24 00:37:53.789082
# Unit test for method map of class Task
def test_Task_map():
    def add(num):
        return num + 1

    task = Task.of(1).map(add)
    assert task.fork(lambda x: None, lambda x: x) == 2


# Generated at 2022-06-24 00:37:58.166626
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(5).map(lambda x: x * 2).fork(None, lambda x: x) == 10


# Generated at 2022-06-24 00:38:04.677093
# Unit test for method bind of class Task
def test_Task_bind():
    """

    """
    task = Task.of(5)

    def fn(value):
        return Task.of(value * 2)

    assert task.bind(fn).fork(
            lambda error: error,
            lambda result: result
        ) == 10

    def fn2(value):
        return Task.reject(value * 2)

    assert task.bind(fn2).fork(
            lambda error: error,
            lambda result: result
        ) == 10

    def fn3(value):
        return Task.reject(value * 2)

    assert Task.reject(4).bind(fn3).fork(
            lambda error: error,
            lambda result: result
        ) == 8

# Generated at 2022-06-24 00:38:12.380715
# Unit test for constructor of class Task
def test_Task():
    # reject function
    def reject(arg):
        return arg ** 2

    # map function
    def map(arg):
        return arg ** arg

    # resolve function
    def resolve(arg):
        return arg ** arg

    # fork task
    def fork(reject, resolve):
        return resolve(reject(map(arg=256)))

    # test for constructor of class Task.
    # Test is success if value of stored in Task value
    # is equal to value of stored in Task value after fork.
    assert Task(fork).fork(reject, resolve) == fork(reject, resolve)


# Generated at 2022-06-24 00:38:16.705318
# Unit test for method map of class Task
def test_Task_map():
    def f(x):
        return x

    assert Task.of(1).map(f).fork(lambda a: None, lambda b: b) == 1
    assert Task.reject(20).map(f).fork(lambda a: a, lambda b: None) == 20



# Generated at 2022-06-24 00:38:20.093885
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda x, y: x).fork(
        lambda x: x,
        lambda x: x
    ) == 'task_reject'
    assert Task(lambda x, y: y).fork(
        lambda x: x,
        lambda x: x
    ) == 'task_resolve'


# Generated at 2022-06-24 00:38:30.008429
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task constructor.
    """

    def task_reject(value):
        def fork(_, _2):
            return True
        return Task(fork)

    def task_resolve(value):
        def fork(_, resolve):
            return resolve(value)
        return Task(fork)

    assert Task(task_reject(True).fork).fork(lambda x: False, lambda x: True)
    assert Task(task_reject(True).fork).fork(True, False)
    assert Task(task_resolve(True).fork).fork(False, lambda x: x)
    assert Task(task_resolve(True).fork).fork(False, True)

    # assert Task(task_reject(False).fork) is None
    # assert Task(task_resolve(False).fork) is None



# Generated at 2022-06-24 00:38:34.005607
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value: str) -> Task[str, str]:
        return Task.of(f"mapped_{value}")


# Generated at 2022-06-24 00:38:38.821645
# Unit test for method map of class Task
def test_Task_map():
    def task_factory(resolve, reject):
        resolve(5)

    task = Task(task_factory)

    def mapper(value): return value * 2

    result = task.map(mapper)
    assert 10 == result.fork(lambda v: v, lambda v: v)


# Generated at 2022-06-24 00:38:42.579033
# Unit test for constructor of class Task
def test_Task():
    # Test case for function of
    assert Task(lambda _, res: res(1)).fork == Task.of(1).fork

    # Test case for function reject
    assert Task(lambda rej, _: rej(1)).fork == Task.reject(1).fork


# Generated at 2022-06-24 00:38:49.179343
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(5)

    mock_assert_success = Mock(side_effect=lambda value: True)
    mock_assert_error = Mock(side_effect=lambda _: False)

    task = Task(fork)
    task.map(lambda arg: arg * arg).fork(mock_assert_error, mock_assert_success)

    assert mock_assert_success.called
    assert not mock_assert_error.called


# Generated at 2022-06-24 00:38:53.242087
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    task = task.bind(lambda x: Task.of(x + 1))
    assert task.fork(lambda x: x, lambda x: x) is 2



# Generated at 2022-06-24 00:38:57.913681
# Unit test for method map of class Task
def test_Task_map():
    # Define mapper function
    fn = lambda x: x + 1

    # Define base task
    task = Task.of(2)

    # Apply to function to Task
    mapped_task = task.map(fn)

    # Check that task is resolved with value result of mapper
    assert mapped_task.fork(
        lambda _: False,
        lambda arg: arg == fn(2)
    )



# Generated at 2022-06-24 00:39:03.620783
# Unit test for method map of class Task
def test_Task_map():
    def addOne(val):
        return val + 1

    def result(reject, resolve):
        return resolve(2)

    t = Task(result)
    task = t.map(addOne)
    assert 3 == task.fork(lambda x: x, lambda x: x)



# Generated at 2022-06-24 00:39:07.103563
# Unit test for constructor of class Task
def test_Task():
    def callback(reject, resolve):
        resolve(5)

    assert Task(callback).fork(lambda _: False, lambda x: x == 5)

    callback = lambda _, r: r(5)

    assert Task(callback).fork(lambda _: False, lambda x: x == 5)



# Generated at 2022-06-24 00:39:17.362846
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method
    """
    class Multiply:
        def __init__(self, value):
            self.value = value

        def __call__(self, arg):
            return self.value * arg

        def __repr__(self):
            return f'Multiply({self.value})'

    class MultiplyTask:
        def __init__(self, value):
            self.value = value

        def __call__(self, arg):
            return Task.of(self.value * arg)

        def __repr__(self):
            return f'MultiplyTask({self.value})'

    assert Task.of(42).bind(Multiply(2)).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == 84

    assert Task.of

# Generated at 2022-06-24 00:39:20.957558
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of Task class.
    """
    def fork(_, resolve):
        return resolve(42)

    try:
        task = Task(fork)
    except TypeError:
        print("Task constructor does't take None type.")
        return None

    assert task.fork == fork, \
        'Task constructor does\'t store argument property.'


# Generated at 2022-06-24 00:39:31.792053
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit-test for method bind of class Task.
    """
    def f(x):
        """
        Auxiliary function.

        :params x: argument
        :type x: int
        :returns: Task[x] + 1
        :rtype: Task[int]
        """
        return Task.of(x + 1)

    def g(x):
        """
        Auxiliary function.

        :params x: argument
        :type x: int
        :returns: Task[x] + 1
        :rtype: Task[int]
        """
        return Task.of(x + 1)


# Generated at 2022-06-24 00:39:33.224884
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda _: None)
    assert task.fork is not None


# Generated at 2022-06-24 00:39:35.702489
# Unit test for constructor of class Task
def test_Task():
    def fork_test(reject, resolve):
        return resolve(20)

    assert Task(fork_test).fork(lambda x: x, lambda y: y) == 20


# Generated at 2022-06-24 00:39:39.656715
# Unit test for method map of class Task
def test_Task_map():
    def test_result(resolve, reject):
        resolve(10)

    task = Task(test_result)
    assert task.fork(lambda a: a, lambda a: a) == 10
    assert task.map(lambda a: a*10).fork(lambda a: a, lambda a: a) == 100


# Generated at 2022-06-24 00:39:42.630722
# Unit test for method map of class Task
def test_Task_map():
    def decrement(value):
        return value - 1

    task = Task.of(10)

    assert task.map(decrement).fork(lambda _: None, lambda value: value) == 9


# Generated at 2022-06-24 00:39:46.784547
# Unit test for method map of class Task
def test_Task_map():
    def plus(x):
        return x+1

    def multiple(x):
        return x*3

    assert Task(lambda reject, resolve: resolve(5)).map(plus).map(multiple).run() == 18
    assert Task.of(5).map(plus).map(multiple).run() == 18


# Generated at 2022-06-24 00:39:56.897777
# Unit test for method bind of class Task
def test_Task_bind():
    def get_employee(id):
        return Task(
            lambda reject, resolve: resolve(
                {
                    'id': 1,
                    'name': 'John Doe',
                    'address': '7th Heaven',
                    'age': 32,
                    'companyId': 1
                }
            )
        )

    def get_company(companyId):
        return Task(
            lambda reject, resolve: resolve(
                {
                    'id': 1,
                    'name': 'Acme',
                    'address': 'Craggy Island'
                }
            )
        )


# Generated at 2022-06-24 00:40:06.598844
# Unit test for method bind of class Task
def test_Task_bind():
    from functools import reduce
    from operator import add

    # Test data
    target = Task.of(200)
    multiplyer = Task.of(2)
    reducer = Task.of([1, 2, 3, 4, 5])

    def with_target(value):
        return Task.of(value * target.fork(lambda _: None, lambda arg: arg))

    def with_multiplyer(value):
        return Task.of(value * multiplyer.fork(lambda _: None, lambda arg: arg))

    def with_reducer(value):
        return Task.of(reduce(add, value))

    # Test

# Generated at 2022-06-24 00:40:10.541788
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(3))


# Generated at 2022-06-24 00:40:17.201574
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(10)
    assert task.fork(lambda _: None, lambda value: value) == 10

    assert task.map(lambda value: value * 2).fork(
        lambda _: None,
        lambda value: value
    ) == 20

    assert task.map(lambda value: value * 2).map(
        lambda value: value / 2
    ).fork(
        lambda _: None,
        lambda value: value
    ) == 10



# Generated at 2022-06-24 00:40:20.049796
# Unit test for constructor of class Task
def test_Task():
   def fork(reject, resolve):
        reject('Rejected value')
        resolve('Resolved value')

   task = Task(fork)
   assert task.fork == fork, 'Constructor of class Task is not valid'


# Generated at 2022-06-24 00:40:27.237901
# Unit test for method map of class Task
def test_Task_map():
    @Task.of(True)
    def task1(resolve):
        pass

    assert task1.map(lambda x: not x).fork(lambda x: None, lambda x: x) == False

    @Task.reject(False)
    def task2(reject):
        pass

    assert task2.map(lambda x: not x).fork(lambda x: x, lambda x: None) == True


# Generated at 2022-06-24 00:40:37.646334
# Unit test for method bind of class Task
def test_Task_bind():
    """
    test case for method bind of class Task

    :returns: if bind method is work correct, print OK
    :rtype: None
    """
    def run_assert(assertion):
        if assertion:
            print('OK')
        else:
            raise Exception('assert error')

    def resolve_fn(x):
        return Task.of(x + 2)

    def reject_fn(x):
        return Task.reject(x * 2)

    fun_resolve = Task.of(3)
    fun_reject = Task.reject(-1)

    fun_resolve2 = Task.of(6)
    fun_reject2 = Task.reject(-2)

    run_assert(fun_resolve.bind(resolve_fn).fork(lambda _: False, lambda x: x == 5))

# Generated at 2022-06-24 00:40:40.325707
# Unit test for method map of class Task
def test_Task_map():
    def mapper(arg):
        return arg * 2

    def fork_function(_, resolve):
        return resolve(7)

    task = Task(fork_function)

    assert task.map(mapper).fork(None, lambda arg: arg) == 14

# Generated at 2022-06-24 00:40:46.675551
# Unit test for method bind of class Task
def test_Task_bind():
    def step1(value):
        assert value == 1

        def step2(value):
            assert value == 2

            return Task.of(value + 1)

        return Task.of(value + 1).bind(step2)


# Generated at 2022-06-24 00:40:51.157916
# Unit test for method map of class Task
def test_Task_map():
    def map_identity(arg):
        return arg

    assert Task.of(42).map(map_identity).fork(None, None) == 42
    assert Task.reject(42).map(map_identity).fork(None, None) == 42


# Generated at 2022-06-24 00:40:53.812899
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    assert task.map(lambda x: x * 2).fork(lambda x: x, lambda x: x) == 4



# Generated at 2022-06-24 00:40:59.609846
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(True)\
        .bind(lambda arg: Task.reject(False))\
        .bind(lambda arg: Task.of(True))\
        .fork(lambda x: print(x), lambda x: print(x))
    assert result is False

# Generated at 2022-06-24 00:41:02.220367
# Unit test for method map of class Task
def test_Task_map():
    def mock(arg):
        return arg + 1

    def mock_reject(arg):
        return -1

    def mock_resolve(arg):
        return arg

    task = Task(
        lambda reject, resolve: resolve(1)
    )
    task = task.map(mock)
    assert isinstance(task, Task)
    assert 0 == task.fork(mock_reject, mock_resolve)


# Generated at 2022-06-24 00:41:09.706719
# Unit test for method map of class Task
def test_Task_map():
    def f(x):
        return x

    def g(x):
        return x + 1

    def h(x):
        return x * 2

    # f  should be the identity function
    assert Task.of(2).map(f).fork(lambda x: None, lambda x: x) == 2

    # g, h should be applied in order
    assert Task.of(2).map(g).map(h).fork(lambda x: None, lambda x: x) == 4
    assert Task.of(2).map(lambda x: g(h(x))).fork(lambda x: None, lambda x: x) == 5


# Generated at 2022-06-24 00:41:20.466729
# Unit test for method bind of class Task
def test_Task_bind():

    # Test 1
    failing_task = Task.reject(Exception())
    succeeding_task = Task.of(1)
    task = failing_task.bind(lambda _: succeeding_task)
    assert not task.fork(lambda _: True, lambda _: True)  # Is rejected

    # Test 2
    failing_task_1 = Task.reject(Exception())
    failing_task_2 = Task.reject(Exception())
    task = failing_task_1.bind(lambda _: failing_task_2)
    assert not task.fork(lambda _: True, lambda _: True)  # Is rejected

    # Test 3
    succeeding_task_1 = Task.of(1)
    succeeding_task_2 = Task.of(2)

# Generated at 2022-06-24 00:41:29.252908
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_test():
        test_task = Task.of(5)
        mapped_task = test_task.map(lambda arg: arg + 100)

        def assert_func(result):
            assert result == 105
        mapped_task.fork(lambda _: None, assert_func)

    def reject_test():
        is_reject = False

        test_task = Task.reject("some message")
        mapped_task = test_task.map(lambda arg: arg + 100)

        def assert_func(err):
            nonlocal is_reject
            is_reject = True
            return Task.of(None)
        mapped_task.fork(assert_func, lambda _: None)
        return is_reject

    assert reject_test()
    resolve_test()


# Generated at 2022-06-24 00:41:32.275058
# Unit test for constructor of class Task
def test_Task():
    """
    >>> Task(lambda reject, resolve: resolve(1))
    <Task object at 0x7f2379e9b2b0>
    """
    assert Task(lambda reject, resolve: resolve(1))


# Generated at 2022-06-24 00:41:41.945906
# Unit test for method bind of class Task
def test_Task_bind():
    def test(fn):
        """
        Test Task.bind with `fn` (mapper) function.

        :param fn: function to use with Task.bind
        :type fn: Function(value) -> B
        """