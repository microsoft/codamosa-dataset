

# Generated at 2022-06-24 00:31:43.911700
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        return "Resolved value: " + str(value)

    def reject(value):
        return "Rejected value: " + str(value)

    def resolve_fn(value):
        return value + "!!!"

    def reject_fn(value):
        return value + "???"

    resolved_task = Task.of("Test")
    rejected_task = Task.reject("Test")

    # Check that Task with resolve value call resolve callback with mapped value
    assert(resolved_task.fork(reject, resolve) == resolve_fn("Resolved value: Test"))

    # Check that Task with reject value call reject callback with mapped value
    assert(rejected_task.fork(reject, resolve) == reject_fn("Rejected value: Test"))

    # Check that Task map method return correct Task

# Generated at 2022-06-24 00:31:49.751453
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(2)

    task = Task(fork)

    def add(value):
        return value + 1

    mapped = task.map(add)

    def fork_mapped(reject, resolve):
        resolve(3)

    assert mapped.fork == fork_mapped


# Generated at 2022-06-24 00:32:00.462066
# Unit test for method bind of class Task
def test_Task_bind():
    value = Task.of(1).bind(lambda x: Task.of(x + 1))
    print(value.fork(None, print))
    assert value.fork(None, lambda x: x) == 2

    value = Task.of(1).bind(lambda x: Task.reject(x * 2))
    print(value.fork(print, None))
    assert value.fork(lambda x: x, None) == 2

    value = Task.reject(1).bind(lambda x: Task.of(x + 1))
    print(value.fork(print, None))
    assert value.fork(lambda x: x, None) == 1

    value = Task.reject(1).bind(lambda x: Task.reject(x * 2))
    print(value.fork(print, None))

# Generated at 2022-06-24 00:32:08.315718
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for:
        Method map of Task class

    :returns: True if all test passed, False if not
    :rtype: bool
    """
    def test_resolve():
        """
        Test resolve function.

        :returns: True if all test passed, False if not
        :rtype: bool
        """
        def get_resolve(resolve):
            def inner(value):
                resolve(value)

            return inner

        def get_reject(reject):
            def inner():
                reject("rejected")

            return inner

        def inner(value):
            return "Hello " + value

        task = Task(lambda reject, resolve: resolve("world!"))
        result = task.map(inner)

# Generated at 2022-06-24 00:32:11.948787
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(2).map(lambda x: x * x).fork(
        lambda x: None,
        lambda x: x
    ) == 4

    assert Task.of(True).map(lambda x: not x).fork(
        lambda x: None,
        lambda x: x
    ) is False


# Generated at 2022-06-24 00:32:16.313132
# Unit test for method map of class Task
def test_Task_map():
    @lazy
    def mock_fork_with_resolve_value():
        def fork(reject, resolve):
            resolve(42)
        return fork


# Generated at 2022-06-24 00:32:21.267289
# Unit test for method map of class Task
def test_Task_map():
    initial_value = "value"

    def map_function(value):
        assert value == initial_value
        return value

    def fork_function(_, resolve):
        return resolve(initial_value)

    def test():
        Task(fork_function).map(map_function)

    test = Task(test)

    test.fork(fail, pass_)



# Generated at 2022-06-24 00:32:26.068674
# Unit test for method map of class Task
def test_Task_map():
    """
    Call fork of Task with lambda functions and check that
    stored function work correct.
    """
    test_Task = Task(lambda reject, resolve: 10)
    assert test_Task.map(lambda value: value * 2).fork(
        lambda _: 0,
        lambda value: value
    ) == 20


# Generated at 2022-06-24 00:32:30.818831
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    def test(a, b, c):
        return Task.of(add(a, b)).map(lambda x: add(x, c))

    assert test(1, 2, 3) == Task.of(6)


# Generated at 2022-06-24 00:32:33.777557
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2).map(lambda x: x ** 2)
    assert task.fork(None, lambda v: v) == 4


# Generated at 2022-06-24 00:32:40.936831
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(arg):
        return arg

    def reject(arg):
        return arg

    def _(arg):
        return Task.of(arg*2)

    result = Task(resolve).bind(_).fork(reject, resolve)

    assert result == 2



# Generated at 2022-06-24 00:32:46.175316
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(True))

# Generated at 2022-06-24 00:32:53.706053
# Unit test for method map of class Task
def test_Task_map():
    def get_type(a):
        return type(a)

    def get_str_type(a):
        return type(str(a))

    def get_str_to_int(a):
        return int(a)

    global error
    error = Exception("Error")

    assert Task.of("10").map(get_type).fork(lambda _: "failure", lambda result: result) == int



# Generated at 2022-06-24 00:32:59.926914
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(x):
        def result(reject, resolve):
            resolve(x + 1)

        return Task(result)

    def reject(arg):
        assert False

    def resolve(arg):
        assert isinstance(arg, int)
        assert arg == 2

    value = Task.of(1)
    Task.bind(value, fn).fork(reject, resolve)

'''
test_Task_bind()
'''

# Generated at 2022-06-24 00:33:08.498604
# Unit test for constructor of class Task
def test_Task():
    import unittest

    class TestTask(unittest.TestCase):

        def test_of(self):
            def reject(val):
                raise ValueError('reject is called but expected resolve')

            def resolve(val):
                return val

            task = Task.of(10)

            self.assertEqual(task.fork(reject, resolve), 10, 'of return incorrect value')

        def test_reject(self):
            def reject(val):
                return val

            def resolve(val):
                raise ValueError('resolve is called but expected reject')

            task = Task.reject(10)

            self.assertEqual(task.fork(reject, resolve), 10, 'reject return incorrect value')

    unittest.main()


# Generated at 2022-06-24 00:33:15.006878
# Unit test for method map of class Task
def test_Task_map():
    def add(a, b):
        return a + b

    def do_add(fn, a, b):
        return fn(a, b)

    assert Task.of(add).map(do_add)(1, 2) == 3

    def not_add(a):
        pass

    assert Task.of(not_add).map(do_add)(1, 2) == None


test_Task_map()
print('Test for method map was passed.')

# Generated at 2022-06-24 00:33:17.881850
# Unit test for method map of class Task
def test_Task_map():
    test_function = lambda value: str(value) + '!!!'
    test_value = 1

# Generated at 2022-06-24 00:33:23.489708
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        print("fork called")
        resolve("Task value")

    task = Task(fork)
    task.map(lambda v: (v, "mapped value")).bind(lambda v: Task.reject(v))


# Generated at 2022-06-24 00:33:28.740927
# Unit test for constructor of class Task
def test_Task():
    def fork_a(reject, resolve):
        reject("a")

    def fork_b(reject, resolve):
        resolve("b")

    task_a = Task(fork_a)
    task_b = Task(fork_b)

    assert task_a.fork == fork_a
    assert task_b.fork == fork_b


# Generated at 2022-06-24 00:33:33.786280
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)
    assert type(task).__name__ == 'Task'
    assert task.map(add_one).fork(lambda _: None, lambda result: result) == 2

# Generated at 2022-06-24 00:33:37.318912
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve(1)

    def resolve(value):
        assert value == 2

    def reject(value):
        raise AssertionError()

    Task(fork).map(lambda x: x + 1).fork(reject, resolve)


# Generated at 2022-06-24 00:33:41.319310
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda a: a, lambda a: a) == 1
    assert Task.reject(1).fork(lambda a: a, lambda a: a) == 1


# Generated at 2022-06-24 00:33:46.372753
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(3)
    task1 = task.map(lambda x: x + 1)
    task2 = task1.map(lambda x: x ** 2)
    task3 = task2.map(lambda x: x // 2)
    task4 = task3.map(lambda x: x % 2)
    assert task4.fork(None, lambda x: x) == 0


# Generated at 2022-06-24 00:33:55.052781
# Unit test for constructor of class Task
def test_Task():
    """
    Unit testing which show how to use constructor and arguments of class Task.

    :return: None
    """
    # Print info about test
    print('*' * 10)
    print('Testing constructor of class Task')
    print('*' * 10)

    # Initialize function with equal arguments
    def task(reject_a, resolve_b): return 'fork'

    # Initialize Task with argument
    task_a = Task(task)
    print('task_a is instance of Task: ', isinstance(task_a, Task))
    print('task_a.fork: ', task_a.fork)


# Generated at 2022-06-24 00:34:04.358254
# Unit test for method bind of class Task

# Generated at 2022-06-24 00:34:06.675714
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Check bind method of class Task
    """
    def test1(reject, resolve):
        assert reject(1) == 1

    def test2(reject, resolve):
        assert resolve(1) == 1

    Task(test1).bind(lambda x: Task(test2)).fork(lambda x: None, lambda x: None)


# Generated at 2022-06-24 00:34:15.191396
# Unit test for method map of class Task
def test_Task_map():
    value = {'result': 0, 'rejected': 0}
    def inc(val):
        value['result'] = val + 1
        return value['result']

    def dec(val):
        value['rejected'] = val - 1
        return value['rejected']

    task = Task(inc)
    task.map(inc)
    task.fork(lambda _: None, lambda res: res)
    assert value['result'] == 2

    task.fork(dec, lambda _: None)
    assert value['rejected'] == -1


# Generated at 2022-06-24 00:34:23.250942
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task.bind method
    """
    @gen.coroutine
    def assert_result(result):
        """
        Assert result of Task execution

        :param result: value to assert
        :type result: Generator[None, Exception, int]
        """
        assert (yield result) == 1
        raise gen.Return(True)

    task = Task.of(1).bind(
        lambda arg: Task.of(arg)
    )

    yield assert_result(task.fork(
        lambda arg: assert_result(Task.reject(arg)),
        lambda arg: assert_result(Task.of(arg))
    ))

    task = Task.of(1).bind(
        lambda arg: Task.reject(arg)
    )


# Generated at 2022-06-24 00:34:29.313291
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map(lambda x: x * 2)
      returns Task(fork = lambda reject, resolve: resolve(10 * 2))
    """
    def verify(a, b):
        """
        Check if value a and value b is equal.

        :param a: value to check
        :param b: value to check
        :type a: a
        :type b: a
        :returns: Boolean
        :rtype: Boolean
        """
        assert a == b

    t = Task.of(10)
    t.map(lambda x: x * 2).fork(
        lambda arg: verify(arg, 20),
        lambda arg: verify(arg, 20)
    )


# Generated at 2022-06-24 00:34:35.715575
# Unit test for method bind of class Task
def test_Task_bind():
    def get_value():
        return Task.of(1)
    def add(value):
        return Task.of(value + 2)

    fork = Task.of(1)\
                .bind(get_value)\
                .bind(add)\
                .fork
    res = fork(lambda val: val, lambda val: val)
    assert res == 4

    fork = Task.reject(0)\
                .bind(get_value)\
                .fork
    res = fork(lambda val: val, lambda val: val)
    assert res == 0

    fork = Task.reject(0)\
                .bind(lambda val: Task.reject(1))\
                .fork
    res = fork(lambda val: val, lambda val: val)
    assert res == 1

# Generated at 2022-06-24 00:34:41.898062
# Unit test for method map of class Task
def test_Task_map():
    """
    Check behavior of method map.
    """
    assert Task(lambda _, resolve: resolve(1)).map(lambda x: x + 1).fork(
        lambda x: x + 1,
        lambda x: x - 1
    ) == 2

    assert Task(lambda _, resolve: resolve(1)).map(lambda x: x + 1).fork(
        lambda x: x + 1,
        lambda x: x - 1
    ) == 2


# Generated at 2022-06-24 00:34:44.301397
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(lambda x: x).bind(lambda x: Task.of(x(2))) == Task.of(2)



# Generated at 2022-06-24 00:34:47.941983
# Unit test for constructor of class Task
def test_Task():
    """
    Test correctness of constructor of class Task.

    :returns: None
    :rtype: NoneType
    """
    task = Task(lambda _, resolve: resolve())

    assert isinstance(task, Task)


# Generated at 2022-06-24 00:34:51.906523
# Unit test for method map of class Task
def test_Task_map():
    def fn(arg):
        return arg * 2
    test_task = Task.of(2)
    mapped_task = test_task.map(fn)
    assert test_task.fork(None, None) == 2
    assert mapped_task.fork(None, None) == 4
    assert test_task != mapped_task



# Generated at 2022-06-24 00:34:54.561168
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(3).bind(lambda x: Task.of(x + 5)).fork(
        lambda x: False,
        lambda x: x == 8
    )

# Generated at 2022-06-24 00:34:59.400356
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x ** 2

    def reject(x):
        raise AssertionError("{} doesn't reject".format(x))

    def resolve(x):
        assert x == 4, "{} doesn't resolve to 4".format(x)

    Task.of(2).map(fn).fork(reject, resolve)


# Generated at 2022-06-24 00:35:07.541868
# Unit test for method bind of class Task
def test_Task_bind():
    def print_value(value):
        print(value)

    def resolve_task(value):
        return Task.of(value + '1')

    def return_task(value):
        return Task.of(value)

    Task.of(1).map(str).bind(return_task).fork(print_value, print_value)
    Task.of(1).map(str).bind(resolve_task).fork(print_value, print_value)
    Task.of(1).map(str).bind(resolve_task).bind(return_task).fork(print_value, print_value)
    Task.of(1).map(str).bind(resolve_task).bind(resolve_task).fork(print_value, print_value)

# Generated at 2022-06-24 00:35:16.105112
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.

    :returns: None
    :rtype: None
    """
    def test(value, log):
        log.append(value)

    def test_error(value, log):
        log.append(value)
        raise "TestError"

    def test_bind(value, log):
        log.append(value)
        return Task.of(value)

    log = []

    t = Task.of(10)
    t.bind(lambda value: test_bind(value, log)).fork(test_error, test)
    assert log == [10]

    t = Task.of(10)
    t.bind(lambda value: test_bind(value, log)).map(lambda arg: arg).fork(test_error, test)

# Generated at 2022-06-24 00:35:22.740152
# Unit test for method map of class Task
def test_Task_map():
    """
    Test function square of function Task
    """
    def square(num):
        return num ** 2

    result = Task.of(1).map(square).fork(None, lambda _: _)

    assert result == 1

    result = Task.of(2).map(square).fork(None, lambda _: _)

    assert result == 4



# Generated at 2022-06-24 00:35:24.776984
# Unit test for constructor of class Task
def test_Task():
    fn = lambda _, resolve: resolve(42)
    task = Task(fn)
    assert task.fork == fn


# Generated at 2022-06-24 00:35:34.362257
# Unit test for method bind of class Task
def test_Task_bind():
    def test_func(arg):
        return arg + '_test'

    def test_map(arg):
        return arg + '_map'

    def task_of_one():
        return Task.of(1)

    def task_of_string():
        return Task.of('2')

    # Task[reject, mapped_value]
    task = Task.of('1')
    task_after_bind = task.bind(task_of_one)

    assert isinstance(task_after_bind, Task)
    assert task_after_bind.fork(lambda arg: 'reject: ' + str(arg), lambda arg: 'resolve: ' + str(arg)) == 'resolve: 1'

    # Task[reject, String]
    task = Task.of('1')

# Generated at 2022-06-24 00:35:43.652123
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Try to bind function for example value.
    :returns: None
    """
    def test_method(value):
        return Task.of(value * 2)

    task = Task.of(2) \
        .bind(test_method) \
        .bind(test_method)

    response = []

    def resolve(result):
        response.append(result)

    def reject(error):
        pass

    task.fork(reject, resolve)

    if response[0] != 8:
        print("Error. Task bind return {}. Expect: 8.".format(response))
    else:
        print("Success. Task bind return 8.")

if __name__ == "__main__":
    test_Task_bind()

# Generated at 2022-06-24 00:35:53.240489
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(2) \
        .bind(lambda n: Task.of(n ** 2)) \
        .fork(lambda _: "ok", lambda _: "bad") == "ok"

    assert Task.reject(2) \
        .bind(lambda n: Task.of(n ** 2)) \
        .fork(lambda _: "ok", lambda _: "bad") == "bad"

    assert Task.of(2) \
        .bind(lambda n: Task.reject(n ** 2)) \
        .fork(lambda _: "ok", lambda _: "bad") == "bad"

    assert Task.reject(2) \
        .bind(lambda n: Task.reject(n ** 2)) \
        .fork(lambda _: "ok", lambda _: "bad") == "bad"

# Unit

# Generated at 2022-06-24 00:35:54.961135
# Unit test for method bind of class Task

# Generated at 2022-06-24 00:35:59.939355
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_fn(value): return value ** 2
    def reject_fn(value): raise Exception(value)

    task = Task.of(2)
    task = task.bind(lambda value: Task.of(resolve_fn(value)))
    task = task.bind(lambda value: Task.reject(reject_fn(value)))
    task = task.bind(lambda value: Task.of(resolve_fn(value)))

    assert task.fork(id, id) == 4


# Generated at 2022-06-24 00:36:06.574169
# Unit test for method map of class Task
def test_Task_map():
    def mock(reject, resolve):
        def fn(arg):
            assert arg == 1
            return resolve(arg + 1)
        return mock2(fn)

    def mock2(fn):
        return fn(1)

    assert Task(mock).map(lambda x: x + 1).map(lambda x: x + 2).fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-24 00:36:08.190726
# Unit test for constructor of class Task
def test_Task():
    test_fn = lambda _, resolve: resolve(2)
    assert Task(test_fn)


# Generated at 2022-06-24 00:36:12.209136
# Unit test for method bind of class Task
def test_Task_bind():
    def background_fn():
        def fn(value):
            return value

        return Task.of(fn).bind(fn)

    # ensure background_fn will be called in another thread
    t = Thread(target=background_fn)
    t.start()
    result = t.join()

    assert result.fork(None, lambda x: x(1)) == 1


# Generated at 2022-06-24 00:36:15.243383
# Unit test for method map of class Task
def test_Task_map():
    """Test for method map of class Task."""
    add_one = lambda x: x + 1
    x = Task.of(100).map(add_one)
    assert x.fork(
        lambda arg: '',
        lambda arg: arg
    ) == 101


# Generated at 2022-06-24 00:36:17.420878
# Unit test for constructor of class Task
def test_Task():
    """
    Test resolve function that return resolved Task.
    """
    assert Task.of(1).fork(lambda arg: arg, lambda arg: arg + 1) == 2


# Generated at 2022-06-24 00:36:22.795079
# Unit test for constructor of class Task
def test_Task():
    reject, resolve = mock.Mock(), mock.Mock()

    task = Task(lambda _, resolve: resolve(1))
    task.fork(reject, resolve)

    resolve.assert_called_once_with(1)
    assert not reject.called


# Generated at 2022-06-24 00:36:27.224927
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        resolve(1)
    t = Task(fork)

    def fn(value):
        def fork(reject, resolve):
            reject(value + 2)
        return Task(fork)

    result = t.bind(fn).fork(lambda v: v, lambda v: v)
    assert result == 3


# Generated at 2022-06-24 00:36:29.584878
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda reject, resolve: resolve(42)).fork(lambda value: value, lambda value: value) == 42


# Generated at 2022-06-24 00:36:36.319573
# Unit test for method map of class Task
def test_Task_map():
    identity = lambda x: x
    map_id = Task.of(3).map(identity)
    assert map_id.fork(
        lambda x: NotImplemented,
        lambda x: x
    ) == 3

    adjusted_id = Task.of(3).map(lambda x: x + 10)
    assert adjusted_id.fork(
        lambda x: NotImplemented,
        lambda x: x,
    ) == 13



# Generated at 2022-06-24 00:36:40.312574
# Unit test for constructor of class Task
def test_Task():
    """
    Test for folow cases:
        - fork are valid function
        - fork are not a function
    """
    def valid_function(_, __):
        return None

    invalid_function = 1

    assert Task(valid_function)

    with raises(TypeError):
        Task(invalid_function)


# Generated at 2022-06-24 00:36:50.788816
# Unit test for method bind of class Task
def test_Task_bind():
    def chained(arg):
        return Task.of(arg * 2)

    def task_with_error(arg):
        if arg < 0:
            return Task.reject(ValueError('arg is negative'))

        return Task.of(arg / 2)

    def test_reject():
        assert Task.of(10).bind(lambda _: Task.reject(Exception())).fork(lambda arg: arg, lambda arg: arg) == Exception()

    def test_resolve():
        assert Task.of(10).bind(lambda _: Task.of(15)).fork(lambda arg: arg, lambda arg: arg) == 15

    def test_chained():
        assert Task.of(10).bind(chained).fork(lambda arg: arg, lambda arg: arg) == 20


# Generated at 2022-06-24 00:36:54.356968
# Unit test for method bind of class Task
def test_Task_bind():
    def test_value(value):
        return value

    assert Task(lambda reject, resolve: resolve(16)).bind(test_value) == Task(lambda reject, resolve: resolve(16))
    assert Task(lambda reject, resolve: resolve(16)).bind(Task.of) == Task(lambda reject, resolve: resolve(16))

# Generated at 2022-06-24 00:36:59.057999
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    assert Task(fork).fork(lambda _: None, lambda value: value) == 1


# Generated at 2022-06-24 00:37:02.437163
# Unit test for method map of class Task
def test_Task_map():
    fn = lambda value: value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    assert task.map(fn).fork(lambda x: None, lambda x: x) == 2


# Generated at 2022-06-24 00:37:07.384616
# Unit test for method bind of class Task
def test_Task_bind():
    def _resolve(value):
        _data = value + 1
        return Task.of(_data)

    class Rejecter:
        def __init__(self):
            self.was_called = False

        def __call__(self, arg):
            self.was_called = True

    rejecter = Rejecter()
    Task.of(2).bind(_resolve).fork(rejecter, lambda arg: arg)
    assert rejecter.was_called is False
    assert _data == 3


# Generated at 2022-06-24 00:37:09.626989
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(2).bind(lambda x: Task.of(x**2))
    assert result.fork(lambda x: x, lambda x: x) == 4

test_Task_bind()

# Generated at 2022-06-24 00:37:10.869253
# Unit test for constructor of class Task
def test_Task():
    assertTask(Task(lambda _, resolve: resolve()), True, False)


# Generated at 2022-06-24 00:37:13.671986
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        def fork(_, resolve):
            resolve(value + 1)

        return Task(fork)

    def fork(_, resolve):
        resolve(1)

    t = Task(fork)

    def check(result):
        assert result == 2

    t.bind(fn).fork(None, check)


# Generated at 2022-06-24 00:37:17.629539
# Unit test for method map of class Task
def test_Task_map():
    def plus_one(value):
        return value + 1

    assert Task.of(0).map(plus_one).fork(lambda _: False, lambda arg: arg == 1)


# Generated at 2022-06-24 00:37:23.579673
# Unit test for method map of class Task
def test_Task_map():
    # Arrange
    arg_A = [1, 2, 3]
    arg_B = [4, 5, 6]
    f_add = lambda arg: arg[0] + arg[1]
    f_mul = lambda arg: arg[0] * arg[1]
    f_reject = lambda arg: arg[0] - arg[1]
    task = Task.of(arg_A)

    # Act
    task_mapped = task.map(f_add)
    task_mapped_again = task_mapped.map(f_mul)
    reject_result = task_mapped.map(f_reject)

    # Assert
    assert task_mapped_again.fork(lambda arg: None, lambda arg: arg) == 28

# Generated at 2022-06-24 00:37:27.683413
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.

    :returns: None
    :rtype: NoneType
    """
    def task(reject, resolve):
        return None

    t = Task(task)

    assert t.fork(lambda arg: None, lambda arg: None) is None


# Generated at 2022-06-24 00:37:30.442041
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(2).fork(lambda _: None, lambda arg: arg) == 2
    assert Task.reject('test').fork(lambda arg: arg, lambda _: None) == 'test'




# Generated at 2022-06-24 00:37:34.571218
# Unit test for method bind of class Task
def test_Task_bind():
    def mock_fork(reject, resolve):
        resolve('value')
    def fn(result):
        return Task.of(result + '_mapped')

    task = Task(mock_fork)

# Generated at 2022-06-24 00:37:40.797204
# Unit test for method bind of class Task
def test_Task_bind():
    def test_case(param, expected_result):
        def task_fn(reject, resolve):
            resolve(param)

        task = Task(task_fn)

        binded = task.bind(
            lambda arg: Task.of(arg ** 2)
        )

        # test for binded.fork(reject, resolve)
        _, resolve = binded.fork(None, None)
        assert resolve(None) == expected_result

        # test for binded.fork(Error, resolve)
        _, resolve = Task(task_fn).bind(
            lambda arg: Task.of(arg ** 2)
        ).fork(ValueError, None)
        assert resolve(None) == expected_result

    test_case(3, 9)
    test_case(7, 49)
    test_case(9, 81)


# Generated at 2022-06-24 00:37:44.785545
# Unit test for method bind of class Task
def test_Task_bind():
    """
    test method bind of class Task
    """
    assert Task(
        lambda reject, resolve: resolve(5)
    ).bind(
        lambda x: Task.of(x)
    ).fork(
        lambda x: "Got an error: {0}".format(x),
        lambda x: x
    ) == 5


# Generated at 2022-06-24 00:37:48.608285
# Unit test for method map of class Task
def test_Task_map():
    value = 4
    result = Task.of(value).map(lambda x: x*2)
    assert Task.of(value*2).fork(
        lambda x: True,
        lambda x: x == value*2
    )



# Generated at 2022-06-24 00:37:50.228249
# Unit test for method map of class Task
def test_Task_map():
    Task.of(1).map(lambda arg: arg + 1).fork(print, print)
    Task.reject(1).map(lambda arg: arg + 1).fork(print, print)


# Generated at 2022-06-24 00:37:52.662131
# Unit test for constructor of class Task
def test_Task():
    def check_fork(reject, resolve):
        reject('test reject')
        resolve('test resolve')

    task = Task(check_fork)
    assert task.fork('reject', 'resolve') == 'test resolve'


# Generated at 2022-06-24 00:38:01.774532
# Unit test for method bind of class Task
def test_Task_bind():
    def get_user():
        return Task(lambda reject, resolve: resolve(
            {'id': 1, 'name': 'Test User'}
        ))

    def get_address(user):
        return Task.reject({'error': 'Not Found'})

    def get_address_error(error):
        return Task.of({'message': 'Error'})

    result = Task.of(None)\
        .bind(lambda _: get_user())\
        .bind(get_address)\
        .map(lambda _: 'Success')\
        .fork(get_address_error, lambda x: x)
    assert result == {'message': 'Error'}


# Generated at 2022-06-24 00:38:06.680434
# Unit test for method map of class Task
def test_Task_map():
    def identity(x):
        return x
    task = Task.of(1).map(identity)
    assert task.fork(lambda x: x, lambda _: _) == 1


# Generated at 2022-06-24 00:38:10.387181
# Unit test for constructor of class Task
def test_Task():
    """
    .. doctest::
       :options: +NORMALIZE_WHITESPACE
       :hide:

       >>> def fn(_, resolve): resolve(1)
       >>> task = Task(fn)
       >>> task.fork(lambda reject: 0, lambda resolve: resolve)
       1
    """


# Generated at 2022-06-24 00:38:18.113152
# Unit test for method bind of class Task
def test_Task_bind():
    def take_value_and_return_resolved_task_with_plus_two():
        return Task.of(10)

    def take_value_and_return_resolved_task_with_plus_four():
        return Task.of(20)

    assert Task.of(1).bind(take_value_and_return_resolved_task_with_plus_two)\
                     .bind(take_value_and_return_resolved_task_with_plus_four)\
                     .fork(reject=lambda x: x, resolve=lambda x: x) == 22


# Generated at 2022-06-24 00:38:28.350176
# Unit test for constructor of class Task
def test_Task():
    from hypothesis import given
    from hypothesis.strategies import integers, text, binary
    from unittest import TestCase, main

    @given(integers())
    def test_returns_task_with_match_fork_function(value):
        subject = Task(lambda _, resolve: resolve(value))

        assert(subject.fork(str, str) == value)

    @given(integers())
    def test_of_returns_task_with_match_fork_function(value):
        subject = Task.of(value)

        assert(subject.fork(str, str) == value)

    @given(integers())
    def test_reject_returns_task_with_match_fork_function(value):
        subject = Task.reject(value)


# Generated at 2022-06-24 00:38:32.534183
# Unit test for constructor of class Task
def test_Task():
    """
    Test case for Task constructor.

    :returns: None
    :rtype: None
    """
    task: Task[reject, SomeType] = Task(lambda reject, resolve: resolve(SomeType()))
    assert task.fork(lambda arg: None, lambda arg: None) == SomeType()



# Generated at 2022-06-24 00:38:36.977922
# Unit test for constructor of class Task
def test_Task():
    def fork(resolve, reject):
        def mocked_resolve(value):
            assert value == 'success'
            return

        def mocked_reject(value):
            assert value == 'error'
            return

        def call_resolve():
            resolve('success')
            return

        def call_reject():
            reject('error')
            return

        return call_resolve, call_reject

    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-24 00:38:43.067993
# Unit test for method map of class Task
def test_Task_map():
    # task_of: Task[Function(_, resolve) -> A]
    task_of = Task.of(5)
    task_of_2 = task_of.map(lambda x: x * 2)

    # task_of_2: Task[Function(_, resolve) -> B]
    assert callable(task_of_2.fork)
    assert task_of_2.fork(None, None) == 10


# Generated at 2022-06-24 00:38:51.148526
# Unit test for method map of class Task
def test_Task_map():
    """
    >>> test_Task_map()
    True
    """
    # Task.of is returning resolved task with argument as value
    task = Task.of(3)

    # Task.map is calling function with resolved value during calling fork method
    # and return new Task with result of this function
    mapped_task = task.map(lambda x: x * 2)

    # fork method is executing function with resolve and reject parameters
    # we don't need reject, only resolve
    result = mapped_task.fork(None, lambda value: value)

    return result == 6


# Generated at 2022-06-24 00:38:55.945138
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(None, lambda x: x) == 2
    assert Task.of(2).map(lambda x: x + 1).map(lambda x: x + 1).fork(None, lambda x: x) == 4


# Generated at 2022-06-24 00:38:56.896644
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(10))

# Generated at 2022-06-24 00:38:58.595815
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    add_one = lambda x: x + 1
    progress = lambda x: x * 2
    double_add_one = task.map(add_one).map(progress)

    assert double_add_one.fork(lambda x: x, lambda x: x) == 4

if __name__ == '__main__':
    test_Task_map()

# Generated at 2022-06-24 00:39:05.338693
# Unit test for method bind of class Task
def test_Task_bind():
    """
    :returns: True if tests passed and False otherwise
    """
    def add_one(value):
        return Task.of(value + 1)

    add_one_task = Task.of(1).bind(lambda value: add_one(value))
    assert add_one_task.fork(lambda _: 1, lambda value: value) == 2
    return True


# Generated at 2022-06-24 00:39:09.114752
# Unit test for method bind of class Task
def test_Task_bind():
    def add_one(value):
        return value + 1

    def double(value):
        return value * 2

    def add_one_and_double(value):
        return Task.of(value).map(add_one).map(double)

    task = Task.of(1)
    assert task.bind(add_one_and_double).fork(lambda _: None, lambda result: result) == 4


# Generated at 2022-06-24 00:39:19.257599
# Unit test for method bind of class Task
def test_Task_bind():
    def add(x):
        return Task(lambda _, resolve: resolve(x + 10))

    def multiply(x):
        return Task(lambda _, resolve: resolve(x * 5))

    def sub(x):
        return Task(lambda _, resolve: resolve(x - 20))

    add_multiply_sub = Task.of(5).bind(add).bind(multiply).bind(sub)

    assert add_multiply_sub.fork(lambda x: x, lambda x: x) == 25

    add_multiply_sub = Task.of(2).bind(add).bind(multiply).bind(sub)

    assert add_multiply_sub.fork(lambda x: x, lambda x: x) == 40

    add_multiply_sub = Task.of(10).bind(add).bind

# Generated at 2022-06-24 00:39:30.282458
# Unit test for method bind of class Task
def test_Task_bind():
    import json

    def get_request():
        """
        Make request to site http://www.reddit.com/r/python/.json
        Parse json response.
        Return Task rejected with reason if request failed.

        :returns: new Task with mapped resolve attribute
        :rtype: Task[reject, mapped_value]
        """
        import urllib2

# Generated at 2022-06-24 00:39:38.002465
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test how bind method of class Task work.
    """
    def map1(value):
        return value + 1

    def map2(value):
        return value + 2

    def failure1(value):
        return Task.reject(value + 1)

    def failure2(value):
        return Task.reject(value + 2)

    assert Task.of(1).bind(map1).bind(map2).fork(lambda arg: arg, lambda arg: arg) == 4
    assert Task.of(1).bind(failure1).bind(failure2).fork(lambda arg: arg, lambda arg: arg) == 2


# Generated at 2022-06-24 00:39:40.978702
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(2)
    inc = task.map(lambda x: x + 1)

    assert inc.fork(None, lambda x: x) == task.fork(None, lambda x: x + 1)


# Generated at 2022-06-24 00:39:46.342472
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve(a):
        assert a == 8

    def reject(a):
        assert False

    value = Task(lambda a, b: b(2))
    value.bind(lambda x: Task(lambda a, b: b(x * x)))\
        .bind(lambda x: Task(lambda a, b: b(x)))\
        .fork(reject, resolve)

# Generated at 2022-06-24 00:39:54.160468
# Unit test for method bind of class Task
def test_Task_bind():
    # should work with good args
    assert Task.of(1).bind(lambda x: Task.of(x + 1)).fork(ignore, lambda x: x) == 2

    # should work with bad args
    def t(x):
        return Task.of(x + 1)
    _ = Task.of(1).bind(t).fork(ignore, ignore)

    # should work with bad args
    def t(x):
        return Task.reject(x + 1)
    Task.of(1).bind(t).fork(lambda x: x, ignore)

    # should work with bad args
    def t(x):
        return Task.of(x + 1)
    Task.reject(1).bind(t).fork(lambda x: x, ignore)

    # should work with bad args

# Generated at 2022-06-24 00:39:57.662474
# Unit test for constructor of class Task
def test_Task():
    def function(resolve):
        resolve(1)

    assert Task(function).fork(reject=None, resolve=lambda x: x) == 1


# Generated at 2022-06-24 00:40:01.224832
# Unit test for method bind of class Task
def test_Task_bind():
    Task.of(1).bind(
        lambda value: Task.of(value + 1)
    ).fork(
        value=lambda value: print(value),
        resolve=lambda value: print(value)
    )

# Generated at 2022-06-24 00:40:03.543899
# Unit test for constructor of class Task

# Generated at 2022-06-24 00:40:08.790969
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map function of class Task.

    :return: None
    """
    task = Task.of(1)
    # If success must return resolved Task of value 2
    assert task.map(lambda x: x + 1).fork(lambda err: None, lambda value: value) == 2

    # If failure must return rejected Task
    assert task.map(lambda x: None if x == 1 else x + 1).fork(
        lambda err: err, lambda value: None) == 1



# Generated at 2022-06-24 00:40:11.347766
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x : x + 1).fork(lambda x: x, lambda x: x) == 2
    assert Task.reject(2).map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-24 00:40:14.525688
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task.
    Fork function must return value during calling with resolve and reject callable arguments.

    :return: True if test is successful
    :rtype: bool
    """
    test_value = 3
    result = Task(lambda _, resolve: resolve(test_value)).fork(lambda e: e, lambda v: v)
    return test_value == result



# Generated at 2022-06-24 00:40:19.081709
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve('Hello')

    assert Task(fork).fork(None, lambda x: x) == 'Hello'


# Generated at 2022-06-24 00:40:22.045857
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(1).bind(lambda value: Task.of(value + 1)).fork(
        lambda reason: "reject",
        lambda value: "resolve: " + str(value)
    )
    assert result == "resolve: 2"



# Generated at 2022-06-24 00:40:24.134062
# Unit test for method bind of class Task
def test_Task_bind():

    def fn(value):
        return Task.of(value * 2)

    task = Task.of(3)
    assert task.bind(fn).fork(lambda a: None, lambda arg: arg) == 6

# Generated at 2022-06-24 00:40:27.646593
# Unit test for constructor of class Task
def test_Task():
    def test_fork(reject, resolve):
        return Null

    assert_equal(Task(test_fork).fork(reject=Null, resolve=Null), Null)



# Generated at 2022-06-24 00:40:35.480090
# Unit test for method bind of class Task
def test_Task_bind():
    rejected = Task.reject("rejected")
    asserted = Task.of("resolved")
    task = Task.of("value").bind(lambda arg: rejected if arg == "value" else asserted)
    assert task.fork(lambda arg: arg, lambda _: ...) == "rejected"
    assert task.fork(lambda _: ..., lambda arg: arg) == "resolved"


# Generated at 2022-06-24 00:40:42.803854
# Unit test for method bind of class Task
def test_Task_bind():
    def task_reject(err):
        return Task.reject(err)

    def task_resolve(value):
        return Task.of(value)

    def task_error(value):
        return Task.of('Error {0}'.format(value))

    def task_mapper(value):
        return Task.of(value + '-mapped')

    def task_mapper_error(value):
        return Task.of('{0}-error-mapped'.format(value))

    def task_reducer(value):
        return Task.of(value + '-reducer')

    def task_reducer_error(value):
        return Task.of('{0}-reducer-error'.format(value))

    assert Task.of('test')\
        .bind(task_mapper)\
        .fork

# Generated at 2022-06-24 00:40:50.889646
# Unit test for method map of class Task
def test_Task_map():
    def test1():
        def fn(value):
            return value * 2

        return Task.of(2).map(fn)

    def test2():
        return Task.of(2).map(lambda value: value)

    def test3(value):
        return Task.of(value).map(str)

    def test4():
        def fn(value):
            if value == 5:
                raise Exception("Value is 5")
            return value * 2

        def checked_fn(value):
            if value == 5:
                return Task.reject("Value is 5")
            return Task.of(value * 2)

        return Task.of(2).map(fn) \
            .map(lambda value: assert_equal(value, 4)) \
            .map(lambda value: 5) \
            .bind(checked_fn)

# Generated at 2022-06-24 00:40:56.718845
# Unit test for method map of class Task
def test_Task_map():
    def add_one(x):
        return x + 1

    def minus_one(x):
        return x - 1

    # Task[int]
    task = Task.of(1)

    # Task[int]
    task_map_int = task.map(add_one)

    # Task[Task[int]]
    task_map_Task_int = task.map(lambda x: Task.of(x + 1))

    # Task[Task[int]]
    task_map_Task_int_map_Task_int = task.map(lambda x: Task.of(x + 1)).map(lambda x: Task.of(x + 1))

    # Task[int]

# Generated at 2022-06-24 00:40:58.890440
# Unit test for constructor of class Task
def test_Task():
    """
    Task is data-type for handle functions.
    """
    mock_reject = Mock()
    mock_resolve = Mock()

    task = Task(mock_reject)
    task.fork(mock_reject, mock_resolve)

    mock_reject.assert_called_once_with(mock_reject)
    mock_resolve.assert_called_once_with(mock_reject)


# Generated at 2022-06-24 00:41:03.901966
# Unit test for method bind of class Task
def test_Task_bind():
    def task_of_test(test_value):
        return Task.of(test_value)

    def run_test(test_value):
        def run(reject, resolve):
            assert(test_value == resolve)

        return Task(run)

    value = 1
    Task.reject(value) \
        .bind(task_of_test) \
        .bind(run_test)


# Generated at 2022-06-24 00:41:08.308051
# Unit test for method map of class Task
def test_Task_map():
    """
    >>> task = Task.of(1).map(lambda value: value + 1)

    >>> task.fork(
    ...     lambda arg: print('Reject'),
    ...     lambda arg: print('Resolve with value: {}'.format(arg))
    ... )
    Resolve with value: 2
    """


# Generated at 2022-06-24 00:41:15.674613
# Unit test for method bind of class Task
def test_Task_bind():
    result = Task.of(1).bind(lambda x: Task.of(x + 1)).fork(raise_error, lambda _: None)
    assert result == 2

    result = Task.of(1)\
                 .bind(lambda x: Task.of(x + 1))\
                 .bind(lambda x: Task.of(x + 1))\
                 .fork(raise_error, lambda _: None)
    assert result == 3


# Generated at 2022-06-24 00:41:27.224769
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Check Task.bind for success and failed case.
    """
    def not_empty(x):
        if x == 'failed':
            return Task.reject(x)
        return Task.of(x * 10)

    assert Task([1, 2, 3, 4, 'failed']) \
        .map(lambda x: x[4]) \
        .bind(not_empty) \
        .fork(lambda x: x, lambda _: None) == 'failed'

    assert Task([1, 2, 3, 4, 'success']) \
        .map(lambda x: x[4]) \
        .bind(not_empty) \
        .fork(lambda _: None, lambda x: x) == 'successsuccesssuccesssuccesssuccess'


# Generated at 2022-06-24 00:41:34.339349
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task::map

    Test:
        load data from some resource and process it
        Test expects that resource will return "I am the walrus"
        and that processor will return "I am the walrus"
    """
    def resource():
        """
        resource

        :returns: "I am the walrus"
        :rtype: String
        """
        return Task.of('I am the walrus')

    def processor(value):
        """
        processor

        :returns: "I am the walrus"
        :rtype: String
        """
        return value

    assert resource().map(processor).fork(
        lambda arg: None,
        lambda arg: arg
    ) == 'I am the walrus'


# Generated at 2022-06-24 00:41:39.076296
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of Task class
    """
    task = Task(lambda reject, resolve: resolve('hello'))
    assert isinstance(task, Task)
    assert task.fork('reject', 'resolve') == 'resolve'('hello')
