

# Generated at 2022-06-24 00:31:35.170035
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(0, lambda value: value) == 1
    assert Task.reject(1).fork(lambda value: value, 0) == 1


# Generated at 2022-06-24 00:31:37.629363
# Unit test for constructor of class Task
def test_Task():
    t = Task.of(2)
    assert t.fork(lambda arg: arg + 1, lambda arg: arg + 1) == 3

    t = Task.reject(2)
    assert t.fork(lambda arg: arg + 1, lambda arg: arg + 1) == 3


# Generated at 2022-06-24 00:31:43.261920
# Unit test for method bind of class Task
def test_Task_bind():
    print("test_Task_bind")

    # test function 1
    def t(x):
        return Task.of(x + 1)

    # test function 2
    def tt(x):
        return Task.of(x * 2)

    # test function 3
    def ttt(x):
        return Task.of(x ** 2)

    # test function
    def test(x):
        return Task.of(x)

    # test of method bind with test function 1
    assert Task.of(3).bind(t).fork(None, lambda resolve: resolve == 4)

    # test of method bind with test function 2
    assert Task.of(3).bind(tt).fork(None, lambda resolve: resolve == 6)

    # test of method bind with test function 2

# Generated at 2022-06-24 00:31:49.098960
# Unit test for method map of class Task
def test_Task_map():
    """
    Test that map of Task work as expected.
    """
    task_1 = Task.of('test')
    task_2 = task_1.map(lambda arg: arg + '_mapped')
    assert task_2.fork(str, None) == task_1.fork(str, None) + '_mapped'


# Generated at 2022-06-24 00:31:51.558995
# Unit test for constructor of class Task
def test_Task():
    """Test that constructor of class Task is working."""
    def fork_fn():
        return "task"

    task = Task(fork_fn)

    assert isinstance(task, Task)
    assert task.fork == fork_fn


# Generated at 2022-06-24 00:31:55.459197
# Unit test for method map of class Task
def test_Task_map():
    def f(x):
        return x

    def fork_mock(reject, resolve):
        return resolve(1)

    task = Task(fork_mock)

    assert task.map(f).fork(None, lambda x: x + 1) == 2


# Generated at 2022-06-24 00:32:01.817917
# Unit test for constructor of class Task
def test_Task():
    # OK
    fork_arg_1 = lambda _, r: r(1)
    fork_arg_2 = lambda _, r: r(2)
    task_1 = Task(fork_arg_1)
    assert task_1.fork == fork_arg_1

    task_2 = Task(fork_arg_2)
    assert task_2.fork == fork_arg_2

    # Error
    try:
        Task(10)
    except TypeError as err:
        assert err



# Generated at 2022-06-24 00:32:07.419434
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method map of class Task
    """
    def add(number):
        return number + 10

    def map_test(resolve, _):
        resolve(10)

    def map_test_2(resolve, _):
        resolve(10)

    task = Task(map_test)
    task_2 = Task(map_test_2)
    assert task_2.map(add).fork(lambda _: None, lambda arg: arg) == task.map(add).fork(lambda _: None, lambda arg: arg)


# Generated at 2022-06-24 00:32:14.476369
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Call with two task.
    Expect to get Task with resolve function, which call resolve function with next value.
    """
    def get_next_Task(number):
        return Task.of(number + 1)

    assert Task.of(1).bind(get_next_Task).fork(None, lambda x: x) == 2


# Generated at 2022-06-24 00:32:17.507819
# Unit test for constructor of class Task
def test_Task():
    assert repr(Task(lambda _, __: __)) == 'Task(lambda _, __: __)'


# Generated at 2022-06-24 00:32:19.946199
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(
        lambda err: err,
        lambda value: value
    ) == 2


# Generated at 2022-06-24 00:32:23.893897
# Unit test for constructor of class Task
def test_Task():
    """
    Create defined Task instances.
    """
    # Task with resolve and reject functions
    Task(lambda reject, resolve: resolve('v'))

    # Task of value
    Task.of('v')

    # Rejected Task
    Task.reject('v')


# Generated at 2022-06-24 00:32:27.704779
# Unit test for method bind of class Task
def test_Task_bind():
    # Test success value
    assert isinstance(Task.of(1).bind(lambda val: Task.of(val+2)), Task)
    # Test error value
    assert isinstance(Task.reject(1).bind(lambda val: Task.reject(val+2)), Task)



# Generated at 2022-06-24 00:32:30.071890
# Unit test for constructor of class Task
def test_Task():
    # Check that instance of Task created without errors
    assert Task(lambda _: 0)



# Generated at 2022-06-24 00:32:35.481569
# Unit test for method map of class Task
def test_Task_map():
    # Setup
    @Task
    def fork(reject, resolve):  # pylint: disable=W0613
        return resolve(5)

    fn_2x = lambda x: 2 * x

    # Run
    mapped_Task = fork.map(fn_2x)

    # Assert
    assert mapped_Task.fork(lambda reject: reject, lambda resolve: resolve) == 10


# Generated at 2022-06-24 00:32:38.232688
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda a: a + 1).fork(lambda a: 1, lambda a: a) == 2



# Generated at 2022-06-24 00:32:42.856252
# Unit test for method map of class Task
def test_Task_map():
    tested = None

    def fork(reject, resolve):
        return resolve(1)

    def mapper(arg):
        return arg * 2

    result = Task(fork).map(mapper)

    def test_fork(reject, resolve):
        nonlocal tested
        tested = resolve(mapper(1))

    result.fork(None, test_fork)
    assert tested == 2


# Generated at 2022-06-24 00:32:52.907587
# Unit test for method bind of class Task
def test_Task_bind():
    def assert_true(bol):
        if not bol:
            raise AssertionError

    def pass_test():
        return Task.of(None)

    def fail_test():
        return Task.reject(None)

    def test_result_task():
        return Task.of(None)

    def initial_task(arg):
        return Task.of(arg)

    def use_result_task_1(arg):
        return Task.of(arg).bind(lambda _: test_result_task())

    def use_result_task_2(arg):
        return Task.of(arg).bind(lambda _: use_result_task_1(arg))

    def use_result_task_3(arg):
        return Task.of(arg).bind(lambda _: use_result_task_2(arg))

   

# Generated at 2022-06-24 00:32:57.556717
# Unit test for method bind of class Task
def test_Task_bind():
    def reject(value):
        pass

    def resolve(value):
        return value

    def count_to_two(resolve, reject):
        resolve(0)
        resolve(1)
        resolve(2)

    called = []

    def fn(value):
        called.append(value)
        return Task.reject(value)

    task = Task(count_to_two)
    task.bind(fn).fork(reject, resolve)

    eq_(called, [0])

# Generated at 2022-06-24 00:33:07.696107
# Unit test for method bind of class Task
def test_Task_bind():
    # reject case
    assert Task.reject(5).bind(lambda x: Task.of(x * 2)).fork(lambda a: a, lambda b: b) == 5
    assert Task.reject(0).bind(lambda x: Task.of(x * 2)).fork(lambda a: a, lambda b: b) == 0
    assert Task.reject(2).bind(lambda x: Task.of(x * 2)).fork(lambda a: a, lambda b: b) == 2

    # resolve case
    assert Task.of(5).bind(lambda x: Task.of(x * 2)).fork(lambda a: a, lambda b: b) == 10
    assert Task.of(0).bind(lambda x: Task.of(x * 2)).fork(lambda a: a, lambda b: b) == 0

# Generated at 2022-06-24 00:33:16.788394
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map() must be callable and return correct value
    """
    # success path
    # of returns resolved Task with placeholder value

# Generated at 2022-06-24 00:33:21.121805
# Unit test for method map of class Task
def test_Task_map():
    def map_inc(task):
        return task.map(lambda el: el + '_map')

    task = Task.of('inc')
    assert(task.fork(lambda el: el + '_fork', lambda el: el + '_resolve') == 'inc_resolve')
    assert(map_inc(task).fork(lambda el: el + '_fork', lambda el: el + '_resolve') == 'inc_map_resolve')
    assert(task.fork(lambda el: el + '_fork', lambda el: el + '_resolve') == 'inc_resolve')


# Generated at 2022-06-24 00:33:24.745597
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of('hey').map(lambda x: x + '!').bind(lambda x: Task.of(x + '?')).fork(
        lambda x: x, lambda x: x
    ) == 'hey!?'


# Generated at 2022-06-24 00:33:26.481332
# Unit test for constructor of class Task
def test_Task():
    """Test Task constructor."""
    def fork(reject, resolve):
        resolve(2)

    task = Task(fork)
    assert task.fork == fork


# Generated at 2022-06-24 00:33:28.633716
# Unit test for method map of class Task
def test_Task_map():
    double = Task.of(2)
    func = lambda value: value * 2

    assert isinstance(double.map(func), Task)
    assert double.map(func).fork(lambda x: None, lambda x: x) == 4


# Generated at 2022-06-24 00:33:39.077762
# Unit test for method bind of class Task
def test_Task_bind():
    def mock_reject(value):
        return 'rejected: ' + str(value)

    def mock_resolve(value):
        return 'resolved: ' + str(value)


# Generated at 2022-06-24 00:33:42.474913
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value * 2

    assert Task.of(2).map(mapper).fork(lambda _: False, lambda x: x == 4)


# Generated at 2022-06-24 00:33:53.815103
# Unit test for method map of class Task
def test_Task_map():
    def test_map_success():
        """
        Test map method for success case.
        """
        def identity(arg):
            return arg

        # Test with map method
        task = Task.of(1)
        task.map(identity).fork(lambda x: None, lambda x: x)

        # Test without map
        mapped = Task(lambda _, resolve: resolve(identity(1)))
        mapped.fork(lambda x: None, lambda x: x)

    def test_map_error():
        """
        Test map method for error case.
        """
        def identity(arg):
            return arg

        # Test with map method
        task = Task.reject(1)
        task.map(identity).fork(lambda x: x, lambda x: None)

        # Test without map

# Generated at 2022-06-24 00:34:00.320260
# Unit test for method map of class Task
def test_Task_map():
    def adder(x):
        return x + 1

    def add2(x):
        return Task.of(x + 2)

    assert Task.of(23).map(adder).fork(None, identity) == 24
    assert Task.reject(23).map(adder).fork(identity, None) == 23
    assert Task.of(42).bind(add2).fork(None, identity) == 44
    assert Task.reject(42).bind(add2).fork(identity, None) == 42


# Generated at 2022-06-24 00:34:04.451359
# Unit test for method bind of class Task
def test_Task_bind():
    res_Task = Task.of(10) \
        .bind(lambda x: Task.of(x + 10)) \
        .bind(lambda x: Task.of(x + 10))

    assert res_Task.fork(lambda x: x, lambda x: x) == 30, 'test_Task_bind is broken'



# Generated at 2022-06-24 00:34:06.150958
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(lambda a: 0, lambda a: a) == 2


# Generated at 2022-06-24 00:34:17.417615
# Unit test for method bind of class Task
def test_Task_bind():
    def reject_to_one(_):
        return Task.of(1)

    def reject_to_two(_):
        return Task.of(2)

    def reject_to_three(_):
        return Task.of(3)

    def reject_to_typeerror(_):
        return Task.reject(TypeError('type error'))

    def reject_to_valueerror(_):
        return Task.reject(ValueError('value error'))

    def reject_to_lasttypeerror(_):
        return Task.reject(TypeError('type error'))

    spec = Spec(Task)


# Generated at 2022-06-24 00:34:19.572974
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)).map(lambda value: value * 2).fork(lambda _: None, lambda _: None) == 2


# Generated at 2022-06-24 00:34:27.167134
# Unit test for method bind of class Task
def test_Task_bind():
    def add(n):
        def result(x):
            return x + n

        return Task.of(result)

    def mul(n):
        def result(x):
            return x * n

        return Task.of(result)

    def div(n):
        def result(x):
            return x / n

        return Task.of(result)

    assert Task.of(5).bind(add(10)).map(lambda f: f(5)).fork(None, lambda x: x) == 20
    assert Task.of(5).bind(add(10).bind(mul(2))).map(lambda f: f(5)).fork(None, lambda x: x) == 30

# Generated at 2022-06-24 00:34:29.390799
# Unit test for method map of class Task
def test_Task_map():
    def resolve(value):
        assert value == 2
    Task.of(1).map(lambda value: value + 1).fork(lambda error: None, resolve)


# Generated at 2022-06-24 00:34:32.497073
# Unit test for constructor of class Task
def test_Task():
    """
    Test, that constructor of Task return
    Lazy evaluated object, that not call any function
    """
    executed = []

    def fork(reject, resolve):
        executed.append('fork')

    task = Task(fork)
    expected = ['fork']

    assert executed == expected, \
        'Task(fork) must not call fork function, '\
        'but call it with {}'.format(repr(executed))


# Generated at 2022-06-24 00:34:42.694166
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for method bind of class Task.
    """
    value = Task.of(5)
    # -5
    value = value.bind(lambda arg: Task.reject(arg + 2))
    # -8
    value = value.bind(lambda arg: Task.reject(arg + 3))

    def fork_handler(reject, resolve):
        """
        Handler for value Task.
        """
        def reject_handler(arg):
            """
            Handler for reject attribute of Task.
            """
            assert arg == -8
            print("Test is passed")

        def resolve_handler(arg):
            """
            Handler for resolve attribute of Task.
            """
            assert arg == -5
            print("Test is passed")

        return value.fork(reject_handler, resolve_handler)

    value.fork

# Generated at 2022-06-24 00:34:47.752941
# Unit test for method map of class Task
def test_Task_map():
    def task_of(value):
        return Task.of(value)

    def mapper(mapped_value):
        return mapped_value

    task = task_of(1)
    assert task.map(mapper) == task_of(1)

    task = task_of(0)
    assert task.map(mapper) == task_of(0)


# Generated at 2022-06-24 00:34:51.056634
# Unit test for constructor of class Task
def test_Task():
    value = 10
    task = Task.of(value)
    assert task.fork(lambda _: None, lambda v: v) == value

    value = 10
    task = Task.reject(value)
    assert task.fork(lambda v: v, lambda _: None) == value


# Generated at 2022-06-24 00:34:53.957287
# Unit test for method map of class Task
def test_Task_map():
    def take(value):
        return value

    def expect(value):
        return value

    def test(value):
        assert take(Task.of(value).map(value)) == expect(value)

    test(5)
    test('5')
    test(None)


# Generated at 2022-06-24 00:34:58.119568
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        if not resolve.im_class == Task:
            reject(AssertionError(
                "Incorrect type of resolve argument: {}".format(resolve.im_class)
            ))
        if not reject.im_class == Task:
            reject(AssertionError(
                "Incorrect type of reject argument: {}".format(reject.im_class)
            ))
        resolve.im_self.observer.next(1)
        resolve.im_self.observer.complete()

    task = Task(fork)
    assert task.fork == fork



# Generated at 2022-06-24 00:35:02.602520
# Unit test for method map of class Task
def test_Task_map():
    def get_user_data(username):
        time.sleep(1)
        return username

    def set_user_data(data):
        time.sleep(1)
        return "trung"

    assert Task.of(get_user_data('trung')).map(set_user_data).fork(None, lambda res: res) == "trung"


# Generated at 2022-06-24 00:35:10.121488
# Unit test for method map of class Task
def test_Task_map():
    def square(value):
        return value * value

    def assert_equal(a, b):
        assert a == b, "Error message: {0} is not equal {1}".format(a, b)

    assert_equal(Task.of(2).map(square).fork(None, square), 4)
    assert_equal(Task.of(2).map(square).fork(square, None), 4)
    assert_equal(Task.reject(2).map(square).fork(square, None), 4)
    assert_equal(Task.reject(2).map(square).fork(square, square), 4)


# Generated at 2022-06-24 00:35:11.388426
# Unit test for constructor of class Task
def test_Task():
    assert type(Task(lambda _, __: __(0))) == Task


# Generated at 2022-06-24 00:35:13.043692
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(1))
    assert task.fork(lambda a: a, lambda a: a) == 1, \
        "Task was not created correctly"


# Generated at 2022-06-24 00:35:15.706946
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for map method of class Task.
    """
    task = Task.of(1)

    assert task.map(lambda arg: arg + 1).fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-24 00:35:23.314125
# Unit test for method map of class Task
def test_Task_map():
    """
    Take two functions (resolve and reject) and return None. This is helper for test Task.map
    method.

    :param resolve: resolve function for Task
    :type resolve: Function(value)
    :param reject: reject function for Task
    :type reject: Function(value)
    :returns: None
    :rtype: NoneType
    """
    def inner_task(resolve, reject):
        resolve(42)

    def test_map(resolve, reject):
        Task(inner_task)\
            .map(lambda num: num * 2)\
            .map(lambda num: "Number: {}".format(num))\
            .map(resolve)


# Generated at 2022-06-24 00:35:25.792676
# Unit test for method map of class Task
def test_Task_map():
    def mapper(value):
        return value * 2


# Generated at 2022-06-24 00:35:31.329588
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)
        return 1

    task = Task(fork)
    assert isinstance(task, Task), 'Task instance should be instance of class Task'
    assert hasattr(task, 'fork'), 'Task instance should has fork method'
    assert task.fork(lambda x: x, lambda x: x) == 1, 'Task should return 1 after fork'


# Generated at 2022-06-24 00:35:33.280711
# Unit test for constructor of class Task
def test_Task():
    assert isinstance(Task(lambda _, resolve: resolve(0)), Task)



# Generated at 2022-06-24 00:35:40.620441
# Unit test for constructor of class Task
def test_Task():
    def fork_func(_, resolve):
        resolve('test')

    def fork_func_with_error(reject, _):
        reject('test')


# Generated at 2022-06-24 00:35:51.241108
# Unit test for method bind of class Task
def test_Task_bind():
    def get_value():
        return Task.of(3)

    def add_one(value):
        return Task.of(value + 1)

    def error_value():
        return Task.reject('error')

    assert Task.of(3).bind(get_value).fork(None, lambda value: value) == 3
    assert Task.reject('error').bind(get_value).fork(
        lambda value: value,
        None
    ) == 'error'
    assert Task.of(3).bind(add_one).fork(None, lambda value: value) == 4
    assert Task.of(3).bind(error_value).fork(
        lambda value: value,
        None
    ) == 'error'

if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-24 00:35:54.970174
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        resolve('value')

    wrapped = Task(fork)

    fn = lambda x: 'mapped ' + x

    mapped = wrapped.map(fn)

    assert mapped.fork(lambda x: x, lambda x: x) == "mapped value"

# Generated at 2022-06-24 00:36:01.387330
# Unit test for method map of class Task
def test_Task_map():
    @task
    def square_plus(x):
        return (yield Task(lambda r, s: s(x ** 2 + 1)))
    # task_resolved = Task.of(1)
    # task_resolved.fork(print, print)
    # task_mapped = task_resolved.map(lambda x: x ** 2 + 1)
    # task_mapped.fork(print, print)
    # square_plus(1).fork(print, print)
    # square_plus(1).fork(print, print)
    # square_plus(2).fork(print, print)
    #
    # @task
    # def square_plus(x):
    #     squared = (yield Task(lambda r, s: s(x ** 2)))
    #     return (yield Task(lambda r, s:

# Generated at 2022-06-24 00:36:09.816377
# Unit test for method bind of class Task
def test_Task_bind():
    def test_1(): return Task.of(1)
    def test_2(): return Task.of(2)
    def test_3(): return Task.of(3)

    def increment(value): return 1 + value
    def mul(value): return 2 * value

    assert Task.of(0) \
        .bind(test_1) \
        .bind(test_2) \
        .bind(test_3) \
        .map(increment) \
        .map(mul) \
        .fork(lambda err: 0, lambda value: value) == 9

# Generated at 2022-06-24 00:36:14.823895
# Unit test for constructor of class Task
def test_Task():
    # The result of call fork function should be equal to 3.
    assert Task(lambda _, resolve: resolve(3)).fork(lambda _: None, lambda x: x) == 3


# Generated at 2022-06-24 00:36:18.342223
# Unit test for constructor of class Task
def test_Task():
    def fork(*args):
        pass

    a = Task(fork)
    b = Task.of(2333)
    c = Task.reject(404)
    assert a.fork == fork
    assert b.fork.func_closure[1].cell_contents == 2333
    assert c.fork.func_closure[2].cell_contents == 404


# Generated at 2022-06-24 00:36:25.774724
# Unit test for method map of class Task
def test_Task_map():
    """
    Test Task.map method

    :returns: None
    :rtype: None
    """
    assert Task.of(1).map(lambda _: _+1).fork(
        lambda _: None,
        lambda arg: arg
    ) == 2

    with pytest.raises(Exception):
        Task.reject(None).map(
            lambda _: 'mapped value'
        ).fork(
            lambda _: 'rejected value',
            lambda arg: arg
        ) == 'rejected value'



# Generated at 2022-06-24 00:36:30.307810
# Unit test for method map of class Task
def test_Task_map():
    value = Task.of(2)
    assert value.fork(lambda x: '{}'.format(x), lambda x: x) == 2

    mapped_value = value.map(lambda x: x * 2)
    assert mapped_value.fork(lambda x: '{}'.format(x), lambda x: x) == 4


# Generated at 2022-06-24 00:36:37.352398
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(2).bind(
        lambda _: Task.reject(1)
    ).fork(
        lambda err: err,
        lambda res: res
    ) == Task.of(1).fork(
        lambda err: err,
        lambda res: res
    )

    assert Task.of(2).bind(
        lambda _: Task.reject(1)
    ).fork(
        lambda err: err,
        lambda res: res
    ) == 1


# Generated at 2022-06-24 00:36:43.277670
# Unit test for method map of class Task
def test_Task_map():
    """
    :returns: result of unit test
    :rtype: Tuple[Bool, String]
    """

    def plus_10(arg):
        return arg + 10

    task = Task(lambda reject, resolve: resolve(1))

    assert task.map(plus_10).fork(
        lambda arg: arg,
        lambda arg: arg,
    ) == 11

    task = Task(lambda reject, resolve: reject('error'))

    assert task.map(plus_10).fork(
        lambda arg: arg,
        lambda arg: arg,
    ) == 'error'

    return True, 'Task map OK'


# Generated at 2022-06-24 00:36:48.829842
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(1).bind(lambda value: Task.of(value + 2)).fork(
        raise_error,
        lambda value: value
    ) == 3

    assert Task.reject(1).bind(lambda value: Task.reject(value + 2)).fork(
        lambda value: value,
        raise_error
    ) == 3



# Generated at 2022-06-24 00:36:55.623193
# Unit test for method map of class Task
def test_Task_map():
    error_msg = 'Test Task failed because result Task and expected value are not equal'
    expected_value = 'New Task Value'

    def fn(arg): return arg + ' New Task Value'
    Task = Task.of('Old Task Value')
    Task = Task.map(fn)

    def res(resolve, reject):
        return Task.fork(reject, resolve)

    assert Task.fork(lambda arg: arg, identity) == expected_value, error_msg


# Generated at 2022-06-24 00:37:01.914927
# Unit test for method bind of class Task
def test_Task_bind():
    def f(x):
        return Task.of(x + '1')

    task_A = Task.of('A')
    task_AB = task_A.bind(f).fork(
        lambda x: 'error: ' + x,
        lambda x: 'success: ' + x
    )

    assert task_AB == 'success: A1'

# Generated at 2022-06-24 00:37:06.982880
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda e: 'error', lambda v: v) == 1
    assert Task.reject(1).fork(lambda e: e, lambda v: 'ok') == 1
    assert Task(lambda _, resolve: resolve(1)).fork(lambda e: 'error', lambda v: v) == 1


# Generated at 2022-06-24 00:37:09.814820
# Unit test for method map of class Task
def test_Task_map():
    def fn(arg):
        return arg + 1

    task = Task.of(10)
    result = task.map(fn)

    def assert_fn(_, resolve):
        assert resolve(11)

    result.fork(assert_fn)



# Generated at 2022-06-24 00:37:14.870707
# Unit test for method map of class Task
def test_Task_map():
    def double(arg):
        return arg * 2

    def add_two(arg):
        return arg + 2

    def double_add_two(arg):
        return add_two(double(arg))

    t = Task.of(1)
    assert t.fork(lambda x: x, lambda x: x) == 1

    # Test map with two functions
    t2 = t.map(double).map(add_two)
    assert t2.fork(lambda x: x, lambda x: x) == 4

    # Test map with one function
    t3 = t.map(double_add_two)
    assert t3.fork(lambda x: x, lambda x: x) == 4


# Generated at 2022-06-24 00:37:24.401429
# Unit test for method bind of class Task
def test_Task_bind():
    assert Task.of(2).bind(lambda x: Task.of(x + 2)).fork(
        lambda e: None,
        lambda r: r
    ) == 4

    assert Task.of(2).bind(lambda x: Task.of(x + 2)
                           .bind(lambda y: Task.of(y ** 2))) \
        .fork(lambda e: None,
              lambda r: r) == 16

    assert Task.reject(1) \
        .bind(lambda x: Task.of(x + 1)) \
        .fork(lambda e: e,
              lambda r: r) == 1

    assert Task.reject(1) \
        .bind(lambda x: Task.of(x + 2)) \
        .fork(lambda e: e,
              lambda r: r) == 1

# Unit test

# Generated at 2022-06-24 00:37:28.167487
# Unit test for constructor of class Task
def test_Task():
    """
    Test function for constructor of class Task
    """
    assert Task(lambda _, resolve: resolve(1)).fork(nop, assert_equal(1))
    assert Task(lambda reject, _: reject(1)).fork(assert_equal(1), nop)



# Generated at 2022-06-24 00:37:30.931788
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda x: None, lambda x: x) == 1
    assert Task.reject(1).fork(lambda x: x, lambda x: None) == 1


# Generated at 2022-06-24 00:37:33.824842
# Unit test for constructor of class Task
def test_Task():
    """
    Test that constructor of Task correctly create instance with stored attribute.
    """
    # Test for creation
    assert Task('test')
    # Test that stored attribute is correct
    assert Task('test').fork == 'test'


# Generated at 2022-06-24 00:37:40.185869
# Unit test for method bind of class Task
def test_Task_bind():
    # check behavior for reject
    reject = lambda x: x
    reject_called = [False]
    def reject(value):
        reject_called[0] = True
        return reject(value)

    resolve = lambda x: x
    resolve_called = [False]
    def resolve(value):
        resolve_called[0] = True
        return resolve(value)

    Task.reject(666).bind(lambda x: Task.reject(777)).fork(reject, resolve)
    assert reject_called == [True]
    assert resolve_called == [False]

    # check behavior for resolve
    reject = lambda x: x
    reject_called = [False]
    def reject(value):
        reject_called[0] = True
        return reject(value)

    resolve = lambda x: x

# Generated at 2022-06-24 00:37:44.785529
# Unit test for method map of class Task
def test_Task_map():
    def add_one(value):
        return value + 1

    def resolve(value):
        return

    def reject(value):
        return

    task = Task.of(5)
    assert isinstance(task.map(add_one), Task)
    assert task.fork(reject, resolve) is None
    task.map(add_one).fork(reject, resolve) is None


# Generated at 2022-06-24 00:37:47.356760
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).resolve(
        lambda _: 'correct',
        lambda _: 'incorrect'
    ) == 'correct'

    assert Task.of(1).map(lambda x: x + 1).resolve(
        lambda x: 'correct' if x == 2 else 'incorrect',
        lambda _: 'incorrect'
    ) == 'correct'


# Generated at 2022-06-24 00:37:53.251727
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map method of Task class
    """
    def mapper(arg):
        return arg + 1

    task_1 = Task.of(1)
    task_2 = task_1.map(mapper)
    task_3 = task_2.map(mapper)
    task_4 = task_3.map(mapper)

    assert task_2.fork(lambda x: None, lambda x: x) == 2
    assert task_3.fork(lambda x: None, lambda x: x) == 3
    assert task_4.fork(lambda x: None, lambda x: x) == 4


# Generated at 2022-06-24 00:38:03.140057
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test for Task bind method.
    """
    def mapper(value):
        return Task.of(value * 2)

    def reject_mapper(value):
        return Task.reject(value * 2)

    def side_effect(value):
        side_effect.called = True
        return value

    def assert_bind(value):
        assert value == (10 * 2)

    side_effect.called = False
    task = Task.of(10).bind(mapper).bind(side_effect).map(lambda x: x / 2)

    task.fork(lambda _: None, assert_bind)
    assert side_effect.called


    assert_bind.called = False

# Generated at 2022-06-24 00:38:07.583207
# Unit test for method bind of class Task
def test_Task_bind():
    called = False
    def fn(value):
        nonlocal called
        called = True
        assert value == 'value'

    task = Task.of('value').bind(lambda arg: Task.of(fn(arg)))
    task.fork(lambda arg: None, lambda arg: None)
    assert called


# Generated at 2022-06-24 00:38:10.572734
# Unit test for method map of class Task
def test_Task_map():
    assert Task(lambda _, resolve: resolve(1)).map(lambda value: value + 1).fork(
        lambda _: "reject", lambda value: value
    ) == 2

if __name__ == '__main__':
    test_Task_map()

# Generated at 2022-06-24 00:38:16.630847
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Try to create simple Task with binded second Task.
    """
    def inner(reject, resolve):
        resolve('Inside Task')

    main = Task(lambda reject, resolve: resolve('Outside Task'))
    inner = Task(inner)

    result = main.bind(lambda arg: inner).fork(
        lambda arg: print('Reject: {0}'.format(arg)),
        lambda arg: print('Resolve: {0}'.format(arg))
    )


# Generated at 2022-06-24 00:38:27.587577
# Unit test for method bind of class Task
def test_Task_bind():
    # Create mock object to handle result of fork
    result = mock.Mock()

    # Create mock object to handle result of Task#bind with Task.of
    result2 = mock.Mock()

    # Create mocked Task object with fork, which accept mocked functions in argument
    result3 = mock.Mock()
    mocked_task = Task(result.fork)

    # Call mocked Task object with new mocked Task and mocked function
    result4 = mock.Mock()
    Task(result4.fork).bind(result2.fn)(1, 2)

    # Mocked function Task#bind, which accept mocked function and return mocked Task
    result5 = mock.Mock()
    Task(result5.fork).map(result2.fn)

    # Compare accepted arguments, which we called #bind

# Generated at 2022-06-24 00:38:31.398205
# Unit test for method map of class Task
def test_Task_map():
    """
    Task.map(fn) should return Task with mapped version of resolve attribute.
    """
    def run(resolve, reject):
        return resolve(0)
    def fn(value):
        return value + 1
    initial = Task(run)
    assert(initial.map(fn).fork(None, lambda arg: arg) == 1)


# Generated at 2022-06-24 00:38:34.595380
# Unit test for constructor of class Task
def test_Task():
    # Setup data
    value = 'foo'

    # Call constructor
    result = Task.of(value)

    # Check result
    def fn(reject, resolve):
        assert value == resolve(value)
    result.fork(fn, fn)


# Generated at 2022-06-24 00:38:35.338413
# Unit test for constructor of class Task
def test_Task():
    assert Task(None)


# Generated at 2022-06-24 00:38:39.669137
# Unit test for constructor of class Task
def test_Task():
    """
    Test task constructor.
    """
    def result(_, resolve):
        return resolve(42)

    try:
        Task(result)
    except:
        print('Test for Task constructor is failed')
        return

    print('Test for Task constructor is passed')


# Generated at 2022-06-24 00:38:44.066182
# Unit test for method bind of class Task
def test_Task_bind():
    def test_error_handle(value):
        return Task.of(value * 2)

    def task_error_handle(_, resolve):
        return resolve(2)

    task = Task(task_error_handle)
    result = task.bind(test_error_handle).fork(lambda arg: arg, lambda arg: arg)

    assert result == 4


# Generated at 2022-06-24 00:38:55.820917
# Unit test for method bind of class Task
def test_Task_bind():

    def f(reject, resolve):
        resolve(1)
        return None

    def f1(value):
        return Task.of(value + 1)

    def f2(value):
        return Task.of(value + 2)

    def f3(value):
        return Task.of(value + 3)

    def f4(value):
        return Task.of(value + 4)

    def f5(value):
        return Task.of(value + 5)

    def f6(value):
        return Task.of(value + 6)

    def f7(value):
        return Task.of(value + 7)

    def f8(value):
        return Task.of(value + 8)

    def f9(value):
        return Task.of(value + 9)


# Generated at 2022-06-24 00:38:59.644760
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject(Exception('Unexpected error'))
        resolve(True)

        return True

    assert isinstance(Task(fork), Task)


# Generated at 2022-06-24 00:39:05.338118
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor Task
    """
    resolve = None
    reject = None

    def fork(reject_, resolve_):
        reject = reject_
        resolve = resolve_

        return reject, resolve

    task = Task(fork)

    assert task.fork is fork


# Generated at 2022-06-24 00:39:14.804906
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Unit test for Task class bind method.
    """

    # Test for success processing with mapper
    def resolve_mapper(val):
        """
        Mapper function for resolve branch of testing bind.

        :param val: value for mapping
        :type val: Any
        """
        return val + ' world'

    def reject_mapper(val):
        """
        Mapper function for reject branch of testing bind.

        :param val: value for mapping
        :type val: Any
        """
        return val

    # Test for success branch
    bind_with_resolve(resolve_mapper)

    # Test for reject branch
    bind_with_reject(reject_mapper)


# Generated at 2022-06-24 00:39:19.403623
# Unit test for method map of class Task
def test_Task_map():
    def fn(x):
        return x + 1

    value = 1
    task = Task.of(value)

    def fork(reject, resolve):
        return resolve(value)

    assert task.fork(None, None) == fork(None, None)
    assert task.map(fn).fork(None, None) == fork(None, fn)


# Generated at 2022-06-24 00:39:27.556222
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Task.bind required for work with composed Task.
    """

    def compose_task(value):
        return Task.of(value + 1)

    result = Task.of(1).bind(compose_task).fork(lambda _: "dont_call", lambda arg: arg)
    assert result == 2
    assert Task.reject(1).bind(compose_task).fork(
        lambda arg: arg,
        lambda _: "dont_call",
    ) == 1

if __name__ == "__main__":
    test_Task_bind()

# Generated at 2022-06-24 00:39:34.566153
# Unit test for method bind of class Task
def test_Task_bind():
    print('Test case for Task.bind method:', end=' ')

    task_test = Task.of(1).bind(lambda x: Task.of(x * 10))


# Generated at 2022-06-24 00:39:40.711887
# Unit test for method map of class Task
def test_Task_map():
    def add_one_if_value_is_even(value):
        return value + 1 if value % 2 == 0 else value

    print(
        Task.of(0).map(add_one_if_value_is_even).fork(
            lambda e: e,
            lambda r: r,
        )
    )

    print(
        Task.of(1).map(add_one_if_value_is_even).fork(
            lambda e: e,
            lambda r: r,
        )
    )

# Unit tests for method bind of class Task

# Generated at 2022-06-24 00:39:48.813330
# Unit test for method map of class Task
def test_Task_map():
    """
    Test map that return new Task with mapped resolve function.
    """
    def f1(resolve, _):
        resolve(1)

    def f2(resolve, _):
        resolve(2)

    def f3(resolve, _):
        resolve(3)

    def g(value):
        return value + 1

    task = Task(f1)
    task2 = Task(f2)
    task3 = Task(f3)

    mapped_task = task.map(g)
    mapped_task2 = task2.map(g)
    mapped_task3 = task3.map(g)

    assert task.fork == f1
    assert task2.fork == f2
    assert task3.fork == f3

    assert mapped_task.fork != f1

# Generated at 2022-06-24 00:39:54.696216
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.reject(value)
    assert Task.of(1).bind(fn) == Task.reject(1)
    assert Task.reject(1).bind(fn) == Task.reject(1)



# Generated at 2022-06-24 00:39:58.625553
# Unit test for method map of class Task
def test_Task_map():
    task = Task(lambda rj, rs: rs(10))
    task = task.map(lambda x: x * 2)

    assert task.fork(print, print) == 20


# Generated at 2022-06-24 00:40:02.986486
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, b: b(12)).fork(
        lambda a: None,
        lambda a: a
    ) == 12

    assert Task(lambda _, b: b(12)).fork(
        lambda a: a,
        lambda a: None
    ) is None


# Generated at 2022-06-24 00:40:10.768314
# Unit test for constructor of class Task
def test_Task():

    # test Task of method
    print("test Task of method...")
    assert Task.of("foo").fork("bar", "baz") == "foo"
    assert Task.of("foo").fork("bar", "baz") == Task("foo").fork("bar", "baz")
    assert Task("foo").fork("bar", "baz") == Task("foo").fork("bar", "baz")
    assert Task("foo").fork("bar", "baz") != Task("bar").fork("bar", "baz")

    # test Task reject method
    print("test Task reject method...")
    assert Task.reject("foo").fork("bar", "baz") == "bar"
    assert Task.reject("foo").fork("bar", "baz") == Task("foo").fork("bar", "baz")

# Generated at 2022-06-24 00:40:14.875314
# Unit test for method map of class Task
def test_Task_map():
    def fn(arg):
        return arg * 2

    task = Task.of(2).map(fn)

    def result(reject, resolve):
        return resolve(4)

    assert task.fork == result


# Generated at 2022-06-24 00:40:19.769551
# Unit test for constructor of class Task
def test_Task():
    reject = lambda v: v
    resolve = lambda v: v

    fork = lambda reject, resolve: resolve(5)
    task = Task(fork)

    assert reject(task) == 5


# Generated at 2022-06-24 00:40:27.176695
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test to check bind method of class Task
    """
    class Test:
        """
        Class for testing methods of Task
        """

        @staticmethod
        def to_message(state):
            """
            Return message from state.
            Note:
                state is JSON string with fields:
                'message' - string for return

            :param state: state for resolve Task
            :type state: JSON
            :returns: message
            :rtype: str
            """
            return json.loads(state)['message']

    def handle_result(state):
        """
        Test to check bind method of class Task
        """
        assert Test.to_message(state) == Test.to_message(state_success)
        assert Test.to_message(state) != Test.to_message(state_error)

    state_

# Generated at 2022-06-24 00:40:32.533682
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """
    def test(resolve, reject):
        resolve(5)
    t = Task(test)
    t2 = t.map(lambda x: x + 1)
    assert t2.fork(lambda x: x, lambda x: x + 1) == 7


# Generated at 2022-06-24 00:40:36.677489
# Unit test for constructor of class Task
def test_Task():
    # Example
    assert Task.of(10).fork(lambda _: "rejected", lambda value: value) == 10
    assert Task.reject(20).fork(lambda value: value, lambda _: "rejected") == 20

    # Negative
    assert Task.of(10).fork(lambda _: "rejected", lambda value: value) != 20
    assert Task.of(20).fork(lambda _: "rejected", lambda value: value) != 10

    print("Task tests are passed")


# Generated at 2022-06-24 00:40:39.802612
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        nonlocal count
        count += 1
        resolve("result")

    count = 0
    value = "value"

    task = Task(fork)
    assert task.fork("value", lambda arg: arg) == value
    assert count == 1

# Generated at 2022-06-24 00:40:45.324683
# Unit test for constructor of class Task
def test_Task():
    def id(x):
        return x

    def task_handler(reject, resolve):
        return resolve(id)

    result = Task(task_handler)
    assert result.fork(None, None) == id


# Generated at 2022-06-24 00:40:49.766670
# Unit test for method bind of class Task

# Generated at 2022-06-24 00:40:52.026565
# Unit test for constructor of class Task
def test_Task():
    """
    >>> test = Task(lambda reject, resolve: resolve("ok"))
    >>> test.fork("reject", "resolve")
    'resolve'
    """


# Generated at 2022-06-24 00:40:56.031692
# Unit test for constructor of class Task
def test_Task():
    # Task(fork)
    assert isinstance(Task(lambda _, __: None), Task)


# Generated at 2022-06-24 00:41:03.996323
# Unit test for method map of class Task
def test_Task_map():
    def mapper(arg):
        return arg * 2

    # test value to store in task and expected value for test
    test_value = 2
    expected_value = test_value * 2

    # create task to test
    task = Task(lambda _, resolve: resolve(test_value)).map(mapper)

    # fork task

# Generated at 2022-06-24 00:41:14.616802
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of Task class

    Test when fork function call resolve
    Test when fork function call reject
    Test when fork function call both resolve and reject function
    """
    def resolve_call(value):
        """
        Test that fork function call resolve function

        :param value: value to store in Task
        :type value: A
        :returns: True if resolve function has been called, or False else
        :rtype: Boolean
        """
        call, _ = resolve_reject_call(value)
        return call.called and not _.called

    def reject_call(value):
        """
        Test that fork function call reject function

        :param value: value to store in Task
        :type value: A
        :returns: True if reject function has been called, or False else
        :rtype: Boolean
        """

# Generated at 2022-06-24 00:41:18.303726
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda x: x + 1).fork(lambda _: False, lambda x: x == 2)
    assert not Task.of(1).map(lambda x: x + 1).map(lambda x: x + 1).fork(lambda _: False, lambda x: x == 3)


# Generated at 2022-06-24 00:41:20.806166
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject

    t = Task(fork)

    return t.fork == fork


# Generated at 2022-06-24 00:41:26.774342
# Unit test for method map of class Task
def test_Task_map():
    assert (Task.of(1)
            .map(lambda x: x + 1)
            .map(lambda x: x * 2)
            .fork(lambda x: x, lambda x: x) == 4)
    assert (Task.of(1)
            .map(lambda x: x / 0)
            .fork(lambda x: x, lambda x: x) == 'Error: division by zero')


# Generated at 2022-06-24 00:41:34.358001
# Unit test for method bind of class Task
def test_Task_bind():
    def second_level_task(resolve):
        resolve("YO!")
        return "YO!"

    def fnc(value):
        return Task(second_level_task)

    class TaskTester(unittest.TestCase):
        def test_first_success_result(self):
            task = Task.of("TEST")
            new_task = task.bind(fnc)
            result = new_task.fork(lambda err: "error", lambda res: res)
            self.assertEqual(result, "YO!")

        def test_first_fail_result(self):
            task = Task.reject("TEST")
            new_task = task.bind(fnc)
            result = new_task.fork(lambda err: "error", lambda res: res)