

# Generated at 2022-06-24 00:31:42.011235
# Unit test for method bind of class Task
def test_Task_bind():
    def task_a():
        return Task(lambda _, resolve: resolve(1))

    def task_b(value):
        return Task(lambda _, resolve: resolve(value + 1))

    def task_c(value):
        return Task(lambda _, resolve: resolve(value > 0))

    expected = True
    actual = Task.of(1).bind(task_a).bind(task_b).bind(task_c).fork(lambda _: None, lambda value: value)

    assert actual == expected


# Generated at 2022-06-24 00:31:45.668993
# Unit test for constructor of class Task
def test_Task():
    assert_equal(Task, type(Task(lambda _, __: None)))


# Generated at 2022-06-24 00:31:51.758837
# Unit test for method map of class Task
def test_Task_map():
    def task_map_method():
        """
        Task map method test
        """

        # Function that return some value
        def double(value):
            return value * 2

        # Resolved Task with value 2
        task = Task.of(2)

        # Assert that mapped Task have attribute fork function that return 4
        assert task.map(double).fork(None, lambda arg: arg) == 4

        # Assert that mapped Task have attribute fork function that return 6
        assert task.map(lambda value: value + 2).fork(None, lambda arg: arg) == 4

    task_map_method()


# Generated at 2022-06-24 00:31:59.148328
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Call Task.of(5).bind(lambda value: Task.of(value * 2)).fork(..., ...)
    """
    def log_resolve(value):
        print(value)
        return value

    def log_reject(value):
        print(value)
        return value

    Task.of(5) \
        .bind(lambda value: Task.of(value * 2)) \
        .fork(log_reject, log_resolve)


if __name__ == '__main__':
    test_Task_bind()

# Generated at 2022-06-24 00:32:05.836538
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map

    Test data:
        * Task.of
        * lambda x: x + 1
    Expected: Task[2]
    """
    def test_task():
        """
        Return Task[Function(resolve, reject) -> 1]
        """
        return Task.of(1)

    def test_mapper(value):
        """
        Return value + 1
        """
        return value + 1

    assert Task.of(1).map(test_mapper).fork(None, lambda x: x) == 2 # True


# Generated at 2022-06-24 00:32:08.608126
# Unit test for method bind of class Task
def test_Task_bind():
    def map(a):
        def _map(b):
            return b + a

        return Task.of(2).map(_map)

    assert Task.of(1).bind(map).fork(lambda _: False, lambda result: result == 3)



# Generated at 2022-06-24 00:32:14.181937
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        def result(reject, resolve):
            return reject(value)
        return Task(result)

    task = Task.of(4).bind(mapper)
    print(task)

    # task.fork(lambda x: print(x), lambda x: print(x))


# Generated at 2022-06-24 00:32:18.299101
# Unit test for constructor of class Task
def test_Task():
    def _(resolve, reject):
        resolve("Task")

    task = Task(_)
    assert task.fork("Task", "") == "Task"


# Generated at 2022-06-24 00:32:19.270302
# Unit test for constructor of class Task
def test_Task():
    assert 1 == 2, 'Some unit tests failed!'

# Generated at 2022-06-24 00:32:27.705304
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(5)).fork(lambda _: None, lambda x: x) == 5
    assert Task(lambda _, resolve: resolve(5)).map(lambda x: x + 5).fork(lambda _: None, lambda x: x) == 10
    assert Task(lambda _, resolve: resolve(5)).bind(lambda x: Task.of(x + 5)).fork(lambda _: None, lambda x: x) == 10
    assert Task(lambda reject, _: reject(5)).bind(lambda x: Task.of(x + 5)).fork(lambda x: x, lambda _: None) == 5

# Test for methods of class Task

# Generated at 2022-06-24 00:32:28.487629
# Unit test for constructor of class Task
def test_Task():
    Task(None)

# Generated at 2022-06-24 00:32:36.064580
# Unit test for method bind of class Task
def test_Task_bind():
    def test1(arg):
        return Task.of(arg)

    def test2(arg):
        return Task.reject(arg)


# Generated at 2022-06-24 00:32:42.959136
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task.

    :returns: True if test is ok, False if not
    :rtype: Bool
    """
    task = Task.of([1, 2, 3])
    task = task.map(lambda l: l + [4, 5, 6])
    if task.fork(lambda _: False, lambda v: v == [1, 2, 3, 4, 5, 6]):
        return True
    else:
        return False


# Generated at 2022-06-24 00:32:45.536681
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(value):
        return Task.of(value * value)

    assert Task.of(10).bind(mapper).fork(None, None) == 100



# Generated at 2022-06-24 00:32:49.468379
# Unit test for constructor of class Task
def test_Task():
    """
    Unit test for constructor of class Task
    """
    assert Task(lambda _, resolve: None).fork(None, None) is None


# Generated at 2022-06-24 00:32:55.489808
# Unit test for method bind of class Task
def test_Task_bind():
    def resolve_and_reject(x):
        if (x % 3 == 0):
            return Task.of(x)
        return Task.reject(x)

    assert Task.of(1).bind(resolve_and_reject).fork(lambda arg: arg, lambda _: None) == 1
    assert Task.of(2).bind(resolve_and_reject).fork(lambda arg: arg, lambda _: None) == 2
    assert Task.of(3).bind(resolve_and_reject).fork(lambda _: None, lambda arg: arg) == 3

# Generated at 2022-06-24 00:33:06.624832
# Unit test for method bind of class Task
def test_Task_bind():

    assert Task.of(1).bind(Task.of).fork(None, None) == 1

    def forker(reject, resolve):
        resolve(1)

    assert Task(forker).bind(Task.of).fork(None, None) == 1

    def forker(reject, resolve):
        resolve(1)

    assert Task(forker).bind(lambda x: Task.of(x + 1)).fork(None, None) == 2

    def forker(reject, resolve):
        resolve(1)

    def forker_mapper(x):
        def forker_inner(reject, resolve):
            resolve(x + 1)
        return Task(forker_inner)

    assert Task(forker).bind(forker_mapper).fork(None, None) == 2


# Generated at 2022-06-24 00:33:15.865143
# Unit test for method map of class Task
def test_Task_map():
    def test_map_with_task_that_resolved_with_number():
        def mapper(number):
            return number * 10

        number = 5
        task = Task.of(number)

        assert mapper(number) == task.map(mapper).fork(None, None)

    def test_map_with_task_that_rejected_with_string():
        def wrong_mapper(some_string):
            return some_string + 'some text'

        task = Task.reject('some string')
        assert task.map(wrong_mapper).fork(None, None) == 'some string'

    test_map_with_task_that_resolved_with_number()
    test_map_with_task_that_rejected_with_string()


# Generated at 2022-06-24 00:33:17.632017
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        reject("some error")
        resolve("some data")

    task = Task(fork)
    assert isinstance(task, Task)


# Generated at 2022-06-24 00:33:23.273470
# Unit test for method map of class Task
def test_Task_map():
    value = 0

    def resolve_inc(arg):
        nonlocal value
        value = arg + 1

    def resolve_inc_inc(arg):
        nonlocal value
        value = arg + 2

    add_one = Task.of(1)
    add_one.fork(lambda _: None, resolve_inc)

    assert value == 1

    add_two = add_one.map(lambda arg: arg + 1)
    add_two.fork(lambda _: None, resolve_inc_inc)

    assert value == 3


# Generated at 2022-06-24 00:33:25.431798
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve("Success"))
    assert task


# Generated at 2022-06-24 00:33:29.524817
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of('example')
    new_task = task.bind(lambda arg: Task.reject(arg))
    assert callable(new_task.fork)
    new_task.fork(lambda arg: arg, lambda _: 'fail') == 'example'
    new_task.fork(lambda arg: arg, lambda _: 'fail') == 'example'


# Generated at 2022-06-24 00:33:36.311882
# Unit test for method bind of class Task
def test_Task_bind():
    def plus(value):
        return Task.of(value + 1)

    def multiply(value):
        return Task.of(value * 2)

    def error_task(error):
        return Task.reject(error)

    assert Task.of(1).bind(plus).bind(multiply).fork(print, print) == 4
    assert Task.of(1).bind(plus).bind(multiply).bind(error_task).fork(print, print) == 2



# Generated at 2022-06-24 00:33:39.672668
# Unit test for method map of class Task
def test_Task_map():
    def test_case(fn, input, expected):
        task = Task.of(input)
        result = task.map(fn).fork(
            lambda err: None,
            lambda val: val
        )
        assert result == expected

    test_case(lambda x: x ** 2, 2, 4)



# Generated at 2022-06-24 00:33:51.623667
# Unit test for method bind of class Task
def test_Task_bind():
    # success case
    def as_Task(arg):
        return Task.of(arg)

    a = Task.of(0).bind(as_Task).fork(lambda x: print(x), lambda x: print(x))
    # 0

    # success case
    def as_Task(arg):
        return Task.reject(arg)

    a = Task.reject(0).bind(as_Task).fork(lambda x: print(x), lambda x: print(x))
    # 0
    a = Task.of([0, 1, 2]).bind(as_Task).fork(lambda x: print(x), lambda x: print(x))
    # [0, 1, 2]

    # success case
    def as_Task(arg):
        return Task.reject(arg)


# Generated at 2022-06-24 00:33:56.021779
# Unit test for constructor of class Task
def test_Task():
    @Task
    def test_task(reject, resolve):
        return resolve(42)

    assert test_task.fork(lambda x: None, lambda x: x) == 42


# Generated at 2022-06-24 00:33:59.669121
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    assert task.map(lambda arg: arg + 1).fork(lambda _: None, lambda arg: arg) == 2


# Generated at 2022-06-24 00:34:03.150449
# Unit test for constructor of class Task
def test_Task():
    """
    Test constructor of class Task.

    :returns: None.
    :rtype: None
    """
    assert Task.of(1) == Task(lambda _, resolve: resolve(1))
    assert Task.reject(1) == Task(lambda reject, _: reject(1))


# Generated at 2022-06-24 00:34:08.117040
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(value):
        return Task.of(value)

    assert Task.of(1).bind(fn).fork(lambda _: None, lambda result: result) == 1
    assert Task.reject(1).bind(fn).fork(lambda result: result, lambda _: None) == 1


# Generated at 2022-06-24 00:34:14.320894
# Unit test for constructor of class Task
def test_Task():
    assert type(Task(lambda reject, resolve: resolve())) is Task

# Generated at 2022-06-24 00:34:22.417023
# Unit test for method bind of class Task
def test_Task_bind():
    value = 'abc'

    @Task.of(value)
    def test_value_1(resolve, _):
        resolve(value)

    @Task.reject(value)
    def test_value_2(reject, _):
        reject(value)

    @Task.of(value)
    def test_value_3(resolve, _):
        resolve(value)

    def reject(arg):
        assert arg == value

    def resolve(arg):
        assert arg == value

    test_value_1.bind(lambda _: test_value_2).fork(reject, resolve)
    test_value_1.bind(lambda _: test_value_3).fork(reject, resolve)



# Generated at 2022-06-24 00:34:30.259378
# Unit test for method bind of class Task
def test_Task_bind():
    # Test 1
    fn = lambda value: Task.reject('%s error' % value)
    task = Task.reject('Some')
    assert task.bind(fn).fork(lambda err: err, None) == 'Some error'

    # Test 2
    fn = lambda value: Task.reject('%s error' % value)
    task = Task.of('Some')
    assert task.bind(fn).fork(lambda err: err, None) == 'Some error'

    # Test 3
    fn = lambda value: Task.of('%s error' % value)
    task = Task.of('Some')
    assert task.bind(fn).fork(None, lambda success: success) == 'Some error'


# Generated at 2022-06-24 00:34:35.684898
# Unit test for constructor of class Task
def test_Task():
    """Checking constructor of Task class."""
    value = 'test'
    task = Task(lambda reject, resolve: resolve(value))

    def test_fork(reject, resolve):
        test[0] = reject
        test[1] = resolve

        return None

    test = [None, None]

    assert task.fork == test_fork
    assert isinstance(test[0], FunctionType)
    assert isinstance(test[1], FunctionType)



# Generated at 2022-06-24 00:34:44.884709
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for Task.map method.

    If Task[Function(_, _) -> A].map(function(A) -> B)
    is returned Task[Function(_, _) -> B]
    """

    def get_number():
        return Task(lambda _, resolve: resolve(5))

    def get_string(value):
        return Task(lambda _, resolve: resolve(str(value)))

    expected = "5"
    actual = get_number().map(get_string).fork(None, lambda v: v)

    if expected != actual:
        raise Exception(
            '\nExpected:\n%s\nActual:\n%s\n' % (expected, actual)
        )


# Generated at 2022-06-24 00:34:48.534004
# Unit test for method map of class Task
def test_Task_map():
    def fn(value=1):
        return value + 1
    of_task = Task.of(1)
    assert of_task.map(fn).fork(lambda x: x, lambda x: x) == 2


# Generated at 2022-06-24 00:34:58.795691
# Unit test for method map of class Task
def test_Task_map():
    """
    Test check map using simple math operations

    :returns: None
    :rtype: None
    """
    from random import randint

    a = randint(-100, 100)
    b = randint(-100, 100)

    def incrementor(x):
        return x + 1

    def multiplier(x):
        return x * 10

    def subbstractor(x):
        return x - a

    def divisor(x):
        return int(x / b)

    def mapper(x):
        return [incrementor(x), multiplier(x), subbstractor(x), divisor(x)]

    task = Task.of(5).map(mapper)
    assert task.fork(None, None) == [6, 50, 5 - a, int(5 / b)]


# Generated at 2022-06-24 00:35:01.830447
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of('Hello')
    task = task.map(lambda arg: arg + ' ')
    task = task.map(lambda arg: arg + 'World')
    assert task.fork(
        lambda err: '',
        lambda arg: arg
    ) == 'Hello World'


# Generated at 2022-06-24 00:35:05.068292
# Unit test for constructor of class Task
def test_Task():
    fork = lambda _, resolve: resolve(2)
    task = Task(fork)

    assert isinstance(task, Task), "Should be instance of class Task"
    assert task.fork == fork, "Fork methods should be equal"


# Generated at 2022-06-24 00:35:09.851706
# Unit test for method bind of class Task
def test_Task_bind():
    def afn(value):
        return Task.of(value + 2)

    def bfn(value):
        return Task.of(value + 3)

    def cfn(value):
        return Task.of(value + 5)

    assert Task.of(1).bind(afn).bind(bfn).bind(cfn).fork(print, print) == 11


# Generated at 2022-06-24 00:35:17.751224
# Unit test for method bind of class Task
def test_Task_bind():
    def f(error, value):
        if value == 3:
            raise AssertionError(error)
        else:
            raise AssertionError(value)

    Task.of(1) \
        .bind(lambda a: Task.of(a + 1)) \
        .bind(lambda a: Task.of(a + 1)) \
        .bind(lambda a: Task.reject(a + 1)) \
        .fork(f, f)
    Task.of(2) \
        .bind(lambda a: Task.of(a + 1)) \
        .bind(lambda a: Task.of(a + 1)) \
        .bind(lambda a: Task.reject(a + 1)) \
        .fork(f, f)

# Generated at 2022-06-24 00:35:20.049041
# Unit test for constructor of class Task
def test_Task():
    assert Task.of('foo').fork(lambda a: a, lambda a: a) == 'foo'
    assert Task.reject('bar').fork(lambda a: a, lambda a: a) == 'bar'


# Generated at 2022-06-24 00:35:27.606549
# Unit test for method map of class Task
def test_Task_map():
    def resolve_only(_, resolve):
        resolve(1)

    def reject_only(reject, _):
        reject(1)

    task = Task(resolve_only)

    assert task.map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 2
    assert task.map(lambda x: x - 1).fork(lambda x: x, lambda x: x) == 0

    task = Task(reject_only)

    assert task.map(lambda x: x + 1).fork(lambda x: x, lambda x: x) == 1
    assert task.map(lambda x: x - 1).fork(lambda x: x, lambda x: x) == 1


# Generated at 2022-06-24 00:35:29.912544
# Unit test for method bind of class Task
def test_Task_bind():
    f = lambda x: x*2
    task = Task.of(2).map(f).bind(f)
    expected = 8
    result = task.fork(lambda x: x, lambda x: x)
    assert result == expected

# Generated at 2022-06-24 00:35:32.810107
# Unit test for method bind of class Task
def test_Task_bind():
    fork = lambda reject, resolve: resolve(1)
    task = Task(fork)
    result = task.bind(lambda value: Task.of(value + 1))
    assert result.fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 2


# Generated at 2022-06-24 00:35:40.364634
# Unit test for method map of class Task
def test_Task_map():
    """
    :returns: True if test is passed and False if some error occurs
    :rtype: Bool
    """
    def add(a, b): return a + b
    def add2(a): return add(a, 2)

    task = Task.of(2)
    result = task.map(add2)

    return result.fork(None, lambda arg: arg == 4)


# Generated at 2022-06-24 00:35:44.396355
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    task_binded = task.bind(lambda arg: Task.of(arg + 1))
    assert 2 == task_binded.fork(lambda _: None, lambda value: value)


# Generated at 2022-06-24 00:35:53.736226
# Unit test for method bind of class Task
def test_Task_bind():
    import unittest

    class TestTaskBind(unittest.TestCase):

        def test_should_return_rejected_task_when_parameter_is_rejected(self):
            def reject(value):
                pass

            def resolve(value):
                raise ValueError('Should not be called')

            task = Task.reject(1).bind(lambda v: Task.of(v**2))
            task.fork(reject, resolve)

        def test_should_return_resolved_task_when_parameter_is_resolved(self):
            def reject(value):
                raise ValueError('Should not be called')

            def resolve(value):
                self.assertEquals(9, value)

            task = Task.of(3).bind(lambda v: Task.of(v**2))
            task.fork

# Generated at 2022-06-24 00:35:58.473503
# Unit test for constructor of class Task
def test_Task():
    """
    Test if fork function parameter passed to constructor is called with same
    first argument and second argument.
    """
    fork = MagicMock()
    task = Task(fork)
    reject = MagicMock()
    resolve = MagicMock()
    task.fork(reject, resolve)
    assert fork.call_args_list[0] == call(reject, resolve)


# Generated at 2022-06-24 00:36:01.106198
# Unit test for method bind of class Task
def test_Task_bind():
    def increment(x):
        return Task.of(x + 1)

    result = Task.of(1).bind(increment)

    assert 2 == result.fork(lambda _, reject: reject(2), lambda arg: arg)

test_Task_bind()



# Generated at 2022-06-24 00:36:08.232173
# Unit test for constructor of class Task
def test_Task():
    def add(x):
        return x + 1

    def reject(x):
        return Task.reject(x)


# Generated at 2022-06-24 00:36:10.672580
# Unit test for constructor of class Task
def test_Task():
    """
    Test for Task.__init__().
    """
    def fork(reject, resolve):
        return resolve(10)

    task = Task(fork)

    assert task.fork is fork


# Generated at 2022-06-24 00:36:15.879385
# Unit test for method bind of class Task
def test_Task_bind():
    def check(a, b):
        print("Check:", a, b)
        assert a == b

    def add(x):
        return Task(lambda _, resolve: resolve(x + 1))

    def decorated_add(x):
        return Task(lambda _, resolve: resolve(x * 2))

    # Task.of(5).bind(add).fork(print, check(6))
    Task.of(5).bind(add).bind(decorated_add).fork(print, check(12))


# Generated at 2022-06-24 00:36:19.125584
# Unit test for method map of class Task
def test_Task_map():
    def add1(x):
        assert x == 1
        return x + 1

    task = Task.of(1).map(add1)


# Generated at 2022-06-24 00:36:28.796753
# Unit test for method bind of class Task
def test_Task_bind():
    def fork_with_resolve(resolve, reject):
        return resolve(1)

    def fork_with_reject(resolve, reject):
        return reject(2)

    task = Task(fork_with_resolve)

    def mapper(value):
        def fork(resolve, reject):
            return resolve(value + 1)

        return Task(fork)

    task2 = task.bind(mapper)
    value, err = task2.fork(
        lambda err: (None, err),
        lambda value: (value, None)
    )

    assert err == None and value == 2

    task3 = Task(fork_with_reject)

    task4 = task3.bind(mapper)

# Generated at 2022-06-24 00:36:32.020570
# Unit test for constructor of class Task
def test_Task():
    assert_equal(Task(lambda x, y: x).fork, lambda x, y: x)
    assert_equal(Task(lambda x, y: y).fork, lambda x, y: y)


# Generated at 2022-06-24 00:36:34.671377
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(1)

    task = Task(fork)

    assert task.fork == fork


# Generated at 2022-06-24 00:36:38.696745
# Unit test for constructor of class Task
def test_Task():
    """
    Test for constructor of class Task
    """
    class Task:
        def __init__(self, fork):
            self.fork = fork

    assert Task(int) == Task(int)
    assert Task(str) != Task(int)
    assert Task(str) != Task(str)


# Generated at 2022-06-24 00:36:44.065155
# Unit test for method bind of class Task
def test_Task_bind():
    def fn(arg):
        if arg:
            return Task.of('b')
        return Task.reject('a')

    task = Task.of(True)
    assert task.bind(fn).fork(lambda _: False, lambda _: True)
    task = Task.of(False)
    assert task.bind(fn).fork(lambda _: True, lambda _: False)
    print('task.bind success')



# Generated at 2022-06-24 00:36:52.873145
# Unit test for method map of class Task
def test_Task_map():
    def func(reject, resolve):
        resolve(2)

    def func_mapper(value):
        return value * 2

    def func_mapper_second(value):
        return value * 3

    task = Task(func)
    assert task.fork(lambda arg: arg, lambda arg: arg) == 2

    task_new = task.map(func_mapper)
    assert task_new.fork(lambda arg: arg, lambda arg: arg) == 4

    task_new_second = task_new.map(func_mapper_second)
    assert task_new_second.fork(lambda arg: arg, lambda arg: arg) == 12


# Generated at 2022-06-24 00:36:54.723924
# Unit test for constructor of class Task
def test_Task():
    assert callable(Task)

    assert Task.of(1)
    assert Task.reject(1)


# Generated at 2022-06-24 00:37:01.488895
# Unit test for method bind of class Task

# Generated at 2022-06-24 00:37:07.232103
# Unit test for method map of class Task
def test_Task_map():
    """
    Call map method for Task and check that is called with correct arguments.
    """

    def resolve(value):
        assert value == 1

    def reject(value):
        assert False

    def fork(reject, resolve):
        resolve(0)

    # call map
    Task(fork).map(lambda value: value + 1).fork(reject, resolve)


# Generated at 2022-06-24 00:37:12.835065
# Unit test for method map of class Task
def test_Task_map():
    """
    Test of Task.map method
    """
    def fn(arg):
        """Fake function: add to arg string ' world'"""
        return arg + ' world'

    t1 = Task.of('Hello')
    t2 = t1.map(fn)

    # Test fork
    assert isinstance(t2.fork, FunctionType)
    assert t2.fork(lambda arg: arg, lambda arg: arg) == 'Hello world'

    # Test map
    assert t2.map(lambda arg: arg.startswith('H')).fork(
        lambda arg: arg,
        lambda arg: arg
    ) == True


# Generated at 2022-06-24 00:37:19.370328
# Unit test for method bind of class Task
def test_Task_bind():
    tasks = [
        Task.of(1),
        Task.of(3),
        Task.of(5)
    ]

    def executor(_, resolve):
        resolve(sum(task.fork(None, lambda arg: arg) for task in tasks))

    task = Task(executor)

    def test_sum_Task():
        assert task.fork(None, lambda arg: arg) == 9

    test_sum_Task()



# Generated at 2022-06-24 00:37:25.223463
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method Task.map()
    """
    log = []
    def fn(value):
        log.append('map_fn')
        return value * 2
    def fork(reject, resolve):
        log.append('fork')
        resolve(2)
    task = Task(fork)
    mapped_task = task.map(fn)
    mapped_task.fork(None, None)
    assert log == ['fork', 'map_fn'], "Task.map() doesn't work correctly"

# Generated at 2022-06-24 00:37:28.882875
# Unit test for method map of class Task
def test_Task_map():
    def fn(value):
        return value + 1

    def fork(reject, resolve):
        return resolve(1)

    task = Task(fork)
    new_task = task.map(fn)
    assert new_task.fork(None, None) == 2



# Generated at 2022-06-24 00:37:33.969607
# Unit test for method map of class Task
def test_Task_map():
    request = Task(lambda reject, resolve: resolve(2))

    assert request.map(lambda arg: arg ** 2).fork(lambda _: None, lambda value: value) == 4
    assert request.map(lambda arg: arg ** 3).fork(lambda _: None, lambda value: value) == 8
    assert request.map(lambda arg: arg ** 4).fork(lambda _: None, lambda value: value) == 16



# Generated at 2022-06-24 00:37:39.914619
# Unit test for method bind of class Task
def test_Task_bind():
    def double(value):
        return value * 2

    def reject(value):
        return Task.reject(value)

    def resolve(value):
        return Task.of(value)

    def fork(reject, resolve):
        return reject('Oops... Something went wrong')

    def fork_map(value):
        return Task.of(value).map(double).fork(reject, resolve)

    Task.of(10).bind(fork_map)

    task_of_10 = Task(lambda reject, resolve: resolve(10))
    assert task_of_10.bind(fork_map).fork(reject, resolve).fork(reject, resolve) == 20
    assert task_of_10.bind(fork).fork(reject, resolve).fork(reject, resolve) == 'Oops... Something went wrong'

# Generated at 2022-06-24 00:37:43.377898
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve(1)).fork(lambda arg: arg, lambda arg: arg) == 1
    assert Task(lambda reject, _: reject(2)).fork(lambda arg: arg, lambda arg: arg) == 2



# Generated at 2022-06-24 00:37:47.341003
# Unit test for constructor of class Task
def test_Task():
    assert Task.of(1).fork(lambda arg: None, lambda arg: arg) == 1
    assert Task.reject(1).fork(lambda arg: arg, lambda arg: None) == 1


# Generated at 2022-06-24 00:37:48.832358
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task(lambda _, resolve: resolve(1))
    assert task.bind(lambda arg: Task.of(arg * 2)).fork(None, lambda arg: arg) == 2


# Generated at 2022-06-24 00:37:50.257402
# Unit test for method bind of class Task
def test_Task_bind():
    t = Task.of(1).bind(lambda v: Task.of(v + 2))
    assert t.fork(lambda _: None, lambda r: r) == 3


# Generated at 2022-06-24 00:37:51.855322
# Unit test for constructor of class Task
def test_Task():
    assert Task(lambda _, resolve: resolve('value')).fork(
        lambda _: False,
        lambda arg: arg == 'value')



# Generated at 2022-06-24 00:37:53.920336
# Unit test for method bind of class Task
def test_Task_bind():
    task = Task.of(1)
    def mapper(value):
        return Task.of(value + 1)

    result = task.bind(mapper)
    assert result.fork(
        lambda _: True,
        lambda value: value == 2
    )


# Generated at 2022-06-24 00:37:59.822956
# Unit test for method map of class Task
def test_Task_map():
    test_value = 42
    mock = Mock()
    mock.return_value = test_value

    value = Task.of('test')
    result = value.map(mock)

    mock.assert_called_once_with('test')
    assert result.fork(None, None) == test_value


# Generated at 2022-06-24 00:38:08.027602
# Unit test for method bind of class Task
def test_Task_bind():
    def error_handler(error):
        pass

    def success_handler(arg):
        assert arg == 3

    def add(arg):
        return Task.of(arg + 2)

    def expected(arg):
        return Task.of(arg + 1)

    task = Task.of(1).bind(add).bind(expected)
    task.fork(error_handler, success_handler)

test_Task_bind()

# Generated at 2022-06-24 00:38:14.562848
# Unit test for method map of class Task
def test_Task_map():
    def add1(x):
        return x + 1
    def bad_add1(x):
        return x + y # pylint: disable=undefined-variable

    assert Task.of(1).map(add1) == Task(lambda reject, resolve: resolve(add1(1)))
    assert Task.reject(1).map(add1) == Task(lambda reject, resolve: reject(1))
    assert Task.of(1).map(bad_add1) == Task(lambda reject, resolve: reject(bad_add1(1)))


# Generated at 2022-06-24 00:38:16.736003
# Unit test for method map of class Task
def test_Task_map():
    r = Task.of(10).map(lambda x: x + 1)
    assert r.fork(
        lambda error: error, lambda value: value
    ) == 11


# Generated at 2022-06-24 00:38:20.444308
# Unit test for method bind of class Task
def test_Task_bind():
    def bind_mapper(value):
        print('mapper: {0}'.format(value))
        return Task.of(value*value)

    def main_fork(reject, resolve):
        print('main_fork:')
        return Task.of(5).bind(bind_mapper).bind(lambda x: Task.of(x+1)).fork(
            lambda arg: reject(arg),
            lambda arg: resolve(arg)
        )

    def main():
        Task(main_fork).fork(
            lambda arg: print('rejected: {0}'.format(arg)),
            lambda arg: print('resolved: {0}'.format(arg))
        )

    main()

test_Task_bind()

# Generated at 2022-06-24 00:38:24.195598
# Unit test for constructor of class Task
def test_Task():
    """
    Create instance of clas Task and call fork function with two function.

    :returns: Unit
    :rtype: Unit
    """
    assert Task(lambda reject, resolve: resolve(1)).fork(lambda arg: arg, lambda arg: arg) == 1


# Generated at 2022-06-24 00:38:29.153829
# Unit test for method bind of class Task
def test_Task_bind():
    def test_function(data):
        return data + " world"

    def test2_function(data):
        return Task.of(data + " world")

    test_data = "Hello"

    assert Task.bind(test_function, Task.of(test_data)) == test_function(test_data)
    assert Task.bind(test2_function, Task.of(test_data)) == test2_function(test_data)


# Generated at 2022-06-24 00:38:32.869381
# Unit test for method map of class Task
def test_Task_map():
    def test_async(reject, resolve):
        return resolve(5)

    def fn(value):
        return 2 * value

    task = Task(test_async)
    mapped_task = task.map(fn)
    assert mapped_task.fork(lambda e: e, lambda x: x) == 10

# Generated at 2022-06-24 00:38:37.419716
# Unit test for method map of class Task
def test_Task_map():
    class MockFork(object):
        def __init__(self):
            self.resolve = None

        def fork(self, reject, resolve):
            self.resolve = resolve

    def fn(value):
        return value + 10

    task = Task(MockFork().fork)
    new_task = task.map(fn)

    new_task.fork(lambda x: None, lambda y: y)

    assert MockFork.resolve(10) == 20


# Generated at 2022-06-24 00:38:42.721633
# Unit test for method map of class Task
def test_Task_map():
    """
    Unit test for method map of class Task
    """

    def add_one(value):
        return value + 1

    def concat_two_strings(value1, value2):
        return value1 + value2

    task = Task(lambda reject, resolve: resolve(5))
    result = task.map(add_one).fork(lambda err: err, lambda res: res)
    assert result == 6

    task_of_string = Task(lambda reject, resolve: resolve('hello'))
    result = task_of_string.map(concat_two_strings).fork(lambda err: err, lambda res: res)
    assert result == 'hellohello'

    task_of_list = Task(lambda reject, resolve: resolve([1, 2, 3]))

# Generated at 2022-06-24 00:38:53.976729
# Unit test for method map of class Task
def test_Task_map():
    """
    Test for method Task.map
    """

    def first(reject, resolve):
        resolve(10)
        return None

    def second(reject, resolve):
        resolve(100)
        return None

    def third(reject, resolve):
        resolve(1000)
        return None

    first_task = Task(first)
    second_task = Task(second)
    third_task = Task(third)

    second_task_from_first_mapped = first_task.map(lambda x: second_task)

    assert second_task_from_first_mapped.fork(lambda x: x, lambda _: None) == 100
    assert third_task_from_first_mapped.fork(lambda x: x, lambda _: None) == 1000


# Generated at 2022-06-24 00:39:01.315292
# Unit test for constructor of class Task
def test_Task():
    """
    Map of Task.of(1) must be equal to Task.of(2)
    Bind of Task.of(1) must be equal to Task.of(2)
    """
    assert Task.of(1).map(lambda arg: arg + 1).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 2

    assert Task.of(1).bind(
        lambda arg: Task.of(arg + 1)
    ).fork(
        lambda reject: reject,
        lambda resolve: resolve
    ) == 2


# Generated at 2022-06-24 00:39:08.550637
# Unit test for method map of class Task
def test_Task_map():
    """Simple test for Task.map method."""
    def fn(arg):
        print(arg)
        return arg * 2

    # Task[resolve, reject] -> Task[resolve, reject]
    def fork(resolve, reject):
        resolve(2)

    task = Task(fork)

    new_task = task.map(fn)
    print(new_task)
    print(new_task.fork)

    # Task[resolve, _] -> Task[resolve, _]
    def new_fork(reject, resolve):
        resolve(fn(2))

    assert new_task.fork == new_fork



# Generated at 2022-06-24 00:39:14.974480
# Unit test for constructor of class Task
def test_Task():
    """
    Test of constructor of class Task.
    """
    def resolve(x):
        print(x)

    def fail(x):
        print(x)

    task = Task(lambda reject, resolve: resolve("abc"))
    task.fork(fail, resolve)

    # OUTPUT:
    # abc


# Generated at 2022-06-24 00:39:18.477636
# Unit test for method map of class Task
def test_Task_map():
    # Task are lazy so we need to call fork function to execute code stored in this Task
    # Its a great for testing callbacks
    task = Task.of(5).map(lambda x: x ** 2).map(lambda x: x * 2)
    assert task.fork(lambda x: x, lambda x: x) == 50


# Generated at 2022-06-24 00:39:21.624407
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        return reject(7)

    task = Task(fork)
    assert(task.fork == fork)



# Generated at 2022-06-24 00:39:25.551266
# Unit test for method map of class Task
def test_Task_map():
    def inc(x):
        return x + 1

    def dec(x):
        return x - 1

    def sqr(x):
        return x * x

    task_one = (
        Task.of(1)
        .map(inc)
        .map(inc)
        .map(inc)
    )
    assert task_one.fork(None, lambda x: x) == 4

    task_two = (
        Task.of(2)
        .map(sqr)
        .map(inc)
        .map(dec)
    )
    assert task_two.fork(None, lambda x: x) == 5


# Generated at 2022-06-24 00:39:28.293013
# Unit test for constructor of class Task
def test_Task():
    def fork(reject, resolve):
        resolve(None)

    task = Task(fork)
    assert task.fork(None, None) == None


# Generated at 2022-06-24 00:39:31.890092
# Unit test for method map of class Task
def test_Task_map():
    """Test case: Task.map"""
    assert Task(lambda _, resolve: resolve(1)) \
        .map(lambda value: value + 1) \
        .fork(lambda err: err, lambda result: result) == 2


# Generated at 2022-06-24 00:39:34.739489
# Unit test for method map of class Task
def test_Task_map():
    def fn(x): return x + 1

    def fork(reject, resolve):
        return resolve(2)

    assert Task(fork).map(fn).fork(None, print) == 3



# Generated at 2022-06-24 00:39:37.175352
# Unit test for method map of class Task
def test_Task_map():
    assert Task.of(1).map(lambda v: v + 1).fork(
        lambda err: 'error',
        lambda res: res
    ) == 2



# Generated at 2022-06-24 00:39:40.132479
# Unit test for method map of class Task
def test_Task_map():
    task = Task.of(1)
    new_task = task.map(lambda value: value + 1)
    assert task.fork(None, None) == 1
    assert new_task.fork(None, None) == 2


# Generated at 2022-06-24 00:39:47.463399
# Unit test for method map of class Task
def test_Task_map():
    def add(x):
        return x + 2

    def fail(x):
        return x / 0

    resolved_task = Task.of(2)
    rejected_task = Task.reject(2)

    assert resolved_task.map(add).fork(None, lambda x: x) == 4
    assert rejected_task.map(add).fork(None, lambda x: x) == 2
    assert resolved_task.map(fail).fork(lambda x: x, None) == 2
    assert rejected_task.map(fail).fork(lambda x: x, None) == 2



# Generated at 2022-06-24 00:39:54.198099
# Unit test for method map of class Task
def test_Task_map():
    """
    :return: boolean flag, True if result is equal to expected
    """
    def fork(reject, resolve):
        return resolve(1)

    def fork2(reject, resolve):
        return resolve(2)

    def add_one(value):
        return value + 1

    x1 = Task(fork)
    r1 = x1.map(add_one)
    assert r1.fork(lambda _: False, lambda arg: arg == 2)

    x2 = r1.map(add_one)
    r2 = x2.map(add_one)
    assert r2.fork(lambda _: False, lambda arg: arg == 4)

    x3 = Task(fork2)
    r3 = x3.map(add_one)

# Generated at 2022-06-24 00:40:05.178668
# Unit test for constructor of class Task
def test_Task():
    # Task.of
    assert Task.of(1).fork(lambda x: None, lambda x: x) == 1
    assert Task.of({"a": 1}).fork(lambda x: None, lambda x: x) == {"a": 1}
    assert Task.of([1, 2, 3]).fork(lambda x: None, lambda x: x) == [1, 2, 3]
    
    # Task.of with error
    assert Task.of(1).fork(lambda x: x, lambda x: None) == None
    assert Task.of({"a": 1}).fork(lambda x: x, lambda x: None) == None
    assert Task.of([1, 2, 3]).fork(lambda x: x, lambda x: None) == None

    # Task.reject

# Generated at 2022-06-24 00:40:06.534093
# Unit test for constructor of class Task
def test_Task():
    fork = lambda reject, resolve: resolve('Test')

    task = Task(fork)

    assert task.fork is fork


# Generated at 2022-06-24 00:40:13.352202
# Unit test for method map of class Task
def test_Task_map():
    result_1 = (
        Task.of(2)
        .map(lambda value: value ** 2)
        .fork(lambda x: x, lambda x: x)
    )
    result_2 = (
        Task.reject(2)
        .map(lambda value: value ** 2)
        .fork(lambda x: x, lambda x: x)
    )

    assert result_1 == 4
    assert result_2 == 2



# Generated at 2022-06-24 00:40:23.047678
# Unit test for method bind of class Task
def test_Task_bind():
    double = lambda arg: arg * 2
    default_error = lambda arg: arg + 10
    default_resolver = lambda arg: arg - 5

    def create_task(value, error, resolver):
        def fork(reject, resolve):
            if resolver is not None:
                resolve(resolver(value))
            if error is not None:
                reject(error(value))
            return value
        return Task(fork)

    task_1 = create_task(50, None, None)
    task_result = task_1.bind(lambda arg: create_task(arg, None, None))
    assert task_result.fork(default_error, default_resolver) == 50

    task_2 = create_task(45, default_error, None)

# Generated at 2022-06-24 00:40:30.882336
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test implementation bind method of class Task
    """
    def spy_fork():
        spy_fork.called = True

    def bind(value):
        assert value == 1
        return Task(spy_fork)

    spy_fork.called = False
    task = Task(lambda _, resolve: resolve(1)).bind(bind)
    task.fork(lambda _: None, lambda _: None)
    assert spy_fork.called



# Generated at 2022-06-24 00:40:39.981639
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Test with two Task[A, B].
    First Task has resolve attribute with value A.
    Second Task has resolve attribute with value B.
    """
    # forked function for first Task
    def fork_first(reject, resolve):
        resolve(1)

    # forked function for second Task
    def fork_second(reject, resolve):
        resolve(2)

    # Task used as mapper inside bind
    task_mapper = Task(fork_second)

    first_task = Task(fork_first)
    """
    :var first_task: first Task[int, int]
    :vartype first_task: Task[Function(_, resolve) -> int]
    """
    result = first_task.bind(lambda arg: task_mapper)

# Generated at 2022-06-24 00:40:49.378244
# Unit test for method bind of class Task
def test_Task_bind():
    def add1(value):
        return value + 1

    def task_with_add1(value):
        return Task.of(add1(value))

    def add_value_to_result_of_task(value):
        return Task.of(value + result)

    result = 0
    assert Task.of(1).bind(lambda _: Task.of(2)).fork(lambda _: None,
                                                     lambda _: None) == 2
    assert Task.of(1).bind(add_value_to_result_of_task).fork(
        lambda _: None,
        lambda _: None) == 1



# Generated at 2022-06-24 00:40:52.295248
# Unit test for method bind of class Task
def test_Task_bind():
    def mapper(arg):
        return Task.of(arg * 2)

    task = Task.of(1).bind(mapper)
    assert task.fork(lambda arg: arg, lambda _: None) == 2



# Generated at 2022-06-24 00:40:56.479712
# Unit test for constructor of class Task
def test_Task():
    task = Task(lambda reject, resolve: resolve(12))
    assert task.fork(None, lambda arg: arg) == 12


# Generated at 2022-06-24 00:41:00.957457
# Unit test for method map of class Task
def test_Task_map():
    def fork(reject, resolve):
        return resolve(42)

    t = Task(fork).map(lambda x: x + 1)
    assert t.fork(lambda _: None, lambda x: x) == 43


# Generated at 2022-06-24 00:41:04.886283
# Unit test for method bind of class Task
def test_Task_bind():
    """
    Return resolved Task with stored value argument.
    """
    task = Task.of(1)
    task = task.map(lambda arg: arg + 1)
    task = task.bind(lambda arg: Task.of(arg * 10))

    assert task.fork(lambda _: None, lambda arg: arg) == 20

# Generated at 2022-06-24 00:41:16.505971
# Unit test for method map of class Task
def test_Task_map():
    def add(x, y):
        return x + y

    def multiply(x, y):
        return x * y

    def add_after_multiply(x, y):
        task = Task.of(x * y)
        return task.map(lambda value: value + x + y)

    t1 = Task.of(1)
    t2 = Task.of(2)
    add_task = t1.map(lambda x: lambda y: add(x, y))
    assert add_task.fork(None, lambda fn: fn(2)) == 3
    multiply_task = t1.map(lambda x: lambda y: x * y)
    assert multiply_task.fork(None, lambda fn: fn(2)) == 2

# Generated at 2022-06-24 00:41:24.983259
# Unit test for method bind of class Task
def test_Task_bind():
    def fork(reject, resolve):
        assert reject is not None
        assert resolve is not None
        return 'fork'

    def mapper(value):
        assert value == 'asd'
        return value + '---'

    task = Task(fork)
    assert task.fork(None, None) == 'fork'
    assert task.map(lambda value: value).fork(None, lambda value: value) == 'fork'
    assert task.map(mapper).fork(None, lambda value: value) == 'asd---'


# Generated at 2022-06-24 00:41:32.867939
# Unit test for method bind of class Task
def test_Task_bind():
    def check(name, input, expected):
        task_function = Task.bind(input)
        result = task_function.fork(lambda x: x + 1, lambda x: x - 1)
        assert result == expected, \
            f"Test case '{name} failed. Result: {result}, expected {expected}"

    check(
        'reject',
        Task.reject(5),
        6
    )

    check(
        'resolve',
        Task.of(5),
        4
    )

    check(
        'nested',
        Task.of(5).map(lambda x: Task.of(x + 5)),
        9
    )

# Unit tests for method map of class Task

# Generated at 2022-06-24 00:41:38.317238
# Unit test for method map of class Task
def test_Task_map():
    identity = lambda x: x
    double = lambda x: x * 2

    assert Task.of('test') \
        .map(identity) \
        .fork(identity, identity) == 'test'

    assert Task.of(5) \
        .map(double) \
        .fork(identity, identity) == 10