

# Generated at 2022-06-24 18:05:34.788789
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    try:
        vault_c_l_i_0.execute_encrypt()
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-24 18:05:36.353481
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    return

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:05:38.363967
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    args = [ 'ansible-vault', 'encrypt']
    with patch.object(sys, 'argv', args):
        bytes_0 = None
        vault_c_l_i_0 = VaultCLI(bytes_0)

    


# Generated at 2022-06-24 18:05:39.576462
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    try:
        test_case_0()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 18:05:49.776918
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    global bytes_0
    global vault_c_l_i_0
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    # execute_edit has more than one return path
    # execute_edit has more than one return path
    # execute_edit has more than one return path
    # execute_edit has more than one return path
    # execute_edit has more than one return path
    print("\t -Testing VaultCLI.execute_edit(self)")
    try:
        vault_c_l_i_0.execute_edit()
    except Exception:
        print("\t\t ->Failed: Test 0")
    else:
        print("\t\t ->Passed: Test 0")

# Generated at 2022-06-24 18:05:52.069128
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # FIXME: write this unit test, or remove the test code
    print("TODO: write unit test")
    return 0



# Generated at 2022-06-24 18:05:53.883348
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    vault_c_l_i_0.execute_view()
    # TODO: check output


# Generated at 2022-06-24 18:05:56.828744
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    v_c_l_i_0 = VaultCLI()
    assert(v_c_l_i_0.execute_decrypt() == None)

# Generated at 2022-06-24 18:06:02.296084
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    with pytest.raises(SystemExit):
        args_0 = ['ansible-vault', 'edit']
        context.CLIARGS = {'args': args_0}
        vault_c_l_i_0.execute_edit()


# Generated at 2022-06-24 18:06:05.482563
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_VaultCLI_run()
    # Run main()
    main()

# Generated at 2022-06-24 18:06:41.243902
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    test_case_0()

# Run unit tests
test_VaultCLI_run()


# Generated at 2022-06-24 18:06:44.954833
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)

    # Test the test
    if sys.version_info[0:2] == (2, 7):
        assert(False)

    vault_c_l_i_0.run()

    

# Generated at 2022-06-24 18:06:58.880770
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    ansible_options = C.DEFAULT_ANSIBLE_VAULT_OPTS.copy()

    # Test function with only the defaults (no args specified)
    vault_c_l_i = VaultCLI(ansible_options)
    vault_c_l_i.post_process_args()
    assert vault_c_l_i.encrypt_string_read_stdin == False
    assert vault_c_l_i.encrypt_string_prompt == False
    assert vault_c_l_i.encrypt_string_stdin_name == None
    assert vault_c_l_i.encrypt_string_names == []

    # Test function with --encrypt-string-stdin
    ansible_options['encrypt_string_stdin'] = True

# Generated at 2022-06-24 18:07:06.335330
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    try:
        vault_c_l_i_0.execute_create()
    except AnsibleOptionsError:
        pass
    bytes_1 = None
    vault_c_l_i_1 = VaultCLI(bytes_1)
    context.CLIARGS['args'] = ['file_name']
    vault_c_l_i_1.execute_create()


# Generated at 2022-06-24 18:07:08.638313
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    test_case_0()


# Generated at 2022-06-24 18:07:12.254181
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    argString = "ansible-vault encrypt_string --encrypt-string 'test' --encrypt-string-prompt"
    subprocess.check_call(argString.split())


# Generated at 2022-06-24 18:07:18.764584
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    argv_0 = ['ansible-vault', 'encrypt', 'test_data/test_playbook.yml']
    context.CLIARGS = {'ask_vault_pass': False, 'new_vault_id': None, 'new_vault_password_file': None, 'encrypt_vault_id': None, 'output_file': None}
    loader_0 = None
    with mock.patch('ansible.cli.vault.VaultCLI.ask_vault_passwords', return_value=None):
        vault_c_l_i_0.run(argv_0, context, loader_0)


# Generated at 2022-06-24 18:07:27.562584
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    parser_0 = None
    argv_0 = ''
    argv_1 = ()
    argv_2 = ['']
    argv_3 = ['', '']
    argv_4 = ('',)
    argv_5 = ('', '')
    argv_6 = ['', '']
    argv_7 = ['', '', '']
    argv_8 = ('', '', '')
    argv_9 = ['', '', '', '']
    argv_10 = ('', '', '', '')
    argv_11 = ['', '', '', '', '']
    argv_12 = ('', '', '', '', '')

# Generated at 2022-06-24 18:07:37.504022
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    args_0 = [""]
    c_l_i_a_r_g_s_0 = {}
    c_l_i_a_r_g_s_0["args"] = args_0
    context.CLIARGS = c_l_i_a_r_g_s_0
    output_file_0 = None
    c_l_i_a_r_g_s_0["output_file"] = output_file_0
    vault_c_l_i_0.execute_decrypt()



# Generated at 2022-06-24 18:07:43.934748
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    parser = CLI.base_parser(constants=C, runas_opts=True, output_opts=True, connect_opts=True,
                             subset_opts=True, check_opts=True, runtask_opts=True, vault_opts=True)
    context.CLIARGS = parser.parse_args()

    vault_c_l_i_0 = VaultCLI(context.CLIARGS)
    context.CLIARGS['encrypt_string_read_stdin'] = True
    vault_c_l_i_0.post_process_args()


# Generated at 2022-06-24 18:08:53.932678
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    f_0 = None
    vault_c_l_i_0.editor = mock.Mock()
    vault_c_l_i_0.args = [f_0]
    vault_c_l_i_0.execute_edit()
    vault_c_l_i_0.editor.edit_file.assert_called_with(f_0)


# Generated at 2022-06-24 18:09:00.290504
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    bytes_0 = None
    r_l_c_0 = RealLoaderConfig(bytes_0)
    vault_c_l_i_0 = VaultCLI(r_l_c_0)
    context.CLIARGS = AttributeDict({'args': ['test_file_01'], 'verbosity': 3, 'ask_vault_pass': False, 'vault_password_file': None, 'new_vault_password_file': None, 'vault_ids': [], 'new_vault_ids': []})
    vault_c_l_i_0.execute_view()


# Generated at 2022-06-24 18:09:03.189576
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    test_case_0()


# Generated at 2022-06-24 18:09:09.076540
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    arg_0 = ['ansible.cfg']
    arg_1 = ['-f', 'ansible-vault.log']
    # arguments = arg_0 + arg_1
    # print(arguments)
    vault_c_l_i_0.parse(arguments)
    vault_c_l_i_0.execute_rekey()


# Generated at 2022-06-24 18:09:16.727661
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    bytes_1 = None
    vault_c_l_i_1 = VaultCLI(bytes_1)
    str_list_par_0 = []
    context.CLIARGS = {'args' : str_list_par_0}
    vault_c_l_i_1.execute_encrypt_string()


# Generated at 2022-06-24 18:09:20.793780
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    if 'VaultCLI' not in globals():
        test_case_0()
    vault_c_l_i_0 = VaultCLI(None)
    vault_c_l_i_0.execute_edit()


# Generated at 2022-06-24 18:09:30.121104
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    file_name_0 = None
    result_0 = vault_c_l_i_0.execute_decrypt(file_name_0)
    # self.assertRaises(Exception, vault_c_l_i_0.execute_decrypt, file_name_0)


# Generated at 2022-06-24 18:09:34.772400
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    args = (1, 2, 3)
    vault_c_l_i_1 = VaultCLI(args)
    vault_c_l_i_1.execute_edit()



# Generated at 2022-06-24 18:09:38.792766
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    # Uncomment to test which exceptions are caught
    # vault_c_l_i_0.execute_create()
    return True


# Generated at 2022-06-24 18:09:48.756794
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    args = None
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)

    # Test normal case
    try:
        vault_c_l_i_0.run(args)
    except:
        raise AssertionError('Normal case failed.')

    # Test that TypeError is raised if args is not an ArgumentParser
    args = "This is not an AnsibleArgumentParser"
    try:
        vault_c_l_i_0.run(args)
    except TypeError:
        pass
    except:
        raise AssertionError('TypeError not raised.')

    # Test that AnsibleError is raised if args is not configured
    args = None

# Generated at 2022-06-24 18:12:18.115552
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    vault_c_l_i_0.execute_encrypt()


# Generated at 2022-06-24 18:12:22.339616
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    argv_0 = None
    output_0 = vault_c_l_i_0.execute_encrypt_string(argv_0)
    assert True


# Generated at 2022-06-24 18:12:29.291076
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    result = vault_c_l_i_0.execute_edit()
    assert result is None


# Generated at 2022-06-24 18:12:30.394735
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: needs tests
    pass


# Generated at 2022-06-24 18:12:38.960769
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    from nose.tools import assert_equals, assert_true
    bytes_0 = None

# Generated at 2022-06-24 18:12:49.152860
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    # INPUT:

    # Creation of 'context_args_0' not covered by this test case.
    context_args_0 = None

    # Creation of 'context' not covered by this test case.
    context_0 = None

    context_0 = DummyCLI.make_context(context_args_0, 'test')
    ansible_v_a_u_l_t_e_d_i_t_o_r_0 = None
    # Creation of 'vault' not covered by this test case.
    vault_0 = None
    ansible_v_a_u_l_t_e_d_i_t_o_r_0 = VaultEditor(vault_0)
    #

# Generated at 2022-06-24 18:12:56.145978
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():

    # Case 1
    bytes_1 = None
    cli_args_1 = dict()
    vault_c_l_i_1 = VaultCLI(bytes_1, cli_args_1)

    # Case 2
    bytes_2 = None
    cli_args_2 = dict()
    vault_c_l_i_2 = VaultCLI(bytes_2, cli_args_2)

    # Case 3
    bytes_3 = None
    cli_args_3 = dict()
    vault_c_l_i_3 = VaultCLI(bytes_3, cli_args_3)

    # Case 4
    bytes_4 = None
    cli_args_4 = dict()
    vault_c_l_i_4 = VaultCLI(bytes_4, cli_args_4)

# Generated at 2022-06-24 18:13:04.313513
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    value_0 = bytearray(8)
    bytes_0 = None
    vault_c_l_i_0 = VaultCLI(bytes_0)
    # caplog is not used, but it is required to be passed to run() to prevent a pytest warning
    with pytest.raises(SystemExit) as excinfo:
        vault_c_l_i_0.run(value_0)
    assert excinfo.value.code == 1


# Generated at 2022-06-24 18:13:15.906792
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():

    print('\n---\nMethod: VaultCLI.post_process_args')

    # Test 1 - With no --encrypt-vault-id, --new-encrypt-vault-id, --vault-id or --new-vault-id and no --vault-password-file,
    # and no --new-vault-password-file, we prompt for password and use the default vault_id
    print('Test 1')
    vault_c_l_i_1 = VaultCLI()
    vault_c_l_i_1._get_prompt_bytes = lambda m: b'ansible'
    vault_c_l_i_1.post_process_args({'action': 'encrypt', 'args': [], 'command': ['ansible-vault', 'encrypt']})

# Generated at 2022-06-24 18:13:17.055585
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    pass
