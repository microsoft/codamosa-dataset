

# Generated at 2022-06-24 18:05:16.477436
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    int_0 = -3764
    vault_c_l_i_0 = VaultCLI(int_0)
    vault_c_l_i_0.setup()
    vault_c_l_i_0.execute_view()


# Generated at 2022-06-24 18:05:24.020633
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # Local variables:
    test_vault_cli_0 = None
    test_vault_id_0 = None
    test_vault_id_1 = None
    test_vault_id_2 = None
    # Body of method execute_encrypt of class VaultCLI
    # [18] test_VaultCLI_execute_encrypt
    # [1] test_VaultCLI_execute_encrypt
    test_vault_id_0 = "test_vault_id_0"
    test_vault_cli_0 = VaultCLI(test_vault_id_0)
    # [2] test_VaultCLI_execute_encrypt
    test_vault_id_1 = "test_vault_id_1"
    # [3] test_VaultCLI_execute

# Generated at 2022-06-24 18:05:33.199637
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    if not is_public_host():
        pytest.skip('Must be run on a public host')

    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)
    f = None
    output_file = None
    try:
        # This call might raise an exception, we need to catch it to finish this test
        vault_c_l_i_0.execute_decrypt()
    except:
        e = sys.exc_info()[1]
        pytest.fail('Unexpected exception raised: %s' % repr(e))


# Generated at 2022-06-24 18:05:41.641391
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # make sure we have an output file if we are going to open the editor
    os.environ['ANSIBLE_VAULT_OUTPUT_FILE'] = "/tmp/ansible-vault-output-file"
    vault_c_l_i_0 = VaultCLI(0)
    vault_c_l_i_0.execute_create()

    # restore env
    del os.environ['ANSIBLE_VAULT_OUTPUT_FILE']


# Generated at 2022-06-24 18:05:52.401528
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    """Test for execute_encrypt_string of class VaultCLI
    """
    # Setup
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)
    vault_c_l_i_0.encrypt_vault_id = 'yjXtBqt'
    vault_c_l_i_0.encrypt_secret = '-sHHs'
    vault_c_l_i_0.FROM_ARGS = '*kkHpa74'
    vault_c_l_i_0.FROM_PROMPT = 'dNPt.5eZ'
    vault_c_l_i_0.FROM_STDIN = '^M(F8g'

    # Invoke method
    vault_c_l_i_0._

# Generated at 2022-06-24 18:06:00.144289
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_c_l_i_0 = VaultCLI(8)

# Generated at 2022-06-24 18:06:04.074002
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)
    context_0 = AnsibleCLI()
    context_0.CLIARGS['args'] = ['test.txt']
    vault_c_l_i_0.execute_decrypt()


# Generated at 2022-06-24 18:06:11.778474
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0) # Create an instance of a class
    # print('Running test_VaultCLI_post_process_args')
    # TODO: test using a mocker object and/or patch
    # TODO: test expected errors (such as missing required args) result in expected exceptions
    vault_c_l_i_0.post_process_args()

    # TODO: test that output is what we expect considering command-line input
    assert vault_c_l_i_0.encrypt_string_read_stdin == False


# Generated at 2022-06-24 18:06:20.195488
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)
    func_0 = context.CLIARGS.get('func')
    if func_0 is None:
        context.CLIARGS['func'] = 'default'
    else:
        context.CLIARGS['func'] = func_0
    func_1 = context.CLIARGS.get('func')
    if func_1 == 'default':
        func_1 = 'decrypt'
    context.CLIARGS['func'] = func_1
    del func_0
    del func_1
    vault_c_l_i_0.execute()



# Generated at 2022-06-24 18:06:23.743144
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    int_0 = -99
    vault_c_l_i_0 = VaultCLI(int_0)
    # TODO: test of post_process_args needs to be added


# Generated at 2022-06-24 18:07:05.111699
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # Not implemented yet, just the function stub
    int_1 = -1470
    vault_c_l_i_1 = VaultCLI(int_1)
    vault_c_l_i_1.execute_decrypt()


# Generated at 2022-06-24 18:07:08.161571
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # testcase 1
    int_0 = -1470
    vault_c_l_i_1 = VaultCLI(int_0)
    vault_c_l_i_1.execute_encrypt()


# Generated at 2022-06-24 18:07:17.713792
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)
    display.column = 4

# Generated at 2022-06-24 18:07:29.664245
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # create an instance of VaultCLI
    vault_c_l_i_0 = VaultCLI(0)
    # create an instance of AnsibleOptions
    ansi_opts_0 = AnsibleOptions(b"ansible-playbook")
    ansi_opts_0.help = 'foo'
    ansi_opts_0.listhosts = 'foo'
    ansi_opts_0.syntax = 'foo'
    ansi_opts_0.version = 'foo'
    ansi_opts_0.run_hosts = AnsibleOptions()
    ansi_opts_0.run_hosts.version = 'foo'
    ansi_opts_0.run_hosts.help = 'foo'

# Generated at 2022-06-24 18:07:31.080331
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)


# Generated at 2022-06-24 18:07:41.597259
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    int_0 = 100
    vault_c_l_i_0 = VaultCLI(int_0)
    loader = DataLoader()
    vault_id_0 = 'test'
    vault_id_1 = 'test'
    vault_password_file_0 = ''
    vault_password_file_1 = ''
    ask_vault_pass_0 = False
    context_0 = {'encrypt_vault_id': None, 'output_file': None, 'ask_vault_pass': False, 'args': [], 'encrypt_string_prompt': False, 'new_vault_id': None, 'show_string_input': False, 'new_vault_password_file': None, 'encrypt_string_stdin_name': None, 'encrypt_string_names': []}
    context.CL

# Generated at 2022-06-24 18:07:43.969277
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)
    vault_c_l_i_0.execute_encrypt()


# Generated at 2022-06-24 18:07:48.548658
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    int_0 = 1751
    vault_c_l_i_0 = VaultCLI(int_0)
    try:
        vault_c_l_i_0.execute_decrypt()
    except TypeError:
        pass


# Generated at 2022-06-24 18:07:50.164604
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    print("test_VaultCLI_execute_edit")
    vault_c_l_i_0 = VaultCLI()
    vault_c_l_i_0.execute_edit()


# Generated at 2022-06-24 18:07:52.472914
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    print("Testing run")
    vault_c_l_i_0 = VaultCLI()
    vault_c_l_i_0.run()


# Test program

# Generated at 2022-06-24 18:08:44.118824
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)

    try:
        vault_c_l_i_0.execute_encrypt()
    except Exception as e:
        assert False
    else:
        assert True


# Generated at 2022-06-24 18:08:46.293201
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # vault_cli = VaultCLI()
    display.Display.verbosity = 2
    # vault_cli.execute_encrypt()


VaultCLI.run = run



# Generated at 2022-06-24 18:08:51.771920
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)
    class_0 = VaultCLI
    list_1 = ['a', 'b', 'c']
    # Call method execute_create of class VaultCLI
    class_0.execute_create(vault_c_l_i_0, list_1)


# Generated at 2022-06-24 18:08:53.076119
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    test_case_0()


# Generated at 2022-06-24 18:08:55.964294
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_c_l_i_0 = VaultCLI(None)
    arg_0 = None
    new_line_0 = '\n'
    vault_c_l_i_0.pager(new_line_0)
    vault_c_l_i_0.execute_view(arg_0)


# Generated at 2022-06-24 18:09:02.626796
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)

    # Verify Arguments
    assert_true(context.CLIARGS['args'] == context.CLIARGS['args'])

    # Verify Member Variables
    assert_false(vault_c_l_i_0.editor == vault_c_l_i_0.editor)


# Generated at 2022-06-24 18:09:10.605793
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # Constructor test
    try:
        int_0 = -1470
        vault_c_l_i_0 = VaultCLI(int_0)
    except Exception as e:
        print("Failed constructor test for class VaultCLI: %s" % e)
        return

    # Method test
    try:
        str_0 = "T"
        str_1 = "e"
        str_2 = "s"
        str_3 = "t"
        test_case_0()
        test_case_0()
    except Exception as e:
        print("Failed method test for class VaultCLI: %s" % e)
        return
    return


# Generated at 2022-06-24 18:09:25.340705
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    data = {'args': ['-'],
            'ask_vault_pass': False,
            'create_new_password': False,
            'decrypt': False,
            'encrypt': True,
            'encrypt_string': False,
            'encrypt_string_prompt': False,
            'encrypt_string_read_stdin': False,
            'encrypt_vault_id': 'default',
            'edit': False,
            'generate_encryption_key': False,
            'keep_vault_order': False,
            'new_vault_id': None,
            'new_vault_password_file': None,
            'output_file': '-',
            'vault_ids': ['default'],
            'vault_password_files': []}
    ansible_options

# Generated at 2022-06-24 18:09:29.429282
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # TODO: create a test case to verify the result of execute_encrypt_string
    print('Test not implemented')


# Generated at 2022-06-24 18:09:41.238129
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    int_0 = -2389
    vault_c_l_i_0 = VaultCLI(int_0)

# Generated at 2022-06-24 18:10:35.178292
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    int_0 = -969
    vault_c_l_i_0 = VaultCLI(int_0)
    ansible_options_error_0 = None
    try:
        vault_c_l_i_0.execute_encrypt_string()
    except AnsibleOptionsError as e:
        ansible_options_error_0 = e
    display_0 = Display(False, True, False)
    display_0.display('The plaintext provided from the prompt was empty, not encrypting', stderr=True)
    assert(str(ansible_options_error_0) == 'The plaintext provided from the prompt was empty, not encrypting')


# Generated at 2022-06-24 18:10:44.302779
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    int_0 = -1864
    vault_c_l_i_0 = VaultCLI(int_0)
    int_1 = -3193
    str_0 = '2(:#GGNj+<I$wE'
    str_1 = 'bT7TzkxMO>J;'
    dict_0 = {
        str_0: int_0,
    }
    dict_1 = {
        str_0: int_0,
        str_1: int_1,
    }
    dict_2 = {
        str_0: dict_0,
    }
    dict_3 = {
        str_0: dict_1,
        str_1: int_1,
    }
    list_0 = [
        int_0,
    ]

# Generated at 2022-06-24 18:10:48.812141
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # vault_c_l_i_0 is an instance of class VaultCLI
    vault_c_l_i_0 = VaultCLI()

    vault_c_l_i_0.execute_encrypt_string()



# Generated at 2022-06-24 18:10:55.734587
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)

    # Test the attribute args is initialized correctly
    assert (context.CLIARGS['args'] == 'args')
    # Test the attribute editor is initialized correctly
    assert (vault_c_l_i_0.editor == 'editor')


# Generated at 2022-06-24 18:10:56.942423
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:11:01.211683
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)
    int_0 = -1689
    str_0 = "A"
    str_1 = "A"
    str_2 = "A"
    str_3 = "A"
    vault_c_l_i_0.run(int_0, str_0, str_1, str_2, str_3)


# Generated at 2022-06-24 18:11:02.838315
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    string_0 = "ansible_test_test-test"
    int_0 = 0
    int_1 = 0
    # FIXME: how to test this?
    return


# Generated at 2022-06-24 18:11:07.960296
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    int_0 = 7
    vault_c_l_i_0 = VaultCLI(int_0)
    int_1 = -2448
    vault_c_l_i_1 = VaultCLI(int_1)
    vault_c_l_i_1.encrypt_secret = 'D|\x16\x0e\x16\x1d(g\x1f$\x1c'
    int_2 = -2329
    vault_c_l_i_2 = VaultCLI(int_2)
    vault_c_l_i_2.encrypt_secret = '\x1d\x1f\x1f(\x1c\x11\x17'
    int_3 = -2338

# Generated at 2022-06-24 18:11:13.527772
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)
    dict_0 = dict()
    dict_0['args'] = ['ansible.cfg']
    dict_0['encrypt_vault_id'] = 'ansible'
    dict_0['func'] = vault_c_l_i_0.execute_create
    dict_0['help'] = 'create and open a new vaulted file for editing'
    dict_0['output_file'] = None
    dict_0['verbosity'] = 0
    context.CLIARGS = dict_0
    context.CLIARGS['func']()


# Generated at 2022-06-24 18:11:21.160818
# Unit test for method run of class VaultCLI

# Generated at 2022-06-24 18:12:18.114615
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # This is probably the simplest case
    test_case_0()
    # if we add --encrypt-string-prompt, it will also prompt for text
    # to encrypt.


# Generated at 2022-06-24 18:12:21.978305
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # set up
    int_0 = -2490
    vault_c_l_i_0 = VaultCLI(int_0)

    # testing
    vault_c_l_i_0.execute_rekey()


# Generated at 2022-06-24 18:12:30.878830
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    assert len(VaultCLI._create_validators()) == 12
    assert len(VaultCLI._name_options_validators()) == 2
    assert len(VaultCLI.init_parser()) == 1
    assert len(VaultCLI.get_optparser()) == 1
    assert len(VaultCLI.normalize_args([])) == 1
    assert len(VaultCLI.setup_vault_secrets(ConfigData(), [], [], False, False)) == 1
    assert len(VaultCLI.execute()) == 1
    assert len(VaultCLI.execute_encrypt()) == 1
    assert len(VaultCLI.format_ciphertext_yaml(b'', None, None)) == 1
    assert len(VaultCLI.execute_encrypt_string()) == 1

# Generated at 2022-06-24 18:12:32.695395
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:12:43.289938
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)


# Generated at 2022-06-24 18:12:44.802625
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    test_case_0()


# Generated at 2022-06-24 18:12:46.149167
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    pass


# Generated at 2022-06-24 18:12:48.755797
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 18:12:56.268914
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    int_0 = -59400
    vault_c_l_i_0 = VaultCLI(int_0)
    str_0 = 'IWFc'
    args_0 = []
    bool_0 = False
    exit_0 = None
    exit_1 = vault_c_l_i_0.post_process_args(str_0, args_0, bool_0)
    assert (exit_0 == exit_1)


# Generated at 2022-06-24 18:13:08.810984
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Test the VaultCLI class for the execute_encrypt_string method
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)

    def test_case_0():
        # Test the encoding and decoding of the YAML string
        yaml_0 = 'Hello World!'
        yaml_1 = to_text(vault_c_l_i_0.editor.encrypt_bytes(to_bytes(yaml_0), 'secret'))
        yaml_2 = to_text(vault_c_l_i_0.editor.decrypt(yaml_1))
        assert yaml_2 == yaml_0
        # Test the execution of the encrypt_string function
        vault_c_l_i_0.execute_encrypt_string()
        

# Generated at 2022-06-24 18:14:21.393229
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    int_0 = -1821
    vault_c_l_i_0 = VaultCLI(int_0)
    int_1 = -115
    a_r_g_s_0 = [ '-', "-encrypt_string_prompt", "-encrypt_string_names", "foo, bar" ]
    context_0 = Context()
    context_0.CLIARGS = dict()

# Generated at 2022-06-24 18:14:22.648503
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    pass


# Generated at 2022-06-24 18:14:25.053826
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    int_0 = -1470
    vault_c_l_i_0 = VaultCLI(int_0)
    vault_c_l_i_0.execute_encrypt()


# Generated at 2022-06-24 18:14:29.716599
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # argv = ['ansible-vault', 'view', '--vault-id', 'development@prompt', 'foo.yml']
    argv = ['ansible-vault', 'view', 'foo.yml']

    with patch.object(sys, 'argv', argv):
        int_0 = -1470
        vault_c_l_i_0 = VaultCLI(int_0)
        assert type(vault_c_l_i_0) == VaultCLI
        vault_c_l_i_0.execute_decrypt()


# Generated at 2022-06-24 18:14:37.166277
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():

    print("Test encrypting file...")
    test_file = path_dwim("test_file.txt")

    secret = "test"

    vault_editor = VaultLib({"test": secret})
    vault_editor.encrypt_file(test_file, secret)

    print("File encrypted.")
    return
