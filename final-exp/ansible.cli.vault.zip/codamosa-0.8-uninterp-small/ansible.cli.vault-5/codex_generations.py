

# Generated at 2022-06-24 18:05:44.277019
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)
    # NOTE: this test will fail unless the following environment variables are defined
    # and have the same value that would have been used in the real Ansible run
    # export ANSIBLE_CONFIG=<contents of the ansible.cfg file>
    # export ANSIBLE_VAULT_PASSWORD_FILE=<path to the vault password file>
    # export ANSIBLE_VAULT_PASSWORD_FILE_2=<path to the new vault password file>
    # export ANSIBLE_VAULT_ID_1=<vault id of the old vault password file>
    # export ANSIBLE_VAULT_ID_2=<vault id of the new vault password file>
    # export ANSIBLE_CONFIG

# Generated at 2022-06-24 18:05:46.296422
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    VaultCLI.execute_encrypt_string()


# Generated at 2022-06-24 18:05:55.716555
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)
    arg_0 = '-'
    arg_1 = [
        arg_0
    ]
    context.CLIARGS['args'] = arg_1
    arg_2 = 'file.yml'
    arg_2 = 'file.yml'
    arg_3 = [
        arg_2
    ]
    context.CLIARGS['args'] = arg_3
    # execute method of object vault_c_l_i_0
    vault_c_l_i_0.execute_decrypt()
    # FIXME: implement test
    assert True



# Generated at 2022-06-24 18:05:59.997141
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    int_0 = 1492
    vault_c_l_i_0 = VaultCLI(int_0)

    # Test for Method 'execute_view' of class 'VaultCLI'
    vault_c_l_i_0.execute_view()


# Generated at 2022-06-24 18:06:11.237726
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    def run_test():
        test_utils.unittest_setup_testcase()
        test_utils.unittest_setup_vault_password_file()

        # set up vault credentials
        fake_loader = DictDataLoader({
            'vault_password_files': [test_utils.VAULT_PASSWORD_FILE_PATH],
        })
        vault_c_l_i = VaultCLI(0)
        vault_c_l_i.setup_vault_secrets(fake_loader)
        # now we have vault_c_l_i.vault_secrets

        # set up the display
        vault_c_l_i.display = Display()
        vault_c_l_i.display.verbosity = 3

        a_e_m_s = test_utils.MockFileObject

# Generated at 2022-06-24 18:06:15.749720
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)
    str_0 = 'testArg'
    args = [str_0]
    context.CLIARGS.update({'args': args})
    vault_c_l_i_0.execute_create()


# Generated at 2022-06-24 18:06:19.649566
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # Given
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)
    # When
    vault_c_l_i_0.execute_view()



# Generated at 2022-06-24 18:06:23.891043
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    int_0 = 562
    vault_c_l_i_0 = VaultCLI(int_0)
    args_0 = MagicMock(name='args_0')
    vault_c_l_i_0.post_process_args(args_0)


# Generated at 2022-06-24 18:06:34.507498
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)
    list_0 = list()
    list_0.append("/usr/lib/python3.7/site-packages/ansible/plugins/loader/vars.py")

    try:
        vault_c_l_i_0.execute_create()
    except Exception as exception_0:
        print(exception_0)
    try:
        vault_c_l_i_0.execute_create()
    except Exception as exception_1:
        print(exception_1)


# Generated at 2022-06-24 18:06:44.664883
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)
    str_0 = 'b/'
    str_1 = 'vault_password_file'
    str_2 = 'b/'
    context.CLIARGS[str_1] = str_2
    context.CLIARGS['new_vault_id'] = str_0
    str_3 = 'b/'
    str_4 = 'new_vault_password_file'
    str_5 = 'b/'
    context.CLIARGS[str_4] = str_5
    str_6 = 'cp'
    str_7 = 'new_encrypt_vault_id'
    str_8 = 'b/'

# Generated at 2022-06-24 18:07:13.913185
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli_0 = VaultCLI()
    vault_cli_0.execute_encrypt = MagicMock()
    int_0 = 1583
    vault_cli_0.execute_encrypt(int_0)
    vault_cli_0.execute_encrypt.assert_called_once_with(int_0)


# Generated at 2022-06-24 18:07:17.220543
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    if (not C.DEFAULT_VAULT_PASSWORD_FILE):
        vault_c_l_i_0 = VaultCLI()
        vault_c_l_i_0.execute_create()


# Generated at 2022-06-24 18:07:18.821372
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    assert True


# Generated at 2022-06-24 18:07:24.320627
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    int_0 = 9182
    vault_c_l_i_0 = VaultCLI(int_0)
    result = vault_c_l_i_0.execute_view()
    assert result is None


# Generated at 2022-06-24 18:07:26.617428
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)

    # Call method: execute_encrypt of class VaultCLI
    # vault_c_l_i_0.execute_encrypt()


# Generated at 2022-06-24 18:07:39.111342
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    import tempfile
    from .vaultlib import VaultLib
    # TODO: use tempfile for testing so we don't leave a mess

    # Create a temporary file
    f = tempfile.NamedTemporaryFile()
    plaintext = 'hello'
    b_plaintext = to_bytes(plaintext)

    # Encrypt the plaintext to the tempfile
    vault_id = None
    old_secret = b'secret'
    new_secret = b'new secret'
    vault = VaultLib([old_secret])

    vault.encrypt_bytes(b_plaintext, old_secret, output_file=f.name, vault_id=vault_id)
    new_ciphertext = vault.encrypt_bytes(b_plaintext, new_secret, vault_id=vault_id)

    # Get the

# Generated at 2022-06-24 18:07:46.640762
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    options = {'ask_vault_pass': False, 'new_vault_password_file': None, 'help': False, 'vault_id': None, 'encrypt_vault_id': None, 'vault_password_file': '/Users/mparker/.vault_pass.txt', 'output_file': '', 'new_vault_id': None}

    # FIXME: yuck. options needs to be a dict, not a list of args
    CLIARGS = parse_vault_options(['ansible-vault', 'encrypt_string', '--name', 'secret', '-', '--vault-id', 'default'], options)
    context.CLIARGS = CLIARGS
    # context.CLIARGS['vault_password_file'] = '/Users/mparker/.vault_

# Generated at 2022-06-24 18:07:55.995814
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Test with strings from args and from the prompt, and show a delimeter in the output.
    # setup all the needed args, defaults, etc
    test_args = ['-n', 'foo_var', 'foo_var_value', '--encrypt-string-prompt']
    context.CLIARGS = CLI.parse(args=test_args)
    context.CLIARGS['args'] = []
    context.CLIARGS['encrypt_string_prompt'] = True
    context.CLIARGS['encrypt_string_read_stdin'] = False
    context.CLIARGS['encrypt_string_stdin_name'] = None
    context.CLIARGS['vault_ids'] = ['test_vault_id']
    context.CLIARGS['ask_vault_pass'] = False

# Generated at 2022-06-24 18:08:04.967684
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # capture output to stdout
    old_stdout = sys.stdout
    string_io = io.StringIO()
    sys.stdout = string_io
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)
    # TODO: create file /tmp/ansible_file_ybKw5m containing encrypted text
    file_0 = "/tmp/ansible_file_ybKw5m"
    vault_c_l_i_0.execute_decrypt()
    sys.stdout = old_stdout
    string_0 = string_io.getvalue()
    # match output to string: Decryption successful
    expected_0 = "Decryption successful"
    assert_true((expected_0 in string_0), "'Decryption successful' not in output")

# Generated at 2022-06-24 18:08:16.948039
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    int_0 = 1558
    vault_c_l_i_0 = VaultCLI(int_0)
    # Variables to facilitate testing, tests should not rely on these as they are subject to removal.
    vault_c_l_i_0.editor = vault_editor_0 = VaultEditor(None)
    # Create a test spy for method rekey_file of class VaultEditor
    vault_editor_0.rekey_file = MagicMock()
    # Unit test for method execute_rekey of class VaultCLI
    # Unit test for method execute_rekey of class VaultCLI
    vault_editor_0.rekey_file.assert_called_with(None, None, None)


# Generated at 2022-06-24 18:09:07.259717
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)
    vault_c_l_i_0.execute_decrypt()


# Generated at 2022-06-24 18:09:10.380667
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    int_1 = 1594
    vault_c_l_i_1 = VaultCLI(int_1)
    vault_c_l_i_1.execute_encrypt_string()


# Generated at 2022-06-24 18:09:18.336870
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)

    # No values set so we don't test to see if the pager is called
    vault_c_l_i_0.pager = MagicMock()

    # Invoke execute_view on class VaultCLI
    vault_c_l_i_0.execute_view()


# Generated at 2022-06-24 18:09:21.280139
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():

    # setup test
    # The test will fail because it has not been implemented yet
    assert False, "TODO: implement test"
    # teardown test


# Generated at 2022-06-24 18:09:25.992578
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    int_1 = 1701
    p_a_array_1 = [ 'arg1', 'arg2', 'arg3', 'arg4', 'arg5' ]
    vault_c_l_i_1 = VaultCLI(int_1)
    vault_c_l_i_1.post_process_args(p_a_array_1)


# Generated at 2022-06-24 18:09:37.473682
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    # Initializing f_a_r_g_s
    f_a_r_g_s = []

    # Initializing args
    args = f_a_r_g_s

    # Initializing context
    context = AnsibleVaultCLI()

    # Initializing loader
    loader = None

    # Initializing ask_vault_pass
    ask_vault_pass = True

    # Initializing new_vault_id
    new_vault_id = None

    # Initializing create_new_password
    create_new_password = False

    # Initializing new_vault_password_file
    new_vault_password_file = None

    # Initializing output_file
    output_file = None

    # Initializing vault_password_files
    vault_password_files = []

    # Initializing vault

# Generated at 2022-06-24 18:09:45.264386
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    cmd_line_args = ['ansible-vault', 'decrypt', 'foo']
    vault_c_l_i_0 = VaultCLI(0)
    vault_c_l_i_0.post_process_args(cmd_line_args)

if __name__ == '__main__':
    test_case_0()
    test_VaultCLI_post_process_args()
    test_parse_yaml_from_bytes()
    test_parse_yaml_from_file()
    test_parse()

# Generated at 2022-06-24 18:09:46.854876
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():

    # Parameters
    self = VaultCLI()

    # Test Execution
    self.execute_rekey()


# Generated at 2022-06-24 18:09:49.518845
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    def test_post_process_args_0():
        int_0 = 1601
        vault_c_l_i_0 = VaultCLI(int_0)


if __name__ == '__main__':
    test_VaultCLI_post_process_args()

# Generated at 2022-06-24 18:09:52.065014
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # Setup

    # test
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)

    # verify
    # FIXME: verify that the value of vault_c_l_i_0 is correct
    assert True


# Generated at 2022-06-24 18:11:49.970782
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    int_1 = 1157
    vault_c_l_i_1 = VaultCLI(int_1)

    vault_c_l_i_1.execute_edit()


# Generated at 2022-06-24 18:11:53.243244
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)
    args = []
    context.CLIARGS = {"action": "create", "args": args}
    vault_c_l_i_0.execute_create()


# Generated at 2022-06-24 18:12:01.927572
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)
    # FIXME: call to execute_rekey not implemented
    # vault_c_l_i_0.<locals>.execute_rekey(vault_c_l_i_0)

# **********************
# Module level testing
# **********************
# Uncomment the below to run some basic module level tests
# if __name__ == '__main__':
#     test_case_0()
#     test_VaultCLI_execute_rekey()
#     print('Tests completed')

# Generated at 2022-06-24 18:12:09.908461
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_c_l_i = VaultCLI(1601)
    # Put your test code here:
    raise Exception('test_VaultCLI_execute_view not implemented')

if __name__ == '__main__':
    import sys
    try:
        test_case_0()
    except Exception as exc:
        print('Exception caught: %s' % exc)
        sys.exit(1)
    else:
        print('Test passed')
    sys.exit(0)

# Generated at 2022-06-24 18:12:14.266288
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)
    with pytest.raises(AnsibleOptionsError):
        vault_c_l_i_0.execute_create()



# Generated at 2022-06-24 18:12:18.755681
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    s_0 = 'args'
    s_1 = 'edit'
    b = [s_1]
    # context.CLIARGS.__setitem__(s_0, b)
    # t0 = VaultCLI.execute_edit(s_1)
    # print t0


# Generated at 2022-06-24 18:12:21.528725
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_c_l_i = VaultCLI(0, args=['test_file'])
    vault_c_l_i.execute_encrypt()



# Generated at 2022-06-24 18:12:25.149514
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    int_0 = 1601
    vault_c_l_i_0 = VaultCLI(int_0)
    assert_equal(None, vault_c_l_i_0.run())


# Generated at 2022-06-24 18:12:28.537013
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    from ansible.errors import AnsibleError
    vault_c_l_i_0 = VaultCLI(6)
    f = ['-']
    try:
      vault_c_l_i_0.execute_view()
    except AnsibleError:
      pass


# Generated at 2022-06-24 18:12:29.692580
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    test_case_0()
