

# Generated at 2022-06-20 13:23:37.319021
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # FIXME: Some test that calls execute_create and verifies that it works.
    assert False


# Generated at 2022-06-20 13:23:48.521104
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Load test yaml file and generate test arguments
    _cli_args = yaml.safe_load(open(os.path.join(os.path.dirname(__file__), './unit/ansible-vault-args.yaml'), 'r'))['execute_encrypt_string']

    # Add a dummy file for testing '--encrypt-string-prompt'
    _cli_args.insert(0, '--vault-id=' + C.DEFAULT_VAULT_IDENTITY)
    _cli_args.insert(0, 'tests/vault/test_vault.yaml')

    # Generate test context
    runner = CliRunner()
    result = runner.invoke(cli.main(), _cli_args)
    assert result.exit_code == 0
    assert 'Encryption successful' in result.output

# Generated at 2022-06-20 13:23:50.112058
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()
    return

# Generated at 2022-06-20 13:23:58.233972
# Unit test for method init_parser of class VaultCLI

# Generated at 2022-06-20 13:24:11.718632
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    import pickle
    cli_args_orig = pickle.load(open('./test_data/test_VaultCLI_execute_decrypt_cli_args_orig.pkl', 'rb'))
    tmp = pickle.load(open('./test_data/test_VaultCLI_execute_decrypt_tmp.pkl', 'rb'))
    from ansible.parsing import vault
    f = tmp['f']
    from ansible.cli import CLI
    from ansible.context import context
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils import context_objects

# Generated at 2022-06-20 13:24:17.094229
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    from ansible.cli.vault import VaultCLI
    from ansible.utils.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.errors import AnsibleOptionsError
    vault_cli = VaultCLI()
    vault_cli.post_process_args()
test_VaultCLI_post_process_args()

# Generated at 2022-06-20 13:24:19.917553
# Unit test for constructor of class VaultCLI
def test_VaultCLI():
    vault_cli = VaultCLI()
    vault_cli.run()

# import the actions into the global namespace, for main()
from ansible.cli.vault import VaultCLI as Action

if __name__ == '__main__':
    Action().run()

# Generated at 2022-06-20 13:24:30.583026
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    va = VaultCLI()
    context_args = {}
    context_args['diff'] = False
    context_args['args'] = ['file.txt']
    context_args['encrypt_secret'] = None
    context_args['decrypt'] = True
    context_args['encrypt_vault_id'] = None
    context_args['output_file'] = None
    context_args['encrypt_string_stdin'] = False
    context_args['encrypt_string_prompt'] = False
    context_args['encrypt_string_names'] = []
    context_args['encrypt_string_read_stdin'] = False
    context_args['encrypt_string_stdin_name'] = None
    context_args['encrypt_string'] = False
    context.CLIARGS = context_args



# Generated at 2022-06-20 13:24:32.803554
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    c = VaultCLI()
    c.setup_default_loader = lambda : None
    c.editor = lambda x : None
    c.execute_create()

# Generated at 2022-06-20 13:24:33.417440
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    pass

# Generated at 2022-06-20 13:25:15.301196
# Unit test for method format_ciphertext_yaml of class VaultCLI
def test_VaultCLI_format_ciphertext_yaml():
    # Initialize command line arguments
    parser = CLI.base_parser(
        usage='usage: %prog [options] encrypt [--vault-id VAULT_IDS] [vaultfile]',
        vault_opts=True,
        desc="""Encrypt a file in-place (does not create a new file).
                For example:

                Rename variables.yml to variables.yml.old
                ansible-vault encrypt variables.yml --vault-password-file .vault_pass.txt
                """)

    parser.add_argument('--output', dest='output_file', default=None, help="The output file name. Use - for stdout")

# Generated at 2022-06-20 13:25:17.162480
# Unit test for method init_parser of class VaultCLI
def test_VaultCLI_init_parser():
    cli = VaultCLI(args=[])
    cli.init_parser()

# Generated at 2022-06-20 13:25:23.908162
# Unit test for method init_parser of class VaultCLI
def test_VaultCLI_init_parser():
    runner = CliRunner()
    result = runner.invoke(VaultCLI, [])
    assert result.exit_code == 0
    assert re.search(r'\bcreate\b', result.output)
    assert re.search(r'\bedit\b', result.output)
    assert re.search(r'\bview\b', result.output)
    assert re.search(r'\bencrypt\b', result.output)
    assert re.search(r'\bdecrypt\b', result.output)
    assert re.search(r'\brekey\b', result.output)


# Generated at 2022-06-20 13:25:27.849936
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    args = ['-v', '--ask-vault-pass']
    load_cli_arguments(args)
    vault_cli = VaultCLI()
    vault_cli.execute_edit()


# Generated at 2022-06-20 13:25:34.633793
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    fixture = VaultCLI()
    fixture.ask_vault_pass = False
    args = ['/path/to/file']
    context.CLIARGS['args'] = args
    fixture.encrypt_secret = 'mysecret'
    expected = ['\n']
    result = fixture.execute_encrypt_string()
    assert result == expected


# Generated at 2022-06-20 13:25:36.500340
# Unit test for method init_parser of class VaultCLI
def test_VaultCLI_init_parser():
    vault_cli = VaultCLI()
    vault_cli.init_parser()

# Generated at 2022-06-20 13:25:40.978743
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    context.CLIARGS = context.make_context('create', args=['test'], vault_password_file=['test_data/test_vault.txt'], encrypt_vault_id='testvault')
    obj = VaultCLI()
    obj.execute_encrypt_string()

# Generated at 2022-06-20 13:25:51.908591
# Unit test for method init_parser of class VaultCLI
def test_VaultCLI_init_parser():
    from ansible.errors import AnsibleOptionsError
    
    context, display = assert_setup_vault_module()
    
    options = context.CLIARGS
    options['func'] = None
    
    #  create
    options['command'] = 'create'
    vault_cli = VaultCLI(context)
    try:
        vault_cli.parse()
    except AnsibleOptionsError:
        pass
    else:
        assert False, "Should have thrown an exception"
        
    options['args'] = [ 'foo' ]
    vault_cli = VaultCLI(context)
    vault_cli.parse()
    
    #  edit
    options['command'] = 'edit'
    options['args'] = []
    vault_cli = VaultCLI(context)

# Generated at 2022-06-20 13:26:00.478648
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_cli = VaultCLI()
    vault_cli.decrypt_vault_ids = ['id']
    vault_cli.decrypt_secrets = ['secret']
    vault_cli.editor = mock()
    args = ['a', 'b']
    context.CLIARGS = {'args': args, 'output_file': 'c'}
    vault_cli.execute_decrypt()
    assert {'args': args, 'output_file': 'c'} == context.CLIARGS
    assert vault_cli.decrypt_vault_ids == ['id']
    assert vault_cli.decrypt_secrets == ['secret']
    assert vault_cli.editor == mock()



# Generated at 2022-06-20 13:26:12.091179
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # Ensure that we get expected behaviour of the method with various combinations of arguments
    import ansible_vault
    ansible_vault.VaultLib = mock.MagicMock()
    ansible_vault.VaultEditor = mock.MagicMock()
    ansible_vault.VaultEditor.return_value = mock.MagicMock()
    ansible_vault.VaultEditor.create_file = mock.MagicMock()
    ansible_vault.CONTEXTS = {
        'CLIARGS': {
            'args': ['foo'],
            'output_file': 'bar',
            'enc_vault_id': 'baz',
            'encrypt_secret': mock.MagicMock()
        }
    }
    vc = ansible_vault.VaultCLI()
    vc

# Generated at 2022-06-20 13:27:10.506875
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI(args=['test_vault_file.yml'])
    try:
        if os.path.isfile('test_vault_file.yml'):
            os.remove('test_vault_file.yml')
        vault_cli.execute_create()
        assert os.path.isfile('test_vault_file.yml')
    finally:
        if os.path.isfile('test_vault_file.yml'):
            os.remove('test_vault_file.yml')



# Generated at 2022-06-20 13:27:16.907851
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.plugins.loader import vault_loader, callback_loader

    loader = DataLoader()
    passwords = {}

# Generated at 2022-06-20 13:27:25.055176
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.encrypt_secret = 'foo'
    vault_cli.new_encrypt_secret = 'foo'
    vault_cli.new_encrypt_vault_id = 'foo'
    # FIXME: test me
    # FIXME: mock out editor?
    # FIXME: plumb in vault_id, use the default new_vault_secret for now

# Generated at 2022-06-20 13:27:28.702784
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # obj = VaultCLI()
    pass


# Generated at 2022-06-20 13:27:30.747701
# Unit test for method init_parser of class VaultCLI
def test_VaultCLI_init_parser():
    assert True

# Generated at 2022-06-20 13:27:35.840022
# Unit test for method init_parser of class VaultCLI
def test_VaultCLI_init_parser():
    x = VaultCLI()
    parser = x.init_parser()
    assert(type(parser) == argparse.ArgumentParser)


# Generated at 2022-06-20 13:27:44.592077
# Unit test for method format_ciphertext_yaml of class VaultCLI
def test_VaultCLI_format_ciphertext_yaml():
    vaultcli = VaultCLI()
    b_ciphertext = b'\nhello\n'
    name = 'password'
    assert vaultcli.format_ciphertext_yaml(b_ciphertext, name=name) == "password: !vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3936306435336664343730343538613031323264643132656635343633343630653365383664396561\n          6464653034643432333137383338383033393462373735363335323461623361363335373738373233\n          63333965353639633331633262646166326538666563633631643532306236\n"

# Generated at 2022-06-20 13:27:55.556916
# Unit test for constructor of class VaultCLI
def test_VaultCLI():
    from ansible.utils.path import unfrackpath

    self_dir = os.path.dirname(unfrackpath(__file__))
    paths = [os.path.join(self_dir, 'fb_vault'),  # password file
             os.path.join(self_dir, 'fb_id_rsa'),  # private key file
             os.path.join(self_dir, 'vault')]  # test data directory

    for _dir in paths:
        if not os.path.exists(_dir):
            os.mkdir(_dir)
        if not os.access(_dir, os.W_OK):
            raise Exception('Required directory %s is not writable' % _dir)
    vault_secret = b'ansible'

# Generated at 2022-06-20 13:28:04.675492
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    from ansible.errors import AnsibleError
    from ansible.parsing.vault import VaultLib
    import ansible.cli.vault as vault
    import ansible.utils
    # Create the object
    try:
        my_obj = vault.VaultCLI(['--output', 'output.txt'])
    except AnsibleError as e:
        assert False

    # Test with args
    res = my_obj.execute_rekey(['file1.txt'])
    assert res is None
    # Test if output file has been created
    if os.path.isfile('output.txt'):
        # Test successful output message
        assert 'Rekey successful' in open('output.txt').read()
    else:
        assert False

    # Remove output file
    os.remove('output.txt')

# Unit

# Generated at 2022-06-20 13:28:12.326605
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # this class is static in the test, so no need to make an object
    # vaultcli = VaultCLI(None, None)
    # vaultcli.execute_rekey()
    # assert False, "Test to be implemented"
    pass

    def pager(self, text):
        if hasattr(self, 'pager'):
            text = to_bytes(text, nonstring='passthru')
            pager(text)
        else:
            display.display(text)
        # Unit test for method pager of class VaultCLI

# Generated at 2022-06-20 13:31:07.295116
# Unit test for constructor of class VaultCLI
def test_VaultCLI():
    try:
        context = VaultCLI()
        context.run()
    finally:
        if context:
            # cleanup
            try:
                context.cleanup()
            except AttributeError:
                # context.cleanup() raises AttributeError, if context.args
                # is not implemented.
                pass

if __name__ == "__main__":
    test_VaultCLI()

# Generated at 2022-06-20 13:31:17.059732
# Unit test for method execute_view of class VaultCLI

# Generated at 2022-06-20 13:31:28.092534
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    my_VaultCLI = VaultCLI()
    my_VaultCLI.pager = Mock(name='pager')
    my_VaultCLI.editor.plaintext = Mock(name='editor.plaintext')
    context.CLIARGS = dict(args=['ansible.cfg'])
    # Set up context.CLIARGS
    my_VaultCLI.execute_view()
    assert context.CLIARGS['args'] == ['ansible.cfg'], 'context.CLIARGS not set up correctly'
    # Call the method
    my_VaultCLI.execute_view()
    my_VaultCLI.pager.assert_called_with(to_text(plaintext))
    my_VaultCLI.editor.plaintext.assert_called_with('ansible.cfg')

# Generated at 2022-06-20 13:31:30.403836
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault = VaultCLI()

    args = None
    vault.decrypt = MagicMock()
    vault.execute_decrypt(args)
    vault.decrypt_file.assert_called()

# Generated at 2022-06-20 13:31:31.233288
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    pass

# Generated at 2022-06-20 13:31:43.434449
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_clic_instance = VaultCLI()

    instance = {
        'editor': mock.MagicMock(),
        'pager': mock.MagicMock()
    }
    instance['editor'].decrypt_file.return_value = True
    with mock.patch.dict('sys.modules', {'sys': mock.MagicMock()}):
        setattr(vault_clic_instance, 'execute_decrypt', new=instance['editor'].decrypt_file)
        setattr(vault_clic_instance, 'pager', new=instance['pager'])
        vault_clic_instance.execute_decrypt()
        instance['editor'].decrypt_file.assert_called_once()
        instance['pager'].assert_not_called()
    del instance


# Generated at 2022-06-20 13:31:49.032662
# Unit test for method init_parser of class VaultCLI
def test_VaultCLI_init_parser():
    '''
    Unit test for function init_parser of class VaultCLI
    '''

    # Module scope
    def _play(cli):
        cli.do_vault()

    vcli = VaultCLI(sys.stdin)
    parser = vcli.init_parser(subparser=None,
                              subparser_loader=None,
                              play_context=None,
                              func=_play)

    assert(parser.__class__.__name__ == 'ArgumentParser')


# Generated at 2022-06-20 13:31:50.936729
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    fixture = VaultCLI()
    

# Generated at 2022-06-20 13:31:58.486317
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    cli = VaultCLI()
    cli.editor = mock.Mock()
    cli.editor.plaintext.return_value = b'encrypted content'
    cli.pager = mock.Mock()
    cli.pager.return_value = None

    input = ['test_file.yml']
    context.CLIARGS = {'args': input}

    cli.execute_view()
    cli.pager.assert_called_with(to_text(b'encrypted content'))


# Module level functions

# Generated at 2022-06-20 13:32:04.856614
# Unit test for method format_ciphertext_yaml of class VaultCLI
def test_VaultCLI_format_ciphertext_yaml():
    # Test strings
    test_string1 = "This is a super secret string.\nThat has a second line"
    test_string2 = "This is an encrypted variable.\n"
    test_string3 = "This is an encrypted variable"