

# Generated at 2022-06-16 20:13:29.681078
# Unit test for method post_process_args of class VaultCLI

# Generated at 2022-06-16 20:13:31.150972
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: implement test
    pass


# Generated at 2022-06-16 20:13:32.875037
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.execute_view()


# Generated at 2022-06-16 20:13:33.752001
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:13:34.436150
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:13:35.402499
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:13:36.295558
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:13:42.581107
# Unit test for method execute_encrypt_string of class VaultCLI

# Generated at 2022-06-16 20:13:43.546175
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:13:54.783862
# Unit test for method execute_encrypt_string of class VaultCLI

# Generated at 2022-06-16 20:14:38.316048
# Unit test for method execute_encrypt_string of class VaultCLI

# Generated at 2022-06-16 20:14:40.268583
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.execute_edit()

# Generated at 2022-06-16 20:14:47.546333
# Unit test for method execute_decrypt of class VaultCLI

# Generated at 2022-06-16 20:14:52.906747
# Unit test for method execute_rekey of class VaultCLI

# Generated at 2022-06-16 20:14:54.291154
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:14:56.432679
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_decrypt()


# Generated at 2022-06-16 20:15:07.441171
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # Setup
    # TODO: use a temp file
    vault_file = '../../../../../test/integration/vault/test_vault.yml'
    vault_password_file = '../../../../../test/integration/vault/vault_pass.txt'
    vault_password = 'secret'
    vault_id = '7a04a384fc46bad7'
    vault_secret = (vault_id, vault_password)
    vault_secrets = [vault_secret]

    # Execute
    # TODO: use a temp file
    cli = VaultCLI(vault_secrets)
    cli.execute_decrypt()

    # Assert
    # TODO: use a temp file

# Generated at 2022-06-16 20:15:19.512402
# Unit test for method execute_encrypt of class VaultCLI

# Generated at 2022-06-16 20:15:21.078448
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:15:28.654009
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # FIXME: this is a hack to get around the fact that we don't have a real
    #        command line to parse
    context.CLIARGS = {'encrypt_string_prompt': True,
                       'encrypt_string_stdin': True,
                       'encrypt_string_stdin_name': 'foo',
                       'encrypt_string_names': ['bar', 'baz'],
                       'args': ['one', 'two', 'three', 'four', 'five']}

    # FIXME: this is a hack to get around the fact that we don't have a real
    #        command line to parse

# Generated at 2022-06-16 20:17:20.325317
# Unit test for method execute_decrypt of class VaultCLI

# Generated at 2022-06-16 20:17:21.650365
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # FIXME: this is a stub
    pass

# Generated at 2022-06-16 20:17:28.538188
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # FIXME: this test is broken
    return
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this test is broken
    # FIXME: this

# Generated at 2022-06-16 20:17:30.118245
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()

# Generated at 2022-06-16 20:17:31.337687
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:17:32.978115
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:17:34.277487
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:17:37.048657
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # FIXME: this is a stub
    pass

# Generated at 2022-06-16 20:17:38.792316
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()

# Generated at 2022-06-16 20:17:48.914747
# Unit test for method run of class VaultCLI

# Generated at 2022-06-16 20:19:59.693305
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: write unit test
    pass


# Generated at 2022-06-16 20:20:00.651574
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # TODO: implement
    pass


# Generated at 2022-06-16 20:20:01.658022
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # TODO: implement
    pass


# Generated at 2022-06-16 20:20:13.625098
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Test with no args
    context.CLIARGS = {'encrypt_string_prompt': False, 'encrypt_string_read_stdin': False, 'encrypt_string_stdin_name': None, 'encrypt_string_names': [], 'args': [], 'encrypt_vault_id': None, 'new_vault_id': None, 'new_vault_password_file': None, 'vault_password_file': None, 'ask_vault_pass': False, 'output_file': None, 'show_string_input': False}
    with pytest.raises(AnsibleOptionsError) as excinfo:
        VaultCLI().execute_encrypt_string()
    assert 'No plaintext was provided' in str(excinfo.value)

    # Test with --encrypt-string-prom

# Generated at 2022-06-16 20:20:19.428054
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # Test with no args
    context.CLIARGS = {'args': []}
    with pytest.raises(AnsibleOptionsError):
        VaultCLI().execute_create()

    # Test with more than one arg
    context.CLIARGS = {'args': ['foo', 'bar']}
    with pytest.raises(AnsibleOptionsError):
        VaultCLI().execute_create()

    # Test with one arg
    context.CLIARGS = {'args': ['foo']}
    VaultCLI().execute_create()


# Generated at 2022-06-16 20:20:20.557365
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # FIXME: test this
    pass


# Generated at 2022-06-16 20:20:21.665175
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a stub
    pass

# Generated at 2022-06-16 20:20:22.698204
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:20:35.058028
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # Setup a mock context
    context.CLIARGS = {'ask_vault_pass': False, 'output_file': None, 'args': ['test_file']}
    context.CLIARGS['vault_password_file'] = None
    context.CLIARGS['new_vault_password_file'] = None
    context.CLIARGS['encrypt_vault_id'] = None
    context.CLIARGS['new_vault_id'] = None
    context.CLIARGS['vault_ids'] = None
    context.CLIARGS['new_vault_ids'] = None
    context.CLIARGS['encrypt_string_prompt'] = False
    context.CLIARGS['encrypt_string_read_stdin'] = False
    context.CLIARGS

# Generated at 2022-06-16 20:20:36.940992
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()
