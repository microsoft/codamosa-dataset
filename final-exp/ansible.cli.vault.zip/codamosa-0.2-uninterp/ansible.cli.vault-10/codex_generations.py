

# Generated at 2022-06-16 20:13:22.134813
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.execute_edit()


# Generated at 2022-06-16 20:13:23.224030
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # TODO: implement
    pass


# Generated at 2022-06-16 20:13:24.981534
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.execute_view()


# Generated at 2022-06-16 20:13:26.400339
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:13:28.194782
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    cli = VaultCLI()
    cli.execute_encrypt()


# Generated at 2022-06-16 20:13:29.866677
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_decrypt()


# Generated at 2022-06-16 20:13:38.509934
# Unit test for method execute_decrypt of class VaultCLI

# Generated at 2022-06-16 20:13:51.169885
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Setup
    cli = VaultCLI()
    cli.setup_vault_secrets = lambda x, y, z, a, b: [('id1', 'secret1')]
    cli.editor = VaultEditor(VaultLib([('id1', 'secret1')]))
    cli.encrypt_string_read_stdin = False
    cli.encrypt_string_prompt = True
    cli.encrypt_vault_id = 'id1'
    cli.encrypt_secret = 'secret1'
    cli.FROM_PROMPT = 'prompt'
    cli.FROM_ARGS = 'args'
    cli.FROM_STDIN = 'stdin'
    cli.show_string_input = True
    cli.encrypt_string_std

# Generated at 2022-06-16 20:14:02.012593
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.setup_vault_secrets = lambda x, y, z, a, b: [('vault_id', 'vault_secret')]
    vault_cli.editor = VaultEditor(VaultLib([('vault_id', 'vault_secret')]))
    vault_cli.encrypt_string_read_stdin = False
    vault_cli.encrypt_string_prompt = False
    vault_cli.encrypt_vault_id = 'vault_id'
    vault_cli.encrypt_secret = 'vault_secret'
    vault_cli.FROM_ARGS = 'from_args'
    vault_cli.FROM_STDIN = 'from_stdin'

# Generated at 2022-06-16 20:14:12.210627
# Unit test for method execute_edit of class VaultCLI

# Generated at 2022-06-16 20:14:44.239187
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:14:45.279759
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:14:46.494907
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:14:47.101857
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # FIXME: test this
    pass

# Generated at 2022-06-16 20:14:48.417469
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # FIXME: this is a stub, implement your test here
    raise NotImplementedError()


# Generated at 2022-06-16 20:14:53.707430
# Unit test for method execute_edit of class VaultCLI

# Generated at 2022-06-16 20:14:54.692668
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # TODO: implement
    pass


# Generated at 2022-06-16 20:14:56.675426
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.execute_view()


# Generated at 2022-06-16 20:14:57.974776
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # TODO: implement
    pass


# Generated at 2022-06-16 20:15:00.238138
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()

# Generated at 2022-06-16 20:16:30.705344
# Unit test for method execute_rekey of class VaultCLI

# Generated at 2022-06-16 20:16:35.254234
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    cli = VaultCLI()
    cli.editor = VaultEditor(VaultLib([]))
    cli.editor.encrypt_bytes = lambda x, y: x
    cli.encrypt_string_read_stdin = True
    cli.encrypt_string_prompt = True
    cli.encrypt_vault_id = 'default'
    cli.encrypt_secret = 'secret'
    cli.FROM_STDIN = 'stdin'
    cli.FROM_PROMPT = 'prompt'
    cli.FROM_ARGS = 'args'
    cli.execute_encrypt_string()


# Generated at 2022-06-16 20:16:46.899194
# Unit test for method execute_encrypt of class VaultCLI

# Generated at 2022-06-16 20:16:48.691308
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    vault_cli.post_process_args()


# Generated at 2022-06-16 20:16:56.563226
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    from ansible.cli.vault import VaultCLI
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import match_encrypt_secret
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.vault import get_vault_secrets
    from ansible.parsing.vault import get_vault_password_files
    from ansible.parsing.vault import get_vault_ids
    from ansible.parsing.vault import get_vault_secret
    from ansible.parsing.vault import get_vault_password_file
    from ansible.parsing.vault import get_v

# Generated at 2022-06-16 20:16:57.301578
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:16:58.586511
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:17:04.322144
# Unit test for method execute_decrypt of class VaultCLI

# Generated at 2022-06-16 20:17:05.363032
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:17:17.767335
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Test with no args, should raise an error
    context.CLIARGS = {'encrypt_string_prompt': False, 'encrypt_string_read_stdin': False, 'encrypt_string_stdin_name': None, 'encrypt_string_names': [], 'args': [], 'encrypt_vault_id': None, 'new_vault_id': None, 'new_vault_password_file': None, 'vault_password_file': None, 'ask_vault_pass': False, 'output_file': None, 'action': 'encrypt_string', 'show_string_input': False, 'func': None}
    with pytest.raises(AnsibleOptionsError) as excinfo:
        VaultCLI().execute_encrypt_string()

# Generated at 2022-06-16 20:19:14.095283
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: use a mock for the loader
    loader = DataLoader()
    vault_cli = VaultCLI(loader)
    vault_cli.run()
    assert False # TODO: implement your test here


# Generated at 2022-06-16 20:19:14.949441
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:19:16.323276
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt()


# Generated at 2022-06-16 20:19:18.794456
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # TODO: implement
    pass

# Generated at 2022-06-16 20:19:20.254956
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # TODO: implement test
    pass


# Generated at 2022-06-16 20:19:21.671691
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # FIXME: this test is not complete
    pass


# Generated at 2022-06-16 20:19:30.408052
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_cli = VaultCLI()
    vault_cli.editor = VaultEditor()
    vault_cli.editor.decrypt_file = MagicMock()
    context.CLIARGS = {'args': ['filename1', 'filename2']}
    vault_cli.execute_decrypt()
    assert vault_cli.editor.decrypt_file.call_count == 2
    assert vault_cli.editor.decrypt_file.call_args_list[0][0][0] == 'filename1'
    assert vault_cli.editor.decrypt_file.call_args_list[1][0][0] == 'filename2'


# Generated at 2022-06-16 20:19:31.742814
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:19:33.015926
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # FIXME: this is a stub
    pass

# Generated at 2022-06-16 20:19:39.068635
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.editor = Mock()
    vault_cli.execute_edit()
    assert vault_cli.editor.edit_file.call_count == 0
    vault_cli.editor.reset_mock()
    vault_cli.execute_edit(['foo'])
    assert vault_cli.editor.edit_file.call_count == 1
    vault_cli.editor.reset_mock()
    vault_cli.execute_edit(['foo', 'bar'])
    assert vault_cli.editor.edit_file.call_count == 2
