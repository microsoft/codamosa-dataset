

# Generated at 2022-06-16 20:13:14.852143
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a hack to make sure we don't try to load plugins
    # when running unit tests
    context.CLIARGS = AttributeDict()
    context.CLIARGS['ask_vault_pass'] = False
    context.CLIARGS['vault_password_file'] = None
    context.CLIARGS['new_vault_password_file'] = None
    context.CLIARGS['encrypt_vault_id'] = None
    context.CLIARGS['new_vault_id'] = None
    context.CLIARGS['encrypt_string_prompt'] = False
    context.CLIARGS['encrypt_string_stdin'] = False
    context.CLIARGS['encrypt_string_stdin_name'] = None
    context.CLIAR

# Generated at 2022-06-16 20:13:26.086776
# Unit test for method execute_edit of class VaultCLI

# Generated at 2022-06-16 20:13:27.403693
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:13:28.562189
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # TODO: implement
    pass


# Generated at 2022-06-16 20:13:29.297132
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    # FIXME: implement this
    pass


# Generated at 2022-06-16 20:13:31.092041
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.execute_edit()

# Generated at 2022-06-16 20:13:38.539840
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # Test with a file that doesn't exist
    # Test with a file that exists
    # Test with a file that exists and is encrypted
    # Test with a file that exists and is not encrypted
    # Test with a file that exists and is encrypted with a different vault_id
    # Test with a file that exists and is encrypted with a different vault_id and a different vault_secret
    # Test with a file that exists and is encrypted with a different vault_id and a different vault_secret and a different new_vault_id
    # Test with a file that exists and is encrypted with a different vault_id and a different vault_secret and a different new_vault_id and a different new_vault_secret
    pass

# Generated at 2022-06-16 20:13:41.964167
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:13:43.383403
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:13:50.843900
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # Test with no args
    with pytest.raises(AnsibleOptionsError):
        VaultCLI(['ansible-vault', 'create']).run()

    # Test with too many args
    with pytest.raises(AnsibleOptionsError):
        VaultCLI(['ansible-vault', 'create', 'foo', 'bar']).run()

    # Test with one arg
    VaultCLI(['ansible-vault', 'create', 'foo']).run()


# Generated at 2022-06-16 20:14:07.965177
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:14:08.829540
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: this is a stub, implement properly
    pass


# Generated at 2022-06-16 20:14:15.144623
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    # FIXME: this test is not complete
    vault_cli = VaultCLI()
    vault_cli.editor = VaultEditor(None)
    vault_cli.editor.edit_file = Mock()
    vault_cli.editor.edit_file.return_value = True
    context.CLIARGS = {'args': ['foo']}
    vault_cli.execute_edit()
    assert vault_cli.editor.edit_file.call_count == 1
    assert vault_cli.editor.edit_file.call_args[0] == ('foo',)


# Generated at 2022-06-16 20:14:16.835772
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.execute_edit()


# Generated at 2022-06-16 20:14:18.630296
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:14:29.721961
# Unit test for method execute_rekey of class VaultCLI

# Generated at 2022-06-16 20:14:30.678872
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # TODO: implement
    pass


# Generated at 2022-06-16 20:14:32.183945
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:14:33.566625
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # TODO: implement unit test
    pass


# Generated at 2022-06-16 20:14:35.912507
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # FIXME: this test is not complete
    vault_cli = VaultCLI()
    vault_cli.execute_decrypt()


# Generated at 2022-06-16 20:14:47.986237
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # FIXME: this is not a unit test, it requires a real file
    pass


# Generated at 2022-06-16 20:14:57.806016
# Unit test for method execute_decrypt of class VaultCLI

# Generated at 2022-06-16 20:15:00.069838
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:15:01.764683
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: this is a stub test
    assert True


# Generated at 2022-06-16 20:15:07.015391
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.pager = mock.MagicMock()
    vault_cli.editor = mock.MagicMock()
    vault_cli.editor.plaintext = mock.MagicMock(return_value=b'foo')
    vault_cli.execute_view()
    vault_cli.pager.assert_called_once_with('foo')


# Generated at 2022-06-16 20:15:08.552213
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()

# Generated at 2022-06-16 20:15:10.855637
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:15:13.865294
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # FIXME:
    # vault_cli = VaultCLI()
    # vault_cli.execute_encrypt()
    pass

# Generated at 2022-06-16 20:15:22.759667
# Unit test for method execute_view of class VaultCLI

# Generated at 2022-06-16 20:15:24.047256
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:15:47.367445
# Unit test for method execute_encrypt_string of class VaultCLI

# Generated at 2022-06-16 20:15:49.634315
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:15:54.013525
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # Test with no args
    with pytest.raises(AnsibleOptionsError):
        VaultCLI().execute_create()

    # Test with more than one arg
    with pytest.raises(AnsibleOptionsError):
        VaultCLI().execute_create(['arg1', 'arg2'])

    # Test with one arg
    VaultCLI().execute_create(['arg1'])



# Generated at 2022-06-16 20:15:56.987813
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.editor = VaultEditor()
    vault_cli.editor.edit_file = lambda x: None
    vault_cli.execute_edit()


# Generated at 2022-06-16 20:16:06.729292
# Unit test for method run of class VaultCLI

# Generated at 2022-06-16 20:16:08.083249
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # FIXME: implement this test
    pass


# Generated at 2022-06-16 20:16:09.066266
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:16:11.986829
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:16:21.738635
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # Test with no args
    context.CLIARGS = {}
    cli = VaultCLI()
    cli.post_process_args()
    assert context.CLIARGS['func'] == cli.execute_encrypt_string
    assert context.CLIARGS['encrypt_string_read_stdin'] == True
    assert context.CLIARGS['encrypt_string_prompt'] == True
    assert context.CLIARGS['encrypt_string_stdin_name'] == None

    # Test with args
    context.CLIARGS = {'args': ['foo']}
    cli = VaultCLI()
    cli.post_process_args()
    assert context.CLIARGS['func'] == cli.execute_encrypt_string

# Generated at 2022-06-16 20:16:31.885350
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Create a mock context object
    context_obj = mock.Mock()
    context_obj.CLIARGS = {
        'encrypt_string_prompt': False,
        'encrypt_string_stdin': False,
        'encrypt_string_stdin_name': None,
        'encrypt_string_names': [],
        'show_string_input': False,
        'args': ['foo', 'bar'],
        'output_file': None
    }

    # Create a mock loader object
    loader_obj = mock.Mock()
    loader_obj.set_vault_secrets.return_value = None

    # Create a mock VaultEditor object
    editor_obj = mock.Mock()

# Generated at 2022-06-16 20:16:45.048834
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:16:54.220626
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Create a mock object for the AnsibleOptions class
    class MockAnsibleOptions(object):
        def __init__(self):
            self.args = ['foo', 'bar']
            self.encrypt_string_prompt = False
            self.encrypt_string_read_stdin = False
            self.encrypt_string_stdin_name = None
            self.encrypt_string_names = None
            self.show_string_input = False

    # Create a mock object for the AnsibleContext class
    class MockAnsibleContext(object):
        def __init__(self):
            self.CLIARGS = MockAnsibleOptions()

    # Create a mock object for the VaultEditor class
    class MockVaultEditor(object):
        def __init__(self):
            pass


# Generated at 2022-06-16 20:16:57.800297
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_cli = VaultCLI()
    vault_cli.editor = mock.MagicMock()
    vault_cli.execute_decrypt()
    vault_cli.editor.decrypt_file.assert_called_once_with(None, output_file=None)

# Generated at 2022-06-16 20:16:59.769618
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:17:06.556471
# Unit test for method execute_decrypt of class VaultCLI

# Generated at 2022-06-16 20:17:12.964324
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.pager = MagicMock()
    vault_cli.editor = MagicMock()
    vault_cli.editor.plaintext = MagicMock(return_value='plaintext')
    vault_cli.execute_view()
    vault_cli.pager.assert_called_with('plaintext')


# Generated at 2022-06-16 20:17:15.072908
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:17:16.309191
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:17:24.949485
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    from ansible.cli.vault import VaultCLI
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import match_encrypt_secret
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleOptionsError
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.utils.path import makedirs_safe
    from ansible.utils.path import is_executable
    from ansible.utils.path import get_pager
    from ansible.utils.path import get_bin_path

# Generated at 2022-06-16 20:17:26.320936
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: this is a stub
    pass

# Generated at 2022-06-16 20:17:40.733059
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:17:42.614713
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.execute_view()


# Generated at 2022-06-16 20:17:51.935522
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # create an instance of the class to test
    vault_cli = VaultCLI()
    # create a mock context object
    context_mock = mock.MagicMock()
    # set the context object as the context for the class
    vault_cli.set_context(context_mock)
    # create a mock editor object
    editor_mock = mock.MagicMock()
    # set the editor object as the editor for the class
    vault_cli.editor = editor_mock
    # create a mock encrypt_secret object
    encrypt_secret_mock = mock.MagicMock()
    # set the encrypt_secret object as the encrypt_secret for the class
    vault_cli.encrypt_secret = encrypt_secret_mock
    # create a mock encrypt_vault_id object

# Generated at 2022-06-16 20:17:52.893052
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # TODO: implement
    pass


# Generated at 2022-06-16 20:17:54.035609
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:17:55.060999
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()

# Generated at 2022-06-16 20:17:56.962747
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:18:05.831848
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    from ansible.cli.vault import VaultCLI
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import match_encrypt_secret
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.vault import get_vault_secrets
    from ansible.parsing.vault import load_vault_secrets
    from ansible.parsing.vault import load_vault_password_file
    from ansible.parsing.vault import get_vault_password_file
    from ansible.parsing.vault import get_vault_ids
    from ansible.parsing.vault import get_

# Generated at 2022-06-16 20:18:18.001704
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # Setup
    # TODO: setup vault_secrets
    # TODO: setup encrypt_secret
    # TODO: setup encrypt_vault_id
    # TODO: setup editor
    # TODO: setup context.CLIARGS
    # TODO: setup old_umask
    # TODO: setup f
    # TODO: setup stdin.isatty
    # TODO: setup stdout.isatty
    # TODO: setup args
    # TODO: setup output_file
    # TODO: setup display.display
    # TODO: setup os.umask
    # TODO: setup VaultEditor.encrypt_file
    # TODO: setup display.display

    # Exercise
    # TODO: exercise VaultCLI.execute_encrypt
    pass


# Generated at 2022-06-16 20:18:21.412314
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:18:37.077918
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:18:38.849000
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:18:41.636713
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:18:43.481816
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    assert vault_cli.post_process_args() == None


# Generated at 2022-06-16 20:18:45.620805
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:18:53.755501
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # Create a mock object for the AnsibleOptions class
    mock_ansible_options = MagicMock()
    mock_ansible_options.ask_vault_pass = False
    mock_ansible_options.encrypt_vault_id = None
    mock_ansible_options.new_vault_id = None
    mock_ansible_options.new_vault_password_file = None
    mock_ansible_options.output_file = None
    mock_ansible_options.vault_password_file = None
    mock_ansible_options.vault_ids = None

    # Create a mock object for the AnsibleContext class
    mock_ansible_context = MagicMock()
    mock_ansible_context.CLIARGS = mock_ansible_options

    # Create a mock object for the Ansible

# Generated at 2022-06-16 20:18:56.064789
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:18:57.827622
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    vault_cli.post_process_args()


# Generated at 2022-06-16 20:18:59.465800
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt()


# Generated at 2022-06-16 20:19:01.724632
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_decrypt()


# Generated at 2022-06-16 20:19:30.705544
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:19:32.041646
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:19:39.766271
# Unit test for method execute_view of class VaultCLI

# Generated at 2022-06-16 20:19:42.079817
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:19:44.036492
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: this is a stub, implement properly
    pass


# Generated at 2022-06-16 20:19:53.097496
# Unit test for method run of class VaultCLI

# Generated at 2022-06-16 20:19:54.314965
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:19:56.014987
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.execute_view()

# Generated at 2022-06-16 20:20:06.612759
# Unit test for method execute_decrypt of class VaultCLI

# Generated at 2022-06-16 20:20:08.869527
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:20:33.169764
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a stub, implement properly
    pass

# Generated at 2022-06-16 20:20:35.391965
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:20:40.405611
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Create an instance of VaultCLI
    vault_cli = VaultCLI()
    # TODO: set up context.CLIARGS
    # Call method execute_encrypt_string of vault_cli
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:20:50.280349
# Unit test for method execute_encrypt_string of class VaultCLI

# Generated at 2022-06-16 20:20:51.762715
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    cli = VaultCLI()
    cli.post_process_args()


# Generated at 2022-06-16 20:20:59.499044
# Unit test for method execute_rekey of class VaultCLI

# Generated at 2022-06-16 20:21:00.541074
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:21:02.837675
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:21:04.391861
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:21:11.650736
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    # FIXME: this test is not complete
    vault_cli = VaultCLI()
    vault_cli.editor = Mock()
    vault_cli.editor.edit_file = Mock()
    vault_cli.editor.edit_file.return_value = None
    context.CLIARGS = {'args': ['foo']}
    vault_cli.execute_edit()
    vault_cli.editor.edit_file.assert_called_with('foo')


# Generated at 2022-06-16 20:22:03.647103
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:22:04.506241
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:22:05.600355
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:22:12.228345
# Unit test for method execute_edit of class VaultCLI

# Generated at 2022-06-16 20:22:13.101680
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:22:14.079439
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    assert vault_cli.post_process_args() == None


# Generated at 2022-06-16 20:22:24.927635
# Unit test for method execute_encrypt of class VaultCLI

# Generated at 2022-06-16 20:22:26.902675
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:22:38.105454
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Test with no args
    context.CLIARGS = {'encrypt_string_prompt': False,
                       'encrypt_string_read_stdin': False,
                       'encrypt_string_stdin_name': None,
                       'encrypt_string_names': None,
                       'show_string_input': False,
                       'args': []}
    with pytest.raises(AnsibleOptionsError) as excinfo:
        VaultCLI().execute_encrypt_string()
    assert 'No plaintext strings provided' in str(excinfo.value)

    # Test with --prompt and --stdin