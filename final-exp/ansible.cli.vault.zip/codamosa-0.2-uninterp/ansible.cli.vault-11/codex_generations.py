

# Generated at 2022-06-16 20:13:16.004402
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.execute_edit()

# Generated at 2022-06-16 20:13:17.996732
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:13:20.937428
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt()

# Generated at 2022-06-16 20:13:22.457097
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:13:24.290965
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:13:30.453548
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # Setup
    vault_cli = VaultCLI()
    vault_cli.editor = Mock()
    context.CLIARGS = {'args': ['foo.yml']}
    vault_cli.encrypt_secret = 'secret'
    vault_cli.encrypt_vault_id = 'id'

    # Test
    vault_cli.execute_create()

    # Assert
    vault_cli.editor.create_file.assert_called_with('foo.yml', 'secret', vault_id='id')


# Generated at 2022-06-16 20:13:32.199247
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.execute_edit()


# Generated at 2022-06-16 20:13:33.200868
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:13:34.933278
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:13:36.374559
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # FIXME: need to mock out the vault editor
    pass


# Generated at 2022-06-16 20:14:00.485580
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:14:01.433023
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # FIXME: implement test
    pass

# Generated at 2022-06-16 20:14:02.842436
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt()


# Generated at 2022-06-16 20:14:04.394748
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:14:05.916444
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:14:07.407879
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a stub
    pass

# Generated at 2022-06-16 20:14:16.216088
# Unit test for method execute_view of class VaultCLI

# Generated at 2022-06-16 20:14:27.284110
# Unit test for method execute_decrypt of class VaultCLI

# Generated at 2022-06-16 20:14:30.396331
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    vault_cli.post_process_args()
    assert context.CLIARGS['func'] == vault_cli.execute_encrypt


# Generated at 2022-06-16 20:14:32.219675
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_decrypt()


# Generated at 2022-06-16 20:15:15.632925
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # TODO: implement
    pass


# Generated at 2022-06-16 20:15:24.608191
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Setup test data
    context.CLIARGS = {'encrypt_string_prompt': False, 'encrypt_string_read_stdin': False, 'encrypt_string_stdin_name': None, 'encrypt_string_names': [], 'args': ['test_value'], 'encrypt_vault_id': None, 'ask_vault_pass': False, 'new_vault_id': None, 'new_vault_password_file': None, 'output_file': None, 'show_string_input': False, 'encrypt_vault_id': None, 'ask_vault_pass': False, 'new_vault_id': None, 'new_vault_password_file': None, 'output_file': None, 'show_string_input': False}

# Generated at 2022-06-16 20:15:26.186289
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.execute_view()


# Generated at 2022-06-16 20:15:27.727533
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:15:29.525295
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # FIXME: this test is not complete
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:15:33.077472
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.editor = MagicMock()
    vault_cli.editor.edit_file = MagicMock()
    context.CLIARGS = {'args': ['file1', 'file2']}
    vault_cli.execute_edit()
    vault_cli.editor.edit_file.assert_has_calls([call('file1'), call('file2')])


# Generated at 2022-06-16 20:15:34.798883
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()
    assert True


# Generated at 2022-06-16 20:15:36.591551
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:15:38.477976
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:15:40.164644
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:17:17.411106
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:17:18.725886
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:17:20.199310
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:17:21.854924
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:17:24.932933
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:17:34.876474
# Unit test for method execute_encrypt of class VaultCLI

# Generated at 2022-06-16 20:17:37.130096
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:17:40.432369
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    vault_cli.post_process_args()
    assert context.CLIARGS['func'] == vault_cli.execute_encrypt


# Generated at 2022-06-16 20:17:48.009462
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # Setup
    vault_cli = VaultCLI()
    vault_cli.editor = MagicMock()
    vault_cli.pager = MagicMock()
    f = 'test'
    context.CLIARGS['args'] = [f]

    # Test
    vault_cli.execute_view()

    # Assert
    vault_cli.editor.plaintext.assert_called_once_with(f)
    vault_cli.pager.assert_called_once_with(vault_cli.editor.plaintext.return_value)


# Generated at 2022-06-16 20:17:49.622772
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a stub, implement your test here
    raise NotImplementedError()

# Generated at 2022-06-16 20:21:02.631055
# Unit test for method execute_rekey of class VaultCLI

# Generated at 2022-06-16 20:21:07.145157
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.encrypt_string_read_stdin = False
    vault_cli.encrypt_string_prompt = False
    vault_cli.encrypt_vault_id = None
    vault_cli.encrypt_secret = None
    vault_cli.new_encrypt_vault_id = None
    vault_cli.new_encrypt_secret = None
    vault_cli.editor = None
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:21:09.761716
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:21:17.333056
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this test is not complete
    test_args = {'encrypt_string_prompt': False, 'encrypt_string_stdin_name': None, 'encrypt_string_read_stdin': False, 'encrypt_string_names': [], 'encrypt_string_args': [], 'encrypt_string_args_prompt': False, 'encrypt_string_args_stdin': False, 'encrypt_string_args_names': [], 'encrypt_string_args_stdin_name': None, 'encrypt_string_args_read_stdin': False, 'encrypt_string_args_prompt_name': None, 'encrypt_string_args_prompt_text': None}
    test_vault_cli = VaultCLI(args=test_args)
    test_vault_cli

# Generated at 2022-06-16 20:21:19.449516
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a stub, implement your test here
    raise NotImplementedError()


# Generated at 2022-06-16 20:21:20.421786
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.execute_view()


# Generated at 2022-06-16 20:21:31.230691
# Unit test for method post_process_args of class VaultCLI

# Generated at 2022-06-16 20:21:32.207944
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:21:33.363387
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:21:34.957323
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.execute_view()
