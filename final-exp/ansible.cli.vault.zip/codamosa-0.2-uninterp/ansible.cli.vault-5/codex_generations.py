

# Generated at 2022-06-16 20:13:17.181648
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.encrypt_string_read_stdin = True
    vault_cli.encrypt_string_prompt = True
    vault_cli.encrypt_secret = 'secret'
    vault_cli.encrypt_vault_id = 'vault_id'
    vault_cli.editor = VaultEditor(VaultLib([('vault_id', 'secret')]))
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:13:18.326235
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:13:20.163018
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # TODO: implement
    pass

# Generated at 2022-06-16 20:13:29.882304
# Unit test for method execute_encrypt of class VaultCLI

# Generated at 2022-06-16 20:13:30.731602
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.execute_edit()

# Generated at 2022-06-16 20:13:32.472906
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:13:33.830584
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:13:39.336091
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # Setup
    args = {'encrypt_vault_id': 'default', 'encrypt_string_prompt': False, 'encrypt_string_stdin_name': None, 'encrypt_string_read_stdin': False, 'encrypt_string_names': None, 'encrypt_string_stdin': False, 'show_string_input': False, 'ask_vault_pass': False, 'new_vault_password_file': None, 'new_vault_id': None, 'output_file': None, 'vault_password_file': None, 'vault_ids': None, 'args': ['foo'], 'action': 'create'}
    context.CLIARGS = args
    context.settings = ImmutableDict()

# Generated at 2022-06-16 20:13:51.505244
# Unit test for method execute_decrypt of class VaultCLI

# Generated at 2022-06-16 20:14:02.309792
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    vault_cli.post_process_args()
    assert context.CLIARGS['func'] == vault_cli.execute_encrypt
    assert context.CLIARGS['args'] == ['foo']
    assert context.CLIARGS['encrypt_vault_id'] == 'foo'
    assert context.CLIARGS['new_vault_id'] == 'bar'
    assert context.CLIARGS['new_vault_password_file'] == 'baz'
    assert context.CLIARGS['ask_vault_pass'] == True
    assert context.CLIARGS['output_file'] == 'quux'
    assert context.CLIARGS['encrypt_string_prompt'] == True

# Generated at 2022-06-16 20:14:48.866469
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:14:50.097739
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:15:01.198805
# Unit test for method post_process_args of class VaultCLI

# Generated at 2022-06-16 20:15:06.611630
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this test is incomplete
    cli = VaultCLI()
    cli.post_process_args()
    assert cli.encrypt_string_read_stdin == False
    assert cli.encrypt_string_prompt == False
    assert cli.encrypt_string_stdin_name == None
    assert cli.encrypt_string_names == []
    assert cli.encrypt_vault_id == None
    assert cli.encrypt_secret == None
    assert cli.new_encrypt_vault_id == None
    assert cli.new_encrypt_secret == None
    assert cli.editor == None
    assert cli.pager == None
    assert cli.FROM_PROMPT == 'prompt'

# Generated at 2022-06-16 20:15:08.186648
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_decrypt()


# Generated at 2022-06-16 20:15:15.632478
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    # Setup
    vault_cli = VaultCLI()
    vault_cli.editor = mock.MagicMock()
    context.CLIARGS = {'args': ['foo', 'bar']}

    # Test
    vault_cli.execute_edit()

    # Assert
    vault_cli.editor.edit_file.assert_has_calls([
        mock.call('foo'),
        mock.call('bar')
    ])


# Generated at 2022-06-16 20:15:16.968472
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:15:19.308867
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # FIXME: this is a stub, implement your test here
    raise NotImplementedError()


# Generated at 2022-06-16 20:15:20.909278
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: test this
    pass


# Generated at 2022-06-16 20:15:22.205651
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:16:22.401337
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:16:32.298551
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: this is a hack to avoid a circular import
    from ansible.cli import CLI

    cli = CLI(args=[])
    vault_cli = VaultCLI(cli)

    # FIXME: this is a hack to avoid a circular import
    from ansible.parsing.vault import VaultLib

    # FIXME: this is a hack to avoid a circular import
    from ansible.parsing.vault import VaultEditor

    # FIXME: this is a hack to avoid a circular import
    from ansible.parsing.vault import match_encrypt_secret

    # FIXME: this is a hack to avoid a circular import
    from ansible.parsing.vault import get_file_vault_secret

    # FIXME: this is a hack to avoid a circular import

# Generated at 2022-06-16 20:16:33.091680
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # TODO: implement
    pass

# Generated at 2022-06-16 20:16:34.343866
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()

# Generated at 2022-06-16 20:16:36.747727
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:16:38.031178
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    cli = VaultCLI()
    cli.execute_decrypt()

# Generated at 2022-06-16 20:16:39.982491
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()

# Generated at 2022-06-16 20:16:42.709966
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.execute_edit()


# Generated at 2022-06-16 20:16:52.789152
# Unit test for method post_process_args of class VaultCLI

# Generated at 2022-06-16 20:16:54.588666
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()

# Generated at 2022-06-16 20:18:42.090482
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # FIXME: need to mock out the editor
    pass


# Generated at 2022-06-16 20:18:43.533400
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    # FIXME: need to mock out editor
    pass

# Generated at 2022-06-16 20:18:44.530682
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:18:45.878386
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # FIXME: this is a stub
    pass

# Generated at 2022-06-16 20:18:49.726359
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: this is a hack to make sure we don't try to load the config file
    # when we are running unit tests.
    context.CLIARGS = {'vault_password_file': None}
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:18:56.441203
# Unit test for method run of class VaultCLI

# Generated at 2022-06-16 20:19:01.110633
# Unit test for method run of class VaultCLI

# Generated at 2022-06-16 20:19:03.928340
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.editor = Mock()
    vault_cli.execute_edit()
    assert vault_cli.editor.edit_file.call_count == 1


# Generated at 2022-06-16 20:19:05.826190
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # FIXME: this is a stub
    pass

# Generated at 2022-06-16 20:19:07.490359
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt()
