

# Generated at 2022-06-16 20:13:23.330269
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    vault_cli.post_process_args()
    assert True


# Generated at 2022-06-16 20:13:24.693459
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:13:26.441532
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt()


# Generated at 2022-06-16 20:13:27.884629
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:13:29.255517
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:13:31.044991
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:13:33.109112
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    vault_cli.post_process_args()
    assert context.CLIARGS['func'] == vault_cli.execute_encrypt


# Generated at 2022-06-16 20:13:34.483622
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()

# Generated at 2022-06-16 20:13:36.093497
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:13:37.547069
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # FIXME: this is a stub, implement your test here
    raise NotImplementedError()


# Generated at 2022-06-16 20:14:05.070572
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:14:06.378427
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    # TODO: implement unit test
    pass

# Generated at 2022-06-16 20:14:07.918954
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    cli = VaultCLI()
    cli.execute_view()


# Generated at 2022-06-16 20:14:09.494937
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_decrypt()

# Generated at 2022-06-16 20:14:13.601707
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # FIXME: this test is not very good
    vault_cli = VaultCLI()
    vault_cli.pager = lambda x: x
    vault_cli.editor = VaultEditor(VaultLib([]))
    vault_cli.editor.plaintext = lambda x: x
    vault_cli.execute_view()


# Generated at 2022-06-16 20:14:20.942628
# Unit test for method execute_rekey of class VaultCLI

# Generated at 2022-06-16 20:14:24.357968
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:14:26.100195
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    # FIXME: This is a stub.
    pass


# Generated at 2022-06-16 20:14:28.034703
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.execute_view()


# Generated at 2022-06-16 20:14:29.111889
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:15:22.519720
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt()


# Generated at 2022-06-16 20:15:24.373494
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt()


# Generated at 2022-06-16 20:15:25.941875
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # FIXME: this is a stub, implement your test here
    raise NotImplementedError()


# Generated at 2022-06-16 20:15:33.008725
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # Setup
    context.CLIARGS = dict()
    context.CLIARGS['args'] = ['foo.yml']
    context.CLIARGS['vault_password_file'] = '~/.vault_pass.txt'
    context.CLIARGS['new_vault_password_file'] = '~/.new_vault_pass.txt'
    context.CLIARGS['encrypt_vault_id'] = 'foo'
    context.CLIARGS['new_vault_id'] = 'bar'
    context.CLIARGS['ask_vault_pass'] = True
    context.CLIARGS['output_file'] = 'foo.yml.out'
    context.CLIARGS['encrypt_string_prompt'] = True

# Generated at 2022-06-16 20:15:34.694980
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_decrypt()


# Generated at 2022-06-16 20:15:43.988549
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    assert vault_cli.post_process_args(['-h']) == ['--help']
    assert vault_cli.post_process_args(['-h', '-v']) == ['--help', '-v']
    assert vault_cli.post_process_args(['-h', '-v', '-v']) == ['--help', '-v', '-v']
    assert vault_cli.post_process_args(['-h', '-v', '-v', '-v']) == ['--help', '-v', '-v', '-v']

# Generated at 2022-06-16 20:15:50.050958
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.setup_vault_secrets = lambda x, y, z, a: [('vault_id', 'vault_secret')]
    vault_cli.editor = VaultEditor(VaultLib([('vault_id', 'vault_secret')]))
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:15:51.556929
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:16:01.182228
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Test with no args
    context.CLIARGS = {'encrypt_string_prompt': False,
                       'encrypt_string_read_stdin': False,
                       'encrypt_string_stdin_name': None,
                       'encrypt_string_names': None,
                       'show_string_input': False,
                       'args': []}
    vault_cli = VaultCLI()
    with pytest.raises(AnsibleOptionsError):
        vault_cli.execute_encrypt_string()

    # Test with empty string

# Generated at 2022-06-16 20:16:03.749329
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:18:04.052872
# Unit test for method execute_encrypt_string of class VaultCLI

# Generated at 2022-06-16 20:18:05.181919
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()
    vault_cli.execute_rekey()


# Generated at 2022-06-16 20:18:17.146679
# Unit test for method execute_encrypt of class VaultCLI

# Generated at 2022-06-16 20:18:20.443474
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:18:27.564929
# Unit test for method run of class VaultCLI

# Generated at 2022-06-16 20:18:38.064996
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Test with no args
    context.CLIARGS = {'encrypt_string_prompt': False,
                       'encrypt_string_read_stdin': False,
                       'encrypt_string_stdin_name': None,
                       'encrypt_string_names': None,
                       'show_string_input': False,
                       'args': []}
    with pytest.raises(AnsibleOptionsError):
        VaultCLI().execute_encrypt_string()

    # Test with args

# Generated at 2022-06-16 20:18:40.757803
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # FIXME: this is a stub, implement your test here
    raise NotImplementedError()


# Generated at 2022-06-16 20:18:42.790843
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:18:44.956345
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    vault_cli.post_process_args()


# Generated at 2022-06-16 20:18:48.930129
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.pager = lambda x: x
    vault_cli.editor = VaultEditor(VaultLib([]))
    vault_cli.editor.plaintext = lambda x: x
    assert vault_cli.execute_view() == None


# Generated at 2022-06-16 20:22:31.557988
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()
