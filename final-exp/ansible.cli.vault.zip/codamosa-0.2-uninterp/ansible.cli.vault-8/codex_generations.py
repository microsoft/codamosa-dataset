

# Generated at 2022-06-16 20:13:13.476113
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:13:14.747844
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()

# Generated at 2022-06-16 20:13:21.228478
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Create an instance of VaultCLI
    vault_cli = VaultCLI()
    # Create an instance of AnsibleOptions
    ansible_options = AnsibleOptions()
    # Set context.CLIARGS to ansible_options
    context.CLIARGS = ansible_options
    # Call method execute_encrypt_string of vault_cli
    vault_cli.execute_encrypt_string()


# Generated at 2022-06-16 20:13:22.287403
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # FIXME: test this
    pass

# Generated at 2022-06-16 20:13:23.767187
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:13:32.246025
# Unit test for method execute_edit of class VaultCLI

# Generated at 2022-06-16 20:13:35.511340
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()

    # FIXME: this is a hack to get around the fact that we don't have a real
    #        context object to pass in
    vault_cli.editor = VaultEditor(None)
    vault_cli.editor.plaintext = lambda x: 'foo'
    vault_cli.pager = lambda x: None

    vault_cli.execute_view()


# Generated at 2022-06-16 20:13:36.378482
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # FIXME: implement test
    pass


# Generated at 2022-06-16 20:13:47.337266
# Unit test for method execute_encrypt_string of class VaultCLI

# Generated at 2022-06-16 20:13:58.874696
# Unit test for method run of class VaultCLI

# Generated at 2022-06-16 20:14:46.480961
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:14:47.657636
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:14:48.716323
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:14:51.275265
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.editor = Mock()
    vault_cli.execute_edit()
    assert vault_cli.editor.edit_file.call_count == 1


# Generated at 2022-06-16 20:14:52.749173
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # FIXME: implement test
    pass


# Generated at 2022-06-16 20:15:04.223129
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # Test with no args
    context.CLIARGS = {'encrypt_string_prompt': False, 'encrypt_string_read_stdin': False, 'encrypt_string_stdin_name': None, 'encrypt_string_names': None, 'args': [], 'encrypt_vault_id': None, 'new_vault_id': None, 'new_vault_password_file': None, 'output_file': None, 'ask_vault_pass': False, 'vault_password_file': None, 'show_string_input': False, 'func': None}
    with pytest.raises(AnsibleOptionsError) as excinfo:
        VaultCLI().execute_encrypt_string()
    assert 'No plaintext to encrypt' in str(excinfo.value)

    # Test with args


# Generated at 2022-06-16 20:15:12.260325
# Unit test for method execute_edit of class VaultCLI

# Generated at 2022-06-16 20:15:13.940481
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    vault_cli.execute_create()


# Generated at 2022-06-16 20:15:15.727788
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt()

# Generated at 2022-06-16 20:15:17.010219
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()
    vault_cli.run()


# Generated at 2022-06-16 20:16:29.566228
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    vault_cli.post_process_args()
    assert context.CLIARGS['func'] == vault_cli.execute_encrypt_string
    assert context.CLIARGS['encrypt_string_prompt'] == True
    assert context.CLIARGS['encrypt_string_read_stdin'] == False
    assert context.CLIARGS['encrypt_string_stdin_name'] == None
    assert context.CLIARGS['encrypt_string_names'] == []
    assert context.CLIARGS['show_string_input'] == False
    assert context.CLIARGS['ask_vault_pass'] == False
    assert context.CLIARGS['new_vault_id'] == None

# Generated at 2022-06-16 20:16:36.852723
# Unit test for method execute_encrypt_string of class VaultCLI

# Generated at 2022-06-16 20:16:48.286890
# Unit test for method execute_create of class VaultCLI

# Generated at 2022-06-16 20:16:56.289797
# Unit test for method run of class VaultCLI

# Generated at 2022-06-16 20:17:03.002952
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    assert vault_cli.post_process_args(['-v']) == ['-v']
    assert vault_cli.post_process_args(['--vault-id', 'foo', '-v']) == ['--vault-id', 'foo', '-v']
    assert vault_cli.post_process_args(['--vault-id', 'foo', '--vault-id', 'bar', '-v']) == ['--vault-id', 'bar', '-v']
    assert vault_cli.post_process_args(['--vault-id', 'foo', '--vault-id', 'bar', '--vault-id', 'baz', '-v']) == ['--vault-id', 'baz', '-v']
    assert vault_cli

# Generated at 2022-06-16 20:17:05.435916
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt()

# Generated at 2022-06-16 20:17:08.250152
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.execute_edit()


# Generated at 2022-06-16 20:17:10.122830
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    vault_cli.execute_edit()

# Generated at 2022-06-16 20:17:11.916594
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:17:22.480823
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    from ansible.utils.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import match_encrypt_secret
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.vault import get_vault_secrets
    from ansible.parsing.vault import get_vault_secret
    from ansible.parsing.vault import get_vault_password_file
    from ansible.parsing.vault import get_vault_password
    from ansible.parsing.vault import get_vault_ids
    from ansible.parsing.vault import get_vault_id

# Generated at 2022-06-16 20:19:35.674711
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.execute_view()


# Generated at 2022-06-16 20:19:36.828682
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-16 20:19:42.936397
# Unit test for method execute_decrypt of class VaultCLI

# Generated at 2022-06-16 20:19:52.428783
# Unit test for method run of class VaultCLI

# Generated at 2022-06-16 20:19:53.931494
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_cli = VaultCLI()
    vault_cli.execute_decrypt()


# Generated at 2022-06-16 20:19:54.778410
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:20:01.952711
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # Test with a file that doesn't exist
    with pytest.raises(AnsibleOptionsError):
        VaultCLI(['ansible-vault', 'encrypt', 'foo.yml'])

    # Test with a file that does exist
    with open('foo.yml', 'w') as f:
        f.write('foo: bar')

    # Test with a file that does exist
    with open('foo.yml', 'w') as f:
        f.write('foo: bar')

    # Test with a file that does exist
    with open('foo.yml', 'w') as f:
        f.write('foo: bar')

    # Test with a file that does exist
    with open('foo.yml', 'w') as f:
        f.write('foo: bar')

    # Test with a

# Generated at 2022-06-16 20:20:03.937302
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # FIXME: implement
    pass

# Generated at 2022-06-16 20:20:06.087312
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # FIXME: implement this test
    assert True


# Generated at 2022-06-16 20:20:09.101200
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_cli = VaultCLI()
    context.CLIARGS = {'args': ['filename']}
    vault_cli.execute_create()
