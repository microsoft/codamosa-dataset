

# Generated at 2022-06-10 22:30:51.779111
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    # Make an instance without calling .run() so we can test some methods
    cli = VaultCLI()

    # Save the real encrypt_file() method so we can restore it later
    real_encrypt_file = cli.editor.encrypt_file

    # Use a mock to assert the encrypt_file() method was called with expected args
    def encrypt_file(filename, secret, output_file=None, vault_id=None):
        assert filename == 'test_file'
        assert secret == b'new_encrypt_secret'
        assert vault_id == 'new_encrypt_vault_id'

        # The real encrypt_file() method might be called with the args from our mock
        # so we need to save the real args for testing.

# Generated at 2022-06-10 22:31:05.224932
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()
    testcase = VaultTestCase()
    testcase.setup_mock_constants()
    vault_cli.post_process_args(['/bin/ansible-vault', 'create', 'textfile1', '--name', 'first_var'])
    assert context.CLIARGS['encrypt_string_prompt'] == False
    assert context.CLIARGS['encrypt_string_stdin'] == False
    assert context.CLIARGS['encrypt_string_show_input'] == False
    assert context.CLIARGS['encrypt_string_names'] == ['first_var']

# Generated at 2022-06-10 22:31:07.053651
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    cli = VaultCLI()
    assert cli.execute_view() is None

# Generated at 2022-06-10 22:31:19.194056
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    from ansible.cli.vault import VaultCLI
    from ansible.config.manager import ConfigManager
    from ansible import context

    config_manager = ConfigManager()
    config = config_manager.get_config_obj()

    # TODO: this test relies on an existing vault file and password
    vault_file = u'/home/me/workspace/ansible_2.3.1/examples/vault-example.yml'
    vault_password_file = u'/home/me/workspace/ansible_2.3.1/examples/vault-example-passwd'
    new_vault_password_file = u'/home/me/workspace/ansible_2.3.1/examples/vault-example-rekey'

    # TODO: this test relies on a configured default vault id


# Generated at 2022-06-10 22:31:21.592863
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_cli = VaultCLI()
    vault_cli.execute_encrypt_string()

# Generated at 2022-06-10 22:31:29.658106
# Unit test for method execute_rekey of class VaultCLI

# Generated at 2022-06-10 22:31:40.140892
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    ''' test that we can rekey a file with a new secret '''
    # skip if vault is not available
    if not HAS_VAULT:
        exit
    empty_file = os.path.join(tempfile.gettempdir(), 'ansible-vault-test-rekey')
    # write an empty file
    with open(empty_file, 'w') as f:
        f.write("")
    # encrypt the empty file with the default password
    cmd = 'ansible-vault encrypt %s' % empty_file
    rc, stdout, stderr = module_execute(cmd)
    if rc != 0:
        raise Exception("Could not encrypt test file %s with default password, got rc=%s" % (empty_file, rc))
    # now rekey the file with a new password

# Generated at 2022-06-10 22:31:41.073144
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    pass


# Generated at 2022-06-10 22:31:52.671663
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    runner = CliRunner()
    result = runner.invoke(cli, ['create', '--ask-vault-pass', 'VaultCLI_test_vault.yml'])
    assert result.exit_code == 0
    with open('VaultCLI_test_vault.yml', 'w') as myfile:
        myfile.write('Vaulted in unit test')
    result = runner.invoke(cli, ['view', '--ask-vault-pass', 'VaultCLI_test_vault.yml'])
    assert result.exit_code == 0
    os.remove('VaultCLI_test_vault.yml')

# Generated at 2022-06-10 22:31:58.916564
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    cli = VaultCLI(args=dict(ask_vault_pass=False,
                             output_file=None,
                             pager='less',
                             version=False,
                             func=None))
    cli.editor = MagicMock()
    cli.execute_edit()
    cli.editor.edit_file.assert_called_with(None)



# Generated at 2022-06-10 22:32:31.371919
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():

    args = context.CLIARGS
    args['func'] = 'execute_decrypt'
    args['vault_password_file'] = 'pass'
    args['args'] = ['filename.yml']

    sc = VaultCLI()
    sc.execute()


# Generated at 2022-06-10 22:32:32.188844
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    pass

# Generated at 2022-06-10 22:32:44.176285
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():

    from ansible.cli.vault import VaultCLI

    v = VaultCLI()

    # Test1: valid args.
    args = {'func': 'execute_encrypt', 'encrypt_vault_id': 'test1', 'new_vault_id': 'test2'}
    assert v.post_process_args(args)

    # Test2: missing func.
    args = {'encrypt_vault_id': 'test', 'new_vault_id': 'test2'}
    assert not v.post_process_args(args)

    # Test3: missing encrypt_vault_id in 'rekey'.
    args = {'func': 'execute_rekey'}
    assert not v.post_process_args(args)

    # Test4: missing new_vault_id for 're

# Generated at 2022-06-10 22:32:49.129032
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    cli = VaultCLI(args=[])
    args=[]
    assert cli.post_process_args(args) == (None, None)


if __name__ == '__main__':
    test_VaultCLI_post_process_args()

# Generated at 2022-06-10 22:32:58.599213
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    f = open('/tmp/ansible-vault.test_VaultCLI_execute_view.tmp', 'w')
    f.write('\n')
    f.write('foo\n')
    f.write('bar\n')
    f.close()

    context.CLIARGS = {
        'args'   : ['/tmp/ansible-vault.test_VaultCLI_execute_view.tmp']
    }
    vault = VaultCLI(None)
    vault.execute_view()


# Generated at 2022-06-10 22:33:03.761535
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    filename = "test-%s.txt" % str(uuid.uuid4())
    try:
        with open(filename, "w") as testfile:
            testfile.write("testing")
        cli = VaultCLI(args=['ansible-vault', 'encrypt', filename], command_args=['testcommand'])
    finally:
        os.remove(filename)
    cli.setup()
    cli.execute_encrypt()


# Generated at 2022-06-10 22:33:04.675902
# Unit test for method execute_encrypt_string of class VaultCLI

# Generated at 2022-06-10 22:33:08.115575
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
	with pytest.raises(AnsibleOptionsError):
		VaultCLI(object).execute_decrypt()


# Generated at 2022-06-10 22:33:14.394887
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # Construct global context for test
    set_context(dict())

    # construct object to be tested
    vault = VaultCLI(dict(), dict())

    # Test execution of method execute_create() with exception
    try:
        vault.execute_create()
    except AnsibleOptionsError:
        pass
    else:
        assert False, "Expected exception"


# Generated at 2022-06-10 22:33:22.312007
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    from ansible.cli.vault import VaultCLI
    from ansible.config.manager import ConfigManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop, mock_unfrackpath_warndir
    mock_unfrackpath_noop()

    args = ['-h']
    vault_cli = VaultCLI(args)
    context.CLIARGS = vault_cli.parse()
    context.CLIARGS['func'] = vault_cli.run
    mock_unfrackpath_warndir()

    vault_cli.run()

# Generated at 2022-06-10 22:34:25.801112
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault = VaultCLI()
    import ansible.cli.vault as vault_cli
    context = vault_cli.VaultCLI.Context(CLIArgs(namespace=get_parser().parse_args([])))
    vault.post_process_args(context)
    assert context.CLIARGS['func']() == None


# Generated at 2022-06-10 22:34:37.409105
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    CLA = DummyModule()
    CLA.args = []
    CLA.pager = ['less']

    context_obj = DummyModule()
    context_obj.CLIARGS = CLA
    context_obj.terminal = DummyModule()
    context_obj.terminal.supports_color = False

    instance = VaultCLI()
    instance.editor = VaultEditor()
    instance.editor.plaintext = MagicMock()

    setattr(context_obj, 'pager', instance.pager)

    with patch('ansible.utils.context', new=context_obj):
        instance.execute_view()
        instance.editor.plaintext.assert_called_with()
        instance.pager.assert_called_with()


# Generated at 2022-06-10 22:34:44.012839
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    v = VaultCLI()
    a = dict(create=True, encrypt=True, edit=True)
    with pytest.raises(AnsibleOptionsError) as excinfo:
        v.post_process_args(a)
    assert "only one of the following" in str(excinfo.value)
    assert "create, encrypt, edit" in str(excinfo.value)
    assert "but more found: create, encrypt, edit" in str(excinfo.value)


# Generated at 2022-06-10 22:34:56.652617
# Unit test for method execute_edit of class VaultCLI

# Generated at 2022-06-10 22:35:05.139872
# Unit test for method run of class VaultCLI

# Generated at 2022-06-10 22:35:09.655918
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli = VaultCLI()
    vault_cli.editor = mock.Mock()
    vault_cli.encrypt_secret = mock.Mock()
    context.CLIARGS = {'args':['arg1', 'arg2']}


# Generated at 2022-06-10 22:35:13.425734
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli = VaultCLI
    args, kwargs = [], {}
    # No exception should be thrown when calling the method
    vault_cli.execute_encrypt()


# Generated at 2022-06-10 22:35:24.968909
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # Set up
    context.CLIARGS = dict()
    context.CLIARGS['vault_password_file'] = None
    context.CLIARGS['ask_vault_pass'] = False
    context.CLIARGS['encrypt_vault_id'] = None
    context.CLIARGS['cipher'] = 'default'
    context.CLIARGS['new_vault_id'] = None
    old_umask = os.umask(0o077)
    inventory = InventoryManager(loader=DictDataLoader({}))
    stdin_text = sys.stdin.read()
    vault_secrets = [(None, None)]

    # Test
    vaultcli = VaultCLI(None)
    loader = DataLoader()
    vault_secrets = vaultcli.setup_vault

# Generated at 2022-06-10 22:35:27.033356
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    cli = VaultCLI()
    cli.post_process_args()
    assert cli.vault_secrets


# Generated at 2022-06-10 22:35:31.585241
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    vault_editor = mock.Mock()
    vault_editor.create_file = mock.Mock()
    vault_cli = VaultCLI(vault_editor)
    vault_cli.encrypt_secret = "encrypt_secret"
    vault_cli.encrypt_vault_id = "encrypt_vault_id"
    context.CLIARGS = {'args': ['test_filename']}
    vault_cli.execute_create()
    vault_editor.create_file.assert_called_once_with(
        "test_filename", "encrypt_secret",
        vault_id="encrypt_vault_id")


# Generated at 2022-06-10 22:39:06.049655
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    args = ['--encrypt', '--encrypt-vault-id', 'dev@prompt', 'foo']
    vault_cli = VaultCLI(args)
    display.verbosity = 2

    parsed = vault_cli.parse()
    assert parsed.encrypt
    assert parsed.encrypt_vault_id == 'dev@prompt'
    assert parsed.new_vault_id == None
    assert parsed.new_vault_password_file == None
    assert parsed.output_file == None
    assert parsed.ask_vault_pass
    assert parsed.encrypt_string
    assert parsed.encrypt_string_prompt
    assert parsed.encrypt_string_stdin
    assert parsed.encrypt_string_names == []
    assert parsed.show_string_input
    assert parsed.decrypt
    assert parsed

# Generated at 2022-06-10 22:39:07.108731
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_cli = VaultCLI()



# Generated at 2022-06-10 22:39:11.076926
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault = VaultCLI()
    vault.ask_vault_pass = True
    vault.encrypt_secret = 'foo'
    vault.encrypt_vault_id = 'foo'
    vault.encrypt_string_prompt = True
    vault.encrypt_string_names = ['foo', 'bar']

    # FIXME: probably need to get this test to pass user input to the prompt and stdin.read
    #        run the function and check that the output is as expected
    vault.execute_encrypt_string()


# Generated at 2022-06-10 22:39:12.447440
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    # TODO: add unit test when we have tests!
    pass

# Generated at 2022-06-10 22:39:22.749494
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    vault_cli = VaultCLI()
    vault_cli.editor.decrypt_file = mock.MagicMock()
    vault_cli.execute_decrypt()
    vault_cli.editor.decrypt_file.assert_called_once_with('-', output_file=None)
    # Now supply some args to the cli
    context.CLIARGS = dict(args=['file1', 'file2'],
                           output_file=None)
    vault_cli.editor.decrypt_file.reset_mock()
    vault_cli.execute_decrypt()
    vault_cli.editor.decrypt_file.assert_has_calls([call('file1', output_file=None), call('file2', output_file=None)])

    # Now supply some args to the cli
    context.CLI

# Generated at 2022-06-10 22:39:31.104599
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    cli = VaultCLI()
    cli.encrypt_secret = 'mysecret'
    cli.editor = None
    cli.pager = lambda x: x
    vaulted_data = '$ANSIBLE_VAULT;1.1;AES256\n6162636465663031623863370a61323036336534663535623863370a6238316133396261326435346635356238316133396261326435346635356238\n'
    with tempfile.NamedTemporaryFile(delete=False) as tmpfile:
        tmpfile.write(vaulted_data)
        tmpfile.flush()
        cli.execute_view([tmpfile.name])
        # raise Exception(vars(cli))
        assert cli.editor.plaintext

# Generated at 2022-06-10 22:39:37.150119
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    import StringIO
    class StringIO:

        def __init__(self, data=None):
            if data is None:
                self.data = []
            else:
                self.data = data


# Generated at 2022-06-10 22:39:46.233787
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    from ansible.cli.arguments import options as cli_options
    from ansible import context
    import sys

    sys.argv = [
        'ansible-vault',
        '--vault-password-file',
        '/etc/ansible/bar.txt',
        'my_file',
        'mytext'
    ]

    context.CLIARGS = cli_options.parse()
    cli = VaultCLI()
    cli.post_process_args()

    assert cli.encrypt_string_read_stdin is True
    assert cli.encrypt_vault_id == "my_file"
    assert len(context.CLIARGS['args']) == 1
    assert context.CLIARGS['args'][0] == 'mytext'



# Generated at 2022-06-10 22:39:56.955067
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
            hostname = 'localhost'
            groups = dict()
            groups['group_1'] = ['host_1', 'host_2']
            groups['ungrouped'] = ['host_3']

            inventory = Inventory(host_list=[], groups=groups)
            task = Task(action='action_1', host=hostname)
            play = Play().load(dict(
                name = "Ansible Play",
                hosts = 'all',
                gather_facts = 'no',
                tasks = [
                    dict(action=dict(module='command', args=dict(cmd='whoami'))),
                ]
            ))


            tqm = None