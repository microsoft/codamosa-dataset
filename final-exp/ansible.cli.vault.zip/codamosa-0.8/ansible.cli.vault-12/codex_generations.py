

# Generated at 2022-06-10 22:30:36.294097
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    pass

# Generated at 2022-06-10 22:30:39.279494
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():

    # pass (assert_raises is handled by plugin_loader)
    pass


# Generated at 2022-06-10 22:30:47.205376
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    import argparse

    args = argparse.Namespace()
    args.cliargs = dict(args='foo', new_vault_id='default')
    args.vault_password_file = None
    args.ask_vault_pass = None
    args.action = 'view'
    args.view_vault_id = 'default'
    args.new_vault_password_file = None
    args.output_file = None
    args.keep_vault_order = None
    args.encrypt_string_prompt = None
    args.encrypt_string_stdin = None
    args.encrypt_string_stdin_name = None
    args.encrypt_string_names = None
    args.show_string_input = None
    args.encrypt_vault_id = 'default'

   

# Generated at 2022-06-10 22:30:57.569597
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():

    # test setup
    # clear context.
    context._init_global_context()

    # initialize context.CLIARGS
    context.CLIARGS = mock.MagicMock()
    context.CLIARGS.get = lambda self, x: None
    context.CLIARGS.args = ['hello']
    context.CLIARGS.encrypt_string = False
    context.CLIARGS.encrypt_string_prompt = False
    context.CLIARGS.list_vault_ids = False
    context.CLIARGS.new_vault_password_file = None
    context.CLIARGS.vault_ids = None

    # create a VaultCLI object
    v = VaultCLI()

    # run post_process_args
    v.post_process_args()

    #

# Generated at 2022-06-10 22:31:09.362845
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    template_fd, template_path = tempfile.mkstemp()

# Generated at 2022-06-10 22:31:22.157566
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    # FIXME: needs test data

    # FIXME: hack to be able to mock the SystemExit exception
    import __builtin__
    if 'SystemExit' not in __builtin__.__dict__:
        __builtin__.__dict__['SystemExit'] = SystemExit

    # TODO: fill in the rest of the test
    # TODO: fill in cli.execute_encrypt and cli.execute_encrypt_string
    # TODO: fill in cli.execute_decrypt

    import ansible.utils.encrypt as encrypt

    original_encrypt = encrypt.encrypt
    original_get_encryption_password = encrypt.get_encryption_password
    original_encrypt_bytes = encrypt.encrypt_bytes
    original_decrypt_bytes = encrypt.decrypt_bytes
    original_decrypt = encrypt

# Generated at 2022-06-10 22:31:26.979457
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    vault_cli = VaultCLI()
    context.CLIARGS = {'args': ['xxx']}
    try:
        vault_cli.execute_edit()
        print('unit test success')
    except:
        print('unit test failed')

# Generated at 2022-06-10 22:31:40.048349
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    vault_secret_list = [['default', 'password']]
    vault_secret = vault_secret_list[0]
    vault_secret_file = None
    vault_password_file = None
    vault_id = 'default'
    args = ['some_text_to_encrypt']
    set_context_args(['vault', 'encrypt_string', '-'] + args, vault_secret_list, vault_secret_file, vault_password_file, vault_id)
    cli = VaultCLI()
    try:
        cli.execute_encrypt_string()
    except AnsibleOptionsError as e:
        import sys
        sys.stderr.write(str(e))


# Generated at 2022-06-10 22:31:40.959207
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault = VaultCLI()



# Generated at 2022-06-10 22:31:54.143207
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    test_obj = VaultCLI()

# Generated at 2022-06-10 22:32:25.029737
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    cli=VaultCLI([])
    with pytest.raises(AnsibleOptionsError) as e_info:
        cli.execute_decrypt()

test_VaultCLI_execute_decrypt()

# Generated at 2022-06-10 22:32:33.717418
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # Create an instance of a generic class, with default args
    vault_cli = VaultCLI()

    env = {}
    env['PYTHONIOENCODING'] = 'utf-8'

    def test_exec_encrypt(vault_id, here, mock_env):
        args = [vault_id, here + 'before.yml', '--output=' + here + '/after.yml']
        vault_cli.run(args)

        with io.open(here + 'after.yml', encoding='utf-8') as f:
            output = f.read()

        return output

    def test_encrypt(vault_id, here, mock_env):
        test_output = test_exec_encrypt(vault_id, here, mock_env)


# Generated at 2022-06-10 22:32:35.914399
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    v = VaultCLI()
    v.execute_encrypt()
    pass

# Generated at 2022-06-10 22:32:41.029926
# Unit test for method execute_edit of class VaultCLI
def test_VaultCLI_execute_edit():
    test_object = VaultCLI()
    test_object.editor = None
    with pytest.raises(AnsibleAssertionError) as excinfo:
        test_object.execute_edit()
    assert 'must be set' in str(excinfo.value)



# Generated at 2022-06-10 22:32:53.780376
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    vault_id = context.CLIARGS['encrypt_vault_id'] or C.DEFAULT_VAULT_ENCRYPT_IDENTITY
    # print('encrypt_vault_id: %s' % encrypt_vault_id)
    # print('default_encrypt_vault_id: %s' % default_encrypt_vault_id)

    # new_vault_ids should only ever be one item, from
    # load the default vault ids if we are using encrypt-vault-id
    new_vault_ids = []
    if encrypt_vault_id:
        new_vault_ids = default_vault_ids

# Generated at 2022-06-10 22:33:03.728626
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():

    # Test with ansible_vault_password_file
    args = [
        "/tmp/ansible-vault-python-argument",
        "--vault-password-file=/home/pjc/.vault_pass.txt"
    ]

    with mock.patch.object(sys, 'argv', args):
        cli = VaultCLI()
        context.CLIARGS = cli.parse()
        cli.post_process_args(context.CLIARGS, None)

    # Test without ansible_vault_password_file
    args = [
        "/tmp/ansible-vault-python-argument",
    ]

    with mock.patch.object(sys, 'argv', args):
        cli = VaultCLI()
        context.CLIARGS = cli.parse()
        cl

# Generated at 2022-06-10 22:33:12.359659
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    v = VaultCLI()
    v.setup_vault_secrets = mock.Mock()
    v.editor = mock.Mock()
    v.encrypt_secret = 'foo'
    v.encrypt_vault_id = 'bar'
    v.execute_create()
    v.editor.create_file.assert_called_once_with(context.CLIARGS['args'][0], v.encrypt_secret, vault_id=v.encrypt_vault_id)


# Generated at 2022-06-10 22:33:18.329473
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    plaintext = 'test plaintext'
    key = 'test key'
    vault_cli.encrypt_secret = key
    vault_cli.editor.encrypt = mock.Mock(return_value=plaintext)
    vault_cli.pager = mock.Mock()

    vault_cli.execute_view()
    assert vault_cli.pager.called


# Generated at 2022-06-10 22:33:22.456528
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    cli = VaultCLI()
    cli.editor.create_file = MagicMock(return_value=0)
    cli.execute_create()
    assert cli.editor.create_file.call_args[0][0] == 'filename'
    assert cli.editor.create_file.call_args[1]['vault_id'] == None


# Generated at 2022-06-10 22:33:32.776522
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    args = dict(
        args=['foo'],
        encrypt_string_prompt=True,
        encrypt_string_stdin_name=None,
        encrypt_string_read_stdin=False,
        encrypt_vault_id=None,
        show_string_input=False,
    )
    context.CLIARGS = MagicMock(**args)
    cli = VaultCLI()

    class MockedTempfile(object):
        def __init__(self, name=''):
            self.name = name
            self.closed = False
        def close(self):
            self.closed = True

    monkeypatch.setattr(tempfile, 'NamedTemporaryFile', MockedTempfile)
    monkeypatch.setattr(display, 'prompt', lambda x: 'foo')
    monkeypatch.set

# Generated at 2022-06-10 22:35:03.681432
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vault_cli = VaultCLI()
    vault_cli.pager = pager
    vault_cli.editor = VaultEditor(VaultLib())
    # TODO: create a test file
    test_file = 'file.txt'
    expected = 'this is test'
    result = vault_cli.execute_view([test_file])
    assert expected == result
# Test method

# Generated at 2022-06-10 22:35:14.466706
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    vault_cli = VaultCLI()

    # not calling object construct
    # This is not a real CLI use, but it is a way to test the arg processing.

    # Test the definitions of the test_options to see that they match what we expect
    # The test_options arg is the only arg we are passed, so we need to test that it is a dict
    # and that it has the right keys, and that those keys have the right values.
    context.CLIARGS = {}

    args = ['ansible-vault', 'encrypt', 'foo']

    # This is a pretty dumb test, but it does not error out.
    vault_cli.post_process_args(args)

    # The real test

# Generated at 2022-06-10 22:35:25.542935
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    test_file = 'testfile'
    vault_secret = 'sekrit'

    def fake_editor_encrypt_file(self, filename, secret, vault_id=None, output_file=None):
        return to_bytes(vault_secret)


# Generated at 2022-06-10 22:35:27.322807
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    vault_cli_obj = VaultCLI()
    vault_cli_obj.execute_encrypt()


# Generated at 2022-06-10 22:35:29.858319
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    vaultcli = VaultCLI(parser=Parser())
    assert not vaultcli.execute_view() # TODO: This should raise exception because of no args.


# Generated at 2022-06-10 22:35:31.877478
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI(args=['view', '-', '-v'])
    vault_cli.run()
#

# Generated at 2022-06-10 22:35:43.316232
# Unit test for method post_process_args of class VaultCLI
def test_VaultCLI_post_process_args():
    # Setup
    from ansible.cli import CLI

    cli = CLI()
    vault_cli = VaultCLI(cli)

    # test to see if args get converted as expected using correct cli argument names
    context.CLIARGS = {'encrypt_string': [u"test_name", u"test_value"], 'ask_vault_pass': False, 'encrypt_string_prompt': False}
    vault_cli.post_process_args()

    result_encrypt_string = copy.deepcopy(context.CLIARGS)
    result_encrypt_string.pop('encrypt_string')


# Generated at 2022-06-10 22:35:51.667518
# Unit test for method execute_encrypt_string of class VaultCLI
def test_VaultCLI_execute_encrypt_string():
    loader, inventory, vault_secrets = setup_loader()
    context.CLIARGS = ImmutableDict(connection='local',
                                    forks=10,
                                    become=False,
                                    become_method=None,
                                    become_user=None,
                                    check=False,
                                    diff=False,
                                    verbosity=4,
                                    module_path=None,
                                    start_at_task=None,
                                    inventory=inventory,
                                    subset=[],
                                    extra_vars=[],
                                    tags=[],
                                    skip_tags=[],
                                    run_once=False,
                                    vault_password_files=[],
                                    vault_ids=[],
                                    default_vault_id='1')
    cli = VaultCLI(args=[])
    cli.setup

# Generated at 2022-06-10 22:35:52.809576
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    assert False, "Test case not implemented"


# Generated at 2022-06-10 22:35:54.178109
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    vault_cli = VaultCLI()

# Generated at 2022-06-10 22:37:56.444736
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # -- HELP --
    # VaultCLI.execute_create()
    # VaultCLI.execute_edit()
    # For now just test it doesn't blow up

    # Execute
    vault_cli = VaultCLI()
    vault_cli.execute_create()
    vault_cli.execute_edit()
    # Assertions
    assert True


################################################################################
# AnsibleOptions



# Generated at 2022-06-10 22:37:59.775290
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    # This method uses a singleton for module, so we can not use it for test.
    # We should update test method.
    return

# Generated at 2022-06-10 22:38:08.772828
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    '''
    unit test for execute_decrypt
    '''
    import os

    import pytest

    from units.compat import unittest
    from units.compat.mock import patch, MagicMock, Mock

    from ansible.cli.vault import VaultCLI

    vault_file = os.path.join(os.path.dirname(__file__), 'fixtures', 'vault-unittest.yml')

    # unencrypted file has same number of bytes as encrypted file
    with open(vault_file) as f:
        unencrypted_bytes_len = len(f.read().encode('utf-8'))

    with open(vault_file+'.vault') as f:
        encrypted_bytes_len = len(f.read().encode('utf-8'))

    assert un

# Generated at 2022-06-10 22:38:12.430601
# Unit test for method execute_create of class VaultCLI
def test_VaultCLI_execute_create():
    arguments = ['ansible-vault', 'create',
        '/Users/martin/ansible/hacking/test/units/modules/utilities/crypto/fixtures/foo.yml',
        '--vault-password-file',
        '/Users/martin/ansible/hacking/test/units/modules/utilities/crypto/fixtures/vault_pass.txt']
    cli = VaultCLI(args = arguments)
    cli.setup()
    cli.parse()
    cli.run()


# Generated at 2022-06-10 22:38:13.381950
# Unit test for method execute_rekey of class VaultCLI
def test_VaultCLI_execute_rekey():
    pass

# Generated at 2022-06-10 22:38:15.648905
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    v = VaultCLI()
    # FIXME: implement VaultCLI.execute_view


# Generated at 2022-06-10 22:38:26.893008
# Unit test for method run of class VaultCLI
def test_VaultCLI_run():
    from ansible.cli import CLI 
    from ansible.config.manager import ConfigManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.cli import ParsingError 
    from ansible.module_utils.common.text.converters import to_bytes

    config_manager = ConfigManager(args=None)
    InventoryManager(loader=DataLoader(), sources='')
    VariableManager()
    config_manager._options_parsed = True
    config_manager._parsed_config_data = MutableMapping()

# Generated at 2022-06-10 22:38:27.767195
# Unit test for method execute_decrypt of class VaultCLI
def test_VaultCLI_execute_decrypt():
    pass

# Generated at 2022-06-10 22:38:40.984807
# Unit test for method execute_view of class VaultCLI
def test_VaultCLI_execute_view():
    import sys
    import os
    import tempfile
    import shutil
    
    
    from ansible.utils.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.cli.vault import VaultCLI
    from ansible.parsing.vault import VaultSecret
    
    
    class FakeVaultEditor(object):
        def __init__(self, vault):
            self._vault = vault
    
        def plaintext(self, file_name):
            return self._vault.decrypt(file_name)
    
    class FakePager(object):
        def __init__(self):
            self.content = None
    
        def __call__(self, content):
            self.content = content
    
    
    vault_

# Generated at 2022-06-10 22:38:46.906882
# Unit test for method execute_encrypt of class VaultCLI
def test_VaultCLI_execute_encrypt():
    # Tested method (actual function to test)
    vaultCLI = VaultCLI(args={'ask_vault_pass': False,
                              'func': VaultCLI.execute_encrypt,
                              'output_file': 'output_file',
                              'vault_password_file': ['python/ansible/cli/vault_password_file']})
    vaultCLI.execute_encrypt()
