

# Generated at 2022-06-22 09:33:17.501380
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass('test__AVMClass_register_methods', '')
    avm_class.register_methods({
        'test__AVMClass_register_methods__0': 0x01,
        'test__AVMClass_register_methods__1': 0x02,
        'test__AVMClass_register_methods__2': 0x03,
    })
    assert avm_class.method_names == {
        'test__AVMClass_register_methods__0': 0x01,
        'test__AVMClass_register_methods__1': 0x02,
        'test__AVMClass_register_methods__2': 0x03,
    }

# Generated at 2022-06-22 09:33:18.582410
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

# Generated at 2022-06-22 09:33:22.934258
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert _Undefined() == _Undefined()
    assert _Undefined() is not None
    assert hash(_Undefined()) == hash(_Undefined())
    assert len(str(_Undefined())) > 0
    assert len(repr(_Undefined())) > 0

Undefined = _Undefined()



# Generated at 2022-06-22 09:33:28.777554
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass('foo', 'foo')
    avm_class.register_methods({'foo': 1, 'bar': 2})
    assert avm_class.method_names == {'foo': 1, 'bar': 2}
    assert avm_class.method_idxs == {1: 'foo', 2: 'bar'}

    avm_class.register_methods({'bar': 2, 'baz': 3})
    assert avm_class.method_names == {'foo': 1, 'bar': 2, 'baz': 3}
    assert avm_class.method_idxs == {1: 'foo', 2: 'bar', 3: 'baz'}



# Generated at 2022-06-22 09:33:29.894916
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0)



# Generated at 2022-06-22 09:33:31.866985
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(3)
    _Multiname(5)
    _Multiname(9)


# Generated at 2022-06-22 09:33:39.445941
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    _AVMClass('name', 'name', {})


AVM_METHOD_FLAG_NEEDARGUMENTS = 0x01
AVM_METHOD_FLAG_NEEDACTIVATION = 0x02
AVM_METHOD_FLAG_NEEDREST = 0x04
AVM_METHOD_FLAG_HASOPTIONAL = 0x08
AVM_METHOD_FLAG_SETDXNS = 0x40
AVM_METHOD_FLAG_HASPARAMNAMES = 0x80


# Generated at 2022-06-22 09:33:45.133947
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():  # pragma: no cover
    class ScopeClass(object):
        name = 'MyClass'
    scope = _ScopeDict(ScopeClass)
    assert repr(scope) == 'MyClass__Scope({})'
    try:
        class AnotherScopeClass(object):
            pass
    except TypeError:
        pass
    else:
        raise AssertionError
test__ScopeDict()



# Generated at 2022-06-22 09:33:47.209524
# Unit test for constructor of class _Multiname
def test__Multiname():
    x = _Multiname(0x0055)
    assert repr(x) == '[MULTINAME kind: 0x55]'



# Generated at 2022-06-22 09:33:48.917175
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'

Undefined = _Undefined()



# Generated at 2022-06-22 09:34:42.056559
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    import doctest
    doctest.testmod()



# Generated at 2022-06-22 09:34:52.012427
# Unit test for constructor of class _Multiname
def test__Multiname():
    m = _Multiname(3)
    assert m
    assert m.kind == 3
    assert str(m) == '[MULTINAME kind: 0x3]'



# Generated at 2022-06-22 09:34:54.455796
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert str(_ScopeDict(None)) == '__Scope({})'
    assert str(_ScopeDict(None, foo=2)) == '__Scope({\'foo\': 2})'



# Generated at 2022-06-22 09:34:55.990197
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not bool(_Undefined())
    assert not bool(_Undefined)



# Generated at 2022-06-22 09:34:59.487569
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter(filepath='test.swf', console_out=True)
    print(interpreter)


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-22 09:35:00.992152
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not bool(_Undefined())
    assert not _Undefined()


# Generated at 2022-06-22 09:35:05.587798
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    pass

    avm_class = _AVMClass('x', 'y')
    avm_class.register_methods(
        {'a': 1, 'b': 2})
    assert avm_class.method_names == {'a': 1, 'b': 2}
    assert avm_class.method_idxs == {1: 'a', 2: 'b'}



# Generated at 2022-06-22 09:35:13.942488
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from flash_player.compat import xrange

    swfi = SWFInterpreter()

    def add(args):
        assert len(args) == 2
        a, b = args
        assert isinstance(a, int)
        assert isinstance(b, int)
        return a + b

    funcs0 = {
        'add': add,
    }

    def ident(args):
        assert len(args) == 1
        return args[0]

    funcs1 = {
        'ident': ident,
    }

    avm_class0 = _AVMClass(
        'VectorClass', variables={}, static_properties={}, static_functions=funcs0,
        method_names=funcs0.keys(),
        is_vector=True)

# Generated at 2022-06-22 09:35:23.905518
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .rtmp_download import CallFunction
    from .utils import (
        find_xmpmeta, xattr_set, xattr_get, xattr_del,
        parse_m3u8_master_playlist, sanitize_open, save_json, load_json)

    # Create an interpreter

# Generated at 2022-06-22 09:35:26.135886
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    instance1 = _AVMClass(1, 'name')
    assert repr(instance1) == '_AVMClass(name)'
    assert instance1._AVMClass__repr__() == '_AVMClass(name)'

# Generated at 2022-06-22 09:36:31.334806
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from yaml import dump as ydump
    interpreter = SWFInterpreter(BytesIO())

    avm_class = interpreter.avm_classes[0]
    avm_class.method_names.append('foo')


# Generated at 2022-06-22 09:36:40.559912
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    a = _AVMClass('a', 'a')
    o = a.make_object()
    o2 = a.make_object()
    assert o.avm_class == a
    assert o2.avm_class == a
    assert o != o2


_AVM_STRINGS = []
_AVM_TAG_STACK = []
_AVM_TAG_STACK_DEPTH = -1
_AVM_INSTANCE_STACK = []
_AVM_INSTANCE_STACK_DEPTH = -1
_AVM_GLOBAL = _ScopeDict(None)
_AVM_CALL_STACK = []
_AVM_CALL_STACK_DEPTH = -1
_AVM_CONSTANTS = {}
_AVM_METHODS = {}
_AVM_CLASSES

# Generated at 2022-06-22 09:36:43.078329
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    avm_interpreter = SWFInterpreter()
    assert avm_interpreter.classes == {}



# Generated at 2022-06-22 09:36:46.117988
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == 'undefined'
    

# Generated at 2022-06-22 09:36:47.804115
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    # Failed to import 'flash_cookie_py'
    pass

# Generated at 2022-06-22 09:36:50.484800
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert (repr(_Multiname(0x07))) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-22 09:36:51.863392
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    _ScopeDict('a', 'b')



# Generated at 2022-06-22 09:36:52.969858
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    _Undefined()
Undefined = _Undefined()



# Generated at 2022-06-22 09:36:54.905232
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    o = _AVMClass(0, 'Test').make_object()
    assert o.avm_class.name == 'Test'


# Generated at 2022-06-22 09:36:57.779233
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    _AVMClass('1', '3')


# Generated at 2022-06-22 09:38:49.029295
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    '''
    >>> str(_Undefined())
    'undefined'
    >>> repr(_Undefined())
    'undefined'
    '''


# Generated at 2022-06-22 09:38:50.611106
# Unit test for constructor of class _Multiname
def test__Multiname():
    print(_Multiname(1))



# Generated at 2022-06-22 09:38:54.895267
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .test import TestCase
    # Test for method __repr__ of class _ScopeDict (0-argument)
    class TestClass:
        pass
    TestClass.name = 'TestClass'
    testclass = TestClass()
    testdict = _ScopeDict(testclass)
    assert testdict.avm_class is testclass
    assert str(testdict) == 'TestClass__Scope({})'



# Generated at 2022-06-22 09:39:02.855914
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .swfdecompiler import _AVMClass
    c = _AVMClass('foo')
    x = _ScopeDict(c)
    assert repr(x) == "foo__Scope({})"
    x['foo'] = 5
    assert repr(x) == "foo__Scope({'foo': 5})"
    assert len(x) == 1
    x['bar'] = 6
    assert repr(x) == "foo__Scope({'bar': 6, 'foo': 5})"
    assert len(x) == 2
    x['baz'] = 7
    assert repr(x) == "foo__Scope({'bar': 6, 'baz': 7, 'foo': 5})"
    assert len(x) == 3



# Generated at 2022-06-22 09:39:11.649790
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class _FileLike(object):
        def __init__(self, data):
            self._data = data
            self._read_pos = 0

        def read(self, size):
            res = self._data[self._read_pos:self._read_pos + size]
            self._read_pos += size
            return res

    f = _FileLike(_SWF_TEST_FUNC_1)
    interpreter = SWFInterpreter(f)
    interpreter.read_info()

    assert 'ABC_Global.abc' in interpreter.abc_files
    abc_file = interpreter.abc_files['ABC_Global.abc']
    assert abc_file.method_pyfunctions['TestFunction0'] is None
    assert abc_file.method_pyfunctions['TestFunction1'] is None

    interpreter.patch_

# Generated at 2022-06-22 09:39:15.487455
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _TestAVMClass(object):
        def __init__(self):
            self.name = 'TestAVMClass'
    inst = _ScopeDict(_TestAVMClass())
    assert '%s' % inst == 'TestAVMClass__Scope({})'
test__ScopeDict()



# Generated at 2022-06-22 09:39:24.079151
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # open a file for reading
    f = open('testdata/hello.swf', 'rb')

    # create an instance of the SWFInterpreter class
    swf = SWFInterpreter()

    # read the SWF file into the SWFInterpreter class
    swf.read(f)

    # close the file
    f.close()

    # Find the AVM class for the main timeline
    avm_class = swf.find_class_by_name('__Packages.MainTimeline')

    # Patch the play function
    swf.patch_function(avm_class, 'play', lambda x: None)


# Generated at 2022-06-22 09:39:26.774868
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    cl = _AVMClass('_Class', '_Class')
    obj = cl.make_object()
    assert isinstance(obj, _AVMClass_Object)



# Generated at 2022-06-22 09:39:32.785957
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from .utils import (
        run_unary_test,
    )

    # Construct argument(s)
    arg0 = 'dummy'
    arg1 = _AVMClass(None, 'dummy')
    # Call the target
    ret = repr(arg1)
    # Check the result
    expected = '_AVMClass(dummy)'

    # Construct argument(s)
    arg0 = 'dummy'
    arg1 = _AVMClass(None, 'dummy')
    arg2 = {}
    # Call the target
    ret = repr(arg1)
    # Check the result
    expected = '_AVMClass(dummy)'

    # Call the unit test
    ret = run_unary_test(__repr__, arg0, arg1,
                         expected, ret)
    return ret




# Generated at 2022-06-22 09:39:41.615312
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class C1(object):
        name = 'C1'
        def __init__(self, name, age=3, height=100):
            self.name = name
            self.age = age
            self.height = height
    class C2(object):
        name = 'C2'
    # Test with no parameter
    c = _AVMClass_Object(C1)
    assert c.avm_class == C1
    assert c.name == ''
    assert c.age == 3
    assert c.height == 100
    # Test with only name, age
    c = _AVMClass_Object(C1, 'abc', 77)
    assert c.avm_class == C1
    assert c.name == 'abc'
    assert c.age == 77
    assert c.height == 100
    # Test with