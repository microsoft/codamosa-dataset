

# Generated at 2022-06-22 09:32:49.511911
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    def testme(test_me, expected_str):
        assert expected_str == repr(test_me())

    from .swfdec import AVMClass

    class MyClass(object):
        def __init__(self):
            self.name = 'MyClass'
    my_dict1 = _ScopeDict(MyClass())
    testme(lambda: my_dict1, 'MyClass__Scope({})')
    my_dict2 = _ScopeDict(AVMClass())
    my_dict2['a'] = 1
    del my_dict2['a']
    testme(lambda: my_dict2, 'AVMClass__Scope({})')



# Generated at 2022-06-22 09:32:53.150090
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class Foo(object):
        def __init__(self, name):
            self.name = name

    assert repr(_AVMClass_Object(Foo('bar'))) == 'bar#%x' % id(_AVMClass_Object(Foo('bar')))



# Generated at 2022-06-22 09:32:53.994030
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    pass



# Generated at 2022-06-22 09:32:58.594895
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    import doctest
    _ScopeDict.__module__ = '__main__'
    doctest.run_docstring_examples(_ScopeDict(None), globals())



# Generated at 2022-06-22 09:32:59.271710
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0)



# Generated at 2022-06-22 09:33:01.986624
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interp = SWFInterpreter()
    if isinstance(interp, compat_str):
        assert 0

# Generated at 2022-06-22 09:33:07.333125
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    global _AVMClass_Object, _ScopeDict, _AVMClass
    name_idx = 0
    name = 'TestClass'
    static_properties = {}
    obj_0 = _AVMClass(name_idx, name, static_properties)
    this_repr = repr(obj_0)
    ret_val_0 = this_repr
    return ret_val_0
_AVMMethod_next_unique_id = -1

# Generated at 2022-06-22 09:33:09.845521
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class C:
        pass
    obj = _AVMClass_Object(C())
    assert obj.avm_class == C()



# Generated at 2022-06-22 09:33:11.201884
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert 'undefined' == repr(_Undefined())


# Generated at 2022-06-22 09:33:23.683260
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    avm = SWFInterpreter(b'')
    avm.constant_numbers = [1.0]
    avm.constant_strings = ['a']
    avm.constant_namespaces = [{}]
    avm.constant_namespace_sets = [
        [[avm.constant_namespaces[0]]]]
    avm.multinames = [_Multiname('foo.bar.baz', 0)]

    expected_stack = []
    expected_scopes = [
        _ScopeDict(avm.constant_namespace_sets[0], {}),
        _ScopeDict(avm.constant_namespace_sets[0], {})]
    expected_registers = [None, None, None, None]
    expected_coder = BytesIO()
    expected

# Generated at 2022-06-22 09:34:18.296900
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    def try_swf(filename):
        interp = SWFInterpreter(filename)
        interp.execute()
    tdata = ['sample.swf']
    for filename in tdata:
        try_swf(filename)


# Generated at 2022-06-22 09:34:29.208801
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _TestAVMClass(object):
        name = '_TestAVMClass'
    def test_scope_dict(d):
        return d._scope_dict
    scope_dict = test_scope_dict(_ScopeDict(_TestAVMClass()))
    name = scope_dict['_TestAVMClass__name']
    assert name == '_TestAVMClass'
    scope_dict['name'] = '_TestAVMClass'
    assert scope_dict['name'] == '_TestAVMClass'
    assert scope_dict['_TestAVMClass__name'] == '_TestAVMClass'
    assert scope_dict['name'] == '_TestAVMClass'
    scope_dict['_name'] = '_name'
    assert scope_dict['name'] == '_TestAVMClass'
    assert scope_

# Generated at 2022-06-22 09:34:37.370522
# Unit test for constructor of class _Undefined
def test__Undefined():
    if not 0:
        # specific asserts for mypy
        assert not _Undefined()
        assert _Undefined() == None  # noqa: E711
        assert hash(_Undefined()) == 0
        assert str(_Undefined()) == 'undefined'


_undefined = _Undefined()

_default_abc_values = {
    0: _undefined,
    1: 0,
    2: 0.0,
    3: False,
    4: None,
    5: '',
}



# Generated at 2022-06-22 09:34:40.291591
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    t = _AVMClass('Teest', 1)
    t.register_methods({'aMethod': 0x1234, 'anotherMethod': 0x5678})
    assert t.method_names == {'aMethod': 0x1234, 'anotherMethod': 0x5678}
    assert t.method_idxs == {0x1234: 'aMethod', 0x5678: 'anotherMethod'}




# Generated at 2022-06-22 09:34:42.362725
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    obj = _AVMClass('name', 'name')
    obj.register_methods({'method1': 'method1_idx'})
    assert obj.method_names == {'method1': 'method1_idx'}
    assert obj.method_idxs == {'method1_idx': 'method1'}

# Generated at 2022-06-22 09:34:47.102848
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class _AVMClass(object):
        name = 'test'
    scope = _ScopeDict(_AVMClass())
    scope['foo'] = 'bar'
    scope['baz'] = 'qux'
    assert repr(scope) == 'test__Scope({\'foo\': \'bar\', \'baz\': \'qux\'})'



# Generated at 2022-06-22 09:34:57.751579
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import zlib

# Generated at 2022-06-22 09:35:01.769807
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    a = _AVMClass('a', 'b', static_properties={123: 456})
    assert a.name_idx == 'a'
    assert a.name == 'b'
    assert a.static_properties == {123: 456}



# Generated at 2022-06-22 09:35:03.795603
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    pyamf = PyAMF()
    interpreter = SWFInterpreter(pyamf)
    class A:
        pass # TODO

# Generated at 2022-06-22 09:35:05.264843
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'

# Generated at 2022-06-22 09:37:00.728109
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    #swf_file = './stackoverflow.swf'
    #swf_file = './lol.swf'
    #swf_file = './sina.swf'
    swf_file = './global.swf'
    assert os.path.isfile(swf_file)
    with open(swf_file, 'rb') as f:
        swf = f.read()
    i = SWFInterpreter(swf)
    c = i.global_properties['com']
    f = c.static_properties['net']
    f = f.static_properties['jp15x']
    f = f.static_properties['hls'].static_properties['VideoPlayer']
    f = f.static_properties['_start']

# Generated at 2022-06-22 09:37:04.684334
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass(1, 'Test', {'a': 1, 'b': 2})
    assert class_.name_idx == 1
    assert class_.name == 'Test'
    assert class_.static_properties == {'a': 1, 'b': 2}



# Generated at 2022-06-22 09:37:06.215975
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    m = _Multiname(0)
    repr(m)



# Generated at 2022-06-22 09:37:15.364957
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    _BaseAVMClass = {}
    _BaseAVMClass['String'] = StringClass
    interpreter = SWFInterpreter(
        _BaseAVMClass,
        _Undefined,
        None)

    abc_string = compat_struct_pack(
        '<7sL',
        b'\x01\x02\x03\x04\x05\x06\x07',
        8)
    abc_string = compat_BytesIO(abc_string)

    tags, _ = swfdecompress(abc_string)
    abc_part = BytesIO()

    # Trailer length (16)
    abc_part.write(compat_struct_pack('<L', 16))

    abc_part.write(tags[-1])
    abc_part.seek(0)

   

# Generated at 2022-06-22 09:37:23.597040
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from swftags.avm_constructs import call_method, create_function
    from swftags.avm_constructs import define_property, get_property
    from swftags.avm_constructs import get_variable, set_variable
    from swftags.avm_ops import AVMOp_add, AVMOp_coerce, AVMOp_construct
    from swftags.avm_ops import AVMOp_divide, AVMOp_dup, AVMOp_greater_than
    from swftags.avm_ops import AVMOp_if_eq, AVMOp_if_le, AVMOp_if_ne
    from swftags.avm_ops import AVMOp_less_than, AVMOp_modulo, AVMOp_multiply

# Generated at 2022-06-22 09:37:26.804103
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-22 09:37:34.291946
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    def class_resolver_1(name):
        class _AVMClass_stub(object):
            def __init__(self, name):
                self.name = name
        return _AVMClass_stub(name)
    scope_dict = _ScopeDict(class_resolver_1('foo'))
    assert repr(scope_dict) == 'foo__Scope({})'

_reserved_prefixes = set(['__'])



# Generated at 2022-06-22 09:37:38.638580
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from yarl import URL
    from io import BytesIO
    from ..utils import (
        make_fake_swf, fake_avm2_class, fake_avm2_method)

    swf = make_fake_swf('http://localhost/foo.swf')
    avm_class1 = fake_avm2_class(b'Bar1', ns='http://x')
    avm_class2 = fake_avm2_class(b'Bar2', ns='http://x')
    subclasses = {
        'Bar1': avm_class1,
        'Bar2': avm_class2,
    }
    interpreter = SWFInterpreter(
        swf, URL('http://localhost/foo.swf'), subclasses)

    def prim_print(args):
        assert len(args)

# Generated at 2022-06-22 09:37:40.323998
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0x07)
    _Multiname(0x09)
    _Multiname(0x0D)
    _Multiname(0x0E)



# Generated at 2022-06-22 09:37:44.719724
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    'Unit test for method __repr__ of class _Undefined'
    assert 'undefined' == repr(_Undefined())

undefined = _Undefined()

