

# Generated at 2022-06-22 09:32:42.999330
# Unit test for constructor of class _Multiname
def test__Multiname():
    kind = 0x07
    multiname = _Multiname(kind)
    assert multiname.kind == kind, '_Multiname constructor fail'


# Generated at 2022-06-22 09:32:44.361560
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'



# Generated at 2022-06-22 09:32:47.663323
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    avm_class = _AVMClass('_AVMClass_Object', None, None)
    obj = _AVMClass_Object(avm_class)
    assert obj.avm_class is avm_class



# Generated at 2022-06-22 09:32:49.800812
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

_undefined = _Undefined()



# Generated at 2022-06-22 09:32:51.846720
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    return _ScopeDict(None).__repr__() is not None
assert test__ScopeDict___repr__()



# Generated at 2022-06-22 09:32:57.216130
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert _Multiname(0).__repr__() == '[MULTINAME kind: 0x0]'
    assert _Multiname(1).__repr__() == '[MULTINAME kind: 0x1]'



# Generated at 2022-06-22 09:33:00.498705
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class_ = _AVMClass(None, 'DummyClass')
    assert repr(class_.make_object()) == 'DummyClass#%x' % id(class_.make_object())

# Generated at 2022-06-22 09:33:11.857969
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class SWFInterpreter_Mock(SWFInterpreter):
        def load_data(self, *args, **kwargs):
            return None
    spliter = SWFInterpreter_Mock(decompiler=None)

    class SWFDataStream_Mock(SWFDataStream):
        data = b'\x03\x00\x03\x00\x03\x00'  # Repeated int 3
    class SWFDefineBinaryData_Mock(SWFDefineBinaryData):
        code = None
        name = 'abc'
        stream = SWFDataStream_Mock()

    abc1 = SWFDefineBinaryData_Mock()
    abc2 = SWFDefineBinaryData_Mock()

# Generated at 2022-06-22 09:33:23.802318
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from io import StringIO
    out = StringIO()
    def callback(a, b):
        if b == 0:
            raise ZeroDivisionError()
        out.write(compat_str(a / b))
        return undefined
    swfinterpreter = SWFInterpreter()
    swfinterpreter.constant_strings.append('log')
    swfinterpreter.constant_strings.append('trace')
    swfinterpreter.constant_strings.append('data')
    swfinterpreter.constant_strings.append('toString')
    swfinterpreter.constant_strings.append('slice')
    swfinterpreter.constant_strings.append('length')
    swfinterpreter.constant_strings.append('url')


# Generated at 2022-06-22 09:33:27.998535
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert eval(repr(_ScopeDict(_AVMClass_Object(None)))) == {}
    assert eval(repr(_ScopeDict(_AVMClass_Object(None), {'a': 1}))) == {'a': 1}



# Generated at 2022-06-22 09:35:04.130911
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    u = _Undefined()
    assert None != u
    assert 0 == hash(u)
    assert '' != str(u)
undefined = _Undefined()
Null = _Undefined()



# Generated at 2022-06-22 09:35:14.122508
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class_ = _AVMClass('', '')
    methods_ = {
        '_constructor': 0,
        'foo': 1,
        'bar': 2,
    }
    class_.register_methods(methods_)
    actual_method_names = class_.method_names
    expected_method_names = methods_
    assert actual_method_names == expected_method_names, (
        'Got %s, expected %s' % (
            actual_method_names, expected_method_names))
    actual_method_idxs = class_.method_idxs
    expected_method_idxs = dict(
        (idx, name)
        for name, idx in methods_.items())

# Generated at 2022-06-22 09:35:19.491822
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _FakeClass(object):
        name = '_FakeClass'
    scope = _ScopeDict(_FakeClass())
    scope[1] = 2
    scope[3] = 4
    assert repr(scope) == "_FakeClass__Scope({1: 2, 3: 4})"



# Generated at 2022-06-22 09:35:21.062243
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
    assert not bool(_Undefined())
    assert bool(True)

UNDEFINED = _Undefined()



# Generated at 2022-06-22 09:35:32.299171
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io
    import time
    import datetime
    from ..utils import (
        parse_age_limit, update_url_query, unescapeHTML, int_or_none,
        xpath_text, ExtractorError, unified_strdate)
    from ..compat import (
        compat_str, compat_urlparse, compat_urllib_parse_unquote)
    from ..common import InfoExtractor
    from ..extractor import YoutubeIE
    from .common import (
        FileDownloader, FileCache, limit_length)
    from .test_download import (
        _test_download, _test_download_http_scheme,
        _test_download_https_scheme)


# Generated at 2022-06-22 09:35:36.313443
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class _MyAvmClass(object):
        name = b'flash.display::Sprite'
    obj = _AVMClass_Object(_MyAvmClass())
    assert obj.__repr__() == 'flash.display::Sprite#%x' % id(obj)
    del obj



# Generated at 2022-06-22 09:35:39.435405
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    multiname = _Multiname(0x07)
    # Check the initalization
    assert (multiname.kind) == 0x07
    
    # Check the output of method __repr__
    assert (str(multiname) == "[MULTINAME kind: 0x7]")


# Generated at 2022-06-22 09:35:42.308429
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    inst = _Undefined()
    print(repr(inst))
    assert repr(inst).endswith('_Undefined')
UNDEFINED = _Undefined()



# Generated at 2022-06-22 09:35:45.653498
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() == _Undefined()  # Test __eq__()
    assert not _Undefined()  # Test __bool__()
test__Undefined()



# Generated at 2022-06-22 09:35:54.537039
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    # Testing method __repr__ of class _ScopeDict
    # This also tests method __init__
    avm_class = _AVMClass('A', None, None)
    scope_dict = _ScopeDict(avm_class)
    assert_equal(repr(scope_dict), 'A__Scope({})')
    scope_dict['a'] = 'avalue'
    assert_equal(repr(scope_dict), "A__Scope({'a': 'avalue'})")
    assert_equal(scope_dict.avm_class, avm_class)



# Generated at 2022-06-22 09:37:27.034442
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    method_names_updated = {'1': '2', '3': '4'}
    method_idxs_updated = {'1': '3', '4': '5'}
    class_stub = _AVMClass('1', '2')
    class_stub.method_names = {}
    class_stub.method_idxs = {}
    class_stub.register_methods({'1': '2', '3': '4'})
    assert class_stub.method_names == method_names_updated, \
    'Method register_methods of class _AVMClass is broken'
    assert class_stub.method_idxs == method_idxs_updated, \
    'Method register_methods of class _AVMClass is broken'

# Generated at 2022-06-22 09:37:38.379344
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import SWFInterpreter
    from .SWFTags import DoABC, SWF
    from ...compat import compat_chr

    with open(get_test_file_path('swf/as3_spec.swf'), 'rb') as f:
        swf_data = f.read()
    swf = SWF(BytesIO(swf_data), swf_data)

    assert swf.file_version == 9
    assert swf.frame_size.xmin == 0
    assert swf.frame_size.xmax == 600
    assert swf.frame_size.ymin == 0
    assert swf.frame_size.ymax == 600
    assert swf.frame_rate == 15
    assert swf.frame_count == 1
    assert len(swf.tags) == 5


# Generated at 2022-06-22 09:37:50.053873
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf.components import SWFInterpreter
    from .swf.components import SWFInfo
    from .swf.components import SWFString
    from .swf.components import SWFDoAction
    from .swf.components import SWFTag
    from .swf.components import SWFSpriteItem
    from .swf.components import SWFMetadata
    from .swf.components import SWFDisplayItem
    from .swf.components import SWFButtonItem
    from .swf.components import SWFObjectItem
    from .swf.components import SWFShapeItem
    from .swf.components import SWFTextItem
    from .swf.components import SWFShowFrame
    from .swf.components import SWFPlaceObject2

# Generated at 2022-06-22 09:37:53.985417
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class TestAVMClass(object):
        name = 'TestAvmClass'
    scopedict = _ScopeDict(TestAVMClass())
    assert str(scopedict) == 'TestAvmClass__Scope({})'
del test__ScopeDict  # noqa



# Generated at 2022-06-22 09:37:55.898774
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    print("%s _Undefined.__hash__(): %s" % (
        _Undefined(),
        hash(_Undefined())))

# Generated at 2022-06-22 09:37:57.161161
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


# Generated at 2022-06-22 09:38:05.134203
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x07).kind == 0x07
    assert _Multiname(0x0D).kind == 0x0D
    assert _Multiname(0x0F).kind == 0x0F
    assert str(_Multiname(0x07)) == '[MULTINAME kind: 0x07]'
    assert str(_Multiname(0x0D)) == '[MULTINAME kind: 0x0d]'
    assert str(_Multiname(0x0F)) == '[MULTINAME kind: 0x0f]'



# Generated at 2022-06-22 09:38:07.441395
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    self = _Undefined()
    assert self.__bool__() == False



# Generated at 2022-06-22 09:38:10.668368
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() == _Undefined()
    assert str(_Undefined()) == 'undefined'
    assert hash(_Undefined()) == 0
    assert not _Undefined()
    assert bool(_Undefined()) == False

Undefined = _Undefined()



# Generated at 2022-06-22 09:38:12.820670
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    multiname = _Multiname(0)
    assert repr(multiname) == '[MULTINAME kind: 0x0]'

