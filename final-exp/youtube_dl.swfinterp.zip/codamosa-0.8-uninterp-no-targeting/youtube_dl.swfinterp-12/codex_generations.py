

# Generated at 2022-06-22 09:33:00.443405
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import sys
    for version, tag_types, actions in (
            (5, {}, {0x96: ActionPush}),
            (6, {}, {0x96: ActionPush}),
            (7, {}, {0x96: ActionPush}),
            (8, {}, {0x96: ActionPush}),
            (9, {}, {0x96: ActionPush}),
            (10, {}, {0x96: ActionPush}),
            (11, {}, {0x96: ActionPush}),
            (12, {}, {0x96: ActionPush})):
        swf = bytes()
        swf_version = version
        swf += compat_struct_pack('<b3s', swf_version, bytes(3))
        swf += compat_struct_pack('<b', 0)

# Generated at 2022-06-22 09:33:02.820876
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    m = _Multiname(0x42)
    print(repr(m))
    assert repr(m) == '[MULTINAME kind: 0x42]'



# Generated at 2022-06-22 09:33:10.609872
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from yaml import load

    from .codegen import (
        CodeGenerator,
        generate_code_from_pyfunction,
    )

    a = _AVMClass('A')
    assert isinstance(a.make_object(), _AVMClass_Object)
    assert a.make_object().avm_class is a

    cg = CodeGenerator()
    generate_code_from_pyfunction(
        cg,
        a,
        'foo',
        'a',
        load('''
            - return: 'Hello world'
            - return: 'Goodbye world'
        '''),
    )
    cg.add_to_pool('A')
    mf = cg.make_method_factory(2)
    a.methods[2] = mf
    a.method_

# Generated at 2022-06-22 09:33:16.389414
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    scope_dict = _ScopeDict(object())
    scope_dict['foo'] = 'bar'
    assert repr(scope_dict) == '<class \'object\'>__Scope({\'foo\': \'bar\'})', repr(scope_dict)



# Generated at 2022-06-22 09:33:17.923219
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    undefined = _Undefined()
    assert not undefined


# Generated at 2022-06-22 09:33:22.073884
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_name = 'Object'
    assert _AVMClass_Object(_AVMClass(class_name)).avm_class.name == class_name
    class_name = 'Object_another'
    assert _AVMClass_Object(_AVMClass(class_name)).avm_class.name == class_name


# Generated at 2022-06-22 09:33:26.210841
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    obj = _AVMClass_Object(_AVMClass('Test'))
    assert repr(obj) == 'Test#%x' % id(obj)



# Generated at 2022-06-22 09:33:31.551976
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .swfdec import AVMClass
    class_under_test = _AVMClass_Object(AVMClass(None, None, None, None, None, None, None, None, None))
    assert class_under_test.__repr__() == '<unknown>#%x' % id(class_under_test)


# Generated at 2022-06-22 09:33:33.837681
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x09) == eval(repr(_Multiname(0x09)))
test__Multiname()



# Generated at 2022-06-22 09:33:40.056717
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    methods = {'foo': 1, 'bar': 2}
    a = _AVMClass('a', 'b', {})
    b = _AVMClass('b', 'b', {})
    b.register_methods(methods)
    assert b.method_names == methods
    assert b.method_idxs == dict(
        (idx, name) for name, idx in methods.items())
    a.register_methods(methods)
    assert a.method_names == methods
    assert a.method_idxs == dict(
        (idx, name) for name, idx in methods.items())



# Generated at 2022-06-22 09:34:42.388475
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    from .bitstream import BitStreamReader
    from .exceptions import PyAMFError
    from .tags import (
        GetUrl2,
        ActionDefineFunction,
    )

    def test_method_decode(self, stack):
        stack.append('!')

    class ActionDefineFunction_hello(ActionDefineFunction):
        def __init__(self):
            self.name = 'hello'

        def decode(self, stack):
            super(ActionDefineFunction_hello, self).decode(stack)
            self.avm_class.register_methods({
                self.name: self.method_idx,
            })

    # dummy tags needed to decode ActionDefineFunction

# Generated at 2022-06-22 09:34:51.513734
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(1, 'Test')
    assert c.name == 'Test'
    assert not c.method_names
    assert not c.method_idxs
    assert not c.methods
    assert not c.method_pyfunctions
    assert not c.static_properties
    assert c.variables == _ScopeDict(c)
    assert not c.constants

    c.register_methods({
        'toString': 1,
        'push': 2
    })
    assert c.method_names == {
        'toString': 1,
        'push': 2
    }
    assert c.method_idxs == {
        1: 'toString',
        2: 'push'
    }



# Generated at 2022-06-22 09:34:53.584510
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) is False
    assert _Undefined().__nonzero__() is False


_undefined = _Undefined()



# Generated at 2022-06-22 09:34:55.741309
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'



# Generated at 2022-06-22 09:34:57.649827
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    a = _AVMClass_Object(None)
    assert repr(a) == 'None#%x' % id(a)



# Generated at 2022-06-22 09:34:59.292272
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert 'undefined' == str(_Undefined())



# Generated at 2022-06-22 09:35:01.270095
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter()
    assert interpreter.constant_string_index('player.swf') == 4
    assert interpreter.constant_string_index('player.swf') == 4



# Generated at 2022-06-22 09:35:08.264130
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    import unittest

    class _AVMClass_make_object_TestCase(unittest.TestCase):
        def test__default(self):
            avm_class = _AVMClass(None, None)
            obj = avm_class.make_object()
            self.assertEqual(obj.avm_class, avm_class)
            self.assertEqual(repr(obj), 'None#%x' % id(obj))

    suite = unittest.TestSuite()
    suite.addTest(_AVMClass_make_object_TestCase('test__default'))
    return suite



# Generated at 2022-06-22 09:35:13.884589
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class _AVMClass_Object(object):
        name = '_AVMClass_Object'

    test_instance = _ScopeDict(_AVMClass_Object())
    assert repr(test_instance) == '_AVMClass_Object__Scope({})'
    test_instance[0] = 1
    assert repr(test_instance) == '_AVMClass_Object__Scope({0: 1})'



# Generated at 2022-06-22 09:35:16.530341
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    assert _AVMClass('foo').make_object().avm_class.name == 'foo'


# Generated at 2022-06-22 09:36:20.932329
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-22 09:36:31.226609
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_file = io.BytesIO()
    test_file.write(struct.pack('<I', 0x534C5600))
    test_file.write(struct.pack('<I', 0x4F4E4552))
    test_file.write(struct.pack('<II', 0, 0))
    test_file.write(struct.pack('<II', 0, 0))
    test_file.write(struct.pack('<I', 1))
    test_file.write(struct.pack('<I', 0))
    test_file.write(struct.pack('<I', 0))
    test_file.write(struct.pack('<I', 0))
    test_file.write(struct.pack('<I', 0))
    test_file.write(struct.pack('<II', 0, 0))

# Generated at 2022-06-22 09:36:34.013896
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(_AVMClass('Foo'))) == 'Foo#%x' % (id(_AVMClass_Object(_AVMClass('Foo'))),)



# Generated at 2022-06-22 09:36:45.363099
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .SWF import SWF as _SWF

    swf = _SWF(open(os.path.join('tests', 'swfs', 'rtmptest.swf'), 'rb'))
    swf.parse_tags(convert_functions=False)
    si = SWFInterpreter(swf)

    class _AVMClass:
        def __init__(self, name, variables, static_properties):
            self.name = name
            self.variables = variables
            self.static_properties = static_properties
            self.method_names = []
            self.method_pyfunctions = {}

    class _AVMClass_Object:
        def __init__(self, avm_class):
            self.avm_class = avm_class
            self.props = {}


# Generated at 2022-06-22 09:36:54.396988
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():

    # Mock up a SWFInterpreter instance
    si = mock.Mock(spec=[
        'constant_strings',
        'multinames',
        'extract_function'])
    si.multinames = [None] * 17
    si.constant_strings = [None] * 5
    si.constant_strings[0] = 'trace'
    si.multinames[1] = 'String'
    si.multinames[2] = 'join'
    si.multinames[3] = si.multinames[4] = si.multinames[5] = si.multinames[6] = si.multinames[8] = '0'
    si.multinames[7] = 'length'
    si.multinames[9] = si.multinames[11]

# Generated at 2022-06-22 09:37:01.458547
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert not "__repr__" in dir(_AVMClass_Object)
    class _AVMClassMock_Object(object):
        def __init__(self, name):
            self.name = name
    result = _AVMClass_Object(_AVMClassMock_Object('a')).__repr__()
    assert result == 'a#%x' % id(_AVMClass_Object(_AVMClassMock_Object('a'))), result



# Generated at 2022-06-22 09:37:11.532672
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    UINT29_MAX = 0x1FFFFFFF

    class Multiname(object):
        def __init__(self, name, kind):
            self.name = name
            self.kind = kind

    class Multiname_QName(Multiname):
        pass

    class Multiname_Multiname(Multiname):
        pass

    class QName(object):
        def __init__(self, name, kind):
            self.name = name
            self.kind = kind

    class _AVMObject(object):
        def __init__(self, avm_class):
            self.avm_class = avm_class
            self.properties = {}

        def __getitem__(self, key):
            return self.properties[key]


# Generated at 2022-06-22 09:37:13.756180
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    myclass = _AVMClass('test', None)
    inst = myclass.make_object()
    assert inst.avm_class is myclass

# Generated at 2022-06-22 09:37:22.913043
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .flash_rl_actions import _FlashRlActions
    from .flash_rl_types import _FlashRlTypes
    from .flash_rl_abcs import _FlashRlAbcs
    from .flash_rl_abc_tags import _FlashRlAbcTags
    from .flash_rl_abc_tag_types import _FlashRlAbcTagTypes
    from .flash_rl_abc_tag_names import _FlashRlAbcTagNames
    from .flash_rl_abc_bytecode_ops import _FlashRlAbcBytecodeOps
    from .flash_rl_abc_bytecode_tags import _FlashRlAbcBytecodeTags
    from .flash_rl_swf_tags import _FlashRlSwfTags
    from .flash_rl_swf_tag_types import _FlashRlSwf

# Generated at 2022-06-22 09:37:30.057353
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass('foo', 'bar')
    avm_class.register_methods({
        u'baz': 1,
    })
    assert avm_class.method_names == {
        u'baz': 1,
    }
    assert avm_class.method_idxs == {
        1: u'baz',
    }


# An AVM2 object that is not a builtin

# Generated at 2022-06-22 09:38:34.839526
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    name = _Multiname(kind=42)
    assert repr(name) == '[MULTINAME kind: 0x2a]'



# Generated at 2022-06-22 09:38:44.925682
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # This is the main test of the whole module
    s = open(os.path.join(HERE, 'flashlib.swf'), 'rb').read()
    interpreter = SWFInterpreter(s)
    interpreter.extract_functions()

    # Verify extracted values
    assert interpreter.avm_classes['NetConnection'].constructor_signature == \
        ['Object']
    assert interpreter.avm_classes['NetConnection'].static_properties[
        'CONNECT_SUCCESS'] == 'NetConnection.Connect.Success'
    assert interpreter.avm_classes['NetConnection.prototype'].method_signatures[
        'connect'] == 'String'
    assert interpreter.avm_classes['NetConnection'].method_signatures[
        'call'] == 'Object'


# Generated at 2022-06-22 09:38:51.561185
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    m = _AVMClass('foo', 0)
    assert len(m.method_names) == 0
    assert len(m.method_idxs) == 0
    m.register_methods({'a': 1, 'b': 2})
    assert len(m.method_names) == 2
    assert len(m.method_idxs) == 2
    assert m.method_names['a'] == 1
    assert m.method_names['b'] == 2
    assert m.method_idxs[1] == 'a'
    assert m.method_idxs[2] == 'b'
# Test for class _AVMClass

# Generated at 2022-06-22 09:38:59.802262
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls1 = _AVMClass('TestClass', {
        'method1': 1,
        'method2': 2,
    })
    assert cls1.static_properties == {}
    assert cls1.method_names == {
        'method1': 1,
        'method2': 2,
    }
    assert cls1.method_idxs == {
        1: 'method1',
        2: 'method2',
    }
    assert isinstance(cls1.variables, _ScopeDict)
    assert isinstance(cls1.variables.avm_class, _AVMClass)
    assert cls1.variables.avm_class.name == 'TestClass'
    assert cls1.constants == {}


# Generated at 2022-06-22 09:39:04.580567
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(0, 'foo')
    c.register_methods({'bar': 0, 'quux': 8, 'baz': 3})
    assert c.method_names == {'bar': 0, 'quux': 8, 'baz': 3}
    assert c.method_idxs == {0: 'bar', 8: 'quux', 3: 'baz'}



# Generated at 2022-06-22 09:39:08.232118
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass(name_idx=0, name="??")
    obj.register_methods({})
    obj.method_names.update({})
    obj.method_idxs.update({})
    assert repr(obj) == '_AVMClass(??)'


# Generated at 2022-06-22 09:39:18.217012
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter()

    # test to read constant pool
    assert swf.constant_intpool == [0, 1, 2]
    assert swf.constant_uintpool == [0, 1, 2]
    assert swf.constant_doublepool == [0.1, 0.2, 0.3]
    assert swf.constant_decimalpool == [decimal.Decimal(0.1), decimal.Decimal(0.2), decimal.Decimal(0.3)]
    assert swf.constant_namespacepool == [
        _Namespace(1, 0, None), _Namespace(2, 1, 'public'), _Namespace(3, 2, 'flash/display')
    ]

# Generated at 2022-06-22 09:39:23.788348
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()

    def test_extract_function(mname, swf_data, native_code=None,
                              min_version=9):
        if native_code is None:
            native_code = mname
        test_swf = TestSWFInterpreter(swf_data, interpreter, min_version)
        class_name, method_name = mname.split('.')
        avm_class = getattr(test_swf, class_name)
        func = interpreter.extract_function(avm_class, method_name)

        # Test that the extracted function has correct number of arguments,
        # and test that all argument names are correct and have correct
        # default values
        code = inspect.getsource(func)

# Generated at 2022-06-22 09:39:31.708126
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(None, 'foo')
    avm_class.register_methods({'foo': 1, 'bar': 3, 'baz': 2})
    expected_method_idxs = {1: 'foo', 2: 'baz', 3: 'bar'}
    assert avm_class.method_names == {'foo': 1, 'bar': 3, 'baz': 2}
    assert avm_class.method_idxs == expected_method_idxs
    avm_class.register_methods({'quux': 4})
    assert avm_class.method_names == {'foo': 1, 'bar': 3, 'baz': 2, 'quux': 4}

# Generated at 2022-06-22 09:39:37.642622
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(None)
    assert repr(obj) == '[MULTINAME kind: 0x0]'
    assert obj._Multiname__repr__() == '[MULTINAME kind: 0x0]'

