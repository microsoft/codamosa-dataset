

# Generated at 2022-06-22 09:33:25.111790
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    assert _AVMClass(0, '', {}).__dict__ == {
        'name_idx': 0,
        'name': '',
        'method_names': {},
        'method_idxs': {},
        'methods': {},
        'method_pyfunctions': {},
        'static_properties': {},
        'variables': _AVMClass('', {}).make_object().variables,
        'constants': {},
    }

# Generated at 2022-06-22 09:33:26.210579
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

# Generated at 2022-06-22 09:33:27.366905
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(Undefined) == 0


# Generated at 2022-06-22 09:33:38.655709
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    name_idx = 1
    name = 'foo'
    static_properties = {}

    class ExpectedClass(object):
        pass

    expected = ExpectedClass()
    expected.name = name
    expected.method_names = {}
    expected.method_idxs = {}
    expected.methods = {}
    expected.method_pyfunctions = {}
    expected.static_properties = static_properties

    ExpectedScope = ExpectedClass()
    class ExpectedScope(object):
        avm_class = expected

    expected.variables = ExpectedScope()
    expected.constants = {}

    result = _AVMClass(name_idx, name, static_properties)
    assert repr(result) == repr(expected)


# Generated at 2022-06-22 09:33:40.691017
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    x = _ScopeDict(None)
    x.update({1: 2})
    repr(x)



# Generated at 2022-06-22 09:33:47.209125
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class Foo():
        name = 'Foo'
    assert 'Foo#' in repr(_AVMClass_Object(Foo()))

# Construct the superclass of the class with the specified name in the specified
# library.  The superclass name is looked up by appending '$' to the specified
# name, and the class is looked up by name in the specified library.  The
# superclass class that is found is used as the superclass in the constructor
# of a new class with the specified name, which is returned.

# Generated at 2022-06-22 09:33:52.109866
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    obj = _ScopeDict('abc')
    assert obj.__repr__() == 'abc__Scope({})'
    obj['a'] = 1
    obj['b'] = 2
    assert obj.__repr__() == "abc__Scope({'a': 1, 'b': 2})"
test__ScopeDict___repr__()



# Generated at 2022-06-22 09:33:53.250491
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    SWFInterpreter()


# Generated at 2022-06-22 09:33:56.211421
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _DummyAVMClass(object):
        name = 'Dummy'
    assert repr(
        _ScopeDict(_DummyAVMClass())) == 'Dummy__Scope({})'



# Generated at 2022-06-22 09:34:05.026376
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass('test', 'test')
    c.register_methods({'a': 0, 'b': 1})
    if c.method_names != {'a': 0, 'b': 1}:
        return False
    if c.method_idxs != {0: 'a', 1: 'b'}:
        return False
    return True
# test__AVMClass_register_methods()

    def get_method_name(self, idx):
        if idx in self.method_idxs:
            return self.method_idxs[idx]
        else:
            return 'unnamed#%d' % idx

# Generated at 2022-06-22 09:34:57.090543
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
undefined = _Undefined()



# Generated at 2022-06-22 09:35:05.477659
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    import unittest
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO
    class _AVMClass_Test(_unittest.TestCase):
        class MockPyClass(object):
            def __init__(self, name):
                self.__name__ = name
        def runTest(self):
            from .swfdecompiler import _AVMClass
            
            c = _AVMClass(0, 'FooClass')
            c.register_methods({
                'Method_1': 0x0000,
                'Method_2': 0x0001,
            })
            self.assertEqual(c.name_idx, 0)
            self.assertEqual(c.name, 'FooClass')
            self

# Generated at 2022-06-22 09:35:07.745804
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(1)) == '[MULTINAME kind: 0x1]'

# End of unit test for constructor of class _Multiname



# Generated at 2022-06-22 09:35:08.674483
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    return str(_Undefined())



# Generated at 2022-06-22 09:35:10.003042
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    b = _Undefined()
    assert hash(b) == 0
Undefined = _Undefined()



# Generated at 2022-06-22 09:35:10.784297
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    _AVMClass(1, 'Object')



# Generated at 2022-06-22 09:35:14.028191
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert repr(
        _AVMClass_Object(_AVMClass.by_name['flash.display::MovieClip'])) == (
        'flash.display::MovieClip#' + hex(id(None)))



# Generated at 2022-06-22 09:35:18.368103
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    c = _AVMClass('foo')
    o = _AVMClass_Object(c)
    assert o.avm_class == c
    assert repr(o) == '_AVMClass:foo#%x' % id(o)



# Generated at 2022-06-22 09:35:26.018920
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Test a simple class with a single method and no attributes
    from .utils import find_class_by_name
    from .debug import dump_constant_pool, dump_method_body
    from .test_swf_extract import TEST_FILE

    with open(TEST_FILE, 'rb') as f:
        swf = SWFInterpreter(f)
        # Dump debug information
        # print(dump_constant_pool(swf))
        # print(dump_method_body(swf, 'test_SWFInterpreter_extract_class'))
        # Get the name of the method to test
        avm_class = find_class_by_name(swf,
            'test_SWFInterpreter_extract_class')

# Generated at 2022-06-22 09:35:36.252353
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

    undef = _Undefined()
    assert hash(undef) == hash(undef)
    assert hash(undef) == 0


Undefined = _Undefined()


_CONSTANTKIND_to_pyobject = {
    0: None,
    1: False,
    2: True,
    3: Undefined,
    4: float('nan'),
    5: float('inf'),
    6: float('-inf'),
    7: -1,
}


# Generated at 2022-06-22 09:36:43.848159
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = open(sys.argv[1], 'rb')
    swfdata = swf.read()
    swf.close()
    swfi = SWFInterpreter(swfdata)
    print(swfi.avm_class.static_properties)
    print(swfi.avm_class.static_method_names)
    avm_prop_main = swfi.avm_class.static_properties['main']
    assert isinstance(avm_prop_main, _AVMClass)
    print(avm_prop_main.method_names)

    # Test functions
    # Print the latest version of ParamArrayDemo.swf
    if False:
        avm_func_print = avm_prop_main.static_properties[
            'print']

# Generated at 2022-06-22 09:36:47.404001
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x1)) == '[MULTINAME kind: 0x1]'



# Generated at 2022-06-22 09:36:50.779561
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass(0, 'SomeClass')
    assert class_.name == 'SomeClass'
    assert class_.method_names == {}



# Generated at 2022-06-22 09:36:58.451286
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    file_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'data',
        'avm_1.swf')
    with open(file_path, 'rb') as swf_file:
        swf = SWF(swf_file)
        interpreter = SWFInterpreter(swf)
        assert interpreter.constant_strings[0] == 'Player'
        assert interpreter.constant_strings[1] == 'Player.getPlayer'
        assert interpreter.constant_strings[2] == 'PlayerVersion'
        assert interpreter.constant_strings[3] == 'PlayerVersion.version'
        assert interpreter.constant_strings[4] == 'PlayerVersion.getVersion'

        avm_class = interpreter.constant_avm_classes

# Generated at 2022-06-22 09:37:01.375932
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    c = AVMClass('foo', b'')
    o = _AVMClass_Object(c)
    assert o.avm_class == c



# Generated at 2022-06-22 09:37:11.027382
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(name_idx='name_idx', name='name', static_properties={'static_prop':'value'})
    assert avm_class.name_idx == 'name_idx'
    assert avm_class.name == 'name'
    assert avm_class.static_properties['static_prop'] == 'value'
    assert avm_class.variables == {}
    assert avm_class.method_names == {}
    assert avm_class.method_idxs == {}
    assert avm_class.methods == {}
    assert avm_class.method_pyfunctions == {}
    assert avm_class.constants == {}
    assert repr(avm_class) == "_AVMClass(name)"


# Generated at 2022-06-22 09:37:16.935436
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    test_scope = _ScopeDict('test')
    assert test_scope['foo'] is None
    test_scope['bar'] = 3
    assert test_scope['bar'] == 3
    str(test_scope)



# Generated at 2022-06-22 09:37:20.304309
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():


    # Testing _Undefined.__hash__ method
    # Ensure hashable and non-equal
    undefined1 = _Undefined()
    undefined2 = _Undefined()
    assert hash(undefined1) != hash(undefined2)
    assert undefined1 != undefined2


_undefined = _Undefined()



# Generated at 2022-06-22 09:37:22.853904
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(_AVMClass_Object).avm_class) == 'ItemInfo'
test__AVMClass_Object()



# Generated at 2022-06-22 09:37:25.809942
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(1)



# Generated at 2022-06-22 09:39:37.524352
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert not hash(_Undefined())
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'

_undefined = _Undefined()



# Generated at 2022-06-22 09:39:39.414692
# Unit test for constructor of class _Undefined
def test__Undefined():
    _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-22 09:39:42.542748
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    return _ScopeDict(
        _AVMClass_Object(_AVMClass_Object(None))).__repr__() == \
        'None__Scope({})'



# Generated at 2022-06-22 09:39:47.215607
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Apparently, there is no unit test for class SWFInterpreter,
    # and no unittest for method extract_function(self, avm_class, func_name)
    # of class SWFInterpreter.
    # Let's try to implement one.
    raise NotImplementedError


# Generated at 2022-06-22 09:39:49.360038
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
undefined = _Undefined()
Null = None  # Unit test for method __hash__ of class _Undefined

# Generated at 2022-06-22 09:39:56.248207
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(0x0E, 'Com')
    assert avm_class.name_idx == 0x0E
    assert avm_class.name == 'Com'
    assert avm_class.method_names == {}
    assert avm_class.method_idxs == {}
    assert avm_class.methods == {}
    assert avm_class.method_pyfunctions == {}
    assert avm_class.static_properties == {}
    assert avm_class.variables == {'avm_class': avm_class}
    assert avm_class.constants == {}


# Generated at 2022-06-22 09:40:01.847315
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    func_name = 'foo'
    interpreter = _SWFInterpreter()
    setattr(interpreter, 'spam', 'ham')
    interpreter.patch_function(fr.get_body(func_name))
    assert hasattr(interpreter, 'foo')
    assert hasattr(interpreter.foo, '__closure__')
    assert len(interpreter.foo.__closure__) == 1
    assert interpreter.foo.__closure__[0].cell_contents == 'ham'


# Generated at 2022-06-22 09:40:03.952754
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'
_undefined = _Undefined()



# Generated at 2022-06-22 09:40:14.779688
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    # Test the creation of a class
    obj = _AVMClass(1234, 'Test')
    assert obj.name_idx == 1234
    assert obj.name == 'Test'
    assert obj.method_names == {}
    assert obj.method_idxs == {}
    assert obj.methods == {}
    assert obj.method_pyfunctions == {}
    assert obj.static_properties == {}
    assert obj.variables == {}
    assert obj.constants == {}

    # Test the creation of a class with static properties
    obj = _AVMClass(1234, 'Test', {'foo': 'bar'})
    assert obj.name_idx == 1234
    assert obj.name == 'Test'
    assert obj.method_names == {}
    assert obj.method_idxs == {}
    assert obj.method

# Generated at 2022-06-22 09:40:23.730842
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    a_class = _AVMClass(42, 'TestClass', {'hello': 'world'})
    assert a_class.__class__ is _AVMClass
    assert a_class.name_idx == 42
    assert a_class.name == 'TestClass'
    assert a_class.static_properties == {'hello': 'world'}
    assert a_class.method_pyfunctions == {}
    assert a_class.constants == {}
    assert isinstance(a_class.variables, _ScopeDict)
    assert a_class.variables.avm_class is a_class
