

# Generated at 2022-06-22 09:33:47.547219
# Unit test for constructor of class _Undefined
def test__Undefined():
    x = _Undefined()
    assert not bool(x)
    assert x == ''
    assert x != 'not empty'
    assert x != 'undefined'
    assert hash(x) == 0
    assert str(x) == 'undefined'
    assert repr(x) == 'undefined'


_undefined = _Undefined()



# Generated at 2022-06-22 09:33:58.216757
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from ytdl.swfinterp import SWFInterpreter

    si = SWFInterpreter()
    si.classes = {
        0: _AVMClass(
            variables={
                'Constant': True,
                'staticMethod': lambda x: compat_str(x * 3),
                'property': 42
            },
            static_properties={
                'staticProperty': 43
            },
            methods={
                'method': lambda x: x * 10,
                'methodThatReturnsArgument': lambda x: x,
            }
        )
    }
    cls = si.extract_class(0)

    cls = si.extract_class(0)
    assert isinstance(cls, _AVMClass)

    assert cls.variables
    assert cls.variables['Constant'] is True

# Generated at 2022-06-22 09:34:10.161255
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    from .utils import avm2_parse_code
    from .utils import avm2_decode_multiname
    c = _AVMClass(
        name_idx=3,
        name=avm2_decode_multiname(3),
        static_properties={
            b'x': None,
            b'y': None,
        })
    assert c.name_idx == 3
    assert c.name == 'Player', c
    method_names = {
        3: b'new',
        2: b'_constructor_',
    }
    c.register_methods(method_names)
    assert c.method_names == method_names
    assert c.method_idxs == dict((v, k) for k, v in method_names.items())

# Generated at 2022-06-22 09:34:17.728493
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(None, None)
    assert avm_class.method_idxs == {}
    assert avm_class.method_names == {}
    assert avm_class.methods == {}
    assert avm_class.static_properties == {}
    assert avm_class.variables == {}
    assert avm_class.constants == {}

    avm_class.register_methods({'foo': 0, 'bar': 1})
    assert avm_class.method_idxs == {0: 'foo', 1: 'bar'}
    assert avm_class.method_names == {'foo': 0, 'bar': 1}



# Generated at 2022-06-22 09:34:19.558188
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    return _AVMClass_Object(avm_class=None).__repr__()


# Generated at 2022-06-22 09:34:20.695722
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    assert True


# Generated at 2022-06-22 09:34:24.230284
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    avm_class = _AVMClass(
        name_idx=1,
        name='foo',
        static_properties={'bar': 1})
    assert repr(avm_class) == '_AVMClass(foo)'



# Generated at 2022-06-22 09:34:25.930524
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    # Constructor test: _Undefined()
    # Unit test for method __bool__ of class _Undefined
    assert not _Undefined()

# Generated at 2022-06-22 09:34:29.808453
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    instance1 = _AVMClass(0, "")
    assert repr(instance1) == "_AVMClass('')"

    instance2 = _AVMClass(0, "x")
    assert repr(instance2) == "_AVMClass('x')"

    instance3 = _AVMClass(0, "abc")
    assert repr(instance3) == "_AVMClass('abc')"



# Generated at 2022-06-22 09:34:31.934641
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
_Undefined = _Undefined()



# Generated at 2022-06-22 09:35:32.426618
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    return _Undefined()

# Generated at 2022-06-22 09:35:33.825896
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0)  # it works



# Generated at 2022-06-22 09:35:39.530057
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    a = _AVMClass(1, 'a')
    assert a.name_idx == 1
    assert a.name == 'a'
    assert a.method_names == {}
    assert a.methods == {}
    assert a.static_properties == {}
    assert isinstance(a.variables, _ScopeDict)
    assert a.variables.avm_class is a
    assert a.constants == {}
    assert repr(a) == '_AVMClass(a)'


# FIXME: This is not the actual float encoding

# Generated at 2022-06-22 09:35:45.203860
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    from pprint import pprint

    with open('test/canvas.swf', 'rb') as f:
        swf = f.read()
    interp = SWFInterpreter(swf)

    pprint(interp.methods)
    pprint(interp.constant_strings)
    pprint(interp.constant_namespaces)
    pprint(interp.constant_namespace_sets)
    pprint(interp.constant_multinames)

    print(interp.internal_classes[19].static_properties)
    print(interp.internal_classes[19].variables)
    print(interp.internal_classes[19].method_names)


# Generated at 2022-06-22 09:35:46.294058
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    obj = _AVMClass_Object(_AVMClass_Object)
    assert repr(obj) == '_AVMClass_Object#%x' % id(obj)



# Generated at 2022-06-22 09:35:48.396169
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    o = _Undefined()
    return o.__hash__() == 0, '___hash__()'

# Generated at 2022-06-22 09:35:55.079177
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class_object = _AVMClass(0, 'test').make_object()
    assert isinstance(class_object, _AVMClass_Object)
    assert isinstance(class_object.avm_class, _AVMClass)
    assert class_object.avm_class.name_idx == 0
    assert class_object.avm_class.name == 'test'



# Generated at 2022-06-22 09:36:01.933093
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    methods = {'a': 1, 'b': 2}
    expected_method_names = {'a': 1, 'b': 2}
    expected_method_idxs = {1: 'a', 2: 'b'}
    obj = _AVMClass('name', 'name', {})
    obj.register_methods(methods)
    assert obj.method_names == expected_method_names
    assert obj.method_idxs == expected_method_idxs



# Generated at 2022-06-22 09:36:09.429273
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import sys
    from .swftags import SWFTagDoABC, SWFTagLoaded
    from .swfdecompiler import decompile_tags

    abc_data = b'\x13\x04\x00\x00AAAA\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    abc_data += b'\x02\x00\x0A\x00\x00\x01\x00\x00\x00\x01\x00\x0A\x00\x00\x0B'
    abc_data += b'\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x01\x09\x00'

# Generated at 2022-06-22 09:36:12.026099
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() == _Undefined()


Undefined = _Undefined()



# Generated at 2022-06-22 09:38:33.369726
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .test import unit_test_assert_equal
    class_name = 'test__AVMClass_Object___repr__'
    avm_class = AVMClass(class_name)
    obj = _AVMClass_Object(avm_class)
    unit_test_assert_equal(repr(obj), '%s#%x' % (class_name, id(obj)))



# Generated at 2022-06-22 09:38:43.708105
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    mn = _Multiname(0x06)
    assert repr(mn) == '[MULTINAME kind: 0x6]'


_CONSTANT_TYPE_UTF8 = 0x01
_CONSTANT_TYPE_INT = 0x03
_CONSTANT_TYPE_UINT = 0x04
_CONSTANT_TYPE_DOUBLE = 0x06
_CONSTANT_TYPE_STRING = 0x08
_CONSTANT_TYPE_NAMESPACE = 0x09
_CONSTANT_TYPE_NAMESPACESET = 0x0a
_CONSTANT_TYPE_MULTINAME = 0x0d
_CONSTANT_TYPE_NAMESPACE_PACKAGE = 0x16
_CONSTANT_TYPE_NAMESPACE_PACKAGE_INTERNAL = 0x17


# Generated at 2022-06-22 09:38:47.518283
# Unit test for constructor of class _Multiname
def test__Multiname():
    from .utils import parse_fragment
    mn = parse_fragment('_Multiname(0x3)')
    assert mn.kind == 0x3, 'Parsing _Multiname failed'


# Generated at 2022-06-22 09:38:59.127190
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import StringIO
    f = StringIO.StringIO()

# Generated at 2022-06-22 09:39:01.516884
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    ac = _AVMClass(name_idx=None, name='asdf')
    assert ac.name_idx is None
    assert ac.name == 'asdf'
    assert isinstance(ac.variables, _ScopeDict)
    assert ac.constants == {}



# Generated at 2022-06-22 09:39:03.725906
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.patch_function(None, None)
    swf_interpreter.patch_function('', '')


# Generated at 2022-06-22 09:39:10.340677
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()
    method_name = 'test_patch_function_method'

# Generated at 2022-06-22 09:39:17.448734
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s = SWFInterpreter()
    assert s.op_codes[0] == 'bkpt'
    assert s.op_codes[1] == 'nop'
    assert s.op_codes[2] == 'throw'
    assert s.op_codes[3] == 'getsuper'
    assert s.op_codes[4] == 'setsuper'
    assert s.op_codes[5] == 'dxns'
    assert s.op_codes[6] == 'dxnslate'
    assert s.op_codes[7] == 'kill'
    assert s.op_codes[8] == 'label'


# Generated at 2022-06-22 09:39:18.342902
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-22 09:39:28.866114
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    """Test SWFInterpreter constructor"""
    from . import flash_proxy
    from . import as3_class
    from . import avm_method
    from .swf_tags import PlaceObject2Tag
    from .swf_tags import DefineSpriteTag

    swf_path = os.path.join(
        os.path.dirname(__file__), '..', '..', 'test', 'as3', 'flash',
    )
    swf_interpreter = SWFInterpreter.from_path(
        os.path.join(swf_path, 'avm2swf.swf'))
    dummy_parent_swf = DefineSpriteTag(id=-1)
    dummy_parent_swf.interpreter = swf_interpreter
    avm_class = swf_