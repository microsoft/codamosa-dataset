

# Generated at 2022-06-22 09:32:39.329720
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(0)) == '[MULTINAME kind: 0x0]'
    assert repr(_Multiname(0x1)) == '[MULTINAME kind: 0x1]'


_KNOWN_MULTINAME_KINDS = {
    0x07: 'QName',
    0x0d: 'RTQName',
    0x0f: 'RTQNameL',
    0x10: 'RTQNameLA',
    0x11: 'Multiname',
    0x12: 'MultinameL',
    0x13: 'MultinameLA',
}



# Generated at 2022-06-22 09:32:41.715904
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    _AVMClass_Object(object).__repr__()



# Generated at 2022-06-22 09:32:51.162907
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(kind=2)
    _Multiname(kind=3)


MULTINAME_QNAME = 7
MULTINAME_QNAME_A = 0x0d
MULTINAME_RTQNAME = 0x0f
MULTINAME_RTQNAME_A = 0x10
MULTINAME_RTQNAME_L = 0x11
MULTINAME_RTQNAME_LA = 0x12
MULTINAME_MULTINAME = 0x09
MULTINAME_MULTINAME_A = 0x0e
MULTINAME_MULTINAMEL = 0x1b
MULTINAME_MULTINAMEL_A = 0x1c



# Generated at 2022-06-22 09:32:55.966830
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    ins = SWFInterpreter(b'')
    assert ins.strings == ()
    assert ins.methods == ()
    assert ins.classes == ()
    assert ins.method_pyfunctions == {}
    assert ins.extract_function() is None
    assert ins.run_method() is None
    assert ins.extract_constant_string() is None
    assert ins.extract_method() is None
    assert ins.extract_class() is None


# Generated at 2022-06-22 09:33:00.021515
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0)) == '[MULTINAME kind: 0x0]'
    assert repr(_Multiname(0x12)) == '[MULTINAME kind: 0x12]'



# Generated at 2022-06-22 09:33:02.778074
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    a = _AVMClass_Object(None)
    a.avm_class = 'hello'
    assert repr(a) == "'hello'#%x" % id(a)



# Generated at 2022-06-22 09:33:07.148072
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    import unittest
    class Test(unittest.TestCase):
        def test_basic(self):
            scope = _ScopeDict(None)
            scope['TEST'] = 'test'
            self.assertEqual(repr(scope), 'None__Scope({\'TEST\': \'test\'})')
    unittest.main()


# Generated at 2022-06-22 09:33:13.305556
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .avm import AVMClass
    from .avm import AVMObject
    from .avm import AVMString

    assert repr(AVMObject()) == 'AVMObject#%x' % id(AVMObject())
    assert repr(AVMString('a')) == 'AVMString#%x' % id(AVMString('a'))
    assert repr(_AVMClass_Object(AVMClass('a'))) == 'AVMClass#%x' % id(AVMClass('a'))



# Generated at 2022-06-22 09:33:18.966090
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(
        name_idx='Test',
        name='ClassName',
        static_properties=dict(
            test='foo'))

    assert avm_class.name_idx == 'Test'
    assert avm_class.name == 'ClassName'
    assert avm_class.static_properties == dict(test='foo')



# Generated at 2022-06-22 09:33:26.314212
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    pass  # For now we use doctest


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.REPORT_ONLY_FIRST_FAILURE)

    # from .swfdecompiler import swfdecompile
    # for name, data in swfdecompile('tests/swf/test.swf'):
    #     print(name)
    #     for x in data['scripts']:
    #         print(x)
    #         s = SWFInterpreter(x)
    #         print(s.extract_function('text_field', 'text_field'))
    #         break

# Generated at 2022-06-22 09:34:33.590117
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    a = _AVMClass('Baz')
    o = _AVMClass_Object(a)
    assert repr(o).startswith('Baz'), repr(o)
# end test__AVMClass_Object



# Generated at 2022-06-22 09:34:41.252157
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    m = _Multiname(0x03)
    assert m.__repr__() == '[MULTINAME kind: 0x3]', m.__repr__()
    m = _Multiname(0x0D)
    assert m.__repr__() == '[MULTINAME kind: 0xd]', m.__repr__()
    m = _Multiname(0x0F)
    assert m.__repr__() == '[MULTINAME kind: 0xf]', m.__repr__()



# Generated at 2022-06-22 09:34:41.951929
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    pass

# Generated at 2022-06-22 09:34:43.132528
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(2)


# Generated at 2022-06-22 09:34:55.491174
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-22 09:35:05.981728
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Tests for the method extract_class of the class SWFInterpreter
    data = open(os.path.join(os.path.dirname(__file__), 'flash_player_24.swf'), 'rb').read()
    swf = SWFInterpreter(data)
    swf.extract_class()

    assert 'flash.display.MovieClip' in swf.avm_classes
    assert 'flash.display.Sprite' in swf.avm_classes

    assert 'MovieClip' in swf.avm_classes['flash.display.MovieClip'].method_names
    assert 'gotoAndStop' in swf.avm_classes['flash.display.MovieClip'].method_names


# Generated at 2022-06-22 09:35:14.314647
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    for filename in sorted(glob.glob(os.path.join(
            os.path.dirname(__file__), 'fixtures', 'test*.swf'))):
        with open(filename, 'rb') as swf_file:
            swf = SWFInterpreter(swf_file)
    assert swf
    print('Tested SWF file %s' % filename)

    # YouTube

# Generated at 2022-06-22 09:35:17.723301
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    assert SWFInterpreter.extract_function(
        None, None, None, None, None) is None

# Generated at 2022-06-22 09:35:26.152265
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(
        1, 'MovieClip',
        static_properties={'prototype': 'some_prototype'})
    assert c.methods == {}
    assert c.method_idxs == {}
    assert c.method_names == {}
    assert c.method_pyfunctions == {}
    assert c.static_properties == {
        'prototype': 'some_prototype'}
    assert c.variables == {'__proto__': 'some_prototype',
                           '__class__': c}
    assert c.constants == {}



# Generated at 2022-06-22 09:35:29.396681
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    # __repr__ of _Undefined must return 'undefined'
    assert str(_Undefined()) == 'undefined', \
        '__repr__ of _Undefined must return \'undefined\''
Undefined = _Undefined()



# Generated at 2022-06-22 09:38:49.600842
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    """
    >>> AVM = SWFInterpreter.fromfile('libavm_example.swf')
    >>> AVM.classes['MyClass']
    <libavm2.SWFInterpreter.interpreter_class Type of MyClass>
    """
    pass


# Generated at 2022-06-22 09:38:51.042601
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    '''
    # Test for method __repr__ of class _Undefined
    '''
    return
undefined = _Undefined()



# Generated at 2022-06-22 09:38:52.791592
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    """(_ScopeDict (class in avmscript)) no longer raises AttributeError."""
    _ScopeDict(None)
    return



# Generated at 2022-06-22 09:38:56.067540
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    class_ = _AVMClass(0, 'Foo')
    expected = '_AVMClass(Foo)'
    actual = repr(class_)
    assert actual == expected


# Generated at 2022-06-22 09:38:57.149003
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    obj = _Undefined()
    assert not obj


# Generated at 2022-06-22 09:39:03.114911
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter(None)
    assert swf_interpreter.classes == {}
    assert swf_interpreter.constant_strings == []
    assert swf_interpreter.method_bodies == []
    assert swf_interpreter.methods == []
    assert swf_interpreter.multinames == []
    assert swf_interpreter.strings == []
    assert swf_interpreter.traits == []


# Generated at 2022-06-22 09:39:07.322782
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    test_swf = load_fixture('test.swf')
    interpreter = SWFInterpreter(test_swf)
    func = interpreter.patch_function(
        interpreter.abc.abc_classes[0], 'entry')
    assert func('0') == '0'
    assert func('1') == '1'

# Generated at 2022-06-22 09:39:16.718997
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s = io.BytesIO(open(os.path.join(
        os.path.dirname(__file__),
        'baodie-swf/baodie-swf-code.swf'), 'rb').read())
    swf = SWF(s)
    for tag in swf.tags:
        if isinstance(tag, DoABC):
            abc_tag = tag
            break
    else:
        assert False
    interpreter = SWFInterpreter()
    interpreter.setup(abc_tag)

    assert interpreter.extract_function(StringClass, 'String')

# Generated at 2022-06-22 09:39:21.993169
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    test_class = _AVMClass(1, 'TestClass', {'test_prop': 42})
    assert test_class.name_idx == 1
    assert test_class.name == 'TestClass'
    assert test_class.static_properties['test_prop'] == 42

    assert repr(test_class) == "_AVMClass('TestClass')"



# Generated at 2022-06-22 09:39:26.685960
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    filename = 'tests/swf/test_abc.swf'
    with open(resolve_filename(filename), 'rb') as f:
        interpreter = SWFInterpreter(f)
        assert interpreter.swf_version == 18
        assert len(interpreter.constant_strings) == 20
        assert len(interpreter.constant_ints) == 2
        assert len(interpreter.constant_uints) == 1
        assert len(interpreter.constant_doubles) == 0
        assert len(interpreter.constant_namespaces) == 7
        assert len(interpreter.constant_namespace_sets) == 0
        assert len(interpreter.constant_multinames) == 20
        assert interpreter.constant_strings[0] == '*'