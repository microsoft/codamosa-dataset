

# Generated at 2022-06-22 09:33:59.557131
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert(_Undefined() == _Undefined())
_UNDEFINED = _Undefined()
NullClass = _AVMClass('(no name idx)', 'Null')
_builtin_classes[NullClass.name] = NullClass
NullClass.variables['prototype'] = NullClass
TrueClass = _AVMClass('(no name idx)', 'Boolean')
_builtin_classes[TrueClass.name] = TrueClass
TrueClass.variables['prototype'] = TrueClass
FalseClass = _AVMClass('(no name idx)', 'Boolean')
_builtin_classes[FalseClass.name] = FalseClass
FalseClass.variables['prototype'] = FalseClass



# Generated at 2022-06-22 09:34:04.641140
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    # We currently don't have a test for this method

    # This statement will raise a NameError if the method make_object is
    # not defined in class _AVMClass (issue #1)
    _AVMClass.make_object

# Generated at 2022-06-22 09:34:11.598247
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    import random
    for i in range(100):
        name = ''.join(
            random.choice(string.ascii_lowercase) for _ in range(4))
        class_ = _AVMClass(0, name)
        obj = class_.make_object()
        assert isinstance(obj, _AVMClass_Object)
        assert obj.avm_class is class_
        assert isinstance(class_.variables, _ScopeDict)
        assert class_.variables.avm_class is class_
test__AVMClass()



# Generated at 2022-06-22 09:34:12.886717
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) == False
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'


_undefined = _Undefined()


# Generated at 2022-06-22 09:34:20.570700
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class test__AVMClass_make_object_Class0(object):
        def __init__(self, name_idx, name, static_properties=None):
            self.name_idx = name_idx
            self.name = name
            self.method_names = {}
            self.method_idxs = {}
            self.methods = {}
            self.method_pyfunctions = {}
            self.static_properties = static_properties if static_properties else {}
            self.variables = _ScopeDict(self)
            self.constants = {}

    temp0 = None
    temp1 = None
    temp2 = None
    temp3 = None
    temp4 = None
    def temp5():
        return None

    def temp6():
        return None

    def temp7():
        return None


# Generated at 2022-06-22 09:34:24.445625
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    avm_class = AVMClass(name='TestClassName')
    obj = _AVMClass_Object(avm_class=avm_class)
    assert repr(obj) == 'TestClassName#%x' % id(obj)
    return True



# Generated at 2022-06-22 09:34:26.597893
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    obj = _Undefined()
    value = obj.__bool__()
    expected = False
    assert value == expected, 'Expected %r, got %r' % (expected, value)



# Generated at 2022-06-22 09:34:29.017245
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert repr(_ScopeDict(1)) == '1__Scope({})'



# Generated at 2022-06-22 09:34:32.111556
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    _AVMClass('Hello', 'Hello')


_AVMClasses = {}
_AVMClasses_idx = {}



# Generated at 2022-06-22 09:34:37.844468
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert str(
        _AVMClass_Object(_AVMClass(0, 'xy', None, None, None))) == 'xy#504f2e8'

_AVMClass = collections.namedtuple(
    '_AVMClass', [
        'index', 'name', 'super_name', 'prototype_name', 'default_constructor'])



# Generated at 2022-06-22 09:36:58.319966
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    data = open(os.path.join(os.path.dirname(__file__),
                             'Flash', 'goforref.swf'), 'rb').read()
    interp = SWFInterpreter(data)

    # Test loading class
    assert 'MovieClip' in interp.avm_classes
    assert 'Shape' in interp.avm_classes

    # Test loading instance
    assert interp.avm_classes['MovieClip'].num_instances == 4

    # Test multinames
    assert interp.multinames[0].name == 'movieclip'
    assert interp.multinames[1].name == '__proto__'
    assert interp.multinames[2].name == '__cinit__'

# Generated at 2022-06-22 09:36:59.782816
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) == False
test__Undefined()



# Generated at 2022-06-22 09:37:04.842895
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class AVMClass(object):
        pass
    avm_class = AVMClass()
    avm_class.name = 'SOME_CLASS'
    d = _ScopeDict(avm_class)
    assert d == {}
    assert d.avm_class is avm_class
    assert d.__dict__ == {}



# Generated at 2022-06-22 09:37:06.240798
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    _ScopeDict(_ScopeDict.__init__.__self__)



# Generated at 2022-06-22 09:37:13.843599
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interp = SWFInterpreter()
    interp.extract_class('''
        function A() {
            var a;
            var b = -1;
            var c = 1;
            delete a;
            delete b;
            delete c;
            a = b + c;
            for (var i=0; i<10; i++) {
                a += b+i;
            }
            return a;
        }
        
        var v = A();
    ''')


# Generated at 2022-06-22 09:37:21.378125
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    fname = 'SWFC/1jcvYIneNhPfZwMA.swf'
    fsize = 1048576
    fdata = get_testdata_file(fname, [fsize])
    swf = SWF(fdata)
    assert swf.header.file_length == fsize

    swf_interpreter = SWFInterpreter(swf)
    swf_interpreter.extract_function('a', 'AVM1Data')
    print('test_SWFInterpreter_extract_function passed')

test_SWFInterpreter_extract_function()


# Generated at 2022-06-22 09:37:23.276609
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():  # pylint:disable=unused-variable
    return _Multiname(0x01)


# Generated at 2022-06-22 09:37:26.002741
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert _Undefined() is not True


# Generated at 2022-06-22 09:37:27.272201
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) is False



# Generated at 2022-06-22 09:37:31.261688
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    c = _AVMClass('Foo')
    c.name = 'C'
    res = _AVMClass_Object(c)
    assert res.avm_class == c

