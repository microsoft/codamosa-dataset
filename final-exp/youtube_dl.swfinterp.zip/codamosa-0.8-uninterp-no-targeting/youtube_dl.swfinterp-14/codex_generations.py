

# Generated at 2022-06-22 09:32:41.339993
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
# Unit tests end


_undefined = _Undefined()



# Generated at 2022-06-22 09:32:44.800783
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class_ = _AVMClass('MyClass', 3)
    obj = class_.make_object()
    assert isinstance(obj, _AVMClass_Object)
    assert obj.avm_class is class_

# Generated at 2022-06-22 09:32:48.909696
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert not _Undefined() == 0
    assert not _Undefined() == ''
    assert not _Undefined() == []
    assert not _Undefined() == {}
    assert not _Undefined() == None
    assert _Undefined() == _Undefined()
    assert {}[_Undefined()] == {}[_Undefined()]
    assert hash(_Undefined()) == hash(_Undefined())


# Generated at 2022-06-22 09:33:01.380217
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    """Unit test for SWFInterpreter.extract_class"""
    from flash_extract.utils import string2bytes
    from flash_extract.interpreter import SWFInterpreter
    from flash_extract.interpreter import _SWFClass
    # Example from BabyTV

# Generated at 2022-06-22 09:33:09.681150
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():

    SI = SWFInterpreter(None)

    # Simple function
    def f1(args):
        assert len(args) == 1
        arg = args[0]
        return arg + 1

    res = SI.patch_function(f1, [], [], [], [])
    assert res() == 2

    # Registers
    def f2(args):
        assert len(args) == 1
        arg = args[0]
        return arg + 1

    res = SI.patch_function(f2, [0], [], [], [])
    assert res() == 3

    # Parameter
    def f3(args):
        assert len(args) == 1
        arg = args[0]
        return arg + 1

    res = SI.patch_function(f3, [], [1], [], [])


# Generated at 2022-06-22 09:33:11.112503
# Unit test for constructor of class _Undefined
def test__Undefined():
    # TODO
    pass

Undefined = _Undefined()



# Generated at 2022-06-22 09:33:16.476694
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert len(SWFInterpreter.classes) == 0
    assert SWFInterpreter.classes['Object'] is ObjectClass

# Unit tests for function SWFInterpreter.extract_function

# Generated at 2022-06-22 09:33:18.017404
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(1).kind == 1



# Generated at 2022-06-22 09:33:26.621457
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = _open_test_swf()
    SWFInterpreter().extract_function(swf.classes[0], 'test_function')

# Generated at 2022-06-22 09:33:28.436545
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(kind=0x0f)



# Generated at 2022-06-22 09:34:25.817546
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() == _Undefined()
    assert hash(_Undefined()) == hash(_Undefined())

undefined = _Undefined()



# Generated at 2022-06-22 09:34:27.065528
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

_undefined = _Undefined()



# Generated at 2022-06-22 09:34:30.022811
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    u = _Undefined()
    assert len(set([u, u])) == 1



# Generated at 2022-06-22 09:34:34.566742
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class AVMClass(object):
        pass
    x = _ScopeDict(AVMClass("TestClass"))
    x[1] = 2
    assert repr(x) == 'TestClass__Scope({1: 2})'



# Generated at 2022-06-22 09:34:37.161992
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    # Fake class
    o = _ScopeDict(type('', (object,), {'name': 'fake_class'}))
    # Make sure that __setitem__ and __getitem__ work
    o['a'] = 1
    assert o['a'] == 1
    # Make sure that repr works
    assert repr(o).startswith('fake_class__Scope({')



# Generated at 2022-06-22 09:34:37.654952
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()



# Generated at 2022-06-22 09:34:45.011430
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = open(os.path.join(os.path.dirname(__file__), 'swf_example.swf'), 'rb').read()
    interpreter = SWFInterpreter(swf)

    # Test method SWFInterpreter.extract_function
    f = interpreter.extract_function(interpreter.avm_root_class, 'avm1_get_video_url')
    url = f([])
    assert url == 'http://example.com/test.mp4'
# Test method SWFInterpreter.extract_function of class SWFInterpreter

# Generated at 2022-06-22 09:34:50.473960
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    method_names = {'try': 0, 'except': 1}
    clas = _AVMClass(0, 'ClassName', static_properties = {'a': 1})
    clas.method_names = method_names
    assert clas.__repr__() == '_AVMClass(ClassName)'
    assert clas.method_names == method_names



# Generated at 2022-06-22 09:34:54.001637
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class Test_Object():
        pass
    Test_make_object = Test_Object()
    assert Test_make_object._AVMClass_method_names == {
        'Test_Object': 'Test_Object'
    }

# Generated at 2022-06-22 09:34:56.480215
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    test = _Multiname('kind')
    assert repr(test) == '[MULTINAME kind: 0xkind]'


# Generated at 2022-06-22 09:36:48.605792
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # pylint: disable=R0914
    i = SWFInterpreter()
    i.constant_double.append(0)
    i.constant_double.append(1)
    i.constant_double.append(2)

    count = SWFTypeCode.ui30
    doubles = [SWFTypeCode.double]
    strings = [SWFTypeCode.string]

    # pylint: disable=C0301
    # Function () { return arguments[0] + arguments[1]; }
    class_name = 'main.MyClass'
    method_name = 'add'
    method_flags = 0x08  # HAS_OPTIONAL
    method_params = [('a', count), ('b', count)]
    method_optionals = [('c', count), ('d', count)]
    method

# Generated at 2022-06-22 09:36:54.424190
# Unit test for constructor of class _Undefined
def test__Undefined():
    for i in [None, False, [], {}]:
        assert not i

    # Test that undef is not equal to anything
    assert not _Undefined()
    p = _Undefined()
    for i in [None, 1, 'hello', [1,2,3], {}, {'a':1}]:
        assert p != i
        assert not i == p
        assert not i is not p
        assert not i is p
        assert not p is i

    # Test that undef is not hashable
    try:
        hash(_Undefined())
        assert False
    except TypeError:
        pass

undefined = _Undefined()



# Generated at 2022-06-22 09:37:01.699013
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import sys
    if sys.version_info > (3, 0):
        from io import BytesIO, StringIO
    else:
        from StringIO import StringIO as BytesIO
    swf = BytesIO(open(__file__.replace('.py', '.swf'), 'rb').read())
    interpreter = SWFInterpreter(swf)
    assert interpreter.patch_function('fscommand', ['a', 'b']) == 'ab'
if __name__ == '__main__':
    test_SWFInterpreter_patch_function()

# Test SWF decoding as a whole, by extracting
# the signature decoding function and checking it
# against some test samples

# Generated at 2022-06-22 09:37:04.793697
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert _AVMClass(
        name_idx=0,
        name='foo',
        static_properties={},
    ).__repr__() == '_AVMClass(foo)'



# Generated at 2022-06-22 09:37:06.586507
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x0b)) == '[MULTINAME kind: 0x0b]'



# Generated at 2022-06-22 09:37:08.019455
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    obj = _Undefined()
    assert 0 == obj.__hash__()
    return True


# Generated at 2022-06-22 09:37:09.787459
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    scope = _ScopeDict(None)
    scope['abc'] = 123
    assert repr(scope) == "{'abc': 123}"


# Generated at 2022-06-22 09:37:21.349226
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()
    class AVMClass(object):
        method_names = set()
        method_pyfunctions = {}
        static_properties = {}
        variables = {}
    avm_class = AVMClass()

    def separator():
        return '---'

    def func1(args):
        print('Hello, world!')
        print(separator())
        return 'foo'

    def func2(args):
        print('Hello, world!')
        print(separator())
        return 'bar'

    avm_class.method_names.add('func1')
    avm_class.method_names.add('func2')
    avm_class.method_pyfunctions['func1'] = func1
    avm_class.method_pyfunctions['func2'] = func

# Generated at 2022-06-22 09:37:27.785007
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .flash.swfparser import parse_swf, SWFParser

# Generated at 2022-06-22 09:37:38.773343
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from .swftags import (
        ABC_METHOD,
    )
    avm_class = _AVMClass(1, 'TestClass', {})
    method_code = ABC_METHOD(
                idx=1,
                flags=0x00000f,
                name='TestMethod',
                params=[
                    (0, 0),
                ],
                return_type=0,
                options=[],
                param_names=[
                ],
                debug_name='TestMethod',
                debug_name_idx=0,
                debug_type='void',
                debug_type_idx=0,
                method_body=None,
            )
    avm_class.register_methods({method_code.name: method_code.idx})