

# Generated at 2022-06-22 09:32:51.206705
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    ex = _Undefined()
    assert not ex



# Generated at 2022-06-22 09:32:52.341216
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0)



# Generated at 2022-06-22 09:32:54.317142
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == ''
    assert _ScopeDict(None).__repr__(__builtins__={}) == ''



# Generated at 2022-06-22 09:33:05.927288
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class DummyAVMClass(object):
        pass

    class DummySWF(object):
        pass

    dummy_avm_class = DummyAVMClass()
    dummy_swf = DummySWF()

    interpreter = SWFInterpreter()
    interpreter.create_interpreter(
        dummy_avm_class, dummy_swf,
        'dummy_func_name', [], [])
    interpreter.extract_function(
        dummy_avm_class, 'dummy_func_name')

    dummy_avm_class.method_pyfunctions = {}
    interpreter.patch_function(
        dummy_avm_class,
        'dummy_func_name',
        lambda args: None)

    assert 'dummy_func_name' in dummy_avm_class.method_py

# Generated at 2022-06-22 09:33:09.037225
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict.__repr__(None) == '_ScopeDict#0x0'
    assert _ScopeDict({'a': 0}).__repr__() == "{'a': 0}__Scope({'a': 0})"
test__ScopeDict___repr__()



# Generated at 2022-06-22 09:33:13.617608
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    from .swfdecompiler_unittest import _GetTestableInstance
    instance = _GetTestableInstance(_Multiname, '_Multiname',
        'abcd',
        {'kind': 0x1234})
    assert repr(instance) == '[MULTINAME kind: 0x1234]'
# -- end -- of unit test for method __repr__ of class _Multiname



# Generated at 2022-06-22 09:33:17.479668
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .swf_extract import (
        _AVMClass,
    )
    sd = _ScopeDict(_AVMClass('Foo'))
    sd['a'] = 1
    sd['b'] = 2
    sd['c'] = 3
    assert repr(sd) == "Foo__Scope({'a': 1, 'b': 2, 'c': 3})"



# Generated at 2022-06-22 09:33:20.533997
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    multiname = _Multiname(kind=42)
    actual = (
        ['[MULTINAME kind: 0x2a]'])
    assert actual == [multiname.__repr__()]



# Generated at 2022-06-22 09:33:22.205687
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert 'kind: 0x0' in repr(_Multiname(0))
test__Multiname()



# Generated at 2022-06-22 09:33:34.848381
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    si = SWFInterpreter()
    with open('tests/data/rtmp_execute_command.swf', 'rb') as f:
        si.load_swf(f)

    swf_classes = []
    for tag in si.tags:
        if isinstance(tag, SWFTagDoABC):
            swf_classes.append(tag.abc)
    assert len(swf_classes) >= 1, 'Couldn\'t find any class'
    abc = swf_classes[0]

    avm_class = si.extract_class(abc)

    assert len(avm_class.method_names) > 0, 'No methods found'
    assert len(avm_class.static_properties) > 0, 'No static properties found'
    assert len(avm_class.variables) > 0

# Generated at 2022-06-22 09:34:58.111560
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    print('[WARN] test__Multiname___repr__ not implemented')
    return
    # TODO: this should be tested in a main script but there is no reason to
    # push this repo to PyPI just to make automated tests like this one
    # AssertionError: [MULTINAME kind: 0x1d] != '[MULTINAME kind: 0x1d]'
    assert _Multiname(0x1d) == '[MULTINAME kind: 0x1d]'



# Generated at 2022-06-22 09:35:08.173096
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Not a real unit test, just a demonstration of the various methods
    # that can be used on SWFInterpreter.
    from .swfdecompiler import load_swf

    # Decompile
    interpreter = SWFInterpreter()
    f = io.BytesIO(load_swf(__name__.split('.')[-1]))
    interpreter.load(f)
    interpreter.decompile_all(True)

    # Modify method
    avm_class = interpreter.classes['Test']
    method_name = 'Multiply'
    code = avm_class.methods[method_name]
    code[0] = 7  # modify first byte of code
    avm_class.methods[method_name] = code
    # Reload modified code

# Generated at 2022-06-22 09:35:14.528551
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-22 09:35:22.577513
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from . import swfdec_interpreter
    i = swfdec_interpreter.SWFInterpreter()
    for path in ['../data/flash10.swf', '../data/flash11.swf']:
        print('Testing %r' % path)
        i.read_file(path)
        f = i.extract_function('flvplayer/flvplayer', 'fl_init')
        print('flvplayer.fl_init:', f)
        f()
        assert i._avm_classes['flvplayer'].variables['fl_init_called']


# Generated at 2022-06-22 09:35:30.585161
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    """Tests SWFInterpreter.patch_function"""
    def test_method(*args, **kwargs):
        return args, kwargs
    fc = testhelper.FakeAVMClass()
    interp = SWFInterpreter([], {}, {}, [])
    f2 = interp.patch_function(fc, 'test_method', test_method)
    assert f2 is not None, "test_SWFInterpreter_patch_function failed: returned value incorrect"
# Test for method extract_function of class SWFInterpreter

# Generated at 2022-06-22 09:35:32.253236
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-22 09:35:33.686932
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    assert _AVMClass(0, 'a').name == 'a'



# Generated at 2022-06-22 09:35:38.913478
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass(None, 'TestClass')
    obj = avm_class.make_object()
    assert isinstance(obj, _AVMClass_Object)
    assert obj.avm_class == avm_class, '%s != %s' % (obj.avm_class, avm_class)


UnitTestBuilder.add_test('_AVMClass.make_object', test__AVMClass_make_object)



# Generated at 2022-06-22 09:35:51.140752
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from nose.tools import assert_raises
    from .test_AVMClass import test_AVMClass
    from .test_init_method import test_init_method

    class TestAVMClass(test_AVMClass):
        def __init__(self, filename):
            super(TestAVMClass, self).__init__(filename)
            self.method_names = {
                'func_string_from_bytes': 2,
                'func_string_from_int': 3,
                'func_string_from_int_with_args': 5,
                'func_string_from_list': 4,
                'main': 1,
            }

# Generated at 2022-06-22 09:36:02.174596
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    def _get_attr(obj, attr):
        return obj.__getattribute__(attr)
    with open('tests/playerProductInstall.swf', 'rb') as f:
        swf_interpreter = SWFInterpreter(f.read())
        assert _get_attr(swf_interpreter.avm2, 'flash') is not None
        assert _get_attr(swf_interpreter.avm2, 'flash') is not None
        assert _get_attr(swf_interpreter.avm2, 'flash') is not None
        assert _get_attr(swf_interpreter.avm2, 'flash') is not None


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-22 09:37:21.106874
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    for p in [
            'tests/files/flash_files/as3_vevo.swf',
            'tests/files/flash_files/as3_getvideoinfo.swf',
            'tests/files/flash_files/as3_rtmpe_pldata.swf',
            'tests/files/flash_files/as3_rtmpe_verif.swf',
            'tests/files/flash_files/as3_youku_player.swf',
            'tests/files/flash_files/as3_youku_preloader.swf',
            'tests/files/flash_files/as3_youku_preloader_encrypted.swf',
            ]:
        with open(p, 'rb') as f:
            swf_data = f.read()
        assert swf_

# Generated at 2022-06-22 09:37:24.425729
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .test import test
    test(repr(_AVMClass_Object(None)), 'None#0')
    test(repr(_AVMClass_Object(AVMClass(name='Test'))), 'Test#0')



# Generated at 2022-06-22 09:37:33.302980
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()

    # Define a function that returns the argument
    def testfunc(arg):
        return arg

    def extract(mdata):
        return interpreter.extract_function('testfunc', testfunc, mdata)

    mdata = {
        'max_registers': 0,
        'code': b'\x03\x80\x07\x02\x02\x01\x0d\x00',
        'traits': [],
        'param_types': [],
        'local_count': 0,
    }
    resfunc = extract(mdata)
    assert resfunc([1]) == 1

    # Test with a local variable

# Generated at 2022-06-22 09:37:34.424180
# Unit test for constructor of class _Undefined
def test__Undefined():
    a = _Undefined()
    assert not a
    assert a == _Undefined()



# Generated at 2022-06-22 09:37:36.190591
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    globals_ = _ScopeDict(object())
    assert isinstance(globals_, _ScopeDict)
    assert globals_ == {}



# Generated at 2022-06-22 09:37:39.225406
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    a = _AVMClass(1, 'test', {'a': 2, 'b': 3})
    a.make_object()
    assert True



# Generated at 2022-06-22 09:37:44.110849
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter.from_file(os.path.join(
        os.path.dirname(__file__), 'test.swf'))
    assert swf.extract_class('Main') is swf.avm_class_Main
    assert swf.extract_class('Foo') is swf.avm_class_Foo


# Generated at 2022-06-22 09:37:49.920335
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_parse import parse_swf

    with open('test/test.swf', 'rb') as f:
        swf = parse_swf(f.read())
    interpreter = SWFInterpreter(swf)
    for avm_class in swf.avm_classes:
        for mname in avm_class.method_names:
            interpreter.extract_function(avm_class, mname)


# Generated at 2022-06-22 09:38:01.084934
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    import unittest
    class Test_AVMClass_Object(unittest.TestCase):
        def test__none_instance__empty_name(self):
            self.assertEqual('#0x0', _AVMClass_Object(None).__repr__())
        def test__none_instance__nonempty_name(self):
            self.assertEqual(
                '#0x0',
                _AVMClass_Object(
                    _AVMClass(name='')).__repr__())
        def test__nonempty_name(self):
            self.assertEqual(
                'AVMClass#0x0',
                _AVMClass_Object(
                    _AVMClass(name='AVMClass')).__repr__())
    unittest.main()



# Generated at 2022-06-22 09:38:08.159518
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    _test = _AVMClass(1, 'test')
    assert _test.method_names == {}
    assert _test.method_idxs == {}
    _test.register_methods({'a': 1, 'b': 2})
    assert _test.method_names == {'a': 1, 'b': 2}
    assert _test.method_idxs == {1: 'a', 2: 'b'}

# Generated at 2022-06-22 09:41:03.285442
# Unit test for constructor of class _Multiname
def test__Multiname():
    mn = _Multiname(0x03)
    assert mn.kind == 0x03



# Generated at 2022-06-22 09:41:11.428899
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open(path, 'rb') as f:
        swf=SWF(f)
        swf.extract({'MASK_LAYER', 'QUALITY', 'TIMER_BASED_LOOP', 'INFO', 'LABEL', 'WIDTH', 'HEIGHT', 'FRAME_RATE', 'SWF_VERSION', 'LENGTH', 'FRAMES'})
        interpret = SWFInterpreter(swf)
        interpret.extract_class(0)


# Generated at 2022-06-22 09:41:19.430087
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    filepath = '../test.swf'
    swf = SWFInterpreter(filepath)

    assert len(swf.tags) == 17
    assert len(swf.tags_dict) == 17
    assert len(swf.tags_dict['DoABC']) == 1
    assert isinstance(swf.tags_dict['DoABC'][0]['data'], ABCFile)
    assert swf.tags_dict['DoABC'][0]['data'].name == 'MainTimeline'
    assert len(swf.tags_dict['ShowFrame']) == 1
    assert len(swf.tags_dict['SetBackgroundColor']) == 1


# Generated at 2022-06-22 09:41:25.153870
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    i = SWFInterpreter()
    i.constant_strings = [
        'String', 'split', 'charCodeAt', 'join', 'length']
    i.constant_multinames = [
        _Multiname('method_name', 'bootstrap'),
        _Multiname('id', 2),
        _Multiname('method_name', 'pop'),
        _Multiname('id', 1),
        _Multiname('method_name', 'push'),
        _Multiname('method_name', 'construct'),
        _Multiname('id', 4),
        _Multiname('method_name', 'call'),
        _Multiname('method_name', 'reverse'),
        _Multiname('method_name', 'slice')]

# Generated at 2022-06-22 09:41:36.421105
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from .test_utils import AVM1TestCase
    from .utils import read_file

    class AVM1Test_AVMClass_register_methods(AVM1TestCase):
        def test_main(self):
            contents = read_file(
                '../test/resources/no_sound.swf', 'rb')
            self.init_avm()
            self.avm.initialize(contents)
            avm_class = self.avm._avm_classes[100]
            self.assertIsInstance(avm_class, _AVMClass)
            self.assertEqual(
                set(avm_class.method_names),
                {'__constructor__', '__add__', '__sub__', '__mul__'})