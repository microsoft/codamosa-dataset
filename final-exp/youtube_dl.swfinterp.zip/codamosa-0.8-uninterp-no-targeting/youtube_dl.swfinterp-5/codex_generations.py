

# Generated at 2022-06-22 09:32:34.694598
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    C = _AVMClass('C', static_properties={'x': 1, 'y': 2})
    assert isinstance(C.static_properties, dict)
    assert isinstance(C.static_properties, collections.Mapping)
    assert C.static_properties['x'] == 1
    assert C.static_properties['y'] == 2



# Generated at 2022-06-22 09:32:36.846575
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x07).__repr__() == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-22 09:32:38.971778
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(0)
    assert repr(obj) == '[MULTINAME kind: 0x0]'



# Generated at 2022-06-22 09:32:44.847593
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(None, None)
    avm_class.register_methods({
        'test_name_1': 1,
        'test_name_2': 2,
    })
    assert avm_class.method_names == {
        'test_name_1': 1,
        'test_name_2': 2,
    }
    assert avm_class.method_idxs == {
        1: 'test_name_1',
        2: 'test_name_2',
    }

# Generated at 2022-06-22 09:32:46.508041
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    _AVMClass_Object(None)

AVMClass_Object = _AVMClass_Object



# Generated at 2022-06-22 09:32:50.683249
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert _Multiname(0x07).__repr__() == '[MULTINAME kind: 0x7]'
    assert _Multiname(0xd).__repr__() == '[MULTINAME kind: 0xd]'



# Generated at 2022-06-22 09:32:57.878636
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .embedswf import SWFInterpreter
    from .embedswf import _Undefined


# Generated at 2022-06-22 09:33:00.616119
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    _verify_function(SWFInterpreter.patch_function, 2)
# end of test_SWFInterpreter_patch_function


# Generated at 2022-06-22 09:33:06.478850
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(0, 'Test')
    avm_class.register_methods({
        'foo': 0x1,
        'bar': 0x2,
    })
    assert avm_class.method_names == {
        'foo': 0x1,
        'bar': 0x2,
    }
    assert avm_class.method_idxs == {
        0x1: 'foo',
        0x2: 'bar',
    }



# Generated at 2022-06-22 09:33:10.603980
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter("tests/test.swf")
    swf.avm1_execute("doit")


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-22 09:34:10.482435
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .abc import _ABCFile

# Generated at 2022-06-22 09:34:12.519581
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.patch_function()


# Generated at 2022-06-22 09:34:14.939538
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    s = _ScopeDict('avm_class')
    assert repr(s) == 'avm_class__Scope({})'

test__ScopeDict()



# Generated at 2022-06-22 09:34:17.044855
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    scope = _ScopeDict('Test__ScopeDict')
    scope['foo'] = 0
    scope['bar'] = 1



# Generated at 2022-06-22 09:34:22.162694
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .utils import (
        identical_objects,
    )

    c = _AVMClass('foo', 'foo')
    o = c.make_object()
    assert isinstance(o, _AVMClass_Object)
    assert isinstance(o, _AVMClass_Object)
    assert identical_objects(c, o.avm_class)

# Generated at 2022-06-22 09:34:25.021543
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    rv = _AVMClass(name_idx=None, name='foo').make_object()
    assert repr(rv) == 'foo#%x' % id(rv)



# Generated at 2022-06-22 09:34:26.244869
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    return _repr_test(_AVMClass('foo'))



# Generated at 2022-06-22 09:34:32.662781
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class Cls(object):
        def dummy_function(self):
            return 'foo'

        def dummy_function_with_args(self, a, b):
            return a + b

        def dummy_function_with_kwargs(self, a=None):
            return a

    cls = Cls()
    si = SWFInterpreter()

    func = si.patch_function(cls.dummy_function)
    assert isinstance(func, types.FunctionType)
    assert func() == 'foo'

    func = si.patch_function(cls.dummy_function_with_args)
    assert isinstance(func, types.FunctionType)
    assert func(123, 456) == 579

    func = si.patch_function(cls.dummy_function_with_kwargs)

# Generated at 2022-06-22 09:34:36.610066
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    instance = _AVMClass(0, 'Name', static_properties=None)
    assert isinstance(instance, _AVMClass)
    # No exception should be raised
    instance.register_methods(methods={})


# Generated at 2022-06-22 09:34:38.606172
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() is _Undefined(), 'Unexpected behavior of _Undefined'



# Generated at 2022-06-22 09:36:32.410285
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    scope = _ScopeDict(None)
    scope['x'] = 0
    scope['y'] = 1
    assert (
        '_Scope(%s)' % dict.__repr__(scope)
        == repr(scope))



# Generated at 2022-06-22 09:36:41.507853
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_filename = '../samples/fetch_swf.swf'
    swf = SWFInfo(io.open(swf_filename, 'rb'))
    interpreter = SWFInterpreter(swf.tags)
    assert interpreter.version == 9
    assert len(interpreter.constant_pool) == 6

# Generated at 2022-06-22 09:36:47.994128
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-22 09:36:49.259046
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    # For coverage
    repr(_ScopeDict(None))



# Generated at 2022-06-22 09:36:51.277439
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__(): return _Undefined.__repr__(_Undefined())

# Generated at 2022-06-22 09:36:53.141576
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert 0 == hash(_Undefined()) == hash('')
    assert str(_Undefined()) == 'undefined'



# Generated at 2022-06-22 09:36:55.897072
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    class UnitTest(_Undefined):
        pass
    assert repr(UnitTest()) == 'undefined'



# Generated at 2022-06-22 09:37:00.278712
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class DummyClass(object):
        pass
    scopedict = _ScopeDict(DummyClass())
    assert repr(scopedict) == '<DummyClass>.__Scope({})'
    assert repr(_ScopeDict(DummyClass())) == '<DummyClass>.__Scope({})'



# Generated at 2022-06-22 09:37:02.774132
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(7)) == '[MULTINAME kind: 0x7]'

_multiname_kinds = {}



# Generated at 2022-06-22 09:37:09.092732
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    p1 = os.path.join(
        os.path.dirname(__file__), 'data',
        'test_swfinterpreter_extract_class_1.class.swf')
    p2 = os.path.join(
        os.path.dirname(__file__), 'data',
        'test_swfinterpreter_extract_class_2.class.swf')
    for p in (p1, p2):
        avm_class = SWFInterpreter(open(p, 'rb').read()).extract_class()
        assert avm_class.variables['a'] == 'abc'
        assert avm_class.variables['b'] == 'def'
        assert avm_class.variables['c'] == 'ghi'