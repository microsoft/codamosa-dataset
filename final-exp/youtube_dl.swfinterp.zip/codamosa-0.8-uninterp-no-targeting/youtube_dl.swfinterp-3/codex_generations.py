

# Generated at 2022-06-22 09:32:19.688964
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    f = open('tests/flash.swf', 'rb')
    interp = SWFInterpreter(f.read())
    f.close()
    assert 'ASSetPropFlags' in interp.avm_root.method_names
    assert 'trace' in interp.avm_root.method_names
    assert 'String' in interp.avm_root.method_names
    assert 'push' in interp.avm_root.method_names
    assert interp.avm_root.variables['NaN'] is not None


# Generated at 2022-06-22 09:32:22.413515
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


# Generated at 2022-06-22 09:32:29.240853
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    expected_result = (
        '[_Multiname'
        ' [MULTINAME kind: 0x0]]')
    assert repr(
        _Multiname(
            kind=0x0)) == expected_result
    expected_result = (
        '[_Multiname'
        ' [MULTINAME kind: 0x1]]')
    assert repr(
        _Multiname(
            kind=0x1)) == expected_result
    expected_result = (
        '[_Multiname'
        ' [MULTINAME kind: 0x2]]')
    assert repr(
        _Multiname(
            kind=0x2)) == expected_result
    expected_result = (
        '[_Multiname'
        ' [MULTINAME kind: 0x3]]')

# Generated at 2022-06-22 09:32:34.152905
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    from pytest import raises
    from .compat import PY2
    if PY2:
        assert _Undefined().__hash__() == 0
    else:
        with raises(TypeError):
            _Undefined().__hash__()

# Generated at 2022-06-22 09:32:37.439816
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    avm_class = _AVMClass()
    avm_class.name = 'name'
    obj = _AVMClass_Object(avm_class)
    assert obj.__repr__().find('name') != -1



# Generated at 2022-06-22 09:32:43.474437
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    import sys
    import six
    import unittest2 as unittest
    import os

    class _AVMClass_Object_Test(unittest.TestCase):
        def setUp(self):
            self.avm_class = _AVMClass(0, '<class>')
            self.avm_obj = self.avm_class.make_object()

        def test__AVMClass_make_object_instance(self):
            self.assertIsInstance(self.avm_obj, _AVMClass_Object)

        def test__AVMClass_make_object_attribute(self):
            self.assertEqual(self.avm_obj.avm_class, self.avm_class)


# Generated at 2022-06-22 09:32:48.186600
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    with open('../test/fixtures/text/text.swf', 'rb') as f:
        intp = SWFInterpreter(f.read())
    intp.extract_function('_level0', '_button')
    intp.extract_function('_level0', '_text1')



# Generated at 2022-06-22 09:32:51.930166
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    cls = _AVMClass_Object
    inst = _ScopeDict(cls)
    cls.name = '_AVMClass_Object'
    assert repr(inst) == '_AVMClass_Object__Scope({})'



# Generated at 2022-06-22 09:32:59.213856
# Unit test for constructor of class _Undefined
def test__Undefined():
    a = _Undefined()
    b = _Undefined()
    assert a is b
    assert not a
    assert not b

    assert hash(a) == hash(b)

    assert str(a) == 'undefined'
    assert repr(a) == 'undefined'

_undefined = _Undefined()

# Test for _undefined

# Generated at 2022-06-22 09:33:03.095195
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    v = _AVMClass('v', 'v')
    v.register_methods({'f': 1, 'g': 2})
    assert v.method_names == {'f': 1, 'g': 2}
    assert v.method_idxs == {1: 'f', 2: 'g'}

# Generated at 2022-06-22 09:34:20.795292
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    multiname = _Multiname(0x07)
    assert repr(multiname) == '[MULTINAME kind: 0x7]'


# Generated at 2022-06-22 09:34:24.976735
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass('FakeClassName', 0, {})
    assert isinstance(avm_class.variables, dict)
    assert isinstance(avm_class.method_names, dict)
    assert isinstance(avm_class.method_idxs, dict)



# Generated at 2022-06-22 09:34:27.802501
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(io.BytesIO(b'\x01\x00\x00\x00\x00\x00\x00\x00'))
    swf.extract_function(None, 'foo')



# Generated at 2022-06-22 09:34:35.337492
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    __test__ = dict()
    import sys
    from StringIO import StringIO

    out = StringIO()
    old_stdout = sys.stdout
    sys.stdout = out

    a = _Multiname(0x01)
    print(repr(a))

    sys.stdout = old_stdout
    assert out.getvalue()[:-1] == '[MULTINAME kind: 0x1]'


# Generated at 2022-06-22 09:34:36.963779
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .asvm import _flash_classes

    class_s = _flash_classes['Object']
    assert repr(class_s.make_object()) == '_AVMClass(Object)#0x'


# Generated at 2022-06-22 09:34:40.274572
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from .swfdec_swf import AVMClass
    assert (
        repr(AVMClass(None, 'test', None)) ==
        "_AVMClass(test)")

# Generated at 2022-06-22 09:34:42.540662
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    str(Undefined) == 'undefined'
    repr(Undefined) == 'undefined'
Undefined = _Undefined()



# Generated at 2022-06-22 09:34:43.728272
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    x = _Undefined()
    assert not x


# Generated at 2022-06-22 09:34:47.783669
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()), (
        'Failed to test method __bool__ of class _Undefined')


_undefined = _Undefined()


# Generated at 2022-06-22 09:34:50.117086
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    obj = _Undefined()
    assert str(obj) == 'undefined', str(obj)


Undefined = _Undefined()



# Generated at 2022-06-22 09:35:42.458455
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .test_swfdecomp import SWFDecompTestCase
    from .SWF import AVMClass

    scope = _ScopeDict(AVMClass('TestClass'))
    scope['a'] = 'b'
    scope['c'] = 'Test'
    scope['d'] = 1
    scope['e'] = 2
    scope['f'] = 3
    SWFDecompTestCase().assertEqual(
        repr(scope),
        'TestClass__Scope({\'e\': 2, \'a\': \'b\', \'f\': 3, \'d\': 1, \'c\': \'Test\'})')

# Generated at 2022-06-22 09:35:54.859085
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    # Test of __repr__ of class _AVMClass
    # This is a default Unit test example. Please add your own tests here.
    # You can learn more about python-unittest at
    # https://docs.python.org/library/unittest.html
    # This is a demonstration of using unit-test.
    # A unit-test has at least one test case - a class which inherits from unittest.TestCase
    from unittest import TestCase
    from .utils import *
    # A unit-test requires a method with prefix "test".
    # This method usually contains a sequence of asserts.
    # The method can have any name, but it must have prefix 'test'

# Generated at 2022-06-22 09:35:58.401457
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from .amf0 import _AVMClass, _ScopeDict
    a = _AVMClass('a')
    assert repr(a) == '_AVMClass(a)'


# Generated at 2022-06-22 09:36:07.593291
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(b'', '')
    import math
    swf.constant_strings[0] = 'Math'
    swf.multinames[0] = 'Math'
    swf.constant_strings[1] = 'sin'
    swf.multinames[1] = 'sin'
    swf._extract_function(0, [b'sin'])
    assert swf.multinames[1] == math
    swf._extract_function(0, [b'sin'])
    swf.constant_strings[2] = 'sqrt'
    swf.multinames[2] = 'sqrt'
    swf._extract_function(0, [b'sqrt'])
    assert swf.multinames[2] == math.sq

# Generated at 2022-06-22 09:36:11.765490
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(
        _AVMClass_Object(_AVMClass_Object(_AVMClass_Object(None)))) == \
        '_AVMClass_Object#...'
test__AVMClass_Object()



# Generated at 2022-06-22 09:36:22.873769
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .flash_proxy import flash_proxy_pyfunctions


# Generated at 2022-06-22 09:36:31.516455
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    from .amf3 import decode_utf8_string

    input_stream = BytesIO(SWF_DATA)

    class FakeFile:
        def __init__(self, swf):
            self.swf = swf
        def read(self, size):
            if len(self.swf) < size:
                retval = self.swf
                self.swf = ''
                return retval
            retval = self.swf[:size]
            self.swf = self.swf[size:]
            return retval

    interp = SWFInterpreter(FakeFile(SWF_DATA))

# Generated at 2022-06-22 09:36:32.970976
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    r = _Undefined()
    assert hash(r) == 0

# Generated at 2022-06-22 09:36:45.047047
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import io
    import hashlib
    with open('../../test/test.swf', 'rb') as f:
        tag_stream = io.BytesIO()
        f.seek(8, 0)
        bytes = 0
        while True:
            tag_type, tag_len = struct.unpack('<BH', f.read(3))
            tag_stream.write(f.read(tag_len))
            bytes += tag_len + 3
            if tag_type == 0:
                break
        f.seek(0, 0)
        sig, version, length = struct.unpack('<3sBB', f.read(5))
        assert sig == b'FWS'
        assert length == bytes + 8

    # Construct a SWFInterpreter

# Generated at 2022-06-22 09:36:51.728152
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    # pylint: disable=missing-docstring

    class _AVMClass(object):
        def __init__(self, name):
            self.name = name

    obj = _AVMClass_Object(_AVMClass('Foo'))
    assert obj.avm_class.name == 'Foo'
    assert repr(obj) == 'Foo#%x' % id(obj)



# Generated at 2022-06-22 09:37:45.410143
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    _AVMClass_Object(None).avm_class

# _AVMClass_Array is a _AVMClass_Object with a fixed-size list as an attribute

# Generated at 2022-06-22 09:37:52.773246
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    assert SWFInterpreter().extract_function(SWFInterpreter._AVMClass.variables['Object'], 'toString')
    assert SWFInterpreter().extract_function(
        SWFInterpreter._AVMClass.variables['Array'], 'join')
    assert SWFInterpreter().extract_function(
        SWFInterpreter._AVMClass.variables['String'], 'indexOf')
    assert SWFInterpreter().extract_function(
        SWFInterpreter._AVMClass.variables['String'], 'split')


# Extract encoder key

# Generated at 2022-06-22 09:38:03.672524
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    def _check(avm_class, expected_repr):
        assert _AVMClass_Object(avm_class).__repr__() == expected_repr
    _check(avm_class=Object(name='Boolean'), expected_repr='Boolean#%x' % id(_AVMClass_Object(Object(name='Boolean'))))
    _check(avm_class=Object(name='int'), expected_repr='int#%x' % id(_AVMClass_Object(Object(name='int'))))
    _check(avm_class=Object(name='int[]'), expected_repr='int[]#%x' % id(_AVMClass_Object(Object(name='int[]'))))

# Generated at 2022-06-22 09:38:05.771299
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    o = _Undefined()
    assert hash(o) == 0
test__Undefined___hash__()


undefined = _Undefined()



# Generated at 2022-06-22 09:38:16.497872
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .tags import _AVM2_INIT_ACTION
    # Unit test for method make_object of class _AVMClass

# Generated at 2022-06-22 09:38:22.230732
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .utils import load_file_contents
    class_dict = load_file_contents('class_dict.bin')
    avm_class = _AVMClass(
        'Test', class_dict, max_recursion_depth=10)
    scope = _ScopeDict(avm_class)
    scope['$1'] = avm_class
    assert repr(scope) == 'Test__Scope({"$1": Test#%x}' % id(avm_class)


# Generated at 2022-06-22 09:38:27.302402
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    coder = compat_io.BytesIO(compat_chr(0) * (1 << 30))
    interpreter = SWFInterpreter(coder)
    interpreter.dump = lambda *args: None
    assert interpreter.patch_function(None, None) is None


# Generated at 2022-06-22 09:38:28.837570
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    m = _Multiname(0x07)
    assert repr(m)



# Generated at 2022-06-22 09:38:39.914121
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf.swf import SWF
    from .swf.tagreader import TagReader
    from .swf.data import ABCFile
    from .swf.byteblock import ByteBlock

    base_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), '..', '..',
        '..', 'doc', 'examples', 'simpleplayer')

    with open(os.path.join(base_path, 'playerProductInstall.swf'), 'rb') as f:
        swf = SWF(f)
        assert swf.do_actions[0].action_records[0].actions[0][1] == b'\x3f\x00\x00\x00'

    avm = SWFInterpreter()
    swf_file

# Generated at 2022-06-22 09:38:50.617231
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf_interpreter import SWFInterpreter
    from .swf_info import SWFInfo
    s = SWFInfo.from_stream(open('test/test.swf', 'rb'))
    i = SWFInterpreter(s)
    c = i.extract_class('TypedObject')
    assert 'Array' in c.variables
    assert c.variables['Array'] == c.static_properties['Array']
    assert 'Object' in c.variables
    assert c.variables['Object'] == c.static_properties['Object']

    c = i.extract_class('Array')
    assert isinstance(c.variables['length'], _AVMMethod)
    assert c.variables['concat'] == c.static_properties['concat']
    assert c.variables

# Generated at 2022-06-22 09:41:21.060727
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
    assert not (_Undefined() and 1)
    assert _Undefined() == _Undefined()

_undefined = _Undefined()



# Generated at 2022-06-22 09:41:22.425298
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined()
    assert not _Undefined()



# Generated at 2022-06-22 09:41:34.211494
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    print('\n' + __name__)
    abc = ABC()
    abc.constant_int = [None, 0, 1, 2, 3]
    abc.constant_uint = abc.constant_int
    abc.constant_double = [None, 0.0, 1.0, 2.0, 3.0, 4.5633, 7.5]
    abc.constant_string = [
        None, '', 'Hello', 'a', 'b', 'c', 'é', 'aé', 'bc']

    abc.multiname = [None]
    for name in ['x', 'y', 'z', 'a', 'b', 'c', 'length']:
        mn = _Multiname(name=name)
        abc.multiname.append(mn)