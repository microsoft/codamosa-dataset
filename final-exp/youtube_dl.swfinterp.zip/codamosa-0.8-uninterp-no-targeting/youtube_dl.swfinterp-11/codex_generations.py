

# Generated at 2022-06-22 09:33:42.401840
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    AVMClass_Object = _AVMClass_Object(None)
    assert repr(AVMClass_Object) == 'None#%x' % id(AVMClass_Object)



# Generated at 2022-06-22 09:33:44.894150
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    args = {}
    rv = _SWFInterpreter_extract_class(args)
    return rv

# Generated at 2022-06-22 09:33:49.893286
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    # __repr__$2 - %s#%x
    import pytest  # pylint: disable=no-name-in-module
    t = _AVMClass_Object(_AVMClass(''))
    assert t.__repr__() == '#%x' % id(t)
    assert t.__repr__() == '#%x' % id(t)
test__AVMClass_Object___repr__()



# Generated at 2022-06-22 09:33:52.010840
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert repr(_ScopeDict({}, None)) == 'None__Scope({})'



# Generated at 2022-06-22 09:33:58.542787
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    # Using the constructor of a class to test it is considered a unit test
    # anti-pattern.
    # However, in this case, I wanted a way to test __repr__, and I wanted
    # __repr__ to be as simple as possible. What I needed to test was that
    # the code name of the class can contain spaces, and that the __repr__
    # method will not break because of that.
    _AVMClass(name_idx=None, name='Some class')



# Generated at 2022-06-22 09:34:08.349529
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .test_util import make_test_swf

    SWF = compat_struct_pack(
        '<4s4BI2H4B',
        b'FWS',
        9,  # Version
        0,  # Length
        0,  # FrameWidth
        0,  # FrameHeight
        0,  # FrameRate
        0,  # FrameCount
        0,  # TagCount
    )

    swf_io = BytesIO(SWF)
    interpreter = SWFInterpreter(swf_io)
    o = interpreter.make_object()
    o['foo'] = 'bar'
    assert o['foo'] == 'bar'
    assert o['undefined'] == undefined

# Generated at 2022-06-22 09:34:15.314682
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    obj = SWFInterpreter(None, None)
    extract_function = obj.extract_function
    code = '\x0c\x00\x02\x01\x06\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'
    method_names = set()
    func = extract_function(None, 'test_return_void', code, method_names)
    assert func() is undefined

# Generated at 2022-06-22 09:34:17.151956
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    obj = _AVMClass_Object(None)
    assert obj.avm_class == None


# Generated at 2022-06-22 09:34:18.959967
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(kind=0x01)), '[MULTINAME kind: 0x1]'



# Generated at 2022-06-22 09:34:21.708003
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    x = _AVMClass_Object('foo/bar')
    assert x.avm_class == 'foo/bar'
    assert x.__dict__ == {}



# Generated at 2022-06-22 09:35:18.206370
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter(b'')
    interpreter.constant_strings = ['']
    interpreter.multinames = [0]
    assert interpreter.patch_function(
        None, 0, 0, [], None, []) == undefined



# Generated at 2022-06-22 09:35:20.812691
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert 'kind: 0x%x' % 1 in str(_Multiname(1))
    assert type(repr(_Multiname(1))) is type(u'abc')



# Generated at 2022-06-22 09:35:22.163772
# Unit test for constructor of class _Multiname
def test__Multiname():
    return _Multiname(0x07)



# Generated at 2022-06-22 09:35:23.526358
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(0)) == '[MULTINAME kind: 0x0]'

# Generated at 2022-06-22 09:35:29.100888
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _ScopeDict(None)
    assert obj.__repr__() == 'None__Scope({})'

    class Foo(object):
        pass

    obj = _AVMClass(1, 'Foo', {})
    assert isinstance(obj.method_names, dict)
    assert isinstance(obj.method_idxs, dict)
    assert isinstance(obj.methods, dict)
    assert isinstance(obj.method_pyfunctions, dict)
    assert isinstance(obj.static_properties, dict)

    obj.method_names.update({'bar': 1, 'baz': 2})
    obj.variables = Foo()
    assert obj.__repr__() == '_AVMClass(Foo)'

    obj = obj.make_object()

# Generated at 2022-06-22 09:35:34.361403
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avmclass = _AVMClass('foo.Bar')
    assert avmclass.name == 'foo.Bar'
    assert len(avmclass.method_names) == 0
    assert len(avmclass.method_idxs) == 0
    assert len(avmclass.methods) == 0
    assert len(avmclass.method_pyfunctions) == 0
    assert avmclass.static_properties == {}



# Generated at 2022-06-22 09:35:38.941308
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .common import assertEquals
    from .common import generate_fake_avm_class
    assertEquals('class_1__Scope({})', repr(_ScopeDict(generate_fake_avm_class('class_1'))))
    assertEquals('class_2__Scope({})', repr(_ScopeDict(generate_fake_avm_class('class_2'))))



# Generated at 2022-06-22 09:35:41.199462
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    instance = _AVMClass(
        name_idx=0,
        name='',
        static_properties=None)
    expected = '_AVMClass()'
    actual = repr(instance)
    assert actual == expected

# Generated at 2022-06-22 09:35:53.599961
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    data = compat_urllib_request.urlopen(
        'https://www.youtube.com/get_video_info?video_id=' +
        'K0RkO5c5lHY&eurl=https%3A%2F%2Ffeather-avm.github.io%2F').read()
    data = compat_str(data)
    info_dict = compat_parse_qs(data)

    for name, values in info_dict.items():
        if name == 'url_encoded_fmt_stream_map':
            streams = values[0].split(',')
            assert len(streams) >= 1, 'streams = %r' % streams
            decoded = compat_parse_qs(compat_urllib_parse.unquote_plus(streams[0]))
            sw

# Generated at 2022-06-22 09:35:56.983560
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    obj1 = _AVMClass_Object(_AVMClass('Object'))
    obj2 = _AVMClass_Object(_AVMClass('OtherObject'))
    assert repr(obj1) == repr(obj2).replace('OtherObject', 'Object')



# Generated at 2022-06-22 09:37:57.714101
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'


# Generated at 2022-06-22 09:38:00.319336
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__(): print(repr(_ScopeDict(object())))



# Generated at 2022-06-22 09:38:03.921500
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(kind=0x07, name=0x41, ns=0x42, ns_set=0x43, type=0x44)) == '[MULTINAME kind: 0x7, name: 0x41, ns: 0x42, ns_set: 0x43, type: 0x44]'



# Generated at 2022-06-22 09:38:05.374606
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
undefined = _Undefined()



# Generated at 2022-06-22 09:38:14.607355
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s = b'\x53\x43\x41\x31\x00\x78\x9c\xed\xd1\x0d\x00\x00\x00\x00\x00'
    swf_obj = SWFInterpreter(s)
    avm_class = swf_obj.all_avm_classes['_level0']
    func = swf_obj.extract_function(avm_class, 'stop')
    assert func() == undefined

# The functions and classes below are a mock up of what AS3/SWF
# programs can do, but are not part of a real AS3/SWF interpreter

# Generated at 2022-06-22 09:38:18.563191
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    # _AVMClass.__repr__ -> <bound method _AVMClass._AVMClass.__repr__ of <__main__._AVMClass object at 0x7f0cc48fdb00>>
    assert repr(_AVMClass(0, 'test')) == "_AVMClass('test')"

# Generated at 2022-06-22 09:38:21.885627
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .utils import make_script
    script = make_script(b'', b'')
    script.register_class(b'Test', _AVMClass)
    assert script.classes[b'Test'].make_object().avm_class is script.classes[b'Test']


# Generated at 2022-06-22 09:38:33.676418
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()) is False
    assert _Undefined() is not None
    assert _Undefined() is not False
_Undefined = _Undefined()



# Generated at 2022-06-22 09:38:35.742791
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass('name_idx', 'name')
    repr(obj)



# Generated at 2022-06-22 09:38:42.422242
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    assert SWFInterpreter(b'').extract_class() is None

# Generated at 2022-06-22 09:41:17.002569
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_path = 'tmp/test.swf'
    with open(swf_path, 'rb') as f:
        avm_interpreter = SWFInterpreter(f)

# Generated at 2022-06-22 09:41:22.357427
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert _AVMClass_Object(avm_class=None).__repr__() == '#' + '%x' % id(_AVMClass_Object(avm_class=None))
