

# Generated at 2022-06-22 09:32:37.779477
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    s = _ScopeDict(_AVMClass_Object(_AVMClass_Object(_AVMClass_Object(None))))
    s['3'] = 'hello'
    assert s.avm_class.avm_class.avm_class.name is None
    assert repr(s) == 'None__Scope({\'3\': \'hello\'})'


# Generated at 2022-06-22 09:32:41.913672
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    x = _Multiname(0)
    assert x.__repr__() == '[MULTINAME kind: 0x0]'



# Generated at 2022-06-22 09:32:44.202346
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = AVMClass__RtmpReader().make_object()
    assert obj.avm_class.name == 'RtmpReader'


# Generated at 2022-06-22 09:32:49.758500
# Unit test for constructor of class _Undefined
def test__Undefined():
    undef1 = _Undefined()
    undef2 = _Undefined()
    none1 = None
    none2 = None
    def assert_equal(a, b):
        assert a is b
    assert_equal(undef1, undef2)
    assert undef1 is not none1
    assert_equal(none1, none2)



# Generated at 2022-06-22 09:32:51.803480
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    o = _Multiname(0)
    repr(o)
    o.kind = 1
    repr(o)



# Generated at 2022-06-22 09:32:56.541786
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm = _AVMClass('class_name', 'class_name')
    avm.register_methods({'method1': 1, 'method2': 2})
    assert avm.method_names == {'method1': 1, 'method2': 2}, avm.method_names
    assert avm.method_idxs == {1: 'method1', 2: 'method2'}, avm.method_idxs
    return True
#test__AVMClass_register_methods()


# Generated at 2022-06-22 09:32:57.882951
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0)



# Generated at 2022-06-22 09:32:58.475243
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0



# Generated at 2022-06-22 09:33:04.122441
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import io
    import gzip
    import pickle

    with io.open('flash.swf', 'rb') as f:
        data = compat_str(f.read())
    interpreter = SWFInterpreter(data)

    # test deserialize_abc_multinames
    with open('abc_multinames.pickle', 'rb') as f:
        abc_multinames = pickle.load(f)
    abc_multinames = tuple(map(lambda multiname: (
        multiname.kind, multiname.namespace_set, multiname.name),
        abc_multinames))
    multinames = interpreter.deserialize_abc_multinames(
        abc_multinames, interpreter.abc_multinames)
    assert multinames[0]

# Generated at 2022-06-22 09:33:06.046211
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class Foo():
        pass

    obj = _AVMClass_Object(Foo)
    assert obj.avm_class == Foo



# Generated at 2022-06-22 09:34:03.614505
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    inst = _Undefined()
    inst.__hash__()
_Undefined = _Undefined()



# Generated at 2022-06-22 09:34:12.817009
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import unittest
    import io

    class TestInterpreter(unittest.TestCase):
        def test_patch_function(self):
            # This is a simple unit test to ensure patch_function works
            # on a few test cases
            swf = io.BytesIO(compat_chr(0) * 8)
            swf.seek(0, 2)
            swf.write(b'\x03\x00')  # length
            swf.write(b'\x02\x00')  # nbfuncs
            # Function body:
            #   var a = new Namespace("foo");
            #   var b = new Namespace("bar");
            #   trace(a == b);
            # Note that this function is invalid (it should
            # have one entry in the exception table)
            sw

# Generated at 2022-06-22 09:34:15.036905
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swfi = SWFInterpreter()
    swfi.extract_function('test', 'test', b'\x10\x00\x2E')


# Generated at 2022-06-22 09:34:19.098787
# Unit test for constructor of class _Multiname
def test__Multiname():
    try:
        _Multiname(5002)
    except AssertionError as e:
        if str(e) != 'Multiname kind 0x13d6 is not supported':
            raise
    else:
        raise AssertionError('_Multiname() does not raise AssertionError')



# Generated at 2022-06-22 09:34:21.803596
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert _AVMClass_Object(object()).__repr__() == 'object#{0:x}'.format(
        id(_AVMClass_Object(object())))



# Generated at 2022-06-22 09:34:24.808262
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert repr(_ScopeDict('a')) == "a__Scope({})"



# Generated at 2022-06-22 09:34:27.568225
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass('', '')
    instance = avm_class.make_object()
    assert isinstance(instance, _AVMClass_Object)
    assert instance.avm_class is avm_class



# Generated at 2022-06-22 09:34:32.498033
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .avm2 import AVMClass
    class_obj = _AVMClass_Object(AVMClass('foo'))
    assert repr(class_obj) == 'foo#%x' % id(class_obj)



# Generated at 2022-06-22 09:34:33.380375
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__(): pass



# Generated at 2022-06-22 09:34:37.637034
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() is _Undefined()
    assert not _Undefined()
    assert {_Undefined(): 3} == {}
    assert _Undefined() == _Undefined() == 7 - 7
    assert _Undefined() < 2
test__Undefined()



# Generated at 2022-06-22 09:35:37.046369
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass(
        name_idx='name_idx',
        name='name',
        static_properties='static_properties')

    try:
        repr(obj)
    except Exception:
        # If we get here, the repr() call raised an exception.
        # It should not.
        assert False

# Generated at 2022-06-22 09:35:38.181738
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert 'undefined' == repr(_Undefined())

# Generated at 2022-06-22 09:35:48.798386
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    import unittest
    import io
    class _(unittest.TestCase):
        def test_dummy(self):
            pass
    for v in _AVMClass_Object._AVMClass_Object__AVMClass_Object_0.traits.values():
        if isinstance(v, _AVMClass_Object__AVMClass_Object__AVMClass_Object_0_Trait):
            v.name = 'name'
            v.name = 'name'
            ret = _AVMClass_Object(v).__repr__()
            assert ret == 'name#%x' % id(_AVMClass_Object(v))
    unittest.main()


# Generated at 2022-06-22 09:35:56.099391
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    from yalafi import utils
    undefined = _Undefined()
    pars, pos = utils.tokenize('\\usepackage{xcolor}\\color{red}Hello')
    t = utils.get_token(pars, pos)
    assert t.macro == '\\color'
    assert t.next is not None
    assert t.param_numbers == []
    assert t.params == ['red']
    assert not undefined
Undefined = _Undefined()



# Generated at 2022-06-22 09:35:59.513675
# Unit test for constructor of class _Undefined
def test__Undefined():
    u = _Undefined()
    assert not u
    assert len({u:1}) == 0
    assert str(u) == 'undefined'

UNDEFINED = _Undefined()



# Generated at 2022-06-22 09:36:01.373245
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert tuple(map(int, _Multiname(0).kind)) == (0, )



# Generated at 2022-06-22 09:36:04.433320
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    code = b'\x27'
    interpreter = SWFInterpreter(code)
    assert interpreter.code == b'\x27'
    assert interpreter.version == 3
    assert interpreter.frame_rate == 15
    assert interpreter.frame_count == 2


if __name__ == '__main__':
    test_SWFInterpreter_patch_function()

# Generated at 2022-06-22 09:36:09.076312
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class TestClass(object):
        pass
    assert 'TestClass__Scope(%s)' % repr({'foo': 'bar'}) == repr(
        _ScopeDict(TestClass()))
if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])



# Generated at 2022-06-22 09:36:14.734903
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    a = _AVMClass('a', 'b', 'c')
    a.register_methods(dict(foo=42))
    assert a.method_names == dict(foo=42)
    assert a.method_idxs == dict(foo=42)
# end test__AVMClass_register_methods



# Generated at 2022-06-22 09:36:17.896054
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class A(object):
        pass
    x = _AVMClass_Object(A)
    assert x.avm_class is A
    assert not hasattr(x, 'b')



# Generated at 2022-06-22 09:37:15.408127
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class MyClass(object):
        scope = _ScopeDict(MyClass)
    assert repr(MyClass.scope) == 'MyClass__Scope({})'



# Generated at 2022-06-22 09:37:18.128628
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = _AVMClass('dummy_class', static_properties={}).make_object()
    assert obj.avm_class.name == 'dummy_class'



# Generated at 2022-06-22 09:37:24.080137
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    cls = _AVMClass('name', 'name')
    assert cls.method_names == {}
    cls.register_methods({'a': 0, 'b': 1})
    assert cls.method_names == {'a': 0, 'b': 1}



# Generated at 2022-06-22 09:37:27.758844
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    avm_class = _AVMClass(None, 'Test')
    instance = _AVMClass_Object(avm_class)
    assert repr(instance) == 'Test#%x' % id(instance)



# Generated at 2022-06-22 09:37:38.726343
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    import pprint
    _ScopeDict(_AVMClass_Object(object())).__repr__()
    # '_ScopeDict$x#x__Scope()'
    _ScopeDict(_AVMClass_Object(object())).__setitem__(3, 4).__repr__()
    # '_ScopeDict$x#x__Scope({3: 4})'
    _ScopeDict(_AVMClass_Object(object())).__setitem__(
        3,
        [1, 2]).__repr__()
    # '_ScopeDict$x#x__Scope({3: [1, 2]})'
    _ScopeDict(_AVMClass_Object(object())).__setitem__(
        3,
        {4: 5}).__repr__()
    # '_ScopeDict$

# Generated at 2022-06-22 09:37:40.186769
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class object:
        pass

    obj = _AVMClass_Object(object)
    assert obj.avm_class == object



# Generated at 2022-06-22 09:37:50.661696
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter()

# Generated at 2022-06-22 09:37:52.453752
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0x07)

# Importing the module registers types in this dict
MULTINAME_CLASSES = {}


# Generated at 2022-06-22 09:38:03.516892
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    """test_SWFInterpreter_extract_class"""
    swf = open(os.path.join(os.path.dirname(__file__), 'test', 'test.swf'), 'rb').read()
    int_ = SWFInterpreter(swf)
    # test number 1
    avm_class = _Classes['Demo']
    res = int_.extract_class(avm_class)
    assert len(res) == 2, '%s != %s' % (len(res), 2)
    assert list(sorted(res.method_pyfunctions)) == list(sorted(['Main', 'Main$'])), '%s != %s' % (list(sorted(res.method_pyfunctions)), list(sorted(['Main', 'Main$'])))

# Generated at 2022-06-22 09:38:04.702919
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not bool(_Undefined())

# Generated at 2022-06-22 09:41:03.409912
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = read_swf('test_lib.swf')
    interpreter = SWFInterpreter(swf)
    avm_class = interpreter.extract_class('Delegate')
    assert avm_class.name == 'Delegate'
    
    namespace = avm_class.static_properties.get('NAMESPACE')
    assert namespace == 'http://youku.com'
    
    tostring = avm_class.static_properties['toString']
    assert tostring == 'http://youku.com.Delegate'
    
    attr = avm_class.static_properties['ATTR']
    assert attr == ['test1', 'test2', 'test3']
    
    class_properties = interpreter.extract_class('ClassProperties')
    attr = class_properties.static_properties

# Generated at 2022-06-22 09:41:04.775177
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    obj = _Undefined()
    assert str(obj) == 'undefined'
test__Undefined___repr__()

# Generated at 2022-06-22 09:41:09.891219
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = open(
        os.path.join(os.path.dirname(__file__), '..', 'tests', 'test.swf'),
        'rb')
    SWFInterpreter(swf)


# Generated at 2022-06-22 09:41:17.914834
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = open(os.path.join(os.path.dirname(__file__),
                            '..', '..', 'tests', 'files', 'playlist.swf'),
               'rb').read()
    swf = BytesIO(swf)
    swf = SWF(swf)
    swf.parse()
    swf.extract_common_items()
    actionscript = getattr(swf.tags[37], 'actionscript', None)
    if actionscript is None:
        return
    as_bytecode = actionscript.as_bytecode()
    interpreter = SWFInterpreter(swf)
    interpreter.extract_function(as_bytecode, 'fill')



# Generated at 2022-06-22 09:41:29.507933
# Unit test for constructor of class SWFInterpreter