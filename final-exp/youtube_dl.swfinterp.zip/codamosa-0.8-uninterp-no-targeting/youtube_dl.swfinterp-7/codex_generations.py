

# Generated at 2022-06-22 09:33:12.645946
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    # Example
    klass = _AVMClass(0, 'Test')
    klass.register_methods({
        'initialize': 1,
        'tostring': 2})
    assert klass.method_names['tostring'] == 2
    assert klass.method_idxs[2] == 'tostring'


# Example:
#  # Push the string 'a'
#  # Get the value of variable 'a' and push it
#  # Call the method '+' on the previous two items
#  # Pop the result and store it in variable 'result'
#  bc_code = b'\x0b\x76\x61\x05\x03\x02\x00\x99\x00'
#  result = _AVMBytecode(bc_code).execute({'a': 10

# Generated at 2022-06-22 09:33:20.533703
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter()
    assert isinstance(interpreter, SWFInterpreter)
    assert interpreter.multinames == []
    assert interpreter.constant_strings == []
    assert interpreter.constant_ints == []
    assert interpreter.constant_uints == []
    assert interpreter.constant_doubles == []
    assert interpreter.constant_namespaces == []
    assert interpreter.constant_namespace_sets == []
    assert interpreter.constant_multinames == []


# Generated at 2022-06-22 09:33:23.440052
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(_AVMClass(name='foo'))) == \
        'foo#%x' % id(_AVMClass_Object(_AVMClass(name='foo')))



# Generated at 2022-06-22 09:33:25.418153
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-22 09:33:34.433697
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interp = SWFInterpreter(
        open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    class_0 = interp.extract_class(0)
    assert class_0.name == 'Object'
    assert class_0.super_name == 'Object'
    assert class_0.static_properties['DATE']
    assert class_0.static_properties['DATE'].name == 'DATE'
    assert class_0.static_properties['DATE'].super_name == 'Object'
    assert 'Date' in class_0.static_properties['DATE'].static_properties
    assert class_0.static_properties['DATE'].static_properties['Date']
    assert class_0.static_properties['DATE'].static

# Generated at 2022-06-22 09:33:35.206083
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    _ScopeDict(None)



# Generated at 2022-06-22 09:33:38.423753
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    u = _Undefined()
    assert hash(u) == 0

# Unit tests for method __bool__ of class _Undefined

# Generated at 2022-06-22 09:33:41.434463
# Unit test for constructor of class _Multiname
def test__Multiname():
    m = _Multiname(1)
    assert m.kind == 1
    assert m.__repr__() == '[MULTINAME kind: 0x1]'



# Generated at 2022-06-22 09:33:42.501169
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()



# Generated at 2022-06-22 09:33:43.976512
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass('a', 'b')
    repr(obj)



# Generated at 2022-06-22 09:34:43.546789
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    scope = _ScopeDict(object())
    scope[1] = 2
    scope[3] = 4
    print(scope)
# End of unit test for constructor of class _ScopeDict



# Generated at 2022-06-22 09:34:51.161572
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    a = _AVMClass('', '')
    assert a.name == ''
    assert a.name_idx == ''
    assert a.method_names == {}
    assert a.method_idxs == {}
    assert a.methods == {}
    assert a.method_pyfunctions == {}
    assert a.static_properties == {}
    assert a.variables == {}
    assert a.constants == {}



# Generated at 2022-06-22 09:34:56.064170
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    #
    # _AVMClass.__repr__
    #
    obj1 = _AVMClass("name_idx", "name", "static_properties")
    obj1.register_methods("methods")
    obj1.register_pyfunctions("method_pyfunctions")
    assert repr(obj1) == '_AVMClass(name)'

# Generated at 2022-06-22 09:34:58.935916
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    o = _AVMClass_Object(None)
    o.avm_class = {'name': 'avm_class'}
    assert repr(o) == 'avm_class#%x' % id(o)



# Generated at 2022-06-22 09:35:01.040101
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    obj = _AVMClass_Object(_AVMClass('ClassName', None, None, None))
    assert repr(obj) == 'ClassName#%x' % id(obj)



# Generated at 2022-06-22 09:35:02.279925
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    x = _Undefined()

    assert bool(x) == False


# Generated at 2022-06-22 09:35:10.690040
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass(0x1234, 'Foo', {'bar': 1})
    assert class_.name_idx == 0x1234
    assert class_.name == 'Foo'
    assert class_.static_properties['bar'] == 1

_AVM_Object = _AVMClass('Object', 'Object')

# Generated at 2022-06-22 09:35:18.192675
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interp = SWFInterpreter()

    f = io.BytesIO(compat_chr(0) * 4 + compat_chr(65) + compat_chr(0))
    res = interp.extract_class(f)
    assert res == ObjectClass

    f = io.BytesIO(compat_chr(0) * 4 + compat_chr(67) + compat_chr(0))
    res = interp.extract_class(f)
    assert res == ArrayClass

    f = io.BytesIO(compat_chr(0) * 4 + compat_chr(68) + compat_chr(0))
    res = interp.extract_class(f)
    assert res == StringClass


# Generated at 2022-06-22 09:35:23.998526
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass('something', [], ())
    assert c.name_idx == 'something'
    assert c.name == []
    assert c.method_names == {}
    assert c.method_idxs == {}
    assert c.methods == {}
    assert c.method_pyfunctions == {}
    assert c.static_properties == {}



# Generated at 2022-06-22 09:35:25.404689
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    pass
    

# Generated at 2022-06-22 09:36:30.018831
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    _AVMClass(0x00, 'Object')



# Generated at 2022-06-22 09:36:34.975605
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter(
        '../testdata/controls.swf',
        '../testdata/tlf-fonts.swf',
        '../testdata/tts.swf')
    assert interpreter.classes['TestCase'].static_properties['runTest']() == \
        "Test case passed"


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-22 09:36:39.654801
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    obj = _AVMClass('a', 'b')
    obj.register_methods({'c': 'd'})
    assert obj.method_names == {'c': 'd'}, repr(obj.method_names)
    assert obj.method_idxs == {'d': 'c'}, repr(obj.method_idxs)


# Generated at 2022-06-22 09:36:42.903790
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _AVMClass_Test(object):
        pass
    obj = _ScopeDict(_AVMClass_Test())
    assert repr(obj).startswith('_AVMClass_Test__Scope')



# Generated at 2022-06-22 09:36:52.203218
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    c = SWFInterpreter()

    # These opcodes are ignored:
    # pushwith
    # popscope
    # constructprop
    # setpropertylate
    # getpropertylate
    # deleteproperty
    # finddef
    # getglobalscope
    # getglobalslot
    # setglobalslot
    # convert_s
    # esc_xelem
    # esc_xattr
    # checkfilter
    # findproperty
    # findpropstrict
    # getlex
    # initproperty
    # setproperty
    # deleteproperty

    # These opcodes are unsupported:
    # ifnle
    # ifnlt
    # ifngt
    # ifnge
    # ifstricteq
    # ifstrictne
    # getdescendants
    # construct

# Generated at 2022-06-22 09:36:54.593948
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    with open('tests/data/resample.swf', 'rb') as f:
        SWFInterpreter(f)
    return True


# Generated at 2022-06-22 09:36:59.853458
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass('MyClass0', 1111, {})
    object = avm_class.make_object()
    assert repr(object) == '_AVMClass(MyClass0)#%x' % id(object)


# Generated at 2022-06-22 09:37:10.284748
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from collections import defaultdict
    from .swfdecompiler import decompile_swf

    class Method(object):
        def __init__(self, code):
            self.code = code

    class NameIndex(object):
        def __init__(self):
            self.data = defaultdict(lambda: 'dummy')

    class ABCFile(object):
        def __init__(self):
            self.classes = {}
            self.name_idx = NameIndex()

        def register_class(self, class_idx, class_abc, class_name_idx):
            self.classes[class_idx] = class_abc
            self.name_idx.data[class_name_idx] = 'c'


# Generated at 2022-06-22 09:37:13.981090
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    _ScopeDict({'a': 'b', 'c': 'd'}).__repr__()



# Generated at 2022-06-22 09:37:15.508062
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-22 09:39:23.459863
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    from .swftags import _Undefined
    assert not _Undefined()

# Testcases for method __repr__ of class _Undefined

# Generated at 2022-06-22 09:39:29.425726
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .test_swfdecompiler import test_avm2
    avm = _AVMClass(
        0,
        'test',
        static_properties={
            'x': _AVMClass_Object(test_avm2.avm_class),
            'y': '123',
        })
    obj = avm.make_object()
    assert obj.avm_class == avm
    assert obj.__class__ == _AVMClass_Object



# Generated at 2022-06-22 09:39:32.718789
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() is _Undefined()
    assert _Undefined() is not None
    assert str(_Undefined()) == 'undefined'
    assert not bool(_Undefined())
    assert bool(True)
    assert bool(1)

_undefined = _Undefined()



# Generated at 2022-06-22 09:39:38.025151
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    obj = _ScopeDict(__AVMClass__Object())
    assert repr(obj) == '__Object__Scope({})'
del test__ScopeDict___repr__

    # Unit test for class _ScopeDict

# Generated at 2022-06-22 09:39:40.301286
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


Undefined = _Undefined()



# Generated at 2022-06-22 09:39:43.562811
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    inst = _AVMClass('name', 'name')
    result = inst.make_object()
    assert isinstance(result, _AVMClass_Object)
    assert result.avm_class is inst



# Generated at 2022-06-22 09:39:53.275828
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import binascii
    bin_data = binascii.unhexlify(
        b'030023004f00700065006e00640061006e0063006500460061006e00630068006500'
        b'6e00e0034d00ffff0c00260049006e006e006f0057006f00720064007300240063'
        b'003d0030003000300030003000300030003000300030003000300030003000300'
        b'930024002c002000650078007400620069006c00240069003d0030003000300030'
        b'003000300030003000300030003000300030003000300030'
    )
    interpreter = SWFInterpreter(bin_data)
    source_func = interpreter.method

# Generated at 2022-06-22 09:39:56.683913
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(1, 'TestClass')
    print(avm_class)
    assert repr(avm_class) == '_AVMClass(TestClass)'



# Generated at 2022-06-22 09:40:01.228462
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    c = _AVMClass(None, None)
    c.static_properties['foo'] = 'Foo'
    c.constants['BAR'] = 'Bar'
    o = c.make_object()
    assert o.avm_class is c
    assert not hasattr(o, 'foo')
    assert not hasattr(o, 'BAR')
    assert o.variables == {}

# Generated at 2022-06-22 09:40:03.551291
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert _AVMClass_Object(_AVMClass_Object).avm_class == _AVMClass_Object

