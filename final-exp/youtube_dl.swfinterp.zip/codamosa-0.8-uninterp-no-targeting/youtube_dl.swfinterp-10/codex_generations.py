

# Generated at 2022-06-22 09:32:55.656985
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open('tests/data/swf_interpreter.swf', 'rb') as f:
        swf = SWFInterpreter(f)
        swf.extract_class('Main')


# Generated at 2022-06-22 09:33:06.239029
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .test import _SWFIntepreter

    inter = SWFInterpreter(_SWFIntepreter.testdata)
    assert inter.constant_int.count(1) == 5
    assert inter.constant_uint.count(0) == 5
    assert inter.constant_string.count('*') == 5
    assert inter.constant_double.count(0.0) == 5
    assert inter.constant_namespace.count(inter.constant_namespace[0]) == 5
    assert len(inter.constant_namespacesets) == 0
    assert inter.constant_multiname.count(inter.constant_multiname[0]) == 59
    assert len(inter.classes) == 26
    assert len(inter.scripts) == 2
    assert inter.avm_globals

# Generated at 2022-06-22 09:33:12.756945
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter()

    SWFInterpreter_extract_class = (lambda self, abc_class, avm_class:
                                    self.extract_class(
                                        abc_class, avm_class))
    SWFInterpreter_extract_class = (lambda self, abc_class, avm_class:
                                    self.extract_class(
                                        abc_class, avm_class))

    methods = {
        'extract_class': SWFInterpreter_extract_class,
    }
    # test_SWFInterpreter_extract_class_case_0
    arg_0 = swf_interpreter
    arg_1 = swf_interpreter.abc_classes[0]
    arg_2 = swf

# Generated at 2022-06-22 09:33:14.188996
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) is False
    assert _Undefined() == _Undefined()



# Generated at 2022-06-22 09:33:16.861441
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from ytdl.extractor.flashmedia import _AVMClass
    f = _AVMClass('foo', 'Foo', static_properties={'a':'b'})
    assert repr(f) == "_AVMClass('foo')"

# Generated at 2022-06-22 09:33:21.169502
# Unit test for constructor of class _Undefined
def test__Undefined():
    u = _Undefined()
    assert not u
    assert u == _Undefined()
    assert not (u != _Undefined())
    assert u == u
    assert not (u != u)
    assert hash(u) == 0
    assert str(u) == 'undefined'



# Generated at 2022-06-22 09:33:28.492591
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    """
    Tests for constructor of class SWFInterpreter
    """

    with open(os.path.join(os.path.dirname(__file__),
                           'test_swfinterpreter.swf'), 'rb') as f:
        interpreter = SWFInterpreter(f.read())
    assert interpreter.bytecode_version == 22
    assert interpreter.constant_ints == [0]
    assert interpreter.constant_uints == [0]
    assert interpreter.constant_doubles == [0.0]
    assert len(interpreter.constant_strings) == 1
    assert interpreter.constant_strings[0] == 'function () { return 10;};'
    assert interpreter.constant_namespaces == [
        ('package', 0, 0), ('', 1, 0)]

# Generated at 2022-06-22 09:33:40.569738
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter=SWFInterpreter()
    for _,avm_class in interpreter.avm_classes.items():
        for func_name,func in avm_class.method_pyfunctions.items():
            if func_name.startswith('_'):
                continue
            assert avm_class.method_names[func_name]['need_instance']==0
            assert len(func.__code__.co_varnames)==(avm_class.method_names[func_name]['param_count']+1)

# 3rd party module
import pyamf

# The basic idea of the flash metadata is to embed some Python objects into the AVM code:
#  - [0xC3, 'python', key1, value1, key2, value2, ...]
# where:
#  -

# Generated at 2022-06-22 09:33:47.475007
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    import inspect
    import re
    def _assert_match(pattern, string):
        assert re.search(pattern, string), (
            '%r did not match pattern %r' % (string, pattern))
    _assert_match('^\\w+#[0-9a-f]+$', repr(_AVMClass_Object(object())))
    _assert_match('^\\w+#[0-9a-f]+$', repr(_AVMClass_Object(object.__new__(_AVMClass_Object))))
    _assert_match('^\\w+#[0-9a-f]+$', repr(_AVMClass_Object(type('%s#%x' % (inspect.currentframe().f_code.co_name, id(_assert_match)), (object,), {}))))



# Generated at 2022-06-22 09:33:58.177420
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import struct

    def _read_u32(fp):
        buf = fp.read(4)
        return struct.unpack('<I', buf)[0]

    # Parse constants
    cnt = 0
    while True:
        tag = _read_byte(fp)
        if tag == 0x00:  # End
            break
        elif tag == 0x08:  # String
            length = u16()
            for i in range(length):
                _read_byte(fp)
        elif tag == 0x0A:  # Float
            fp.read(4)
        elif tag == 0x0C:  # Double
            fp.read(8)
        elif tag == 0x0D:  # Int
            fp.read(4)

# Generated at 2022-06-22 09:34:49.711089
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    instance = _AVMClass_Object('avm_class')
    assert repr(instance) == 'avm_class#%x' % id(instance)


# Generated at 2022-06-22 09:34:52.098219
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0)) == '[MULTINAME kind: 0x0]', repr(_Multiname(0))
    assert repr(_Multiname(1)) == '[MULTINAME kind: 0x1]', repr(_Multiname(1))


# Generated at 2022-06-22 09:34:56.972989
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from extractors.common import get_api_key
    api_key = get_api_key()
    if not api_key:
        raise SkipTest('This test requires an API key')

# Generated at 2022-06-22 09:34:58.782134
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():  # noqa: N802
    assert str(_Multiname(0xf)) == '[MULTINAME kind: 0xf]'



# Generated at 2022-06-22 09:35:02.486316
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(42, 'Foo', {'Bar': 43})
    assert avm_class.name_idx == 42
    assert avm_class.name == 'Foo'
    assert avm_class.static_properties == {'Bar': 43}



# Generated at 2022-06-22 09:35:06.748204
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    methods = {'foo': 234, 'bar': 534}
    cls = _AVMClass(None, 'test', methods)
    assert cls.name == 'test'
    assert cls.method_names == methods
    assert cls.method_idxs == dict(
        (idx, name) for name, idx in methods.items())



# Generated at 2022-06-22 09:35:12.208327
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass('foo', 1)
    c.register_methods({'a': 1, 'b': 2})
    return
# test__AVMClass_register_methods()

    def define_method(self, method_idx, method_body):
        self.methods[method_idx] = method_body

    def define_pyfunction(self, method_idx, pyfunc):
        self.method_pyfunctions[method_idx] = pyfunc

# Generated at 2022-06-22 09:35:14.272775
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    """Test method _AVMClass.register_methods."""
    pass
# -*- EOF: test__AVMClass_register_methods -*-


# Generated at 2022-06-22 09:35:15.724050
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x05).kind == 0x05



# Generated at 2022-06-22 09:35:27.935739
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass('name', 'name')
    assert avm_class.method_names == {}
    assert avm_class.method_idxs == {}
    assert avm_class.methods == {}
    assert avm_class.method_pyfunctions == {}
    assert avm_class.static_properties == {}
    assert avm_class.variables == {
        'avm_class': avm_class,
    }
    assert avm_class.constants == {}
    avm_class.register_methods({'foo': 1, 'bar': 2})
    assert avm_class.method_names == {
        'foo': 1,
        'bar': 2,
    }

# Generated at 2022-06-22 09:36:25.624012
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) is False
    assert hash(_Undefined()) is 0
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'
test__Undefined()



# Generated at 2022-06-22 09:36:26.625049
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


# Generated at 2022-06-22 09:36:27.626947
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0)



# Generated at 2022-06-22 09:36:30.937169
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    undefined = _Undefined()
    actual = repr(undefined)
    assert actual == 'undefined'



# Generated at 2022-06-22 09:36:31.577468
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():pass

# Generated at 2022-06-22 09:36:33.973875
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    instance = _AVMClass_Object(avm_class=None)
    r = instance.__repr__()
    assert r == '#%x' % id(instance)



# Generated at 2022-06-22 09:36:35.570480
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


_Undefined = _Undefined()



# Generated at 2022-06-22 09:36:43.980129
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-22 09:36:48.663609
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    """Unit test for SWFInterpreter.patch_function
    """
    # Test for a simple function

# Generated at 2022-06-22 09:36:49.801561
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    obj = _Undefined()
    assert isinstance(obj.__repr__(), str)


# Generated at 2022-06-22 09:37:47.982015
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    a = _AVMClass(None, None)
    assert a.__repr__().startswith('_AVMClass(')

# Generated at 2022-06-22 09:37:52.996327
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass(1, 'Test')
    assert cls.name == 'Test'
    assert cls.name_idx == 1
    assert not cls.method_names
    assert not cls.method_idxs
    assert not cls.methods
    assert not cls.method_pyfunctions
    assert not cls.static_properties
    assert not cls.variables
    assert not cls.constants



# Generated at 2022-06-22 09:37:56.255876
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() == _Undefined()


UNDEFINED = _Undefined()
NULL = None



# Generated at 2022-06-22 09:37:59.430282
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    var_repr = repr(_AVMClass('', '').make_object())
    assert var_repr == '_AVMClass()#%x' % id(var_repr)



# Generated at 2022-06-22 09:38:04.702870
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class Test(object):
        __AVMClass__ = _AVMClass_Object
    class Test_class(object):
        name = 'Test'
    assert Test().avm_class == Test_class
    assert repr(Test()) == 'Test#%x' % id(Test())
test__AVMClass_Object()



# Generated at 2022-06-22 09:38:15.503859
# Unit test for method __repr__ of class _ScopeDict

# Generated at 2022-06-22 09:38:26.852822
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # read file
    test_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(test_dir, 'test_SWFInterpreter_extract_class.swf'), 'rb') as f:
        swf = SWF(f.read())
    # extract class
    interpreter = SWFInterpreter(swf)
    avm_class = interpreter.extract_class('Test')
    # has class name
    assert avm_class.name == 'Test'
    # has super class name
    assert avm_class.superclass_name == 'Object'
    # has constructor
    assert 'Test' in avm_class.constructor_names
    # has constructor property
    assert 'constructor' in avm_class.static_properties


# Generated at 2022-06-22 09:38:29.989713
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert str(eval(repr(_AVMClass_Object(_AVMClass_Object)))
        ) == '_AVMClass_Object#%x' % id(_AVMClass_Object())



# Generated at 2022-06-22 09:38:40.879844
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    import zlib
    from hashlib import sha1

    def write_cpool(coder, cpool):
        coder.write_u16(len(cpool) + 1)
        for item in cpool:
            if isinstance(item, compat_str):
                _write_bytes_raw(coder, item.encode('utf-8'))
            else:
                coder.write_u32(item)

    def write_multiname(coder, name):
        if isinstance(name, compat_str):
            _write_bytes_raw(coder, name.encode('utf-8'))
        else:
            coder.write_u32(name)


# Generated at 2022-06-22 09:38:42.795770
# Unit test for constructor of class _Multiname
def test__Multiname():
    print(_Multiname(2))



# Generated at 2022-06-22 09:41:17.523436
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(None)) == '_AVMClass_Object#x'



# Generated at 2022-06-22 09:41:23.756019
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert len(SWFInterpreter(b'')) == 0
    assert len(SWFInterpreter(b'\x46')) == 0
    assert (len(SWFInterpreter(b'\x46\x57\x53')) == 0)
    assert (len(SWFInterpreter(b'\x46\x57\x53\x07\x1e'
                               b'\x00\x00\x00\x00\xd0\x00\x00')) == 0)

# Generated at 2022-06-22 09:41:35.274424
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    def _test_value(arg, expected_retval):
        retval = arg.register_methods(expected_retval)
        assert retval == None
        for key in expected_retval:
            assert arg.method_names.get(key, None) == expected_retval[key]
            assert arg.method_idxs[expected_retval[key]] == key
        return expected_retval

    _test_value(_AVMClass('', None), {0: 1})
    _test_value(_AVMClass('', None), {0: 1})
    _test_value(_AVMClass('', None), {0: 1})
    _test_value(_AVMClass('', None), {0: 1})
    _test_value(_AVMClass('', None), {0: 1})