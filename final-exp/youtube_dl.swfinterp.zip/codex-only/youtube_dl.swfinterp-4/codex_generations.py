

# Generated at 2022-06-24 14:21:20.722500
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__(): pass


UNDEFINED = _Undefined()



# Generated at 2022-06-24 14:21:29.448749
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open('test/assets/sample1.swf', 'rb') as f:
        swf = f.read()
        interpreter = SWFInterpreter(swf)
        avm_class = interpreter.extract_class(
            '1', 'flash.external.ExternalInterface')
        assert avm_class.instance_name == 'flash.external.ExternalInterface'
        assert avm_class.init_properties == {}
        assert avm_class.static_properties == {}
        assert avm_class.method_names == ['addCallback']
        assert avm_class.method_pyfunctions['addCallback'] is not None



# Generated at 2022-06-24 14:21:30.650638
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    return _Undefined().__hash__() == 0

# Generated at 2022-06-24 14:21:41.026884
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swfdump import dump_swf
    from .swfdump import StringIO
    from .utils import int_to_string

    for name in sorted(dump_swf.swf_versions):
        swf_version = dump_swf.swf_versions[name]
        swf_version_str = int_to_string(swf_version)

        f = StringIO()
        f.write(b'CWS')
        f.write(bytes((swf_version, )))
        f.write(b'\x00\x00')
        f.write(b'\x65\x65\x66\x66')
        f.write(int_to_string(swf_version, 5))

        # A magic do_nothing method that returns its argument
        # It is used to verify that the extracted

# Generated at 2022-06-24 14:21:42.636483
# Unit test for constructor of class _Multiname
def test__Multiname():
    if _Multiname(0xd) != _Multiname(0xd):
        assert False


# Generated at 2022-06-24 14:21:43.698811
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    return _Undefined() == False


# Generated at 2022-06-24 14:21:47.767054
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    raise NotImplementedError()
test__Undefined___bool__.func_annotations = {}

# Generated at 2022-06-24 14:21:49.345314
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert _Undefined().__hash__() == 0

# Generated at 2022-06-24 14:21:50.423184
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    _ScopeDict(object())



# Generated at 2022-06-24 14:21:58.845316
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():

    # Arrange
    swf_interpreter = SWFInterpreter()

    # Try a case of simple function

# Generated at 2022-06-24 14:22:00.446706
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    ac = _AVMClass('name', 'name', {})
    ac.make_object()

# Generated at 2022-06-24 14:22:03.787295
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert bool(_Undefined()) is False
    assert len({_Undefined(): 'foo', _Undefined(): 'bar'}) == 1

undefined = _Undefined()


# Generated at 2022-06-24 14:22:07.118866
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0).__repr__() == '[MULTINAME kind: 0x0]'
    assert _Multiname(1).__repr__() == '[MULTINAME kind: 0x1]'



# Generated at 2022-06-24 14:22:09.449937
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(None)) == 'None#%x' % id(_AVMClass_Object(None))



# Generated at 2022-06-24 14:22:10.596073
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()



# Generated at 2022-06-24 14:22:17.365025
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    data = open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb').read()
    swf = SWF(BytesIO(data), parse_body=False)

    interpreter = SWFInterpreter(swf)
    interpreter.patch_function('_init')
    assert interpreter.extract_function(interpreter.avm_classes[0], '_init')



# Generated at 2022-06-24 14:22:23.280313
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cl = _AVMClass(0, 'Foo', {'a': 'b'})
    assert cl.name_idx == 0
    assert cl.name == 'Foo'
    assert cl.static_properties == {'a': 'b'}
    assert cl.variables == {}
    assert cl.constants == {}
    assert cl.make_object().avm_class == cl
    cl.method_names = {'a': 'b'}
    cl.method_idxs = {'b': 'a'}
    cl.methods = {'a': 'b'}



# Generated at 2022-06-24 14:22:26.939773
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    c = _AVMClass_Object()
    assert c.__repr__() == '<class \'__main__._AVMClass_Object\'>#x'
    c.avm_class = c
    assert c.__repr__() == '<class \'__main__._AVMClass_Object\'>#x'



# Generated at 2022-06-24 14:22:29.887546
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    from .utils import compat_str

    assert compat_str(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'
    assert compat_str(_Multiname(0x0d)) == '[MULTINAME kind: 0xd]'



# Generated at 2022-06-24 14:22:32.533638
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    avm_class = AVMClass('Test', [], 'Test')
    obj = _AVMClass_Object(avm_class)
    assert repr(obj) == 'Test#%x' % id(obj)


# Generated at 2022-06-24 14:22:38.027044
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    return
    # First try a function declared in the class
    interpreter = SWFInterpreter()
    interpreter.swf_header = {
        'flashVersion': 18,
        'fileLength': 50,
    }

# Generated at 2022-06-24 14:22:41.054065
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    # Test whether _Undefined() is hashable
    m = {}
    m[_Undefined()] = 1
    return m.keys()
global_undefined = _Undefined()



# Generated at 2022-06-24 14:22:44.746787
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from yalix import yalcompiler
    avm_class = _AVMClass(-1, 'Class')
    avm_class.register_methods({
        'foo': 1,
        'bar': 2})
    assert avm_class.method_idxs == {
        1: 'foo',
        2: 'bar'}
test__AVMClass_register_methods()

# Generated at 2022-06-24 14:22:51.232113
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(None, '')
    avm_class.register_methods({'test1': 1, 'test2': 2})
    assert avm_class.method_names == {'test1': 1, 'test2': 2}
    assert avm_class.method_idxs == {1: 'test1', 2: 'test2'}


# Generated at 2022-06-24 14:22:57.231388
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_name = 'Object'

    # Create a class and a new object
    avm_class = _AVMClass(class_name, None)
    o = _AVMClass_Object(avm_class)

    # Make sure we can access the __class__ property
    assert o.__class__ == avm_class

    # Make sure __repr__ is sane
    assert repr(o) == '%s#%x' % (class_name, id(o))



# Generated at 2022-06-24 14:22:58.674302
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    undef = _Undefined()
    assert repr(undef) == undef.__repr__()
Undefined = _Undefined()



# Generated at 2022-06-24 14:23:01.013502
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .helper import make_fake_swf
    assert SWFInterpreter(make_fake_swf()).extract_function(None, 'a') == 'a'

""" Abstraction for AS3 class, with methods and static properties
"""


# Generated at 2022-06-24 14:23:02.063987
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:23:10.496005
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(name_idx='name_idx', name='name')
    assert avm_class.name_idx == 'name_idx'
    assert avm_class.name == 'name'
    assert isinstance(avm_class.variables, _ScopeDict)



# Generated at 2022-06-24 14:23:13.358255
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    assert (str(_AVMClass(0, 'name')) ==
            '_AVMClass(name)')
    assert (str(_AVMClass(0, 'name', static_properties={'foo': 'bar'})) ==
            '_AVMClass(name)')



# Generated at 2022-06-24 14:23:14.652759
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    a = _AVMClass('Foo', None, {})
    assert a.name == 'Foo'



# Generated at 2022-06-24 14:23:26.439673
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    if True:
        # Test name_idx
        avm_class = _AVMClass(123, 'Foo')
        assert avm_class.name_idx == 123

        # Test name
        avm_class = _AVMClass(123, 'Foo')
        assert avm_class.name == 'Foo'

        # Test static_properties
        avm_class = _AVMClass(123, 'Foo', {'Bar': 456})
        assert avm_class.name == 'Foo' and avm_class.static_properties['Bar'] == 456

    if True:
        # Test method_names
        avm_class = _AVMClass(123, 'Foo')
        assert avm_class.method_names == {}


# Generated at 2022-06-24 14:23:27.406602
# Unit test for constructor of class _Undefined
def test__Undefined():
    return _Undefined() == _Undefined()



# Generated at 2022-06-24 14:23:29.738081
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    print(_ScopeDict(None))
    print(_ScopeDict(None, {'a': 'A'}))
test__ScopeDict___repr__()



# Generated at 2022-06-24 14:23:32.753908
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    """_Multiname.__repr__(...) -> str"""
    m = _Multiname(0)
    assert (m.__repr__()
            == '[MULTINAME kind: 0x0]')



# Generated at 2022-06-24 14:23:39.596639
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(
        name_idx=0, name='testclass')
    avm_class.register_methods({
        'test1': 1,
        'test2': 2,
    })
    assert isinstance(avm_class.method_names, dict)
    assert avm_class.method_names['test1'] == 1
    assert avm_class.method_names['test2'] == 2
    assert avm_class.method_idxs[1] == 'test1'
    assert avm_class.method_idxs[2] == 'test2'
# tests for class _AVMClass end



# Generated at 2022-06-24 14:23:46.949192
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .test_utils import assert_equal
    from . import avm
    m = avm.AVMFile.load('tests/avm', [])
    s = _ScopeDict(m.classes['tests.abcd'])
    assert_equal(repr(s), """tests.abcd__Scope({})""")
    s['x'] = 3
    assert_equal(repr(s), """tests.abcd__Scope({'x': 3})""")
    s['y'] = 4
    assert_equal(repr(s), """tests.abcd__Scope({'y': 4, 'x': 3})""")



# Generated at 2022-06-24 14:23:48.495033
# Unit test for constructor of class _Multiname
def test__Multiname():
    m = _Multiname(0)


# Generated at 2022-06-24 14:23:52.289870
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    test_obj = _Undefined()
    expected = 'undefined'
    actual = test_obj.__repr__()
    assert expected == actual
test__Undefined___repr__()

# Generated at 2022-06-24 14:23:54.349740
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) is False
undefined = _Undefined()



# Generated at 2022-06-24 14:23:56.078843
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert _Undefined() == _Undefined()
    assert not(_Undefined() == 42)

undefined = _Undefined()



# Generated at 2022-06-24 14:23:57.981273
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert isinstance(bool(_Undefined()), bool)

Undefined = _Undefined()



# Generated at 2022-06-24 14:24:09.527701
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .flash_player_parser import FlashPlayerParser
    from .flash_player_parser import _TagDefineSprite
    from .flash_player_parser import _TagDefineButton2
    from .flash_player_parser import _TagPlaceObject2
    fp = FlashPlayerParser(
        tags=[
            _TagDefineSprite('sprite', chars=[
                _TagDefineButton2('button', action_data='\x00')]),
            _TagPlaceObject2(
                'sprite',
                depth=1,
                matrix_data='\x00\x00\x00\x00\x00\x00\x00\x00\x00'),
        ])
    assert fp.avm_class_by_name['Button'].make_object() is not None



# Generated at 2022-06-24 14:24:13.927243
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    for value in (None, 0, 'null', 'undefined'):
        assert hash(value) == hash(_Undefined())
try:
    hash(None)
except TypeError:
    # Python 3
    pass
else:
    # Python 2
    def test__Undefined___hash___python2():
        assert hash(None) == hash(_Undefined())


_undefined = _Undefined()



# Generated at 2022-06-24 14:24:21.530467
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from flash_proxy import gen_flash_proxy
    from flash_proxy import SWFInterpreter

    def test_decrypt(args):
        return ''.join(reversed(args[0]))

    swf = gen_flash_proxy()
    avm = SWFInterpreter(swf)
    avm.extract_function(avm.builtin_classes['String'], 'String', test_decrypt)

    assert avm.evaluate('String("abc")') == 'cba'


# Generated at 2022-06-24 14:24:27.945814
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    global found_classes
    found_classes = set()

    class AVMClass(object):
        def __init__(self, name):
            self.name = name
            found_classes.add(name)

    class_hello = AVMClass('hello')

    assert repr(_AVMClass_Object(class_hello)) == 'hello#%x' % id(class_hello)



# Generated at 2022-06-24 14:24:32.156386
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    inte = SWFInterpreter()
    inte.patch_function(
        'function(args:Array):String {return "foo";}', 'foo', 'String')


# Class used to rename classes and variables into the JS world

# Generated at 2022-06-24 14:24:34.711418
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    instance0 = _Undefined()
    test_value = instance0.__repr__()
    expected_value = 'undefined'
    assert test_value == expected_value, test_value

    return

# Generated at 2022-06-24 14:24:43.727791
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    from .rtmp_yael_client import _Undefined
    from nose.tools import assert_equals, raises
    assert_equals(_Undefined.__hash__(None), 0)
    assert_equals(hash(_Undefined), 0)
    assert_equals(hash((1, _Undefined)), 1)
    assert_equals(hash([1, _Undefined]), 1)
    assert_equals(hash({1: _Undefined}), 1)
_UNDEF = _Undefined()



# Generated at 2022-06-24 14:24:52.712023
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    name = '_AVMClass_register_methods_name'

    methods = {
        'method_name': 200,
    }
    class_obj = _AVMClass(5, name, {'property': 5})

    assert class_obj.method_names == {}
    assert class_obj.method_idxs == {}
    assert class_obj.methods == {}
    assert class_obj.method_pyfunctions == {}

    class_obj.register_methods(methods)

    assert class_obj.method_names == methods
    assert class_obj.method_idxs == {200: 'method_name'}
    assert class_obj.methods == {}
    assert class_obj.method_pyfunctions == {}



# Generated at 2022-06-24 14:24:53.561649
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert True

# Generated at 2022-06-24 14:24:58.472108
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    # setUp
    # Test
    actual = repr(_Undefined())
    # Verify
    assert actual == 'undefined', \
        'repr(_Undefined()) is %r, not %r' % (actual, 'undefined')
test__Undefined___repr__()



# Generated at 2022-06-24 14:25:00.649333
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined(), 'not _Undefined()'
Undefined = _Undefined()



# Generated at 2022-06-24 14:25:13.251159
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Testing SWFInterpreter.__init__()
    source = open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               'test.swf'), 'rb').read()
    i = SWFInterpreter(source)

# Generated at 2022-06-24 14:25:24.257783
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-24 14:25:31.665738
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avmclass = _AVMClass(1, 'Test', static_properties={'x': 1})
    avmclass.register_methods({'a': 2, 'b': 3})
    assert avmclass.method_names == {'a': 2, 'b': 3}
    assert avmclass.method_idxs == {2: 'a', 3: 'b'}
test__AVMClass_register_methods()


# Generated at 2022-06-24 14:25:32.644208
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0).kind == 0
    assert _Multiname(100).kind == 100
# End of unit test



# Generated at 2022-06-24 14:25:34.385231
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:25:38.222898
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class MyAVMClass(object):
        def __init__(self):
            self.name = 'MyAVMClass'

    test_obj = _AVMClass_Object(MyAVMClass())
    assert repr(test_obj) == 'MyAVMClass#%x' % id(test_obj)

# Generated at 2022-06-24 14:25:44.199860
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class_n = _AVMClass(None, None)
    class_n.register_methods({'method1': 1, 'method2': 2})
    assert class_n.method_names == {'method1': 1, 'method2': 2}
    assert class_n.method_idxs == {1: 'method1', 2: 'method2'}


_avm_type_handlers = {}



# Generated at 2022-06-24 14:25:54.471276
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf.tag import DoABC
    from .swf.abc import ABCFile
    from .swf.abc.abc_data import ConstantPool, ConstantMultiname, ConstantMultiname_QName, ConstantMultiname_RTQName, ConstantGetter, ConstantSetter
    from .swf.abc.abc_trait import TraitMethod
    from .swf.abc.abc_method_body import MethodBody
    avm2_parser = SWFInterpreter()
    avm2_parser.avm2_abc_files[0] = ABCFile()

# Generated at 2022-06-24 14:26:07.866094
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    constant_pool = []
    constant_pool.append(None)
    constant_pool.append(None)
    constant_pool.append(None)
    constant_pool.append(None)
    constant_pool.append('getProperty')
    constant_pool.append(None)
    constant_pool.append(None)
    constant_pool.append(None)
    constant_pool.append('Object')
    constant_pool.append(None)
    constant_pool.append(None)
    constant_pool.append('getProperty')
    constant_pool.append(None)
    constant_pool.append(None)
    constant_pool.append(None)
    constant_pool.append('getProperty')
    constant_pool.append(None)
    constant_pool.append(None)
    constant_pool.append(None)

# Generated at 2022-06-24 14:26:10.736169
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _AVMClass(object):
        name = 'test'
    _ScopeDict(_AVMClass()).__repr__()
    assert True



# Generated at 2022-06-24 14:26:19.793736
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-24 14:26:21.788480
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    obj = _ScopeDict(None)
    assert isinstance(repr(obj), compat_str)


# Generated at 2022-06-24 14:26:25.211558
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    class_ = _AVMClass(None, None)
    assert str(class_)
    class_.name = 'ClassName'
    assert str(class_)
# test__AVMClass___repr__()



# Generated at 2022-06-24 14:26:33.200624
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    cls = _AVMClass('SomeClass', {'m1': 0x1001, 'm3': 0x1003})
    cls.register_methods({'m2': 0x1002, 'm4': 0x1004})
    assert cls.method_names == {'m1': 0x1001, 'm2': 0x1002, 'm3': 0x1003, 'm4': 0x1004}
    assert cls.method_idxs == {0x1001: 'm1', 0x1002: 'm2', 0x1003: 'm3', 0x1004: 'm4'}



# Generated at 2022-06-24 14:26:40.921066
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    code = b'\x01\x00\x07\x00\x00\x00\x00\x00\x01\x00'
    swf = SWF(BytesIO(code))
    swf.read_header()
    swf.read_tag_code_and_length()
    assert swf.file.read() == b''
    assert swf.file.tell() == len(code)



# Generated at 2022-06-24 14:26:49.441022
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    import copy

    class AVMClass(object):
        name = 'TestClass'

    class TestClass(_AVMClass_Object):
        avm_class = AVMClass
        pass

    t = TestClass()
    t.__dict__['a'] = 1
    t.__dict__['b'] = 2
    t.__dict__['c'] = 3
    t.__dict__['d'] = 4

    s = _ScopeDict(AVMClass)
    for v in t.__dict__.values():
        s[v] = v
    assert s.a == 1
    assert s.b == 2
    assert s.c == 3
    assert s.d == 4

    s2 = copy.copy(s)
    s2.a = 5
    assert s2.a == 5

# Generated at 2022-06-24 14:26:53.123093
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    d = _ScopeDict(None)
    assert repr(d) == 'None__Scope({})', repr(d)
    d['hello'] = 'world'
    assert repr(d) == 'None__Scope({\'hello\': \'world\'})', repr(d)

# Generated at 2022-06-24 14:26:55.077747
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    obj = _AVMClass_Object(None)
    obj.avm_class.name = 'foo'
    obj.id = lambda: 0xffffffff
    assert repr(obj) == 'foo#ffffffff'



# Generated at 2022-06-24 14:26:57.051861
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert str(object()) == str(_Undefined())
undefined = _Undefined()



# Generated at 2022-06-24 14:27:05.317675
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swf_utils import open_swf_as_fileobj
    from .swf_tags import DoAction
    from .swf_movie import FlashMovie
    import struct

    # Compile an SWF with the Python code
    #     player = this.getPlayer();
    #     trace(typeof(player));

# Generated at 2022-06-24 14:27:06.562935
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    obj = _ScopeDict(None)
    assert repr(obj) == 'None__Scope({})'



# Generated at 2022-06-24 14:27:16.078625
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import zlib
    from base64 import b64decode
    from collections import namedtuple, Counter
    from io import BytesIO
    from .amf import AMF0, AMF0Error

    def _fake_dl(url):
        assert url == ('http://www.cntv.cn/videos/'
                       'used/tvplay/data/20120719/100004.js')
        res = b64decode(
            'eJxLTEwso0lWV7TI0SU1JUjZOUlJXSkpOT0lKSzJQUkepKe1wgAAB0+jdAA==')
        res = zlib.decompress(res)
        return res


# Generated at 2022-06-24 14:27:17.430770
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert False, "Unimplemented"


# Generated at 2022-06-24 14:27:21.850987
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    undefined = _Undefined()
    assert repr(undefined) == 'undefined'

Undefined = _Undefined()



# Generated at 2022-06-24 14:27:27.900652
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(0, 'Test')
    methods = {'test1': 1, 'test2': 2, 'test3': 3}
    avm_class.register_methods(methods)
    assert avm_class.method_names == methods
    assert avm_class.method_idxs == dict(
        (idx, name) for name, idx in methods.items())



# Generated at 2022-06-24 14:27:40.942954
# Unit test for method __repr__ of class _Multiname

# Generated at 2022-06-24 14:27:49.242874
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    input_data = b'\x46\x57\x53\x09\x00\x00\x00\x01\x66\x00\x03\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    output_data = '_AVMClass(Object)'
    i = _AVMClass(None, 'Object')
    assert i._AVMClass__repr__() == output_data


# Generated at 2022-06-24 14:27:50.685743
# Unit test for constructor of class _Undefined
def test__Undefined():
    _Undefined()
test__Undefined()
Undefined = _Undefined()



# Generated at 2022-06-24 14:27:55.524188
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert ('%s#%x' % (test__AVMClass_Object.avm_class.name, id(_AVMClass_Object(test__AVMClass_Object.avm_class)))) == 'test__AVMClass_Object#' + hex(id(_AVMClass_Object(test__AVMClass_Object.avm_class)))
test__AVMClass_Object.avm_class = None



# Generated at 2022-06-24 14:27:57.434009
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # assert False # TODO: implement your test here
    SWFInterpreter.patch_function()
    pass


# Generated at 2022-06-24 14:28:03.432927
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() == _Undefined(), '_Undefined() is not a singleton'
    assert not _Undefined(), '!_Undefined()'
    assert str(_Undefined()) == 'undefined', 'str(_Undefined())'


_undefined = _Undefined()

_double_words = (
    'constant_pool',
    'method_info',
    'metadata_info',
    'instance_info',
    'class_info',
    'script_info',
    'method_body',
)

# Generated at 2022-06-24 14:28:05.205278
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


Undefined = _Undefined()



# Generated at 2022-06-24 14:28:12.567916
# Unit test for constructor of class _Undefined
def test__Undefined():
    def assert_undef_equality(fst, snd):
        assert fst == snd
        assert fst is not snd
        assert fst is snd

    assert_undef_equality(_Undefined(), _Undefined())
    assert_undef_equality(None, _Undefined())
    assert_undef_equality(_Undefined(), None)
    assert _Undefined() == None
    assert None == _Undefined()

    assert not _Undefined()

_undefined = _Undefined()
del test__Undefined



# Generated at 2022-06-24 14:28:13.518731
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__(): assert _Undefined().__hash__() == 0



# Generated at 2022-06-24 14:28:17.580715
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    """
    Returns a string representing the object.
    """
    obj = _AVMClass()
    assert repr(obj) == '_AVMClass()'


# Generated at 2022-06-24 14:28:19.515200
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined == eval(_Undefined.__repr__())
_Undefined = _Undefined()



# Generated at 2022-06-24 14:28:30.419124
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from yalafi.defs import init_definitions
    from yalafi.parser import Parser
    from yalafi.macros import MacroCode
    plain_macros = MacroCode(init_definitions('plain'))
    latex_macros = MacroCode(init_definitions('latex'))
    parser = Parser(plain_macros, latex_macros)
    avm_class = _AVMClass(0, 'AvmClass')
    avm_class.register_methods({'getURL': 1})
    avm_class.register_methods({'getBytesLoaded': 6})
    assert avm_class.method_names == {
        'getURL': 1,
        'getBytesLoaded': 6,
    }

# Generated at 2022-06-24 14:28:30.977986
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    pass

# Generated at 2022-06-24 14:28:34.260718
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = _AVMClass('', '').make_object()
    assert isinstance(obj, _AVMClass_Object)

# Generated at 2022-06-24 14:28:35.260491
# Unit test for constructor of class _Multiname
def test__Multiname():
    return _Multiname(0)


# Generated at 2022-06-24 14:28:37.923714
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert _AVMClass_Object(_AVMClass_Object).__repr__()\
        == '_AVMClass_Object#%x' % id(_AVMClass_Object(_AVMClass_Object))



# Generated at 2022-06-24 14:28:44.574697
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class_ = _AVMClass(123, 'test')
    methods = {
        'test': 456,
    }
    class_.register_methods(methods)
    assert hasattr(class_, 'method_names')
    assert isinstance(class_.method_names, dict)
    assert class_.method_names == methods

    assert hasattr(class_, 'method_idxs')
    assert isinstance(class_.method_idxs, dict)
    assert class_.method_idxs == {456: 'test'}
# Test method register_methods for class _AVMClass with parameters:
#   methods:
#       test: 456
# Result:
#   {'test': 456}
#   test: 'test'



# Generated at 2022-06-24 14:28:46.037704
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-24 14:28:49.233120
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert len({_Undefined(): 1}) == 0
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'



# Generated at 2022-06-24 14:28:57.861235
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    def test_method(self):
        return self.avm_class.name
    original_method = _AVMClass_Object.__repr__
    _AVMClass_Object.__repr__ = test_method
    b = _AVMClass_Object(None)
    assert repr(b) == ''
    c = _AVMClass_Object(AVMClass({b'name': b'foo'}))
    assert repr(c) == 'foo'
    _AVMClass_Object.__repr__ = original_method
test__AVMClass_Object___repr__()



# Generated at 2022-06-24 14:29:00.499611
# Unit test for constructor of class _Undefined
def test__Undefined():
    a = _Undefined()
    b = _Undefined()
    assert a is b


_undefined = _Undefined()



# Generated at 2022-06-24 14:29:02.231109
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    _AVMClass('', {'foo': 'bar'})



# Generated at 2022-06-24 14:29:08.032668
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter('AVMGlue.as')
    class_name = 'com.adobe.flascc.CModule'
    avm_class = swf_interpreter.extract_class(class_name)

# Generated at 2022-06-24 14:29:14.463126
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    _avm_class = _AVMClass(
        name_idx=42,
        name='Test_AVMClass',
        static_properties=[],
    )
    _test_object = _avm_class.make_object()
    assert isinstance(_test_object, _AVMClass_Object), type(_test_object)
    assert _test_object.avm_class == _avm_class
    assert repr(_test_object) == 'Test_AVMClass#%x' % id(_test_object)



# Generated at 2022-06-24 14:29:18.197832
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    expected = 'undefined'
    actual = repr(_Undefined())
    assert actual == expected, (
        'Wrong result %r instead of %r' % (actual, expected))

# Generated at 2022-06-24 14:29:25.957429
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    test_avm_class = _AVMClass()
    test_avm_class.name = 'ZOOM'
    test_scopedict = _ScopeDict(test_avm_class)
    test_scopedict['PROTON'] = 42
    test_scopedict['NEUTRON'] = 'gluon'
    assert(repr(test_scopedict) ==
        "ZOOM__Scope({'PROTON': 42, 'NEUTRON': 'gluon'})")



# Generated at 2022-06-24 14:29:30.298438
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    '''
    >>> class_object = _AVMClass_Object(avm_class=None)
    >>> print(class_object.__repr__())
    >>> class_object.avm_class = 'name'
    >>> print(class_object.__repr__())
    name#...
    '''
    pass



# Generated at 2022-06-24 14:29:34.383193
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    filepath = 'test/smile-v10.swf'
    _SWFInterpreter(filepath)


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-24 14:29:39.388884
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(0, 'MyClass', {'a': 1, 'b': 2})
    assert c.name_idx == 0
    assert c.name == 'MyClass'
    assert c.methods == {}
    assert c.method_names == {}
    assert c.static_properties == {'a': 1, 'b': 2}


_tag_handlers = {}



# Generated at 2022-06-24 14:29:42.440098
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.init()


# Generated at 2022-06-24 14:29:51.607668
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    for i in range(10):
        cls = _AVMClass(0, '')
        obj = cls.make_object()
        assert obj is not None, 'obj is None'
        assert isinstance(obj, _AVMClass_Object), \
            'obj is a %s' % (obj.__class__.__name__,)
        assert obj.avm_class is cls, 'obj.avm_class is not cls'
        assert repr(obj) == '_AVMClass(%s)#%x' % (cls.name, id(obj)), \
            'unexpected object representation %r' % (repr(obj),)

# Generated at 2022-06-24 14:29:56.244986
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    a = [_Multiname(0x07)]
    assert str(a) == '[_Multiname(kind=7)]'
    assert repr(a) == '[[_Multiname(kind=7)]]'
    a = _Multiname(0x0d)
    assert str(a) == '[_Multiname(kind=13)]'
    assert repr(a) == '[_Multiname(kind=13)]'



# Generated at 2022-06-24 14:29:59.968896
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    x = _Undefined()
    assert not x
    assert not bool(x)
    assert not x.__bool__()
    assert not x.__nonzero__()


Undefined = _Undefined()



# Generated at 2022-06-24 14:30:12.652024
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .amf0 import AMF0
    from .SWF import SWF
    from .tag_data import TagData
    from .tag_import_assets import TagImportAssets
    from .tag_script_limits import TagScriptLimits
    from .tag_set_background_color import TagSetBackgroundColor


# Generated at 2022-06-24 14:30:19.522237
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    klass = _AVMClass(1, 'test')
    assert len(klass.method_names) == 0
    assert len(klass.method_idxs) == 0
    klass.register_methods({'test': 2})
    assert len(klass.method_names) == 1
    assert len(klass.method_idxs) == 1
    assert klass.method_names['test'] == 2



# Generated at 2022-06-24 14:30:23.639707
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert not bool(_Undefined())
    assert len(set([_Undefined()])) == 1
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'
test__Undefined()



# Generated at 2022-06-24 14:30:28.429446
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), 'dump',
        'tests', 'fixtures', 'test.swf')
    with open(path, 'rb') as f:
        swf = SWF(f)
    interpreter = SWFInterpreter(swf)
    return interpreter


# Generated at 2022-06-24 14:30:29.803050
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x0f).kind == 0x0f



# Generated at 2022-06-24 14:30:31.185679
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()) == False

# Generated at 2022-06-24 14:30:37.459001
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    cls = _AVMClass('test', None)
    cls.register_methods({
        'foo': 1,
        'bar': 2,
        'baz': 3,
    })
    assert cls.method_names == {
        'foo': 1,
        'bar': 2,
        'baz': 3,
    }
    assert cls.method_idxs == {
        1: 'foo',
        2: 'bar',
        3: 'baz',
    }



# Generated at 2022-06-24 14:30:44.375944
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import tempfile
    swf = _load_test_swf('video_starts_and_stops.swf')
    class_name = 'StartsAndStops'
    tmp_path = tempfile.mkdtemp(prefix='pyswf_unittest_')
    try:
        interp = SWFInterpreter(swf)
        interp.extract_class(class_name, tmp_path)
    finally:
        shutil.rmtree(tmp_path)

# Generated at 2022-06-24 14:30:49.414129
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    return repr(_AVMClass_Object(AVMClass()))



# Generated at 2022-06-24 14:30:59.165894
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    myclass_str = 'Test'
    str_attribute = 'a'
    str_attribute_value = 'b'
    myclass = _AVMClass(myclass_str)
    myclass.attributes['a'] = _AVMClassAttribute(None, myclass_str)
    instance = _AVMClass_Object(myclass)
    assert (instance.avm_class.name == myclass_str), 'Object must contain a reference to %r class' % myclass_str
    setattr(instance, str_attribute, str_attribute_value)
    assert (getattr(instance, str_attribute) == str_attribute_value), 'Object must correctly set attribute'



# Generated at 2022-06-24 14:31:09.542058
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():

# SWFInterpreter.extract_deobfuscated_method
    def extract_deobfuscated_method(self, avm_class, func_name):
        # I am not sure this function works correctly
        def resfunc(args):
            global stack
            stack = args

            registers = args
            global registers

            code_cursor = 0
            global code_cursor

            # Ideally, we would substitute local
            # variables for registers, but for now we
            # assume that registers are used only for locals
            coder = self.method_codes[func_name]

            def _read_byte(bytestream):
                global code_cursor
                code_cursor += 1
                return bytestream.read(1)


# Generated at 2022-06-24 14:31:19.757891
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class _Testing_SWFInterpreter(SWFInterpreter):
        def __init__(self):
            super(_Testing_SWFInterpreter, self).__init__(debug_read=None)
            # self.debug_read = None
            self.debug_read_file = open(
                get_testdatapath('test.swf'), 'rb')
            self.debug_read_coder = SWF.StreamReader(
                self.debug_read_file)
            self.debug_read_end = self.debug_read_coder.tell()
            self.debug_read_coder.seek(0)
            self.debug_write_file = open(
                get_testdatapath('test_dump.swf'), 'wb')
            self.debug_write_coder = SWF.StreamWriter