

# Generated at 2022-06-24 14:21:23.608049
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class _AVMClass(object):
        name = 'foo'
    scope = _ScopeDict(_AVMClass())
    scope[1] = 2
    assert repr(scope) == 'foo__Scope({1: 2})'



# Generated at 2022-06-24 14:21:25.166333
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__(): pass


_undefined = _Undefined()



# Generated at 2022-06-24 14:21:27.829459
# Unit test for constructor of class _Multiname
def test__Multiname():
    print(repr(_Multiname(0x07)))

MULTINAME_TYPENAMES = {
    0x00: 'QName',
    0x07: 'Multiname',
}



# Generated at 2022-06-24 14:21:35.913362
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import rtmp
    from .rtmp import SWF_CONSTANTS
    from .swfdec import SWF

    f = open(os.path.join(os.path.dirname(__file__), 'test', 'sample.swf'), 'rb')
    SWFData = f.read()
    f.close()

    swf = SWF(SWFData, SWF_CONSTANTS)
    interpreter = SWFInterpreter(swf, rtmp)
    return interpreter


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-24 14:21:37.277855
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:21:43.329874
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class TestClass(object):
        def __init__(self, name):
            self.name = name
    assert repr(_AVMClass_Object(TestClass('TestClass'))) == 'TestClass#%x' % id(_AVMClass_Object(TestClass('TestClass')))



# Generated at 2022-06-24 14:21:50.405717
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    print('Test for method register_methods')
    class Class:
        pass
    test_class = Class()
    test_class.name = 'test'
    test_class.method_names = {}
    test_class.method_idxs = {}
    test_class.register_methods({'a': 0, 'b': 1, 'c': 2, 'd': 3})
    expected_method_names = {'a': 0, 'b': 1, 'c': 2, 'd': 3}
    assert test_class.method_names == expected_method_names, (
        'Test failed - test_class.method_names = %r, expected_method_names = %r'
        % (test_class.method_names, expected_method_names))

# Generated at 2022-06-24 14:21:51.942139
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    return testinterface._ObjectTest('_Undefined', '__bool__').test()

# Generated at 2022-06-24 14:21:53.502086
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    obj = _Undefined()
    return bool(obj) == False

# Generated at 2022-06-24 14:21:54.914705
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x07).kind == 0x07



# Generated at 2022-06-24 14:21:56.446873
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    obj = _ScopeDict(None)
    expected = None
    actual = obj.__repr__()
    assert expected == actual, 'Expected %r, got %r' % (expected, actual)



# Generated at 2022-06-24 14:21:58.707406
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    o = _Undefined()
    if o:
        raise Exception(o)
    if o.toString():
        raise Exception(o)
_Undefined = _Undefined()



# Generated at 2022-06-24 14:22:01.627541
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_object = _AVMClass_Object(None)
    assert repr(class_object) == 'None#%x' % id(class_object)
test__AVMClass_Object()



# Generated at 2022-06-24 14:22:05.398284
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class TestClass(object):
        pass
    test_class = TestClass()
    test_instance = _AVMClass_Object(test_class)
    assert test_instance.avm_class == test_class



# Generated at 2022-06-24 14:22:06.343887
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    pass


# Generated at 2022-06-24 14:22:08.987407
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    # type: () -> None
    assert bool(_Undefined()) is False
Undefined = _Undefined()



# Generated at 2022-06-24 14:22:12.553840
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    t = _AVMClass_Object(None).__repr__()
    assert type(t) == str
    assert t[0] == '_'
    assert t[-1] == 'x'



# Generated at 2022-06-24 14:22:13.652840
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert False, "Not implemented."


# Generated at 2022-06-24 14:22:22.404004
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    import unittest
    class _Multiname___repr__Tester(unittest.TestCase):
        def test__Multiname___repr__(self):
            # self.failUnlessRaises(
            #     NotImplementedError,
            #     lambda: self.do__Multiname___repr__())
            self.do__Multiname___repr__()
        def do__Multiname___repr__(self):
            m = _Multiname(0x70)
            self.assertTrue(isinstance(m, _Multiname))
            self.assertEqual(m.__repr__(), '[MULTINAME kind: 0x70]')
    unittest.main()



# Generated at 2022-06-24 14:22:23.837248
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    s = _Undefined()
    assert str(s) == 'undefined'

# Generated at 2022-06-24 14:22:27.561481
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class _AVMClass(object):
        name = 0x4657
    obj = _AVMClass_Object(_AVMClass())
    assert obj.avm_class.name == 0x4657
    assert repr(obj) == '0x4657#%x' % id(obj)
test__AVMClass_Object()



# Generated at 2022-06-24 14:22:30.968412
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    m = _AVMClass(0, 'Siuh')
    m.register_methods({'Luh': 0, 'Iuh': 5})
    assert m.method_idxs == {0: 'Luh', 5: 'Iuh'}
    assert m.method_names == {'Luh': 0, 'Iuh': 5}



# Generated at 2022-06-24 14:22:31.722906
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-24 14:22:34.109695
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(_AVMClass('')).__repr__() == '__Scope({})'
    assert _ScopeDict(_AVMClass(''), __x=1).__repr__() == '__Scope({\'__x\': 1})'



# Generated at 2022-06-24 14:22:34.911099
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    o = _Undefined()
    return o

# Generated at 2022-06-24 14:22:41.009037
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    assert repr(
        _AVMClass(
            name_idx=0, name='test__AVMClass.TestClass',
            static_properties={'static_prop': 0}
        )
    ) == '_AVMClass(test__AVMClass.TestClass)'



# Generated at 2022-06-24 14:22:42.650295
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(type(_AVMClass_Object))) == 'type#83800e0'


# Generated at 2022-06-24 14:22:44.174491
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert_equal(repr(_Multiname(0x0d)), '[MULTINAME kind: 0x0d]')


# Generated at 2022-06-24 14:22:50.904795
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class Test1(object):
        def __init__(self):
            self.var = 0
        def method(self):
            self.var = 1

    class Test2(object):
        def __init__(self):
            self.var = 0
        def method(self):
            self.var = 2

    avmi = SWFInterpreter()
    avmi.patch_function(Test1, 'method', lambda: None)

    t1, t2 = Test1(), Test2()
    t1.method()
    t2.method()

    assert t1.var == 0
    assert t2.var == 2


# Generated at 2022-06-24 14:23:00.357538
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .abc_ import AbcFile
    from .abc_ import AbcConstantPool
    from .abc_ import CONSTANT_AnyName
    from .abc_ import CONSTANT_Double
    from .abc_ import CONSTANT_Int
    from .abc_import import classes_from_abc
    from .abc_import import methods_from_abc
    from .abc_import import members_from_abc
    
    class _Interpreter(compat_abc.ABC):
        def __init__(self, swf, avm2_class, func_name):
            self.swf = swf
            self.avm2_class = avm2_class
            self.func_name = func_name
            

# Generated at 2022-06-24 14:23:03.732775
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-24 14:23:14.297156
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from collections import namedtuple
    from .swftags import SWFDefineBinaryDataTag
    from .swf import SWF

    class AVMClass(object):
        def __init__(self, name):
            self.name = name
            self.method_names = []

    class AVMClass_Object(object):
        def __init__(self, avm_class):
            self.avm_class = avm_class

    class SWFReader(object):
        def __init__(self, swf):
            self.swf = swf
            self.seek = self.swf.f.seek
            self.tell = self.swf.f.tell
            self.read = self.swf.f.read


# Generated at 2022-06-24 14:23:26.311077
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-24 14:23:29.099429
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass(17, 'someclass')
    assert avm_class.make_object().avm_class == avm_class
test__AVMClass_make_object()


# Generated at 2022-06-24 14:23:31.035413
# Unit test for constructor of class _AVMClass
def test__AVMClass(): assert _AVMClass('Foo') == _AVMClass('Foo')



# Generated at 2022-06-24 14:23:33.236842
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    a = _ScopeDict(None)
    a['a'] = 1
    assert repr(a) == 'None__Scope({\'a\': 1})'



# Generated at 2022-06-24 14:23:34.598949
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'

# Generated at 2022-06-24 14:23:39.802603
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = _AVMClass('Foo', 'foo', {}).make_object()
    assert repr(obj.avm_class) == '_AVMClass(foo)', repr(obj.avm_class)
test__AVMClass_make_object()



# Generated at 2022-06-24 14:23:42.291563
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not bool(_Undefined())
    assert len(str(_Undefined())) != 0
    assert 0 == hash(_Undefined())
    assert 0 != hash(None)



# Generated at 2022-06-24 14:23:47.865072
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    v_test__ScopeDict___repr__0 = _AVMClass_Object(None)
    v_test__ScopeDict___repr__1 = _ScopeDict(v_test__ScopeDict___repr__0)
    v_test__ScopeDict___repr__1['A'] = v_test__ScopeDict___repr__0
    t_test__ScopeDict___repr__0 = repr(v_test__ScopeDict___repr__1)
    print(t_test__ScopeDict___repr__0)

# Generated at 2022-06-24 14:23:53.905557
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from yalix.context import Context
    ctx = Context()
    avm_class = _AVMClass(0, 'TextInput')
    obj = avm_class.make_object()
    assert repr(obj) == 'TextInput#%x' % id(obj)


# Generated at 2022-06-24 14:23:56.707157
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class EmptyClass:
        name = 'EmptyClass'

    obj = _AVMClass_Object(EmptyClass)
    assert repr(obj) == 'EmptyClass#%x' % id(obj)



# Generated at 2022-06-24 14:24:03.593242
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Note that this is not a real unit-test but a way to make sure
    # that the AVM extraction works
    import os
    import shutil

    def mkdir_quiet(dir):
        try:
            os.mkdir(dir)
        except OSError:
            pass

    mkdir_quiet('youtube_js')
    mkdir_quiet('youtube_js/avm2')
    mkdir_quiet('youtube_js/avm2/builtin')
    mkdir_quiet('youtube_js/avm2/generated')

    def write_file(fname, text):
        with open(os.path.join(
                'youtube_js/avm2/generated', fname), 'w') as outf:
            outf.write(text)


# Generated at 2022-06-24 14:24:05.878237
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(object)) == 'object#%x' % id(object)


# Generated at 2022-06-24 14:24:06.826943
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # TODO: Write unit test
    pass


# Generated at 2022-06-24 14:24:10.702299
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    undefined = _Undefined()
    assert repr(undefined).startswith('<_Undefined ')

    assert undefined is not _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:24:13.198850
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert (
        _Undefined() == _Undefined()
        and _Undefined() is _Undefined()
        and _Undefined() == None
        and _Undefined() is None)



# Generated at 2022-06-24 14:24:18.162091
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    # See http://docs.python.org/2/library/collections#collections.OrderedDict

    from .compat import unittest

    class _Class(object):
        name = 'test_classname'
    class Test___repr__(unittest.TestCase):
        def runTest(self):
            self.assertEqual(
                repr(_ScopeDict(_Class())),
                'test_classname__Scope({})')

    Test___repr__().runTest()
test__ScopeDict___repr__()



# Generated at 2022-06-24 14:24:19.411276
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert (
        repr(_AVMClass_Object(_AVMClass_Object)) ==
        '_AVMClass_Object#0x%x' % id(_AVMClass_Object))


# Generated at 2022-06-24 14:24:26.785151
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    import yaml
    source = u"""
      properties:
        # TODO: Maybe make it possible to have more than one of these?
        strings:
          - unbound_text_field
          - text_field
        arrays:
          - list_item_renderer
        objects:
          - unbound_text_field
          - text_field
          - list_item_renderer
    """
    for v in yaml.load(source).values():
        for key in v:
            if key not in globals():
                globals()[key] = _AVMClass(key, key)
    assert repr(
        globals()[key].make_object()) == '_AVMClass(list_item_renderer)#%x' % id(
        globals()[key].make_object())



# Generated at 2022-06-24 14:24:36.710165
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .avm2 import parse_script_info
    si = parse_script_info(b'''<?xml version="1.0"?>
<swf><scripts><doABC name="test"><![CDATA[
function f() {
  var x = 1;
  var y = 2;
  return x + y;
}
]]></doABC></scripts></swf>''')
    si_class = si.classes[0]
    this_scope = _ScopeDict(si_class)
    this_scope.update({'x': 1, 'y': 2})
    assert (repr(this_scope) ==
        '%s__Scope(%s)' % (si_class.name, this_scope))
# end of unit test for method __repr__ of class _ScopeDict



# Generated at 2022-06-24 14:24:43.594067
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert _Multiname(0x07).__repr__() == '[MULTINAME kind: 0x7]'
    assert _Multiname(0x0d).__repr__() == '[MULTINAME kind: 0xd]'
    assert _Multiname(0x0f).__repr__() == '[MULTINAME kind: 0xf]'



# Generated at 2022-06-24 14:24:53.325590
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    global abc_data
    global interpreter
    global avm_class
    global MovieClipClass
    global StringClass
    global ArrayClass
    global undefined

    global _AVMClass

    global _builtin_classes
    _builtin_classes['MovieClip'] = MovieClipClass

    _AVMClass = type('AVMClass', (object,), {})
    interpreter = SWFInterpreter(abc_data)

    interpreter.interpret_function(
        avm_class, 'ctor', [])
    assert avm_class.variables['clips'] == []

    avm_class.variables['clips'] = [undefined]
    print(interpreter.interpret_function(
        avm_class, 'get_numChildren', []))
    print(avm_class.variables['clips'])
   

# Generated at 2022-06-24 14:24:56.732862
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0, '_Undefined().__hash__() is different from 0'


# Generated at 2022-06-24 14:24:57.321381
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__(): pass



# Generated at 2022-06-24 14:25:01.584260
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = _read_swf_extern(open(os.path.join('test', 'sample.swf')))
    interpreter = SWFInterpreter(swf)
    interpreter.extract_function(interpreter.script, 'decode')
    

# Generated at 2022-06-24 14:25:13.946568
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    import string
    import random
    from .swfdecompiler import _AVMClass
    def get_chars(length):
        return ''.join(
            random.choice(string.ascii_letters)
            for _ in range(length))

    # Generated random strings for usage as names for methods of a
    # mock AVM class
    random_method_names = [
        '_'.join((get_chars(10), get_chars(15)))
        for _ in range(random.randint(6, 12))]
    # The same names are used as indices (offsets)
    random_indices = {
        name: random.randint(-500, 1000)
        for name in random_method_names}
    # The methods are ordered by random index

# Generated at 2022-06-24 14:25:24.971348
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF

    swf = SWF(BytesIO(b'''
        FWS
        0003
        00000
        00000
        0000
    '''))


# Generated at 2022-06-24 14:25:34.106996
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    obj = _ScopeDict(_AVMClass_Object(object()))
    assert repr(obj) == '_AVMClass_Object#1f8c6d0__Scope({})'
    obj['a'] = 1
    assert repr(obj) == '_AVMClass_Object#1f8c6d0__Scope({\'a\': 1})'
    obj['b'] = 2
    assert repr(obj) == '_AVMClass_Object#1f8c6d0__Scope({\'a\': 1, \'b\': 2})'



# Generated at 2022-06-24 14:25:45.436630
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():

    class _AVMClass_Object(object):
        def __init__(self, avm_class):
            self.avm_class = avm_class

        def __repr__(self):
            return '%s#%x' % (self.avm_class.name, id(self))

    class _AVMClass(object):
        def __init__(self, name_idx, name):
            self.name_idx = name_idx
            self.name = name

        def make_object(self):
            return _AVMClass_Object(self)

    obj = _AVMClass(0, 'foo').make_object()
    assert 'foo#%x' % id(obj) == repr(obj)



# Generated at 2022-06-24 14:25:56.690680
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swfbytes = b'\x46\x57\x53\x09\x00\x00\x00\x00\x00\x00\x00\x42'
    swf = SWFInterpreter(BytesIO(swfbytes))
    assert swf.major_version == 9
    assert swf.minor_version == 0
    assert swf.length == 18
    assert swf.framerate == 0.0
    assert swf.framelimit == 0
    assert swf.file_size == 18
    assert swf.constant_pool == []
    assert len(swf.method_bodies) == 1
    body = swf.method_bodies[0]
    assert body.method == 0
    assert body.max_stack == 0
    assert body.local_count == 0


# Generated at 2022-06-24 14:26:03.030651
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class Class(object):
        def __init__(self, name):
            self.name = name
    c = Class('Foo')
    d = _ScopeDict(c)
    d['a'] = 'b'
    assert repr(d) == "Foo__Scope({'a': 'b'})"
test__ScopeDict()



# Generated at 2022-06-24 14:26:04.291389
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    c = _Multiname(0x03)
    assert repr(c) == '[MULTINAME kind: 0x3]'



# Generated at 2022-06-24 14:26:05.349046
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    a = _Undefined()
    b = _Undefined()
    assert hash(a) == hash(b)



# Generated at 2022-06-24 14:26:06.467416
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    pass



# Generated at 2022-06-24 14:26:17.431547
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open(os.path.join(os.path.dirname(__file__), 'data', 'helloworld.swf')) as f:
        interpreter = SWFInterpreter(f)


# Generated at 2022-06-24 14:26:21.638867
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass(1, 'cls', dict(
        one=1, two=2))
    assert cls.name == 'cls'
    assert cls.variables == dict(
        one=1, two=2)



# Generated at 2022-06-24 14:26:29.655012
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass(name_idx=1, name='SomeClass')

    assert class_.name_idx == 1
    assert class_.name == 'SomeClass'
    assert isinstance(class_.variables, _ScopeDict)
    assert class_.variables.avm_class == class_
    assert class_.constants == {}

    # Make sure the variables scope dict is initialized properly
    assert isinstance(class_.variables, dict)
    assert class_.variables == {}


Tag = collections.namedtuple('Tag', 'type code data')



# Generated at 2022-06-24 14:26:34.617367
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    arg = random.sample(range(0, 100), 1)[0]
    assert type(_Multiname(arg)) == _Multiname
    assert repr(_Multiname(arg)) == '[MULTINAME kind: 0x%x]' % arg
test__Multiname___repr__()


# Generated at 2022-06-24 14:26:36.386832
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == 'undefined'

# Generated at 2022-06-24 14:26:40.176911
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    _AVMClass_instance = _AVMClass(
        name_idx=None,
        name=None,
        static_properties=None)
    _AVMClass_instance.make_object()



# Generated at 2022-06-24 14:26:47.670617
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    filename = 'files/metadata.swf'
    filename = 'files/samples/swf_ch1_115x75_1000.swf'
    filename = 'files/samples/swf_ch1_88x72_100.swf'
    filename = 'files/samples/swf_ch1_110x86_100.swf'
    filename = 'files/samples/swf_ch1_220x172_100.swf'
    filename = 'files/samples/swf_ch1_220x172_1000.swf'
    filename = 'files/samples/swf_video_flv_fp9_1500.swf'
    filename = 'files/samples/swf_video_flv_fp9_2000.swf'

# Generated at 2022-06-24 14:26:49.738621
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x0D) == _Multiname(0x0D)



# Generated at 2022-06-24 14:26:53.448625
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_Object = _AVMClass_Object(_AVMClass('Object', 0x3f))
    assert class_Object.avm_class.name == 'Object'
    assert repr(class_Object) == 'Object#%x' % id(class_Object)



# Generated at 2022-06-24 14:27:02.874328
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    import unittest2
    from .utils import FakeMultiname

    class Test(_Multiname):
        pass

    _test = unittest2.TestCase()
    _test.assertEqual(repr(Test(0x01)), '[MULTINAME kind: 0x1]')
    _test.assertEqual(repr(Test(0x02)), '[MULTINAME kind: 0x2]')
    _test.assertEqual(repr(Test(0x09)), '[MULTINAME kind: 0x9]')
    _test.assertEqual(repr(Test(0x0e)), '[MULTINAME kind: 0xe]')
    _test.assertEqual(repr(Test(0x0f)), '[MULTINAME kind: 0xf]')
    _test.assertEqual

# Generated at 2022-06-24 14:27:04.752094
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-24 14:27:06.970632
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_object = _AVMClass_Object('')
    assert repr(class_object) == u'#%x' % id(class_object)
    assert class_object.avm_class == ''



# Generated at 2022-06-24 14:27:10.262610
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass('test', 0)
    c.register_methods({'test': 0})

    assert c.method_names == {'test': 0}
    assert c.method_idxs == {0: 'test'}



# Generated at 2022-06-24 14:27:16.753351
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    from .test_extract import os_mock
    os_mock.open_mock('test.swf', b'\x00\x00\x00\x00')  # Sane file header

    class_hierachy = collections.OrderedDict()
    top_class = _AVMClass(None, '', static_properties={
        'swf_version': 10,
        'frame_size': (1024, 768),
        'frame_count': 3,
        'frame_rate': 30.0,
    })
    class_hierachy['_root'] = top_class

    # Test constructor of class _AVMClass
    assert top_class.name == '_root'
    assert top_class.name_idx is None
    assert top_class.method_names == {}
    assert top_class

# Generated at 2022-06-24 14:27:29.252376
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import pprint
    interp = SWFInterpreter()
    with open(
            'tests/swf/Amf3Test.swf', 'rb') as f:
        tagstream = TagStream(f)
        tagstream.skip_until_tag(68)
        swf = tagstream.read_swf()

    # DefineClass

# Generated at 2022-06-24 14:27:32.187948
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass(0, "")
    repr = obj.__repr__()


# Generated at 2022-06-24 14:27:33.756447
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()) is False

# Generated at 2022-06-24 14:27:35.951198
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    try:
        _Undefined().__hash__()
        assert True
    except:
        assert False

# Generated at 2022-06-24 14:27:37.459711
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
UNDEFINED = _Undefined()



# Generated at 2022-06-24 14:27:49.123946
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():

    # Tested SWFInterpreter with sample SWFs
    swf = open(test_cases / 'sample_swf/uncompressed_empty.swf', 'rb').read()

    for action in get_swf_actions(swf):
        try:
            break
        except Exception as exception:
            if not isinstance(exception, NotImplementedError):
                raise
            else:
                continue
    else:
        raise Exception('No actions found to test extract_function')

    interpreter = SWFInterpreter()
    interpreter.multinames = [
        'concat',
        'push',
        'join',
        'undefined',
        'split',
        'slice',
        'String',
        'length',
        'charCodeAt',
        'length',
    ]
    interpreter.constant

# Generated at 2022-06-24 14:27:50.909646
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
test__Undefined___bool__()


Undefined = _Undefined()



# Generated at 2022-06-24 14:27:57.984390
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    avm_class_object_init = _AVMClass_Object.__init__
    def __init__(self, avm_class):
        print('__init__: %r' % (self, ))
        print('__init__: %r is %r' % (avm_class, avm_class.name))
        avm_class_object_init(self, avm_class)
    _AVMClass_Object.__init__ = __init__
    _AVMClass_Object('_AVMClass_Object')
    _AVMClass_Object.__init__ = avm_class_object_init



# Generated at 2022-06-24 14:28:11.982466
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    doc_class = _AVMClass(0x42, 'doc')
    assert doc_class.name == 'doc'
    assert doc_class.name_idx == 0x42
    assert doc_class.method_names == {}
    assert doc_class.method_idxs == {}
    assert doc_class.methods == {}
    assert doc_class.method_pyfunctions == {}
    assert isinstance(doc_class.variables, _ScopeDict)

    assert repr(doc_class.variables) == 'doc__Scope({})'
    doc_class.variables.update({'v1': 0x1337, 'v2': 0x42})
    assert repr(doc_class.variables) == 'doc__Scope({\'v1\': 4919, \'v2\': 66})'
    assert doc_

# Generated at 2022-06-24 14:28:21.955037
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import re

# Generated at 2022-06-24 14:28:32.005897
# Unit test for constructor of class _AVMClass

# Generated at 2022-06-24 14:28:37.975813
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) is False
    assert hash(_Undefined()) == 0
    assert bool(not _Undefined()) is True
    assert bool(_Undefined() is None) is False
    assert bool(_Undefined() is _Undefined()) is True
    assert bool(_Undefined() == _Undefined()) is False
    assert bool(_Undefined() != _Undefined()) is True
    assert str(_Undefined()) == 'undefined'



# Generated at 2022-06-24 14:28:40.703917
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    c = _AVMClass('test')
    v = _AVMClass_Object(c)
    assert isinstance(v, object)
    assert repr(v) == 'test#%x' % id(v)



# Generated at 2022-06-24 14:28:44.563271
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter('examples/test_methods.swf')
    interpreter.patch_function('BaseClass', 'func1')


# Generated at 2022-06-24 14:28:54.502958
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import os
    path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'swfs/sample1-supported-min.swf')
    with open(path, 'rb') as f:
        swf_interpreter = SWFInterpreter(f)

    assert isinstance(swf_interpreter, SWFInterpreter)
    assert isinstance(swf_interpreter.abc_header, _ScriptInfo)
    assert isinstance(swf_interpreter.abc_methods, tuple)
    assert isinstance(swf_interpreter.method_bodies, tuple)
    assert isinstance(swf_interpreter.constant_pool, tuple)

# Generated at 2022-06-24 14:28:57.755381
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() == _Undefined()
    assert hash(_Undefined()) == hash(_Undefined())
    assert not _Undefined()
    assert str(_Undefined()) == 'undefined'

_undefined = _Undefined()



# Generated at 2022-06-24 14:29:09.472487
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .bitstream import BitStream
    from .parse_abc import parse_abc
    from .swf_build import build_swf
    from .swf_build import make_do_abc_tag
    from .AVMClass import AVMClass
    from .AVMClass import AVMClasses
    from .AVMClass import AVMClassesCollection
    from .AVMClass import AVMString
    from .AVMClass import AVMNumber
    from .AVMClass import AVMUndefined
    from .AVMClass import AVMBoolean
    from .AVMClassAssembler import AVMClassAssembler
    from .AVMBytecode import AVMBytecode


# Generated at 2022-06-24 14:29:13.362279
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert _Undefined().__hash__() == _Undefined().__hash__()

Undefined = _Undefined()

_MethodSignature = collections.namedtuple(
    '_MethodSignature',
    ['name', 'param_count', 'return_type', 'param_types'])



# Generated at 2022-06-24 14:29:19.669545
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Setup
    dct = dict()
    dct['class_info'] = [(1, 1),
                         (2, 2, 0),
                         (3, 3, 0, 1),
                         (4, 4, 0, 1, 2),
                         (5, 5, 0, 1, 2, 3),
                         (6, 6, 0, 1, 2, 3, 4)]

# Generated at 2022-06-24 14:29:25.659931
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    obj = _AVMClass('name_idx', 'name')
    obj.register_methods({'a': 1, 'b': 2})
    assert obj.method_names == {'a': 1, 'b': 2}
    assert obj.method_idxs == {1: 'a', 2: 'b'}
# test__AVMClass_register_methods()



# Generated at 2022-06-24 14:29:33.536990
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # This file is taken from a real SWF file
    infile = open('../testfile.swf', 'rb')

    from .swfread import SWFReader
    swf = SWFReader()
    swf.parse(infile)
    infile.close()

    # TODO test this on more files
    for tag in swf.tags:
        if tag['tag_type'] == SWFReader.TAG_DEFINE_SCRIPT:
            si = SWFInterpreter(
                tag['actions'].actions,
                tag['actions'].constant_pool,
                tag['actions'].method_info,
                tag['actions'].multinames)
            si.extract_function(si.avm_class, 'main')
            si.run()


# Define a custom object

# Generated at 2022-06-24 14:29:35.814388
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(0x42)
    assert repr(obj) == '[MULTINAME kind: 0x42]'



# Generated at 2022-06-24 14:29:37.495266
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert _AVMClass_Object(_AVMClass('dummy')).__repr__() == 'dummy#<Id>'


# Generated at 2022-06-24 14:29:38.375340
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()



# Generated at 2022-06-24 14:29:43.912374
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    a = _AVMClass(0, b'')
    a.register_methods({b'foo': 5})
    assert a.method_names == {b'foo': 5}
    assert a.method_idxs == {5: b'foo'}
    b = _AVMClass(0, b'')
    b.register_methods({b'foo': 5, b'bar': 10})
    assert b.method_names == {b'foo': 5, b'bar': 10}
    assert b.method_idxs == {5: b'foo', 10: b'bar'}




# Generated at 2022-06-24 14:29:45.721440
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    _Undefined()

_undefined = _Undefined()



# Generated at 2022-06-24 14:29:46.344296
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    pass



# Generated at 2022-06-24 14:29:47.777239
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    d = _Undefined()
    assert d and not d

# Generated at 2022-06-24 14:29:56.259282
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .avm2lib import ABCFile
    abc_file = ABCFile.from_abc_string(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    class_scope = abc_file.get_avm_class('Class')
    scope = _ScopeDict(class_scope)
    scope[1] = 2
    assert repr(scope) == 'Class__Scope({1: 2})'
# End of unit test for method __repr__ of class _ScopeDict



# Generated at 2022-06-24 14:30:00.427259
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert _Multiname(0x1).__repr__() == '[MULTINAME kind: 0x1]'
    assert _Multiname(0x3ff).__repr__() == '[MULTINAME kind: 0x3ff]'



# Generated at 2022-06-24 14:30:06.577724
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass(None, 'TestClass')
    obj = avm_class.make_object()
    assert obj is not None
    assert obj.__class__.__name__ == '_AVMClass_Object'
    assert obj.avm_class.name == 'TestClass'

# Generated at 2022-06-24 14:30:19.779900
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler

    def _get_file(name):
        filename = os.path.join(os.path.dirname(__file__), '_swfs/' + name)
        return open(filename, 'rb')

    with _get_file('alchemy.swf') as f:
        swf = SWFDecompiler(BytesIO(f.read()))

    with _get_file('alchemy.abc') as f:
        abc = ABCFile(BytesIO(f.read()))

    avm = SWFInterpreter(swf, abc)
    avm_class = avm.extract_class('Vector')
    assert str(avm_class) == 'Vector'

# Generated at 2022-06-24 14:30:21.364476
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
test__Undefined___bool__()

# Generated at 2022-06-24 14:30:23.020338
# Unit test for constructor of class _Multiname
def test__Multiname():
    return _Multiname(0x07) == _Multiname(0x07)



# Generated at 2022-06-24 14:30:31.690603
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import pyamf

    class TestClass(object):
        pass

    avm_obj = TestClass()
    avm_obj.prop = 'test'

    interpreter = SWFInterpreter()
    interpreter.patch_function(avm_obj, 'test', ['arg'], 'return arg;')

    assert avm_obj.test('hello') == 'hello'

    amf3 = pyamf.encode(avm_obj, encoding=pyamf.AMF3).getvalue()
    assert amf3 == b'\x0a\x05-test\x06\x07test\x0b\x01\x01'

    avm_obj2 = pyamf.decode(amf3, encoding=pyamf.AMF3).next()

# Generated at 2022-06-24 14:30:33.971848
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(_AVMClass(None, 'Foo'))) == 'Foo#5d9b5d0'



# Generated at 2022-06-24 14:30:35.357521
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    avm_class = _AVMClass('')



# Generated at 2022-06-24 14:30:40.879463
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    my_class = _AVMClass(name='MyClass', properties=['foo'])
    scope_dict = _ScopeDict(my_class)
    scope_dict['foo'] = 'bar'
    scope_dict['bar'] = 'baz'
    print(scope_dict)
    assert repr(scope_dict) == "MyClass__Scope({'foo': 'bar', 'bar': 'baz'})"



# Generated at 2022-06-24 14:30:50.628749
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-24 14:30:52.778539
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(0)
    try:
        assert repr(obj) is None
    except NotImplementedError:
        pass



# Generated at 2022-06-24 14:30:57.921519
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    avm_class = _AVMClass('test_avm_class')
    scope_dict = _ScopeDict(avm_class)
    assert repr(scope_dict) == 'test_avm_class__Scope({})'
test__ScopeDict()



# Generated at 2022-06-24 14:31:00.790593
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm_interpreter = SWFInterpreter()
    avm_interpreter.extract_function('Main', 'main')


# Generated at 2022-06-24 14:31:05.148046
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from . import utils
    self = SWFInterpreter(utils.get_test_data_path('soundCloud.swf'))

    self.extract_function(self.classes['soundCloudConfig'], 'getConfig')

# Test for method get_extracted_python_code of class SWFInterpreter

# Generated at 2022-06-24 14:31:08.350330
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class_ = _AVMClass(0, 'TestClass')
    assert isinstance(class_.make_object(), _AVMClass_Object)
    assert class_.make_object().avm_class is class_



# Generated at 2022-06-24 14:31:11.670798
# Unit test for constructor of class _Undefined
def test__Undefined():
    _ = _Undefined()
    assert _Undefined() is not _
    assert len(set([_Undefined(), _Undefined(), _Undefined()])) == 1
    assert hash(_Undefined()) == 0
    assert bool(_Undefined()) is False
    assert not _Undefined()



# Generated at 2022-06-24 14:31:15.487717
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    Inter = SWFInterpreter('test.swf')
    AVMClass = Inter.extract_class()
    assert AVMClass.static_properties['foo'] == 'bar'

# Generated at 2022-06-24 14:31:22.602875
# Unit test for constructor of class _Undefined
def test__Undefined():
    class TestClass(object):
        def __init__(self):
            self.data1 = _Undefined()
            self.data2 = None

        def __bool__(self):
            return self.data1 and self.data2

        __nonzero__ = __bool__

    obj = TestClass()
    assert not obj


_undefined = _Undefined()
_null = None

