

# Generated at 2022-06-24 14:21:23.033361
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(0, 'test')
    assert c
    assert 'test' in repr(c)



# Generated at 2022-06-24 14:21:24.988625
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    _Multiname(0).__repr__()

# Generated at 2022-06-24 14:21:27.557530
# Unit test for constructor of class _Undefined
def test__Undefined():
    # Make sure _Undefined is not False
    if _Undefined():
        assert False, '_Undefined should be False'

_undefined = _Undefined()



# Generated at 2022-06-24 14:21:31.664877
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass(0, 'my-avm-class', {'a': 1, 'b': 2})
    obj = avm_class.make_object()
    assert obj.avm_class is avm_class
    assert repr(obj) == 'my-avm-class#%x' % id(obj)

# Generated at 2022-06-24 14:21:41.967507
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swfdata = binascii.unhexlify(b'43535746')  # CSWF
    swf = SWFInterpreter(swfdata)
    cs = swf.constant_strings
    assert cs == [
        '_level0',
        'createEmptyMovieClip',
        'MovieClip',
        'onLoad',
        'onUnload',
    ]

    assert swf.constant_namespaces == {
        0: '',
        2: 'public',
        3: 'protected',
        4: 'internal',
        5: 'private',
        6: 'protected internal',
        7: 'package-private',
    }

# Generated at 2022-06-24 14:21:44.276973
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    test_object = _AVMClass('fake_name').make_object()
    assert test_object.avm_class.name == 'fake_name'


# Generated at 2022-06-24 14:21:47.456506
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    u = _Undefined()
    assert hash(u) == 0

# Generated at 2022-06-24 14:21:52.138126
# Unit test for constructor of class _Undefined
def test__Undefined():
    u = _Undefined()
    assert u is not None
    assert not u
    assert not bool(u)
    assert u != u
    assert u is not u
    assert u == _Undefined()
    assert str(u) == 'undefined'
    assert repr(u) == 'undefined'

_undefined = _Undefined()



# Generated at 2022-06-24 14:21:55.236890
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    assert _AVMClass('name',0,'name',{}).make_object()=='_AVMClass_Object(name#%x)'%id('_AVMClass_Object(name#%x)')

# Generated at 2022-06-24 14:21:56.352212
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    return _Undefined().__repr__()

# Generated at 2022-06-24 14:21:57.652399
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert 0 == hash(_Undefined())

Undefined = _Undefined()



# Generated at 2022-06-24 14:21:59.289798
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()



# Generated at 2022-06-24 14:22:10.314598
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    
    class FakeAVMClass(object):
        def __init__(self, name_idx, name, static_properties=None):
            self.name_idx = name_idx
            self.name = name
            self.method_names = {}
            self.method_idxs = {}
            self.methods = {}
            self.method_pyfunctions = {}
            self.static_properties = static_properties if static_properties else {}

            self.variables = _ScopeDict(self)
            self.constants = {}

    obj1 = FakeAVMClass(0, '', )
    methods = {'foobar': 0, }
    obj1.register_methods(methods)
    assert obj1.method_names == {'foobar': 0, }

# Generated at 2022-06-24 14:22:14.553638
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    AVM = _AVMClass('Foo', 'Foo')
    obj = AVM.make_object()
    assert obj.avm_class == AVM
    assert repr(obj) == 'Foo#%x' % id(obj)

# Generated at 2022-06-24 14:22:15.974453
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    assert _AVMClass(1, 'Sprite')



# Generated at 2022-06-24 14:22:17.019903
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():  # TODO
    pass



# Generated at 2022-06-24 14:22:24.341685
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    class SWFInterpreterTest(SWFInterpreter):
        def __init__(self, *args, **kwargs):
            super(SWFInterpreterTest, self).__init__(*args, **kwargs)
            self._read_method_bodies_called = False

        def _read_method_bodies(self):
            super(SWFInterpreterTest, self)._read_method_bodies()
            self._read_method_bodies_called = True
    with open(os.path.join(os.path.dirname(__file__), 'flashdump.swf'), 'rb') as swf_file:
        swf = SWFInterpreterTest(swf_file)
    assert swf._read_method_bodies_called


# Generated at 2022-06-24 14:22:26.100265
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0).kind == 0
    assert _Multiname(0x11).kind == 0x11


# Generated at 2022-06-24 14:22:27.640385
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
_Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:22:31.074011
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    M = _Multiname
    assert repr(M(0x07)) == '[MULTINAME kind: 0x7]'
    assert repr(M(0x0d)) == '[MULTINAME kind: 0xd]'
    assert repr(M(0x09)) == '[MULTINAME kind: 0x9]'



# Generated at 2022-06-24 14:22:34.246107
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class AVMClass(object):
        name = 'AVMClass'
    a = _AVMClass_Object(AVMClass)
    if not a.avm_class is AVMClass:
        raise Exception('_AVMClass_Object.__init__')
    if not repr(a) == 'AVMClass#0x%x' % id(a):
        raise Exception('_AVMClass_Object.__repr__')


# Generated at 2022-06-24 14:22:44.318425
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avmc = _AVMClass('foo', 0)
    avmc.register_methods({'bar': 1})
    assert avmc.method_names == {'bar': 1}
    assert avmc.method_idxs == {1: 'bar'}
    avmc.register_methods({'baz': 2, 'bing': 3})
    assert avmc.method_names == {'bar': 1, 'baz': 2, 'bing': 3}
    assert avmc.method_idxs == {1: 'bar', 2: 'baz', 3: 'bing'}



# Generated at 2022-06-24 14:22:46.860803
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    return 'undefined'

    def __eq__(self, other):
        return isinstance(other, _Undefined)

# Generated at 2022-06-24 14:22:51.032245
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert _Multiname(0).__repr__() == '[MULTINAME kind: 0x0]'
    assert _Multiname(0x42).__repr__() == '[MULTINAME kind: 0x42]'

# Generated at 2022-06-24 14:22:53.433009
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class _AVMClass_ObjectClass_0(object):
        name = '_AVMClass_ObjectClass_0'

    assert repr(_AVMClass_Object(_AVMClass_ObjectClass_0())) == '_AVMClass_ObjectClass_0#%x' % id(_AVMClass_ObjectClass_0())



# Generated at 2022-06-24 14:23:02.190868
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from . import flash_proxy, format_utils

# Generated at 2022-06-24 14:23:03.712227
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == 'undefined'



# Generated at 2022-06-24 14:23:11.849556
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass(0, 'TestClass')
    assert cls.name == 'TestClass'
    assert len(cls.method_names) == 0
    assert len(cls.method_idxs) == 0
    assert len(cls.methods) == 0
    assert len(cls.static_properties) == 0
    assert len(cls.variables) == 0
    assert len(cls.constants) == 0
    cls = _AVMClass(0, 'TestClass', {'a': 0, 'b': 1})
    assert cls.name == 'TestClass'
    assert len(cls.method_names) == 0
    assert len(cls.method_idxs) == 0
    assert len(cls.methods) == 0

# Generated at 2022-06-24 14:23:15.253788
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = _AVMClass('test.Test', 'Test').make_object()
    assert obj.avm_class.name == 'test.Test', obj.avm_class.name

# Generated at 2022-06-24 14:23:17.105243
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__(): assert 'undefined' == _Undefined().__repr__()


# Generated at 2022-06-24 14:23:25.154125
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    avm_class = _AVMClass('test', None)
    inst = avm_class(object())
    inst.__dict__['scope'] = _ScopeDict(avm_class)
    inst.__dict__['scope']['foo'] = 'bar'
    assert repr(inst) == 'test#0'
    assert repr(inst.__dict__['scope']) == "test__Scope({'foo': 'bar'})"
    assert inst.__dict__['scope']['foo'] == 'bar'


# Generated at 2022-06-24 14:23:30.053312
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    m = _AVMClass(None, None)
    assert not m.method_names
    assert not m.method_idxs
    assert not m.methods
    assert not m.method_pyfunctions
    m.register_methods({
        'm1': 1,
        'm2': 2,
        })
    assert m.method_names == {'m1': 1, 'm2': 2}
    assert m.method_idxs == {1: 'm1', 2: 'm2'}
    assert not m.methods
    assert not m.method_pyfunctions


# Generated at 2022-06-24 14:23:31.596638
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert repr(_ScopeDict('Foo')) == 'Foo__Scope({})'



# Generated at 2022-06-24 14:23:33.495790
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    test_instance = _AVMClass_Object(None)
    assert test_instance.__repr__() == 'None#0'


# Generated at 2022-06-24 14:23:34.556807
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()



# Generated at 2022-06-24 14:23:45.605916
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    a = _AVMClass(1, 'a', {'b': 'c'})
    assert a.name_idx == 1
    assert a.name == 'a'
    assert a.method_names == {}
    assert a.method_idxs == {}
    assert a.methods == {}
    assert a.method_pyfunctions == {}
    assert a.static_properties == {'b': 'c'}
    assert a.variables == {'avm_class': a}
    assert a.constants == {}
    assert a.make_object() == _AVMClass_Object(a)
    assert repr(a) == "_AVMClass('a')"
    assert repr(_ScopeDict(a)) == "a__Scope({'avm_class': a#%x})" % (id(a))
   

# Generated at 2022-06-24 14:23:52.788186
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    import io
    import os.path
    from .compat import (
        compat_struct_unpack,
    )
    from .utils import (
        ExtractorError,
    )

    def _extract_tags(file_contents):
        if file_contents[1:3] != b'WS':
            raise ExtractorError(
                'Not an SWF file; header is %r' % file_contents[:3])
        if file_contents[:1] == b'C':
            content = zlib.decompress(file_contents[8:])
        else:
            raise NotImplementedError(
                'Unsupported compression format %r' %
                file_contents[:1])

        # Determine number of bits in framesize rectangle
        framesize_nbits = compat_struct_

# Generated at 2022-06-24 14:23:54.734734
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0)) == '[MULTINAME kind: 0x0]'



# Generated at 2022-06-24 14:23:57.784926
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert _Undefined() == _Undefined()
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'


Undefined = _Undefined()



# Generated at 2022-06-24 14:24:09.526400
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler

    class MockedSwfFile:
        def __init__(self, data):
            self.data = BytesIO(data)
            self.decompiler = SWFDecompiler(self.data)

    decompiler = SWFDecompiler(BytesIO(SWF_FILE))

    swffile = MockedSwfFile(SWF_FILE)
    swfdecompiler = SWFDecompiler(swffile.data)

    swfdecompiler.decompile()
    interpreter = SWFInterpreter(swffile, decompiler)
    interpreter.extract_class(swfdecompiler.classes[0])
    interpreter.extract_class(swfdecompiler.classes[1])

# Generated at 2022-06-24 14:24:21.357749
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    if not hasattr(binascii, 'a2b_base64'):
        binascii.a2b_base64 = binascii.a2b_base64

# Generated at 2022-06-24 14:24:26.775862
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x00)) == '[MULTINAME kind: 0x0]'
    assert repr(_Multiname(0x01)) == '[MULTINAME kind: 0x1]'
    assert repr(_Multiname(0x10)) == '[MULTINAME kind: 0x10]'



# Generated at 2022-06-24 14:24:34.710424
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert not _Undefined().__nonzero__()
    assert not bool(_Undefined())
    assert not bool(_Undefined().__nonzero__())
    assert 0 == hash(_Undefined())
    assert 0 == hash(_Undefined())
    assert 'undefined' == str(_Undefined())
    assert 'undefined' == str(_Undefined())
    assert 'undefined' == repr(_Undefined())
    assert 'undefined' == repr(_Undefined())
_test__Undefined = test__Undefined
del test__Undefined



# Generated at 2022-06-24 14:24:47.079374
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    #
    # Create a trivial example of an SWF file
    #
    swf = BytesIO()
    swf.write(compat_str('FWS\x00\x05\x00\x05').encode('ascii'))
    swf.write(compat_str('\x11\x00\x00\x00\x00').encode('ascii'))  # File length
    swf.write(compat_str('\x00\x00\x00\x00').encode('ascii'))  # Frame size
    swf.write(compat_str('\x00\x00\x00\x00').encode('ascii'))  # Frame rate

# Generated at 2022-06-24 14:24:52.753151
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class _AVMClass(object): pass
    assert repr(_AVMClass_Object(_AVMClass())) == 'None#%x' % id(
        _AVMClass_Object(_AVMClass()))
    assert repr(_AVMClass_Object(_AVMClass())) == 'None#%x' % id(
        _AVMClass_Object(_AVMClass()))
# end unit test for method __repr__ of class _AVMClass_Object



# Generated at 2022-06-24 14:24:55.144501
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'

# ------------------------------------------------------------------------------
# ABC, AVM2 bytecode, Flex
# ------------------------------------------------------------------------------



# Generated at 2022-06-24 14:24:57.938952
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined(), '_Undefined should be False'
    assert _Undefined() == _Undefined(), '_Undefined should be equal to itself'
    assert _Undefined() in {}, '_Undefined should be hashable and equal to others'
    assert str(_Undefined()) == 'undefined'



# Generated at 2022-06-24 14:25:00.070946
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    a = _AVMClass('a', 'a')
    assert a.name == 'a'



# Generated at 2022-06-24 14:25:12.684656
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = open(os.path.join('..', 'test', 'swf', 'example.swf'), 'rb').read()
    interpreter = SWFInterpreter(swf, debug=False)
    class_abc = interpreter.abc_classes[3]
    avm_class = class_abc.avm_class
    avm_class.init_static_properties()
    # The function we want to test is called Main.main, which is the only
    # function in the last script
    script = class_abc.scripts[-1]
    func_name = script.method.name
    assert func_name == 'main'
    # Verify that the function is not already initialized
    assert func_name not in avm_class.method_pyfunctions
    # First, let's test the function with a bounded array

# Generated at 2022-06-24 14:25:14.699629
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    print("testing method __repr__")
    # === begin unit test === #
    # Unit test for method __repr__ of class _AVMClass
    # === end unit test === #


# Generated at 2022-06-24 14:25:17.667728
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()) is False

# Generated at 2022-06-24 14:25:21.603052
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass('Thing', 'Thing')
    assert repr(c) == '_AVMClass(Thing)'
    o = c.make_object()
    assert repr(o) == 'Thing#%x' % id(o)



# Generated at 2022-06-24 14:25:25.229776
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() == _Undefined()
    assert _Undefined() is not None


_undefined = _Undefined()



# Generated at 2022-06-24 14:25:27.637186
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'
test__Multiname___repr__()



# Generated at 2022-06-24 14:25:30.583474
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    _AVMClass('a', 'b', static_properties={}).static_properties


# Generated at 2022-06-24 14:25:36.142041
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class DummyAVMClass:
        name = 'DummyClass'
    assert repr(_ScopeDict(DummyAVMClass())) == 'DummyClass__Scope({})'
    assert repr(_ScopeDict(DummyAVMClass(), a=1, b=2)) == 'DummyClass__Scope({\'a\': 1, \'b\': 2})'



# Generated at 2022-06-24 14:25:42.534290
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    for x in [
            _AVMClass(1, 'foo'),
            _AVMClass(2, 'bar', {'a': 42}),
    ]:
        assert x.name == 'bar' if x.name_idx else 'foo'
        assert isinstance(x.static_properties, dict)
        assert x.static_properties == {'a': 42} if x.name_idx else {}



# Generated at 2022-06-24 14:25:53.447110
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWF()
    swf.method_names = [
        'construct',
        'handle_button_click',
    ]
    swf.constant_strings = [
        'button1',
        'button2',
    ]
    swf.variable_names = [
        'button1_mc1',
        'button2_mc2',
    ]


# Generated at 2022-06-24 14:25:58.506306
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass(7, 'ClassName', {'static_prop1': 7})
    assert class_.name_idx == 7
    assert class_.name == 'ClassName'
    assert class_.static_properties['static_prop1'] == 7
    class_ = _AVMClass(7, 'ClassName')
    assert class_.name_idx == 7
    assert class_.name == 'ClassName'
    assert list(sorted(class_.static_properties.items())) == []



# Generated at 2022-06-24 14:26:04.604235
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    """Test method _AVMClass_Object.__repr__"""
    obj = _AVMClass_Object(
        _AVMClass_Object._test_avm_class)
    assert repr(obj) == 'AVMClass_Object#%x' % id(obj)
_AVMClass_Object._test_avm_class = object()



# Generated at 2022-06-24 14:26:16.512690
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # External function
    avm_class = _AVMClass(
        'test_SWFInterpreter_extract_function_external',
        [{    # Trait
            'kind': 9,
            'name': 'test_SWFInterpreter_extract_function_external',
            'id': 0,
             'data': {
                 'typeName': 1,
                 'value': {
                     'ref': {
                         'className': 1,
                         'namespace': 0,
                         'kind': 0
                      }
                 }
             },
             'metadata': []
         }])
    func = lambda x: 0
    swf_interpreter = SWFInterpreter()

# Generated at 2022-06-24 14:26:27.647331
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    import sys
    import unittest
    class _Class(object):
        def __init__(self):
            self.name = '_Class'
    class Test__ScopeDict(unittest.TestCase):
        def setUp(self):
            self.scope = _ScopeDict(_Class())
        def assertEqual(self, a, b):
            super(Test__ScopeDict, self).assertEqual(
                a, b, '%r != %r' % (a, b))
        def test__ScopeDict(self):
            self.assertEqual(self.scope.avm_class.name, '_Class')
            self.assertEqual(repr(self.scope), '_Class__Scope({})')
            self.scope['foo'] = 'bar'

# Generated at 2022-06-24 14:26:29.059352
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    a = _Undefined()
    assert not a


# Generated at 2022-06-24 14:26:36.261723
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    f = compat_named_temporary_file(suffix='.swf')

# Generated at 2022-06-24 14:26:43.536930
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    parser_state = ParserState()
    swf = SWFInterpreter(parser_state)
    code = ['findpropstrict', 'pushscope', 'getproperty', 'pushbyte', 'pushstring', 'multiply', 'getlocal_0', 'pushstring', 'add', 'pushstring', 'add', 'returnvalue']
    avm_class = swf.patch_function(code, 0)
    func = avm_class.method_pyfunctions['function' + str(0)]
    assert func(['test']) == 'test[0][0]'

# Class used to group methods and properties of the same class
# (i.e. to group things that are seen by actionscript as static members)

# Generated at 2022-06-24 14:26:51.581796
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class _AVMClass:
        def __init__(self):
            self.static_properties = {}
            self.method_names = {}
            self.method_pyfunctions = {}
    class _Multiname:
        def __init__(self, name):
            self.name = name
    class _AVMClass_Object:
        def __init__(self, avm_class):
            self.avm_class = avm_class
            self.instance_properties = {}
    class _ScopeDict:
        def __init__(self, avm_class):
            self.avm_class = avm_class
            self.dict = {}
        def __getitem__(self, key):
            return self.dict.get(key, undefined)

# Generated at 2022-06-24 14:26:58.826951
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Tests that SWFInterpreter.extract_function returns a function object
    swf = _SWFInterpreter(b'\0\0\0\0', None, None)
    m = mock.Mock
    t = {'abc': m(), 'abc': m(), 'abc': m()}
    c = mock.Mock(methods_abc=t)
    r = swf.extract_function(c, 'abc')
    assert r is t['abc']
    assert c.methods_abc['abc'] is not m()


# Generated at 2022-06-24 14:27:00.855008
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_A = _AVMClass('A')
    a = _AVMClass_Object(class_A)
    assert repr(a) == 'A#%x' % id(a), repr(a)



# Generated at 2022-06-24 14:27:08.447379
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    objects = []
    for i in range(5):
        class AVMClass(object):
            pass
        objects.append(_AVMClass_Object(AVMClass))
    for i in range(5):
        assert objects[i].__repr__(
        ) == 'AVMClass#%x' % id(objects[i]), objects[i].__repr__()
# END unit test for method __repr__ of class _AVMClass_Object



# Generated at 2022-06-24 14:27:15.400856
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    obj = _AVMClass(None,None)
    methods = {'first': 8}
    obj.register_methods(methods)
    assert obj.method_names == {'first': 8}
    assert obj.method_idxs == {8: 'first'}
    methods = {'second': 9}
    obj.register_methods(methods)
    assert obj.method_names == {'first': 8, 'second': 9}
    assert obj.method_idxs == {8: 'first', 9: 'second'}


# Generated at 2022-06-24 14:27:24.140924
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    si = SWFInterpreter()
    class FakeAVMClass(object):
        static_properties = {}
        method_names = []
    class_ = FakeAVMClass()
    class_.method_names = ['avm_class']
    class_.static_properties = {
        'avm_class': class_,
    }
    class_.make_object = lambda: {'avm_class': class_}
    func = si.extract_function(class_, 'avm_class')
    assert func([]) == class_

# Generated at 2022-06-24 14:27:25.618670
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    o = _AVMClass_Object(_AVMClass('Object', None))
    assert repr(o) == 'Object#%x' % id(o)



# Generated at 2022-06-24 14:27:28.912396
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    a = _AVMClass(2, 'foo')
    assert a.method_names == {}
    assert a.method_idxs == {}
    a.register_methods({
        'foo': 2,
        'bar': 3,
    })
    assert a.method_names == {
        'foo': 2,
        'bar': 3,
    }
    assert a.method_idxs == {
        2: 'foo',
        3: 'bar',
    }



# Generated at 2022-06-24 14:27:32.187951
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert _Undefined() == _Undefined()
    assert hash(_Undefined()) == hash(_Undefined())
undefined = _Undefined()



# Generated at 2022-06-24 14:27:44.230110
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    goodSWF = io.BytesIO(b'FWS\n\x05\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x14\x00\x00\x00<hello><world/><a/><c/><b/><d/></hello>')

# Generated at 2022-06-24 14:27:46.857938
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter(io.BytesIO(b''))
    assert interpreter.extract_class(None, None) is None



# Generated at 2022-06-24 14:27:49.841592
# Unit test for constructor of class _Undefined
def test__Undefined():
    import pytest
    assert not bool(_Undefined())
    assert bool(True)  # No assert needed - just to make Pytest happy

_undefined = _Undefined()


# Generated at 2022-06-24 14:27:57.052645
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(name_idx=0, name='Test')
    avm_class.register_methods(
        {
            u'__init__': 1,
            u'foo': 2,
            u'bar': 3,
        }
    )
    assert avm_class.method_names == {
        u'__init__': 1,
        u'foo': 2,
        u'bar': 3,
    }
    assert avm_class.method_idxs == {
        1: u'__init__',
        2: u'foo',
        3: u'bar',
    }



# Generated at 2022-06-24 14:28:01.485423
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(0x3)) == '[MULTINAME kind: 0x3]'


# Generated at 2022-06-24 14:28:04.968972
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    o = _ScopeDict(None)
    o['x'] = 'y'
    assert repr(o) == 'None__Scope({\'x\': \'y\'})'



# Generated at 2022-06-24 14:28:06.166245
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()



# Generated at 2022-06-24 14:28:10.208443
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert (_ScopeDict(_AVMClass_Object(_AVMClass(name='Toplevel'))) ==
            {'avm_class': _AVMClass_Object(_AVMClass(name='Toplevel'))})



# Generated at 2022-06-24 14:28:15.406101
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert ('test.test_swfdecode.test__AVMClass_Object___repr___'
        '_AVMClass_Object#%x' % id(_AVMClass_Object(None))) == (
        repr(_AVMClass_Object(None)))


# Generated at 2022-06-24 14:28:16.547486
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    _AVMClass('test', 'Test')



# Generated at 2022-06-24 14:28:28.097502
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from .utils import make_method_dict
    _AVMClass_Object = _AVMClass_Object
    _AVMClass = _AVMClass
    _ScopeDict = _ScopeDict
    class _AVMClass(object):
        def __init__(self, name_idx, name, static_properties=None):
            self.name_idx = name_idx
            self.name = name
            self.method_names = {}
            self.method_idxs = {}
            self.methods = {}
            self.method_pyfunctions = {}
            self.static_properties = static_properties if static_properties else {}
            self.variables = _ScopeDict(self)
            self.constants = {}
        def make_object(self):
            return _AVMClass_Object(self)
       

# Generated at 2022-06-24 14:28:29.353925
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    x = _Undefined()
    assert not x

# Generated at 2022-06-24 14:28:39.653611
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    p = SWFInterpreter()
    p._read_method_body = lambda a, b, c, d: ['test']

    f = functools.partial(p.extract_function, None)
    assert f('urlencode')('abc') == 'abc'

    f = functools.partial(p.extract_function, None, 'String')
    assert f('', 'abc') == 'abc'

    f = functools.partial(p.extract_function, 'String', 'split')
    assert f('', 'o') == list('foobar')

    f = functools.partial(p.extract_function, 'String', 'charCodeAt')
    assert f('', 2) == ord('r')
    assert f('', 0) == ord('f')

    f = functools.partial

# Generated at 2022-06-24 14:28:44.311335
# Unit test for constructor of class _Undefined
def test__Undefined():
    obj = _Undefined()
    assert not obj
    assert hash(obj) == 0
    assert str(obj) == 'undefined'

    assert not bool(_Undefined)


_undefined_value = _Undefined()



# Generated at 2022-06-24 14:28:49.835726
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x07).__repr__() == '[MULTINAME kind: 0x7]'
    assert _Multiname(0x0d).__repr__() == '[MULTINAME kind: 0xd]'
    assert _Multiname(0x0f).__repr__() == '[MULTINAME kind: 0xf]'



# Generated at 2022-06-24 14:28:52.687421
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == '__Scope({})'
    assert _ScopeDict(None).__repr__() == '__Scope({})'



# Generated at 2022-06-24 14:28:59.202220
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    '''
    >>> test__AVMClass_Object___repr__()
    True
    '''
    class_class = _AVMClass(name='Class')
    frame_class = _AVMClass(
        name='Frame', members={'avm_version': 'AVM2'}, superclass=class_class)
    instance = _AVMClass_Object(avm_class=frame_class)
    assert repr(instance) == 'Frame#%x' % id(instance)
    return True


# Generated at 2022-06-24 14:29:10.971793
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Simple case
    def check_interpreter(code, expected_strings, expected_multinames):
        f = io.BytesIO(code)
        si = SWFInterpreter(f)
        assert si.constant_strings == expected_strings
        assert (si.multinames == [
            _Multiname(namespace_set_index=0, name_index=0),
            _Multiname(namespace_set_index=0, name_index=1),
            _Multiname(namespace_set_index=0, name_index=2),
            ])


# Generated at 2022-06-24 14:29:19.868758
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter = swftools.SWFInterpreter()

# Generated at 2022-06-24 14:29:30.560210
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf_extract import (
        extract_swf, update_pyamf, extract_swfs, update_pyamf_multi,
        update_pyamf_with_config)
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import path

    temp_dir = mkdtemp()

# Generated at 2022-06-24 14:29:34.910500
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class _AVMClass(object):
        name = 'test'
    assert str(_AVMClass_Object(_AVMClass())) == 'test#%x' % id(_AVMClass_Object(_AVMClass()))



# Generated at 2022-06-24 14:29:42.593238
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter('tests/swftest_1.swf')
    interpreter.extract_class(0x0012, 'TestCase')
    avm_class = interpreter.avm_classes['TestCase']
    assert len(avm_class.instantiated_objects) == 1
    assert avm_class.instantiated_objects[0]['_name'] == 'TestCase'
    assert avm_class.method_names == ['test', 'callAccessor']

# Generated at 2022-06-24 14:29:53.549898
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = io.BytesIO(SWF_EXAMPLE)
    swf.seek(0)
    avm_interpreter = SWFInterpreter(swf)
    avm_classes = avm_interpreter.extract_classes()
    assert len(avm_classes) == 1
    avm_class = avm_classes[0]
    assert isinstance(avm_class, _AVMClass)
    assert avm_class.name == 'RootClass'
    assert avm_class.superclass_name == 'Object'
    assert avm_class.method_names == set(('doit',))
    assert avm_class.static_properties == {'object_class': 'RootClass'}
    assert avm_class.static_methods == {}
    assert avm_class.make

# Generated at 2022-06-24 14:29:57.052857
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    a = _Undefined()
    assert not a

# Generated at 2022-06-24 14:29:59.561127
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    undefined = _Undefined()
    assert not bool(undefined)
    assert not undefined

# Generated at 2022-06-24 14:30:12.331503
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter(None, 'abc.swf')
    avm_class = _AVMClass(None)
    avm_class.variables['a'] = 'b'
    avm_class.variables['c'] = 'd'
    fname = 'f'

# Generated at 2022-06-24 14:30:25.210068
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__(): assert str(
    _AVMClass_Object(avm_class=_AVMClass(
        name='_AVMClass_Object', attrs=dict(
            name=_AVMAttribute(name='name', value='_AVMClass_Object'),
            attrs=_AVMAttribute(name='attrs', value=dict(
                name=_AVMAttribute(name='name', value='name'),
                value=_AVMAttribute(name='value', value='_AVMClass_Object'))),
            __class__=_AVMAttribute(name='__class__', value=_AVMClass_Object))))) \
    == '_AVMClass_Object#48d72f0'


# Generated at 2022-06-24 14:30:26.907038
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == 'undefined'

Undefined = _Undefined()



# Generated at 2022-06-24 14:30:34.196599
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .amf import read_amf_data
    from .amf import read_amf_string

    from .compat import compat_urlparse

    from .compat import compat_str
    from .compat import compat_struct_pack

    import base64
    import sys

    class MockRequest(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_header(self, name):
            return ''

        def read(self, size):
            return b''

    class MockFile(object):
        def __init__(self, *args, **kwargs):
            from io import BytesIO
            self._data = BytesIO()

        def read(self, size):
            return b''

        def tell(self):
            return 0


# Generated at 2022-06-24 14:30:40.057413
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    '''Test __repr__'''
    _ScopeDict___repr___test_object = _ScopeDict(
        avm_class=None)
    assert _ScopeDict___repr___test_object.__repr__() == (
        'None__Scope(%s)' % ({}.__repr__()))



# Generated at 2022-06-24 14:30:50.057910
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import unittest
    import io
    class SWFInterpreter_extract_function_TestCase(unittest.TestCase):
        def setUp(self):
            pass
        def test_SWFInterpreter_extract_function_trivial(self):
            # trival
            code = io.BytesIO()
            code.write(_TagDoABC.TAG_CODE)
            code.write(compat_struct_pack('<I', 0))
            code.write(compat_struct_pack('<I', 0))
            code.write(b'Trivial\x00')
            code.write(compat_struct_pack('<I', 0))
            swf_interpreter = SWFInterpreter(code)

# Generated at 2022-06-24 14:30:53.738300
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    avm_class = _AVMClass(None, 'foo', parent_class=None)
    avm_object = _AVMClass_Object(avm_class)
    assert repr(avm_object) == 'foo#%x' % id(avm_object)

# Generated at 2022-06-24 14:30:58.140054
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) == False
    assert repr(_Undefined()) == 'undefined'
    assert str(_Undefined()) == 'undefined'


Undefined = _Undefined()



# Generated at 2022-06-24 14:30:59.572418
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    m = _Multiname(0x42)
    def func1():
        return m
    assert_equal(func1(), '[MULTINAME kind: 0x42]')



# Generated at 2022-06-24 14:31:03.154660
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    o = _AVMClass('Foo', {
        'f1': 1,
        'f2': 2,
    })
    assert o.name == 'Foo'
    assert o.make_object() is not None
    assert o.make_object() is not o.make_object()
    assert o.static_properties == {
        'f1': 1,
        'f2': 2,
    }



# Generated at 2022-06-24 14:31:06.835355
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert _Undefined() == _Undefined()
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'
test__Undefined()



# Generated at 2022-06-24 14:31:08.607684
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    avm_class = _AVMClass(0, 'Object')
    obj = _AVMClass_Object(avm_class)
    repr(obj)


# Generated at 2022-06-24 14:31:10.002648
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

# Generated at 2022-06-24 14:31:16.375038
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    x = _ScopeDict(_AVMClass())
    assert isinstance(x, _ScopeDict), repr(x)
    assert repr(x) == '_AVMClass()__Scope({})', repr(x)
    x['y'] = 1
    assert repr(x) == '_AVMClass()__Scope({\'y\': 1})', repr(x)



# Generated at 2022-06-24 14:31:19.460155
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(0xFEED)
    assert repr(obj) == '[MULTINAME kind: 0xFEED]'



# Generated at 2022-06-24 14:31:20.378834
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()) == False

# Generated at 2022-06-24 14:31:25.882197
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    from .utils import attr_name_to_camel_case, camel_case_to_attr_name
    s = _ScopeDict(attr_name_to_camel_case('_ScopeDict'))
    s['test'] = 'test'
    s['test2'] = 'test2'
    assert repr(s) == '_ScopeDict__Scope({"test": "test", "test2": "test2"})'
    assert camel_case_to_attr_name(s.avm_class.name) == '_scope_dict'

