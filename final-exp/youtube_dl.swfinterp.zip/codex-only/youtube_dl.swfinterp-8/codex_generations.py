

# Generated at 2022-06-24 14:21:23.963889
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    def assert_equal_multiname(mname, **kwargs):
        for name, value in kwargs.items():
            assert getattr(mname, name) == value, (
                'Multiname %s has incorrect value %r (expected %r)'
                % (name, getattr(mname, name), value))

    _SWFInterpreter = SWFInterpreter(None)

    # parse_multiname
    assert_equal_multiname(
        _SWFInterpreter.parse_multiname(0x00),
        kind=0x00, name='')
    assert_equal_multiname(
        _SWFInterpreter.parse_multiname(0x07),
        kind=0x07, name='')

# Generated at 2022-06-24 14:21:25.725465
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    x = _AVMClass_Object(_AVMClass(name='Foo'))
    assert repr(x) == 'Foo#%x' % id(x)



# Generated at 2022-06-24 14:21:30.070452
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    avmclass = _AVMClass(0, 'x')
    assert repr(avmclass) == '_AVMClass(x)'



# Generated at 2022-06-24 14:21:40.157752
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .test_utils import find_swfs
    for filename in find_swfs(os.path.join('tests', 'swfs')):
        with open(filename, 'rb') as swf_file:
            swf = SWF(swf_file)
            for tag in swf.tags:
                if isinstance(tag, DoABC):
                    abc = tag.abc_data
                    break
            else:
                pytest.skip('No DoABC tag in %r' % filename)
        try:
            interpreter = SWFInterpreter(abc, filename)
            interpreter.extract_class(filename)
        except NotImplementedError as e:
            pytest.skip('Unsupported code in file %r: %s'
                        % (filename, e))


# Generated at 2022-06-24 14:21:44.693122
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-24 14:21:50.855526
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    o = _ScopeDict(None)
    o.update({
        'test': 1,
        'test2': 'this is a test',
    })
    _test_equal(repr(o), 'None__Scope(test=1,test2=this is a test)')
test__ScopeDict___repr__()



# Generated at 2022-06-24 14:21:56.019172
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    cl = _AVMClass(1, 'Test')
    cl.register_methods({
        'foo': 2,
        'bar': 3,
    })
    assert (
        cl.method_names['foo'],
        cl.method_names['bar']) == (2, 3)
    assert (
        cl.method_idxs[2],
        cl.method_idxs[3]) == ('foo', 'bar')



# Generated at 2022-06-24 14:22:01.005021
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    f = BytesIO()

# Generated at 2022-06-24 14:22:03.982784
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x07).__repr__() == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:22:14.179330
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    import sys
    if sys.version_info[:2] == (2, 6):
        # Python 2.6 has an old and broken C implementation for dict.
        # Skip the test for now.
        return
    avm_class = StubAVMClass()
    scope = _ScopeDict(avm_class)
    scope['foo'] = 'bar'
    scope['a'] = '1'
    scope['b'] = 2
    assert repr(scope).startswith('StubAVMClass__Scope({')
    assert 'foo' in repr(scope)
    assert 'a' in repr(scope)
    assert 'b' in repr(scope)
    assert 'bar' in repr(scope)
    assert '1' in repr(scope)
    assert '2' in repr(scope)



# Generated at 2022-06-24 14:22:16.625535
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(5).kind == 5, 'Initial value should be preserved'
# end of test__Multiname()



# Generated at 2022-06-24 14:22:18.067224
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert _Undefined() == _Undefined()
test__Undefined___hash__()



# Generated at 2022-06-24 14:22:20.403475
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass(1, 'foo')
    assert isinstance(avm_class.make_object(), _AVMClass_Object)


# Generated at 2022-06-24 14:22:27.805848
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = _SWFInterpreter()
    from . import avm2_toplevel_names
    swf.register_class('Object', avm2_toplevel_names.ObjectClass)
    swf.register_class('Function', avm2_toplevel_names.FunctionClass)


# Generated at 2022-06-24 14:22:29.533461
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    obj = _Undefined()
    assert isinstance(obj, _Undefined)
    assert repr(obj) == 'undefined'

# Generated at 2022-06-24 14:22:32.095045
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x07).__repr__() == '[MULTINAME kind: 0x7]'
    assert _Multiname(0x0D).__repr__() == '[MULTINAME kind: 0xd]'



# Generated at 2022-06-24 14:22:34.110698
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class_ = _AVMClass('classname', 0)
    obj = class_.make_object()
    assert obj.avm_class is class_
    assert repr(obj) == 'classname#%x' % id(obj)

# Generated at 2022-06-24 14:22:37.622241
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class ClassAdder(object):
        def __init__(self, value):
            self.value = value
        def add(self, b):
            return self.value + b
    adder = ClassAdder(123)
    SWFInterpreter.patch_function(adder, 'add', 0)
    assert adder.add(456) == 123 + 456
# class SWFInterpreter
SWFInterpreter = SWFInterpreter()
# class AVM2Reader

# Generated at 2022-06-24 14:22:39.827825
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    """_Undefined.__repr__"""
    assert repr(_Undefined()) == 'undefined'

# Generated at 2022-06-24 14:22:40.917508
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()



# Generated at 2022-06-24 14:22:41.728672
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


# Generated at 2022-06-24 14:22:43.764523
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'

# Generated at 2022-06-24 14:22:46.686899
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    a = _AVMClass_Object(_AVMClass(u'Foo'))
    assert repr(a) == 'Foo#%x' % id(a)


# Generated at 2022-06-24 14:22:56.758708
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from jsunpackn import _builtin_classes, _Undefined, _ScopeDict

    inter = SWFInterpreter()
    inter.method_names = set(['test_func'])
    inter.method_pyfunctions['test_func'] = lambda: None
    inter.method_bodies[10] = SWFMethodBody(None)
    
    test_func_pyfunc = inter.extract_function('test_func')
    assert test_func_pyfunc is not None

    # When the function is patched, we are able to call it
    # (if it throws an exception when executed, the test will fail)
    assert test_func_pyfunc() is undefined
test_SWFInterpreter_patch_function()

# Generated at 2022-06-24 14:22:58.982870
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    obj = _AVMClass()
    obj.register_methods({u'foobar': 0})
    assert obj.method_names[u'foobar'] == 0
    assert obj.method_idxs[0] == u'foobar'


# Generated at 2022-06-24 14:23:06.019357
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-24 14:23:07.537447
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    assert isinstance(_AVMClass('foo').make_object(), _AVMClass_Object)


# Generated at 2022-06-24 14:23:10.133438
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert _Undefined() == _Undefined()
    assert not (_Undefined() != _Undefined())  # NOQA
    assert hash(_Undefined()) == 0



# Generated at 2022-06-24 14:23:14.165788
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    c = _AVMClass('Foo')
    c._methods['bar'] = None
    s = _ScopeDict(c)
    s['this'] = 'that'
    assert repr(s) == "Foo__Scope({'this': 'that'})"



# Generated at 2022-06-24 14:23:16.381136
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    c = _AVMClass(0, '__main__')
    c.register_methods({'foo': 1, 'bar': 2})
    assert (repr(c) == '_AVMClass(__main__)')



# Generated at 2022-06-24 14:23:19.074369
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class1 = _AVMClass('MyClass')
    obj1 = _AVMClass_Object(class1)
    assert isinstance(obj1, _AVMClass_Object)



# Generated at 2022-06-24 14:23:29.994174
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():

    from .test_swfdata import SWFDataTestCase

    class TestSWFInterpreter(SWFDataTestCase):

        class TestSWFInterpreter(SWFInterpreter):
            """Subclass to override extract_function"""
            def extract_function(self, avm_class, mname):
                def func(args):
                    assert len(args) == 1
                    assert isinstance(args[0], int)
                    return args[0] + 1
                return func

        def setUp(self):
            self.interpreter = self.TestSWFInterpreter()


# Generated at 2022-06-24 14:23:32.227730
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    # Test method __repr__ of class _AVMClass with unspecified arguments
    assert repr(_AVMClass(*(None,) * 4)) == '_AVMClass(None)'



# Generated at 2022-06-24 14:23:34.063065
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    multiname = _Multiname(1)
    assert str(multiname) == '[MULTINAME kind: 0x1]'


# Generated at 2022-06-24 14:23:34.976142
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(1)



# Generated at 2022-06-24 14:23:40.195200
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    # If a call to the method __repr__ of class _AVMClass_Object with
    # arguments ( ) raises an error, then the function returns False;
    # otherwise it returns True.
    _AVMClass_Object(None).__repr__()
    return True



# Generated at 2022-06-24 14:23:43.768450
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(str(_Undefined())) == hash(str(_Undefined()))
    assert hash(str(_Undefined())) != 0

_undefined = _Undefined()

_true = True  # Used to pass bool true
_false = False  # Used to pass bool false



# Generated at 2022-06-24 14:23:50.479856
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from . import swftags
    avm_class = _AVMClass(0, 'TestClass')
    avm_class.register_methods({swftags.DO_ABC: 'do_abc'})
    assert avm_class.method_names[swftags.DO_ABC] == 'do_abc'
    assert avm_class.method_idxs[0] == 'do_abc'
# Test
test__AVMClass_register_methods()



# Generated at 2022-06-24 14:23:56.091483
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class DummyAVMClass(object):
        def __init__(self):
            self.name = '<DummyAVMClass>'

    obj = _AVMClass_Object(DummyAVMClass())
    assert repr(obj) == '<DummyAVMClass>#%x' % id(obj)


# Generated at 2022-06-24 14:24:03.170521
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import struct
    import zlib


# Generated at 2022-06-24 14:24:06.672705
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    if None: yield None
    m = _Multiname(0x1)
    assert repr(m) == '[MULTINAME kind: 0x1]'
    assert m == _Multiname(0x1)
    assert m != _Multiname(0x2)



# Generated at 2022-06-24 14:24:11.482774
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_a = _AVMClass('A')
    class_b = _AVMClass('B', super_class=class_a)
    instance_b = class_b.new_instance()

    assert repr(instance_b) == 'B#%x' % id(instance_b)



# Generated at 2022-06-24 14:24:14.281658
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass('foo', {'a': 1, 'b': 2})
    assert class_.static_properties == {'a': 1, 'b': 2}
    assert class_.variables == {}
test__AVMClass()



# Generated at 2022-06-24 14:24:20.880441
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(1, "name", static_properties=None)
    expected__AVMClass_register_methods0 = {
    }
    avm_class.register_methods(expected__AVMClass_register_methods0)
    expected__AVMClass_register_methods1 = {
        u'a': 2,
        u'b': 2,
        u'c': 2,
    }
    avm_class.register_methods(expected__AVMClass_register_methods1)
    expected__AVMClass_register_methods2 = {
        u'd': 4,
        u'b': 4,
    }
    avm_class.register_methods(expected__AVMClass_register_methods2)

    expected__AVMClass_register_methods

# Generated at 2022-06-24 14:24:33.512356
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = open(SWF_FILE, 'rb').read()
    interpreter = SWFInterpreter()
    interpreter.parse(swf)

# Generated at 2022-06-24 14:24:46.417361
# Unit test for constructor of class _Undefined
def test__Undefined():
    x = _Undefined()
    assert not x
    assert x == _Undefined()
    assert x == None
    assert x != 42
    assert not (x == 42)
    assert x != False
    assert not (x == False)
    assert x != True
    assert not (x == True)
    assert x != 0
    assert not (x == 0)
    assert x != ''
    assert not (x == '')
    assert x != {}
    assert not (x == {})
    assert x != []
    assert not (x == [])
    assert x != ()
    assert not (x == ())
    assert hash(x) == hash(_Undefined())
    assert hash(x) == hash(None)
    assert str(x) == 'undefined'
    assert repr(x) == 'undefined'
test__Und

# Generated at 2022-06-24 14:24:47.497705
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()) == False

# Generated at 2022-06-24 14:24:49.266242
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    instance = _AVMClass()
    assert repr(instance) == '_AVMClass(None)'



# Generated at 2022-06-24 14:24:52.345150
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_ = _AVMClass_Object(_AVMClass('test'))
    if class_.__repr__().find('#') != -1:
        return class_.__repr__()
    return None
test__AVMClass_Object()



# Generated at 2022-06-24 14:24:53.931574
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'

# Generated at 2022-06-24 14:25:01.617874
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass('test_avm_class', 'test_avm_class')
    assert avm_class.name == 'test_avm_class'
    assert avm_class.name_idx == 'test_avm_class'
    assert len(avm_class.method_names) == 0
    assert len(avm_class.method_idxs) == 0
    assert len(avm_class.methods) == 0
    assert len(avm_class.static_properties) == 0

    assert isinstance(avm_class.variables, _ScopeDict)
    assert avm_class.variables.avm_class is avm_class
    assert len(avm_class.variables) == 0

    assert len(avm_class.constants) == 0



# Generated at 2022-06-24 14:25:04.745089
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert _AVMClass_Object(_AVMClass_Object).avm_class is _AVMClass_Object



# Generated at 2022-06-24 14:25:06.824912
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(0)) == '[MULTINAME kind: 0x0]'


# Generated at 2022-06-24 14:25:17.019566
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .test import TOLERANCE
    from .test import avm2_unit_test
    from .swf import avm2

    @avm2_unit_test
    def make_object(avm2, obj):
        def method():
            pass
        avm2.classes.add(
            'class_name',
            static_properties={'prop_name': 0},
            methods={'method_name': method})
        method_name_idx = avm2.classes.method_name_idxs['class_name']['method_name']
        avm2.method_idxs.append(method_name_idx)
        avm2.methods.append(method)

# Generated at 2022-06-24 14:25:20.156402
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert _Undefined() == _Undefined()
    assert hash(_Undefined()) == 0
test__Undefined___hash__()
Undefined = _Undefined()



# Generated at 2022-06-24 14:25:23.510076
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    scope = _ScopeDict(None)
    assert scope.__repr__() == 'None__Scope({})'
    scope.foo = 'bar'
    assert scope.__repr__() == 'None__Scope({\'foo\': \'bar\'})'



# Generated at 2022-06-24 14:25:28.329570
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass(1, 'Foo')
    assert cls.name == 'Foo'
    assert cls.name_idx == 1
    assert cls.static_properties == {}
    assert cls.variables == {'this': cls.make_object()}



# Generated at 2022-06-24 14:25:39.034506
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from .atoms import _AVMAtom
    from .execution import AVMExecution
    from .methods import _AVMMethod
    from .operations import AVMOperation_Push

    avm = AVMExecution(None)

    _AVMClass._AVMClass__repr__(
        _AVMClass('a', 'b', static_properties={'a': _AVMAtom(1)})) == \
            '_AVMClass(b)'

    method.__repr__() == '_AVMMethod(a)'

    methods = {}
    m = _AVMMethod('a', methods)
    m.add_op(AVMOperation_Push(m, _AVMAtom(1)))
    m.resolve_names(avm.names)
    methods['a'] = m

    _AVM

# Generated at 2022-06-24 14:25:42.683402
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class DummyAVMClass(object):
        name = 'DummyClass'
    assert repr(_AVMClass_Object(DummyAVMClass())) == 'DummyClass#0x0'



# Generated at 2022-06-24 14:25:43.627338
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__(): return _Multiname(0x01).__repr__()



# Generated at 2022-06-24 14:25:54.113158
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import io

    class TestAVMClass(object):
        def __init__(self, *args, **kwargs):
            self.variables = {}
            self.static_properties = {}
            self.method_names = [
                'String', 'charCodeAt', 'split', 'length', 'join', 'slice',
                'reverse']
            self.method_pyfunctions = {}

        def make_object(self):
            return {}
    _builtin_classes['String'] = TestAVMClass()


# Generated at 2022-06-24 14:25:57.055112
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    multiname = _Multiname(0x0b)
    assert repr(multiname) == '[MULTINAME kind: 0x0b]'



# Generated at 2022-06-24 14:25:59.028487
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    avm_class = _AVMClass('Object')
    assert repr(_AVMClass_Object(avm_class)) == 'Object#%x' % id(_AVMClass_Object(avm_class))



# Generated at 2022-06-24 14:26:12.055781
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # A random SWF file
    path = ('https://raw.githubusercontent.com/rg3/youtube-dl/master/tests/'
        'youtube-dl/test.swf')

    # Download the SWF file
    with closing(compat_urllib_request.urlopen(path)) as f:
        content = f.read()

    # Load the SWF file
    swf = SWFInterpreter(content)

    # Get the code of function
    code = swf.avm_class.methods['getSources'].code

    # Make the code to be valid Python code
    code = '\n'.join(code)

    # Execute the Python code
    exec(code)

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-24 14:26:15.067380
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    c = _AVMClass(1, 'someClass')
    assert repr(c) == '_AVMClass(someClass)', repr(c)

# Generated at 2022-06-24 14:26:26.876229
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import unittest
    class TestSWFInterpreter_patch_function(unittest.TestCase):
        def setUp(self):
            self.swfdata = compat_urllib_request.urlopen(
                'http://www.youtube-dl.org/downloads/test/flashvideos.swf'
            ).read()
            self.swfdata = io.BytesIO(self.swfdata)
            self.swf = SWF(self.swfdata)
            self.avm2 = self.swf.avm2
            self.avm2.extract_from_swf(self.swfdata)
            self.avm2.patch_function(
                '_get',
                lambda args: 'http://www.google.com/',
            )

# Generated at 2022-06-24 14:26:28.306385
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    _ScopeDict(None).__repr__()



# Generated at 2022-06-24 14:26:30.738746
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    # Call method __repr__ of class _ScopeDict with fake arguments
    assert (_ScopeDict.__repr__("") != "\n")


# Generated at 2022-06-24 14:26:38.845597
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .test_swf import _avm_class_object
    from .test_utils import UnitTestExtractor

    def _run_test(name, expected_repr):
        return lambda: UnitTestExtractor.assertEqual(
            expected_repr, _avm_class_object(name).__repr__())
    return [
        _run_test('String', 'String#%x' % id(_avm_class_object('String'))),
    ]



# Generated at 2022-06-24 14:26:46.657610
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    converter = SWFInterpreter()
    converter.constant_strings = [
        '_root', 'onMetaData', 'duration', 'audiodatarate', 'canSeekToEnd',
        'audiosize', 'stereo', 'audiocodecid', 'filesize', 'avcprofile',
        'videodatarate', 'height', 'framerate', 'videocodecid', 'width', 'seekpoints',
        'seekpoint', 'time', 'name', 'filepositions', 'fileposition',
        'bytelength', 'times', 'keyframes', 'times', 'filepositions',
    ]


# Generated at 2022-06-24 14:26:48.557130
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert _Undefined() is not None, "Unit test for method __bool__ of class _Undefined failed"

# Generated at 2022-06-24 14:26:55.523553
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class_ = _AVMClass(None, None)
    assert class_.method_names == {}
    assert class_.method_idxs == {}
    class_.register_methods({
        b'foo': 100,
        b'bar': b'200',
    })
    assert class_.method_names == {
        b'foo': 100,
        b'bar': b'200',
    }
    assert class_.method_idxs == {
        100: b'foo',
        b'200': b'bar',
    }



# Generated at 2022-06-24 14:26:58.688243
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    foo = _AVMClass_Object(None)
    assert repr(foo) == '_AVMClass_Object#%x' % id(foo)  # pylint: disable=no-member
    return foo



# Generated at 2022-06-24 14:27:00.735778
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    obj = _Undefined()
    try:
        obj.__bool__()
    except:
        pass


# Generated at 2022-06-24 14:27:03.341373
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert _Multiname(1).__repr__() == '[MULTINAME kind: 0x1]'



# Generated at 2022-06-24 14:27:07.412646
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    f = _AVMClass_Object(_AVMClass(None, 'TestClass'))
    assert repr(f) == 'TestClass#%x' % id(f)


# TODO: rename to _AVMObject?

# Generated at 2022-06-24 14:27:10.238059
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert str(_Undefined()) == 'undefined'
    assert _Undefined() is _Undefined()
    set([_Undefined()])  # this should not raise an error
test__Undefined()



# Generated at 2022-06-24 14:27:11.696639
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
# test__Undefined___hash__()



# Generated at 2022-06-24 14:27:15.173967
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _AVMClass(object):
        name = 'test__ScopeDict'

    scope = _ScopeDict(_AVMClass())
    scope['a'] = 'b'
    scope['c'] = 'd'
    assert repr(scope) == 'test__ScopeDict__Scope({\'a\': \'b\', \'c\': \'d\'})'



# Generated at 2022-06-24 14:27:21.933119
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import os
    import json
    import random
    import re
    import itertools
    from .compat import str_to_bytes
    from ..aes import aes_cbc_decrypt
    from ..utils import (
        extract_flat_dict, determine_ext, int_or_none,
        mimetype2ext)

    def run_test(test_path):
        loader = _SWFLoader(test_path)
        interpreter = SWFInterpreter(loader)

        with open(test_path, 'rb') as f:
            js = json.load(f)

        match = re.match(r'Test (.*) (\d+)', js['name'])
        # test case name: Test <function> <number>
        test_case_name, test_case_number = match.groups()

# Generated at 2022-06-24 14:27:28.028402
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass(
        name_idx=1234, name='dummy_class',
        static_properties={'test1': 'test2'})
    assert cls.name_idx == 1234
    assert cls.name == 'dummy_class'
    assert cls.method_names == {}
    assert cls.method_idxs == {}
    assert cls.methods == {}
    assert cls.method_pyfunctions == {}
    assert cls.static_properties == {'test1': 'test2'}

    assert isinstance(cls.variables, _ScopeDict)
    assert cls.variables.avm_class is cls

    assert cls.constants == {}



# Generated at 2022-06-24 14:27:41.150705
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import os
    import tempfile
    # test for SWFInterpreter constructor
    filename = os.path.join(os.path.dirname(__file__),
                            'flash', 'playerProductInstall.swf')
    with open(filename, 'rb') as fh:
        swf_data = fh.read()

    with tempfile.NamedTemporaryFile(prefix='yt_adobedecrypt_', suffix='.py') as temp_f:
        temp_f.write(swfdecompyler.adobedecrypt.py_source)
        temp_f.flush()
        with open(temp_f.name, 'r') as temp_f2:
            adobedecrypt = imp.load_source('temp_f', temp_f.name, temp_f2)
    swf

# Generated at 2022-06-24 14:27:46.194842
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    methods = {'name': 5}
    avm_class = _AVMClass(0, 'name_str')
    avm_class.register_methods(methods)
    assert avm_class.method_names == methods
    assert avm_class.method_idxs == {5: 'name'}

# Generated at 2022-06-24 14:27:48.250849
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    undef = _Undefined()
    assert hash(undef) == 0

# Generated at 2022-06-24 14:27:52.117957
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert not bool(_Undefined())
    assert not True if _Undefined() else True
    assert 0 == hash(_Undefined())
    assert 'undefined' == str(_Undefined())
    assert 'undefined' == repr(_Undefined())

_undefined = _Undefined()



# Generated at 2022-06-24 14:27:54.497775
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    help_class = _AVMClass(None, 'MyClass')
    ref = help_class.make_object()
    assert ref.avm_class is help_class



# Generated at 2022-06-24 14:27:56.741584
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
UNDEFINED = _Undefined()



# Generated at 2022-06-24 14:28:02.574761
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interp = SWFInterpreter()

    with io.open('tests/swf_interpreter_test_1.swf', 'rb') as f:
        swf = load(f)

        coder = io.BytesIO(swf.code)
        func_name = '_level0_level1_level2_level3_level4_moveClip'
        resfunc = interp.extract_function(swf, func_name, '_level0_level1_level2_level3_level4')

        assert resfunc(['hello']) == {
            'url': 'http://localhost:8000/hello'
        }

# Generated at 2022-06-24 14:28:05.026064
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert _Multiname(1).__repr__() == '[MULTINAME kind: 0x1]'

# Generated at 2022-06-24 14:28:16.745729
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Just ensure that when the class is instantiated the class has the expected
    # values in it
    interpreter = SWFInterpreter()
    assert interpreter.constant_int == {}, 'constant_int'
    assert interpreter.constant_uint == {}, 'constant_uint'
    assert interpreter.constant_double == {}, 'constant_double'
    assert interpreter.constant_strings == {}, 'constant_strings'
    assert interpreter.constant_namespace == {}, 'constant_namespace'
    assert interpreter.constant_namespace_set == {}, 'constant_namespace_set'
    assert interpreter.constant_multiname == {}, 'constant_multiname'
    assert interpreter.methods == {}, 'methods'
    assert interpreter.metadata == {}, 'metadata'

# Generated at 2022-06-24 14:28:20.738246
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    o = _Undefined()
    assert type(o) == _Undefined
    assert o == _Undefined()
    assert hash(o) == 0
    assert len({o: 1}) == 0

Undefined = _Undefined()



# Generated at 2022-06-24 14:28:22.939755
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__(): assert (''
    == _Multiname(0x09).__repr__() )



# Generated at 2022-06-24 14:28:30.644623
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()
    parser = SWFParser()

    with open('tests/swfs/as3_method_patch.swf', 'rb') as inf:
        swf = parser.parse(inf)

    interpreter.parse(swf)

    print('- run original')
    interpreter.run('Main', 'main0', [])

    print('- patch method')
    interpreter.patch_function(
        'Main', 'main0', lambda: print('patched'))

    print('- run patched')
    interpreter.run('Main', 'main0', [])



# Generated at 2022-06-24 14:28:40.741300
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swfi = SWFInterpreter()

    fname = 'testFunction'
    pos = 0
    body = [
        b'\x03',  # pushscope
        b'\x02\x00\x00\x00',  # pushstring:0
        b'\x57',  # findpropstrict
        b'\x73\x00\x00\x00',  # getproperty:0
        b'\x03\x00\x00\x00',  # pushshort:0
        b'\x46\x00\x00\x00',  # construct:0
        b'\x3e',  # returnvoid
    ]

# Generated at 2022-06-24 14:28:52.296926
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():

    class _Get(object):
        def __getitem__(self, key):
            return 1

    class _GetGet(object):
        def __getitem__(self, key):
            return _Get()

    class _get_class(object):
        def get_class(self, name):
            if name == 'ByteArray':
                return ByteArrayClass
            elif name == 'flash.net.URLRequestMethod':
                return URLRequestMethodClass
            elif name == 'flash.net.URLRequest':
                return URLRequestClass
            elif name == 'String':
                return StringClass
            else:
                raise NotImplementedError(name)


# Generated at 2022-06-24 14:28:57.743982
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from yaml import load
    from .utils import get_example_file_contents
    from .extractor import _AVMClass, test__AVMClass_register_methods
    _AVMClass.register_methods = test__AVMClass_register_methods
    with io.open(get_example_file_contents('__main__.yml'), 'r', encoding='utf-8') as f:
        expected = load(f)
    avm_class = _AVMClass('Object', 'Object')
    avm_class.register_methods(expected['class']['methods'])
    assert avm_class.make_object() == expected['object']



# Generated at 2022-06-24 14:29:00.186457
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert len({(): _Undefined()}) == 0
    assert str(_Undefined()) == 'undefined'



# Generated at 2022-06-24 14:29:04.366652
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class Foo(object):
        pass
    obj = _AVMClass_Object(Foo)
    assert obj.avm_class == Foo
    assert obj.__repr__() == 'Foo#%x' % id(obj)



# Generated at 2022-06-24 14:29:09.034268
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = AVMClass('Object').make_object()
    assert obj.avm_class.name == 'Object'

    obj2 = AVMClass('Object').make_object()
    assert obj2.avm_class.name == 'Object'

    assert obj is not obj2


# Generated at 2022-06-24 14:29:11.247928
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass(1, '__repr__', static_properties={})
    return obj.__repr__()

# Generated at 2022-06-24 14:29:12.250756
# Unit test for constructor of class _Undefined
def test__Undefined():
    return _Undefined()



# Generated at 2022-06-24 14:29:20.585342
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass(0x1234, '_TestAVMClass', {
        'A': 'B',
    })
    obj = cls.make_object()
    assert cls.name == '_TestAVMClass'
    assert obj.avm_class.name == '_TestAVMClass'
    assert cls.method_names == {'a': 'A', 'b': 'B'}
    assert cls.method_idxs == {0xA: 'a', 0xB: 'b'}
    assert cls.methods == {}
    assert cls.method_pyfunctions == {}
    assert cls.static_properties == {'A': 'B'}
    assert cls.variables == {}
    assert cls.constants == {}



# Generated at 2022-06-24 14:29:22.154177
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

Undefined = _Undefined()



# Generated at 2022-06-24 14:29:31.963206
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from flash_proxy.test_utils import test_swf_interpreter
    from .test_utils import uncompress_swf, parse_abc

    abc_data = uncompress_swf(test_swf_interpreter)
    coder = BytesIO(abc_data)
    swf_interpreter = SWFInterpreter(coder, parse_abc(coder))
    swf_interpreter.patch_methods()

    res = swf_interpreter.call_function('', 'doTest1', '%s %s %s', "a", "b", "c")
    assert res == ['c', 'b', 'a']

    res = swf_interpreter.call_function('', 'doTest2', '%s %s %s', "a", "b", "c")

# Generated at 2022-06-24 14:29:33.343618
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    o = _Undefined()
    r = repr(o)
_Undefined = _Undefined()
del test__Undefined___repr__



# Generated at 2022-06-24 14:29:39.265868
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class _AVMClass_Object:
        def __init__(self):
            self.method_names = {}
            self.method_idxs = {}
    o = _AVMClass_Object()
    _avm_class = _AVMClass(
        name_idx = 0,
        name = '_AVMClass',
        static_properties = {},
    )
    _avm_class.register_methods({
        '<constructor>' : 17,
        'play' : 3,
    })
    assert _avm_class == o

# Generated at 2022-06-24 14:29:40.633335
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(0x5)) == '[MULTINAME kind: 0x5]'

# Generated at 2022-06-24 14:29:45.252732
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    avm_class = _AVMClass(b'Object')
    obj = _AVMClass_Object(avm_class)
    assert repr(obj) == 'Object#%x' % id(obj)
test__AVMClass_Object()



# Generated at 2022-06-24 14:29:48.290691
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class TestClass(object):
        name = 'TestClass'
    assert repr(_ScopeDict(TestClass())) == 'TestClass__Scope({})'
del test__ScopeDict___repr__



# Generated at 2022-06-24 14:29:57.004798
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass(1, 'SomeClass', static_properties={
        'foo': 1,
        'bar': _AVMClass_Object(_AVMClass(2, 'SomeObject')),
    })
    assert cls.name_idx == 1
    assert cls.name == 'SomeClass'
    assert cls.static_properties == {
        'foo': 1,
        'bar': _AVMClass_Object(_AVMClass(2, 'SomeObject')),
    }
    assert cls.variables == _ScopeDict(cls)
    assert cls.variables.avm_class == cls
    assert cls.method_names == {}
    assert cls.method_idxs == {}
    assert cls.methods == {}
    assert cls.method_pyfunctions == {}

# Generated at 2022-06-24 14:30:09.283453
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    intp = SWFInterpreter()
    intp.add_trait(
        'px', 'px',
        _Multiname('http://adobe.com/AS3/2006/builtin', 'MethodClosure'),
        [123, 456, 789])
    intp.add_trait(
        'px', 'py',
        _Multiname('http://adobe.com/AS3/2006/builtin', 'MethodClosure'),
        [123, 456, 789])
    intp.add_trait(
        'px', 'sx',
        _Multiname('http://adobe.com/AS3/2006/builtin', 'MethodClosure'),
        [123, 456, 789])

# Generated at 2022-06-24 14:30:11.543701
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    return _Undefined().__repr__() == 'undefined'

Undefined = _Undefined()



# Generated at 2022-06-24 14:30:17.998998
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass('name', 0)
    assert not avm_class.method_names
    assert not avm_class.method_idxs
    avm_class.register_methods({'func': 0})
    assert {'func': 0} == avm_class.method_names
    assert {0: 'func'} == avm_class.method_idxs

# Generated at 2022-06-24 14:30:28.831763
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(
        name_idx=0xbeef,
        name='TestObject',
        static_properties={
            'a': 1337,
            'b': 'moo'
        })
    assert c.name_idx == 0xbeef
    assert c.name == 'TestObject'
    assert c.static_properties == {
        'a': 1337,
        'b': 'moo'
    }
    assert c.method_names == {}
    assert c.methods == {}
    assert c.method_pyfunctions == {}
    assert c.variables == {'this': _ScopeDict(c, {'a': 1337, 'b': 'moo'})}



# Generated at 2022-06-24 14:30:39.021673
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    assert _builtin_classes['Array'] is list

# Generated at 2022-06-24 14:30:43.352947
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    name = __name__
    static_properties = __name__
    obj = _AVMClass(name, static_properties)
    assert repr(obj) == '_AVMClass(%s)' % name
    assert obj.__repr__() == '_AVMClass(%s)' % (name)



# Generated at 2022-06-24 14:30:50.668712
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    class MySWFInterpreter(SWFInterpreter):
        def __init__(self, *args, **kwargs):
            super(MySWFInterpreter, self).__init__(*args, **kwargs)
            self.load_builtin_classes()
            self.load_default_class()

    swf = MySWFInterpreter('test.swf')
    assert hasattr(swf, 'doAction')
    assert callable(swf.doAction)
    assert hasattr(swf, 'trace')
    assert callable(swf.trace)


# Generated at 2022-06-24 14:30:53.580591
# Unit test for constructor of class _Undefined
def test__Undefined():
    x = _Undefined()
    assert x == _Undefined()
    assert not x
    assert hash(x) == 0
    assert str(x) == 'undefined'
_undefined = _Undefined()



# Generated at 2022-06-24 14:30:57.544584
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    cls = _AVMClass(None, 'Baz')
    inst = cls.make_object()
    assert inst.avm_class == cls



# Generated at 2022-06-24 14:31:08.306855
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter([
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
    ], [
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
    ], [
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
        'abcdefg',
    ])
    avm_class = SWFClass(None, 'ABC', {}, {})
    func_name = 'def'
    swf.extract_function(avm_class, func_name)
    assert func

# Generated at 2022-06-24 14:31:19.322337
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class _TestAVMClass(object):
        def __init__(self, func_name, func, args, kwargs):
            self.method_pyfunctions = {}
            self.variables = {
                'print': lambda x: sys.stdout.write(x),
                'arguments': args,
                'undefined': undefined,
            }