

# Generated at 2022-06-24 14:21:23.781316
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _DummyClass1(object):
        pass
    class _DummyClass2(object):
        pass
    scope1 = _ScopeDict(_DummyClass1)
    scope2 = _ScopeDict(_DummyClass2)
    scope1['a'] = scope2
    scope1['b'] = scope2
    assert scope1 == {'a': scope2, 'b': scope2}



# Generated at 2022-06-24 14:21:26.947081
# Unit test for constructor of class _Undefined
def test__Undefined():
    v = _Undefined()
    assert not v
    assert 'undefined' == str(v)
    assert not hash(v)
test__Undefined()



# Generated at 2022-06-24 14:21:31.085572
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass('avm_class', 'foo', {})
    avm_class.register_methods({
        'setter__bar': 1,
    })
    assert avm_class.method_names == {'setter__bar': 1}
    assert avm_class.method_idxs == {1: 'setter__bar'}



# Generated at 2022-06-24 14:21:33.133370
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass('test', {})
    assert isinstance(cls.variables, _ScopeDict)
    assert isinstance(cls.make_object(), _AVMClass_Object)



# Generated at 2022-06-24 14:21:34.924826
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0x07)



# Generated at 2022-06-24 14:21:39.218703
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import io
    import pickle

    def print_class(cls):
        print('*' * 80)
        print('Class', cls)
        print('Variables:', cls.variables)
        print('Methods:', cls.methods)
        print('Method names:', cls.method_names)
        print('Method functions:', cls.method_pyfunctions)
        print('Static properties:', cls.static_properties)


# Generated at 2022-06-24 14:21:41.721549
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class DummyAVMClass(object):
        name = 'Dummy'
    obj = _AVMClass_Object(DummyAVMClass)
    assert obj.avm_class is DummyAVMClass



# Generated at 2022-06-24 14:21:47.976444
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    f = io.BytesIO(b"\x43\x57\x53"  # Signature
                   b"\x0A\x00\x00\x00"  # Version
                   b"\x00\x00\x00\x00"  # File length
                   b"\x00\x00\x00\x00"  # Frame size
                   b"\x78\x00"  # frame rate
                   b"\x00\x00")  # frame count
    swf = SWF(f)

    swf_interpreter = SWFInterpreter(swf)
    assert swf_interpreter.constant_strings == []
    assert swf_interpreter.multinames == []
    assert swf_interpreter.method_bodies == []
    assert swf_interpre

# Generated at 2022-06-24 14:21:49.567540
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert _Undefined() == False


undefined = _Undefined()



# Generated at 2022-06-24 14:21:52.833550
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert hash(object()) != hash(object())
    assert not bool(_Undefined())
    assert hash(_Undefined()) == 0
    assert _Undefined() == _Undefined()
test__Undefined()
Undefined = _Undefined()



# Generated at 2022-06-24 14:21:59.278773
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter()
    interpreter.read(os.path.join(
        os.path.dirname(__file__), 'testdata', 'test.swf'))
    avm_class = interpreter.extract_class('com.adobe.serialization.json.JSON')
    assert hasattr(avm_class, 'make_object')
    obj = avm_class.make_object()
    assert hasattr(obj, 'parse')
    result = obj.parse('{"a": 1, "b": "c"}')
    assert result == {'a': 1, 'b': 'c'}

# Generated at 2022-06-24 14:22:00.584235
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0x0f)
test__Multiname()



# Generated at 2022-06-24 14:22:02.450889
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
assert not _Undefined()


# Generated at 2022-06-24 14:22:04.736052
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    # Check return value for function __bool__
    assert _Undefined() == False


# Generated at 2022-06-24 14:22:06.087361
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

Undefined = _Undefined()



# Generated at 2022-06-24 14:22:10.025509
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = _AVMClass('class_name_1', 1, 2).make_object()
    assert obj.avm_class == _AVMClass('class_name_1', 1, 2)



# Generated at 2022-06-24 14:22:19.022259
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass('foo', {'m1': 1, 'm2': 2})
    assert avm_class.name == 'foo'
    assert avm_class.method_names == {'m1': 1, 'm2': 2}
    assert avm_class.method_idxs == {1: 'm1', 2: 'm2'}
    assert avm_class.methods == {}
    assert avm_class.method_pyfunctions == {}
    assert avm_class.static_properties == {}
    assert isinstance(avm_class.variables, _ScopeDict)
    assert avm_class.constants == {}



# Generated at 2022-06-24 14:22:20.444950
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert repr(_AVMClass(1, 'test')) == '_AVMClass(test)'


# Generated at 2022-06-24 14:22:22.270829
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined(), repr(_Undefined())
    assert _Undefined().__bool__() == _Undefined().__nonzero__()

# Generated at 2022-06-24 14:22:29.401590
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    classes = {}
    interpreter = SWFInterpreter(classes)
    class_ = interpreter.make_class('FooClass')

    class_.variables['FooVar'] = 42
    class_.variables['BarVar'] = 'Bar'
    class_.static_properties['FooStaticProp'] = 'Foo'
    class_.static_properties['BarStaticProp'] = 24
    class_.method_names.add('FooMethod')

    avm_fun = class_.add_method('FooMethod',
        [[], [_undefined], [_undefined, 42, 'Bar']])

# Generated at 2022-06-24 14:22:30.164780
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


Undefined = _Undefined()



# Generated at 2022-06-24 14:22:32.297618
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    o = _AVMClass_Object(type('bla', (), {}))
    assert o.avm_class.__name__ == 'bla'



# Generated at 2022-06-24 14:22:33.236463
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'

# Generated at 2022-06-24 14:22:41.446688
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert '%r' % _AVMClass_Object(_AVMClass_Object) == 'test_swf._AVMClass_Object#0x%x' % id(_AVMClass_Object)
    assert '%r' % _AVMClass_Object(_AVMClass_Object) == 'test_swf._AVMClass_Object#0x%x' % id(_AVMClass_Object)
test__AVMClass_Object()



# Generated at 2022-06-24 14:22:43.157611
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == 'undefined'



# Generated at 2022-06-24 14:22:51.759144
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-24 14:22:55.075022
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    avm_class = _AVMClass('alpha')
    avm_object = _AVMClass_Object(avm_class)
    assert repr(avm_object) == 'alpha#%x' % id(avm_object)



# Generated at 2022-06-24 14:22:58.977774
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_file = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'test.swf')
    with open(swf_file, 'rb') as f:
        data = f.read()
    SWFInterpreter(data)



# Generated at 2022-06-24 14:23:00.134664
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    assert _AVMClass(1, 'AVMClassName')



# Generated at 2022-06-24 14:23:01.782215
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    assert isinstance(_AVMClass('name_idx', 'name').make_object(), _AVMClass_Object)

# Generated at 2022-06-24 14:23:07.192102
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    my_class = _AVMClass('MyClass')
    my_object = _AVMClass_Object(my_class)
    assert my_object.__repr__() == 'MyClass#' + hex(id(my_object))

    return True
test__AVMClass_Object()



# Generated at 2022-06-24 14:23:09.797136
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_object = _AVMClass_Object(_AVMClass('test'))
    assert class_object.avm_class.name == 'test'
    assert class_object.avm_class is not None



# Generated at 2022-06-24 14:23:12.178787
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    expected_value = '_ScopeDict__Scope({})'
    # Test method __repr__ of class _ScopeDict
    assert repr(_ScopeDict(None)) == expected_value



# Generated at 2022-06-24 14:23:17.104467
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    method_names = {'foo': 3}
    static_properties = {'bar': 'baz'}
    avm_class = _AVMClass('foo', method_names=method_names, static_properties=static_properties)
    assert repr(avm_class) == '_AVMClass(foo)'



# Generated at 2022-06-24 14:23:18.588991
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x07).kind == 0x07



# Generated at 2022-06-24 14:23:19.610417
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0x1)



# Generated at 2022-06-24 14:23:30.406077
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io
    import json
    import SWFInterpreter
    import SWFParser
    import pyamf
    with io.open('testdata/get_video_info.swf', 'rb') as swfdata:
        swf = SWFParser.parse(swfdata)
        interpreter = SWFInterpreter.SWFInterpreter(swf)
        f = interpreter.extract_function(
                interpreter.avm_classes[22], 'get_video_info')
        if not hasattr(f.__code__, 'co_filename'):
            # For Python 3.4 and earlier
            f.__code__.co_filename = '<generated code>'

# Generated at 2022-06-24 14:23:34.239727
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    # Create an instance of class _AVMClass with appropriate arguments
    args = ()
    obj = _AVMClass(*args)
    # Now call the method __repr__ to test it
    try:
        retval = obj.__repr__()
    except Exception as e:
        raise AssertionError(type(e))



# Generated at 2022-06-24 14:23:37.344934
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'

undefined = _Undefined()



# Generated at 2022-06-24 14:23:41.504320
# Unit test for constructor of class _Undefined
def test__Undefined():
    return (
        _Undefined() is not None and
        _Undefined() is not True and
        hash(_Undefined()) == 0 and
        str(_Undefined()) == 'undefined' and
        repr(_Undefined()) == 'undefined')

_undefined = _Undefined()



# Generated at 2022-06-24 14:23:42.478235
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()) is False



# Generated at 2022-06-24 14:23:43.094489
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


# Generated at 2022-06-24 14:23:43.936971
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

_undefined = _Undefined()



# Generated at 2022-06-24 14:23:46.692645
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    for byte_order in (0, 1, 2, 3):
        _ = _AVMClass_Object(
            _AVMClass('foo', None, {}, {}, {}, {}, None, byte_order))



# Generated at 2022-06-24 14:23:50.157817
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class AVMClass:
        pass
    foo = _AVMClass_Object(AVMClass)
    assert foo.avm_class is AVMClass



# Generated at 2022-06-24 14:23:53.459119
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(0)
    assert repr(obj) == '[MULTINAME kind: 0x0]'


# Generated at 2022-06-24 14:24:01.568138
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(123, 'SomeClass', static_properties={'a': [1, 2, 3]})
    assert c.name_idx == 123
    assert c.name == 'SomeClass'
    assert c.static_properties == {'a': [1, 2, 3]}
    assert c.variables == {}
    assert c.constants == {}
    assert c.method_names == {}
    assert c.method_idxs == {}
    assert c.methods == {}
    assert c.method_pyfunctions == {}

    c.variables['abc'] = 5
    assert c.variables == {'abc': 5}
    assert repr(c.variables) == 'SomeClass__Scope({\'abc\': 5})'
    assert repr(c) == '_AVMClass(SomeClass)'

   

# Generated at 2022-06-24 14:24:04.423924
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    # Check that a simple _AVMClass object is correctly represented as a string
    assert repr(
        _AVMClass('foobar', 'foobar', {})
    ) == "_AVMClass('foobar')", (
        '_AVMClass should be represented with its name'
    )



# Generated at 2022-06-24 14:24:07.657484
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass(0, 'TestClass')
    a = avm_class.make_object()
    assert a.avm_class == avm_class, 'a.avm_class = %r' % (a.avm_class,)

# Generated at 2022-06-24 14:24:11.480921
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    # Unit test for method __repr__ of class _AVMClass
    class_ = _AVMClass('a', 'b')
    assert repr(class_) == '_AVMClass(b)'

# Generated at 2022-06-24 14:24:14.829531
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(0, '')
    c.register_methods({'foo': 23, 'bar': 42})
    assert c.method_names == {'foo': 23, 'bar': 42}
    assert c.method_idxs == {23: 'foo', 42: 'bar'}



# Generated at 2022-06-24 14:24:24.846079
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    with open(filename, 'rb') as f:
        rawdata = f.read()
        tags = _read_swf(rawdata)
        swf = SWF(tags)

        constants = swf.tags[0].constants
        constant_strings = swf.tags[0].constant_strings
        constant_namespaces = swf.tags[0].constant_namespaces
        constant_namespace_sets = swf.tags[0].constant_namespace_sets
        constant_multinames = swf.tags[0].constant_multinames
        scripts = swf.tags[1].scripts

        interpreter = SWFInterpreter(constants, constant_strings,
                constant_namespaces, constant_namespace_sets,
                constant_multinames)


# Generated at 2022-06-24 14:24:26.256653
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    pass


# Generated at 2022-06-24 14:24:27.996702
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class_ = _AVMClass('name', 'name')
    return class_



# Generated at 2022-06-24 14:24:37.293351
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    mp3_class = _AVMClass(0x00, 'MP3')
    mp3_class.register_methods({
        'play': 1,
        'stop': 2,
        'gotoFrame': 3,
        'nextFrame': 4,
        'prevFrame': 5,
    })
    mp3_class.method_pyfunctions[1] = lambda: None
    mp3_class.method_pyfunctions[2] = lambda: None
    assert repr(mp3_class) == "_AVMClass('MP3')", repr(mp3_class)
    assert repr(mp3_class.method_names) == "{'gotoFrame': 3, 'nextFrame': 4, 'play': 1, 'prevFrame': 5, 'stop': 2}", repr(mp3_class.method_names)
    assert repr

# Generated at 2022-06-24 14:24:41.080760
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_ = _AVMClass('TestClass')
    class_object = _AVMClass_Object(class_)
    assert class_object.avm_class == class_



# Generated at 2022-06-24 14:24:47.589762
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not bool(_Undefined())
    assert bool(_Undefined()) is False
    assert _Undefined() == _Undefined()
    assert not (_Undefined() == None)
    assert _Undefined() + 1 == 1
    assert 1 + _Undefined() == 1
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'



# Generated at 2022-06-24 14:24:56.243933
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open(os.path.join(_TEST_DIR, 'minimal.swf'), 'rb') as f:
        data = f.read()
        swf_parser = SWFParser(data)
        swf_parser.parse()
        min_swf_interpreter = SWFInterpreter(
            swf_parser, swf_parser.abc_multinames, swf_parser.abc_strings,
            swf_parser.abc_name)
    with open(os.path.join(_TEST_DIR, 'tiny.swf'), 'rb') as f:
        data = f.read()
        swf_parser = SWFParser(data)
        swf_parser.parse()

# Generated at 2022-06-24 14:25:08.496397
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from pytest import raises
    class TestAVMClass(_AVMClass):
        def __init__(self, name_idx, name, static_properties):
            self.name_idx = name_idx
            self.name = name
            self.method_names = {}
            self.method_idxs = {}
            self.methods = {}
            self.method_pyfunctions = {}
            self.static_properties = static_properties
            self.variables = {}
            self.constants = {}

    methods = {
        'method_1': 1,
        'method_2': 2,
    }
    test_avm_class = TestAVMClass(
        name_idx='test_name_idx',
        name='test_name',
        static_properties={})
    test_avm_

# Generated at 2022-06-24 14:25:13.204741
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    name_idx = 0
    name = ''
    static_properties = None
    unit_test_instance = _AVMClass(name_idx, name, static_properties)
    expected = '_AVMClass(%s)' % (name)
    assert repr(unit_test_instance) == expected


# Generated at 2022-06-24 14:25:17.428171
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass('test', 'test')
    assert c.method_names == {}
    c.register_methods({'foo': 12, 'bar': 42})
    assert c.method_names == {'foo': 12, 'bar': 42}
    assert c.method_idxs == {12: 'foo', 42: 'bar'}



# Generated at 2022-06-24 14:25:18.776240
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    return _AVMClass_Object(None)



# Generated at 2022-06-24 14:25:26.743069
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swfi = SWFInterpreter()

# Generated at 2022-06-24 14:25:38.223154
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swftags import TagDoABC, TagDoABCDefine
    from .swfheader import SWFInfo

    info = SWFInfo(
        file_size=0,
        frame_size=0,
        frame_rate=0,
        frame_count=0,
    )
    class_name = 'SomeClass'

# Generated at 2022-06-24 14:25:50.857109
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s = bz2.BZ2File(
        os.path.join(os.path.dirname(__file__), 'test', 'A.swf')).read()
    s = compat_bytes(s)
    a = SWFInterpreter(s)

    def get_register_count(method):
        assert isinstance(method, tuple)
        max_index = method[4]
        for inner in method[-1]:
            assert isinstance(inner, tuple)
            inner_max_index = inner[4]
            if inner_max_index > max_index:
                max_index = inner_max_index
        return max_index

    assert get_register_count(a.methods['getServersURL']) == 2


# Hack to avoid import errors of avm_class.method_pyfunction


# Generated at 2022-06-24 14:26:03.331712
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    assert SWFInterpreter.extract_class({
        'methods': [
            'function1',
            {'name': 'function2', 'code': b'\3'},
            {'name': 'function3', 'body': None},
        ],
    }) == {
        'function1': None,
        'function2': lambda: undefined,
        'function3': None,
    }
    assert SWFInterpreter.extract_class({
        'methods': [
            {'name': 'function1', 'body': None},
            {'name': 'function2', 'body': None},
            {'name': 'function3', 'body': None},
        ],
    }) == {
        'function1': None,
        'function2': None,
        'function3': None,
    }


# Generated at 2022-06-24 14:26:14.167279
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x00)) == '[MULTINAME kind: 0x00]'


_CONSTANT_KINDS = {
    0x00: 'undefined',
    0x01: 'string',
    0x03: 'float',
    0x06: 'namespace',
    0x08: 'true',
    0x0A: 'false',
    0x0B: 'null',
    0x0D: 'qname',
    0x0E: 'namespace_set',
    0x0F: 'multiname',
    0x10: 'int',
    0x11: 'uint',
    0x16: 'name',
}



# Generated at 2022-06-24 14:26:16.447141
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    '''Test the method that returns a string representation of the object
    '''
    return True

# Generated at 2022-06-24 14:26:18.337584
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    _AVMClass('name_idx', 'name').make_object()


# Generated at 2022-06-24 14:26:21.084916
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    obj = _Undefined()
    assert obj.__repr__() == 'undefined'


_undefined = _Undefined()



# Generated at 2022-06-24 14:26:23.560637
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not bool(_Undefined())
    assert 0 == hash(_Undefined())
    assert 'undefined' == str(_Undefined())



# Generated at 2022-06-24 14:26:24.638755
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    SWFInterpreter('')


# Generated at 2022-06-24 14:26:26.330557
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0x7).__repr__()



# Generated at 2022-06-24 14:26:35.021043
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from .compat import (
        compat_str,
        )
    from .utils import (
        make_method_closure,
        )

    cc = _AVMClass(0, 'TestClass', {})
    assert(compat_str(cc.__repr__()) == '_AVMClass(TestClass)')
    cc.register_methods({
        'foo': 0,
        'bar': 1,
        })
    assert(compat_str(cc.method_names) ==
        "{'foo': 0, 'bar': 1}")
    assert(compat_str(cc.method_idxs) ==
        "{0: 'foo', 1: 'bar'}")
    assert(not cc.methods)
    # Add a dummy method to test object

# Generated at 2022-06-24 14:26:37.397810
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == str(_Undefined())

UNDEFINED = _Undefined()


# Generated at 2022-06-24 14:26:39.155481
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 14:26:43.669899
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    multiname = _Multiname(0)
    assert repr(multiname) == '[MULTINAME kind: 0x0]'
    multiname = _Multiname(0x102)
    assert repr(multiname) == '[MULTINAME kind: 0x102]'
test__Multiname___repr__()



# Generated at 2022-06-24 14:26:45.310251
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:26:47.580506
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert repr(_ScopeDict(None)) == 'None__Scope({})'



# Generated at 2022-06-24 14:26:57.931514
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    _SWFInterpreter_extract_class = get_method_function(
        SWFInterpreter, '_extract_class')
    si = SWFInterpreter('http://localhost/test.swf')

    # Test extraction of native classes
    assert _SWFInterpreter_extract_class(si, 'Object') is dict
    assert _SWFInterpreter_extract_class(si, 'Array') is list

    # Test extraction of user-defined classes

# Generated at 2022-06-24 14:27:07.179945
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from . import swfdec_swf_interpreter
    coder = swfdec_swf_interpreter.SWFDecoder()
    coder.seek(0)

    coder.offset_to_data[0] = 0
    coder.read_to_offset[0] = 0
    coder.offset_to_data[1] = 0
    coder.read_to_offset[1] = 0


# Generated at 2022-06-24 14:27:11.411342
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    s = _ScopeDict('avm_class')
    s['a'] = 1
    s.update({'b': 2, 'c': 3})
    assert repr(s) == "'avm_class__Scope({'a': 1, 'b': 2, 'c': 3})'"
test__ScopeDict()



# Generated at 2022-06-24 14:27:14.760642
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    avm_class = SWFInterpreter(b'').extract_class({})
    assert isinstance(avm_class.variables['Object'], _AVMClass)
    assert isinstance(avm_class.variables['String'], _AVMClass)
    assert isinstance(avm_class.variables['Array'], _AVMClass)


# Generated at 2022-06-24 14:27:15.965577
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:27:17.347407
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    undef = _Undefined()
    assert hash(undef) == 0
    assert hash(undef) == 0



# Generated at 2022-06-24 14:27:21.757021
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    obj = _AVMClass_Object(None)
    assert repr(obj) == 'None#%x' % id(obj)



# Generated at 2022-06-24 14:27:25.397299
# Unit test for method __repr__ of class _Undefined

# Generated at 2022-06-24 14:27:29.312267
# Unit test for constructor of class _Undefined
def test__Undefined():
    u = _Undefined()
    assert not u
    assert False, u
    assert {}[u] == 2
    assert (u, u)
    assert {}[(u, u)] == 3
    assert str(u) == 'undefined'
    assert repr(u) == 'undefined'



# Generated at 2022-06-24 14:27:33.469365
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert (
        repr(
            _ScopeDict(_AVMClass_Object('SomeClass'), x=1)) ==
        'SomeClass__Scope(dict(x=1))')


# Generated at 2022-06-24 14:27:34.703866
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0x09)



# Generated at 2022-06-24 14:27:35.951358
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


# Generated at 2022-06-24 14:27:47.503771
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter(six.BytesIO(b''))
    method_id = 0
    body_id = 0
    names = ['a', 'b']
    params = [object(), object()]
    for name, param in zip(names, params):
        assert not hasattr(param, 'avm_name')
        swf.add_variable(name, param)
    swf.patch_function(method_id, body_id)
    method = swf.methods[method_id]
    assert list(method.params) == params
    assert [p.avm_name for p in method.params] == names
    pyfunc = swf.method_pyfunctions[method_id]
    assert pyfunc.__code__.co_varnames == names


# Generated at 2022-06-24 14:27:49.500838
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _AVMClass(object):
        pass
    _ScopeDict(_AVMClass())



# Generated at 2022-06-24 14:27:56.268468
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert _Undefined() == _Undefined()
    assert not (_Undefined() == [] or _Undefined() == '')
    assert _Undefined() != []
    assert _Undefined() != ''
    assert _Undefined() != None
    assert _Undefined() != 0
    assert _Undefined() != False
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'

Undefined = _Undefined()

# TODO: Find out what ActionScript 2.0 specs say about this object

# Generated at 2022-06-24 14:27:58.199132
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    str(_AVMClass_Object('foo'))
    str(_AVMClass_Object('foo'))

# Generated at 2022-06-24 14:28:11.981765
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-24 14:28:12.871891
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    ins = _Undefined()
    assert isinstance(ins, _Undefined)
    assert not ins

# Generated at 2022-06-24 14:28:18.630887
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    r = _Undefined()
    assert r == _Undefined()
    r2 = _Undefined()
    assert r == r2
    assert hash(r) == hash(r2)
    assert hash(r) == hash(_Undefined())
    assert hash(r) == 0
    assert hash(r) == hash(_Undefined())



# Generated at 2022-06-24 14:28:20.645499
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    u = _Undefined()
    assert not u

# Generated at 2022-06-24 14:28:30.932769
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    '''
    assert _Undefined() == _Undefined()
    '''

GLOBAL_SCOPE = _ScopeDict(None)
GLOBAL_SCOPE['undefined'] = _Undefined()
GLOBAL_SCOPE['NaN'] = float('nan')
GLOBAL_SCOPE['Infinity'] = float('inf')

_method_names = {}
_method_names['add'] = lambda x, y: x + y
_method_names['subtract'] = lambda x, y: x - y
_method_names['multiply'] = lambda x, y: x * y
_method_names['divide'] = lambda x, y: x / y
_method_names['modulo'] = lambda x, y: x % y
_method_names['increment'] = lambda x: x + 1


# Generated at 2022-06-24 14:28:36.017836
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class_ = _AVMClass(name_idx=0,
                       name='SomeClassName',
                       static_properties=dict())
    instance = class_.make_object()

    assert isinstance(instance, _AVMClass_Object)
    assert instance.avm_class == class_



# Generated at 2022-06-24 14:28:43.865654
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    def run_test(stream):
        interp = SWFInterpreter(stream)
        interp.construct_method_pyfunctions()
        res = interp.extract_function(interp.avm_class, '_init')()
        return res


# Generated at 2022-06-24 14:28:48.967054
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(0, 'SomeClass')
    c.register_methods({
        'foo': 1,
        'bar': 2,
    })
    assert c.method_names == {'foo': 1, 'bar': 2}
    assert c.method_idxs == {1: 'foo', 2: 'bar'}



# Generated at 2022-06-24 14:28:51.888736
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class ExampleAVMClass(object):
        name = 'Example'
    assert repr(_ScopeDict(ExampleAVMClass())) == 'Example__Scope({})'



# Generated at 2022-06-24 14:28:54.237004
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    obj = _AVMClass_Object(_AVMClass_Object(None))
    assert repr(obj) == '_AVMClass_Object#%x' % id(obj)



# Generated at 2022-06-24 14:28:57.330931
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    testval = _Undefined()
    res = testval.__repr__()
    assert res == 'undefined'


# Generated at 2022-06-24 14:28:59.585115
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # TODO: fix this
    return
    # Check for a valid constructor
    assert SWFInterpreter('') is not None



# Generated at 2022-06-24 14:29:03.348887
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = _AVMClass('Dummy', None).make_object()
    assert isinstance(obj, _AVMClass_Object)
    assert obj.avm_class.name == 'Dummy'



# Generated at 2022-06-24 14:29:06.666620
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class Object(object):
        pass
    assert _AVMClass_Object(Object).__repr__() == 'Object#%x' % id(_AVMClass_Object(Object))



# Generated at 2022-06-24 14:29:10.828205
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    dict_ = _ScopeDict('avm_class')
    dict_['_namespace'] = 'namespace'
    assert (dict_ ==
            eval(repr(_ScopeDict('avm_class')))('avm_class'))



# Generated at 2022-06-24 14:29:16.349207
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    for _AVMClass_Object, _ScopeDict, _AVMClass in [
            (object, dict, object)]:
        unit_test_instance = _AVMClass(
            name_idx=1, name=2, static_properties=3)
        unit_test_object = unit_test_instance.make_object()
        assert isinstance(unit_test_object, _AVMClass_Object)



# Generated at 2022-06-24 14:29:18.250542
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-24 14:29:22.206238
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class SampleAVMClass(object):
        name = 'SampleAVMClass'
    obj = _AVMClass_Object(SampleAVMClass)
    assert str(obj) == 'SampleAVMClass#%x' % id(obj)



# Generated at 2022-06-24 14:29:32.024598
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    intpr = SWFInterpreter()
    foo_cls = intpr.extract_class('Foo', [])
    bar_cls = intpr.extract_class('Bar', ['foo=5'])
    foo_cls_data = intpr.extract_data('Foo', [], [])
    bar_cls_data = intpr.extract_data('Bar', ['foo=5'], [])
    foo_inst = foo_cls.instantiate(foo_cls_data)
    bar_inst = bar_cls.instantiate(bar_cls_data)

# Generated at 2022-06-24 14:29:34.034551
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert type(_Undefined()) is _Undefined
    assert len({_Undefined(): 1}) == 0
    assert len({_Undefined(): 1, _Undefined(): 1}) == 0
Undefined = _Undefined()



# Generated at 2022-06-24 14:29:34.682858
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__(): pass

# Generated at 2022-06-24 14:29:38.639191
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from yalafi import defs
    o = defs.avm_classes.get('String', None).make_object()
    assert o.avm_class == defs.avm_classes['String']
    assert str(o) == 'String#%x' % id(o)

# Generated at 2022-06-24 14:29:45.373240
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = _test_swf()
    swf_interpreter = SWFInterpreter()
    swf_interpreter.read(swf)
    assert len(swf_interpreter.extract_class('Module4').method_pyfunctions) == 2
    assert len(swf_interpreter.extract_class('ProxyInnerClass').method_pyfunctions) == 1
    assert ('printInnerClasses(s:String,s:String,s:String,s:String,s:String,s:String,s:String,s:String)'
            in swf_interpreter.extract_class('Module4').method_pyfunctions)
    assert ('printInnerClasses()' in swf_interpreter.extract_class('Module4').method_pyfunctions)

# Generated at 2022-06-24 14:29:55.249105
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(0, 'Object', {})
    c.register_methods(dict(
        m0=0,
        m2=2,
    ))
    assert c.method_names == dict(
        m0=0,
        m2=2,
    )


# class _AVMMethod(object):
#     def __init__(self, arguments):
#         self.arguments = arguments
#         self.name = None
#         self.body = None
#         self._implemented = False
#
#     def implement(self, body):
#         self.body = body
#         self._implemented = True
#
#     def __repr__(self):
#         return '_AVMMethod(%s%s)' % (
#             self.name,
#            

# Generated at 2022-06-24 14:30:01.291114
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    inst = _AVMClass('name_idx', 'name', 'static_properties')
    methods = {}
    inst.register_methods(methods)
    assert inst.method_names == {}
    assert inst.method_idxs == {}
    assert inst.methods == {}
    assert inst.method_pyfunctions == {}



# Generated at 2022-06-24 14:30:05.626579
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    method = '__repr__'
    v = _AVMClass(2, 'MyClass')
    assert eval(repr(v)) == v


# Generated at 2022-06-24 14:30:08.452432
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'
_undefined = _Undefined()



# Generated at 2022-06-24 14:30:12.334041
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .avm import _AVMClass
    assert repr(_AVMClass_Object(_AVMClass(None))) == 'None#25452896'
test__AVMClass_Object___repr__()



# Generated at 2022-06-24 14:30:25.296915
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # First extract a dummy class
    f = io.BytesIO()
    add_swf_header(f)
    add_swf_tags(f, [
        DoABC(flags=0, name='', data=encode_abce(ABCExporter().export_class(
            class_name='dummy',
            attributes=['private'],
            base_class=object,
            init_function_code=b'\x02\x00\x14\x7f\x01\x02\x01\x1a\x04'
                                b'\x0f\x01\x00\x0a')),),
    ])

    swf = SWF(f)
    swf.seek(0)  # Needed for SWFInterpreter
    interpreter = SWFInterpreter(swf)

# Generated at 2022-06-24 14:30:28.795233
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(4, 'Test')
    assert c.method_names == {}
    assert c.method_idxs == {}
    c.register_methods({'test1': 1, 'test2': 2})
    assert c.method_names == {'test1': 1, 'test2': 2}
    assert c.method_idxs == {1: 'test1', 2: 'test2'}



# Generated at 2022-06-24 14:30:29.484925
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    pass

# Generated at 2022-06-24 14:30:34.306178
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_def_tag = (0x1, b'\x00\x03foo\x00\x04blah')
    class_def = _AVMClass_Object(class_def_tag)
    assert repr(class_def) == 'foo#%x' % id(class_def)
test__AVMClass_Object()



# Generated at 2022-06-24 14:30:35.673354
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
    assert not _Undefined()



# Generated at 2022-06-24 14:30:39.364583
# Unit test for constructor of class _Multiname
def test__Multiname():
    mn = _Multiname(0x07)
    assert str(mn) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:30:43.505258
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .tests import AVMFileTest
    inst = AVMFileTest.inst
    assert inst._avm_make_object().avm_class == inst._avm_get_class('Object')
    assert inst._avm_make_object(
            inst._avm_get_class('Video')).avm_class == inst._avm_get_class('Video')



# Generated at 2022-06-24 14:30:46.143741
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class_info = _AVMClass_Object(_AVMClass(None, 'Foo'))
    assert repr(class_info) == "Foo#" + hex(id(class_info))[2:]



# Generated at 2022-06-24 14:30:49.845277
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(0x02)) == '[MULTINAME kind: 0x2]'


# Generated at 2022-06-24 14:30:59.963062
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    method_names = {}
    method_idxs = {}
    methods = {}
    method_pyfunctions = {}
    static_properties = {}
    avm_class = _AVMClass(4, 'name', None)
    _methods = {40: 'method'}
    avm_class.register_methods(_methods)
    # If we would get the same dict, we would get a different id
    assert id(avm_class.method_names) != id(method_names)
    assert avm_class.method_names == {'method': 40}
    assert avm_class.method_idxs == {40: 'method'}



# Generated at 2022-06-24 14:31:00.922369
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x07).kind == 0x07



# Generated at 2022-06-24 14:31:10.600585
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swfinterpreter = SWFInterpreter()
    swfinterpreter.avm_class = _AVMClass()
    swfinterpreter.constant_strings = [""]
    swfinterpreter.multinames = [None]
    swfinterpreter.traits = [_Traits()]
    coder = bytearray([-1, -1])
    coder = compat_StringIO(coder)
    swfinterpreter.patch_function(coder, "", "")

# TODO: test for method run_code of class SWFInterpreter
# class _AVMClass(object):
#     """Object representing a class"""
#     def __init__(self, super_class, constructor_name, variables,
#                  static_properties, method_names, method_pyfun

# Generated at 2022-06-24 14:31:13.319697
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    cls = _AVMClass('Test', {})
    assert cls.make_object()

# Generated at 2022-06-24 14:31:18.050386
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    import nose.tools

    class _TestAVMClass(_AVMClass):
        pass

    test_avm_class = _TestAVMClass(0, '_TestAVMClass')
    nose.tools.assert_is_instance(test_avm_class.make_object(), _AVMClass_Object)



# Generated at 2022-06-24 14:31:26.246388
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io
    import os
    import unittest

    TEST_FILE = os.path.join(os.path.dirname(__file__), 'flash/flash.swf')
    ASSET_FILE = os.path.join(os.path.dirname(__file__), 'flash/asset.swf')

    class MockOutput(object):
        def __init__(self, *args, **kwargs):
            pass

        def write(self, *args, **kwargs):
            pass

        def read(self, *args, **kwargs):
            pass

        def close(self, *args, **kwargs):
            pass

        def flush(self, *args, **kwargs):
            pass
