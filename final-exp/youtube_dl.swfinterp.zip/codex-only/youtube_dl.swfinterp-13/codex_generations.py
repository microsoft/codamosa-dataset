

# Generated at 2022-06-24 14:21:18.056613
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    _AVMClass_Object(None)



# Generated at 2022-06-24 14:21:30.263556
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class StubTag(object):
        kind = None

    interpreter = SWFInterpreter()
    avm_class = _AVMClass()

    @interpreter.patch_function(avm_class=avm_class, func_name='foo')
    def func():
        return 0

    assert interpreter.extract_function(avm_class, 'foo')() == 0

    @interpreter.patch_function(
        avm_class=avm_class, func_name='foo', tag=StubTag)
    def func():
        return 1

    assert interpreter.extract_function(avm_class, 'foo')() == 1

    @interpreter.patch_function(avm_class=avm_class, func_name='foo')
    def func():
        return 2

    assert interpreter.extract

# Generated at 2022-06-24 14:21:40.709165
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    if False:  # Skip this test
        raise unittest.SkipTest()

    def _cmp_class(cls):
        if cls.__name__ == 'classobj':
            return True
        return False

    # Testing the interpreter in the simple case
    # (without protected and package internal methods)
    from .swftags import DoABC
    from .swftags import Tag, TagPlaceObject2
    from .swftags import TagDefineSprite, TagShowFrame


# Generated at 2022-06-24 14:21:41.789919
# Unit test for constructor of class _Multiname
def test__Multiname():
    name = _Multiname(10)
    assert name.kind == 10



# Generated at 2022-06-24 14:21:44.501443
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    name = "name"
    o = _AVMClass(1, name)
    r = repr(o)
    assert r == "_AVMClass(%s)" % name


# Generated at 2022-06-24 14:21:48.265981
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert _AVMClass_Object(_AVMClass('Dummy')).__repr__() == 'Dummy#<id>'


# Generated at 2022-06-24 14:21:49.982731
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert (bool(_Undefined()) == False)

# Generated at 2022-06-24 14:21:50.915070
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 14:21:55.756349
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class AGNOSTIC(_AVMClass_Object):
        def __init__(self, *args, **kwargs):
            _AVMClass_Object.__init__(self, *args, **kwargs)
    assert repr(AGNOSTIC(_AVMClass_Object)) == '_AVMClass_Object#0x%x' % id(AGNOSTIC(_AVMClass_Object))



# Generated at 2022-06-24 14:21:58.428682
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # nop, pushstring, returnvalue
    hexbytes = '02 02 00 0f 07 68 65 6c 6c 6f'
    ints = list(map(int, hexbytes.split()))
    interp = SWFInterpreter(ints)
    res = interp.extract_function(None, 'some_func')()
    assert res == 'hello'


# Generated at 2022-06-24 14:22:00.736751
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    result = _Multiname(0).__repr__()
    assert result == '[MULTINAME kind: 0x0]'


# Generated at 2022-06-24 14:22:04.773657
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    # Create an _AVMClass object
    x = _AVMClass('name_idx', 'name')

    # Invoke method
    x.register_methods(dict())


# Interface: DoActionScript

# Generated at 2022-06-24 14:22:06.131547
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    _Multiname(0x0).__repr__()

# Generated at 2022-06-24 14:22:10.165430
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.extract_function(None, None, None, None)
test_SWFInterpreter_extract_function()


# Generated at 2022-06-24 14:22:13.606901
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    name = 'dummy'
    static_properties = None
    a = _AVMClass(3, name, static_properties)
    assert repr(a) == '_AVMClass(dummy)'

# Generated at 2022-06-24 14:22:23.030768
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(None)

    assert swf.extract_function(None, 'toString') == swf._to_string
    assert swf.extract_function(ObjectClass, 'toString') == swf._to_string
    assert swf.extract_function(StringClass, 'toString') == swf._to_string
    assert swf.extract_function(ArrayClass, 'toString') == swf._to_string
    assert swf.extract_function(BooleanClass, 'toString') == swf._to_string
    assert swf.extract_function(NumberClass, 'toString') == swf._to_string
    assert swf.extract_function(MathClass, 'toString') == swf._to_string

# Generated at 2022-06-24 14:22:29.168785
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    methods = {
        'one': 1,
        'two': 2,
    }
    expected_method_names = {
        'one': 1,
        'two': 2,
    }
    expected_method_idxs = {
        1: 'one',
        2: 'two',
    }
    avm_class = _AVMClass('testing!', 'testing!')
    avm_class.register_methods(methods)
    assert avm_class.method_names == expected_method_names
    assert avm_class.method_idxs == expected_method_idxs



# Generated at 2022-06-24 14:22:31.376755
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    o1 = _Undefined()
    o2 = _Undefined()
    assert o1 is o2
    assert hash(o1) == hash(o2)
_undefined = _Undefined()



# Generated at 2022-06-24 14:22:36.803937
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import io
    from ..utils import (
        hex_to_bytes, xrange, compat_str, _Infinity, _Undefined)
    from ..amf import loads as amf_loads
    from ..compat import (
        compat_urlparse, compat_HTTPError, compat_struct_pack, compat_urllib_error,
        compat_urllib_request)
    from ..swfinterp import (
        SWFInterpreter, SWFMethod, SWFMultiname, SWFValue, _Multiname,
        _AVMClass, _AVMClass_Object, _Undefined)

    _builtin_classes = {
        'String': StringClass,
        'Number': NumberClass,
        'Boolean': BooleanClass,
        'Array': ArrayClass,
    }

    def s24():
        return

# Generated at 2022-06-24 14:22:48.140764
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # No unit test as method extract_function of class SWFInterpreter is
    # used in other unit test tests.
    return True

# Class SWFInterpreter:
# Methods:
#     parse_script
#     parse_swf
#     extract_methods
#     extract_val
#     extract_val_id
#     extract_val_type
#     extract_val_val
#     parse_value
#     parse_multinames
#     parse_method_body
#     parse_script
#     parse_class
#     parse_constants
#     parse_methods
#     parse_instance
#     parse_metadata
#     parse_class
#     parse_annotation
#     parse_script_tags
#     parse_script_tag
#     parse_do_abc
#     parse_do

# Generated at 2022-06-24 14:22:56.630591
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    multi = _Multiname(1)
    assert 'kind: 0x1' in repr(multi)

_MULTINAME_KIND = {
    0x07: 'QName',
    0x0D: 'RTQName',
    0x0F: 'RTQNameL',
    0x10: 'Multiname',
    0x11: 'MultinameL',
    0x09: 'Multiname_A',
    0x0E: 'Multiname_L',
    0x1B: 'Multiname_LA',
    0x0C: 'TypeName',
}

# Generated at 2022-06-24 14:22:58.540082
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    _Undefined()
# End unit test for method __repr__ of class _Undefined


# Generated at 2022-06-24 14:23:05.445526
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    constants = [
        '', ' ', '.', '..', 'http://', 'http://a', 'http://a/',
        'http://a/b', 'http://a/b/', 'http://a/b/c', 'http://a/b/c/',
    ]
    constant_indexes = {
        'http://a': 3, 'http://a/': 4, 'http://a/b': 5, 'http://a/b/': 6,
        'http://a/b/c': 7, 'http://a/b/c/': 8, 'http://': 2, ' ': 1,
        '': 0, '.': 3, '..': 4,
    }

# Generated at 2022-06-24 14:23:07.965782
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avmc = _AVMClass(None, 'Foo')
    avmo = avmc.make_object()
    assert avmo.avm_class is avmc
test__AVMClass_make_object()


# Generated at 2022-06-24 14:23:09.004527
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    import pytest
    assert _Undefined().__hash__() == 0


# Generated at 2022-06-24 14:23:11.242428
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    o = _Undefined()
    o.__repr__()


_undefined = _Undefined()

# Generated at 2022-06-24 14:23:17.946557
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(0, 'TestClass')
    avm_class.register_methods({1: 'method1', 2: 'method2'})
    assert avm_class.method_names == {
        'method1': 1,
        'method2': 2,
        }
    assert avm_class.method_idxs == {
        1: 'method1',
        2: 'method2',
        }



# Generated at 2022-06-24 14:23:18.593479
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    pass

# Generated at 2022-06-24 14:23:22.197823
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_ = _AVMClass_Object(_AVMClass_Object)
    assert repr(class_) == '_AVMClass_Object#0x%08x' % id(class_)



# Generated at 2022-06-24 14:23:25.593535
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    print('\n\nTesting test__AVMClass___repr__:')
    avmclass = _AVMClass(None, None, None)
    print(repr(avmclass))


# Generated at 2022-06-24 14:23:27.684078
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert (
        repr(_Multiname(2))
        ==
        '[MULTINAME kind: 0x2]')

# Generated at 2022-06-24 14:23:37.498783
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s = io.BytesIO(b'\x01\x02\x00\x00\x00\x00\x03\x04')
    class Test:
        def __init__(self, f, start, size):
            self.fp = f
            self.start = start
            self.size = size
    swf = Test(s, 0, 8)
    swf_interpreter = SWFInterpreter(swf, verbose=False, dump_decompiled=False)
    # Check the magic number
    assert swf_interpreter.magic == b'CWS'
    # Check the two integers
    assert swf_interpreter.version == 2
    assert swf_interpreter.file_length == 7


# Generated at 2022-06-24 14:23:39.047164
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x07).kind == 0x07



# Generated at 2022-06-24 14:23:41.183246
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(
        _AVMClass_Object(avm_class=_AVMClass('DoNotCall_AVMClass_Object')))



# Generated at 2022-06-24 14:23:45.449714
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    for filename, tests in _TESTS.items():
        if 'SWFInterpreter.extract_class' not in tests:
            continue

        swf = tests['SWFInterpreter.extract_class']['swf']
        expected = tests['SWFInterpreter.extract_class']['expected']

        swf_interpreter = SWFInterpreter(swf)
        res = swf_interpreter.extract_class(expected['name'])

        assert res.name == expected['name'], 'Class extraction failed'



# Generated at 2022-06-24 14:23:47.794449
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    x = _ScopeDict(_AVMClass(None, 'A'))
    x['b'] = 3
    assert repr(x) == "A__Scope({'b': 3})"



# Generated at 2022-06-24 14:23:53.901443
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert hash(_Undefined()) == 0
    str(_Undefined())
    repr(_Undefined())
    assert _Undefined() == _Undefined()
    assert all(type(x) == _Undefined for x in [_Undefined(), _Undefined()])



# Generated at 2022-06-24 14:23:56.048428
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    # Order matters here
    v = _ScopeDict(_AVMClass_Object(None))
    assert v['foo'] == 0



# Generated at 2022-06-24 14:24:00.064430
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    @SWFInterpreter.patch_function
    def pypatch(abc_file, func_name, args):
        raise NotImplementedError

    assert pypatch.__name__ == 'pypatch'
    assert pypatch.__doc__.startswith('Patch function')



# Generated at 2022-06-24 14:24:03.397390
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass(0, 'ClassName', static_properties={'prop': 1})
    assert class_.name == 'ClassName'
    assert class_.static_properties == {'prop': 1}
    assert type(class_.variables) is _ScopeDict
    assert class_.variables.avm_class is class_



# Generated at 2022-06-24 14:24:04.844155
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    _AVMClass_Object(None)
    assert True


# Generated at 2022-06-24 14:24:09.341968
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() is _Undefined()
    assert len({_Undefined(), _Undefined(), _Undefined()}) == 1
    assert not _Undefined()
    assert not _Undefined()
    assert True if _Undefined() else True
    assert True if not _Undefined() else True

    import json
    assert json.dumps({'a': _Undefined()}) == '{"a": null}'



# Generated at 2022-06-24 14:24:13.593254
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    sd = _ScopeDict(None)
    assert repr(sd) == 'None__Scope()'
    sd['a'] = 'b'
    assert repr(sd) == 'None__Scope({\'a\': \'b\'})'


# Generated at 2022-06-24 14:24:23.962113
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from collections import namedtuple

    class AVMClass(object):
        def __init__(self):
            self.method_names = []
            self.method_pyfunctions = {}
            self.method_bodies = {}
        def make_object(self):
            return {}
        def patch_function(self, fname, pyfunc):
            self.method_pyfunctions[fname] = pyfunc

    class SWF(object):
        actions = []
        traits = []
        strings = ['Array', 'push', 'charAt', 'split']
        multinames = [
            Multiname('Array'), Multiname('push'), Multiname('charAt'),
            Multiname('split'), Multiname('length'), Multiname('slice'),
            Multiname('join')]


# Generated at 2022-06-24 14:24:26.104223
# Unit test for constructor of class _Undefined
def test__Undefined():
    u = _Undefined()
    assert not bool(u)
    assert str(u) == 'undefined'



# Generated at 2022-06-24 14:24:32.156178
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass('', )
    c.register_methods({'a': 1, 'b': 2})
    assert c.method_names['a'] == 1
    assert c.method_names['b'] == 2
    assert c.method_idxs[1] == 'a'
    assert c.method_idxs[2] == 'b'



# Generated at 2022-06-24 14:24:34.215666
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    _Undefined()

# Generated at 2022-06-24 14:24:39.005903
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass('test_class', 1)
    assert c.name == 'test_class'
    assert c.method_names == {}
    assert c.static_properties == {}



# Generated at 2022-06-24 14:24:40.389608
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0



# Generated at 2022-06-24 14:24:43.371777
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
undefined = _Undefined()



# Generated at 2022-06-24 14:24:49.922878
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class Foo(object):
        def __init__(self, name):
            super(Foo, self).__init__()
            self.name = name
    foo_obj = _AVMClass_Object(Foo('fooname'))
    assert foo_obj.__repr__() == "fooname#%x" % id(foo_obj)


_AVMClass = collections.namedtuple(
    '_AVMClass',
    'name is_instance_of_avm_class')

# Generated at 2022-06-24 14:24:53.747457
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class test(object):
        name = 'name_0'
    _ScopeDict(avm_class=test()).__repr__()

# Generated at 2022-06-24 14:24:56.011435
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    o = _AVMClass('A', 'B', {'C': 'D'})
    assert o.name == 'B'
    assert o.static_properties == {'C': 'D'}



# Generated at 2022-06-24 14:24:58.528660
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_abc = _AVMClass_ABC('MyClass')
    obj = _AVMClass_Object(class_abc)
    assert obj.avm_class == class_abc



# Generated at 2022-06-24 14:25:11.498539
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import io
    import tempfile
    import unittest
    from json import loads

    with tempfile.TemporaryDirectory() as tmpdir:
        fname = os.path.join(tmpdir, 'get_ytplayer_config.swf')
        assert not os.path.exists(fname), fname
        with open(fname, 'wb') as outf:
            outf.write(b64decode(get_ytplayer_config_swf))

        swf = SWFInterpreter()
        swf.parse_file(fname)

        for name in ('ActionScript', 'JSObject'):
            assert name in swf.classes
        assert swf.classes['ActionScript'].static_properties['JSObject']
        JSObject = swf.classes['ActionScript'].static_properties['JSObject']


# Generated at 2022-06-24 14:25:16.433230
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    print('')
    name_idx = 17
    name = 'ABC'
    static_properties = {'a': 5}
    avm_class = _AVMClass(name_idx, name, static_properties)
    # Input arguments used in the test
    object = avm_class.make_object()
    assert object.avm_class == avm_class


# Generated at 2022-06-24 14:25:20.110114
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    multiname = _Multiname(1)
    assert multiname.__repr__() == '[MULTINAME kind: 0x1]', multiname.__repr__()



# Generated at 2022-06-24 14:25:21.054592
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    # Not implemented
    pass


# Generated at 2022-06-24 14:25:34.334923
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    si = SWFInterpreter()
    avm_class = si.extract_class(
        'tests/swfdec_test_as/RegularExpressions.swf', 'TestRegExp')
    assert avm_class.name == 'TestRegExp'
    assert avm_class.base == 'Object'
    assert avm_class.instance_count == 0
    assert avm_class.constructor.scope == [
        'Object', 'Math', 'RegExp', 'String', 'Boolean', 'Number', 'Array',
        'Date', 'TestRegExp']

# Generated at 2022-06-24 14:25:46.439367
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-24 14:25:48.953468
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == 'undefined'

# Generated at 2022-06-24 14:25:51.583277
# Unit test for constructor of class _Multiname
def test__Multiname():
    mn = _Multiname(0)
    assert mn.kind == 0
    assert repr(mn) == '[MULTINAME kind: 0x0]'


# Generated at 2022-06-24 14:25:56.841754
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    """Unit test for method __hash__ of class _Undefined"""
    from hashlib import md5
    assert md5(
        compat_str(
            _Undefined())).digest() == b'\x8a\x36\x06\x96\xc9\x8a\x2c\x1a\xbb\x15\x39\x6d\x5f\x64\x50\xfa'
Undefined = _Undefined()



# Generated at 2022-06-24 14:25:58.277140
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert repr(_ScopeDict(None)) == 'None__Scope({})'



# Generated at 2022-06-24 14:26:11.483862
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    # _AVMClass__ScopeDict
    assert repr(_AVMClass('Test', static_properties=None).variables) == 'Test__Scope({})'

    # _AVMClass_Object
    avm = _AVMClass('Test', static_properties={'foo': 3})
    assert repr(avm.make_object()) == 'Test#%x' % id(avm.make_object())

    # _AVMClass
    assert repr(avm) == '_AVMClass(Test)'

    # __repr__ of _AVMClass, using _AVMClass_Object and _AVMClass__ScopeDict
    assert repr(avm.make_object().avm_class) == '_AVMClass(Test)'

# Generated at 2022-06-24 14:26:12.655561
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-24 14:26:15.160115
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    method = _Multiname._Multiname__repr__
    method(
        _Multiname(
            kind=0))



# Generated at 2022-06-24 14:26:26.876694
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .swfdecompiler import decompile_swf
    from .hexdump import hexdump

    swf_file = io.BytesIO(compat_str(zlib.decompress(suite_data[0][0])))
    abc_data = decompile_swf(swf_file.read())[1][suite_data[0][1]]
    #hexdump(abc_data)
    parsed_abc = parse_abc(abc_data)
    parsed_abc.dump()
    globals_ = {
        'trace': lambda *a: trace(*a),
        'AVMClass': lambda n, s=None: get_builtin_class(n, s),
    }
    exec(parsed_abc.code, globals_)
    exec_abc = globals_['_exec']

# Generated at 2022-06-24 14:26:35.324208
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    bs = BytesIO(swf_data)
    swf = SWFInterpreter(bs)
    assert swf.version == 14
    assert swf.frame_size is None
    assert swf.frame_rate == 30
    assert swf.frame_count == 1
    assert len(swf.tags) == 1
    tag = swf.tags[0]
    assert isinstance(tag, DoABC)
    abc = tag.abc
    assert isinstance(abc, ABCFile)
    assert abc.major_version == 40
    assert abc.constant_integer
    assert abc.constant_uint
    assert abc.constant_double
    assert abc.constant_string
    assert abc.constant_namespace
    assert abc.constant_nsset

    assert len

# Generated at 2022-06-24 14:26:44.962164
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .unit_test import unit_test
    import random
    import string
    for i in range(3):
        for class_name in [
            ''.join([random.choice(string.printable) for j in range(random.randint(1, 100))])
            for i in range(50)]:
            unit_test.assert_equal(
                '%s#%x' % (class_name, id(_AVMClass_Object(type(class_name, (_AVMClass_Object,), {'name': class_name}))(0))),
                repr(_AVMClass_Object(type(class_name, (_AVMClass_Object,), {'name': class_name}))(0)))



# Generated at 2022-06-24 14:26:48.299941
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_object = _AVMClass_Object(_AVMClass())
    assert class_object.avm_class is not None


# Generated at 2022-06-24 14:26:49.596309
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-24 14:26:54.769791
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    cls = _AVMClass(0, b'')
    cls.register_methods({b'foo': 0, b'bar': 2})
    assert cls.method_names == {
        b'foo': 0,
        b'bar': 2,
    }
    assert cls.method_idxs == {
        0: b'foo',
        2: b'bar',
    }



# Generated at 2022-06-24 14:26:55.706310
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    _AVMClass('', '', {})



# Generated at 2022-06-24 14:26:56.957902
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert 0 == 1


# Generated at 2022-06-24 14:27:05.287328
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():

    path = os.path.join(os.path.dirname(__file__), 'test.swf')
    with open(path, 'rb') as f:
        swf = f.read()

    avm_interpreter = SWFInterpreter(swf)

# Generated at 2022-06-24 14:27:11.861136
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    instance = _AVMClass(0, 'test_class')
    instance.register_methods({0: 'test_method_0', 1: 'test_method_1'})
    assert instance.method_names == {'test_method_0': 0, 'test_method_1': 1}, \
        'test_method_0 and test_method_1 should both be in method_names'
    assert instance.method_idxs == {0: 'test_method_0', 1: 'test_method_1'}, \
        'test_method_0 and test_method_1 should both be in method_idxs'



# Generated at 2022-06-24 14:27:14.644647
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    d = _ScopeDict(None)
    d[1] = 2
    assert d == {1: 2}
    assert repr(d) == 'None__Scope({1: 2})'



# Generated at 2022-06-24 14:27:17.087585
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(0)
    res = obj.__repr__()
    assert res == '[MULTINAME kind: 0x0]'
test__Multiname___repr__()



# Generated at 2022-06-24 14:27:21.469988
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(_AVMClass('SomeName'))) == 'SomeName#%x' % id(None)



# Generated at 2022-06-24 14:27:28.931607
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    cls = _AVMClass(0, 'Test')
    cls.register_methods({'a': 1, 'b': '2'})
    cls.register_methods({'c': '3'})
    assert cls.method_names == {'a': 1, 'b': '2', 'c': '3'}, repr(cls.method_names)
    assert cls.method_idxs == {1: 'a', '2': 'b', '3': 'c'}, repr(cls.method_idxs)


# Generated at 2022-06-24 14:27:32.222607
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_ = _AVMClass('TestClass')
    obj = class_()
    assert obj.avm_class == class_



# Generated at 2022-06-24 14:27:44.181116
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    # _AVMClass_Object.__repr__
    # Test: _AVMClass_Object#__repr__
    assert repr(test_instance) == 'test__AVMClass_Object___repr__#%x' % id(test_instance)
    test_instance.avm_class.name = 'test_class'
    # Test: _AVMClass_Object#__repr__
    assert repr(test_instance) == 'test_class#%x' % id(test_instance)
_AVMClass_Object__repr__.param_names = ()
_AVMClass_Object__repr__.params = ()
_AVMClass_Object__repr__.dependencies = []
test__AVMClass_Object___repr__ = _AVMClass_Object__repr__()



# Generated at 2022-06-24 14:27:50.821240
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    filename = 'tests/data/as3-test.swf'
    with open(filename, 'rb') as f:
        interp = SWFInterpreter(f)
    class_str = interp.extract_class(1)
    method_str = interp.extract_class(2)

    eval(class_str)
    eval(method_str)


# Generated at 2022-06-24 14:27:52.178601
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    run_test(_AVMClass_register_methods_test)

# Generated at 2022-06-24 14:27:59.287125
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class TestAVMClass(object):
        variables = {}
        static_properties = {}
        method_names = {}
        method_pyfunctions = {}

    def f(args):
        assert len(args) == 1
        assert args[0] == 2
        return 3

    TestAVMClass.method_names['foo'] = f
    TestAVMClass.method_pyfunctions['foo'] = f

    interpreter = SWFInterpreter(
        b'\xa0', TestAVMClass, 'foo', [])
    interpreter.patch_function(True)

if __name__ == '__main__':
    test_SWFInterpreter_patch_function()

# Generated at 2022-06-24 14:28:05.144096
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .test_extractor import MockFile
    obj = _AVMClass('foo', 32, {}).make_object()
    assert obj.avm_class.name == 'foo'
    assert repr(obj) == 'foo#%x' % id(obj)



# Generated at 2022-06-24 14:28:08.046772
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    scopedict = _ScopeDict(object())
    result = repr(scopedict)
    assert type(result) is str



# Generated at 2022-06-24 14:28:12.887790
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class MockAVMClass(object):
        def __init__(self, name):
            self.name = name

    class_obj = MockAVMClass('Test')
    inst = _AVMClass_Object(class_obj)
    assert inst.avm_class == class_obj
    assert inst.__repr__() == 'Test#%x' % id(inst)



# Generated at 2022-06-24 14:28:22.265160
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class Foo:
        pass

    scope = _ScopeDict(Foo)
    scope['a'] = 'b'
    scope['c'] = scope
    # Note that if this constructor doesn't work, the unit test will
    # be in an infinite loop
    assert repr(scope) == "Foo__Scope({'c': Foo__Scope({'c': ..., 'a': 'b'}), 'a': 'b'})"
    scope['d'] = scope
    assert repr(scope) == "Foo__Scope({'d': Foo__Scope({'c': ..., 'a': 'b', 'd': ...}), 'c': Foo__Scope({'c': ..., 'a': 'b', 'd': ...}), 'a': 'b'})"



# Generated at 2022-06-24 14:28:28.437820
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    # Run 'repr' on a string, list and _ScopeDict
    assert repr(b'abc') == "b'abc'"
    assert repr([1, 2, 3]) == '[1, 2, 3]'
    foo_scope = _ScopeDict(None)
    foo_scope[b'abc'] = b'def'
    assert repr(foo_scope) == "_Scope({b'abc': b'def'})"



# Generated at 2022-06-24 14:28:31.210068
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    from .test.utils import _FakeAVMClass
    avm_class = _FakeAVMClass('test')
    scope = _ScopeDict(avm_class)
    assert str(scope) == 'test__Scope({})'



# Generated at 2022-06-24 14:28:33.742265
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x07).kind == 0x07



# Generated at 2022-06-24 14:28:35.485093
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    i = _Undefined()
    assert False == i, 'assert False == i'



# Generated at 2022-06-24 14:28:40.930891
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert repr(_ScopeDict(_AVMClass_Object(None))) == 'None__Scope({})'
    assert repr(_ScopeDict(_AVMClass_Object(None), key='value')) == \
        'None__Scope({\'key\': \'value\'})'
    assert repr(_ScopeDict(_AVMClass_Object(None), key='value', key2='value2')) == \
        'None__Scope({\'key\': \'value\', \'key2\': \'value2\'})'



# Generated at 2022-06-24 14:28:47.558058
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    def get_all_classes():
        return [_AVMClass_Object(_AVMClass())]
    assert (_ScopeDict(_AVMClass()).__repr__() ==
            '_AVMClass__Scope({})')
    assert (_ScopeDict(_AVMClass()).__repr__() ==
            '_AVMClass__Scope({})')



# Generated at 2022-06-24 14:28:58.897759
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-24 14:29:03.009239
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
    assert False == _Undefined()
    assert not bool(_Undefined())
    from .utils import make_doctest
    assert make_doctest('assert not _Undefined()') == ''

# Generated at 2022-06-24 14:29:13.614440
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-24 14:29:25.799018
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import sys
    import io
    import unittest
    from .swfdump import SWFDump

    stdout = sys.stdout
    stdin = sys.stdin
    sys.stdout = stdout = io.StringIO()
    sys.stdin = stdin = io.StringIO()

    class Mock(SWFDump):

        def __init__(self):
            self.interpreter = SWFInterpreter()

        def read_data(self, path):
            with open(path, 'rb') as f:
                return f.read()

    avm_class = Mock()
    assert avm_class.display_item_info(None, 1)
    assert avm_class.display_script_info(None, 1)

    sys.stdout = stdout
    sys.stdin = stdin



# Generated at 2022-06-24 14:29:29.720522
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    cls = AVMClass('MyClass', None)
    scope = _ScopeDict(cls)
    scope[1] = 'x'
    assert repr(scope) == "MyClass__Scope({1: 'x'})"



# Generated at 2022-06-24 14:29:38.519920
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    v = _AVMClass('a', 'b')
    v.register_methods({'c': 'd'})
    assert v.methods == {}
    assert v.method_names == {'c': 'd'}
    assert v.method_idxs == {'d': 'c'}
    v.register_methods({'c': 'e', 'd': 'f'})
    assert v.methods == {}
    assert v.method_names == {'c': 'e', 'd': 'f'}
    assert v.method_idxs == {'e': 'c', 'f': 'd'}



# Generated at 2022-06-24 14:29:50.301140
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    methods = {
        'test_method_one': 1,
        'test_method_two': 2,
    }
    avm_class = _AVMClass('test', 'test_class')
    result = avm_class.register_methods(methods)
    assert result == None, 'result was %s' % (result,)
    assert avm_class.method_names == methods, 'avm_class.method_names == %s' % (avm_class.method_names,)
    assert avm_class.method_idxs == dict(
        (idx, name)
        for name, idx in methods.items()), 'avm_class.method_idxs == %s' % (avm_class.method_idxs,)
    return



# Generated at 2022-06-24 14:29:51.244378
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():

    assert not _Undefined()


# Generated at 2022-06-24 14:29:58.434037
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from .constants import AVM_VERSION
    from .generator import generate_code
    from .memory import AVMMemory
    from .runtime import AVMRuntime
    from .utils import parse_bytecode

    mm = AVMMemory(AVM_VERSION)

# Generated at 2022-06-24 14:30:09.787614
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    global _builtin_classes
    _builtin_classes['String'] = StringClass

# Generated at 2022-06-24 14:30:17.245715
# Unit test for constructor of class _Undefined
def test__Undefined():
    # Assert that _Undefined() is a singleton
    assert _Undefined() is _Undefined()
    # Assert that bool(_Undefined()) is False
    assert not _Undefined()
    # Assert that hash(_Undefined()) is 0
    assert hash(_Undefined()) == 0
    # Assert that str(_Undefined()) is 'undefined'
    assert str(_Undefined()) == 'undefined'


_undefined = _Undefined()



# Generated at 2022-06-24 14:30:18.352809
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__(): pass

_Undefined = _Undefined()



# Generated at 2022-06-24 14:30:21.356728
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    instance = _AVMClass(NameIndex(0), "name", ["var1", "var2"])
    assert repr(instance) == '_AVMClass(name)'



# Generated at 2022-06-24 14:30:23.927294
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    undefined = _Undefined()
    assert undefined.__hash__() == 0, undefined.__hash__()
    assert not undefined, undefined


_undefined = _Undefined()



# Generated at 2022-06-24 14:30:25.739565
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert True


# Generated at 2022-06-24 14:30:29.042664
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    m = _AVMClass('Test', 'Test', {'b': 66, 'a': 55})
    assert m.name == 'Test'
    assert m.name_idx == 'Test'
    assert m.static_properties == {'b': 66, 'a': 55}



# Generated at 2022-06-24 14:30:29.962288
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0x07)



# Generated at 2022-06-24 14:30:39.998734
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    cls = _AVMClass('TestClass')
    cls.static_properties[
        'static_prop'] = 'static_prop_value'
    obj = cls.make_object()
    obj.variables['instance_prop'] = 'instance_prop_value'
    obj.variables['instance_prop2'] = 'instance_prop_value2'
    obj.constants['instance_constant'] = 'instance_constant_value'
    assert obj.avm_class == cls
    assert obj.variables.avm_class == cls
    assert obj.variables['instance_prop'] == 'instance_prop_value'
    assert obj.variables['instance_prop2'] == 'instance_prop_value2'
    assert obj.constants['instance_constant'] == 'instance_constant_value'

# Generated at 2022-06-24 14:30:41.044898
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()



# Generated at 2022-06-24 14:30:45.486265
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():

    class _AVMClass_Dummy(object):
        def __init__(self):
            self.name = '__AVMClass_Dummy'

    scope_dict = _ScopeDict(_AVMClass_Dummy())
    scope_dict['a'] = 'b'
    assert repr(scope_dict) == '__AVMClass_Dummy__Scope({\'a\': \'b\'})'



# Generated at 2022-06-24 14:30:51.700487
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    testfile = BytesIO()
    with open('data/test1.txt', 'rb') as f:
        testfile.write(f.read())
    testfile.seek(0)
    parser = SWFInterpreter(testfile)
    parser.parse()
    assert parser.constant_strings[1] == 'rtmp'
    assert parser.constant_strings[3] == 'NetConnection.Connect.Success'


# Generated at 2022-06-24 14:31:04.031911
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Given
    swfc = SWFClass()
    swf = swfc('../test/swfs/sound.swf')
    # When
    avm_class = swf.get_avm_class('_level0', 'Sound')
    # Then
    assert avm_class.method_names == {
        'Sound', 'attachSound', 'start', 'stop', 'setVolume', 'getVolume'}
    assert avm_class.variable_names == {
        'attachSound', 'start', 'stop', 'setVolume', 'getVolume'}
    assert isinstance(avm_class.variables['attachSound'], _AVMFunction)
    assert isinstance(avm_class.variables['start'], _AVMFunction)

# Generated at 2022-06-24 14:31:04.903414
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert not len(locals())
# End unit test



# Generated at 2022-06-24 14:31:07.738359
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert str(
        _ScopeDict(avm_class=0).
        setdefault(None, None).
        setdefault(None, None)) == "0__Scope({None: None})"



# Generated at 2022-06-24 14:31:09.735421
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    import sys
    string = _AVMClass('', '').__repr__()
    assert isinstance(string, compat_str)
    assert isinstance(string, compat_str)


# Generated at 2022-06-24 14:31:10.754210
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    return _Undefined()


# Generated at 2022-06-24 14:31:16.598376
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    arg0 = 'name' # FIXME: construct object
    arg1 = 'name_idx' # FIXME: construct object
    avm_class = _AVMClass(arg0, arg1)
    return_value = avm_class.__repr__()
    assert return_value == '_AVMClass(name)'


# Generated at 2022-06-24 14:31:21.462980
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class A:
        pass
    a = A()
    a.x = 1
    def f1(a):
        return a.x
    def f2(x):
        return x
    # TODO: add test code here
    # assert f1(a) == f2(a.x)

