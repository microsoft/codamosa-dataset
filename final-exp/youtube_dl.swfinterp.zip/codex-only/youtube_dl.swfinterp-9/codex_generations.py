

# Generated at 2022-06-24 14:21:30.303845
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import textwrap
    interpreter = SWFInterpreter([])
    interpreter._refcounts = {}
    interpreter._builtin_classes = {
        'String': StringClass,
        'Array': ArrayClass,
    }

# Generated at 2022-06-24 14:21:33.429796
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    m = _AVMClass_Object(None)
    m.avm_class = None
    m.avm_class = 'foo'
    print(m)
    assert False, 'TODO'



# Generated at 2022-06-24 14:21:37.502297
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .fileio import _FileIO
    from .swfdecompiler import decompile_swf_to_bytecode
    with _FileIO('hello-world.swf', 'rb') as handle:
        bytecode = decompile_swf_to_bytecode(handle.read())
    f = bytecode['f']
    assert repr(f.make_object()) == 'f#<object-id>'

# Generated at 2022-06-24 14:21:43.825571
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    """Test _ScopeDict.__repr__"""
    a = _ScopeDict(None)
    assert a.__repr__() == 'None__Scope()'
    a[1] = 2
    assert a.__repr__() == 'None__Scope({1: 2})'



# Generated at 2022-06-24 14:21:48.583900
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x0c).__repr__() == '[MULTINAME kind: 0x0c]'

test__Multiname()



# Generated at 2022-06-24 14:21:52.393387
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    avm_class = _AVMClass('foo')
    avm_object = _AVMClass_Object(avm_class)
    res = repr(avm_object)
    assert res == 'foo#%x' % id(avm_object)



# Generated at 2022-06-24 14:21:54.836886
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'
test__Multiname()



# Generated at 2022-06-24 14:21:57.025333
# Unit test for constructor of class _Multiname
def test__Multiname():
    obj = _Multiname(42)
    assert obj.kind == 42
    assert repr(obj) == '[MULTINAME kind: 0x2a]'



# Generated at 2022-06-24 14:21:58.513798
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    self = _Undefined()
    assert self.__repr__() == 'undefined'


Undefined = _Undefined()



# Generated at 2022-06-24 14:22:00.359020
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    val = _Undefined()
    assert val.__str__() == 'undefined'


# Generated at 2022-06-24 14:22:03.683528
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    avm_class = _AVMClass(0, 'classname', {})
    assert repr(avm_class) == "_AVMClass('classname')"

# Generated at 2022-06-24 14:22:08.571456
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter(compat_str('test'), StringIO(b''))
    classdef = compat_struct(
        '<IH36s3HIH3I3HI16s',
        1,  # class name
        0,  # class name
        b'\x00' * 36,  # class name
        0,  # flags
        0,  # protected namespace
        2,  # interfaces
        0,  # interfaces
        0,  # interfaces
        0,  # constructor
        0,  # constructor
        1,  # traits
        0,  # traits
        0,  # traits
        1,  # traits
        b'\x00' * 16)  # traits
    res = interpreter.extract_class(classdef)

# Generated at 2022-06-24 14:22:16.175556
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swf_utils import read_swf
    version, movie_size, frame_size, frame_rate, frame_count, tags = read_swf('../tests/swfs/test_simple.swf')
    swf_intepreter = SWFInterpreter(tags=tags)
    for tag in swf_intepreter.tags:
        if tag.tag_type == 69:
            assert tag.do_action == test_SWFInterpreter.__code__
            break
    else:
        assert False

# Generated at 2022-06-24 14:22:16.843932
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    return _AVMClass_Object(None).__repr__()


# Generated at 2022-06-24 14:22:19.204536
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    x = _AVMClass_Object(None)
    x.avm_class = type('', (object, ), {'name': 'y'})
    assert eval(repr(x)) is x



# Generated at 2022-06-24 14:22:20.641094
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:22:25.896635
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = AVMFile.avmclasses[0]
    avm_class.method_names
    method_names = {}
    method_names.update(dict(
        (name, idx) for name, idx in
        [('$construct', 1),
         ('_level0', 2)]))
    assert avm_class.method_names == method_names
    assert avm_class.method_idxs == dict(
        (idx, name) for name, idx in method_names.items())

# Generated at 2022-06-24 14:22:29.606343
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass('Foobar', {'foo': 0, 'bar': 1})
    assert cls.name == 'Foobar'
    assert cls.method_names == {'foo': 0, 'bar': 1}
    assert cls.method_idxs == {0: 'foo', 1: 'bar'}



# Generated at 2022-06-24 14:22:33.591588
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Bytecode for this method:
    #
    # (function (a, b) {
    #   return -1;
    # }
    #
    data = b'\n\x00\x1d\x1f\x00\x05\x06\x07\x08\x01\x02\x03\x04\x00\x00\x00\x00'
    interp = SWFInterpreter()
    func = interp.extract_function(SWFInterpreter, data)
    assert callable(func)
    res = func([a, b])
    assert res == -1
 

# Generated at 2022-06-24 14:22:35.039067
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    _ScopeDict(None).__repr__()



# Generated at 2022-06-24 14:22:41.208122
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'files', 'test_00.swf'), 'rb').read())

    def test_func01(args):
        return args[0] * 10

    def test_func02():
        return 'test_return'

    def test_func03(args):
        return args[0] / args[1]

    swf.patch_function('test_func01', test_func01)
    swf.patch_function('test_func02', test_func02)
    swf.patch_function('test_func03', test_func03)

    assert swf.files['test_00.main.as']['scope']['test_func01']([2]) == 20
    assert swf.files

# Generated at 2022-06-24 14:22:42.248273
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


# Generated at 2022-06-24 14:22:46.860707
# Unit test for constructor of class _Undefined
def test__Undefined():
    x = _Undefined()
    assert not x
    assert 0 == hash(x)
    assert 'undefined' == str(x)
    assert 'undefined' == repr(x)
    x2 = _Undefined()
    assert x is x2


_undefined = _Undefined()



# Generated at 2022-06-24 14:22:57.537862
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import os
    import unittest
    import os.path

    data_dir = os.path.join(os.path.dirname(__file__), 'swf_files')

    class SWFInterpreterTest(unittest.TestCase):
        def test_constructor(self):
            empty_content = b'\x46\x57\x53\x01\x00\x00\x00\x00'
            with open(os.path.join(data_dir, 'empty.swf'), 'rb') as f:
                SWFInterpreter(f.read())

            long_content = empty_content + b'\x00' * 1000000
            with self.assertRaises(SWFError):
                SWFInterpreter(long_content)

# Generated at 2022-06-24 14:23:00.323394
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    cls = _AVMClass('test', {})
    assert repr(cls.make_object()) == "_AVMClass_Object(test#%x)" % id(cls.make_object())
test__AVMClass_make_object()



# Generated at 2022-06-24 14:23:07.121404
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    #
    # Unit test for method register_methods of class _AVMClass.
    #
    # EDIT THIS CODE:
    avm_class = _AVMClass(None, None)
    methods = None
    # END EDIT
    avm_class.register_methods(methods)



# Generated at 2022-06-24 14:23:10.051042
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    scope = _ScopeDict(_AVMClass(b'Fake'))
    scope.update({b'a': 1, b'b': 2})
    assert repr(scope) == "Fake__Scope({'a': 1, 'b': 2})"



# Generated at 2022-06-24 14:23:11.506097
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert 'undefined' == _Undefined().__repr__()

Undefined = _Undefined()



# Generated at 2022-06-24 14:23:12.284418
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
  pass

# Generated at 2022-06-24 14:23:16.264219
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    data = compat_struct_unpack('<12I', compat_urllib_request.urlopen(
        'https://www.youtube.com/api/timedtext?lang=en&v=BgQDPwOj7Ng').read(48))
    swf_interpreter = SWFInterpreter(data)
    functions = swf_interpreter.extract_functions()
    return functions


# Generated at 2022-06-24 14:23:18.198055
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x00)) == '[MULTINAME kind: 0x0]'



# Generated at 2022-06-24 14:23:22.252237
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    _avm = _AVMClass('_avm', '_avm')
    assert isinstance(_avm.make_object(), _AVMClass_Object)
    assert _avm.make_object().avm_class == _avm

# Generated at 2022-06-24 14:23:23.298737
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined() == None  # pylint: disable=singleton-comparison



# Generated at 2022-06-24 14:23:32.534866
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .parser import Parser
    from .reader import FileReader
    from .tag import Tag
    from .tag_type import TagType

    swf = Parser.parse(FileReader('flash.swf'))
    tag = swf.tags[0]
    assert isinstance(tag, Tag)
    assert tag.tag_code == TagType.DoABC
    assert isinstance(tag.tag, DoABC)
    assert isinstance(tag.tag.abc, ABC)
    abc_file = tag.tag.abc
    interpreter = SWFInterpreter(abc_file)

    assert isinstance(interpreter.abc, ABC)
    assert interpreter.abc == abc_file
    methods = interpreter.abc.methods
    assert isinstance(methods, list)
    assert len(methods) > 0

# Generated at 2022-06-24 14:23:38.252497
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    a = _AVMClass(None, 'Test')
    a.register_methods({'foo': 0, 'bar': 1, 'baz': 2})
    assert a.name == 'Test'
    assert a.method_names == {'foo': 0, 'bar': 1, 'baz': 2}
    assert a.method_idxs == {0: 'foo', 1: 'bar', 2: 'baz'}
    assert a.static_properties == {}
    assert a.variables == _ScopeDict(a)
    assert a.constants == {}



# Generated at 2022-06-24 14:23:40.478411
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    a = _AVMClass('name', 'name')
    assert a.__repr__() == '_AVMClass(name)'



# Generated at 2022-06-24 14:23:42.192804
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert str(_Undefined()) == 'undefined'

_undefined = _Undefined()



# Generated at 2022-06-24 14:23:43.047361
# Unit test for constructor of class _Undefined
def test__Undefined():
    _Undefined()

undefined = _Undefined()



# Generated at 2022-06-24 14:23:45.208911
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class Test(object):
        def __init__(self):
            pass
    assert (_AVMClass_Object(Test).__repr__() ==
        '%s#%x' % (Test.__name__, id(_AVMClass_Object(Test))))



# Generated at 2022-06-24 14:23:46.098684
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    _undefined.__repr__()

# Generated at 2022-06-24 14:23:56.348772
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    """Test method '__repr__' of class AVMClass_Object
    """
    _AVMClass = collections.namedtuple('_AVMClass', ('name',))
    instance = _AVMClass_Object(_AVMClass(name='Foo'))
    expected = 'Foo#%x' % id(instance)
    actual = repr(instance)
    expected_regexp = r'^%s$' % re.escape(expected)
    assert re.match(expected_regexp, actual), \
        "class name is not correct '%s'" % actual
# End unit test for method __repr__ of class _AVMClass_Object



# Generated at 2022-06-24 14:23:59.546438
# Unit test for constructor of class _Undefined
def test__Undefined():
    u = _Undefined()
    assert not u
    assert u == 0
    assert u == 0.0
    assert u == ''
    assert u == u'undefined'
    assert u == False
    assert u == b''
    assert hash(u) == 0



# Generated at 2022-06-24 14:24:03.451731
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert (_Undefined() == _Undefined()) is False
    assert _Undefined() != ''
    assert _Undefined() != {}
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'

_undefined = _Undefined()


# Base class for all AST nodes

# Generated at 2022-06-24 14:24:05.877919
# Unit test for constructor of class _Undefined
def test__Undefined():
    u = _Undefined()
    assert not u
    assert str(u) == 'undefined'

_undefined = _Undefined()



# Generated at 2022-06-24 14:24:11.070111
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .swf import SWF
    from .tag import Tag
    from .abc import ABC
    from .actions import Push
    from .utils import (
        list_reader, dict_reader, string_reader, boolean_reader,
        string_writer, dict_writer, list_writer, number_reader,
        parse_bool, parse_int, parse_number, parse_string)


# Generated at 2022-06-24 14:24:13.579997
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    '''Test str(_Undefined())'''
    c = _Undefined()
    s = repr(c)
    e = 'undefined'
    assert s == e, (s, e)



# Generated at 2022-06-24 14:24:20.399974
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()  # __nonzero__ is called when 'if v:'
    assert _Undefined() == _Undefined()  # __eq__ is called when 'if v is v2:'
    assert len({_Undefined(): 1}) == 1

_undefined = _Undefined()


# Generated at 2022-06-24 14:24:26.880738
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    import unittest
    import re
    class Test(unittest.TestCase):
        def test(self):
            class X:
                pass
            self.assertRegexpMatches(repr(_AVMClass_Object(X)), r'^X#[0-9a-fA-F]+$')
    unittest.main(module=__name__)


# Generated at 2022-06-24 14:24:32.897523
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import os

    SWF_SRC = os.path.join(
        os.path.dirname(__file__), '..', '..', '..', 'runtimes', 'playerProductInstall.swf')
    interpreter = SWFInterpreter(SWF_SRC)
    assert isinstance(interpreter, SWFInterpreter)


# Generated at 2022-06-24 14:24:39.609020
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    x = _AVMClass(1, 'MyClass')
    x.register_methods({'foo': 2, 'bar': 3})
    assert x.method_names == {'foo': 2, 'bar': 3}
    assert x.method_idxs == {2: 'foo', 3: 'bar'}



# Generated at 2022-06-24 14:24:43.485544
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    m = _Multiname(0xA)
    assert repr(m) == '[MULTINAME kind: 0xA]'


CACHE_MAX_TRIES = 1000
CACHE_BLACKLIST = set()



# Generated at 2022-06-24 14:24:45.723281
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    name = _Multiname(0)
    assert str(name) == '[MULTINAME kind: 0x0]'



# Generated at 2022-06-24 14:24:49.877940
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    name_idx = 0
    name = 'TestClass'
    static_properties = None
    avm_class = _AVMClass(name_idx, name, static_properties)
    assert repr(avm_class) == '_AVMClass(%s)' % name

# Generated at 2022-06-24 14:24:51.201889
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0x07)
    assert True


# Generated at 2022-06-24 14:24:53.344736
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert _Undefined() is not None
    assert not _Undefined()



# Generated at 2022-06-24 14:24:55.937284
# Unit test for constructor of class _Multiname
def test__Multiname():
    mn = _Multiname(kind=0x07)
    assert repr(mn) == '[MULTINAME kind: 0x7]'

if __name__ == '__main__':
    test__Multiname()



# Generated at 2022-06-24 14:25:02.952473
# Unit test for constructor of class _Undefined
def test__Undefined():
    global _Undefined
    _Undefined()
Undefined = _Undefined()


# From: http://www.adobe.com/content/dam/Adobe/en/devnet/swf/pdf/swf-file-format-spec.pdf
# Section: SWF Definition
# Page: 20
#
# Some methods are not implemented
#
# TODO:
#   * Implement other kinds of constants
#   * Implement exceptions
#   * Implement other kinds of methods

# Generated at 2022-06-24 14:25:04.745180
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    return
undefined = _Undefined()



# Generated at 2022-06-24 14:25:06.252611
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
_undefined = _Undefined()



# Generated at 2022-06-24 14:25:10.836166
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
  uu=_Multiname(0)
  assert repr(uu) == '[MULTINAME kind: 0x0]'
  uu=_Multiname(0xfffffff)
  assert repr(uu) == '[MULTINAME kind: 0xfffffff]'

# Generated at 2022-06-24 14:25:19.307436
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-24 14:25:22.383963
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    dict1 = _ScopeDict(None)
    dict1[0] = 1
    dict1['a'] = 'b'
    assert repr(dict1) == 'None__Scope({0: 1, \'a\': \'b\'})'



# Generated at 2022-06-24 14:25:27.487535
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(
        _AVMClass(name='TestClass', super_=None, is_sealed=False))) == 'TestClass#%x' % id(_AVMClass_Object(
        _AVMClass(name='TestClass', super_=None, is_sealed=False)))



# Generated at 2022-06-24 14:25:28.588523
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


# Generated at 2022-06-24 14:25:37.485184
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(123, 'SomeClass', {'a': 456, 'b': 789})
    assert avm_class.name_idx == 123
    assert avm_class.name == 'SomeClass'
    assert avm_class.static_properties == {'a': 456, 'b': 789}
    assert avm_class.make_object() not in (123, None, avm_class)
    assert repr(avm_class.variables) == 'SomeClass__Scope({})'
# test__AVMClass()



# Generated at 2022-06-24 14:25:39.964286
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert _AVMClass_Object(_AVMClass_Object).avm_class == _AVMClass_Object



# Generated at 2022-06-24 14:25:42.729977
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    interp = AVM2Interpreter()
    return repr(interp._Multiname(0)) == '[MULTINAME kind: 0x0]'


# Generated at 2022-06-24 14:25:53.567622
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf0 import parse_swf


# Generated at 2022-06-24 14:26:06.553936
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import unittest
    import io

    class SWFInterpreterTest(unittest.TestCase):
        def test_extract_function(self):
            avm_class = SWFInterpreter.make_class('Test')
            avm_class.static_properties['testproperty'] = 42

            # Construct a function that takes one argument and returns it
            with io.BytesIO() as method_info:
                w = method_info.write
                w(compat_chr(1))  # Max stack
                w(compat_chr(0))  # Locals
                w(compat_chr(0))  # Init scope depth
                w(compat_chr(0))  # Max scope depth

                w(compat_chr(65))  # getlocal_0

# Generated at 2022-06-24 14:26:07.403827
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) is False

_undefined = _Undefined()



# Generated at 2022-06-24 14:26:11.632559
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class _ObjTest(object):
        pass
    obj = _ObjTest()
    obj.methods = {}
    obj.method_names = {}
    obj.method_idxs = {}
    obj.register_methods({'foo': 0, 'bar': 1})
    assert obj.methods == {}
    assert obj.method_names == {'foo': 0, 'bar': 1}
    assert obj.method_idxs == {0: 'foo', 1: 'bar'}
    try:
        obj.register_methods({'foo': 2})
        assert False, 'Already seen method foo'
    except AssertionError:
        pass
# test end
    return 'ok'



# Generated at 2022-06-24 14:26:14.701212
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from . import swftags
    assert repr(swftags.test_avmclasses.BasicObject()) == 'basic.BasicObject#3067e20'


# Generated at 2022-06-24 14:26:18.919867
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    def _(self, avm_class):
        self.avm_class = avm_class
        return '%s#%x' % (self.avm_class.name, id(self))
    _AVMClass_Object___repr__ = _

    res = _AVMClass_Object___repr__(None, None)
    assert res == 'None#x', 'got %r' % res



# Generated at 2022-06-24 14:26:20.350606
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class TestAVMClass(object):
        name = 'TestAVMClass'
    obj = _ScopeDict(TestAVMClass)



# Generated at 2022-06-24 14:26:22.411926
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    t = _Undefined()
    hash(t)

Undefined = _Undefined()



# Generated at 2022-06-24 14:26:32.258874
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert '[MULTINAME kind: 0x2]' == repr(_Multiname(0x2))

_MULTINAME_KINDS = {
    0x07: 'QName',
    0x09: 'QNameA',
    0x0d: 'RTQName',
    0x0f: 'RTQNameA',
    0x10: 'RTQNameL',
    0x11: 'RTQNameLA',
    0x12: 'Multiname',
    0x13: 'MultinameA',
    0x14: 'MultinameL',
    0x15: 'MultinameLA',
    0x1b: 'Generic',
    0x1c: 'MultinameG',
}



# Generated at 2022-06-24 14:26:33.466598
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    # TODO: Implement test
    pass



# Generated at 2022-06-24 14:26:38.418056
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter.from_file('../test/test.swf')
    func = swf.extract_function('Main', 'test')
    assert func() == 'toto'

# Class AVMClass

# Generated at 2022-06-24 14:26:40.418002
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) is False
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'


undefined = _Undefined()



# Generated at 2022-06-24 14:26:43.278481
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    avm_class = _AVMClass(83, 'Cocktail')
    expected = '_AVMClass(Cocktail)'
    assert str(avm_class) == expected

# Generated at 2022-06-24 14:26:48.557237
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class _Mock_AVMClass(object):
        name = 'foo'
    scope = _ScopeDict(_Mock_AVMClass)
    scope['x'] = 12
    scope['y'] = 'test'
    assert repr(scope) == "foo__Scope({'y': 'test', 'x': 12})"



# Generated at 2022-06-24 14:26:50.686131
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert _Undefined().__hash__() == 0
test__Undefined___hash__()

# Generated at 2022-06-24 14:27:00.518213
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = _SWFInterpreter(compat_urllib_request.urlopen(TEST_SWF_URL))
    cls = swf.extract_class('_level0.Shell_Panel.Panel_Shell_Panel')
    assert cls.static_properties['position'].x == 150
    assert cls.static_properties['position'].y == 150
    assert cls.static_properties['size'].width == 500
    assert cls.static_properties['size'].height == 300
    assert cls.static_properties['size'].x == 150
    assert cls.static_properties['size'].y == 150
    assert cls.static_properties['size'].alpha == 100
    assert cls.static_properties['size'].blendMode == 'normal'
    assert cls.static_properties

# Generated at 2022-06-24 14:27:06.439771
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class TestClass(object):
        def __init__(self, name):
            self.name = name
    instance = _AVMClass_Object(TestClass('TestName'))
    assert instance.avm_class.name == 'TestName'
    assert repr(instance) == 'TestName#%x' % id(instance)



# Generated at 2022-06-24 14:27:07.203260
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()



# Generated at 2022-06-24 14:27:12.137625
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    methods = {'m1': 0x4000, 'method2': 0x4001, 'method_three': 0x4002}
    obj = _AVMClass('name', 'name', {})
    obj.register_methods(methods)
    assert obj.method_names == methods
    assert obj.method_idxs == dict(
        (idx, name)
        for name, idx in methods.items())



# Generated at 2022-06-24 14:27:13.517469
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
test__Undefined___bool__()



# Generated at 2022-06-24 14:27:20.892827
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from base64 import b64decode


# Generated at 2022-06-24 14:27:24.504074
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from yledl.extractors.swf import _AVMClass
    t = _AVMClass(17, 'some-class')
    assert repr(t) == '_AVMClass(some-class)'

# Generated at 2022-06-24 14:27:26.830147
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    test_object = _AVMClass('TestClass')
    return isinstance(test_object.make_object(), _AVMClass_Object)

# Generated at 2022-06-24 14:27:28.361937
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    o = _ScopeDict(_AVMClass_Object(_AVMClass('TestClass')))
    return o



# Generated at 2022-06-24 14:27:30.245144
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    from .utils import testvalue
    testvalue(undefined)


undefined = _Undefined()



# Generated at 2022-06-24 14:27:32.869061
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    _AVMClass = undefined
    return True


# Generated at 2022-06-24 14:27:44.797689
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from pyamf.remoting.client import RemotingService
    # Run a test for constructor of class SWFInterpreter
    SWFInterpreter("http://www.pitvlive.com/live/live_pittsburgh.swf")
    # Initialize the pyamf remoting service and get the flashvars
    pyamf_remoting_service = RemotingService(
        "http://www.pitvlive.com/services/gateway.php")
    flash_vars = pyamf_remoting_service.getFlash_vars()
    # Construct an SWFInterpreter object to get the constructor arguments
    interpreter = SWFInterpreter("http://www.pitvlive.com/live/live_pittsburgh.swf",
                                 flash_vars = flash_vars)
    # Get rid of

# Generated at 2022-06-24 14:27:56.105547
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import binascii

# Generated at 2022-06-24 14:28:00.991539
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    zz = _AVMClass(
        0x1001,
        'zz',
        static_properties={'z1': 2, 'z2': 4})
    assert zz.name_idx == 0x1001
    assert zz.name == 'zz'
    assert zz.static_properties == {'z1': 2, 'z2': 4}
    assert not zz.method_names
    assert not zz.constants
    assert not zz.method_idxs
    assert not zz.methods



# Generated at 2022-06-24 14:28:02.217614
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


# Generated at 2022-06-24 14:28:13.645117
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    myClass = _AVMClass(name_idx=3, name='MyClass')
    assert myClass.name_idx == 3
    assert myClass.name == 'MyClass'
    assert myClass.method_names == {}
    assert myClass.method_idxs == {}
    assert myClass.methods == {}
    assert myClass.method_pyfunctions == {}
    assert myClass.static_properties == {}
    assert isinstance(myClass.variables, _ScopeDict)
    assert myClass.constants == {}


OPCODE_PUSH = 0x96
OPCODE_GETVARIABLE = 0x1c
OPCODE_SETVARIABLE = 0x1d
OPCODE_CONSTANTPOOL = 0x88
OPCODE_NEWFUNCTION = 0x40


# Generated at 2022-06-24 14:28:22.850230
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class_a = _AVMClass(1, 'A')
    class_b = _AVMClass(2, 'B')
    assert not class_a.method_idxs
    assert not class_a.method_names
    class_a.register_methods({'foo': 11, 'bar': 12})
    class_b.register_methods({'foo': 13, 'baz': 14})
    assert class_a.method_idxs == {11: 'foo', 12: 'bar'}
    assert class_a.method_names == {'foo': 11, 'bar': 12}
    assert class_b.method_idxs == {13: 'foo', 14: 'baz'}
    assert class_b.method_names == {'foo': 13, 'baz': 14}



# Generated at 2022-06-24 14:28:24.411770
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x07).kind == 0x07



# Generated at 2022-06-24 14:28:33.326855
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()

# Generated at 2022-06-24 14:28:34.244340
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class A:
        pass



# Generated at 2022-06-24 14:28:42.506051
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(666, 'foo')
    assert c.name == 'foo', 'name'
    assert c.name_idx == 666, 'name_idx'
    assert c.method_names == {}, 'method_names'
    assert c.method_idxs == {}, 'method_idxs'
    assert c.methods == {}, 'methods'
    assert c.method_pyfunctions == {}, 'method_pyfunctions'
    assert c.variables == {}, 'variables'
    assert c.constants == {}, 'constants'
    assert repr(c) == '_AVMClass(foo)', '__repr__'
    c.method_names[0] = 'bar'
    c.method_idxs[1] = 'baz'
    assert c.method

# Generated at 2022-06-24 14:28:43.907931
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert not hash(_Undefined())



# Generated at 2022-06-24 14:28:54.054398
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import StringIO
    from .swfheader import read_swf_header
    from .swfdata import read_swf_tags
    from .swfcast import read_cdata
    from .swfcast import CData

    def str_to_file(f, s):
        if isinstance(f, CData):
            f.write(s)
        else:
            f.write(s.encode('ascii'))

    def str_to_coder(coder, s):
        arr = coder.new_array(len(s), coder.unsigned_char)
        coder.write_array(s, arr)
        return arr

    def str_to_io(io, s):
        io.write(s)
        io.seek(0)


# Generated at 2022-06-24 14:28:57.285495
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    c = _AVMClass(0, 'Foo', {})
    o = c.make_object()
    assert repr(o) == 'Foo#'
    

# Generated at 2022-06-24 14:29:08.987780
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import os
    from .flash_proxy_dick_com import FlashProxyDickIE
    if not _TESTS_ONLINE or not _PY3:
        pytest.skip('The Flash Proxy Dick tests are only run on Python 3 '
                    'and when the tests are run online')

    def get_flash_proxy_dick_config(mode):
        return {
            'url': 'https://flashproxy-dick.com/',
            'mode': mode,
            'password': 'abcdefg',
        }


# Generated at 2022-06-24 14:29:11.201784
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    undefined = _Undefined()
    assert not undefined
    assert hash(undefined) == 0


undefined = _Undefined()



# Generated at 2022-06-24 14:29:18.392794
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(open(get_test_file('test.swf'), 'rb').read(),
                         global_scope=None)
    assert global_scope is not None

    avm_class = swf.avm_classes['Main']
    avm_class.method_pyfunctions['test'] = None

    func = swf.extract_function(avm_class, 'test')
    # Test _builtin_classes
    assert func() is undefined
    assert func(1) == 2
    assert func(1, 2) == 3
    assert func(1, 2, 3, 4) == 10

    # Test attributes
    assert func([3, 4])[0] == 3

    # Test function calls
    assert func(func) is func

    # Test built-in constructors

# Generated at 2022-06-24 14:29:20.578425
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
  assert "'undefined'" in str(_Undefined()) # str


_undefined = _Undefined()



# Generated at 2022-06-24 14:29:22.153560
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert repr(_ScopeDict(object)).startswith('object__Scope(')



# Generated at 2022-06-24 14:29:24.244638
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_ = _AVMClass_Object(None)
    assert class_ is not None



# Generated at 2022-06-24 14:29:32.510331
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass('someclass', 'someclass', {})
    c.register_methods({'m1': 0, 'm2': 1})
    assert c.method_idxs == {0: 'm1', 1: 'm2'}
    assert c.method_names == {'m1': 0, 'm2': 1}
    c.register_methods({'m3': 2, 'm4': 3})
    assert c.method_idxs == {0: 'm1', 1: 'm2', 2: 'm3', 3: 'm4'}
    assert c.method_names == {'m1': 0, 'm2': 1, 'm3': 2, 'm4': 3}



# Generated at 2022-06-24 14:29:36.422708
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    sd = _ScopeDict([
        ('a', 1),
        ('b', 2),
        ('c', 3)])
    sd['b'] = 4
    assert repr(sd) == "{'a': 1, 'b': 4, 'c': 3}", repr(sd)



# Generated at 2022-06-24 14:29:40.636986
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    intepreter = SWFInterpreter()
    t = intepreter.extract_class(os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'test.swf'))
    assert t.variables['test']('hello') == 'helloX'

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-24 14:29:44.658158
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from yalix import avm2
    a = avm2._AVMClass('foobar','bar')
    a = str(a)
    assert 2+2 == 4



# Generated at 2022-06-24 14:29:54.838519
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    """Test method extract_class of class SWFInterpreter."""

# Generated at 2022-06-24 14:29:57.586986
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:29:59.344960
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0x07)
    _Multiname(0x0D)
    _Multiname(0x11)
    _Multiname(0x09)



# Generated at 2022-06-24 14:30:02.003482
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    foo_class = _AVMClass(0, 'Foo')

    foo_obj = foo_class.make_object()
    assert isinstance(foo_obj, _AVMClass_Object)
    assert foo_obj.avm_class == foo_class



# Generated at 2022-06-24 14:30:04.240662
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-24 14:30:06.184695
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    _Undefined().__repr__()

_undefined = _Undefined()



# Generated at 2022-06-24 14:30:12.061573
# Unit test for constructor of class _Multiname
def test__Multiname():
    repr(_Multiname(0x07))

QName = collections.namedtuple('QName', ('ns', 'name'))
RTQName = collections.namedtuple('RTQName', ('name', ))
RTQNameL = collections.namedtuple('RTQNameL', ())
Multiname = collections.namedtuple('Multiname', ('name', ))
MultinameL = collections.namedtuple('MultinameL', ())
MultinameQName = collections.namedtuple('Multiname', ('ns', 'name'))
MultinameQNameL = collections.namedtuple('Multiname', ())

# Generated at 2022-06-24 14:30:25.120417
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from pyamf import remoting
    from pyamf.remoting.client import RemotingService
    from pyamf.util import amf_decode_with, amf_encode_with
    from pyamf.tests.util import unittest
    from swfdecompiler import SWFInterpreter

    si = SWFInterpreter()
    si.amf3_decode = amf_decode_with(remoting.decoders)
    si.amf3_encode = amf_encode_with(remoting.encoders)

    outputs = []

# Generated at 2022-06-24 14:30:26.447220
# Unit test for constructor of class _Multiname
def test__Multiname():
    m = _Multiname(5)
    assert m.kind == 5



# Generated at 2022-06-24 14:30:30.697910
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Patching a function is not a straight-forward operation, as
    # functions can be called in various ways and its call may
    # even be embedded in other bytecode, so it is not possible
    # to create a general test that would patch a function and
    # check if it has been patched indeed.
    SWFInterpreter(b'').patch_function(b'', b'')



# Generated at 2022-06-24 14:30:40.387575
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # !!! Do not forget to put a docstring !!!
    # Unit test for method extract_function of class SWFInterpreter
    obj = SWFInterpreter()
    obj.constant_strings = [
        "player", "VideoPlayer", "get_video_info", "playbackToken",
        "t", "video_id", "credentials", "signatureCipher",
        "VideoInfo", "streams", "flashVersion", "minVersion", "formats",
        "httpStreams", "mimeType", "quality", "url", "itag", "streamerType",
        "getStreams", "https://", "rtmp://", "videoplayback", "cipheredSignature",
        "setProperty"
    ]

# Generated at 2022-06-24 14:30:42.902998
# Unit test for constructor of class _Multiname
def test__Multiname():
    a = _Multiname(3)
    assert a.kind == 3
    assert repr(a) == '[MULTINAME kind: 0x3]'
test__Multiname()



# Generated at 2022-06-24 14:30:45.313812
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    f = _AVMClass(1, 'Foo')
    assert f.name_idx == 1
    assert f.name == 'Foo'



# Generated at 2022-06-24 14:30:54.143223
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert _AVMClass_Object(
        _AVMClass(
            name='_AVMClass',
            properties=[],
            methods=[],
        )
    ).__repr__() == '_AVMClass#0x44556677'


_Type_UnsignedInt = b'\x00'
_Type_Integer = b'\x03'
_Type_Double = b'\x06'
_Type_String = b'\x01'
_Type_Object = b'\x03'
_Type_MovieClip = b'\x04'
_Type_Null = b'\x05'
_Type_Undefined = b'\x06'
_Type_Reference = b'\x07'
_Type_ECMAArray = b'\x08'

# Generated at 2022-06-24 14:30:57.650168
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    assert _AVMClass(1, 'name')

# Stub class for classes referenced in AVM bytecode
# that aren't defined in the bytecode.

# Generated at 2022-06-24 14:31:01.684351
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    assert str(_AVMClass('', '_AVMClass').make_object()) == '_AVMClass#13'
    assert str(_AVMClass('', '_AVMClass').make_object()) == '_AVMClass#14'

# Generated at 2022-06-24 14:31:03.691273
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    d = _ScopeDict(_AVMClass(''))
    d['x'] = 1
    d['y'] = 2
    assert repr(d) == "_AVMClass('')__Scope({'x': 1, 'y': 2})"



# Generated at 2022-06-24 14:31:05.864383
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    c = _AVMClass(1, 'Object')
    assert str(c) == '_AVMClass(Object)'

# Generated at 2022-06-24 14:31:12.146074
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(0, 'TestClass', {})
    assert avm_class.method_names == {}
    assert avm_class.method_idxs == {}
    avm_class.register_methods({'test_method': 0})
    assert avm_class.method_names == {'test_method': 0}
    assert avm_class.method_idxs == {0: 'test_method'}

    avm_class.register_methods({'test_method1': 1, 'test_method2': 2})
    assert avm_class.method_names == {'test_method': 0, 'test_method1': 1, 'test_method2': 2}

# Generated at 2022-06-24 14:31:17.477604
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    import pytest
    from .utils import DummyMeth, DummyObject

    class DummyClass(object):
        pass

    avm_class = _AVMClass(1, 'foo', {'a': 'b', 'c': DummyMeth(DummyClass)})
    assert repr(avm_class) == "_AVMClass('foo')"

# Generated at 2022-06-24 14:31:20.134080
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    inst = _AVMClass('name_idx', 'name')
    assert repr(inst) == "_AVMClass('name')"

