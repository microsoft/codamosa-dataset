

# Generated at 2022-06-24 14:21:21.781161
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    from .test_utils import perform_basic_tests
    perform_basic_tests(
        _Undefined())

# Generated at 2022-06-24 14:21:24.809142
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    u = _Undefined()
    assert str(u) == 'undefined'
    assert repr(u) == 'undefined'

# Generated at 2022-06-24 14:21:30.375922
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(2, 'FlashNetConnect')
    assert avm_class.name_idx == 2
    assert avm_class.name == 'FlashNetConnect'
    assert avm_class.static_properties == {}
    assert avm_class.method_names == {}
    assert avm_class.methods == {}
    assert avm_class.variables == {}
    assert avm_class.constants == {}


# Generated at 2022-06-24 14:21:35.348593
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = open(os.path.join(TEST_DIR, 'test_ver.swf'), 'rb').read()
    swf = BytesIO(swf)
    swf = SWF(swf)
    _ = SWFInterpreter(swf)


# Generated at 2022-06-24 14:21:43.661955
# Unit test for constructor of class _Multiname
def test__Multiname():
    m = _Multiname(13)
    assert repr(m) == '[MULTINAME kind: 0xd]'

# TODO: parse the file and dynamically create classes instead
# of manually adding them.

# Generated at 2022-06-24 14:21:44.849634
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()

Undefined = _Undefined()



# Generated at 2022-06-24 14:21:50.552216
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    # Tests for method make_object of class AVMClass
    x = _AVMClass('foo', 'foo')
    assert x.make_object()
    assert isinstance(x.make_object(), _AVMClass_Object)
    assert x.make_object().avm_class



# Generated at 2022-06-24 14:21:52.312846
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined(), 'not _Undefined()'
# Unit tests for method __init__ of class _Undefined

# Generated at 2022-06-24 14:21:53.586872
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    _ScopeDict(None)


# Generated at 2022-06-24 14:21:54.637141
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


# Generated at 2022-06-24 14:21:56.553431
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    def dummy_func(*args):
        return args
    _AVMClass('test_class', {
        'test': 1,
        'method': dummy_func
    }, {
        'static': 2,
        'property': 3,
    })
test__AVMClass()



# Generated at 2022-06-24 14:21:57.946910
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


_undefined = _Undefined()



# Generated at 2022-06-24 14:22:08.586669
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(None, 'Test')
    c.register_methods({'f1': 1, 'f2': 2})
    assert c.method_names == {'f1': 1, 'f2': 2}
    assert c.method_idxs == {1: 'f1', 2: 'f2'}

    c.register_methods({'f3': 3})
    assert c.method_names == {'f1': 1, 'f2': 2, 'f3': 3}
    assert c.method_idxs == {1: 'f1', 2: 'f2', 3: 'f3'}

    # Should ignore None name
    c.register_methods({None: 4, 'f4': 5})

# Generated at 2022-06-24 14:22:12.858351
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert repr(_AVMClass_Object(_AVMClass('MovieClip'))) == 'MovieClip#%x' % id(_AVMClass_Object(_AVMClass('MovieClip')))
# End of unit test for method __repr__ of class _AVMClass_Object



# Generated at 2022-06-24 14:22:14.207407
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class avm_class(object):
        name = 'foo.bar'
    assert repr(_AVMClass_Object(avm_class()))



# Generated at 2022-06-24 14:22:17.409603
# Unit test for constructor of class _Undefined
def test__Undefined():
    u = _Undefined()
    assert str(u) == 'undefined'
    assert not bool(u)
    assert hash(u) == 0


_undefined = _Undefined()



# Generated at 2022-06-24 14:22:18.710915
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    s = _ScopeDict(None)
    assert repr(s) == 'None__Scope({})'



# Generated at 2022-06-24 14:22:20.647869
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    undef = _Undefined()
    assert not undef
if __name__ == '__main__':
    test__Undefined___bool__()



# Generated at 2022-06-24 14:22:25.536959
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter()

    class TestAVMClass:
        def __init__(self, avm_class):
            self.avm_class = avm_class


# Generated at 2022-06-24 14:22:30.060023
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    si = SWFInterpreter()
    si.classes = {}
    si.constant_strings = []
    si.multinames = []
    si.method_name = 'test_method'
    # Example extracted from
    # http://www.swfdec.org/source/swfdec_interp_avm_c.html

# Generated at 2022-06-24 14:22:31.640646
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    res = repr(_Undefined())
    return res


_undefined = _Undefined()



# Generated at 2022-06-24 14:22:34.065568
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class AVMClass(object):
        name = 'SomeClass'
    scope = _ScopeDict(AVMClass())
    scope['k'] = 'v'
    assert repr(scope) == ("SomeClass__Scope({'k': 'v'})")


# Generated at 2022-06-24 14:22:34.954741
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert _AVMClass_Object(None).avm_class is None



# Generated at 2022-06-24 14:22:38.272422
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

_undefined = _Undefined()



# Generated at 2022-06-24 14:22:48.738748
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():

    def assert_all_undefined(avm_class):
        for pname in avm_class.method_names:
            assert avm_class.method_pyfunctions[pname] is undefined
        for pname in avm_class.static_properties:
            assert avm_class.static_properties[pname] is undefined

    class TestLoader(object):
        def __init__(self, indata):
            self.indata = indata

        def load(self, *args, **kwargs):
            return self.indata

# Generated at 2022-06-24 14:22:53.427034
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    for name in ['_AVMClass_Object', '_AVMClass_Array_Object']:
        class_ = _AVMClass(name)
        obj = _AVMClass_Object(class_)
        assert repr(obj) == '%s#%x' % (name, id(obj))



# Generated at 2022-06-24 14:22:54.792145
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert repr(_ScopeDict(None)) == '__Scope({})'



# Generated at 2022-06-24 14:22:56.536063
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
# End of unit test


Undefined = _Undefined()



# Generated at 2022-06-24 14:23:04.268304
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .test import get_test_file_path
    from .sdk import parse_swf_and_extract_classes, _reload_modified
    filename = get_test_file_path('decrypt_aes_cbc.swf')
    interpreter = SWFInterpreter()
    swf = parse_swf_and_extract_classes(
        filename, interpreter=interpreter,
        preload_file_callback=_reload_modified(filename))

    time_after_parse = time.time()
    print('Time after parse: %.3fs' % time_after_parse)
    assert len(interpreter.classes) == 28

    interpreter.extract_function(
        interpreter.classes['Main'], 'main')

    time_after_extract = time.time()
    diff = time_

# Generated at 2022-06-24 14:23:06.031041
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert repr(_ScopeDict(None)) == '__Scope({})', repr(_ScopeDict(None))
test__ScopeDict___repr__()



# Generated at 2022-06-24 14:23:13.872424
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    def to_b(s):
        return bytearray(s, 'utf-8')

    # Example class with "publish")

# Generated at 2022-06-24 14:23:17.683695
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    m = _Multiname(0x42)
    assert repr(m) == '[MULTINAME kind: 0x42]'
# /Unit test for method __repr__ of class _Multiname



# Generated at 2022-06-24 14:23:20.925190
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    name = 'abc'
    obj = _AVMClass(None, name)
    assert obj.__repr__() == '_AVMClass(abc)' 
    
    

# Generated at 2022-06-24 14:23:23.316252
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    obj = _AVMClass_Object(None)
    assert '#' in repr(obj)


# Generated at 2022-06-24 14:23:25.257304
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'



# Generated at 2022-06-24 14:23:26.484791
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert str(_Undefined()) == 'undefined'
undefined = _Undefined()



# Generated at 2022-06-24 14:23:30.650028
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s = '''
var Object = new Object();
var String = new String();
var Number = new Number();
'''
    res = SWFInterpreter.extract_class('Test', s)
    assert 'Object' in res.variables
    assert res.variables['Object'].name == 'Object'


# Generated at 2022-06-24 14:23:34.670650
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass('', '')
    avm_class.register_methods({"method1":1, "method2":2})
    assert avm_class.method_names == {"method1":1, "method2":2}
    assert avm_class.method_idxs == {1:"method1", 2:"method2"}


# Generated at 2022-06-24 14:23:40.243705
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(0, 'Sample', {'prop': 'val'})
    assert avm_class.name_idx == 0
    assert avm_class.name == 'Sample'
    assert avm_class.static_properties == {'prop': 'val'}



# Generated at 2022-06-24 14:23:41.962428
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    obj = _Undefined()
    assert 'undefined' == str(obj)

# Generated at 2022-06-24 14:23:45.772637
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    from .parse_abc import _AVMClassSymbol
    s = _ScopeDict(_AVMClassSymbol('test'))
    assert 'this' not in s
    s['this'] = 'that'
    assert s['this'] == 'that'
    assert 'this' in s



# Generated at 2022-06-24 14:23:48.980953
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    _ScopeDict._ScopeDict__repr__(_ScopeDict(_AVMClass_Object(_AVMClass_Object(_AVMClass_Object(_AVMClass_Object(_AVMClass_Object({})))))))


# Generated at 2022-06-24 14:23:52.342684
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    multiname = _Multiname(0x0d)
    assert repr(multiname) == '[MULTINAME kind: 0x0d]'
test__Multiname___repr__()


# Generated at 2022-06-24 14:23:53.248395
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert(_Undefined() == _Undefined())

Undefined = _Undefined()



# Generated at 2022-06-24 14:24:01.042448
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from yalafi.defs import init_defs
    from yalafi.parser import get_parser
    from yalafi.swf.defs import init_functions, init_classes

    for latex in [
        r'\parskip',
        r'\foo',
        r'\parskip\relax\foo{a}',
    ]:
        p = get_parser(latex)
        p.parse()
        plain_text, defs = p.get_plain_text()

        init_defs(defs)

        functions = {}
        init_functions(functions)
        assert len(functions) > 0

        classes = {}
        init_classes(classes)

        avm = _AVM_Machine(classes, functions)

# Generated at 2022-06-24 14:24:03.064337
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:24:04.933998
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert hash(_Undefined()) == 0


_undefined = _Undefined()



# Generated at 2022-06-24 14:24:14.909509
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    """
    Unit test for method extract_function
    """
    # Create a fake class
    class TestAVMClass(object):
        """
        A fake class to test SWFInterpreter.extract_function
        """
        # pylint: disable=too-few-public-methods

        def __init__(self):
            self.variables = {}
            self.static_properties = {}
            self.method_names = set()
            self.method_pyfunctions = {}
    # Create a fake subclass
    class TestAVMClass_Object(object):
        """
        A fake class to test SWFInterpreter.extract_function
        """
        # pylint: disable=too-few-public-methods
        def __init__(self, avm_class):
            self.avm_class

# Generated at 2022-06-24 14:24:20.465927
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    test_cases = [
        {
            'assert': '__main__.AVMClass#3f3aadb0__Scope({\'alpha\': 1})',
            'args': {
                'avm_class': '__main__.AVMClass#3f3aadb0',
                'dict': {'alpha': 1},
            },
            'method': '_ScopeDict',
        },
    ]
    for test_case in test_cases:
        assert test_case['assert'] == repr(getattr(
            globals()[test_case['method']](**test_case['args']),
            test_case['method'])(),
        )



# Generated at 2022-06-24 14:24:23.469528
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert repr(_AVMClass(None, None)) == '_AVMClass(None)'



# Generated at 2022-06-24 14:24:34.635986
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .abce import load_file
    from .abc_interpreter import ABCInterpreter
    from .abc_compiler import ABCCompiler
    from .abc_parser import parse_file
    interp = ABCInterpreter()
    interp.load_file('tests/abce/arithm.abc')
    compiled = ABCCompiler(parse_file('tests/abce/arithm.abc'))
    func_name_bodies = {}
    for func_name, func_body in iteritems(compiled.functions):
        func_name_bodies[func_name] = func_body.data
    interp.patch_function = SWFInterpreter(func_name_bodies).patch_function

    interp.run_method('addition')
    interp.stack
    interp.run_

# Generated at 2022-06-24 14:24:35.548593
# Unit test for constructor of class _Multiname
def test__Multiname():
    return _Multiname


# Generated at 2022-06-24 14:24:39.694596
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(None)) == '?#%x' % id(_AVMClass_Object(None))



# Generated at 2022-06-24 14:24:49.319125
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swf.SWF import SWF
    swf = SWF()
    swf.read('test/test.swf')
    interpreter = SWFInterpreter(swf)
    assert len(interpreter.traits.keys()) == 6
    assert interpreter.has_class('Logo')
    assert interpreter.has_class('Object')
    assert interpreter.has_class('String')
    assert interpreter.has_class('Number')
    assert interpreter.has_class('Boolean')
    assert interpreter.has_class('Array')
    assert len(interpreter.constant_strings) == 69
    assert len(interpreter.constant_names) == 3
    assert len(interpreter.multinames) == 27
    assert interpreter.multinames[0].name == 'constructor'

# Generated at 2022-06-24 14:24:56.991497
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interp = SWFInterpreter()
    coder = compat_BytesIO(b'\x03\x00')
    with pytest.raises(NotImplementedError):
        interp.patch_function('foo', coder, [])

# _AVMClass_Object
_Object_prototype = {'constructor': lambda args: {}.update(args[0])}

# Generated at 2022-06-24 14:25:09.095460
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open(os.path.join(os.path.dirname(__file__), "FlashPlayer_10.2.version"), 'rb') as f:
        swf = SWFInterpreter(f)
    with open(os.path.join(os.path.dirname(__file__), "FlashPlayer_10.2.version"), 'rb') as f:
        swf2 = SWF(f)
        class_idx = swf2.abc_class_idx_map['flash.system.Capabilities']
        avm_class = swf2.classes[class_idx]
        version = swf2.classes[class_idx].make_object()['playerType']
        assert version == swf.avm_class.playerType




# Generated at 2022-06-24 14:25:17.317128
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class TestClass(object):
        pass
    tinst = TestClass()

    def test_func(args):
        return tinst

    def test_func2():
        return 42

    c = SWFInterpreter()
    c.patch_function(tinst, 'foo', test_func)
    c.patch_function(tinst, 'foo', test_func, args=['hello'])
    c.patch_function(tinst, 'bar', test_func2)
    assert tinst.foo(1) == tinst
    assert tinst.foo() == 'hello'
    assert tinst.bar() == 42


# Playing AVM2
# Command line interface

# Generated at 2022-06-24 14:25:18.683144
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

# Generated at 2022-06-24 14:25:20.063784
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert repr(_ScopeDict(None)) == repr(_ScopeDict({}))



# Generated at 2022-06-24 14:25:23.429391
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    cl = _AVMClass('', {})
    d = _ScopeDict(cl)
    assert str(d) == '__Scope({})'
    d['a'] = 1
    assert str(d) == '__Scope({\'a\': 1})'

# Generated at 2022-06-24 14:25:35.946317
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    import pickle
    # This test depends on executing the code below:
    # class Foo:
    #     pass
    def_obj = _AVMClass_Object(None)
    foo = Foo()
    foo.__class__ = _AVMClass_Object
    assert type(foo) == _AVMClass_Object
    assert repr(foo) == 'Foo#%x' % id(foo)
    foo.avm_class = def_obj
    foo_pickled = pickle.dumps(foo)
    foo2 = pickle.loads(foo_pickled)
    assert foo2.avm_class == def_obj
    assert type(foo2) == _AVMClass_Object
    assert repr(foo2) == '{}#%x' % id(foo2)



# Generated at 2022-06-24 14:25:38.981002
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class MyAVMClass(object):

        @property
        def name(self):
            return 'MyAVMClass'

    _AVMClass_Object(MyAVMClass())



# Generated at 2022-06-24 14:25:42.267410
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _AVMClass_Object(object):
        pass
    assert repr(_ScopeDict(_AVMClass_Object())) == '_AVMClass_Object__Scope({})'



# Generated at 2022-06-24 14:25:53.264753
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()
    interpreter.constant_strings = ['foo', 'bar']


# Generated at 2022-06-24 14:25:57.315169
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _AVMClass(object):
        def __init__(self):
            self.name = 'test__ScopeDict'
    assert repr(_ScopeDict(_AVMClass())) == 'test__ScopeDict__Scope({})'



# Generated at 2022-06-24 14:26:04.155876
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    """Test method __repr__ of class _ScopeDict."""
    scopedict = avm2.action_script.AVM2._ScopeDict(None)
    scopedict['a'] = 1
    scopedict['b'] = 2
    assert scopedict.__repr__() == 'None__Scope({\'a\': 1, \'b\': 2})'



# Generated at 2022-06-24 14:26:16.024331
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from re import search
    from random import choice as rnd_choice
    from string import ascii_letters as letters
    from .test_AVMClass import test__AVMClass_register_methods
    
    class Pattern(object):
        def __init__(self, *args, **kwargs):
            
            self.defaults = {}
            self.regex = args[0]
            if 'defaults' in kwargs:
                self.defaults = kwargs['defaults']
                del kwargs['defaults']
            self.args = args[1:]
            self.kwargs = kwargs
        

# Generated at 2022-06-24 14:26:27.309415
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from . import _SWFExporter

    exporter = _SWFExporter()

# Generated at 2022-06-24 14:26:30.559702
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    c = _AVMClass_Object(_AVMClass)
    assert c.avm_class is _AVMClass
    assert repr(c) == '_AVMClass#%x' % id(c)



# Generated at 2022-06-24 14:26:42.988432
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter(None, None, None)
    avm_class = _AVMClass({}, {})
    assert_equal(interpreter.extract_function(avm_class, 'foo'), None)
    interpreter.extract_function(avm_class, 'foo')
    assert_equal(interpreter.extract_function(avm_class, 'foo'), None)
    interpreter.extract_function(avm_class, 'foo')
    assert_equal(interpreter.extract_function(avm_class, 'foo'), None)
    interpreter.extract_function(avm_class, 'bar')
    assert_equal(interpreter.extract_function(avm_class, 'foo'), None)
    interpreter.extract_function(avm_class, 'foo')


# Generated at 2022-06-24 14:26:46.909466
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    x = _AVMClass('Object', {})
    y = x.make_object()
    assert isinstance(y, _AVMClass_Object)
    assert y.avm_class is x



# Generated at 2022-06-24 14:26:47.728414
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

# Generated at 2022-06-24 14:26:52.894267
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_1 = _AVMClass('test_class_1', {})
    print(class_1)
    print(class_1.variables)
    print(class_1.constants)
    print(class_1.methods)
    print(class_1.method_idxs)
    print(class_1.method_names)



# Generated at 2022-06-24 14:26:54.222099
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass(0, u'')
    assert repr(obj) == '_AVMClass(u\'\')'


# Generated at 2022-06-24 14:26:59.576824
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class _DummyAVMClass(object):
        name = 'foo'
    dummy_avm_class = _DummyAVMClass()
    avm_object = _AVMClass_Object(dummy_avm_class)
    assert repr(avm_object) == 'foo#%x' % id(avm_object)
test__AVMClass_Object___repr__()



# Generated at 2022-06-24 14:27:02.022357
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    si = SWFInterpreter(os.path.join(
        test_dir, 'testdata', 'test-flashlive-live-clusters.swf'))
    si.extract_class()
    si.extract_class('one.video.ClusterList')
    si.extract_class('one.video.ClusterList', 'init')

# Generated at 2022-06-24 14:27:07.862295
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avmclass = _AVMClass(3, 'foo', {'a': 'b'})
    assert avmclass.name_idx == 3
    assert avmclass.name == 'foo'
    assert avmclass.static_properties == {'a': 'b'}
    assert repr(avmclass) == "_AVMClass('foo')"



# Generated at 2022-06-24 14:27:10.712583
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    class_obj = _AVMClass('dummy_name', 'dummy_name')
    assert class_obj.__repr__() == '_AVMClass(dummy_name)'



# Generated at 2022-06-24 14:27:12.180721
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
Undefined = _Undefined()



# Generated at 2022-06-24 14:27:14.939587
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert ('AVM_Class#0x413de70' ==
        repr(_AVMClass_Object(_AVMClass('AVM_Class'))))
test__AVMClass_Object___repr__()



# Generated at 2022-06-24 14:27:21.782859
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s = SWFInterpreter({})

# Generated at 2022-06-24 14:27:25.996385
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    x = _Multiname(1)
    assert repr(x) == '[MULTINAME kind: 0x1]'
    x = _Multiname(42)
    assert repr(x) == '[MULTINAME kind: 0x2a]'




# Generated at 2022-06-24 14:27:31.352970
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-24 14:27:35.743635
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    object_ = _AVMClass_Object(_AVMClass_Object)
    assert object_.__repr__() == '_AVMClass_Object#%x' % id(object_)



# Generated at 2022-06-24 14:27:47.147313
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()
    avm = interpreter.load_swf(path_or_fd('tests/swfs/vast-viewability-threshold.swf'))
    player = avm.classes['Player']
    func = interpreter.extract_function(player, 'p')
    func(['s'])
    assert func._original_code
    assert func.func_code.co_argcount == 1
    assert func.func_code.co_varnames == ('self', 'arg1')

# Generated at 2022-06-24 14:27:50.999700
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class_foo = _AVMClass('foo')
    class_foo.name = 'foo'
    class_instance = _AVMClass_Object(class_foo)
    assert repr(class_instance) == 'foo#%x' % id(class_instance)



# Generated at 2022-06-24 14:27:55.186185
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class AVMClass(object):
        pass
    _AVMClass_Object.get_property = lambda self, avm_class, prop_name: None
    o = _AVMClass_Object(AVMClass)
    assert o.__repr__() == 'AVMClass#%x' % id(o)



# Generated at 2022-06-24 14:28:02.649244
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io
    import pprint
    from .swf_utils import SWF
    from .enum_abc_tags import ABC_TAG
    from .abc_tags import ABC
    from .abctags_body import _Body

    with io.open('examples/swfs/as3_trace.swf', 'rb') as f:
        swf = SWF(f)
        abc = None
        for tag in swf.tags:
            if isinstance(tag, ABC_TAG):
                abc = ABC()
                abc.parse(tag.reader, tag.header.size)
                break
        assert abc
        assert len(abc.body.trait_count) == 1,\
            'Expected only one Trait in the file'

# Generated at 2022-06-24 14:28:05.999628
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert eval(repr(_Undefined())) is _Undefined()
# Test code for method __repr__ of class _Undefined


Undefined = _Undefined()



# Generated at 2022-06-24 14:28:15.882764
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class _TestSWF:
        def __init__(self, code):
            self.code = code
            self.tag_size = len(code)
        def read(self, size):
            data = self.code[:size]
            self.code = self.code[size:]
            return data

    interpreter = SWFInterpreter()
    interpreter.extract_class(
        _TestSWF(testdata_swf_class1), 'test_SWFInterpreter_extract_class')
    classname = 'test_SWFInterpreter_extract_class'
    assert classname in interpreter.avm2_classes
    avm_class = interpreter.avm2_classes[classname]
    assert avm_class.variables[0] == 1

# Generated at 2022-06-24 14:28:21.050775
# Unit test for constructor of class _Undefined
def test__Undefined():
    # __str__ returns a string
    assert isinstance(str(_Undefined()), str)
    # Two instances are equal
    assert _Undefined() == _Undefined()
    # Two instances have the same hash value
    assert hash(_Undefined()) == hash(_Undefined())
    # The instance is false
    assert not _Undefined()
    # The instance is not true
    assert _Undefined() is not True


_undefined = _Undefined()



# Generated at 2022-06-24 14:28:23.358724
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    _extract_function()


# Class SWF that holds information of the SWF file and its tags

# Generated at 2022-06-24 14:28:26.945050
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class A(object):
        pass
    AClass = _AVMClass_Object(A)
    assert repr(AClass) == '%s#%x' % (A.__name__, id(AClass))



# Generated at 2022-06-24 14:28:37.076989
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from io import BytesIO
    from .compat import compat_bytes
    from .swftags import TagDefineSprite
    from .swftags import TagSymbolClass
    from .swfdecompiler import (
        get_swf_decompiler,
        _AVMClass_Object,
    )
    from .utils import (
        extract_swf_headers,
        get_exception_message,
        get_exception_stacktrace,
    )
    from .compat import (
        compat_mkstemp,
    )
    from tempfile import (
        mkstemp,
    )
    from contextlib import closing


# Generated at 2022-06-24 14:28:39.883269
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) is False
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'

undefined = _Undefined()


# Generated at 2022-06-24 14:28:43.961408
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(_AVMClass_String())) == 'String#1'

_AVMClasses = collections.OrderedDict()
_AVMInstances = []



# Generated at 2022-06-24 14:28:55.505741
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-24 14:28:58.923274
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    inst = _AVMClass_Object(_AVMClass_Object)
    assert repr(inst) == '_AVMClass_Object#%x' % id(inst)



# Generated at 2022-06-24 14:29:10.570235
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    def do_asserts(expected, obj):
        assert expected == repr(obj)

# Generated at 2022-06-24 14:29:18.024163
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Required for some test cases
    _builtin_classes['String'] = StringClass

    class FakeAVMClass(object):
        def __init__(self, variables):
            self.method_pyfunctions = {}
            self.variables = variables

    avm_class = FakeAVMClass({})

    # Normal constructor

# Generated at 2022-06-24 14:29:25.892250
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = io.BytesIO(SWF_BYTES)
    f = io.BytesIO(swf.read())
    swf = SWF(f)
    interpreter = SWFInterpreter(swf)
    assert interpreter.avm_class.method_pyfunctions['AmfFunction'] is None
    interpreter.patch_function('AmfFunction')
    assert interpreter.avm_class.method_pyfunctions['AmfFunction'] is not None
# class _AVMClass

# Generated at 2022-06-24 14:29:30.702152
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from pprint import pprint
    from .codegen import _AVMClass
    obj = _AVMClass(name='x', fields={}, methods={})
    obj = _ScopeDict(obj)
    obj['a'] = '1'
    obj['b'] = '2'
    pprint(obj)



# Generated at 2022-06-24 14:29:35.761359
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    from .utils import make_testcase
    testcase = make_testcase(
        _Multiname(0x0b).__repr__,
        description='_Multiname.__repr__',
        expected='[MULTINAME kind: 0xb]',
    )
    return testcase

# Generated at 2022-06-24 14:29:38.733454
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class DummyAVMClass(object):
        def __init__(self, name):
            self.name = name
    assert repr(_ScopeDict(DummyAVMClass(name='AVMClass'))).startswith(
        'AVMClass__Scope({')



# Generated at 2022-06-24 14:29:50.977436
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter(open(test_file('test.swf'), 'rb'))

    def simple_test(test_name, return_value):
        def resfunc(_):
            return return_value
        interpreter.extract_function(resfunc, test_name)

    simple_test('access_child', 0)
    simple_test('access_child_node', 0)
    simple_test('join', '{}')
    simple_test('encodeURIComponent', '{}')
    simple_test('decodeURIComponent', '{}')
    simple_test('ascii_to_b64', 0)

# Generated at 2022-06-24 14:29:58.358438
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter()

# Generated at 2022-06-24 14:30:01.225149
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    parent = _AVMClass_Object(_AVMClass('Parent', None))
    child = _AVMClass_Object(_AVMClass('Child', parent))
    assert repr(parent) == 'Parent#%x' % id(parent)
    assert repr(child) == 'Child#%x' % id(child)



# Generated at 2022-06-24 14:30:13.310169
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from .avm_common import _AVMClass
    from .avm_common import _AVMClass_Object
    from .avm_common import _AVMMethod
    from .avm_common import _AVMMethod_Object

    m = _AVMClass('Main', None, None)
    o = m.make_object()
    assert o.avm_class.name == 'Main'
    m.register_methods(dict(
        (compat_str('f1'), 'f1_idx'),
        (compat_str('f2'), 'f2_idx'),
    ))
    assert m.method_names == dict(
        (compat_str('f1'), 'f1_idx'),
        (compat_str('f2'), 'f2_idx'),
    )
    assert m

# Generated at 2022-06-24 14:30:26.248866
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    si = SWFInterpreter()
    si.constant_strings.append('org.osmf.elements.proxyClass')
    si.constant_strings.append('proxyFunction')
    si.constant_strings.append('smu')
    si.constant_strings.append('media')
    si.constant_strings.append('id')
    si.constant_strings.append('args')
    si.constant_strings.append('get')
    si.constant_strings.append('plugin/adal')

    si.multinames.append({
        'namespace': 'org.osmf.elements.proxyClass',
        'name': 'proxyFunction',
        'kind': _CONSTANT_QName,
    })

# Generated at 2022-06-24 14:30:30.747468
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    inst = _AVMClass(name_idx=1, name='Test', static_properties={'a': 1})
    assert repr(inst) == '_AVMClass(Test)'
    class T(type(_AVMClass__register_methods)):
        def __call__(*args, **kwargs):
            return T()
    inst.register_methods = T()
    assert repr(inst) == '_AVMClass(Test)'



# Generated at 2022-06-24 14:30:35.627500
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert repr(_ScopeDict(None)) == 'None__Scope({})'
    assert repr(_ScopeDict(None, a=1)) == 'None__Scope({\'a\': 1})'
    assert repr(_ScopeDict(None, a=1, b=2)) == 'None__Scope({\'a\': 1, \'b\': 2})'



# Generated at 2022-06-24 14:30:36.941573
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    return '_AVMClass(%s)' % (self.name)


# Generated at 2022-06-24 14:30:46.639321
# Unit test for method register_methods of class _AVMClass

# Generated at 2022-06-24 14:30:49.310655
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class AVMClass(object):
        name = 'X'

    assert repr(_ScopeDict(AVMClass)) == 'X__Scope(%r)' % {}



# Generated at 2022-06-24 14:30:58.303171
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    """
    This unit test checks the correct operation of the method
    :meth:`SWFInterpreter.extract_function` of the class :class:`SWFInterpreter`.
    """
    import sys
    output = sys.stderr
    avi = SWFInterpreter(debug_output = output)
    def f(args):
        return args[0]
    avi.extract_function("class1", "method1", f)
    assert avi.class_swf.functions["class1"]["method1"][0] == f

# Class SWFInterpreter

# Generated at 2022-06-24 14:31:08.783252
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class _AVMClass:
        def __init__(self, name_idx, name, static_properties=None):
            self.name_idx = name_idx
            self.name = name
            self.method_names = {}
            self.method_idxs = {}
            self.methods = {}
            self.method_pyfunctions = {}
            self.static_properties = static_properties if static_properties else {}

            self.variables = _ScopeDict(self)
            self.constants = {}

        def make_object(self):
            return _AVMClass_Object(self)

        def __repr__(self):
            return '_AVMClass(%s)' % (self.name)


# Generated at 2022-06-24 14:31:15.484231
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    global_class = _AVMClass(0, 'global')
    assert global_class.name_idx == 0
    assert global_class.name == 'global'
    assert global_class.method_names == {}
    assert global_class.method_idxs == {}
    assert global_class.methods == {}
    assert global_class.method_pyfunctions == {}



# Generated at 2022-06-24 14:31:20.127601
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    res = [
        (bool(_Undefined()), False),
    ]
    try:
        from test import _test
        _test(res)
    except ImportError:
        pass

