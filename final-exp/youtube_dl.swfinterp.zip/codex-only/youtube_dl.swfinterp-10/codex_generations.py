

# Generated at 2022-06-24 14:21:21.732853
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    return str(_Undefined()) == 'undefined'

_undefined = _Undefined()



# Generated at 2022-06-24 14:21:24.763846
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    d = _Undefined()
    assert d.__repr__() == 'undefined'
# End unit test

# Generated at 2022-06-24 14:21:35.116608
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    foo_class_abc = r'abc'
    foo_class_from_swf = r'foo_class'
    bar_class_from_swf = r'bar_class'
    baz_class_from_swf = r'baz_class'

# Generated at 2022-06-24 14:21:36.097383
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    _AVMClass(1, 'String')



# Generated at 2022-06-24 14:21:44.218087
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swftags import TagDoABC
    from .abc import ABCFile
    from .abc import SWFMetadataInfo, SWFMetadataItem, ABCMethodBody
    from .abc import ABCConstantPool, ABCMultiname, ABCMethod, ABCMethodInfo
    from .abc import ABCClass, ABCInstance
    from .abc import ABCOpcode
    from .abc import ABCValue

    abcfile = ABCFile()
    abcfile.add_metadata_info(
        SWFMetadataInfo('title', [SWFMetadataItem('k1', 'v1')]))
    abcfile.add_metadata_info(
        SWFMetadataInfo('artist', [SWFMetadataItem('k2', 'v2'),
                                   SWFMetadataItem('k3', 'v3')]))

    constpool = ABCConstantPool

# Generated at 2022-06-24 14:21:47.096735
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()



# Generated at 2022-06-24 14:21:55.761472
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .abc import ABCFile
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCMethod
    from .abc import ABCConstantPool
    from .abc import ABCMetaTag

    pool = ABCConstantPool()
    class_ = ABCClass(pool, 'TestClass')
    inst = ABCInstance(class_)
    method = ABCMethod(inst)
    abc = ABCFile(pool)
    abc.add_class(class_)
    abc.add_instance(inst)
    abc.add_method(method)
    from .abc import I8
    from .abc import I32

    from .abc import OP_add_i
    from .abc import OP_findpropstrict
    from .abc import OP_getproperty
    from .abc import OP_returnvalue

# Generated at 2022-06-24 14:21:59.387813
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open(test_swf_path, 'rb') as f:
        swf = SWF(f)
    swfi = SWFInterpreter(swf)
    class_name = '_level0_mc'
    avm_class = swfi.extract_class(class_name)
    assert avm_class.name == class_name
    assert avm_class.method_names == set(['frame1'])
    assert avm_class.variable_names == set(['_xmouse', '_ymouse'])

# Generated at 2022-06-24 14:22:00.314909
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


# Generated at 2022-06-24 14:22:04.032559
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(0x1234, 'test')
    assert repr(c) == '_AVMClass(test)'
    assert repr(c.variables) == 'test__Scope({})'



# Generated at 2022-06-24 14:22:08.893612
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    well_known_classes = {}

    class HelloClass(object):
        def __init__(self):
            self.flashVars = {'wmode': 'direct'}
        
        def get_url(self, arg_1):
            arg_1 = arg_1.replace('&', '&amp;')
            arg_1 = arg_1.replace('<', '&lt;')
            arg_1 = arg_1.replace('>', '&gt;')
            arg_1 = arg_1.replace('"', '&quot;')
            arg_1 = arg_1.replace("'", '&#39;')
            flashVars = self.flashVars
            flashVars_keys = flashVars.keys()
            flashVars_keys.sort()
            res = []

# Generated at 2022-06-24 14:22:14.001514
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(0, 'ClassName')
    c.register_methods({'m1': 0, 'm2': 1})
    assert c.method_names == {'m1': 0, 'm2': 1}
    assert c.method_idxs == {0: 'm1', 1: 'm2'}



# Generated at 2022-06-24 14:22:17.227549
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    cls = _Multiname(0x11)
    assert cls.__repr__() == '[MULTINAME kind: 0x11]'
# test__Multiname___repr__()



# Generated at 2022-06-24 14:22:19.278684
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    o = _AVMClass_Object(_AVMClass(name='foo'))
    assert repr(o) == 'foo#%x' % id(o)



# Generated at 2022-06-24 14:22:21.182811
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    c = _AVMClass(0, 'foobar')
    assert c.make_object().avm_class is c



# Generated at 2022-06-24 14:22:29.922577
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    methods = {0x8: 'foo'}
    avm_class = _AVMClass(1, 'TestClass', {0x2: 'prop2'})
    avm_class.register_methods(methods)
    obj = avm_class.make_object()

    assert obj.avm_class == avm_class

    assert avm_class.__repr__() == '_AVMClass(TestClass)'

    assert avm_class.variables["test"] == "test"
    avm_class.variables["test"] = "test1"
    assert avm_class.variables["test"] == "test1"

    avm_class.static_properties[0x1] = "prop1"
    assert avm_class.static_properties[0x1] == "prop1"



# Generated at 2022-06-24 14:22:31.787512
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class AVMClass(AVMClass):
        pass
    obj = AVMClass()
    assert repr(obj) == 'AVMClass#%x' % id(obj)



# Generated at 2022-06-24 14:22:33.266036
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass(0, '')
    avm_class.make_object()


# Generated at 2022-06-24 14:22:36.415015
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    import pytest
    class _AVMClass(object):
        def __init__(self, name):
            self.name = name
    for name in ('Py', 'Object'):
        for id in (0x123, 0x456):
            obj = _AVMClass_Object(_AVMClass(name))
            assert repr(obj) == '%s#%x' % (name, id(obj))



# Generated at 2022-06-24 14:22:44.515756
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()

    method_names = []
    for method_name in ['dummy', 'foo', 'bar']:
        method_names.append(compat_str(method_name))
        interpreter.patch_function(method_name)

    assert sorted(interpreter.function_names) == sorted(method_names)
    assert callable(interpreter.dummy)
    assert callable(interpreter.foo)
    assert callable(interpreter.bar)


# Generated at 2022-06-24 14:22:47.323670
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    instance = _AVMClass('name_idx', 'name', 'static_properties')
    assert repr(instance) == "_AVMClass('name')"



# Generated at 2022-06-24 14:22:48.393681
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()) == False

# Generated at 2022-06-24 14:22:50.261314
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    u = _Undefined()
    assert hash(u) == 0

# Generated at 2022-06-24 14:22:51.759138
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert _AVMClass('foo', 1, 2).__repr__() == '_AVMClass(foo)'


# Generated at 2022-06-24 14:22:56.203948
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .avm2 import AVM2
    avm2 = AVM2('/tmp/')
    avm2._classes[1] = _AVMClass(1, 'whatever')
    assert str(avm2._classes[1].make_object()) == 'whatever#<unknown>'


# Generated at 2022-06-24 14:22:57.192059
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(0)
    obj.kind = 2
    assert repr(obj) == '[MULTINAME kind: 2]'

# Generated at 2022-06-24 14:23:02.605891
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    d = _ScopeDict(None)
    d.update({'a': 'b'})
    assert repr(d) == 'None__Scope({\'a\': \'b\'})'
    class A(object):
        pass
    d = _ScopeDict(A())
    d.update({'a': 'b'})
    assert repr(d) == 'A#%x__Scope({\'a\': \'b\'})' % id(A())
# Test end
test__ScopeDict___repr__()



# Generated at 2022-06-24 14:23:11.171059
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf.binary import SWFFile

    # Generate a dummy file with a empty DoABC tag
    class DummyTag(object):
        def __init__(self):
            self.tag_type = 'DoABC'
            self.data = bytes()

    swf = SWFFile.from_fileobj(BytesIO(b'FWS\x04\x00\x00\x00\x00\x05\x00'))
    swf.tags.append(DummyTag())

    m = SWFInterpreter()
    m.multinames = []
    m.tags = swf.tags
    m.abcs = swf.abcs

    # Create a class and a method in it
    avm_class = _AVMClass('Test')
    m.add

# Generated at 2022-06-24 14:23:13.133657
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
_Undefined.instance = _Undefined()



# Generated at 2022-06-24 14:23:15.203360
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert_equal(str(_Multiname(0xff)), '[MULTINAME kind: 0xff]')



# Generated at 2022-06-24 14:23:16.624678
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0)



# Generated at 2022-06-24 14:23:18.882245
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    # Incomplete test; just to check if I didn't miss anything
    assert repr(_Undefined()) == 'undefined'



# Generated at 2022-06-24 14:23:29.823810
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open(os.path.join(TEST_DIR, 'unittests', 'test_SWFInterpreter_test_extract_class.swf'), 'rb') as f:
        interpreter = SWFInterpreter(f)
        avm_class = interpreter.extract_class('test_extract_class.TestClass')
        assert avm_class.static_properties['static_prop_int'] == 42
        assert avm_class.static_properties['static_prop_str'] == 'static string'
        assert isinstance(avm_class.static_properties['static_prop_dict'],
                          _ScopeDict)
        assert avm_class.static_properties['static_prop_func_num'] == 666

# Generated at 2022-06-24 14:23:31.317053
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() == _Undefined()


Undefined = _Undefined()



# Generated at 2022-06-24 14:23:34.508883
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Test extract_class
    obj = SWFInterpreter(b'')
    obj.extract_class(b'\x00\x00\x00\x00\x00\x00\x00\x00',
                      0, b'')

# Generated at 2022-06-24 14:23:38.098691
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == hash(None)
    assert _Undefined() != None

_undefined = _Undefined()

# Generated at 2022-06-24 14:23:39.528476
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    # TODO: assert correctness of method
    pass


# Generated at 2022-06-24 14:23:45.605731
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    def test(obj, expected):
        actual = obj.__repr__()
        assert actual == expected, ('%r != %r' % (actual, expected))
    avm_class = _AVMClass(name='Example')
    obj = _ScopeDict(avm_class)
    test(obj, "Example__Scope({})")
    obj['a'] = 1
    test(obj, "Example__Scope({'a': 1})")
test__ScopeDict___repr__()



# Generated at 2022-06-24 14:23:50.667257
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_interpreter = SWFInterpreter(None)
    with open(os.path.join(TESTS_DATA_PATH,
                           'test-descramblershort.dump')) as f:
        coder = _ABCCoder(f)
        coder.seek(70)
        res = swf_interpreter.extract_function(
            coder, 'descrambleShort', [undefined, undefined])
        assert res(['!$#@@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@']) == 97740675

# Instantiate SWFInterpreter
swf_interpreter = SWFInterpreter(None)


# Generated at 2022-06-24 14:23:52.024226
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) is False



# Generated at 2022-06-24 14:23:54.609138
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter()
    interpreter.extract_class(None, None, None)

# Generated at 2022-06-24 14:24:02.126400
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    data = textwrap.dedent(
        '''\
        function main (arg1) {
            var arg2 = new Object();
            var arg3 = arg1.split(arg2.toString());
        }
        ''').encode('ascii')
    coder = BytesIO(data)
    swf = SWFInterpreter(coder)
    swf.extract_class('Test')
    class_ = swf.constant_classes['Test']
    assert isinstance(class_, _AVMClass)
    assert isinstance(class_.methods['main'], ScriptFunction)

    func = class_.method_pyfunctions['main']
    res = func([None, 'a'])
    assert res is None


# Generated at 2022-06-24 14:24:08.061179
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter('test_extract_class.swf')
    avm_classes = interpreter.extract_class()

    assert len(avm_classes) == 1
    assert avm_classes['test_extract_class.TestClass'].static_properties[
        'testproperty'] == 42
    assert avm_classes['test_extract_class.TestClass'].method_pyfunctions[
        'testmethod']([]) == 'Hello world'


# Generated at 2022-06-24 14:24:12.166100
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass('name', {'prop': 0})
    obj = avm_class.make_object()
    assert isinstance(obj, _AVMClass_Object)
    assert obj.avm_class == avm_class

# Generated at 2022-06-24 14:24:22.899846
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    code = (
        '\x10\x00\x2e\x00\x00\x00\x00\x00\x00\x03\x00\x02\x00\x01\x00\x04'
        '\x0c\x03\x00\x0d\x0a\x4f\x62\x6a\x65\x63\x74\x20\x41\x72\x72\x61'
        '\x79')

    swfi = SWFInterpreter(code=code, file_version=11)
    assert swfi.multinames == [(None, 'public', [0, 'Array'])]
    assert swfi.constant_integers == []
    assert swfi.constant_uints == []
    assert swfi.const

# Generated at 2022-06-24 14:24:24.821298
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x1A)) == '[MULTINAME kind: 0x1a]'



# Generated at 2022-06-24 14:24:29.807548
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = get_test_obj('test1.swf').classes[0].make_object()
    assert obj.avm_class.name == 'Main'
    str(obj.avm_class)
    str(obj)
    assert not obj.avm_class.variables



# Generated at 2022-06-24 14:24:32.400210
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class _AVMClass_ObjectTest(object):
        name = 'testClass'

    test = _AVMClass_Object(_AVMClass_ObjectTest())
    assert test.avm_class.name == 'testClass'
    assert test.__repr__() == 'testClass#%x' % id(test)



# Generated at 2022-06-24 14:24:35.505451
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    a = _Undefined()
    assert not a
    assert not bool(a)
UNDEFINED = _Undefined()



# Generated at 2022-06-24 14:24:41.056023
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert hash(_Undefined()) == 0

    t = _Undefined()
    assert t == t
    assert not (t < t)
    assert not (t > t)

Global = _Undefined()



# Generated at 2022-06-24 14:24:43.910629
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    var0 = ''
    if None:
        var0 = 1
    return (var0,)

# Generated at 2022-06-24 14:24:47.094950
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class _A(object):
        name = 'test_dummy_class'
    object = _A()
    x = _AVMClass_Object(object)
    x.__repr__()



# Generated at 2022-06-24 14:24:51.808109
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avmclass = _AVMClass('ClassName', {})
    assert avmclass.name == 'ClassName'
    assert avmclass.method_names.keys() == []
    assert avmclass.method_idxs.keys() == []
    assert avmclass.methods.keys() == []
    assert avmclass.method_pyfunctions.keys() == []



# Generated at 2022-06-24 14:24:54.694602
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass(1, 2)
    assert repr(obj) == '_AVMClass(2)'


# Generated at 2022-06-24 14:25:00.990545
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_data = read_swf('test/swf/simple.swf')
    interpreter = SWFInterpreter(swf_data, log_as3_errors=False)
    assert 'Foo' in interpreter.extracted_classes
    assert 'Bar' in interpreter.extracted_classes
    assert 'Foo' in interpreter.extracted_classes['Foo'].method_names
    assert 'Bar' in interpreter.extracted_classes['Foo'].method_names
    assert not interpreter.extracted_classes['Foo'].method_names['Bar'].static


# Generated at 2022-06-24 14:25:13.534836
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    avm = SWFInterpreter()
    avm.extract_function(lambda: 1)

# Function to use when a variable is not defined
undefined = _Undefined()

# Built-in classes
ObjectClass = _AVMClass(
    instance_names=[], instance_types=[],
    static_names=[], static_types=[],
)

# Generated at 2022-06-24 14:25:17.804619
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    o = _AVMClass('', '', static_properties={}).make_object()
    assert repr(o) == '_AVMClass()#%x' % (id(o))



# Generated at 2022-06-24 14:25:19.928928
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined() == _Undefined()

Undefined = _Undefined()



# Generated at 2022-06-24 14:25:27.437362
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import os
    import sys

    this_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(os.path.join(this_dir, '..', '..', 'test'))
    from test_swftools import run_as_main

    class SWFInterpreterForTesting(SWFInterpreter):
        def extract_function(self, avm_class, func_name):
            if func_name == 'get_items':
                return SWFInterpreter.extract_function(
                    self, avm_class, func_name)

    @run_as_main(__file__)
    def swf_interpreter_extract_function_main(filename='test.swf'):
        interpreter = SWFInterpreterForTesting()


# Generated at 2022-06-24 14:25:34.423355
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    print('Testing method __repr__ of class _AVMClass')
    # Init
    name_idx = 0
    name = 'name'
    o = _AVMClass(
        name_idx=name_idx,
        name=name,
    )
    # Execute
    ret = repr(o)
    assert ret == '_AVMClass(name)'
    # Return
    return



# Generated at 2022-06-24 14:25:36.301797
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    value = _Undefined()
    assert (value.__hash__() == 0)

# Generated at 2022-06-24 14:25:37.263331
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__(): pass


# Generated at 2022-06-24 14:25:41.622461
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    t = _AVMClass_Object(None)
    assert t.avm_class is None


_AVMClass = collections.namedtuple('_AVMClass', ['name', 'supername', 'fields'])



# Generated at 2022-06-24 14:25:42.662595
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


# Generated at 2022-06-24 14:25:45.436657
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class DummyAVMClass(object):
        def __init__(self):
            self.method_strings = []
            self.method_pyfunctions = []
    assert True

# Generated at 2022-06-24 14:25:50.176002
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_object = _AVMClass_Object(object)
    assert class_object.avm_class is object
    assert repr(class_object) == 'object#%x' % id(class_object)



# Generated at 2022-06-24 14:25:58.072469
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class_ = _AVMClass(1, 'Test')
    assert class_.method_idxs == {}
    assert class_.method_names == {}
    class_.register_methods({'one': 1, 'two': 2})
    assert class_.method_idxs == {1: 'one', 2: 'two'}
    assert class_.method_names == {'one': 1, 'two': 2}
    class_.register_methods({'three': 3, 'four': 4})
    assert class_.method_idxs == {1: 'one', 2: 'two', 3: 'three', 4: 'four'}
    assert class_.method_names == {'one': 1, 'two': 2, 'three': 3, 'four': 4}



# Generated at 2022-06-24 14:26:03.281664
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class Dummy(object):
        name = 'Foo'
    assert repr(_AVMClass_Object(Dummy())) == '%s#%x' % ('Foo', id(_AVMClass_Object(Dummy())))



# Generated at 2022-06-24 14:26:08.879163
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-24 14:26:11.739512
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert _Undefined() is _Undefined()
    assert hash(_Undefined()) == 0

_undef_instance = _Undefined()



# Generated at 2022-06-24 14:26:14.793220
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    m = _AVMClass(0x2000, 'test_class')
    assert m.name == 'test_class'
    assert m.name_idx == 0x2000


# Generated at 2022-06-24 14:26:18.193412
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    o = _AVMClass_Object(None)
    o.avm_class = collections.namedtuple('avm_class', 'name')('MyClass')
    assert o.__repr__() == 'MyClass#%x' % id(o)
test__AVMClass_Object___repr__()



# Generated at 2022-06-24 14:26:20.805361
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    the_undefined = _Undefined()
    assert dict([(the_undefined, 'value')]) == {}


# Generated at 2022-06-24 14:26:23.204872
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    _Multiname(1).__repr__() == '[MULTINAME kind: 0x1]'

# Generated at 2022-06-24 14:26:27.647265
# Unit test for constructor of class _Undefined
def test__Undefined():
    Undefined = _Undefined()
    assert Undefined is Undefined
    assert Undefined is _Undefined()
test__Undefined()

BuiltinVals = {
    StringClass.name: '',
    ByteArrayClass.name: b'',
    'undefined': _Undefined(),
}



# Generated at 2022-06-24 14:26:35.678644
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():

    class _AVMClass_Object(object):
        def __init__(self, avm_class):
            self.avm_class = avm_class

        def __repr__(self):
            return '%s#%x' % (self.avm_class.name, id(self))

    class _ScopeDict(dict):
        def __init__(self, avm_class):
            super(_ScopeDict, self).__init__()
            self.avm_class = avm_class

        def __repr__(self):
            return '%s__Scope(%s)' % (
                self.avm_class.name,
                super(_ScopeDict, self).__repr__())


# Generated at 2022-06-24 14:26:39.990718
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    u = _Undefined()
    assert hash(u) == 0, repr(hash(u))
    assert u.__hash__() == 0, repr(u.__hash__())
_Undefined = _Undefined()

# Generated at 2022-06-24 14:26:48.070151
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert '%r' % _Multiname(0x07) == '[MULTINAME kind: 0x7]'

_Multiname.QName = 0x01
_Multiname.QNameA = 0x02
_Multiname.RTQName = 0x0f
_Multiname.RTQNameA = 0x10
_Multiname.RTQNameL = 0x11
_Multiname.RTQNameLA = 0x12
_Multiname.Multiname = 0x09
_Multiname.MultinameA = 0x0e
_Multiname.MultinameL = 0x1b
_Multiname.MultinameLA = 0x1c



# Generated at 2022-06-24 14:26:52.111982
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    scope = _ScopeDict(_AVMClass_Object(None))
    scope['foo'] = 'bar'
    assert scope.__repr__() == '_AVMClass_Object__Scope({' \
                               '\'foo\': \'bar\'})'



# Generated at 2022-06-24 14:26:56.583159
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    test_class = _AVMClass(1, "TestClass")
    assert test_class.name_idx == 1
    assert test_class.name == "TestClass"
    # Check the default static properties
    assert test_class.static_properties == {}
    assert test_class.method_names == {}
    assert test_class.method_idxs == {}
    assert test_class.methods == {}
    assert test_class.method_pyfunctions == {}
    assert test_class.variables == {}
    assert test_class.constants == {}



# Generated at 2022-06-24 14:27:05.001969
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .action_class import ActionClass
    from .builtin import print_
    from .multiname_class import MultinameClass
    from .scope_class import ScopeClass
    from .swf_interpreter import SWFInterpreter
    from .undefined_class import UndefinedClass

    swf_interpreter = SWFInterpreter(None)

    scope_class = ScopeClass(UndefinedClass)
    scope_class.method_pyfunctions['print'] = print_

    action_class = ActionClass()
    action_class.variables['_global'] = scope_class
    action_class.static_properties['_global'] = scope_class

    print_multiname = MultinameClass('print')
    action_class.method_pyfunctions[print_multiname] = print_
    action_

# Generated at 2022-06-24 14:27:05.997129
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    _ScopeDict(_AVMClass_Object(_AVMClass('name')))



# Generated at 2022-06-24 14:27:15.640149
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import re


# Generated at 2022-06-24 14:27:25.201305
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    filename = os.path.join(os.path.dirname(__file__), 'test.swf')
    filename = os.path.abspath(filename)
    interp = SWFInterpreter(filename)
    class_name = 'test'
    swf_class = interp.extract_class(class_name)

    assert isinstance(swf_class, _AVMClass)
    assert swf_class.name == class_name
    assert swf_class.method_pyfunctions['testMethod']() == 'testMethod'



# Generated at 2022-06-24 14:27:27.437178
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class A(object):
        name = 'A'
    assert repr(_AVMClass_Object(A)) == 'A#%x' % id(_AVMClass_Object(A))



# Generated at 2022-06-24 14:27:29.454609
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(42)) == '[MULTINAME kind: 0x2a]'



# Generated at 2022-06-24 14:27:32.813018
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .utils import make_object # @UnresolvedImport
    assert repr(make_object(None, None))=='None#0x10'


# Generated at 2022-06-24 14:27:35.361275
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    method = _AVMClass._AVMClass__repr__
    method(None)
    assert False

# Generated at 2022-06-24 14:27:40.293043
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    # swfdec_test_swfdec_script_object_register_methods
    avm_class = _AVMClass('test1', 'test2')
    avm_class.register_methods({'a': 1, 'b': 2})
    assert avm_class.method_names == {'a': 1, 'b': 2}, (
        'Expected {"a": 1, "b": 2}, got %r' % avm_class.method_names)
    assert avm_class.method_idxs == {1: 'a', 2: 'b'}, (
        'Expected {1: "a", 2: "b"}, got %r' % avm_class.method_idxs)



# Generated at 2022-06-24 14:27:41.251173
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'

# Generated at 2022-06-24 14:27:52.503391
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from .test_swfdecomp import fake_swf
    from .utils import FakeFile

    swf = FakeFile(fake_swf.files['simple.swf'])
    swf.seek(8)
    avm2 = AVM2(swf)
    avm2._abc_read_tag(None, None)
    scripts = avm2.abc_scripts

    def testfunc(self_obj, *args):
        return (self_obj.prop, args)

    # TODO: Should there be an easier way to generate a fake _AVMClass?
    # Maybe just hack one up in memory?
    class_def = _AVMClass(7, 'TestClass')
    class_def.methods = {7: testfunc}
    scripts[0].classes = [class_def]
    class_inst

# Generated at 2022-06-24 14:27:54.187846
# Unit test for constructor of class _Multiname
def test__Multiname():
    m = _Multiname(0x07)
    assert (m.kind == 0x07)



# Generated at 2022-06-24 14:27:56.106792
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    _AVMClass = _AVMClass(0, 'test')
    assert repr(_AVMClass) == '_AVMClass(test)'



# Generated at 2022-06-24 14:27:57.404329
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'

_undefined = _Undefined()



# Generated at 2022-06-24 14:28:00.527480
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(kind=1)) == '[MULTINAME kind: 0x1]'
    assert repr(_Multiname(kind=2)) == '[MULTINAME kind: 0x2]'
    assert repr(_Multiname(kind=123)) == '[MULTINAME kind: 0x7b]'



# Generated at 2022-06-24 14:28:12.387447
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter()

    swf._payload = compat_bytes(
        b'\xbf\x00\x06'  # Class: private, index=6
        b'\x00\x00\x00'  # Constructor
        b'\x00\x01\x00'
        b'\x20\x00\x00'
        b'\x00\x00\x00'
        b'\x00\x00\x00'
        b'\x00\x00\x00'
    )
    coder = io.BytesIO(swf._payload)
    res = swf.extract_class(coder)
    assert res.class_name == 'Class6'
    assert res.index == 6
    assert res.instances is None  #

# Generated at 2022-06-24 14:28:19.461491
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class Foo(object):
        name = 'Foo'
    foo = Foo()
    d = _ScopeDict(foo)
    assert repr(d) == 'Foo__Scope({})'
    d['foo'] = 'bar'
    assert repr(d) == 'Foo__Scope({\'foo\': \'bar\'})'
    d[1] = 2
    assert repr(d) == 'Foo__Scope({\'foo\': \'bar\', 1: 2})'



# Generated at 2022-06-24 14:28:30.459420
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test = SWFInterpreter()

    # Test integer data parsing
    assert test._read_integer(b'\x40\x00\x00\x00') == 64
    assert test._read_integer(b'\x40\x00\x00\x00', bigendian=False) == 64

    # Test float data parsing
    assert test._read_float(b'\x00\x00\x00\x00') == 0.0
    assert test._read_float(b'\xC0\x00\x00\x00') == -2.0
    assert test._read_float(b'\x3F\x80\x00\x00') == 1.0
    assert test._read_float(b'\x7F\x80\x00\x00') == 2.0

   

# Generated at 2022-06-24 14:28:40.181094
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class_ = _AVMClass('name', 'name')
    assert class_.method_names == {}
    assert class_.method_idxs == {}
    class_ = _AVMClass('name', 'name')
    class_.method_names = {'method1': 1, 'method2': 2}
    class_.method_idxs = {1: 'method1', 2: 'method2'}
    class_.register_methods({'method3': 3, 'method4': 4})
    assert class_.method_names == {'method1': 1, 'method2': 2, 'method3': 3, 'method4': 4}
    assert class_.method_idxs == {1: 'method1', 2: 'method2', 3: 'method3', 4: 'method4'}



# Generated at 2022-06-24 14:28:46.518082
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    def test_helper(function, name, case_input, expected, expected_traceback):
        actual_value, actual_traceback = None, None
        try:
            actual_value = function(**case_input)
        except Exception as actual_traceback:
            pass
        try:
            assert actual_value == expected and actual_traceback == expected_traceback
        except AssertionError as e:
            print('%s(**%s) -> %s, but expected: %s' % (name, case_input, actual_value, expected))
            if expected_traceback:
                print('Traceback:')
                for line in str(actual_traceback).split('\n'):
                    print('    ' + line)
            raise e


# Generated at 2022-06-24 14:28:49.984858
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() == _Undefined()
    assert not _Undefined()
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'

_undefined = _Undefined()



# Generated at 2022-06-24 14:28:53.484068
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm = _AVMClass(1, 'test', {'static': 10})
    assert avm.name_idx == 1
    assert avm.name == 'test'
    assert avm.static_properties == {'static': 10}



# Generated at 2022-06-24 14:28:57.684557
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    avm_class = DummyClass(name='Test')
    scope = _ScopeDict(avm_class)
    scope['a'] = 1

# Generated at 2022-06-24 14:29:01.119147
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass('_AVMClass', '_AVMClass')
    obj = avm_class.make_object()
    assert obj.avm_class == avm_class



# Generated at 2022-06-24 14:29:03.727579
# Unit test for constructor of class _Multiname
def test__Multiname():
    from .pyamf import register_class
    register_class(_Multiname, 'flash.utils.Dictionary')



# Generated at 2022-06-24 14:29:12.391340
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass(1, 'Test', {1: 'a'})
    assert cls.name_idx == 1
    assert cls.name == 'Test'
    assert cls.method_names == {}
    assert cls.method_idxs == {}
    assert cls.methods == {}
    assert cls.method_pyfunctions == {}
    assert cls.static_properties == {1: 'a'}
    assert cls.variables == _ScopeDict(cls)
    assert cls.constants == {}
    assert cls.make_object().avm_class is cls



# Generated at 2022-06-24 14:29:14.268394
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    m = _Multiname(0x30)
    assert repr(m) == '[MULTINAME kind: 0x30]'

# Generated at 2022-06-24 14:29:16.511394
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    a = _AVMClass('a', {})
    a_ = a.make_object()
    assert a_ is not None
    assert a_.avm_class is a

# Generated at 2022-06-24 14:29:28.748643
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    def unpack_uint32(b):
        return struct.unpack('>I', b[:4])[0]

    def unpack_uint16(b):
        return struct.unpack('>H', b[:2])[0]

    # Extract tag data length and code from a raw tag
    # The code is given as a tuple (code_id, code_obj)
    # where code_obj is like a string for a normal tag,
    # or a SWFObject for the FileAttributes tag
    def extract_tag_code(tag):
        assert tag[0] == b'\x3F'[0]
        tag_len = unpack_uint32(tag[1:])
        tag_code = unpack_uint16(tag[5:])
        return tag_len, tag_code

    # Extract the contents

# Generated at 2022-06-24 14:29:31.206578
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    assert_raises(NotImplementedError, lambda: _AVMClass._AVMClass_make_object.im_func(1, 1))

# Generated at 2022-06-24 14:29:35.918363
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    # Testing with _AVMClass
    #    >>> _AVMClass(name_idx=None, name='', static_properties=None)
    #    _AVMClass('')
    pass # when run directly, this would print out the class's docstring



# Generated at 2022-06-24 14:29:42.349379
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interp = SWFInterpreter()

    resfunc = interp.patch_function(None, ['abc', 'def'], 0)
    assert resfunc(None) == ['abc', 'def']

    resfunc = interp.patch_function(None, ['abc', 'def'], 1)
    assert resfunc(None) == 'abc'

    resfunc = interp.patch_function(None, ['abc', 'def'], 2)
    assert resfunc(None) == 'def'

    resfunc = interp.patch_function(None, ['abc', 'def'], 3)
    assert resfunc(None) is undefined

# Define global variables for unit tests

# Generated at 2022-06-24 14:29:47.129980
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class _AVMClass(object):
        name = '_AVMClass'
    obj = _AVMClass_Object(_AVMClass)
    assert obj.avm_class == _AVMClass
    assert repr(obj) == '_AVMClass#%x' % id(obj)



# Generated at 2022-06-24 14:29:48.615381
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    # TODO
    pass

    # verify that the method register_methods of class _AVMClass
    #  raises NotImplementedError
    # TODO
    pass


# Generated at 2022-06-24 14:29:51.635752
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class_ = _AVMClass_Object(None).avm_class = _AVMClass('name')
    assert repr(_AVMClass_Object(class_)) == 'name#1e47f4d0'



# Generated at 2022-06-24 14:29:58.710478
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interp = SWFInterpreter()
    classobj = interp.extract_class(None, 'Number', 'NumberClass')
    assert classobj._full_name == 'NumberClass'
    classobj2 = interp.extract_class(None, 'NumberClass', 'NumberClass2')
    assert classobj2._full_name == 'NumberClass2'
    classobj3 = interp.extract_class(None, 'Object', 'ObjectClass')
    assert classobj3._full_name == 'ObjectClass'
    assert classobj3.superclass == interp.builtin_class_objects['Object']
    classobj4 = interp.extract_class(None, classobj3, 'ObjectClass2')
    assert classobj4.superclass == classobj3
    classobj4b = interp.extract_class

# Generated at 2022-06-24 14:30:00.613979
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert _AVMClass(name_idx=0x0, name=b'', static_properties=None).__repr__() == "_AVMClass(b'')"

# Generated at 2022-06-24 14:30:07.744814
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass(None, 'Test')
    cls.register_methods({
        'foo': 0,
        'bar': 1,
    })
    assert cls.method_names == {'foo': 0, 'bar': 1}
    assert cls.method_idxs == {0: 'foo', 1: 'bar'}
    assert cls.variables == {}



# Generated at 2022-06-24 14:30:11.543047
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == 'undefined'
    assert str(_Undefined()) == 'undefined'
    assert _Undefined() == _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:30:13.270224
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == 'undefined'



# Generated at 2022-06-24 14:30:26.204674
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    res = SWFInterpreter.extract_class(
        _SWFClasses_flash_net_URLStream().AVM2Class)

# Generated at 2022-06-24 14:30:28.497563
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    obj = _Undefined()
    expected_res = 'undefined'
    res = obj.__repr__()
    assert res == expected_res




# Generated at 2022-06-24 14:30:32.082969
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert _AVMClass_Object(AVMClass('flash.display.Sprite')).__repr__() == 'flash.display.Sprite#%x' % id(_AVMClass_Object(AVMClass('flash.display.Sprite')))



# Generated at 2022-06-24 14:30:34.725670
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class C(object):
        pass
    c = C()
    s = _ScopeDict(c)
    assert s.avm_class is c



# Generated at 2022-06-24 14:30:44.464520
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():

    class Mock_AVMClass(object):
        def __init__(self, name_idx, name, static_properties=None):
            self.name_idx = name_idx
            self.name = name
            self.method_names = {}
            self.method_idxs = {}
            self.methods = {}
            self.method_pyfunctions = {}
            self.static_properties = static_properties if static_properties else {}
            self.variables = _ScopeDict(self)
            self.constants = {}

    name_idx = MagicMock()
    name = MagicMock()
    static_properties = MagicMock()
    static_properties = MagicMock()
    static_properties = MagicMock()
    static_properties = MagicMock()
    static_properties = MagicMock()


# Generated at 2022-06-24 14:30:52.468076
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    # NOTE: class Methods must be defined in global namespace for
    # _AVMClass.make_method_pyfunction() to work
    class Methods(object):
        def test(self, a, b, c=1, d=2):
            return a + b + c + d
    m = _AVMClass('Test', Methods)
    from .external import unittest
    test_case = unittest.FunctionTestCase(m.__repr__)
    test_case()



# Generated at 2022-06-24 14:30:55.402936
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    o = _Undefined()
    if o:
        raise AssertionError('o is not expected to be True')

# Generated at 2022-06-24 14:30:57.270909
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == hash(0)

# Generated at 2022-06-24 14:31:02.582851
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .swfdecompiler import swfdecompiler
    class_ = swfdecompiler._AVMClass('TestClass', 1, None)
    obj = class_.make_object()
    assert obj.avm_class == class_
    assert repr(obj) == 'TestClass#0x%x' % id(obj)



# Generated at 2022-06-24 14:31:04.022889
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:31:09.082470
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    clazz = _AVMClass('Foo', 'Foo')
    clazz.register_methods({
        'func1': 1,
        'func2': 2,
    })
    assert clazz.method_names == {'func1': 1, 'func2': 2}
    assert clazz.method_idxs == {2: 'func2', 1: 'func1'}



# Generated at 2022-06-24 14:31:19.648485
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    avm = SWFInterpreter(SWF(open(os.path.join(
            os.path.dirname(__file__), 'Test.swf'), 'rb')))
    assert avm.get_class_name(0) == 'Main'
    assert avm.get_class_name('Main') == 'Main'
    assert avm.get_static_property('Main', 'trace', True) == [
        'Main::Main()', 'Main::a', 'Main::b']
    assert avm.get_static_property('Main', 'CONSTANT', True) == 'CONSTANT'
    assert avm.get_static_property('Main', '_CONSTANT', True) == 0
    assert avm.get_static_property('Main', 'name', True) == 'Main'