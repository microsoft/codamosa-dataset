

# Generated at 2022-06-24 14:21:23.390911
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = _AVMClass('foo.Bar', 'Bar').make_object()
    assert repr(obj) == 'foo.Bar#' + hex(id(obj)).rstrip('L')



# Generated at 2022-06-24 14:21:30.302117
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .compat import compat_str
    from .utils import (
        _TestScopeDict_avm_class,
        _TestScopeDict_super__ScopeDict___repr__,
    )
    scope_dict = _ScopeDict(_TestScopeDict_avm_class)
    result = scope_dict.__repr__()
    expected = compat_str(_TestScopeDict_super__ScopeDict___repr__)
    assert result == expected
test__ScopeDict___repr__()



# Generated at 2022-06-24 14:21:31.923832
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x0b)) == '[MULTINAME kind: 0x0b]'



# Generated at 2022-06-24 14:21:39.858029
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    x = _AVMClass('a', 'b', {'c': 'd'})
    assert x.name_idx == 'a'
    assert x.name == 'b'
    assert x.static_properties == {'c': 'd'}
    assert x.method_names == {}
    assert x.method_idxs == {}
    assert x.methods == {}
    assert x.method_pyfunctions == {}
    assert x.variables == _ScopeDict(x)
    assert x.constants == {}


# TODO: Add unit tests for this class

# Generated at 2022-06-24 14:21:40.789493
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()



# Generated at 2022-06-24 14:21:42.791836
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class Foo:
        name = 'Foo'
    o = _ScopeDict(Foo())
    o['foo'] = 'bar'
    assert o.__repr__() == 'Foo__Scope(dict(foo=bar))'



# Generated at 2022-06-24 14:21:45.947445
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .avm2 import AVMFile
    avmf = AVMFile()
    avmf.extract_script(compat_str(__file__))
    avmf.classes['_ScopeDict'].__repr__()

# Generated at 2022-06-24 14:21:47.206377
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    a = SWFInterpreter()
    a.extract_function('Class', 'method')

# Generated at 2022-06-24 14:21:50.717699
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not bool(_Undefined())

    assert 0 == hash(_Undefined())

    assert 'undefined' == str(_Undefined())
    assert 'undefined' == repr(_Undefined())

Undefined = _Undefined()



# Generated at 2022-06-24 14:21:54.966342
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    constant_pool = {}
    avm3_swf_tag = _AVMClass(
        name_idx=1, name="avm3_swf_tag", static_properties={
            'ScriptTimeout': 10,
        })
    avm3_swf_tag.methods = {}
    return avm3_swf_tag



# Generated at 2022-06-24 14:21:55.701680
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


_undefined = _Undefined()



# Generated at 2022-06-24 14:22:00.754313
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import AVM2File
    from .swf import AVM2Class
    from .swf import ABCFile
    from .swf import SWF

    with open('tests/files/1.swf', 'rb') as f:
        swf = SWF(f)
        assert swf.version == 18
        assert len(swf.tags.tags) == 5
        assert isinstance(swf.tags.tags[1], AVM2File)

        avm2 = swf.tags.tags[1]
        assert len(avm2.tags) == 4
        assert isinstance(avm2.tags[0], ABCFile)

        abc = avm2.tags[0]
        assert len(abc.classes) == 1

# Generated at 2022-06-24 14:22:03.746715
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    rc = _ScopeDict('this is a test').__repr__()
    assert rc == 'this is a test__Scope({})', rc



# Generated at 2022-06-24 14:22:08.636218
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    from avsparser import AVSMapParser
    from hachoir_core.tools import makePrintable
    from hachoir_core.error import HachoirError

    def ensure_str(s):
        if s is undefined:
            return None
        elif isinstance(s, compat_str):
            return s
        elif isinstance(s, _AVMClass_Object):
            return s.__repr__()
        elif isinstance(s, list):
            return '[%s]' % ','.join([ensure_str(x) for x in s])
        else:
            return str(s)

    def assert_all(obj, **kwargs):
        for k, v in kwargs.items():
            if v is None:
                v = undefined

# Generated at 2022-06-24 14:22:09.893497
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    print(repr(_AVMClass_Object('AVMClass')))
    # _AVMClass_Object#434103760



# Generated at 2022-06-24 14:22:20.364912
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_tags import DoABCDefineTag

# Generated at 2022-06-24 14:22:23.981463
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass('example',
                          ['example', 'Example'],
                          {'foo': 42})
    assert avm_class.name_idx == 'example'
    assert avm_class.name == 'Example'
    assert avm_class.static_properties == {'foo': 42}



# Generated at 2022-06-24 14:22:30.023322
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from ykdl.swfinterp.swfparser import SWFParser
    from ykdl.util.html import get_content
    from ykdl.util.match import match1
    swf_url = 'http://tv.sohu.com/upload/swf/20160621/Main.swf?2015'
    filename = 'Main.swf'
    url = "http://hot.vrs.sohu.com/ipad205641_4637131764891_6248470.m3u8"
    swf = get_content(swf_url, headers={'Referer': url})
    swfparser = SWFParser(swf)
    swfparser.parse()
    interp = SWFInterpreter(swfparser)

# Generated at 2022-06-24 14:22:32.909141
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class TestClass(object):
        def __init__(self, name):
            self.name = name
    assert repr(_AVMClass_Object(TestClass('test class'))) == 'test class#%x' % id(_AVMClass_Object)



# Generated at 2022-06-24 14:22:33.921222
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-24 14:22:35.815517
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


Undefined = _Undefined()

# Generated at 2022-06-24 14:22:48.066418
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-24 14:22:50.366493
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    instance = _AVMClass('name_idx', 'name', 'static_properties')



# Generated at 2022-06-24 14:22:51.992197
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert '__Scope(%r)' % {'a': 1}.__repr__() == '__Scope({\'a\': 1})' # noqa: E501



# Generated at 2022-06-24 14:22:53.752111
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    v = _Undefined()
    assert (not v) is True
Undefined = _Undefined()



# Generated at 2022-06-24 14:22:59.430355
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    inst = _AVMClass(name_idx=1, name='test_AVMClass')
    inst.register_methods({
        'test': 1,
        'test2': 2
    })
    assert inst.method_names['test'] == 1
    assert inst.method_names['test2'] == 2
    assert inst.method_idxs[1] == 'test'
    assert inst.method_idxs[2] == 'test2'



# Generated at 2022-06-24 14:23:00.988884
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    obj = _ScopeDict(None)
    assert obj.__repr__() is not None



# Generated at 2022-06-24 14:23:02.246541
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

Undefined = _Undefined()
Null = None



# Generated at 2022-06-24 14:23:03.926918
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert repr(_ScopeDict(object())) == 'object__Scope({})'
test__ScopeDict()



# Generated at 2022-06-24 14:23:09.260882
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class_name = 'ClassName'
    class_attrs = {
        'version': 11,
        'method_names': {},
        'static_properties': {},
        'instance_properties': {},
    }
    class_data = {
        'class_name': class_name,
        'class_attrs': class_attrs,
    }
    interpreter = SWFInterpreter(extract_class(class_data))
    assert interpreter.version == 11
    assert interpreter.method_names == set([])
    assert interpreter.variables == {}


# Generated at 2022-06-24 14:23:15.769774
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(0, 'SomeClass')
    avm_class.register_methods({
        'method1': 0x1f,
        'method2': 0x20,
    })
    assert len(avm_class.method_names) == 2
    assert len(avm_class.method_idxs) == 2
    assert avm_class.method_names['method1'] == 0x1f
    assert avm_class.method_names['method2'] == 0x20
    assert avm_class.method_idxs[0x1f] == 'method1'
    assert avm_class.method_idxs[0x20] == 'method2'



# Generated at 2022-06-24 14:23:21.044835
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_obj = _AVMClass_Object(None)
    assert class_obj.avm_class is None
    assert repr(class_obj) == 'None#%x' % id(class_obj)


# See Section 3.2.4 of adobe-flash/amf0-file-format-specification.pdf

# Generated at 2022-06-24 14:23:24.277652
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    u = _Undefined()
    assert u == _Undefined()
    assert u != None
    assert not u


_undefined = _Undefined()



# Generated at 2022-06-24 14:23:25.745409
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    print(_Multiname(0x1d))


# Generated at 2022-06-24 14:23:29.213246
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    import doctest
    from .extractor import _AVMClass
    failure_count, test_count = doctest.testmod(
        _AVMClass, optionflags=doctest.REPORT_ONLY_FIRST_FAILURE)
    assert test_count > 0, 'No tests found.'
    assert failure_count == 0, '{} failures'.format(failure_count)

# Generated at 2022-06-24 14:23:31.734405
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    # __Undefined___repr__ is a method
    assert callable(Undefined.__repr__)
Undefined = _Undefined()



# Generated at 2022-06-24 14:23:40.097537
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import pyamf
    import pyamf.remoting.client

    client = pyamf.remoting.client.RemotingService('http://coub.com/api/swf/amf')
    g = client.gateway
    x = g.loadCoub('http://coub.com/view/21mzf')
    swf_interpreter = SWFInterpreter(x['body'])

    res = swf_interpreter.interpret_function(
        'avm2.domain:SystemDomain', 'getDefinitionByName', ['coub.com.flash.api.v1.domain::CoubDomain'])
    assert res == 'coub.com.flash.api.v1.domain.CoubDomain'


# Generated at 2022-06-24 14:23:42.193485
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    a = _AVMClass(None, 'a')
    assert a.__repr__() == '_AVMClass(a)'

# Generated at 2022-06-24 14:23:44.262898
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    v = _Multiname(0)
    assert str(v) == '[MULTINAME kind: 0x0]'



# Generated at 2022-06-24 14:23:47.135637
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass('classname', 'classname')
    assert repr(avm_class.make_object()) == 'classname#%x' % id(avm_class.make_object())



# Generated at 2022-06-24 14:23:56.749058
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cl = _AVMClass(0, 'cl')
    assert cl.name_idx == 0
    assert cl.name == 'cl'
    assert cl.method_names == {}
    assert cl.method_idxs == {}
    assert cl.methods == {}
    assert cl.method_pyfunctions == {}
    assert cl.static_properties == {}
    assert cl.variables == {
        'avm_class': cl,
        'avm_class_name': 'cl',
    }
    assert isinstance(cl.variables, _ScopeDict)
    assert cl.constants == {}


# Generated at 2022-06-24 14:23:59.429175
# Unit test for constructor of class _Undefined
def test__Undefined():
    # In python2, undefined is not an object
    if hasattr(_Undefined(), '__nonzero__'):  # pragma: no cover
        assert not _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:24:01.158262
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    c = _AVMClass(0, 'TestClass')
    o = c.make_object()
    assert o.avm_class == c



# Generated at 2022-06-24 14:24:02.725947
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
    assert hash(object()) != 0


# Generated at 2022-06-24 14:24:04.581318
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert str(_Undefined()) == 'undefined'


_undefined = _Undefined()



# Generated at 2022-06-24 14:24:05.809030
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    u = _Undefined()
    assert not u


# Generated at 2022-06-24 14:24:07.007404
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x0B).kind == 0x0B



# Generated at 2022-06-24 14:24:12.316367
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    name_idx = 0
    name = 'MovieClip'
    static_properties = {'a': int}
    obj = _AVMClass(name_idx, name, static_properties)
    obj.register_methods({'nextFrame': 0, 'gotoAndPlay': 1})
    assert repr(obj) == "_AVMClass('MovieClip')"



# Generated at 2022-06-24 14:24:14.344408
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    inst = _AVMClass_Object(None)
    assert isinstance(inst.__repr__(), compat_str)



# Generated at 2022-06-24 14:24:20.932581
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    kwargs1 = {
        'static_properties': {},
        'name': 'foo',
    }
    kwargs2 = {
        'static_properties': {},
        'name': 'foobar',
    }
    item1 = _AVMClass(kwargs2, 24)
    item2 = _AVMClass(kwargs1, 35)
    # attribute 'name' of class _AVMClass is writable
    item2.name = 'baz'
    item3 = _AVMClass(kwargs2, 1)
    item3.name = 'baz'
    assert repr(item1) == '_AVMClass(foobar)'
    assert repr(item2) == '_AVMClass(baz)'
    assert repr(item3) == '_AVMClass(foobar)'



# Generated at 2022-06-24 14:24:25.839682
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class AVMClass(object):
        def __init__(self, name):
            self.name = name
    obj = _AVMClass_Object(AVMClass('a'))
    print(obj.__repr__())



# Generated at 2022-06-24 14:24:29.664733
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    x = _AVMClass_Object(AVMClass('TestClass', {}, {'toString': lambda s: '%s_toString' % s}))
    assert repr(x) == 'TestClass#%x' % id(x)


# Generated at 2022-06-24 14:24:32.855619
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    v = _Undefined()
    assert repr(v) == 'undefined'
    assert str(v) == 'undefined'

Undefined = _Undefined()



# Generated at 2022-06-24 14:24:34.626587
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    assert True



# Generated at 2022-06-24 14:24:38.003751
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():

    m = _Multiname(0x07)

    assert repr(m) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:24:47.875718
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass(0, 'Foo')
    assert class_.name_idx == 0
    assert class_.name == 'Foo'
    assert class_.static_properties == {}
    assert class_.method_names == {}
    assert class_.method_idxs == {}
    assert class_.methods == {}
    assert class_.constants == {}
    assert class_.variables == {}
    object_ = class_.make_object()
    assert isinstance(object_, _AVMClass_Object)
    assert object_.avm_class == class_
    assert repr(class_) == '_AVMClass(Foo)'
    assert repr(object_) == 'Foo#%x' % id(object_)



# Generated at 2022-06-24 14:24:50.990791
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    avm_class_Test = _AVMClass(None, 'Test')
    test_obj1 = _AVMClass_Object(avm_class_Test)
    test_obj2 = _AVMClass_Object(avm_class_Test)
    assert 'Test#%x' % id(test_obj1) == repr(test_obj1)
    assert 'Test#%x' % id(test_obj2) == repr(test_obj2)



# Generated at 2022-06-24 14:24:58.420346
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .tag import DoAbcDefTag
    from .abc import ABCFile
    from .swf import SWF
    from .swf.abc.code_stream import ABCCodeStream
    from .swf.abc.opcode import ABCOpcode

    def make_abc_tag():
        abc_tag = DoAbcDefTag()
        abc_tag.abc = ABCFile()
        abc_tag.abc.major = 52
        return abc_tag

    def make_abc_code(opcodes):
        abc_code = ABCCodeStream()
        abc_code.opcodes = opcodes
        return abc_code

    res = SWFInterpreter(SWF(make_abc_tag()))

# Generated at 2022-06-24 14:25:11.292516
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    assert _AVMClass(0, 'Foo').name_idx == 0
    assert _AVMClass(0, 'Foo').name == 'Foo'
    assert _AVMClass(0, 'Foo').method_names == {}
    assert _AVMClass(0, 'Foo').method_idxs == {}
    assert _AVMClass(0, 'Foo').methods == {}
    assert _AVMClass(0, 'Foo').method_pyfunctions == {}
    assert _AVMClass(0, 'Foo').static_properties == {}
    assert _AVMClass(
        0, 'Foo', static_properties={'foo': 42}).static_properties['foo'] == 42
    assert _AVMClass(0, 'Foo').variables == {}

# Generated at 2022-06-24 14:25:14.592665
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(0)
    assert obj.__repr__() == '[MULTINAME kind: 0x0]', \
        'Unexpected result for _Multiname.__repr__()'



# Generated at 2022-06-24 14:25:24.329591
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(0, 'foo')

    assert avm_class.name_idx == 0
    assert avm_class.name == 'foo'
    assert avm_class.static_properties == {}
    assert avm_class.method_names == {}
    assert avm_class.method_idxs == {}
    assert avm_class.methods == {}
    assert avm_class.method_pyfunctions == {}

    assert avm_class.variables == {
        'avm_class': avm_class,
    }
    assert avm_class.constants == {}



# Generated at 2022-06-24 14:25:33.782071
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class _TestDict(dict):
        def __repr__(self):
            return '--%d--' % super(_TestDict, self).__repr__()
    class _TestClass(object):
        name = '_TestClass'
    o = _ScopeDict(_TestClass())
    o.update({
        'abc': _AVMClass_Object(_TestClass()),
        'def': _TestDict({'foo': 1, 'bar': 2}),
        'ghi': [1, 2, 3],
    })
    return repr(o)


# Generated at 2022-06-24 14:25:37.336548
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swfinterpreter = SWFInterpreter(StringIO(b''), get_logger('test'))
    res = swfinterpreter.extract_function(None, None)
    assert res is None



# Generated at 2022-06-24 14:25:39.478976
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    _AVMClass_Object({'name': 'Test', 'method_names': []})



# Generated at 2022-06-24 14:25:41.113635
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class _AVMClass(object):
        def __init__(self, name):
            self.name = name
    assert repr(_AVMClass_Object(_AVMClass('TestClass'))) == 'TestClass#%x' % (hash('TestClass') & 0xffffffff)



# Generated at 2022-06-24 14:25:45.724565
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    avm_class = _AVMClass({
        'a': 1,
        'f': lambda x: x,
        'cls_const1': 1,
        'cls_const2': 2,
        'cls_const3': 3,
        'x': None,
    })

# Generated at 2022-06-24 14:25:49.246050
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class C(object):
        pass
    assert 'C#' in repr(_AVMClass_Object(C))



# Generated at 2022-06-24 14:25:55.642645
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    input_ins  = [(1, 'a'),
                  (2, 'b'),
                  (3, 'c'),
                  (4, 'd')]
    input_dict = dict(input_ins)

    _AVMClass.register_methods.__dict__.update(_AVMClass.method_names.__dict__)
    _AVMClass.register_methods.__dict__.update(_AVMClass.method_idxs.__dict__)

    c = _AVMClass('a', 'b')

    c.register_methods(input_dict)

    assert c.method_names == dict(input_ins)
    assert c.method_idxs == dict(
        (idx, name)
        for (name, idx) in input_ins)



# Generated at 2022-06-24 14:25:57.737561
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    return (hash(_Undefined()) == 0)

_undefined = _Undefined()



# Generated at 2022-06-24 14:26:01.046693
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    x = _AVMClass_Object(_AVMClass_Object)
    assert x.avm_class is _AVMClass_Object



# Generated at 2022-06-24 14:26:04.657902
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert repr(_AVMClass_Object(_AVMClass('foo'))) == 'foo#0x%x' % id(None)
test__AVMClass_Object___repr__()



# Generated at 2022-06-24 14:26:07.385068
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    obj = _Undefined()
    assert obj.__repr__() == 'undefined'  # PASSED

# Generated at 2022-06-24 14:26:09.107807
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()

_undefined = _Undefined()



# Generated at 2022-06-24 14:26:18.893511
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    avm_class = _AVMClass_Object()
    avm_class.static_properties['true'] = True
    avm_class.static_properties['false'] = False
    avm_class.static_properties['NaN'] = float('NaN')
    avm_class.static_properties['undefined'] = _Undefined()
    avm_class.static_properties['trace'] = lambda x: x
    avm_interp = SWFInterpreter()
    avm_interp.interp_code(avm_class, 'true', _CodeIterator(b'[0 0]\x06\x03'))
    avm_interp.interp_code(avm_class, 'false', _CodeIterator(b'[0 0]\x06\x03'))
    avm_interp

# Generated at 2022-06-24 14:26:20.321945
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    methods = {}
    _AVMClass(0, 'Test', {}).register_methods(methods)
    


# Generated at 2022-06-24 14:26:22.365682
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert repr(_AVMClass_Object(_AVMClassStub_1)) == 'AVMClassStub#1'

# Generated at 2022-06-24 14:26:32.943050
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .concurrency import DummyConcurrencyHandler

    def test(func_name, expected_args, expected_return_type):
        concurrency_handler = DummyConcurrencyHandler()
        swf_interpreter = SWFInterpreter(
            concurrency_handler,
            None,
            codecs.open(get_test_file_path('bbb.swf'), 'rb'))
        func = swf_interpreter.extract_function(
            swf_interpreter.global_class, func_name)
        res = func(expected_args)
        assert isinstance(res, expected_return_type)

    test(
        'join',
        ['-', ['foo', 'bar']],
        compat_str)


# Generated at 2022-06-24 14:26:42.753342
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass('MyClass', 'my_class', {'a': 1})
    assert class_.name == 'my_class'
    assert class_.name_idx == 'MyClass'
    assert class_.static_properties == {'a': 1}
    assert class_.method_names == {}
    assert class_.method_idxs == {}
    assert class_.methods == {}
    assert class_.method_pyfunctions == {}
    assert class_.variables == _ScopeDict(class_)
    assert class_.constants == {}

    class_.register_methods({'my_method': 1})
    assert cla

# Generated at 2022-06-24 14:26:48.384739
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass(1, 'ClassName', {
        'a': 'A',
        'b': 'B',
    })
    assert class_.name == 'ClassName'
    assert class_.name_idx == 1
    assert class_.static_properties == {
        'a': 'A',
        'b': 'B',
    }

    obj = class_.make_object()
    assert isinstance(obj, _AVMClass_Object)
    assert obj.avm_class is class_



# Generated at 2022-06-24 14:26:49.644542
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    _AVMClass('a', 'b')



# Generated at 2022-06-24 14:26:58.826506
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    avm_class = _AVMClass()
    avm_class.name = 'TestClass'
    avm_object = _AVMClass_Object(avm_class)
    assert avm_object.avm_class.name == 'TestClass'


# -*- coding: utf-8 -*-
# TODO:
#   * Support more ActionScript opcodes
#     * Check this with real-world SWF files and find some
#       reference information
#   * Make _AVMClass, _AVMClass_Object, _AVMFrame, _AVMMethod
#     and _AVMMethod_Object work together to support
#     class instantiation and method execution
#   * Optimize the vars/locals handling for _AVMFrame

# Generated at 2022-06-24 14:27:06.304639
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass('MyClass', 19)
    assert avm_class.method_names == {}
    assert avm_class.method_idxs == {}
    avm_class.register_methods(dict(
        method1=5,
        method2=10,
        method3=19,
    ))
    assert avm_class.method_names == dict(
        method1=5,
        method2=10,
        method3=19,
    )
    assert avm_class.method_idxs == dict(
        (5, 'method1'),
        (10, 'method2'),
        (19, 'method3'),
    )

    avm_class.register_methods(dict(
        method1=20,
        method3=0,
    ))
    assert av

# Generated at 2022-06-24 14:27:08.764299
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    is_false = not _Undefined()
    assert is_false
test__Undefined___bool__()


_undefined = _Undefined()



# Generated at 2022-06-24 14:27:12.505824
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    # Case 1
    avm_class = _AVMClass('my_class')
    obj = _AVMClass_Object(avm_class)
    assert obj.__repr__() == '%s#%x' % (avm_class.name, id(obj))



# Generated at 2022-06-24 14:27:13.888891
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert '%r' % _AVMClass_Object(None) == 'None#0'



# Generated at 2022-06-24 14:27:18.448965
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-24 14:27:24.963754
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    avm_classes = {0: _AVMClass('int')}
    f = io.BytesIO()
    f.write(b'\0\0\0\0')
    obj = _AVMClass_Object(avm_classes[0])
    print(repr(obj))
    assert repr(obj) == 'int#%x' % id(obj)


# Generated at 2022-06-24 14:27:29.819514
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interp1 = build_interpreter(None)
    avm_class1 = interp1.extract_class(1)
    assert avm_class1.classname == 'Object'

    interp2 = build_interpreter(None)
    avm_class2 = interp2.extract_class(2)
    assert avm_class2.classname == 'String'

# Generated at 2022-06-24 14:27:34.593249
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = _AVMClass('foo').make_object()
    assert obj.avm_class.name == 'foo'
    assert isinstance(obj, _AVMClass_Object)

# Generated at 2022-06-24 14:27:37.086294
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    a = _Multiname(0)
assert str(a) == '[MULTINAME kind: 0x0]'



# Generated at 2022-06-24 14:27:39.464023
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():

    interpreter = SWFInterpreter()

    # Nothing to do yet

    return True


# Generated at 2022-06-24 14:27:41.832466
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    obj = _AVMClass_Object(None)
    obj.avm_class = None
    return obj.__repr__()

# Generated at 2022-06-24 14:27:46.949248
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = open(os.path.join(TEST_DATA_ROOT, 'simple.swf'), 'rb')
    assert SWFInterpreter(swf).extract_function(None, 'toString')
    swf.close()
test_SWFInterpreter_extract_function()

# Unit test class SWFInterpreter

# Generated at 2022-06-24 14:27:50.820165
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0)) == '[MULTINAME kind: 0x0]'
    assert repr(_Multiname(1)) == '[MULTINAME kind: 0x1]'



# Generated at 2022-06-24 14:27:59.287500
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from .helpers import BinaryData
    from .helpers import get_binary_data
    from .extractor import SwfExtractor as _SwfExtractor
    from .utils import escape_rfc3986

# Generated at 2022-06-24 14:28:05.143859
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    method = _Multiname(0)
    assert repr(method) == '[MULTINAME kind: 0x0]'
    method = _Multiname(0x123456)
    assert repr(method) == '[MULTINAME kind: 0x123456]'



# Generated at 2022-06-24 14:28:09.327349
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(1, 'testclass')
    assert c.name == 'testclass'
    assert c.static_properties == {}
    assert c.method_names == {}
    assert c.methods == {}



# Generated at 2022-06-24 14:28:15.407758
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from .compat import unittest
    from .utils import FakeOpener

    class TestCase(unittest.TestCase):
        def test(self):
            avm_class = _AVMClass(0, 'Test')
            self.assertEqual(repr(avm_class), '_AVMClass(Test)')

    unittest.main()



# Generated at 2022-06-24 14:28:19.577870
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .test_utils import assertRegexpMatches
    def f():
        return '<AVMClass%x>' % id(f)
    A = _AVMClass_Object(f)
    assertRegexpMatches(repr(A), r'<AVMClass\d+>#\d+')



# Generated at 2022-06-24 14:28:30.582591
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter()
    swf.get_coder()

    assert swf.method_codes['f_0'] == [
        [
            [120, 5, 0, 0, 0],
            [46, 0, 0, 0],
            [46, 1, 0, 0],
            [46, 0, 0, 0],
            [46, 0, 0, 0],
            [1],
            [4],
            [4],
            [4],
            [4],
            [4],
            [4],
            [4],
            [72, 0],
        ]
    ]

    swf.patch_function('f_0', 'return "test_SWFInterpreter_patch_function"')
    assert callable(swf.method_pyfunctions['f_0'])


# Generated at 2022-06-24 14:28:31.487700
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(0)

# Generated at 2022-06-24 14:28:40.414356
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():

    # Initialize interpreter
    interp = SWFInterpreter()

    # Create a class with no properties
    coder = compat_StringIO()
    avm_class = _AVMClass(None, 'Foo', {}, None, None)
    _write_u32_le(coder, 0)
    _write_u32_le(coder, 0)
    _write_u32_le(coder, 0)
    _write_u32_le(coder, 0)
    _write_u32_le(coder, 0)
    _write_u32_le(coder, 0)
    coder.seek(0)

    # Create the file
    f = SWFFile()
    f._version_number = 16

# Generated at 2022-06-24 14:28:51.974961
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .bintools import cStringIO as BytesIO
    from .do_action import do_action

    def check_extract_function(asm):
        f = BytesIO(asm)
        interpreter = SWFInterpreter(f)
        func = interpreter.extract_function('test', 'DoAction')
        return func

    def test_extract_function(asm, expected_result):
        func = check_extract_function(asm)
        frame = do_action(asm, 0)
        assert expected_result == func(frame.scope_stack)


# Generated at 2022-06-24 14:29:00.164346
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    import io
    import pyamf.util.math
    out = io.StringIO()
    obj = pyamf.util.math._AVMClass('name_idx', 'name', 'static_properties')
    obj.method_names = 'method_names'
    obj.method_idxs = 'method_idxs'
    obj.methods = 'methods'
    obj.method_pyfunctions = 'method_pyfunctions'
    obj.variables = 'variables'
    obj.constants = 'constants'
    pyamf.util.math._AVMClass.__repr__(obj, out)
    assert out.getvalue() == '_AVMClass(name)'



# Generated at 2022-06-24 14:29:02.021984
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == 'undefined'

# Generated at 2022-06-24 14:29:08.138659
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class Foo(object):
        name = 'Foo'
    scope = _ScopeDict(Foo())
    scope['bar'] = 42
    scope['baz'] = 'quux'
    assert ('Foo__Scope({'
            '\'bar\': 42, '
            '\'baz\': \'quux\'})' == repr(scope))

test__ScopeDict()



# Generated at 2022-06-24 14:29:16.700665
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from . import core
    from .core import _read_swf_file, _abc_parser
    from .core import SWFInterpreter

    import io
    sio = io.BytesIO()

    # The minimal SWF header

# Generated at 2022-06-24 14:29:28.882030
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    import swftools.swfdecompiler.swfdump.swfdump_main as swfdump_main
    from .swfdump import parse_swf
    from .utils import (
        ExtractorError,
    )

# Generated at 2022-06-24 14:29:30.050866
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert str(_Undefined()) == 'undefined'

# Generated at 2022-06-24 14:29:34.630167
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interp = SWFInterpreter()
    coder = io.BytesIO(b'\x3f\xf3\x13\x00')
    assert interp.extract_class(coder) == 3

# Generated at 2022-06-24 14:29:46.447061
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-24 14:29:48.256961
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert repr(_AVMClass(None, None, None)) == '_AVMClass(None)'



# Generated at 2022-06-24 14:29:57.030944
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open('../swf_data/swf/gddkpiig.swf', 'rb') as fp:
        interp = SWFInterpreter(fp)

    # Check version
    assert interp.version == 9

    # Check size
    assert interp.size == (800, 600)

    # Check frame rate
    assert interp.frame_rate == 30

    # Check frame count
    assert interp.frame_count == 6

    # Check tags
    assert interp.tags[0].tag_type == 9
    assert interp.tags[0].file_position == 8

# Generated at 2022-06-24 14:29:59.509677
# Unit test for constructor of class _Multiname
def test__Multiname():
    a = _Multiname(0x07)
    assert (a.kind == 0x07)


# Generated at 2022-06-24 14:30:01.140228
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    _AVMClass(0, 'Root').__repr__()

# Generated at 2022-06-24 14:30:02.636957
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    c = _Multiname(0x07)
    assert repr(c) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:30:03.761104
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    try:
        hash(_Undefined())
    except:
        raise AssertionError()

# Generated at 2022-06-24 14:30:08.764960
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .utils import PY2, PY3
    assert PY2 or PY3
    class TE:
        def __init__(self):
            te=TE()
            _AVMClass('a', 'b').make_object()
            _AVMClass_Object(te).avm_class
            _ScopeDict(te).avm_class
            dict()
            _ScopeDict('a').__repr__()
            _AVMClass_Object('a').__repr__()
            list()
            _AVMClass('a', 'b')
            dict()
    x = TE()

# Generated at 2022-06-24 14:30:16.860360
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    import json

    class MyClass:
        pass

    mc = MyClass()
    mc.__name__ = 'MyClass'

    def test_equal(mc, c):
        c_instance = c(mc)
        expect = '%s#%x' % (repr(mc), id(c_instance))
        print('expect: ' + json.dumps(expect))
        assert repr(c_instance) == expect

    test_equal(mc, _AVMClass_Object)


# Generated at 2022-06-24 14:30:18.517929
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    with pytest.raises(AssertionError):
        True

# Generated at 2022-06-24 14:30:23.976525
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    x = _Undefined()
    assert hash(x) == 0
    assert hash(x) is not x
_Undefined.__code__ = test__Undefined___hash__.__code__
_Undefined = collections.namedtuple('_Undefined', ['b'])
Undefined = _Undefined()



# Generated at 2022-06-24 14:30:28.972187
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _TestClass(object):
        pass
    tc = _TestClass()
    tc.name = 'Classname'
    scope = _ScopeDict(tc)
    scope['foo'] = 'bar'
    scope['baz'] = 'qux'
    assert str(scope).startswith(
        'Classname__Scope({') and 'baz' in scope and 'foo' in scope, scope



# Generated at 2022-06-24 14:30:36.119377
# Unit test for constructor of class _Undefined
def test__Undefined():
    u = _Undefined()
    assert u is not None
    assert not bool(u)
    assert not bool(bool(u))
    assert u is not False
    assert bool(u) == bool(False)
    assert bool(bool(u)) == bool(bool(False))
    assert bool(u) == False
    assert bool(bool(u)) == bool(False)
    assert bool(u) is False
    assert bool(bool(u)) is bool(False)
    assert hash(u) == hash(False)


# Generated at 2022-06-24 14:30:46.191582
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .tags import DoABC

    # DoABC tag with a little AS3 code

# Generated at 2022-06-24 14:30:57.493385
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    EXPECTED_CODE = 'var exp=0.0;'\
        'var val=0.0;'\
        'for(var i=0;i<this._numbFrames;i++)'\
        '{exp+=Math.pow(2.718281828459045,'\
        'this._framesLoaded/this._totalFrames*9-9);'\
        'val+=i/this._totalFrames*this._bytesLoaded;'\
        'if(this._framesLoaded>i){continue;}'\
        'var p=Math.round(val/exp);'\
        'if(p<0){p=0;}'\
        'if(p>100){p=100;}'\
        'this.dispatchEvent({type:"progress",level:p});}'\
       

# Generated at 2022-06-24 14:31:04.761111
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from yalafi.parser import init_parser
    parser, defs = init_parser(lang='en')
    with open('test/test_interpreter.swf', 'rb') as f:
        file_contents = f.read()
    _, avm3_class_idx_map = _parse_tags(parser, defs, file_contents)
    assert repr(avm3_class_idx_map[1]) == '_AVMClass(A)'



# Generated at 2022-06-24 14:31:05.769036
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    return 'pass'

# Generated at 2022-06-24 14:31:10.240775
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    import types
    obj = _AVMClass('Test', ('',)).make_object()
    assert isinstance(obj, _AVMClass_Object)
    assert isinstance(obj.avm_class, _AVMClass)
    assert obj.avm_class.name == 'Test'
    assert repr(obj) == 'Test#%x' % id(obj)

# Generated at 2022-06-24 14:31:13.691216
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class_ = _AVMClass(None, None)
    obj = class_.make_object()
    assert isinstance(obj, _AVMClass_Object)



# Generated at 2022-06-24 14:31:15.639882
# Unit test for constructor of class _Undefined
def test__Undefined():
    return not bool(_Undefined()) and not bool(hash(_Undefined()))



# Generated at 2022-06-24 14:31:24.626443
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .dummy_swf import make_dummy_swf_with_class_def
    from .extractor import _RootType
    from .avm2 import avm2_parse
    dummy_swf = make_dummy_swf_with_class_def(
        'Class1', '<dummy_bytes>')
    avm2_root = avm2_parse(io.BytesIO(dummy_swf))

    sd = _ScopeDict(avm2_root.classes['Class1'])
    sd['foo'] = 'bar'
    assert repr(sd) == 'Class1__Scope({\'foo\': \'bar\'})'
