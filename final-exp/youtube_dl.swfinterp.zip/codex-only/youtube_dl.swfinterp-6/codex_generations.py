

# Generated at 2022-06-24 14:21:30.224964
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from .test_compat import StringIO

    class _AVMFile(object):
        def __init__(self):
            self.constants = {}
            self.strings = {}

    class _ScopeDict(dict):
        def __init__(self, parent_class):
            super(_ScopeDict, self).__init__()
            self.avm_class = parent_class

    class _AVMClass(object):
        def __init__(self, name_idx, name, static_properties=None):
            self.name_idx = name_idx
            self.name = name
            self.method_names = {}
            self.method_idxs = {}
            self.methods = {}
            self.method_pyfunctions = {}

# Generated at 2022-06-24 14:21:31.117143
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


# Generated at 2022-06-24 14:21:36.143043
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() is _Undefined()
    assert not _Undefined()
    assert hash(_Undefined()) == hash(0)
    assert str(_Undefined()) == 'undefined'
test__Undefined.register = False

Undefined = _Undefined()

# Generated at 2022-06-24 14:21:39.284266
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class_ = _AVMClass(None, None, '<foo>', 'bar')
    scope = _ScopeDict(class_)
    scope['baz'] = 'quux'
    assert class_.name in scope.__repr__()



# Generated at 2022-06-24 14:21:42.709742
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cl = _AVMClass(0, b'Test')
    assert cl.name_idx == 0
    assert cl.name == b'Test'
    assert cl.static_properties == {}
    assert cl.variables == {}
    assert cl.constants == {}
    assert cl.method_names == {}
    assert cl.method_idxs == {}
    assert cl.methods == {}
    assert cl.method_pyfunctions == {}



# Generated at 2022-06-24 14:21:47.636632
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    si = SWFInterpreter()
    si.constant_strings = [
        'String', 'undefined', 'Number', 'join', 'split', 'length',
        'split', 'indexOf', 'charCodeAt', 'slice', 'reverse', 'join',
        'split', 'length', 'charCodeAt']
    si.multinames = [
        'String', 'undefined', 'Number', 'join', 'split', 'length',
        'split', 'indexOf', 'charCodeAt', 'slice', 'reverse', 'join',
        'split', 'length', 'charCodeAt']

    def run_test(code, expected_result):
        class DummyClass:
            pass
        cls = DummyClass()
        resfunc = si.extract_function(
            'test', code, cls, [])


# Generated at 2022-06-24 14:21:50.074481
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    cls = _AVMClass("abc", "abc")
    assert repr(cls) == "_AVMClass(abc)"

# Generated at 2022-06-24 14:21:51.942223
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    class0 = _AVMClass(None, 'example')
    assert repr(class0) == '_AVMClass(example)'

# Generated at 2022-06-24 14:21:54.090259
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    u = _Undefined()
    if u:
        raise Exception('Unit test failed')

# Generated at 2022-06-24 14:21:55.642799
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from avmpy._avm_stdlib import SWFInterpreter
    SWFInterpreter()


# Generated at 2022-06-24 14:21:57.800146
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert _ScopeDict(_AVMClass_Object(_AVMClass_Object(None))).avm_class.avm_class.name is None
    assert str(_ScopeDict(_AVMClass_Object(_AVMClass_Object(None)))) == 'None__Scope({})'
test__ScopeDict()



# Generated at 2022-06-24 14:21:59.221515
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    r = _AVMClass('', '')
    assert isinstance(r.make_object(), _AVMClass_Object)



# Generated at 2022-06-24 14:22:00.861963
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
    assert not _Undefined()
    assert _Undefined() is not None

# Generated at 2022-06-24 14:22:05.445707
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open(os.path.join(os.path.dirname(__file__), 'f0.swf'), 'rb') as f:
        swf = SWF(f.read())
    for tag in swf.tags:
        if isinstance(tag, DoABC):
            abc = tag.abc_file
            for avm_class in abc.classes:
                if avm_class.cinit is not None:
                    interp = SWFInterpreter(abc)
                    interp.extract_function(avm_class, '<cinit>')


# Generated at 2022-06-24 14:22:06.743768
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    u = _Undefined()
    assert not u
    assert False == u

# Generated at 2022-06-24 14:22:17.995073
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    # Test calls the _AVMClass method register_methods
    # with arguments (_AVMClass(), dict([('run', 'run'), ('init', 'init')]))
    # to the function _AVMClass.register_methods

    def call(methods):
        # Test calls methods.items()
        class TestItems(object):
            def items(self):
                return [('run', 'run'), ('init', 'init')]
        methods = TestItems()

        # Test invokes _AVMClass method register_methods
        # with arguments (_AVMClass(), dict([('run', 'run'), ('init', 'init')]))
        class TestAVMClass(object):
            def __init__(self, name_idx, name, static_properties=None):
                self.name_idx = name_idx
               

# Generated at 2022-06-24 14:22:22.271808
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    self = _AVMClass('self', 'name')
    methods = dict(
        a='a_name',
        b='b_name')
    self.register_methods(methods)
    assert self.method_names == methods
    assert self.method_idxs == dict(
        (idx, name)
        for name, idx in methods.items())



# Generated at 2022-06-24 14:22:23.346396
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0)  # no issue



# Generated at 2022-06-24 14:22:25.084800
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0).__repr__() == '[MULTINAME kind: 0x0]'

# Expected output:
# [MULTINAME kind: 0x0]
# test__Multiname()



# Generated at 2022-06-24 14:22:27.601264
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    undefined = _Undefined()  # noqa: F841
    assert 'undefined' == str(undefined)
    assert not bool(undefined)
    assert 0 == hash(undefined)

# Generated at 2022-06-24 14:22:34.457929
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    mn_1 = _Multiname(0x09)
    assert str(mn_1) == '[MULTINAME kind: 0x9]'
    mn_2 = _Multiname(0x0b)
    assert str(mn_2) == '[MULTINAME kind: 0xb]'
    mn_3 = _Multiname(0x0d)
    assert str(mn_3) == '[MULTINAME kind: 0xd]'
    mn_4 = _Multiname(0x0f)
    assert str(mn_4) == '[MULTINAME kind: 0xf]'
    mn_5 = _Multiname(0x10)
    assert str(mn_5) == '[MULTINAME kind: 0x10]'

# Generated at 2022-06-24 14:22:38.534687
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert _Multiname(1).__repr__() == '[MULTINAME kind: 0x1]'


# Generated at 2022-06-24 14:22:41.360009
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    avm_class = _AVMClass(None, None, None)
    assert repr(avm_class) == '_AVMClass(None)'

# Generated at 2022-06-24 14:22:46.152971
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    cls = _AVMClass_Object
    assert cls(None).__repr__() == 'None#%x' % id(cls.avm_class)
    assert cls('').__repr__() == '#%x' % id(cls.avm_class)



# Generated at 2022-06-24 14:22:53.992565
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    ac = _AVMClass(0, 'Foo', {'bar': 42})
    assert ac.name_idx == 0
    assert ac.name == 'Foo'
    assert ac.static_properties == {'bar': 42}
    assert ac.method_names == {}
    assert ac.method_idxs == {}
    assert ac.methods == {}
    assert ac.method_pyfunctions == {}
    assert ac.variables == {}
    assert ac.constants == {}



# Generated at 2022-06-24 14:22:54.979781
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

# Generated at 2022-06-24 14:22:56.336949
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    x = _Undefined()
    hash(x)



# Generated at 2022-06-24 14:23:02.289923
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    v = _AVMClass('hello', 'hello')
    v.register_methods({'sayHello': 1, 'sing': 2})
    assert v.method_names == {'sayHello': 1, 'sing': 2}, repr(v.method_names)
    assert v.method_idxs == {1: 'sayHello', 2: 'sing'}, repr(v.method_idxs)
test__AVMClass_register_methods()


# Generated at 2022-06-24 14:23:10.841370
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_lib import SWFReader
    from .swfx import SWFExtractor
    from .swfx import SWFHeader
    from .swfx import SWFBody
    from .tag_reader import TagReader
    from .tag_reader import UserDefineFunction

    tag_readers = {
        0x3f: UserDefineFunction
    }
    swf_reader = SWFReader()
    swf = swf_reader.read_swf('tests/test-data/test.swf')
    headers_dict = swf_extractor.extract_headers(swf)
    bodies_dict = swf_extractor.extract_bodies(swf)
    tag_readers_dict = swf_extractor.extract_tag_readers(headers_dict,
                                                         bodies_dict)

# Generated at 2022-06-24 14:23:15.411835
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(None, None)
    c.register_methods({'M1': 1, 'M2': 2})
    assert list(c.method_names.keys()) == ['M1', 'M2']
    assert list(c.method_idxs.keys()) == [1, 2]



# Generated at 2022-06-24 14:23:22.887699
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    _AVMClass(
    ).__repr__()  # NameResolveError: name '_AVMClass' is not defined
    _AVMClass(
        name_idx=1,
        name='a',
        static_properties={
            'b': 2,
            'c': 3,
            'd': 4,
        },
    ).__repr__()  # NameResolveError: name '_AVMClass' is not defined



# Generated at 2022-06-24 14:23:25.693098
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class Sample:
        name = 'sample'

    object = _AVMClass_Object(Sample())
    assert str(object) == 'sample#%x' % id(object)



# Generated at 2022-06-24 14:23:27.451749
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    assert repr(AVM.classes['Object'].make_object()) == 'Object#414d6d0'

# Generated at 2022-06-24 14:23:32.145730
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    name_idx = 0
    name = 0
    static_properties = 0

    a = _AVMClass(name_idx, name, static_properties)
    a.make_object()


# Generated at 2022-06-24 14:23:34.540989
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _AVMClass(object):
        name = '_test_AVMClass'
    assert repr(_ScopeDict(_AVMClass())) == '_test_AVMClass__Scope({})'



# Generated at 2022-06-24 14:23:43.498715
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass('Test', 'Test', {'a': 1, 'b': 2})
    assert class_.name == 'Test'
    assert class_.name_idx == 'Test'
    assert class_.static_properties == {'a': 1, 'b': 2}
    assert class_.constants == {}
    assert class_.variables == {}
    assert class_.methods == {}
    assert class_.method_idxs == {}
    assert class_.method_names == {}
    assert class_.method_pyfunctions == {}
    assert class_.make_object().avm_class is class_



# Generated at 2022-06-24 14:23:44.838846
# Unit test for constructor of class _Multiname
def test__Multiname():
    return repr(_Multiname(0x0d))



# Generated at 2022-06-24 14:23:45.919221
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

# Generated at 2022-06-24 14:23:46.946137
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert repr(_ScopeDict(None)) == 'None__Scope({})'



# Generated at 2022-06-24 14:23:50.526872
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    klass = _AVMClass('ClassName', 'ClassName', {})
    obj = klass.make_object()
    assert obj.avm_class == klass

# Generated at 2022-06-24 14:23:55.225914
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    assert repr(_AVMClass(1, b'moar')) == '_AVMClass(moar)'
    assert repr(_AVMClass(1, b'moar', {b'k': b'v'})) == '_AVMClass(moar)'



# Generated at 2022-06-24 14:24:02.962507
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .utils import FakeVM
    from .avm_classes import *
    from .format_avm1 import (
        _AVM1_constants,
        _AVM1_static_properties,
        _AVM1_methods,
    )
    vm = FakeVM(format_avm1)
    for idx, (classname, static_properties) \
            in enumerate(_AVM1_constants['class'].items()):
        vm.avm['class_id_by_name'][classname] = idx
        vm.avm['class_name_by_id'][idx] = classname
        vm.avm['classes'][classname] = _AVMClass(
            idx, classname, static_properties)

# Generated at 2022-06-24 14:24:06.834939
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    instance = _Undefined()
    assert str(instance) == 'undefined'
    assert repr(instance) == 'undefined'
    assert instance.__str__() == 'undefined'
    assert instance.__repr__() == 'undefined'
_Undefined = _Undefined()



# Generated at 2022-06-24 14:24:09.283222
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
undefined = _Undefined()



# Generated at 2022-06-24 14:24:14.683007
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    a = _AVMClass(42, '#42')
    d = _ScopeDict(a)
    assert d.__repr__() == '#42__Scope({})'
    d[None] = True
    assert d.__repr__() == '#42__Scope({None: True})'
    d[None] = False
    d[b'X'] = True
    assert d.__repr__() == '#42__Scope({None: False, b\'X\': True})'



# Generated at 2022-06-24 14:24:15.576832
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0x0f)



# Generated at 2022-06-24 14:24:25.269507
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass(
        name_idx = 12,
        name = "TestClass",
        static_properties = {
            'static_string': 'Hello',
            'static_int': 42,
        },
    )
    obj.method_names = {
        '__repr__': 1,
        'static_method_1': 2,
        'static_method_2': 3,
    }
    obj.method_idxs = {
        1: '__repr__',
        2: 'static_method_1',
        3: 'static_method_2',
    }
    obj.methods = {
        1: '__repr__(self)',
        2: 'static_method_1()',
        3: 'static_method_2()',
    }
    obj.method

# Generated at 2022-06-24 14:24:28.391223
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter('test_flash.swf')
    for cls in swf.classes:
        print(cls.name)


# Generated at 2022-06-24 14:24:31.361984
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    var = _Undefined()
    assert repr(var) == 'undefined'
_undefined = _Undefined()



# Generated at 2022-06-24 14:24:34.748335
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    avm_class = _AVMClass('SomeClass', [])
    interpreter = SWFInterpreter(avm_class)
    interpreter.patch_function(b'\x00')
    assert len(avm_class.method_pyfunctions) == 1



# Generated at 2022-06-24 14:24:47.115456
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import os.path
    import unittest
    import shutil
    
    # TODO: test with classes that do not have any method
    
    mydir = 'data'

    class AVMClassData(object):
        def __init__(self, avm_class):
            self.class_name = avm_class.class_name
            self.base_class_name = avm_class.base_class.class_name
            self.parent_names = [c.class_name for c in avm_class.parent_classes]
            self.has_method = sorted(avm_class.method_names)
            self.method_code = avm_class.method_code['__construct']
            self.constant_strings = avm_class.constant_strings
            self.multinames = avm_

# Generated at 2022-06-24 14:24:48.051277
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    pass  # Not implemented

# Generated at 2022-06-24 14:24:53.275137
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    _avm_class = _AVMClass(None, 'TestClass')
    _avm_class.register_methods({'sys_getQualifiedClassName': 2})
    expected = '_AVMClass(TestClass)'
    actual = repr(_avm_class)
    assert actual == expected, '%r != %r' % (actual, expected)
# test__AVMClass_register_methods()


# Generated at 2022-06-24 14:24:54.704368
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'


_undefined = _Undefined()



# Generated at 2022-06-24 14:25:07.389669
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from pprint import pprint
    import sys
    from . import amf
    interpreter = SWFInterpreter()
    interpreter.extract_class(
        'com.adobe.serialization.json.JSON',
        _load_avm_test_data('JSON.abc')
    )
    pprint(interpreter.convert_pyclass_into_js(
        interpreter.avm_classes['com.adobe.serialization.json.JSON']))
    interpreter.extract_class(
        'com.adobe.utils.IntUtil', _load_avm_test_data('IntUtil.abc'))
    interpreter.extract_class(
        'flash.utils.Dictionary', _load_avm_test_data('Dictionary.abc'))

# Generated at 2022-06-24 14:25:13.764045
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    c1 = _AVMClass('Foo')
    c2 = _AVMClass('Foo')
    assert c1 is not c2  # different object
    assert c1 == c2  # but with the same name

    assert repr(c1) == 'Foo#0x%x' % id(c1)
    assert repr(c2) == 'Foo#0x%x' % id(c2)



# Generated at 2022-06-24 14:25:16.683205
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    print('test__AVMClass___repr__')
    # Simple test
    o1 = _AVMClass(1, 'a')
    assert repr(o1) == '_AVMClass(a)'



# Generated at 2022-06-24 14:25:20.565293
# Unit test for constructor of class _Undefined
def test__Undefined():
    _Undefined()
    assert not _Undefined()
    assert _Undefined() == False
    assert u'undefined' == _Undefined.__str__(_Undefined())
    assert hash(_Undefined()) == 0



# Generated at 2022-06-24 14:25:33.594843
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter()

    class_id = 1

    method_ids = {}
    method_names = {}

    class_property_names = [
        'U', 'P', 'T', 'B', 'N', 'V', 'Q', 'R', 'G', 'J', 'Z', 'H', 'S', 'F',
        'D', 'C', 'I', 'M', 'L', 'O', 'K', 'A', 'E', 'Y'
    ]

    multinames = {i: n for i, n in enumerate(class_property_names)}


# Generated at 2022-06-24 14:25:41.056326
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from collections import OrderedDict
    from .tlslite.utils.codec import _encode_be16
    from .tlslite.utils.codec import _encode_be24

    # SWF 1
    constant_pool = [
        'Proxy.asyncCall',
        '__setTimeout',
        '__setInterval',
        'clearInterval',
        'parseInt',
        'String',
    ]

# Generated at 2022-06-24 14:25:43.929346
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    u = _Undefined()
    assert u.__repr__() == 'undefined'


undefined = _Undefined()
nan = float('nan')
null = None
false = False
true = True



# Generated at 2022-06-24 14:25:45.210282
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    x = _ScopeDict('test')
    assert repr(x).startswith('test__Scope(')



# Generated at 2022-06-24 14:25:48.402640
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    undefined = _Undefined()
    assert bool(undefined) == False

# Generated at 2022-06-24 14:25:57.475906
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter()
    interpreter.constant_strings = {0: 'foo'}
    interpreter.constant_namespaces = {
        0: Namespace(None, '', 'private'),
    }
    interpreter.multinames = [
        Multiname(0, 0, 0, 'foo', None, None),
    ]
    interpreter.method_param_types = [[]]
    interpreter.method_param_names = [[]]
    interpreter.method_return_types = [[]]
    interpreter.method_name = 'foo'
    interpreter.method_flags = 0
    interpreter.method_option_info = None
    interpreter.method_registers = 0

# Generated at 2022-06-24 14:26:04.654221
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    cls = _AVMClass('SomeClass', 0)
    cls.register_methods({'a': 1, 'b': 2})
    assert cls.method_names['a'] == 1
    assert cls.method_names['b'] == 2
    assert cls.method_idxs[1] == 'a'
    assert cls.method_idxs[2] == 'b'



# Generated at 2022-06-24 14:26:06.720152
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    return _Undefined().__repr__()

# Generated at 2022-06-24 14:26:11.210002
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    test_object = _AVMClass('name').make_object()
    assert test_object.avm_class.name == 'name'
    assert test_object.__repr__() == 'name#%x' % id(test_object)

# Generated at 2022-06-24 14:26:14.761461
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(0x0)) == '[MULTINAME kind: 0x0]'
    assert repr(_Multiname(0x96)) == '[MULTINAME kind: 0x96]'


# Generated at 2022-06-24 14:26:19.379174
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert (
        _ScopeDict(
            _AVMClass_Object(_AVMClass('Foo', None))
        ) == {'a': 'b'}) == "Foo__Scope({'a': 'b'})"



# Generated at 2022-06-24 14:26:21.733011
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    """This is a test method for the _AVMClass class.
    """
    assert True, "Not implemented."


# Generated at 2022-06-24 14:26:24.543132
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = AVM2().method_classes['flash.display.Sprite'].make_object()
    assert isinstance(obj, _AVMClass_Object)



# Generated at 2022-06-24 14:26:26.225790
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert eval(repr(_ScopeDict(None))).__class__ == dict



# Generated at 2022-06-24 14:26:32.384294
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class AVMClass(object):
        pass

    avm_class = AVMClass()
    avm_class.name = 'MyClass'
    scope = _ScopeDict(avm_class)
    scope[0] = 1
    scope[1] = 2
    scope[4] = 3
    scope[5] = 6
    assert repr(scope) == 'MyClass__Scope({0: 1, 1: 2, 4: 3, 5: 6})'



# Generated at 2022-06-24 14:26:44.339477
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(
        0, 'TestClass',
        static_properties={
            'num_sprop': 1,
            'str_sprop': 'string',
            'obj_sprop': _AVMClass_Object(_AVMClass(1, 'OtherClass')),
        })
    assert isinstance(c.variables, _ScopeDict)
    assert c.variables.avm_class is c
    assert c.variables.items() == []
    assert c.constants == {}
    assert c.method_names == {}
    assert c.method_idxs == {}
    assert c.methods == {}
    assert c.method_pyfunctions == {}


# Generated at 2022-06-24 14:26:47.881183
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    _Multiname(kind=0x0)
    _Multiname(kind=0x1)
    _Multiname(kind=0x11)
    _Multiname(kind=0x1e)
    _Multiname(kind=0x1e).__repr__()



# Generated at 2022-06-24 14:26:50.779824
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    instance = _ScopeDict(avm_class='avm_class')
    assert repr(instance) == 'avm_class__Scope(%s)' % repr(dict())



# Generated at 2022-06-24 14:26:51.828255
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    SWFInterpreter(None, None)


# TODO: finish this test

# Generated at 2022-06-24 14:26:57.379905
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import _swf as swf
    from .amf0 import ParseError
    from .swfdecompiler import SWF
    from .swfdecompiler import SWF, swftags
    from .swftypes import Rect, RECT_SIZE
    swf_data = open(os.path.join(
            os.path.dirname(__file__),
            'res', 'test.swf'), 'rb').read()
    det, rest = swf.Swf.parse_header(swf_data)
    swf_decompiler = SWF(swf_data, det)

    def get_tags(swfdecompiler, *tags):
        return [
            x for x in swfdecompiler.iter_tags()
            if isinstance(x, tags)]

    tags = get_

# Generated at 2022-06-24 14:27:00.316437
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .as_lib import AVMClass
    avm_class = AVMClass('Foo')
    scope = _ScopeDict(avm_class)
    scope['a'] = 42
    scope['b'] = 43
    assert repr(scope) == 'Foo__Scope({\'a\': 42, \'b\': 43})'
# End of unit test for method __repr__ of class _ScopeDict



# Generated at 2022-06-24 14:27:03.166985
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():  # noqa: N802
    assert repr(_AVMClass('a', 'b', 'c')) == "_AVMClass('b')"



# Generated at 2022-06-24 14:27:06.112660
# Unit test for method __repr__ of class _AVMClass

# Generated at 2022-06-24 14:27:08.134591
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert repr(_ScopeDict(_TestAVMClass(b''))) == 'class_0__Scope({})'

# Generated at 2022-06-24 14:27:17.327733
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    print("Unit test for class SWFInterpreter")

# Generated at 2022-06-24 14:27:26.875355
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    name_idx = None
    name = None
    static_properties = None
    clazz = _AVMClass(name_idx, name, static_properties)
    methods = {
        b'onMetaData': 0x2000,
        b'#': 0x0001,
    }
    clazz.register_methods(methods)
    assert clazz.method_names == methods
    assert clazz.method_idxs == {
        0x0001: b'#',
        0x2000: b'onMetaData',
    }



# Generated at 2022-06-24 14:27:39.745255
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .tags.doabc import ABCFile
    import sys


# Generated at 2022-06-24 14:27:41.420945
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass(0, 'Foo')
    obj = avm_class.make_object()
    assert obj.avm_class is avm_class



# Generated at 2022-06-24 14:27:47.414940
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class Dummy:
        def __init__(self):
            self.tag_name = None
            self.attrs = {}
            self.children = []

    obj = Dummy()

    obj.tag_name = 'sometag'
    obj.attrs['attr1'] = 1
    obj.attrs['attr2'] = 'two'
    obj.children = [1, 2, 3]

# Generated at 2022-06-24 14:27:49.033065
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    x = _Undefined()
    assert hash(x) == 0

# Generated at 2022-06-24 14:27:55.099932
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    x = _ScopeDict('foo')
    x['a'] = 5
    assert repr(x) == 'foo__Scope({\'a\': 5})'
    assert x['a'] == 5
    y = _ScopeDict('foo')
    y['b'] = 6
    assert repr(y) == 'foo__Scope({\'b\': 6})'
    assert y['b'] == 6
    assert x['a'] == 5
    del x['a']
    assert not x



# Generated at 2022-06-24 14:27:58.444325
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    o = _AVMClass('aaa', 'aaa')
    o.register_methods({'a': 0, 'b': 2})
# End unit test for method register_methods
    def register_method(self, idx, method):
        self.methods[idx] = method

# Generated at 2022-06-24 14:28:03.520912
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    p = _AVMClass_Object(_AVMClass_Object)
    assert repr(p) == '_AVMClass_Object#%x' % id(p)



# Generated at 2022-06-24 14:28:05.260224
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert repr(_ScopeDict(None)) == 'None__Scope({})'



# Generated at 2022-06-24 14:28:14.870185
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass('Object', 'Object')
    c.register_methods({
        'toString': 0x7c,
        'valueOf': 0x7d,
        'equals': 0x7e,
        'new': 0x7f,
        })
    assert c.method_names == {
        'toString': 0x7c,
        'valueOf': 0x7d,
        'equals': 0x7e,
        'new': 0x7f,
        }
    assert c.method_idxs == {
        0x7c: 'toString',
        0x7d: 'valueOf',
        0x7e: 'equals',
        0x7f: 'new',
        }



# Generated at 2022-06-24 14:28:19.940161
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    obj = _ScopeDict(_AVMClass_Object._AVMClass(None, 'fooclass', None))
    obj['foo'] = 'bar'
    obj['quux'] = 'baz'
    assert repr(obj) == "fooclass__Scope({'foo': 'bar', 'quux': 'baz'})"
# End unit test for method __repr__ of class _ScopeDict



# Generated at 2022-06-24 14:28:22.939678
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    try:
        _Undefined().__hash__()
    except AttributeError:
        assert False, 'Unexpected AttributeError'


# Generated at 2022-06-24 14:28:31.438575
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert str(compat_str(_Multiname(0))) == 'kind: 0x0'
    assert str(compat_str(_Multiname(0x0b))) == 'kind: 0xb'
    assert str(compat_str(_Multiname(0x0c))) == 'kind: 0xc'
    assert str(compat_str(_Multiname(0x1e))) == 'kind: 0x1e'
    assert str(compat_str(_Multiname(0x1f))) == 'kind: 0x1f'
    assert (str(compat_str(_Multiname(0x00020))) ==
            '[MULTINAME kind: 0x20]')



# Generated at 2022-06-24 14:28:35.169926
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    print('-' * 40)
    class_obj = _AVMClass(1, 'Foo')
    assert repr(class_obj) == '_AVMClass(Foo)'



# Generated at 2022-06-24 14:28:36.457650
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    u = _Undefined()
    assert hash(u) == 0

# Generated at 2022-06-24 14:28:44.110235
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from unittest import TestCase
    import test.test_utils as test_utils
    _test_class = test_utils.test_class

    class Test(_test_class(TestCase)):
        def test(self):
            avm_class = _AVMClass(
                name_idx=1,
                name='TestClass')
            avm_class.register_methods({
                'TestMethod1': 2,
                'TestMethod2': 3})
            self.assertEqual(avm_class.name_idx, 1)
            self.assertEqual(avm_class.name, 'TestClass')
            self.assertEqual(avm_class.method_idxs, {
                2: 'TestMethod1',
                3: 'TestMethod2'})

# Generated at 2022-06-24 14:28:54.201604
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-24 14:28:57.239455
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    o = _Undefined()
    assert hash(o) == 0, hash(o)

undefined = _Undefined()



# Generated at 2022-06-24 14:29:00.604707
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    scope = _ScopeDict(None)
    scope['test'] = 1
    scope['test2'] = 2
    assert str(scope) == '_Scope({"test2": 2, "test": 1})'



# Generated at 2022-06-24 14:29:05.903228
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_ = _AVMClass(name='test', superclass=None, traits=[])
    obj = _AVMClass_Object(class_)
    assert obj.avm_class.name == 'test'
    assert obj.avm_class.superclass is None
    assert obj.avm_class.traits == []



# Generated at 2022-06-24 14:29:08.834358
# Unit test for constructor of class _Multiname
def test__Multiname():
    return (
        _Multiname(0x07) ==
        type('')('[MULTINAME kind: 0x07]')
    )


# Generated at 2022-06-24 14:29:17.043580
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    from .utils import try_get_pyfunction_code
    class_obj = _AVMClass(name_idx=42, name='myClass', static_properties={})
    assert class_obj.name_idx == 42
    assert class_obj.name == 'myClass'
    assert class_obj.method_names == {}
    assert class_obj.method_idxs == {}
    assert class_obj.methods == {}
    assert class_obj.method_pyfunctions == {}
    assert class_obj.static_properties == {}
    assert (repr(class_obj) == '_AVMClass(myClass)' or
            repr(class_obj) == '_AVMClass(\'myClass\')')

    class_obj.method_names = {'myMethod1': 0}
    class_obj.method_id

# Generated at 2022-06-24 14:29:20.968916
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    x = _Undefined()
    xx = repr(x)
    assert type(xx) is str

    assert x is Undefined

Undefined = _Undefined()

# Generated at 2022-06-24 14:29:30.443702
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open(os.path.join(os.path.dirname(__file__), 'get-vid-info.swf'), 'rb') as f:
        data = f.read()
    interpreter = SWFInterpreter(data)
    avm_class = interpreter.extract_class('GetTubeInfo')
    avm_obj = avm_class.make_object()
    avm_func = interpreter.extract_function(avm_obj.avm_class, 'load')
    res = avm_func([])
    assert res == 'http://www.youtube.com/get_video_info?&video_id=u1zgFlCw8Aw'

# Generated at 2022-06-24 14:29:31.018414
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()) is False


# Generated at 2022-06-24 14:29:35.289942
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    avm1_swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), '../tests/swfs/avm1.swf'), 'rb').read())


# Generated at 2022-06-24 14:29:36.015342
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

# Generated at 2022-06-24 14:29:43.608067
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Construct from file
    with open('tests/testdata/tiny.swf', 'rb') as f:
        interpreter = SWFInterpreter(f)
    assert interpreter
    assert len(interpreter.constant_strings) == 1
    assert interpreter.constant_strings[0] == 'constructor'
    assert interpreter.swf.tag_codes == {
        49: b'ScriptLimits',
        82: b'DoABC',
        69: b'FileAttributes',
        9: b'SetBackgroundColor',
    }
    assert len(interpreter.traits) == 1
    assert interpreter.traits[0].is_method()
    assert interpreter.traits[0].method.is_function()

# Generated at 2022-06-24 14:29:50.531341
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # This tests the constructor of SWFInterpreter by checking if the
    # global variable 'String' is present
    filename = os.path.join(os.path.dirname(__file__),
                            'flash', 'playerProductInstall.swf')
    swf = SWFInterpreter(filename)
    assert swf.globals['String'] is not None

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-24 14:29:58.074264
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    # This function must be named test__ScopeDict
    # Otherwise it wouldn't be executed by `python -m unittest tests.test_swf`
    import unittest
    class ScopeDictTest(unittest.TestCase):
        def test_dict(self):
            class DummyAVMClass(object):
                pass
            dummy_avm_class = DummyAVMClass()
            dummy_avm_class.name = 'DummyAVMClass'
            my_dict = _ScopeDict(dummy_avm_class)
            my_dict['foo'] = 'bar'
            self.assertEqual(repr(my_dict), 'DummyAVMClass__Scope({\'foo\': \'bar\'})')
    unittest.main()



# Generated at 2022-06-24 14:30:01.141147
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    d = _ScopeDict(None)
    d[1] = 2
    d[3] = 4
    assert d == {1: 2, 3: 4}



# Generated at 2022-06-24 14:30:12.748836
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    klass = _AVMClass(0, 'Foo')
    first_methods = {
        'func1': 1,
        'func2': 2,
    }
    second_methods = {
        'func3': 3,
        'func2': 4,
    }
    klass.register_methods(first_methods)
    klass.register_methods(second_methods)
    assert klass.method_names == {
        'func1': 1,
        'func2': 4,
        'func3': 3,
    }
    assert klass.method_idxs == {
        1: 'func1',
        3: 'func3',
        4: 'func2',
    }



# Generated at 2022-06-24 14:30:16.296749
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class Cls(object):
        name = 'foo'
    assert '%r' % _ScopeDict(Cls()) == 'foo__Scope({})'
test__ScopeDict()



# Generated at 2022-06-24 14:30:28.014616
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(None, 'TestClass')
    avm_class.register_methods({1: 'method1', 2: 'method2'})
    assert avm_class.method_names == {1: 'method1', 2: 'method2'}
    assert avm_class.method_idxs == {1: 'method1', 2: 'method2'}
    avm_class.register_methods({3: 'method3'})
    assert avm_class.method_names == {1: 'method1', 2: 'method2', 3: 'method3'}
    assert avm_class.method_idxs == {1: 'method1', 2: 'method2', 3: 'method3'}



# Generated at 2022-06-24 14:30:38.102937
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    expected_output = (
        'avm_class_NameSpace_public: OrderedDict([(static_properties, OrderedDict([(' +
        'uri, http://www.w3.org/2005/07/scxml)])), (variables, OrderedDict([(qname, ' +
        'OrderedDict([(prefix, ), (localName, qname), (uri, urn:oasis:names:tc:QU' +
        'MLC:2.0:core)]))])), (methods, OrderedDict())])\n')
    interp = SWFInterpreter(open(
        '../test/oasis.log', 'rb'))
    assert str(interp.avm_classes['NameSpace::public']) == expected_output


# Generated at 2022-06-24 14:30:43.472513
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class SomeClass(object):
        pass
    assert repr(_ScopeDict(SomeClass)) == 'SomeClass__Scope({})'
    assert repr(_ScopeDict(SomeClass(name='some name'))) == 'SomeClass0x...__Scope({})'
    assert repr(_ScopeDict(SomeClass(), {'a': 1, 'b': 2})) == "SomeClass0x...__Scope({'a': 1, 'b': 2})"
test__ScopeDict()



# Generated at 2022-06-24 14:30:46.240452
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class AVMClass(object):
        def __init__(self, name):
            self.name = name

    o = _AVMClass_Object(AVMClass('a'))
    assert o.avm_class.name == 'a'



# Generated at 2022-06-24 14:30:48.885637
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert (_AVMClass_Object(object()).__repr__() ==
            '%s#%x' % (repr(object()), id(object())))



# Generated at 2022-06-24 14:30:50.144702
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    _AVMClass(1, b'SomeClass')



# Generated at 2022-06-24 14:30:57.493897
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    c1 = _AVMClass(name='class name 1')
    c2 = _AVMClass(name='class name 2')
    o1 = _AVMClass_Object(c1)
    o2 = _AVMClass_Object(c2)

    assert repr(o1) == 'class name 1#%x' % id(o1)
    assert repr(o2) == 'class name 2#%x' % id(o2)
    return True



# Generated at 2022-06-24 14:31:01.520482
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    avm_class = _AVMClass()
    avm_class.name = 'abc'
    obj = _AVMClass_Object(avm_class)
    assert repr(obj).startswith('abc#')


# Generated at 2022-06-24 14:31:11.027979
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class AVMClass1(object):
        pass
    c1 = AVMClass1()
    c1.static_properties = {}
    c1.method_names = {}
    c1.static_properties = {}
    c1.method_pyfunctions = {}
    c1.variables = {}
    c1.variables['x'] = 'x-value'
    c1.variables['y'] = 'y-value'

    class AVMClass2(object):
        pass
    c2 = AVMClass2()
    c2.static_properties = {}
    c2.method_names = {}
    c2.method_pyfunctions = {}
    c2.variables = {}

    si = SWFInterpreter(None)
    si.extract_function(c1, 'foobar')
   

# Generated at 2022-06-24 14:31:12.343868
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    obj = _AVMClass_Object('class_name')
    assert repr(obj) == 'class_name#%x' % id(obj)



# Generated at 2022-06-24 14:31:14.960836
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert repr(_AVMClass(1, 'foo', {'a': 2})) == "_AVMClass('foo')"



# Generated at 2022-06-24 14:31:21.723003
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert not bool(_Undefined())
    assert not isinstance(None, _Undefined)
    assert not isinstance(_Undefined(), _Undefined)
    assert _Undefined() == _Undefined()
    assert not isinstance(_Undefined(), bool)


_undefined = _Undefined()

