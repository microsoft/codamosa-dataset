

# Generated at 2022-06-24 14:21:30.062419
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x0d)) == '[MULTINAME kind: 0xd]'

MULTINAME_QNAME = 0x07
MULTINAME_QNAMEA = 0x0d
MULTINAME_RTQNAME = 0x0f
MULTINAME_RTQNAMEA = 0x10
MULTINAME_RTQNAMEL = 0x11
MULTINAME_RTQNAMELA = 0x12
MULTINAME_MULTINAME = 0x09
MULTINAME_MULTINAMEA = 0x0e
MULTINAME_MULTINAMEL = 0x1b
MULTINAME_MULTINAMELA = 0x1c



# Generated at 2022-06-24 14:21:32.588916
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():

    a_class = _AVMClass('name')
    a_object = _AVMClass_Object(a_class)
    assert repr(a_object) == 'name#%x' % id(a_object)


# Generated at 2022-06-24 14:21:42.559407
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-24 14:21:47.437576
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # print(SWFInterpreter.__init__.__dict__)
    pass
# class SWFInterpreter(object):
#     def __init__(self, swf):
#         self.swf = swf
#         self.constant_strings = []
#         self.multinames = []
#         self.method_defs = {}
#         self.class_defs = {}
#         self.method_pyfunctions = {}
#         self.method_names = []
#         self.classes = {}
#         self.instances = {}
#         self.functions = {}
#         self.strings = {}
#         self.obj_pools = {}
#         self.var_name_to_idx = {}
#         self.method_body_info_cache = {}
#         self.

# Generated at 2022-06-24 14:21:56.093609
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-24 14:21:57.107272
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'


undefined = _Undefined()



# Generated at 2022-06-24 14:22:00.894714
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _AVMClass_Object(object):
        def __init__(self, name):
            self.name = name
    scope = _ScopeDict(_AVMClass_Object('Object'))
    scope['foo'] = 42
    scope['bar'] = 'hello'
    assert repr(scope) == "_AVMClass_Object__Scope({'foo': 42, 'bar': 'hello'})"



# Generated at 2022-06-24 14:22:03.312750
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    data = compat_urllib_request.urlopen(
        'https://github.com/rg3/youtube-dl/raw/master/youtube_dl/extractor/youtube.swf').read()
    swf = SWFInterpreter(data)



# Generated at 2022-06-24 14:22:04.645856
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    '''_Undefined.__bool__'''
    test_obj = _Undefined()
    assert bool(test_obj) == False

# Generated at 2022-06-24 14:22:05.642863
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


# Generated at 2022-06-24 14:22:08.035967
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(kind=0xb).kind == 0xb



# Generated at 2022-06-24 14:22:18.669118
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .extractor_abc import ABC
    from .utils import (
        parse_flashvar_value,
    )

    abc_xml = ABC('<abc></abc>')

# Generated at 2022-06-24 14:22:21.583909
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    class_obj = _AVMClass('Foo', 1).make_object()
    assert class_obj.avm_class.name == 'Foo'
    assert isinstance(class_obj.avm_class, _AVMClass)



# Generated at 2022-06-24 14:22:22.117842
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    assert True



# Generated at 2022-06-24 14:22:25.536725
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    c = _AVMClass('Foo')
    d = _ScopeDict(c)
    assert repr(d) == 'Foo__Scope({})'
    d['a'] = 'A'
    assert repr(d) == 'Foo__Scope({\'a\': \'A\'})'
test__ScopeDict___repr__()



# Generated at 2022-06-24 14:22:28.294385
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():

    class Dummy(object):
        def __init__(self):
            self.method_names = set()

    interp = SWFInterpreter(None)
    dummy = Dummy()

    @interp.patch_function(dummy, 'foo')
    def foo(args):
        return args

    assert dummy.foo(['a', 'b']) == ['a', 'b']
    assert 'foo' in dummy.method_names

# Generated at 2022-06-24 14:22:29.656472
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert swf_interpreter.patch_function() # TODO: implement your test here


# Generated at 2022-06-24 14:22:31.983602
# Unit test for constructor of class _Undefined
def test__Undefined():
    undef = _Undefined()
    assert not bool(undef)
    assert bool(not undef)
    assert not undef
    assert undef != 0
    assert hash(undef) == 0
    assert str(undef) == 'undefined'
    assert repr(undef) == 'undefined'



# Generated at 2022-06-24 14:22:32.901338
# Unit test for constructor of class _Multiname
def test__Multiname():
    a = 1
    assert _Multiname(a).kind == 1


# Generated at 2022-06-24 14:22:38.356102
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .f4m import (
        _extract_stream_metadata,
    )

    # https://gist.github.com/rg3/9222867

# Generated at 2022-06-24 14:22:48.738871
# Unit test for method __repr__ of class _ScopeDict

# Generated at 2022-06-24 14:22:55.261970
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    obj = _AVMClass('Foo', {'bar': 'baz'})
    assert obj.name == 'Foo'
    assert obj.static_properties == {'bar': 'baz'}
    assert obj.method_names == {}
    assert obj.method_idxs == {}
    assert obj.methods == {}
    assert obj.method_pyfunctions == {}
    assert obj.variables == _ScopeDict(obj)
    assert obj.constants == {}



# Generated at 2022-06-24 14:22:59.329739
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class Foo:
        def __init__(self, name):
            self.name = name
    obj = _AVMClass_Object(Foo('bar'))
    assert obj.avm_class.name == 'bar'



# Generated at 2022-06-24 14:23:00.793575
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter('a.swf')
    swf.extract_class(0)

# Generated at 2022-06-24 14:23:02.528387
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass(1, 'UnitTest')
    assert cls.name == 'UnitTest'
    assert cls.name_idx == 1



# Generated at 2022-06-24 14:23:03.629830
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    _AVMClass_Object(None)



# Generated at 2022-06-24 14:23:06.921783
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    std = _ScopeDict(_AVMClass_Object(AVMClass('foo', None)))
    assert repr(std) == 'foo__Scope({})'
    std['a'] = 'b'
    assert repr(std) == "foo__Scope({'a': 'b'})"



# Generated at 2022-06-24 14:23:10.433038
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class _AVMClass(object):
        def __init__(self, name):
            self.name = name
    o = _AVMClass_Object(_AVMClass('foo'))
    assert o.avm_class.name == 'foo'
    assert 'foo' in repr(o)



# Generated at 2022-06-24 14:23:22.145176
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter()
    assert swf_interpreter.constant_strings == []
    assert swf_interpreter.multinames == []
    assert swf_interpreter.classes == []
    assert swf_interpreter.strings == []
    assert swf_interpreter.floats == []
    assert swf_interpreter.namespaces == []
    assert swf_interpreter.namespace_sets == []
    assert swf_interpreter.methods == []
    assert swf_interpreter.metadata == []
    assert swf_interpreter.instance_infos == []
    assert swf_interpreter.class_infos == []
    assert swf_interpreter.scripts == []
    assert swf_interpreter.method_

# Generated at 2022-06-24 14:23:25.542706
# Unit test for constructor of class _Undefined
def test__Undefined():
    a = _Undefined()
    assert a == a
    b = _Undefined()
    assert a == b
    assert hash(a) == hash(b)


Undefined = _Undefined()



# Generated at 2022-06-24 14:23:28.009331
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class TestAVMClass(object):
        name = 'TestAVMClass'
    d = _ScopeDict(TestAVMClass)
    d['k'] = 'v'
    assert repr(d) == "TestAVMClass__Scope({'k': 'v'})"



# Generated at 2022-06-24 14:23:32.019819
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
    assert hash(_Undefined()) == hash(_Undefined())
    assert hash(_Undefined()) != hash(object())


# Generated at 2022-06-24 14:23:38.687450
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(0, 'Test')
    c.register_methods({'foo': 2})
    c.register_methods({'bar': 3})
    assert c.method_names == {'foo': 2, 'bar': 3}
    assert c.method_idxs == {2: 'foo', 3: 'bar'}
    c.register_methods({'bar': 4, 'baz': 5})
    assert c.method_names == {'foo': 2, 'bar': 4, 'baz': 5}
    assert c.method_idxs == {2: 'foo', 4: 'bar', 5: 'baz'}



# Generated at 2022-06-24 14:23:44.489003
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(None, None, None)
    methods = {'method1': 1, 'method2': 2, 'method3': 3}
    avm_class.register_methods(methods)
    assert avm_class.method_names == methods
    assert avm_class.method_idxs == {
        1: 'method1',
        2: 'method2',
        3: 'method3',
    }



# Generated at 2022-06-24 14:23:46.710594
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    m = _Multiname(1)
    expected = '[MULTINAME kind: 0x1]'
    actual = repr(m)
    assert expected == actual

# Generated at 2022-06-24 14:23:52.892071
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = _SWFInterpreter(None)


# Generated at 2022-06-24 14:23:57.196395
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    ScopeDict = _ScopeDict(_AVMClass_Object(_AVMClass_Object(None)))
    assert repr(ScopeDict) == '_AVMClass_Object#%x__Scope({})' % id(ScopeDict)
    ScopeDict['foo'] = 'bar'
    assert repr(ScopeDict) == '_AVMClass_Object#%x__Scope({\'foo\': \'bar\'})' % id(ScopeDict)



# Generated at 2022-06-24 14:23:58.779227
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    _ScopeDict(_AVMClass_Object('foo.bar')).__repr__()



# Generated at 2022-06-24 14:24:10.015467
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_utils import load_swf_movie
    from .abc_compiler import ABCFile

    movie = load_swf_movie('../swfextract/test/swfs/test0_compressed.swf')
    swf_compilation = SWFCompilation(movie)
    swf_compilation.decompile()

    # This is just a simple example to test the SWFInterpreter.extract_function
    # method.

# Generated at 2022-06-24 14:24:11.846137
# Unit test for constructor of class _Undefined
def test__Undefined():
    a = _Undefined()
    b = _Undefined()
    assert a is b


_undefined = _Undefined()



# Generated at 2022-06-24 14:24:19.082554
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(
        name_idx=0,
        name='foo',
        static_properties=dict(a='b'),
        )
    o = avm_class.make_object()
    assert o.avm_class == avm_class
    assert isinstance(avm_class.variables, _ScopeDict)
    assert isinstance(avm_class.method_names, dict)
    assert isinstance(avm_class.method_idxs, dict)
    assert isinstance(avm_class.methods, dict)
    assert isinstance(avm_class.static_properties, dict)
    assert 'a' in avm_class.variables
    assert 'a' in avm_class.static_properties
    assert 'a' in o.avm_class.vari

# Generated at 2022-06-24 14:24:21.225181
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    t = _AVMClass('t', 't')
    assert repr(t) == '_AVMClass(t)'

# Generated at 2022-06-24 14:24:25.181560
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class MyClass(object):
        pass
    m = MyClass()
    obj = _AVMClass_Object(m)
    assert obj.avm_class is m
    assert obj.__dict__ == {}



# Generated at 2022-06-24 14:24:29.965412
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import amf0
    from .amf0 import _decode
    from .swf_tag import DoAction
    from .swf_tag_rendering import _read_swf

    raw_swf = open('tests/swf/PlayerProductInstall.swf', 'rb').read()
    swf = _read_swf(raw_swf)
    action_tag = swf.tags[12]
    assert isinstance(action_tag, DoAction)
    assert action_tag.symbol_class.sprite == 11
    assert action_tag.symbol_class.name == '_level0'

    # read tag with id 11
    action_script = swf.tags[11]

    # test get_amf_data method

# Generated at 2022-06-24 14:24:42.096734
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    def _create_coder(bytecode):
        coder = BytesIO()
        coder.write(bytecode)
        coder.seek(0)
        return coder
    # int
    coder = _create_coder(b'\x01\x00\x00\x00')
    interpreter = SWFInterpreter(None, None)
    res = interpreter.extract_class(coder)
    assert res == 1
    # string
    coder = _create_coder(b'\x01\x00\x05\x48\x65\x6c\x6c\x6f')
    interpreter = SWFInterpreter(None, None)
    res = interpreter.extract_class(coder)
    assert res == 'Hello'
    # multiname
    coder

# Generated at 2022-06-24 14:24:48.438099
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    file_path = os.path.join(os.path.dirname(__file__),
                             u'..', u'..', u'data', u'flash',
                             u'cmd_test_decoder.swf')
    with open(file_path, 'rb') as f:
        data = f.read()
    SWFInterpreter(data)

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-24 14:24:56.796629
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-24 14:25:02.951862
# Unit test for constructor of class _ScopeDict

# Generated at 2022-06-24 14:25:14.733734
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(5, 'URL')
    assert avm_class.method_names == {}
    assert avm_class.method_idxs == {}
    avm_class.register_methods(
        dict((name, 123 + i) for i, name in enumerate(
            ('toString', 'load', 'send', 'loadVariables', 'sendAndLoad'))))
    assert avm_class.method_names == {
        'toString': 123,
        'load': 124,
        'send': 125,
        'loadVariables': 126,
        'sendAndLoad': 127,
    }
    assert avm_class.method_idxs == dict(
        (idx, name)
        for name, idx in avm_class.method_names.items())
    return True


# Generated at 2022-06-24 14:25:19.193684
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    v = _AVMClass('name', {'1': '2'})
    assert repr(v) == "_AVMClass('name')"

# Generated at 2022-06-24 14:25:23.631213
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert _Multiname(0).__repr__() == '[MULTINAME kind: 0x0]'
    assert _Multiname(1).__repr__() == '[MULTINAME kind: 0x1]'
    assert _Multiname(0x1234567890).__repr__() == '[MULTINAME kind: 0x1234567890]'



# Generated at 2022-06-24 14:25:26.766496
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(None)
    return repr(obj)
_Multiname.test__Multiname___repr__ = test__Multiname___repr__



# Generated at 2022-06-24 14:25:32.205100
# Unit test for constructor of class _Undefined
def test__Undefined():
    val = _Undefined()
    assert not val
    assert not val.any_attribute
    assert 0 == hash(val)
    assert str(val) == 'undefined'
    assert repr(val) == 'undefined'
test__Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:25:38.560000
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    def f(): pass
    c = _AVMClass(1, '', {'a': f})
    o = c.make_object()
    assert o.avm_class is c
    assert o.__dict__ == {}

# Generated at 2022-06-24 14:25:51.022519
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-24 14:25:58.550782
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from nose.tools import assert_equals, assert_is_instance
    from collections import namedtuple
    MyClass = namedtuple('MyClass', ['name_idx', 'name'])
    avm_class = MyClass(name_idx=0, name='MyClass')
    actual_result = _AVMClass_make_object(avm_class)
    assert_is_instance(actual_result, _AVMClass_Object)
    assert_equals(actual_result.avm_class, avm_class)

# Generated at 2022-06-24 14:26:11.641342
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    test_class = _AVMClass(
        name_idx=0x1abc,
        name='foo',
        static_properties={'a': 'static', 'b': 'property'},
    )
    assert test_class.name_idx == 0x1abc
    assert test_class.name == 'foo'
    assert test_class.method_names == {}
    assert test_class.method_idxs == {}
    assert test_class.methods == {}
    assert test_class.method_pyfunctions == {}
    assert test_class.static_properties == {'a': 'static', 'b': 'property'}
    assert test_class.variables == {'__class__': test_class}
    assert test_class.constants == {}

    assert test_class.make_object().avm_class

# Generated at 2022-06-24 14:26:20.293945
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf import SWFParser
    from .abc import ABCParser
    from .abc import ABCInterpreter

    for name in ['../../test/as3/TestFunction.swf']:
        with open(name, 'rb') as f:
            swfp = SWFParser(f.read())
        swfp.parse_swf_file()
        # import IPython; IPython.embed()
        for tag in swfp.tags:
            if hasattr(tag, 'abc'):
                abcp = ABCParser(tag.abc)
                abcp.parse()
                abci = ABCInterpreter(abcp.abc)
                abci.extract_method_pyfunctions()

# Generated at 2022-06-24 14:26:30.198433
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    avm_interpreter = SWFInterpreter(b'FWS')
    assert avm_interpreter
    assert avm_interpreter.version == 0
    assert avm_interpreter.file_sig == b'FWS'
    assert avm_interpreter.file_len == 0
    assert avm_interpreter.frame_size == (0, 0, 0, 0)
    assert avm_interpreter.frame_rate == 0
    assert avm_interpreter.frame_count == 0

    # Unknown / unsupported signature
    with pytest.raises(IOError):
        SWFInterpreter(b'FOOBAR')


# Generated at 2022-06-24 14:26:42.395814
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    swf = SWFInterpreter(BytesIO(b'\x00\x00\x00\x00\x00\x00\x00\x00'))
    class dummy(object):
        pass
    avm_class = dummy()
    res = swf.patch_function(avm_class, b'\x00')
    assert res is None
    try:
        res = swf.patch_function(avm_class, b'\x02')
        assert False, 'Expected SWFDecompressionError'
    except SWFDecompressionError:
        pass

# Generated at 2022-06-24 14:26:46.905649
# Unit test for constructor of class _Undefined
def test__Undefined():
    import pytest
    u = _Undefined()
    assert u != u
    assert u == None
    assert not u
    assert hash(u) == 0
    assert str(u) == 'undefined'
    assert not hasattr(u, '__len__')
    assert not hasattr(u, '__iter__')
test__Undefined()



# Generated at 2022-06-24 14:26:48.401838
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    return _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:26:54.639548
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class Foo(object):
        pass
    foo_class = Foo()
    foo_object = _AVMClass_Object(foo_class)
    assert foo_object.avm_class == foo_class


_SHAPE_RECORD_TYPE_END = 0
_SHAPE_RECORD_TYPE_STYLECHANGE = 1
_SHAPE_RECORD_TYPE_STRAIGHTEDGE = 2
_SHAPE_RECORD_TYPE_CURVEDEDGE = 3



# Generated at 2022-06-24 14:26:58.873207
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_foo = _AVMClass('foo')
    obj = _AVMClass_Object(class_foo)
    assert obj.avm_class is class_foo
    assert repr(obj) == 'foo#%x' % id(obj)
test__AVMClass_Object()



# Generated at 2022-06-24 14:27:01.296106
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    """_AVMClass.make_object"""
    obj = _AVMClass('Foo', 0, {}).make_object()
    assert isinstance(obj, _AVMClass_Object)
    assert obj.avm_class.name == 'Foo'



# Generated at 2022-06-24 14:27:08.179841
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(name_idx=3, name='SomeClass', static_properties=dict(x=1))
    assert c.name_idx == 3
    assert c.name == 'SomeClass'
    assert c.static_properties == dict(x=1)
    assert c.variables == {}
    assert c.constants == {}

    o = c.make_object()
    assert o.avm_class is c



# Generated at 2022-06-24 14:27:09.308208
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:27:11.502031
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    _AVMClass(3, 'foo').__repr__()
test__AVMClass___repr__()

# Generated at 2022-06-24 14:27:14.249194
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    global _Undefined
    obj = _Undefined()
    assert str(obj) == 'False'
    assert obj.__bool__() == False
    assert obj.__nonzero__() == False
    return
test__Undefined___bool__()


# Generated at 2022-06-24 14:27:15.786132
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert _AVMClass_Object(object).__repr__() == 'object#%x' % id(_AVMClass_Object(object))



# Generated at 2022-06-24 14:27:16.817029
# Unit test for constructor of class _Undefined
def test__Undefined():
    __Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:27:22.147501
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass('test', {'a': 1, 'b': 2}, static_properties={'c': 3})
    assert c.make_object().avm_class == c



# Generated at 2022-06-24 14:27:26.371930
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'
# End of unit tests for method __repr__ of class _Undefined

    def __add__(self, other):
        return other

    def __radd__(self, other):
        return other

# Generated at 2022-06-24 14:27:26.886367
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__(): pass


# Generated at 2022-06-24 14:27:28.729799
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    obj = SWFInterpreter()
    obj.extract_class(None, None)


# Generated at 2022-06-24 14:27:36.157387
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not bool(_Undefined())
    assert not _Undefined()
    assert _Undefined() == _Undefined()
    assert not (_Undefined() != _Undefined())
    assert _Undefined() != False
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'

_undefined = _Undefined()



# Generated at 2022-06-24 14:27:47.657604
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interp = SWFInterpreter(None)
    interp.constant_strings = ['v1', 'v2', 'v3', 'v4']
    interp.multinames = [
        '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']

    # from flash.filters import BlurFilter
    interp.extract_function(
        'flash.filters.BlurFilter', 'BlurFilter')([])

    # from flash.filters import DropShadowFilter
    interp.extract_function(
        'flash.filters.DropShadowFilter', 'DropShadowFilter')([])

    # from flash.filters import ShaderFilter

# Generated at 2022-06-24 14:27:49.320975
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    x = _AVMClass(0, '')
    x._AVMClass__repr__()



# Generated at 2022-06-24 14:27:58.341779
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import decompile_method
    from .swfdecompiler import get_abce_method
    from .jsinterpreter import JSInterpreter
    from .jsinterpreter import _get_function_param_names

    def run_js_code(code, args):
        from . import jsinterpreter
        jsfunc = jsinterpreter.JSInterpreter(
            code, _get_function_param_names(code)).interpret()
        res = jsfunc(**args)
        return res
    def run_swf_code(code, args):
        abce_method = get_abce_method(code)

# Generated at 2022-06-24 14:28:00.170634
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    m = _AVMClass('test', 'test')
    o = m.make_object()
    assert repr(o) == 'test#%x' % id(o)

# Generated at 2022-06-24 14:28:05.053597
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swfinterpreter = SWFInterpreter()
    swfinterpreter.method_name = 'dummy_method_name'
    swfinterpreter.constant_strings = []
    swfinterpreter.constant_strings.append('dummy_constant_string')
    swfinterpreter.constant_strings.append('dummy_constant_string2')
    swfinterpreter.multinames = []
    swfinterpreter.multinames.append('dummy_multiname')
    swfinterpreter.multinames.append(1)
    swfinterpreter.multinames.append('dummy_multiname2')
    swfinterpreter.multinames.append(2)

# Generated at 2022-06-24 14:28:09.675733
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert _Multiname(0x0A).__repr__() == '[MULTINAME kind: 0xa]'
    assert _Multiname(0x1B).__repr__() == '[MULTINAME kind: 0x1b]'

# Generated at 2022-06-24 14:28:11.032392
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


Undefined = _Undefined()



# Generated at 2022-06-24 14:28:13.475071
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass(0, '')
    assert isinstance(avm_class.make_object(), _AVMClass_Object)



# Generated at 2022-06-24 14:28:19.460887
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(None, 'Test', {})
    assert avm_class.name == 'Test'
    assert avm_class.variables == {}
    assert avm_class.constants == {}


Op = collections.namedtuple(
    'Op', ['name', 'nargs', 'code', 'impl'])


# Generated at 2022-06-24 14:28:25.642993
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    # A test method for the _AVMClass_Object class
    #
    # -> __repr__
    # Get a real _AVMClass_Object instance from _TamarinFlash
    instance = _TamarinFlash().classes['flash.utils.ByteArray'](None)
    assert repr(instance) == 'ByteArray#%x' % id(instance)

# Generated at 2022-06-24 14:28:33.851455
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass('String', {'indexOf': 1, 'substring': 2})
    assert class_.name == 'String'
    assert class_.method_names == {'indexOf': 1, 'substring': 2}
    assert class_.method_idxs == {1: 'indexOf', 2: 'substring'}
    assert class_.methods == {}
    assert class_.method_pyfunctions == {}
    assert isinstance(class_.variables, _ScopeDict)
    assert class_.variables.avm_class == class_
    assert class_.constants == {}


_AVM_TYPE_NUMBER = 0
_AVM_TYPE_BOOLEAN = 1
_AVM_TYPE_STRING = 2
_AVM_TYPE_OBJECT = 3
_AVM_TYPE_MOVIEC

# Generated at 2022-06-24 14:28:35.929204
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert '_Scope(dict_items([(6, \'1\')]))' == repr(_ScopeDict(None, {6: 1}))



# Generated at 2022-06-24 14:28:41.866210
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert _AVMClass_Object(_AVMClass_Object).avm_class is _AVMClass_Object
    assert repr(_AVMClass_Object(_AVMClass_Object)) == (
        '_AVMClass_Object#%x' % id(_AVMClass_Object(_AVMClass_Object)))


_AVM_Class = collections.namedtuple('_AVM_Class', ['name', 'constructor'])


# Some built-in AVM classes
_AVMClass_Object = _AVM_Class(
    'Object', _AVMClass_Object)



# Generated at 2022-06-24 14:28:47.504494
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open(os.path.join(
            os.path.dirname(__file__), 'tests/data/test_0.swf')) as f:

        data = f.read()

    swf_interpreter = SWFInterpreter(data)

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-24 14:28:57.462224
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    test_obj = _ScopeDict(_AVMClass_Object(_AVMClass_Object(_AVMClass_Object(_AVMClass_Object(None)))))
    assert repr(test_obj) == '<...>.<...>.<...>.<...>__Scope(%s)' % repr(dict())
    test_obj = _ScopeDict(_AVMClass_Object(_AVMClass_Object(_AVMClass_Object(_AVMClass_Object(None)))))
    test_obj[0] = 0
    assert repr(test_obj) == '<...>.<...>.<...>.<...>__Scope(%s)' % repr({0: 0})



# Generated at 2022-06-24 14:28:58.589576
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    pytest.skip()



# Generated at 2022-06-24 14:29:00.263819
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    assert test_AVMClass.make_object() is not None



# Generated at 2022-06-24 14:29:02.023348
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    print(repr(_AVMClass('a', 'b')))



# Generated at 2022-06-24 14:29:12.859212
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.opcode_table[0x21] = lambda coder: None
    swf_interpreter.opcode_table[0x1A] = lambda coder: None
    swf_interpreter.opcode_table[0x09] = lambda coder: None
    swf_interpreter.opcode_table[0x03] = lambda coder: None
    swf_interpreter.opcode_table[0x81] = lambda coder: None
    swf_interpreter.opcode_table[0x11] = lambda coder: None
    swf_interpreter.opcode_table[0x23] = lambda coder: None

# Generated at 2022-06-24 14:29:19.360702
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Create a dummy ClassInfo
    classinfo = _ClassInfo()
    classinfo.instance_info.name_index = 1
    classinfo.instance_info.ns_index = 2

    # Create a dummy ScriptInfo
    scriptinfo = _ScriptInfo()
    scriptinfo.class_info = classinfo

    # Create a dummy ABCFile

# Generated at 2022-06-24 14:29:20.648978
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(None)) == '#%x' % id(None)


# Generated at 2022-06-24 14:29:29.100048
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(0, 'foo', {})
    c.register_methods(
        collections.OrderedDict(
            ['sayHi'
                , 'sayBye'
                , 'sayHello'
                ]
        )
    )

    assert c.method_names == {
        'sayHi': 0,
        'sayBye': 1,
        'sayHello': 2,
    }
    assert c.method_idxs == {
        0: 'sayHi',
        1: 'sayBye',
        2: 'sayHello',
    }



# Generated at 2022-06-24 14:29:39.960913
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    t = SWFInterpreter()

    # init__()
    def func(args):
        assert len(args) == 1
        assert args[0] == 1
        return 'done'
    t.patch_function('init__', func)
    assert t.method_pyfunctions['init__'] == func

    # init()
    def func(args):
        assert len(args) == 0
        return 'done'
    t.patch_function('init', func)
    assert t.method_pyfunctions['init'] == func

    # String.split()
    def func(args):
        assert len(args) == 1
        assert isinstance(args[0], compat_str)
        return ['done']
    t.patch_function('String', 'split', func)

# Generated at 2022-06-24 14:29:43.693771
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = _get_test_swf()
    avminterp = SWFInterpreter(swf)
    avminterp.extract_class('MainTimeline')

# Generated at 2022-06-24 14:29:47.684642
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_info = SWFInfo('test1.swf')
    interpreter = SWFInterpreter(swf_info)
    interpreter.patch_method('_root', 'Frame1', '$init')


# Generated at 2022-06-24 14:29:56.675237
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from .test_cmdline import parse_to_json

# Generated at 2022-06-24 14:30:09.038945
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    _Multiname(12).__repr__()

# ----------------------------------------------------------------------
# Very basic support for interpreting SWF tags

ACTION_PUSH = 0x96
ACTION_POP = 0x17
ACTION_ADD = 0xa0
ACTION_SUBTRACT = 0xa1
ACTION_MULTIPLY = 0xa2
ACTION_DIVIDE = 0xa3
ACTION_GET_VARIABLE = 0x1c
ACTION_SET_VARIABLE = 0x1d
ACTION_GET_ATTRIBUTE = 0x23
ACTION_SET_ATTRIBUTE = 0x24
ACTION_NEW_OBJECT = 0x40
ACTION_NEW_METHOD = 0x53
ACTION_NEW_ARRAY = 0x56
ACTION_GET_MEMBER = 0x4e
ACTION_SET_MEMBER = 0x4f
ACTION_

# Generated at 2022-06-24 14:30:20.026994
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf1 = utils.get_test_data_file(
        'video.visitmix.com.swf').read()
    swf2 = utils.get_test_data_file(
        'video.visitmix.com-2.swf').read()
    assert swf1 != swf2
    assert b'function' not in swf1
    assert b'function' in swf2
    obj = SWFInterpreter(swf1)
    obj2 = SWFInterpreter(swf2)
    assert swf1 != swf2
    obj.patch_function(obj2.functions)
    assert swf1 == swf2

# Generated at 2022-06-24 14:30:23.737238
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    item = _AVMClass_Object(_AVMClass_Object)
    assert repr(item) == 'test_swf._AVMClass_Object#%x' % id(item), \
        'Got %r' % repr(item)

test__AVMClass_Object()



# Generated at 2022-06-24 14:30:32.080749
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()

    def print_func(x):
        print(x)

    def eval_func(x):
        return eval(x)

    interpreter.patch_function('print', print_func)
    interpreter.patch_function('eval', eval_func)

    # Test patching and unpatching
    interpreter.patch_function('print', None)
    assert interpreter.patch_function('print', None) is None
    assert interpreter.patch_function('eval', None) is not None

    # Test patching and unpatching a non-existing function
    assert interpreter.patch_function('abc', None) is None
    assert interpreter.patch_function('abc', print_func) is print_func
    assert interpreter.patch_function('abc', None) is print_func

    # Test unpatching with patching a non-existing function

# Generated at 2022-06-24 14:30:32.948367
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert bool(hash(_Undefined()))
    print('Passed.')

# Generated at 2022-06-24 14:30:34.676074
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert repr(_AVMClass_Object(None)) == '_AVMClass_Object#0xffff'
    assert repr(_AVMClass_Object(object)) == 'object#0xffff'



# Generated at 2022-06-24 14:30:45.418335
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from avm2.SWF import parse_swf
    from avm2.ABC import ABCParser
    from avm2.ABC import ABCEmitter
    from avm2.ABC import parse_method

    abc_parser = ABCParser(b'\x03\x00\x03\x00+\x00\x00\x00p')
    abc_emitter = ABCEmitter(abc_parser.constant_pool)


# Generated at 2022-06-24 14:30:51.481383
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(1, 'Test', static_properties={42: 'foo'})
    assert isinstance(avm_class.variables, _ScopeDict)
    assert isinstance(avm_class.make_object(), _AVMClass_Object)
    assert '42' in repr(avm_class)



# Generated at 2022-06-24 14:30:54.916327
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(3)
    expected = '[MULTINAME kind: 0x3]'
    assert obj.__repr__() == expected
test__Multiname___repr__()



# Generated at 2022-06-24 14:30:58.900183
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    a = _AVMClass_Object(_AVMClass('MovieClip', None, None))
    if a.__repr__() != 'MovieClip#27a3c80':
        raise AssertionError



# Generated at 2022-06-24 14:31:07.496733
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    o = _AVMClass('Test', static_properties={'foo': 1, 'bar': 2})
    assert o.name == 'Test'
    assert o.static_properties['foo'] == 1
    assert o.static_properties['bar'] == 2
    assert o.method_names == {}

    o.register_methods({'foobar': 1, 'barfoo': 2})
    assert o.method_names['foobar'] == 1
    assert o.method_names['barfoo'] == 2
    assert o.method_idxs[1] == 'foobar'
    assert o.method_idxs[2] == 'barfoo'



# Generated at 2022-06-24 14:31:13.486967
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avmclass = _AVMClass(0, 'Foo', {'bar': 'baz', 'aaa': 'bbb'})
    assert avmclass.name == 'Foo'
    assert avmclass.static_properties == {'bar': 'baz', 'aaa': 'bbb'}
    assert avmclass.variables == {'bar': 'baz', 'aaa': 'bbb'}
    assert 'bar' in avmclass.variables
    assert 'aaa' in avmclass.variables
    assert 'undefined' not in avmclass.variables
    assert avmclass.method_names == {}
    assert avmclass.method_idxs == {}
    assert avmclass.methods == {}
    assert avmclass.constants == {}

# Generated at 2022-06-24 14:31:19.066224
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class_1 = _AVMClass(None, 'Class1')
    methods_1 = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    class_1.register_methods(methods_1)
    assert(class_1.method_names == dict(
        (name, idx) for name, idx in methods_1.items()))
    assert(class_1.method_idxs == dict(
        (idx, name) for name, idx in methods_1.items()))
test__AVMClass_register_methods()


# Generated at 2022-06-24 14:31:26.604689
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    obj = mock.Mock()
    i = SWFInterpreter()
    i.extract_function(obj, 'func')
    assert obj.method_pyfunctions == {'func': mock.ANY}
    assert len(obj.method_names) == 1
    assert obj.method_names[0] == 'func'
    assert obj.method_options == [{
        'option_kind': 1,
        'name': 'func',
        'val': 0,
        'flag': 0,
        'metadata': [],
    }]