

# Generated at 2022-06-24 14:21:20.812490
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(1)



# Generated at 2022-06-24 14:21:26.728163
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass('Test', {
        'foo':  1,
        'bar':  2,
        'baz':  3,
    })
    assert c.name == 'Test'
    assert c.static_properties == {
        'foo':  1,
        'bar':  2,
        'baz':  3,
    }


# Generated at 2022-06-24 14:21:36.947216
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import flash_parser
    import flash_parser.abcs
    swf = flash_parser.SWF()
    swf.parse_from_file('../test/swf/ABcData.swf')

    # Test if the constructor of class 'SWFInterpreter' can run without error
    interpreter = SWFInterpreter(swf)
    assert isinstance(interpreter, SWFInterpreter)
    # Test if all ABCs in the swf file are parsed
    assert len(interpreter.abc_codes) == 1
    # Test if all script codes are parsed
    assert len(interpreter.abc_codes[0].script_codes) == 1
    # Test if all method codes are parsed
    assert len(interpreter.abc_codes[0].script_codes[0].method_codes) == 1




# Generated at 2022-06-24 14:21:41.959422
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert str(
        _Multiname(
            kind=0x07)) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:21:43.101962
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    # Test no exception is raised
    _ScopeDict(None)



# Generated at 2022-06-24 14:21:44.773769
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    u = _Undefined()
    assert repr(u) == 'undefined'

# Generated at 2022-06-24 14:21:47.273114
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0



# Generated at 2022-06-24 14:21:55.912853
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # call_function is also used in test_SWF_method_call
    # so we test it properly in this place

    class MySWFInterpreterClass(object):
        constant_strings = ['class', 'function']
        multinames = [_Multiname('class', 0), _Multiname('function', 0)]
        strings = ['_avm_proto_', '_avm_class_']
        functions = [(0, 'main', 0)]
        classes = [('_avm_proto_', 0, {'_avm_proto_': '_avm_proto_', 'test': 1}),
                    ('_avm_class_', 0, {'_avm_proto_': '_avm_proto_', 'x': 2})]

# Generated at 2022-06-24 14:22:00.571667
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .utils import str_to_int
    assert eval(repr(_AVMClass_Object(None))) == _AVMClass_Object(None)
    assert eval(repr(_AVMClass_Object(None))) == _AVMClass_Object(None)
    assert eval(repr(_AVMClass_Object(None))) != _AVMClass_Object(None)
    assert eval(repr(_AVMClass_Object(None))) != _AVMClass_Object(None)



# Generated at 2022-06-24 14:22:02.966276
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Right now, the unit test is just checking that the method is not crashing

    interpreter = SWFInterpreter('dummy.swf', 'dummy.abc')
    interpreter.patch_function(interpreter.avm_class, '__init__')



# Generated at 2022-06-24 14:22:05.106043
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert str(_Undefined()) == 'undefined'
_undefined = _Undefined()



# Generated at 2022-06-24 14:22:06.743256
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    _ScopeDict(None)
    _ScopeDict(None).__repr__()



# Generated at 2022-06-24 14:22:17.994918
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interp = SWFInterpreter()
    interp.multinames = [None, 'var0', 'var1', 'substr_name']

# Generated at 2022-06-24 14:22:21.843223
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    avm_class = _AVMClass('name', 1, None, None, [])
    scope = _ScopeDict(avm_class)
    scope.update(a=1, b=2)
    assert ('%r' % scope) == "name__Scope({'a': 1, 'b': 2})", \
        ('%r' % scope)



# Generated at 2022-06-24 14:22:24.246228
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class Foo(object):
        pass
    scope = _ScopeDict(Foo())
    scope['foo'] = 'bar'
    assert repr(scope) == 'Foo__Scope({\'foo\': \'bar\'})'



# Generated at 2022-06-24 14:22:25.649758
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    """_Undefined.__repr__: returns 'undefined'"""
    _ = _Undefined()

Undefined = _Undefined()



# Generated at 2022-06-24 14:22:28.186283
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    instance = _AVMClass('name', 'name').make_object()
    assert isinstance(instance, _AVMClass_Object)
    assert isinstance(instance.avm_class, _AVMClass)



# Generated at 2022-06-24 14:22:34.718425
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(1, 'Foo')
    avm_class_object = avm_class.make_object()

    assert avm_class.name_idx == 1
    assert avm_class.name == 'Foo'
    assert avm_class.method_names == {}
    assert avm_class.method_idxs == {}
    assert avm_class.methods == {}
    assert avm_class.method_pyfunctions == {}
    assert avm_class.static_properties == {}

    assert avm_class is avm_class_object.avm_class
    assert avm_class.variables is not {}
    assert avm_class_object != avm_class.variables
    assert avm_class_object == avm_class_object
    assert av

# Generated at 2022-06-24 14:22:47.574395
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    from .utils import assertRaisesRegexp
    assertRaisesRegexp(
        ValueError,
        '^Kind 0x0 is not supported$',
        _Multiname,
        0)
    assertRaisesRegexp(
        ValueError,
        '^Kind 0x1 is not supported$',
        _Multiname,
        1)
    assertRaisesRegexp(
        ValueError,
        '^Kind 0x2 is not supported$',
        _Multiname,
        2)
    assertRaisesRegexp(
        ValueError,
        '^Kind 0x3 is not supported$',
        _Multiname,
        3)

# Generated at 2022-06-24 14:22:50.261619
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    # >> > print(str(Undefined))
    # undefined
    assert str(Undefined) == 'undefined'

# Generated at 2022-06-24 14:22:55.229827
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass('Test', ())
    c.register_methods({'a': 1, 'b': 2, 'c': 3})
    assert c.method_names == {'a': 1, 'b': 2, 'c': 3}
    assert c.method_idxs == {1: 'a', 2: 'b', 3: 'c'}



# Generated at 2022-06-24 14:22:58.022881
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    o = _AVMClass_Object(None)
    assert o.__repr__() == '#%x' % id(o)
test__AVMClass_Object___repr__()



# Generated at 2022-06-24 14:23:04.600258
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    flash_version = 9

    swf = SWF(open(os.path.join(os.path.dirname(__file__),
                                'swf_interpreter_test.swf'), 'rb'))
    swf.read_tags()

    interpreter = SWFInterpreter(swf, flash_version)

    swf_file = swf.file
    swf_file.seek(0)

    for tag in swf.iter_tags():
        if isinstance(tag, DoABC):
            abc = tag.abc
            for avm_class in abc.classes:
                for method in avm_class.methods:
                    if method.code is None:
                        continue
                    # print('Method:', method.name)

# Generated at 2022-06-24 14:23:07.682622
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    """Test method __repr__ of class _Undefined"""
    obj = class_._Undefined()
    res = obj.__repr__()
    assert res == 'undefined'
undefined = _Undefined()



# Generated at 2022-06-24 14:23:10.878178
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    scope_dict = _ScopeDict(None)
    scope_dict['a'] = 1
    scope_dict['b'] = 2
    assert repr(scope_dict) == 'None__Scope({\'a\': 1, \'b\': 2})'



# Generated at 2022-06-24 14:23:22.718529
# Unit test for constructor of class _AVMClass_Object

# Generated at 2022-06-24 14:23:32.104895
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert eval(repr(
        _ScopeDict(_AVMClass(b'Object', None))), {'_AVMClass': _AVMClass}) \
        == _ScopeDict(_AVMClass(b'Object', None))

# Generated at 2022-06-24 14:23:33.330920
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == hash(None)

# Generated at 2022-06-24 14:23:35.115385
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert(repr(_ScopeDict('foo')) == 'foo__Scope()')



# Generated at 2022-06-24 14:23:44.397176
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass('Foo', 'foo')
    assert c.name == 'foo'
    assert c.method_names == {}

    c.register_methods({
        'foo': 1,
        'bar': 2,
        'baz': 3,
    })
    assert c.name == 'foo'
    assert c.method_names == {
        'foo': 1,
        'bar': 2,
        'baz': 3,
    }
    assert c.method_idxs == {
        1: 'foo',
        2: 'bar',
        3: 'baz',
    }



# Generated at 2022-06-24 14:23:50.310184
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO


# Generated at 2022-06-24 14:23:59.284081
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    output = io.StringIO()

    class AVMClass(object):
        def __init__(self, name):
            self.name = name
    
    scope_dict = _ScopeDict(AVMClass('Foo'))
    scope_dict['bar'] = 'baz'
    scope_dict['asdf'] = 'qwer'
    print(scope_dict, file=output)
    assert output.getvalue() == "Foo__Scope({'bar': 'baz', 'asdf': 'qwer'})\n"
try:
    test__ScopeDict___repr__()
finally:
    del test__ScopeDict___repr__



# Generated at 2022-06-24 14:24:10.015933
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from . swf_elements import DoAction
    from . swf_elements import DoInitAction
    from . swf_elements import SWF


# Generated at 2022-06-24 14:24:12.630881
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert _AVMClass(0, 'Foobar').__repr__() == '_AVMClass(Foobar)'

# Generated at 2022-06-24 14:24:19.297747
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    _AVMClass('SomeClass').create_instance()
test__AVMClass_Object___repr__()


# Generated at 2022-06-24 14:24:25.888143
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swf import SWFInterpreter
    with open(os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'test_swf_interpreter.swf'), 'rb') as f:
        swf = SWFInterpreter(f.read())

    print(swf.constant_strings)
    print(swf.multinames)
    print(swf.classes)
    print(swf.method_bodies)
    print(len(swf.method_bodies))
    print(swf.method_bodies[0].code)

# Generated at 2022-06-24 14:24:28.919869
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    c = _AVMClass_Object(object)
    assert c.avm_class == object
    assert repr(c) == 'object#%x' % id(c)



# Generated at 2022-06-24 14:24:33.294853
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Test for method extract_function( ... ) of class SWFInterpreter
    #
    # Interesting test cases!
    # But how to test that the method is extracted properly?
    #
    # The test currently just asserts that extracting the function
    # will not crash.
    return


# Generated at 2022-06-24 14:24:35.284722
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(None))



# Generated at 2022-06-24 14:24:47.568391
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from decimal import Decimal
    swf = swftools.SWF('test.swf')
    avm_class = SWFInterpreter(swf).extract_class(
        swf.abc[0].classes['video/x-flv::NetStream'])

    # Assert static properties are correctly extracted
    assert avm_class.static_properties['CONNECT_TO_FMS'] == 'connectToFMS'
    assert avm_class.static_properties['DIRECT_CONNECTIONS'] == []

    # Assert instance properties are correctly extracted
    assert (avm_class.instance_properties['bufferLength'] ==
            Decimal('0'))

    # Assert class method names are correctly extracted
    method_names = avm_class.method_names
    assert 'play' in method_names

# Generated at 2022-06-24 14:24:50.108610
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    class_ = _AVMClass(name_idx=1, name='UnitTest')
    assert repr(class_) == '_AVMClass(UnitTest)'


# Generated at 2022-06-24 14:24:57.348135
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from .actionscript import ActionScript
    avm_class = _AVMClass(None, None, None)
    assert len(avm_class.method_names) == 0
    assert len(avm_class.method_idxs) == 0
    avm_class.register_methods({b'foo': 42, b'bar': 66666})
    assert len(avm_class.method_names) == 2
    assert len(avm_class.method_idxs) == 2
    assert avm_class.method_names == {b'foo': 42, b'bar': 66666}
    assert avm_class.method_idxs == {
        42: b'foo',
        66666: b'bar'}



# Generated at 2022-06-24 14:25:09.961718
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    code = b'\x62\x01\x00\x61\x03\x00\x62\x00\x00\x63\x00\x00'
    swf = SWFInterpreter(code, SWF_VERSION_PRE_AVM2)
    swf.constant_pool = ['add']

    avm_class = _AVMClass({})
    avm_class.constant_pool = ['add']
    avm_class.static_properties = {}
    avm_class.static_properties['add'] = lambda x: x[0] + x[1]

    avm_class2 = _AVMClass({})
    avm_class2.static_properties = {}


# Generated at 2022-06-24 14:25:18.930710
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    import binascii

# Generated at 2022-06-24 14:25:21.010539
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    avm = _AVMClass(0, 'Test')
    assert (repr(avm) == "_AVMClass('Test')")



# Generated at 2022-06-24 14:25:24.498125
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert (
        repr(_ScopeDict('Class'))
        == 'Class__Scope()')
    assert (
        repr(_ScopeDict({'1': 1, '2': 'X'}))
        == "Class__Scope({'1': 1, '2': 'X'})")



# Generated at 2022-06-24 14:25:26.708845
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'



# Generated at 2022-06-24 14:25:35.289497
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import unittest
    class TestSWFInterpreter(unittest.TestCase):
        def test_patch_function(self):
            swf = SWFInterpreter()
            swf.extract_function = lambda avm_class, func_name: 'ONE'
            res = swf.patch_function('TWO', 'TWO', []).func_name
            self.assertEqual(res, 'ONE')
    unittest.main()
# The interpreter
swf = SWFInterpreter()

# The actual code

# Generated at 2022-06-24 14:25:38.559264
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    args = ('a', 'b', 'c')
    kwargs = {}
    obj = _AVMClass(*args, **kwargs)
    repr(obj)

# Generated at 2022-06-24 14:25:39.750738
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()) == False


# Generated at 2022-06-24 14:25:44.508833
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(0x1234, 'Foo')
    assert c.name == 'Foo'
    assert c.name_idx == 0x1234
    assert c.method_names == {}
    assert c.method_idxs == {}
    assert c.variables == {}
    assert c.constants == {}



# Generated at 2022-06-24 14:25:50.685046
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    v_0 = _AVMClass_Object(AVMClass(name='abc'))
    v_1 = v_0.__repr__()
    assert v_1 == 'abc#%x' % id(v_0)
# <Unit test for method __repr__ of class _AVMClass_Object>



# Generated at 2022-06-24 14:25:54.462627
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    avm_class = _AVMClass('SomeClass', [
        ('SomeMethod', {'num_params': 1}),
        ('OtherMethod', {'num_params': 2}),
    ])
    assert repr(_AVMClass_Object(avm_class)) == 'SomeClass#0'



# Generated at 2022-06-24 14:25:58.476210
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(1, 'Test')
    c.register_methods({
        'Foo': 1,
        'Bar': 2
    })
    assert c.method_names == {
        'Foo': 1,
        'Bar': 2
    }
    assert c.method_idxs == {
        1: 'Foo',
        2: 'Bar'
    }



# Generated at 2022-06-24 14:25:59.275250
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__(): return True


# Generated at 2022-06-24 14:26:03.676250
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(None)) == 'None#%x' % id(None)
    assert repr(_AVMClass_Object(object)) == 'object#%x' % id(object)



# Generated at 2022-06-24 14:26:06.358550
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    x = _Multiname(kind=34)
    assert repr(x) == '[MULTINAME kind: 0x22]'



# Generated at 2022-06-24 14:26:09.263567
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    obj = _Multiname(1)
    assert repr(obj) == '[MULTINAME kind: 0x1]'



# Generated at 2022-06-24 14:26:10.727873
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    return '[MULTINAME kind: 0x%x]' % self.kind

# Generated at 2022-06-24 14:26:11.307138
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

# Generated at 2022-06-24 14:26:15.512855
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    # __repr__ (undefined) -> undefined
    # _Undefined#__repr__(): undefined -> undefined
    undefined = _Undefined()
    assert undefined.__repr__() == 'undefined'


_undefined = _Undefined()



# Generated at 2022-06-24 14:26:21.588911
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    instance = _AVMClass(name_idx=1, name='class')
    instance.register_methods(methods={'method': 1})
    assert type(instance.method_names) == dict
    assert type(instance.method_idxs) == dict
    assert instance.method_names['method'] == 1
    assert instance.method_idxs[1] == 'method'

# Generated at 2022-06-24 14:26:23.709696
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert repr(_AVMClass('', 'ABC')) == "_AVMClass('ABC')"

# Generated at 2022-06-24 14:26:26.976215
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    from .swfdec import AVMClass
    class_foo = AVMClass(None, 'Foo')
    obj = class_foo.construct()
    assert obj.avm_class == class_foo


# Generated at 2022-06-24 14:26:33.017755
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class _FooAVMClass(object):
        name = 'Foo'
        def __init__(self):
            self.members = {
                'baz': 1,
            }
    class_ = _AVMClass_Object(_FooAVMClass())
    class_.baz = 2
    assert class_.baz == 2
    assert class_.members['baz'] == 1
    del class_.baz
    assert class_.baz == 1



# Generated at 2022-06-24 14:26:44.426819
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():

    s = SWFLoader()
    classname = 'com.longtailvideo.jwplayer.utils::Strings'
    avm_class = s.extract_class(classname)
    assert avm_class.method_names == set(
        ['charCodeAt', 'split', 'getDomainFromHost'])
    assert avm_class.static_properties['VERSION'] == "6.0.4511"
    assert avm_class.instance_properties == set([])
    assert avm_class.inheritance_scopes[0]['Object'] == ObjectClass
    assert avm_class.inheritance_scopes[0]['String'] == StringClass
    assert avm_class.inheritance_scopes[1]['Object'] == ObjectClass

# Generated at 2022-06-24 14:26:47.955881
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert '_AVMClass_Object#%x' % id(_AVMClass_Object) == repr(_AVMClass_Object)
    assert '<class \'_AVMClass_Object\'>#%x' % id(_AVMClass_Object) == repr(_AVMClass_Object())



# Generated at 2022-06-24 14:26:49.644933
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    print(hash( _Undefined() ))


# Generated at 2022-06-24 14:26:51.112289
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    a = _AVMClass('a', 'a')



# Generated at 2022-06-24 14:26:52.478749
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    undef = _Undefined()
    assert not undef

# Generated at 2022-06-24 14:26:57.411360
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_definition = _AVMClass_Object(_AVMClass_Object)
    assert class_definition == class_definition
    assert class_definition != _AVMClass_Object(_AVMClass_Object)
    assert class_definition != object()
    assert repr(class_definition) == '_AVMClass_Object#%x' % id(class_definition)



# Generated at 2022-06-24 14:26:58.504311
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:26:59.846766
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert _ScopeDict(None)
test__ScopeDict()



# Generated at 2022-06-24 14:27:06.519770
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() is _Undefined()

_multiname_types = {
    0x07: 'QName',
    0x0D: 'QNameA',
    0x0F: 'RTQName',
    0x10: 'RTQNameA',
    0x11: 'RTQNameL',
    0x12: 'RTQNameLA',
    0x09: 'Multiname',
    0x0E: 'MultinameA',
    0x1B: 'MultinameL',
    0x1C: 'MultinameLA',
}
_unsupported_multiname_types = set(
    [0x1D, 0x1E])

# Generated at 2022-06-24 14:27:10.409344
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .utils import unit_test
    cls = _AVMClass("foo", "foo")
    obj = cls.make_object()
    assert obj.avm_class is cls
    assert repr(obj) == 'foo#{:x}'.format(id(obj))



# Generated at 2022-06-24 14:27:11.840107
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    class_0 = _AVMClass

    assert repr(class_0)

# Generated at 2022-06-24 14:27:12.928010
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(1).kind == 1
    assert _Multiname(2).kind == 2



# Generated at 2022-06-24 14:27:14.216996
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'

# Generated at 2022-06-24 14:27:16.722606
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(0)) == '[MULTINAME kind: 0x0]'
    assert repr(_Multiname(0xFFFFFFFF)) == '[MULTINAME kind: 0xffffffff]'



# Generated at 2022-06-24 14:27:22.441866
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'

_MULTINAME_KIND_NAME = 0x07
_MULTINAME_KIND_QNAME = 0x0d



# Generated at 2022-06-24 14:27:28.428821
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .testutils import make_avm_classes
    avm_classes = make_avm_classes()
    for avm_class in avm_classes:
        if avm_class.name == 'Object':
            obj = _AVMClass_Object(avm_class)
            assert repr(obj) == 'Object#%x' % id(obj)
test__AVMClass_Object___repr__()



# Generated at 2022-06-24 14:27:29.876041
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert {_Undefined(): None} == {None: None}



# Generated at 2022-06-24 14:27:32.542404
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # TODO
    pass

# Class SWFObjectLoader

# Generated at 2022-06-24 14:27:38.114868
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    def test(kind):
        return _Multiname(kind).__repr__() == '[MULTINAME kind: 0x%x]' % kind

    assert (test(0x07))
    assert (test(0x0d))
    assert (test(0x0f))
    assert (test(0x10))



# Generated at 2022-06-24 14:27:41.781265
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class myClass(object):
        pass
    myClass.__name__ = 'myClass'
    d = _ScopeDict(myClass)
    assert str(d) == 'myClass__Scope({})'



# Generated at 2022-06-24 14:27:43.167301
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    from . import _AVMClassDB_empty
    print(collections.OrderedDict() == _ScopeDict(_AVMClassDB_empty._AVMClass('', None)))


# Generated at 2022-06-24 14:27:46.902199
# Unit test for constructor of class _Undefined
def test__Undefined():
    u = _Undefined()
    assert not u
    assert hash(u) == 0
    assert str(u) == 'undefined'
    assert repr(u) == 'undefined'

test__Undefined()



# Generated at 2022-06-24 14:27:50.730711
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class MyClass(object):
        def __init__(self):
            self.name = 'MyClass'
    obj = _AVMClass_Object(MyClass())
    assert repr(obj) == 'MyClass#%x' % id(obj)



# Generated at 2022-06-24 14:27:53.847639
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    ac = _AVMClass('test', {'foo': 1234, 'bar': 'hello world'})
    assert ac.name == 'test'
    assert ac.static_properties == {'foo': 1234, 'bar': 'hello world'}



# Generated at 2022-06-24 14:27:57.470990
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    u = _Undefined()
    assert repr(u) == 'undefined'
_Undefined = _Undefined()



# Generated at 2022-06-24 14:28:11.940706
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # get movieclips related class
    swf_interpreter = SWFInterpreter()
    swf_interpreter._SWFInterpreter__read_movieclips(open('../../IMDB/a.swf', 'rb'))

    # get some classes
    for class_name, avm_class in swf_interpreter.classes.iteritems():
        if class_name == 'flash.display.Stage':
            assert avm_class.supername == '__AS3__.vec.Vector'
            assert avm_class.method_names == set(['Stage'])
            assert avm_class.static_properties == {
                'FRAME_RATE': 30.0
            }

# Generated at 2022-06-24 14:28:16.647404
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class dummy_object:
        pass
    x = _ScopeDict(dummy_object)
    x['a'] = 1
    assert repr(x) == 'dummy_object__Scope({\'a\': 1})'
    return True


# Generated at 2022-06-24 14:28:18.943615
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    a = _Undefined()
    b = _Undefined()
    assert hash(a) == hash(b)
    assert a == b



# Generated at 2022-06-24 14:28:21.002236
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    _AVMClass('Object', dict(a=1))



# Generated at 2022-06-24 14:28:23.206056
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'


_undefined = _Undefined()



# Generated at 2022-06-24 14:28:29.543665
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(1, 'MyClass')
    assert avm_class.name_idx == 1
    assert avm_class.name == 'MyClass'
    assert avm_class.methods == {}
    assert avm_class.method_idxs == {}
    assert avm_class.method_names == {}
    assert avm_class.variables == {}
    assert avm_class.constants == {}



# Generated at 2022-06-24 14:28:31.531623
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    name_idx = int()
    name = str()
    r0 = _AVMClass(name_idx, name)

# Generated at 2022-06-24 14:28:40.322809
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWF('tests/swf/all.swf')
    si = open_swf(swf)

    assert si.extract_function(si.classes['ActionScript'], 'String')(
        [('abc',)]) == 'abc'
    assert si.extract_function(si.classes['Array'], 'pop')([]) == None
    assert si.extract_function(si.classes['Date'], 'getMonth')([]) == 2
    assert si.extract_function(si.classes['Math'], 'random')([]) >= 0
    assert si.extract_function(si.classes['String'], 'indexOf')(
        ['abc', 'bc']) == 1

# Generated at 2022-06-24 14:28:51.860061
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = open(os.path.join(os.path.dirname(__file__),
                            'test_data/bbc.swf'), 'rb').read()
    interpreter = SWFInterpreter(swf)
    avm_class = interpreter.extract_class('bbc.as$0')
    assert avm_class.name == 'bbc.as$0'

# Generated at 2022-06-24 14:28:55.165119
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class _AVMClass(object):
        pass
    c1 = _AVMClass()
    c1.name = 'Foo'
    assert repr(_AVMClass_Object(c1)) == 'Foo#%x' % id(c1)
test__AVMClass_Object()



# Generated at 2022-06-24 14:28:57.927820
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x0f)) == '[MULTINAME kind: 0x0f]'



# Generated at 2022-06-24 14:28:58.968984
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    assert True

# Generated at 2022-06-24 14:29:10.627335
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    """Testcase for _AVMClass_Object.__repr__"""
    class_test = type(b'class_test',(),{})()
    print('test1:')
    print(type(class_test))
    print('test2:')
    print(type(class_test))
    print('test3:')
    print(type(class_test))
    print('test4:')
    print(type(class_test))
    print('test5:')
    print(type(class_test))
    print('test6:')
    print(type(class_test))
    print('test7:')
    print(type(class_test))
    print('test8:')
    print(type(class_test))
    print('test9:')
    print(type(class_test))




# Generated at 2022-06-24 14:29:12.165825
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    assert(True)


# Generated at 2022-06-24 14:29:15.187073
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert not bool(_Undefined())
    assert str(_Undefined()) == 'undefined'
    assert _Undefined() == _Undefined()

_undefined = _Undefined()



# Generated at 2022-06-24 14:29:20.242504
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    from .utils import make_doctest_bytes
    # doctest: +ELLIPSIS
    assert make_doctest_bytes(_Multiname(0xdeadbeef)) == (
        b"[MULTINAME kind: 0xdeadbeef]")

# Generated at 2022-06-24 14:29:23.439062
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0)) == '[MULTINAME kind: 0x0]'
    assert repr(_Multiname(1)) == '[MULTINAME kind: 0x1]'



# Generated at 2022-06-24 14:29:25.074184
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    # FIXME
    pass

# Generated at 2022-06-24 14:29:29.571539
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    f = _AVMClass('Flash', 'Object')
    # Make sure it returns the proper type
    assert isinstance(f.make_object(), _AVMClass_Object)
    # Make sure all the attributes were transferred
    assert getattr(f.make_object(), 'avm_class').name_idx == 'Flash'



# Generated at 2022-06-24 14:29:34.330478
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    f = SWFInterpreter._extract_function
    assert f(True, u'class') is bool
    assert f(bytes(), u'class') is bytes
    assert f(compat_str(), u'class') is compat_str
# class SWFExtractor

# Generated at 2022-06-24 14:29:42.247365
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s = SWFInterpreter()
    assert s.namespaces[0].name == ''
    assert s.namespaces[1].name == 'private'
    assert s.namespaces[2].name == 'public'
    assert s.namespaces[3].name == 'http://adobe.com/AS3/2006/builtin'
    assert s.namespaces[4].name == 'http://ns.adobe.com/mxml/2009'
    assert s.namespaces[5].name == 'http://ns.adobe.com/fxg/2008'
    assert s.namespaces[6].name == 'library'
    assert s.namespaces[7].name == 'http://www.adobe.com/2006/actionscript/flash/proxy'

    assert s.namespaces[1].kind == 1  # private
    assert s.namespaces

# Generated at 2022-06-24 14:29:44.390074
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(avm_class=None).__repr__() == 'None__Scope({})'



# Generated at 2022-06-24 14:29:45.617660
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-24 14:29:47.442881
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    _AVMClass('_AVMClass', '_AVMClass', static_properties=None)


# Generated at 2022-06-24 14:29:56.039876
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass('foo', {'foo': 1, 'bar': 0})
    assert avm_class.name_idx == 'foo'
    assert avm_class.name == 'foo'
    assert avm_class.method_names == {'foo': 1, 'bar': 0}
    assert avm_class.method_idxs == {0: 'bar', 1: 'foo'}
    assert avm_class.methods == {}
    assert avm_class.method_pyfunctions == {}
    assert avm_class.static_properties == {}
    assert avm_class.variables == {'avm_class': avm_class}
    assert avm_class.constants == {}



# Generated at 2022-06-24 14:29:59.764647
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    avm_class = _AVMClass(name_idx=None,name='_AVMClass')
    assert repr(avm_class) == "_AVMClass('_AVMClass')"



# Generated at 2022-06-24 14:30:05.167104
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    x = _Undefined()
    y = _Undefined()
    assert x == y
    assert x is not y
    assert x
    assert y
    assert hash(x) == hash(y)

_undefined = _Undefined()



# Generated at 2022-06-24 14:30:09.309959
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from .as3 import (
        _AVMMethod,
    )
    class_ = _AVMClass(b'', b'')
    methods = {
        b'method': _AVMMethod(b'', b'', b''),
    }
    class_.register_methods(methods)
    assert class_.method_names == methods
    assert class_.method_idxs == dict(
        (idx, name)
        for name, idx in methods.items())


# Generated at 2022-06-24 14:30:13.053195
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass('name_idx', 'name')
    method = getattr(obj, '__repr__')

    assert method() == '_AVMClass(name)'



# Generated at 2022-06-24 14:30:14.692567
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert str(eval(repr(_Undefined()))) == 'undefined'



# Generated at 2022-06-24 14:30:16.350627
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    _Undefined()

__undefined = _Undefined()



# Generated at 2022-06-24 14:30:18.963053
# Unit test for constructor of class _Undefined
def test__Undefined():
    o = _Undefined()
    assert not o
    assert 0 == hash(o)
    assert 'undefined' == str(o)
    assert 'undefined' == repr(o)

_undef = _Undefined()



# Generated at 2022-06-24 14:30:25.069994
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    scope = _ScopeDict(_AVMClass(b'[test]'))
    scope['foo'] = 'bar'
    scope['baz'] = 'quux'
    assert repr(scope) == b'[test]__Scope({\'foo\': \'bar\', \'baz\': \'quux\'})'



# Generated at 2022-06-24 14:30:26.032726
# Unit test for constructor of class _Multiname
def test__Multiname():
    print(_Multiname(0x07))



# Generated at 2022-06-24 14:30:32.986274
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(name_idx=0, name='TestClass')
    o = c.make_object()
    assert o.avm_class is c
    assert c.method_names == {}
    assert c.method_idxs == {}
    assert c.methods == {}
    assert c.static_properties == {}
    assert repr(c.variables) == 'TestClass__Scope({})'
    assert repr(o) == 'TestClass#%x' % id(o)

    c.static_properties['staticProp'] = 1

    c.register_methods({'test_method': 0})
    assert c.method_names == {'test_method': 0}
    assert c.method_idxs == {0: 'test_method'}

# Generated at 2022-06-24 14:30:34.343574
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    s = _ScopeDict(None)
    assert isinstance(s, dict)
    assert repr(s) == 'None__Scope({})'



# Generated at 2022-06-24 14:30:35.769348
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert 'undefined' == str(_Undefined())

Undefined = _Undefined()



# Generated at 2022-06-24 14:30:39.332525
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert hash(_Undefined()) == 0
    assert _Undefined().__str__() == 'undefined'
    assert _Undefined().__repr__() == 'undefined'

_undef = _Undefined()



# Generated at 2022-06-24 14:30:45.193732
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    # TODO: why do we use the name twice?  What's the point?
    # Is it because `repr` could contain the class name?
    assert _ScopeDict.__repr__(_ScopeDict(None)) == 'None__Scope({})'
    assert _ScopeDict.__repr__(
        _ScopeDict(None, {'a': 'b'})) == 'None__Scope({\'a\': \'b\'})'



# Generated at 2022-06-24 14:30:49.488798
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    return (_Undefined() == _Undefined())
Undefined = _Undefined()



# Generated at 2022-06-24 14:30:53.834825
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    M = _AVMClass('dummy', 'name')
    methods = dict(a=0, b=1, c=2)
    M.register_methods(methods)
    assert M.method_names == methods
    assert M.method_idxs == dict((i, n) for n, i in methods.items())



# Generated at 2022-06-24 14:30:57.385740
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    m = _Multiname(0x1)
    assert '[MULTINAME kind: 0x1]' == repr(m)



# Generated at 2022-06-24 14:31:08.044646
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm = _AVMClass('foo')
    assert avm.method_names == {}
    assert avm.method_idxs == {}
    avm.register_methods({'first': 1, 'second': 2, 'third': 3})
    assert avm.method_names == {'first': 1, 'second': 2, 'third': 3}
    assert avm.method_idxs == {1: 'first', 2: 'second', 3: 'third'}
    # Check that dublications don't affect method names and idxs
    avm.register_methods({'first': 1, 'second': 2, 'third': 3})
    assert avm.method_names == {'first': 1, 'second': 2, 'third': 3}

# Generated at 2022-06-24 14:31:09.067999
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(
        _Undefined()) == 0



# Generated at 2022-06-24 14:31:12.893278
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert _Multiname(1).__repr__() == '[MULTINAME kind: 0x1]'
test__Multiname___repr__()



# Generated at 2022-06-24 14:31:20.793137
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    si = SWFInterpreter()
    with open('test/minimal.swf', 'rb') as f:
        swf = f.read()
    si.parse(BytesIO(swf))
    assert si.constant_strings[0] == 'Hello'
    assert si.constant_strings[1] == 'World'
    assert si.constant_strings[2] == 'Hello World'
    assert si.constant_strings[3] == '1'
    assert si.constant_strings[4] == '2'
    assert si.constant_strings[5] == 'main'
    # TODO: test the returned function
    si.patch_function('TestClass_39', 'main')

