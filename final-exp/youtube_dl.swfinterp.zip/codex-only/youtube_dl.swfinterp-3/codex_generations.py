

# Generated at 2022-06-24 14:21:22.339628
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'
    raise _UnitTestError('not done')

# Generated at 2022-06-24 14:21:32.276804
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .parser import NoneParser as parser_class
    from .constants import AVM1_ACTION_CONSTANTS
    from .structures import ScriptTag
    from .structures import DoABCTag
    from .structures import SWF

    # fetch_page
    fetch_page = '''
        var file = new FileReference();
        file.save(page, "page.html");
    '''

    fetch_page_action = SWF.parse(fetch_page.encode('ascii'), parser_class)[0]
    assert isinstance(fetch_page_action, DoABCTag)

    fetch_page_script = SWF.parse(
        fetch_page_action.action_data, parser_class,
        action_constants=AVM1_ACTION_CONSTANTS)

# Generated at 2022-06-24 14:21:36.188910
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    x = _ScopeDict(_AVMClass(1))
    x['y'] = 2
    assert repr(x) == '_AVMClass#1__Scope({\'y\': 2})'


# Generated at 2022-06-24 14:21:37.851943
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x0003)) == '[MULTINAME kind: 0x3]'



# Generated at 2022-06-24 14:21:41.542298
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() == _Undefined()
    assert not _Undefined()
    assert not bool(_Undefined())
    assert True is not _Undefined()
    assert False is _Undefined()


_undefined = _Undefined()


_constant_string_pool = {}



# Generated at 2022-06-24 14:21:49.421870
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    '''Unit test for method __repr__ of class _Undefined'''
    Undef = _Undefined()
    assert Undef.__repr__() == Undef.__str__()
Undefined = _Undefined()
Null = object()
TrueValue = object()
FalseValue = object()
_CONST_VALUE = {
    0x00: Undefined,
    0x01: Null,
    0x02: TrueValue,
    0x03: FalseValue,
}
_CONST_VALUE_STR = {
    TrueValue: 'true',
    FalseValue: 'false',
}
_CONST_VALUE_STR.update(dict((v, k) for k, v in _CONST_VALUE.items()))

# Generated at 2022-06-24 14:21:51.637519
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    cls = _Undefined()
    if cls == 'undefined':
        pass
    __undefined = _Undefined()


# Generated at 2022-06-24 14:21:59.660923
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    _setup_globals()
    si = SWFInterpreter()
    # Load a compilation unit

# Generated at 2022-06-24 14:22:10.609434
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(
        name_idx=1,
        # TODO: the name_idx is used by the AVM2 class, and should
        # be replaced with an actual name later
        name='_AVMClassUnitTest',
        static_properties={
            'pi': 3.14159,
            'e': 2.71828,
        })

    assert avm_class.name_idx == 1
    assert avm_class.name == '_AVMClassUnitTest'
    assert avm_class.method_names == {}
    assert avm_class.method_idxs == {}
    assert avm_class.methods == {}
    assert avm_class.method_pyfunctions == {}

# Generated at 2022-06-24 14:22:12.818496
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()
    avm_class = interpreter.parse(test_swfdecompress_swf)
    interpreter.patch_function(avm_class, 'swfdecompress')

    res = avm_class.method_pyfunctions['swfdecompress'](None, [])
    assert res == uncompressed_bytes



# Generated at 2022-06-24 14:22:13.673349
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    _Undefined()
    pass

_undefined = _Undefined()



# Generated at 2022-06-24 14:22:15.396769
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    obj = _AVMClass_Object(object())
    obj.__repr__()


# Generated at 2022-06-24 14:22:23.211310
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_object = _AVMClass('MyObj', static_properties={
        'a': 'A',
        'b': 'B',
        'c': 'C',
    })
    assert class_object.name == 'MyObj'
    assert class_object.static_properties['a'] == 'A'
    assert dict(
        class_object.method_names.items()) == dict()
    assert dict(
        class_object.method_idxs.items()) == dict()
    assert dict(
        class_object.methods.items()) == dict()
    assert dict(
        class_object.method_pyfunctions.items()) == dict()
    assert dict(
        class_object.variables.items()) == dict()
    assert dict(
        class_object.constants.items()) == dict()
test__AVM

# Generated at 2022-06-24 14:22:24.464986
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    obj = _Undefined()
    assertequal(str(obj), "undefined")


# Generated at 2022-06-24 14:22:26.562392
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert _Multiname(0x0d).kind == 0x0d
    assert str(_Multiname(0x0d)) == '[MULTINAME kind: 0xd]'



# Generated at 2022-06-24 14:22:33.313448
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from jstools.parse_abc import ABC, Multiname, MultinameKind

    # % cat

# Generated at 2022-06-24 14:22:41.230752
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    obj = _AVMClass(0, '')
    obj.register_methods({
        'a': 1,
        'b': 2,
    })
    assert obj.method_names == {
        'a': 1,
        'b': 2,
    }
    assert obj.method_idxs == {
        1: 'a',
        2: 'b',
    }



# Generated at 2022-06-24 14:22:47.813840
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class StubAVMClass(object):
        PRECONSTRUCTED = True

        @staticmethod
        def make_object():
            assert isinstance(Stub_AVMClass, _AVMClass_Object)
            return Stub_AVMClass()

    _builtin_classes['Object'] = StubAVMClass

    swf = SWFInterpreter(None)
    swf.extract_class(None, None)

    del _builtin_classes['Object']


# Generated at 2022-06-24 14:22:52.098373
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = _AVMClass('foobar', None).make_object()
    assert isinstance(obj, _AVMClass_Object)
    assert isinstance(obj.avm_class, _AVMClass)
    assert obj.avm_class.name == 'foobar'



# Generated at 2022-06-24 14:22:53.174461
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0



# Generated at 2022-06-24 14:22:58.262328
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    a = _Undefined()
    if a:
        raise AssertionError('truth value of an instance of _Undefined should be False')
    a = _Undefined()
    if bool(a):
        raise AssertionError('truth value of an instance of _Undefined should be False')

# Generated at 2022-06-24 14:23:00.312519
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    assert repr(_AVMClass(0, 'paf.object', {'x': 0, 'y': 0})) == '_AVMClass(paf.object)'



# Generated at 2022-06-24 14:23:06.832304
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    try:
        assert repr(_AVMClass('a', 'b', 'c')) == "_AVMClass('b')"
    except Exception:
        print(repr(_AVMClass('a', 'b', 'c')))
        raise


# Generated at 2022-06-24 14:23:10.416838
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    obj = _ScopeDict(_AVM_Class('TestClass'))
    obj['one'] = 1
    obj['two'] = 2
    repr_result = repr(obj)
    assert repr_result == 'TestClass__Scope({\'two\': 2, \'one\': 1})'



# Generated at 2022-06-24 14:23:11.855195
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert _Undefined().__repr__() == 'undefined'
_undefined = _Undefined()



# Generated at 2022-06-24 14:23:13.496536
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = AVMClass('name')
    assert obj.__repr__() == '_AVMClass(name)'


# Generated at 2022-06-24 14:23:14.248617
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    # TODO
    pass


# Generated at 2022-06-24 14:23:20.217445
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    def assert_obj(cls, obj, expected_repr):
        if obj is None:
            assert cls.get_class() is None
        else:
            assert cls.get_class() == obj.avm_class
        assert repr(obj) == expected_repr

    def assert_obj_class(cls, obj, expected_repr):
        assert cls.get_class() == obj.avm_class
        assert repr(obj) == expected_repr

    class_A = _AVMClass()
    assert_obj(class_A, class_A.new_instance(), '%s#%x' % (class_A.name, id(class_A.new_instance())))
    class_B = _AVMClass()

# Generated at 2022-06-24 14:23:26.709857
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Test method extract_function of class SWFInterpreter

    # Test with a simple test class
    s = '''\
    %s
    class TestClass
    {
        function testFunction(param1, param2) {
            return param1 + param2;
        }
    }
    ''' % AS3_CLASS_HEADER

    abc = parse_swf(BytesIO(s.encode('UTF-8')))
    interpreter = SWFInterpreter(abc)

    # test_func is a bound method, we need to use it
    obj = interpreter.builtins['TestClass'].make_object()
    test_func = interpreter.extract_function(obj, 'testFunction')

    assert test_func([1, 2]) == 3

# Generated at 2022-06-24 14:23:32.826974
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    scope = _ScopeDict(
        avm_class=_AVMClass(
            name='MyClass',
            super_class=_AVMClass(name='Object', super_class=None, id=0)))
    scope.update({'x': 1})
    assert repr(scope) == 'MyClass__Scope({\'x\': 1})'



# Generated at 2022-06-24 14:23:34.386807
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass(name_idx=0, name=0)
    repr(obj)


# Generated at 2022-06-24 14:23:37.435249
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s = SWFInterpreter.from_file('../tests/test.swf')
    assert len(s.scripts) == 1
    assert s.scripts['Script5']
    assert len(s.classes) == 1
    assert s.classes['Script5']


# Generated at 2022-06-24 14:23:39.336809
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None) == eval(_ScopeDict(None).__repr__())


# Generated at 2022-06-24 14:23:42.573471
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert compat_str(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'

_MultinameQName = collections.namedtuple('_MultinameQName', 'namespace_idx name_idx')


# Generated at 2022-06-24 14:23:43.543006
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()



# Generated at 2022-06-24 14:23:47.107684
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    name = 'OMG'
    class_obj = _AVMClass_Object(object())
    class_obj.avm_class.name = name
    assert repr(class_obj) == '%s#%x' % (name, id(class_obj))



# Generated at 2022-06-24 14:23:53.826769
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    avm_class = _AVMClass(1, 'Foo', {
        'bar': 42,
    })
    assert avm_class.name_idx == 1
    assert avm_class.name == 'Foo'
    assert avm_class.method_names == {}
    assert avm_class.method_idxs == {}
    assert avm_class.static_properties == {'bar': 42}

    # The empty scope of variables uses the class
    assert avm_class.variables.avm_class == avm_class

    avm_class.register_methods({
        'baz': 2,
    })
    assert avm_class.method_names == {'baz': 2}
    assert avm_class.method_idxs == {2: 'baz'}



# Generated at 2022-06-24 14:23:57.826247
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class TestClass(_AVMClass_Object):
        def __init__(self):
            pass
    inst = _ScopeDict(TestClass)
    assert not inst, '__ScopeDict() is not empty'
    inst = _ScopeDict(TestClass)
    inst['test'] = True
    assert inst['test'], '__ScopeDict() does not work'



# Generated at 2022-06-24 14:24:05.064202
# Unit test for constructor of class _Multiname
def test__Multiname():
    _Multiname(0x07)


_MULTINAME_KIND_QNAME = 0x07
_MULTINAME_KIND_QNAMEA = 0x0d
_MULTINAME_KIND_RTQNAME = 0x0f
_MULTINAME_KIND_RTQNAMEA = 0x10
_MULTINAME_KIND_RTQNAMEL = 0x11
_MULTINAME_KIND_RTQNAMELA = 0x12
_MULTINAME_KIND_MULTINAME = 0x09
_MULTINAME_KIND_MULTINAMEA = 0x0e
_MULTINAME_KIND_MULTINAMEL = 0x1b
_MULTINAME_KIND_MULTINAMELA = 0x1c

# Generated at 2022-06-24 14:24:13.083596
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class _AVMClass__usertest1(object):
        def test(self, msg):
            print('Hello %s' % msg)
    instance = _AVMClass('test_object', None)
    assert not instance.method_names
    methods = {'test': _AVMClass__usertest1().test}
    instance.register_methods(methods)
    assert instance.method_names == {'test': 1}, \
        'register_methods did not do what was expected'
    instance.method_names = {}
    assert not instance.method_names
test__AVMClass_register_methods()


# Generated at 2022-06-24 14:24:15.394703
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():

    # Call method(s) and check return value(s)
    assert str(_Undefined()) == 'undefined'
UNDEFINED = _Undefined()
NULL = _Undefined()



# Generated at 2022-06-24 14:24:25.197205
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-24 14:24:31.029909
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    method_names = {
        'fetch': 23,
        'extract': 41,
    }
    static_properties = {
        'display_id': 'E4E4E4',
        'title': 'ABCDEF',
    }
    avm_class = _AVMClass(7, 'YoutubeIE', static_properties)

    assert avm_class.name_idx == 7
    assert avm_class.name == 'YoutubeIE'
    assert avm_class.static_properties == static_properties
    assert isinstance(avm_class.variables, _ScopeDict)
    assert avm_class.method_names == {}
    assert avm_class.method_idxs == {}

    avm_class.register_methods(method_names)
    assert avm_class.method_names

# Generated at 2022-06-24 14:24:34.201346
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    parser = _SWFInterpreter(compat_etree_Element('swf'))
    parser.extract_function('', [])
test_SWFInterpreter_extract_function()


# Load a SWF from file path

# Generated at 2022-06-24 14:24:40.984392
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class A(object):
        pass
    a = A()
    a.name = 'A'
    b = _ScopeDict(a)
    b[1] = 2
    assert repr(b) == 'A__Scope({1: 2})'
    assert b.avm_class == a
    assert b[1] == 2



# Generated at 2022-06-24 14:24:45.143297
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    cls = _AVMClass('class', None)
    obj = _ScopeDict(cls)
    obj[0] = 1
    assert repr(obj) == 'class__Scope({0: 1})'



# Generated at 2022-06-24 14:24:57.094291
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class Dummy:
        def __init__(self):
            self.variables = {}
            self.method_names = set()
            self.static_properties = {}
    interpreter = SWFInterpreter()

# Generated at 2022-06-24 14:25:09.155448
# Unit test for constructor of class _Multiname
def test__Multiname():
    mn = _Multiname(1)
    assert mn.kind == 1


_AVM1_VALUE_TYPES = {
    0x00: 'undefined',
    0x01: 'null',
    0x02: 'boolean',
    0x03: 'integer',
    0x04: 'double',
    0x05: 'string',
    0x06: 'register_index',
    0x07: 'boolean_register',
    0x08: 'double_register',
    0x09: 'integer_register',
    0x0a: 'constant_8',
    0x0b: 'constant_16',
    0x0c: 'constant_32',
    0x0d: 'function',
}



# Generated at 2022-06-24 14:25:18.425994
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from ..lib import cl
    from ..OsFlashVars import os_flash_vars
    from ..OsFlashVars import default_flash_vars
    from ..OsFlashVars import default_player_params

    swf_interpreter = SWFInterpreter('get_flash_vars.swf')

    # test get_flash_vars
    expected_flash_vars = os_flash_vars(default_flash_vars)
    flash_vars = swf_interpreter.get_flash_vars(default_flash_vars,
                                                default_player_params)
    assert flash_vars == expected_flash_vars

    # test get_js_vars

# Generated at 2022-06-24 14:25:20.155202
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(Undefined) == hash(_Undefined())


Undefined = _Undefined()



# Generated at 2022-06-24 14:25:27.569371
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
  import pyamf
  avm = SWFInterpreter(test_avm2_swf_data)

  # Test if we can extract some built-in classes
  assert isinstance(avm['Object'], _AVMClass)
  assert isinstance(avm['String'], _AVMClass)
  assert isinstance(avm['Array'], _AVMClass)

  # Test if all built-in classes are constructed
  assert avm['Object'].static_properties == {}
  assert avm['Object'].method_names == {}
  assert avm['Object'].constructor is None
  assert avm['Object'].static_constructor is None
  assert avm['Object'].superclass == None
  assert avm['Object'].interfaces == []

  assert avm['String'].static_properties == {}

# Generated at 2022-06-24 14:25:31.314926
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    from . import AVMClass

    c = AVMClass(name='foo')
    assert repr(_ScopeDict(c)) == 'foo__Scope({})'



# Generated at 2022-06-24 14:25:40.144568
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_file = io.open(
        os.path.join(os.path.dirname(__file__), 'swf_files', 'test_6.swf'),
        'rb')
    swf = SWFInterpreter(swf_file)
    # Test constructor, get_file_attributes and get_file_metadata
    assert swf.version == 19
    assert swf.width == 20
    assert swf.height == 10
    assert swf.frame_rate == 0.02
    assert swf.verify_signature() == True
    assert len(swf.tags) == 4
    assert len(swf.tag_actions) == 2
    assert len(swf.tag_libs) == 2
    assert len(swf.tag_symbols) == 2

# Generated at 2022-06-24 14:25:41.185278
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(None)) == 'None#%x' % id(_AVMClass_Object(None))



# Generated at 2022-06-24 14:25:52.507942
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    dummy_method_avm_classes = [
        ('a', [], [], []),
        ('b', [], [], []),
        ('c', [], [], []),
        ('d', [], [], []),
    ]
    dummy_methods = [
        ('dummy', dummy_method_avm_classes),
    ]
    dummy_avm_classes = [
        ('AVMClass_Object', dummy_methods),
    ]
    dummy_superclass = None
    dummy_instance_fields = []
    c = _AVMClass(
        'AVMClass_Object', dummy_methods, dummy_superclass, dummy_instance_fields)
    obj = _AVMClass_Object(c)

# Generated at 2022-06-24 14:25:59.326735
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    scope = _ScopeDict('test_class')
    scope[1] = 'val_1'
    scope['val_2'] = 'val_2'
    assert str(scope) == 'test_class__Scope({1: \'val_1\', \'val_2\': \'val_2\'})'
    assert repr(scope) == 'test_class__Scope({1: \'val_1\', \'val_2\': \'val_2\'})'



# Generated at 2022-06-24 14:26:12.442966
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import os
    file_path = os.path.join(os.path.dirname(__file__),
        'tests/swfdec_test_dump.dump')
    with open(file_path, 'rb') as f:
        swfdec_test_bytes = f.read()
    swfdec_test = SWFInterpreter(swfdec_test_bytes)
    assert swfdec_test.file_version == 10
    assert len(swfdec_test.constant_strings) == 10
    assert len(swfdec_test.multinames) == 8
    assert len(swfdec_test.all_classes) == 2
    assert isinstance(swfdec_test.all_classes[0], _AVMClass)

# Generated at 2022-06-24 14:26:20.701937
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    ex = io.BytesIO(b'''\x00\xbf
\x00\x01\x07 <init>\x00\x01\x00\x06+\x05\x00\x01\x07 <clinit>\x00\x01\x00\x06\x01\x02\x07\x01
\x00\x01\x07\x0c\x00\x01\x01\x06\x01\x02\x01\x05\x03'\x03\x08+\x04\x01\x00\x05\x00\x01\x00''')
    reader = compat_struct_unpack(
        '>HI', ex.read(6))
    (version, flags) = reader
    assert version == 1
    assert flags == 0

# Generated at 2022-06-24 14:26:31.602861
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO

# Generated at 2022-06-24 14:26:35.442290
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    """Test for method __repr__ of class _ScopeDict"""
    d = _ScopeDict(None)
    assert d.__repr__() == 'None__Scope({})'



# Generated at 2022-06-24 14:26:37.229805
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    val = _Undefined()
    assert bool(val) == False




# Generated at 2022-06-24 14:26:41.526894
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class Foo:
        name = 'Foo'
    f = Foo()
    d = _ScopeDict(f)
    d.x = 'y'
    assert repr(d) == "Foo__Scope({'x': 'y'})"



# Generated at 2022-06-24 14:26:43.863253
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    _avm_class = _AVMClass(idx=None, name=None, static_properties=None)
    repr(_avm_class)



# Generated at 2022-06-24 14:26:45.760198
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(Undefined) is False
    assert not Undefined
    assert str(Undefined) == 'undefined'

Undefined = _Undefined()



# Generated at 2022-06-24 14:26:53.720550
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() == _Undefined()
    assert not _Undefined()
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'

_undefined = _Undefined()

# We may have to implement the following builtin functions:
# - flash.utils.ByteArray: clear
# - flash.utils.Timer: stop
# - flash.events.TimerEvent: TIMER
# - flash.display.DisplayObject: addFrameScript, addEventListener,
#   dispatchEvent, removeEventListener
# - flash.display.MovieClip: play



# Generated at 2022-06-24 14:26:55.388762
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    assert _AVMClass('name').make_object().avm_class == 'name'


# Generated at 2022-06-24 14:26:57.004080
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    assert repr(_ScopeDict(None)) == 'None__Scope({})'



# Generated at 2022-06-24 14:26:58.416498
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    _Undefined()
undefined = _Undefined()



# Generated at 2022-06-24 14:27:06.059868
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class __Dummy__AVMClass(_AVMClass):
        def __init__(self, name_idx, name, static_properties=None):
            _AVMClass.__init__(self, name_idx, name, static_properties)
        def register_methods(self, methods):
            _AVMClass.register_methods(self, methods)
    dummy__Dummy__AVMClass = __Dummy__AVMClass(1, 'UnitTest1')
    dummy__Dummy__AVMClass.register_methods({'method1': 1})

# Generated at 2022-06-24 14:27:11.347158
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    StringIO = io.StringIO
    import copy
    import sys
    import unittest

    class _Multiname___repr__Tester(unittest.TestCase):
        def test__Multiname___repr__(self):
            r = _Multiname(0).__repr__()
            self.assertEqual(
                r,
                '[MULTINAME kind: 0x0]')

    unittest.main()

    return


# Generated at 2022-06-24 14:27:12.725665
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    return 'undefined'.__hash__() == _Undefined().__hash__()
_undefined = _Undefined()



# Generated at 2022-06-24 14:27:13.693887
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()) == False

# Generated at 2022-06-24 14:27:21.010775
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from swftools.swf import SWF

    interpreter = SWFInterpreter()
    fp = BytesIO(open('./test/actionscript_tests/do_nothing.swf', 'rb').read())
    swf = SWF(fp)
    for tag in swf.tags:
        if tag.code == 82:
            interpreter.tag_DoAction(tag)
            interpreter.tag_DoInitAction(tag)
    assert interpreter.constant_strings[0] == 'I can do nothing'
    assert interpreter.multinames[0].name == 'trace'

    # Test patch_function
    interpreter.patch_function()
    assert interpreter.constant_strings[0] == 'I can do nothing'
    assert False not in interpreter.multinames


# Generated at 2022-06-24 14:27:23.641682
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(join('test', 'swfs', 'test.swf'), 'rb'))
    # TODO write unit test
    pass

# Generated at 2022-06-24 14:27:26.693640
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    # a = _AVMClass('flash.display.Sprite', static_properties={})
    a = _AVMClass('foo', static_properties={})



# Generated at 2022-06-24 14:27:31.072753
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    instance1 = _AVMClass(0, '')
    instance2 = {'a': 1, 'b': 2, 'c': 'd'}
    # Call method
    instance1.register_methods(instance2)
    assert instance1.method_names == {'a': 1,'c': 'd', 'b': 2}, 'Wrong result for method register_methods of class _AVMClass' # Wrong result for method register_methods of class _AVMClass


# Generated at 2022-06-24 14:27:41.563915
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class AVMClass_Object(object):
        def __init__(self, name):
            self.name = name

    class AVMClass(object):
        def __init__(self, name):
            self.name = name
            self.static_scope = _ScopeDict(self)
            self.static_scope['name'] = name
            self.static_scope['obj'] = AVMClass_Object(self)

    # Make sure that __repr__ is correct
    print('%r' % AVMClass('AVMClass'))
    AVMClass('AVMClass')
test__ScopeDict.create_test = True



# Generated at 2022-06-24 14:27:45.080072
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    my_class = _AVMClass('test_class', 'test_class')
    my_object = my_class.make_object()
    assert my_object.avm_class == my_class, my_object.avm_class


# Generated at 2022-06-24 14:27:48.250283
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    return not _Undefined()
_Undefined = _Undefined()



# Generated at 2022-06-24 14:27:53.233424
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    test_parameters = [
        { 'avm_class': AVMClass('Foo'), },
    ]
    for test_parameter in test_parameters:
        avm_object = _AVMClass_Object(**test_parameter)
        print('%r.__repr__() == %r' % (avm_object, avm_object.__repr__()))


# Generated at 2022-06-24 14:27:58.341478
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(0, 'Test')
    avm_class.register_methods({
        'hello': 78,
        'goodbye': 79,
    })
    assert avm_class.method_names == {
        'hello': 78,
        'goodbye': 79,
    }
    assert avm_class.method_idxs == {
        78: 'hello',
        79: 'goodbye',
    }

# Generated at 2022-06-24 14:28:00.381181
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert '%r' % _AVMClass('name', {1: 'a', 2: 'b'}) == "_AVMClass('name', {1: 'a', 2: 'b'})"

# Generated at 2022-06-24 14:28:07.770168
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = _SWFInterpreter()
    expected_func_name = (
        '_level0.Video-159.VideoPlayer.duration',
        '_level0.Video-159.VideoPlayer.getConnectedTextStream(2)',
    )
    for func_name in expected_func_name:
        swf._patch_function(func_name)
    assert swf.method_pyfunctions



# Generated at 2022-06-24 14:28:08.816422
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__(): pass

_undefined = _Undefined()



# Generated at 2022-06-24 14:28:10.438404
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert _Multiname(0x0D).__repr__() == '[MULTINAME kind: 0xd]'



# Generated at 2022-06-24 14:28:15.352689
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class _AVMClass(object):
        name = 'foo'

    assert _AVMClass_Object(_AVMClass).__repr__() == 'foo#%x' % id(_AVMClass_Object(_AVMClass))



# Generated at 2022-06-24 14:28:18.260830
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    cls = _AVMClass('test_class')
    assert repr(cls()) == 'test_class#%x' % id(cls())
test__AVMClass_Object___repr__()



# Generated at 2022-06-24 14:28:23.099483
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    avm = SWFInterpreter()
    avm.swfstream.write(b'\x53\x57\x46\xFA\xFF\xFF\xFF\xFF\x00')
    avm.parse_swf_tag()



# Generated at 2022-06-24 14:28:32.601983
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    def test_deobfuscate(func_name, hex_code):
        code = unhexlify(hex_code)
        swf = SWF(code)
        swf.seek(0)
        sig = read_string(swf, 3)
        assert sig == 'FWS'
        version = _read_byte(swf)
        swf.skip_bytes(4)
        swf_size = _read_uint32_be(swf)
        assert swf_size == len(code)
        # TODO: obtain movie version from the header
        minimum_version = version if version <= 5 else 5
        avm_class = SWFInterpreter._make_class(swf, minimum_version)
        extract_function = swf.method_pyfunctions[func_name]

# Generated at 2022-06-24 14:28:33.734384
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert _Undefined().__hash__() == 0
Undefined = _Undefined()



# Generated at 2022-06-24 14:28:35.438280
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    a = _ScopeDict(None)
    assert repr(a) == 'None__Scope({})'



# Generated at 2022-06-24 14:28:37.758621
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    a = _AVMClass('a', 'a')
    b = a.make_object()
    assert str(b) == 'a#16'



# Generated at 2022-06-24 14:28:47.840200
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    if _AVMClass(42, 'TestClass') != \
            _AVMClass(42, 'TestClass', {}):
        raise ValueError


_TYPES = {
    0: 'number',
    1: 'string',
    2: 'boolean',
    3: 'object',
    4: 'movieclip',
    5: 'null',
    6: 'undefined',
    7: 'reference',
    8: 'ecmaarray',
    9: 'object end marker',
    10: 'strict array',
    11: 'date',
    12: 'long string',
}



# Generated at 2022-06-24 14:28:51.784473
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class _AVMClass(object):
        pass
    c = _AVMClass()
    c.name = '_AVMClass'
    o = _AVMClass_Object(c)
    assert repr(o) == '_AVMClass#%x' % id(o)


# Generated at 2022-06-24 14:29:00.715542
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import io
    import binascii
    # Test a simple function
    x = SWFInterpreter()

# Generated at 2022-06-24 14:29:05.745898
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():  # noqa: N802
    import unittest
    class Test(unittest.TestCase):
        def test(self):
            cls = _AVMClass('Cls')
            obj = cls.wrap(cls)
            assert repr(obj) == 'Cls#%x' % (id(obj))
    return unittest.defaultTestLoader.loadTestsFromTestCase(Test)



# Generated at 2022-06-24 14:29:06.763695
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


Undefined = _Undefined()



# Generated at 2022-06-24 14:29:16.013884
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .swf_utils import _get_swf_interpreter
    swfparser = _get_swf_interpreter('SWF with AVM2', 'avm2-patch-function.swf')
    func_names_before = set(swfparser.avm_class.method_pyfunctions.keys())
    swfparser.patch_function('decode', 1)
    func_names_after = set(swfparser.avm_class.method_pyfunctions.keys())
    assert func_names_before.issubset(func_names_after)

    decode_avm2 = swfparser.avm_class.method_pyfunctions['decode']
    assert decode_avm2.func_defaults == (1,)

# Generated at 2022-06-24 14:29:23.371268
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    avm = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'swfs', 'do_nothing.swf'), 'rb'))
    assert 'Main' in avm.classes
    cls = avm.classes['Main']
    assert isinstance(cls, _AVMClass)
    assert isinstance(cls.make_object(), _AVMClass_Object)


# Generated at 2022-06-24 14:29:32.654057
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import io
    import pyamf
    from av1an.SWF import SWFInterpreter

    def _read_io(f, count):
        res = f.read(count)
        assert len(res) == count
        return res

    with io.open(os.path.join('test', 'test.swf'), 'rb') as f:
        swf_file = f.read()
        # ignore first 8 bytes
        decoder = pyamf.get_decoder(
            io.BytesIO(swf_file),
            context=pyamf.Context(
                encoding=pyamf.AMF3))
        abc = decoder.readElement()
        class_def = decoder.readElement()

    swfi = SWFInterpreter(abc, class_def)

# Generated at 2022-06-24 14:29:40.568759
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_parse import parse_swf

    with open(os.path.join(os.path.dirname(__file__),
                           'testdata/swfdecrypt/main.swf'), 'rb') as f:
        swf = parse_swf(f)
        swfints = [SWFInterpreter(swf)]

        # Extract needed classes and methods
        def extract_class_method(class_name, method_name):
            for swfint in swfints:
                for c in swfint.avm_classes:
                    if c.name == class_name:
                        func = swfint.extract_function(c, method_name)
                        return func

        Brain = extract_class_method('Brain', 'Brain')

# Generated at 2022-06-24 14:29:42.288213
# Unit test for constructor of class _Multiname
def test__Multiname():
    return _Multiname(0x07)


# Generated at 2022-06-24 14:29:43.497923
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    obj = _AVMClass_Object(_AVMClass_Object)
    assert repr(obj) == '_AVMClass_Object#%x' % id(obj)
test__AVMClass_Object()


# Generated at 2022-06-24 14:29:46.648349
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    a1 = _AVMClass('foo', 0)
    assert a1.make_object()
    assert a1.make_object().avm_class is a1



# Generated at 2022-06-24 14:29:48.445669
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    obj = _AVMClass('foo').make_object()
    assert obj


# Generated at 2022-06-24 14:29:50.800445
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    testval = _Undefined()
    assert testval == 'undefined'

_undefined = _Undefined()



# Generated at 2022-06-24 14:29:53.830665
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_obj = _AVMClass_Object(object())
    assert isinstance(class_obj, _AVMClass_Object), \
        '_AVMClass_Object is not a _AVMClass_Object!'



# Generated at 2022-06-24 14:29:57.536076
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    import pytest

    assert not _Undefined()
    return


_undefined = _Undefined()



# Generated at 2022-06-24 14:30:00.021227
# Unit test for constructor of class _Undefined
def test__Undefined():
    # pylint: disable=pointless-statement
    assert not _Undefined()



# Generated at 2022-06-24 14:30:03.694993
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    a = _Undefined()
    assert a.__hash__() == 0


# Generated at 2022-06-24 14:30:13.944612
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import os
    import tempfile
    with tempfile.NamedTemporaryFile(suffix='.swf') as swf_fp:
        swf_fp.write('FWS'.encode('ascii'))
        swf_fp.write(b'\x09')
        swf_fp.write(b'\x00')
        old_pos = swf_fp.tell()
        swf_fp.seek(4)
        swf_fp.write(struct.pack('<i', old_pos))
        swf_fp.seek(old_pos)
        swf_fp.write(b'\x00\x00\x00\x00')

        swf_fp.seek(0)
        swf_interpreter = SWFInterpreter(swf_fp)


# Unit

# Generated at 2022-06-24 14:30:17.559586
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    # _AVMClass.__repr__
    # self.assertEqual(expected, _AVMClass.__repr__(x))
    assert True # TODO: implement your test here


# Generated at 2022-06-24 14:30:25.210420
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    a = _AVMClass(1, 'Class1')
    a.register_methods({'method1': 0, 'method2': 2})
    assert (
        a.method_idxs == {
            0: 'method1',
            2: 'method2',
        })
    assert (
        a.method_names == {
            'method1': 0,
            'method2': 2,
        })



# Generated at 2022-06-24 14:30:28.784867
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert len(_Undefined.__bool__.__code__.co_code) == 2
    assert _Undefined.__bool__.__code__.co_code[:2] == b'\x32\x00'
_Undefined_instance = _Undefined()



# Generated at 2022-06-24 14:30:38.741807
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    a = _AVMClass(0, 'a')
    m = {'foo': 0, 'bar': 1}
    a.register_methods(m)
    assert a.method_names == m
    assert a.method_idxs == dict((idx, name) for name, idx in m.items())

# test__AVMClass_register_methods()

    def get_method_names(self):
        return self.method_names.keys()

    def get_method_name(self, idx):
        return self.method_idxs.get(idx)

    def get_method_idx(self, name):
        return self.method_names.get(name)

    def get_method(self, idx):
        return self.methods.get(idx)


# Generated at 2022-06-24 14:30:44.382940
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    global standard_classes, _namespace_constructor_classes, _builtin_classes

    interpreter = SWFInterpreter()

# Generated at 2022-06-24 14:30:51.419476
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    def f():
        class TestClass:
            name = 'test'
        class avm_class:
            name = 'an avm class'
        o = _AVMClass_Object(avm_class)
        assert o.__repr__() == 'an avm class#%x' % id(o)
    f()



# Generated at 2022-06-24 14:30:53.300144
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert True, ('Info: _Undefined.__hash__() is not tested')

# Generated at 2022-06-24 14:31:02.731981
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    import swftools.swfdec_util as swfdec_util
    class_A = swfdec_util._AVMClass('A', None, None)
    class_A.register_methods({
        'a': 1,
        'b': 2,
    })
    assert class_A.method_names['a'] == 1
    assert class_A.method_names['b'] == 2
    assert class_A.method_idxs[1] == 'a'
    assert class_A.method_idxs[2] == 'b'



# Generated at 2022-06-24 14:31:11.804119
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-24 14:31:20.571937
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
