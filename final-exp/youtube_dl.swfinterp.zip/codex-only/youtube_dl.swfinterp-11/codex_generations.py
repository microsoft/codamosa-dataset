

# Generated at 2022-06-24 14:21:30.339285
# Unit test for method make_object of class _AVMClass

# Generated at 2022-06-24 14:21:40.751390
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = compat_BytesIO(open(path.join(
        path.dirname(__file__), 'tests', 'test.swf'), 'rb').read())
    interpreter = SWFInterpreter(swf)

    code_block = SWFCodeBlock.read_from_stream(compat_BytesIO(
        open(path.join(path.dirname(__file__), 'tests', 'test2.swf'), 'rb').read()))
    class_name = 'TestClass'

    avm_class = _AVMClass(class_name)
    avm_class.add_code_block('test', code_block)
    interpreter.add_class(avm_class)
    global_scope = interpreter.build_global_scope()

# Generated at 2022-06-24 14:21:44.421722
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    a = _AVMClass('', '')
    a.register_methods({'a': 0, 'b': 1})
    assert a.method_names == {'a': 0, 'b': 1}
    assert a.method_idxs == {0: 'a', 1: 'b'}
    a.register_methods({'c': 2})
    assert a.method_names == {'a': 0, 'b': 1, 'c': 2}
    assert a.method_idxs == {0: 'a', 1: 'b', 2: 'c'}



# Generated at 2022-06-24 14:21:47.903890
# Unit test for method __repr__ of class _AVMClass

# Generated at 2022-06-24 14:21:56.232695
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    # These values are picked from serialized object and class created by
    # ActionScript from
    # http://www.kaourantin.net/2005/02/reversing-as-bytecode-part-1.html
    avm_class = _AVMClass(
        184, 'flash.text.TextField',
        static_properties={
            'embedFonts': False,
            'antiAliasType': 'advanced',
        })
    assert avm_class.name == 'flash.text.TextField'
    assert avm_class.static_properties == {
        'embedFonts': False,
        'antiAliasType': 'advanced',
    }
test__AVMClass()



# Generated at 2022-06-24 14:21:57.249116
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    assert True

# Generated at 2022-06-24 14:22:00.779749
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass('name_idx', 'name')
    try:
        assert repr(obj) == '_AVMClass(%s)' % ('name')
    except AssertionError as e:
        raise AssertionError(
            'repr(obj) != \'_AVMClass(%s)\' got ' % ('name') + repr(e))



# Generated at 2022-06-24 14:22:06.589153
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    global undefined
    undefined = _Undefined()
    x = y = z = None

    def f(_):
        return x

    x = SWFInterpreter(b'', f, [])
    assert x._extract_function(lambda _: None) is None
    assert x._extract_function(None, lambda _: None) is None
    y = SWFInterpreter(
        b'{}',
        lambda _: {},
        [{'name': 'abc'}])
    assert y._extract_function(lambda _: None) is None
    assert y._extract_function(None, lambda _: None) is None

    def f(_):
        return x

    x = {'method': f}

# Generated at 2022-06-24 14:22:09.336684
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass('Test', 'Test')
    c.register_methods(dict(m1=1, m2=2))
    assert c.method_names == dict(m1=1, m2=2)
    assert c.method_idxs == dict(m1=1, m2=2)
test__AVMClass_register_methods()



# Generated at 2022-06-24 14:22:19.982745
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .__main__ import FlashExtractor
    from .swfdecompiler import SWFDecompiler
    from .swfdump import SWFDump
    from .compat_str import compat_str

    flash_data = compat_str(open('test/test_ab.swf', 'rb').read(), 'iso-8859-1')
    flash = SWF(flash_data)
    decompiler = SWFDecompiler(flash)
    decompiler.decompile()

    interp = SWFInterpreter(decompiler)
    # The interpreter shall fail without this
    def patch_function(avm_class, func_name, param_names, code_asm):
        # Add 'self' as the first argument
        if not param_names:
            param_names = [None]

# Generated at 2022-06-24 14:22:21.401889
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    _Undefined()
test__Undefined___hash__.test = True


Undefined = _Undefined()



# Generated at 2022-06-24 14:22:28.596850
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    from io import BytesIO
    from .utils import get_sample_file
    from .utils import get_sample_content
    from .utils import get_sample_content_unicode
    from .utils import get_sample_files_path
    import zlib

    with get_sample_file('swf1.swf') as f:
        swf_data = f.read()
        swf_data = swf_data[:8] + zlib.compress(swf_data[8:])
        assert _extract_tags(swf_data) != []

        with get_sample_file('swf3.swf') as f:
            swf_data = f.read()
            swf_data = swf_data[:8] + zlib.compress(swf_data[8:])
           

# Generated at 2022-06-24 14:22:31.651885
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    from .testcase import assertDeepAlmostEqual
    # test with dict
    a = {}
    a[_Undefined()] = 'test'
    assertDeepAlmostEqual(a, {})
    # test with set
    b = set()
    b.add(_Undefined())
    assertDeepAlmostEqual(b, set())


# Generated at 2022-06-24 14:22:37.193825
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from . import (AVM2, AVM2_CLASSES,
        AVM2_METHODS, AVM2_MULTINAMES)

    swf_interpreter = SWFInterpreter(
        AVM2, AVM2_CLASSES, [],
        AVM2_METHODS, AVM2_MULTINAMES)

    func = swf_interpreter.methods['String::indexOf']
    swf_interpreter.patch_function(func)
    func = swf_interpreter.methods['String::substring']
    swf_interpreter.patch_function(func)
    func = swf_interpreter.methods['String::substr']
    swf_interpreter.patch_function(func)

# Generated at 2022-06-24 14:22:48.174206
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    global __AVMClass_make_object___init__
    def __AVMClass_make_object___init__(self, name_idx, name, static_properties=None):
        self.name_idx = name_idx
        self.name = name
        self.method_names = {}
        self.method_idxs = {}
        self.methods = {}
        self.method_pyfunctions = {}
        self.static_properties = static_properties if static_properties else {}
        self.variables = _ScopeDict(self)
        self.constants = {}
    global __AVMClass_make_object___init___wrapped
    __AVMClass_make_object___init___wrapped = __AVMClass_make_object___init__

# Generated at 2022-06-24 14:22:50.827794
# Unit test for constructor of class _Multiname
def test__Multiname():
    mname = _Multiname(0)
    assert repr(mname) == '[_Multiname]'
test__Multiname()


# Generated at 2022-06-24 14:23:00.209231
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass('myclass', {'method1': 1, 'method2': 2})
    assert c.name == 'myclass'
    assert c.method_names == {'method1': 1, 'method2': 2}
    assert c.method_idxs == {1: 'method1', 2: 'method2'}
    assert c.methods == {}
    assert c.method_pyfunctions == {}
    assert c.variables == {'super': {}}
    assert c.constants == {}
    assert repr(c) == '_AVMClass(myclass)'
    assert repr(c.variables) == 'myclass__Scope({})'
    o = c.make_object()
    assert o.avm_class == c
    assert repr(o) == 'myclass#%s' % id

# Generated at 2022-06-24 14:23:07.880349
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_Object = _AVMClass(0, 'Object')
    print(class_Object)
    assert repr(class_Object) == '_AVMClass(Object)'
    obj_Object = class_Object.make_object()
    print(obj_Object)
    assert repr(obj_Object) == 'Object#%x' % id(obj_Object)



# Generated at 2022-06-24 14:23:12.982024
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class Object(object):
        def __init__(self):
            pass
        def __repr__(self):
            return '%s#%x' % (Object.__name__, id(self))
    class_object = _AVMClass_Object(
        _AVMClass(
            Object, Object.__name__, None, {}, set(), 0, False, False))
    assert repr(class_object) == '_AVMClass_Object#%x' % id(class_object)


# Generated at 2022-06-24 14:23:14.133406
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined(), 'Undefined.__nonzero__ must be False'

# Generated at 2022-06-24 14:23:24.178476
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    cls = _AVMClass('Hotness', 'YoutubePlayer')
    cls.register_methods({'isHot': 3})
    assert cls.method_names['isHot'] == 3
    assert cls.method_idxs[3] == 'isHot'
    cls.register_methods({'isNot': 1, 'isHot': 4})
    assert cls.method_names['isHot'] == 4
    assert cls.method_idxs[4] == 'isHot'
    assert cls.method_names['isNot'] == 1
    assert cls.method_idxs[1] == 'isNot'



# Generated at 2022-06-24 14:23:33.012968
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .abc import ABCFile

    abc = ABCFile.from_file('tests/files/cdns.abc')
    for name, method in abc.methods.items():
        if not hasattr(method, 'body'):
            continue
        interpreter = SWFInterpreter(abc)
        method_name = name
        interpreter.patch_function(method, method_name)
        ch = method_name[0]
        if ch >= '0' and ch <= '9':
            continue
        if method_name.startswith('tick'):
            continue
        if method_name.startswith('init'):
            continue

        print(method_name)

# Generated at 2022-06-24 14:23:41.102968
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    binary_data = open(c_flash_fmt_simple, 'rb').read()
    interpreter = SWFInterpreter()
    interpreter.parse(binary_data)
    assert isinstance(interpreter.avm_class, _AVMClass)
    assert 'Main' in interpreter.avm_class.variables
    assert 'stage' in interpreter.avm_class.variables
    assert 'Flash10_AccessibilityImplementation' in interpreter.avm_class.method_pyfunctions
    assert 'Flash10_AccessibilityImplementation' in interpreter.avm_class.method_names
    assert 'Flash10_AccessibilityImplementation' not in interpreter.avm_class.static_properties
    assert 'Flash10_AccessibilityImplementation' in interpreter.avm_class.static_methods

# Generated at 2022-06-24 14:23:45.307220
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class_obj = _AVMClass('name', None)
    class_obj.register_methods({'meth_name': 1})
    assert class_obj.method_names == {'meth_name': 1}
    assert class_obj.method_idxs == {1: 'meth_name'}


# Generated at 2022-06-24 14:23:46.602019
# Unit test for constructor of class _Multiname
def test__Multiname():
    obj = _Multiname(0x0A)
    assert obj.kind == 0x0A



# Generated at 2022-06-24 14:23:48.052391
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:23:51.990163
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    # Set up
    self = _AVMClass('Test', 0)

    method_names = {'test': 0, 'test2': 1}

    # Exercise
    self.register_methods(method_names)

    # Verify
    assert self.method_names == method_names
    assert self.method_idxs == dict(
        (idx, name)
        for name, idx in method_names.items())



# Generated at 2022-06-24 14:23:54.172365
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert bool(_Undefined()) is False
    assert bool(None) is False

# Generated at 2022-06-24 14:23:55.606243
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:23:57.756438
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert repr(_ScopeDict(None)) in (
        '_ScopeDict__Scope([])',
        '_ScopeDict__Scope({})')



# Generated at 2022-06-24 14:23:58.599398
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

# Generated at 2022-06-24 14:24:04.967441
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass('Class1', {
        'method1': 1, 'method2': 2,
        'method3': 3, 'method4': 4,
    })
    assert cls.name == 'Class1'
    assert cls.method_names == {
        'method1': 1, 'method2': 2,
        'method3': 3, 'method4': 4,
    }
    assert cls.method_idxs == {
        1: 'method1', 2: 'method2',
        3: 'method3', 4: 'method4',
    }
    assert cls.methods == {}
    assert cls.method_pyfunctions == {}
test__AVMClass()



# Generated at 2022-06-24 14:24:10.220132
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-24 14:24:21.618641
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter()


# Generated at 2022-06-24 14:24:24.189091
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(_Undefined()) is False
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'

Undefined = _Undefined()



# Generated at 2022-06-24 14:24:26.306906
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'



# Generated at 2022-06-24 14:24:30.794184
# Unit test for constructor of class _Multiname
def test__Multiname():
    multiname = _Multiname(kind=0x1B)
    assert multiname.kind == 0x1B
    assert multiname.__repr__() == '[MULTINAME kind: 0x1b]'



# Generated at 2022-06-24 14:24:36.810081
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    # Get a reference to the method to test
    tm = _ScopeDict.__repr__

    # Get a reference to a class to use
    tmp_class = _AVMClass_Object

    # Define some arguments
    tmp_obj = tmp_class(None)
    tmp_obj.name = 'hi'

    # Define some keyword arguments
    tmp_kwargs = {}

    # Call the method
    tmp_return = tm(tmp_obj, **tmp_kwargs)
    # Check the returned value
    assert tmp_return == 'hi__Scope({})'



# Generated at 2022-06-24 14:24:40.125470
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert repr(_AVMClass(1, 'Test')) == '_AVMClass(Test)'


# Generated at 2022-06-24 14:24:43.280329
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0
_undefined = _Undefined()



# Generated at 2022-06-24 14:24:45.143133
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
test__Undefined___bool__()


undefined = _Undefined()



# Generated at 2022-06-24 14:24:54.494989
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    """
    This is a unit test for the class `_SWFInterpreter`.
    """

# Generated at 2022-06-24 14:24:57.274177
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    obj = _Undefined()
    assert not obj


# Generated at 2022-06-24 14:25:05.727444
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from swftools.swf_interpreter import SWFInterpreter
    from swftools.swf_interpreter import OpCodes
    def extract_function(avm_class, func_name):
        return SWFInterpreter(None, avm_class).extract_function(func_name)
    # Note that extract_function is tested by test_swf_interpreter


# Class representing a SWF file, as per the SWF File Format Specification (pdf)

# Generated at 2022-06-24 14:25:08.717486
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    local_object = _Undefined()
    hash_value = local_object.__hash__()
    assert type(hash_value) == int


# Generated at 2022-06-24 14:25:11.445196
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    for method in _AVMClass(0, '').register_methods(()): pass

# end class _AVMClass



# Generated at 2022-06-24 14:25:12.448713
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0


# Generated at 2022-06-24 14:25:14.208766
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    value = _Undefined()
    assert not value
test__Undefined___bool__()



# Generated at 2022-06-24 14:25:21.144795
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    code = u'\x43\x00\x02\x61\x63\x46\x00\x00\x0b\x01\x00\x02\x00\x01\x00\x11\x15'
    code += u'\x07\x02\x01\x01\x11\x01\x01\x0b\x01\x00\x02\x00\x01\x00\x11\x01\x01'
    code += u'\x0b\x01\x00\x02\x00\x01\x00\x11\x01\x03\x01\x01\x0b'

    it = SWFInterpreter(None, None, None)
    def f(args):
        return args
    it.extract_

# Generated at 2022-06-24 14:25:23.429616
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    o = _AVMClass_Object(_AVMClass(name='String'))
    assert repr(o) == 'String#0x%x' % id(o)

# Generated at 2022-06-24 14:25:35.944024
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-24 14:25:37.298653
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    obj = _Undefined()
    assert obj.__repr__() == 'undefined'
_undefined = _Undefined()



# Generated at 2022-06-24 14:25:40.484315
# Unit test for constructor of class _Multiname
def test__Multiname():
    m = _Multiname(0)
    assert m.kind == 0 and repr(m) == '[MULTINAME kind: 0x0]'


# Generated at 2022-06-24 14:25:49.192741
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    import random
    import string
    random_id = ''.join([random.choice(string.hexdigits.lower()) for i in range(0,8)])
    random_name = ''.join([random.choice(string.ascii_letters) for i in range(0,8)])
    o = _AVMClass_Object(_AVMClass(random_name))
    assert repr(o) == random_name+'#'+random_id
test__AVMClass_Object___repr__()



# Generated at 2022-06-24 14:25:58.009264
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    f = io.BytesIO(open(os.path.join(os.path.dirname(__file__),
                                     'tests/SWFInterpreter-patch-function.bin'),
                        'rb').read())
    swf = SWF(f)
    interpreter = swf.tags[0]._body
    for script in interpreter.scripts:
        for trait in script.traits:
            trait.patch_function(interpreter)

    assert isinstance(script.traits[0].name, _Multiname)
    assert script.traits[0].name.name == 'MultinameTrait'
    assert script.traits[0].name.namespace.type == 'private'
    script.traits[0].name.name = 'test'
    import pprint

# Generated at 2022-06-24 14:26:03.225144
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass(0, 'name', None)
    r = repr(obj)
    assert r.startswith('_AVMClass(')
    assert r.endswith(')')

# Generated at 2022-06-24 14:26:05.000597
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:26:08.716875
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(_AVMClass_Object)) == '_AVMClass_Object#%x' % id(_AVMClass_Object)



# Generated at 2022-06-24 14:26:15.295564
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    '''
    Unit test for method extract_class of class SWFInterpreter
    '''
    filename = os.path.join(
        os.path.dirname(__file__), 'test.swf')
    with open(filename, 'rb') as fd:
        swf = fd.read()
    interp = SWFInterpreter(swf)
    interp.extract_class('TestClass')

# Generated at 2022-06-24 14:26:17.961538
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter(b'test')
    assert isinstance(interpreter, SWFInterpreter)



# Generated at 2022-06-24 14:26:21.938497
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass(name_idx=None, name=None, static_properties=None)
    assert obj.__repr__() == '_AVMClass(None)', obj.__repr__()



# Generated at 2022-06-24 14:26:32.589965
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf_reader import SWF
    from .utils import make_read_file
    read_file = make_read_file(open(
        os.path.join(os.path.dirname(__file__),
                     'tests/swf_interpreter_test.swf')), 'rb')
    swf = SWF(read_file)
    assert 'SWFInterpreterTest' in swf.tags
    interp = SWFInterpreter(swf)
    assert hasattr(interp, 'SWFInterpreterTest')
    interp.SWFInterpreterTest.fields
    assert 'res' in interp.SWFInterpreterTest.static_properties
    assert 'method' in interp.SWFInterpreterTest.method_pyfunctions



# Generated at 2022-06-24 14:26:33.708682
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not bool(_Undefined())



# Generated at 2022-06-24 14:26:38.604951
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    obj = _AVMClass_Object(None)
    assert str(obj) == '_AVMClass_Object#%x' % id(obj)
# End unit test for method __repr__ of class _AVMClass_Object



# Generated at 2022-06-24 14:26:40.783338
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    obj = _ScopeDict('ClassName')
    assert repr(obj) == 'ClassName__Scope({})'



# Generated at 2022-06-24 14:26:43.228110
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(True)
    assert bool(1)
    assert not bool(False)
    assert not bool(0)
    assert not bool(_Undefined())


Undefined = _Undefined()



# Generated at 2022-06-24 14:26:48.558133
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    def test_body(avm_class):
        avm_obj = avm_class.make_object()
        assert isinstance(avm_obj, _AVMClass_Object)
        assert avm_obj.avm_class is avm_class
    test_body(_AVMClass('asdf', 'asdf'))

# Generated at 2022-06-24 14:26:50.686281
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert '%r' % _Multiname(1) == '[MULTINAME kind: 0x1]'



# Generated at 2022-06-24 14:26:53.904090
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    def _test_code(kind):
        multiname = _Multiname(kind)
        return multiname.__repr__()

    assert _test_code(0x0D) == '[MULTINAME kind: 0xd]'



# Generated at 2022-06-24 14:26:56.367383
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    # Test for method __repr__ of class AVMClass
    assert repr(_AVMClass('abc', None)) == '_AVMClass(abc)'



# Generated at 2022-06-24 14:27:03.069067
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    m = _Multiname(0x07)     # MULTINAME_QName
    assert str(m) == '[MULTINAME kind: 0x7]'
    m = _Multiname(0x0d)     # MULTINAME_RTQName
    assert str(m) == '[MULTINAME kind: 0xd]'
    m = _Multiname(0x0f)     # MULTINAME_RTQNameL
    assert str(m) == '[MULTINAME kind: 0xf]'
    m = _Multiname(0x10)     # MULTINAME_Multiname
    assert str(m) == '[MULTINAME kind: 0x10]'
    m = _Multiname(0x11)     # MULTINAME_MultinameL

# Generated at 2022-06-24 14:27:05.336097
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    _Multiname.__repr__
    # TODO



# Generated at 2022-06-24 14:27:14.981361
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    ctx = lzma.LZMADecompressor()
    with open(test_data, 'rb') as f:
        data = f.read()
    uncompressed = ctx.decompress(data)
    uncompressed = BytesIO(uncompressed)
    swf = SWF(uncompressed)
    assert swf.version == 'FWS9'
    assert len(swf.tags) == 30
    # TODO unit test for extract_avm_class
    for tag in swf.tags:
        if isinstance(tag, DoABC):
            interpreter = SWFInterpreter(tag)
            break
    else:
        return
    # test extract_function
    assert interpreter.constant_strings[0] == 'NetConnection'  # we can ignore

# Generated at 2022-06-24 14:27:26.739431
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    def test_extract_class(swf_filename):
        swf = parse_swf(open(swf_filename, 'rb'))
        with open(swf_filename, 'rb') as f:
            swf = SWF(f)
        interpreter = SWFInterpreter(swf)
        assert len(swf.tags) == 1
        tag = swf.tags[0]
        assert tag.name == 'DoABC'
        interpreter.extract_class(tag)

    test_extract_class(
        os.path.join(os.path.split(__file__)[0], 'test', 'unit',
                     'test_abc.swf'))

# Generated at 2022-06-24 14:27:27.735318
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    print('FIXTEST: test__ScopeDict___repr__')



# Generated at 2022-06-24 14:27:30.562275
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert bool(Undefined) == False
    assert hash(Undefined) == 0
    assert str(Undefined) == 'undefined'
Undefined = _Undefined()



# Generated at 2022-06-24 14:27:37.717190
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    name_in = 'foo'
    value_in = 'bar'
    avm_class_in = 'baz'
    test_obj = _ScopeDict(avm_class_in)
    test_obj[name_in] = value_in
    assert test_obj.__repr__() == 'baz__Scope({\'foo\':\'bar\'})'



# Generated at 2022-06-24 14:27:49.339849
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swfi = SWFInterpreter({})

    def test_function_0(args):
        assert len(args) == 0
        return 0

    assert test_function_0([]) == 0
    test_function_1 = swfi.patch_function(test_function_0, 1)

    assert test_function_1 is not test_function_0
    assert test_function_1([]) == 0
    assert test_function_1([1]) == 0

    test_function_2 = swfi.patch_function(test_function_0, 2)
    assert test_function_2 is not test_function_1
    assert test_function_2 is not test_function_0
    assert test_function_2([]) == 0
    assert test_function_2([1]) == 0

# Generated at 2022-06-24 14:27:52.638790
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class MyClass(object):
        @property
        def name(self):
            return 'MyClass'

    avm_obj = _AVMClass_Object(MyClass())
    assert avm_obj.avm_class is MyClass()



# Generated at 2022-06-24 14:28:01.183768
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    i = SWFInterpreter()

    coder = io.BytesIO(b'\x1B\x03\x00')
    res = i.patch_function(coder, 5, '', [], {})
    assert res is None

    coder = io.BytesIO(b'\x1B\x03\x00')
    res = i.patch_function(coder, 2, '', [], {})
    assert res == 3

    coder = io.BytesIO(b'\x1B\x03\x00')
    res = i.patch_function(coder, -3, '', [], {})
    assert res == -3


# Generated at 2022-06-24 14:28:10.306228
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    filename = '../files/as3-examples/Square.swf'
    with open(filename, 'rb') as stream:
        as3_code = _extract_as3_code(stream.read())
    as3c = _AVMClass(as3_code)
    as3c.__dict__['name'] = '%s()' % filename
    as3i = _AVMInstance(as3c)
    d = _ScopeDict(as3c)
    assert repr(d) == as3c.name + '__Scope({})'



# Generated at 2022-06-24 14:28:11.304262
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    pass



# Generated at 2022-06-24 14:28:21.415201
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    """Test the constructor of class SWFInterpreter"""
    avm = SWFInterpreter(SWF(open(fixture_input_path('test.swf'), 'rb')))
    assert len(avm.constant_strings) == 6
    assert avm.constant_strings[0] == '_'
    assert avm.constant_strings[1] == '_level0'
    assert avm.constant_strings[2] == 'movieClip'
    assert avm.constant_strings[3] == '_root'
    assert avm.constant_strings[4] == 'root'
    assert avm.constant_strings[5] == 'avm2'

    assert len(avm.code_strings) == 3
    assert avm.code_strings[0] == 'src'

# Generated at 2022-06-24 14:28:22.779709
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()



# Generated at 2022-06-24 14:28:24.358463
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    u = _Undefined()
    assert not u

# Generated at 2022-06-24 14:28:25.956677
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

_undefined = _Undefined()



# Generated at 2022-06-24 14:28:28.871530
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    m = _Multiname(0x1d)
    assert repr(m) == '[MULTINAME kind: 0x1d]'
# End unit test for method __repr__ of class _Multiname



# Generated at 2022-06-24 14:28:32.308233
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    mock_name = 'mock_name'
    mock_static_properties = {}

    arg0 = _AVMClass(mock_name, {}, mock_static_properties)
    res0 = repr(arg0)

    assert res0 == "_AVMClass(mock_name)"



# Generated at 2022-06-24 14:28:36.633662
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass(1, 'Object', {'variable': 0, 'constant': 1})
    assert cls.name_idx == 1
    assert cls.name == 'Object'
    assert cls.static_properties == {'variable': 0, 'constant': 1}


# Generated at 2022-06-24 14:28:37.547030
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


# Generated at 2022-06-24 14:28:50.216619
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import io

    tor = SWFTagReader()

    with open('test/flash/sample.swf', 'rb') as f:
        tor.parse(f)
    swf = tor.swf

    # The following two lines are for debugging purposes
    with open('test/flash/sample.dump', 'wb') as f:
        swf.dump_header(f)

    for tag in swf.tags:
        if isinstance(tag, DefineBinaryDataTag):
            if tag.name == 'strings.txt':
                strings_txt = tag
            elif tag.name == 'rawxml.xml':
                rawxml_xml = tag
            elif tag.name == 'urm.txt':
                urm_txt = tag
    str_io = io.StringIO(str(strings_txt.data))
   

# Generated at 2022-06-24 14:28:52.321332
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    obj = _Undefined()
    assert obj.__hash__() == 0



# Generated at 2022-06-24 14:28:55.595315
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    m = _AVMClass(1, 'aaa')  # noqa: F841
    assert True, 'Constructed'



# Generated at 2022-06-24 14:29:07.663136
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter()
    swf.extract_function('MyClass', 'doSomething')
    return True
# Test if SWFInterpreter has attribute extract_function
assert hasattr(SWFInterpreter, 'extract_function'), \
    'You must implement a method named extract_function'
# Test if SWFInterpreter has method extract_function
assert callable(getattr(SWFInterpreter, 'extract_function')), \
    'extract_function must be a method'
# Test if SWFInterpreter attribute extract_function is working
assert test_SWFInterpreter_extract_function(), \
    'extract_function method must work'
 
# Helper function to get a SWFInterpreter attribute extract_method

# Generated at 2022-06-24 14:29:13.529928
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class _DummyAVMClass(object):
        name = '_DummyAVMClass'

    obj = _AVMClass_Object(_DummyAVMClass())
    if obj.__repr__() != '_DummyAVMClass#%x' % id(obj):
        raise AssertionError('%r != _DummyAVMClass#%x' % (obj.__repr__(), id(obj)))
# End unit test for method __repr__


# Generated at 2022-06-24 14:29:16.440832
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    class_a = _AVMClass('foo', None)
    obj = _AVMClass_Object(class_a)
    assert repr(obj) == 'foo#%x' % id(obj)



# Generated at 2022-06-24 14:29:22.871499
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class_object = _AVMClass_Object(None)
    assert class_object.__repr__() == '#%x' % (id(class_object))


# Defines a class that is used to encapsulate metadata and methods of the
# ActionScript class of the same name. This class is instantiated by the
# constructor of class _AVMClass_Object

# Generated at 2022-06-24 14:29:31.930051
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    with open(path.join(path.dirname(__file__), 'test.swf'), 'rb') as f:
        swf_data = f.read()
    interp = SWFInterpreter('test.swf', swf_data)
    interp.extract_function(
        interp._avm_classes['test'], 'test')
    swf_data = compat_chr(9) + compat_chr(0) + compat_chr(10) + compat_chr(0)
    interp = SWFInterpreter('test.swf', swf_data)
    interp.extract_function(
        interp._avm_classes['test'], 'test')



# Generated at 2022-06-24 14:29:35.246817
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert str(_Multiname(0)) == '[MULTINAME kind: 0x0]'
    assert str(_Multiname(0x23)) == '[MULTINAME kind: 0x23]'



# Generated at 2022-06-24 14:29:38.399948
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    avm_class = _AVMClass('Object', 0)
    obj = avm_class.make_object()
    assert obj.__doc__ is None
    assert obj.avm_class is avm_class

# Generated at 2022-06-24 14:29:45.214028
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class _AVMClass_Object_Undefined(object):
        pass
    undefined = _AVMClass_Object_Undefined()
    class _AVMClass_Object(object):
        def __init__(self, avm_class, members={}):
            self.avm_class = avm_class
            self.members = members
        def get(self, key, default=None):
            return self.members.get(key, default)
        def __getitem__(self, key):
            return self.members[key]
        def __setitem__(self, key, value):
            self.members[key] = value
    def _AVMClass_new(variables, static_properties, method_names):
        res_class = _AVMClass(variables, static_properties, method_names)
        return res

# Generated at 2022-06-24 14:29:46.289396
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0

# Generated at 2022-06-24 14:29:49.810477
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class _DummyAVMClass(object):
        name = 'DummyAVMClass'
    assert repr(_ScopeDict(_DummyAVMClass())) == 'DummyAVMClass__Scope()'
test__ScopeDict()



# Generated at 2022-06-24 14:29:58.132162
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import pyamf
    import datetime
    from pyamf.util import BufferedByteStream


# Generated at 2022-06-24 14:30:00.157739
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    method = _AVMClass(
        name_idx=None,
        name=None
    )
    assert method.__repr__() == "_AVMClass(None)"


# Generated at 2022-06-24 14:30:09.553594
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass('test', 3)
    assert class_.name == 'test'
    assert class_.name_idx == 3
    assert class_.method_names == {}
    assert class_.method_idxs == {}
    assert class_.methods == {}
    assert class_.static_properties == {}
    assert len(class_.variables) == 0

    print('Tests passed')

_AVMClass_Object.__module__ = '__main__'
_ScopeDict.__module__ = '__main__'
_AVMClass.__module__ = '__main__'

# test__AVMClass()



# Generated at 2022-06-24 14:30:14.291297
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    # _Undefined.__repr__
    # Test for method __repr__ of class _Undefined
    # Unit test for method __repr__ of class _Undefined
    assert str(_Undefined()) == 'undefined'
Undefined = _Undefined()



# Generated at 2022-06-24 14:30:17.304517
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    o = _AVMClass(0, 'foo', {'x': 1})
    assert o.static_properties == {'x': 1}
    assert o.variables == {}



# Generated at 2022-06-24 14:30:25.739563
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    a = _AVMClass_Object(
        _AVMClass(
            name=b'vimeo11234567890',
            extends=_AVMClass_Object,
            members={
                b'foo': _AVMClass_Object,
            }))
    assert repr(a) == 'vimeo11234567890#%x' % id(a)


# Class member types that are references to other classes
_AVMClass_Object_types = [
    _AVMClass_Object,
]



# Generated at 2022-06-24 14:30:34.543527
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    klass = _AVMClass(0x0123, 'Foo', {'static_prop1': None})
    assert klass.method_names == {}
    assert klass.method_idxs == {}
    assert klass.method_pyfunctions == {}

    def func1a():
        pass
    def func1b():
        pass
    def func2():
        pass

    klass.register_methods({
        'method1': 0x1234,
        'method2': 0x4567,
    })

    klass.methods.update({
        0x1234: func1a,
        0x4567: func2,
    })
    klass.method_pyfunctions.update({
        0x1234: True,
    })


# Generated at 2022-06-24 14:30:36.595586
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert str(_Undefined()) == 'undefined'
    assert not _Undefined()


Undefined = _Undefined()



# Generated at 2022-06-24 14:30:39.062748
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    v = _AVMClass('a', 'b', 'c')
    assert repr(v) == "_AVMClass('a', 'b', 'c')"

# Generated at 2022-06-24 14:30:48.971480
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    from .compat import unittest
    class Test_AVMClass_make_object(unittest.TestCase):
        def setUp(self):
            pass
        def test_1(self):
            self.assertEqual(1, 1)
        def test_2(self):
            self.assertEqual(1, 1)
        def test_3(self):
            self.assertEqual(1, 1)
        def test_4(self):
            self.assertEqual(1, 1)
        def test_5(self):
            self.assertEqual(1, 1)
        def test_6(self):
            self.assertEqual(1, 1)
        def test_7(self):
            self.assertEqual(1, 1)
        def test_8(self):
            self

# Generated at 2022-06-24 14:30:50.582822
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert repr(_AVMClass('name')) == "_AVMClass('name')"

# Generated at 2022-06-24 14:31:02.785697
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    code = '\x12\x00\x2e\x05\x2d\x07\x03\x81\x02\x00\x01\x07\x03\x81\x02\x00'
    swf = SWFInterpreter(io.BytesIO(code))
    assert swf.extract_class() == 'ScriptObject$'
    assert len(swf.constant_strings) == 1
    assert swf.constant_strings[0] == 'ScriptObject$'
    assert len(swf.multinames) == 1
    # XXX what is the expected value?
    # assert swf.multinames[0] == 'aviable'
    assert swf.classes['ScriptObject$'].super_name == 'ASObject$'

# Generated at 2022-06-24 14:31:05.388897
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    assert _AVMClass('name', {}).make_object()
    assert _AVMClass('name', {}).make_object().avm_class.name == 'name'



# Generated at 2022-06-24 14:31:10.559735
# Unit test for constructor of class _Undefined
def test__Undefined():
    u = _Undefined()
    assert not u
    assert not bool(u)
    assert not u.__nonzero__()
    assert u.__str__() == 'undefined'
    assert u.__repr__() == 'undefined'
    d0 = {}
    d0[u''] = 'test'
    d1 = {}
    d1[u] = 'test'
    assert d0 == d1



# Generated at 2022-06-24 14:31:12.892201
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:31:14.592549
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    u = _Undefined()
    assert hash(u) == 0



# Generated at 2022-06-24 14:31:17.554616
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert isinstance(_Undefined(), _Undefined)
    assert hash(_Undefined()) == 0
    assert hash(_Undefined()) == hash(_Undefined())


Undefined = _Undefined()



# Generated at 2022-06-24 14:31:19.860298
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == 'undefined'


_undefined = _Undefined()

