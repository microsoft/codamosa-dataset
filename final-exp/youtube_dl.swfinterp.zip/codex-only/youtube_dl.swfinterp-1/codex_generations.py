

# Generated at 2022-06-24 14:21:31.161286
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .test import fixture

    super_ = SWFInterpreter.extract_function

    def extract_function(self, avm_class, func_name):
        if avm_class.qname == 'flash.utils::Timer':
            if func_name == 'start':
                def func(args):
                    assert len(args) == 1
                    assert isinstance(args[0], int)
                return func
            elif func_name == 'stop':
                return lambda x: None
            else:
                return super_(self, avm_class, func_name)
        else:
            return super_(self, avm_class, func_name)

    SWFInterpreter.extract_function = extract_function


# Generated at 2022-06-24 14:21:41.433764
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    res = repr(_Multiname(0x0))
    assert res == '[MULTINAME kind: 0x0]', 'res: %s' % res
    res = repr(_Multiname(0x1))
    assert res == '[MULTINAME kind: 0x1]', 'res: %s' % res
    res = repr(_Multiname(0x2))
    assert res == '[MULTINAME kind: 0x2]', 'res: %s' % res
    res = repr(_Multiname(0x3))
    assert res == '[MULTINAME kind: 0x3]', 'res: %s' % res
    res = repr(_Multiname(0x4))
    assert res == '[MULTINAME kind: 0x4]', 'res: %s' % res
    res = repr

# Generated at 2022-06-24 14:21:47.752675
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test_files/test_swf/test_swfinterpreter.swf', 'rb'))
    assert isinstance(swf, SWFInterpreter)
    s = swf.multinames[0]
    assert isinstance(s, compat_str)
    assert s == 'String'
    swf.extract_function(Class, 'new')
    swf.extract_function(Class, 'get_length')
    swf.extract_function(Class, 'get_lastIndexOf')
    swf.extract_function(Class, 'get_split')
    swf.extract_function(Class, 'get_charCodeAt')
    swf.extract_function(Class, 'get_slice')

# Generated at 2022-06-24 14:21:52.021680
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter(b'\x00\x21' + (b'\xFF' * 100) + b'\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    assert interpreter.major == 0
    assert interpreter.minor == 33
    assert len(interpreter.file_attributes) == 100


# Generated at 2022-06-24 14:21:57.263709
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    def build_function(coder):
        """
        Wrap a coder byte string into a function
        """
        coder = bytearray(coder)
        arg_count = 0
        name = ''
        return _Function(name, arg_count, coder)
    def check_result(expected, *arguments):
        """
        Check if the function returns the expected result
        """
        returned = function(*arguments)
        assert returned == expected, (
            '%r returned %r, expected %r'
            % (function, returned, expected))
    # Successful test
    si = SWFInterpreter()
    si.register_builtin('print', None, None, None)
    fname = 'test'
    code_with_no_args = b'\x03'  # returnvoid
    code

# Generated at 2022-06-24 14:22:05.999352
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    avm_class = _AVMClass('Test', None)
    avm_class.add_method('foo', None)
    assert repr(_ScopeDict(avm_class)) == (
        'Test__Scope(%s)' % collections.OrderedDict([
            ('__proto__', _AVMClass_Object(avm_class)),
            ('super', _AVMClass_Object(avm_class)),
            ('__class', _AVMClass_Object(avm_class)),
            ('globals', {}),
        ]))



# Generated at 2022-06-24 14:22:12.216716
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    obj = _AVMClass(0, '')
    try:
        repr(obj)
    except Exception:
        print(
            'FAIL: __repr__ for _AVMClass raised exception' +
            ' -- ERROR EXPECTED')
    else:
        print('PASS: __repr__ for _AVMClass did not raise exception')



# Generated at 2022-06-24 14:22:13.247823
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == 'undefined'

Undefined = _Undefined()



# Generated at 2022-06-24 14:22:21.402718
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-24 14:22:27.856574
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    import sys
    import io
    import unittest

    if hasattr(sys, '_clear_type_cache'):
        sys._clear_type_cache()

    class Mock_avm_class(object):
        def __init__(self):
            self.name = 'Mock_avm_class'
    mock_avm_class = Mock_avm_class()
    mock_self = _AVMClass_Object(mock_avm_class)

    # test __repr__
    expected_result = 'Mock_avm_class#%x' % (id(mock_self), )
    assert (expected_result == repr(mock_self))


AVMData = collections.namedtuple('AVMData', [
    'version', 'constants', 'methods', 'classes'])



# Generated at 2022-06-24 14:22:29.175883
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    print(_Undefined().__hash__())  # expected to print 0
Undefined = _Undefined()



# Generated at 2022-06-24 14:22:30.141661
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    _ScopeDict(None).__repr__()



# Generated at 2022-06-24 14:22:33.459039
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    with open(testdata_path('example.swf'), 'rb') as swf_file:
        swf = SWF(swf_file)
    swf_interp = SWFInterpreter(swf)
    swf_interp.parse_doabc()
    resfunc = swf_interp.extract_function(swf_interp.loader_class, 't')
    assert resfunc([]) == 'undefined'
    assert resfunc(['abc']) == 'abc'



# Generated at 2022-06-24 14:22:38.773430
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import copy

    def method_add(value1, value2):
        return value1 + value2

    func_name = 'add'

    interpreter = SWFInterpreter()
    interpreter.classes[''] = _AVMClass(
        '', [func_name], {'': None})
    interpreter.classes[''].method_pyfunctions[func_name] = method_add
    interpreter.patch_function('', func_name)

    globals_ = {'': {'': {}}}

    func = interpreter.classes[''].method_pyfunctions[func_name]
    assert func(globals_, None, 1, 2) == 3

    globals_copy = copy.deepcopy(globals_)
    globals_copy['add_args'] = [None, 1, 2]

# Generated at 2022-06-24 14:22:40.718385
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert "%r" % _Multiname(0x10) == ('[_Multiname(0x10)]')



# Generated at 2022-06-24 14:22:41.802467
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__(): assert str(_Undefined()) == 'undefined'

Undefined = _Undefined()



# Generated at 2022-06-24 14:22:43.408422
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():

    _Undefined()
_Undefined = _Undefined()



# Generated at 2022-06-24 14:22:45.678811
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x0d)) == '[MULTINAME kind: 0x0d]'
    assert repr(_Multiname(0x1d)) == '[MULTINAME kind: 0x1d]'



# Generated at 2022-06-24 14:22:48.076681
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:22:50.375675
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert str(
        _Multiname(0x0d)) == '[MULTINAME kind: 0xd]'



# Generated at 2022-06-24 14:22:53.056094
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    _Undefined___repr__ = _Undefined().__repr__
    assert _Undefined___repr__() == 'undefined'


Undefined = _Undefined()



# Generated at 2022-06-24 14:22:58.458624
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(1, 'foo')

    c.register_methods({'bar': 1})

    ob = c.make_object()
    assert isinstance(ob, _AVMClass_Object)
    assert ob.avm_class is c

    assert repr(c) == '_AVMClass(foo)'

    assert repr(c.variables) == 'foo__Scope({})'

test__AVMClass()



# Generated at 2022-06-24 14:22:59.619084
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    _ScopeDict({'x': 1}).__repr__()



# Generated at 2022-06-24 14:23:01.754999
# Unit test for constructor of class _Undefined
def test__Undefined():
    undefined = _Undefined()
    assert not undefined
    assert str(undefined) == 'undefined'
    assert hash(undefined) == 0
test__Undefined()



# Generated at 2022-06-24 14:23:05.253408
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() is _Undefined()


_undefined = _Undefined()



# Generated at 2022-06-24 14:23:08.181717
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = _SWFInterpreter()
    assert_raises(NotImplementedError,
                  interpreter.patch_function, 'some_name', b'\x10\x00\x00\x01\x09')

# Generated at 2022-06-24 14:23:12.948965
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    c = _AVMClass(0, 'ClassName', {'foo': 'bar'})
    assert c.variables == {}
    assert c.method_names == {}
    assert c.method_idxs == {}
    assert c.methods == {}
    assert c.static_properties == {'foo': 'bar'}
    assert c.constants == {}
    assert c.name_idx == 0
    assert c.name == 'ClassName'



# Generated at 2022-06-24 14:23:14.248650
# Unit test for constructor of class _Undefined
def test__Undefined():
    u = _Undefined()
    assert not u


_undefined = _Undefined()



# Generated at 2022-06-24 14:23:16.414658
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    undef = _Undefined()
    assert hash(undef) == 0

# Generated at 2022-06-24 14:23:27.684683
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import os.path

    # Sanity check: don't try to run the actual test if aab/ab/
    # are not available
    for test_file_name in (
            'aab.swf', 'ab.swf',
            'bbb-avm2.swf', 'bbb.swf',
            'bbb_encrypted.swf',
            'bbb_encrypted2.swf',
            'bbb_encrypted3.swf'):
        if not os.path.exists(test_file_name):
            return
        if not os.path.isfile(test_file_name):
            return

    def assert_equal(a, b):
        if a != b:
            raise AssertionError('%r != %r' % (a, b))

    # Check a simple .a

# Generated at 2022-06-24 14:23:32.602540
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert bool(_Undefined()) is False
    assert _Undefined().__hash__() == 0
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'
    pass

# Generated at 2022-06-24 14:23:34.408789
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    undef = _Undefined()
    assert repr(undef) == 'undefined'


Undefined = _Undefined()



# Generated at 2022-06-24 14:23:40.386235
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    cls = _AVMClass('', '', {})
    cls.register_methods({'a': 1, 'b': 2})
    assert cls.method_names == {'a': 1, 'b': 2}
    assert cls.method_idxs == {1: 'a', 2: 'b'}



# Generated at 2022-06-24 14:23:42.076375
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interp = SWFInterpreter(io.open('tests/data/Test.swf', 'rb'))
    interp.extract_class('Test')


# Generated at 2022-06-24 14:23:47.758274
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = open(os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test.swf'), 'rb').read()
    swfinter = SWFInterpreter(swf)
    avm_class = swfinter.extract_class(0)
    foo_func = swfinter.extract_function(avm_class, 'foo')
    assert foo_func() == 'Hello World!'

    bar_func = swfinter.extract_function(avm_class, 'bar')
    assert bar_func(['one', 'two', 'three']) == [
        'one', 'two']

    bar_func = swfinter.extract_function(avm_class, 'bar')

# Generated at 2022-06-24 14:23:53.501726
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    class Foo(object):
        def __init__(self):
            self.name = 'Foo'
    obj = _AVMClass_Object(Foo())
    assert obj.repr() == 'Foo#%x' % id(obj)



# Generated at 2022-06-24 14:23:57.931389
# Unit test for constructor of class _Multiname
def test__Multiname():
    import sys
    mn = _Multiname(1)
    assert mn.kind == 1
    # Test that __repr__ is accessible, it's used by logging
    assert 'Multiname' in str(mn)
    assert 'Multiname' in repr(mn)
    assert not mn.__doc__
    assert not mn.__module__



# Generated at 2022-06-24 14:24:09.528058
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import gzip
    import os
    import tarfile
    import shutil
    import tempfile
    
    interpreter = SWFInterpreter()


# Generated at 2022-06-24 14:24:12.251045
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(None)) == 'None#<uninitialized>'



# Generated at 2022-06-24 14:24:15.781673
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    s = _AVMClass(0, '')
    # pylint:disable=protected-access
    assert repr(s.make_object()) == '<__main__._AVMClass object at 0x%x>#%x' % (id(_AVMClass_Object), id(s.make_object()))

# Generated at 2022-06-24 14:24:19.842493
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    from .avm import AVMClass
    class Foo(AVMClass):
        def __init__(self):
            super(Foo, self).__init__()
            self.name = 'Foo'
    scope = _ScopeDict(Foo())
    scope['aaa'] = 5
    scope['bbb'] = 'hello'
    assert repr(scope) == "Foo__Scope({'aaa': 5, 'bbb': 'hello'})"



# Generated at 2022-06-24 14:24:32.391290
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    class A:
        def foo_bar(self, x):
            return x + 4

        def foo_bar_baz(self, x):
            return x + 5

    class B:
        def foo_bar(self, x):
            return x + 7
    
    a = A()
    b = B()
    swfi = SWFInterpreter()

    swfi.extract_function(a, 'foo_bar')
    assert swfi.extract_function(a, 'foo_bar')([3]) == 7
    assert swfi.extract_function(b, 'foo_bar')([3]) == 10

    # Test caching
    assert a.foo_bar is swfi.extract_function(a, 'foo_bar')

# Generated at 2022-06-24 14:24:45.988135
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import os
    from .tools import load_script
    # Load the module
    path_to_test_dir = os.path.dirname(os.path.abspath(__file__))
    path_to_module_file = os.path.join(
        path_to_test_dir, 'resources', 'helper.swf')
    interpreter = SWFInterpreter()
    with open(path_to_module_file, 'rb') as f:
        swf_data = f.read()
    interpreter.load_module(swf_data)
    # Test the method directly
    avm_class = interpreter.avm_classes[_NAME_OF_TEST_FUN_CLASS]
    func_name = _NAME_OF_TEST_FUN

# Generated at 2022-06-24 14:24:47.185058
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert True

# Generated at 2022-06-24 14:24:48.532364
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert _Undefined() is _Undefined()
    assert not _Undefined()



# Generated at 2022-06-24 14:24:50.921321
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    'Unit test for method __repr__ of class _Undefined'
    obj = _Undefined()
    result = obj.__repr__()
    assert result == 'undefined', 'Expected "undefined", but got %s' % repr(
        result)



# Generated at 2022-06-24 14:24:57.360153
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    '''
    Test for the SWFInterpreter class.
    '''
    interpreter = SWFInterpreter()
    assert interpreter.builtin_classes == {}
    return

if __name__ == '__main__':
    # Unit tests
    test_SWFInterpreter()

# Generated at 2022-06-24 14:25:04.852386
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    dict_ = _ScopeDict(object())
    assert repr(dict_) == 'object__Scope({})'
    dict_.update({b'a': object(), b'b': object()})
    assert repr(dict_) == 'object__Scope({b\'a\': object#%x, b\'b\': object#%x})' % (id(dict_[b'a']), id(dict_[b'b']))



# Generated at 2022-06-24 14:25:15.751578
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    testfile = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'swfs', 'fixtures', 'testcase.swf')
    with open(testfile, 'rb') as fd:
        interp = SWFInterpreter(fd.read())
    assert interp.constant_strings == [
        'onMetaData', 'duration', 'config', 'video', 'width', 'height',
        'framerate', 'filepositions', 'times', 'filepositions',
        'filepositions', 'filepositions', 'filepositions', 'filepositions',
        'filepositions']
    assert interp.constant_numbers == []
    assert interp.constant_floats == [1.28]
    # NOTE: constant_ints are

# Generated at 2022-06-24 14:25:19.729665
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    m = _AVMClass('test', 'test', 'props')
    assert m.method_names == {}
    assert m.method_idxs == {}
    m.register_methods({1: 'a', 2: 'b'})
    assert m.method_names == {1: 'a', 2: 'b'}
    assert m.method_idxs == {1: 'a', 2: 'b'}



# Generated at 2022-06-24 14:25:21.054293
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert _Undefined().__hash__() == 0

# Generated at 2022-06-24 14:25:23.971435
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    avm_class = _AVMClass('Object')
    avm_obj = _AVMClass_Object(avm_class)
    assert repr(avm_obj) == 'Object#%x' % id(avm_obj)



# Generated at 2022-06-24 14:25:26.618274
# Unit test for constructor of class _Undefined
def test__Undefined():
    a = _Undefined()
    b = _Undefined()
    assert a is b


undefined = _Undefined()



# Generated at 2022-06-24 14:25:38.130225
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from _io import BytesIO
    with open('tests/avm.swf', 'rb') as f:
        raw_data = f.read()
    stream = BytesIO(raw_data)
    self = SWFInterpreter(stream)

    # Patch only the method get_video_info (with a trivial
    # implementation)
    def get_video_info_patched(args):
        video_id = args[0]
        webpage_url = args[1]
        webpage_url_basename = webpage_url.rpartition('/')[2]
        return {
            'title': webpage_url_basename
        }

    self.patch_function('YouTubeVideoInfo', 'get_video_info',
                        get_video_info_patched)

    # Test the patched method
    assert self.run

# Generated at 2022-06-24 14:25:40.729903
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert repr(_AVMClass(0, 'Object')) == '_AVMClass(Object)'



# Generated at 2022-06-24 14:25:45.443163
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .swf_disasm_debug import load_swf_third_party_debug
    from .swf_utils import parse_swf_debug
    from .swf_convert_debug import convert_swf_debug
    from .swf_multiname_debug import _Multiname

    swf_in = load_swf_third_party_debug('../../../test_files/as3/youtube_player_api.swf')
    constant_pool = parse_swf_debug(swf_in)

# Generated at 2022-06-24 14:25:52.991180
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter(b'')
    assert swf_interpreter.version == 0
    assert swf_interpreter.file_length == 0
    assert swf_interpreter.frame_size is None
    assert swf_interpreter.frame_rate == 0
    assert swf_interpreter.frame_count == 0
    assert swf_interpreter.tags == []



# Generated at 2022-06-24 14:25:55.492944
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x07)) == '[MULTINAME kind: 0x7]'
test__Multiname()



# Generated at 2022-06-24 14:26:01.421217
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    a = _AVMClass_Object(None)
    assert a.avm_class == None


# Known classes in ActionScript 3.0

# Generated at 2022-06-24 14:26:13.910226
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    # >>> from .compat import unicode_compatible
    # >>> class type_repr:
    # ...     @unicode_compatible
    # ...     class _Multiname(object):
    # ...         def __init__(self, kind):
    # ...             self.kind = kind
    # ...         def __repr__(self):
    # ...             return '[MULTINAME kind: 0x%x]' % self.kind
    # ...     _Multiname.__module__ = '__main__'
    # >>> type_repr._Multiname(42)
    # _Multiname(42)
    x = _Multiname(42)
    assert type(x) is _Multiname
    assert repr(x) == '[MULTINAME kind: 0x2a]'



# Generated at 2022-06-24 14:26:15.642992
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    cls = _AVMClass('', 'TestClass')
    assert cls.make_object()

# Generated at 2022-06-24 14:26:26.975942
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .as3commons import decompile_method
    from .as3commons_asdoc import asdoc_main
    from .compat import BytesIO, compat_urllib_request

    # Download sample SWF file
    r = compat_urllib_request.urlopen(
        'http://samples.mplayerhq.hu/SWF/zelda.swf')
    assert r.getcode() == 200, 'URL opens'
    sample_swf = BytesIO()
    sample_swf.write(r.read())
    sample_swf.seek(0)
    del r

    # Parse file as SWF
    flash = SWF(sample_swf)

    # Select first ActionScript code
    assert len(flash.tags) > 0, 'Flash file has tags'
    found = False

# Generated at 2022-06-24 14:26:32.384573
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    _Multiname(0)
    _Multiname(1)
    _Multiname(2)
    _Multiname(3)
    _Multiname(4)
    _Multiname(7)
    _Multiname(0x0f)
    _Multiname(0x0f | 0x80)
    _Multiname(0x0f | 0xc0)



# Generated at 2022-06-24 14:26:43.978291
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm = _AVMClass('', '')
    assert avm.method_names == {}
    assert avm.method_idxs == {}
    avm.register_methods({'m1': 1, 'm2': 'abc', 'm3': None})
    assert avm.method_names['m1'] == 1
    assert avm.method_names['m2'] == 'abc'
    assert avm.method_names['m3'] is None
    assert avm.method_idxs[1] == 'm1'
    assert avm.method_idxs['abc'] == 'm2'
    assert avm.method_idxs[None] == 'm3'
    # TODO: add a test for ensure_has_method



# Generated at 2022-06-24 14:26:45.266925
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
Undefined = _Undefined()



# Generated at 2022-06-24 14:26:51.834643
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    def test_one(d, expected_r):
        actual_r = d.__repr__()
        assert actual_r == expected_r, '%r == %r' % (actual_r, expected_r)
    test_one(_ScopeDict(None), '__Scope()')
    test_one(_ScopeDict(None, a=1), '__Scope(a=1)')



# Generated at 2022-06-24 14:27:01.570141
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    si = SWFInterpreter(None, None)
    sb = si.build_string_bytes
    si.string_table = [
        sb(u'String'), sb(u'charCodeAt'), sb(u'split'),
        sb(u'join'), sb(u'length'), sb(u'reverse')]
    si.constant_strings = {0: u'', 1: u'', 2: u'', 3: u'', 4: u'', 5: u''}

# Generated at 2022-06-24 14:27:03.261311
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    _ScopeDict(None).__repr__()


# Generated at 2022-06-24 14:27:05.112909
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()

# Generated at 2022-06-24 14:27:10.032966
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    _avm_class = _AVMClass(0, '<class 0>')
    _avm_class.register_methods({'method1': 1, 'method2': 2})
    assert _avm_class.method_names == {
        'method1': 1, 'method2': 2}
    assert _avm_class.method_idxs == {
        1: 'method1', 2: 'method2'}


# Generated at 2022-06-24 14:27:13.735100
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    from .test import (
        _assert_repr_equal,
    )
    _assert_repr_equal(
        _AVMClass_Object(avm_class=object())
    )
test__AVMClass_Object___repr__()



# Generated at 2022-06-24 14:27:21.039564
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-24 14:27:22.147047
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    pass


# Generated at 2022-06-24 14:27:28.771360
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm_interp = SWFInterpreter()
    avm_interp.add_class(AVMClass(None, 'testpublicclass', None))
    avm_interp.add_method(AVMMethod(None, 'testpublicmethod', None, None, None))


# Generated at 2022-06-24 14:27:30.202643
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined) == 0
_Undefined = _Undefined()



# Generated at 2022-06-24 14:27:36.523506
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x1)) == '[MULTINAME kind: 0x1]'
    assert repr(_Multiname(0x0f)) == '[MULTINAME kind: 0xf]'
    assert repr(_Multiname(0xffff)) == '[MULTINAME kind: 0xffff]'



# Generated at 2022-06-24 14:27:38.949708
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    cls = _AVMClass('test', 0)
    assert repr(cls) == '_AVMClass(test)'


# Generated at 2022-06-24 14:27:41.988184
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    """Unit test for method __repr__ of class _Undefined"""
    obj = _Undefined()
    assert str(obj) == 'undefined'

# Generated at 2022-06-24 14:27:45.797189
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class Bla(object):
        name = 'Bla'
    assert repr(dict(a=1)) == '{\'a\': 1}'
    assert repr(_ScopeDict(Bla)) == 'Bla__Scope({})'



# Generated at 2022-06-24 14:27:48.250154
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    _ScopeDict(_AVMClass(b'test_class'))



# Generated at 2022-06-24 14:27:50.955107
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    def _test():
        obj = _Undefined

        assert repr(obj) == 'undefined'
    _test()

# Generated at 2022-06-24 14:27:59.386201
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    import io
    import io
    import io
    from .avm2.avm2_parser import AVM2Parser, AVM2Class
    avm2_parser = AVM2Parser()
    with io.open(u'fixtures/as3/playerProductInstall.swf', 'rb') as f:
        file_contents = f.read()
    avm_class = AVM2Class(avm2_parser, u'.')
    avm_class.static_scope = _ScopeDict(avm_class)
    avm_class.static_scope[u'a'] = 1
    avm_class.static_scope[u'b'] = 2
    scope_dict = _ScopeDict(avm_class)
    scope_dict[u'a'] = 3

# Generated at 2022-06-24 14:28:00.881625
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert ('<AVMClass_Object>#%x' % id(object())) == repr(_AVMClass_Object(None))
    


# Generated at 2022-06-24 14:28:02.157264
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    assert hash(_Undefined()) == 0



# Generated at 2022-06-24 14:28:04.625816
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert _AVMClass(None, None).__repr__() == '_AVMClass(None)'

# Generated at 2022-06-24 14:28:08.959839
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    avm_class = _AVMClass('Foo')
    self = _ScopeDict(avm_class)
    self['foo'] = 'bar'
    assert repr(self) == "Foo__Scope({'foo': 'bar'})"
test__ScopeDict___repr__()



# Generated at 2022-06-24 14:28:12.438711
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _undefined
    assert not bool(_undefined)
    assert not hash(_undefined)
    assert str(_undefined) == 'undefined'
    assert repr(_undefined) == 'undefined'

_undefined = _Undefined()



# Generated at 2022-06-24 14:28:15.509392
# Unit test for method __repr__ of class _AVMClass
def test__AVMClass___repr__():
    assert _AVMClass(17, 'foo').__repr__() == '_AVMClass(foo)'



# Generated at 2022-06-24 14:28:23.136632
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    res = SWFInterpreter.fromstring('')
    assert res.version == 1

    res = SWFInterpreter.fromstring(b'\x00')
    assert res.version == 1

    res = SWFInterpreter.fromstring(b'\x00\x00\x00\x00')
    assert res.version == 1

    res = SWFInterpreter.fromstring(b'\x00\x00\x00\x00\x00')
    assert res.version == 1

    res = SWFInterpreter.fromstring(b'\x00\x00\x00\x00\x00\xff\xff\xff\xff\xff')
    assert res.version == 1


# Generated at 2022-06-24 14:28:32.569540
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    def test_func():
        pass
    avm_class = _AVMClass(
        name_idx=42,
        name='test',
        static_properties={'foo_prop': 42})
    avm_class.register_methods({'test_method': 42})
    avm_class.methods.update({42: test_func})
    avm_class.method_pyfunctions.update({42: test_func})
    avm_class.variables.update({'foo': 42})
    avm_class.constants.update({'foo_const': 42})
    print(avm_class.name)
    print(avm_class.name_idx)
    print(avm_class.method_names)
    print(avm_class.method_idxs)

# Generated at 2022-06-24 14:28:35.260079
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    x = _Undefined()
    if x:
        raise AssertionError('Not false: %r' % x)


_undefined = _Undefined()



# Generated at 2022-06-24 14:28:43.291288
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io
    import sys

    # This reads the file tests/swfbytes/SWF_TESTS.swf,
    # which is a test suite for ActionScript2 decoders
    # by Adobe. We only load it and ignore it as we only
    # want to use it to load the test functions
    fp = io.open('tests/swfbytes/SWF_TESTS.swf', 'rb')
    swf = SWF(fp)

    interpreter = SWFInterpreter(swf.constant_pool)
    for tag in swf.tags:
        if isinstance(tag, DoABC):
            interpreter.handle_tag(tag)

    # This list contains the names of all functions
    # contained in the SWF_TESTS.swf file

# Generated at 2022-06-24 14:28:47.362082
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    # Test for method __repr__ of class _Undefined (generated)
    test = _Undefined()
    test_repr = test.__repr__()
    assert (test_repr == 'undefined')



# Generated at 2022-06-24 14:28:50.318545
# Unit test for constructor of class _Multiname
def test__Multiname():
    mname = _Multiname(kind=0x07)
    assert repr(mname) == '[MULTINAME kind: 0x7]'



# Generated at 2022-06-24 14:28:53.484129
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object(_AVMClass_Object).avm_class) == '_AVMClass_Object#%x' % id(_AVMClass_Object)
test__AVMClass_Object()



# Generated at 2022-06-24 14:28:57.963041
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert _Undefined() is not False
    assert _Undefined() is not None
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'

_undefined = _Undefined()



# Generated at 2022-06-24 14:29:02.022081
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not _Undefined()
    assert not bool(_Undefined())
    assert 1 != hash(_Undefined())
    assert bool(1)
    assert bool('')
    assert bool(b'')
test__Undefined()



# Generated at 2022-06-24 14:29:05.416639
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class AVMClass(object):
        name = 'TestClass'
    s = _ScopeDict(AVMClass)
    assert repr(s) == 'TestClass__Scope({})'



# Generated at 2022-06-24 14:29:09.958596
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass(
        name_idx=0,
        name='mock_class',
        static_properties={},
    )
    assert 'mock_class' == cls.name
    assert {} == cls.method_idxs
    assert {} == cls.methods



# Generated at 2022-06-24 14:29:11.383934
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    assert repr(_Undefined()) == 'undefined'


# Generated at 2022-06-24 14:29:15.440548
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    class A(object):
        pass
    a = _ScopeDict(A)
    assert repr(a) == 'A__Scope({})'
    a['ok'] = True
    assert repr(a) == 'A__Scope({\'ok\': True})'
test__ScopeDict()



# Generated at 2022-06-24 14:29:21.450780
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    Test_AVMClass_Object = type('Test_AVMClass_Object',
                                (_AVMClass_Object, ),
                                {})
    test_object = Test_AVMClass_Object._AVMClass_Object(None)
    assert repr(test_object) == 'None#%x' % (id(test_object))



# Generated at 2022-06-24 14:29:28.057998
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swfdecompiler import SWFInterpreter
    interp = SWFInterpreter(None, None)

    c1 = interp.extract_class(
        {'name': 'Class1', 'script_id': 1, 'instance_info': None,
         'class_info': None, 'traits': [], 'static_properties': {}})

# Generated at 2022-06-24 14:29:30.398750
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert '(AVMClass#1)' == repr(_AVMClass_Object(_AVMClass(name='AVMClass')))



# Generated at 2022-06-24 14:29:31.523265
# Unit test for method __bool__ of class _Undefined
def test__Undefined___bool__():
    assert not _Undefined()
    assert len({_Undefined()} & {_Undefined()}) == 0
Undefined = _Undefined()



# Generated at 2022-06-24 14:29:43.394397
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .test_common import get_test_data_folder

    # Test __init__
    swf_interpreter = SWFInterpreter(
        os.path.join(get_test_data_folder(), 'test.swf'))

    # Test patch_function
    def func_toplevel(a):
        for i in range(4):
            a = a + 1
        return a
    def func_level1_1(a):
        for i in range(2):
            a = a + 1
        return a
    def func_level1_2(a):
        return 2 * a
    def func_level2_1(a):
        return 3 * a
    def func_level2_2(a):
        return 4 * a
    def func_level3_1(a):
        return 5

# Generated at 2022-06-24 14:29:47.729511
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    avm_class = _AVMClass('Object')
    obj = _AVMClass_Object(avm_class)
    assert repr(obj) == 'Object#%x' % id(obj), repr(obj)
test__AVMClass_Object()



# Generated at 2022-06-24 14:29:50.844733
# Unit test for constructor of class _ScopeDict
def test__ScopeDict():
    sd = _ScopeDict(None)
    assert repr(sd) == 'None__Scope([])'
    sd['x'] = 1
    assert repr(sd) == 'None__Scope(x:1)'



# Generated at 2022-06-24 14:29:54.263178
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter(io.BytesIO(b'\x00'))
    @swf.patch_function
    def add(a, b):
        return a + b
    assert add(1, 2) == 3

# Generated at 2022-06-24 14:29:58.611450
# Unit test for method __hash__ of class _Undefined
def test__Undefined___hash__():
    # Test that it works as a dictionary key
    assert len({_Undefined(): 1, _Undefined(): 1}) == 1


# Generated at 2022-06-24 14:29:59.365893
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    pass

# Generated at 2022-06-24 14:30:04.306177
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert not bool(_Undefined())
    assert hash(_Undefined()) == 0
    assert str(_Undefined()) == 'undefined'
    assert repr(_Undefined()) == 'undefined'
test__Undefined()



# Generated at 2022-06-24 14:30:12.639516
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    # Setup
    class_1 = _AVMClass(
        'class 1',
        0,
        )
    methods = {
        'method 1': 1,
        'method 2': 2,
        }

    # Exercise
    class_1.register_methods(
        methods)

    # Verify
    assert class_1.method_names == methods
    assert class_1.method_idxs == dict(
        (v, k)
        for k, v in methods.items())
# Exercise class _AVMClass with a _ScopeDict
# Verify that _ScopeDict.__repr__ is called

# Generated at 2022-06-24 14:30:16.243821
# Unit test for method make_object of class _AVMClass
def test__AVMClass_make_object():
    retval = _AVMClass(0, '').make_object()
    assert isinstance(retval, _AVMClass_Object)
    assert retval.avm_class is not None


# Generated at 2022-06-24 14:30:28.381841
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Testing against swf 'dynamictext_py.swf'
    f = open('dynamictext_py.swf','rb')
    swf_data = f.read()
    f.close()
    interpreter = SWFInterpreter(swf_data)

    assert isinstance(interpreter, SWFInterpreter)
    assert isinstance(interpreter.constant_strings, list)
    assert isinstance(interpreter.constant_namespaces, dict)
    assert isinstance(interpreter.constant_namespace_sets, dict)
    assert isinstance(interpreter.constant_multinames, dict)
    assert isinstance(interpreter.scripts, dict)
    assert isinstance(interpreter.classes, dict)
    assert isinstance(interpreter.methods, dict)


# Generated at 2022-06-24 14:30:31.647706
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    assert repr(_AVMClass_Object('Foo')) == 'Foo#%x' % id(
        _AVMClass_Object('Foo'))
test__AVMClass_Object()



# Generated at 2022-06-24 14:30:32.761244
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    _AVMClass_Object(None)



# Generated at 2022-06-24 14:30:34.497209
# Unit test for constructor of class _Multiname
def test__Multiname():
    assert repr(_Multiname(0x0c)) == '[MULTINAME kind: 0xc]'



# Generated at 2022-06-24 14:30:35.851503
# Unit test for constructor of class _AVMClass_Object
def test__AVMClass_Object():
    _AVMClass_Object(None)


# Generated at 2022-06-24 14:30:39.741404
# Unit test for method __repr__ of class _AVMClass_Object
def test__AVMClass_Object___repr__():
    assert _AVMClass_Object(_AVMClass('test')).__repr__() == 'test#7fad0'


# Generated at 2022-06-24 14:30:49.710250
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(path_or_fd)

# Generated at 2022-06-24 14:30:51.684743
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    class_ = _AVMClass('test')
    assert repr(class_) == "_AVMClass('test')"



# Generated at 2022-06-24 14:31:01.052766
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    cls = _AVMClass('MyClass', [], {})
    obj = cls.make_object()
    assert isinstance(obj, _AVMClass_Object)
    assert obj.avm_class == cls

    # Test _ScopeDict
    cls.variables['test'] = 'test1'
    assert cls.variables['test'] == 'test1', cls.variables['test']
    assert repr(cls.variables) == 'MyClass__Scope({\'test\': \'test1\'})'

test__AVMClass()



# Generated at 2022-06-24 14:31:02.985516
# Unit test for constructor of class _AVMClass
def test__AVMClass():
    # pylint: disable=W0612
    _AVMClass(1, 'foo')



# Generated at 2022-06-24 14:31:05.693723
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(
        # file_obj=open('youtube.swf', 'rb')
        file_obj=open('test.swf', 'rb')
    )

    for func in swf.extract_function, swf.extract_function_from_name:
        cb = func(swf.avm_class_loader, 'load')
        assert cb(['https://www.youtube.com/player_api']) == ''

# Generated at 2022-06-24 14:31:07.405002
# Unit test for constructor of class _Undefined
def test__Undefined():
    assert (_Undefined() == 0) is False

undefined = _Undefined()



# Generated at 2022-06-24 14:31:10.363063
# Unit test for method __repr__ of class _Undefined
def test__Undefined___repr__():
    x = _Undefined()
    # test__Undefined___repr__.py:19:
    assert repr(x) == 'undefined'
test__Undefined___repr__()

Undefined = _Undefined()
Null = None



# Generated at 2022-06-24 14:31:13.047738
# Unit test for method __repr__ of class _Multiname
def test__Multiname___repr__():
    assert repr(_Multiname(kind=0)) == '[MULTINAME kind: 0x0]'



# Generated at 2022-06-24 14:31:16.945822
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    a = SWFInterpreter('1', b'\x46\x57\x53\x01\x00\x00\x00\x00')
    assert len(a.constant_strings) == 0


# Generated at 2022-06-24 14:31:25.772255
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import sys
    import io
    import unittest

    # Do not load the actual Version 0 ActionScripts, as they are not
    # available
    class MockVersion0(object):
        def __init__(self, versions):
            self.versions = versions
            self.instance = self

        def put_version_0(self, stream, tag_type, data):
            if self.versions[tag_type]:
                self._put_version_0(stream, tag_type, data)

        def _put_version_0(self, stream, tag_type, data):
            pass
