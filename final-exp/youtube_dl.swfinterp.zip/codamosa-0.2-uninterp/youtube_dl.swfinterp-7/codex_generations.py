

# Generated at 2022-06-18 16:02:53.015636
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerNotImplementedError
    from .swfdecompiler import SWFDecompilerNotSupportedError
    from .swfdecompiler import SWFDecompilerUnsupportedError
    from .swfdecompiler import SWFDecompilerUnsupportedTagError
    from .swfdecompiler import SWFDecompilerUnsupportedVersionError

    # Test SWFDecompiler
    swfdecompiler = SWFDecompiler()
    swfdecompiler.decompile(
        'test/swf/test_swfdecompiler.swf',
        'test/swf/test_swfdecompiler.xml')

    #

# Generated at 2022-06-18 16:03:03.370137
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import io
    import os
    import sys
    import unittest


# Generated at 2022-06-18 16:03:12.247842
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameLT
    from .abc import ABCMultinameN
    from .abc import ABCMultinameNT
    from .abc import ABCMultinameT
    from .abc import ABCMultinameTA
    from .abc import ABCMultinameType
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCString
    from .abc import ABCInt
    from .abc import ABCUInt
    from .abc import ABCDouble

# Generated at 2022-06-18 16:03:22.901742
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter()

# Generated at 2022-06-18 16:03:25.266283
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_function(swf.avm_class, 'test')



# Generated at 2022-06-18 16:03:35.801753
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABC


# Generated at 2022-06-18 16:03:40.387360
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_tags import TagDefineBinaryData
    from .swf_tags import TagDoABC

    # Test with a SWF file that contains a single class

# Generated at 2022-06-18 16:03:48.512263
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('TestClass')
    assert swf.classes['TestClass'].static_properties['test'] == 'test'
    assert swf.classes['TestClass'].static_properties['test2'] == 'test2'
    assert swf.classes['TestClass'].static_properties['test3'] == 'test3'
    assert swf.classes['TestClass'].static_properties['test4'] == 'test4'
    assert swf.classes['TestClass'].static_properties['test5'] == 'test5'
    assert swf.classes['TestClass'].static_properties['test6'] == 'test6'

# Generated at 2022-06-18 16:03:59.141025
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter()
    swf.constant_strings = ['String', 'length']
    swf.constant_namespaces = [
        _Namespace(0, 'public'),
        _Namespace(0, 'public'),
    ]
    swf.constant_namespace_sets = [
        [0, 1],
    ]
    swf.multinames = [
        _Multiname(1, 0, 0),
        _Multiname(1, 0, 1),
    ]

# Generated at 2022-06-18 16:04:06.544645
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:05:20.559825
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.version == 9
    assert swf.file_length == 524
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 12.0
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:05:29.635466
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfinterpreter import SWFInterpreter
    from .swfobject import SWFObject

    swf = SWFObject()
    swf.version = 18
    swf.file_size = 0
    swf.frame_size = (0, 0, 0, 0)
    swf.frame_rate = 0
    swf.frame_count = 0
    swf.tags = []

    swfdata = SWFData(BytesIO(b''))
    swfdata.swf = swf
    swfdata.version = 18
    swfdata.file_size = 0
    swfdata.frame_size = (0, 0, 0, 0)


# Generated at 2022-06-18 16:05:36.368641
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_tags import read_swf_tag
    from .swf_tags import TAG_DO_ABC
    from .swf_tags import TAG_SYMBOL_CLASS
    from .swf_tags import TAG_END
    from .swf_tags import TAG_FILE_ATTRIBUTES
    from .swf_tags import TAG_SET_BACKGROUND_COLOR
    from .swf_tags import TAG_DO_ACTION
    from .swf_tags import TAG_DO_INIT_ACTION
    from .swf_tags import TAG_DEFINE_SPRITE
    from .swf_tags import TAG_DEFINE_SHAPE
    from .swf_tags import TAG_DEFINE_SHAPE2

# Generated at 2022-06-18 16:05:46.015683
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    avm_class = swf.extract_class('Test')
    assert avm_class.name == 'Test'
    assert avm_class.super_name == 'Object'
    assert avm_class.static_properties['test'] == 'test'
    assert avm_class.static_properties['test2'] == 'test2'
    assert avm_class.static_properties['test3'] == 'test3'
    assert avm_class.static_properties['test4'] == 'test4'
    assert avm_class.static_properties['test5'] == 'test5'
    assert avm_class.static_properties['test6']

# Generated at 2022-06-18 16:05:53.093489
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter()
    assert swf_interpreter.constant_strings == []
    assert swf_interpreter.constant_namespaces == []
    assert swf_interpreter.constant_namespace_sets == []
    assert swf_interpreter.constant_multinames == []
    assert swf_interpreter.methods == []
    assert swf_interpreter.metadata == []
    assert swf_interpreter.classes == []
    assert swf_interpreter.scripts == []
    assert swf_interpreter.method_bodies == []


# Generated at 2022-06-18 16:05:59.409696
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:06:05.225445
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import io
    from .swf_utils import read_swf_tag_data


# Generated at 2022-06-18 16:06:10.911470
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Test for constructor of class SWFInterpreter
    with open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb') as f:
        swf = f.read()
    swf_interpreter = SWFInterpreter(swf)
    assert swf_interpreter.version == 9
    assert swf_interpreter.file_length == len(swf)
    assert swf_interpreter.frame_size == (0, 0, 640, 480)
    assert swf_interpreter.frame_rate == 30
    assert swf_interpreter.frame_count == 1
    assert swf_interpreter.tag_count == 2
    assert swf_interpreter.tags[0].tag_type == 69
    assert swf_inter

# Generated at 2022-06-18 16:06:15.226833
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCMultiname
    from .abc import ABCConstantPool
    from .abc import ABCConstantPool_String
    from .abc import ABCConstantPool_Namespace
    from .abc import ABCConstantPool_NamespaceSet
    from .abc import ABCConstantPool_Multiname
    from .abc import ABCConstantPool_Multiname_QName
    from .abc import ABCConstantPool_Multiname_Multiname
    from .abc import ABCConstantPool_Multiname_Multiname_QName
    from .abc import ABCConstantPool_Multiname_Multiname_Multiname

# Generated at 2022-06-18 16:06:17.307525
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.extract_class('Main') is not None

# Generated at 2022-06-18 16:08:31.723204
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter()
    swf.constant_strings = ['foo', 'bar', 'baz']
    swf.multinames = [
        _Multiname(0, 0, 0, 'foo'),
        _Multiname(0, 0, 0, 'bar'),
        _Multiname(0, 0, 0, 'baz'),
    ]
    swf.method_bodies = [
        _MethodBody(
            0, 0, 0, 0, 0,
            [
                0x01,  # getlocal_0
                0x02,  # getlocal_1
                0x0a,  # add
                0x47,  # returnvalue
            ],
            [],
            [],
            [],
        ),
    ]
    func = swf.extract_

# Generated at 2022-06-18 16:08:40.654758
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))

# Generated at 2022-06-18 16:08:49.773348
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:08:51.465730
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter()
    swf.patch_function('trace', lambda x: x)
    assert swf.trace('foo') == 'foo'


# Generated at 2022-06-18 16:09:00.618677
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:09:09.894766
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:09:16.201936
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import io
    from .swf import SWF
    from .tags import DoABCTag
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCScript
    from .abc import ABCMethodBody
    from .abc import ABCMethodParam

# Generated at 2022-06-18 16:09:23.490216
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_parse import SWF


# Generated at 2022-06-18 16:09:31.884811
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodInfo
    from .abc import ABCMethodBodyInfo
    from .abc import ABCExceptionInfo
    from .abc import ABCException
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameRTQName
    from .abc import ABCMultinameRTQNameA
    from .abc import ABCMultinameRTQNameL
    from .abc import ABCMultinameRTQNameLA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
   

# Generated at 2022-06-18 16:09:40.613114
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_extract import SWF
    from .swf_extract import SWFInterpreter
    from .swf_extract import SWFClass
    from .swf_extract import SWFMethod
    from .swf_extract import SWFMethodBody
    from .swf_extract import SWFMultiname
    from .swf_extract import SWFMultinameL
    from .swf_extract import SWFMultinameLA
    from .swf_extract import SWFMultinameQName
    from .swf_extract import SWFMultinameQNameA
    from .swf_extract import SWFMultinameRTQName
    from .swf_extract import SWFMultinameRTQNameA
    from .swf_extract import SWFMultin