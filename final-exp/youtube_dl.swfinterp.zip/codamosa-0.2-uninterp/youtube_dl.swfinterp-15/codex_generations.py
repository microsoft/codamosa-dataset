

# Generated at 2022-06-18 16:02:30.687702
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:02:39.748701
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.version == 9
    assert swf.file_length == 638
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 12
    assert swf.frame_count == 1
    assert len(swf.tags) == 4
    assert swf.tags[0].tag_type == 69
    assert swf.tags[0].tag_length == 5
    assert swf.tags[0].tag_data == b'\x00\x00\x00\x00\x00'
    assert swf.tags[1].tag_type == 9
    assert swf.tags[1].tag_length == 583
    assert swf.tags[1].tag

# Generated at 2022-06-18 16:02:49.718167
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import os
    import sys
    import tempfile
    import unittest

    from .swfdecompiler import SWFInterpreter

    class SWFInterpreterTest(unittest.TestCase):
        def setUp(self):
            self.interpreter = SWFInterpreter()

        def test_patch_function(self):
            def func(args):
                return args[0] + args[1]

            self.interpreter.patch_function(
                'test', func, ['a', 'b'], 'c')

            self.assertEqual(self.interpreter.extract_function('test', 'c'), func)

        def test_patch_function_with_default_args(self):
            def func(args):
                return args[0] + args[1]

            self.interpre

# Generated at 2022-06-18 16:03:01.160690
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf import SWF
    from .swf_data import SWFData
    from .swf_tag import TagDefineBinaryData
    from .swf_tag import TagDoABC
    from .swf_tag import TagDoABCDefine
    from .swf_tag import TagEnd
    from .swf_tag import TagFileAttributes
    from .swf_tag import TagMetadata
    from .swf_tag import TagSetBackgroundColor
    from .swf_tag import TagShowFrame
    from .swf_tag import TagSymbolClass
    from .swf_tag import TagUnknown
    from .swf_tag import TagDefineBitsLossless
    from .swf_tag import TagDefineBitsLossless2
    from .swf_tag import TagDefineBitsJPEG2
   

# Generated at 2022-06-18 16:03:10.235395
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_tags import TagDefineFunction
    from .swf_tags import TagDoAction
    from .swf_tags import TagDoInitAction
    from .swf_tags import TagSymbolClass
    from .swf_tags import TagFileAttributes
    from .swf_tags import TagSetBackgroundColor
    from .swf_tags import TagShowFrame
    from .swf_tags import TagEnd
    from .swf_tags import TagDefineBinaryData
    from .swf_tags import TagDefineScalingGrid
    from .swf_tags import TagDefineShape
    from .swf_tags import TagDefineShape2
    from .swf_tags import TagDefineShape3

# Generated at 2022-06-18 16:03:12.827571
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('TestClass')

# Generated at 2022-06-18 16:03:22.962453
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('com.adobe.serialization.json.JSON')
    swf.extract_class('com.adobe.serialization.json.JSONToken')
    swf.extract_class('com.adobe.serialization.json.JSONTokenizer')
    swf.extract_class('com.adobe.serialization.json.JSONDecoder')
    swf.extract_class('com.adobe.serialization.json.JSONEncoder')
    swf.extract_class('com.adobe.serialization.json.JSONSubstitutionRegistry')

# Generated at 2022-06-18 16:03:27.523723
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod


# Generated at 2022-06-18 16:03:37.426630
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInter

# Generated at 2022-06-18 16:03:46.570038
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:04:43.647036
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_utils import read_swf_tags
    from .swf_utils import read_swf_tag_header
    from .swf_utils import read_swf_tag_doabc
    from .swf_utils import read_swf_tag_doaction
    from .swf_utils import read_swf_tag_doinitaction
    from .swf_utils import read_swf_tag_symbols
    from .swf_utils import read_swf_tag_end
    from .swf_utils import read_swf_tag_definebits
    from .swf_utils import read_swf_tag_definebitsjpeg2
    from .swf_utils import read_swf_tag

# Generated at 2022-06-18 16:04:55.319701
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCException
    from .abc import ABCMultiname
    from .abc import ABCConstantPool
    from .abc import ABCMethodBody
    from .abc import ABCOpcode
    from .abc import ABCExceptionHandler
    from .abc import ABCExceptionHandlerType
    from .abc import ABCExceptionHandlerTarget
    from .abc import ABCExceptionHandlerTargetType
    from .abc import ABCExceptionHandlerTargetWithType
    from .abc import ABCExceptionHandlerTargetWithTypeAndName
    from .abc import ABCExceptionHandlerTargetWithTypeAndNameAndTraits
    from .abc import ABCExceptionHandlerTargetWithTypeAndTraits
    from .abc import ABC

# Generated at 2022-06-18 16:05:05.983818
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import Multiname
    from .abc import MultinameL


# Generated at 2022-06-18 16:05:16.554431
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:05:19.873252
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'



# Generated at 2022-06-18 16:05:29.035285
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    from .swf import SWF
    from .tags import TagDefineBinaryData
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCOpcode
    from .abc import ABCOpcode_Push
    from .abc import ABCOpcode_Push_String
    from .abc import ABCOpcode_Push_Double
    from .abc import ABCOpcode_Push_Int
    from .abc import ABCOpcode_Push_UInt
    from .abc import ABCOpcode_Push_True
    from .abc import ABCOpcode_Push_False
    from .abc import ABCOpcode_Push_Null
    from .abc import ABCOpcode_Push_Undefined

# Generated at 2022-06-18 16:05:35.905856
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABCTag
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCOpcode
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameRTQName
    from .abc import ABCMultinameRTQNameA
    from .abc import ABCMultinameRTQNameL
    from .abc import ABCMultinameRTQName

# Generated at 2022-06-18 16:05:37.685137
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert repr(_ScopeDict(None)) == 'None__Scope({})'
    assert repr(_ScopeDict(None, a=1)) == 'None__Scope({\'a\': 1})'



# Generated at 2022-06-18 16:05:42.521626
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('TestClass')

# Generated at 2022-06-18 16:05:51.598587
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'

# Generated at 2022-06-18 16:07:39.373393
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('com.example.Test')

# Generated at 2022-06-18 16:07:50.637945
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError

    # Test for SWFDecompilerError
    with pytest.raises(SWFDecompilerError):
        SWFDecompiler(None)

    # Test for SWFDecompilerError
    with pytest.raises(SWFDecompilerError):
        SWFDecompiler('')

    # Test for SWFDecompilerError
    with pytest.raises(SWFDecompilerError):
        SWFDecompiler('test/swfs/invalid.swf')

    # Test for SWFDecompilerError
    with pytest.raises(SWFDecompilerError):
        SWFDecompiler('test/swfs/invalid_version.swf')



# Generated at 2022-06-18 16:07:57.124472
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWF
    from .swfdecompiler import SWFError
    from .swfdecompiler import SWFInfo
    from .swfdecompiler import SWFInfoError
    from .swfdecompiler import SWFInfoError
    from .swfdecompiler import SWFInfoError
    from .swfdecompiler import SWFInfoError
    from .swfdecompiler import SWFInfoError
    from .swfdecompiler import SWFInfoError
    from .swfdecompiler import SWFInfoError
    from .swfdecompiler import SWFInfoError
    from .swfdecompiler import SWFInfoError
    from .swfdecompiler import SWFInfoError

# Generated at 2022-06-18 16:08:00.331581
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter()
    swf.patch_function('trace', lambda x: print(x))
    assert swf.trace('foo') == 'foo'


# Generated at 2022-06-18 16:08:10.123278
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABC
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody


# Generated at 2022-06-18 16:08:17.807900
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb').read()
    swf = SWF(swf)
    swf.parse()
    swf.extract_all_scripts()
    interpreter = SWFInterpreter(swf)
    interpreter.extract_class('_level0.Main')
    assert interpreter.classes['_level0.Main'].variables['_x'] == 0
    assert interpreter.classes['_level0.Main'].variables['_y'] == 0
    assert interpreter.classes['_level0.Main'].variables['_width'] == 0
    assert interpreter.classes['_level0.Main'].variables['_height'] == 0

# Generated at 2022-06-18 16:08:26.851571
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter()
    assert swf_interpreter.constant_strings == []
    assert swf_interpreter.constant_namespaces == []
    assert swf_interpreter.constant_namespace_sets == []
    assert swf_interpreter.multinames == []
    assert swf_interpreter.methods == []
    assert swf_interpreter.metadata == []
    assert swf_interpreter.classes == []
    assert swf_interpreter.scripts == []
    assert swf_interpreter.method_bodies == []
    assert swf_interpreter.method_pyfunctions == {}


# Generated at 2022-06-18 16:08:33.167160
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMultiname
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCString
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCTrait
    from .abc import ABCTraitSlot
    from .abc import ABCTraitMethod
    from .abc import ABCTraitClass
    from .abc import ABCTraitFunction
    from .abc import ABCTraitConst
    from .abc import ABCTraitGetter
    from .abc import ABCTraitSetter
    from .abc import ABCTraitFunction

    swf = SW

# Generated at 2022-06-18 16:08:42.125041
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfobject import SWFObject
    from .swfdecompiler import SWFDecompiler
    from .swfobject import SWFObject

    swf_data = SWFData(open('tests/swf/test_swf_interpreter.swf', 'rb').read())
    swf_obj = SWFObject(swf_data)
    swf_decompiler = SWFDecompiler(swf_obj)
    swf_decompiler.decompile()

    swf_interpreter = SWFInterpreter(swf_decompiler)
    swf_interpreter.interpret()

if __name__ == '__main__':
    test_SWFInterpre

# Generated at 2022-06-18 16:08:50.697875
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
