

# Generated at 2022-06-18 16:02:29.878156
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:02:38.895853
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.version == 9
    assert swf.file_length == 658
    assert swf.frame_size == (550, 400)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1
    assert swf.file_attributes == {'UseNetwork': False}

# Generated at 2022-06-18 16:02:48.975598
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_tags import TAG_DO_ABC
    from .swf_abc import ABCFile
    from .swf_abc_utils import ABCFileReader
    from .swf_abc_opcodes import ABC_OPCODES


# Generated at 2022-06-18 16:02:55.852293
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:03:00.147936
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:03:09.376402
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb').read()
    swf = SWFInterpreter(swf)

# Generated at 2022-06-18 16:03:16.485880
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io
    from .swf_utils import read_swf_header
    from .swf_tags import read_swf_tag
    from .swf_tags import TAG_DO_ABC
    from .swf_tags import TAG_SYMBOL_CLASS
    from .swf_tags import TAG_END
    from .swf_tags import TAG_FILE_ATTRIBUTES
    from .swf_tags import TAG_SET_BACKGROUND_COLOR
    from .swf_tags import TAG_DO_ACTION
    from .swf_tags import TAG_DO_INIT_ACTION
    from .swf_tags import TAG_DEFINE_SPRITE
    from .swf_tags import TAG_DEFINE_SCENE_AND_FRAME_LABEL_DATA
    from .swf_tags import TAG_DEFINE_B

# Generated at 2022-06-18 16:03:23.820700
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('com.example.Test')
    assert swf.classes['com.example.Test'].static_properties['test'] == 'test'
    assert swf.classes['com.example.Test'].static_properties['test2'] == 'test2'
    assert swf.classes['com.example.Test'].static_properties['test3'] == 'test3'
    assert swf.classes['com.example.Test'].static_properties['test4'] == 'test4'
    assert swf.classes['com.example.Test'].static_properties['test5'] == 'test5'

# Generated at 2022-06-18 16:03:28.340555
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import SWF
    swf = SWF(open('test/swfs/test_swfdecompiler.swf', 'rb'))
    interpreter = SWFInterpreter(swf)

# Generated at 2022-06-18 16:03:38.159262
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = _SWFInterpreter()
    swf.constant_strings = ['Object', 'String', 'Array', 'Number', 'Boolean']
    swf.constant_namespaces = [
        _Namespace('public', 0),
        _Namespace('public', 1),
        _Namespace('public', 2),
        _Namespace('public', 3),
        _Namespace('public', 4),
    ]
    swf.multinames = [
        _Multiname('Object', 0),
        _Multiname('String', 1),
        _Multiname('Array', 2),
        _Multiname('Number', 3),
        _Multiname('Boolean', 4),
    ]

# Generated at 2022-06-18 16:04:50.533267
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter()
    assert swf_interpreter.constant_strings == []
    assert swf_interpreter.constant_namespaces == []
    assert swf_interpreter.constant_namespace_sets == []
    assert swf_interpreter.constant_multinames == []
    assert swf_interpreter.methods == []
    assert swf_interpreter.classes == []
    assert swf_interpreter.scripts == []
    assert swf_interpreter.method_bodies == []


# Generated at 2022-06-18 16:04:54.853350
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Main')


# Generated at 2022-06-18 16:04:59.576297
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Main')


# Generated at 2022-06-18 16:05:07.901263
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:05:18.632565
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class TestAVMClass(object):
        def __init__(self):
            self.method_names = set()
            self.method_pyfunctions = {}
            self.static_properties = {}
            self.variables = {}

        def make_object(self):
            return _ScopeDict(self)

    class TestAVMClass_Object(object):
        def __init__(self, avm_class):
            self.avm_class = avm_class
            self.variables = {}

    class TestSWFInterpreter(SWFInterpreter):
        def __init__(self):
            self.constant_strings = []
            self.multinames = []
            self.classes = {}


# Generated at 2022-06-18 16:05:27.878774
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf_interpreter import SWFInterpreter
    from .swf_parser import SWFParser
    from .swf_tags import DoABCTag


# Generated at 2022-06-18 16:05:35.141484
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_utils import read_swf_file
    from .swf_tags import DoABCTag
    from .swf_tags import FileAttributesTag
    from .swf_tags import MetadataTag
    from .swf_tags import SetBackgroundColorTag
    from .swf_tags import ShowFrameTag
    from .swf_tags import SymbolClassTag
    from .swf_tags import SWFTag
    from .swf_tags import SWFTagType
    from .swf_tags import SWFTags
    from .swf_tags import TagDoABC
    from .swf_tags import TagFileAttributes
    from .swf_tags import TagMetadata
    from .swf_tags import TagSetBackgroundColor
    from .swf_tags import TagShowFrame
    from .swf_tags import TagSymbolClass


# Generated at 2022-06-18 16:05:44.427550
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodBody
    from .abc import ABCMethodInfo
    from .abc import ABCMethodKind
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCNamespace
    from .abc import ABCNamespaceKind
    from .abc import ABCQName
    from .abc import ABCTrait
    from .abc import ABCTraitKind
    from .abc import ABCValueKind
    from .abc import ABCFileInfo
    from .abc import ABCInstanceInfo
    from .abc import ABCClassInfo
    from .abc import ABCMetaData
    from .abc import ABCException
    from .abc import ABCExceptionKind
    from .abc import ABCExceptionHandler
    from .abc import ABCOpcode

# Generated at 2022-06-18 16:05:53.065998
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('test')
    assert swf.classes['test'].static_properties['test'] == 'test'
    assert swf.classes['test'].static_properties['test2'] == 'test2'
    assert swf.classes['test'].static_properties['test3'] == 'test3'
    assert swf.classes['test'].static_properties['test4'] == 'test4'
    assert swf.classes['test'].static_properties['test5'] == 'test5'
    assert swf.classes['test'].static_properties['test6'] == 'test6'

# Generated at 2022-06-18 16:05:59.356930
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:07:51.483302
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:07:57.660834
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData

# Generated at 2022-06-18 16:08:02.130511
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb').read())
    swf.extract_class('_level0.test')


# Generated at 2022-06-18 16:08:11.167188
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:08:18.315670
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFMethod
    from .swfdecompiler import SWFClass
    from .swfdecompiler import SWFConstantPool
    from .swfdecompiler import SWFMultiname
    from .swfdecompiler import SWFMultiname_TypeName
    from .swfdecompiler import SWFMultiname_QName
    from .swfdecompiler import SWFMultiname_RTQName
    from .swfdecompiler import SWFMultiname_RTQNameL
    from .swfdecompiler import SWFMultiname_Multiname
    from .swfdecompiler import SWFMultiname_MultinameL

# Generated at 2022-06-18 16:08:28.076746
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:08:30.326071
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')

# Generated at 2022-06-18 16:08:39.716658
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import SWFInterpreter
    from . import SWF
    from . import SWFError
    from . import SWFObject
    from . import SWFDataError
    from . import SWFValueError
    from . import SWFTypeError
    from . import SWFIOError
    from . import SWFNotImplementedError
    from . import SWFEOFError
    from . import SWFUnsupportedError
    from . import SWFInvalidTagError
    from . import SWFInvalidTagTypeError
    from . import SWFInvalidTagLengthError
    from . import SWFInvalidTagDataError
    from . import SWFInvalidTagCodeError
    from . import SWFInvalidTagNameError
    from . import SWFInvalidTagObjectError
    from . import SWFInvalidTagObjectTypeError
    from . import SWFInvalidTagObjectLength

# Generated at 2022-06-18 16:08:49.312581
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('test')
    assert swf.classes['test'].variables['a'] == 1
    assert swf.classes['test'].variables['b'] == 2
    assert swf.classes['test'].variables['c'] == 3
    assert swf.classes['test'].variables['d'] == 4
    assert swf.classes['test'].variables['e'] == 5
    assert swf.classes['test'].variables['f'] == 6
    assert swf.classes['test'].variables['g'] == 7
    assert swf.classes['test'].variables['h'] == 8
   

# Generated at 2022-06-18 16:08:59.291311
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFMethod
    from .swfdecompiler import SWFClass
    from .swfdecompiler import SWFConstantPool
    from .swfdecompiler import SWFMultiname
    from .swfdecompiler import SWFMultiname_QName
    from .swfdecompiler import SWFMultiname_Multiname
    from .swfdecompiler import SWFMultiname_MultinameL
    from .swfdecompiler import SWFMultiname_RTQName
    from .swfdecompiler import SWFMultiname_RTQNameL
    from .swfdecompiler import SWFMultiname_RTQNameLA