

# Generated at 2022-06-18 16:01:46.581808
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF


# Generated at 2022-06-18 16:01:54.302977
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCConstantPool
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCOpcode
    from .abc import ABCOpcode_0
    from .abc import ABCOpcode_1
    from .abc import ABCOpcode_2
    from .abc import ABCOpcode_3
    from .abc import ABCOpcode_4
    from .abc import ABCOpcode

# Generated at 2022-06-18 16:02:01.159126
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:02:09.038569
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompiler_TagHandler

    class TestSWFDecompiler_TagHandler(SWFDecompiler_TagHandler):
        def __init__(self, decompiler):
            super(TestSWFDecompiler_TagHandler, self).__init__(decompiler)
            self.tags = []

        def handle_tag(self, tag):
            self.tags.append(tag)

    class TestSWFDecompiler(SWFDecompiler):
        def __init__(self, fileobj):
            super(TestSWFDecompiler, self).__init__(fileobj)
            self.tag_handler = Test

# Generated at 2022-06-18 16:02:16.820176
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCConstantPool
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCMultinameKind
    from .abc import ABCMultinameKindTypeName
    from .abc import ABCMultinameKindTypeNameA
    from .abc import ABCMultinameKind

# Generated at 2022-06-18 16:02:27.262219
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swf_parse import SWF
    from .swf_parse import SWF_HEADER
    from .swf_parse import SWF_TAG_TYPE_DO_ABC
    from .swf_parse import SWF_TAG_TYPE_SYMBOL_CLASS
    from .swf_parse import SWF_TAG_TYPE_END
    from .swf_parse import SWF_TAG_TYPE_FILE_ATTRIBUTES
    from .swf_parse import SWF_TAG_TYPE_SET_BACKGROUND_COLOR
    from .swf_parse import SWF_TAG_TYPE_DO_ACTION
    from .swf_parse import SWF_TAG_TYPE_DO_INIT_ACTION
    from .swf_parse import SWF_TAG_TYPE_SCRIPT_LIMITS
    from .swf_parse import SW

# Generated at 2022-06-18 16:02:37.394566
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:02:40.297072
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(test_dir, 'test.swf'), 'rb'))
    swf.extract_class('test')

# Generated at 2022-06-18 16:02:45.659217
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(0, 'Test')
    avm_class.register_methods({'foo': 1, 'bar': 2})
    assert avm_class.method_names == {'foo': 1, 'bar': 2}
    assert avm_class.method_idxs == {1: 'foo', 2: 'bar'}



# Generated at 2022-06-18 16:02:53.652775
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .tags import DoABCTag
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCMethodBody
    from .abc import ABCMethodParam

# Generated at 2022-06-18 16:03:48.151546
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceType
    from .abc import ABCNamespaceTypeName

# Generated at 2022-06-18 16:03:58.421046
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:03:59.761912
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Test for method patch_function( ... )
    pass


# Generated at 2022-06-18 16:04:05.710283
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('com.adobe.serialization.json.JSON')
    assert swf.classes['com.adobe.serialization.json.JSON'].static_properties['stringify']([1, 2, 3]) == '[1,2,3]'
    assert swf.classes['com.adobe.serialization.json.JSON'].static_properties['parse']('[1,2,3]') == [1, 2, 3]


# Generated at 2022-06-18 16:04:12.211383
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCOpcode
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCMultinameKind
    from .abc import ABCMultinameKindTypeName
    from .abc import ABCMultinameKindQName
    from .abc import ABCMultinameKindRTQ

# Generated at 2022-06-18 16:04:23.242259
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.version == 10
    assert swf.file_length == 807
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:04:33.719921
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABCTag
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCScript
    from .abc import ABC

# Generated at 2022-06-18 16:04:37.861628
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('tests/test.swf', 'rb'))
    assert swf.version == 9
    assert swf.file_length == 609
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1



# Generated at 2022-06-18 16:04:48.849265
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_tags import TAG_CODE_TO_NAME
    from .swf_tags import TAG_CODE_TO_CLASS
    from .swf_tags import TAG_CODE_TO_ATTRIBUTES
    from .swf_tags import TAG_CODE_TO_CONSTRUCTOR
    from .swf_tags import TAG_CODE_TO_PARSER
    from .swf_tags import TAG_CODE_TO_EMITTER
    from .swf_tags import TAG_CODE_TO_EMITTER_ARGS
    from .swf_tags import TAG_CODE_TO_EMITTER_KWARGS
    from .swf_tags import TAG_CODE_TO_EMITTER_RET

# Generated at 2022-06-18 16:05:01.470569
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()

# Generated at 2022-06-18 16:06:53.264292
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:07:00.093364
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:07:10.081293
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData

    swf_data = SWFData()

# Generated at 2022-06-18 16:07:17.828621
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:07:27.203742
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompiler_ABC
    from .swfdecompiler import SWFDecompiler_ABC_MethodInfo
    from .swfdecompiler import SWFDecompiler_ABC_MethodBodyInfo
    from .swfdecompiler import SWFDecompiler_ABC_ExceptionInfo
    from .swfdecompiler import SWFDecompiler_ABC_TraitInfo
    from .swfdecompiler import SWFDecompiler_ABC_TraitInfo_Slot
    from .swfdecompiler import SWFDecompiler_ABC_TraitInfo_Method
    from .swfdecompiler import SWFDecompiler_

# Generated at 2022-06-18 16:07:34.971149
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:07:37.661079
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('test.Test')


# Generated at 2022-06-18 16:07:48.795859
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler

# Generated at 2022-06-18 16:07:55.930627
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.extract_class('Main') is not None
    assert swf.extract_class('Main').extract_function('main') is not None
    assert swf.extract_class('Main').extract_function('main')() is None
    assert swf.extract_class('Main').extract_function('main')() is None
    assert swf.extract_class('Main').extract_function('main')() is None
    assert swf.extract_class('Main').extract_function('main')() is None
    assert swf.extract_class('Main').extract_function('main')() is None
    assert sw

# Generated at 2022-06-18 16:08:07.490000
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABCTag
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCOpcode

    swf = SWF()
    swf.header.signature = b'FWS'
    swf.header.version = 9
    swf.header.file_length = 0
    swf.header.frame_size = (0, 0, 0, 0)
    swf.header.frame_rate = 0
    swf.header.frame_count = 0

    abcfile = ABCFile()
    abcfile.minor_version = 16
    abcfile.major_version = 46

    abcmethod = ABCMethod()