

# Generated at 2022-06-18 16:01:51.835681
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData

    def test_extract_function(swf_data):
        swf = SWFData(BytesIO(swf_data))
        decompiler = SWFDecompiler(swf)
        interpreter = SWFInterpreter(decompiler)
        interpreter.extract_function('TestClass', 'test_method')

    # Test with a simple method

# Generated at 2022-06-18 16:01:58.983372
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    avm_class = swf.extract_class('Test')
    assert avm_class.name == 'Test'
    assert avm_class.static_properties['a'] == 1
    assert avm_class.static_properties['b'] == 2
    assert avm_class.static_properties['c'] == 3
    assert avm_class.static_properties['d'] == 4
    assert avm_class.static_properties['e'] == 5
    assert avm_class.static_properties['f'] == 6
    assert avm_class.static_properties['g'] == 7
    assert avm_class.static_properties['h'] == 8

# Generated at 2022-06-18 16:02:05.412343
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerNotImplementedError
    from .swfdecompiler import SWFDecompilerNotSupportedError
    from .swfdecompiler import SWFDecompilerNotFoundError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerEOFError
    from .swfdecompiler import SWFDecompilerZlibError
    from .swfdecompiler import SWFDecompilerLZMAError
    from .swfdecompiler import SWFDecompilerLZMAError
    from .swfdecompiler import SWFDecompilerLZMAError

# Generated at 2022-06-18 16:02:12.319397
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(None, None)
    avm_class.register_methods({'foo': 1, 'bar': 2})
    assert avm_class.method_names == {'foo': 1, 'bar': 2}
    assert avm_class.method_idxs == {1: 'foo', 2: 'bar'}


# Generated at 2022-06-18 16:02:15.589407
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    cls = _AVMClass(0, 'Test')
    cls.register_methods({'m1': 1, 'm2': 2})
    assert cls.method_names == {'m1': 1, 'm2': 2}
    assert cls.method_idxs == {1: 'm1', 2: 'm2'}

# Generated at 2022-06-18 16:02:20.207749
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_function(swf.avm_classes['test.Test'], 'test')


# Generated at 2022-06-18 16:02:29.942826
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__),
                                           'test.swf'), 'rb'))
    swf.extract_class('TestClass')
    assert swf.classes['TestClass'].static_properties['foo'] == 'bar'
    assert swf.classes['TestClass'].static_properties['baz'] == 42
    assert swf.classes['TestClass'].static_properties['qux'] == [1, 2, 3]
    assert swf.classes['TestClass'].static_properties['quux'] == {
        'corge': 'grault',
        'garply': 'waldo',
    }
    assert swf.classes['TestClass'].static_properties['waldo'] == 'fred'

# Generated at 2022-06-18 16:02:39.022046
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import _swf
    from . import _swf_data
    from . import _swf_tag
    from . import _swf_tag_doabc
    from . import _swf_tag_doaction
    from . import _swf_tag_end
    from . import _swf_tag_showframe
    from . import _swf_tag_symbolclass
    from . import _swf_tag_unknown
    from . import _swf_tag_definebitsjpeg2
    from . import _swf_tag_definebitsjpeg3
    from . import _swf_tag_definebitslossless2
    from . import _swf_tag_definebitslossless
    from . import _swf_tag_definebits
    from . import _swf_tag_definebutton2

# Generated at 2022-06-18 16:02:49.016496
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(
        os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.version == 9
    assert swf.file_length == 798
    assert swf.frame_size == (0, 0, 400, 300)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1
    assert swf.file_attributes == {'UseNetwork': False}

# Generated at 2022-06-18 16:02:59.713423
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:04:02.277371
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler

# Generated at 2022-06-18 16:04:09.296219
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerErrorNoFlash
    from .swfdecompiler import SWFDecompilerErrorNoSWF
    from .swfdecompiler import SWFDecompilerErrorNoURL
    from .swfdecompiler import SWFDecompilerErrorNoVideo
    from .swfdecompiler import SWFDecompilerErrorNoYoutube
    from .swfdecompiler import SWFDecompilerErrorNoVimeo
    from .swfdecompiler import SWFDecompilerErrorNoDailymotion
    from .swfdecompiler import SWFDecompilerErrorNoFacebook
    from .swfdecompiler import SWFDecompilerErrorNoGeneric

# Generated at 2022-06-18 16:04:14.434293
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfinterpreter import SWFInterpreter
    from .swfobject import SWFObject
    from .swfrecords import SWFDoABC
    from .swftags import SWFTag
    from .swftags import SWFTagDoABC

    # SWF file with a single DoABC tag

# Generated at 2022-06-18 16:04:24.006570
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodBody
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCExceptionKind
    from .abc import ABCMultiname
    from .abc import ABCMultinameKind
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameRTQName
    from .abc import ABCMultinameRTQNameA
    from .abc import ABCMultinameRTQNameL
    from .abc import ABCMultinameRTQNameLA
    from .abc import ABCMultin

# Generated at 2022-06-18 16:04:34.520150
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCMultiname
    from .abc import ABCConstantPool
    from .abc import ABCConstantPool_String
    from .abc import ABCConstantPool_Int
    from .abc import ABCConstantPool_UInt
    from .abc import ABCConstantPool_Double
    from .abc import ABCConstantPool_Namespace
    from .abc import ABCConstantPool_NamespaceSet
    from .abc import ABCConstantPool_Multiname
    from .abc import ABCConstantPool_Multiname_QName
    from .abc import ABCConstantPool_Multiname_QNameA

# Generated at 2022-06-18 16:04:42.852942
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABC


# Generated at 2022-06-18 16:04:54.668521
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter()
    assert swf_interpreter.constant_strings == []
    assert swf_interpreter.constant_namespaces == []
    assert swf_interpreter.constant_namespace_sets == []
    assert swf_interpreter.constant_multinames == []
    assert swf_interpreter.methods == []
    assert swf_interpreter.classes == []
    assert swf_interpreter.scripts == []
    assert swf_interpreter.method_bodies == []
    assert swf_interpreter.multinames == []
    assert swf_interpreter.strings == []
    assert swf_interpreter.namespaces == []
    assert swf_interpreter.namespace_sets == []


# Generated at 2022-06-18 16:05:05.518834
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:05:16.008181
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:05:25.449641
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameLT
    from .abc import ABCMultinameN
    from .abc import ABCMultinameNT
    from .abc import ABCMultinameT
    from .abc import ABCMultinameTA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceType
    from .abc import ABCNamespaceTypeName
    from .abc import ABCNamespaceTypePackageName
    from .abc import ABCNamespaceTypePackage

# Generated at 2022-06-18 16:07:18.223351
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:07:27.759755
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfextract import SWFExtract
    from .swfinterpreter import SWFInterpreter
    from .swfobject import SWFObject
    from .swfparse import SWFParse
    from .swfrender import SWFRender
    from .swfrender import SWFRenderContext
    from .swfrender import SWFRenderMatrix
    from .swfrender import SWFRenderTransform
    from .swfrender import SWFRenderCxform
    from .swfrender import SWFRenderGradient
    from .swfrender import SWFRenderGradientRecord
    from .swfrender import SWFRenderGradientSpread
    from .swfrender import SWFRenderGradientInter

# Generated at 2022-06-18 16:07:35.402627
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_utils import read_swf_tag_data


# Generated at 2022-06-18 16:07:45.667956
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:07:54.066245
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.version == 9
    assert swf.file_length == 579
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:08:05.096834
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf_utils import read_swf_header
    from .swf_tags import TagDefineBinaryData
    from .swf_tags import TagDoABC
    from .swf_tags import TagDoABCDefine
    from .swf_tags import TagDoAction
    from .swf_tags import TagDoInitAction
    from .swf_tags import TagFileAttributes
    from .swf_tags import TagSymbolClass
    from .swf_tags import TagShowFrame
    from .swf_tags import TagEnd
    from .swf_tags import TagSetBackgroundColor
    from .swf_tags import TagDefineSceneAndFrameLabelData
    from .swf_tags import TagDefineBitsJPEG2
    from .swf_tags import TagDefineBitsJPEG3

# Generated at 2022-06-18 16:08:11.685554
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCConstantPool
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameRTQName
    from .abc import ABCMultinameRTQNameA
    from .abc import ABCMultinameRTQNameL
    from .abc import ABCMultinameRTQNameLA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceSet

# Generated at 2022-06-18 16:08:18.483403
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.version == 9
    assert swf.file_length == 639
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:08:28.235111
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    swf = SWFDecompiler(open('tests/swf/test.swf', 'rb').read())
    swf.decompile()
    interpreter = SWFInterpreter(swf)

# Generated at 2022-06-18 16:08:30.504686
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Main')
