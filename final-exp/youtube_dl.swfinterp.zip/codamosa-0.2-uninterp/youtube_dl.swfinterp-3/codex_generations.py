

# Generated at 2022-06-18 16:01:44.733984
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import _swf_data
    interpreter = SWFInterpreter(_swf_data.SWF_DATA)
    assert interpreter.constant_strings[0] == 'onMetaData'
    assert interpreter.constant_strings[1] == 'duration'
    assert interpreter.constant_strings[2] == 'width'
    assert interpreter.constant_strings[3] == 'height'
    assert interpreter.constant_strings[4] == 'videodatarate'
    assert interpreter.constant_strings[5] == 'framerate'
    assert interpreter.constant_strings[6] == 'videocodecid'
    assert interpreter.constant_strings[7] == 'audiodatarate'
    assert interpreter.constant_strings[8] == 'audiosamplerate'
    assert interpreter.constant

# Generated at 2022-06-18 16:01:47.380963
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__),
                                           'test.swf'), 'rb'))
    swf.extract_class('com.example.Test')


# Generated at 2022-06-18 16:01:55.160139
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:01:56.758040
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import _SWFInterpreter_test
    _SWFInterpreter_test.test_SWFInterpreter()


# Generated at 2022-06-18 16:02:03.481667
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCConstantPool
    from .abc import ABCMultiname
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCOpcode
    from .abc import ABCOpcode_0
    from .abc import ABCOpcode_1
    from .abc import ABCOpcode_2
    from .abc import ABCOpcode_3
    from .abc import ABCOpcode_4
    from .abc import ABCOpcode_5
    from .abc import ABCOpcode_6

# Generated at 2022-06-18 16:02:10.244640
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfinterpreter import SWFInterpreter
    from .swfobject import SWFObject
    from .swfrecords import SWFRecord
    from .swfrecords import SWFRecord_DoABC
    from .swfrecords import SWFRecord_DoAction
    from .swfrecords import SWFRecord_DoInitAction
    from .swfrecords import SWFRecord_FileAttributes
    from .swfrecords import SWFRecord_FrameLabel
    from .swfrecords import SWFRecord_PlaceObject2
    from .swfrecords import SWFRecord_ShowFrame
    from .swfrecords import SWFRecord_SymbolClass

# Generated at 2022-06-18 16:02:12.966668
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')

# Generated at 2022-06-18 16:02:18.675833
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:02:28.799984
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .tags import TagDefineBinaryData

    swf = SWF(BytesIO(b''))

# Generated at 2022-06-18 16:02:38.377822
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.constant_strings[0] == 'onMetaData'
    assert swf.constant_strings[1] == 'duration'
    assert swf.constant_strings[2] == 'width'
    assert swf.constant_strings[3] == 'height'
    assert swf.constant_strings[4] == 'videodatarate'
    assert swf.constant_strings[5] == 'framerate'
    assert swf.constant_strings[6] == 'videocodecid'
    assert swf.constant_strings[7] == 'audiodatarate'
    assert swf.constant_

# Generated at 2022-06-18 16:03:38.837783
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb').read()
    swf = SWF(swf)
    swf.parse()
    interpreter = SWFInterpreter(swf)
    interpreter.extract_class(swf.tags[2])
    assert interpreter.classes['Test'] is not None
    assert interpreter.classes['Test'].static_properties['test_static'] == 'test_static'
    assert interpreter.classes['Test'].variables['test_var'] == 'test_var'
    assert interpreter.classes['Test'].method_names == ['test_method']
    assert interpreter.classes['Test'].method_pyfunctions['test_method'] is not None

# Generated at 2022-06-18 16:03:42.585999
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('test')


# Generated at 2022-06-18 16:03:49.783060
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData


# Generated at 2022-06-18 16:03:59.356158
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:04:05.365402
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCConstantPool
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCException
    from .abc import ABCMethodBody
    from .abc import ABCMethodBodyInfo
    from .abc import ABCMethodInfo
    from .abc import ABCMetadataInfo
    from .abc import ABC

# Generated at 2022-06-18 16:04:11.976598
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_tags import TagDefineBinaryData
    from .swf_tags import TagDoABC
    from .swf_tags import TagDoABCDefine
    from .swf_tags import TagDoInitAction
    from .swf_tags import TagFileAttributes
    from .swf_tags import TagMetadata
    from .swf_tags import TagShowFrame
    from .swf_tags import TagSymbolClass
    from .swf_tags import TagUnknown
    from .swf_tags import TagEnd
    from .swf_tags import TagSetBackgroundColor
    from .swf_tags import TagDefineSceneAndFrameLabelData
    from .swf_tags import TagDefineBitsLossless2

# Generated at 2022-06-18 16:04:15.456601
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert repr(_ScopeDict(None)) == 'None__Scope({})'
    assert repr(_ScopeDict(None, a=1)) == 'None__Scope({\'a\': 1})'



# Generated at 2022-06-18 16:04:24.536815
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF


# Generated at 2022-06-18 16:04:35.183776
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf_utils import read_swf
    from .swf_tags import TagDefineBinaryData
    from .swf_types import TagHeader
    from .swf_types import TagDoABC
    from .swf_types import TagDoABCDefine
    from .swf_types import TagSymbolClass
    from .swf_types import TagFileAttributes
    from .swf_types import TagSetBackgroundColor
    from .swf_types import TagShowFrame
    from .swf_types import TagEnd
    from .swf_types import TagShowFrame
    from .swf_types import TagEnd
    from .swf_types import TagShowFrame
    from .swf_types import TagEnd
    from .swf_types import TagShowFrame
    from .swf_types import TagEnd

# Generated at 2022-06-18 16:04:43.348069
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:06:23.810247
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:06:28.126867
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:06:32.394235
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-18 16:06:36.887114
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData

# Generated at 2022-06-18 16:06:46.925857
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerParseError
    from .swfdecompiler import SWFDecompilerTypeError
    from .swfdecompiler import SWFDecompilerValueError
    from .swfdecompiler import SWFDecompilerWarning
    from .swfdecompiler import SWFDecompilerDeprecationWarning
    from .swfdecompiler import SWFDecompilerPendingDeprecationWarning
    from .swfdecompiler import SWFDecompilerSyntaxWarning
    from .swfdecompiler import SWFDecompilerRuntimeWarning

# Generated at 2022-06-18 16:06:56.166860
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf_utils import read_swf_file
    from .swf_utils import read_swf_header
    from .swf_utils import read_swf_tags
    from .swf_utils import read_swf_tag_DoABC
    from .swf_utils import read_swf_tag_DoABC_body
    from .swf_utils import read_swf_tag_DoABC_body_abcfile
    from .swf_utils import read_swf_tag_DoABC_body_abcfile_cpool_info
    from .swf_utils import read_swf_tag_DoABC_body_abcfile_method_info
    from .swf_utils import read_swf_tag_DoABC_body_abcfile_metadata_info
    from .swf_utils import read_sw

# Generated at 2022-06-18 16:07:01.805891
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:07:11.327769
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.version == 9
    assert swf.file_length == 459
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:07:18.814122
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:07:28.413118
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('TestClass')
    assert swf.classes['TestClass'].static_properties['test_static_property'] == 'test_static_property_value'
    assert swf.classes['TestClass'].static_properties['test_static_property_2'] == 'test_static_property_2_value'
    assert swf.classes['TestClass'].static_properties['test_static_property_3'] == 'test_static_property_3_value'
    assert swf.classes['TestClass'].static_properties['test_static_property_4'] == 'test_static_property_4_value'
    assert swf