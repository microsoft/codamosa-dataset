

# Generated at 2022-06-18 16:01:58.498920
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter(None)
    swf.constant_strings = ['a', 'b']
    swf.constant_ints = [1, 2]
    swf.constant_uints = [3, 4]
    swf.constant_doubles = [5.0, 6.0]
    swf.constant_namespaces = [
        _Namespace('a'), _Namespace('b'), _Namespace('c')]
    swf.constant_namespace_sets = [
        [swf.constant_namespaces[0], swf.constant_namespaces[1]],
        [swf.constant_namespaces[2]]]

# Generated at 2022-06-18 16:02:05.061119
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF


# Generated at 2022-06-18 16:02:10.802606
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'



# Generated at 2022-06-18 16:02:13.340487
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')


# Generated at 2022-06-18 16:02:18.938087
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))

# Generated at 2022-06-18 16:02:28.910762
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb').read())
    assert swf.version == 9
    assert swf.file_length == 549
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:02:38.377839
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('test')
    assert swf.extract_class('test') is swf.extract_class('test')
    assert swf.extract_class('test').make_object() is not None
    assert swf.extract_class('test').make_object().avm_class is swf.extract_class('test')
    assert swf.extract_class('test').make_object().avm_class is swf.extract_class('test')
    assert swf.extract_class('test').make_object().avm_class.make_object() is not None
    assert swf.extract_

# Generated at 2022-06-18 16:02:48.331757
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodBody
    from .abc import ABCMethod


# Generated at 2022-06-18 16:02:55.568943
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:03:05.305835
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import os
    import sys
    import unittest

    class TestSWFInterpreter(unittest.TestCase):
        def test_SWFInterpreter(self):
            swf_path = os.path.join(os.path.dirname(__file__), 'test.swf')
            with open(swf_path, 'rb') as f:
                swf = f.read()
            interpreter = SWFInterpreter(swf)
            self.assertEqual(interpreter.version, 9)
            self.assertEqual(interpreter.file_length, len(swf))
            self.assertEqual(interpreter.frame_size, (0, 0, 320, 240))
            self.assertEqual(interpreter.frame_rate, 24)

# Generated at 2022-06-18 16:04:22.358322
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-18 16:04:33.483787
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_parse import SWF
    from .swf_parse import SWF_HEADER_SIZE
    from .swf_parse import SWF_TAG_TYPE_DO_ABC
    from .swf_parse import SWF_TAG_TYPE_SYMBOL_CLASS
    from .swf_parse import SWF_TAG_TYPE_END
    from .swf_parse import SWF_TAG_TYPE_FILE_ATTRIBUTES
    from .swf_parse import SWF_TAG_TYPE_SCRIPT_LIMITS
    from .swf_parse import SWF_TAG_TYPE_SET_BACKGROUND_COLOR
    from .swf_parse import SWF_TAG_TYPE_FRAME_LABEL
    from .swf_parse import SWF_TAG_TYPE_DO_ACTION


# Generated at 2022-06-18 16:04:41.814695
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swf_utils import read_swf_header
    from .swf_utils import read_swf_tags
    from .swf_utils import read_swf_tag
    from .swf_utils import read_swf_tag_header
    from .swf_utils import read_swf_tag_doabc
    from .swf_utils import read_swf_tag_symbolclass
    from .swf_utils import read_swf_tag_doaction
    from .swf_utils import read_swf_tag_doinitaction
    from .swf_utils import read_swf_tag_definebutton
    from .swf_utils import read_swf_tag_definebutton2
    from .swf_utils import read_swf_tag_definebuttoncxform

# Generated at 2022-06-18 16:04:48.667212
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData

    swf = SWFData()

# Generated at 2022-06-18 16:05:01.357932
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))

# Generated at 2022-06-18 16:05:08.999286
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.version == 9
    assert swf.file_length == 524
    assert swf.frame_size == Rect(0, 0, 320, 240)
    assert swf.frame_rate == 12
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:05:20.185890
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF


# Generated at 2022-06-18 16:05:29.323240
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_utils import read_swf_tags

    def test_extract_function(swf_data):
        swf_data = BytesIO(swf_data)
        swf_tags = read_swf_tags(swf_data)
        swf_data.close()

        interpreter = SWFInterpreter()
        for tag in swf_tags:
            if tag.tag_type == 82:
                interpreter.handle_doabc(tag)

        for tag in swf_tags:
            if tag.tag_type == 69:
                interpreter.handle_symboltable(tag)

        for tag in swf_tags:
            if tag.tag_type == 72:
                interpreter.handle_doaction(tag)

        return interpreter

    # Test for a

# Generated at 2022-06-18 16:05:36.114812
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerNotImplementedError
    from .swfdecompiler import SWFDecompilerNotSupportedError
    from .swfdecompiler import SWFDecompilerNotFoundError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerValueError
    from .swfdecompiler import SWFDecompilerTypeError
    from .swfdecompiler import SWFDecompilerIndexError
    from .swfdecompiler import SWFDecompilerKeyError
    from .swfdecompiler import SWFDecompilerAttributeError
    from .swfdecompiler import SW

# Generated at 2022-06-18 16:05:45.679394
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFClass
    from .swfdecompiler import SWFMethod
    from .swfdecompiler import SWFMethodBody
    from .swfdecompiler import SWFMethodBody_ActionBlock
    from .swfdecompiler import SWFMethodBody_ActionBlock_Action
    from .swfdecompiler import SWFMethodBody_ActionBlock_Action_Push
    from .swfdecompiler import SWFMethodBody_ActionBlock_Action_Push_String
    from .swfdecompiler import SWFMethodBody_ActionBlock_Action_Push_Float
    from .swfdecompiler import SWFMethodBody_ActionBlock_Action_Push_Null
    from .swfdecompiler import SWFMethodBody_ActionBlock_Action

# Generated at 2022-06-18 16:07:26.373736
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    with open('tests/swf/test_avm2.swf', 'rb') as f:
        swf = SWF(f)
    swfdecompiler = SWFDecompiler(swf)
    swfdecompiler.decompile()
    swfdecompiler.dump_abc(BytesIO())
    swfdecompiler.dump_xml(BytesIO())

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-18 16:07:34.553102
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:07:44.062329
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData

# Generated at 2022-06-18 16:07:53.509814
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'testdata', 'test.swf'), 'rb'))
    swf.extract_class('test')
    assert swf.classes['test'].static_properties['test'] == 'test'
    assert swf.classes['test'].static_properties['test2'] == 'test2'
    assert swf.classes['test'].static_properties['test3'] == 'test3'
    assert swf.classes['test'].static_properties['test4'] == 'test4'
    assert swf.classes['test'].static_properties['test5'] == 'test5'
    assert swf.classes['test'].static_properties['test6'] == 'test6'

# Generated at 2022-06-18 16:08:04.603087
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.version == 9
    assert swf.file_length == 607
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 12.0
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:08:11.346341
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData


# Generated at 2022-06-18 16:08:18.331218
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodBody
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCMultiname
    from .abc import ABCConstantPool
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCMultinameRTQName
    from .abc import ABCMultinameRTQNameA

# Generated at 2022-06-18 16:08:28.076056
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:08:39.002504
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_tags import read_swf_tag
    from .swf_tags import TAG_DO_ABC
    from .swf_tags import TAG_SYMBOL_CLASS
    from .swf_tags import TAG_FILE_ATTRIBUTES
    from .swf_tags import TAG_END
    from .swf_tags import TAG_DO_INIT_ACTION
    from .swf_tags import TAG_SCRIPT_LIMITS
    from .swf_tags import TAG_SET_BACKGROUND_COLOR
    from .swf_tags import TAG_DEFINE_SCENE_AND_FRAME_LABEL_DATA
    from .swf_tags import TAG_DEFINE_BINARY_DATA

# Generated at 2022-06-18 16:08:48.583468
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.version == 9
    assert swf.file_length == 527
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1