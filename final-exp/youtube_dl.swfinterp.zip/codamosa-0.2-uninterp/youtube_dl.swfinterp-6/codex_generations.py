

# Generated at 2022-06-18 16:01:30.779387
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter()
    interpreter.extract_class(None, None, None)

# Generated at 2022-06-18 16:01:42.256905
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerValueError
    from .swfdecompiler import SWFDecompilerTypeError
    from .swfdecompiler import SWFDecompilerIndexError
    from .swfdecompiler import SWFDecompilerKeyError
    from .swfdecompiler import SWFDecompilerNotImplementedError
    from .swfdecompiler import SWFDecompilerAttributeError
    from .swfdecompiler import SWFDecompilerRuntimeError
    from .swfdecompiler import SWFDecompilerStopIteration
    from .swfdecompiler import SWF

# Generated at 2022-06-18 16:01:49.851531
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABCTag
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCOpcode
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCMultinameRTQName
    from .abc import ABCMultinameRTQNameA
    from .abc import ABCMultinameRTQNameL

# Generated at 2022-06-18 16:01:53.276603
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(0, 'test')
    avm_class.register_methods({'foo': 1, 'bar': 2})
    assert avm_class.method_names == {'foo': 1, 'bar': 2}
    assert avm_class.method_idxs == {1: 'foo', 2: 'bar'}



# Generated at 2022-06-18 16:02:00.151098
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_utils import read_swf_header
    from .swf_utils import read_swf_tags
    from .swf_utils import read_swf_tag_DoABC
    from .swf_utils import read_swf_tag_DoABC_body
    from .swf_utils import read_swf_tag_DoABC_body_abc_file
    from .swf_utils import read_swf_tag_DoABC_body_abc_file_cpool_info
    from .swf_utils import read_swf_tag_DoABC_body_abc_file_method_info
    from .swf_utils import read_swf_tag_DoABC_body_abc_file_method_body_info
    from .swf_utils import read_swf_tag_DoABC_body_

# Generated at 2022-06-18 16:02:03.779722
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(_AVMClass_Object(None)).__repr__() == 'None__Scope({})'
    assert _ScopeDict(_AVMClass_Object(None)).__repr__() == 'None__Scope({})'



# Generated at 2022-06-18 16:02:15.558914
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCConstantPool
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCMethodBody
    from .abc import ABCFileInfo
    from .abc import ABCMetadataInfo
    from .abc import ABCScriptInfo
    from .abc import ABCMethodInfo
    from .abc import ABCExceptionInfo
    from .abc import ABCTrait
    from .abc import ABCTrait

# Generated at 2022-06-18 16:02:17.972571
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'



# Generated at 2022-06-18 16:02:28.144261
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_utils import read_swf_header, read_swf_tags, read_swf_tag_header, read_swf_tag_body
    from .swf_utils import read_swf_tag_doabc, read_swf_tag_doaction, read_swf_tag_doinitaction
    from .swf_utils import read_swf_tag_symbolclass, read_swf_tag_definebits, read_swf_tag_definebitsjpeg2
    from .swf_utils import read_swf_tag_definebitsjpeg3, read_swf_tag_definebitsjpeg4, read_swf_tag_definebitslossless
    from .swf_utils import read_swf_tag_definebitslossless2, read_sw

# Generated at 2022-06-18 16:02:37.697895
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABCTag
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCMethodBody
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCConstantPool
    from .abc import ABCMethodInfo
    from .abc import ABCMetadata

# Generated at 2022-06-18 16:03:37.853596
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData

# Generated at 2022-06-18 16:03:46.942913
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABC
    from .abc import ABCFile
    from .abc import Multiname
    from .abc import MultinameL
    from .abc import MultinameLA
    from .abc import Namespace
    from .abc import NamespaceSet
    from .abc import QName
    from .abc import RTQName
    from .abc import RTQNameL
    from .abc import RTQNameLA
    from .abc import U30
    from .abc import U8
    from .abc import U16
    from .abc import S24
    from .abc import S32
    from .abc import S8
    from .abc import S16
    from .abc import _read_u30
    from .abc import _read_u8

# Generated at 2022-06-18 16:03:56.566748
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerNotImplementedError
    from .swfdecompiler import SWFDecompilerParseError
    from .swfdecompiler import SWFDecompilerTypeError
    from .swfdecompiler import SWFDecompilerValueError
    from .swfdecompiler import SWFDecompilerWarning
    from .swfdecompiler import SWFDecompilerZeroDivisionError
    from .swfdecompiler import SWFDecompilerAssertionError
    from .swfdecompiler import SWFDecompilerAttributeError

# Generated at 2022-06-18 16:04:04.125402
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.version == 9
    assert swf.file_length == 524
    assert swf.frame_size == Rectangle(0, 0, 800, 600)
    assert swf.frame_rate == 24.0
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:04:11.027921
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF


# Generated at 2022-06-18 16:04:22.289686
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:04:33.442013
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_parse import SWF


# Generated at 2022-06-18 16:04:41.777700
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerIOError

    # Test for constructor of class SWFInterpreter
    # Test for constructor of class SWFInterpreter
    # Test for constructor of class SWFInterpreter
    # Test for constructor of class SWFInterpreter
    # Test for constructor of class SWFInterpreter
    # Test for constructor of class SWFInterpreter
    # Test for constructor of class SWFInterpreter
    # Test for constructor of class SWFInterpreter
    # Test for constructor of class SWFInterpreter
    # Test for constructor of class SWFInterpreter
    # Test for constructor of class SWFInterpreter
    # Test for constructor of class SW

# Generated at 2022-06-18 16:04:48.695782
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_extract import extract_swf
    from .swf_extract import extract_swf_data
    from .swf_extract import extract_swf_url
    from .swf_extract import extract_swf_urls
    from .swf_extract import extract_swf_playlist
    from .swf_extract import extract_swf_playlist_from_url
    from .swf_extract import extract_swf_playlist_from_html
    from .swf_extract import extract_swf_playlist_from_xml
    from .swf_extract import extract_swf_playlist_from_xml_url
    from .swf_extract import extract_swf_playlist_from_xml_url_handle

# Generated at 2022-06-18 16:05:01.359084
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABCTag
    from .abc import ABCFile
    from .abc import Multiname
    from .abc import MultinameL
    from .abc import MultinameLA
    from .abc import MultinameLT
    from .abc import MultinameLAT
    from .abc import MultinameA
    from .abc import MultinameT
    from .abc import MultinameAT
    from .abc import MultinameRT
    from .abc import MultinameR
    from .abc import MultinameRAT
    from .abc import MultinameRTQName
    from .abc import MultinameRTQNameL
    from .abc import MultinameRTQNameLA
    from .abc import MultinameQName

# Generated at 2022-06-18 16:06:59.498480
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_utils import read_swf
    from .swf_tags import DoABCTag
    from .swf_tags import SymbolClassTag
    from .swf_tags import DoActionTag
    from .swf_tags import DefineSpriteTag
    from .swf_tags import PlaceObject2Tag
    from .swf_tags import PlaceObject3Tag
    from .swf_tags import RemoveObject2Tag
    from .swf_tags import RemoveObjectTag
    from .swf_tags import ShowFrameTag
    from .swf_tags import FrameLabelTag
    from .swf_tags import DefineButtonTag
    from .swf_tags import DefineButton2Tag
    from .swf_tags import DefineButtonCxformTag
    from .swf_tags import DefineButtonSoundTag

# Generated at 2022-06-18 16:07:09.622093
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter()
    assert swf_interpreter.constant_strings == []
    assert swf_interpreter.constant_namespaces == []
    assert swf_interpreter.constant_namespace_sets == []
    assert swf_interpreter.constant_multinames == []
    assert swf_interpreter.methods == []
    assert swf_interpreter.metadata == []
    assert swf_interpreter.classes == []
    assert swf_interpreter.scripts == []
    assert swf_interpreter.method_bodies == []
    assert swf_interpreter.multinames == []
    assert swf_interpreter.method_pyfunctions == {}
    assert swf_interpreter.classes_by_

# Generated at 2022-06-18 16:07:17.455923
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF


# Generated at 2022-06-18 16:07:26.567189
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:07:34.587833
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import io
    import os
    import sys
    import unittest

    class TestSWFInterpreter(unittest.TestCase):
        def test_constructor(self):
            with io.open(os.path.join(os.path.dirname(__file__),
                                      'test.swf'), 'rb') as f:
                swf = SWFInterpreter(f)

# Generated at 2022-06-18 16:07:44.086322
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdata import SWFDefineBinaryDataTag
    from .swfdata import SWFDoABCTag
    from .swfdata import SWFDoActionTag
    from .swfdata import SWFDoInitActionTag
    from .swfdata import SWFEndTag
    from .swfdata import SWFHeader
    from .swfdata import SWFShowFrameTag
    from .swfdata import SWFSymbolClassTag
    from .swfdata import SWFTag
    from .swfdata import SWFTagType
    from .swfdata import SWFTags
    from .swfdata import SWFUnknownTag
    from .swfdata import SWFVersion

# Generated at 2022-06-18 16:07:53.510237
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:08:04.603801
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))

# Generated at 2022-06-18 16:08:11.308687
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:08:16.529505
# Unit test for method extract_function of class SWFInterpreter