

# Generated at 2022-06-18 16:02:09.788337
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCExceptionHandler
    from .abc import ABCException
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCString
    from .abc import ABCInt
    from .abc import ABCUInt
    from .abc import ABCDouble
    from .abc import ABCDecimal
    from .abc import ABC

# Generated at 2022-06-18 16:02:15.167328
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABCTag


# Generated at 2022-06-18 16:02:26.672667
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_tags import TagDefineBinaryData
    from .swf_tags import TagDoABC
    from .swf_tags import TagDoABCDefine
    from .swf_tags import TagDoInitAction
    from .swf_tags import TagFileAttributes
    from .swf_tags import TagMetadata
    from .swf_tags import TagPlaceObject2
    from .swf_tags import TagShowFrame
    from .swf_tags import TagSymbolClass
    from .swf_tags import TagUnknown
    from .swf_tags import TagSetBackgroundColor
    from .swf_tags import TagDefineSceneAndFrameLabelData
    from .swf_tags import TagDefineFontName

# Generated at 2022-06-18 16:02:33.503576
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMultiname
    from .abc import ABCConstantPool
    from .abc import ABCInstanceInfo
    from .abc import ABCClassInfo
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionInfo
    from .abc import ABCExceptionEntry
    from .abc import ABCOpcode
    from .abc import ABCOpcode_getlocal
    from .abc import ABCOpcode_pushstring
    from .abc import ABCOpcode_returnvalue
    from .abc import ABCOpcode_findproperty
    from .abc import ABCOpcode_getproperty
    from .abc import ABCOpcode_pushscope
    from .abc import ABCOpcode_pushint


# Generated at 2022-06-18 16:02:43.933522
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCOpcode
    from .abc import ABCMultiname
    from .abc import ABCConstantPool
    from .abc import ABCMethodBody
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCScript
    from .abc import ABCMethodInfo
    from .abc import ABCMethodParam
    from .abc import ABCMethodKind
    from .abc import ABCMethodFlags
    from .abc import ABCExceptionKind
    from .abc import ABCExceptionFlags
    from .abc import ABCTraitKind
    from .abc import ABCTraitAttributes
    from .abc import ABCTrait

# Generated at 2022-06-18 16:02:52.340167
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:02:56.594374
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('_level0')

# Generated at 2022-06-18 16:03:06.085029
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:03:14.174688
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerValueError
    from .swfdecompiler import SWFDecompilerTypeError
    from .swfdecompiler import SWFDecompilerIndexError
    from .swfdecompiler import SWFDecompilerKeyError
    from .swfdecompiler import SWFDecompilerAttributeError
    from .swfdecompiler import SWFDecompilerNotImplementedError
    from .swfdecompiler import SWFDecompilerRuntimeError
    from .swfdecompiler import SWFDecompilerStopIteration
    from .swfdecompiler import SWF

# Generated at 2022-06-18 16:03:23.046920
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.version == 9
    assert swf.file_length == 488
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24.0
    assert swf.frame_count == 1
    assert swf.file_attributes == 0

# Generated at 2022-06-18 16:04:22.564900
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter()
    assert swf_interpreter.constant_strings == []
    assert swf_interpreter.multinames == []
    assert swf_interpreter.classes == {}
    assert swf_interpreter.method_pyfunctions == {}
    assert swf_interpreter.method_names == []
    assert swf_interpreter.static_properties == {}
    assert swf_interpreter.variables == {}
    assert swf_interpreter.method_body == {}
    assert swf_interpreter.method_param_count == {}
    assert swf_interpreter.method_return_type == {}
    assert swf_interpreter.method_param_type == {}
    assert swf_interpreter.method_debug_

# Generated at 2022-06-18 16:04:24.831555
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.extract_class(None, None)

# Generated at 2022-06-18 16:04:35.492242
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_tags import TagDefineBinaryData


# Generated at 2022-06-18 16:04:40.301568
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')


# Generated at 2022-06-18 16:04:47.605460
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFInterpreter
    from .swfdecompiler import SWFClass
    from .swfdecompiler import SWFMethod
    from .swfdecompiler import SWFVariable
    from .swfdecompiler import SWFMultiname
    from .swfdecompiler import SWFMultiname_QName
    from .swfdecompiler import SWFMultiname_RTQName
    from .swfdecompiler import SWFMultiname_RTQNameL
    from .swfdecompiler import SWFMultiname_RTQNameLA
    from .swfdecompiler import SWFMultiname_Multiname
    from .swfdecompiler import SWF

# Generated at 2022-06-18 16:04:53.085593
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:05:04.718038
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerValueError
    from .swfdecompiler import SWFDecompilerTypeError
    from .swfdecompiler import SWFDecompilerIndexError
    from .swfdecompiler import SWFDecompilerKeyError
    from .swfdecompiler import SWFDecompilerNotImplementedError
    from .swfdecompiler import SWFDecompilerAttributeError
    from .swfdecompiler import SWFDecompilerRuntimeError
    from .swfdecompiler import SWFDecompilerStopIteration
    from .swfdecompiler import SWF

# Generated at 2022-06-18 16:05:10.913373
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:05:21.493293
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:05:30.004996
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf_utils import read_swf_tag_data

    # Test with a simple function

# Generated at 2022-06-18 16:07:28.313069
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdata import SWFDoABCTag
    from .swfdata import SWFDoActionTag
    from .swfdata import SWFDoInitActionTag
    from .swfdata import SWFEndTag
    from .swfdata import SWFShowFrameTag
    from .swfdata import SWFSymbolClassTag
    from .swfdata import SWFTag
    from .swfdata import SWFTagType
    from .swfdata import SWFUnknownTag
    from .swfdata import SWFUnknownTagType
    from .swfdata import SWFUnknownTagTypeError
    from .swfdata import SWFUnknownTagTypeWarning
    from .swfdata import SWFUnknown

# Generated at 2022-06-18 16:07:35.924746
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerNotImplementedError
    from .swfdecompiler import SWFDecompilerUnsupportedError
    from .swfdecompiler import SWFDecompilerUnsupportedTagError
    from .swfdecompiler import SWFDecompilerUnsupportedTagAttributeError

    def test_extract_function(swf_file, func_name):
        with open(swf_file, 'rb') as f:
            swf = SWFDecompiler(f)
            swf.decompile()
            swf.interpreter.extract_function(swf.avm_class, func_name)



# Generated at 2022-06-18 16:07:47.091412
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-18 16:07:54.749389
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import _swf_data
    from . import _swf_tags
    from . import _swf_abc

    # Test constructor

# Generated at 2022-06-18 16:08:05.727837
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:08:14.963723
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABCTag
    from .abc import ABCFile
    from .abc import Multiname
    from .abc import Namespace
    from .abc import NamespaceSet
    from .abc import MethodInfo
    from .abc import MethodBodyInfo
    from .abc import ClassInfo
    from .abc import InstanceInfo
    from .abc import Trait
    from .abc import TraitSlot
    from .abc import TraitMethod
    from .abc import TraitClass
    from .abc import TraitFunction
    from .abc import TraitNamespace
    from .abc import TraitNamespaceSet
    from .abc import TraitConst
    from .abc import TraitSlotConst
    from .abc import TraitClassConst
    from .abc import TraitFunctionConst
   

# Generated at 2022-06-18 16:08:18.997538
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('test.Test')

# Generated at 2022-06-18 16:08:28.599513
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:08:39.327189
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:08:48.911047
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData