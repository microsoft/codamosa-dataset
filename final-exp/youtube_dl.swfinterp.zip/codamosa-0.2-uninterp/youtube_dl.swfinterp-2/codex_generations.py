

# Generated at 2022-06-18 16:02:06.262044
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.constant_strings[0] == 'onMetaData'
    assert swf.constant_strings[1] == 'duration'
    assert swf.constant_strings[2] == 'width'
    assert swf.constant_strings[3] == 'height'
    assert swf.constant_strings[4] == 'videodatarate'
    assert swf.constant_strings[5] == 'framerate'
    assert swf.constant_strings[6] == 'videocodecid'
    assert swf.constant_strings[7] == 'audiodatarate'
    assert swf.constant_strings[8] == 'audiosamplerate'

# Generated at 2022-06-18 16:02:15.738730
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_data import SWFData
    from .swf_tags import TagDoABC


# Generated at 2022-06-18 16:02:26.832385
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:02:33.651670
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter


# Generated at 2022-06-18 16:02:43.998965
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:02:52.567182
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class AVMClass(object):
        def __init__(self):
            self.method_names = set()
            self.method_pyfunctions = {}
            self.static_properties = {}
            self.variables = {}
            self.make_object = lambda: AVMClass_Object(self)
    class AVMClass_Object(object):
        def __init__(self, avm_class):
            self.avm_class = avm_class
    class SWFInterpreter(object):
        def __init__(self):
            self.multinames = []
            self.constant_strings = []
            self.constant_namespaces = []
            self.constant_namespace_sets = []
            self.constant_multinames = []
            self.classes = {}
            self.methods

# Generated at 2022-06-18 16:02:58.345097
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABCTag
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCOpcode
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceSetL
    from .abc import ABCConstantPool
    from .abc import ABCInstanceInfo
    from .abc import ABCClassInfo

# Generated at 2022-06-18 16:03:01.265471
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'



# Generated at 2022-06-18 16:03:10.337477
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler


# Generated at 2022-06-18 16:03:17.281792
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf import SWF
    from .swf_data import swf_data
    swf = SWF(BytesIO(swf_data))
    interpreter = SWFInterpreter(swf)
    interpreter.extract_class('_level0')
    assert interpreter.classes['_level0'].static_properties['_x'] == 0
    assert interpreter.classes['_level0'].static_properties['_y'] == 0
    assert interpreter.classes['_level0'].static_properties['_xscale'] == 100
    assert interpreter.classes['_level0'].static_properties['_yscale'] == 100
    assert interpreter.classes['_level0'].static_properties['_currentframe'] == 1
    assert interpreter.classes['_level0'].static_properties['_totalframes'] == 1

# Generated at 2022-06-18 16:04:12.776619
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__),
                                           'test.swf'), 'rb'))
    assert swf.version == 9
    assert swf.file_length == 549
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1
    assert len(swf.tags) == 5
    assert swf.tags[0].code == 69
    assert swf.tags[1].code == 70
    assert swf.tags[2].code == 87
    assert swf.tags[3].code == 69
    assert swf.tags[4].code == 59
    assert swf.tags[0].length == 4
    assert sw

# Generated at 2022-06-18 16:04:23.269948
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:04:33.758344
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('com.example.Test')
    assert swf.classes['com.example.Test'].static_properties['test'] == 'test'
    assert swf.classes['com.example.Test'].static_properties['test2'] == 'test2'
    assert swf.classes['com.example.Test'].static_properties['test3'] == 'test3'
    assert swf.classes['com.example.Test'].static_properties['test4'] == 'test4'
    assert swf.classes['com.example.Test'].static_properties['test5'] == 'test5'

# Generated at 2022-06-18 16:04:42.131006
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodInfo
    from .abc import ABCMethodBodyInfo
    from .abc import ABCExceptionInfo
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCMultinameKind
    from .abc import ABCMultinameKindTypeName
    from .abc import ABCMultinameKindQName
    from .abc import ABCMultinameKindRTQName

# Generated at 2022-06-18 16:04:49.421332
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_utils import read_swf_header

    swf_data = open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb').read()
    header = read_swf_header(BytesIO(swf_data))
    swf = SWFInterpreter(header, swf_data)
    swf.extract_function(swf.avm_class, 'get_video_info')


# Generated at 2022-06-18 16:05:01.738002
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceTypeName
    from .abc import ABCString
    from .abc import ABCInt
    from .abc import ABCUInt
    from .abc import ABCDouble
    from .abc import ABCDecimal

# Generated at 2022-06-18 16:05:09.330043
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:05:20.524325
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABC


# Generated at 2022-06-18 16:05:29.604825
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:05:31.562474
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('com.longtailvideo.jwplayer.player::Player')

# Generated at 2022-06-18 16:07:19.410825
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter()
    interpreter.extract_class(
        '<class name="Object" flags="0" super="*" '
        'protectedNs="0" initializer="0" traits="0">'
        '<method name="toString" flags="0" dispId="0" '
        'method="0" traits="0"/>'
        '<method name="valueOf" flags="0" dispId="0" '
        'method="1" traits="0"/>'
        '</class>')
    assert 'Object' in interpreter.classes
    assert 'toString' in interpreter.classes['Object'].method_names
    assert 'valueOf' in interpreter.classes['Object'].method_names
    assert interpreter.classes['Object'].method_pyfunctions['toString'] is not None
    assert interpreter.classes

# Generated at 2022-06-18 16:07:28.445113
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:07:35.956714
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'
    assert _ScopeDict(None).__repr__() == 'None__Scope({})'

# Generated at 2022-06-18 16:07:47.134569
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import os
    import sys
    import unittest
    import doctest
    import io

    class SWFInterpreterTest(unittest.TestCase):
        def test_extract_function(self):
            class TestAVMClass(object):
                def __init__(self):
                    self.method_names = set()
                    self.method_pyfunctions = {}
                    self.static_properties = {}
                    self.variables = {}
                    self.make_object = lambda: TestAVMClassObject(self)

            class TestAVMClassObject(object):
                def __init__(self, avm_class):
                    self.avm_class = avm_class

            class TestSWFInterpreter(SWFInterpreter):
                def __init__(self):
                    self.constant_strings = []

# Generated at 2022-06-18 16:07:54.898069
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_tags import TagDefineBinaryData
    from .swf_tags import TagDoABC
    from .swf_tags import TagDoABCDefine
    from .swf_tags import TagDoInitAction
    from .swf_tags import TagFileAttributes
    from .swf_tags import TagMetadata
    from .swf_tags import TagShowFrame
    from .swf_tags import TagSymbolClass
    from .swf_tags import TagUnknown
    from .swf_tags import TagEnd
    from .swf_tags import TagSetBackgroundColor
    from .swf_tags import TagDefineSceneAndFrameLabelData
    from .swf_tags import TagDefineFontName

# Generated at 2022-06-18 16:07:59.145380
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__),
                                           'test.swf'), 'rb'))
    swf.extract_class('Main')


# Generated at 2022-06-18 16:08:09.248030
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodBody
    from .abc import ABCMethodInfo
    from .abc import ABCMethodKind
    from .abc import ABCMethodParam
    from .abc import ABCMultiname
    from .abc import ABCNamespace
    from .abc import ABCNamespaceKind
    from .abc import ABCOpcode
    from .abc import ABCTrait
    from .abc import ABCTraitKind
    from .abc import ABCValueKind
    from .abc import ABCValueType
    from .abc import ABCFile
    from .abc import ABCFile
    from .abc import ABCFile
    from .abc import ABCFile
    from .abc import ABCFile
    from .abc import ABCFile
    from .abc import ABCFile
    from .abc import ABCFile

# Generated at 2022-06-18 16:08:15.798312
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter()
    assert swf_interpreter.constant_strings == []
    assert swf_interpreter.constant_namespaces == []
    assert swf_interpreter.constant_namespace_sets == []
    assert swf_interpreter.constant_multinames == []
    assert swf_interpreter.methods == []
    assert swf_interpreter.classes == []
    assert swf_interpreter.scripts == []
    assert swf_interpreter.method_bodies == []


# Generated at 2022-06-18 16:08:26.503498
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf_utils import SWF
    from .swf_utils import SWF_CLASS_DEFINITION_TAG
    from .swf_utils import SWF_DO_ABC_TAG
    from .swf_utils import SWF_DO_ABC_DEFINE_TAG
    from .swf_utils import SWF_SYMBOL_CLASS_TAG
    from .swf_utils import SWF_SCRIPT_LIMITS_TAG
    from .swf_utils import SWF_SET_BACKGROUND_COLOR_TAG
    from .swf_utils import SWF_FILE_ATTRIBUTES_TAG
    from .swf_utils import SWF_METADATA_TAG
    from .swf_utils import SWF_SHOW_FRAME_TAG
    from .swf_utils import SWF_END_TAG
   

# Generated at 2022-06-18 16:08:32.869561
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCExceptionHandler
    from .abc import ABCException
    from .abc import ABCMultiname
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCScript
    from .abc import ABCMethodBody
    from .abc import ABCOpcode
    from .abc import ABCConstantPool
    from .abc import ABCConstantPoolString
    from .abc import ABCConstantPoolInt
    from .abc import ABCConstantPoolUInt
    from .abc import ABCConstantPoolDouble
    from .abc import ABCConstantPoolNamespace
    from .abc import ABCConstantPoolNamespaceSet
    from .abc import ABCConstantPoolMultiname