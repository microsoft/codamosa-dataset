

# Generated at 2022-06-18 16:01:49.566781
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter

# Generated at 2022-06-18 16:01:56.913618
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))

# Generated at 2022-06-18 16:02:03.565203
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-18 16:02:06.806371
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .test_swf import TEST_SWF_FILE
    with open(TEST_SWF_FILE, 'rb') as f:
        swf = SWF(f)
        interpreter = SWFInterpreter(swf)
        interpreter.extract_class('_level0')

# Generated at 2022-06-18 16:02:15.805622
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:02:26.871326
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.version == 9
    assert swf.file_length == 899
    assert swf.frame_size == (550, 400)
    assert swf.frame_rate == 30
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:02:33.651873
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.version == 9
    assert swf.file_length == 568
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:02:40.327196
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:02:44.120579
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(TEST_DIR, 'test.swf'), 'rb'))
    swf.extract_class('TestClass')


# Generated at 2022-06-18 16:02:52.471949
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter()
    assert swf.constant_strings == []
    assert swf.constant_namespaces == []
    assert swf.constant_namespace_sets == []
    assert swf.constant_multinames == []
    assert swf.constant_ints == []
    assert swf.constant_uints == []
    assert swf.constant_doubles == []
    assert swf.constant_decimals == []
    assert swf.constant_floats == []
    assert swf.constant_methods == []
    assert swf.constant_method_bodies == []
    assert swf.constant_classes == []
    assert swf.constant_scripts == []
    assert swf.constant_method_traits == []
   

# Generated at 2022-06-18 16:04:01.209439
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameKind
    from .abc import ABCNamespace
    from .abc import ABCNamespaceKind
    from .abc import ABCMethodBody
    from .abc import ABCOpcode
    from .abc import ABCExceptionKind
    from .abc import ABCTrait
    from .abc import ABCTraitKind
    from .abc import ABCTraitAttr
    from .abc import ABCConstantKind

# Generated at 2022-06-18 16:04:08.577993
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter()
    swf.extract_class('flash.display.Sprite')
    swf.extract_class('flash.display.MovieClip')
    swf.extract_class('flash.display.Stage')
    swf.extract_class('flash.display.Loader')
    swf.extract_class('flash.net.URLRequest')
    swf.extract_class('flash.net.URLVariables')
    swf.extract_class('flash.net.URLLoader')
    swf.extract_class('flash.net.URLLoaderDataFormat')
    swf.extract_class('flash.events.Event')
    swf.extract_class('flash.events.IOErrorEvent')

# Generated at 2022-06-18 16:04:11.976471
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.extract_class('test') == {
        'test': {
            'test': 'test',
            'test2': 'test2',
            'test3': 'test3',
        },
    }


# Generated at 2022-06-18 16:04:23.049202
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameLT
    from .abc import ABCMultinameN
    from .abc import ABCMultinameNT
    from .abc import ABCMultinameT
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceType
    from .abc import ABCQName
    from .abc import ABCQNameA
    from .abc import ABCRTQName
    from .abc import ABCRTQNameA

# Generated at 2022-06-18 16:04:33.605654
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    avm_class = swf.extract_class('TestClass')
    assert avm_class.name == 'TestClass'
    assert avm_class.super_name == 'Object'
    assert avm_class.static_properties['test_static_property'] == 'test_static_property_value'
    assert avm_class.static_properties['test_static_property2'] == 'test_static_property2_value'
    assert avm_class.static_properties['test_static_property3'] == 'test_static_property3_value'

# Generated at 2022-06-18 16:04:41.970548
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF


# Generated at 2022-06-18 16:04:53.987096
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerNotImplementedError
    from .swfdecompiler import SWFDecompilerNotSWFError
    from .swfdecompiler import SWFDecompilerParseError
    from .swfdecompiler import SWFDecompilerUnsupportedError
    from .swfdecompiler import SWFDecompilerVersionError
    from .swfdecompiler import SWFDecompilerWarning
    from .swfdecompiler import SWFDecompilerZlibError
    from .swfdecompiler import SWFDecompilerZlibNotSupportedError

    import os
   

# Generated at 2022-06-18 16:05:05.096662
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.extract_class('Main') is not None
    assert swf.extract_class('Main').static_properties['test'] == 'test'
    assert swf.extract_class('Main').static_properties['test2'] == 'test2'
    assert swf.extract_class('Main').static_properties['test3'] == 'test3'
    assert swf.extract_class('Main').static_properties['test4'] == 'test4'
    assert swf.extract_class('Main').static_properties['test5'] == 'test5'

# Generated at 2022-06-18 16:05:11.154408
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import _swf_data
    from . import _swf_tags
    from . import _swf_abc


# Generated at 2022-06-18 16:05:21.947349
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.version == 10
    assert swf.file_length == 809
    assert swf.frame_size == (0, 0, 800, 600)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1
    assert swf.file_attributes == {'UseNetwork': False}

# Generated at 2022-06-18 16:07:28.444573
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:07:36.083716
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:07:47.420909
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:07:54.973606
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_utils import parse_swf
    from .swf_tags import TagDefineBinaryData
    from .swf_tags import TagDoABC
    from .swf_tags import TagDoABCDefine
    from .swf_tags import TagDoInitAction
    from .swf_tags import TagFileAttributes
    from .swf_tags import TagMetadata
    from .swf_tags import TagSetBackgroundColor
    from .swf_tags import TagShowFrame
    from .swf_tags import TagSymbolClass
    from .swf_tags import TagUnknown
    from .swf_tags import TagEnd
    from .swf_tags import TagShowFrame
    from .swf_tags import TagDefineShape
    from .swf_tags import TagPlaceObject2
    from .swf_tags import TagRemove

# Generated at 2022-06-18 16:08:06.045377
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler

# Generated at 2022-06-18 16:08:15.237721
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.version == 13
    assert swf.file_length == 514
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 12.0
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:08:24.548155
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.extract_class('Test') == {
        'static_properties': {
            'test': 'test',
            'test2': 'test2',
            'test3': 'test3',
            'test4': 'test4',
            'test5': 'test5',
        },
        'method_names': set(['test']),
        'method_pyfunctions': {
            'test': lambda args: 'test',
        },
    }

# Generated at 2022-06-18 16:08:31.851465
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .test_utils import assertRegexpMatches
    from .test_utils import assertNotRegexpMatches
    from .test_utils import assertRaisesRegexp
    from .test_utils import assertRaises
    from .test_utils import assertEqual
    from .test_utils import assertNotEqual
    from .test_utils import assertTrue
    from .test_utils import assertFalse
    from .test_utils import assertIs
    from .test_utils import assertIsNot
    from .test_utils import assertIsNone
    from .test_utils import assertIsNotNone
    from .test_utils import assertIn
    from .test_utils import assertNotIn
    from .test_utils import assertIsInstance
    from .test_utils import assertNotIsInstance
    from .test_utils import assertGreater

# Generated at 2022-06-18 16:08:40.815229
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameKind
    from .abc import ABCMultinameKindTypeName
    from .abc import ABCMultinameKindQName
    from .abc import ABCMultinameKindQNameA
    from .abc import ABCMultinameKindRTQName
    from .abc import ABCMultinameKindRTQNameA
    from .abc import ABCMultinameKindRTQNameL
    from .abc import ABCMultinameKindRTQNameLA
    from .abc import ABCMultinameKindMultiname
   

# Generated at 2022-06-18 16:08:46.334667
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__),
                                           'flash_player_version.swf'), 'rb'))
    swf.extract_class('flash.system.Capabilities')
    swf.extract_class('flash.system.Capabilities').static_properties['version']
