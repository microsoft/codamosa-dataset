

# Generated at 2022-06-18 16:01:45.848042
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFMethod
    from .swfdecompiler import SWFClass
    from .swfdecompiler import SWFConstantPool
    from .swfdecompiler import SWFConstantPoolItem
    from .swfdecompiler import SWFConstantPoolItemString
    from .swfdecompiler import SWFConstantPoolItemFloat
    from .swfdecompiler import SWFConstantPoolItemNamespace
    from .swfdecompiler import SWFConstantPoolItemNamespaceSet
    from .swfdecompiler import SWFConstantPoolItemMultiname
    from .swfdecompiler import SWFConstantPoolItemMultiname

# Generated at 2022-06-18 16:01:50.382654
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(0, 'TestClass')
    avm_class.register_methods({
        'foo': 1,
        'bar': 2,
    })
    assert avm_class.method_names == {
        'foo': 1,
        'bar': 2,
    }
    assert avm_class.method_idxs == {
        1: 'foo',
        2: 'bar',
    }


# Generated at 2022-06-18 16:01:57.784702
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))

# Generated at 2022-06-18 16:02:01.159264
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(0, 'Test')
    avm_class.register_methods({'foo': 1, 'bar': 2})
    assert avm_class.method_names == {'foo': 1, 'bar': 2}
    assert avm_class.method_idxs == {1: 'foo', 2: 'bar'}



# Generated at 2022-06-18 16:02:09.038223
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:02:16.820327
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.version == 9
    assert swf.file_length == 599
    assert swf.frame_size == (550, 400)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:02:27.179136
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(0, 'TestClass')
    assert avm_class.method_names == {}
    assert avm_class.method_idxs == {}
    avm_class.register_methods({'foo': 1, 'bar': 2})
    assert avm_class.method_names == {'foo': 1, 'bar': 2}
    assert avm_class.method_idxs == {1: 'foo', 2: 'bar'}
    avm_class.register_methods({'bar': 3, 'baz': 4})
    assert avm_class.method_names == {'foo': 1, 'bar': 3, 'baz': 4}
    assert avm_class.method_idxs == {1: 'foo', 3: 'bar', 4: 'baz'}
#

# Generated at 2022-06-18 16:02:37.395316
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfextract import extract_swf
    from .swfextract import extract_swf_data
    from .swfextract import extract_swf_url
    from .swfextract import extract_swf_urls
    from .swfextract import extract_swf_xml
    from .swfextract import extract_swf_xmls
    from .swfextract import extract_swfs
    from .swfextract import extract_swfs_data
    from .swfextract import extract_swfs_url
    from .swfextract import extract_swfs_urls
    from .swfextract import extract_swfs_xml
    from .swfextract import extract

# Generated at 2022-06-18 16:02:47.519516
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_utils import read_swf_header
    from .swf_tags import read_swf_tag
    from .swf_tags import TAG_DO_ABC
    from .swf_tags import TAG_SYMBOL_CLASS
    from .swf_tags import TAG_END
    from .swf_tags import TAG_FILE_ATTRIBUTES
    from .swf_tags import TAG_SET_BACKGROUND_COLOR
    from .swf_tags import TAG_DO_ACTION
    from .swf_tags import TAG_DO_INIT_ACTION
    from .swf_tags import TAG_EXPORT_ASSETS
    from .swf_tags import TAG_DEFINE_SCENE_AND_FRAME_LABEL_DATA
    from .swf_tags import TAG_DEFINE_BINARY_DATA


# Generated at 2022-06-18 16:02:55.014698
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-18 16:04:47.337931
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_utils import read_swf_header, read_swf_tags
    from .swf_tags import TagDefineBinaryData
    from .swf_binary_data import SWFBinaryData
    from .swf_abc import ABCFile
    from .swf_abc_tags import TagDoABC, TagDoABCDefine
    from .swf_abc_method import ABCMethod
    from .swf_abc_class import ABCClass
    from .swf_abc_instance import ABCInstance
    from .swf_abc_script import ABCScript
    from .swf_abc_trait import ABCTrait
    from .swf_abc_multiname import ABCMultiname
    from .swf_abc_constant_pool import ABCConstantPool

# Generated at 2022-06-18 16:05:01.200631
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodBody
    from .abc import ABCMethodInfo
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceType
    from .abc import ABCNamespaceTypeName
    from .abc import ABCNamespaceTypeNameA

# Generated at 2022-06-18 16:05:08.887783
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))

# Generated at 2022-06-18 16:05:19.995090
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.extract_class('TestClass') is not None
    assert swf.extract_class('TestClass').static_properties['test_prop'] == 'test_value'
    assert swf.extract_class('TestClass').static_properties['test_prop2'] == 'test_value2'
    assert swf.extract_class('TestClass').static_properties['test_prop3'] == 'test_value3'
    assert swf.extract_class('TestClass').static_properties['test_prop4'] == 'test_value4'
    assert swf.extract_class('TestClass').static_properties['test_prop5']

# Generated at 2022-06-18 16:05:23.271933
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')


# Generated at 2022-06-18 16:05:32.035072
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:05:38.970668
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-18 16:05:48.674958
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .test_swf import get_test_swf
    swf = get_test_swf()
    interpreter = SWFInterpreter(swf)
    interpreter.extract_class('TestClass')
    assert 'TestClass' in interpreter.classes
    assert 'TestClass' in interpreter.classes['TestClass'].variables
    assert 'TestClass' in interpreter.classes['TestClass'].static_properties
    assert 'TestClass' in interpreter.classes['TestClass'].method_names
    assert 'TestClass' in interpreter.classes['TestClass'].method_pyfunctions
    assert 'TestClass' in interpreter.classes['TestClass'].method_pyfunctions
    assert 'TestClass' in interpreter.classes['TestClass'].method_pyfunctions
    assert 'TestClass' in interpreter.classes['TestClass'].method_

# Generated at 2022-06-18 16:05:56.275975
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-18 16:05:58.433437
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')


# Generated at 2022-06-18 16:07:54.574421
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABCTag
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCString
    from .abc import ABCInt
    from .abc import ABCUInt
    from .abc import ABCDouble
    from .abc import ABCNamespaceKind
    from .abc import ABCMethodKind
    from .abc import ABCMethodFlags
    from .abc import ABCException
    from .abc import ABCExceptionKind
    from .abc import ABCOpcode
    from .abc import ABCExceptionHandler
    from .abc import ABCExceptionHandlerKind


# Generated at 2022-06-18 16:08:05.658052
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerWarning
    from .swfdecompiler import SWFDecompilerInfo
    from .swfdecompiler import SWFDecompilerDebug
    from .swfdecompiler import SWFDecompilerVerbose
    from .swfdecompiler import SWFDecompilerTrace
    from .swfdecompiler import SWFDecompilerTrace2
    from .swfdecompiler import SWFDecompilerTrace3
    from .swfdecompiler import SWFDecompilerTrace4
    from .swfdecompiler import SWFDecompilerTrace5
    from .swfdecompiler import SWFDecomp

# Generated at 2022-06-18 16:08:14.929685
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:08:26.034679
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_tags import TagDefineBinaryData
    from .swf_tags import TagDoABC
    from .swf_tags import TagDoABCDefine
    from .swf_tags import TagDoAction
    from .swf_tags import TagDoInitAction
    from .swf_tags import TagFileAttributes
    from .swf_tags import TagMetadata
    from .swf_tags import TagPlaceObject2
    from .swf_tags import TagShowFrame
    from .swf_tags import TagSymbolClass
    from .swf_tags import TagUnknown
    from .swf_tags import TagSetBackgroundColor
    from .swf_tags import TagDefineSceneAndFrameLabelData

# Generated at 2022-06-18 16:08:36.165868
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .swf_interpreter import SWFInterpreter
    from .swf_parser import SWFParser
    from .swf_tag_reader import SWFTagReader
    from .swf_tag_types import TagDefineBinaryData
    from .swf_tag_types import TagDoABC
    from .swf_tag_types import TagDoABCDefine
    from .swf_tag_types import TagDoABCDeprecated
    from .swf_tag_types import TagDoInitAction
    from .swf_tag_types import TagFileAttributes
    from .swf_tag_types import TagMetadata
    from .swf_tag_types import TagShowFrame
    from .swf_tag_types import TagSymbolClass
    from .swf_tag_types import TagUnknown

# Generated at 2022-06-18 16:08:46.096717
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')
    assert swf.classes['Test'].static_properties['test'] == 'test'
    assert swf.classes['Test'].static_properties['test2'] == 'test2'
    assert swf.classes['Test'].static_properties['test3'] == 'test3'
    assert swf.classes['Test'].static_properties['test4'] == 'test4'
    assert swf.classes['Test'].static_properties['test5'] == 'test5'
    assert swf.classes['Test'].static_properties['test6'] == 'test6'

# Generated at 2022-06-18 16:08:52.563814
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.version == 9
    assert swf.file_length == 576
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24.0
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:09:01.340956
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.constant_strings[0] == 'onMetaData'
    assert swf.constant_strings[1] == 'duration'
    assert swf.constant_strings[2] == 'width'
    assert swf.constant_strings[3] == 'height'
    assert swf.constant_strings[4] == 'videodatarate'
    assert swf.constant_strings[5] == 'framerate'
    assert swf.constant_strings[6] == 'videocodecid'
    assert swf.constant_strings[7] == 'audiodatarate'
    assert swf.constant_

# Generated at 2022-06-18 16:09:10.720232
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFInterpreter
    from .swfdecompiler import SWFMethod
    from .swfdecompiler import SWFClass
    from .swfdecompiler import SWFConstantPool
    from .swfdecompiler import SWFMultiname
    from .swfdecompiler import SWFDoABC
    from .swfdecompiler import SWFDoABCTag
    from .swfdecompiler import SWFDefineBinaryDataTag
    from .swfdecompiler import SWFDefineBitsJPEG2Tag
    from .swfdecompiler import SWFDefineBitsJPEG3Tag
    from .swfdecompiler import SWFDefineBitsLossless

# Generated at 2022-06-18 16:09:17.708446
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swftags import TagDefineFunction
    from .swftags import TagDoAction
    from .swftags import TagDoInitAction
    from .swftags import TagSymbolClass
    from .swftags import TagFileAttributes
    from .swftags import TagSetBackgroundColor
    from .swftags import TagShowFrame
    from .swftags import TagEnd
    from .swftags import TagDefineBinaryData
    from .swftags import TagDefineScalingGrid
    from .swftags import TagDefineSceneAndFrameLabelData
    from .swftags import TagDefineFontName
    from .swftags import TagDefineFontAlignZones
    from .swftags import TagDefineFont3
    from .swftags import TagDefineFont4
   