

# Generated at 2022-06-18 16:01:40.874324
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerFileNotFoundError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerNotImplementedError
    from .swfdecompiler import SWFDecompilerNotSWFError
    from .swfdecompiler import SWFDecompilerUnsupportedSWFError
    from .swfdecompiler import SWFDecompilerUnsupportedTagError
    from .swfdecompiler import SWFDecompilerUnsupportedTagError
    from .swfdecompiler import SWFDecompilerUnsupportedTagError
    from .swfdecompiler import SWFDecompilerUnsupported

# Generated at 2022-06-18 16:01:45.075216
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class _AVMClass(object):
        name = '_AVMClass'
    scope = _ScopeDict(_AVMClass())
    scope['a'] = 'b'
    assert repr(scope) == '_AVMClass__Scope({\'a\': \'b\'})'



# Generated at 2022-06-18 16:01:52.601149
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerValueError
    from .swfdecompiler import SWFDecompilerTypeError
    from .swfdecompiler import SWFDecompilerIndexError
    from .swfdecompiler import SWFDecompilerKeyError
    from .swfdecompiler import SWFDecompilerNotImplementedError
    from .swfdecompiler import SWFDecompilerAttributeError
    from .swfdecompiler import SWFDecompilerRuntimeError
    from .swfdecompiler import SWFDecompilerAssertionError
    from .swfdecompiler import SW

# Generated at 2022-06-18 16:01:59.628183
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:02:05.909079
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_parse import parse_swf
    from .swf_parse import SWF
    from .swf_parse import SWF_HEADER
    from .swf_parse import SWF_TAG_TYPE_DO_ABC
    from .swf_parse import SWF_TAG_TYPE_DO_ABC_DEFINE
    from .swf_parse import SWF_TAG_TYPE_SYMBOL_CLASS
    from .swf_parse import SWF_TAG_TYPE_FILE_ATTRIBUTES
    from .swf_parse import SWF_TAG_TYPE_SCRIPT_LIMITS
    from .swf_parse import SWF_TAG_TYPE_SET_BACKGROUND_COLOR
    from .swf_parse import SWF_TAG_TYPE_FRAME_LABEL

# Generated at 2022-06-18 16:02:15.739324
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError

    def test_decompiler(file_name):
        with open(file_name, 'rb') as f:
            swf = f.read()
        try:
            decompiler = SWFDecompiler(swf)
        except SWFDecompilerError:
            return
        for tag in decompiler.tags:
            if tag.type == 82:
                return SWFInterpreter(tag.data)
        raise SWFDecompilerError('No DoABC tag found')

    # Test for SWF file with no DoABC tag
    with open('tests/swfs/no_doabc_tag.swf', 'rb') as f:
        swf = f.read()

# Generated at 2022-06-18 16:02:26.832706
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:02:33.677956
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-18 16:02:44.038053
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler

# Generated at 2022-06-18 16:02:52.407004
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:04:20.747450
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('test')


# Generated at 2022-06-18 16:04:32.236637
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io
    import unittest

    class TestSWFInterpreter_extract_function(unittest.TestCase):
        def setUp(self):
            self.interpreter = SWFInterpreter()

        def test_extract_function(self):
            # Test that the function can be extracted
            # from a simple SWF file
            with io.open('tests/test.swf', 'rb') as f:
                self.interpreter.read_swf(f)
            self.interpreter.extract_function(
                self.interpreter.classes['Test'], 'test')

    suite = unittest.TestSuite()
    suite.addTest(TestSWFInterpreter_extract_function('test_extract_function'))

# Generated at 2022-06-18 16:04:40.715783
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABC
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCMultinameRTQName
    from .abc import ABCMultinameRTQNameA
    from .abc import ABCMultin

# Generated at 2022-06-18 16:04:47.953463
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodBody
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameLT
    from .abc import ABCMultinameN
    from .abc import ABCMultinameNT
    from .abc import ABCMultinameT
    from .abc import ABCMultinameTA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceType
    from .abc import ABCNamespaceTypeName
    from .abc import ABCNamespaceTypePackage

# Generated at 2022-06-18 16:04:52.208182
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .test_utils import assertRegexpMatches
    class _AVMClass(object):
        name = '_AVMClass'
    scope = _ScopeDict(_AVMClass())
    scope['a'] = 1
    scope['b'] = 2
    assertRegexpMatches(repr(scope), r'_AVMClass__Scope\(\{.*\}\)\Z')



# Generated at 2022-06-18 16:05:04.281133
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfinterpreter import SWFInterpreter
    from .swfobject import SWFObject

    # Test case 1

# Generated at 2022-06-18 16:05:10.564832
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    swf.extract_function('_level0', '_init')()
    swf.extract_function('_level0', '_init')()
    swf.extract_function('_level0', '_init')()
    swf.extract_function('_level0', '_init')()
    swf.extract_function('_level0', '_init')()
    swf.extract_function('_level0', '_init')()
    swf.extract_function('_level0', '_init')()
    swf.extract_function('_level0', '_init')()
    swf.extract_function('_level0', '_init')()
    swf.extract

# Generated at 2022-06-18 16:05:20.774053
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler

# Generated at 2022-06-18 16:05:29.826777
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.extract_class('TestClass') is not None
    assert swf.extract_class('TestClass2') is not None
    assert swf.extract_class('TestClass3') is not None
    assert swf.extract_class('TestClass4') is not None
    assert swf.extract_class('TestClass5') is not None
    assert swf.extract_class('TestClass6') is not None
    assert swf.extract_class('TestClass7') is not None
    assert swf.extract_class('TestClass8') is not None
    assert swf.extract_class('TestClass9')

# Generated at 2022-06-18 16:05:36.469581
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:07:46.422679
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb').read())
    assert swf.version == 9
    assert swf.file_length == 576
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:07:54.389987
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import io
    import struct
    from collections import namedtuple

    class _AVMClass(object):
        def __init__(self, name):
            self.name = name
            self.method_names = set()
            self.static_properties = {}
            self.method_pyfunctions = {}
            self.variables = {}

        def make_object(self):
            return _AVMClass_Object(self)

    class _AVMClass_Object(object):
        def __init__(self, avm_class):
            self.avm_class = avm_class

    class _Multiname(object):
        def __init__(self, name):
            self.name = name

    class _ScopeDict(dict):
        def __init__(self, avm_class):
            self.avm

# Generated at 2022-06-18 16:08:05.351089
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf import SWF
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdecompiler import _Undefined

    swf = SWF(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    decompiler = SWFDecompiler(swf)
    interpreter = SWFInterpreter(decompiler)

    def test_func(args):
        assert len(args) == 1
        assert isinstance(args[0], int)
        return args[0] + 1

    interpreter.extract_function(decompiler.avm_classes['Test'], 'test', test_func)

# Generated at 2022-06-18 16:08:08.622712
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.extract_class('test') is not None

# Generated at 2022-06-18 16:08:14.373698
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:08:19.953451
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData

# Generated at 2022-06-18 16:08:29.101084
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:08:39.570979
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')
    assert swf.classes['Test'].variables['a'] == 1
    assert swf.classes['Test'].variables['b'] == 2
    assert swf.classes['Test'].variables['c'] == 3
    assert swf.classes['Test'].variables['d'] == 4
    assert swf.classes['Test'].variables['e'] == 5
    assert swf.classes['Test'].variables['f'] == 6
    assert swf.classes['Test'].variables['g'] == 7
    assert swf.classes['Test'].variables['h'] == 8
    assert sw

# Generated at 2022-06-18 16:08:49.168231
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')
    assert swf.classes['Test'].variables['test'] == 'test'
    assert swf.classes['Test'].variables['test2'] == 'test2'
    assert swf.classes['Test'].variables['test3'] == 'test3'
    assert swf.classes['Test'].variables['test4'] == 'test4'
    assert swf.classes['Test'].variables['test5'] == 'test5'
    assert swf.classes['Test'].variables['test6'] == 'test6'

# Generated at 2022-06-18 16:08:59.290678
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodBody
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameLT
    from .abc import ABCMultinameN
    from .abc import ABCMultinameNT
    from .abc import ABCMultinameT
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCScript
    from .abc import ABCMethodInfo
    from .abc import ABCConstantPool