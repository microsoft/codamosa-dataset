

# Generated at 2022-06-18 16:01:48.464129
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Test constructor
    interpreter = SWFInterpreter()
    assert isinstance(interpreter, SWFInterpreter)
    assert isinstance(interpreter.constant_strings, list)
    assert isinstance(interpreter.multinames, list)
    assert isinstance(interpreter.methods, list)
    assert isinstance(interpreter.classes, list)
    assert isinstance(interpreter.scripts, list)
    assert isinstance(interpreter.method_pyfunctions, dict)
    assert isinstance(interpreter.class_pyfunctions, dict)
    assert isinstance(interpreter.script_pyfunctions, dict)


# Generated at 2022-06-18 16:01:55.820256
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swftags import TagDefineFunction2
    from .swfdata import SWFData
    from .swfrecords import SWFRecordHeader
    from .swfrecords import SWFRecordDoAction
    from .swfrecords import SWFRecordDoInitAction
    from .swfrecords import SWFRecordPlaceObject2
    from .swfrecords import SWFRecordPlaceObject3
    from .swfrecords import SWFRecordRemoveObject2
    from .swfrecords import SWFRecordShowFrame
    from .swfrecords import SWFRecordEnd
    from .swfrecords import SWFRecordSetBackgroundColor
    from .swfrecords import SWFRecordFrameLabel
    from .swfrecords import SWFRecordExportAssets
    from .swfrecords import SW

# Generated at 2022-06-18 16:02:02.600828
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter()
    assert swf.constant_strings == []
    assert swf.constant_namespaces == []
    assert swf.constant_namespace_sets == []
    assert swf.constant_multinames == []
    assert swf.constant_ints == []
    assert swf.constant_uints == []
    assert swf.constant_doubles == []
    assert swf.constant_decimals == []
    assert swf.constant_ints == []
    assert swf.constant_uints == []
    assert swf.constant_doubles == []
    assert swf.constant_decimals == []
    assert swf.constant_ints == []
    assert swf.constant_uints == []
    assert sw

# Generated at 2022-06-18 16:02:09.731468
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swftags import TagDoABC

    swf = SWFData()

# Generated at 2022-06-18 16:02:17.021086
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.version == 9
    assert swf.file_length == 709
    assert swf.frame_size == Rect(0, 0, 800, 600)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1
    assert swf.tags == [
        Tag(0, Tag.End, None),
        Tag(0, Tag.ShowFrame, None),
        Tag(0, Tag.End, None),
    ]

# Generated at 2022-06-18 16:02:27.434054
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:02:37.394916
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__),
                                           'test.swf'), 'rb'))

# Generated at 2022-06-18 16:02:47.466805
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfobject import SWFObject
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompiler

# Generated at 2022-06-18 16:02:50.559880
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('TestClass')


# Generated at 2022-06-18 16:03:01.491511
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:04:00.319956
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-18 16:04:07.737039
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:04:16.879684
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodInfo
    from .abc import ABCExceptionInfo
    from .abc import ABCException
    from .abc import ABCExceptionKind
    from .abc import ABCMultiname
    from .abc import ABCMultinameKind
    from .abc import ABCNamespace
    from .abc import ABCNamespaceKind
    from .abc import ABCInstanceInfo
    from .abc import ABCClassInfo
    from .abc import ABCMetaData
    from .abc import ABCMethodBody
    from .abc import ABCOpcode
    from .abc import ABCOpcodeArgument
    from .abc import ABCOpcodeArgumentKind
    from .abc import ABCOpcodeArgumentType
    from .abc import ABCOpcodeArgumentValue
    from .abc import ABCOp

# Generated at 2022-06-18 16:04:25.357382
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:04:35.881082
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .swf_utils import SWF
    from .swf_utils import SWFInterpreter
    from .swf_utils import SWFMethod
    from .swf_utils import SWFClass
    from .swf_utils import SWFClassMethod
    from .swf_utils import SWFClassVariable
    from .swf_utils import SWFConstantPool
    from .swf_utils import SWFConstantPoolItem
    from .swf_utils import SWFConstantPoolItemString
    from .swf_utils import SWFConstantPoolItemFloat
    from .swf_utils import SWFConstantPoolItemNamespace
    from .swf_utils import SWFConstantPoolItemNamespaceSet
    from .swf_utils import SWFConstantPoolItemMultiname
    from .swf_utils import SWF

# Generated at 2022-06-18 16:04:43.975212
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABCTag
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCMethodBody
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCConstantPool
    from .abc import ABCMethodInfo
    from .abc import ABCMetadataInfo
    from .abc import ABCInstanceInfo
    from .abc import ABCClassInfo
    from .abc import ABCScriptInfo
    from .abc import ABCExceptionInfo

# Generated at 2022-06-18 16:04:46.753952
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Main')


# Generated at 2022-06-18 16:04:49.993665
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()
    interpreter.extract_function(None, None, None, None)

# Generated at 2022-06-18 16:05:02.063553
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__),
                                           'test.swf'), 'rb'))
    swf.extract_class('_level0')
    swf.extract_class('_level0.test')
    swf.extract_class('_level0.test.Test')
    swf.extract_class('_level0.test.Test2')
    swf.extract_class('_level0.test.Test3')
    swf.extract_class('_level0.test.Test4')
    swf.extract_class('_level0.test.Test5')
    swf.extract_class('_level0.test.Test6')

# Generated at 2022-06-18 16:05:04.571487
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Test for method patch_function(...) of class SWFInterpreter
    # TODO: implement this!
    pass


# Generated at 2022-06-18 16:06:51.213853
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerValueError
    from .swfdecompiler import SWFDecompilerTypeError
    from .swfdecompiler import SWFDecompilerIndexError
    from .swfdecompiler import SWFDecompilerKeyError
    from .swfdecompiler import SWFDecompilerNotImplementedError
    from .swfdecompiler import SWFDecompilerAttributeError
    from .swfdecompiler import SWFDecompilerRuntimeError
    from .swfdecompiler import SWFDecompilerNameError
    from .swfdecompiler import SWFDec

# Generated at 2022-06-18 16:06:59.145560
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.version == 9
    assert swf.file_length == 584
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1
    assert len(swf.tags) == 9
    assert swf.tags[0].tag_type == 69
    assert swf.tags[0].tag_length == 0
    assert swf.tags[1].tag_type == 9
    assert swf.tags[1].tag_length == 5
    assert swf.tags[2].tag_type == 10
    assert swf.tags[2].tag_length == 0

# Generated at 2022-06-18 16:07:03.897556
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()
    interpreter.patch_function(
        'String', 'String',
        [('String', 'str')],
        'return str;')
    assert interpreter.extract_function(StringClass, 'String')(['foo']) == 'foo'


# Generated at 2022-06-18 16:07:12.187382
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf import SWF
    from .tags import DoABCTag
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCMetaData

# Generated at 2022-06-18 16:07:20.829579
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import io
    import struct
    import zlib

    from .swf_tags import TagDefineBinaryData

    def _read_byte(f):
        return struct.unpack('B', f.read(1))[0]

    def _read_u16(f):
        return struct.unpack('<H', f.read(2))[0]

    def _read_u32(f):
        return struct.unpack('<I', f.read(4))[0]

    def _read_s24(f):
        return struct.unpack('<i', b'\x00' + f.read(3))[0]

    def _read_u30(f):
        res = 0
        for i in range(5):
            b = _read_byte(f)

# Generated at 2022-06-18 16:07:29.284448
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCOpcode
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameLT
    from .abc import ABCMultinameN
    from .abc import ABCMultinameNT
    from .abc import ABCMultinameT
    from .abc import ABCMultinameTA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameT
    from .abc import ABCMultinameTypeNameTA
    from .abc import ABC

# Generated at 2022-06-18 16:07:37.237269
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile


# Generated at 2022-06-18 16:07:48.348734
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData

# Generated at 2022-06-18 16:07:55.590223
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')
    assert swf.classes['Test'].variables['test'] == 'test'
    assert swf.classes['Test'].variables['test2'] == 'test2'
    assert swf.classes['Test'].variables['test3'] == 'test3'
    assert swf.classes['Test'].variables['test4'] == 'test4'
    assert swf.classes['Test'].variables['test5'] == 'test5'
    assert swf.classes['Test'].variables['test6'] == 'test6'

# Generated at 2022-06-18 16:08:06.574193
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')
    assert swf.classes['Test'].static_properties['test_var'] == 'test_value'
    assert swf.classes['Test'].static_properties['test_var2'] == 'test_value2'
    assert swf.classes['Test'].static_properties['test_var3'] == 'test_value3'
    assert swf.classes['Test'].static_properties['test_var4'] == 'test_value4'
    assert swf.classes['Test'].static_properties['test_var5'] == 'test_value5'
    assert swf.classes['Test'].static_