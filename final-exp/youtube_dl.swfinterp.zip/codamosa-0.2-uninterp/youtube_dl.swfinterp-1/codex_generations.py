

# Generated at 2022-06-18 16:02:15.326573
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.version == 9
    assert swf.file_length == 545
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:02:26.713435
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf_extract import SWFInterpreter
    from .swf_extract import _AVMClass
    from .swf_extract import _AVMClass_Object
    from .swf_extract import _ScopeDict
    from .swf_extract import _Undefined
    from .swf_extract import _Multiname
    from .swf_extract import _builtin_classes
    from .swf_extract import undefined
    from .swf_extract import StringClass
    from .swf_extract import ArrayClass


# Generated at 2022-06-18 16:02:33.534582
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .tags import DoABCTag
    from .abc import ABCMethodBody
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceSetItem
    from .abc import ABCString
    from .abc import ABCInt

# Generated at 2022-06-18 16:02:43.879127
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:02:52.273222
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf_utils import read_swf_header, read_swf_tags
    from .swf_utils import read_swf_tag_doabc
    from .swf_utils import read_swf_tag_symbolclass
    from .swf_utils import read_swf_tag_doaction
    from .swf_utils import read_swf_tag_doinitaction
    from .swf_utils import read_swf_tag_fileattributes
    from .swf_utils import read_swf_tag_showframe
    from .swf_utils import read_swf_tag_end
    from .swf_utils import read_swf_tag_setbackgroundcolor
    from .swf_utils import read_swf_tag_definebits

# Generated at 2022-06-18 16:03:02.592865
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter()
    swf.patch_function('trace', lambda x: print(x))
    swf.patch_function('getTimer', lambda: 0)
    swf.patch_function('setTimeout', lambda x, y: None)
    swf.patch_function('setInterval', lambda x, y: None)
    swf.patch_function('clearInterval', lambda x: None)
    swf.patch_function('clearTimeout', lambda x: None)
    swf.patch_function('escape', lambda x: x)
    swf.patch_function('unescape', lambda x: x)
    swf.patch_function('encodeURIComponent', lambda x: x)
    swf.patch_function('decodeURIComponent', lambda x: x)
    swf.patch

# Generated at 2022-06-18 16:03:11.678994
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .tags import DoABCTag
    from .abc import ABCMethodBody
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceSetL
    from .abc import ABCNamespaceSetLA
    from .abc import ABCString


# Generated at 2022-06-18 16:03:18.151928
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData


# Generated at 2022-06-18 16:03:24.976265
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:03:35.763358
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_function('Main', 'main')
    swf.extract_function('Main', 'main')
    swf.extract_function('Main', 'main')
    swf.extract_function('Main', 'main')
    swf.extract_function('Main', 'main')
    swf.extract_function('Main', 'main')
    swf.extract_function('Main', 'main')
    swf.extract_function('Main', 'main')
    swf.extract_function('Main', 'main')
    swf.extract_function('Main', 'main')
    swf.extract_

# Generated at 2022-06-18 16:04:41.383812
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodInfo
    from .abc import ABCMethodBodyInfo
    from .abc import ABCExceptionInfo
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameRTQName
    from .abc import ABCMultinameRTQNameA
    from .abc import ABCMultinameRTQNameL
    from .abc import ABCMultinameRTQNameLA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCInstanceInfo
    from .abc import ABC

# Generated at 2022-06-18 16:04:48.382174
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData

# Generated at 2022-06-18 16:05:01.321217
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:05:09.000489
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-18 16:05:20.184232
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('TestClass')
    swf.extract_class('TestClass2')
    swf.extract_class('TestClass3')
    swf.extract_class('TestClass4')
    swf.extract_class('TestClass5')
    swf.extract_class('TestClass6')
    swf.extract_class('TestClass7')
    swf.extract_class('TestClass8')
    swf.extract_class('TestClass9')
    swf.extract_class('TestClass10')
    swf.extract_class('TestClass11')

# Generated at 2022-06-18 16:05:29.355328
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler


# Generated at 2022-06-18 16:05:36.140426
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io
    import unittest

    from .swf_utils import read_swf_header

    class TestSWFInterpreter_extract_function(unittest.TestCase):
        def setUp(self):
            self.interpreter = SWFInterpreter()

# Generated at 2022-06-18 16:05:39.731090
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')

# Generated at 2022-06-18 16:05:43.854284
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.extract_class('_level0.test') is not None

# Generated at 2022-06-18 16:05:52.554899
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'testdata', 'test.swf'), 'rb'))
    swf.extract_class('TestClass')
    assert swf.classes['TestClass'].static_properties['test_static_property'] == 'test_static_property_value'
    assert swf.classes['TestClass'].static_properties['test_static_property_2'] == 'test_static_property_value_2'
    assert swf.classes['TestClass'].static_properties['test_static_property_3'] == 'test_static_property_value_3'
    assert swf.classes['TestClass'].static_properties['test_static_property_4'] == 'test_static_property_value_4'


# Generated at 2022-06-18 16:07:03.864734
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCString
    from .abc import ABCInt
    from .abc import ABCUInt
    from .abc import ABCDouble
    from .abc import ABCFloat
    from .abc import ABCNamespaceKind
    from .abc import ABCConstantKind
    from .abc import ABCMethodFlags


# Generated at 2022-06-18 16:07:06.971061
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    assert swf.extract_class('Main')


# Generated at 2022-06-18 16:07:14.032408
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-18 16:07:22.752816
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInter

# Generated at 2022-06-18 16:07:31.443926
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_utils import read_swf
    from .swf_tags import TagDoABC
    from .swf_abc import ABCFile
    from .swf_abc import ABCMethod
    from .swf_abc import ABCMethodBody
    from .swf_abc import ABCMultiname
    from .swf_abc import ABCMultinameL
    from .swf_abc import ABCMultinameLA
    from .swf_abc import ABCMultinameQName
    from .swf_abc import ABCMultinameQNameA
    from .swf_abc import ABCMultinameTypeName
    from .swf_abc import ABCNamespace
    from .swf_abc import ABCNamespaceSet
    from .swf_abc import ABCParam
    from .swf_abc import ABCParamName

# Generated at 2022-06-18 16:07:38.992613
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCInstanceInfo
    from .abc import ABCClassInfo
    from .abc import ABCMetaData
    from .abc import ABCScriptInfo
    from .abc import ABCMethodBody
    from .abc import ABCMethodInfo
    from .abc import ABCConstantPool

# Generated at 2022-06-18 16:07:43.439121
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('Test')


# Generated at 2022-06-18 16:07:52.921318
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfinterpreter import SWFInterpreter
    from .swfobject import SWFObject
    from .swfutils import swf_compress_data


# Generated at 2022-06-18 16:08:04.217479
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb').read()
    swf = SWFInterpreter(swf)

# Generated at 2022-06-18 16:08:11.112073
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceSetL
    from .abc import ABCNamespacePrivate
    from .abc import ABCNamespacePublic
   

# Generated at 2022-06-18 16:10:28.117839
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCConstantPool
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCMethodBody
    from .abc import ABCMethodInfo
    from .abc import ABCOpcode
    from .abc import ABCExceptionInfo
    from .abc import ABCExceptionKind
    from .abc import ABCExceptionTarget
    from .abc import ABCExceptionTargetKind
    from .abc import ABCExceptionTargetInfo
    from .abc import ABCExceptionTargetInfos
    from .abc import ABCExceptionTargetInfoKind
    from .abc import ABCExceptionTargetInfoKinds
    from .abc import ABCExceptionTargetInfosKind
   

# Generated at 2022-06-18 16:10:38.912232
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter()

# Generated at 2022-06-18 16:10:44.859783
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swf_utils import read_swf_header
    from .swf_tags import TagDefineBinaryData
    from .swf_tags import TagDoABC
    from .swf_tags import TagSymbolClass
    from .swf_tags import TagDoAction
    from .swf_tags import TagDoInitAction
    from .swf_tags import TagFileAttributes
    from .swf_tags import TagSetBackgroundColor
    from .swf_tags import TagShowFrame
    from .swf_tags import TagPlaceObject2
    from .swf_tags import TagPlaceObject3
    from .swf_tags import TagRemoveObject2
    from .swf_tags import TagRemoveObject
    from .swf_tags import TagEnd
    from .swf_tags import TagShowFrame