

# Generated at 2022-06-18 16:01:49.664547
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swf_parse import SWF
    from .swf_parse import SWFHeader
    from .swf_parse import SWFDoABC
    from .swf_parse import SWFDoAction
    from .swf_parse import SWFDoInitAction
    from .swf_parse import SWFDefineSprite
    from .swf_parse import SWFDefineBinaryData
    from .swf_parse import SWFDefineBitsLossless
    from .swf_parse import SWFDefineBitsLossless2
    from .swf_parse import SWFDefineBitsJPEG2
    from .swf_parse import SWFDefineBitsJPEG3
    from .swf_parse import SWFDefineBitsJPEG4
    from .swf_parse import SWFDefineButton


# Generated at 2022-06-18 16:01:57.065837
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:02:03.701674
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCConstantPool
    from .abc import ABCMultiname
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCOpcode
    from .abc import ABCExceptionHandler
    from .abc import ABCTraits
    from .abc import ABCTrait
    from .abc import ABCTraitMethod
    from .abc import ABCTraitSlot
    from .abc import ABCTraitClass
    from .abc import ABCTraitFunction
    from .abc import ABCTraitConst
    from .abc import ABCTrait

# Generated at 2022-06-18 16:02:10.578304
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:02:20.838482
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    import zlib


# Generated at 2022-06-18 16:02:30.412403
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfinterpreter import SWFInterpreter
    from .swfdata import SWFData
    from .swfextract import SWFExtract
    from .swfheader import SWFHeader
    from .swfobjects import SWFObject
    from .swfobjects import SWFObjectDefineSprite
    from .swfobjects import SWFObjectPlaceObject2
    from .swfobjects import SWFObjectShowFrame
    from .swfobjects import SWFObjectStartSound
    from .swfobjects import SWFObjectStopSound
    from .swfobjects import SWFObjectUnknown
    from .swfobjects import SWFObjectUnknownTag
    from .swfobjects import SWFObjectUnknownTagDefineBits

# Generated at 2022-06-18 16:02:39.479797
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethodInfo
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceKind
    from .abc import ABCConstantKind
    from .abc import ABCConstantPool
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionKind
    from .abc import ABCOpcode
    from .abc import ABCExceptionHandler
    from .abc import ABCTraitsInfo
    from .abc import ABCTraitKind
    from .abc import ABCTraitAttr
    from .abc import ABCTraitMethod

# Generated at 2022-06-18 16:02:49.561606
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:02:56.251870
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io
    from .swf_tags import TagDefineFunction2
    from .swf_types import ABCFile
    from .swf_types import ABCMethodInfo
    from .swf_types import ABCMethodBodyInfo
    from .swf_types import ABCExceptionInfo
    from .swf_types import ABCTraitInfo
    from .swf_types import ABCTraitMethod
    from .swf_types import ABCTraitSlot
    from .swf_types import ABCTraitClass
    from .swf_types import ABCTraitFunction
    from .swf_types import ABCTraitConst
    from .swf_types import ABCMultiname
    from .swf_types import ABCMultinameL
    from .swf_types import ABCMultinameLA
    from .swf_types import ABCMultinameQName

# Generated at 2022-06-18 16:03:05.771053
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_utils import read_swf_header
    from .swf_tags import TagDefineBinaryData
    from .swf_tags import TagDoABC
    from .swf_tags import TagDoABCDefine
    from .swf_tags import TagFileAttributes
    from .swf_tags import TagMetadata
    from .swf_tags import TagSetBackgroundColor
    from .swf_tags import TagShowFrame
    from .swf_tags import TagSymbolClass
    from .swf_tags import TagUnknown
    from .swf_tags import TagEnd
    from .swf_tags import TagShowFrame
    from .swf_tags import TagDefineBinaryData
    from .swf_tags import TagSymbolClass
    from .swf_tags import TagDoABC

# Generated at 2022-06-18 16:04:04.252420
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerParseError
    from .swfdecompiler import SWFDecompilerTypeError
    from .swfdecompiler import SWFDecompilerValueError

    # Test SWFDecompiler
    with open('test/test.swf', 'rb') as f:
        swf = SWFDecompiler(f)

    # Test SWFInterpreter
    interpreter = SWFInterpreter(swf)

# Generated at 2022-06-18 16:04:10.646207
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.version == 9
    assert swf.file_length == 827
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 24
    assert swf.frame_count == 1
    assert len(swf.tags) == 3
    assert swf.tags[0].type == 9
    assert swf.tags[0].length == 788
    assert swf.tags[1].type == 69
    assert swf.tags[1].length == 0
    assert swf.tags[2].type == 0
    assert swf.tags[2].length == 0


# Generated at 2022-06-18 16:04:22.080638
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCConstantPool
    from .abc import ABCMethod
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameRTQName
    from .abc import ABCMultinameRTQNameA
    from .abc import ABCMultinameRTQNameL
    from .abc import ABCMultinameRTQNameLA
    from .abc import ABCMultinameTypeName
    from .abc import ABC

# Generated at 2022-06-18 16:04:27.225672
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter()
    swf.parse(open(os.path.join(
        os.path.dirname(__file__), 'test', 'test.swf'), 'rb'))
    swf.patch_function('_level0.Main.main')
    assert swf.extract_function('_level0.Main', 'main')() == 'Hello World!'

# Generated at 2022-06-18 16:04:37.402305
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfextract import SWFExtract
    from .swfparse import SWFParse
    from .swfrender import SWFRender
    from .swftext import SWFText
    from .swftree import SWFTree
    from .swfview import SWFView
    from .swfxml import SWFXML
    from .swfxml2 import SWFXML2
    from .swfxml3 import SWFXML3
    from .swfxml4 import SWFXML4
    from .swfxml5 import SWFXML5
    from .swfxml6 import SWFXML6
    from .swfxml7 import SWFXML7
    from .swfxml8 import SWFXML8

# Generated at 2022-06-18 16:04:47.338267
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter()
    swf.patch_function('trace', lambda x: print(x))
    swf.patch_function('String', lambda x: x)
    swf.patch_function('String.split', lambda x: x)
    swf.patch_function('String.charCodeAt', lambda x: x)
    swf.patch_function('Array', lambda x: x)
    swf.patch_function('Array.slice', lambda x: x)
    swf.patch_function('Array.join', lambda x: x)
    swf.patch_function('Array.reverse', lambda x: x)
    swf.patch_function('Math.random', lambda x: x)
    swf.patch_function('Math.floor', lambda x: x)

# Generated at 2022-06-18 16:04:54.091356
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf_utils import read_swf_header
    from .swf_utils import read_swf_tags
    from .swf_utils import read_swf_tag_doabc
    from .swf_utils import read_swf_tag_doaction
    from .swf_utils import read_swf_tag_symbols
    from .swf_utils import read_swf_tag_end

    # Test 1: simple class with a method

# Generated at 2022-06-18 16:05:05.161304
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import os
    import sys
    import unittest

    class TestSWFInterpreter(unittest.TestCase):
        def test_constructor(self):
            # Test constructor of class SWFInterpreter
            # Test case 1
            swf_file = os.path.join(
                os.path.dirname(sys.argv[0]), 'test_data', 'test1.swf')
            swf_interpreter = SWFInterpreter(swf_file)
            self.assertEqual(len(swf_interpreter.constant_strings), 3)
            self.assertEqual(len(swf_interpreter.multinames), 3)
            self.assertEqual(len(swf_interpreter.classes), 1)

# Generated at 2022-06-18 16:05:11.198311
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swf import SWF
    from .swfdecompiler import SWFDecompiler
    from .swfextract import SWFExtract
    from .swfinterpreter import SWFInterpreter
    from .swfparser import SWFParser
    from .swfrender import SWFRender

    # Test SWFInterpreter
    swf = SWF(open('tests/swfs/test_abc.swf', 'rb'))
    swf.parse()
    swf.decompile()
    swf.extract()
    swf.render()
    swf.interpreter()

# Generated at 2022-06-18 16:05:21.946675
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCMultiname
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCConstantPool
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCOpcode
    from .abc import ABCOpcode_0
    from .abc import ABCOpcode_1
    from .abc import ABCOpcode_2
    from .abc import ABCOpcode_3
    from .abc import ABCOpcode_4
    from .abc import ABCOpcode_5
    from .abc import ABCOpcode_6
    from .abc import ABCOpcode

# Generated at 2022-06-18 16:08:18.698484
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open('test.swf', 'rb'))
    assert swf.version == 9
    assert swf.file_length == 805
    assert swf.frame_size == (0, 0, 320, 240)
    assert swf.frame_rate == 12
    assert swf.frame_count == 1

# Generated at 2022-06-18 16:08:28.354958
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-18 16:08:34.316137
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCConstantPool
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCMethodBody
    from .abc import ABCException
    from .abc import ABCOpcode
    from .abc import ABCExceptionHandler
    from .abc import ABCTrait
    from .abc import ABCTraitSlot
    from .abc import ABCTraitMethod
    from .abc import ABCTraitClass
    from .abc import ABCTraitFunction

# Generated at 2022-06-18 16:08:43.382667
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb'))
    swf.extract_class('TestClass')
    swf.extract_class('TestClass2')
    swf.extract_class('TestClass3')
    swf.extract_class('TestClass4')
    swf.extract_class('TestClass5')
    swf.extract_class('TestClass6')
    swf.extract_class('TestClass7')
    swf.extract_class('TestClass8')
    swf.extract_class('TestClass9')
    swf.extract_class('TestClass10')
    swf.extract_class('TestClass11')

# Generated at 2022-06-18 16:08:51.521946
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCExceptionHandler
    from .abc import ABCException
    from .abc import ABCClass
    from .abc import ABCInstance
    from .abc import ABCMethodBody
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameLT
    from .abc import ABCMultinameN
    from .abc import ABCMultinameNT
    from .abc import ABCMultinameT
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCNamespaceType
    from .abc import ABCNamespaceTypeName
    from .abc import ABCNamespace

# Generated at 2022-06-18 16:09:00.648302
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .abc import ABCMethod
    from .abc import ABCException
    from .abc import ABCExceptionHandler
    from .abc import ABCMultiname
    from .abc import ABCMultinameL
    from .abc import ABCMultinameLA
    from .abc import ABCMultinameQName
    from .abc import ABCMultinameQNameA
    from .abc import ABCMultinameTypeName
    from .abc import ABCMultinameTypeNameA
    from .abc import ABCNamespace
    from .abc import ABCNamespaceSet
    from .abc import ABCInstance
    from .abc import ABCClass
    from .abc import ABCScript
    from .abc import ABCMethodBody
    from .abc import ABCMethodInfo
    from .abc import ABC

# Generated at 2022-06-18 16:09:09.965691
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:09:16.255888
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler
    from .swfdata import SWFData
    from .swfdecompiler import SWFDecompiler

# Generated at 2022-06-18 16:09:23.418942
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-18 16:09:31.755581
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFDecompilerError
    from .swfdecompiler import SWFDecompilerIOError
    from .swfdecompiler import SWFDecompilerValueError

    # Test case 1
    # Test SWFInterpreter constructor with invalid file path
    with pytest.raises(SWFDecompilerIOError):
        SWFInterpreter('invalid_file_path')

    # Test case 2
    # Test SWFInterpreter constructor with invalid file object
    with pytest.raises(SWFDecompilerIOError):
        SWFInterpreter(BytesIO())

    # Test case 3
    # Test SWFInterpreter constructor with invalid file object