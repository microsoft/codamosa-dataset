

# Generated at 2022-06-12 19:36:22.233806
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import pprint
    from .swfdata import SWF

    def test_extract_function(swf_file, func_name):
        swf = SWF(swf_file)
        interpreter = SWFInterpreter(swf)
        func = interpreter.extract_function(
            interpreter.get_class('root'), func_name)
        print('# Function %r extracted:' % func_name)
        pprint.pprint(func)


# Generated at 2022-06-12 19:36:30.465240
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import shutil
    import tempfile
    import sys

    from .parser import parse_swf_file

    def test_parse_and_extract():
        class_name = 'Foo'
        with tempfile.NamedTemporaryFile(suffix='.py') as tmp:
            filename = tmp.name
            with open(
                os.path.join(
                    os.path.split(os.path.realpath(__file__))[0],
                    'SWFInterpreter_test.py'),
                'rb') as f:
                shutil.copyfileobj(f, tmp)
                tmp.flush()
                data = parse_swf_file(filename)
                interpreter = SWFInterpreter(data, filename)
                interpreter.extract_all()
                avm_class_foo = interpreter.extract

# Generated at 2022-06-12 19:36:31.841477
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    si = SWFInterpreter(None, None, None)
    assert si


# Generated at 2022-06-12 19:36:39.721584
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(123, 'Test')
    methods = {
        'testmethod1': 234,
        'testmethod2': 123,
    }
    c.register_methods(methods)
    assert c.method_names == methods
    assert c.method_idxs == dict(
        (v, k)
        for k, v in methods.items())
    return c



# Generated at 2022-06-12 19:36:47.336878
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():

    swfi = SWFInterpreter('test.swf')
    func = swfi.extract_function(namespace='VideoPlayer', name='cuePoints')
    assert callable(func)
    if 'VideoPlayer_cuePoints' in globals():
        del globals()['VideoPlayer_cuePoints']
    res = func()
    assert res == ['fullscreen']
    assert VideoPlayer_cuePoints == ['fullscreen']

    func = swfi.extract_function(
        namespace='VideoPlayer', name='onMetaData',
        func_namespace='onMetaData', func_name='onMetaData')
    assert callable(func)
    if 'onMetaData_onMetaData' in globals():
        del globals()['onMetaData_onMetaData']
    res = func(['fullscreen'])
    assert res

# Generated at 2022-06-12 19:36:52.434154
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    if ((_AVMClass.register_methods.__doc__ is not None) and
        _AVMClass.register_methods.__doc__.strip() !=
        'Unit test for method register_methods of class _AVMClass'):
        print(_AVMClass.register_methods.__doc__)
    avm_class = _AVMClass(name_idx=1, name='Foo')
    avm_class.register_methods(collections.OrderedDict((
        ('init', 0),
        ('baz', 3),
        ('foo', 1),
        ('bar', 2),
    )))

# Generated at 2022-06-12 19:36:58.813931
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter()
    class_id = 0

# Generated at 2022-06-12 19:37:05.117422
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open('data/puppetswf_interpreter.bin', 'rb') as f:
        swfdata = f.read()
    interp = SWFInterpreter(swfdata)
    assert interp.avm_classes['puppetswf.PuppetSWF'].static_properties[
        'INTERPRETER_VER'] == 'Python3.3.3'



# Generated at 2022-06-12 19:37:16.485421
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf_interpreter import SWFInterpreter
    from .as_obj import ASClassDef
    from .as_types import ASString

    # Implementation of Date.getTime
    class DateClass(ASClassDef):
        methods = {
            'getTime': lambda: 42
        }

        static_properties = {
            'Date': DateClass
        }

    # Implementation of String.substr
    class StringClass(ASClassDef):
        methods = {
            'substr': lambda s: s[1]
        }
    _builtin_classes['Date'] = DateClass()
    _builtin_classes['String'] = StringClass()

    # Implementation of 'Array' class

# Generated at 2022-06-12 19:37:22.962535
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    methods = [
        ['String', 'split'],
        ['flash.net', 'URLStream'],
        ['flash.net', 'NetConnection'],
        ['flash.net', 'NetStream'],
        ['flash.media', 'Sound'],
        ['flash.media', 'Video'],
        ['flash.media', 'SoundTransform'],
    ]
    methods_str = '\n'.join('%s.%s' % (name, mname)
                            for name, mname in methods)
    methods_str_repr = repr(methods_str)

    swf_interpreter = SWFInterpreter()

    for name, mname in methods:
        swf_interpreter._patch_function(name, mname)

    methods_found = set()

# Generated at 2022-06-12 19:38:36.263216
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Test of SWFInterpreter constructor
    from .test_flash_player_abc import abc_avm2_string
    from .test_flash_player_abc import abc_avm2_string_tests
    from .test_flash_player_abc import generate_avm2_string_tests
    from .test_flash_player_abc import abc_avm2_string_arguments
    from .test_flash_player_abc import generate_avm2_string_arguments
    from .test_flash_player_abc import abc_avm2_number
    from .test_flash_player_abc import abc_avm2_number_tests
    from .test_flash_player_abc import generate_avm2_number_tests
    from .test_flash_player_abc import abc_avm2

# Generated at 2022-06-12 19:38:37.286140
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Not yet tested
    pass

# Generated at 2022-06-12 19:38:39.817892
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    obj = _ScopeDict(_AVMClass_Object(None))
    assert obj.__repr__() == '_AVMClass_Object__Scope({})'



# Generated at 2022-06-12 19:38:48.014794
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    test_case = open(join_path('Data', 'avm', 'avm_class.swf'), 'rb').read()
    swf = SWFInterpreter(test_case)
    assert issubclass(swf.extract_class('Test'), object)
    assert issubclass(swf.extract_class('Test', ['abc']), object)
    assert issubclass(swf.extract_class('Test', [23.0]), object)
    assert issubclass(swf.extract_class('Test', [23]), object)
    assert issubclass(swf.extract_class('Test', [True]), object)
    assert issubclass(swf.extract_class('Test', [False]), object)

# Generated at 2022-06-12 19:38:58.137849
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class Obj(object):
        pass
    obj = Obj()
    # We create a function to patch, that is also a module
    obj.f = modules['f'] = lambda: 3
    obj.f.__module__ = 'f'
    # Dummy interpreter
    avm_interp = SWFInterpreter()
    # First, no patch
    assert obj.f() == 3
    # Patch
    avm_interp.patch_function(obj.f, 'f', 'g')
    assert obj.f() == 'g'
    assert obj.g == 3
    # Unpatch
    avm_interp.unpatch_function(obj.f)
    assert obj.f() == 3
    assert not hasattr(obj, 'g')
    # Cleanup
    del modules['f']
    del obj.f

# Generated at 2022-06-12 19:39:04.961822
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    class SWFInfo(object):
        def __init__(self, version, file_version, file_length, frame_size,
                     frame_rate, frame_count, tag_code_and_length_list,
                     constant_pool, actionscript3, fileattributes,
                     metadata_string, doabc, toplevel_class):
            self.version = version
            self.file_version = file_version
            self.file_length = file_length
            self.frame_size = frame_size
            self.frame_rate = frame_rate
            self.frame_count = frame_count
            self.tag_code_and_length_list = tag_code_and_length_list
            self.constant_pool = constant_pool
            self.actionscript3 = actionscript3
            self.fileattributes = fileattributes

# Generated at 2022-06-12 19:39:15.225683
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:39:16.169450
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    pass


# Generated at 2022-06-12 19:39:18.598377
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    """__repr__ of _ScopeDict returns name of class"""
    cl = _AVMClass('ccc')
    assert repr(_ScopeDict(cl)) == 'ccc__Scope({})'

# Generated at 2022-06-12 19:39:20.790519
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter(b'\x00\x00\x00\x00')
    assert swf_interpreter


# Generated at 2022-06-12 19:40:20.383866
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    r = _ScopeDict(avm_class=123).__repr__()
    assert repr(r) == repr('123__Scope({})'), repr(r)
test__ScopeDict___repr__()



# Generated at 2022-06-12 19:40:25.925239
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interp = SWFInterpreter()
    swf_io = BytesIO()
    swf_io.write(b'%PDF-1.2')  # Invalid header
    swf_io.seek(0)
    with pytest.raises(ExtractionError):
        interp.parse(swf_io)

    interp = SWFInterpreter()
    swf_io = BytesIO()
    writer = SWFWriter(swf_io)
    writer.write_header()

    # The swf with just a script
    # But also a reference to String class, so we can be sure
    # that String.String is implemented correctly

# Generated at 2022-06-12 19:40:32.099852
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    si = SWFInterpreter(None)


# Generated at 2022-06-12 19:40:34.315177
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interp = SWFInterpreter()
    assert len(interp.constant_pool) == 0
    assert len(interp.classes) == 0
    assert len(interp.methods) == 0
    assert len(interp.method_info) == 0


# Generated at 2022-06-12 19:40:40.463826
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    def check(avm_code, func_name, expected_arg_type,
              expected_res_type, expected_res=None,
              extra_methods=None):
        print('Testing %r' % func_name)
        print('\n'.join(['   ' + l for l in avm_code.splitlines()]))
        avm_interpreter = SWFInterpreter(avm_code)
        avm_interpreter.extract_functions()
        assert len(avm_interpreter.extracted_functions) == 1,\
            'Exactly one function must be extracted'
        func = avm_interpreter.extracted_functions[0]
        assert func.arg_type == expected_arg_type,\
            'Argument type mismatch'
        assert func.res_

# Generated at 2022-06-12 19:40:47.745312
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():

    class TestSWFInterpreter(SWFInterpreter):
        def __init__(self, *args, **kwargs):
            pass

    # Testing for method extract_function
    # Case 1: simple
    constant_integers = [0, 1, 2, 3]
    constant_strings = ['', 'a', 'b', 'c']
    multinames = [
        'a', _Multiname('b', idx=0), 'c', _Multiname('d', idx=1), 'e',
        _Multiname('f', idx=3), 'g', 'h', _Multiname('i', idx=4),
        _Multiname('j', idx=4), _Multiname('k', idx=4), 'l', 'm', 'n']

# Generated at 2022-06-12 19:40:56.923964
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io

    def dummy_method_extractor(method_abc):
        def dummy_function(args):
            if len(args) == 2:
                return args[0] + args[1]
            elif len(args) == 1:
                return args[0]
            else:
                return undefined

        return dummy_function

    interpreter = SWFInterpreter(None)
    interpreter.extract_function = dummy_method_extractor

    class TestClass(interpreter.AVMClass):
        method_names = ['test']

    class TestInstance(interpreter.AVMClass_Object):
        avm_class = TestClass

    interpreter.register_class('TestClass', TestClass)
    interpreter.register_class('TestInstance', TestInstance)
    interpreter.constant_strings = ['test']

# Generated at 2022-06-12 19:41:01.925021
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = io.BytesIO(open(
        'tests/data/get_video_info-1.swf', 'rb').read())
    interpreter = SWFInterpreter(swf)
    decompiler = SWFDecompiler(interpreter)
    interpreter.extract_class(
        decompiler.avm_classes['GetVideoInfo'])
    return interpreter


# Generated at 2022-06-12 19:41:08.615774
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-12 19:41:14.168424
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():

    class MyClass(_AVMClass):
        name = 'MyClass'
        supername = 'Class'
        variables = {
            'publicStaticVar': 'publicStaticVarValue'}
        static_properties = {
            'doTrace': _builtin_functions['doTrace']}
        method_names = {'myMethod', 'myMethodArg'}

        def __init__(self):
            _AVMClass.__init__(self)
            self.publicVar = None

        @staticmethod
        def make_object(args=()):
            self = MyClass()
            self.publicVar = args[0] if args else 'defaultValue'
            self.variables.update({
                'publicVar': self.publicVar,
            })

# Generated at 2022-06-12 19:43:16.870099
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import abc
    from io import BytesIO
    abc_bytes = open(abc.__file__, 'rb').read()
    abc_bytes = abc_bytes.replace(
        b'\r\n', b'\n')
    if not abc_bytes.endswith(b'\n'):
        abc_bytes += b'\n'
    abc_io = BytesIO(abc_bytes)
    from .as3consts import AS3Consts
    from .as3parser import AS3Parser
    as3_parser = AS3Parser(abc_io)
    as3_parser.parse()
    from .as3instructions import AS3Instructions
    from .as3method import AS3Method
    from .as3class import AS3Class
    from .as3abc import AS

# Generated at 2022-06-12 19:43:19.063456
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # TODO: add unit test
    SWFInterpreter(None)

# Generated at 2022-06-12 19:43:20.465101
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    pass
# Code for class _AVMClass

# Generated at 2022-06-12 19:43:27.093099
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Initializing mock objects
    swf = mock.Mock(SWF)
    swf.abc_tags = [mock.Mock(ABCFile)]
    swf.abc_tag = swf.abc_tags[0]

    # Mock ABCFile
    abc_file = swf.abc_tags[0]
    abc_file.constant_int.return_value = 0
    abc_file.constant_int.return_value = 1
    abc_file.constant_uint.return_value = 2
    abc_file.constant_uint.return_value = 3
    abc_file.constant_double.return_value = 4.0
    abc_file.constant_double.return_value = 5.0
    abc_file.constant_string.return_value

# Generated at 2022-06-12 19:43:29.326208
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    obj = SWFInterpreter('dummy', debug_read=True)
    obj.extract_function(None, 'nonexistent')

# Generated at 2022-06-12 19:43:31.764641
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert repr(_ScopeDict(object)) == 'object__Scope({})'
    assert repr(_ScopeDict(object, foo=1)) == "object__Scope({'foo': 1})"



# Generated at 2022-06-12 19:43:38.215572
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .base_utils import fake_swf_tags

    with open('tests/swf/as2-tracer.swf', 'rb') as f:
        swf_data = f.read()

    interpreter = SWFInterpreter()


# Generated at 2022-06-12 19:43:49.914857
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter(
        max_id=610,
        min_file_version=10,
        classes=defaultdict(lambda: SWFClass(
            class_name='',
            class_id=610,
            variables=defaultdict(lambda: undefined),
            static_properties=defaultdict(lambda: undefined),
            method_names=[],
            super_class_id=0,
            method_pyfunctions=defaultdict(lambda: None),
            method_signatures=defaultdict(lambda: None),
            is_interface=False,
        ))
    )
    assert len(swf.classes) == 1
    assert 610 in swf.classes

# Generated at 2022-06-12 19:43:57.320602
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():

    scope_dict, interpreter = get_scope_dict_and_interpreter([
        (0, 1, 2, 3, 4, 0), (5, 6, 7, 8, 9, 0),
        (10, 11, 12, 13, 14, 0), (15, 16, 17, 18, 19, 0)])

    def xmax(args):
        return max(args[0], args[1])

    interpreter.patch_function(
        scope_dict, 'xmax', 2,
        ((1, 2, 3), (4, 5, 6), (7, 8, 9), (10, 11, 12)))

    assert interpreter.extract_function(scope_dict, 'xmax')([1, 2]) == 2


# Generated at 2022-06-12 19:44:04.756019
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io
    from . import swf

    swf_bytes = compat_b(
        '\x46\x57\xb4\x64\x00\x00\x00\x00\x00\x00'
        '\x14\x00\x00\x00\x68\x00\x05\x00\x00\x00')
    inp = io.BytesIO(swf_bytes)
    swf_file = swf.SWFInterpreter(inp)

    # The bytecode corresponds to the following function:
    # function f(x) {
    #     return x + 1;
    # }
    assert swf_file.extract_function(swf_file.classes[0], 'f')([1]) == 2