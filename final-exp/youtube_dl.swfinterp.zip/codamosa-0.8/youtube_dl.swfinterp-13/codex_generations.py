

# Generated at 2022-06-12 19:36:41.645272
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    def test_func(args):
        assert isinstance(args, list)
        print(args)
        return 'answer is ' + '-'.join(args)
    test_interpreter = SWFInterpreter()
    test_interpreter.patch_function(test_func, '', [])
    assert test_interpreter.functions[''] == test_func
    assert test_interpreter.constant_strings == []
    assert test_interpreter.avms == []
    assert test_interpreter.multinames == []

# Generated at 2022-06-12 19:36:51.403481
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter(b'')
    interpreter.constant_strings = []
    interpreter.method_bodies = [
        SWFMethodBody(
            max_stack=2,
            local_count=2,
            init_scope_depth=1,
            max_scope_depth=1,
            code=(
                b'\x0e\x00\x00\x00\x00\x00\x00\x00\x00\x00'
                b'\x04\x00\x00\x00\x00\x00\x03\x00\x00'))]

    avm_class = _AVMClass('MyClass', _ObjectClass)
    interpreter.extract_class(avm_class)
    assert avm_class.static_properties['age'] == 10


# Generated at 2022-06-12 19:36:57.337157
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class TestInterpreter(SWFInterpreter):
        @classmethod
        def _load_abc_file(cls, fn):
            with open(fn, 'rb') as f:
                return f.read()

    input_files = [
        'flash/avm2.abc',
        'flash/abce.abc',
        'flash/avm1lib.abc',
        'flash/playerglobal.abc',
    ]

# Generated at 2022-06-12 19:37:05.437656
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:37:16.662315
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF
    swf = SWF(BytesIO(b''))
    from .swf_utils import DisplayList, Matrix, Rect
    from .swf_tags import DoAction, Tag
    tag = DoAction(
        actions=[0x22,
                  0x45, 0x04, 0x00,
                  0x00])
    player = SWFInterpreter()
    display_list = DisplayList()
    frame = DisplayList()
    display_list.append_frame([frame])
    player.patch_function(
        SWFInterpreter.patch_function,
        'TestFunction', [1, 2],
        display_list, Matrix(), Rect(0, 0, 0, 0), frame,
        tag, 0, swf, tag)
    assert player.method

# Generated at 2022-06-12 19:37:21.431489
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(
        fileobj = io.BytesIO(b'\x46\xf0\x00\x00'),
        versions = [20])
    swf.parse_header()
    swf.parse_scount()
    swf.parse_abc_file(0x0, 0x10000)

    c = swf.extract_classes()
    assert len(c) == 1
    assert 'RegExp' in c
    assert c['RegExp'].instance_method_names == ['exec']


# Generated at 2022-06-12 19:37:24.712454
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert repr(_ScopeDict(object())) == 'object__Scope({})'
    assert repr(_ScopeDict(object())) == 'object__Scope({})'



# Generated at 2022-06-12 19:37:34.055757
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open('video/big_buck_bunny_trailer.swf', 'rb') as f:
        swf_interpreter = SWFInterpreter(f)

        assert swf_interpreter.version == 9
        assert swf_interpreter.file_length == 1406550
        assert len(swf_interpreter.tags) == 859

        assert len(swf_interpreter.classes) == 1
        avm_class_idx = list(swf_interpreter.classes.keys())[0]
        avm_class = swf_interpreter.classes[avm_class_idx]
        assert isinstance(avm_class, _AVMClass)

        # Check that main function returns type number with value 100
        stack = []

# Generated at 2022-06-12 19:37:40.278289
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_data = open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb').read()
    intern = SWFInterpreter(swf_data)
    class_ = intern.extract_class('XMLUI')
    assert isinstance(class_, _AVMClass)
    assert class_.static_properties['ATTACH_LOAD'] == 'load'

# Generated at 2022-06-12 19:37:46.857632
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:39:36.689709
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import sys
    import StringIO

    class Tester(object):
        def __init__(self):
            self.written = StringIO.StringIO()
            self.original_stdout = sys.stdout
            sys.stdout = self.written

        def assertIn(self, a, b):
            if a not in b:
                assert False, '%r not in %r' % (a, b)

    def run(code):
        s = SWFInterpreter()

        s.parse(code)
        assert len(s.methods) == 1
        assert len(s.methods[0].code) == 1
        assert s.methods[0].code[0] == code

        s.extract_function(MainClass, 'main')

# Generated at 2022-06-12 19:39:37.484376
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert True


# Generated at 2022-06-12 19:39:46.916418
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    avm_class = _AVMClass(0, 'Foo')
    avm_class.register_methods({
        'foo': 6,
        'bar': 8,
        'baz': 42
    })
    assert avm_class.method_names == {
        'foo': 6,
        'bar': 8,
        'baz': 42,
    }
    assert avm_class.method_idxs == {
        6: 'foo',
        8: 'bar',
        42: 'baz',
    }
test__AVMClass_register_methods()


# Generated at 2022-06-12 19:39:53.463607
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter(
        dict(
            swf_name='TestSWF',
            swf_url='http://localhost',
            swf_size=0,
            swf_checksum=0,
            swf_md5=0,
            swf_id=0,
            swf_version=0,
            swf_sig=0,
            swf_file_handle=open('swftest.swf', 'rb'),
        ),
        dict())
    # Test method extract_function in class SWFInterpreter
    assert interpreter.extract_function('AVM1Class', 'AsyncError') is None
    assert interpreter.extract_function('AVM1Class', 'ThrowError') is None



# Generated at 2022-06-12 19:40:02.145648
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    code = (
        b'\x10'          # SWF 10
        b'\x00\x00'      # File length
        b'\x00'          # Frame size
        b'\x00\x00'      # Frame rate
        b'\x00\x00'      # Frame count
    )
    with open('test.swf', 'wb') as f:
        f.write(code)

    si = SWFInterpreter(open('test.swf', 'rb'))
    assert si.version == 10
    assert si.file_length == 0
    assert si.frame_size == (0, 0, 0, 0)
    assert si.frame_rate == 0
    assert si.frame_count == 0

# Generated at 2022-06-12 19:40:11.538405
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter()
    # test class 'Object'
    classdef = interpreter.extract_class('Object')
    assert not classdef.has_superclass
    assert not classdef.final
    assert classdef.interface
    assert not classdef.protected
    assert not classdef.sealed
    assert 'Object' == classdef.name
    assert 0 == len(classdef.static_initializers)
    assert 0 == len(classdef.instance_initializers)
    assert 0 == len(classdef.instance_methods)
    assert 0 == len(classdef.instance_properties)
    assert 0 == len(classdef.static_properties)
    assert 0 == len(classdef.multinames)
    assert 0 == len(classdef.instance_attributes)

# Generated at 2022-06-12 19:40:18.194333
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(b'', '\0')
    assert swf.constant_integers == [0]
    assert swf.constant_strings == ['', 'null', 'false', 'true',
                                    'undefined', 'void', 'String', 'Number',
                                    'Boolean', 'Object', 'RegExp',
                                    'Array', 'Math', 'Date']
    assert len(swf.constant_namespaces) == 3
    assert len(swf.constant_namespace_sets) == 2
    assert len(swf.constant_multinames) == 13
    assert len(swf.method_signatures) == 1
    assert len(swf.method_bodies) == 1


# Global variable (or singleton) used as built-in classes
StringClass = _AV

# Generated at 2022-06-12 19:40:19.070411
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter()



# Generated at 2022-06-12 19:40:24.657344
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interp = SWFInterpreter()

# Generated at 2022-06-12 19:40:30.040481
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import SWF
    from .abc import ABCFile
    from .tag import Tag
    from .abc import parse_abc
    from .abc import ABCMethodInfo, ABCMethodBodyInfo

    # Test 0
    # No body
    abcfile = ABCFile()
    abcfile.methods = [
        ABCMethodInfo(
            0, 'method_0', [], [], 1, None, None),
    ]
    ctx = SWFInterpreter()
    ctx.extract_function(abcfile, 'method_0')
    # Test 0.1
    # No body, but a bodyinfo
    abcfile = ABCFile()

# Generated at 2022-06-12 19:42:31.225305
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_filename = get_test_file_path('basic_ad.swf')
    with open(swf_filename, 'rb') as swf_file:
        swf_bytes = swf_file.read()
        swf_interpreter = SWFInterpreter(swf_bytes)
    return True


# Generated at 2022-06-12 19:42:36.429164
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:42:39.542084
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    classTestSWF = TestSWF()
    interpreter = SWFInterpreter(classTestSWF)
    avm_class = interpreter.parse_class('Test')
    assert 'test' in avm_class.method_pyfunctions


_builtin_classes = {}



# Generated at 2022-06-12 19:42:44.171829
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:42:46.388434
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # TODO add unit test
    pass

# Generated at 2022-06-12 19:42:50.392837
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter(debug_output=True)
    with open(os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
            'test', 'test.swf'), 'rb') as f:
        interpreter.from_file(f)
    _test_SWFInterpreter_extract_class(interpreter)

# Generated at 2022-06-12 19:43:01.234917
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():

    swf_interpreter = SWFInterpreter(io.BytesIO(b''), None)

    assert list(swf_interpreter.constant_strings) == []
    assert list(swf_interpreter.constant_ints) == []
    assert list(swf_interpreter.constant_uints) == []
    assert list(swf_interpreter.constant_doubles) == []
    assert list(swf_interpreter.multinames) == []
    assert list(swf_interpreter.namespace_sets) == []
    assert list(swf_interpreter.namespaces) == []
    assert list(swf_interpreter.methods) == []
    assert list(swf_interpreter.metadata) == []

# Generated at 2022-06-12 19:43:02.255701
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    pass


# Generated at 2022-06-12 19:43:08.305707
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    decoder = get_swf_decoder()

    swfbytes = compat_urllib_request.urlopen(
        'http://www.tiny.cc/swfbin/tinycc-3.swf').read()
    is_swf = decoder.is_swf(swfbytes)
    assert is_swf
    swfobj = decoder.decode(swfbytes)
    assert swfobj is not None

    interpreter = SWFInterpreter()

    avm_class = interpreter.extract_class(swfobj.abc_entries[0])
    assert avm_class is not None

    #assert avm_class.variables['instanceName'].get('getter') is not None
    #assert avm_class.variables['instanceName'].get('setter') is not None



# Generated at 2022-06-12 19:43:17.512544
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .crypto import SWFCrypto
    from .consts import TAG_DO_ABC, TAG_DO_ABC_DEFINE, CONSTANT_Qname, \
        CONSTANT_Multiname, CONSTANT_NamespaceSet, CONSTANT_Namespace, \
        CONSTANT_RTQname, CONSTANT_RTQnameL, CONSTANT_RTQnameLA, \
        CONSTANT_NameL, CONSTANT_NameLA, MULTINAME_TypeName, MULTINAME_QName, \
        MULTINAME_RTQname, MULTINAME_RTQnameL, MULTINAME_Multiname, \
        MULTINAME_MultinameL, ABC_OP_NEWFUNCTION, ABC_OP_CALL, ABC_OP_CONSTRUCT, \
        ABC_