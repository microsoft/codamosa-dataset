

# Generated at 2022-06-12 19:36:21.491328
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-12 19:36:29.797415
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import os
    import tempfile

    path_swf = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests', 'test.swf')
    with open(path_swf, 'rb') as f:
        swf_bytes = f.read()

    with tempfile.NamedTemporaryFile(suffix='.swf') as f:
        f.write(swf_bytes)
        f.flush()
        swf = SWFInterpreter(f)

    assert swf.interpreter == "MAC 10,1,82,76"
    assert swf.width == 640
    assert swf.height == 360
    assert len(swf.frames) == len(swf.frame_labels)

# Generated at 2022-06-12 19:36:41.155824
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    class FakeAVMClass:
        def __init__(self):
            self._classname = ''
            self.static_properties = {}
            self.method_names = set()
            self.variables = {}

        def make_object(self):
            return {}

    class FakeAVMClass_Object(dict):
        def __init__(self):
            self.avm_class = FakeAVMClass()

    class FakeMultiname:
        def __init__(self, text):
            self.text = text

    class FakeAVMFile:
        def __init__(self):
            self.method_names = set()

    fake_avm_class = FakeAVMClass()
    fake_avm_file = FakeAVMFile()


# Generated at 2022-06-12 19:36:48.366529
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .amf0 import read_amf0_str
    from .abc import ABCFile
    from .abc import strings_to_constants
    from .abc import constants_to_multinames
    from . import utils
    from .parser import parse_swf_data

    test_file = os.path.join(
        os.path.dirname(__file__), 'test_cases',
        'video.tudou.com', '88032412')

    swf = parse_swf_data(test_file)
    abc_file = ABCFile(utils.read_bytes(test_file, swf.abc_data_offset))

    # TODO: test more than just the strings
    # TODO: parse strings
    # TODO: parse namespaces
    # TODO: parse multiname
    #

# Generated at 2022-06-12 19:36:54.199525
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = _SWFInterpreter(None)
    class AVMClass(object):
        def __init__(self):
            self.methods = {}
            self.method_names = set()
            self.method_pyfunctions = {}
            self.static_properties = {}
            self.variables = _ScopeDict(self)

    avm_class = AVMClass()
    func_name = 'test'
    coder = BytesIO(b'\x10')
    swf.extract_function(avm_class, func_name, coder)
    assert avm_class.method_pyfunctions[func_name]([]) is undefined


# Generated at 2022-06-12 19:36:57.901260
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(None, 'foo')
    c.register_methods({
        'foo_handler': 12,
        'bar_handler': 43,
    })
    assert c.method_names == {
        'foo_handler': 12,
        'bar_handler': 43,
    }
    assert c.method_idxs == {
        12: 'foo_handler',
        43: 'bar_handler',
    }



# Generated at 2022-06-12 19:37:03.029122
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interp = SWFInterpreter()
    avm_class = _AVMClass(
        'Foo',
        [(None, 'Foo')],
        [],
        [(None, 'bar')],
        {})
    with open('test_method.swf', 'rb') as f:
        interp.parse_swf(f)

    with open('test_method.avm', 'rb') as f:
        interp.parse_avm2(f, avm_class)

    assert len(avm_class.method_names) == 1
    func = interp.extract_function(avm_class, 'bar')
    res = func([])
    assert res == 'bar'

    res = func([42])
    assert res == 'barbaz'


# Generated at 2022-06-12 19:37:14.931926
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swfdump_path = get_exe_path('swfdump')
    if not swfdump_path:
        raise Exception('swfdump not found')

    # Use a simple test SWF file
    test_file = TEST_FILE('__main__/swf/test_player_version_18.swf')
    assert os.path.exists(test_file)

    # Dump the SWF
    out, err = get_subprocess_output([
        swfdump_path, test_file, '-a', '-s', '-M'],
        env=None,
        log_output=True,
        standalone_exec=False)

    # Extract the AS3 method

# Generated at 2022-06-12 19:37:21.955272
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    cls = _AVMClass('abc', 123,
        {'a': 1, 'b': 2, 'c': 3})
    cls.register_methods({'a': 1, 'b': 2, 'foo': 3, 'bar': 4})
    assert cls.name_idx == 123
    assert cls.name == 'abc'
    assert cls.method_names == {'a': 1, 'b': 2, 'foo': 3, 'bar': 4}
    assert cls.method_idxs == {1: 'a', 2: 'b', 3: 'foo', 4: 'bar'}
    assert cls.methods == {}
    assert cls.method_pyfunctions == {}
    assert cls.static_properties == {'a': 1, 'b': 2, 'c': 3}
   

# Generated at 2022-06-12 19:37:24.416843
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    check_swfinterpreter_extract_function(  # noqa: F821
        SWFInterpreter)



# Generated at 2022-06-12 19:38:45.481478
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swf import SWF
    filename = 'tests/swfs/swf.swf'
    swf = SWF(filename)
    si = SWFInterpreter(swf, filename)

# Generated at 2022-06-12 19:38:48.582610
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(compat_urlopen('http://example.com').read())
    avm_class = swf._class_by_name['flash.net.NetStream']
    assert 'time' in avm_class.method_pyfunctions
if __name__ == '__main__':
    test_SWFInterpreter_extract_function()

# Generated at 2022-06-12 19:38:58.463001
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open('fixtures/test.swf', 'rb') as test_file:
        # Read first 8 bytes
        test_file.read(8)
        # Read and interpret the 'abc' data
        abc_data_length, = struct.unpack('<I', test_file.read(4))
        abc_data = SWFInterpreter(test_file.read(abc_data_length))
        assert abc_data.version == 17
        assert abc_data.minor_version == 0
        assert len(abc_data.constant_ints) == 8
        assert len(abc_data.constant_uints) == 10
        assert len(abc_data.constant_doubles) == 2
        assert len(abc_data.constant_strings) == 19

# Generated at 2022-06-12 19:39:06.448626
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = Interpreter()
    interpreter.avm_class = {
        'variables': {
            'Number': NumberClass,
            'String': StringClass,
            'Array': ArrayClass,
            'Math': MathClass,
        },
    }

# Generated at 2022-06-12 19:39:11.115236
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .test_files import get_test_file_path

    path = get_test_file_path('simple.swf')
    interp = SWFInterpreter()
    interp.parse_swf(path)
    main_class = interp.extract_class('Main')
    main = main_class.make_object()
    main.run()

# Generated at 2022-06-12 19:39:21.003960
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class Clazz(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def func1(self):
            return self.a
    class InnerClazzBase(object):
        def __init__(self, b, c):
            self.b = b
            self.c = c
        def func2(self):
            return self.b * self.c
    class InnerClazz(_AVMClass_Object):
        variables = {}
        method_names = set()
        static_properties = {}
        class_name = 'InnerClazz'
        def __init__(self, b, c, d):
            clazz = self.avm_class
            super(InnerClazz, self).__init__(clazz)
            self.d = d

# Generated at 2022-06-12 19:39:27.783342
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    c = SWFInterpreter(SWF(b'\x46\x57\x53\x06\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10'
                          b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x44'
                          b'\x00\x00'))

    assert c.extract_function(c.main_class, 'avm2_vs_method_0') is not None

# Test method extract_function of class SWFInterpreter by running a script
# extracted from a real SWF file

# Generated at 2022-06-12 19:39:30.682149
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swfint = SWFInterpreter(
        'test.swf', logging.getLogger('test.logger'),
        'test/LZMAUtil.swf'
   )
    assert swfint
    assert len(swfint.constant_strings) == 109



# Generated at 2022-06-12 19:39:36.739555
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:39:42.903841
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .test_core import read_test_data
    data = read_test_data('as3_test1.abc')
    interpreter = SWFInterpreter(data)
    assert interpreter.constant_strings[0] == '_'
    assert isinstance(interpreter.avm_classes[0], _AVMClass)
    assert len(interpreter.avm_classes[0].method_pyfunctions) >= 1
    assert len(interpreter.avm_classes[0].static_properties) >= 1
    test_func = interpreter.avm_classes[0].method_pyfunctions['start']
    assert test_func([]) == 'undefined'
    assert test_func(['abc']) == 'abc'
    assert test_func([42]) == 42
    assert test_func([4.2])

# Generated at 2022-06-12 19:40:48.128585
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf_test import swf_test
    # Test against file assets/test.swf
    swf = swf_test()
    swf_obj = SWFInterpreter(swf)
    exports = swf_obj.extract_class('test')
    assert isinstance(exports, dict)
    assert exports['a'] == 0
    assert isinstance(exports['get_a'], compat_callable)
    assert exports['get_a']() == 0
    assert exports['set_a'](1) is undefined
    assert exports['get_a']() == 1
    assert exports['set_a'](exports['get_a']) is undefined
    assert exports['get_a']() == 1
    assert exports['b'] == 'b'

# Generated at 2022-06-12 19:40:57.304861
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-12 19:40:59.339296
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter()
    assert(interpreter)

# Generated at 2022-06-12 19:41:06.491503
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .decompiler import decompile_method
    from .utils import read_swf

    def _test_extract_func(test_id, cdata):
        tag_type, data = read_swf(BytesIO(cdata))
        assert tag_type == 82
        interpreter = SWFInterpreter(data)
        assert len(interpreter.methods) == 1
        method = interpreter.methods[0]
        func = interpreter.extract_function('test', method)
        assert func(None, None) == test_id
        assert decompile_method(method) == 'public function test(arg1:int, arg2:Array):int {{ return {0}; }}'.format(test_id)


# Generated at 2022-06-12 19:41:12.342568
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class C(object):
        pass
    class D(object):
        pass
    si = SWFInterpreter()
    assert 'a' not in C.__dict__
    si.patch_function(C, 'a', lambda: 'a')
    assert C.a() == 'a'
    assert C.a
    assert 'a' in C.__dict__
    si.patch_function(C, 'a', lambda: 'a2')
    assert C.a() == 'a2'
    assert C.a
    assert 'a' in C.__dict__
    del C.a
    assert C.a() == 'a2'
    assert C.a
    assert 'a' in C.__dict__
    si.patch_function(D, 'a', lambda: 'b')
    assert D.a()

# Generated at 2022-06-12 19:41:16.211091
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter('test.swf')
    assert isinstance(swf_interpreter, SWFInterpreter)



# Generated at 2022-06-12 19:41:20.885924
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    i = SWFInterpreter(BytesIO(b''))
    assert i.constant_integers == []
    assert i.constant_unsigned_ints == []
    assert i.constant_doubles == []
    assert i.constant_strings == []
    assert i.namespaces == []
    assert i.namespace_sets == []
    assert i.multinames == []



# Generated at 2022-06-12 19:41:28.642812
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():

    class DummySWF(object):
        def __init__(self, data):
            self.data = data

        def read_tag_data(self, tag_code, length):
            return self.data


# Generated at 2022-06-12 19:41:35.341741
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from os.path import join, dirname
    import io

    def _read_file(filename):
        path = join(dirname(__file__), 'tests', 'swf', filename)
        with io.open(path, 'rb') as f:
            return f.read()

    data = _read_file('test.swf')

    swfinterpreter = SWFInterpreter(data)
    assert swfinterpreter.version == 10
    assert swfinterpreter.file_attributes['NetworkAccess'] is False


# Generated at 2022-06-12 19:41:42.840800
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class_bytes = (
        b'\x00'  # Class name
        b'\x00'  # Superclass name
        b'\x00\x00\x00\x01'  # Initializer
        b'\x01'  # Method count
        b'\x01'  # Method flags: 1: need_arguments, 2: need_activation
        b'\x00\x00\x00\x02'  # Method name
        b'\x00\x00\x00\x00'  # Method_param_count
    )

# Generated at 2022-06-12 19:42:51.581449
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swf import load_AVM2
    from .avm2 import ABCFile


# Generated at 2022-06-12 19:43:01.984143
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    f = open(
        os.path.join(os.path.dirname(__file__), 'input_files',
                     'a_big_buck_bunny.swf'), 'rb')
    swf = BitParsingBuffer(f.read())
    f.close()

    stripper = SWFStripper()
    stripper.parse(swf)

    swf_compressed = stripper.result

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 19:43:03.746017
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert SWFInterpreter(b'') is not None

_Multiname = namedtuple('_Multiname', 'index name kind')



# Generated at 2022-06-12 19:43:09.582350
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .script import ActionPush
    from .script import ActionPushXML
    from .script import ActionSetVariable
    from .avm2 import AVM2File
    from .abc import ABC
    from .abc import ABCFile

    with open('tests/files/20.swf', 'rb') as f:
        swf = SWF(f)
    for tag in swf.tags:
        if not isinstance(tag, TagDoABC):
            continue
        with io.BytesIO(tag.abc_bytes) as f:
            abc_data = ABC.load_from_io(f)
        break
    else:
        raise Exception('ABC data not found')

    # Patch integer
    abc = ABCFile(abc_data)
    abc.patch_integer(1, 2)

# Generated at 2022-06-12 19:43:10.579385
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert False, "Test not implemented."

# Generated at 2022-06-12 19:43:18.346131
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import json
    import sys
    if sys.version_info < (3, 0):
        from urllib2 import urlopen
    else:
        from urllib.request import urlopen

    url = ('https://raw.githubusercontent.com/rg3/youtube-dl/master/'
           'youtube_dl/extractor/youtube.py')
    with closing(urlopen(url)) as f:
        data = f.read().decode('utf-8')
    exec(data)
    assert YoutubeIE.is_suitable(
        'https://www.youtube.com/watch?v=DIEz0AuF3qE')
    ydl = YoutubeDL()
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-12 19:43:26.316866
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    class FileWrapper(object):
        def __init__(self, data):
            self._data = data
            self._pos = 0

        def tell(self):
            return self._pos

        def seek(self, pos, whence=None):
            if whence is None:
                self._pos = pos
            elif whence == 0:
                self._pos = self._pos + pos
            else:
                raise NotImplementedError('Unsupported whence value %r' % whence)

        def read(self, size=None):
            if size is None:
                res = self._data[self._pos:]
                self._pos = len(self._data)
                return res
            else:
                res = self._data[self._pos:self._pos + size]
                self._pos = self._pos + size
                return res



# Generated at 2022-06-12 19:43:34.345105
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_parser = SWFParser()

# Generated at 2022-06-12 19:43:40.177942
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:43:50.054336
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-12 19:44:50.970352
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Test for method extract_function( ... )
    # Test is not yet implemented
    pass


# Generated at 2022-06-12 19:44:57.748079
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class Test:
        def __init__(self, a, b):
            self.a = a
            self.b = b
    class Test2:
        def __init__(self):
            pass
    class Test3(Test2):
        pass
    class Test4(Test3):
        def __init__(self, c):
            super().__init__()
            self.c = c

    interpreter = SWFInterpreter()
    interpreter.extract_class(Test)
    interpreter.extract_class(Test2)
    interpreter.extract_class(Test3)
    interpreter.extract_class(Test4)

    assert Test.swf_name == 'Test'
    assert Test.inherited_from == []
    assert Test.static_properties == {}

# Generated at 2022-06-12 19:45:07.990444
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .avm2_constants import _builtin_classes
    from .avm2_class_info import (
        _AVMClass, _AVMClass_Object, _AVMInstanceInfo,
        _AVMClass_Object__init__)

    # We make a fake interpreter object for testing purpose

# Generated at 2022-06-12 19:45:14.620348
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from collections import OrderedDict
    from pprint import pprint
    from io import BytesIO

    def test_actions(p):
        def f(a, b, c):
            return None
        f.actions = p
        return f

    def _compare_actions(r, p):
        r = list(OrderedDict.fromkeys(r))
        p = list(OrderedDict.fromkeys(p))
        if r != p:
            pprint(r)
            pprint(p)
            raise AssertionError
        return True

    def _test(p):
        f = test_actions(p)
        f2 = _SWFInterpreter.patch_function(f)
        _compare_actions(f2.actions, p)
        assert f2(1, 2, 3)

# Generated at 2022-06-12 19:45:24.898596
# Unit test for method patch_function of class SWFInterpreter