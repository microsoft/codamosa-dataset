

# Generated at 2022-06-12 19:37:07.479794
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    avm_interpreter = SWFInterpreter()
    assert avm_interpreter.constant_int[0] == 0
    assert avm_interpreter.constant_uint[0] == 0
    assert avm_interpreter.constant_double[0] == 0
    assert avm_interpreter.constant_strings[0] == ''
    assert avm_interpreter.constant_namespace[0] == {}
    assert avm_interpreter.constant_namespace_set[0] == {}


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-12 19:37:15.332871
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    fname = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '../test/testdata/h264.swf')

    interp = SWFInterpreter(fname)
    assert interp

    method = interp.extract_function(interp.classes['flash.utils.ByteArray'], 'readBoolean')
    assert method
    assert isinstance(method, types.FunctionType)



# Generated at 2022-06-12 19:37:17.457499
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
  # Test with an empty SWFInterpreter
  swf = SWFInterpreter()
  assert swf.extract_class(0) is None



# Generated at 2022-06-12 19:37:27.427774
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = _SWFInterpreter({}, debug=True)

    # pylint: disable=invalid-name

# Generated at 2022-06-12 19:37:36.234744
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    scopes = []
    for scope in scopes:
        scope['a'] = scope['b']

    def f(*args, **kwargs):
        return 1

    class Test_Class(dict):
        def __init__(self, variables):
            self.variables = variables

        def __getattr__(self, attr):
            return 1

    class Test_Function(object):
        def __init__(self, *args):
            self.args = args

        def __call__(self, *args):
            return 3


# Generated at 2022-06-12 19:37:44.632053
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:37:51.838008
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-12 19:38:00.718036
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = open(test_utils.find_test_file('test.swf'), 'rb').read()

    # The following snippet extracts the compressed SWF data
    f = open(test_utils.find_test_file('test.swf'), 'rb')
    data = compat_struct_unpack('>4s2L', f.read(12))
    f.seek(data[2])
    data = f.read(data[3])
    f.close()
    data = zlib.decompress(data)

    class TestInterpreter(SWFInterpreter):
        def get_file_data(self, index):
            return data

    interp = TestInterpreter('test.swf', 'test.swf', 'test.swf')


# Generated at 2022-06-12 19:38:08.081189
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import traceback
    interpreter = SWFInterpreter()
    interpreter.parse_abcs(open(r'D:\programs\ffmpeg-20180302-8bf742f-win64-static\ffmpeg-20180302-8bf742f-win64-static\bin\adobe-flashplayer\lib\avmplus.abc', 'rb').read())
    #print(interpreter.multinames[1].name)
    #abc = interpreter.swf_abc_list[0]
    #print(abc.constant_strings)
    #print(abc.constant_multinames)
    #print(abc.constant_namespaces)
    #print(abc.constant_namespace_sets)

# Generated at 2022-06-12 19:38:11.349508
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(io.open('tests/swf/test_0022-extract_function.swf', 'rb').read())
    main = swf.avm_classes['Main']
    func = main.method_pyfunctions['main']
    assert func('Hello', 'World') == ['Hello', 'World']
    assert func('Hello', 10) == ['Hello', '10']



# Generated at 2022-06-12 19:39:35.892199
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    data = open(os.path.join(
        os.path.dirname(__file__), 'flash.bin'), 'rb').read()
    interpreter = SWFInterpreter(data)
    avm_class = interpreter.avm_classes['Main']

# Generated at 2022-06-12 19:39:42.145501
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter({})
    swf._avm2_magic = bytearray(b'\x00')
    swf._swf_magic = bytearray(b'\x00')
    swf._swf_version = bytearray(b'\x00')
    swf._swf_file_length = bytearray(b'\x00')
    swf._swf_frame_size = bytearray(b'\x00')
    swf._swf_frame_rate = bytearray(b'\x00')
    swf._swf_frame_count = bytearray(b'\x00')
    swf._tags = []
    swf._strings = ['String']
    swf._namespace_sets = []
    sw

# Generated at 2022-06-12 19:39:51.030935
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # https://github.com/rg3/youtube-dl/issues/15482
    def test(data):
        interp = SWFInterpreter()
        interp.extract_class(data, 'com.adobe.serialization.json.JSONToken')
        try:
            # Assert that the JSON encoder is extracted
            assert 'encode' in interp.avm._globals['com.adobe.serialization.json.JSON'].static_properties
        except AssertionError:
            # Assert that the JSON decoder is extracted
            assert 'decode' in interp.avm._globals['com.adobe.serialization.json.JSON'].static_properties

    def test_json(data):
        cls = 'com.adobe.serialization.json.JSON'
        interp = SWFInterpre

# Generated at 2022-06-12 19:39:51.824683
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    _extract_class()


# Generated at 2022-06-12 19:39:52.694666
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    pass


# Generated at 2022-06-12 19:40:01.882430
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swfdecompress import SWFDecompressor
    decompressor = SWFDecompressor()
    decompressor.method_extract_class = MethodType(
        extract_class.__func__, decompressor)
    swf = BytesIO(compat_b('\x1bLZ') + undefined_winbox_swf_data)
    decompressor.load_file(swf)
    decompressor.prepare()
    assert len(decompressor.classes) == 9
    assert decompressor.classes[0].name == 'Undefined'
    assert decompressor.classes[0].parent is None
    assert decompressor.classes[0].variables == {}

    assert decompressor.classes[1].name == 'Object'
    assert decompressor.classes[1].parent is None
   

# Generated at 2022-06-12 19:40:04.687916
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    filename = os.path.join(os.path.dirname(__file__), 'samples', 'patch_function.swf')
    with open(filename, 'rb') as f:
        raw_data = f.read()
    interp = SWFInterpreter(raw_data)

# Generated at 2022-06-12 19:40:14.201673
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-12 19:40:18.273790
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import os
    import pprint
    with open(os.path.join(os.path.split(__file__)[0],
                           '../../tests/swfs/as-02.swf'), 'rb') as f:
        swf = f.read()
    interpreter = SWFInterpreter(swf)
    interpreter.debug()
    #pprint.pprint(interpreter.constant_strings)

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-12 19:40:23.855111
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    try:  # Python 2
        exec('from __future__ import print_function')
    except ImportError:  # Python 3
        pass


# Generated at 2022-06-12 19:41:22.862169
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .flash_types import (
        ConvertSWFToAVM2, AVM2Class, push_constant_pool, push_byte_code,
        push_method_info)
    from .flash_utils import get_default_flash_version
    from io import BytesIO

    flash_version = get_default_flash_version(None)

    avm2class = AVM2Class(
        name='TestClass',
        superclass=None,
        interfaces=[],
        protected_namespace=None,
        static_attrs={},
        static_methods={},
        instance_attrs={},
        instance_methods={},
    )

    swf_interpreter = SWFInterpreter(flash_version, 0)


# Generated at 2022-06-12 19:41:27.563026
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import io
    import zlib
    from mpy_swf.abc.coder import ABCFile
    import mpy_swf.abc.constant_pool as constant_pool
    from mpy_swf.abc.opcodes import _OPCODES


# Generated at 2022-06-12 19:41:33.721501
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .stream import SWFStream
    from .tags.DoABC import ABCFile

    interp = SWFInterpreter()
    abc_tag = ABCFile()
    abc_tag.parse(SWFStream(open(os.path.join(
        os.path.dirname(__file__),
        'abc_lso_test.swf'), 'rb')))
    interp.parse_abc_file(abc_tag.abc_file)
    interp.extract_function(interp.classes[0], 'testecho')


# Generated at 2022-06-12 19:41:41.886729
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    print('Testing SWFInterpreter.patch_function')
    # Test setup
    ###########################################################################
    class _SWF(object):
        def __init__(self):
            self.abc_blocks = []
    swf = _SWF()
    class _ABC():
        def __init__(self, doabc_tag):
            self.doabc_tag = doabc_tag
    class _DoABCTag(object):
        def __init__(self, object_name=None):
            self.object_name = object_name
            self.method_names = {}
            self.static_properties = {}
            self.instance_properties = {}
    class _MethodInfo(object):
        def __init__(self, name):
            self.name = name

# Generated at 2022-06-12 19:41:46.042198
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = Avm2Interpreter(
        'tests/swf_files/avm_version_5.swf',
        'tests/swf_files/avm_version_5.swf.json')
    # TODO test the returned class properly
    cls = swf.extract_class(tag_id=149)
    assert isinstance(cls, _AVMClass)
    assert cls.name == 'flash.display.SimpleButton'

# Generated at 2022-06-12 19:41:51.507723
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s = compat_BytesIO(b'\n\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    i = SWFInterpreter(s)
    i.extract_class()
    assert i.constant_strings == []
    assert i.constant_ints == []
    assert i.constant_uints == []
    assert i.constant_doubles == []
    assert i.constant_namespaces == []
    assert i.constant_namespace_sets == []
    assert i.constant_multinames == []
    assert i.classes == []

# Generated at 2022-06-12 19:41:54.525066
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    interpreter = SWFInterpreter(BytesIO(b''))
    assert interpreter.patch_function(None, None, None) is None



# Generated at 2022-06-12 19:42:03.482243
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from io import SEEK_SET
    from io import SEEK_CUR
    from io import SEEK_END
    from io import FileIO
    from io import RawIOBase
    from io import UnsupportedOperation
    from io import BlockingIOError

    from .AVM2 import set_swf_interpreter
    from .Decoder import Decoder
    from .AVM2 import AVM2
    from .AVM2 import AVM2Error
    from .SWF import SWF
    from .Tag import Tag
    from .EndTag import EndTag

    # Unit test for class SWFInterpreter
    class SWFInterpreter(object):
        def __init__(self):
            self.classes = {}

        def get_class(self, name):
            return self.classes[name]



# Generated at 2022-06-12 19:42:11.971588
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Open sample file
    with open("sample_swf_files/CatStr.asasm.swf", "rb") as f:
        swf = SWF(f)

        # Check yaml2swf
        swf.show()
        swf.extract_yaml("sample_swf_files/CatStr.yaml")

        # Check swf2yaml
        with open("sample_swf_files/CatStr.yaml", "rb") as g:
            swf2 = SWF(g, yaml_file=True)
        swf2.show()

        # Check that the two SWFs are equals
        assert swf == swf2


# Generated at 2022-06-12 19:42:20.012547
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    def extract_class_test(clsname, abcdata, args):
        swf = SWFInterpreter(abcdata)
        cls = swf.extract_class(clsname)
        test_fn = cls.static_methods['test']
        res = test_fn(args)
        assert res == True

    # The following test is taken from issue #1049

# Generated at 2022-06-12 19:44:17.925202
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = _SWFInterpreter(b'\x03\x00\x00\x00\x00\x00\x00\x00\x00')
    assert isinstance(swf.extract_class('Object'), _AVMClass)



# Generated at 2022-06-12 19:44:23.076300
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():

    class TestAVMClass(object):
        def __init__(self):
            self.method_names = []
            self.variables = {}
            self.method_pyfunctions = {}
            self.static_properties = {}

        def make_object(self):
            return TestAVMObject(self)

        def set_property(self, idx, value):
            self.variables[idx] = value

    class TestAVMObject(object):
        def __init__(self, avm_class):
            self.avm_class = avm_class
            self.variables = {}

        def __getitem__(self, idx):
            return self.variables[idx]

        def __setitem__(self, idx, value):
            self.variables[idx] = value


# Generated at 2022-06-12 19:44:28.108111
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-12 19:44:34.158496
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:44:41.856803
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .test_swf import TEST_SWF_FILES_STRUCTURE

    sample_swf_struct = TEST_SWF_FILES_STRUCTURE['sample.swf']
    sample_swf_struct['clsName'] = 'SampleClass'
    sample_swf_struct['functions']['SampleFunction'] = dict(
        arguments=['a'],
        returns='undefined',
        source='./samplefunc_source.as')

    interpreter = SWFInterpreter()
    interpreter.read_file(sample_swf_struct['path'])

    sample_class = interpreter.extract_class('SampleClass')
    assert sample_class.name == 'SampleClass'
    assert sample_class.variables == {}

    sample_func = sample_class.method_pyfunctions['SampleFunction']

# Generated at 2022-06-12 19:44:47.011089
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    print('test_SWFInterpreter_patch_function')
    # https://github.com/rg3/youtube-dl/issues/9805
    swf = youtube_dl.utils.swfdecompress(
        compat_urllib_request.urlopen(
            'https://s.ytimg.com/yts/swfbin/player-en_US-vflZyoHVp.swf'
        ).read())
    s = SWFInterpreter(swf)
    init_func = s.extract_function('', 'init')
    assert init_func is not None
    swforswc = 'https://s.ytimg.com/yts/swfbin/player-vflHJQkoD.swf'

# Generated at 2022-06-12 19:44:53.312984
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm_class = _AVMClass('TestClass')
    avm_class.variables = {
        'a': 10,
        'b': 20,
        'c': 30,
        'd': 4,
        'e': 4,
    }
    swfdata = io.BytesIO(compat_chr(0) * 2)
    swf = SWFInterpreter(swfdata)
    swf.extract_function(avm_class, 'testFunc')
    assert avm_class.method_pyfunctions['testFunc'] is not None
    assert callable(avm_class.method_pyfunctions['testFunc'])


# Generated at 2022-06-12 19:44:59.783006
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()
    interpreter.parse(
        fixtures.join('swf', 'actionscript.swf'),
        skip_first_tag=True)
    assert len(interpreter.avm_classes) == 1, 'Exactly one class expected'
    avm_class, = interpreter.avm_classes

    assert len(avm_class.method_pyfunctions) == 0, (
        'No functions should be defined yet')
    interpreter.extract_function(avm_class, 'SomeFunction')
    assert len(avm_class.method_pyfunctions) == 1, (
        'One function should be defined')
    f = avm_class.method_pyfunctions['SomeFunction']
    outputs = []
    def fake_print(s):
        outputs.append(s)
    assert f

# Generated at 2022-06-12 19:45:02.125047
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    SWFInterpreter().patch_function(None, None)

# Building AVMClass from class_tag of type DoABC

# Generated at 2022-06-12 19:45:10.922974
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = _read_swf('test.swf')
    swf_interpreter = SWFInterpreter(swf)
    empty_class = swf_interpreter.extract_class(0)
    assert isinstance(empty_class, _AVMClass)
    assert len(empty_class.method_names) == 0
    listclass = swf_interpreter.extract_class(1)
    assert isinstance(listclass, _AVMClass)
    assert len(listclass.method_names) == 1
    assert 'join' in listclass.method_names
    myclass = swf_interpreter.extract_class(3)
    assert isinstance(myclass, _AVMClass)
    assert 'init' in myclass.method_names
    assert not myclass.is_native