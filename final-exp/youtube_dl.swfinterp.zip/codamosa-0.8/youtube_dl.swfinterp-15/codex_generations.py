

# Generated at 2022-06-12 19:36:48.674410
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    filename = 'test.swf'
    interpreter = SWFInterpreter
    swf = open(filename, 'rb').read()
    interpreter = interpreter(swf)
    assert interpreter.version == 17
    assert interpreter.frame_size == (496.0, 274.0)
    assert interpreter.frame_rate == 30
    assert len(interpreter.tags) == 3


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-12 19:36:51.337822
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    pytest.skip()
    interp = SWFInterpreter('md5hash.swf')
    interp.extract_function(
        interp.classes[0], 'md5Hash', keep_file=True)


# Class used by SWFInterpreter

# Generated at 2022-06-12 19:36:57.291102
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    class Point(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y
        def __eq__(self, other):
            return self.x == other.x and self.y == other.y
        def __repr__(self):
            return 'Point(%d, %d)' % (self.x, self.y)
    class Rectangle(object):
        def __init__(self, top_left, bottom_right):
            self.top_left = top_left
            self.bottom_right = bottom_right
        def __eq__(self, other):
            return self.top_left == other.top_left and self.bottom_right == other.bottom_right

# Generated at 2022-06-12 19:37:05.381879
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from ._abc_file import ABCFile
    from .helpers import SWFObject
    from .utils import bits_needed
    from .tags.do_abc import DoABC
    from .tags.scriptlimits import ScriptLimits
    from .tags.symbolclass import SymbolClass
    from .tags.fileattributes import FileAttributes

    t = SWFObject()

# Generated at 2022-06-12 19:37:11.277219
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s = SWFInterpreter()
    s.readFromFile('../test/fixtures/sample_swf_1/1/1.swf')
    s.extract_function(s.avm_classes[0], 'testFunc')
    res = s.avm_classes[0].method_pyfunctions['testFunc']()
    assert res == 42
# Class SWF

# Generated at 2022-06-12 19:37:20.423574
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # This code will execute if this file is executed as a script
    from .swftags import SWFTagDefineBinaryData, TagHeader
    from .swfdata import SWFData
    from .swftags import TagDefineBinaryData

    # For testing
    class SWFActionCode(object):
        def __init__(self, bytes, pos=0):
            self.bytes = bytes
            self.pos = pos

        def read_byte(self):
            res = self.bytes[self.pos]
            self.pos += 1
            return res

        def seek(self, pos):
            self.pos = pos

        def read_u16(self):
            res = self.bytes[self.pos] + self.bytes[self.pos + 1] * 256
            self.pos += 2
            return res


# Generated at 2022-06-12 19:37:30.225572
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = io.BytesIO(compat_bytes(
        '\x46\x57\x53\x09\x09\x00\x00\x00\x00\x7c\x00\x75\x59\x0f\x00\x00'
        '\x00\x00\x00\x00\x00\x00\x00\xff\xff\x00\x00\x00\x00\x00\x00\x00'
        ))
    with open(os.path.join(os.path.dirname(__file__), '../test/test.swf')) as f:
        swf = io.BytesIO(f.read())
    swf = SWF(swf)
    interpreter = SWFInterpreter(swf)
    func = interpreter

# Generated at 2022-06-12 19:37:38.308840
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swftags import TagDoABC

    # Dump of opcodes list
    # Opcode 0: nop
    # Opcode 1: throw
    # Opcode 2: getsuper
    # Opcode 3: setsuper
    # Opcode 4: dxns
    # Opcode 5: dxnslate
    # Opcode 6: kill
    # Opcode 7: label
    # Opcode 8: ifnlt
    # Opcode 9: ifnle
    # Opcode 10: ifngt
    # Opcode 11: ifnge
    # Opcode 12: jump
    # Opcode 13: iftrue
    # Opcode 14: iffalse
    # Opcode 15: ifeq
    # Opcode 16: ifne
    # Opcode 17: iflt
    # Opcode 18: ifle

# Generated at 2022-06-12 19:37:43.794372
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-12 19:37:47.497465
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    tests = [
        ('SWFInterpreter', 'patch_function'),
    ]
    return do_test_dynamic_class(SWFInterpreter, tests)

# Generated at 2022-06-12 19:38:50.493731
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    fname = os.path.join(os.path.dirname(__file__), 'test_extract_class.swf')
    with open(fname, 'rb') as f:
        data = f.read()
    interp = SWFInterpreter(data)
    assert interp.extract_classes()
    assert interp.classes['TestClass'].extract_functions()
    c = interp.classes['TestClass']
    assert 'f' in c.method_names
    f = c.method_names['f']
    assert f('hello') == 'hello world'
    f = c.method_names['f2']
    assert f('hello', 'world') == 'hello world'
    f = c.method_names['f3']

# Generated at 2022-06-12 19:38:54.605815
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    path = os.path.join(os.path.dirname(__file__), 'swf/test_shell.swf')
    swf = SWFInterpreter(path)
    assert swf.extract_class('TestClass')



# Generated at 2022-06-12 19:39:02.155053
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter(None, None)

    def fake_extract_function(obj, name):
        return lambda _: name

    # Support for patch_function
    class FakeClass2(object):
        def __init__(self, variables, method_names, method_pyfunctions):
            self.variables = variables
            self.method_names = method_names
            self.method_pyfunctions = method_pyfunctions

    def make_object():
        return {'fake_class': 'fake_object'}

    class FakeClass(object):
        def __init__(self, variables, method_names, method_pyfunctions):
            self.variables = variables
            self.method_names = method_names
            self.method_pyfunctions = method_pyfunctions

# Generated at 2022-06-12 19:39:05.591557
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interp = SWFInterpreter()
    def _test_extract_function(avm_class, method_name):
        avm_class.extract_method(interp, method_name)
    return _test_extract_function

# Class representing an AVM class

# Generated at 2022-06-12 19:39:15.963798
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    filename = os.path.join(
        os.path.dirname(__file__), 'testdata/hello.swf')
    interpreter = SWFInterpreter(filename)
    interpreter.extract_function('Main', 'setStage')
    assert 'Main' in interpreter.avm_classes

    filename = os.path.join(
        os.path.dirname(__file__), 'testdata/charcodeat.swf')
    interpreter = SWFInterpreter(filename)
    interpreter.extract_function('Main', 'main')
    assert 'Main' in interpreter.avm_classes

    filename = os.path.join(
        os.path.dirname(__file__), 'testdata/decodeURIComponent.swf')
    interpreter = SWFInterpreter(filename)
    interpreter.ext

# Generated at 2022-06-12 19:39:23.905135
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf import SWF

    with open('test/data/test.swf', 'rb') as f:
        swf = SWF(f)

    class_count = 0
    for tag in swf.tags:
        if tag.type == 'DoABC':
            abc_data = tag.decompress_data()
            abc_coder = io.BytesIO(abc_data)
            interpreter = SWFInterpreter(abc_coder)
            interpreter.extract_class('<test%d>' % class_count)
            class_count += 1

    assert class_count == 1
    assert '<test0>' in interpreter.classes
    assert not set(interpreter.classes['<test0>'].method_pyfunctions).issubset(
        {None})
    assert not set

# Generated at 2022-06-12 19:39:30.243790
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    """Test case -  Extract class (with and without traits)
    Args:
        arg1 (str): string
    Returns:
        bool: True on success, False otherwise
    """

    interpreter = SWFInterpreter()

    # Test with traits
    method_count = 0
    method_names = []
    constant_count = 0
    constant_strings = []
    trait_count = 0
    traits = []
    method_code = []

    def extract_class(
            coder, method_count, method_names, constant_count,
            constant_strings, trait_count, traits):
        nonlocal interpreter
        res = interpreter.extract_class(
            coder, method_count, method_names,
            constant_count, constant_strings, trait_count, traits)
        return res


# Generated at 2022-06-12 19:39:36.272230
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = unittest_SWFInterpreter_setup()

# Generated at 2022-06-12 19:39:42.466716
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter()
    current_dir = os.path.dirname(__file__)
    swf = open(os.path.join(current_dir, 'SWFInterpreter_v6.swf'), 'rb')
    swf = swf.read()
    header = SWF.parse_header(BytesIO(swf))
    assert header.version == 6
    assert header.file_length == 673
    tag_data = swf[8:]
    try:
        tag = SWF.parse_tag(BytesIO(tag_data))
    except EOFError:
        tag = None
    while tag:
        if tag.type == 69 and tag.name == 'DoABC':
            interpreter.parse_abc(tag.abc_data)
            break

# Generated at 2022-06-12 19:39:51.291558
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import sys
    import io
    import traceback
    from collections import namedtuple

    # Wrap sys.stdout into a Stream capturing object:
    #   1. a stream capturing object can be passed into the swf() method
    #      of class SWFInterpreter as the output stream for the AVM interpreter
    #   2. a stream capturing object has a 'stream' attribute
    #      which is a io.StringIO object
    #      where the captured stdout text is stored
    CapturingStdout = namedtuple('CapturingStdout', ['stream'])

    class StreamCapturing(io.StringIO):
        def __enter__(self):
            self.oldstdout = sys.stdout
            sys.stdout = self
            return self


# Generated at 2022-06-12 19:41:41.857097
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter()
    assert len(swf.constant_strings) == 0
    assert len(swf.multinames) == 0
    assert len(swf.classes) == 0


# Generated at 2022-06-12 19:41:48.468546
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swftags import TagDoABC

    swfinterpreter = SWFInterpreter(None, True)
    abcblock = TagDoABC()
    abcblock.abcfile = parse_abc(open(os.path.join(
        os.path.dirname(__file__), 'tests/stubs/youtube-dl/youtube_dl/extractor/common.as'),
        'rb'))
    swfinterpreter.process_tag(abcblock)
    swfinterpreter.get_class('youtube_dl.extractor.common.')

    abcblock = TagDoABC()

# Generated at 2022-06-12 19:41:54.082150
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Unsupported (parsing)
    interp = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'swf',
        'flashplayer', '5.5r115.swf'), 'rb'))
    with pytest.raises(NotImplementedError) as excinfo:
        interp.extract_class(0)
    assert 'Tag' in str(excinfo.value)
    interp = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'swf',
        'test_flashplayer.swf'), 'rb'))
    cl = interp.extract_class(1)
    assert isinstance(cl, _AVMClass)
    assert cl.name == 'avm2'

# Generated at 2022-06-12 19:42:03.082590
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from collections import namedtuple
    class _TagDefineSprite(object):
        def __init__(self, stream, tag_id):
            self.stream = stream
            self.tag_id = tag_id
            self.frame_count = int(_read_u16(self.stream))
            self.control_tags = []
            self.tags_dict = {}
            self.tags_dict[39] = _TagDefineSprite
            self.tags_dict[9] = _TagDoABC
            while True:
                tag = _read_tag(
                    self.stream, self.tags_dict, self.tag_id)
                if tag is None:
                    break
                self.control_tags.append(tag)

# Generated at 2022-06-12 19:42:08.564869
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-12 19:42:17.094967
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Open file
    test_class_file = open(os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test_data/test_class.swf'), 'rb')
    # Create instance of class
    swf_interpreter = SWFInterpreter(test_class_file)

    # Extract class
    res_dict = swf_interpreter.extract_class('Main')
    assert isinstance(res_dict, dict)
    assert res_dict['CLASS_NAME'] == 'Main'
    assert res_dict['CONSTRUCTOR'] is not None
    assert res_dict['STATIC_ATTRIBUTES'] == {
        '_width': 0,
        '_height': 0
    }

# Generated at 2022-06-12 19:42:25.316335
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = mock.Mock(spec_set=SWF)
    swf.swf9_compressed = False
    swf.header = mock.Mock(spec_set=SWF.SWFHeader)
    swf.header.version = 9

# Generated at 2022-06-12 19:42:28.561701
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 19:42:35.970448
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from . import dump_tags

    swf = dump_tags.tests.load_test_swf()
    swf_io = BytesIO(swf)
    assert swf_io.read(3) == b'SWF'
    version, length = dump_tags.read_header(swf_io)

    interpreter = SWFInterpreter(version)
    assert interpreter.version == 13

    class AVMClass(object):
        def __init__(self, name, subclass_name=None):
            self.name = name
            self.subclass_name = subclass_name
            self.static_properties = {}
            self.method_pyfunctions = {}
            self.method_names = set()


# Generated at 2022-06-12 19:42:46.153089
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .compat_str import compat_str

    def test_suite():
        t = SWFInterpreter()

        def check_not_implemented(meth):
            with pytest.raises(NotImplementedError):
                meth()

        def check_undefined(meth):
            assert meth() is undefined

        def check_bool(meth, expected):
            assert meth() is expected

        def check_int(meth, expected):
            assert meth() == expected

        def check_str(meth, expected):
            assert meth() == expected

        def check_float(meth, expected):
            assert is_float_equals(meth(), expected)

        def check_list(meth, expected):
            assert meth() == expected

        def check_dict(meth, expected):
            assert meth