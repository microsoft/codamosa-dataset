

# Generated at 2022-06-12 19:36:43.473131
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:36:51.466305
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interp = SWFInterpreter()

# Generated at 2022-06-12 19:36:53.676699
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    obj =  _ScopeDict(_AVMClass_Object(_AVMClass_Int).__dict__['avm_class'])
    assert repr(obj) == 'Int__Scope({})'



# Generated at 2022-06-12 19:36:59.554582
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class TestSWFInterpreter(SWFInterpreter):
        def __init__(self, *args, **kwargs):
            self.called_patch_function = False
            super(TestSWFInterpreter, self).__init__(*args, **kwargs)
        def patch_function(self, *args, **kwargs):
            self.called_patch_function = True
            super(TestSWFInterpreter, self).patch_function(*args, **kwargs)
    avm_dump = BytesIO(b'FLV')
    interp = TestSWFInterpreter(avm_dump)
    interp.patch_function('testfunc', 'testfunction-body')
    assert interp.called_patch_function

# Generated at 2022-06-12 19:37:11.277686
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    filename = 'test_SWFInterpreter_extract_function.swf'
    swf = SWFInterpreter(open(environ.resolve_data_file(filename), 'rb').read())
    # Test extract_function
    for avm_class in swf.avm_classes.values():
        for method_name in avm_class.method_names:
            swf.extract_function(avm_class, method_name)

test_SWFInterpreter_extract_function()
# Extract functions from all SWF files, so we can import them later

# Generated at 2022-06-12 19:37:16.190808
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class _ParentAVMClass(object):
        name = 'TestClass'
    test_scope = _ScopeDict(_ParentAVMClass())
    test_scope['abc'] = 'def'
    assert test_scope.__repr__() == 'TestClass__Scope({\'abc\': \'def\'})'



# Generated at 2022-06-12 19:37:19.363330
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()
    interpreter.read_file(os.path.join(DATA_DIR, '01', '0101.swf'))
    interpreter.scan_actions()
    interpreter.extract_function(interpreter.main_class, '_renderFrame')



# Generated at 2022-06-12 19:37:29.230895
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Create an empty SWF file
    swf_f = open('__test_SWFInterpreter_extract_class.swf', 'wb')
    swf_f.seek(8)
    swf_f.write(b'\t')
    swf_f.seek(0)
    swf_f.write(b'FWS')
    swf_f.write(struct.pack('<L', 8))
    swf_f.close()

    # Create an SWFInterpreter
    swf_f = open('__test_SWFInterpreter_extract_class.swf', 'rb')
    swf = SWFInterpreter(swf_f)
    swf_f.close()

    # Try the extraction
    swf.extract_class('cls')

   

# Generated at 2022-06-12 19:37:37.529118
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter()

# Generated at 2022-06-12 19:37:45.339957
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .avm_class import _AVMClass
    from .constant_pool import ConstantPool
    from .multiname import Multiname
    from .method_info import MethodInfo

    avm_class = _AVMClass()
    avm_class.load_avm1_script(BytesIO(b''))

    class MockSWFInterpreter(SWFInterpreter):
        def __init__(self, avm_class):
            self.avm_class = avm_class
            self.constant_pool = ConstantPool()
            self.multinames = [
                Multiname(),
                Multiname(kind=0x07, idx=0),
                Multiname(kind=0x07, idx=1),
            ]
            self.constant_

# Generated at 2022-06-12 19:38:45.615674
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import binascii

    swf_data = compat_urllib_request.urlopen(
        'https://github.com/rg3/youtube-dl/raw/master/test/mp3.swf').read()

# Generated at 2022-06-12 19:38:49.194748
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter(None)
    def f(args):
        return args

    interpreter.patch_function(f)


# Class that implements a modified SWF interpreter that allows to
# expose the AVM2 classes contained in the SWF file

# Generated at 2022-06-12 19:38:54.259427
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_data = open(test_file('test-avm2-1.swf'), 'rb').read()
    swfi = SWFInterpreter(swf_data)

    avm_class = swfi.extract_avm_class()
    print(avm_class.method_names)

    assert swfi.extract_function(avm_class, 'test_empty')() == 'empty'
    assert swfi.extract_function(avm_class, 'test_empty_body')() == 'empty_body'
    assert swfi.extract_function(avm_class, 'test_literal_int')() == 12345
    assert swfi.extract_function(avm_class, 'test_literal_float')() == 1.2345
    assert swfi.extract_function

# Generated at 2022-06-12 19:39:00.384854
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(SWF(open(
        os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb')))
    swf.extract_function(swf.avm_classes['com.example.Example'],
                         'echoHelloWorld')
    assert swf.avm_classes['com.example.Example'].method_pyfunctions[
        'echoHelloWorld']('hello', 'world') == 'hello world'

# For compatibility with old avconv
_builtin_classes['avconv'] = _builtin_classes['av.avutil']


# Generated at 2022-06-12 19:39:06.589922
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    inter = SWFInterpreter()
    inter.load(path_to_data_file('asfunction.swf'))
    inter.extract_class('ASFunction')
    print(inter.extract_function(inter.ASFunction, 'Add')([1, 1]))
    assert inter.extract_function(inter.ASFunction, 'Add')([1, 1]) == 2

    inter.load(path_to_data_file('asclass.swf'))
    inter.extract_class('ASClass')
    inter.extract_function(inter.ASClass, 'Main')([])



# Generated at 2022-06-12 19:39:11.849528
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    def _test_swf(swf_path):
        with open(swf_path, 'rb') as f:
            swf = f.read()
        interpreter = SWFInterpreter(swf)
        interpreter.extract_class('Foo')
        interpreter.extract_class('Bar')
        interpreter.extract_class('FooBar')
    do_common_assertions(_test_swf)


# Generated at 2022-06-12 19:39:17.297607
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swfi = SWFInterpreter()
    filename = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'test_data/test_swf_extract_class.swf')
    res = swfi.extract_class(filename)
    return res


# Generated at 2022-06-12 19:39:24.994572
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    test_file = io.BytesIO(b"""
      \x0a\x05\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00
    """)
    interpreter = _SWFInterpreter(test_file)

    class_info = _AVMClass(interpreter, b'\x01\x00\x01\x00\x01\x00\x01\x00\x01\x00\x01\x00', [], [], [])
    interpreter.extract_class(class_info, [])
    assert class_info.static_properties['prop1'] == 1
    assert class_info.static_properties['prop2'] == 2

# Generated at 2022-06-12 19:39:27.529370
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    """Test for method _ScopeDict.__repr__."""
    assert _ScopeDict(0) == {}, '__repr__()'
    assert _ScopeDict(1) == {'a': 1}, '__repr__()'


# Generated at 2022-06-12 19:39:36.484097
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    def assert_list_keys_equal(list1, list2):
        keys1 = set(x.keys() for x in list1)
        keys2 = set(x.keys() for x in list2)
        assert keys1 == keys2, '%r != %r' % (keys1, keys2)


# Generated at 2022-06-12 19:41:02.641214
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    def test_SWFInterpreter_extract_class_helper(in_, out_):
        swf = SWFInterpreter(in_)
        assert swf.extract_class() == out_

# Generated at 2022-06-12 19:41:05.078511
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter()
    swf.patch_function('some_method', lambda args: 'some_method called')
    assert swf.get_function('some_method')(None) == 'some_method called'


# Generated at 2022-06-12 19:41:15.737938
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open(os.path.join(SWF_DIR, 'as3-urldecode.swf'), 'rb') as swf_f:
        swf = swf_f.read()

    as_swf = AS_SWF(swf)
    interpreter = as_swf.interpreter
    interpreter.extract_class('URLLoaderDataFormat', {
        'objectEncoding': 3,
        'url': 'http://localhost/tests/get.php',
    })


# Generated at 2022-06-12 19:41:17.261432
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # TODO add unit test
    assert True


# Generated at 2022-06-12 19:41:20.432246
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interp = SWFInterpreter()
    assert isinstance(interp.string_cache, _StringCache)
    assert isinstance(interp.constant_pool, _ConstantPool)
    assert isinstance(interp.constant_strings, list)



# Generated at 2022-06-12 19:41:28.302463
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    from .swftags import TagDefineBinaryData

    # class TestClass extends Object
    # {
    #    private var a:int = 10;
    #    public function TestClass()
    #    {
    #        super();
    #    }
    #    public function get_a():int
    #    {
    #        return this.a;
    #    }
    #    public function set_a(value:int):int
    #    {
    #        this.a = value;
    #        return value;
    #    }
    # }


# Generated at 2022-06-12 19:41:33.731560
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    swf_path = os.path.join(here, 'files', 'test_getter.swf')
    with open(swf_path, 'rb') as f:
        swf = f.read()

    assert 'getter' in SWFInterpreter.extract_action_script(swf)



# Generated at 2022-06-12 19:41:37.123053
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter(BytesIO(test_data))
    swf_interpreter.extract_class(0)

# Generated at 2022-06-12 19:41:39.728009
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    f = SWFInterpreter(b'\x03\x00\x03\x00\x03\x00\x00\xff\x10\xff')
    assert f.extract_function('foo', 'bar') is undefined
# class SWFInfo

# Generated at 2022-06-12 19:41:46.317842
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    def extract_function(avm_class, method_name):
        for function_name, function in avm_class.method_pyfunctions.items():
            if function_name.startswith(method_name):
                try:
                    return function
                except:
                    pass


# Generated at 2022-06-12 19:43:57.954643
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-12 19:44:03.124576
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    class MySWFInterpreter(SWFInterpreter):
        """Dummy SWFInterpreter class that allows setting the file content"""
        def __init__(self, *args):
            self.init_content = None
            self.data = args
            self._read_data(args[0], args[1])

    # Initializing a SWFInterpreter with an empty file shall raise
    # an exception
    with pytest.raises(EmptySWFError):
        MySWFInterpreter('', '')

# Generated at 2022-06-12 19:44:09.819608
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import os
    import sys
    from .swfdecompiler import SWFDecompiler
    from .testutils import vstr, vint, vsint, vu30, vu8, vdouble, vu16, u8
    from .testutils import vbytes, test_swf, data_path

    def extract_class(swf_path, class_name):
        assert isinstance(swf_path, compat_str)
        assert isinstance(class_name, compat_str)
        with open(swf_path, 'rb') as f:
            s = SWFDecompiler(f)
            s.read()
            c = s.extract_class(class_name)
            return c


# Generated at 2022-06-12 19:44:17.899545
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    code = '\x10\x00\x0B\x00\x01\x00\x00\x00\x01\x00\x00\x00'
    code += '\x00\x00\x00\x08\x00\x03\x01\x00\x01\x00\x00\x00\x01\x00\x00\x00'
    code += '\x00\x00\x00\x08\x00\x03\x02\x00\x01\x00\x00\x00\x01\x00\x00\x00'
    code += '\x00\x00\x00\x04\x00\x03\x03\x00\x01'

    intp = SWFInterpreter()
    avm_

# Generated at 2022-06-12 19:44:20.017651
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    PATH = os.path.dirname(__file__)
    swf = SWFInterpreter(os.path.join(PATH, 'test.swf'))
    print(swf.extract_function('Main', 'myFunc'))

# Generated at 2022-06-12 19:44:23.414410
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter = SWFInterpreter.from_file(
        os.path.join(TEST_DIR, 'swf/use_get_property.swf'),
        {'stage': _AVMClass('Stage', {'stageWidth': 640, 'stageHeight': 480})})
    func = swf_interpreter.get_function(
        'Test', 'test_get_property')
    # TODO implement

# Generated at 2022-06-12 19:44:30.631059
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'test', 'swf', 'as3.swf'), 'rb'))
    avm_class = interpreter.extract_class('Main')
    assert avm_class.function_names == {
        'Main',
        'main',
    }
    assert avm_class.static_properties == {
        'Main': avm_class,
        'main': avm_class.pyfunctions['main'],
    }
    assert avm_class.static_method_names == {
        'main',
    }

# Generated at 2022-06-12 19:44:40.431254
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-12 19:44:46.752550
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interp = SWFInterpreter(io.BytesIO(b'\x0A\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'))
    assert interp.version == 10
    assert interp.file_length == 0
    assert interp.frame_size == [0, 0, 0, 0]
    assert interp.frame_rate == 0
    assert interp.frame_count == 0
    assert interp.constant_pool is None
    assert interp.constant_strings == []
    assert interp.constant_namespaces == []
    assert interp.multinames == []
    assert interp.methods == []
    assert interp.method_bodies == []
    assert interp.scripts == []

# Generated at 2022-06-12 19:44:53.299450
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swfdecompiler import read_swf
    from collections import namedtuple

    from .swfdecompiler import _SwfFile
    # We have to fake a SWFInterpreter for this to work
    class _FakeSWFInterpreter:
        def __init__(self, swf):
            self.constant_strings = []
            self.constant_ints = []
            self.constant_u30s = []
            self.multinames = []
            self.classes = []
            self.scripts = []
            self.method_bodies = []

            for s in swf.string_constants:
                self.constant_strings.append(s)

            for i in swf.integer_constants:
                self.constant_ints.append(i)
