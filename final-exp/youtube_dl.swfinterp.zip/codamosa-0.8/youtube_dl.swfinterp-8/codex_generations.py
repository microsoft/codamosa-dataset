

# Generated at 2022-06-12 19:36:30.045164
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    a1 = _SWFClass('avm2', 'AS3')
    a1.static_properties['_global'] = dict()
    a1.static_properties['_global']['a'] = 1
    a1.static_properties['_global']['b'] = 2
    a1.static_properties['_global']['c'] = 3


# Generated at 2022-06-12 19:36:41.523792
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class _AVMClass(object):
        def __init__(self, method_names):
            self.method_names = method_names


# Generated at 2022-06-12 19:36:46.127622
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import os
    from flash_video_extractor.flash_vars import flash_vars
    swfi = SWFInterpreter(os.path.join(os.path.dirname(__file__),
                                       'test_flash_vars.swf'))
    assert swfi.extract_class(flash_vars) is flash_vars
    assert flash_vars.static_properties['my_var'] == 'Hello, world!'


# Generated at 2022-06-12 19:36:52.890373
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io


# Generated at 2022-06-12 19:36:59.205522
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWF(os.path.join(
        os.path.dirname(__file__), 'swf', 'swfinterpreter.swf'),
        parse_actions=True)
    for tag in swf.tags:
        if getattr(tag, 'code', None) == 59:
            assert isinstance(tag, DoActionTag), tag
            assert tag.actions[0].code == 12, tag.actions[0]
            assert tag.actions[0].bytes == b'\n\x00', tag.actions[0].bytes
            assert tag.actions[1].code == 0x81, tag.actions[1]
            assert tag.actions[1].bytes == b'\x00\x01', tag.actions[1].bytes
            assert tag.actions[2].code == 0, tag.actions[2]

# Generated at 2022-06-12 19:37:07.785469
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()
    class MyClass(object):
        def __init__(self):
            pass
    class MySuperClass(object):
        def __init__(self):
            pass

    avm_class = _AVMClass(MyClass, MySuperClass)
    interpreter.avm_classes.append(avm_class)

    interpreter.extract_function(
        avm_class, 'x', _AVM2_CODE, _AVM2_REGISTER_COUNT)

    assert 'x' in avm_class.method_pyfunctions

# Generated at 2022-06-12 19:37:18.597331
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Unit test for method extract_class of class SWFInterpreter
    from . import _parse
    from . import tools
    from . import _extract_example_swfs

    # Test resource
    avm_root_class, abcdata_index, abcdata_data, swf_data = _extract_example_swfs.extract_example_swf('geo_startrek_920326_6.swf')

    # Test method
    interp = SWFInterpreter()
    avm_class = interp.extract_class(avm_root_class)

    # Test assertion

# Generated at 2022-06-12 19:37:27.626159
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    top_level = {
        'trace': lambda *args: None,
    }
    res = SWFInterpreter.patch_function(
        'trace', control_flow_graph=None,
        top_level=top_level)
    assert res is top_level['trace']
    def fake_flow(name, top, control_flow_graph):
        return [
            (lambda *args: None,
             {'a': 1, 'b': 5})
        ]
    res = SWFInterpreter.patch_function(
        'trace', control_flow_graph=fake_flow,
        top_level={})
    assert res is not None
    # TODO test it properly



# Generated at 2022-06-12 19:37:32.153138
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swftags import SWFTag
    from .swftag import DefineBinaryDataTag, DefineSceneAndFrameLabelDataTag

    class DummyTag(DefineBinaryDataTag):
        def __init__(self, raw_data):
            super(DummyTag, self).__init__(raw_data=raw_data)
            self.tag_type = 42
            self.tag = self

    class DummyLabelTag(DefineSceneAndFrameLabelDataTag):
        def __init__(self, raw_data):
            super(DummyLabelTag, self).__init__(raw_data=raw_data)
            self.tag_type = 43
            self.tag = self

    class DummySWF(object):
        def __init__(self, swf_interpreter):
            self.swf

# Generated at 2022-06-12 19:37:43.170253
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    c = _AVMClass(0, '')
    c.register_methods({'m1': 0})
    c.register_methods({'m2': 1})
    assert c.method_names == {'m1': 0, 'm2': 1}
    assert c.method_idxs == {0: 'm1', 1: 'm2'}



# _AVM2Context, a stateful interface to an AVM2 interpreter.
#
# This, supported by _AVMClass and _ScopeDict, implements a very
# basic AVM2 interpreter.
#
# TODO:
# - Implement proper garbage collection
#   - Currently, all constants and all objects ever created live forever.
#     This should be changed so that only those constants and objects
#     that are currently reachable from the scope chain live on.
#

# Generated at 2022-06-12 19:39:11.078793
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .parse_swf import parse_swf
    p = parse_swf(open(
        'misc/swftest/misc-actions.swf', 'rb').read())
    swf_data = p['swf_data']
    code = swf_data['abc_data']['methods'][0]['body']['code']
    coder = io.BytesIO(code)
    multinames = p['swf_data']['abc_data']['multinames']

    interpreter = SWFInterpreter(multinames)
    interpreter.extract_function(None, '_0_0', coder, [])


# TODO: Get rid of this
_builtin_classes = {}


# Generated at 2022-06-12 19:39:20.969384
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()

# Generated at 2022-06-12 19:39:29.253101
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class _MockAVMClass(object):
        def __init__(self):
            self.method_pyfunctions = {}
            self.method_names = []
            self.variables = {}
    _aclass = _MockAVMClass()

    class _MockMultiname(object):
        def __init__(self, name):
            self.name = name
    _mname = _MockMultiname('mname')

    si = SWFInterpreter()
    si.multinames = [_mname]
    si.constant_strings = ['mname']

    def f(_):
        pass

    si.patch_function(_aclass, f, 0)
    assert 'mname' in _aclass.method_names
    assert 'mname' in _aclass.method_pyfunctions

# Generated at 2022-06-12 19:39:31.547134
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(io.BytesIO(b'CWS'), '')
    swf.handle_parsing_error('test error')
    assert swf.warnings[0][0] == 'test error'


# Generated at 2022-06-12 19:39:34.839053
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(path_to_test_file_data, 'rb'))
    res = swf.extract_class('requestAds', '__AVE_Flash__.default')
    assert isinstance(res, _AVMClass)
    assert res.name == 'requestAds'
    assert len(list(res.methods)) == 14

# Generated at 2022-06-12 19:39:44.746143
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:39:52.819627
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    d = dict()
    d['this'] = dict()
    d['this']['m'] = lambda x: x
    d['this']['p'] = 5
    d['this']['is_in_scopes'] = True
    d['this']['is_not_in_scopes'] = False

# Generated at 2022-06-12 19:40:02.013621
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    def _read_variable_name(coder):
        length = _read_byte(coder)
        return coder.read(length).decode('utf-8')


# Generated at 2022-06-12 19:40:11.322803
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import tags
    with open('tests/test_inf.swf', 'rb') as f:
        swf = tags.SWF(f)
    interpreter = SWFInterpreter(swf)
    assert interpreter.constant_pool == [
        'Object', 'MovieClip', 'get_currentframe', 'currentframe',
        'gotoAndStop', 'frame', 'gotoAndPlay', 'nextFrame', 'prevFrame',
        'stop', 'play', 'stop_drag', 'start_drag', 'stop_loop', 'start_loop',
        'get_framesloaded', 'framesloaded', 'get_totalframes', 'totalframes',
        'get_playheadtime', 'playheadtime', 'get_fps', 'fps']

# Generated at 2022-06-12 19:40:16.251123
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    print('Testing SWFInterpreter.extract_class')
    with open(testdata_path('swfinterpreter', 'test1.abc'), 'rb') as f:
        abc_data = f.read()
    swfinterpreter = SWFInterpreter(abc_data)

    avm_class = swfinterpreter.extract_class('TestClass')
    assert avm_class.name == 'TestClass'
    assert avm_class.static_properties['static_member'] == 'static'

# Generated at 2022-06-12 19:42:35.299337
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    parser = _SWFParser(None)
    interpreter = interpreter_instance = SWFInterpreter(parser)

    def get_swf(name):
        filename = os.path.join(os.path.dirname(__file__), 'swfs', name)
        with open(filename, 'rb') as f:
            return f.read()

    def parse_tags(tags):
        parser = _SWFParser(None)
        parser.tags = tags
        parser.parse_all_tags()
        return parser

    # Test for swf_version
    swf_version = 5
    assert interpreter.swf_version == swf_version

    # Test for parse_swf_file
    data = get_swf('crash.swf')
    parsed_tags = parse_tags(data)

# Generated at 2022-06-12 19:42:44.251460
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swfinterpreter = SWFInterpreter()
    swf_class = _DummySWFClass()
    avm_class = swfinterpreter.extract_class(swf_class)
    assert isinstance(avm_class, _AVMClass)
    assert avm_class.instance_properties == {
        '$version': 'MAC 10,0,32,18',
        '$name': 'Shockwave Flash',
    }
    assert isinstance(avm_class.variables['global'], _ScopeDict)
    assert avm_class.variables['global'].avm_class == avm_class

    assert avm_class.make_object().get('flashVars', undefined) == 'foo=bar'


# Generated at 2022-06-12 19:42:52.661406
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class AVMClass(object):
        def __init__(self):
            self.variables = {
                'String': StringClass,
                'undefined': undefined,
            }
    avm_class = AVMClass()

    class SWFClass(object):
        def __init__(self):
            self.constant_strings = ['str']
            self.multinames = [
                _Multiname(['length']),
                'str',
            ]
            self.method_names = {'f'}

    swf_class = SWFClass()


# Generated at 2022-06-12 19:43:02.864267
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:43:08.809095
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-12 19:43:13.978532
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open(os.path.join(MODULE_TESTS_DIR, 'flash/videoplayer.swf'), 'rb') as f:
        swf = SWF(f)
    interpreter = SWFInterpreter(swf)
    interpreter.extract_class('videoLoader')
    return True

# Generated at 2022-06-12 19:43:18.438863
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .swfdecompiler import SWFDecompiler
    in_stream = BytesIO(open('tests/testdata/a.swf', 'rb').read())
    swf_decompiler = SWFDecompiler(in_stream)
    swf_decompiler.extract_scripts()
    avm_class = swf_decompiler.avm2_scripts[0][1]
    si = SWFInterpreter(swf_decompiler)
    si.extract_function(avm_class, 'f_1')
    func = avm_class.method_pyfunctions['f_1']
    assert func() == 3


# Generated at 2022-06-12 19:43:23.593387
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    with open('testsuite/_testdata/swfinterpreter/exampleMethod.swf', 'rb') as f:
        swf = SWF(f)
    swfin = swf.tags[1]
    avm = swfin.avm2
    res = avm.extract_function('Class', 'method')
    res(['13', '37'])


# Generated at 2022-06-12 19:43:31.155555
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()
    interpreter.parse('xxx\000\000\000\001\000\002\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\002\000\001\000\000\000\000\000\002null\000')
    assert interpreter.extract_string(0) == 'xxx'
    assert interpreter.extract_number(0) == 0
    interpreter.extract_function(interpreter.instance_info[0].class_info, 'null')

# Class _FlashVar
# This class was used to implement the getFlashVars() method in class AVMClass_Object
# It is no longer used

# Generated at 2022-06-12 19:43:37.720504
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    class TestSWFInterpreter(SWFInterpreter):
        def __init__(self, *args, **kwargs):
            super(TestSWFInterpreter, self).__init__(
                *args, **kwargs)
            self.constant_strings.append('CONSTANT_STRING')
            self.multinames.append('multiname')

    test_code = b'\x30\x00\x2c\x01'  # pushstring, pushstring
    test_code += b'\x0f'  # add
    test_code += b'\x1c'  # returnvalue

    interpreter = TestSWFInterpreter()
    avm_class = _AvmClass()
    interpreter.extract_function(avm_class, 'some_func', test_code)
   