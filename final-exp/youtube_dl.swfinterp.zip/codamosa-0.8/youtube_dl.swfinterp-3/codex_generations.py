

# Generated at 2022-06-12 19:36:01.061464
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from .flash_extractor import (
        _AVMClass,
    )
    self0 = _AVMClass('', '')
    methods0 = {}
    return_value_1 = self0.register_methods(methods0)
    return_value_2 = self0.register_methods({})
    assert (return_value_1 is None)
    assert (return_value_2 is None)
test__AVMClass_register_methods()


# Generated at 2022-06-12 19:36:04.883328
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    from .test_swf_extract import _swf_testdata
    avm = _AVMClass(0, 'TestClass')
    avm.register_methods({'method1': 1, 'method2': 2})
    assert avm.method_names == {'method1': 1, 'method2': 2}, ('get_methods() should return {1: "method1", 2: "method2"}')
    assert avm.method_idxs == {1: 'method1', 2: 'method2'}, ('get_method_idxs() should return {1: "method1", 2: "method2"}')
    assert avm.methods == {}, ('get_methods() should return {}')
    assert avm.method_pyfunctions == {}, ('get_method_pyfunctions() should return {}')
   

# Generated at 2022-06-12 19:36:07.864635
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    a = _AVMClass('for_test', 0)
    a.register_methods({'a': 1})
    assert a.method_names['a'] == 1
    assert a.method_idxs[1] == 'a'
    a.register_methods({'b': 2})
    assert a.method_names['a'] == 1
    assert a.method_idxs[1] == 'a'
    assert a.method_names['b'] == 2
    assert a.method_idxs[2] == 'b'


# Generated at 2022-06-12 19:36:19.085842
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    obj = SWFInterpreter()

# Generated at 2022-06-12 19:36:23.896253
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_file = io.BytesIO(
        compat_urllib_request.urlopen(
            'https://ubistatic-a.akamaihd.net/flash/2.6/videoPlayer/preloader/videoPlayerPreloader.swf'
        ).read())
    parser = _SWFParser(swf_file)
    interpreter = SWFInterpreter(parser)
    del swf_file
    del parser



# Generated at 2022-06-12 19:36:25.102632
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    inst = _AVMClass('name_idx', 'name')
    inst.register_methods(methods={'m1': 1, 'm2': 2})



# Generated at 2022-06-12 19:36:35.929993
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:36:44.588203
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import os
    from io import BytesIO

    TESTS_ROOT = os.path.dirname(os.path.abspath(__file__))

    with open(os.path.join(TESTS_ROOT, 'as3-fuse.swf'), 'rb') as f:
        swf = f.read()

    with open(os.path.join(TESTS_ROOT, 'as3-fuse-expect.py'), 'rb') as f:
        expected_func_python = f.read().decode('utf-8')

    interpreter = SWFInterpreter(BytesIO(swf))
    func = interpreter.extract_function(interpreter.classes['Dispatcher'], 'getInstance')
    func_python = inspect.getsource(func).strip()
    assert func_

# Generated at 2022-06-12 19:36:46.675810
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    test_obj = _AVMClass('name_idx', 'name', None)

    test_obj.register_methods({'name': 'idx'}) # No error (exception is raised)



# Generated at 2022-06-12 19:36:53.378277
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .lib import swfinterp_test

    avm_interpreter = SWFInterpreter.from_file(swfinterp_test)

    avm_class = None
    for a in avm_interpreter.classes:
        if a.static_properties['className'] == 'swfinterp_test':
            avm_class = a
            break

    assert avm_class is not None

    # test that the class has been created
    assert 'swfinterp_test' in avm_interpreter.global_object
    test_class = avm_interpreter.global_object['swfinterp_test']

    # test that the methods have been created
    assert test_string_method in test_class.method_pyfunctions
    assert test_number_method in test_class.method

# Generated at 2022-06-12 19:37:51.313397
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-12 19:38:00.131246
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    def make_class(name, super_, vars_):
        class cls(object):
            def __init__(self):
                self.name = name
                self._super = super_
                self.variables = vars_
        return cls()

    def make_multiname(name):
        class Multiname(object):
            def __init__(self, name):
                self.name = name
        return Multiname(name)

    def make_method(name, traits):
        method = {}
        method['name'] = name
        method['traits'] = traits
        return method

    def make_method_body(code):
        body = {}
        body['code'] = code
        body['max_stack'] = 10
        body['max_regs'] = 1

# Generated at 2022-06-12 19:38:07.475782
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    with open('issue_number_1399.swf', 'rb') as infile:
        swf = BytesIO(infile.read())
    swf = SWFInterpreter(swf)
    assert swf
    assert swf.swf_version == 16
    assert len(swf.constant_strings) == 9
    assert len(swf.multinames) == 16
    assert len(swf.constant_int_pool) == 1
    ci_pool = swf.constant_int_pool
    assert ci_pool[0] == [0, 1]
    assert len(swf.constant_uint_pool) == 1
    cui_pool = swf.constant_uint_pool

# Generated at 2022-06-12 19:38:13.377948
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-12 19:38:22.820974
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:38:30.476379
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter()

    assert interpreter.version == 6
    assert interpreter.file_length == 20
    assert interpreter.frame_size == Rect(
        numbits=5, xmin=0, xmax=320, ymin=0, ymax=240)

# Generated at 2022-06-12 19:38:32.443024
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interp = SWFInterpreter()

    @interp.patch_function
    def test_patch_function(a, b):
        return a + b

    assert test_patch_function(1, 2) == 3



# Generated at 2022-06-12 19:38:33.278936
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert repr(_ScopeDict(None)) == 'None__Scope({})'



# Generated at 2022-06-12 19:38:38.375296
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    verifier = VerifySWF()
    avm2 = SWFInterpreter()

    # Properly encoded SWF file
    encoded_swf = verifier.load_resource('SWFUnitTest_test_SWFInterpreter_extract_function.swf')
    swf_string = zlib.decompress(encoded_swf)

    avm2.load_from_string(swf_string)
    class_decl = avm2.scripts['SWFUnitTestClass']

    # This should not raise any exception
    func = class_decl.method_pyfunctions['method1']

    assert func([undefined]) == undefined
    assert func([10, 2]) == 5
    assert func(['']) == ''
    assert func(['abc']) == 'cba'

# Generated at 2022-06-12 19:38:45.806335
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.parse('tests/swf/7.swf')
    swf_interpreter.patch_function('YouTubePlugin.NetConnection.connect', 4)
    assert swf_interpreter.global_vars['YouTubePlugin'].get(
        'NetConnection').get('connect').__name__ == 'patched'
    assert len(swf_interpreter.global_vars['YouTubePlugin'].get(
        'NetConnection').get('connect').original_instructions) == 4



# Generated at 2022-06-12 19:39:47.308247
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:39:53.980142
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    """Tests the method extract_function of class SWFInterpreter"""
    swf = SWFInterpreter()
    swf.tags = [
        SWFDoABC(abc_data=b'version 1 2 abc\n'
                 b'scope_count 1\n'
                 b'method_count 1\n'
                 b'constant_count 1\n'
                 b'class_count 1\n'
                 b'method 0:\n'
                 b'  0 pushbyte 42\n'
                 b'  3 returns\n'
                 b'end\n'
                 b'end\n')
    ]
    method_idx = 0
    method_name = 'func'
    abc_class_name = 'abc'
    expected_res = 42


# Generated at 2022-06-12 19:40:03.011761
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swfread import SWF, SWFReadError

    # Taken from http://www.adobe.com/content/dam/Adobe/en/devnet/swf/pdf/swf_file_format_spec_v10.pdf
    swf_file_path = 'tests/swf/simple_button.swf'
    with open(swf_file_path, 'rb') as swf_file:
        swf = SWF(swf_file)
        assert swf.header.nbits == 16
        assert swf.header.width == 18
        assert swf.header.height == 18
        tag = swf.tags[1]
        assert tag.tag_type == 82
        assert tag.tag_len == 69

# Generated at 2022-06-12 19:40:12.446204
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompiler import SWFDecompiler
    from .swfdecompiler import SWFData
    from .swfdecompiler import SWFTagTypes
    import base64
    import io

# Generated at 2022-06-12 19:40:15.668466
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter = SWFInterpreter(
        AVM2(SWF(io.BytesIO(b'\x00'))))
    patch_function = swf_interpreter.patch_function
    SWFInterpreter._read_byte = lambda x: 0
    assert patch_function(None, None, None) is None

# Generated at 2022-06-12 19:40:20.815079
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-12 19:40:26.278232
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import _build_tests_swf_interpreter
    for test_case in _build_tests_swf_interpreter.test_cases:
        swf_interpreter = SWFInterpreter(test_case.filepath, test_case.varname)
        assert swf_interpreter.constant_ints == test_case.constant_ints
        assert swf_interpreter.constant_doubles == test_case.constant_doubles
        assert swf_interpreter.constant_strings == test_case.constant_strings
        assert swf_interpreter.classes == test_case.classes
        assert swf_interpreter.method_bodies == test_case.method_bodies

        # Test method 'get_instance_method_pyfunction'

# Generated at 2022-06-12 19:40:28.468094
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert SWFInterpreter(b'')
    assert SWFInterpreter(b'F')
    assert SWFInterpreter(b'FWS')

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv[1:]))

# Generated at 2022-06-12 19:40:34.651671
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm_interp = SWFInterpreter([], [], [], [], [], [], [], [], {})

    def _extract_function(code):
        coder = compat_BytesIO(code)
        return avm_interp._extract_function(
            coder, 'test_function', [], [], [], {}, {}, {})

    # The code below implements a function
    # function () {
    #    return undefined;
    # }
    resfunc = _extract_function(
        b'\x02\x00\x01'
        b'\x00\x00\x00\x01'  # 1 action in ActionEnd
        b'\x06'  # pushundefined
        b'\x1c'
        )
    assert resfunc() is undefined

   

# Generated at 2022-06-12 19:40:40.876846
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import struct
    import io
    import os
    import hashlib
    import random
    import string
    def rand_str(length):
        return ''.join(random.choice(string.ascii_lowercase) for _ in range(length))

    class SWFVideo(object):
        def __init__(self, title):
            self.title = title

        def patch_function(self, name, func):
            setattr(self, name, func)

    class SWFTag(object):
        def __init__(self, tag, xmin=0, xmax=0, ymin=0, ymax=0, frame_rate=0, frame_count=0):
            self.tag = tag
            self.xmin = xmin
            self.xmax = xmax
            self.ymin = ymin
           

# Generated at 2022-06-12 19:43:06.465046
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(
        swf_content = _TEST_SWF_FILE.read_bytes())
    for avm_class in swf.classes.values():
        for func_name in avm_class.method_pyfunctions:
            if func_name == '_as_class':
                continue
            if func_name == '_as_class_local':
                continue
            if func_name == '_as_class_global':
                continue
            swf.extract_function(avm_class, func_name)
    print('test_SWFInterpreter_extract_function - ok')

# class TestAVMProperty

# Generated at 2022-06-12 19:43:16.869929
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Initialize the interpreter
    si = SWFInterpreter()
    # extract_function, part 1
    swf_class = _SWFClass(
        '', '',
        None,
        None,
        (
            {},
            {
                '+': _BuiltinFunction('+', lambda args: args[0] + args[1]),
                '*': _BuiltinFunction('*', lambda args: args[0] * args[1]),
            },
            {
                'add': _SWFFunction('add', [], [
                    ('getlocal_0', None), ('getlocal_1', None),
                    ('add', None), ('returnvalue', None),
                ]),
            },
        )
    )
    name = 'add'

# Generated at 2022-06-12 19:43:25.839345
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import nose.tools

    def assert_svg_equal(svg1, svg2):
        import xml.dom.minidom
        def format_dom(dom):
            import xml.dom.minidom
            return xml.dom.minidom.parseString(dom).toprettyxml()

        nose.tools.assert_equal(format_dom(svg1), format_dom(svg2))

    with open('test/resources/rect-multiname-private.swf', 'rb') as f:
        swf = f.read()
    swf_interpreter = SWFInterpreter(swf, parse_svg=True)


# Generated at 2022-06-12 19:43:33.113009
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(io.BytesIO(b'\x00\x00'))
    swf.register_class(_AVMClass(
        'test_SWFInterpreter_extract_function', [], {},
        io.BytesIO(b'\x01\x00\x00\x00'),
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0))
    swf.extract_function(swf.get_class('test_SWFInterpreter_extract_function'), 'test_function')
# Test SWFInterpreter_extract_function
test_SWFInterpreter_extract_function()

# Generated at 2022-06-12 19:43:39.251203
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .flash_address import InputFile
    from .flash_address import convert_to_python_function
    from .flash_address import LazyFunction
    from .flash_address import FlashGlobalProxy
    from .flash_address import FlashError

    with open(get_test_data_filepath('swf/v_01.swf'), 'rb') as f:
        data = f.read()
    ifr = InputFile(data)
    ifr.seek(8)
    file_version = ifr.read_u16()
    if file_version >= 6:
        raise NotImplementedError('Unsupported SWF version %d' % file_version)
    swfinterpreter = SWFInterpreter(ifr, data)


# Generated at 2022-06-12 19:43:49.988428
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io
    import struct
    avm_class = _AVMClass(variables={})
    s = io.BytesIO()
    swf = SWFInterpreter(s, None)
    swf.constant_strings = ['foo', 'bar', 'baz']
    swf.multinames = [None] * len(swf.constant_strings)
    swf.multinames[0] = _Multiname(None, [])
    swf.multinames[1] = _Multiname(None, [])
    swf.multinames[2] = _Multiname(None, [])

# Generated at 2022-06-12 19:43:57.954215
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Test extract_function() method of SWFInterpreter class
    import abc
    from collections import namedtuple
    
    test_file = 'tests/files/swf_interpreter_extract_function.swf'
    interp = SWFInterpreter.load(test_file)
    
    # The class defining the functions to test
    TestClass = namedtuple('TestClass', 'variables methods '
                           'method_names static_properties')

    def noop_method():
        pass
    
    # The class defining the functions to test
    TestClass = namedtuple('TestClass', 'variables methods method_names '
                           'static_properties')
    
    def get_x_method(args):
        assert len(args) == 0
        self = args[0]

# Generated at 2022-06-12 19:44:02.387042
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = _SWFInterpreter()
    interpreter.extract_class({}, 'TestClass')


if __name__ == '__main__':
    test_SWFInterpreter_extract_class()
# # python-edgar (c) 2015-2017 UPSIDE DOWN LABS LLC.
# # This program is free software: you can redistribute it and/or modify
# # it under the terms of the GNU General Public License as published by
# # the Free Software Foundation, either version 3 of the License, or
# # (at your option) any later version.
# # This program is distributed in the hope that it will be useful,
# # but WITHOUT ANY WARRANTY; without even the implied warranty of
# # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# # GNU General Public License for more details.
#

# Generated at 2022-06-12 19:44:09.139855
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import os
    import sys
    from ._abc_parser import ABCParser

    if sys.gettrace() is None:
        sys.settrace(lambda *args: None)

    def roundtrip(val):
        coder = io.BytesIO()
        SWFInterpreter.code_value(coder, val)
        coder.seek(0)
        return SWFInterpreter.decode_value(coder)

    def make_function(
            code=None,
            max_regs=None,
            params=None,
            return_type=None,
            type_sig=None):
        coder = io.BytesIO()
        if type_sig:
            _write_byte(coder, 64)
            _write_byte(coder, 1)
        else:
            _write_byte

# Generated at 2022-06-12 19:44:14.530411
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open(test_utils.get_test_file('test.swf')) as f:
        swf = f.read()
    si = SWFInterpreter(swf)
    assert 'TestInterface' in si.classes
    assert 'TestClass' in si.classes
    assert not si.classes['TestInterface'].is_concrete
    assert si.classes['TestClass'].is_concrete

    assert 'TestInterface' not in si.global_scope
    assert 'TestClass' not in si.global_scope
    assert 'TestObj' not in si.global_scope
    assert 'TestClass' in si.classes
    assert 'TestInterface' in si.classes
    assert 'TestObj' in si.classes
    assert 'TestObj' in si.classes['TestClass'].variables