

# Generated at 2022-06-12 19:36:42.366074
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = _tests.swf
    assert len(swf.tags) == 38
    class_ = swf.find_class('Com')
    assert class_ is not None
    # This call is the one we are really testing
    interpreter.patch_function(class_)
    assert class_.method_pyfunctions['__construct'] is not None


# Generated at 2022-06-12 19:36:49.869698
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf = SWFInterpreter(
        """
        var a = 0x12345;
        var b = 0x6789;
        trace(a + b);
        """
    )

    def mocktrace(arg):
        assert arg == 0x79bd
        swf.trace_output.append(arg)
        return arg

    swf.patch_function('trace', mocktrace)
    swf.call_method('evaluate', [])

    assert swf.trace_output == [0x79bd]

# Class for test method patch_function of class SWFInterpreter

# Generated at 2022-06-12 19:36:56.105694
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swf import _load_swf
    from .swf import _SWFDummyClass
    from .swf import _SWFDummyObject
    from .swf import _SWFDummyFunction
    from .swf import _swf_dump
    from .tags import TagDoABC
    from .tags import TagDoABCDefine
    from .tags import TagDefineSprite
    from .tags import TagPlaceObject
    from .tags import TagPlaceObject2
    # Create a SWF file

# Generated at 2022-06-12 19:37:00.877043
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    c = SWFInterpreter(None)
    c.version = 10
    c.constant_strings = ['someString', 'someUserAgent']

    # initproperty
    c.ops = [
        'initproperty',
        'pushstring',
        'setproperty',
        'returnvoid'
    ]
    c.operands = [
        0,
        0,
        1,
        0,
    ]
    c.constant_strings = ['someName', 'someValue']
    m = Multiname([3, 'someName'])
    c.multinames = [m]
    methods = [
        c.extract_function(
            'someMethodName', [],
            {'prop': 'value'}),
    ]
    assert methods[0]({}) == None

# Generated at 2022-06-12 19:37:03.736985
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter('foo.swf')
    interpreter.extract_function(interpreter.root_class, 'log')

# Generated at 2022-06-12 19:37:04.930815
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    return True

# Generated at 2022-06-12 19:37:16.341052
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .tag_classdef import TagDefineBinaryData
    from .swf import SWF
    from .flash_proxy import ActionScriptVirtualMachine

    avm = ActionScriptVirtualMachine()

# Generated at 2022-06-12 19:37:21.903770
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert SWFInterpreter(0)

    fileobj = io.BytesIO(b'\x53\x57\x46\x00\x01\x00\x00\x00')
    assert SWFInterpreter(fileobj)

    interp = SWFInterpreter(fileobj, 'flash 9.0 r123')
    assert interp.flash_version == '9.0 r123'


# Generated at 2022-06-12 19:37:30.868445
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter(open(testdata_path('interpreter.swf'), 'rb'))
    avm_class = swf.extract_class('Test')
    assert avm_class.static_properties['publicStaticInt'] == 0
    assert avm_class.static_properties['publicStaticString'] == 'default'
    assert avm_class.static_properties['publicStaticArray'] == []
    assert avm_class.static_properties['publicStaticBool'] is False
    assert avm_class.static_properties['publicStaticObject'] == {}

    func_add = swf.extract_function(avm_class, 'add')
    assert func_add([1, 2]) == 3
    assert func_add([5, -2]) == 3

# Generated at 2022-06-12 19:37:38.744411
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()
    interpreter.constant_strings = ['foo', 'bar', 'baz']

    interpreter.multinames = [
        None, 'baz', 'bar', 'foo',
    ]

# Generated at 2022-06-12 19:38:42.892923
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter(None)

    # The fact of the function is that it does not use any information
    # from the object.  So, we pass anything as the object
    def testfunc(args):
        return len(args)

    pyfunc = interpreter.extract_function(None, testfunc)

    assert pyfunc([1, 2, 3]) == 3



# Generated at 2022-06-12 19:38:49.566738
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Borrow the test fixture from test_read_swf
    path = os.path.join(TEST_DATA_ROOT, 'flash/swfversion06.swf')
    with open(path, 'rb') as f:
        interp = SWFInterpreter(f, verbose=True)
        assert interp.swf.version == 6
        assert interp.swf.file_len == 6168
        assert interp.swf.frame_size.rect == Rect(0, 0, 4984, 16)
        assert interp.swf.frame_rate == 24
        assert interp.swf.frame_count == 1

        avm_class = interp.extract_class(0x0000)
        assert avm_class.version == '7,0,14,0'
        assert avm

# Generated at 2022-06-12 19:38:54.627411
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:39:02.188202
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    """
    Test method extract_function
    """
    from io import BytesIO
    from os.path import join as path_join
    from srt_tools.helper import resource_path as ResourcePath
    from srt_tools.SWFInterpreter import SWFInterpreter
    from srt_tools.SWFUnitTest import SWFUnitTest

    # Load the test data
    data_path = ResourcePath(
        path_join('SWFInterpreter', 'test_data'))

# Generated at 2022-06-12 19:39:11.168819
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    fileshortname = 'PlayerProductInstall'
    filename = os.path.join(os.path.dirname(
        unittest.__file__), 'testdata', fileshortname + '.swf')

    with io.open(filename, 'rb') as testf:
        data = testf.read()
    r = SWFInterpreter(data)
    r.decode()
    avm_class = r.avm_classes['com.adobe.flash.installer.PlayerDownloader']

    fields = avm_class.variables

# Generated at 2022-06-12 19:39:21.005449
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = io.BytesIO(binascii.a2b_hex(b'0060000000001000000000002301'))
    with open('test_SWFInterpreter_extract_function.swf', 'wb') as f:
        f.write(swf.read())
    swf.seek(0)
    interpreter = SWFInterpreter(swf)

    assert repr(interpreter.extract_function(interpreter.avm_class, 'getLength')) == '<bound method SWFInterpreter.extract_function.<locals>.decoder of <__main__.SWFInterpreter object at 0x7fb3dbf9b780>>'

# Generated at 2022-06-12 19:39:26.017767
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .utils import byteify


# Generated at 2022-06-12 19:39:35.819006
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    print('Testing SWFInterpreter.extract_class...', end='')
    from . import obj_abc
    from .avm2_abc_parser import parse_mpy

    abc_data = obj_abc.AbcFile.deserialize(io.BytesIO(obj_abc.abc_data))
    avm_class = SWFInterpreter().extract_class(abc_data, 'Obj')

    mpy = parse_mpy(obj_abc.mpy_data)

    assert len(avm_class.static_properties) == len(mpy.static_properties)
    assert len(avm_class.instance_properties) == len(mpy.instance_properties)


# Generated at 2022-06-12 19:39:42.174661
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:39:48.018157
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    Import('extract_avm').load_public_functions(globals())
    avm_source = """
        var a = 5;
        var b = a + 6;
        trace(a);
        trace(b);
    """
    avm_class = load_avm(avm_source)
    assert avm_class.variables['a'] == 5
    assert avm_class.variables['b'] == 11

# Generated at 2022-06-12 19:41:42.253718
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    si = SWFInterpreter()
    si.parse_swf_data(test_swf_data_0)
    si.extract_function(si.global_avm_class, 'test')
    return si



# Generated at 2022-06-12 19:41:44.978769
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter()
    assert swf_interpreter.avm_version == 12
    assert swf_interpreter.abc_version == 46
    assert swf_interpreter.avm_name == 'AVM2'


# Generated at 2022-06-12 19:41:51.273014
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class TestAVMClass(object):
        def __init__(self, class_name, variables, traits_info, super_name, constants):
            self.class_name = class_name
            self.variables = variables
            self.traits_info = traits_info
            self.super_name = super_name
            self.constants = constants

    test_avm_class = TestAVMClass('Class1',
                                  {'a': None, 'b': 2},
                                  [],
                                  'Object1',
                                  {0: 1, 1: 2})

    test_interpreter = _SWFInterpreter()

    assert test_interpreter.extract_class(test_avm_class) is None


# Generated at 2022-06-12 19:41:52.986938
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    my_interpreter = SWFInterpreter()
    my_interpreter.initialize([], None, None)
    assert isinstance(my_interpreter, SWFInterpreter)


# Generated at 2022-06-12 19:42:02.252678
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Create a SWFInterpreter object
    # Load a sample file
    with open('../../test/flash/class_test1.swf', 'rb') as in_file:
        swf = SWF(in_file)

    # Create the interpreter
    interpreter = SWFInterpreter(swf)

    # Extract the class
    class_name = 'Class1'
    avm_class = interpreter.extract_class(class_name)
    assert set(avm_class.implements) == {'ClassInterface'}
    assert set(avm_class.static_properties) == {'static_prop'}
    assert set(avm_class.method_names) == {'func1', 'func2', 'func3'}

    # Test the functions

# Generated at 2022-06-12 19:42:07.970724
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:42:16.469183
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:42:19.779782
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    filepath = os.path.join(
        os.path.dirname(__file__),
        'testdata',
        'test-swf-extract-class.swf')
    with open(filepath, 'rb') as f:
        swf = SWFInterpreter(f)



# Generated at 2022-06-12 19:42:27.235625
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open('flash_test.swf', 'rb') as f:
        raw = f.read()
    d = SWFInterpreter()
    d.read(raw)
    classes = d.extract_classes()
    assert len(classes) == 3
    main_class = classes['Main']

    # Test Main.get_functions_names
    func_names = main_class.get_functions_names()
    assert len(func_names) == 10

    # Test Main.get_variables_names
    var_names = main_class.get_variables_names()
    assert len(var_names) == 2

    # Test Main.get_constant_strings
    strings = main_class.get_constant_strings()
    assert len(strings) == 2

# Generated at 2022-06-12 19:42:35.416606
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import io
    import shutil
    test_data_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'test_data')
    if not os.path.exists(test_data_path):
        os.makedirs(test_data_path)
    for file_name in ['test1.swf', 'test2.swf']:
        test_swf_path = os.path.join(
            test_data_path, file_name)
        if not os.path.exists(test_swf_path):
            shutil.copy2(os.path.join('flashplayer', file_name), test_swf_path)
        with open(test_swf_path, 'rb') as f:
            swfdata = f