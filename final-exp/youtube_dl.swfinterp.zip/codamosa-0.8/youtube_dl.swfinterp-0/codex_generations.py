

# Generated at 2022-06-12 19:36:58.453150
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:37:10.203425
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(open(
        os.path.join(os.path.dirname(__file__), '..', 'test', 'samples',
                     'assets', 'interpreter', 'combined.swf'), 'rb'))
    avm_class = swf.classes['com.example.combined']
    avm_class.variables['test_int'] = 42

    f = swf.extract_function(avm_class, 'test_static_method')
    assert f() == 1337

    f = swf.extract_function(avm_class, 'test_static_method_with_param')
    assert f(100) == 101

    f = swf.extract_function(avm_class, 'test_static_method_with_optional_param')

# Generated at 2022-06-12 19:37:14.706386
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swfi = SWFInterpreter()
    swfi.extract_function('TestClass', 'testfunc')
# class SWFInterpreter (end)


# class _DumpAVM2 (begin)
# For debugging

# Generated at 2022-06-12 19:37:21.847917
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import io
    import unittest

    from .packbits import decompress


# Generated at 2022-06-12 19:37:30.880070
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    extract_class = SWFInterpreter.extract_class.im_func
    metadata = {}
    extract_class(
        None, None, {}, {}, {}, {}, {}, {}, {}, {}, {}, {},
        [0, 0, 0, 1], {0: _ABC_MethodInfo(
            0, 0, 0, 1, 1, 0x1, 0x2, [], [0], [], [])}, {}, {},
        metadata) == metadata
    metadata = {
        0x2: [
            {
                'key': 'FLV::Metadata::TITLE',
                'value': 'title',
            },
            {
                'key': 'FLV::Metadata::HAS_KEYFRAMES',
                'value': True,
            },
        ]
    }
    extract_

# Generated at 2022-06-12 19:37:36.341822
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert repr(_ScopeDict(None)) == '__Scope({})'

_AVM_TYPE_NUMBER = 2
_AVM_TYPE_STRING = 10
_AVM_TYPE_OBJECT = 12

_AVM_TYPE_NAMES = {
    _AVM_TYPE_NUMBER: 'NUMBER',
    _AVM_TYPE_STRING: 'STRING',
    _AVM_TYPE_OBJECT: 'OBJECT',
}



# Generated at 2022-06-12 19:37:44.725883
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-12 19:37:51.860227
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:38:00.751478
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:38:08.069090
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import unittest
    class TestSWFInterpreter(unittest.TestCase):
        def test_extract_class(self):
            class _Tester(object):
                def __init__(self, avm_class):
                    self.avm_class = avm_class
            myswf = _Tester(SWFInterpreter().extract_class(
                _SWF.open('tests/swf/button.swf'), 'Button'))
            self.assertIsInstance(myswf.avm_class.variables, _ScopeDict)
            self.assertEqual(6, len(myswf.avm_class.variables))
            self.assertEqual(6, len(myswf.avm_class.decoded_fields))

# Generated at 2022-06-12 19:39:15.004946
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():

    # Collect tests into a test suite.
    from unittest import TestSuite, makeSuite
    suite = TestSuite()
    suite.addTest(makeSuite(TestSWFInterpreter))

    import sys
    import doctest

    # Setup a test runner, pass it your suite and run it.
    from unittest import TextTestRunner
    runner = TextTestRunner(sys.stdout, verbosity=2)
    runner.run(suite)
    doctest.testmod()
# SWFInterpreter end



# Generated at 2022-06-12 19:39:20.200929
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with TemporaryDirectory(suffix='_test_SWFInterpreter_extract_class') as tmpd:
        swf_file = os.path.join(tmpd, 'test.swf')
        test_avm2_class_file(swf_file)

        with open(swf_file, 'rb') as f:
            swf = SWFInterpreter(f, swf_file)

        swf.extract_class(0)


# Generated at 2022-06-12 19:39:27.358399
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import io
    import pyamf.remoting.client

# Generated at 2022-06-12 19:39:36.494375
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .flash_constants import SUPPORTED_SWF_VERSION
    from .abc import ABCFile
    from .abc_parser import ABCParser
    from .swf_parser import SWF, SWFParser
    from .swf_tags import TagDefineBinaryData, TagSymbolClass, TagEnd

    def assert_extracted(swf_data, class_name, expected_variables):
        swf = SWF(SWFParser(BytesIO(swf_data), is_little_endian=True))
        tags = swf.read()
        assert tags[0].type == TagEnd.type
        assert tags[1].type == TagSymbolClass.type

        processed_tags = []
        for t in tags[1:]:
            assert t.type == TagDefineBinaryData.type

# Generated at 2022-06-12 19:39:42.677504
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:39:49.541300
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    for i, (cls_name, cls_methods) in enumerate(SWFInterpreter.sample_classes):
        cls = SWFInterpreter.extract_class(cls_name, cls_methods, {})
        for method_name in cls_methods:
            method_func = cls.method_pyfunctions[method_name]
            assert method_func.__name__ == 'avm_class_%d_func_%s' % (
                i, method_name)
            assert method_func(None) is undefined


# Generated at 2022-06-12 19:39:50.896998
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert isinstance(SWFInterpreter(b'FWS'), SWFInterpreter)


# Generated at 2022-06-12 19:40:00.004575
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWF.load_test_swf()
    for version in range(4, 11):
        if not version in swf.tags:
            continue
        for tag in swf.tags[version]:
            if isinstance(tag, DoABC):
                abc_data = tag.abc_data
                break
        else:
            continue

        swf_interpreter = SWFInterpreter()
        swf_interpreter.parse(abc_data)
        class_count = swf_interpreter.read_u30()
        for i in range(class_count):
            name = swf_interpreter.constant_strings[i]
            avm_class = swf_interpreter.extract_class(name)
            assert isinstance(avm_class, _AVMClass)


# Generated at 2022-06-12 19:40:06.634591
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter()

# Generated at 2022-06-12 19:40:10.557822
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swfinter = SWFInterpreter()
    swfinter.patch_function = MagicMock(name='patch_function')
    swfinter.load_and_parse_swf('test.swf')
    assert swfinter.patch_function.call_count == 1

# Class for extracting metadata from a SWF file.

# Generated at 2022-06-12 19:42:05.784647
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    avm = SWFInterpreter()

    # This is a simplified class from YouTube player
    class YoutubePlayer(object):
        method_names = {
            'onMetaData',
            'onCuePoint',
            'onPlayStatus',
            'onTextData',
        }

        def make_object(self):
            return _ScopeDict(
                _AVMClass_Object(
                    avm_class=self,
                    static_properties=self.static_properties.copy(),
                    properties={},
                ),
            )

    player = YoutubePlayer()
    player.static_properties = {
        'type': 'application/x-shockwave-flash',
        'width': 480,
        'height': 360,
    }

# Generated at 2022-06-12 19:42:15.606483
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:42:24.089893
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    """
    Test for constructor of class SWFInterpreter
    """

# Generated at 2022-06-12 19:42:35.146763
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class DummyAVMClass(object):
        def __init__(self):
            self.variables = {}
            self.method_names = set()
            self.method_pyfunctions = {}
            self.static_properties = {}
        
        def make_object(self):
            return {}
    # test_SWFInterpreter_extract_class #0

# Generated at 2022-06-12 19:42:38.713598
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with io.open(os.path.join(
            os.path.dirname(__file__), 'as3classes.swf'), 'rb') as f:
        swf = SWF(f)

    swf.extract_classes(SWFInterpreter())

# Generated at 2022-06-12 19:42:44.897856
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s = SWFInterpreter(SWF())
    assert s.constant_strings == []
    assert s.multinames == []
    assert s.methods == [
        MethodInfo(
            param_types=None, return_type=None,
            name='undefined', param_names=None,
            is_native=True, is_final=False,
            is_override=False, is_explicit=False,
            is_attr=False, is_static=False, native_code=None)]

# Generated at 2022-06-12 19:42:47.415488
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-12 19:42:49.434407
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm_interpreter = SWFInterpreter()
    # On empty SWFInterpreter
    with pytest.raises(NotImplementedError):
        avm_interpreter.extract_function(None, None)

# Generated at 2022-06-12 19:42:54.693693
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interp = SWFInterpreter()

    class SampleClass:
        pass

    sample_class = SampleClass()
    code = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    interp.extract_function(sample_class, 'testfunc', code, [])

# Generated at 2022-06-12 19:43:04.281675
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from SWF.AVMFile import AVMFile
    avm_file = AVMFile(open('../test/test.avm', 'rb'))
    resolved_classes = {}
    resolved_methods = {}
    interpeter = SWFInterpreter(
        resolved_classes, resolved_methods, avm_file, 1)

    res = interpeter.extract_function(
        avm_file.classes['ns::TestCallMethod'].methods['test'])
    assert res([1]) == '1'
    assert res([2]) == '2'
    assert res([3]) == '3'
    assert res([4]) == '4'
    assert res([5]) == '5'
    assert res([10]) == '10'
    assert res([11]) == '11'

# Generated at 2022-06-12 19:45:14.508781
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter.from_file(
        os.path.join('tests/swf', 'test_swfinterpreter.swf'))
    avm_class = swf.extract_class('TestClass')
    assert avm_class.variables == {
        'num': int,
        'str': compat_str,
        'arr': list,
    }
    assert avm_class.static_properties == {
        'static_num': int,
        'static_str': compat_str,
        'static_arr': list,
    }

# Generated at 2022-06-12 19:45:24.067199
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb').read()
    swf_ = SWF(BytesIO(swf))
    swf_.extract_all()

    swf = SWFInterpreter(swf)
    test_class = swf.extract_class('test')
    t = test_class.make_object()
    assert len(t.static_properties) == 2
    assert t.static_properties['test_int'] == 123
    assert t.static_properties['test_str'] == 'abc'
    assert len(t.method_names) == 4
    assert t.method_pyfunctions['spike']() == 1243
