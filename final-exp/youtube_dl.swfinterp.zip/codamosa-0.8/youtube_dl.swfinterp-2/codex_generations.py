

# Generated at 2022-06-12 19:36:25.876172
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    from .avm import _AVMClass
    cl = _AVMClass('test')
    assert repr(_ScopeDict(cl)) == 'test__Scope(dict_proxy({}))'
    cl = _AVMClass('foo')
    assert repr(_ScopeDict(cl).update({1: 2})) == 'foo__Scope(dict_proxy({1: 2}))'



# Generated at 2022-06-12 19:36:28.574346
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import sys
    instr = SWFInterpreter(sys.argv[1])
    instr.extract_method_pyfunctions()


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-12 19:36:39.802906
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .abc_import import ABC
    from .abc_parser import ABCParser
    from .abc_symbol_table import SymbolTable

    # ABC test case

# Generated at 2022-06-12 19:36:44.002351
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    avm = get_interpreter('sample.swf')
    avm_class = avm.extract_class(avm.abc_classes['Sample'])
    assert 'Sample' in avm_class.static_properties
    assert 'main' in avm_class.method_names
    assert 'init' not in avm_class.method_names

# Generated at 2022-06-12 19:36:51.496458
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter(io.BytesIO())
    mn = _Multiname({'name': 'Foo', 'namespace': ['foo', 'bar', 'baz']})
    avm_class = _AVMClass({'method_names': [mn], 'method_pyfunctions': {}})
    opcode = _ABCOpcode()
    opcode.opcode = 42
    opcode.operands = [None]
    opcode.operand_range = [None]
    opcode.operand_types = [None]
    opcode.method = None
    avm_class.method_opcodes[mn] = [opcode]
    interpreter.avm_classes.append(avm_class)
    func = interpreter.extract_function(avm_class, mn)
    assert func()

# Generated at 2022-06-12 19:36:57.619119
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from collections import OrderedDict


# Generated at 2022-06-12 19:37:05.464603
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # This test consists of a simple class with a constructor and one method
    # The class is not exported, but its hierarchy is rather complex
    avm_code = compat_struct_pack(
        '>' + 'H' * 16 + 'IIIIII',
        4, 16, 0, 0,  # header
        5, 1, 0, 0,  # method_count, init_index
        3, 0,  # trait_count, classi_index
        0, 0,  # super_index
        0, 0,  # protected_ns, intrf_count
        0, 0,  # intrf_indexes
        0,  # flags
        0,  # name_index
    )

# Generated at 2022-06-12 19:37:12.185946
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:37:15.257217
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    class C(object):
        pass
    c = C()
    c.name = 'x'

    assert repr(_ScopeDict(c)) == 'x__Scope({})'



# Generated at 2022-06-12 19:37:20.642415
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()
    with io.open('../tests/swfs/media_rtmp_amf0_extract_function.swf', 'rb') as f:
        swf = f.read()
        interpreter.parse(swf)
        assert interpreter.extract_function(interpreter.classes['ToStringClass'], 'toString')
        interpreter.extract_function(interpreter.classes['RtmpUrlClass'], 'rtmpUrl')
        interpreter.extract_function(interpreter.classes['Main'], 'main')

# Generated at 2022-06-12 19:38:23.886601
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(BytesIO(SWF_FILE_NO_CONSTRUCTOR))
    assert len(swf.constant_strings) == 2
    assert swf.constant_strings[0] == 'flv-application/x-fcs'
    assert swf.constant_strings[1] == 'streamID'
    assert len(swf.constant_unsigned_ints) == 1
    assert swf.constant_unsigned_ints[0] == 0
    assert len(swf.method_bodies) == 1
    assert swf.method_bodies[0].method_name == 1
    assert swf.method_bodies[0].return_type == 1
    assert swf.method_bodies[0].flags == 1
    assert swf.method_bodies[0].max_register

# Generated at 2022-06-12 19:38:31.389010
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Run extract_function first to avoid warnings
    c = SWFInterpreter(None)

    c.multinames = {
        0: 'undefined',
        1: '_global',
        2: 'String',
        8: 'length',
        20: 'split',
    }

    class StringClass(object):
        pass

    c.constant_strings = {
        0: '',
        1: '_root',
        2: 'String',
        3: 'split',
    }

    c.variables = {
        '_root': {
            '_root': {
                '_level0': {},
            }
        }
    }


# Generated at 2022-06-12 19:38:36.692794
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    def do_test(filename, func_name):
        with open(filename, 'rb') as f:
            fdata = f.read()
        parser = SWFCodecParser(fdata)
        parser.read_file_header()
        parser.read_tags()
        swf_interpreter = SWFInterpreter(parser)
        swf_interpreter.extract_classes()
        for cname, cls in compat_iteritems(swf_interpreter.avm_classes):
            if func_name in cls.method_pyfunctions:
                break
        else:
            assert False

        args = []
        kwargs = {}
        cls.method_pyfunctions[func_name](*args, **kwargs)


# Generated at 2022-06-12 19:38:40.207695
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    SWFInterp = SWFInterpreter(open(
        os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     'test.swf'), 'rb').read())
    assert SWFInterp



# Generated at 2022-06-12 19:38:48.718731
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    with open(test_utils.get_test_file_path(
            'basic_mxmlc.swf'), 'rb') as f:
        swf = SWF(f)

    interpreter = SWFInterpreter(swf)
    interpreter.parse()
    interpreter.extract_function(interpreter.main_class, 'init')
    interpreter.extract_function(interpreter.main_class, 'valueOf')
    assert len(interpreter.main_class.method_pyfunctions) == 6
    assert 'valueOf' in interpreter.main_class.method_pyfunctions
    assert len(interpreter.main_class.method_pyfunctions['valueOf'].__code__.co_code) == 158
    assert interpreter.main_class.method_pyfunctions['valueOf'](undefined)

# Generated at 2022-06-12 19:38:58.565285
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open(test_file, 'rb') as f:
        swf_interpreter = SWFInterpreter(f)
        assert swf_interpreter.version == 9
        assert isinstance(swf_interpreter.constant_int_min, int)
        assert isinstance(swf_interpreter.constant_int_max, int)
        assert isinstance(swf_interpreter.constant_uint_min, int)
        assert isinstance(swf_interpreter.constant_uint_max, int)
        assert isinstance(swf_interpreter.constant_double_min, float)
        assert isinstance(swf_interpreter.constant_double_max, float)
        assert isinstance(swf_interpreter.class_name_map, dict)
       

# Generated at 2022-06-12 19:39:00.554895
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    SWFInterpreter(None)


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-12 19:39:08.521568
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = open(test_file('test.swf'), 'rb').read()
    interpreter = SWFInterpreter(swf)
    func = interpreter.extract_function(
        interpreter.avm_classes['LotteryEntry'],
        'entryCompare')
    assert func([{'prize': 'b', 'asset': 'a'}, {'prize': 'a', 'asset': 'b'}]) == 0
    assert func([{'prize': 'a', 'asset': 'a'}, {'prize': 'b', 'asset': 'b'}]) == -1
    assert func([{'prize': 'b', 'asset': 'a'}, {'prize': 'a', 'asset': 'a'}]) == 1


# Generated at 2022-06-12 19:39:18.451326
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.load('test/test_SWFInterpreter_extract_class.swf')
    swf_interpreter.extract_class()
    assert swf_interpreter.constant_strings == [
        '', 'Listener', 'TestClass', 'testMethod', 'testFunction',
        'avm_constructor', 'Function', 'n', 'i', 's', 'd', 'a', 'o', 'f']

# Generated at 2022-06-12 19:39:22.757760
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    AVM_FILE = open('avm1.dat', 'rb')
    AVM_FILE.seek(0, 2)
    AVM_SIZE = AVM_FILE.tell()
    AVM_FILE.seek(0)
    AVM_DATA = AVM_FILE.read(AVM_SIZE)
    AVM_FILE.close()

    avm = SWFInterpreter(AVM_DATA)


# Generated at 2022-06-12 19:40:15.605166
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter()
    swf.parse(open(path.join(
        path.dirname(__file__),
        'avm2',
        'helloworld_0.swf'), 'rb'))
    assert swf.version == 10
    assert swf.movie_width == 100
    assert swf.movie_height == 100
    assert len(swf.scripts) == 1

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-12 19:40:21.074872
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # make a fake SWF file
    version = 9
    file_len = 24
    frame_rate = 1
    frame_count = 1
    tags = []
    file = BytesIO()
    dump_swf_header(file, version, file_len, frame_rate, frame_count, data_only=True)
    for tag in tags:
        file.write(tag)
    file.seek(0)
    swf = SWFInterpreter(file)

    # test SWFInterpreter.get_abc_tag()
    tag = swf.get_abc_tag()
    assert isinstance(tag, RECT), 'Not a RECT object?'
    assert tag.nbits == 5, 'Wrong nbits value: %d' % tag.nbits

# Generated at 2022-06-12 19:40:25.391712
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    class TestAVMClass(object):
        variables = dict()
        static_properties = dict()
        method_names = set()
        method_pyfunctions = dict()
        def __init__(self, parent, name):
            self.variables = dict()
            self.static_properties = dict()
            self.method_names = set()
            self.method_pyfunctions = dict()
            self.parent = parent
            self.name = name
        def make_object(self, parent=None):
            return TestAVMClass_Object(self, parent)
        def make_class(self, parent, name):
            return TestAVMClass(self, name)

    class TestAVMClass_Object(object):
        def __init__(self, avm_class, parent):
            self.avm_class = av

# Generated at 2022-06-12 19:40:31.431872
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import sys
    import json

    # Load SWF file
    filename = sys.argv[1]
    with open(filename, 'rb') as f:
        swf = f.read()
    source, ver, uses_abc, scripts = read_swf(swf)
    c_data = scripts[0]

    # Parse AS2 bytecode
    intprt = SWFInterpreter(source, ver)
    intprt.parse_code(c_data)
    intprt.parse_code(intprt.scripts[0])

    # Show parsed data
    print('constant ints:')
    print(json.dumps(intprt.constant_ints, indent=2))
    print('constant uints:')

# Generated at 2022-06-12 19:40:37.406389
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    self = _SWFInterpreter({'string': 'Foo'})
    self.constant_strings = ['string']
    self.multinames = [
        _Multiname(1, ['string'], 'QName', [], _CONSTANT_Qname),
    ]

# Generated at 2022-06-12 19:40:43.238370
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:40:48.443909
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    filename = os.path.join(os.path.dirname(__file__), 'tests/test_swf_1.swf')
    with open(filename, 'rb') as in_f:
        swf = in_f.read()
    swf = SWF(swf)
    swf.parse()
    interpreter = SWFInterpreter(swf)
    interpreter.extract_function('MainTimeline', 'play')
    assert 'play' in swf.classes['MainTimeline'].method_pyfunctions

# Generated at 2022-06-12 19:40:57.637486
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io

# Generated at 2022-06-12 19:41:05.543709
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import array
    import struct


# Generated at 2022-06-12 19:41:15.880142
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:43:17.755785
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    class _TestClass1(object):
        pass
    class _TestClass2(object):
        pass
    interpreter = SWFInterpreter()
    interpreter.add_avm_class(_TestClass1)
    interpreter.add_avm_class(_TestClass2, base_class='_TestClass1')
    assert len(interpreter.builtin_classes) == 2
    assert interpreter.builtin_classes['_TestClass1'] == _TestClass1
    assert interpreter.builtin_classes['_TestClass2'] == _TestClass2
    assert '_TestClass1' in interpreter.multinames_by_class
    assert '_TestClass2' in interpreter.multinames_by_class

    assert len(interpreter.multinames) == 2

# Generated at 2022-06-12 19:43:26.267082
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .tag import Tag
    import io

    tag = Tag([
        '\x08\x00\x00\x00',  # method header (8 bytes)
        '\x00\x00\x00\x00',  # method header (8 bytes)
        '\x00\x01\x00\x00',  # method header (8 bytes)
        '\x00\x01\x00\x00',  # method header (8 bytes)
        '\x00\x00\x00\x03',  # return int 0
        '\x02\x00\x00\x00',  # end of method
    ], 0)

    interpreter = SWFInterpreter('', tags=[tag])
    int = interpreter.interpreters['0']
    int.patch_all_methods()

   

# Generated at 2022-06-12 19:43:34.376203
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from .avm_compiler import AVMCompiler

    avm_file = compat_str(
        '''class Main extends AVM {
    function main() {
        trace([1, 2, 3].slice(1));
        trace(String.split('a,b,c', ','));
    }
}
''')

    avm_compiler = AVMCompiler()
    avm_compiler.compile_file(BytesIO(avm_file.encode('utf-8')))
    interpreter = SWFInterpreter(avm_compiler.swf_data)
    interpreter.extract_function('Main', 'main')
    interpreter.avm_classes['Main'].make_object().main()

    interpreter.extract_function('Main', 'new')
    interpreter

# Generated at 2022-06-12 19:43:34.901408
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    pass

# Generated at 2022-06-12 19:43:38.539744
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert True
    return


# Test find_function on the following instructions:
#
#   1 = getlocal_0
#   86 = newarray
#   96 = getlex
#   97 = setproperty
#   99 = setlocal
#   102 = getproperty
#   104 = initproperty
#   108 = getslot
#   109 = setproperty
#   160 = add
#   208 = getlocal_0
#   209 = getlocal_1


# Generated at 2022-06-12 19:43:49.963131
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:43:51.533100
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    pytest.skip('SWFInterpreter is not implemented')


# Generated at 2022-06-12 19:43:58.950336
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = io.BytesIO(test_swf_data)
    swf_interpreter = SWFInterpreter(swf)

    # read signature and version
    swf.read(3)
    swf_interpreter.read_file_data()

    assert len(swf_interpreter.tags) == 1
    tag = swf_interpreter.tags[0]
    for c in tag.avm_classes:
        if c.name == 'SimpleTestClass':
            cls = c

    assert cls
    assert len(cls.method_names) == 1
    assert 'method' in cls.method_names
    assert len(cls.static_properties) == 2
    assert 'static_prop' in cls.static_properties
    assert 'static_prop2' in cls

# Generated at 2022-06-12 19:44:06.497612
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import unittest
    import io
    from .flash_constants import TAG_DO_ABC, TAG_DO_ABC_DEFINE
    class SWFInterpreter_extract_function_Test(unittest.TestCase):
        class _MockHeader:
            def __init__(self):
                self.version = 20
        def _make_one(self):
            self.swf = SWFInterpreter(self._MockHeader(), io.BytesIO(b''))
            return self.swf
        def setUp(self):
            self.swf = SWFInterpreter(self._MockHeader(), io.BytesIO(b''))
        @staticmethod
        def _make_tdef(name, super_name=None):
            from .flash_types import TDef

# Generated at 2022-06-12 19:44:12.521453
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    if sys.version_info[0] >= 3:
        import io
        coder = io.BytesIO(b'ABCDEF')
    else:
        import cStringIO
        coder = cStringIO.StringIO('ABCDEF')
    si = SWFInterpreter(coder)
    assert si.read('u30') == 0x21
    assert si.read('u30') == 0x43
    assert si.read('u30') == 0x1C
    assert si.read('s24') == 0xFF
    assert si.read('s24') == 0x00
    assert si.read('s24') == -0x01
    assert si.read('u8') == 0xA
    assert si.read('u8') == 0xB
    assert si.read('u8') == 0xC
