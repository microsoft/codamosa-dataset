

# Generated at 2022-06-12 19:37:34.490166
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .swftags import DoAction, DoInitAction, SWFBinaryTag
    from .swfdataio import SWFDataFileWriter
    from .swfdef import SWFHeader
    from .avmdata import ABCFile
    from .avmconst import kHasNext2Name, kHasNextName, kDXNSName, kReturnValueName
    from .abc_helper import create_Multiname
    
    swf_interpreter = SWFInterpreter()
    
    # Start by creating a simple test case
    abc_file = ABCFile()
    abc_file.methods.append(ABCMethod(0, [], [], 0, []))
    abc_file.constant_pool.constant_int.append(1)

# Generated at 2022-06-12 19:37:39.060797
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()
    # @TODO: It seems that the following test is not needed
    # (it does not cause any failure if commented out)
    # assert interpreter.extract_function(
    #     interpreter.this_avm_class, 'avm_trace') is not None


# Generated at 2022-06-12 19:37:46.163667
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from io import BytesIO
    from sys import intern
    from .samples import (
        do_download, do_extract, do_download_extract,
        get_testcases_namespace,
    )

    ns = get_testcases_namespace()

    def _chk_names(obj):
        for k, v in obj.items():
            if isinstance(k, tuple):
                assert isinstance(v, (compat_str, list, dict))
            elif isinstance(k, _Multiname):
                assert isinstance(v, (compat_str, list, dict))
            else:
                assert isinstance(k, compat_str), k
                assert not isinstance(v, (compat_str, list, dict))

    def test(idx, raw_swf):
        swf

# Generated at 2022-06-12 19:37:49.814472
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = swftools.SWF(io.BytesIO(eol_test_swf))
    constants = swf.tags[0].constants
    tags = list(enumerate(swf.tags))

    avm = SWFInterpreter()
    res = avm.extract_class(swf.tags[0])

    assert res is not None



# Generated at 2022-06-12 19:37:57.879719
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .abc import ABC

    class Foo(object):
        pass

    swf = SWF(BytesIO(b''), strict=False)

# Generated at 2022-06-12 19:38:05.709280
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    constant_strings = ['', 'as3', 'flash.events::Event', 'onMetaData', 'duration', 'abcd']
    class_names = ['X', 'Y', 'Z']
    string_count = 5
    namespace_count = 0
    multiname_count = 5

# Generated at 2022-06-12 19:38:12.237158
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter()

    # Add Constants
    interpreter.add_constant_integer(1)
    interpreter.add_constant_string('abc')
    interpreter.add_constant_string('def')

    # Add Multinames
    interpreter.add_multiname('x')
    interpreter.add_multiname('y')
    interpreter.add_multiname('z')
    interpreter.add_multiname('String')
    interpreter.add_multiname('split')

    # Add Methods
    def make_function(name, code):
        assert not interpreter.code_cursor
        code = array.array('B', code)
        interpreter.add_method(name, code)

    def make_class(classname, baseclass):
        interpreter.add_class(classname, baseclass)



# Generated at 2022-06-12 19:38:17.658079
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter()
    test_c = type('', (), {})()
    test_c.constant_strings = ['test']
    test_c.constant_strings.append('')
    test_c.constant_strings.append('pushshort')
    test_c.constant_strings.append('pushstring')
    test_c.constant_strings.append('pushtrue')
    test_c.constant_strings.append('pushfalse')
    test_c.constant_strings.append('callproperty')
    test_c.constant_strings.append('ifstrictne')
    test_c.constant_strings.append('add')
    test_c.constant_strings.append('pushundefined')
    test_c.constant_strings.append('construct')
    test

# Generated at 2022-06-12 19:38:25.648427
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:38:32.589781
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    mo_file = open(os.path.join(os.path.dirname(__file__), 'test_methods.mo'), 'rb')
    mo_tags = swftags.SWFTags(io.BytesIO(mo_file.read()))
    mo_file.close()
    mo_swf = swf.SWF(mo_tags)
    mo_doabc = mo_swf.tags[0]

    const_str = mo_doabc.cpool_string.values
    const_ns = mo_doabc.cpool_ns.values
    const_ns_set = mo_doabc.cpool_ns_set.values
    const_mn = mo_doabc.cpool_mn.names
    assert len(mo_doabc.instances) == 1
    mo_instance = mo_doabc

# Generated at 2022-06-12 19:39:47.795167
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    def assert_dict_eq(d1, d2):
        assert isinstance(d1, dict)
        assert isinstance(d2, dict)
        assert set(d1.keys()) == set(d2.keys())
        for k in d1:
            assert d2[k] == d1[k]

    with open('test/test.swf', 'rb') as f:
        swf = SWFInterpreter(f)
        # Test swf.constant_strings

# Generated at 2022-06-12 19:39:54.264134
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import sys
    from .abc import _ABCFileReader

    class AVMClass(object):
        def __init__(self):
            self.method_names = set()
            self.method_pyfunctions = {}
            self.variables = {}
            self.static_properties = {}
            self.instances = {}

        def add_method(self, name, method_info, code):
            self.method_names.add(name)

        def make_object(self):
            self.instances[id(self)] = _ScopeDict(self)
            return self.instances[id(self)]


# Generated at 2022-06-12 19:40:00.328975
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    snippet = bytes.fromhex('0a0109010013010111180100011011')
    swf = SWF(io.BytesIO(snippet))
    intp = SWFInterpreter(swf)

    class1 = intp.extract_class('Main')
    assert isinstance(class1, _AVMClass)
    assert class1.name == 'Main'
    assert len(class1.method_names) == 1


# Generated at 2022-06-12 19:40:06.813809
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    f = open('examples/swf/003.swf', 'rb')
    swf = f.read()
    f.close()

    interpreter = SWFInterpreter(swf)
    interpreter.load_actions()

    avm_class = interpreter.extract_class('_level0')

    assert avm_class.class_name == '_level0'
    assert avm_class.super_class_name == 'Object'
    assert avm_class.constant_pool_type == 'String'
    assert len(avm_class.constant_strings) == 7
    assert avm_class.constant_strings[0] == ''
    assert avm_class.constant_strings[1] == 'Hola, Mundo'

# Generated at 2022-06-12 19:40:14.906623
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swfi = SWFInterpreter()
    def extract_function(avm_class, func_name):
        code = avm_class.methods[func_name].body
        def dummy(args, scope):
            return args[0] + args[1]
        return dummy
    swfi.extract_function = extract_function
    avm_class = object()
    func_name = 'some_method'
    avm_code = object()
    class AVMMethod(object):
        def __init__(self):
            self.body = avm_code
    avm_class.methods = {
        func_name: AVMMethod(),
    }
    avm_class.method_pyfunctions = {}
    avm_class.variables = {}


# Generated at 2022-06-12 19:40:19.887140
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:40:25.498464
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:40:26.155048
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert SWFInterpreter([])



# Generated at 2022-06-12 19:40:29.650792
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from rtmpy.io import ByteArray

    file_obj = open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb')
    tags = []
    reader = ByteArray(file_obj)
    reader.set_endian(ByteArray.BIG_ENDIAN)
    swf = SWFInterpreter(reader)
    swf.run()
    # print(SWFInterpreter.decode('test.swf'))

# Generated at 2022-06-12 19:40:32.268841
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import io
    swf = io.BytesIO(SWF_EXAMPLE.encode('latin-1'))
    assert SWFInterpreter(swf).extract_function('_main', '_init')


# Generated at 2022-06-12 19:41:39.033140
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()
    script = _Script(
        # Test initobject (empty object literal)
        _ActionPush([3]),
        _ActionInitObject(),
        _ActionReturn(),
    )
    func = interpreter.extract_function(script, 'SCRIPT')
    assert func() == {}

    script = _Script(
        _ActionPush([3]),
        _ActionInitObject(),
        _ActionPush([5]),
        _ActionInitObject(),
        _ActionReturn(),
    )
    func = interpreter.extract_function(script, 'SCRIPT')
    assert func() == {}

    script = _Script(
        _ActionPush([3]),
        _ActionAdd(),
        _ActionReturn(),
    )
    func = interpreter.extract_function(script, 'SCRIPT')
    assert func() == 6

# Generated at 2022-06-12 19:41:40.779169
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    filepath = _TEST_FILE
    SWFInterpreter(filepath)

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-12 19:41:47.327636
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb').read())

    func = functools.partial(swf.run_method, 'SWFTimelineTest', 'test')
    assert func() == 1
    assert func(1) == 2
    assert func('aa', 3) == 5
    assert func([1, 2, 3, 4]) == 10
    assert func(None) == 12
    assert func('Test') == 15
    assert func('test', 'Test') == 16
    assert func('test') == 'test'
    assert func('hello') == 'hello'

    func = functools.partial(swf.run_method, 'SWFTimelineTest', 'test2')

# Generated at 2022-06-12 19:41:53.236834
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open(os.path.join(os.path.dirname(__file__), 'flash_video.swf')) as f:
        swf_data = f.read()
    swf = compat_BytesIO(swf_data)
    interp = SWFInterpreter(swf)
    class_obj = interp.extract_class('flash.display::Stage')
    assert class_obj.static_properties['stageWidth'] == 412
    assert class_obj.static_properties['stageHeight'] == 308
    assert class_obj.static_properties['fullScreenSourceRect'] == None
    assert class_obj.static_properties['stageFocusRect'] == false
    class_obj = interp.extract_class('flash.display::MovieClip')
    assert class_obj is MovieClipClass

# Generated at 2022-06-12 19:42:02.421044
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:42:03.970011
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-12 19:42:13.617763
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .swf import SWF, SWFStream
    from .stdparser import SWFStdParser

    with open(os.path.join(os.path.dirname(__file__), '../test/swfs/helloworld.swf'), 'rb') as swf_file:
        swf = SWF(SWFStream(swf_file))
        parser = SWFStdParser()
        parser.parse_swf(swf)

    interpreter = SWFInterpreter(swf, parser.constant_strings, parser.multinames)
    interpreter.extract_class(parser.classes['HelloWorld'])

    assert 'HelloWorld' in interpreter.classes
    assert interpreter.classes['HelloWorld'].make_object().initialize() == 'Hello World'


# Generated at 2022-06-12 19:42:20.280710
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open(os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            'avm2', 'SimpleClass.swf'), 'rb') as f:
        avm_bytes = f.read()

        ai = SWFInterpreter()
        avm_class = ai.extract_class(avm_bytes)

    assert avm_class.classname == 'SimpleClass'
    assert len(avm_class.static_properties) == 0
    assert len(avm_class.method_pyfunctions) == 1
    assert 'call' in avm_class.method_pyfunctions


# Generated at 2022-06-12 19:42:23.175972
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Constructor of class SWFInterpreter
    assert SWFInterpreter(b'')
    assert SWFInterpreter(b'FWS')


# Generated at 2022-06-12 19:42:29.235820
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swfdata = open(
        os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data/1.swf'),
        'rb').read()
    # len(swfdata) - 1: skip the last byte (signature)
    # 0x002A: skip the file size bytes
    # -1: skip the last byte
    swf_parser = SWFInterpreter(swfdata[len(swfdata) - 1 - 0x002A: -1])

# Generated at 2022-06-12 19:44:33.136452
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swfdecompress import decompress_swf
    testdata = data_directory.joinpath('test.swf')
    finfo = io.open(testdata, mode='rb')
    swf_data = finfo.read()
    finfo.close()
    swf_data = decompress_swf(swf_data)
    swf_data = swf_data[8:]  # remove inital start tag
    swf = io.BytesIO(swf_data)

    def _show_tag(tag):
        tagtype = tag.tag_type & 0xff
        print('Tagtype: %d' % tagtype)
        if tagtype == 82:  # DoABC
            print('DoABC data: %r' % tag.data)

# Generated at 2022-06-12 19:44:40.813764
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s = b'\x10' + b'\x00' * 8 + b'\x00' * 4 + b'\x00' * 4
    swf = SWF(BytesIO(s))
    avm_interpreter = SWFInterpreter()
    avm_interpreter.load(swf)
    class_name = 'DoABC'
    avm_class = avm_interpreter.classes[class_name]
    func_name = 'f'
    res = avm_interpreter.extract_function(avm_class, func_name)
    assert isinstance(res, types.FunctionType)
    assert res() is None
    return res


# Generated at 2022-06-12 19:44:47.028155
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class MyInterpreter(SWFInterpreter):
        def make_output(self, name, streaming=False, **kwargs):
            return [name]

    interpreter = MyInterpreter(global_variables=None)
    my_func = namedtuple('my_func', ['code', 'parameters', 'max_registers'])

    func = interpreter.patch_function(
        my_func(code=[], parameters=[], max_registers=0))
    assert func() == []

    func = interpreter.patch_function(
        my_func(code=[15], parameters=[], max_registers=0))
    assert func() == [15]

    func = interpreter.patch_function(
        my_func(code=[21, 10, 0], parameters=[], max_registers=1))

# Generated at 2022-06-12 19:44:54.208514
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter(b'')
    class AVMClass(object):
        def __init__(self):
            self.variables = {}
            self.method_pyfunctions = {}
    avm_class = AVMClass()
    code = b'\x01\x00\x00\x00\x01\x00\x00\x00'
    avm_class.method_names = ['method']
    resfunc = interpreter.patch_function(avm_class, code, 'method')
    assert resfunc([]) is undefined

ValueClass_name = 'ValueClass'
FunctionClass_name = 'Function'
StringClass_name = 'String'

# Generated at 2022-06-12 19:45:00.462153
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:45:09.654102
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s = '\x03\x00\x00\x00\x3A\x2A\x2F\x2F'
    s += '\x74\x65\x73\x74\x2E\x61\x73\x6D'
    s += '\x00\x00\x00\x00\x00\x03\x00\x05'
    s += '\x00\x00\x00\x02\x00\x00\x00\x01'
    s += '\x00\x00\x00\x00\x00\x00\x00\x00'
    s += '\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-12 19:45:15.968709
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Build an interpreter
    fp = open('../test/swfs/hello.swf', 'rb')
    z = _SWFInterpreter(fp)

    # Find a method
    avm_class = z.avm_classes[0]
    method_name = avm_class.method_names[0]
    method_func = avm_class.method_pyfunctions[method_name]

    # Patch the method
    def patched_method(args):
        return 'patched'
    z.patch_function(avm_class, method_name, patched_method)

    # Test the patched method
    func = avm_class.method_pyfunctions[method_name]
    assert func(None) == 'patched'

    # Restore the method

# Generated at 2022-06-12 19:45:21.429931
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(os.path.dirname(__file__), 'youtubedl-test.swf'), 'rb').read())
    assert len(swf.constant_floats) == 12
    assert len(swf.constant_ints) == 1
    assert len(swf.constant_strings) == 36
    assert len(swf.constant_namespaces) == 1
    assert len(swf.constant_namespace_sets) == 1
    assert len(swf.multinames) == 48
    assert len(swf.scripts) == 1
    assert len(swf.method_bodies) == 1

# Extract a base64 encoded string from inside a Flash file