

# Generated at 2022-06-12 19:36:13.986703
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Also testing extract_class since it's a prerequisite for extract_function
    class _SWFInterpreterTest(SWFInterpreter):
        VERSION = 17


# Generated at 2022-06-12 19:36:16.335888
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    for attr in ['name_idx', 'name', 'method_names', 'method_idxs', 'methods', 'method_pyfunctions', 'static_properties']:
        assert hasattr(AVMClass, attr)
    return True
AVMClass = _AVMClass



# Generated at 2022-06-12 19:36:22.309165
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    class_ = _AVMClass(None, 'Foo')
    class_.register_methods({
        'foo': 10,
        'bar': 20})
    assert class_.method_names['foo'] == 10
    assert class_.method_names['bar'] == 20
    assert class_.method_idxs[10] == 'foo'
    assert class_.method_idxs[20] == 'bar'


# Generated at 2022-06-12 19:36:30.528461
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-12 19:36:42.131134
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from tests.flash_tests.actionscript_test import test_class
    interpreter = SWFInterpreter()
    constant_strings = test_class['constant_strings']
    methods = test_class['methods']
    namespaces = test_class['namespaces']
    namespace_sets = test_class['namespace_sets']
    multinames = test_class['multinames']
    class_info = test_class['instances'][0]['class']
    static_properties = test_class['classes'][0]['static_properties']
    res = interpreter.extract_class(class_info, static_properties)
    assert res.class_name == 'TestClass'
    assert res.base_class_name == 'Object'
    assert res.method_pyfunctions == {}

# Generated at 2022-06-12 19:36:50.327594
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter(open(os.path.join(
        os.path.dirname(__file__), 'test.swf'), 'rb').read())
    assert len(swf.get_script_names()) == 1
    assert swf.get_script_names()[0] == 'ytplayer.config.assets.js'
    assert ('ytplayer.config.assets.js', 'main') in swf.get_script_func_names()
    assert swf.get_script_func_names()[('ytplayer.config.assets.js', 'main')] ==\
        'async_main'


# Tests the ability to interpret a real SWF file

# Generated at 2022-06-12 19:36:56.477470
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .swftags import SWFTagShowFrame
    from .swftags import SWFTagDoAction
    from .swftags import SWFDoAction_Push
    from .swftags import SWFDoAction_ConstantPool
    from .swftags import SWFDoAction_Return
    from .swftags import SWFDoAction_GetVariable
    from .swftags import SWFDoAction_SetVariable
    from .swftags import SWFDoAction_ConvertString
    from .swftags import SWFDoAction_TypeOf
    from .swftags import SWFDoAction_And
    from .swftags import SWFDoAction_Add
    from .swftags import SWFDoAction_GreaterOrEqual


# Generated at 2022-06-12 19:37:04.561695
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    a = _AVMClass(None, 'Cl')
    a.register_methods({
        'foo': 1,
        'bar': 2,
    })
    assert a.method_names == {
        'foo': 1,
        'bar': 2,
    }
    assert a.method_idxs == {
        1: 'foo',
        2: 'bar',
    }
    a.register_methods({
        'bar': 3,
        'baz': 4,
    })
    assert a.method_names == {
        'foo': 1,
        'bar': 2,
        'baz': 4,
    }
    assert a.method_idxs == {
        1: 'foo',
        2: 'bar',
        3: 'bar',
        4: 'baz',
    }

# Generated at 2022-06-12 19:37:16.000146
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from . import testdata
    class IntClass(object):
        def __init__(self):
            self.a = 0
        def set_a(self, args):
            assert len(args) == 1
            assert isinstance(args[0], int)
            self.a = args[0]
            return undefined

    class Global(object):
        IntClass = IntClass

    interp = SWFInterpreter(Global)
    avm_class = interp.extract_class(
        testdata.read_bytes('flash/actionscript_intclass.abc'), 0)
    assert avm_class.class_name == 'IntClass'
    assert avm_class.super_name == 'Object'
    assert avm_class.method_names == {'IntClass', 'set_a'}
    assert avm_

# Generated at 2022-06-12 19:37:22.649593
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .abc_file import ABCFile

# Generated at 2022-06-12 19:38:23.879975
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter()
    with open(os.path.join('tests', 'data', 'menu_class_hierarchy.json'), 'rb') as fh:
        interpreter.class_hierarchy = json.load(fh)

    with open(os.path.join('tests', 'data', 'menu.swf'), 'rb') as fh:
        swf = fh.read()
    interpreter.parse_swf(swf)

    for qname, avm_class in sorted(interpreter.classes.items()):
        print(qname)
        for pname, method_info in sorted(avm_class.methods.items()):
            print('  %s' % pname)
            method_info.extract_method(interpreter, avm_class)


# Generated at 2022-06-12 19:38:26.186162
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    method = _ScopeDict(None).__repr__

# Generated at 2022-06-12 19:38:31.270305
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    class Integer(object):
        pass
    swfi = SWFInterpreter()
    assert swfi.global_variables == {}
    assert swfi.trait_parser == None
    assert swfi.constant_ints == {}
    assert swfi.constant_uints == {}
    assert swfi.constant_doubles == {}
    assert swfi.constant_strings == {}
    assert swfi.multinames == {}
    assert swfi.method_bodies == {}
    assert swfi.classes == {}


# Generated at 2022-06-12 19:38:32.375516
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    _ScopeDict(None).__repr__()
# .
# .
# .


# Generated at 2022-06-12 19:38:37.562973
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import hashlib
    from rtmp_base import read_swf
    interpreter = SWFInterpreter(read_swf(b'_001'))
    interpreter.extract_function(interpreter.avm_classes[b'Function'], b'apply')
    h = hashlib.md5()
    h.update(compat_str(interpreter.avm_classes[b'Function'].method_pyfunctions[b'apply']).encode('UTF-8'))
    assert h.digest() == b'\xa4\x9e\x8fY\xd7\xbc\x90\xbc\x1a\xa2\xc9\xdf\x07+\xa0\x1a\x8d\xaa'.replace(b'\\', b'\\\\')

_built

# Generated at 2022-06-12 19:38:47.122343
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    with open('test/test.swf', 'rb') as f:
        data = f.read()
    with BytesIO(data) as f:
        swf = SWF(f)
        interpreter = SWFInterpreter(swf)

# Generated at 2022-06-12 19:38:57.995196
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # First, create a simple class
    class Obj1(object):
        def __init__(self):
            self.a = 1
            self.b = 'string'
            self.c = [1, 2, 3]
            self.d = None
    obj1 = Obj1()

    # create a dictionary
    obj2 = {
        'a': 'string'
    }

    # Of course, for real examples, we need a bit more complicated
    # setup (like a class inheriting from another one, or
    # functions in the methods of the class), but this unit test is
    # only intended to check the extraction of the data from the
    # objects, so it should be enough.

    # Now we need to extract the bytecode from this class
    interpreter = SWFInterpreter()

# Generated at 2022-06-12 19:39:03.034535
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    with codecs.open(('/home/gogol/youtube-dl/youtube_dl/extractor/'
                      'brightcove.py'), 'r+b') as f:
        interpreter = SWFInterpreter(f.read())
        interpreter.patch_functions()
        with codecs.open('/home/gogol/youtube-dl/youtube_dl/extractor/'
                         'brightcove.py.patched', 'w+b') as g:
            g.write(interpreter.buffer)
# Class SWFInfo

# Generated at 2022-06-12 19:39:11.740503
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_interpreter = SWFInterpreter(SWFData(''))

    def extract_function(avm_class, func_name):
        return lambda x: 1
    swf_interpreter.extract_function = extract_function

    swf_method = SWFData(b'%s\x00\x00\x00' % compat_struct_pack(
        '>HHH', 1, 0, 1))

    avm_class = _AVMClass('test', {}, {}, {}, {})
    avm_class.variables = {'arguments': []}

    func = swf_interpreter.extract_method(swf_method, 'fake_method',
                                          avm_class)
    assert func() == 1


# Generated at 2022-06-12 19:39:15.921601
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    file_path = '/Users/gala/Downloads/V7ZebiQ.swf'
    interpreter = SWFInterpreter(file_path)
    interpreter.extract_function('external')

# Generated at 2022-06-12 19:42:07.828234
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    def check_SWFInterpreter_extract_function(s):
        a = SWFInterpreter()
        a.extract_class(s)


# Generated at 2022-06-12 19:42:16.330839
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter(BytesIO(b'FWS\x04\x00\x00\x00\x00\x00\x00\x00\x00'))
    class AVMClass(object):
        method_names = set(['test', 'test2'])
        static_properties = {'Boolean': BooleanClass}

    def test(args):
        assert len(args) == 1
        assert args == [1]
        return 2

    swf.avm_methods['test'] = test
    swf.avm_classes['test'] = AVMClass()

    class FakeScopeDict(object):
        avm_class = AVMClass()

    res = swf.extract_function(FakeScopeDict(), 'test')
    assert res([1]) == 2

# Generated at 2022-06-12 19:42:24.768008
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import binascii
    swf_file = open('testdata/adobe-logo.swf', 'rb')
    data = swf_file.read()
    swf_file.close()
    swf = SWFInterpreter(data)

    assert len(swf.tags) == 12

    assert swf.header.version == 17
    assert swf.header.length == 13480

    assert swf.header.rect.xmin == 0
    assert swf.header.rect.xmax == 429
    assert swf.header.rect.ymin == 0
    assert swf.header.rect.ymax == 429

    assert swf.header.framerate == 15
    assert swf.header.framescount == 1

    assert swf.tags[0].type == SWF_TAG_DEFINESPR

# Generated at 2022-06-12 19:42:25.754553
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import doctest
    doctest.testmod(SWFInterpreter)



# Generated at 2022-06-12 19:42:31.166012
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from io import BytesIO
    from .swfdecompiler import _swf_iter_objects

    swf3 = b'\x46\x57\x53\x09\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    swf4 = b'\x46\x57\x53\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

    with open('test/minimal.swf3.swf', 'rb') as f:
        swf3_data = f.read()
    with open('test/minimal.swf4.swf', 'rb') as f:
        swf4_data = f.read()


# Generated at 2022-06-12 19:42:35.446371
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    si = SWFInterpreter()
    si.extract_class(SWF_CLASS)
    assert si._AVMClass_String is not None

    si = SWFInterpreter()
    si.extract_class(SWF_CLASS2)
    assert 'Array' in si._AVMClass_Object.static_properties
    assert si.extract_function(si._AVMClass_Object, 'Array')

    si = SWFInterpreter()
    si.extract_class(SWF_CLASS3)
    assert 'return' not in si._AVMClass_Object.static_method_names

# Generated at 2022-06-12 19:42:36.544102
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    assert False, "Not implemented"

# Generated at 2022-06-12 19:42:46.637023
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter()
    swf.do_tags([
        b'\x3F\x03\x00\x00\x00\x00'
        b'\x0C\x00\x00\x00\x00'
        b'\x3C\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x14\x00\x00\x00\x00\x00\x00\x00\x00'
    ])

# Generated at 2022-06-12 19:42:53.327858
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-12 19:42:58.591961
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    for class_name in (
            'Array',
            'Date',
            'Error',
            'RegExp',
            'String',
            'XML',
            'Object',
    ):
        # let the interpreter create a class
        avm_interpreter.extract_class(class_name)

