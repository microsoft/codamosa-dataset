

# Generated at 2022-06-12 19:36:54.965802
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # 1. Parse all of _test_files/test.swf
    filename = os.path.join(os.path.dirname(__file__), '_test_files/test.swf')
    with open(filename, 'rb') as swf_file:
        swf_data = swf_file.read()
        swf = SWF(swf_data, parse_body=False)
        swf.parse_body()
        # 2. Get and parse DoABCTags
        abc_tags = [t for t in swf.tags if t.type == 82]
        abc_bodies = [t.body for t in abc_tags]
        as3_tags = [t for t in swf.tags if t.type == 73]

# Generated at 2022-06-12 19:37:00.956918
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import os
    import sys
    import tempfile
    import json
    import textwrap
    import unittest

    if sys.version_info > (3,):
        unicode = str

    class TestInterpreter(SWFInterpreter):
        def __init__(self, *args, **kwargs):
            super(TestInterpreter, self).__init__(*args, **kwargs)
            self.method_pyfunctions = {}

    def extract_function(self, avm_class, func_name):
        resfunc = None

        # If a cached function is available use it
        if func_name in self.method_pyfunctions:
            return self.method_pyfunctions[func_name]

        # Find the right ABCMethodInfo

# Generated at 2022-06-12 19:37:12.781211
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():

    swf = SWFInterpreter()
    swf.load_file(get_test_file_path('interpreter_class.swf'))

    # Assert there is only one class in the avm
    assert len(swf.avm.classes) == 1

    # Assert class "MyClass" is defined
    my_class = swf.avm.classes['MyClass']
    assert isinstance(my_class, _AVMClass)

    # Assert class has three static vars
    assert len(my_class.static_properties) == 3

    # Assert class has one static method
    assert len(my_class.method_names) == 1
    assert 'MyClass_function' in my_class.method_names

    # Assert static method returns a:5 + b:5 == 10

# Generated at 2022-06-12 19:37:21.119847
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interp = SWFInterpreter()

    class TestAVMClass(object):
        def __init__(self):
            self.instance_variable_names = []
            self.static_properties = {}
            self.method_names = set()
            self.methods = {}

    class TestAVMClass_Instance(object):
        def __init__(self, avm_class):
            self.avm_class = avm_class
            self.properties = {}

        def get(self, idx):
            return self.properties[idx]

        def set(self, idx, value):
            self.properties[idx] = value

    def make_object(self):
        return TestAVMClass_Instance(self)

    TestAVMClass.make_object = make_object


# Generated at 2022-06-12 19:37:30.224165
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swfdec = SWFDecompiler()
    interpreter = SWFInterpreter()
    interpreter.read_swf(swfdec)

    class_name = 'NetConnection'
    func_name = 'call'
    obj = interpreter.classes[class_name].make_object()
    func = interpreter.extract_function(obj, func_name)

    # Example from: https://helpx.adobe.com/flash/flash-player/
    # flash-player-dev-center.html
    args = [
        'http://www.helpexamples.com/flashservices/echo.php',
        'myResult',
        [1, 2, 3],
    ]
    func(args)

# This class represents ActionScript string

# Generated at 2022-06-12 19:37:37.060828
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s = Stream('swf/interpreter')
    p = SWFParser(s)
    avm_class = p.read_avm_class()
    interpreter = SWFInterpreter(avm_class, 'track_id')
    assert interpreter.extract_function(avm_class, 'onMetaData')() == {
        'keywords': '',
        'metadatacreator': 'flv_validator',
    }

#------------------------------------------------------------------------------#
#                                                                              #
#------------------------------------------------------------------------------#

# dict mapping from class to dict

# Generated at 2022-06-12 19:37:45.257358
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    constants = [undefined, False, True, None, 0.0, 2.5, 7, 'foobar']

    i = SWFInterpreter(constants, {}, {}, {}, 'abc', None, None, None, None,
                       None)
    func_name = 'foobarbaz'
    avm_class = _AVMClass(i)
    avm_class.method_names.add(func_name)
    resfunc = i.extract_function(avm_class, func_name)
    assert resfunc is not None
    assert resfunc([]) == undefined
    args = [
        [],
        ['string'],
        [None],
        [7.5],
        ['baz', 'foo', 'bar'],
    ]

# Generated at 2022-06-12 19:37:52.040670
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from io import BytesIO
    from .swf import _UNDEF, _SWF_HEADER_SIZE, _read_full
    import hashlib

    _ = SWFInterpreter()


# Generated at 2022-06-12 19:38:00.974152
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .test_utils import TestCase

    class TestSWFInterpreter(SWFInterpreter):
        def __init__(self, *args, **kwargs):
            super(TestSWFInterpreter, self).__init__(*args, **kwargs)
            self.calls = []

        def log_call(self, fname, *args):
            self.calls.append((fname, args))


# Generated at 2022-06-12 19:38:04.078718
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = io.BytesIO(SWF_BYTES)
    swf_interpreter = SWFInterpreter()
    swf_interpreter.feed(swf)
    assert swf_interpreter.extract_class(1)



# Generated at 2022-06-12 19:39:13.092384
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    f = SWFInterpreter()

    # We should have some simple functions exported
    assert 'isFinite' in f.globals
    assert 'isNaN' in f.globals
    assert 'parseFloat' in f.globals
    assert 'parseInt' in f.globals
    assert 'decodeURI' in f.globals
    assert 'decodeURIComponent' in f.globals
    assert 'encodeURI' in f.globals
    assert 'encodeURIComponent' in f.globals
    assert 'escape' in f.globals
    assert 'unescape' in f.globals

    assert 'Math' in f.globals
    assert 'NaN' in f.globals
    assert 'Infinity' in f.globals


# Generated at 2022-06-12 19:39:16.716223
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    c = SWFInterpreter(b'\x00\x00\x00\x00')
    f = c.patch_function('foo')
    assert f.__name__ == 'foo'


# Generated at 2022-06-12 19:39:24.483129
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import io
    from .swfdecompiler import SWFDecompiler
    from .abcserializer import abc_serializer


# Generated at 2022-06-12 19:39:28.454231
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = open(r'/Users/noplay/pycharm/mpy/tests/output.swf', 'rb').read()
    swf_script = SWFInterpreter(swf)
    swf_script.extract_class("JSVideo")

# Generated at 2022-06-12 19:39:37.216936
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .compat import compat_str
    from .flash_proxy import flash_proxy
    from .tv_utils import parse_amf_data
    from .utils import (
        AnonymousObject,
        FlashVar,
        ScriptConstant,
        Undefined,
        UnsupportedAction,
    )

    avm_class = SWFInterpreter()
    attr_obj = _ScopeDict({'a': 'A'})

# Generated at 2022-06-12 19:39:47.830972
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import re
    from .compat import parse_qs
    from .common import InfoExtractor
    from .compat import (
        compat_b64decode,
    )
    from .swfdecompiler import decompile_swf
    from .swfinterp import (
        SWFInterpreter, _Undefined,
    )

    media_id = '42'
    example_swf = '''
        42 43 57 53  SWF
        00 04 00 00  Version 4
        00 00 00 00  Size (not a real tag)
        42 43 f6 06  SWF File Signature (6 bytes)
        02 02 3f a0  Frame Size
        00 01 00 01  Frame Rate & Count
        01  Tag Count
        3f a0 00 01  End Tag
    '''

# Generated at 2022-06-12 19:39:49.706920
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interp = SWFInterpreter()
    print (interp.constant_strings)
    print (interp.multinames)


# Generated at 2022-06-12 19:39:58.782749
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    sin = io.StringIO()

# Generated at 2022-06-12 19:40:05.848886
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:40:12.257673
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb') as f:
        swf = SWF(f)

        obj = swf.get_script_object(0)

        assert obj.name == 'MainTimeline'
        assert obj.variables['x'] == 'x'

        assert obj.frame0.variables['y'] == 'y'

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-12 19:42:06.251139
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .tag_data import TagDefineFunction
    from .tag_data import TagDoABC
    from .tag_data import TagEnd
    from .tag_data import TagFileAttributes
    from .tag_data import TagSetBackgroundColor
    from .tag_data import TagShowFrame
    from .tag_data import TagSymbolClass
    from .tag_data import TagDoAction
    from .tag_data import TagFrameLabel

    # Test against a SWF file that contains only a single function
    # that is constructed from the following ActionScript code:

# Generated at 2022-06-12 19:42:15.713024
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter(fake_simplexml = True, fake_ffmpeg = True,
        fake_rtmpdump = True, fake_f4m_linear_adapter = True)

    def _fake_extract_function(avm_class, func_name):
        if isinstance(avm_class, SWFClass):
            return swf_classes[avm_class.class_name][func_name]
        elif isinstance(avm_class, SWFObjectClass):
            return swf_object_class[func_name]
        elif isinstance(avm_class, SWFArrayClass):
            return swf_array_class[func_name]
        elif isinstance(avm_class, SWFStringClass):
            return swf_string_class[func_name]
        el

# Generated at 2022-06-12 19:42:16.740195
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # TODO
    pass


# Generated at 2022-06-12 19:42:25.015267
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:42:28.144928
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    pass



# Generated at 2022-06-12 19:42:35.794353
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Remove the logger.handlers, so that the output for this function
    # will not be affected by the logging configuration in the main
    # module.
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    logging.basicConfig(level=logging.DEBUG)
    def get_func(avm_class, func_name):
        return avm_class.method_pyfunctions[func_name]

    interpreter = SWFInterpreter(b'\x0F')
    interpreter.tag_do_abc = lambda _: test_abc_data
    class_abc = interpreter.extract_class(0, 'Class')
    assert class_abc.name == 'Class'
    assert class_abc.super_name == 'Object'
    names = class_abc.method_names


# Generated at 2022-06-12 19:42:45.973180
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    method = SWFInterpreter.patch_function
    is_elem_of = lambda res, container: any(r == res for r in container)
    # Test cases
    assert is_elem_of(method(ByteArray([0, 0, 0])), [None]) == True
    assert is_elem_of(method(ByteArray([1, 0, 0])), [None]) == True
    assert is_elem_of(method(ByteArray([2, 0, 0])), [None]) == True
    assert is_elem_of(method(ByteArray([3, 0, 0])), [None]) == True
    assert is_elem_of(method(ByteArray([4, 0, 0])), [None]) == True

# Generated at 2022-06-12 19:42:47.452518
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = _SWFInterpreter()
    interpreter.extract_function(None, 'foo')



# Generated at 2022-06-12 19:42:53.153208
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    f = io.BytesIO(base64.b64decode(TEST_SWF))
    swf = SWF(f)
    swf.read_header()
    swf.read_body()
    interpreter = SWFInterpreter(swf)

    assert len(interpreter.constant_strings) == 8
    assert len(interpreter.constant_namespace) == 2
    assert len(interpreter.multinames) == 3
    assert len(interpreter.methods) == 1
    assert len(interpreter.scripts) == 1
    assert len(interpreter.classes) == 1

# Test the basic actionscripts functionalities

# Generated at 2022-06-12 19:43:03.182277
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    class Class:
        abc = 3
        method_names = ['foo', 'bar', 'baz']