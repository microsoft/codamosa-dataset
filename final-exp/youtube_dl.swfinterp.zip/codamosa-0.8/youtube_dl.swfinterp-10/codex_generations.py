

# Generated at 2022-06-12 19:36:13.865055
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    def read_avm_file(fname, force_py_parser=False):
        if force_py_parser or not has_lxml():
            avm = _read_avm_file(fname)
        else:
            avm = _read_avm_file_lxml(fname)
        return avm
    avm = read_avm_file('tests/media/amf1.avm')
    intp = SWFInterpreter()
    intp.resolve(avm)
    func = intp.extract_function('_level16', '_level17', '_level18')
    assert func() == [1, 2, 3]

    avm = read_avm_file('tests/media/amf3.avm')
    intp = SWFInterpreter()
   

# Generated at 2022-06-12 19:36:25.032096
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from . import utils
    from .compat import binary_type, compat_socket

    _, content_type, body = utils.get_content(
        'https://www.youtube.com/watch?v=J---aiyznGQ')
    if not content_type.startswith('video/') and \
            not content_type.startswith('audio/'):
        if isinstance(body, binary_type):
            swfobj = SWFInterpreter(body)
        else:
            swfobj = SWFInterpreter(compat_socket.makefile(body, 'b'))
        assert swfobj
        assert swfobj.sign is 0x535746
        assert swfobj.version is 13
        assert swfobj.file_length is 493
        assert swfobj.frame

# Generated at 2022-06-12 19:36:30.619840
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import fileinput
    # Test on stream
    content = fileinput.input(
        '/Users/ben/Downloads/highcharts/js/highcharts.src.js')
    content_str = ''.join(content)
    swf = SWFInterpreter(content_str)
    assert swf.decompiled_code[0] == 'var HighchartsAdapter = (function(H){'
    assert swf.decompiled_code[-1] == 'return H; }(HighchartsAdapter));'
    
# Entry point

# Generated at 2022-06-12 19:36:42.247335
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swfinterpreter = SWFInterpreter()
    swf_data = compat_bytes(
        range(0, 4096))
    avm_class = swfinterpreter.extract_class(swf_data)
    assert isinstance(avm_class, _AVMClass)
    assert not isinstance(avm_class, _AVMClass_Object)

    swfinterpreter = SWFInterpreter()
    swf_data = compat_bytes(
        range(0, 4096))
    avm_class = swfinterpreter.extract_class(swf_data, is_object=False)
    assert isinstance(avm_class, _AVMClass)
    assert not isinstance(avm_class, _AVMClass_Object)

    swfinterpreter = SWFInterpre

# Generated at 2022-06-12 19:36:49.198680
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swf import SWF
    from .utils import hex_to_bytes


# Generated at 2022-06-12 19:36:50.785457
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    si = SWFInterpreter()
    si.patch_function('dummy', [])

# end class SWFInterpreter


# Generated at 2022-06-12 19:36:56.843049
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'test', 'AMF0_example.swf')
    infile = open(swf_path, 'rb')
    with infile:
        swf = SWFInterpreter(infile)

    if os.getenv('DEBUG'):
        print('Classes:')
        for avm_class in swf.classes:
            print(avm_class)
        print('Methods:')
        for fname, f in sorted(swf.functions.items()):
            print('    %s: %s' % (fname, f))
        print('Strings:')

# Generated at 2022-06-12 19:36:59.711992
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter(open('test.swf', 'rb').read())
    assert interpreter.do_abc_tag.tag_type == 82
    assert interpreter.do_abc_tag.abc_name == 'embedded.fonts.Font1'

    interpreter.extract_class('embedded.fonts.Font1')


# Generated at 2022-06-12 19:37:11.316492
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Create a new SWFInterpreter object
    from . import ENABLE_AMF
    from .swftags import SWFTagDoABC, SWFTagFileAttributes, SWFTagSetBackgroundColor, SWFTagSymbolClass
    from .swftags import SWFTagShowFrame, SWFTagDefineSprite, SWFTagPlaceObject2, SWFTagRemoveObject2
    from .swftags import SWFTagDoAction
    from .swfdoaction import SWFActionPush, SWFActionPushString, SWFActionConstantPool, SWFActionGetVariable
    from .swfdoaction import SWFActionSetVariable
    from .swfrect import SWFRect


# Generated at 2022-06-12 19:37:12.552512
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    SWFInterpreter.extract_function(avm_class=None, func_name=None)


# Generated at 2022-06-12 19:38:07.278777
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .utils import get_testdata_file
    from .subtitles import EmbeddedSubtitles

    with open(get_testdata_file('subtitles_subtitle.swf'), 'rb') as f:
        swf = f.read()
    swf_interpreter = SWFInterpreter.from_swf(swf)
    assert swf_interpreter.constant_strings == []
    assert swf_interpreter.avm2_classes == {}
    assert swf_interpreter.constant_namespaces == []

# Generated at 2022-06-12 19:38:13.337540
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import os
    import pickle

    this_dir = os.path.dirname(__file__)
    test_swfs_dir = os.path.join(
        this_dir, '..', '..', '..', '..', '..', 'test', 'media', 'swfs')
    with open(os.path.join(test_swfs_dir, 'test-ref.pkl'), 'rb') as f:
        ref = pickle.load(f)

    swf = ref['swf']
    avm_class = swf.avm2.classes[ref['class_name']]
    interp = SWFInterpreter(swf.avm2, avm_class)


# Generated at 2022-06-12 19:38:17.289617
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    tb = _ScopeDict('a')
    tb.update({'x': 1})
    assert repr(tb) == "_Scope(a, {'x': 1})"



# Generated at 2022-06-12 19:38:25.414869
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()

    avm_class = _AVMClass('Test', None, [
        # All these methods must be implemented in this function
        _AVMClass_Method('foo', None),
    ])
    avm_class.constant_strings = ['foo']

    # Test method foo
    foo_name = 'foo'
    foo_code = b'\x01\x00\x00\x00'  # nop

    func = interpreter.extract_function(
        avm_class, foo_name)
    assert func() is undefined

    # Test method foo (nop)
    foo_name = 'foo'
    foo_code = b'\x01\x00\x00\x00'  # nop


# Generated at 2022-06-12 19:38:30.600481
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from adobe_swf_parser import AdobeSWF
    filename = os.path.join(
        os.path.dirname(__file__),
        'testdata', 'avm1.swf')
    swf = AdobeSWF(filename)
    with contextlib.closing(swf):
        interpreter = SWFInterpreter(swf)
        with contextlib.closing(interpreter):
            assert interpreter.n_constant_strings == 0
            # TODO: get it actually working


# Helper function to read one byte

# Generated at 2022-06-12 19:38:32.945541
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_intr = SWFInterpreter()
    swf_intr.extract_function(SWFInterpreter.SWFClass, 'String')

if __name__ == '__main__':
    test_SWFInterpreter_extract_function()
# Test function install_abc()

# Generated at 2022-06-12 19:38:38.183154
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:38:45.549365
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    with open(os.path.join(os.path.dirname(__file__), 'swf', 'test.swf'), 'rb') as f:
        swf = SWF(f)

        interpreter = SWFInterpreter(swf)
        func = interpreter.extract_function(interpreter.avm_classes[0], 'avm2')
        args = [3, 4]
        assert func(args) == (3 + 4) * (3 - 4) + (3 / 4) * (3 % 4)

# Generated at 2022-06-12 19:38:56.097340
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    test_code = b'A\x02\x00\x03\x00'
    test_parser = SWFParser(test_code)
    test_avm2 = SWFInterpreter(test_parser)
    test_avm2.abc_scripts = [
        {'methods': [{'method_name': 'test_method'}]}]
    test_avm2.multinames = [{'name': 'test_name'}]
    test_avm2.constant_strings = ['test_constant']
    test_avm2.patch_function('test_method')
    expected_code = b'C\x02\x00\x03\x00'
    assert test_avm2.code == expected_code

# Class for file-like object storing an internal buffer
# we

# Generated at 2022-06-12 19:39:03.463910
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import swftools.swfdecompiler as swf
    interpreter = SWFInterpreter()

# Generated at 2022-06-12 19:41:35.340733
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import re
    import sys
    import unittest.mock as mock

    class MockInterpreter(object):
        @staticmethod
        def to_number(value):
            return value + 1

    interpreter = MockInterpreter()
    func_body = (
        'function test_patch(args) {\n'
        '  var result = to_number(args.x);\n'
        '  return result;\n'
        '}\n')
    func_patched = SWFInterpreter.patch_function(
        interpreter, func_body, 'test_patch')
    patched_func = compat_exec(func_patched)

    output = sys.stdout

# Generated at 2022-06-12 19:41:39.644012
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:41:42.106398
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    actual = repr(SWFInterpreter(b'').extract_function(None, None))
    assert isinstance(actual, compat_str)
    assert actual == '<function extract_function at 0x%x>' % actual.__code__.co_firstlineno


# Generated at 2022-06-12 19:41:48.747615
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swfi = SWFInterpreter()

# Generated at 2022-06-12 19:41:50.629919
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter(
        'META-INF/AIR/application.xml', 'META-INF/AIR/swf-version.xml')
    return interpreter


# Generated at 2022-06-12 19:41:55.730378
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():

    int1 = _AVMClass(
        'int', variables={}, class_properties={}, static_properties={},
        method_names={'toString'}, avm_interpreter=None)
    int1.avm_interpreter = _AVMInterpreter(
        class_names=['int', 'String', 'Array'],
        constant_strings=['a', 'b', 'c'], multinames=[0, 1, 2])
    int1.method_pyfunctions['toString'] = _Int_toString  # @UnusedVariable
    int2 = _AVMClass(
        'int', variables={}, class_properties={}, static_properties={},
        method_names={'toString'}, avm_interpreter=None)
    int2.avm_interpreter = _AVMInterpre

# Generated at 2022-06-12 19:42:04.150902
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .asconstants import as_constants
    from .swfdecompiler import SWFDecompiler
    from .swfheader import SWFHeader
    from .swftags import DefineBinaryDataTag
    from .swftags import FileAttributesTag
    from .swftags import SWFTag
    from .swftags import SymbolClassTag

    def define_binary_data(data):
        from .swfdata import SWFData

        tag = DefineBinaryDataTag()
        tag.character_id = 1
        tag.data = SWFData(tag=tag)
        tag.data.data = data
        return tag

    def file_attributes(swf_version, avm_version):
        tag = FileAttributesTag()
        tag.has_metadata = True
        tag.use_network = True
       

# Generated at 2022-06-12 19:42:14.212365
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import pickle
    from .compat import compat_StringIO
    from .compat.dictproxy import viewkeys


    class SWFInterpreter_Mock(SWFInterpreter):

        def __init__(self):
            self.constant_strings = {}
            self.multinames = []
            self.methods = []
            self.strings = {}

    def make_codedata(codestr):
        buf = compat_StringIO()
        buf.write(codestr)
        buf.seek(0)
        codefile = buf
        codedata = codefile.read()
        return codedata


    def test_1(debug=False):
        interpreter = SWFInterpreter_Mock()
        if debug:
            interpreter.debug = True
            interpreter.debug_trace = sys.std

# Generated at 2022-06-12 19:42:22.781389
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter = SWFInterpreter(None)
    swf_interpreter.constant_strings = ['a', 'b', 'c']
    swf_interpreter.multinames = [
        _Multiname(0, 0, 0, ['a', 'b']),
        'c',
    ]
    avm_class = _AVMClass(None, {}, {'a': 6})

# Generated at 2022-06-12 19:42:28.271743
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.avm2_classes = {}
    swf_interpreter.inheritance_tree = {'Object': None}
    swf_interpreter.constant_strings = ['getName', 'getVersion', 'getUrl', 'getConfig', 'getFile', 'getPath', 'getCookie', 'getUserAgent', 'getReferrer', 'getToken', 'parseInt', 'setProperty', 'addEventListener', 'getTicks', 'getTime', 'createEmptyMovieClip', 'setClipParams', 'setMember', 'buttonPressed', 'onButtonPress']
    swf_interpreter.multinames = [None, 'getTime', None, None, 'getTime2']
    avm2_class_object = pyam

# Generated at 2022-06-12 19:44:26.932171
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interp = SWFInterpreter()
    class_bytecodes = [
        0x30, 0x01, 0x00, 0x01, 0x01, 0x01, 0x01, 0x01,
        0x13, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    ]
    class_bytecodes = map(compat_ord, class_bytecodes)
    class_bytecoder = compat_BytesIO(class_bytecodes)

# Generated at 2022-06-12 19:44:32.774170
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    itr = SWFInterpreter()
    itr.extract_class(SWFInterpreterTest_AVMClass_Object)
    assert not isinstance(itr.avm_classes, _ScopeDict)
    assert isinstance(itr.avm_classes['Object'], _AVMClass)
    assert not isinstance(itr.avm_classes['Object'].variables, _ScopeDict)

# Generated at 2022-06-12 19:44:40.517234
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    SWF_FILE_PATH = 'tests/data/sample1.swf'

    with open(SWF_FILE_PATH, 'rb') as f:
        swf = f.read()
    version, frames, width, height, ftw, frame_rate = SWF.read_header(swf)
    assert version == 9
    assert width == 640
    assert height == 480

    interpreter = SWFInterpreter(swf)

    avm_class = interpreter.avm_classes[-1]
    code = avm_class.method_codes[0]

    (resfunc, _) = extract_function(code, 0, interpreter, avm_class)

    assert resfunc([]) == {}


# Generated at 2022-06-12 19:44:46.406796
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import base64
    with open(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'swfdecompress.py')) as stream:
        source = stream.read()

    with open(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'swfb64'),
        'rb') as stream:
        swfb64 = stream.read()

    swf = SWFInterpreter(BytesIO(base64.b64decode(swfb64)))

    assert source == swf.extract_class('decompress')
    assert source.startswith('class SWFDecompress:\n')

# Generated at 2022-06-12 19:44:51.515723
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from . import tests
    import io
    import sys

    if sys.version_info >= (2, 7):
        from unittest import mock
    else:
        import mock

    swf = io.BytesIO(tests.swf_data)
    swf.name = 'test_SWFInterpreter_extract_class'
    with mock.patch(
            'youtube_dl.extractor.youtube.SWFInterpreter.extract_function') \
            as mock_extract_function:
        swf.seek(0)
        interpreter = SWFInterpreter(swf)
        swf.seek(0)
        interpreter.extract_class(swf)

    assert mock_extract_function.call_count == 1

# Generated at 2022-06-12 19:44:52.068547
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    pass

# Generated at 2022-06-12 19:44:58.732037
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()
    interpreter.load(os.path.join(
        testfiles_path, 'youtube', 'great_swf_interpreter_unit_test.swf'))
    assert len(interpreter.constant_strings) == 14
    assert len(interpreter.multinames) == 23
    assert len(interpreter.methods) == 1
    assert 'extract_function_test' in interpreter.methods[0].avm_class.method_pyfunctions

    res = interpreter.methods[0].avm_class.method_pyfunctions['extract_function_test'](
        [interpreter.methods[0].avm_class.make_object()])

# Generated at 2022-06-12 19:45:08.743448
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = io.BytesIO()
    swf.seek(0, 2)
    off = swf.tell()
    writer = SWF.SWFWriter(swf, 1, 10, 10, {})
    writer.write_header()
    writer.write_byte(4)  # DoABC
    writer.write_u24(0)  # Flags
    writer.write_u32(0)  # Name
    main_abc_ofs = swf.tell()
    abc = writer.write_byte(0)
    abc.seek(0)
    abc.write(b'\x09')  # abcFile
    abc.write(sint30(1))  # minor_version
    abc.write(sint30(46))  # major_version

# Generated at 2022-06-12 19:45:17.327419
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():

    # The following method is run for each swf file in the testsuite directory.
    # It extracts the classes from the swf files and checks if the resulting
    # classes are available.
    def do_extract_and_check(swf_filename):
        interpreter = SWFInterpreter()
        with open(swf_filename, 'rb') as swf_file:
            with open(swf_filename + '.avm.info', 'rb') as avm_file_info:
                classes = interpreter.extract_classes(swf_file, avm_file_info)
        missing_classes = []
        for cl in classes:
            if not hasattr(cl, 'main'):
                continue
            func = cl.main()
            if func is None:
                missing_classes.append(cl)
        return missing_

# Generated at 2022-06-12 19:45:19.205288
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter()
    assert swf.create_class('Object') == {'_name': 'Object'}


if __name__ == '__main__':
    test_SWFInterpreter()