

# Generated at 2022-06-12 19:36:13.895392
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class _MockAVMClass():
        pass
    avm_class = _MockAVMClass()
    avm_class.method_pyfunctions = {}

# Generated at 2022-06-12 19:36:20.889826
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    an_interpreter = SWFInterpreter()
    with open('../../example-swfs/asvals/asvals-compiled.swf', 'rb') as f:
        an_interpreter.read(f)
        for c in an_interpreter.extract_classes():
            print(c)
    return an_interpreter

# Generated at 2022-06-12 19:36:29.402468
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    class FakeAVMClass(object):
        def __init__(self):
            self.static_properties = {}
            self.instance_properties = {}
            self.method_pyfunctions = {}
        def add_variable(self, name, value):
            self.static_properties[name] = value

    a = FakeAVMClass()
    interpreter = SWFInterpreter(a)
    assert interpreter.extract_function(a, 'm_') is None

# Generated at 2022-06-12 19:36:30.496600
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert SWFInterpreter('playerProductInstall.swf')


# Generated at 2022-06-12 19:36:42.091970
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:36:51.371196
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:36:53.853168
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    file_name = 'yt.swf'
    interpreter = SWFInterpreter(file_name)
    func = interpreter.extract_function(
        interpreter.avm_classes['yt'], 'getVideoPlayerModule')
    assert func is not None



# Generated at 2022-06-12 19:37:00.136143
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .abc import _parse_abc_multiname, _parse_abc_multiname_l

    def _check_extract_function(source):
        a = SWFInterpreter()
        a.constant_strings.append(source)
        avm_class = _AVMClass({
            'test_method': {
                'id': 0,
                'body': _Body(
                    method='test_method', max_stack=2, max_regs=2,
                    scope_depth=1, init_scope_depth=1,
                    code=b'\x05' + u30(len(source)) + b'\x0B' + s24(3),
                    exceptions=[],
                    traits=[],
                ),
            },
        }, [])

# Generated at 2022-06-12 19:37:07.322374
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import unittest
    import io

    class TestSWFInterpreter(unittest.TestCase):
        def test_decompile(self):
            swf = SWFInterpreter(io.BytesIO(b'CWS'))
            # Add a DummyScreen
            swf.screens.append(_DummyScreen())
            swf.decompile()

    unittest.main()

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-12 19:37:09.040471
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    pass # TODO


# Generated at 2022-06-12 19:38:29.391655
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    si = SWFInterpreter()

# Generated at 2022-06-12 19:38:33.351459
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    i = SWFInterpreter()
    i.extract_class(fake_class, 'fake_class')
    assert i.fake_class.make_object().func1('hello') == 'hello'
    def func1_patch(args):
        assert len(args) == 1
        return args[0] + ' world'
    i.patch_function(fake_class, 'func1', func1_patch)
    assert i.fake_class.make_object().func1('hello') == 'hello world'



# Generated at 2022-06-12 19:38:38.414920
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    from .abc_format import ABCFormat
    from .swf_format import SWF
    swf = SWF(open(os.path.join(os.path.dirname(__file__), 'tests',
                                'fixtures', 'test1.swf'), 'rb'))
    abc = ABCFormat()
    abc.load(BytesIO(swf.abc_data))
    s = SWFInterpreter(abc)
    c = s.extract_class(swf, abc.classes[0])
    assert c.name == 'Test'

    # Test if method 'run' returns the correct value
    class_instance = c()
    assert class_instance.run == 3

    # Test if method 'add' returns the correct value
    assert class_instance.add(1, 2) == 3

    # Test

# Generated at 2022-06-12 19:38:42.766197
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .swf_parser import SWFParser
    from .int_classes import _AbcFile

    test_swf = SWFParser(
        'tests/swfs/videoad_preroll_revive_player.swf',
        parse_actionscript=False)
    test_swf.load_abc_file()
    test_swf._abc_file = _AbcFile(
        test_swf._abc_file.abc_data,
        test_swf._abc_file.constant_pool,
        test_swf._abc_file.methods,
        test_swf._abc_file.metadata,
        test_swf._abc_file.classes,
        test_swf._abc_file.scripts,
        test_swf._abc_file.method_bodies)

    interp

# Generated at 2022-06-12 19:38:49.453601
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    from .externals.ply import lex
    from .externals.ply import yacc
    from .test.test_interpreter import (
        as_lexer, as_parser, to_bytes, to_bits)
    from .test.test_interpreter import parse_swf_text


# Generated at 2022-06-12 19:38:54.567015
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    test_pathname = os.path.join(
        os.path.dirname(__file__),
        'test_SWFInterpreter_extract_class_with_ABC.swf')
    with open(test_pathname, 'rb') as fin:
        swf = fin.read()
        swf_header = SWF.SWFHeader(BytesIO(swf))
        swf_body = SWF.SWFBody(BytesIO(swf[8:]))

# Generated at 2022-06-12 19:39:02.123415
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    import unittest

    class TestSWFInterpreter(unittest.TestCase):
        def setUp(self):
            class TestClass(object):
                @classmethod
                def get_args(cls):
                    return ['fake']

            self.test_class = TestClass

        def test_extract_function(self):

            # Test with simple non-class-based code
            class SimpleClass(object):
                pass


# Generated at 2022-06-12 19:39:11.078454
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    def test(method_name, expected_method_names):
        class SomeClass(object):
            def __init__(self):
                self.method_names = set()
                self.static_properties = {}
                self.method_pyfunctions = {}

        swfinterp = SWFInterpreter()

        ttag_doabc = FLVABCTag()
        ttag_doabc.read_body = lambda a: None
        ttag_doabc.body_bytes = pickle.dumps(b'\x00\x00\x00\x00\x00\x00')

        swfinterp.extract_class(method_name, [ttag_doabc], SomeClass())

        method_names = set(SomeClass().method_pyfunctions)

# Generated at 2022-06-12 19:39:20.934647
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swfdata = open(
        os.path.join(
            os.path.dirname(__file__), 'test', 'assets', 'test.swf'),
        'rb').read()
    interpreter = SWFInterpreter(swfdata)
    assert interpreter.version == 19
    assert interpreter.file_size == len(swfdata)
    assert interpreter.frame_size == [0, 0, 550, 400]
    assert interpreter.frame_rate == 30.0
    assert interpreter.frame_count == 1

# Generated at 2022-06-12 19:39:27.946058
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-12 19:41:04.089206
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    c = SWFInterpreter()
    assert c is not None


# Generated at 2022-06-12 19:41:10.368851
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO
    from .swf import SWF

# Generated at 2022-06-12 19:41:20.609060
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    class TestSWFInterpreter(SWFInterpreter):
        def __init__(self, *args, **kwargs):
            super(TestSWFInterpreter, self).__init__(*args, **kwargs)
            self.builtin_classes = {}
    ti = TestSWFInterpreter()

    with open(os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'test_extract_class.swf'), 'rb') as f:
        data = f.read()

    ti.read_swf(io.BytesIO(data))

    assert_equal(len(ti.constant_strings), 5)
    assert_equal(ti.constant_strings[0], 'MnFPnf')

# Generated at 2022-06-12 19:41:21.463832
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    pass


# Generated at 2022-06-12 19:41:29.209911
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interpreter = SWFInterpreter()

# Generated at 2022-06-12 19:41:34.945134
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    filename = os.path.join(
        os.path.dirname(__file__), '..', '..', 'tests', 'testdata',
        'test_decode.swf')
    with open(filename, 'rb') as f:
        swf_data = f.read()
    interpreter = SWFInterpreter(swf_data)
    assert len(interpreter.extract_classes()) == 1

# Generated at 2022-06-12 19:41:40.995380
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    si = SWFInterpreter()
    si.parse_tags(open(os.path.join(os.path.dirname(__file__), '../assets/bootstrap.swf'), 'rb'))
    si.expose_method('Bootstrap.log')
    assert si.extract_function(si.classes['Bootstrap'], 'log')
    #assert si.extract_function(si.classes['Bootstrap'], 'log')(['foo']) == None


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-12 19:41:45.508373
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .compat_struct import Struct
    from .utils import (
        int2byte, byte2int, bytes_to_uint24, uint24_to_bytes,
        bytes_to_uint30, uint30_to_bytes,
    )

    i = SWFInterpreter()
    s = compat_str if sys.version_info < (3,) else bytes

    def check(script_data, expected_output, expected_return=None,
              expected_registers=None, expected_stack=None,
              expected_scopes=None):
        #script_data = script_data.encode('ascii')
        if expected_return is None:
            expected_return = undefined
        if expected_registers is None:
            expected_registers = [undefined] * 4

# Generated at 2022-06-12 19:41:49.009151
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWFInterpreter()
    swf.load(INPUT_FILE)
    swf.parse()
    swf.extract_classes_and_functions()
    assert len(swf.classes) == 4, 'there are 4 classes: %r' % swf.classes
    assert 'Object' in swf.classes, 'Object is a class: %r' % swf.classes

# Generated at 2022-06-12 19:41:53.740594
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from .swfdecompiler import decompile_to_swf
    from .swfdecompiler import decompile_to_xml
    from .swfdecompiler import swf_extract_doABC_tag


# Generated at 2022-06-12 19:44:03.949159
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    interp = SWFInterpreter()
    interp.extract_class(None, None)


# Class representing an AVM object

# Generated at 2022-06-12 19:44:10.473773
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from collections import namedtuple
    class FakeMultiname(object):
        def __init__(self, name, k, l):
            self.name = name
            self.k = k
            self.l = l

    class FakeMultinameResolver(object):
        def resolve(self, multiname):
            for idx, (k, l) in enumerate(self.multinames):
                if k == multiname.k and l == multiname.l:
                    return idx
            assert False, 'multiname not known'

        def __init__(self, multinames):
            self.multinames = multinames


# Generated at 2022-06-12 19:44:18.033241
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    import binascii
    from io import BytesIO
    from yarl import URL
    from .swfextractor import SWFExtractor
    from .swfdecompressor import decompress_swf
    from .amf import decode_amf3, encode_amf3, dump_amf3, detect_amf,\
        read_amf_data, read_amf_strict
    from .compat import compat_urllib_request, compat_struct_unpack
    from .utils import encode_compat_str
    from .compat import compat_chr

    # Flag: execute all tests
    test_all = False

    # Flag: verbose logging
    test_verbose = False

    # Flag: execute test_obj_in_list
    test_obj_in_list = False

    # Flag

# Generated at 2022-06-12 19:44:24.984321
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    fi = SWFInterpreter()
    assert isinstance(fi, SWFInterpreter)
    assert isinstance(fi.constant_strings, list)
    assert isinstance(fi.constant_floats, list)
    assert isinstance(fi.constant_ints, list)
    assert isinstance(fi.constant_uints, list)
    assert isinstance(fi.method_bodies, list)
    assert isinstance(fi.instances, list)
    assert isinstance(fi.classes, list)
    assert isinstance(fi.scripts, list)
    assert isinstance(fi.method_names, list)
    assert isinstance(fi.multinames, list)
    assert isinstance(fi.metadata, list)
    assert isinstance(fi.method_signatures, list)

# Generated at 2022-06-12 19:44:27.905468
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = open(os.path.join(TEST_DIR, 'flash/playerProductInstall.swf'), 'rb').read()
    interpreter = SWFInterpreter(swf)
    interpreter.extract_class('\x03')

# Generated at 2022-06-12 19:44:34.077715
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    import os
    import os.path
    from .util import get_test_file_url


# Generated at 2022-06-12 19:44:41.825534
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    with open(test_file, 'rb') as f:
        swf = SWFInterpreter(f, False)
    obj = {}
    func = swf.extract_function(swf.root['com.foo.bar'], 'simple')
    assert func([obj]) is None
    assert obj == {u'simple': u'simple'}
    obj = {}
    func = swf.extract_function(swf.root['com.foo.bar'], 'NonStaticMethod')
    assert func([obj]) is None
    assert obj == {u'NonStaticMethod': u'NonStaticMethod'}
    obj = {}
    func = swf.extract_function(swf.root['com.foo.bar'], 'prop')
    assert func([]) == u'prop'
    assert obj == {}


# Generated at 2022-06-12 19:44:46.663802
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_bytes = get_test_data('as3/helloworld.swf')
    interpreter = SWFInterpreter(swf_bytes)
    assert interpreter.extract_class('HelloWorld')



# Generated at 2022-06-12 19:44:53.189483
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-12 19:44:59.733261
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = open(TEST_FILE, 'rb').read()
    avm = SWFInterpreter(swf)
    avm.extract_class('VideoPlayerClassic')
    avm.extract_class('VideoPlayerHTML5')
    avm.extract_class('VideoPlayerStageVideo')
    avm.extract_class('VideoPlayer')
    avm.extract_class('VideoPlayerJsWrapper')
    avm.extract_class('Main')
    avm.extract_class('MainComplete')
    avm.extract_class('MainHD')
    avm.extract_class('MainHDComplete')
    avm.extract_class('MainUnified')
    avm.extract_class('MTVPlayer')
    avm.extract_class('MTVPlayerHD')
