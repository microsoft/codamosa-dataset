

# Generated at 2022-06-26 13:55:31.352595
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Pytest doesn't support scoped variables, so we have to use globals
    global undefined_0, var_0

    # Call the function
    undefined_0 = _Undefined()
    var_0 = undefined_0.__bool__()

    # Check the result
    assert var_0 == False


# Generated at 2022-06-26 13:55:42.942911
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Create a demo class to run a test on
    class TestClass(object):

        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    class TestAvmClass(object):

        def __init__(self, *args):
            self.args = args
            self.objects = []

        def make_object(self):
            res = TestClass(*self.args)
            self.objects.append(res)
            return res

        def __getitem__(self, idx):
            return self.objects[idx]

    avm_class = _AVMClass()
    avm_class.static_properties = {}
    avm_class.static_properties['TestClass'] = TestAvmClass

    # Create a demo swf

# Generated at 2022-06-26 13:55:46.509695
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Create an instance of SWFInterpreter
    swf_interp = SWFInterpreter(None, None, None)

    # Create an instance of ActionCode object
    action_0 = ActionCode()

    # Invoke method patch_function on object
    swf_interp.patch_function(action_0, None)



# Generated at 2022-06-26 13:55:47.842526
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    var_0 = test_case_0()


# Generated at 2022-06-26 13:55:48.977825
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter('')



# Generated at 2022-06-26 13:55:55.663234
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    test_class = _AVMClass('test_class', (), {})
    test_class.make_object()
    test_class.static_properties = {
        'test_var': 'test_value'
    }
    test_class.method_names = [
        'test_function'
    ]
    test_class.method_pyfunctions = {
        'test_function': lambda *args: None
    }
    test_class.variables = {
        'test_variable': 'test_value'
    }

    class_id = test_class.id
    assert SWFInterpreter.extract_class(class_id) == test_class


# Generated at 2022-06-26 13:55:58.012335
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert isinstance(SWFInterpreter(), SWFInterpreter)

# Unit tests for method _AVMClass_Object.__getitem__

# Generated at 2022-06-26 13:56:05.116744
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 13:56:07.010492
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    test_case_0()

test_case_0()



# Generated at 2022-06-26 13:56:18.326225
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Test case const_0
    const_0 = compat_str('')
    # Test case const_1
    const_1 = 0
    # Test case const_2
    const_2 = compat_str('')
    # Test case const_3
    const_3 = 0
    # Test case const_4
    const_4 = compat_str('')
    # Test case const_5
    const_5 = 0
    # Test case const_6
    const_6 = 0
    # Test case const_7
    const_7 = compat_str('')
    # Test case const_8
    const_8 = 0
    # Test case const_9
    const_9 = 0
    # Test case const_10
    const_10 = compat_str('')
    # Test case const_11
   

# Generated at 2022-06-26 13:57:56.748417
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s_w_f_interpreter_0 = SWFInterpreter()
    abc_data_0 = open('/home/travis/build/rg3/youtube-dl/tests/swfinterpreter/0.abc', 'rb').read()
    res_0 = s_w_f_interpreter_0.extract_class(abc_data_0, 'Test')
    assert res_0.name == 'Test'
    assert res_0.super_name == 'Object'
    assert res_0.flags == 0
    assert res_0.is_interface
    assert res_0.interfaces == ['IEventDispatcher', 'IDataInput', 'IDataOutput']
    assert len(res_0.static_properties) == 2
    assert len(res_0.static_properties['_pointer'])

# Generated at 2022-06-26 13:58:03.999105
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 13:58:05.683073
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    case_0()
    assert True # TODO: implement your test here



# Generated at 2022-06-26 13:58:13.614396
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s_w_f_interpreter_0 = SWFInterpreter()
    class_data_0 = _ClassData(
        class_name='FirstClass',
        super_class_name='',
        attr=0,
        init_index=0,
        trait_count=0,
        traits=[],
        static_trait_count=0,
        static_traits=[],
    )
    s_w_f_interpreter_0.class_data_list.append(class_data_0)
    s_w_f_interpreter_0.extract_class()
    print('%r' % s_w_f_interpreter_0.classes)


# Generated at 2022-06-26 13:58:20.513033
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s_w_f_interpreter_1 = SWFInterpreter()
    avm_class_1 = AVMClass()
    func_code_1 = b'\x10\x00\x00\x00\x00\x9c\x00'
    func_name_1 = 'test'
    s_w_f_interpreter_1.patch_function(
        avm_class_1, func_code_1, func_name_1)



# Generated at 2022-06-26 13:58:30.302421
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_0 = SWFInterpreter()

    def _testf(self):
        pass

    with open('tests/SWFInterpreter/ActionRecord.dump', 'rb') as f:
        s_w_f_interpreter_0.extract_function(_testf, f)

    # Assert that all the extracted function are actually functions
    for v in s_w_f_interpreter_0.classes.values():
        try:
            for k in v.method_pyfunctions.keys():
                assert isinstance(v.method_pyfunctions[k], FunctionType)
        except AttributeError:
            pass

test_case_0()
test_SWFInterpreter_extract_function()

# Generated at 2022-06-26 13:58:31.239175
# Unit test for method __repr__ of class _ScopeDict
def test__ScopeDict___repr__():
    assert 'test__ScopeDict___repr__' in globals()
    s_w_f_interpreter_0 = test_case_0()


# Generated at 2022-06-26 13:58:34.602197
# Unit test for method __repr__ of class _ScopeDict

# Generated at 2022-06-26 13:58:46.593734
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    avm_class = _AVMClass()
    avm_class.static_properties['val'] = 1
    coder = BytesIO()

# Generated at 2022-06-26 13:58:50.886518
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    s_w_f_interpreter_1 = SWFInterpreter()

    # Test extraction from empty opcode list
    assert s_w_f_interpreter_1.extract_class([]) == _AVMClass(
        [], [], [], [], {}, {})


# Generated at 2022-06-26 14:00:03.812608
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    s_w_f_interpreter_0 = SWFInterpreter()

    def wrapped_f_SWFInterpreter_extract_function(s_w_f_interpreter_0):
        s_w_f_interpreter_0.extract_function(
            avm_class=None, func_name='', constant_integers=[],
            constant_uintegers=[], constant_doubles=[],
            constant_strings=[], constant_namespaces=[],
            constant_namespace_sets=[], constant_multinames=[],
            method_param_types=[], method_return_type=0, method_name='')

    for i in range(10):
        if i == 5:
            continue

# Generated at 2022-06-26 14:00:05.307613
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    assert 'class_1' in s_w_f_interpreter_0.static_properties, \
        'Failed to extract class class_1'


# Generated at 2022-06-26 14:00:06.403241
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    try:
        SWFInterpreter()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-26 14:00:10.110188
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    for tag_id, reader in [
            (39, io.BytesIO(b'\x00\x00')),
            (70, io.BytesIO(b'\x04\x00\x00')),
            (82, io.BytesIO(b'\x00\x00\x00\x00\x00\x00')),
    ]:
        yield test_case_0, tag_id, reader



# Generated at 2022-06-26 14:00:18.962147
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    import pickle
    path = os.path.join('swf', 'actions.swf')
    with open(path, 'rb') as f:
        swf = pickle.load(f, encoding='bytes')

    swf_interpreter = SWFInterpreter()

    swf['d']['__init__']['pyfunc'] = lambda x: None
    globals_0 = {}
    method_name_0 = '__init__'
    args_0 = []
    res_0 = swf_interpreter.extract_class(swf, method_name_0, globals_0, args_0)

    assert res_0 is not None
    assert res_0.avm_class.variables['a'] == 'Foo'


# Generated at 2022-06-26 14:00:22.586699
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert_raises(TypeError, SWFInterpreter.SWFInterpreter, None)
    s_w_f_interpreter_0 = SWFInterpreter()

# Test for method extract_function()

# Generated at 2022-06-26 14:00:30.027116
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s_w_f_interpreter = SWFInterpreter()
    # (1) Patch the unpatched function
    s_w_f_interpreter.patch_function('some_function', 'new_code')
    # (2) Patch the patched function
    s_w_f_interpreter.patch_function('some_function', 'newer_code')
    # (3) Call the patched function
    res = s_w_f_interpreter.call_function('some_function')
    expected_res = 'newer_code'
    assert res == expected_res



# Generated at 2022-06-26 14:00:34.722031
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Check reading of constants
    abc_0 = s_w_f_interpreter_0.constant_strings
    assert abc_0[0] == ''
    assert abc_0[1] == 'abc'
    assert abc_0[2] == 'def'

    # Check reading of multinames
    mnames_0 = s_w_f_interpreter_0.multinames
    assert mnames_0[0] == ''
    assert mnames_0[1] == 'abc'
    assert mnames_0[2] == 'def'



# Generated at 2022-06-26 14:00:44.643154
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s_w_f_interpreter_0 = SWFInterpreter()
    function_0 = s_w_f_interpreter_0.patch_function(
        s_w_f_interpreter_0.avm_classes[0], '__constructor__')
    function_1 = s_w_f_interpreter_0.patch_function(
        s_w_f_interpreter_0.avm_classes[2], '__constructor__')

    # test with AVMClass_Object
    obj_0 = function_0([])
    assert obj_0.avm_class.instance_properties['rtmp_url'] == undefined
    # test with _AVMClass
    obj_1 = function_1.avm_class([])

# Generated at 2022-06-26 14:00:48.300357
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    s_w_f_interpreter_0 = SWFInterpreter()
    assert isinstance(s_w_f_interpreter_0, SWFInterpreter)


# Generated at 2022-06-26 14:01:40.743836
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    a_SWFInterpreter = SWFInterpreter()


# Generated at 2022-06-26 14:01:47.783503
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter('examples/sample.swf')
    assert swf.version == 21
    assert swf.frame_size == (550, 400)
    assert swf.frame_rate == 25
    assert swf.frame_count == 1
    assert swf.tags == [{
        'id': 39,
        'header': {
            'compressed': True,
            'length': 4,
        },
        'body': b'\x00\x00\x00\x00',
    }]


# Unit tests for method get_class_name of class SWFInterpreter

# Generated at 2022-06-26 14:01:55.466252
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    with open(filename, 'rb') as f:
        swf = SWF(f)
    assert len(swf.tags) == 2
    assert swf.tags[0].code == sheet_id
    sheet = swf.tags[0]
    assert sheet.compressed
    assert sheet.decompressed_len == sheet_len

    assert swf.tags[1].code == 39
    shape = swf.tags[1]
    assert shape.compressed
    assert shape.decompressed_len == shape_len

    interp = SWFInterpreter(sheet.data[:])
    avm_class = _AVMClass(interp)
    resfunc = interp.extract_function(avm_class, 'test_case_0')

    # Verify that we do not crash and return something
    assert res

# Generated at 2022-06-26 14:02:05.790063
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 14:02:07.889456
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # TODO: Implement test for test_SWFInterpreter_patch_function
    raise NotImplementedError()


# Generated at 2022-06-26 14:02:15.455680
# Unit test for constructor of class SWFInterpreter

# Generated at 2022-06-26 14:02:16.611342
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert isinstance(SWFInterpreter(), SWFInterpreter)



# Generated at 2022-06-26 14:02:25.616538
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_SWFInterpreter = SWFInterpreter(
        constant_strings=['', '', '', ''], multinames=[],
        methods=[], metadata=[], classes=[], scripts=[],
        method_bodies=[
            SWFMethodBody(
                method_name='', method_traits=[],
                max_stack=0, local_count=0, init_scope_depth=0, max_scope_depth=0,
                code=[], exeception_table=[],
                traits=[]
            )
        ],
    )
    assert test_SWFInterpreter.constant_strings == ['', '', '', ''],\
        test_SWFInterpreter.constant_strings
    assert test_SWFInterpreter.multinames == [], test_SWFInterpreter.multinames


# Generated at 2022-06-26 14:02:31.537362
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    class_name = 'SWFInterpreter'
    method_name = 'SWFInterpreter'
    params = []
    tester.start_test(class_name, method_name, params)
    avm_class = tester.load_class('%s' % class_name)
    instance = avm_class.make_instance()
    actual = instance.constructor()
    expected = None
    tester.check(actual, expected)


# Generated at 2022-06-26 14:02:33.926368
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.extract_function(test_case_0)


# Generated at 2022-06-26 14:04:23.679059
# Unit test for method extract_function of class SWFInterpreter