

# Generated at 2022-06-26 13:55:56.639664
# Unit test for method patch_function of class SWFInterpreter

# Generated at 2022-06-26 13:55:57.772411
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = SWFInterpreter()
    swf.test_case_0()


# Generated at 2022-06-26 13:55:59.450492
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    var_0 = SWFInterpreter()
    test_case_0()

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-26 13:56:02.136700
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    assert callable(SWFInterpreter)
    assert_raises(TypeError, SWFInterpreter)
    s = SWFInterpreter(None)
    s = SWFInterpreter(b'blah')



# Generated at 2022-06-26 13:56:04.774604
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # TODO: check if it works properly
    assert SWFInterpreter()



# Generated at 2022-06-26 13:56:16.393928
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    f = compat_StringIO()
    f.write(b'\x43\x57\x53\x06\x06\x00\x00\x00\x70\x00\x00\x00')
    f.seek(0)

    swf_interpreter = SWFInterpreter(f)


# Generated at 2022-06-26 13:56:27.130607
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Constants
    CONSTANT_INT = 0x03
    CONSTANT_UINT = 0x04
    CONSTANT_DOUBLE = 0x06
    CONSTANT_UTF8 = 0x01
    CONSTANT_TRUE = 0x0b
    CONSTANT_FALSE = 0x0a
    CONSTANT_UNDEFINED = 0x00
    CONSTANT_NULL = 0x0c
    CONSTANT_NAMESPACE = 0x08
    CONSTANT_PACKAGE_NAMESPACE = 0x16
    CONSTANT_PRIVATE_NAMESPACE = 0x18
    CONSTANT_QNAME = 0x07
    CONSTANT_QNAME_A = 0x0d
    CONSTANT_RTQNAME = 0x0f
    CONST

# Generated at 2022-06-26 13:56:34.745313
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():

    # args:
    # (1, 2, ('a', 'b'))

    # ...
    a = undefined_0.__eq__(var_0)
    # ...
    var_2 = undefined_0.__gt__(var_0)
    if not var_2:
        var_3 = undefined_0.__gt__(var_0)
        if not var_3:
            var_4 = undefined_0.__eq__(var_0)
            if not var_4:
                var_5 = undefined_0.__eq__(var_0)
                if not var_5:
                    a = None
                    # ...
                    var_7 = undefined_0.__gt__(var_0)

# Generated at 2022-06-26 13:56:35.937384
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # TODO:
    pass


# Generated at 2022-06-26 13:56:46.703325
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter = SWFInterpreter()

# Generated at 2022-06-26 13:58:08.455725
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    """Test for constructor of class SWFInterpreter"""
    tuple_0 = ()
    s_w_f_interpreter_0 = SWFInterpreter(tuple_0)
    assert s_w_f_interpreter_0 is not None



# Generated at 2022-06-26 13:58:11.674193
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    tuple_0 = ()
    string_0 = 'class0'
    s_w_f_interpreter_0 = SWFInterpreter(tuple_0)
    extract_class_0 = s_w_f_interpreter_0.extract_class(string_0)



# Generated at 2022-06-26 13:58:22.377645
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    obj_0 = SWFInterpreter()
    obj_1 = _AVMClass(obj_0)
    obj_2 = _AVMClass_Object(obj_1)
    obj_3 = _AVMClass_String(obj_0)
    obj_1.static_properties = {
        'String': obj_3,
    }

    def func_0(args, this):
        if len(args) == 0:  # new HTTPStream
            return _AVMClass_HTTPStream(obj_0)
        elif len(args) == 3:  # new Sound
            assert isinstance(args[0], _AVMClass_HTTPStream)
            assert isinstance(args[1], int)
            assert isinstance(args[2], int)
            return _AVMClass_Sound(obj_0)

# Generated at 2022-06-26 13:58:32.024929
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    tuple_1 = ()
    s_w_f_interpreter_1 = SWFInterpreter(tuple_1)
    def t_e_s_t_s_w_f_interpreter_extract_class_body_0(avm_class):
        assert avm_class.class_name == 'com.example.classes.HelloWorld',\
            'com.example.classes.HelloWorld'
        assert avm_class.instance_method_names == ['main', 'trace'],\
            '["main", "trace"]'
        assert avm_class.super_class == ObjectClass,\
            'ObjectClass'
        assert avm_class.static_properties == {},\
            '{}'
        pass


    t_e_s_t_s_w_f_interpreter

# Generated at 2022-06-26 13:58:32.971367
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    """Class SWFInterpreter, method extract_function"""
    return


# Generated at 2022-06-26 13:58:45.324215
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 13:58:48.543815
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    print('SWFInterpreter.patch_function')
    tuple_0 = ()
    s_w_f_interpreter_0 = SWFInterpreter(tuple_0)
    test_case_0()


# Generated at 2022-06-26 13:58:52.976726
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    tuple_0 = ()
    s_w_f_interpreter_0 = SWFInterpreter(tuple_0)
    s_w_f_data_0 = SWFData(b'')
    extract_class_unimplemented('SWFData', s_w_f_data_0)


# Generated at 2022-06-26 13:59:00.657451
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 13:59:07.468730
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    """Test SWFInterpreter.patch_function"""
    tuple_0 = ('playpause', 'stop', 'resize', 'skip', 'jump', 'shuffle',
        'repeat', 'seek', 'next', 'prev')
    s_w_f_interpreter_0 = SWFInterpreter(tuple_0)
    assert (s_w_f_interpreter_0.method_pyfunctions[
        '_ym_wrap_playpause'] is not None)



# Generated at 2022-06-26 14:00:58.289948
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    if not isinstance(s_w_f_parsed_file_0, SWFParsedFile):
        raise ValueError('Variable s_w_f_parsed_file_0 is not of type SWFParsedFile')
    if not isinstance(s_w_f_interpreter_0, SWFInterpreter):
        raise ValueError('Variable s_w_f_interpreter_0 is not of type SWFInterpreter')
    s_w_f_interpreter_0.extract_function(s_w_f_parsed_file_0.avm_classes['~.~.AS3::Engine'], 'getVersion')


# Generated at 2022-06-26 14:01:04.551439
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    tuple_0 = (
        ('String', 'String'),
        ('String', 'split'),
        ('Array', 'slice'),
        ('String', 'length'),
        ('int', 'charCodeAt'),
    )
    s_w_f_interpreter_0 = SWFInterpreter(tuple_0)
    with open('test_data/swfinterpreter.asasm', 'rb') as f:
        s_w_f_interpreter_0.parse(f)

    # test extract_function with a function defined via classes
    # test extract_function with a function defined via DefineFunction2
    # test extract_function with a function defined via DefineFunction3

    # TODO better test coverage


# Generated at 2022-06-26 14:01:05.413332
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    test_case_0()


# Generated at 2022-06-26 14:01:11.179411
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    tuple_0 = ()
    s_w_f_interpreter_0 = SWFInterpreter(tuple_0)
    class_0 = _AVMClass(dict_0, dict_1, dict_2, dict_3)
    def function_0(tuple_0):
        return 
    tuple_1 = ('method', function_0)
    s_w_f_interpreter_0.patch_function(class_0, tuple_1)
    assert class_0.method_pyfunctions['method'] == function_0, 'patch_function returned unexpected value'


# Generated at 2022-06-26 14:01:12.254193
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 14:01:14.838111
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    tuple_0 = ()
    s_w_f_interpreter_0 = SWFInterpreter(tuple_0)


# Generated at 2022-06-26 14:01:20.071574
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    tuple_0 = ()
    s_w_f_interpreter_0 = SWFInterpreter(tuple_0)
    tuple_0 = ()
    a_v_m_class_0 = AVMClass('', tuple_0, {}, {}, {}, {}, {}, {}, {}, {}, {}, {})
    tuple_1 = (1, 2, 3, 4, 5)
    patch_function_0 = s_w_f_interpreter_0.patch_function(
        a_v_m_class_0, 'patch_function', tuple_1)
    tuple_1 = ()
    patch_function_1 = s_w_f_interpreter_0.patch_function(
        a_v_m_class_0, 'patch_function', tuple_1)


# Generated at 2022-06-26 14:01:26.791151
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    tuple_0 = ()
    s_w_f_interpreter_0 = SWFInterpreter(tuple_0)
    s_w_f_interpreter_1 = SWFInterpreter(tuple_0)
    s_w_f_interpreter_2 = SWFInterpreter(tuple_0)
    with pytest.raises(Exception):
        s_w_f_interpreter_0.extract_function(s_w_f_interpreter_1, s_w_f_interpreter_2)


# Generated at 2022-06-26 14:01:28.698141
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    tuple_0 = ()
    s_w_f_interpreter_0 = SWFInterpreter(tuple_0)

##

# Generated at 2022-06-26 14:01:34.377858
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    tuple_0 = ()
    s_w_f_interpreter_0 = SWFInterpreter(tuple_0)
    func_0 = s_w_f_interpreter_0.extract_function
    avm_class_0 = s_w_f_interpreter_0.extract_function.__defaults__[0]
    str_0 = 'toString'
    func_1 = func_0(avm_class_0, str_0)
    num_0 = func_1((),)
    assert num_0 == '[object Object]'
