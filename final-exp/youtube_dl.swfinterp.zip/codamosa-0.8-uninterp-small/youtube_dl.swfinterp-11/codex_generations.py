

# Generated at 2022-06-26 13:55:42.668012
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter_0 = SWFInterpreter()
    avm_class_0 = _AVMClass('undefined')
    method_0 = _MethodInfo(
        0, [], [], [],
        'test', 0, 0,
        [avm_class_0], '',
        1, 0, [], [], [],
        '',
        0, 0, 0, 0, 0, 0,
        0,
        [], [], [], [],
        [], [], [], [],
        [], [], [], [],
        [], [], [], [],
        [], [], [], [],
        [], [], [], [])
    avm_class_0.method_info.append(method_0)

# Generated at 2022-06-26 13:55:45.662950
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    bool_0 = False
    print('Testing constructor of class SWFInterpreter...')
    interpreter = SWFInterpreter(bool_0)
    assert interpreter.verbose == False
    assert interpreter.constant_strings == []
    assert interpreter.multinames == []
    assert interpreter.method_bodies == []
    assert interpreter.method_pyfunctions == {}


# Generated at 2022-06-26 13:55:51.320872
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    """
    Test that extract_class works as expected
    """
    swf = SWFInterpreter(data_case_0)
    swf.extract_class('TestClass')
    assert swf.extract_function('TestClass', 'test_method')([1, 2]) == 3
    assert swf.extract_function('TestClass', 'property_access')() == 4

# Check that SWF interpreter can correctly interpret a simple case

# Generated at 2022-06-26 13:55:57.065476
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm_class_0 = AVMClass('TestClass')
    method_0 = AVMMethod('test_method')
    method_0.body = '\x00\x00\x00\x00'
    avm_class_0.method_bodies.append(method_0)
    interp_0 = SWFInterpreter()
    interp_0.extract_function(avm_class_0, 'test_method')


# Generated at 2022-06-26 13:55:58.471223
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    try:
        test_case_0()
    except:
        raise RuntimeError('Method register_methods of class _AVMClass failed')

# Main program

# Wrap the main program in a function, so that we can call it
# from a REPL

# Generated at 2022-06-26 13:56:00.441166
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    # _AVMClass method register_methods should assign the variable var_0 to
    # the object returned by _ScopeDict method __repr__ (line 50).
    bool_0 = False
    scope_dict_0 = _ScopeDict(bool_0)
    var_0 = scope_dict_0.__repr__()
    # AssertionError: '_AVMClass(False__Scope({}))' != '{}'


# Generated at 2022-06-26 13:56:02.257319
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interp = SWFInterpreter('', 1)

# Generated at 2022-06-26 13:56:06.593962
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    file_path = 'avm.swf'
    swf = SWFInterpreter(file_path)


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-26 13:56:13.902273
# Unit test for method register_methods of class _AVMClass
def test__AVMClass_register_methods():
    bool_0 = True
    methods_0 = {
        '0': '0',
        '1': '1'
    }
    class_0 = _AVMClass('0', '1', methods_0)
    class_0.register_methods(methods_0)
    var_0 = class_0.name
    var_1 = class_0.method_names
    var_2 = class_0.method_idxs


# Generated at 2022-06-26 13:56:21.737891
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    file_obj = StringIO()
    file_obj.write(compat_struct_pack('>I', 0x00020001))
    file_obj.write(compat_struct_pack('>I', 0x02020001))
    file_obj.seek(0)
    swf_interpreter = SWFInterpreter(file_obj)

    assert_equals(0x00020001, swf_interpreter.file_version)
    assert_equals(0x02020001, swf_interpreter.file_length)


# Generated at 2022-06-26 13:57:13.848838
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    test_case_0()
    assert True


# Generated at 2022-06-26 13:57:17.403508
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = '',
    s_w_f_interpreter_0.extract_class(str_1)


# Generated at 2022-06-26 13:57:21.870156
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = 'Main'
    class_object_0 = s_w_f_interpreter_0.extract_class(str_1)
    assert class_object_0.__class__ == _AVMClass


# Generated at 2022-06-26 13:57:27.494169
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    print('Testing constructor of class SWFInterpreter')
    _filename = 'avm.swf'
    try:
        _DUT = SWFInterpreter(_filename)

    except Exception as e:
        print('Constructor of class SWFInterpreter raised following exception:')
        print(e)



# Generated at 2022-06-26 13:57:28.730784
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

    return 'success'



# Generated at 2022-06-26 13:57:32.187742
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    method_0_0 = test_case_0()
    # assert method_0_0 ==
    method_1_0 = test_case_1()
    # assert method_1_0 ==


# Generated at 2022-06-26 13:57:34.058384
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # def extract_class(self, class_name, super_class=None):
    assert True == False, "Not implemented"



# Generated at 2022-06-26 13:57:35.457464
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

test_SWFInterpreter()

# Generated at 2022-06-26 13:57:40.156100
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    int_0 = 0
    str_1 = 'Main'
    _AVMClass__0 = s_w_f_interpreter_0.extract_class(int_0, str_1)
    _py_builtin_print(_AVMClass__0)


# Generated at 2022-06-26 13:57:46.460895
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm_class_0 = _AVMClass('<class 0>', [], {})
    str_0 = 'test_method'
    swf_interpreter_0 = SWFInterpreter()
    function_0 = swf_interpreter_0.extract_function(avm_class_0, str_0)
    # Type of function_0 should be function, but it is None
    assert False


# Generated at 2022-06-26 13:58:57.667886
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # For now, simply call the test_case_0 function
    test_case_0()

#    def test_case_1(self):
#        str_0 = 'avm.swf'
#        SWFInterpreter_0 = SWFInterpreter(str_0)
#        s_w_f_interpreter_0 = SWFInterpreter_0
#
#    # Unit test for constructor of class SWFInterpreter
#    def test_SWFInterpreter(self):
#        # For now, simply call the test_case_1 function
#        self.test_case_1()


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-26 13:59:01.353221
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = 'AS3::AVM2::FJPlayer'
    swf_class_0 = s_w_f_interpreter_0.extract_class(str_1)


# Generated at 2022-06-26 13:59:03.070611
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    print('Testing SWFInterpreter...')
    test_case_0()
    print('Done')


# Generated at 2022-06-26 13:59:03.819419
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()


# Generated at 2022-06-26 13:59:11.341424
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    method_name = 'SWFInterpreter.extract_class'
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = 'Object'
    a_v_m_class_0 = s_w_f_interpreter_0.extract_class(str_1)
    str_2 = 'StringClass'
    assert str_2 == a_v_m_class_0.name


# Generated at 2022-06-26 13:59:19.219065
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = 'flash.display.MovieClip'
    a_v_m_class_0 = s_w_f_interpreter_0.extract_class(str_1)
    str_2 = 'flash.display.MovieClip'
    d_i_c_t_0 = s_w_f_interpreter_0.extract_class(str_2).static_properties
    str_3 = '__init__'
    d_i_c_t_1 = a_v_m_class_0.method_pyfunctions
    function_0 = d_i_c_t_1[str_3]
    o_b_

# Generated at 2022-06-26 13:59:24.274287
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = 'swfdata'
    str_1 = '0123456789'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    avm_class_0 = s_w_f_interpreter_0.extract_class(str_1)
    str_2 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    avm_class_1 = s_w_f_interpreter_0.extract_class(str_2)
    assert avm_class_1._name == 'com.greensock.plugins.ColorTransformPlugin'


# Generated at 2022-06-26 13:59:26.048457
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    test_case_0()

if __name__ == '__main__':
    test_SWFInterpreter_patch_function()

# Generated at 2022-06-26 13:59:32.764403
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = 'test'
    avm_class_1 = s_w_f_interpreter_0.avm_classes['Foo']
    pyfunc_0 = s_w_f_interpreter_0.extract_function(avm_class_1, str_1)
    str_2 = 'foobar_%s_%d_%s' % ('foo', 0, '\uabcd')
    assert pyfunc_0(str_2) == str_2
    int_0 = 1
    float_0 = 3.1

# Generated at 2022-06-26 13:59:41.574388
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    _AVMClass_0 = AVMClass()
    str_1 = 'TestVars'
    _AVMClass_0.name = str_1
    str_2 = 'AS3'
    _AVMClass_0.version = str_2
    str_3 = 'Ljava.lang.Object;'
    _AVMClass_0.super_name = str_3
    _ScopeDict_0 = _ScopeDict()
    _ScopeDict_0.avm_class = _AVMClass_0
    str_4 = 'TestVars'

# Generated at 2022-06-26 14:02:08.257819
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = 'Object'
    a_v_m_class_0 = s_w_f_interpreter_0.extract_class(str_1)


# Generated at 2022-06-26 14:02:09.592034
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-26 14:02:13.855236
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    def func_0(arg_0):
        return arg_0
    assert s_w_f_interpreter_0.patch_function('func_0', func_0) == func_0


# Generated at 2022-06-26 14:02:15.154752
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # TODO: add tests
    return

if __name__ == '__main__':
    test_case_0()
    test_SWFInterpreter()

# Generated at 2022-06-26 14:02:19.698605
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    str_1 = 'decode'
    str_2 = 'SWFInterpreter'
    dict_0 = s_w_f_interpreter_0.extract_function(str_1, str_2)


# Generated at 2022-06-26 14:02:26.045406
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    avm_class_0 = _AVMClass({
        'name': 'foo',
        'static_properties': {
            'bar': _Undefined,
        },
        'methods': {
            'foo': {
                'body': ((SWFInstruction(opcode=36, args=[1]), ), ),
                'name': 'foo'
            }
        }
    })
    foo_func_0 = SWFInterpreter.extract_function(avm_class_0, 'foo')
    foo_0 = foo_func_0()
    assert foo_0 == 1


# Generated at 2022-06-26 14:02:29.753938
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Test for constructor
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)



# Generated at 2022-06-26 14:02:30.864904
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    test_case_0()

###########
# TESTING #
###########


# Generated at 2022-06-26 14:02:39.176655
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = 0
    int_4 = 0
    int_5 = 0
    int_6 = 0
    int_7 = 0
    int_8 = 0
    int_9 = 0
    int_10 = 0
    int_11 = 0
    int_12 = 0
    int_13 = 0
    int_14 = 0
    int_15 = 0
    int_16 = 0
    int_17 = 0
    int_18 = 0
    int_19 = 0
    int_20 = 0
    int_21 = 0
    int_22 = 0
   

# Generated at 2022-06-26 14:02:46.605451
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = 'avm.swf'
    s_w_f_interpreter_0 = SWFInterpreter(str_0)
    _AVMClass_0 = s_w_f_interpreter_0._AVMClass[0]
    assert _AVMClass_0.name == 'Object'
    _AVMClass_Object_0 = _AVMClass_0.make_object()
    _AVMClass_1 = s_w_f_interpreter_0._AVMClass[1]
    assert _AVMClass_1.name == 'Dictionary'
    _AVMClass_2 = s_w_f_interpreter_0._AVMClass[2]
    assert _AVMClass_2.name == 'Array'
