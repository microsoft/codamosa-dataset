

# Generated at 2022-06-26 13:56:03.015629
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    global _multiname

    interpreter = SWFInterpreter()

    _AVMClass_Object = interpreter.get_avm_class('Object')
    _instance = _AVMClass_Object.make_object()

    # detect extract_function method
    try:
        _fun = interpreter.extract_function(_instance, '_')
    except NotImplementedError:
        return

    # case 0
    _fun = interpreter.extract_function(_instance, '_')
    test_case_0()



# Generated at 2022-06-26 13:56:15.115492
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    class TestSWFInterpreter(SWFInterpreter):
        def extract_function(self, avm_class, func_name):
            # Override, as it depends on other methods
            return lambda args: 'fake(%s)' % ', '.join(map(repr, args))

    swf = TestSWFInterpreter()


# Generated at 2022-06-26 13:56:25.838178
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf = SWF()
    swf.trailer.signature = 'FWS'
    swf.trailer.compression = 'zlib'
    swf.trailer.version = 12
    swf.trailer.length = 10
    swf.header.signature = 'CWS'
    swf.header.version = 12
    swf.header.length = 10
    tag = Tag()
    tag.type = 72
    tag.id = 0
    tag.data = b''
    tag.length = 0
    swf.tags.append(tag)
    with io.BytesIO(b'') as f:
        swf.save_to_fileobj(f)
    swf_interpreter = SWFInterpreter(swf)

# Generated at 2022-06-26 13:56:30.515986
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from .swf import SWF
    from io import BytesIO

    # Test decoding of sample1.swf (do not fail)
    sample_file = os.path.join('test', 'sample1.swf')
    with open(sample_file, 'rb') as f:
        swf = SWF(BytesIO(f.read()))
        swf.parse()

    # Test decoding of sample2.swf (and at least one method)
    sample_file = os.path.join('test', 'sample2.swf')
    with open(sample_file, 'rb') as f:
        swf = SWF(BytesIO(f.read()))
        swf.parse()

# Generated at 2022-06-26 13:56:35.795295
# Unit test for method extract_function of class SWFInterpreter

# Generated at 2022-06-26 13:56:46.545586
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    avm_interpreter = SWFInterpreter(_TagType('tag0', 1, None, None))
    avm_interpreter.constant_strings = [
        'this', 'printf', 'dprintf', 'traceprintf', 'trace', 'length',
        'slice',
        'split', 'join', 'charCodeAt',
    ]
    avm_interpreter.constant_namespaces = [
        _ConstantNamespace('http://adobe\.com/AS3/2006/builtin', 0),
    ]
    avm_interpreter.constant_namespace_sets = [
        [0],
    ]

# Generated at 2022-06-26 13:56:55.284807
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    with open('../../video_samples/sample_01.swf', 'rb') as f:
        swf = f.read()
    swf_interpreter = SWFInterpreter(swf)
    assert len(swf_interpreter.constant_strings) == 10
    assert swf_interpreter.constant_strings[0] == '_function_'
    assert swf_interpreter.constant_strings[1] == '0'
    assert swf_interpreter.constant_strings[2] == '1'
    assert swf_interpreter.constant_strings[3] == '2'
    assert swf_interpreter.constant_strings[4] == '3'
    assert swf_interpreter.constant_strings[5] == '4'


# Generated at 2022-06-26 13:57:00.134884
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    print('Testing method: extract_class of class: SWFInterpreter')
    str_0 = b'\x02\x00'

# Generated at 2022-06-26 13:57:10.320157
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    avm_class_0 = AVMClass(constant_strings=['_level0'])
    avm_method_0 = AVMMethod(code=[8, 0, 32, 192])
    avm_class_0.method_names['_level0'] = avm_method_0
    avm_class_0.static_properties['_level0'] = {'width': 1, 'height': 1}
    avm_class_0.static_properties['_level0']['visible'] = 1
    avm_class_0.static_properties['_level0']['name'] = '_level0'
    swf_interpreter_0 = SWFInterpreter()
    swf_interpreter_0.extract_class(avm_class_0)


# Generated at 2022-06-26 13:57:19.161861
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 13:59:39.155936
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    SWFInterpreter()


# Generated at 2022-06-26 13:59:44.486692
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    from flash_proxy import SWFInterpreter, SWFUploader
    SWFInterpreter.extract_function(None,None)
    SWFInterpreter.extract_function(SWFInterpreter(),None)
    SWFInterpreter.extract_function(None,"")
    SWFInterpreter.extract_function(SWFInterpreter(),"")
    SWFInterpreter.extract_function(SWFInterpreter(),"asdf")
    SWFInterpreter.extract_functio

# Generated at 2022-06-26 13:59:45.859420
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # No need to test, we do not actually do patching
    pass


# Generated at 2022-06-26 13:59:55.634776
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    interpreter = SWFInterpreter()

    class C:
        def __init__(self, *args):
            self.name = 'C'
            self.args = args
            self.member0 = 'member0'

        def f(self, x):
            return 'C.f(%r)' % x

        def multiname(self):
            return 'C.multiname'

    class D:
        def __init__(self, *args):
            self.name = 'D'
            self.args = args
            self.member0 = 'member0'

        def f(self, x):
            return 'D.f(%r)' % x

        def g(self, x, y):
            return 'D.g(%r, %r)' % (x, y)


# Generated at 2022-06-26 14:00:03.024400
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 14:00:08.291212
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():

    # avm_class is an instance of class AVMClass
    # multinames is an instance of list

    # Test function
    def test_func(self, avm_class, multinames):
        return avm_class._SWFInterpreter__extract_class(avm_class, multinames)

    _SWFInterpreter__extract_class = test_func

    # Verify the contents of instance an instance of class AVMClass
    def test_func(self, avm_class):
        for attr in dir(avm_class):
            if attr.startswith('__'):
                continue
            if getattr(avm_class, attr) is None:
                assert False, \
                    'Attribute "%s" of class AVMClass has a value of None' \
                    % attr



# Generated at 2022-06-26 14:00:13.211956
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    try:
        file = open(r'C:\Users\Kurosaki.T\Desktop\YJ.swf', 'rb')
    except FileNotFoundError:
        print('Test file not found')
        return
    swf = SWF(file)
    si = SWFInterpreter(swf)


if __name__ == '__main__':
    test_SWFInterpreter()

# Generated at 2022-06-26 14:00:14.790840
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    interpreter = SWFInterpreter()
    assert undefined_0 == _Undefined()
    return interpreter



# Generated at 2022-06-26 14:00:24.486024
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    from io import BytesIO


# Generated at 2022-06-26 14:00:27.219966
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    r = SWFInterpreter(valid_swfs[0])
    undefined_0 = _Undefined()
    test_case_0()


# Generated at 2022-06-26 14:02:17.928518
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    str_0 = ' - Charlie Rose'
    a_v_m_class__object_0 = _AVMClass_Object(str_0)
    a_v_m_class__object_0.avm_class.method_names = []
    str_1 = 'charCodeAt'
    int_0 = a_v_m_class__object_0.avm_class.method_pyfunctions[str_1]([])
    assert int_0 == 32, 'Expected 32, got %d' % int_0


# Generated at 2022-06-26 14:02:26.642337
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    '''
    Test method patch_function of class SWFInterpreter
    '''
    # [0] Test case 0
    str_0 = ' - Charlie Rose'
    a_v_m_class__object_0 = _AVMClass_Object(str_0)
    a_v_m_class__object_0.set_variable('name', str_0)
    swf_interpreter_0 = SWFInterpreter(a_v_m_class__object_0.avm_class, str_0)
    swf_interpreter_0.patch_function()
    assert swf_interpreter_0.extract_function(a_v_m_class__object_0.avm_class, 'name')() == str_0


# Generated at 2022-06-26 14:02:35.805817
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    str_0 = ' - Charlie Rose'
    a_v_m_class__object_0 = _AVMClass_Object(str_0)
    method_names_0 = ['toString', 'charCodeAt', 'indexOf', 'charAt', 'split', 'match', 'slice', 'join', 'lastIndexOf']
    static_properties_0 = {'length': 0}
    static_properties_1 = {'length': 1}
    static_properties_0.update(static_properties_1)
    a_v_m_class_0 = _AVMClass(method_names_0, static_properties_0)
    a_v_m_class__object_0.avm_class = a_v_m_class_0

# Generated at 2022-06-26 14:02:41.501552
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm_class = _AVMClass('String')
    avm_class.make_method(
        'String',
        'String',
        (('u30', 'int_0'),),
        'this = String(this_ptr.string);')
    avm_class.string = 'this is a string'
    interp = SWFInterpreter()
    interp.extract_function(avm_class, 'String')
    res = interp.extract_function(avm_class, 'String')(avm_class, [11])
    assert res == 'this is'


# Generated at 2022-06-26 14:02:42.478632
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_interpreter_0 = SWFInterpreter()



# Generated at 2022-06-26 14:02:45.894313
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    with open(os.path.join(os.path.dirname(__file__), 'test.swf'), 'rb') as f:
        swf = SWFInterpreter(f)
        swf.extract_class(0)
        test_case_0()


# Generated at 2022-06-26 14:02:53.862006
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm_class = _AVMClass(0)
    avm_class.method_names.add('toString')

# Generated at 2022-06-26 14:03:02.013650
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf_interpreter_0 = SWFInterpreter(open(test_case_0, 'rb'), 0)
    str_a = 'substr'
    func_a = swf_interpreter_0.extract_function(str_0, str_a)
    list_0 = [None] * 2
    int_0 = 13
    list_0[0] = int_0
    int_1 = -1
    list_0[1] = int_1
    res_a = func_a(list_0)

if __name__ == '__main__':
    test_SWFInterpreter_extract_function()

# Generated at 2022-06-26 14:03:11.951247
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    avm_class = _AVMClass('String', [], [], [
        ('toLowerCase', [], ['String']),
        ('substr', ['i', 'l'], ['String']),
    ])
    avm_class.make_object()

    constant_strings = [
        'toLowerCase', 'substr', 'abcdefg', 'abc', 'String',
    ]
    multinames = [
        'toLowerCase', 'substr', 'abcdefg', 'abc', 'String',
    ]

    def u30():
        return 0

    def s24():
        return 0

    def _read_byte(coder):
        return 0

    #asm0 = SWFAssembler([])
    #asm0.add_opcode(2)  # getlocal_0
    #asm0.

# Generated at 2022-06-26 14:03:13.550350
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    objectUnderTest = SWFInterpreter()
    objectUnderTest.extract_function(test_case_0(), 'trim')
