

# Generated at 2022-06-26 13:55:50.693780
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    obj_0 = SWFInterpreter()
    obj_0.decompile()


# Generated at 2022-06-26 13:55:52.814628
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    # Check constructor
    x = SWFInterpreter()
    # Check type
    assert isinstance(x, SWFInterpreter), "Constructor create incorrect type"



# Generated at 2022-06-26 13:55:55.106531
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    """Test constructor of class SWFInterpreter"""
    instance = SWFInterpreter()
    assert isinstance(instance, SWFInterpreter)


# Generated at 2022-06-26 13:55:59.592725
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    swf_interpreter = SWFInterpreter()
    swf_interpreter.tag_functions = [(lambda tag: None)] # <== oom bug
    swf_interpreter.doabc_tags = {}
    swf_interpreter.patch_function()


# Generated at 2022-06-26 13:56:03.293391
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf_data = compat_urllib_request.urlopen(
        'https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/vimeo.py?raw=true').read()
    swf_interpreter = SWFInterpreter(swf_data)
    swf_interpreter.run()


# Generated at 2022-06-26 13:56:11.377147
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    swf = open(os.path.join(os.path.dirname(__file__), 'sample_SWF_0.swf'), 'rb').read()
    interpreter = SWFInterpreter(swf)
    avm_class = interpreter.extract_class('TestClass')
    method_name = 'testCase0'
    assert method_name in avm_class.method_names

    resfunc = interpreter.extract_function(avm_class, method_name)
    assert resfunc() is None

# Generated at 2022-06-26 13:56:13.858248
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    trace_bounds = None
    instance = SWFInterpreter(trace_bounds)


# Generated at 2022-06-26 13:56:24.318517
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # Create a SWFInterpreter object
    si = SWFInterpreter()
    si.constant_strings = ['undefined_0', 'var_0', '__bool__']
    si.classes = [
        ('test_case_0', {'super_name': 'Object', 'traits': []}),
    ]

# Generated at 2022-06-26 13:56:26.012696
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    # We don't test SWFInterpreter.extract_class on a real class
    # as the classes are actually very simple, and the code for
    # extracting functions is tested in other places anyway
    assert True


# Generated at 2022-06-26 13:56:33.792103
# Unit test for method extract_class of class SWFInterpreter

# Generated at 2022-06-26 13:57:35.172761
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    swf = SWFInterpreter()

# Compile a unit test for the constructor above

# Generated at 2022-06-26 13:57:40.927442
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    string_0 = 'C'
    list_0 = []
    a_v_m_class_0 = _builtin_classes['Boolean'](list_0)
    thread_0 = _AVMThread(string_0, a_v_m_class_0)
    s_w_f_interpreter_0 = SWFInterpreter(thread_0)
    function_0 = s_w_f_interpreter_0.extract_function(a_v_m_class_0, string_0)
    assert function_0 is undefined


# Generated at 2022-06-26 13:57:48.154831
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # Test a trivial case
    class TrivialSWFInterpreter(SWFInterpreter):
        def extract_function(self, avm_class, func_name, func_coder):
            def resfunc(args):
                return 0
            return resfunc

    trivial_s_w_f_interpreter_0 = TrivialSWFInterpreter()
    trivial_s_w_f_interpreter_0.patch_function('', '', None)



# Generated at 2022-06-26 13:57:57.147894
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    # Create a mock object
    swf_interpreter = SWFInterpreter()

    # Set up the method input parameters
    avm_class = _AVMClass(['test1', 'test2'], ['method1', 'method2'])
    func_name = 'test2'

    # Invoke method
    resfunc = swf_interpreter.extract_function(avm_class, func_name)

    assert resfunc is avm_class.method_pyfunctions[func_name]

    for v in [1, 1.2, undefined, True, False, None]:
        res = resfunc([v])
        assert res == v

    for v in ['test1', 'test2']:
        res = resfunc([v])
        assert res == v


# Generated at 2022-06-26 13:58:05.078647
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    si = SWFInterpreter()

# Generated at 2022-06-26 13:58:10.017854
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    """Test method extract_class of class SWFInterpreter."""
    swf_data = make_SWF_test_data()
    swf = SWFInterpreter(swf_data)
    avm_class = swf.extract_class(0)
    assert isinstance(avm_class, _AVMClass)
    assert avm_class.variables == {
        'name': 'TestClass',
    }



# Generated at 2022-06-26 13:58:20.171073
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    list_0 = []
    a_v_m_class__object_0 = _AVMClass_Object(list_0)
    _AVMClass_Object_0 = _AVMClass_Object
    _AVMClass_Object_0.methods = {
        'String': function_0,
        'split': function_1,
        'charCodeAt': function_2,
    }

# Generated at 2022-06-26 13:58:23.377459
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    # this_0 - this_0 is a local variable of type SWFInterpreter
    this_0 = SWFInterpreter()

    # Method call
    this_0.patch_function(None)


# Generated at 2022-06-26 13:58:32.900954
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    avm_class = _AVMClass()
    avm_class.static_properties = {'val': 3.0}

    abc_data = b'\x01\x0e\x0c\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    abc_data += b'\x00\x00\x00\x00'
    abc_data += b'\x00\x00\x00\x00'
    abc_data += b'\x01\x09'

# Generated at 2022-06-26 13:58:36.687555
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    interpreter = SWFInterpreter(None, {})

    # Testing method patch_function
    interpreter.patch_function(None, None)


# Generated at 2022-06-26 14:00:32.554128
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    list_0 = []
    a_v_m_class__object_0 = _AVMClass_Object(list_0)
    swf_interpreter = SWFInterpreter()
    swf_interpreter.extract_function(
        a_v_m_class__object_0, 'Object', 'toString')


# Generated at 2022-06-26 14:00:33.480756
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    test_case_0()


# Generated at 2022-06-26 14:00:35.417337
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    list_0 = []
    assert isinstance(_AVMClass_Object(list_0), _AVMClass_Object)



# Generated at 2022-06-26 14:00:39.490853
# Unit test for method patch_function of class SWFInterpreter
def test_SWFInterpreter_patch_function():
    s = SWFInterpreter()

    def add_0(x, y):
        return x + y

    def add_1(x, y):
        return x + y + 1

    mname = 'add'
    # Patch function 'add_0' with new function 'add_1'
    s.patch_function(mname, add_0, add_1)

    assert s.avm_functions[mname] == add_1


# Generated at 2022-06-26 14:00:43.709832
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    obj = SWFInterpreter()
    # Test case 0
    func_name = 'method_0'
    obj.extract_function(test_case_0, func_name)


if __name__ == '__main__':
    test_SWFInterpreter_extract_function()

# Generated at 2022-06-26 14:00:53.068981
# Unit test for constructor of class SWFInterpreter
def test_SWFInterpreter():
    print('Tests for SWFInterpreter')
    # Case 0
    interpreter = SWFInterpreter(None)
    assert interpreter.str_repository is None
    assert interpreter.abc_repository is None
    assert interpreter.constant_strings == []
    assert interpreter.constant_ints == []
    assert interpreter.constant_uints == []
    assert interpreter.constant_doubles == []
    assert interpreter.method_bodies == []
    assert interpreter.method_names == []
    assert interpreter.constant_ns == []
    assert interpreter.constant_ns_sets == []
    assert interpreter.constant_multinames == []
    assert isinstance(interpreter.classes, dict)
    assert interpreter.class_names == []
    assert interpreter.script_names == []
    assert interpreter.method_

# Generated at 2022-06-26 14:01:00.881936
# Unit test for method extract_function of class SWFInterpreter
def test_SWFInterpreter_extract_function():
    _dummy_avm_class = _AVMClass('class_0')
    _method_name = 'method_0'
    _method_body = _MethodBody([], [])
    _method_body.code = b'\x01\x01\x00'
    _method_body.method_body_size = 3
    _method_body.min_stack = 1
    _method_body.max_stack = 1
    _method_body.local_count = 0
    _method_body.init_scope_depth = 0
    _method_body.max_scope_depth = 1

    _method = _Method(_method_name, _method_body, [])

    _methods = [_method]


# Generated at 2022-06-26 14:01:04.844670
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter_0 = _SWFInterpreter(None)

    swf_interpreter_0.extract_class(None, None)


# Generated at 2022-06-26 14:01:10.612444
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    list_0 = []
    a_v_m_class__object_0 = _AVMClass_Object(list_0)
    a_v_m_class__object_0.static_properties["length"] = 0
    a_v_m_class__object_2 = _AVMClass_Object(a_v_m_class__object_0)
    a_v_m_class_object_1 = _AVMClass("Object", a_v_m_class_object_2)
    a_v_m_class__object_2.static_properties["length"] = 0
    string_class_0 = _AVMClass("String", a_v_m_class_object_1)
    a_v_m_class__object_0.static_properties["length"] = 0
    a_v_m_class

# Generated at 2022-06-26 14:01:14.351760
# Unit test for method extract_class of class SWFInterpreter
def test_SWFInterpreter_extract_class():
    swf_interpreter_0 = SWFInterpreter()
    list_0 = []
    a_v_m_class_0 = _AVMClass(0, list_0)
    swf_interpreter_0.extract_class(a_v_m_class_0)

